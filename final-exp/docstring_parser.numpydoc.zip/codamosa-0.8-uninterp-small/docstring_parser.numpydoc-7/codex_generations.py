

# Generated at 2022-06-25 16:24:03.011067
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser_0 = NumpydocParser()
    str_0 = 'x'
    str_1 = 'Vb*A1J'
    str_2 = 'p'
    str_3 = 'C7^\x7f'
    str_4 = 'T.1n'
    meta_0 = parser_0.parse(str_0)
    assert isinstance(meta_0, Docstring)

    parser_1 = NumpydocParser()
    meta_0 = parser_1.parse(str_0)
    meta_1 = parser_1.parse(str_1)
    meta_2 = parser_1.parse(str_2)
    meta_3 = parser_1.parse(str_3)
    meta_4 = parser_1.parse(str_4)

# Generated at 2022-06-25 16:24:10.086876
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'S,\x0bf<;}$UHmzlj&{uB0'
    section_0 = Section(str_0, str_0)
    NumpydocParser_instance_0 = NumpydocParser({str_0: section_0})
    str_1 = "[m(Yrc$=Zi~Qo,O>|<aA@"
    Docstring_instance_0 = NumpydocParser_instance_0.parse(str_1)


# Generated at 2022-06-25 16:24:23.770651
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = '7:%h|CVpP(F\x0b'
    str_1 = 'szc#\x7fI\x7fP4a<nUo'
    str_2 = 'k6S\x0b'
    int_0 = 234
    str_3 = '%\x7fU'
    str_4 = 'lD|\x7f'
    str_5 = '\x0b\x0bUD'
    str_6 = '\x0by\x0bL\x7f& '
    str_7 = '\x0b\x7fL'
    str_8 = 'lD|\x7f'
    str_9 = '\x0b\x0bUD'

# Generated at 2022-06-25 16:24:36.822970
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'S,\x0bf<;}$UHmzlj&{uB0'
    str_1 = 'x2+6x+9'
    str_2 = 'XZhk-}@'
    str_3 = '8,\x0b<oKj$MJ:1*ZRX,WLE0'
    str_4 = '\x0c'
    str_5 = 'T$Z:l&X8*A1j'
    str_6 = '#D_F)B6/jU6-/'
    str_7 = '$D_F)B6/jU6-/'
    str_8 = '4'
    str_9 = '9I{@u}=hGc7M.'

# Generated at 2022-06-25 16:24:51.169131
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_1 = 'S,\x0bf<;}$UHmzlj&{uB0'
    docstring_1 = numpydoc_parser_0.parse(str_1)
    str_2 = 'S,\x0bf<;}$UHmzlj&{uB0'
    str_3 = ",\x0c"
    params_section_1 = ParamSection(str_2, str_3)
    str_4 = 'S,\x0bf<;}$UHmzlj&{uB0'
    raises_section_0 = RaisesSection(str_4, str_4)
    str_5 = 'S,\x0bf<;}$UHmzlj&{uB0'
   

# Generated at 2022-06-25 16:24:58.015619
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_0 = '\n    short description\n    long description\n    '
    section_0 = ParamSection('Arguments', 'param')
    numpydoc_parser_0 = NumpydocParser({section_0.title: section_0})

    result_0 = numpydoc_parser_0.parse(text_0)

    assert result_0.short_description == 'short description'


# Generated at 2022-06-25 16:25:10.994080
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_2 = 'R>0{@!x/%Ozj\n<1(:g1a&3qHkzt\nylD#'
    meta_0 = {'param': [DocstringParam(args=['param', 'hi'], description='good')]}
    parser_0 = NumpydocParser()
    docstring_0 = parser_0.parse(str_2)
    assert docstring_0.short_description == 'Test comment.'
    assert docstring_0.long_description == 'More test comment.\n\nWow.'
    assert docstring_0.meta == meta_0
    assert docstring_0.blank_after_long_description
    assert docstring_0.blank_after_short_description


# Generated at 2022-06-25 16:25:26.054453
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    returns_section_0 = ReturnsSection('Returns', 'returns')
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.add_section(returns_section_0)
    numpydoc_parser_0.add_section(returns_section_0)
    numpydoc_parser_0.add_section(returns_section_0)

    assert(numpydoc_parser_0.titles_re.pattern ==
           r'(?m)^Returns\s*?\n------\s*$|(?m)^Returns\s*?\n------\s*$|(?m)^Returns\s*?\n------\s*$')
    numpydoc_parser_0.parse('Returns value')


# Generated at 2022-06-25 16:25:31.159740
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser_0 = NumpydocParser()
    str_0 = '"""}Cv`w'
    str_1 = '~\x1aZ|M\x19X\x1f&'
    parser_0.parse(str_0 + str_1)


# Generated at 2022-06-25 16:25:38.267273
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_0 = inspect.cleandoc(
        "short desciption\nthis is the long description\n"
    )
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse(
        text_0
    )
    assert docstring_0.short_description == 'short desciption'
    assert docstring_0.long_description == 'this is the long description'
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.blank_after_short_description is True

# Generated at 2022-06-25 16:25:54.137800
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    print(numpydoc_parser_0)
    str_0 = 'This is the short docstring\n\nThis is the long docstring.\n\n'
    print(inspect.cleandoc(str_0))
    print(numpydoc_parser_0.parse(str_0))

    str_1 = '''
    This is the short docstring

    This is the long
    docstring.
    '''

    Docstring_0 = numpydoc_parser_0.parse(str_1)
    print(Docstring_0)
    print(Docstring_0.short_description)
    print(Docstring_0.long_description)
    print(Docstring_0.blank_after_short_description)
   

# Generated at 2022-06-25 16:26:06.493344
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Arrange
    numpydoc_parser = NumpydocParser()
    text = '''
        Parameters
        ----------
        text : int
            Text to be parsed.

        Returns
        -------
        Docstring
            Parsed docstring.
        '''

    # Act
    result = numpydoc_parser.parse(text)

    # Assert
    assert len(result.meta) == 2
    assert isinstance(result.meta[0], DocstringParam)
    assert result.meta[0].arg_name == "text"
    assert result.meta[0].type_name == "int"
    assert result.meta[0].description == "Text to be parsed."
    assert isinstance(result.meta[1], DocstringReturns)
    assert result.meta[1].type_name == "Docstring"


# Generated at 2022-06-25 16:26:17.147136
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    text_1 = ('Single line description.\n'
              '\n'
              'Additional description that spans multiple lines.')
    docstring_1 = numpydoc_parser_1.parse(text_1)
    assert docstring_1.short_description == 'Single line description.'
    assert (docstring_1.long_description ==
            'Additional description that spans multiple lines.')
    assert not docstring_1.blank_after_short_description
    assert docstring_1.blank_after_long_description
    assert len(docstring_1.meta) == 0
    text_2 = ('Single line description.\n'
              '\n'
              '\n'
              'Additional description that spans multiple lines.')

# Generated at 2022-06-25 16:26:29.467710
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # Test case with no docstring
    assert numpydoc_parser_0.parse("") == Docstring()

    # Test case with an inline docstring
    text_1 = """
    This is a docstring.
    """
    docstring_1 = Docstring(
        short_description="This is a docstring."
    )
    assert numpydoc_parser_0.parse(text_1) == docstring_1

    # Test case with a multi-line docstring
    text_2 = """
    This is a docstring.

    The short description is followed by
    a blank line and the long description.
    """

# Generated at 2022-06-25 16:26:35.399700
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Instantiate NumpyDocParser class object
    numpydoc_parser = NumpydocParser()
    # Instantiate Docstring class object
    docstring = Docstring()
    # Read docstring from .py file
    with open("demo.py", "r") as f:
        file = f.read()
        docstring_from_file = inspect.getdoc(file)
        # Call parse method of NumpyDocParser class object with docstring
        actual_result = numpydoc_parser.parse(docstring_from_file)
        # Call parse method of NumpyDocParser class object without docstring
        numpydoc_parser.parse()
    assert docstring_from_file is not None
    assert actual_result is not None
    assert docstring_from_file is not None

# Generated at 2022-06-25 16:26:38.353140
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 = "test_string"
    result_mock_0 = numpydoc_parser_0.parse(str_0)


# Generated at 2022-06-25 16:26:45.098134
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:26:55.508745
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:27:07.583844
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()

    text = """
    A test docstring with a couple of paragraphs.

    Paragraphs are separated by a blank line.

    Any amount of whitespace can be used, but at least one blank
    line should be present.

    Args:
        arg_1: The first arg.
        arg_2: The second arg.

    Returns:
        True if everything was fine.

    Raises:
        ValueError: in the case of a problem.
    """
    docstring = numpydoc_parser_1.parse(text)

    assert docstring.short_description == "A test docstring with a couple of paragraphs."

# Generated at 2022-06-25 16:27:13.190981
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    result = numpydoc_parser_0.parse("")
    assert result == {
        'args': [],
        'description': None,
        'short_description': None,
        'long_description': None,
        'blank_after_short_description': False,
        'blank_after_long_description': False
    }

# Generated at 2022-06-25 16:27:29.105192
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring = numpydoc_parser_0.parse('')
    # Assert that the docstring is empty
    assert (docstring == Docstring(short_description = None, long_description = None, meta = [])), "Return value: {}, is not Docstring(short_description = None, long_description = None, meta = [])".format(repr(docstring))
    docstring = numpydoc_parser_0.parse('    ')
    # Assert that the docstring is empty

# Generated at 2022-06-25 16:27:41.296675
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstr = 'Function to compute the L2 distance between two vectors.\n\n    Computes the L2 distance between two vectors.\n\n        Examples\n        --------\n\n        >>> a = np.array([1, 2, 3])\n        >>> b = np.array([4, 5, 6])\n        >>> dist(a, b)\n        5.196152422706632\n\n    '
    text = inspect.cleandoc(docstr)
    docstring = numpydoc_parser_0.parse(text)
    assert docstring.short_description == 'Function to compute the L2 distance between two vectors.', "Assert failed on docstring.short_description == 'Function to compute the L2 distance between two vectors.'"

# Generated at 2022-06-25 16:27:52.840996
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    docstr_1 = '''
    Parameters
    ----------
    a : int
        This is a.

    b : float
        This is b.

    Returns
    -------
    x : int
        This is x.

    y : float
        This is y.
    '''
    parsed_1 = numpydoc_parser_1.parse(docstr_1)
    assert parsed_1.short_description is None
    assert parsed_1.blank_after_short_description is False
    assert parsed_1.long_description is None
    assert parsed_1.blank_after_long_description is False

# Generated at 2022-06-25 16:27:59.214681
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:28:07.461827
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = "Panda Panda Panda\n Panda Panda Panda\n\n"
    assert numpydoc_parser_0.parse(text) == Docstring(
        short_description="No example test provided",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="Panda Panda Panda\n Panda Panda Panda",
        meta=[],
    )



# Generated at 2022-06-25 16:28:19.787771
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:28:32.686252
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import io
    import pytest

    # Constructor test
    obj = NumpydocParser()

    # Read the expected result from the unit test file
    expected = []
    with io.open("tests/results/test_numpydocparser_parse.txt", "r") as fd:
        for line in fd:
            expected.append(line)

    # Parse the file and compare the result with the expected result
    with open("tests/data/test_numpydocparser_parse.txt", "r") as fd:
        docstring = fd.read()

    expected.sort()

    result = parse(docstring)
    result_docstring = str(result)

    lines = result_docstring.split("\n")
    lines.sort()

    for line in lines:
        assert line in expected

# Generated at 2022-06-25 16:28:42.931105
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    if numpydoc_parser_1 is None:
        raise Exception("NumpydocParser object is null/None")

# Generated at 2022-06-25 16:28:54.090981
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import pytest
    numpydoc_parser_0 = NumpydocParser()

    text_0 = ""
    assert(numpydoc_parser_0.parse(text_0) == Docstring())

    text_1 = "This is a test of a Numpy-format docstring.\n"
    parsed_1 = numpydoc_parser_0.parse(text_1)
    assert(parsed_1.short_description == "This is a test of a Numpy-format docstring.")
    assert(parsed_1.blank_after_short_description == False)
    assert(parsed_1.blank_after_long_description == True)
    assert(parsed_1.long_description == None)
    assert(parsed_1.meta == [])


# Generated at 2022-06-25 16:28:59.861949
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_test_case_0 = NumpydocParser()
    docstring = numpydoc_parser_test_case_0.parse("")
    assert not docstring.short_description
    assert not docstring.long_description
    assert docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert not docstring.meta



# Generated at 2022-06-25 16:29:06.622987
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser().parse('This module provides the') == Docstring()

# Generated at 2022-06-25 16:29:09.012319
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.parse("'''Hello, world!'''")

# Generated at 2022-06-25 16:29:13.999170
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Initialize NumpydocParser object
    numpydoc_parser = NumpydocParser()
    # Test if parse method can be called
    ret = numpydoc_parser.parse("")
    assert True

test_case_0()
test_NumpydocParser_parse()
print("Test cases passed")

# Generated at 2022-06-25 16:29:23.705026
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case data
    text_0 = """
    Minimize a scalar function of one or more variables using the
    downhill simplex algorithm.

    This algorithm only uses function values, not derivatives or second
    derivatives.
    """

    # Perform the test
    docstring_0 = NumpydocParser().parse(text_0)

    # Check the result
    assert docstring_0.long_description == """
    Minimize a scalar function of one or more variables using the
    downhill simplex algorithm.

    This algorithm only uses function values, not derivatives or second
    derivatives."""
    assert docstring_0.short_description == "Minimize a scalar function of one or more variables using the"
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.blank_after_short_description is True

# Generated at 2022-06-25 16:29:28.179893
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    class TestNumpydocParser:
        def test_NumpydocParser(self):
            NumpydocParser_instance = NumpydocParser()

    testNumpydocParser_instance = TestNumpydocParser()
    testNumpydocParser_instance.test_NumpydocParser()

# Generated at 2022-06-25 16:29:39.827366
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Initialise the NumpydocParser
    numpydoc_parser_0 = NumpydocParser()
    text_0 = ''
    str_0 = ''
    list_0 = []
    list_1 = []
    list_2 = []
    list_3 = []
    # Invoke method parse of numpydoc_parser_0
    ret = numpydoc_parser_0.parse(text_0)
    # Check the docstring of ret
    assert ret.__doc__ == str_0
    # Check the type of ret is Docstring
    assert isinstance(ret, Docstring)
    # Check the type of the attribute meta of ret is list
    assert isinstance(ret.meta, list)
    # Check whether attribute meta of ret is equal to list_0
    assert ret.meta == list_0


# Generated at 2022-06-25 16:29:51.340224
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """numpydoc-style docstring parsing.

    This parser is an almost direct port of the numpydoc_ parser implementation.
    It is much more tolerant of docstring formatting than the default sphinx-
    style parser.

    .. _numpydoc: https://numpydoc.readthedocs.io/en/latest/format.html#docstring-standard
    """
    ds = numpydoc_parser_0.parse(text)
    assert ds.short_description == "numpydoc-style docstring parsing."
    assert ds.blank_after_short_description == 0
    assert ds.blank_after_long_description == 1

# Generated at 2022-06-25 16:29:58.949213
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring = parse(
        """
A short summary of this function.

Can span multiple lines.

Attributes
----------
attr_name
    attribute description

"""
    )
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ["attribute", "attr_name"]
    assert docstring.meta[0].description == "attribute description"
    assert len(docstring.meta[0].meta) == 0


# Generated at 2022-06-25 16:30:12.567170
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case with no docstring
    numpydoc_parser_0 = NumpydocParser()
    expected_docstring_0 = Docstring()
    assert numpydoc_parser_0.parse("") == expected_docstring_0, "Test Case 0 Failed."
    # Test case with a short description and no meta
    numpydoc_parser_1 = NumpydocParser()
    expected_docstring_1 = Docstring()
    expected_docstring_1.short_description = "Something."
    assert numpydoc_parser_1.parse("Something.") == expected_docstring_1, "Test Case 1 Failed."
    # Test case with multi-line short description and no meta
    numpydoc_parser_2 = NumpydocParser()
    expected_docstring_2 = Docstring()
    expected

# Generated at 2022-06-25 16:30:16.486639
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    """
    # parse the text
    result = NumpydocParser().parse(text)
    # expected result
    expected = Docstring()
    # compare expected result to generated result
    assert result == expected


# Generated at 2022-06-25 16:30:31.208638
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    expected_result_1 = Docstring()
    actual_result_1 = numpydoc_parser_1.parse("")
    assert actual_result_1 == expected_result_1
    assert not actual_result_1
    numpydoc_parser_2 = NumpydocParser()
    expected_result_2 = Docstring()
    actual_result_2 = numpydoc_parser_2.parse(" ")
    assert actual_result_2 == expected_result_2
    assert actual_result_2
    numpydoc_parser_3 = NumpydocParser()
    expected_result_3 = Docstring(
        short_description = "do something", long_description = "really do it\n"
    )
    actual_result_

# Generated at 2022-06-25 16:30:41.883609
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:30:49.715887
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
            This is the first line.
            This is the second line.
            Parameters
            ----------
            arg1 : int
                describe arg1
            arg2 : str
                describe arg2
            Returns
            -------
            int
                describe return value
            Other Parameters
            ----------------
            other_arg1 : list
                describe other_arg1
            other_arg2 : dict
                describe other_arg2
            Raises
            ------
            ValueError
                describe what raises ValueError
            """
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.add_section(ParamSection("Args", "args"))
    result = numpydoc_parser_0.parse(text)

# Generated at 2022-06-25 16:30:51.474654
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()


# Generated at 2022-06-25 16:30:54.602426
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()

    assert numpydoc_parser_1.parse(text=None) == Docstring()



# Generated at 2022-06-25 16:31:02.122947
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = ""
    ret_val_0 = numpydoc_parser_0.parse(text_0)
    assert ret_val_0 == Docstring()

if __name__ == "__main__":
    test_case_0()
    test_NumpydocParser_parse()

# Generated at 2022-06-25 16:31:09.618463
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    numpydoc_parser.parse('numpy_docstring_parser\n====================')
    numpydoc_parser.parse('numpy_docstring_parser\n====================\n\n')
    numpydoc_parser.parse('numpy_docstring_parser\n====================\n\n\n')
    numpydoc_parser.parse('numpy_docstring_parser\n====================\n\n\n\n')
    numpydoc_parser.parse('numpy_docstring_parser\n====================\n\n\n\n\n\n')
    numpydoc_parser.parse('numpy_docstring_parser\n====================\n\n\n\n\n\n\n')
    n

# Generated at 2022-06-25 16:31:22.446915
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print("test_NumpydocParser_parse...")

    numpydoc_parser_0 = NumpydocParser(sections=None)
    text_0 = ""
    docstring_0 = Docstring()
    docstring_0.short_description = None
    docstring_0.long_description = None
    docstring_0.blank_after_short_description = False
    docstring_0.blank_after_long_description = False
    docstring_0.meta = []

    assert numpydoc_parser_0.parse(text_0) == docstring_0

    numpydoc_parser_1 = NumpydocParser(sections=None)
    text_1 = "Valid docstring 1."
    docstring_1 = Docstring()

# Generated at 2022-06-25 16:31:25.116664
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse("")
    assert isinstance(docstring_0, Docstring)


# Generated at 2022-06-25 16:31:33.277381
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:31:45.039570
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = '''
    The long description of a function.

    This text can span
    multiple lines.
    '''

    # Call method parse of class NumpydocParser
    docstring = numpydoc_parser_0.parse(text)
    assert docstring.long_description == 'This text can span multiple lines.'
    assert docstring.blank_after_long_description == False
    assert docstring.blank_after_short_description == True
    assert docstring.short_description == 'The long description of a function.'
    assert len(docstring.meta) == 0


# Generated at 2022-06-25 16:31:56.680952
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

    # Test case 0:
    test_docstring_0 = 'This is a test docstring.\n'
    docstring_0 = numpydoc_parser_0.parse(test_docstring_0)
    assert docstring_0.short_description == 'This is a test docstring.'
    assert docstring_0.long_description is None
    assert not docstring_0.blank_after_short_description
    assert not docstring_0.blank_after_long_description
    assert not docstring_0.meta

    # Test case 1:
    test_docstring_1 = 'This is a test docstring.\n\nAnd some additional information.'

# Generated at 2022-06-25 16:32:07.562832
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Unit test code
    assert NumpydocParser().parse('') == Docstring()
    assert NumpydocParser().parse('   \n\t\n') == Docstring()
    assert NumpydocParser().parse('  a\n\t\n') == Docstring(
        short_description='a',
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert NumpydocParser().parse('  a\n\t\n  b') == Docstring(
        short_description='a',
        blank_after_short_description=True,
        long_description='b',
        blank_after_long_description=False,
    )
    assert NumpydocParser().parse('  a\n\t\n  b\n\n')

# Generated at 2022-06-25 16:32:15.575686
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # method call - test 0
    numpydoc_parser_0 = NumpydocParser()
    assert(numpydoc_parser_0.parse('\
A function that describes this function.') ==
           Docstring('Docstring', 'A function that describes this function.', None))

    # method call - test 1
    numpydoc_parser_1 = NumpydocParser()

# Generated at 2022-06-25 16:32:21.151019
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = ""
    res = numpydoc_parser_0.parse(text)
    assert isinstance(res, Docstring)
    # tests for method parse of class NumpydocParser end here


# Generated at 2022-06-25 16:32:30.968877
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
            First line.
            Second line.
            Params:
                name:
                    Description.
                address:
                    Description.
                id:
                    Description.
    """

    doc = numpydoc_parser_0.parse(text)
    assert doc.short_description == "First line."
    assert doc.long_description == "Second line."
    assert doc.blank_after_long_description == False

    assert doc.meta[0].args[0] == "param"
    assert doc.meta[0].args[1] == "name"
    assert doc.meta[0].description == "Description."
    assert doc.meta[1].args[0] == "param"
    assert doc.meta[1].args[1] == "address"
    assert doc.meta[1].description == "Description."

# Generated at 2022-06-25 16:32:37.666043
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 = "None\n"
    # Execution of method parse on class NumpydocParser
    docstring_0 = numpydoc_parser_0.parse(str_0)
    # Value comparison between docstring_0.short_description and str_0
    assert (docstring_0.short_description == str_0)

# Generated at 2022-06-25 16:32:40.635500
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = parse("test")
    assert text is not None

# Generated at 2022-06-25 16:32:46.217300
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = Docstring()
    # insert code here to test method parse of class NumpydocParser
    assert docstring_0 == numpydoc_parser_0.parse("")

# Generated at 2022-06-25 16:32:57.463585
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    assert numpydoc_parser_0.parse('') == Docstring()
    assert numpydoc_parser_0.parse('\t\t') == Docstring()
    assert numpydoc_parser_0.parse('string') == Docstring(short_description='string', long_description=None, blank_after_short_description=None, blank_after_long_description=None, meta=[])
    assert numpydoc_parser_0.parse(' string') == Docstring(short_description='string', long_description=None, blank_after_short_description=None, blank_after_long_description=None, meta=[])