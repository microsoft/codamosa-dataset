

# Generated at 2022-06-25 16:24:23.710960
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    #  Empty docstring
    docstring_0 = '""'
    docstring_1 = numpydoc_parser_0.parse(docstring_0)
    docstring_2 = Docstring()
    assert docstring_1 == docstring_2
    #  Simple docstring single line
    docstring_0 = '"A test docstring"'
    docstring_1 = numpydoc_parser_0.parse(docstring_0)
    docstring_2 = Docstring('A test docstring')
    assert docstring_1 == docstring_2
    #  Simple docstring mutliline with leading and trailing newlines
    docstring_0 = '"A test docstring\nwith multiple lines"'
    docstring_1 = numpydoc_

# Generated at 2022-06-25 16:24:36.781826
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:24:44.814748
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    test_str = textwrap.dedent("""
    Some function.

        Args:
            x (int): An integer.
            y (float): A float.
        Returns:
            float: The sum of the inputs.
    """)
    doc = numpydoc_parser_0.parse(test_str)
    assert doc.short_description == 'Some function.'
    assert doc.long_description == '\n        Args:\n            x (int): An integer.\n            y (float): A float.\n        Returns:\n            float: The sum of the inputs.\n'

# Generated at 2022-06-25 16:24:54.870504
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    numpydoc_parser.add_section(ParamSection("Parameters", "param"))
    numpydoc_parser.add_section(ReturnsSection("Returns", "returns"))
    doc_string = """
    This function parses the doc string and returns it in a more useful format.

    Parameters
    ----------
    func: function
        The function whose docstring is required to be parsed.
    tag: string
        Tag of the doc string to be parsed.

    Returns
    -------
    docstring: Docstring
        Parsed docstring.
    """

# Generated at 2022-06-25 16:25:01.043435
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    case_0_in = ""
    case_0_expected = Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    case_0_actual = numpydoc_parser_0.parse(case_0_in)
    assert case_0_actual == case_0_expected

# Generated at 2022-06-25 16:25:09.634109
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_1 = "This is a docstring."
    docstring_2 = numpydoc_parser_0.parse(text_1)
    assert docstring_2.short_description == "This is a docstring."
    assert docstring_2.long_description == None
    assert docstring_2.blank_after_short_description == False
    assert docstring_2.blank_after_long_description == False
    assert docstring_2.meta == [DocstringMeta(args=[], description=None)]


# Generated at 2022-06-25 16:25:18.816253
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from dd_doc import parse
    docstring = parse("""
    PlayerSession
        Base class for game sessions.
    """)
    ret = docstring
    assert ret.short_description == 'PlayerSession'
    assert ret.long_description == 'Base class for game sessions.'
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == True
    meta = ret.meta
    assert meta[0].args == ['param', 'player']
    assert meta[0].description == 'Player instance if not set player_id.'
    assert meta[0].arg_name == 'player'
    assert meta[0].type_name == 'Player'
    assert meta[0].is_optional == True
    assert meta[0].default == None

# Generated at 2022-06-25 16:25:30.292036
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    test_string_0 = 'a dictionary containing the positional arguments'
    # call method parse on object 'numpydoc_parser_0'
    result_m_0 = numpydoc_parser_0.parse(test_string_0)
    expect_m_0 = 'a dictionary containing the positional arguments'
    assert expect_m_0 == result_m_0

    test_string_1 = '''Compute a hash value for an object.'''
    # call method parse on object 'numpydoc_parser_0'
    result_m_1 = numpydoc_parser_0.parse(test_string_1)
    expect_m_1 = '''Compute a hash value for an object.'''
    assert expect_m_1 == result_

# Generated at 2022-06-25 16:25:31.875548
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    if __name__ == "__main__":
        doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-25 16:25:39.657920
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    docstr = """This is a short description.
    This is a longer description

    Parameters
        param1 (type): This is a param

    Returns
        type: The return value

    Raises
        ValueError: When something bad happens

    Warns
        RuntimeWarning: If something bad happens

    """
    result = numpydoc_parser_1.parse(docstr)
    assert result.short_description == "This is a short description."
    assert result.blank_after_short_description == True
    assert result.long_description == "This is a longer description"
    assert result.blank_after_long_description == True

# Generated at 2022-06-25 16:26:15.261560
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    global numpydoc_parser_0
    returnval = numpydoc_parser_0.parse(text=None)

    returnval_desc = ""
    returnval_desc += "Description: " + str(type(returnval.description)) + "\n"
    returnval_desc += "Value: " + str(returnval.description) + "\n"
    returnval_desc += "\n"
    returnval_desc += "Short Description: " + str(type(returnval.short_description)) + "\n"
    returnval_desc += "Value: " + str(returnval.short_description) + "\n"
    returnval_desc += "\n"
    returnval_desc += "Long Description: " + str(type(returnval.long_description)) + "\n"

# Generated at 2022-06-25 16:26:23.100430
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:26:31.727292
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    import re
    import xml.etree.ElementTree as ET

    root = ET.parse('./test/unittest_cases/unit_test_cases_NumpydocParser_parse.xml').getroot()
    
    # Test case configuration
    numpydoc_parser = NumpydocParser()

    # Test case inputs
    text = root.find('inputs/text').text

    # Test case execution
    actual_output = numpydoc_parser.parse(text)

    # Test case verification
    expected_output = re.split(r'\n\n|\r\n\r\n', root.find('outputs/DocString').text)[0].strip()
    line_pattern = re.compile(r'^(.+?)\n')
    def _is_empty(x): return x

# Generated at 2022-06-25 16:26:43.758471
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    text_1 = '''
        A short description of what this function does

        One or two paragraphs of description about how to use the function,
        including its parameters.

        Parameters
        ----------
        x : int
            The x variable.
        y : str
            The y variable.

        Returns
        -------
        int
            The sum of x and y.
        '''
    text_2 = None

# Generated at 2022-06-25 16:26:55.146148
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    expected = Docstring(
        short_description='Gets the long description for this project.',
        long_description="""\
This will normally be the contents of a text file, which contains a longer
description of the project than the short description returned by
get_short_description().

If the long description doesn't exist, this will return the short description.
""",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[
            DocstringMeta(['param', 'project'], description='the project to get the long description for'),
            DocstringMeta(['returns'], description='the long project description', type_name=None, is_generator=False, return_name=None),
        ]
    )

# Generated at 2022-06-25 16:27:01.419240
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Test for class initialization
    numpydoc_parser_0 = NumpydocParser()

    # Test for exception
    try:
        numpydoc_parser_0.parse(
            """foo"""
        )

    except:
        numpydoc_parser_0.parse(
            """foo"""
        )


# Generated at 2022-06-25 16:27:10.244634
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parse_0 = NumpydocParser().parse('')
    assert type(parse_0) == Docstring
    parse_1 = NumpydocParser().parse('Example to parse.\n\n')
    assert type(parse_1) == Docstring
    parse_2 = NumpydocParser().parse('Example to parse.\n')
    assert type(parse_2) == Docstring
    parse_3 = NumpydocParser().parse('Example to parse.\n\n\n')
    assert type(parse_3) == Docstring
    parse_4 = NumpydocParser().parse('Example to parse.\n    See\n    Also\n')
    assert type(parse_4) == Docstring


# Generated at 2022-06-25 16:27:15.648426
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """this is a function

    with multiple lines of description

    Parameters
    ==========
    x : int
        x
    y : str
        y

    Raises
    ======
    ValueError
        Value error"""
    docstring_0 = parse(text_0)
    print(docstring_0)

# Generated at 2022-06-25 16:27:20.801991
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = '\nParameters\n\t----------\n\targ1 : int\n\t    The first argument.\n\n\targ2 : str\n\t    The second argument.\n\n\tReturns\n\t-------\n\tbool\n\t    True if successful, False otherwise.\n\t'
    numpydoc_parser_0.parse(text_0)


# Generated at 2022-06-25 16:27:21.725645
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    pass # TODO: should we add this method?

# Generated at 2022-06-25 16:27:42.719085
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "  This is a docstring.   "
    Docstring_0 = numpydoc_parser_0.parse(text_0)
    assert(Docstring_0.short_description == 'This is a docstring.')
    assert(Docstring_0.long_description == None)
    assert(Docstring_0.blank_after_short_description == True)
    assert(Docstring_0.blank_after_long_description == False)
    assert(Docstring_0.meta == [])


# Generated at 2022-06-25 16:27:47.060177
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()


# Generated at 2022-06-25 16:27:55.846584
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:28:08.184826
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = 'This module implements the asyncio compatibility layer with async/await syntax.\n\nThis makes it possible to run MicroPython code written using asyncio on top of any other\nasync concurrency library.\n\n\n\nArgs\n----\nloop : asyncio.AbstractEventLoop\n    The event loop to use for async/await.\n\n\n\nReturns\n-------\nNone\n    Nothing.\n\n\n\nExample\n-------\n>>> import asyncio\n>>> import uasyncio\n>>> import your.library\n>>> asyncio.set_event_loop(uasyncio.get_event_loop())'
    result = parse(text)
    assert result.short_description == 'This module implements the asyncio compatibility layer with async/await syntax.'

# Generated at 2022-06-25 16:28:17.537144
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    result = numpydoc_parser_1.parse("Return the dict representation of the\nobject.\n")
    assert(result.short_description == "Return the dict representation of the")
    assert(result.long_description == "object.")
    assert(result.blank_after_short_description)
    assert(result.blank_after_long_description)
    assert(len(result.meta) == 0)



# Generated at 2022-06-25 16:28:24.615704
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = 'Compute the Gini coefficient of a population.'
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description == 'Compute the Gini coefficient of a population.'
    assert docstring_0.long_description == None
    assert len(docstring_0.meta) == 0

# Generated at 2022-06-25 16:28:39.308093
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Case 0
    numpydoc_parser_0 = NumpydocParser()
    function_0 = numpydoc_parser_0.parse
    text_0 = "Lorem ipsum\n"
    expected_0 = Docstring(
        short_description="Lorem ipsum",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    actual_0 = function_0(text_0)
    assert actual_0 == expected_0
    # Case 1
    numpydoc_parser_1 = NumpydocParser()
    function_1 = numpydoc_parser_1.parse
    text_1 = "Foo\nBar\n\nBaz\n"
    expected

# Generated at 2022-06-25 16:28:49.417704
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    import pkg_resources

    text = pkg_resources.resource_string(
        __name__, "tests/fixtures/numpydoc/numpydoc_0.txt"
    )
    doc = parse(text.decode())

# Generated at 2022-06-25 16:28:54.140278
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    s = '''
    Return a docstring
    with parsed information.
    '''
    assert numpydoc_parser_0.parse(s)


# Generated at 2022-06-25 16:29:01.667914
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = Docstring()
    str_arg_0 = ""
    docstring_0 = numpydoc_parser_0.parse(str_arg_0)
    str_0 = ""
    docstring_0.short_description = str_0
    assert docstring_0.short_description == str_0
    assert docstring_0.meta == list()
    boolean_0 = False
    docstring_0.blank_after_short_description = boolean_0
    assert docstring_0.blank_after_short_description == boolean_0
    boolean_1 = False
    docstring_0.blank_after_long_description = boolean_1
    assert docstring_0.blank_after_long_description == boolean_1
    str_

# Generated at 2022-06-25 16:29:19.779845
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 1:
    # Assume that text is defined
    try:
        text
    except NameError:
        text = None
    # Assume that text is defined
    try:
        text
    except NameError:
        text = None
    # Assume that text is str
    try:
        type(text) is str
    except NameError:
        text = None
    # Assume that text is defined
    try:
        text
    except NameError:
        text = None
    expected = Docstring()
    actual = NumpydocParser.parse(text)
    assert actual == expected
    # Test case 2:
    # Assume that text is defined
    try:
        text
    except NameError:
        text = None
    # Assume that text is defined

# Generated at 2022-06-25 16:29:30.461624
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_1 = NumpydocParser()
    test_cases_parse = [
        ("""For each state, we get an array of size N, with the value of the probability distribution at that state for each action.""", Docstring()),
        ("""For each state, we get an array of size N, with the value of the probability distribution at that state for each action.""", numpydoc_parser_0.parse("""For each state, we get an array of size N, with the value of the probability distribution at that state for each action."""))
    ]


# Generated at 2022-06-25 16:29:41.675224
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    parser = NumpydocParser()

    def test_parse(text, expected):
        """Test NumpydocParser.parse()."""
        actual = parser.parse(text)
        assert actual == expected

    text = """ Return the number of nonzero entries in the matrix.

    This method is equivalent to ``(A != 0).sum()``.

    Returns
    -------
    nnz : int
        The number of non-zero values.

    See Also
    --------
    count_nonzero, nnz, size
    """

# Generated at 2022-06-25 16:29:52.498366
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    docstring_0 = numpydoc_parser.parse("")
    docstring_1 = numpydoc_parser.parse("First line of docstring.")
    docstring_2 = numpydoc_parser.parse("First line of docstring.\n")
    docstring_3 = numpydoc_parser.parse("First line of docstring.\n\n")
    docstring_4 = numpydoc_parser.parse("First line of docstring.\nSecond line of docstring.\n")
    docstring_5 = numpydoc_parser.parse("First line of docstring.\n\nSecond line of docstring.\n")

# Generated at 2022-06-25 16:30:01.514794
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Usage: NumpydocParser.parse(text: str) -> Docstring
    """
    text = """Test title
    ==========


    This is a test for method parse of class NumpydocParser.

    Parameters
    ----------
    text : str
        This is a docstring with some description.

    Returns
    -------
    Docstring
        This is the return value.

    """

# Generated at 2022-06-25 16:30:15.125636
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # create NumpydocParser object
    numpydoc_parser = NumpydocParser()
    # get docstring for method
    text = numpydoc_parser.parse.__doc__
    # parse docstring
    docstring = numpydoc_parser.parse(text)
    # test short description
    assert docstring.short_description == 'Parse the numpy-style docstring into its components.'
    # test long description
    assert docstring.long_description == ':returns: parsed docstring'
    # test blank line after short
    assert docstring.blank_after_short_description == True
    # test blank line after long
    assert docstring.blank_after_long_description == False
    # test meta parameters
    assert len(docstring.meta) == 0


# Generated at 2022-06-25 16:30:18.961081
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse("TestDocstring")
    assert docstring_0.short_description == "TestDocstring"


# Generated at 2022-06-25 16:30:30.993465
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 0:
    text = """
    Definitions
    -----------
    This is the short description.

    This is the long description. It can contain multiple lines.

    Parameters
    ----------
    arg : int
        Description of the first parameter.
    arg2 : float
        Description of the second parameter.

    Returns
    -------
    int
        Description of the output.

    Warnings
    --------
    This is a warning text.
    """

    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse(text)


# Generated at 2022-06-25 16:30:41.568059
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = '''
    Does some magic.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Examples
    --------
    >>> print("Hello, World!")
    Hello, World!
    '''

# Generated at 2022-06-25 16:30:49.523029
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    assert numpydoc_parser_0.parse("Test a function.") == Docstring(
        short_description="Test a function.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert numpydoc_parser_0.parse("Test a function.\nTest.") == Docstring(
        short_description="Test a function.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Test.",
        meta=[],
    )

# Generated at 2022-06-25 16:31:11.119062
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert True
    # assert False # Remove this line when implemented.


# Generated at 2022-06-25 16:31:23.374404
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:31:32.254462
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    #
    # Docstring description

    text = """\
    Some description text.

    This can span multiple lines.
    """
    parse_result_0 = NumpydocParser().parse(text)
    assert (
        parse_result_0.short_description == "Some description text."
    )
    assert (
        parse_result_0.long_description
        == """\
This can span multiple lines.
"""
    )
    assert parse_result_0.long_description
    assert not parse_result_0.meta

    text = """\
    Some description text.

    This can span multiple lines.
    """
    parse_result_1 = NumpydocParser().parse(text)
    assert (
        parse_result_1.short_description == "Some description text."
    )

# Generated at 2022-06-25 16:31:39.474569
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 = """foo"""
    ret_0 = numpydoc_parser_0.parse(str_0)
    ret_1 = Docstring()
    assert (ret_0 == ret_1)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:31:48.560268
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Create an object of class NumpydocParser
    numpydoc_parser = NumpydocParser()
    doc_str = """
    test description
    Parameters
    ----------
    arg_1
        description of arg_1
    arg_2 : type, optional
        description of arg_2
    other_params
    Raises
    ------
    ValueError
        description of what might cause ValueError
    Returns
    -------
    returns : type
        description of returns
    See Also
    --------
    func1
    func2
    Examples
    --------
    example
    """
    # Test the method parse of class NumpydocParser
    doc_0 = numpydoc_parser.parse(doc_str)
    # Test the method parse of class NumpydocParser

# Generated at 2022-06-25 16:31:54.337888
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "This is my docstring"
    ret_0 = numpydoc_parser_0.parse(text_0)
    assert ret_0.short_description == "This is my docstring"
    assert not ret_0.blank_after_short_description
    assert ret_0.long_description is None
    assert not ret_0.blank_after_long_description
    assert ret_0.meta == []

# Generated at 2022-06-25 16:32:05.091425
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """\
    Change the time zone definition of the local time to time zone.
    Return a datetime with new tzinfo attribute tz, adjusting
    the date and time data so the result is the same UTC time
    as self, and the same wall clock time as in time zone.

    self must be naive UTC, and tz must be an instance of a
    tzinfo subclass.
    """
    result_0 = numpydoc_parser_0.parse(text_0)
    assert result_0.short_description == "Change the time zone definition of the local time to time zone."

# Generated at 2022-06-25 16:32:13.998438
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    p = NumpydocParser()

# Generated at 2022-06-25 16:32:25.893331
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    expected = {
        'short_description': 'Foo class',
        'long_description': 'really long description with an indented block::\n\n    def foo(self):\n        pass',
        'meta': [
            {'args': ['param', 'name'], 'description': 'name of foo'},
            {'args': ['param', 'size'], 'description': 'size of foo', 'default': '1'},
            {'args': ['returns'], 'description': 'something', 'type_name': 'str'},
            {'args': ['warning'], 'description': 'Warning about foo'},
            {'args': ['example'], 'description': 'an example'},
        ]
    }

# Generated at 2022-06-25 16:32:28.360792
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    parser.parse('''
    test_NumpydocParser_parse
        This docstring gets parsed into a Docstring object
    See Also
        Another_test
    ''')


# Generated at 2022-06-25 16:32:45.631842
# Unit test for function parse
def test_parse():
    docstring = """
Sum of a and b.

This is a long description. This is a long description. This is a long
description. This is a long description. This is a long description.

Another paragraph of the long description. Another paragraph of the long
description. Another paragraph of the long description. Another paragraph
of the long description. Another paragraph of the long description.

:param a: The first number to add.
:param b: The second number to add.
:returns: The sum of a and b.
:raises TypeError: if a or b are not numbers
:rtype: int
"""

    ret = parse(docstring)

    assert ret.short_description == "Sum of a and b."

# Generated at 2022-06-25 16:32:46.933997
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
   numpydoc_parser_0 = NumpydocParser()
   raises_section_0 = RaisesSection(None, None)


# Generated at 2022-06-25 16:32:57.874578
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    text_1 = '''A sentence with a

Parameters
----------
param1 : str
    The first parameter
param2 : int
    The second parameter
Yields
------
int
    The return value

Raises
------
ValueError
    If anything goes wrong
'''
    value_1 = numpydoc_parser_1.parse(text_1)
    assert isinstance(value_1, Docstring)
    assert isinstance(value_1.short_description, str)
    assert isinstance(value_1.long_description, str)
    assert isinstance(value_1.blank_after_long_description, bool)
    assert isinstance(value_1.blank_after_short_description, bool)

# Generated at 2022-06-25 16:33:09.276940
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_1 = NumpydocParser()
    withDeprecationSection = numpydoc_parser_1.parse(text='.. deprecated:: 1.0\n   Being phased out, see :ref:`this link <config_dirs_ref>`\n\n\n')
    assert withDeprecationSection.meta[0].args == ['deprecation']
    assert withDeprecationSection.meta[0].description == 'Being phased out, see :ref:`this link <config_dirs_ref>`'
    assert withDeprecationSection.meta[0].version == '1.0'

