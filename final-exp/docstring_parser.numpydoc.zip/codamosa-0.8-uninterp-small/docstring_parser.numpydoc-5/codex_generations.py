

# Generated at 2022-06-25 16:23:57.711298
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydocParser = NumpydocParser()
    doc = numpydocParser.parse(
        """
        A multi-line docstring.
        
        Parameters
        ----------
        
        Returns
        -------
        """
    )

    assert doc.short_description.strip() == "A multi-line docstring."
    assert doc.blank_after_short_description
    assert len(doc.meta) == 1

    # the meta list is sorted by the first item in the args list
    assert doc.meta[0].args == ["param"]
    assert not doc.meta[0].description



# Generated at 2022-06-25 16:24:05.620859
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    r1 = 'Returns'
    p1 = ParamSection(r1, 'returns')
    s1 = NumpydocParser()
    text1 = '>s1'
    s1.parse(text1)
    r2 = 'Returns'
    p2 = ParamSection(r2, 'returns')
    s2 = NumpydocParser()
    text2 = '>s2'
    s2.parse(text2)
    r3 = 'Returns'
    p3 = ParamSection(r3, 'returns')
    s3 = NumpydocParser()
    text3 = '>s3'
    s3.parse(text3)
    r4 = 'Parameters'
    p4 = ParamSection(r4, 'param')
    s4 = NumpydocParser()

# Generated at 2022-06-25 16:24:15.033978
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 0.1
    str_0 = "This is a short desc\nThis is a long desc"
    expected_str_0_1 = "This is a short desc"
    expected_str_0_2 = "This is a long desc"

    result_0_1, result_0_2 = NumpydocParser().parse(str_0).short_description, NumpydocParser().parse(str_0).long_description
    assert result_0_1 == expected_str_0_1, "method \"parse\" of class \"NumpydocParser\" failed on case 0.1"
    assert result_0_2 == expected_str_0_2, "method \"parse\" of class \"NumpydocParser\" failed on case 0.2"

    # Test case 1.1

# Generated at 2022-06-25 16:24:17.944927
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = "test_NumpydocParser_parse"
    section_0 = _KVSection(str_0, str_0)


# Generated at 2022-06-25 16:24:25.519863
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Base case: normal function definition with a docstring
    NumpydocParser_parse_0 = '''This is a basic docstring'''
    ret_0 = NumpydocParser().parse(NumpydocParser_parse_0)
    assert ret_0.short_description == 'This is a basic docstring'
    assert ret_0.long_description is None
    assert ret_0.blank_after_short_description is True
    assert ret_0.blank_after_long_description is False
    assert ret_0.meta == []

    # Base case: function with a docstring and metadata
    NumpydocParser_parse_1 = '''This is a basic docstring

Parameters
----------
p1 : a param
    some description

Returns
-------
returns_value
    other description'''
    ret_

# Generated at 2022-06-25 16:24:38.793947
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'C1'
    str_1 = 'C2'
    str_2 = 'C3'
    str_3 = 'C4'
    str_4 = 'C5'
    str_5 = 'C6'
    str_6 = 'C7'
    str_7 = 'C8'
    str_8 = 'C9'
    str_9 = 'C10'
    str_10 = 'C11'
    str_11 = 'C12'
    str_12 = 'C13'
    str_13 = 'C14'
    str_14 = 'C15'
    str_15 = 'C16'
    str_16 = 'C17'
    str_17 = 'C18'
    str_18 = 'C19'
    str_19 = 'C20'

# Generated at 2022-06-25 16:24:51.205410
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test the functionality of NumpydocParser.parse().
    """
    print("\ntest_NumpydocParser_parse")

    test_text_0 = '\n'.join([
        'Example of a test docstring',
        'Parameters',
        '----------',
        'arg_0 : int',
        '    arg_0 is an int',
        'arg_1 : str, optional',
        '    arg_1 is a str, optional',
        '    Default is "hello"',
        'arg_2 : float',
        '    arg_2 is a float',
        'Returns',
        '-------',
        'float',
        '    The result of the operation',
        'Raises',
        '------',
        'TypeError',
        'KeyError'
    ])
    expected_description

# Generated at 2022-06-25 16:25:02.341766
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Setup environment for test
    # Make sure that the default sections are built
    NumpydocParser()

    str_1 = "Examples\n--------\n\nExample 1::\n\n    >>> print(2)\n    2\nExample 2::\n\n    >>> print(2)\n    2\n"
    str_2 = "Warnings\n--------\n\nBeware of dog!\n\n"
    str_3 = "See Also\n--------\n\n* :py:class:`OtherClass`"
    str_4 = "Notes\n-----\n\nSome notes go here."
    str_5 = "References\n----------\n\n* Some links here\n* citations here"

# Generated at 2022-06-25 16:25:13.828281
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Tests for the first if statement
    text = 'value'
    numpydocParser = NumpydocParser()
    res = numpydocParser.parse(text)
    assert res.short_description == 'value'
    assert res.long_description == None
    assert res.blank_after_short_description == False
    assert res.blank_after_long_description == False
    assert res.meta == []

    # Tests for the second if statement
    text = 'title: description'
    numpydocParser = NumpydocParser()
    res = numpydocParser.parse(text)
    assert res.short_description == 'title'
    assert res.long_description == 'description'
    assert res.blank_after_short_description == False
    assert res.blank_after_long_description == True

# Generated at 2022-06-25 16:25:21.305247
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Tests for parse in NumpydocParser
    ds = '>This is my awesome function.\nAnd here is some more text.\n\nParameters\n----------\narg1 : type\n\n    and some more text.\n    '
    return NumpydocParser().parse(ds)


# Generated at 2022-06-25 16:25:36.949969
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    text_1 = """
    Args:
        a
            b
        c: type, optional
            d
    """
    result_1 = numpydoc_parser_1.parse(text_1)
    assert isinstance(result_1, Docstring)
    assert isinstance(result_1.short_description, type(None))
    assert isinstance(result_1.long_description, type(None))
    assert isinstance(result_1.blank_after_short_description, bool)
    assert isinstance(result_1.blank_after_long_description, bool)
    assert isinstance(result_1.meta, list)
    assert len(result_1.meta) == 1

# Generated at 2022-06-25 16:25:40.164633
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 0
    numpydoc_parser_0 = NumpydocParser()
    text_0 = ""
    docstring_0 = numpydoc_parser_0.parse(text_0)


numpydoc_parser = NumpydocParser()

# Generated at 2022-06-25 16:25:50.867384
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """Test a leading short desc

    Test a leading short description with a blank line following it.

    Test for a full description spanning multiple lines.

    Test for a full description with a blank line following it.
    """
    res_0 = numpydoc_parser_0.parse(text_0)
    assert res_0.short_description == "Test a leading short desc"
    assert res_0.long_description == "Test a full description spanning multiple lines."
    assert res_0.blank_after_short_description == True
    assert res_0.blank_after_long_description == False
    res_0 = numpydoc_parser_0.parse("")
    assert res_0.short_description == None
    assert res_0.long

# Generated at 2022-06-25 16:26:03.021387
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:26:14.742366
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    numpydoc_docstring = numpydoc_parser.parse("""\
Some description of this function.

:param x: A required parameter, with no default value.
:type x: int
:param y: An optional, keyword-only parameter.
:type y: float
:param z: An optional, keyword-only parameter with default.
:type z: str
:param w: A parameter with a default and type annotation.
:type w: bool
:returns: An :class:`int`.
:raises: :exc:`ValueError` If `x` is negative.
The short description continues here.

The long description continues here.

An indented code block:

    print("Hello world")

Another indented code block.
""")
    assert n

# Generated at 2022-06-25 16:26:22.712376
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstr = "This is the short description.\n\n    It can span multiple lines.\n    \n    Parameters\n    ----------\n    first\n        first param\n    second : int, optional\n        second param\n    \n    Raises\n    ------\n    ValueError\n        a value error\n    \n    Attributes\n    ----------\n    attr_name : str\n        an attribute\n"


# Generated at 2022-06-25 16:26:26.586982
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser(sections=None)

    docstring_0 = numpydoc_parser_0.parse(text="string")



# Generated at 2022-06-25 16:26:35.562400
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """This is the short description.

This is the long description. It can span
multiple lines and include
    ANSI Escapes
"""
    doc = parse(text)
    assert doc.short_description == "This is the short description."
    assert doc.long_description == "This is the long description.\nIt can span\nmultiple lines and include\n    ANSI Escapes"


# Generated at 2022-06-25 16:26:48.512501
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # parse
    result = numpydoc_parser_0.parse('')
    assert result.short_description == None
    assert result.long_description == None
    assert result.blank_after_short_description == None
    assert result.blank_after_long_description == None
    assert result.meta == []
    result = numpydoc_parser_0.parse('\n')
    assert result.short_description == None
    assert result.long_description == None
    assert result.blank_after_short_description == None
    assert result.blank_after_long_description == None
    assert result.meta == []
    result = numpydoc_parser_0.parse('Parameters')
    assert result.short_description == None

# Generated at 2022-06-25 16:26:49.105117
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    pass

# Generated at 2022-06-25 16:26:57.415500
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    test_case_0()


# Generated at 2022-06-25 16:27:08.507666
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """This is the first line of the docstring.
    This is the second line of the docstring.

    Parameters
    ----------
    x : int
        The x coordinate.
    y : str, optional
        The y coordinate.

    Raises
    ------
    ValueError
        If the input cannot be parsed.

    Warns
    -----
    UserWarning
        If the x or y parameter is None.

    Returns
    -------
    int
        The input x, y integer.
    """
    ret_0 = numpydoc_parser_0.parse(text_0)
    assert ret_0.short_description == "This is the first line of the docstring."
    assert ret_0.blank_after_short_description == False


# Generated at 2022-06-25 16:27:18.063080
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print("\n\n\n\ntest_NumpydocParser_parse\n\n")

# Generated at 2022-06-25 16:27:29.246629
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

    text = """
    Perform a 2-D convolution on an array.
    Apply a separable 2-D convolution on the 2-D `input` array using the given
    2-D `kernel`.
    Parameters
    ----------
    input : array_like
        Two-dimensional input array.
    kernel : array_like
        Two-dimensional kernel array.
    Returns
    -------
    output : array
        An array calculated by 2-D convolution.
    """
    docstring = numpydoc_parser_0.parse(text)
    # Assert that the short_description attribute of docstring equals the expected value
    assert docstring.short_description == "Perform a 2-D convolution on an array."
    # Assert that the blank_after_short

# Generated at 2022-06-25 16:27:41.409585
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring = inspect.cleandoc(
        '''
    """
    This is my docstring.

    They can span multiple lines too.

    Parameters:
        param1 : type

            description of param1

            which can also span multiple lines

        param2 : optional
            description of param2

        param3

            description of param3

    Examples:
        >>> 12 + 3
        15

    Warnings:
        do not hang yourself
    """
    '''
    )

# Generated at 2022-06-25 16:27:47.968315
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Create a NumpydocParser object
    numpydoc_parser_0 = NumpydocParser()

    # Create a Docstring object
    docstring_0 = Docstring()

    # Call the NumpydocParser method parse
    docstring_1 = numpydoc_parser_0.parse('test')

    # Assert that Docstring objects are equal
    assert docstring_0 == docstring_1

# Unit tests for function parse

# Generated at 2022-06-25 16:27:54.624929
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    args_0 = [
        '"""\n        No-op.\n        """\n        '
    ]
    r1 = Docstring(short_description='No-op.', long_description=None, blank_after_short_description=True, blank_after_long_description=False, meta=[], annotations=[])
    r0 = numpydoc_parser_0.parse(args_0[0])
    assert r0 == r1



# Generated at 2022-06-25 16:27:59.964553
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:28:11.587400
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:28:16.484899
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(r'''
    This is a short description.

    This is a longer/fuller description.
''')
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a longer/fuller description."


# Generated at 2022-06-25 16:28:27.221525
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse("")


# Generated at 2022-06-25 16:28:36.155264
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    text = """
    # doctest: +SKIP
    """
    docstring = numpydoc_parser.parse(text)
    assert docstring.short_description == docstring.long_description == None
    assert docstring.blank_after_short_description == True

    text = """
    Args:
        arg1 (int): the first value
        arg2 (str): the second value

    Returns:
        bool: True if successful, False otherwise

    """
    docstring = numpydoc_parser.parse(text)
    assert docstring.short_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.meta[1].description == "True if successful, False otherwise"


# Generated at 2022-06-25 16:28:43.983448
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    text = """Return a string containing the text of the docstring for the given
    object, or None if the object does not have a docstring."""

    numpydoc_parser_1 = NumpydocParser()

    assert numpydoc_parser_1.parse(text) == parse(text)

    c = NumpydocParser.parse
    assert c(text) == parse(text)



# Generated at 2022-06-25 16:28:55.096828
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    test_source_0 = """\
    method_name(var_1=1, var_2=2, var_3=3)

    method_description

    Parameters
    ----------
    param_1 : type, optional
        First parameter
    param_2 : type, optional
        Second parameter

    Returns
    -------
    type
        Returned value
    """
    test_0 = numpydoc_parser_0.parse(test_source_0)
    assert test_0.short_description == "method_name(var_1=1, var_2=2, var_3=3)"
    assert test_0.blank_after_short_description
    assert test_0.long_description == "method_description"
    assert not test_0

# Generated at 2022-06-25 16:29:03.435025
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:29:11.229644
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    from .common import Docstring
    from .numpydoc import NumpydocParser
    from .utils import full_type_name

    numpydoc_parser_0 = NumpydocParser()

    # Test cases
    # ----------
    ds = numpydoc_parser_0.parse(
    """
    Short description
    Long description.

    Parameters
    ----------
    arg1 : type
        Description of arg1
    arg2 : type, optional
        Description of arg2

    Raises
    ------
    RaisesError
        Description of RaisesError

    Returns
    -------
    return_arg : type
        Description of return_arg
    """
    )
    assert full_type_name(ds) == "docal.tests.common.Docstring"

# Generated at 2022-06-25 16:29:20.086515
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    with open('test/numpydoc_fixtures/numpydoc_parser_parse_docstring_0.txt', 'r') as file:
        text = file.read()
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse(text)
    with open('test/numpydoc_fixtures/numpydoc_parser_parse_docstring_0.json', 'r') as file:
        expected = Docstring.from_json(file.read())
    assert docstring_0 == expected


# Generated at 2022-06-25 16:29:30.647957
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Verify that the docstring parsing works when no docstring is given
    text = ""
    docstring_obj = parse(text)
    assert docstring_obj.short_description is None
    assert docstring_obj.long_description is None

    # Test correct parsing of a single-line docstring
    text = "This is a docstring"
    docstring_obj = parse(text)
    assert docstring_obj.short_description == "This is a docstring"
    assert docstring_obj.long_description is None

    # Test correct parsing of a short docstring
    text = """
        This is a docstring
        It spans multiple lines.
    """
    docstring_obj = parse(text)
    assert docstring_obj.short_description == "This is a docstring"

# Generated at 2022-06-25 16:29:41.800313
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = """
    This is a short description.

    This is also a short description.

    Parameters
    ----------
    param1 : type1
        description1
    param2 : type2
        description2

    """
    docstring = numpydoc_parser_0.parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is also a short description."
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ["param", "param1"]
    assert docstring.meta[0].type_name == "type1"
    assert docstring.meta[0].description == "description1"
    assert docstring.meta[1].args

# Generated at 2022-06-25 16:29:57.284192
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    Test a class with members.

    Test a class with members.

    Parameters
    ----------
    classname: str
        The name of the class.
    memeber: str
        The class memeber.
    '''

    numpydoc_parser_1 = NumpydocParser()
    docstring = numpydoc_parser_1.parse(text)

    assert docstring.short_description == 'Test a class with members.'
    assert docstring.long_description == 'Test a class with members.'
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == True

    assert len(docstring.meta) == 1
    assert docstring.meta[0].args[0] == 'param'
    assert docstring.meta[0].args

# Generated at 2022-06-25 16:30:13.936646
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:30:19.581071
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "This is a docstring."
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert (docstring_0.short_description == "This is a docstring.")
    assert (docstring_0.long_description is None)


# Generated at 2022-06-25 16:30:27.785168
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''\
    This is an example docstring for this function.

    Parameters
    ----------
    x : int
        first parameter
    y : list
        second parameter

    Returns
    -------
    int
        -1

    Other Parameters
    ----------------
    w : float
        third parameter
    '''

    actual = NumpydocParser().parse(text)


# Generated at 2022-06-25 16:30:31.966425
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Parse a numpydoc docstring into its components.

    :returns: parsed docstring
    """
    numpydoc_parser_0 = NumpydocParser()
    assert isinstance(numpydoc_parser_0.parse(""), Docstring)


# Generated at 2022-06-25 16:30:42.795574
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = parse(
        '''Summary line.

Further description.

Parameters
----------
arg_name
    arg_description
arg_2 : type, optional
    descriptions can also span...
    ... multiple lines
arg_3
    default is 0

Returns
-------
return_name : type
    A description of this returned value
another_type
    Return names are optional, types are required

Raises
------
ValueError
    A description of what might raise ValueError

Warns
-----
RuntimeWarning
    More description about what might raise RuntimeWarning
'''
    )
    assert numpydoc_parser_1.short_description == "Summary line."
    assert numpydoc_parser_1.long_description == "Further description."
    assert numpydoc_parser_1.blank_

# Generated at 2022-06-25 16:30:45.862138
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert parse(text = "") == Docstring()

# Generated at 2022-06-25 16:30:57.696398
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()

    text = """This is a docstring.

Parameters
----------
text : string
    The text to parse.

Returns
-------
Docstring
    The parsed docstring.
"""

    docstring = numpydoc_parser.parse(text)
    if docstring.short_description != 'This is a docstring.':
        raise Exception("docstring.short_description != 'This is a docstring.'")
    if docstring.blank_after_short_description != True:
        raise Exception("docstring.blank_after_short_description != True")

    if docstring.long_description != None:
        raise Exception("docstring.long_description != None")


# Generated at 2022-06-25 16:31:02.608986
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    assert parser.parse(None) == Docstring()



# Generated at 2022-06-25 16:31:15.002808
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''A potentially long-winded,
    multi-line description
    for a simple method.

    Parameters
    ----------
    arg1 : str
        A positional argument.
    arg2 : list or str
        An optional argument.
    arg3 : float, optional
        Another optional argument.
        With multiple lines of description.

    Raises
    ------
    ValueError
        If `arg2` is not a list or string.

    Returns
    -------
    output : str
        A convoluted value.
    '''

    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:31:18.593937
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse('\n    Short description\n    ')

    assert docstring_0.long_description is None


# Generated at 2022-06-25 16:31:32.146665
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Initialize the class
    numpydoc_parser_1 = NumpydocParser()
    text_1 = 'foo'
    docstring_1 = numpydoc_parser_1.parse(text_1)
    assert docstring_1.short_description == text_1
    text_2 = ''
    docstring_2 = numpydoc_parser_1.parse(text_2)
    assert docstring_2.short_description == None

    section_parser_1 = Section('Section1', 'meta')
    section_parser_2 = Section('Section2', 'meta')
    section_parser_3 = Section('Section3', 'meta')
    numpydoc_parser_2 = NumpydocParser([section_parser_1, section_parser_2, section_parser_3])
    text_3

# Generated at 2022-06-25 16:31:33.752819
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    NumpydocParser.parse()



# Generated at 2022-06-25 16:31:44.626481
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
:param arg_0: The first argument.
:param arg_1: The second argument. Optional.
:returns: The return value, a boolean.
"""
    )
    assert len(docstring.meta) == 3
    meta_0, meta_1, meta_2 = docstring.meta
    assert isinstance(meta_0, DocstringParam)
    assert meta_0.args == ["param", "arg_0"]
    assert isinstance(meta_1, DocstringParam)
    assert meta_1.args == ["param", "arg_1"]
    assert isinstance(meta_2, DocstringReturns)
    assert meta_2.args == ["returns"]


##------------------------
# Number 0
##------------------------
# NumpydocParser

# Generated at 2022-06-25 16:31:56.531852
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = str()
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.long_description is None
    assert docstring_0.short_description is None
    text_1 = '"""\nNo sections\n"""\n'
    docstring_1 = numpydoc_parser_0.parse(text_1)
    assert docstring_1.long_description is None
    assert docstring_1.short_description == 'No sections'
    text_2 = '"""\nNo sections, but with newlines\n\n"""\n'
    docstring_2 = numpydoc_parser_0.parse(text_2)
    assert docstring_2.long_description

# Generated at 2022-06-25 16:32:05.931789
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    simple_docstring = '''
    This is a simple docstring.
    
    
    '''
    returned_object = NumpydocParser().parse(simple_docstring)
    assert returned_object.short_description is 'This is a simple docstring.'
    assert returned_object.long_description is None
    assert returned_object.blank_after_short_description is False
    assert returned_object.blank_after_long_description is True
    assert returned_object.meta == []


# Generated at 2022-06-25 16:32:14.431415
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "This is the summary.\n"
    text_1 = "This is the summary.\n\nThis is the docstring body.\n"
    text_2 = "This is the summary.\n\nThis is the docstring body.\n\nThis is the docstring body.\n"
    text_3 = "This is the summary.\n\nThis is the docstring body.\n\nThis is the docstring body.\n\nThis is the docstring body.\n"

# Generated at 2022-06-25 16:32:23.535205
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    arg_0 = '''
    Parameters
    ----------
    paremeter_1 : type1
        Description1
    paremeter_2 : type2, optional
        Description2
    paremeter_3 : type3, optional
        Description3
    paremeter_4 : type4, optional (default=12.4)
        Description4
    '''
    numpydoc_parser_0.parse(arg_0)


# Generated at 2022-06-25 16:32:34.219463
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_text = '''
    Fit the model according to the given training data.
    Parameters
    ----------
    X : array-like, shape = [n_samples, n_features]
        Training vector, where n_samples is the number of samples and
        n_features is the number of features.
    y : array-like, shape = [n_samples] or [n_samples, n_output]
        Target relative to X for classification or regression;
        None for unsupervised learning.
    sample_weight : array-like, shape = [n_samples], optional
        Sample weights.
    Returns
    -------
    self : returns a trained MLPRegressor or MLPClassifier.
    '''
    parsed_docstring = numpydoc

# Generated at 2022-06-25 16:32:42.533180
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print("Testing parse...")
    numpydoc_parser_0 = NumpydocParser()
    assert numpydoc_parser_0.parse("This is.").short_description == "This is."
    assert numpydoc_parser_0.parse("This is.\n\nAnd this is.").long_description == "And this is."
    assert numpydoc_parser_0.parse("\nThis is.\n\nAnd this is.\n").short_description == "This is."
    assert numpydoc_parser_0.parse("This is.\nAnd this is.\n").long_description == "And this is."
    assert numpydoc_parser_0.parse("This is.\n\nAnd\nthis is.\n").long_description == "And\nthis is."

# Generated at 2022-06-25 16:32:46.897258
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Assigning docstring to variable
    docstring = """
    This is a test string
    """
    # Assigning result of method parse of class NumpydocParser with value docstring to variable
    result_parse = NumpydocParser().parse(docstring)
    # Assigning the short description of result_parse to variable
    short_description = result_parse.short_description
    # Assigning the long description of result_parse to variable
    long_description = result_parse.long_description

# Generated at 2022-06-25 16:33:00.307666
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:33:03.693744
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case_0()


if __name__ == "__main__":
    import doctest

    doctest.testmod()