

# Generated at 2022-06-25 16:23:27.602744
# Unit test for method parse of class Section
def test_Section_parse():

    # Test arguments
    title = "title"
    key = "key"
    text = "text"

    # Test function call
    result = Section.parse(title, key, text)
    assert result != None


# Generated at 2022-06-25 16:23:31.339388
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section = ParamSection("Parameters", "param")
    text = inspect.cleandoc("""
    a
        a description
        with multiple lines
    b
        b description
    """)
    params = list(section.parse(text))
    assert params[0].description == "a description\nwith multiple lines"
    assert params[0].arg_name == "a"
    assert params[0].type_name is None
    assert params[1].description == "b description"
    assert params[1].arg_name == "b"
    assert params[1].type_name is None


# Generated at 2022-06-25 16:23:33.091874
# Unit test for method parse of class Section
def test_Section_parse():
    str_0 = 'T\t1(|E?-hIU`.-"~\n'
    obj_0 = Section('', '')
    str_1 = obj_0.parse(str_0)
    return str_1


# Generated at 2022-06-25 16:23:34.447963
# Unit test for method parse of class Section
def test_Section_parse():
    str_0 = 'T\t1(|E?-hIU`.-"~\n'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:23:36.157094
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    str_0 = 'T\t1(|E?-hIU`.-"~\n'
    docstring_0 = parse('U{(6;Oa6zE}*y:D^rP.\n')


# Generated at 2022-06-25 16:23:44.498101
# Unit test for method parse of class Section
def test_Section_parse():
    # Test case:
    str_0 = 'T\t1(|E?-hIU`.-"~\n'
    title_1 = 'Parameters'
    key_1 = 'param'
    section_2 = Section(title_1, key_1)
    text_3 = inspect.cleandoc(str_0)
    docstring_0 = section_2.parse(text_3)


# Generated at 2022-06-25 16:23:53.144616
# Unit test for method parse of class Section
def test_Section_parse():
    text_0 = 'arg_name\n    arg_description\n    value\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines\n'
    section_0 = ParamSection("Parameters", "param")
    assert section_0.parse(text_0) == [(section_0._parse_item(m.group(0), text_0[m.end():end])) for m, (end, _) in zip(re.finditer(KV_REGEX, text_0), zip(re.finditer(KV_REGEX, text_0), range()))]


# Generated at 2022-06-25 16:23:56.347604
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = ''
    docstring_0 = NumpydocParser().parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.long_description == None
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:23:58.672456
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    obj_0 = DeprecationSection()
    print(obj_0)



# Generated at 2022-06-25 16:24:05.165714
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    instance_0 = _KVSection('Parameters', 'param')
    str_0 = 'param\n    arg_description'
    instance_0.parse(str_0)
    str_0 = 'param : type, optional\n    values can also span...\n    ... multiple lines'
    instance_0.parse(str_0)


# Generated at 2022-06-25 16:24:33.591301
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    obj = ParamSection("Parameters", "param")
    text = "arg_name\n\targ_description\narg_2 : type, optional\n\tdescriptions can also span...\n\t... multiple lines\n"
    ret = obj.parse(text)
    assert ret


# Generated at 2022-06-25 16:24:35.241699
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    p = _KVSection.parse(str_0)


# Generated at 2022-06-25 16:24:40.885029
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    str_0 = 'T\t1(|E?-hIU`.-"~\n'
    docstring_0 = parse(str_0)



# Generated at 2022-06-25 16:24:46.853662
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    obj = _KVSection("Parameters","param" )
    try:
        assert isinstance(obj.parse( "key\n    value\nkey2 : type\n    values can also span...\n    ... multiple lines\n"),T.Iterable[DocstringMeta])
        assert True
    except:
        assert False


# Generated at 2022-06-25 16:24:49.938402
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 16:24:58.944826
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    np = NumpydocParser()
    # Test 1
    str_1 = 'T\t1(|E?-hIU`.-"~\n'
    docstring_1 = np.parse(str_1)

    # Test 2
    str_2 = 'T\t1(|E?-hIU`.-"~\n'
    docstring_2 = np.parse(str_2)

    # Test 3
    str_3 = 'T\t1(|E?-hIU`.-"~\n'
    docstring_3 = np.parse(str_3)



# Generated at 2022-06-25 16:25:01.311228
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    obj = NumpydocParser()
    obj.parse("T\t1(|E?-hIU`.-\"~\n")
    return None

# Generated at 2022-06-25 16:25:12.963406
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    parser = NumpydocParser()
    docstring = parser.parse('a : int\n    t\n    t\n')
    docstring.meta.extend(parser.parse('a : int\n    t\n    t\n'))
    docstring.meta.extend(parser.parse('a : int\n    t\n    t\n'))
    docstring.meta.extend(parser.parse('a : int\n    t\n    t\n'))
    docstring.meta.extend(parser.parse('a : int\n    t\n    t\n'))
    docstring.meta.extend(parser.parse('a : int\n    t2\n    \n'))


# Generated at 2022-06-25 16:25:16.528072
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section_0 = _KVSection(None, None)
    str_0 = 'T\t1(|E?-hIU`.-"~\n'
    test___KVSection_parse_0(section_0, str_0)



# Generated at 2022-06-25 16:25:17.911411
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case_0()



# Generated at 2022-06-25 16:26:17.995884
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Setup test case
    text = 'T\t1(|E?-hIU`.-"~\n'
    expected_docstring = Docstring()
    expected_docstring.short_description = None
    expected_docstring.blank_after_short_description = False
    expected_docstring.blank_after_long_description = False
    expected_docstring.long_description = None
    expected_docstring.meta = []

    # Create instance of NumpydocParser
    parser = NumpydocParser()

    # Execute test case
    docstring = parser.parse(text)

    # Verify results
    assert expected_docstring == docstring


# Generated at 2022-06-25 16:26:20.847166
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    test0 = 'T\t1(|E?-hIU`.-"~\n'
    try:
        result = parser.parse(test0)
    except: # noqa: E722
        assert False, 'Failed to parse NumpydocParser parse'


# Generated at 2022-06-25 16:26:25.021392
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'T\t1(|E?-hIU`.-"~\n'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:26:29.093517
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'T\t1(|E?-hIU`.-"~\n'
    parser_0 = NumpydocParser()
    docstring_0 = parser_0.parse(str_0)


# Generated at 2022-06-25 16:26:35.125210
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    NumpydocParser_instance_0 = NumpydocParser()
    str_0 = 'T\t1(|E?-hIU`.-"~\n'
    Docstring_0 = NumpydocParser_instance_0.parse(str_0)

# Generated at 2022-06-25 16:26:39.064917
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = 'T\t1(|E?-hIU`.-"~'
    # Constructor test
    parser = NumpydocParser()
    # Method test
    assert parser.parse(text) is not None

# Generated at 2022-06-25 16:26:42.355708
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_1 = 'T\t1(|E?-hIU`.-"~\n'
    docstring_1 = NumpydocParser().parse(str_1)
    assert docstring_1.short_description == 'T\t1(|E?-hIU`.-"~\n'


# Generated at 2022-06-25 16:26:50.963746
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'T\t1(|E?-hIU`.-"~\n'
    docstring_0 = parse(str_0)
    arg_0 = 'T\t1(|E?-hIU`.-"~\n'
    docstring_1 = NumpydocParser().parse(arg_0)
    assert docstring_0 == docstring_1


# Generated at 2022-06-25 16:26:58.884320
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    str_0 = 'T\t1(|E?-hIU`.-"~\n'
    docstring_0 = parser.parse(str_0)
    print(docstring_0.short_description)
    print(docstring_0.long_description)
    print(docstring_0.blank_after_short_description)
    print(docstring_0.blank_after_long_description)
    for meta in docstring_0.meta:
        print('----')
        print(meta.args)
        print(meta.description)
        print(meta.arg_name)
        print(meta.type_name)
        print(meta.is_optional)
        print(meta.default)
        print(meta.return_name)
        print(meta.version)

# Generated at 2022-06-25 16:27:09.470197
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = ''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.meta == []

    str_1 = 'short description'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'short description'
    assert docstring_1.long_description is None
    assert docstring_1.meta == []

    str_2 = \
        '   short description\n'\
        '   \n'\
        '   long description'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'short description'
    assert docstring_2.long_description == 'long description'

# Generated at 2022-06-25 16:27:34.372049
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test with empty input string
    actual = NumpydocParser().parse("")
    expected = Docstring()
    assert actual == expected
    # Test with single line without meta data
    actual = NumpydocParser().parse("Short description")
    expected.short_description = "Short description"
    assert actual == expected

    # Test with single line with section Parser
    actual = NumpydocParser().parse("Short description\n\nParameters\n--------")
    expected.short_description = "Short description"
    expected.blank_after_short_description = True
    assert actual == expected

    # Test with single line with section Parser and missing new line
    actual = NumpydocParser().parse("Short description\nParameters\n--------")
    expected.short_description = "Short description"
    expected.blank_after_short_

# Generated at 2022-06-25 16:27:39.982672
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = 'Test numpydoc_parsing.py for test cases'
    ds = numpydoc_parser_0.parse(text)
    if ds is None:
        pass
    else:
        assert False


if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-25 16:27:51.778416
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:27:58.144296
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """The first line is the short description.
    The second line is ignored because it is indented.
    The third line is part of the long description. It can be on any number of lines.
    """
    docstring_0 = numpydoc_parser_0.parse(text_0)

    assert docstring_0.short_description == "The first line is the short description."
    assert docstring_0.long_description == (
        "The third line is part of the long description. It can be on any number of lines."
    )


# Generated at 2022-06-25 16:28:09.985791
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """
    A short summary

    A long description.

    Parameters
    ----------
    arg
        A required argument.
    arg_2 : type
        An argument with type.
    arg_3 : type, optional
        An optional argument with type.
    arg_with_default = 'default_value'
        An argument with a default value.
    arg_with_default_and_type = None : type
        An argument with a default value and type.

    Raises
    ------
    ValueError
        Something went wrong
    """
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description == "A short summary"

# Generated at 2022-06-25 16:28:20.024570
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    Function with a really long description

    This is a really long description that you want to test.

    Parameters
    ----------
    arg1
        Description of arg1,
        this can span multiple lines
    arg2 : type, optional
        Description of arg2
    '''
    d = NumpydocParser().parse(text)
    assert d.short_description == 'Function with a really long description'
    assert d.blank_after_short_description == False
    assert d.long_description == '''This is a really long description that you want to test.'''
    assert d.blank_after_long_description == True
    assert len(d.meta) == 2


# Generated at 2022-06-25 16:28:32.836811
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

    text_0 = """
    This is a summary line

    Then comes the long description, which is usually indented and can span
    multiple lines.
    """
    docstring_0 = numpydoc_parser_0.parse(text_0)

    text_1 = """
    Summary.

    Description.

    Examples
    --------
    This is a description of an example.

    Example
    -------
    This is a description of an example.

    Notes
    -----
    This is a description of a note.
    """
    docstring_1 = numpydoc_parser_0.parse(text_1)


# Generated at 2022-06-25 16:28:43.006274
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Implicit python docstring
    text = """
    This docstring is implicitly created by this class
    """
    # Implicitly created description
    ret = parse(text)
    try:
        assert ret.short_description is None
    except AssertionError as e:
        print(
            "Wrong answer for implicit docstring. Expected None for short_description but returned {}. Test case failed."
            .format(ret.short_description)
        )
        raise e
    else:
        print("Passed test case 0")
    try:
        assert ret.long_description is None
    except AssertionError as e:
        print(
            "Wrong answer for implicit docstring. Expected None for long_description but returned {}. Test case failed."
            .format(ret.long_description)
        )
        raise

# Generated at 2022-06-25 16:28:54.210546
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 0
    numpydoc_parser_0 = NumpydocParser()
    text = 'This is a test.\n\nThis is the end.'
    result = numpydoc_parser_0.parse(text)
    assert result._short_description == 'This is a test.'
    assert result._blank_after_short_description
    assert result._blank_after_long_description
    assert result._long_description == 'This is the end.'
    assert len(result._meta) == 0

    # Test case 1
    numpydoc_parser_1 = NumpydocParser()
    text = 'This is a test.\n\nThis is the end.'
    result = numpydoc_parser_1.parse(text)
    assert result._short_description == 'This is a test.'
   

# Generated at 2022-06-25 16:29:02.902697
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text="""
    Short description.
    Long description.

    Parameters
    arg_name : arg_type
        arg_description
    arg_name, optional
        arg_description

    Returns
    return_type
        return_description
    """
    ret=numpydoc_parser_0.parse(text)
    assert type(ret) is Docstring
    assert type(ret.short_description) is str
    assert type(ret.blank_after_short_description) is bool
    assert type(ret.long_description) is str
    assert type(ret.blank_after_long_description) is bool
    assert type(ret.meta) is list
    assert type(ret.meta[0]) is DocstringParam
    assert ret.meta[0].args

# Generated at 2022-06-25 16:29:12.297550
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    try:
        numpydoc_parser_1 = NumpydocParser()
        numpydoc_parser_1.parse('Method to add metadata to a TimeSeries.')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 16:29:22.630899
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    expected_return_value_0 = Docstring()
    expected_return_value_0.short_description = "short description"
    expected_return_value_0.long_description = "long description"
    expected_return_value_0.blank_after_short_description = True
    expected_return_value_0.blank_after_long_description = True

# Generated at 2022-06-25 16:29:30.555634
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    s = "Raises\n------\nAn error\n"
    NumpydocParser().parse(s)

    s = "Raises\n------\nAn error"
    NumpydocParser().parse(s)

    s = "Raises\n------\n"
    NumpydocParser().parse(s)

    s = "Raises\n------"
    NumpydocParser().parse(s)


if __name__ == '__main__':
    test_case_0()
    test_NumpydocParser_parse()
    print("All tests passed successfully.")

# Generated at 2022-06-25 16:29:41.769936
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring = numpydoc_parser_0.parse("""
    Short description.

    Long description.

    Parameters
    ----------
    arg1 : some type
        With multiple lines.
    arg2 : int, optional
        Another argument.
    other_params : other type, optional
        Many other parameters.
    arg3 : str, optional (default="")
        Yet another argument.

    Returns
    -------
    out1 : int
        The first output.
    out2 : list
        The second output.

    Raises
    ------
    SomeError
        When stuff goes wrong.

    Warnings
    --------
    This is a warning.

    Examples
    --------
    >>> import stuff
    >>> stuff.make_stuff()
    stuff
    """)

# Generated at 2022-06-25 16:29:52.517993
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    numpydoc_parser_0 = parse("")
    assert numpydoc_parser_0
    assert numpydoc_parser_0.short_description is None
    assert numpydoc_parser_0.long_description is None
    assert numpydoc_parser_0.blank_after_short_description is False
    assert numpydoc_parser_0.blank_after_long_description is False
    assert numpydoc_parser_0.meta == []

    numpydoc_parser_1 = parse("A single line")
    assert numpydoc_parser_1
    assert numpydoc_parser_1.short_description == "A single line"
    assert numpydoc_parser_1.long_description is None
    assert numpydoc_parser_1.blank_after_short_

# Generated at 2022-06-25 16:29:57.246541
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """\
    Test function for some_package.

    This function should be used to test some_package.

    Parameters
    ----------
    arg : bool, optional
        Description of `arg` (the default is False).
    *args : array_like
        Description of `args` (the default is None).
    **kwargs : dict
        Description of `kwargs` (the default is None).
    """

    numpydoc_parser_0 = NumpydocParser()

    ret = numpydoc_parser_0.parse(text)

    assert ret.short_description == \
        "Test function for some_package."
    assert ret.blank_after_short_description
    assert ret.long_description == \
        "This function should be used to test some_package."
    assert not ret.blank_after_

# Generated at 2022-06-25 16:30:10.541019
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # example docstring
    docstring = '''
    Some function.

    Parameters
    ----------
    x : int
        A useful parameter.
    y : int, optional
        A default parameter.
    z : str
        Some user-defined parameter.

    Raises
    ------
    ValueError : if x < 0

    Returns
    -------
    int
        Return value.
    '''
    # Initialize the parser
    parser = NumpydocParser()

    # Parse the example docstring
    doc = parser.parse(docstring)

    # Check short_description
    assert doc.short_description == "Some function."

    # Check blank_after_short_description
    assert doc.blank_after_short_description == True

    # Check long_description
    assert doc.long_description == None

    # Check blank

# Generated at 2022-06-25 16:30:19.093697
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = '''Function docstring
    '''

    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.short_description == 'Function docstring'
    assert docstring_0.long_description == None

    text_1 = '''Function docstring
    With a single empty line after
    '''

    docstring_1 = numpydoc_parser_0.parse(text_1)
    assert docstring_1.blank_after_long_description == True
    assert docstring_1.blank_after_short_description == False

# Generated at 2022-06-25 16:30:23.490727
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = 'this is the description\n\n' \
           'the paragraph this time\n' \
           'has no double space at the end'
    numpydoc_parser_0.parse(text)


# Generated at 2022-06-25 16:30:33.773353
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    expected_0 = (
        "This is a deprecated test.\n"
        "All the lines in this paragraph will be considered part of the type\n"
        "annotation, because this option is not yet supported.\n\n"
    )
    text_0 = (
        "This is a deprecated test.\n"
        "This should be part of the test, but is treated as type annotation\n"
        "because this is not yet supported.\n"
    )
    ret_0 = numpydoc_parser_0.parse(text_0)
    assert ret_0.short_description == "This is a deprecated test."
    assert len(ret_0.meta) == 1
    assert ret_0.meta[0].description == expected_0

# Generated at 2022-06-25 16:30:48.801561
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = inspect.cleandoc("""\
    """
    )
    r_0 = numpydoc_parser_0.parse(text_0)
    assert r_0.short_description is None
    assert r_0.long_description is None
    assert r_0.meta == []
    numpydoc_parser_1 = NumpydocParser()
    text_1 = inspect.cleandoc("""\
    x.

    """
    )
    r_1 = numpydoc_parser_1.parse(text_1)
    assert r_1.short_description == "x."
    assert r_1.long_description is None
    assert r_1.meta == []
    numpydoc_parser_2

# Generated at 2022-06-25 16:30:59.231507
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    ret = numpydoc_parser_1.parse("")
    assert (ret.short_description is None)
    assert (ret.long_description is None)
    assert (ret.blank_line_after_short_description == False)
    assert (ret.blank_line_after_long_description == False)
    ret.meta == list()
    ret = numpydoc_parser_1.parse("abc\ndef")
    assert (ret.short_description == "abc")
    assert (ret.long_description == "def")
    assert (ret.blank_line_after_short_description == False)
    assert (ret.blank_line_after_long_description == False)
    ret.meta == list()
    ret = numpydoc_

# Generated at 2022-06-25 16:31:04.897709
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    docstring_2 = '''
    this is a short description
        this is a long desc
        it can span multiple lines

    Args:
        arg_one(str): arg desc
        arg_two: arg desc
    '''
    docstring_2 = numpydoc_parser_1.parse(docstring_2)


# Generated at 2022-06-25 16:31:12.404416
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring = inspect.cleandoc("""\
        Parse the numpy-style docstring into its components.

        :returns: parsed docstring

        Parameters
        ----------
        text: str
            Docstring to clean

        Raises
        ------
        ValueError
            If no text is supplied
    """)
    numpydoc_parser_0.parse(docstring)
    docstring = inspect.cleandoc("""\
        Parse the numpy-style docstring into its components.

        :returns: parsed docstring

        Parameters
        ----------
        text: str
            Docstring to clean

        Raises
        ------
        ValueError
            If no text is supplied
    """)

# Generated at 2022-06-25 16:31:21.561377
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 = "The_method_does_not_exist"
    docstring_0 = numpydoc_parser_0.parse(str_0)
    assert docstring_0.short_description == "The method does not exist"
    assert docstring_0.long_description == "The method does not exist"
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.blank_after_short_description == True
    assert len(docstring_0.meta) == 0


# Generated at 2022-06-25 16:31:31.558396
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    assert numpydoc_parser_0.parse("a") == Docstring(
        short_description='a',
        long_description=None,
        metadata=[],
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert numpydoc_parser_0.parse("a\nb") == Docstring(
        short_description='a',
        long_description='b',
        metadata=[],
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

# Generated at 2022-06-25 16:31:43.918568
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    d = numpydoc_parser_0.parse(
        "short description\n\nlong description\n\nParameters\n----------\nparam1 : type, optional\n    param1 description\n    spanned over\n    multiple lines\n\nparam2 : type, optional\n    param2 description\n\nReturns\n-------\nout1 : type\n    description of out1"
    )
    assert d.short_description == "short description"
    assert d.long_description == "long description"

# Generated at 2022-06-25 16:31:53.850502
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from . import test_case_0
    from textwrap import dedent
    docstring = dedent(
        """
        Example docstring.

        Some other text.
        """
    )
    expected_docstring = Docstring(
        meta=[],
        short_description="Example docstring.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="Some other text.\n",
    )
    assert(numpydoc_parser_0.parse(docstring) == expected_docstring)


# Generated at 2022-06-25 16:32:01.525824
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = "Returns an integer"
    docstring = numpydoc_parser_0.parse(text)

    assert docstring.short_description == "Returns an integer"
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 0


# Generated at 2022-06-25 16:32:04.989101
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.parse('')


# Generated at 2022-06-25 16:32:24.796788
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:32:30.256473
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = 'helloworld\n'
    numpydoc_parser_1 = NumpydocParser()
    docstring = numpydoc_parser_1.parse(text)
    assert docstring.short_description == 'helloworld'
    assert not docstring.blank_after_short_description



# Generated at 2022-06-25 16:32:40.585876
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = """Parses a NumPy-style docstring.

    :param text:
        A docstring to parse.
    :return: parsed docstring
    :rtype: Docstring
    """
    docstring = numpydoc_parser_0.parse(text)
    assert docstring.short_description == "Parses a NumPy-style docstring."
    assert docstring.long_description == ":param text:\n    A docstring to parse.\n:return: parsed docstring\n:rtype: Docstring"
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 0

# Generated at 2022-06-25 16:32:47.447949
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser().parse(
        """\
        This is an amazing function.

            - It can do this
            - It can do that
            - It can make the world go round

        Parameters
        ----------
        x : int
            where to start counting

        Returns
        -------
        out : int
            how many things there were
        """
    )



# Generated at 2022-06-25 16:32:58.310528
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # string to parse
    doc_string = '''\
    Parameters
    ----------
        arg_name
            arg_description
        arg_2: type, optional
            Descriptions can also span
            multiple lines
    '''
    result_0 = numpydoc_parser_0.parse(doc_string)
    assert len(result_0.meta) == 1
    arg_param_1 = result_0.meta[0]

    assert arg_param_1.key == 'param'
    assert arg_param_1.args == ['param', 'arg_name']
    assert arg_param_1.description == 'arg_description'
    assert arg_param_1.arg_name == 'arg_name'
    assert arg_param_1.type