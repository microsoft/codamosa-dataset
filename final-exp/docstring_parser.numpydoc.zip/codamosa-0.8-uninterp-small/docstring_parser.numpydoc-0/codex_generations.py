

# Generated at 2022-06-25 16:24:12.443967
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.parse('   first line   \n   second line\n')
    numpydoc_parser_0.parse('   first line   \n\n   second line\n')
    numpydoc_parser_0.parse('   first line   \n   second line')
    numpydoc_parser_0.parse('\n   first line   \n   second line')
    numpydoc_parser_0.parse('\n   first line   \n   second line\n')
    numpydoc_parser_0.parse('   first line   \n\n   second line')
    numpydoc_parser_0.parse('   first line   \n\n\n   second line')
    nump

# Generated at 2022-06-25 16:24:22.485155
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    str_1 = ''
    ret = numpydoc_parser_1.parse(str_1)
    assert ret.short_description == None
    assert ret.blank_after_short_description == None
    assert ret.blank_after_long_description == None
    assert ret.long_description == None
    assert ret.meta == []
    str_2 = '''One line summary.
    
    More detailed description. It can have multiple paragraphs.
    '''
    ret = numpydoc_parser_1.parse(str_2)
    assert ret.short_description == 'One line summary.'
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False

# Generated at 2022-06-25 16:24:35.477533
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    numpydoc_parser_1 = NumpydocParser()
    assert numpydoc_parser_1.parse("") == Docstring()
    numpydoc_parser_2 = NumpydocParser()
    text = "  test_2\n"
    assert numpydoc_parser_2.parse(text).short_description == "test_2"
    assert numpydoc_parser_2.parse(text).long_description == None
    numpydoc_parser_3 = NumpydocParser()
    text = "  test_3\n\n\n"
    assert numpydoc_parser_3.parse(text).short_description == "test_3"
    assert numpydoc_parser_3.parse(text).long_description == None
    numpydoc_parser_4

# Generated at 2022-06-25 16:24:41.097155
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    ds = """The input array.
    :type arg1: array_like
    :return: The calculated autocorrelations.
    :rtype: ndarray"""
    parser = NumpydocParser()
    new_doc = parser.parse(ds)

    assert new_doc.long_description is not None
    assert new_doc.short_description is None
    assert new_doc.meta[0].arg_name == "arg1"
    assert new_doc.meta[0].type_name == "array_like"



# Generated at 2022-06-25 16:24:51.706711
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''\
The quick brown fox jumped over the lazy dog.

Params:
param 1:
    A string.
param 2:
    A number.

Returns:
    A string.

Raises:
    ValueError:
        If the result is none.
    RuntimeError:
        If the result is none.

Examples:
    >>> a = 12
    >>> b = 13
    >>> a + b
    25
    >>> a - b
    -1
'''
    res = NumpydocParser().parse(text)
    assert res.short_description == 'The quick brown fox jumped over the lazy dog.'
    assert res.blank_after_short_description == True
    assert res.blank_after_long_description == True
    assert res.long_description == ''
    assert len(res.meta)

# Generated at 2022-06-25 16:25:02.716976
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

    # Test 1
    text_1 = '''
    test_NumpydocParser_parse(self)

    Unit test for method parse of class NumpydocParser
    '''
    docstring_1 = numpydoc_parser_0.parse(text_1)
    assert docstring_1.short_description == 'test_NumpydocParser_parse(self)'
    assert docstring_1.long_description == 'Unit test for method parse of class NumpydocParser'
    assert docstring_1.meta == []

    # Test 2

# Generated at 2022-06-25 16:25:04.957326
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    numpydoc_parser_0 = NumpydocParser()
    try:
        result = numpydoc_parser_0.parse("")
    except Exception as e:
        print(e)
        assert False
    assert True


# Generated at 2022-06-25 16:25:15.092557
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """ Test docstring parsing with numpydoc format.
    """
    docstring = """
    A numpydoc docstring for this function.

    Description goes here.

    Parameters
    ----------
    arg_without_name : int
        Description of the first argument.
    arg_with_name : int, optional
        Description of the second argument.
    arg_with_default : int, optional
        Description of the third argument. Default is 1.

    Returns
    -------
    str
        Description of the return value.

    Other Parameters
    ----------------
    other_param : int
        Some other parameter.

    Raises
    ------
    ValueError
        Some error.

    References
    ----------
    [1] http://example.com/
    """

    parser = NumpydocParser()


# Generated at 2022-06-25 16:25:27.002436
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:25:32.169584
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = str("")
    docstring0 = numpydoc_parser_0.parse(text)

###############################################################################
# Test the following:
# Element of type DocstringRaises, args attribute is a list of type str
###############################################################################


# Generated at 2022-06-25 16:25:48.089286
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    with open('numpydoc.txt') as f:
        text = f.read()

    docstring = NumpydocParser().parse(text)
    assert type(docstring) == Docstring
    assert docstring.short_description == "add two numbers together"
    assert type(docstring.long_description) == str
    assert type(docstring.meta) == list

    for meta in docstring.meta:
        assert type(meta) == DocstringMeta


# Generated at 2022-06-25 16:25:53.986356
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    text_1 = ""
    serialized_parse_result_1 = "{}"
    assert str(numpydoc_parser_1.parse(text_1)) == serialized_parse_result_1


# Generated at 2022-06-25 16:26:06.299872
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    ds = numpydoc_parser_1.parse(text="")
    assert len(ds.meta) == 0
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    ds = numpydoc_parser_1.parse(text="  ")
    assert len(ds.meta) == 0
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False

# Generated at 2022-06-25 16:26:09.679086
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 = ""
    ret_0 = numpydoc_parser_0.parse(str_0)


# Generated at 2022-06-25 16:26:19.122445
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    numpydoc_parser_1 = NumpydocParser(sections=DEFAULT_SECTIONS)

    text_1 = """short description

        long description
        can contain all kinds of important info and go over
        multiple lines as well.
        """

    docstring_1 = numpydoc_parser_1.parse(text_1)

    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.short_description == "short description"
    assert docstring_1.long_description == (
        "long description\ncan contain all kinds of important info and go over\n"
        "multiple lines as well."
    )
    assert docstring_1.meta == []



# Generated at 2022-06-25 16:26:30.460319
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Assign parameters
    text = "This is a short description.\n\nThis is a long description.\n\nParameters: arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines\nRaises: ValueError\n    A description of what might raise ValueError\nReturns:\n    A description of what is returned\nReferences:\n    [1] Link text <https://example.com>\n    [2] Link text <https://example.com>\n    [3] Link text <https://example.com>\nSee Also:\n    Other class or function (or something else) you should also look at"
# Test with supplied parameters
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:26:42.583221
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """\
Example numpy-style doctring.

Parameters
----------
    numbers: int
        The numbers.
Returns
-------
    average: float
        The average.
"""

# Generated at 2022-06-25 16:26:47.862968
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # x = NumpydocParser()
    # assert True == x.parse()
    assert True # TODO: implement your test here


# Generated at 2022-06-25 16:26:55.116814
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    string_0 = """This method returns a description of the data."""
    docstring_0 = numpydoc_parser_0.parse(string_0)
    assert type(docstring_0) == Docstring
    assert docstring_0.short_description == string_0
    assert docstring_0.long_description == None
    assert docstring_0.meta == []
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False



# Generated at 2022-06-25 16:27:07.447290
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:27:24.295443
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_docstring_0 = numpydoc_parser_0.parse("a\n\n.. warning::\n\tb\n\n\n")
    # self.assertEqual(numpydoc_docstring_0.meta[0], NumpydocMeta(["warning"], description="b"))
    # self.assertEqual(numpydoc_docstring_0.short_description, "a")
    # self.assertEqual(numpydoc_docstring_0.long_description, "")



# Generated at 2022-06-25 16:27:37.762089
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = 'Quick sort algorithm.\n\n    :param items: list of items to be sorted\n    :type items: list\n    :param comp: comparison function taking 2 arguments (list items) and returning -1, 0 or 1\n    :return: None\n\n    '
    numpydoc_parser_0 = NumpydocParser()


# Generated at 2022-06-25 16:27:42.657999
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = None
    numpydoc_parser_1 = NumpydocParser()
    ret = numpydoc_parser_1.parse(text)
    assert ret == Docstring()


# Generated at 2022-06-25 16:27:46.463662
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0_str = """\
    """
    ret_0_Docstring = numpydoc_parser_0.parse(text_0_str)

    return


# Generated at 2022-06-25 16:27:55.551735
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    docstring_1 = numpydoc_parser_1.parse('')
    assert docstring_1.short_description == None
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == False
    assert len(docstring_1.meta) == 0

# Generated at 2022-06-25 16:28:04.746328
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "Return the absolute value of the argument."
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description == "Return the absolute value of the argument."
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:28:12.328503
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Arrange
    numpydoc_parser_1 = NumpydocParser()
    text_0 = "        Parse the numpy-style docstring into its components"

    # Act
    ret = numpydoc_parser_1.parse(text_0)

    # Assert
    assert ret.long_description == "Parse the numpy-style docstring into its components"
    assert ret.short_description == ""
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False
    assert ret.meta == [DocstringMeta(args=[], description=None)]


# Generated at 2022-06-25 16:28:20.845716
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    string = """
    This function does something cool with ``arg``.

    Parameters
    ----------
    arg : :class:`~my_module.MyClass`
        An instance of a class within the same module
    """
    numpydoc_parser_0 = NumpydocParser()
    result_0 = numpydoc_parser_0.parse(string)
    assert result_0.short_description == "This function does something cool with ``arg``."
    assert result_0.long_description == \
"""
An instance of a class within the same module
"""
    assert result_0.blank_after_short_description == True
    assert result_0.blank_after_long_description == True
    assert result_0.meta[0].args[0] == "param"

# Generated at 2022-06-25 16:28:31.873963
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    nupydoc_parser = NumpydocParser()
    docstring = inspect.cleandoc(
        '''
    Parameters
    ----------
    arg : type
        desc
    arg_2 : str
        desc
    '''
    )

    assert nupydoc_parser.parse(
        docstring
    ) == Docstring(
        short_description=None,
        long_description=None,
        meta=[
            DocstringMeta(args=["param", "arg"], description="desc"),
            DocstringMeta(args=["param", "arg_2"], description="desc"),
        ],
    )



# Generated at 2022-06-25 16:28:42.406995
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case with description only
    assert repr(parse("""
        Example docstring
        """)) == repr(Docstring(
        short_description='Example docstring',
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    ))

    # Test case with description and a single meta entry

# Generated at 2022-06-25 16:28:52.152566
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    text = '''This function computes the sigmoid of x.

Parameters
----------
x : array_like
    Input values.
'''
    result = numpydoc_parser_1.parse(text)
    assert result.short_description == 'This function computes the sigmoid of x.'
    assert result.long_description is None
    assert result.blank_after_short_description is True
    assert result.blank_after_long_description is False
    assert result.meta[0].keystr == 'param:x'
    assert result.meta[0].description == 'Input values.'


# Generated at 2022-06-25 16:29:02.178267
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_0 = '''
    This is a special method.

    :param a: A
    :param b: B
    :return: The result
    '''

# Generated at 2022-06-25 16:29:10.841991
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test of parsing
    """
    numpydoc_parser_1 = NumpydocParser()
    actual_output = numpydoc_parser_1.parse(
        """
    Run a function in a separate process

    This is a thin wrapper around `mp.Process`.

    Arguments
    ---------
    target: callable
        Target function to be run in the other process.
    args: tuple, optional
        Args for the target function.
    kwargs: dict, optional
        Keyword args for the target function.
    daemon: bool, optional
        Whether or not the process should be daemonic.
    """
    )

    assert actual_output.short_description == "Run a function in a separate process"
    assert actual_output.long_description is None
    assert actual_output.blank_after_short_

# Generated at 2022-06-25 16:29:14.779590
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''Test class for the NumpydocParser class.
    '''
    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == 'Test class for the NumpydocParser class.'
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == None
    assert docstring.meta == []


# Generated at 2022-06-25 16:29:22.726101
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "This is a test."
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert isinstance(docstring_0, Docstring)
    assert docstring_0.short_description == "This is a test."
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []



# Generated at 2022-06-25 16:29:32.928115
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert numpydoc_parser_0.parse("") == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert numpydoc_parser_0.parse("hello") == Docstring(
        short_description="hello",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-25 16:29:39.664050
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Construct the test case
    numpydoc_parser_0 = NumpydocParser()

    # Invoke the method under development
    result = numpydoc_parser_0.parse(**{
        "text": "",
    })

    # Check the result
    assert result == {}, "The method parse of class NumpydocParser returned something other than the expected value"

# Generated at 2022-06-25 16:29:48.456444
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''Test function for Foo.'''

    # Parse docstring with default settings
    docstring = NumpydocParser().parse(text)

    # Parse docstring with default settings
    docstring = NumpydocParser().parse("")

    # Raise AttributeError if one of the components is used before calling NumpydocParser.parse
    try:
        docstring = Docstring()
        docstring.short_description
        assert False
    except AttributeError:
        assert True


# Generated at 2022-06-25 16:29:59.381267
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case = parse("""
        Parses a numpy-style docstring with embedded param/return tags into its
        components.

    Parameters
    ----------
    text: str
        The docstring you want to parse

    Returns
    -------
    Docstring
        The parsed Docstring object

    Raises
    ------
    ValueError
        If the docstring is not formatted as a numpy-style docstring.
        """)

    assert test_case.short_description == 'Parses a numpy-style docstring with embedded param/return tags into its components.'

# Generated at 2022-06-25 16:30:12.783835
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case_0()

# def test_NumpydocParser_parse():
#     numpydoc_parser_0 = NumpydocParser()
#     text = str()
#     # Call the method under test
#     assert Docstring(
#         meta=[
#             DocstringParam(
#                 description=None,
#                 type_name=str(),
#                 is_optional=True,
#                 default=str(),
#                 arg_name=str(),
#                 args=[str(), str()],
#             )
#         ],
#         notes=None,
#         references=None,
#         warnings=None,
#         see_also=None,
#         examples=None,
#         returns=None,
#         attribute=None,
#         raises=None,
#         warns=None,


# Generated at 2022-06-25 16:30:19.834011
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    obj = NumpydocParser()
    obj.parse(text="")
    return True


# Generated at 2022-06-25 16:30:26.229703
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    input_str = inspect.cleandoc("""
    template method for making a new array of this shape and type.

    This method exists to be overloaded in subclasses that require a
    different constructor.

    Parameters
    ----------
    another_param : type
        Description of another_param

    Returns
    -------
    ret : type
        Description of ret
        long enough to span...
        several lines
    """)
    numpydoc_parser_1 = NumpydocParser()
    docstring = numpydoc_parser_1.parse(input_str)


# Generated at 2022-06-25 16:30:29.682755
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = 'This is a random docstring.'
    parse(text_0)
    assert True


# Generated at 2022-06-25 16:30:35.196250
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc_0 = "Example\n-------\n\nThese are examples.\nOnly two for now.\n"
    examples_0 = parse(doc_0)
    assert examples_0.meta[0].key == "examples"
    assert examples_0.meta[0].description == "These are examples.\nOnly two for now."

if __name__ == '__main__':
    test_case_0()
    test_NumpydocParser_parse()

# Generated at 2022-06-25 16:30:46.662821
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    first_section = ParamSection('Parameters', 'param')
    # The following section is not covered by the generated test cases
    second_section = ParamSection('Params', 'param')
    third_section = RaisesSection('Raises', 'raises')
    numpydoc_parser_1 = NumpydocParser({first_section.title: first_section, second_section.title: second_section, third_section.title: third_section})

    ret = numpydoc_parser_1.parse('')
    assert ret.short_description == None
    assert ret.long_description == None
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == False
    assert len(ret.meta) == 0
    assert ret.meta == []

    ret = numpydoc_

# Generated at 2022-06-25 16:30:57.839794
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()

    ret_val_1 = numpydoc_parser_1.parse('''
    Examples
    --------
    >>> import numpy as np
    >>> a = np.arange(6).reshape(2,3)
    >>> a
    array([[0, 1, 2],
           [3, 4, 5]])
    >>> np.sum(a)
    15
    >>> np.sum(a, axis=0)
    array([3, 5, 7])
    >>> np.sum(a, axis=1)
    array([ 3, 12])
    ''')
    print(ret_val_1, end = "\n")
    assert isinstance(ret_val_1, Docstring)


# Generated at 2022-06-25 16:31:03.599182
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = """My function.

:param arg1: the first argument.
:type arg1: str
:returns: description of return value
:rtype: int
"""

# Generated at 2022-06-25 16:31:16.312701
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print("Testing NumpydocParser.parse")
    f = open("docstrings.txt", "r")
    for line in f:
        if line[0] == '#':
            continue
        line_segments = line.split(", ")
        text = line_segments[0]
        short_desc = line_segments[1]
        long_desc = line_segments[2]
        para_0 = line_segments[3]
        para_1 = line_segments[4]
        para_2 = line_segments[5]
        raises_0 = line_segments[6]
        raises_1 = line_segments[7]
        returns_0 = line_segments[8]
        returns_1 = line_segments[9]
        see_also_0 = line_

# Generated at 2022-06-25 16:31:25.977069
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:31:33.607945
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Examples for numpydoc-style docstring format.
    """

# Generated at 2022-06-25 16:31:39.905627
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "_"
    Docstring_0 = numpydoc_parser_0.parse(text_0)
    assert Docstring_0 is not None


# Generated at 2022-06-25 16:31:46.590940
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse('')
    assert docstring_0.short_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []

# Generated at 2022-06-25 16:31:52.942726
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = ("This is a one-line docstring."
            "This is the second line of the docstring.")
    assert NumpydocParser().parse(text).short_description == "This is a one-line docstring."
    assert NumpydocParser().parse(text).long_description == "This is the second line of the docstring."


# Generated at 2022-06-25 16:32:04.864470
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    func_0 = lambda: None
    text_0 = inspect.getdoc(func_0)
    docstring = numpydoc_parser_0.parse(text_0)
    if (docstring.short_description != "An undocumented function."):
        return False
    if (not docstring.blank_after_short_description):
        return False
    if (docstring.long_description != ("This function does nothing. It just sits there.\n\nSitting there.\n\nIt does not change."
    )):
        return False
    if (not docstring.blank_after_long_description):
        return False

# Generated at 2022-06-25 16:32:13.615553
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "\n        Return the value of the named attribute of object. name must be a string.\n        If the string is the name of one of the object's attributes, the result is the\n        value of that attribute. For example, getattr(x, 'foobar') is equivalent to x.foobar.\n        If the named attribute does not exist, default is returned if provided,\n        otherwise AttributeError is raised.\n      "

# Generated at 2022-06-25 16:32:25.833870
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Test :meth:``NumpydocParser.parse``."""

    def sample_docstr(
        short_desc: T.Optional[str] = None,
        long_desc: T.Optional[str] = None,
        b1: bool = False,
        b2: bool = False,
        meta: T.List[DocstringMeta] = None,
    ) -> Docstring:
        """Create a sample docstring.

        :param short_desc: docstring short description
        :param long_desc: docstring long description
        :param b1: blank after short description?
        :param b2: blank after long description?
        :param meta: docstring meta
        """

# Generated at 2022-06-25 16:32:29.560760
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser
    numpydoc_parser_0.parse(text)


# Generated at 2022-06-25 16:32:37.946806
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    ds_0 = numpydoc_parser_0.parse("long\nSomethings\n\n   Parameters\n   ----------\n\n   Returns\n   -------\n\n")
    ds_1 = numpydoc_parser_0.parse("long\nSomethings\n\n   Parameters\n   ----------\n\n   Returns\n   -------\n\n")
    ds_2 = numpydoc_parser_0.parse("long\nSomethings\n\n   Parameters\n   ----------\n\n   Returns\n   -------\n\n")
    assert (ds_1 == ds_2)
    assert (ds_0 != ds_2)

# Generated at 2022-06-25 16:32:44.923720
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    res = parse(
        """
This is a short description.


This is a long description. It can span multiple lines,
but the first line must be blank and the last line,
while optional, must be empty.
This is the first para of the long description.

This is the second para of the long description.

This is the third para of the long description.

"""
    )
    assert res.short_description == "This is a short description."
    assert res.long_description == "This is a long description. It can span multiple lines,\nbut the first line must be blank and the last line,\nwhile optional, must be empty.\nThis is the first para of the long description.\n\nThis is the second para of the long description.\n\nThis is the third para of the long description."
    assert res.blank_

# Generated at 2022-06-25 16:32:56.562153
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:33:10.883772
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.add_section(Section("New section", "new"))
    numpydoc_parser_0.add_section(RaisesSection("Errors", "error"))