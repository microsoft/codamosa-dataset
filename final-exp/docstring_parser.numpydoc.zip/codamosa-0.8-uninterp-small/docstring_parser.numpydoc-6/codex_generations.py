

# Generated at 2022-06-25 16:24:04.691011
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Setup fixture
    numpydoc_parser_1 = NumpydocParser()
    name = 'deprecation'
    key = 'key'
    # Exercise SUT
    numpydoc_parser_1.add_section(
        DeprecationSection(
            name,
            key
        )
    )
    output = numpydoc_parser_1.parse(
        """
        .. deprecated:: 0.2.0
           Removed in version 0.4. Use :mod:`some_other_module` instead.
        """
    )
    # Verify results

# Generated at 2022-06-25 16:24:14.364477
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    dir = os.path.dirname(os.path.abspath(__file__))
    examples_dir = os.path.join(dir, 'test_data', 'case_0')
    expect_dir = os.path.join(dir, 'test_data', 'case_0')
    files = os.listdir(examples_dir)
    for file in files:
        with open(os.path.join(examples_dir, file)) as f:
            comments = f.read()
        with open(os.path.join(expect_dir, file)) as f:
            expect_docstring = f.read()

        numpydoc_parser_0 = NumpydocParser()
        docstring = numpydoc_parser_0.parse(comments)

# Generated at 2022-06-25 16:24:25.141079
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    expected_1_docstring_meta = [
        DocstringMeta([
            "param",
            "arg_1"
        ], description = "arg_1_description\n"),
        DocstringMeta([
            "param",
            "arg_2"
        ], description = "arg_2_description", type_name = "type_2", is_optional = True)
    ]
    expected_1_docstring = Docstring(
        short_description = "This is the short description",
        blank_after_short_description = True,
        long_description = "long_description part 1\nlong_description part 2\n",
        blank_after_long_description = True,
        meta = expected_1_docstring_meta
    )
    numpydoc_parser_0_with_default_sections = NumpydocParser

# Generated at 2022-06-25 16:24:38.291030
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    parser = NumpydocParser()
    assert parser.parse("") == Docstring()
    assert parser.parse("\n") == Docstring(
        short_description="",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parser.parse(None) == Docstring()

    doc_0 = parser.parse(
        """
This is a docstring
for a function.

Multi-line, yay!

Parameters
----------
param1 : int
    The first param.
param2 : float, optional
    The second param.

Returns
-------
str
    The return value.
"""
    )

# Generated at 2022-06-25 16:24:44.997265
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    This is a test case for the NumpydocParser.parse() method.
    This method parses the numpy-style docstring into its components.
    """
    # Test case 0
    text_0 = """
        This is a test case for the NumpydocParser.parse() method.
        This method parses the numpy-style docstring into its components.
    """

    numpydoc_parser_0 = NumpydocParser()
    assert(numpydoc_parser_0.parse(text=text_0).short_description == "This is a test case for the NumpydocParser.parse() method.")
    assert(numpydoc_parser_0.parse(text=text_0).long_description == "This method parses the numpy-style docstring into its components.")

# Generated at 2022-06-25 16:24:47.808440
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test Case 0:
    expected_return = []
    actual_return = NumpydocParser().parse(None)
    assert actual_return == expected_return


# Generated at 2022-06-25 16:25:00.497057
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    nd_parser_0 = NumpydocParser()

    # cleanup

    test_str_0 = """
    This function does something.

    It takes a really long time, like, a really really long time.

    It takes so long that it is not worth calling.

    Parameters
    ----------
    param1 : int
        This is param1.
        It is an int.

    Returns
    -------
    int
        The sum of param1 and ``1``.

    Examples
    --------
    >>> import numpy as np
    >>> import numpydoc as npd
    >>> npd.test_formatter.test_case_0()
    >>> # doctest: +ELLIPSIS
    "Successfully ran test_case_0..."
    """

    # run unit test


# Generated at 2022-06-25 16:25:05.397513
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # fixture
    numpydoc_0 = NumpydocParser()
    # exercise
    numpydoc_0.parse("Deprecated since version v0.1")


# Generated at 2022-06-25 16:25:11.371941
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_1 = NumpydocParser()
    text = """Example warning text."""
    list_to_compare = [DocstringDeprecated(args=['deprecation'], description="Example warning text.", version=None)]
    assert numpydoc_parser_1.parse(text).meta == list_to_compare


# Generated at 2022-06-25 16:25:20.113375
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:25:35.554144
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = \
"""This function does nothing.

Parameters
----------
foo : int
    A parameter named ``foo``.
bar
    A parameter named ``bar``.

Returns
-------
baz
    A return value named ``baz``.

Raises
------
ValueError
    If ``bar`` is ``None``.
"""

    parsed = parse(docstring)

    assert parsed.short_description == "This function does nothing."
    assert parsed.long_description == ""
    assert parsed.blank_after_short_description
    assert not parsed.blank_after_long_description

    assert len(parsed.meta) == 5
    assert parsed.meta[0].args == ["param", "foo"]
    assert parsed.meta[0].description == "A parameter named ``foo``."

# Generated at 2022-06-25 16:25:43.364078
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring_0 = 'short\nl\nl\n\nl'
    docstring_1 = 'short\nl\nl\n\nl'
    docstring_2 = """\
        foo.bar(arg_foo, arg_bar='default')

        This is a docstring.

        Parameters
        ----------
        arg_foo : int
            A required argument.
        arg_bar : str
            An optional argument. Default is 'default'.
        Returns
        -------
        str
            The output string.
        """
    docstring_3 = """
        Parameters
        ----------
        message : str
            A message to be printed.
        times : int
            Number of times to print the message.
        """

# Generated at 2022-06-25 16:25:52.286275
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """\
This is a description.

Raises
    ValueError
        if something is wrong
    KeyError
        if something else is wrong

    Returns
    -------
    object
        A thing
    None
        Nothing
"""
    docstring = NumpydocParser().parse(text)

    assert docstring.short_description == "This is a description."
    assert docstring.long_description == ""
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is True

# Generated at 2022-06-25 16:26:04.923161
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_0 = """.. math::

    foo
    """
    text_1 = """Returns an array of shape (M,) containing the tangent 
    of ``x``"""
    text_2 = """Arguments:
    ---------
    x : array_like
        Values to compute tan for, in radians.
    """
    # expected output

# Generated at 2022-06-25 16:26:15.873202
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print("\n\n>>> Test of NumpydocParser().parse")
    numpydoc_parser_1 = NumpydocParser()
    text_1 = '\n'.join([
        "text_1",
        "----",
        "",
        "This line should be in the long description.",
        "",
        "This line should also be in the long description.",
        "",
    ])
    docstring_1 = numpydoc_parser_1.parse(text_1)
    print(docstring_1)

# Generated at 2022-06-25 16:26:27.997322
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    assert numpydoc_parser_0.parse(""""
    Args:
    arg: str
        a string argument
    """
) == Docstring(
    short_description=None,
    long_description=None,
    blank_after_short_description=False,
    blank_after_long_description=False,
    meta=[
        DocstringParam(
            args=['param', 'arg'],
            description='a string argument',
            arg_name='arg',
            type_name='str',
            is_optional=False,
            default=None,
        )
    ],
)


# Generated at 2022-06-25 16:26:37.731802
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text='Returns\n    :return: A string generated from applying a transform.\n    :rtype: str\n    '
    assert numpydoc_parser_0.parse(text)==Docstring(short_description=None, long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[DocstringReturns(args=['returns'], description='A string generated from applying a transform.', type_name=None, is_generator=False, return_name=None)])
    

# Generated at 2022-06-25 16:26:41.045982
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = "Return x rounded."
    numpydoc_parser_0.parse(text)
    print("Passed test of method parse")


test_NumpydocParser_parse()

# Generated at 2022-06-25 16:26:51.932485
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = ""
    assert numpydoc_parser_0.parse(text_0) == Docstring()
    text_1 = "this is a docstring"
    assert numpydoc_parser_0.parse(text_1) == Docstring(
        short_description="this is a docstring"
    )
    text_2 = "this is a docstring\n\nthis is the long description"
    assert numpydoc_parser_0.parse(text_2) == Docstring(
        short_description="this is a docstring",
        long_description="this is the long description",
        blank_after_short_description=True,
    )

# Generated at 2022-06-25 16:27:06.838074
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Test the parse method of class NumpydocParser."""

    # Set up test docstring.
    doc_str = """
        Summary line.

        Extended description.

        Parameters
        ----------
        arg1 : int
            Description of arg1.
        arg2 : str
            Description of arg2.

        Raises
        ------
        ValueError
            If something wrong happens.
        TypeError
            If something else is wrong.

        Returns
        -------
        int
            Description of return value.
        """

    # Parse the docstring.
    parsed_doc_str = parse(doc_str)

    # Test short_description.
    assert parsed_doc_str.short_description == "Summary line."

    # Test blank_after_short_description.
    assert parsed_doc_str.blank_after_short_description

# Generated at 2022-06-25 16:27:12.846687
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_4 = NumpydocParser()
    text_4 = "method_name"
    docstring_4 = numpydoc_parser_4.parse(text_4)
    return docstring_4


# Generated at 2022-06-25 16:27:15.123188
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = ""
    ret = NumpydocParser().parse(text)
    assert isinstance(ret, Docstring)



# Generated at 2022-06-25 16:27:17.214886
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = ""
    parse = numpydoc_parser_0.parse(text)
    assert parse == None


# Generated at 2022-06-25 16:27:29.155507
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test parse of NumpydocParser 
    """
    numpydoc_parser = NumpydocParser()
    docstring = Docstring()
    assert numpydoc_parser.parse("") == docstring
    
    docstring.short_description = "A simple function"
    assert numpydoc_parser.parse("A simple function") == docstring

    docstring.long_description = "More details."
    assert numpydoc_parser.parse(
        "A simple function\nMore details."
    ) == docstring
    assert numpydoc_parser.parse(
        "A simple function\n\nMore details."
    ) == docstring
    assert numpydoc_parser.parse(
        "A simple function\n\nMore details.\n\n"
    ) == docstring

# Generated at 2022-06-25 16:27:41.335572
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc_string_1 = """A docstring.

Args:
    arg_1: The first argument.
"""
    doc_string_2 = """A docstring.

Parameters
----------
    arg_1 : str
        The first argument.
"""
    doc_string_3 = """A docstring.

Args:
    arg_1: The first argument.
    arg_2: The second argument.
    arg_3:
        The third argument.
"""  # noqa: E501
    doc_string_4 = """A docstring.

Args:
    arg_1: The first argument.
    arg_2: The second argument.
    arg_3:
        The third argument.

Args:
    arg_4: The fourth argument.
"""  # noqa: E501

# Generated at 2022-06-25 16:27:52.943909
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # test_NumpydocParser_parse
    numpydoc_parser_0 = NumpydocParser()
    text_0 = ""
    docstring_0 = numpydoc_parser_0.parse(text_0)
    text_1 = " "
    docstring_1 = numpydoc_parser_0.parse(text_1)
    text_2 = "short description"
    docstring_2 = numpydoc_parser_0.parse(text_2)
    text_3 = "  short description  "
    docstring_3 = numpydoc_parser_0.parse(text_3)
    text_4 = "short description\n\nlong description\n"
    docstring_4 = numpydoc_parser_0.parse(text_4)

# Generated at 2022-06-25 16:27:55.881415
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Arrange
    numpydoc_parser_0 = NumpydocParser()
    text = ""
    # Act
    docstring = numpydoc_parser_0.parse(text)
    # Assert
    assert len(docstring.meta) == 0


# Generated at 2022-06-25 16:28:08.230890
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    parser = NumpydocParser()
    input = ""
    expected = Docstring()


    assert expected == parser.parse(input)

    input = \
    """
    Do something.

    Parameters
    ----------
    a: int
       A parameter

    Note
    ----
    More detailed
    """
    expected = Docstring(
        short_description='Do something.',
        long_description='More detailed',
        meta=[
            DocstringParam(
                args=['param', 'a'],
                type_name='int',
                description='A parameter'
            ),
            DocstringMeta(
                args=['notes'],
                description='More detailed'
            )
        ],
        blank_after_short_description=False,
        blank_after_long_description=False
    )

    assert expected == parser

# Generated at 2022-06-25 16:28:17.575947
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    NumpydocParser_parse_0 = NumpydocParser()
    NumpydocParser_parse_0.parse("""
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    """)

# Generated at 2022-06-25 16:28:19.701363
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert numpydoc_parser_0.parse("") == ""

# Generated at 2022-06-25 16:28:27.341397
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """This is a short description

    This is a longer description. It can span multiple paragraphs.

    Parameters
    ----------
    a_param : type
        description of ``a_param``
    another_param :
        description without a name, but with a type
    """
    docstring = text
    numpydoc_parser_1 = NumpydocParser()
    result = numpydoc_parser_1.parse(docstring)
    assert result == """ """

# Generated at 2022-06-25 16:28:39.465062
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser=NumpydocParser()
    docstring= numpydoc_parser.parse("""

        This is a simple test.
        \n


        Parameters
        ----------
        test:str
            This is a test.

        Returns
        -------
        The parsed docstring.
        None if no docstring.

        """
    )
    assert docstring.short_description == "This is a simple test."
    assert docstring.meta[0].description == "This is a test."
    assert docstring.meta[1].description == "The parsed docstring.\nNone if no docstring."
    assert docstring.meta[1].type_name == "None"
    assert docstring.meta[0].type_name =="str"

# Generated at 2022-06-25 16:28:49.499623
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = ""
    result_0 = numpydoc_parser_0.parse(text_0)
    assert result_0.short_description is None
    assert result_0.long_description is None
    assert result_0.blank_after_short_description is True
    assert result_0.blank_after_long_description is True
    assert result_0.meta == []

    assert result_0.deprecations == []
    assert result_0.params == []
    assert result_0.other_params == []
    assert result_0.attributes == []
    assert result_0.returns == []
    assert result_0.yields == []
    assert result_0.raises == []

# Generated at 2022-06-25 16:28:57.987878
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    docstring = '''
    """
    Parameters
    ----------
    x : str, optional
        A string. The default is "foo".

    Returns
    -------
    list
        Not a very exciting return value.
    """
    '''
# call the function
    numpydoc_parser_0 = NumpydocParser()
    actual = numpydoc_parser_0.parse(docstring)
# expected
    expected = ['"foo"']
    assert actual == expected


# Generated at 2022-06-25 16:29:09.005491
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = ''
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []
    text_1 = '    This is a docstring.  '
    docstring_1 = numpydoc_parser_0.parse(text_1)
    assert docstring_1.short_description == 'This is a docstring.'
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short

# Generated at 2022-06-25 16:29:20.570030
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    numpydoc_parser_1 = NumpydocParser()
    
    # Empty docstring
    result = numpydoc_parser_1.parse("")
    assert result.short_description == None
    assert result.long_description == None
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == True
    assert len(result.meta) == 0

    # No meta sections
    result = numpydoc_parser_1.parse("Short description")
    assert result.short_description == "Short description"
    assert result.long_description == None
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == True
    assert len(result.meta) == 0

    result = numpydoc_parser_1.parse

# Generated at 2022-06-25 16:29:22.822264
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Set up for the test case
    text = None

    # Invoke method under test
    ret = NumpydocParser.parse(text)

    # Check the response
    assert ret is not None


# Generated at 2022-06-25 16:29:33.018298
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = """ Single-line description.

            More detailed multi-line description. This can even go on
            over multiple paragraphs.

            Author:
                Adam Smith <adam@example.com>

            Args:
                this_thing (int): A description of ``this_thing``.
                    It can also span multiple lines.
                other (float, optional): This is ``other``. Defaults to 1.0.

            Returns:
                int: This will be the return type.

            Raises:
                ValueError: A description of what might raise ValueError.
                WhateverError: Some unknown error.

            Warns:
                UserWarning: This will warn the user.

            Examples:
                >>> # An example of how to use this.
                >>> import this

                >>> this_thing
                1
    """

    numpydoc_parser_0

# Generated at 2022-06-25 16:29:44.967550
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc_str_simple = """
    this is a doc string
      over multiple lines
    """
    doc_str_simple_parsed = parse(doc_str_simple)

    doc_str_compound = """
    this is a doc string
      over multiple lines

    Parameters
    ----------
    this is a parameter

    Examples
    --------

    this is an example

    Warnings
    --------

    this is a warning
    """

    doc_str_compound_parsed = parse(doc_str_compound)

    doc_str_no_desc = """
    Notes
    -----
    notes here
    """

    doc_str_no_desc_parsed = parse(doc_str_no_desc)

# Generated at 2022-06-25 16:29:58.214942
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()

    # Test case 0
    #
    #   Simple function with no parameters or return values
    #   ds = NumpydocParser().parse(text)
    #   assert ds == Docstring(
    #       short_description="None",
    #       blank_after_short_description=False,
    #       long_description="None",
    #       blank_after_long_description=False,
    #       meta=[],
    # )
    #
    #    Returns:
    #        Docstring: A parsed numpy-style docstring
    #
    #    Examples:
    #        >>> ds = NumpydocParser().parse('A function with no parameters or return values')
    #        >>> assert ds == Docstring(
    #            short

# Generated at 2022-06-25 16:30:13.938348
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test parse()
    numpydoc_parser = NumpydocParser()
    docstring = """This will be the short description.

And this will be the long docstring, that can span multiple lines.
This usually contains a more detailed explanation of the object
being documented, which can contain other subsections.

The docstring can go all the way to the bottom of the code file.

Parameters
----------
arg1 : str
    Description of `arg1`.
arg2 : bool
    Description of `arg2`, with a default value.
    Default is `"default"`.
arg3 : dict
    Description of `arg3`, that spans multiple lines.
    Default is `{'key': 'value'}`.

Returns
-------
int
    Description of `return`.
"""

# Generated at 2022-06-25 16:30:22.798949
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = "This is my docstring\n"
    docstring = numpydoc_parser_0.parse(text)
    assert docstring.short_description == 'This is my docstring'
    assert docstring.meta == []
    assert docstring.long_description is None
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description


# Generated at 2022-06-25 16:30:33.184880
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert parse(text=None) == Docstring()
    assert parse(text="") == Docstring()
    text = "First line.\n\nSecond line."
    meta = DocstringMeta(args=[], description="First line.")
    short_desc = "First line."
    long_desc = "Second line."
    blank_after_short = True
    blank_after_long = False
    assert parse(text=text) == Docstring(
        short_description=short_desc,
        long_description=long_desc,
        blank_after_short_description=blank_after_short,
        blank_after_long_description=blank_after_long,
        meta=[meta],
    )
    text = "First line.\n\nSecond line.\n\n"

# Generated at 2022-06-25 16:30:44.166635
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # zzzzzz = 1
    # print ("\n===NumpydocParser_parse_test0:")
    # print ("\n  zzzzzz = ", zzzzzz)

    docstring = """
        Short description here
        docstrings can span

        multiple lines

        Parameters
        ----------
        parameter_name
            parameter_description

        parameter_2 : type
            descriptions can also span
            multiple lines


        Returns
        -------
        return_name : type
            A description of this returned value
        another_type
            Return names are optional

        Raises
        ------
        ValueError
            A description of what might raise ValueError
    """
    docstring = inspect.cleandoc(docstring)
    docstring = parse(docstring)

    # print ("\n  docstring = ", docstring)



# Generated at 2022-06-25 16:30:54.337499
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "testcase_0"
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description == 'testcase_0'
    assert docstring_0.long_description == None
    assert docstring_0.meta == []
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False


# Generated at 2022-06-25 16:30:56.851870
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    assert isinstance(numpydoc_parser.parse(''), Docstring)


# Generated at 2022-06-25 16:31:03.067687
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Init
    test_0_expected_output = Docstring(
        short_description="DocstringMeta",
        long_description="",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(args=["param"], description="parameters used to serialize"),
            DocstringParam(args=["param", "parameters"], description="", arg_name="parameters", type_name="", is_optional=None, default=None),
            DocstringMeta(args=["returns"], description="a DocstringMeta instance"),
            DocstringReturns(args=["returns"], description="", type_name="", is_generator=False, return_name=None)
        ]
    )
    # Call function

# Generated at 2022-06-25 16:31:15.565087
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # Test case 0
    # (no docstring)
    docstring_0 = numpydoc_parser_0.parse("")
    assert(docstring_0.short_description == None)
    assert(docstring_0.long_description == None)
    assert(docstring_0.blank_after_short_description == False)
    assert(docstring_0.blank_after_long_description == False)
    assert(docstring_0.meta == [])

    # Test case 1
    # (no blank line)
    docstring_1 = numpydoc_parser_0.parse("a string")
    assert(docstring_1.short_description == "a string")
    assert(docstring_1.long_description == None)
   

# Generated at 2022-06-25 16:31:25.665244
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:31:35.455144
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:31:43.539673
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser().parse("") == Docstring()


# Generated at 2022-06-25 16:31:55.595582
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    result_0 = numpydoc_parser_0.parse("\n    This is a  brief description.\n    This is the long description.")
    assert result_0.short_description == "This is a brief description."
    assert result_0.long_description == "This is the long description."
    assert result_0.blank_after_short_description == True
    assert result_0.blank_after_long_description == False
    assert result_0.meta == []
    numpydoc_parser_1 = NumpydocParser()
    result_1 = numpydoc_parser_1.parse("\n    short description.\n\n    long description.")
    assert result_1.short_description == "short description."
    assert result_1

# Generated at 2022-06-25 16:32:08.357237
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # PEP 257 style docstring
    # https://www.python.org/dev/peps/pep-0257/
    # https://www.python.org/dev/peps/pep-0008/#docstring-conventions

# Generated at 2022-06-25 16:32:15.428504
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "    I am a test case.\n    I have two lines.\n\n    I contain a blank line after the description.\n\n\n    I also have a blank line after that.\n"
    docstring_0 = numpydoc_parser_0.parse(text_0)
    print(docstring_0.short_description)
    print(docstring_0.long_description)
    print(docstring_0.blank_after_short_description)
    print(docstring_0.blank_after_long_description)
    print(docstring_0.meta)


# Generated at 2022-06-25 16:32:23.030951
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc_string_0 = '"""\n    test_function(arg_1, arg_2)\n    '
    doc_string_1 = '\n    test_function(arg_1, arg_2)\n\n    '
    doc_string_2 = '\n    test_function(arg_1, arg_2)\n\n\n    '
    doc_string_3 = '\n\n    test_function(arg_1, arg_2)\n\n    '
    doc_string_4 = '\n///\n    test_function(arg_1, arg_2)\n\n    '
    doc_string_5 = '\n///\n    test_function(arg_1, arg_2)\n\n\n    '

# Generated at 2022-06-25 16:32:25.110087
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-25 16:32:34.854403
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # TODO: fix the regex, not sure why it isn't catching the first section
    # pattern = re.compile(r"^(Parameters|Params|Arguments)(?=\n--)", flags=re.M)

    test_case_0_arg_0 = """description

Parameters
----------
arg1 : type
    this is a description of arg1
arg2 : type
    this is a description of arg2

Returns
-------
return_1 : type
    this is a description of return_1

Other Parameters
----------------
kwarg_1 : type
    this is a description of kwarg_1
kwarg_2 : type
    this is a description of kwarg_2
"""
    test_case_0_ret_0 = test_case_0_arg_0
    test_case_0_ret_1

# Generated at 2022-06-25 16:32:42.990072
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Test for method parse of class NumpydocParser"""
    numpydoc_parser_1 = NumpydocParser()
    text_1 = None
    assert numpydoc_parser_1.parse(text_1) == None

    # Test with default sections
    numpydoc_parser_2 = NumpydocParser()

# Generated at 2022-06-25 16:32:47.331838
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_instance_0 = numpydoc_parser_0.parse("Parse numpy-style docstring\n\n")
    assert docstring_instance_0.short_description == "Parse numpy-style docstring"
    assert docstring_instance_0.blank_after_short_description == False
    assert docstring_instance_0.blank_after_long_description == True
    assert docstring_instance_0.long_description == None
    assert len(docstring_instance_0.meta) == 0


# Generated at 2022-06-25 16:32:58.212417
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()