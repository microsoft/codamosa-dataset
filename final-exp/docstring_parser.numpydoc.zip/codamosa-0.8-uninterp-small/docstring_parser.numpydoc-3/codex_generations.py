

# Generated at 2022-06-25 16:24:14.293138
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    docstring_0 = numpydoc_parser.parse('Docstring')
    assert docstring_0.short_description == 'Docstring'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []

    docstring_0 = numpydoc_parser.parse('A docstring.\n\n')
    assert docstring_0.short_description == 'A docstring.'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False

# Generated at 2022-06-25 16:24:25.140087
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text="""
        This is a description.
        It is across multiple lines!

        Parameters
        ----------
        arg: int
            This is an argument.

        arg2: str, optional
            This is another argument.

        Returns
        -------
        str:
            This is a return value.

        Raises
        ------
        ValueError
            If something goes wrong.
    """

    docstring = numpydoc_parser_0.parse(text)
    assert_equals(docstring.short_description, "This is a description.")
    assert_equals(docstring.long_description, "It is across multiple lines!")
    assert_equals(docstring.blank_after_short_description, True)
    assert_equals(docstring.blank_after_long_description, True)


# Generated at 2022-06-25 16:24:32.893702
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # Test argument: text = '  \nThis is a test.\n    '
    text = '  \nThis is a test.\n    '
    # Call method
    actual = numpydoc_parser_0.parse(text)
    # Check results
    expected = Docstring(
        short_description='This is a test.',
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )
    assert actual == expected, 'Expected: ' + str(expected) + ', but got: ' + str(actual)

# Generated at 2022-06-25 16:24:41.611141
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:24:51.993513
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring = inspect.cleandoc("""
        Single paragraph description
        extended over multiple lines.
        Parameters
        ----------
        param : int
            A required parameter.
        optional : str, optional
            An optional parameter.
        other_param : ~typing.Union[str, int]
            Another parameter.
        Returns
        -------
        value : float
            A float value.
        Examples
        --------
        >>> print(value)
        42
        >>> print(other_param)
        'hello'
        Warnings
        --------
        This should be *taken seriously*!
        """
)
    numpydoc_parser_0.parse(docstring)



# Generated at 2022-06-25 16:25:02.933428
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 0
    numpydoc_parser_0 = NumpydocParser()

    doc_str = '''
        This is a short description.

        This is a long description.

        Parameters
        ==========
        name : type
            This is a description
        name2 : type2
            This is another description
            that spans multiple lines

        Returns
        =======
        ret_name : type3
            This is a description of the return value
        '''

# Generated at 2022-06-25 16:25:09.446953
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = 'The function to fit the data.\n\nParameters\n----------\n'
    docstring_0 = numpydoc_parser_0.parse(text)
    assert docstring_0.short_description == 'The function to fit the data.'
    assert docstring_0.long_description == ''
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True

# Generated at 2022-06-25 16:25:18.856992
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Arrange
    text = '''
    Short description

    Long description

    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.
    param3 : list of ints
        The third parameter.

    Returns
    -------
    str
        The return value.
    '''


# Generated at 2022-06-25 16:25:30.339698
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    text = """A first line of the docstring.

    A second line of the docstring.
    """
    parser = NumpydocParser()
    doc = parser.parse(text)
    assert doc.__dict__ == {'short_description': 'A first line of the docstring.', 'blank_after_short_description': True, 'long_description': 'A second line of the docstring.', 'blank_after_long_description': True, 'meta': []}

    text = """A first line of the docstring.
    A second line of the docstring.
    """
    parser = NumpydocParser()
    doc = parser.parse(text)

# Generated at 2022-06-25 16:25:32.423675
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    numpydoc_parser_0 = NumpydocParser()
    # str -> Docstring
    numpydoc_parser_0.parse(text='')



# Generated at 2022-06-25 16:25:48.865190
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert inspect.isclass(NumpydocParser)
    assert NumpydocParser.parse.__module__ == __name__
    assert NumpydocParser.__module__ == __name__
    assert parse.__module__ == __name__
    assert isinstance(NumpydocParser.parse, staticmethod)
    assert callable(parse)

    docstring = """
    This is a short description.

    This is a long description.
    It is quite long.

    Parameters
    ----------
    arg : type, optional
        Description of ``arg``

    Other Parameters
    ----------------
    kwarg : type, optional
        Description of ``kwarg``
    """

# Generated at 2022-06-25 16:26:02.748267
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test Case 0
    text_0 = ""
    NumpydocParser_parse_0 = numpydoc_parser_0.parse(text_0)
    assert NumpydocParser_parse_0.short_description is None
    assert NumpydocParser_parse_0.long_description is None
    assert NumpydocParser_parse_0.blank_after_short_description is False
    assert NumpydocParser_parse_0.blank_after_long_description is False
    assert NumpydocParser_parse_0.meta == []
    # Test Case 1
    text_1 = ""
    NumpydocParser_parse_1 = numpydoc_parser_0.parse(text_1)
    assert NumpydocParser_parse_1.short_description is None
    assert Numpyd

# Generated at 2022-06-25 16:26:14.478522
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = ""
    n = parse(text)
    if (n.short_description != None):
        print("Failed: NumpydocParser:test_case_0")
    else: print("Passed: NumpydocParser:test_case_0")
    if (n.blank_after_short_description != False):
        print("Failed: NumpydocParser:test_case_1")
    else: print("Passed: NumpydocParser:test_case_1")
    if (n.blank_after_long_description != False):
        print("Failed: NumpydocParser:test_case_2")
    else: print("Passed: NumpydocParser:test_case_2")

# Generated at 2022-06-25 16:26:27.413559
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # Example of a parameter docstring
    text_0 = (
        "Parameter values\n"
        "----------------\n"
        "values : array-like of shape (n_features,)\n"
        "    Values of the features\n"
        "example : array-like of shape (n_samples, n_features)\n"
        "    Training vector, where n_samples is the number of samples and\n"
        "    n_features is the number of features.\n"
        "X_new : array-like of shape (1, n_features)\n"
        "    Test sample features.\n"
    )
    doc_0 = numpydoc_parser_0.parse(text_0)
    # Example of a return doc

# Generated at 2022-06-25 16:26:30.485476
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:26:42.583145
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """Parse the numpy-style docstring into its components.

:returns: parsed docstring
"""
    ret_0 = numpydoc_parser_0.parse(text=text_0)
    assert ret_0.short_description == "Parse the numpy-style docstring into its components."
    assert ret_0.blank_after_short_description is True
    assert ret_0.blank_after_long_description is False
    assert ret_0.long_description == ":returns: parsed docstring"
    assert ret_0.meta == []

    numpydoc_parser_1 = NumpydocParser()
    text_1 = """Returns:
    parsed docstring
"""
    ret_1 = numpyd

# Generated at 2022-06-25 16:26:53.833301
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    text = ""
# Expected result:
    Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    actual = numpydoc_parser.parse(text)
    assert actual == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-25 16:27:01.746220
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    try:
        docstring = NumpydocParser.parse(
            text="This is an example of missing title line.\n"
            ".. title::"
            "   something"
            "   possibly over multiple lines\n"
            "More text."
        )
        assert docstring == "This is an example of missing title line. More text."
    except:
        assert False, "Could not parse text."

# Generated at 2022-06-25 16:27:09.420617
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Testing invalid calls
    try:
        numpydoc_parser_0 = NumpydocParser()
        numpydoc_parser_0.parse()
        assert False
    except Exception as e:
        assert str(e) == "parse() missing 1 required positional argument: 'text'"

    # Testing invalid calls
    try:
        numpydoc_parser_0 = NumpydocParser()
        numpydoc_parser_0.parse(1)
        assert False
    except Exception as e:
        assert str(e) == "parse() missing 1 required positional argument: 'text'"


# Generated at 2022-06-25 16:27:12.645583
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = 'This is a description. It can span multiple lines.\n\n'
    numpydoc_parser_0.parse(text_0)


# Generated at 2022-06-25 16:27:18.464453
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    docstring_2 = numpydoc_parser_1.parse('\n    Foo\n    ')
    assert(docstring_2.short_description == 'Foo')
    assert(docstring_2.long_description == None)



# Generated at 2022-06-25 16:27:24.303470
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = r"""This is a short description.

    This is a longer description.
    It can be multiple lines.

    Parameters
    ----------
    arg_name: type
        Description of the argument. It can be multiple lines.
        Default is "default".

    Raises
    ------
    TypeError
        Description of what raises a TypeError. It can be multiple lines.

    Warnings
    --------
    This is a warning.
        Warnings can have a description.
        They can also be multiple lines.
    """
    docstring_0 = numpydoc_parser_0.parse(text_0)
    docstring_0.short_description == "This is a short description."

# Generated at 2022-06-25 16:27:37.761868
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:27:51.402314
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstr1 = """
    Open next file in the directory.

    Raises
    ------
    StopIteration
        If there are no more files.

    """
    docstr2 = """
    Open next file in the directory.

    Parameters
    ----------
    path : string, optional
        Directory to read files from

    Raises
    ------
    StopIteration
        If there are no more files.

    """
    docstr3 = """

    Open next file in the directory.

    Parameters
    ----------
    path : string, optional
        Directory to read files from
    other : int, optional
        some other flag


    Raises
    ------
    StopIteration
        If there are no more files.

    """

    # Test case 1
    doc1 = parse(docstr1)

# Generated at 2022-06-25 16:28:01.380837
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:28:12.164875
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # 1
    def fun_with_docstr(a: int, b: float = 2.0) -> T.Optional[float]:
        """Function with docstring.

        Parameters
        ----------
        a : int
            A positional int argument.
        b : float, optional
            A keyword argument with default.

        Returns
        -------
        float
            The return value.

        """
        pass

    docstr = fun_with_docstr.__doc__
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse(docstr)

    docstring_0.short_description == "Function with docstring."
    docstring_0.blank_after_short_description == True
    docstring_0.long_description == None
    docstring_0

# Generated at 2022-06-25 16:28:20.777840
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()


# Generated at 2022-06-25 16:28:27.959177
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.parse("")
    numpydoc_parser_1 = NumpydocParser()
    numpydoc_parser_0.parse("put your test here")

# Generated at 2022-06-25 16:28:40.348353
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:28:48.425421
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Setup
    text = "This is the docstring for Test.\n\nThis is a new sentence.\n\n"

    # Create an object of class NumpydocParser.
    numpydoc_parser = NumpydocParser()

    # Test method parse of class NumpydocParser.
    doc = numpydoc_parser.parse(text)
    assert doc.short_description == "This is the docstring for Test."
    assert doc.long_description == "This is a new sentence."
    assert not doc.blank_after_short_description
    assert doc.blank_after_long_description



# Generated at 2022-06-25 16:28:57.010194
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    given_0 = ""
    expected_0 = Docstring(
        short_description=None,
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )
    actual_0 = parse(given_0)
    assert actual_0 == expected_0


# Generated at 2022-06-25 16:28:59.258224
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    numpydoc_parser_1.parse('')


# Generated at 2022-06-25 16:29:06.602551
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse("TODO")
    assert(type(docstring_0) == Docstring)
    assert(type(docstring_0.short_description) == str)
    assert(len(docstring_0.meta) == 0)


# Generated at 2022-06-25 16:29:18.658174
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 = ''
    docstring_0 = numpydoc_parser_0.parse(str_0)
    docstring_1 = Docstring()
    assert docstring_0 == docstring_1

    numpydoc_parser_1 = NumpydocParser()
    str_1 = """
    str:
        fix

    str_2 : optional

        other fix
    """
    docstring_2 = numpydoc_parser_1.parse(str_1)

# Generated at 2022-06-25 16:29:25.495428
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = """A short description

An even longer description which can span multiple
lines and include ``syntax coloring``.

Parameters
----------
name : str, optional
    A string value with a default.

Returns
-------
ret
    A return value
"""

# Generated at 2022-06-25 16:29:36.214523
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """
    test_NumpydocParser_parse

    this is a test for NumpydocParser.parse

    for argument, see https://www.google.com

    Parameters
    ----------
    text : str
        the string to be parsed
    """
    result = parser.parse(text)
    assert result.short_description == "test_NumpydocParser_parse"
    assert len(result.meta) == 1
    assert result.meta[0].args[0] == 'param'
    assert result.meta[0].args[1] == 'text'
    assert result.meta[0].description == 'the string to be parsed'



# Generated at 2022-06-25 16:29:49.896597
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Test NumpydocParser's parse method."""
    text = """\
        The function's docstring may extend over multiple lines.

        Parameters
        ----------
        param1 : int
            The first parameter.
        param2 : str
            The second parameter.

        Returns
        -------
        str
            The return value.

        Other Parameters
        ----------------
        other_param1 : str
            The other first parameter.
        other_param2 : int
            The other second parameter.

        Raises
        ------
        ValueError
            In case `param2` is equal to `param1`.
        TypeError
            In case param is not str
        """

# Generated at 2022-06-25 16:30:00.319503
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpy_docstring_0 = numpydoc_parser_0.parse(
        'This function returns the sum of the two parameters.\n\nParameters\n----------\narg_1 : int\n    A positive integer.\narg_2 : float\n    A positive float.\narg_3 : float\n\nReturn\n------\nresult : float\n    A float\n'
    )
    assert (
        numpy_docstring_0.long_description
        == 'This function returns the sum of the two parameters.'
    )
    assert (
        numpy_docstring_0.short_description
        == 'This function returns the sum of the two parameters.'
    )
    assert numpy_docstring_0.blank_after

# Generated at 2022-06-25 16:30:03.988817
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    input_str0 = ""
    docstring_0 = numpydoc_parser_0.parse(input_str0)


# Generated at 2022-06-25 16:30:17.559752
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.parse("This could just be an empty string")

    empty_docstring = Docstring()
    assert numpydoc_parser_0.parse("") == empty_docstring

    example_docstring = Docstring()
    example_docstring.short_description = "Models the world in black and white"
    example_docstring.long_description = "The world is not all black and white, but this model is."
    example_docstring.blank_after_short_description = True
    example_docstring.blank_after_long_description = True

    docstring_param_0 = DocstringParam()
    docstring_param_0.args = ['param', 'black']

# Generated at 2022-06-25 16:30:26.366768
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # arrange
    numpydoc_parser = NumpydocParser()
    text = None
    expected = {}

    # act
    actual = numpydoc_parser.parse(text)

    # assert
    assert isinstance(actual, Docstring)
    assert actual.short_description == expected.get("short_description")
    assert actual.long_description == expected.get("long_description")
    assert actual.blank_after_short_description == expected.get("blank_after_short_description")
    assert actual.blank_after_long_description == expected.get("blank_after_long_description")


# Generated at 2022-06-25 16:30:29.089126
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_str = "str"
    assert isinstance(NumpydocParser().parse(test_str), Docstring)


# Generated at 2022-06-25 16:30:32.879357
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = "This is a string to be parsed"
    obj = NumpydocParser()
    res = obj.parse(text)
    exp = "This is a string to be parsed"
    assert res.short_description == exp

test_case_0()
test_NumpydocParser_parse()

# Generated at 2022-06-25 16:30:44.166663
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    assert numpydoc_parser.parse("") == Docstring()
    assert numpydoc_parser.parse("\n") == Docstring()
    assert numpydoc_parser.parse("\n\n") == Docstring()

    assert numpydoc_parser.parse("A\n") == Docstring(short_description="A")
    assert numpydoc_parser.parse("A\n\n") == Docstring(short_description="A")
    assert numpydoc_parser.parse("A\nB") == Docstring(
        short_description="A",
        long_description="B",
        blank_after_short_description=True,
    )

    assert numpydoc_parser.parse("A\n\nB") == Docstring

# Generated at 2022-06-25 16:30:57.328514
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = ''
    Docstring_1 = numpydoc_parser_0.parse(text_0)
    assert Docstring_1 is not None
    #assert Docstring_1.short_description is None
    #assert Docstring_1.long_description is None
    #assert Docstring_1.blank_after_short_description is None
    #assert Docstring_1.blank_after_long_description is None
    #assert Docstring_1.meta is None
    text_1 = 'This is a test document\nwith two paragraphs.\n\n'
    Docstring_2 = numpydoc_parser_0.parse(text_1)
    assert Docstring_2 is not None
    #assert Docstring_2.short_description is

# Generated at 2022-06-25 16:31:03.015528
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Setup
    text = """Single line description"""
    numpydoc_parser_0 = NumpydocParser()

    # Exercise
    result = numpydoc_parser_0.parse(text)

    # Verify
    assert result.short_description == 'Single line description'
    assert result.long_description is None


# Generated at 2022-06-25 16:31:15.520933
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Set up test case inputs and expected results
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """Foo function.

Args:
    foo (*int*):  The foo.
"""
    expected_results_0 = """<Docstring: short_description: 'Foo function.', long_description: None, blank_after_short_description: True, blank_after_long_description: False, meta: 'param: [param, foo], type_name: int'>"""
    # Perform the unit test
    actual_results_0 = str(numpydoc_parser_0.parse(text_0))
    # Check for and report any errors
    assert actual_results_0 == expected_results_0, 'At least one unit test failed: test_NumpydocParser_parse'
    # Return

# Generated at 2022-06-25 16:31:19.836656
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 = '# Documentation string for module'
    docstring_0 = numpydoc_parser_0.parse(str_0)



# Generated at 2022-06-25 16:31:27.390562
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser().parse("") == Docstring()
    # TODO: add actual tests
    # assert NumpydocParser().parse("Hello, world!") == Docstring(short_description='Hello, world!', long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])
    # assert NumpydocParser().parse("Hello,\nword") == Docstring(short_description='Hello,', long_description='word', blank_after_short_description=True, blank_after_long_description=False, meta=[])
    # assert NumpydocParser().parse("Hello,\nword\n") == Docstring(short_description='Hello,', long_description='word', blank_after_short_description=True, blank_after_long_description=True, meta

# Generated at 2022-06-25 16:31:33.934366
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Tests parse()."""


# Generated at 2022-06-25 16:31:48.731633
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # the first test case
    func_name_0 = inspect.currentframe().f_code.co_name
    numpydoc_parser_0 = NumpydocParser()
    s0 = 'foo(bar)\n\n  Hello, world time.\n\n'
    s1 = numpydoc_parser_0.parse(s0)
    assert isinstance(s1, Docstring)


# Generated at 2022-06-25 16:31:54.824819
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    docstring_1 = numpydoc_parser_1.parse("""
        This is a docstring
        it spans multiple lines

        Parameters
        ----------
        arg1 : type
            arg1 description
        arg2 : type, optional
            arg2 description
        arg3, optional
            arg3 description

        Returns
        -------
        return_name : type
            return_description
    """)
    print(docstring_1.meta)

test_NumpydocParser_parse()

# Generated at 2022-06-25 16:32:05.314744
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # Example 0
    text = """\
    A quick test. Shouldn't break.

    Parameters
    ----------
    this
        A parameter.
    that : str, optional
        Another parameter.

    Returns
    -------
    None
        Nothing

    Raises
    ------
    ValueError
        If something goes wrong.
    """
    expected_0 = Docstring()
    expected_0.short_description = "A quick test. Shouldn't break."
    expected_0.blank_after_short_description = True
    expected_0.blank_after_long_description = True
    expected_0.long_description = None

# Generated at 2022-06-25 16:32:14.172211
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_text = '''
    Computes the logarithm of the probability density/mass function for
    a multivariate normal distribution.

    Parameters
    ----------
    x : (..., ndim) array
        The sampled data points.
    mu : (..., ndim) array
        The mean of the distribution (default is 0).
    sigma : (..., ndim, ndim) array
        The covariance matrix of the distribution (must be symmetric and
        positive definite).
    '''

    expected_short_description = "Computes the logarithm of the probability density/mass function for\na multivariate normal distribution."
    expected_long_description = ""
    expected_blank_after_short_description = True
    expected_blank_after_long_description = False

    d = numpydoc_parser_0.parse

# Generated at 2022-06-25 16:32:26.597105
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
        Summary line.
        Extended description.

        Parameters
        ----------
        arg1 : int
             The first argument.
        arg2 : str
             The second argument.

        Returns
        -------
        int
            Some return value.

        The following raises:
        DeprecationWarning
            This was deprecated in version 0.23. Use `parse_docstring` instead.
    """
    numpydoc_parser_1 = NumpydocParser()
    res = numpydoc_parser_1.parse(docstring)

# Generated at 2022-06-25 16:32:35.974531
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
        Long description.

        Parameters
        ----------
        arg1 : int
            Description for arg1.

        arg2 : str
            Description for arg2.

        Returns
        -------
        arg2
            Description for arg2.

        """

    numpydoc_parser_0 = NumpydocParser()
    docstring = numpydoc_parser_0.parse(text)

    assert docstring.short_description == "Long description."
    assert docstring.meta[0].args == ['arg1', 'param']
    assert docstring.meta[1].args == ['arg2', 'param']
    assert docstring.meta[2].args == ['returns']

# Generated at 2022-06-25 16:32:40.225841
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    s = '''
    Parameters
    ----------
    x : int
        A test parameter.
    '''
    docstring = numpydoc_parser_0.parse(s)
    assert len(docstring.meta) == 1



# Generated at 2022-06-25 16:32:53.094753
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    text_1 = """Test case 1: No short description exists\n\nreturns\n    A Numpydoc test case"""
    expected_1 = Docstring()
    expected_1.short_description = None
    expected_1.long_description = None
    expected_1.blank_after_short_description = False
    expected_1.blank_after_long_description = False
    expected_1.meta = [DocstringMeta(['returns'], description='A Numpydoc test case')]
    
    actual_1 = numpydoc_parser_1.parse(text_1)
    assert actual_1 == expected_1

    numpydoc_parser_2 = NumpydocParser()

# Generated at 2022-06-25 16:32:58.373876
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse('')
    assert docstring_0.to_yaml() == """\
short_description: null
blank_after_short_description: false
long_description: null
blank_after_long_description: true
meta: []
"""


# Generated at 2022-06-25 16:33:10.821251
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    text_1 = "numpy_like_doc(arg, optional_param=None, optional_param=None)\n\nA description.\n\nNow a list of parameters.\n\nParameters\n----------\narg : int\n    The argument.\noptional_param : None\n    An optional parameter.\n\nReturns\n-------\nint\n    The length of the text.\n\n"
    docstring_1 = numpydoc_parser_1.parse(text_1)
    assert docstring_1.short_description == "numpy_like_doc(arg, optional_param=None, optional_param=None)"