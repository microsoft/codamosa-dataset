

# Generated at 2022-06-25 16:23:32.339712
# Unit test for method parse of class Section
def test_Section_parse():
    # 1. Arrange
    str_0 = '4:/'
    k_v_section_0 = _KVSection(str_0,str_0)

    str_1 = 'test'
    text = 'test'
    # 2. Act
    ret = k_v_section_0.parse(text)

    # 3. Assert
    assert isinstance(ret,(list,tuple))


# Generated at 2022-06-25 16:23:42.062302
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case data
    text_0 = """
    Docstring for a class.
    :type a: str
    :param a: length of the string
    :returns: description: description of the return value
    :rtype: str
    """
    text_1 = """
    Docstring for a class.

    :type a: str
    :param a: length of the string
    :returns: description: description of the return value
    :rtype: str
    """
    text_2 = """
    Docstring for a class.

    :type a: str
    :param a: length of the string
    :returns: description: description of the return value
    :rtype: str

    :param c:
    """

# Generated at 2022-06-25 16:23:50.362837
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = ''
    str_1 = '\t'
    str_2 = ' '
    str_3 = '\n'
    str_4 = '4:/'
    str_5 = '4:'
    str_6 = '4'
    str_7 = '4:/4:'
    str_8 = '4:/4:/4'
    str_9 = '4:/4:/4:\n4:/4:/4'
    str_10 = '4:/4:/4:\n4:/4:/4\n\n'
    str_11 = '4:/4:/4:\n4:/4:/4:\n\n\n'
    str_12 = '4:/4:/4:\n4:/4:/4\n\n\n'
    str_13 = '4:/4:/4'
    str_

# Generated at 2022-06-25 16:23:58.852497
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = NumpydocParser()
    docstring = inspect.cleandoc('''.. deprecated:: 1.0
        This is a deprecation warning message.
    ''')
    assert parser.parse(docstring).meta == [
        DocstringDeprecated(
            args=["deprecation"],
            description="This is a deprecation warning message.",
            version="1.0",
        )
    ]

# Generated at 2022-06-25 16:24:05.615195
# Unit test for method parse of class Section
def test_Section_parse():
    str_0 = '4:/'
    k_v_section_0 = _KVSection(str_0, str_0)
    str_1 = '4:/'
    str_2 = '4:/'
    k_v_section_0.parse(str_1)
    k_v_section_0.parse(str_2)


# Generated at 2022-06-25 16:24:12.083614
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    print('\nTesting _KVSection.parse')
    # Inputs
    k_v_section_text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    print('Input:\n', k_v_section_text)
    # Expected output
    expected_output = [
        {'key': 'key', 'value': 'value'},
        {'key': 'key2 : type', 'value': 'values can also span...\n... multiple lines'}
    ]
    print('Expected output:\n', expected_output)

    # Actual output
    actual_output = [i.__dict__ for i in list(_KVSection(None, None).parse(k_v_section_text))]

# Generated at 2022-06-25 16:24:21.824606
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    str_0 = '4:/'
    k_v_section_0 = _KVSection(str_0, str_0)
    text_0 = '+/{'
    str_1 = '+/{'
    str_2 = '+/{'
    str_3 = '+/{'
    str_4 = '+/{'
    str_5 = '+/{'
    str_6 = '+/{'
    str_7 = '+/{'
    str_8 = '+/{'
    str_9 = '+/{'
    str_10 = '+/{'
    str_11 = '+/{'
    str_12 = '+/{'
    str_13 = '+/{'
    str_14 = '+/{'
   

# Generated at 2022-06-25 16:24:33.069099
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # 1: test case when input string is empty
    str_1 = '1:'
    k_v_section_1 = _KVSection(str_1, str_1)
    text_1 = '  '

    # expected parsed object
    meta_1 = DocstringMeta(['1:'])

    # Assertion
    assert next(k_v_section_1.parse(text_1)) == meta_1

    # 2: test case when input string is 'key\nvalue'
    str_2 = '2:'
    k_v_section_2 = _KVSection(str_2, str_2)
    text_2 = 'key\nvalue'

    # expected parsed object
    meta_2 = DocstringMeta(['2:'], description='value')

    # Assertion

# Generated at 2022-06-25 16:24:41.716197
# Unit test for method parse of class Section
def test_Section_parse():
    '''Unit tests for method parse of class Section'''
    #test case #1
    str_0 = '4:/'
    k_v_section_0 = _KVSection(str_0, str_0)
    str_1 = '\n'
    k_v_section_0.parse(str_1)

    #test case #2
    str_2 = 'H'
    k_v_section_1 = _KVSection(str_2, str_2)
    str_3 = 'w6'
    k_v_section_1.parse(str_3)

    #test case #3
    str_4 = '01;'
    k_v_section_2 = _KVSection(str_4, str_4)
    str_5 = 'N\x7f'
   

# Generated at 2022-06-25 16:24:52.046722
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    indent_first_line=False
    single_line=True

# Generated at 2022-06-25 16:25:15.059844
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    note = 'This test case want to check whether there is any exceptions when running parse method of class NumpydocParser.\n' \
        'There is a docstring to test as shown in the below:\n'
    docstring_0 = """
    test_parse_docstring_0
    This is the short description
    This is the long description
    Args:
        arg_1(int):
            This is the first arg
        arg_2(str):
            This is the second arg
        arg_3(float, optional):
            This is the third arg
    Returns:
        str:
            This is the returns
    Raises:
        ValueError:
            Something may raise ValueError
        TypeError:
            Something may raise TypeError
    See Also:
        None
    """
    parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:25:26.091425
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Setup
    text_0 = 'E;,v}9'
    numpydocParser_0 = NumpydocParser()
    # AssertionError: Docstring(short_description=None, long_description=None, meta=[], header='', blank_after_short_description=None, blank_after_long_description=None)
    # AssertionError: No exception raised
    try:
        # Method call to be tested
        numpydocParser_0.parse(text_0)

    # Exception raised
    except Exception as e:
        print(e)
        # Expected
        # Failed: NO exception should be raised

    # Expected not distinct
    # Failed: No exception should be raised



# Generated at 2022-06-25 16:25:36.588019
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    sections = {}
    sections['Parameters'] = ParamSection('Parameters', 'param')
    parser = NumpydocParser(sections)
    text = 'Hello, this is a test string.'
    actual_result = parser.parse(text)
    expected_result = None
    assert(actual_result == expected_result)

    text = """
    Hello, this is a test string.

    Parameters
    ----------
    param_1 : int
        this param is for test.
    param_2 : str
        this param is for test.

    Returns
    -------
    int
        this return is for test.
    """
    actual_result = parser.parse(text) 

# Generated at 2022-06-25 16:25:43.965530
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = '4:/'
    k_v_section_0 = _KVSection(str_0, str_0)
    str_1 = 'syntax error'
    str_2 = '$#!@'
    str_3 = ':'
    str_4 = ' '
    str_5 = '''/6/3-6
/                                                                                                             :'''
    str_6 = '4'
    str_7 = '4'
    str_8 = ''
    str_9 = '4:/'
    str_10 = '4:/'
    str_11 = '''/5/2-2
/                                                                                                             :'''
    str_12 = ''
    str_13 = '5:/'
    str_14 = '5:/'
    str_

# Generated at 2022-06-25 16:25:53.061566
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_obj = NumpydocParser()
    def test_func(text):
        test_obj.parse(text)
    str_0 = '4:/'
    str_1 = '_numpydoc_'
    str_2 = '_numpydoc_'
    str_3 = '%'
    str_4 = '%'
    str_5 = '(jliu118)'
    str_6 = '(jliu118)'
    str_7 = '"'
    str_8 = '"'
    # Test the case that the length of the arg is unequal to the length of the arg

# Generated at 2022-06-25 16:26:05.616664
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print("\n=== Test NumpydocParser.parse() ===")

    # Test case 1
    print("\nTest case 1:")
    input_1 = '4:/'
    output_1 = NumpydocParser().parse(input_1)
    print(f"\tInput:{input_1}\n\tOutput: {output_1}")

    # Test case 2
    print("\nTest case 2:")
    input_2 = """\
    4: A relative path from the workspace root to the file to upload.
    """
    output_2 = NumpydocParser().parse(input_2)
    print(f"\tInput:{input_2}\n\tOutput: {output_2}")

    # Test case 3
    print("\nTest case 3:")

# Generated at 2022-06-25 16:26:13.987598
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Preprocess
    numpydocparser_0 = NumpydocParser()
    str_0 = '4:/'
    numpydocparser_0.add_section(_KVSection(str_0, str_0))
    str_1 = '5:5'
    numpydocparser_0.add_section(_KVSection(str_1, str_1))

    # Parse
    list_0 = ['6', '6']
    # Postprocess
    numpydocparser_0.parse(list_0)


# Generated at 2022-06-25 16:26:16.638989
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 = '4:/'
    docstr_0 = numpydoc_parser_0.parse(str_0)


# Generated at 2022-06-25 16:26:29.112796
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Testing input:
    str_0 = str_1 = str_2 = str_3 = None
    NumpydocParser_0 = NumpydocParser(str_0)  # type: NumpydocParser
    str_4 = str_5 = str_6 = ""
    Docstring_0 = NumpydocParser_0.parse(str_4)  # type: Docstring
    str_7 = str_8 = str_9 = str_10 = ""
    Docstring_1 = NumpydocParser_0.parse(str_7)  # type: Docstring
    str_11 = str_12 = str_13 = str_14 = str_15 = ""
    Docstring_2 = NumpydocParser_0.parse(str_11)  # type: Docstring
    str_16 = str_

# Generated at 2022-06-25 16:26:32.372823
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = '/home/david/.local/lib/python3.6/site-packages/pyparsing/Future.py::Future.__rfloordiv__'

    meta_1 = _KVSection(str_0, str_0)


    d = NumpydocParser()

    d.add_section(meta_1)
    d.parse(str_0)



# Generated at 2022-06-25 16:26:45.325726
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:26:50.095932
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse("\n   .. versionadded:: 0.1.0\n\n\n")


# Generated at 2022-06-25 16:26:54.753158
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_parse = NumpydocParser()
    assert numpydoc_parser_parse.parse("""\
    Method to test parsable docstrings in numpydoc format.
    """)


# Generated at 2022-06-25 16:27:07.156152
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Parameters
    ----------
    something: str
        a str that does something
    something_else: int
        an int that does something else

    Returns
    -------
    a: str
        a str that is returned
    b: int
        an int that is returned
    """

    docstring = NumpydocParser().parse(text)
    assert(len(docstring.param) == 2)
    assert docstring.param[0] == DocstringParam(
        args=['param', 'something'],
        description='a str that does something',
        arg_name='something',
        type_name='str',
        is_optional=None,
        default=None,
    )

# Generated at 2022-06-25 16:27:17.743991
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    numpydoc_parser_0 = NumpydocParser()
    text = '''This is a test that has a Deprecated section
    .. deprecated:: 1.2.2
        Test is deprecated
    '''
    ret = numpydoc_parser_0.parse(text)
    assert ret.short_description == "This is a test that has a Deprecated section"
    assert ret.long_description == None
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == False
    assert ret.is_deprecated == False
    assert ret.meta[0].args[0] == "deprecation"
    assert ret.meta[0].description == "Test is deprecated"
    assert ret.meta[0].version == "1.2.2"

# Generated at 2022-06-25 16:27:19.466960
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    NumpydocParser().parse("")

# Generated at 2022-06-25 16:27:26.777617
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    test_docstring = inspect.cleandoc(
        """
    Short description.

    Long description.
    """
    )
    expected_docstring = Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[],
    )
    actual_docstring = parser.parse(test_docstring)
    assert actual_docstring == expected_docstring



# Generated at 2022-06-25 16:27:39.603791
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    lines = ['TestSummary', '', '    TestDescription', '', '    Parameters', '    ----------', '    a : int', '        A first parameter', '', '    method : function', '        A function parameter', '', '    Returns', '    -------', '    c : str', '        A here is a return type', '    d : str', '        Here is the description', '        of the second return value']

    ret_val_0 = numpydoc_parser_0.parse('\n'.join(lines))

    assert ret_val_0.short_description == 'TestSummary'
    assert ret_val_0.long_description == 'TestDescription'
    assert ret_val_0.blank_after_short_description is True
    assert ret_val_

# Generated at 2022-06-25 16:27:46.205537
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

    # Test case 0
    # The following docstring comes from the wonderful parse_type function in
    # pydantic:
    # https://github.com/samuelcolvin/pydantic/blob/v0.32.1/pydantic/main.py
    # It parses correctly, but does have some (intentional) deviation from the
    # numpydoc formatting guide.

# Generated at 2022-06-25 16:27:52.998768
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    assert isinstance(
        numpydoc_parser_0.parse(""),
        Docstring,
        "Test if an empty docstring parsed to Docstring()",
    )


if __name__ == "__main__":
    import os

    basename = os.path.basename(__file__)
    pytest.main([basename, "-s", "--tb=native"])

# Generated at 2022-06-25 16:28:08.667258
# Unit test for function parse
def test_parse():
    # This test case calls function parse. Assert the function call
    # returns the expected output.
    actual = parse(
        """
        unit test for function parse

        Parameters
        ----------
        input : str
            input string to be parsed

        Returns
        -------
        parsed : Docstring
            parsed Docstring object
        """
    )


# Generated at 2022-06-25 16:28:10.232080
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
  deprecationSection = DeprecationSection("Deprecated", "deprecated");


# Generated at 2022-06-25 16:28:15.228384
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    deprecation_section_0 = DeprecationSection("deprecation-section-title-0", "deprecation-section-key-0")
    deprecation_section_1 = DeprecationSection("deprecation-section-title-1", "deprecation-section-key-1")
    numpydoc_parser_0.add_section(deprecation_section_0)
    numpydoc_parser_0.add_section(deprecation_section_1)


# Generated at 2022-06-25 16:28:21.010881
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Arrange
    test_title = "Parameters"
    test_key = "param"

    # Act
    test_parser = _KVSection(title=test_title, key=test_key)
    test_title_pattern = test_parser.title_pattern

    # Assert
    assert test_title_pattern == "^Parameters\\s*?\\n---*\\s*$"


# Generated at 2022-06-25 16:28:24.300645
# Unit test for method parse of class Section
def test_Section_parse():
    numpydoc_parser_0 = NumpydocParser()
    section_0 = Section()


# Generated at 2022-06-25 16:28:39.030142
# Unit test for function parse
def test_parse():
    assert parse('Parses the numpy-style docstring into its components.')
    assert parse('Hello world!')
    assert parse('')
    assert parse('Hello world!\n\n\n')
    assert parse('Long description upper case \n\n\n')
    assert parse('Long description lower case \n\n\n')
    assert parse('description upper case\ndescription lower case\n\n')
    assert parse('Description upper case.\nDescription lower case.\n\n')
    assert parse('description upper case.\ndescription lower case.\n\n')
    assert parse('Example: \n\nExample: \n\n')
    assert parse('Example: \nExample: \n\n')
    assert parse('Example: \n Example: \n\n')

# Generated at 2022-06-25 16:28:42.406391
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    assert isinstance(numpydoc_parser_0.sections['Warning'].parse("This is a warning"), T.Iterable[DocstringMeta])
    numpydoc_parser_0.parse("This is a warning")


# Generated at 2022-06-25 16:28:44.138442
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    numpydoc_parser_1 = NumpydocParser()


# Generated at 2022-06-25 16:28:54.828669
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Path of the test file
    path = "..\\tests\\test_data\\test_NumpydocParser_parse.txt"
    # Open the test file
    with open(path, 'r') as file:
        lines = file.readlines()

    # Create the parser
    parser = NumpydocParser()

    # Parse the first docstring from the test file
    doc = parser.parse(lines[0])

    # Assert that the parsed docstring is correct
    assert doc.short_description == lines[1].strip()
    assert doc.blank_after_short_description == True
    assert doc.long_description == lines[2].strip()
    assert doc.blank_after_long_description == True
    assert len(doc.meta) == 3



# Generated at 2022-06-25 16:29:03.366549
# Unit test for function parse
def test_parse():
    test_text = '''
    Params:
        line_1 : type
            description
        line_2 (optional)
            description
        line_3
            description
            description
            description
        line_4 : type[, optional]
            description
        line_5 : type, optional
            description
    '''

    result = parse(test_text)
    assert isinstance(result, Docstring)


# Generated at 2022-06-25 16:29:18.573258
# Unit test for method parse of class Section
def test_Section_parse():
    text = inspect.cleandoc( """
        my_long_name
            Description of something with a
            long name.
        my_other_long_name : int, optional
            Description of something with a
            long name and a type.
        """
    )
    section = ParamSection("Parameters", "param")
    result = section.parse(text)

# Generated at 2022-06-25 16:29:20.809344
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    title = "deprecation"
    key = "DEPRECATED"
    numpydoc_parser_1 = DeprecationSection(title, key)


# Generated at 2022-06-25 16:29:31.150448
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    Document a thing.

    This is the long description.
    It can span multiple lines.

    Parameters
    ----------
    param_1 : int
        description of first parameter
    param_2 : float
        description of second parameter

    Returns
    -------
    int
        description of return value

    Raises
    ------
    ValueError
        description of exception
    """
    text_0 = """
        Document a thing.

        This is the long description.
        It can span multiple lines.

        Parameters
        ----------
        param_1 : int
            description of first parameter
        param_2 : float
            description of second parameter

        Returns
        -------
        int
            description of return value

        Raises
        ------
        ValueError
            description of exception
        """
    numpydoc_parser_0

# Generated at 2022-06-25 16:29:43.565794
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    numpydoc_parser_0 = _KVSection("Parameters", "param")
    text_0 = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines\n"
    assert numpydoc_parser_0.parse(text_0) == [DocstringParam(['param', 'arg_name'], 'arg_description', arg_name='arg_name', type_name=None, is_optional=False, default=None), DocstringParam(['param', 'arg_2'], 'descriptions can also span... ... multiple lines', arg_name='arg_2', type_name='type', is_optional=True, default=None)]
# End test for method parse of class _KVSection




# Generated at 2022-06-25 16:29:51.351996
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("Deprecated", "deprecated")
    text = "0.2.0\n\nThe old API was not as good."
    parsed = section.parse(text)
    assert next(parsed).version == "0.2.0"
    assert next(parsed).description == "The old API was not as good."


# Generated at 2022-06-25 16:30:00.595267
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydoc_parser_1 = NumpydocParser()
    class Section_1(Section):
        def __init__(self, title: str, key: str) -> None:
            self.title = title
            self.key = key
        @property
        def title_pattern(self) -> str:
            return r"^({})\s*?\n{}\s*$".format(self.title, "-" * len(self.title))
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            yield DocstringMeta([self.key], description=_clean_str(text))
    numpydoc_parser_1.add_section(Section_1("Section_1", "key"))


# Generated at 2022-06-25 16:30:13.846445
# Unit test for method parse of class Section
def test_Section_parse():
    numpydoc_parser_0 = NumpydocParser()
    assert numpydoc_parser_0
    # make sure it builds
    assert isinstance(numpydoc_parser_0, NumpydocParser)

    example_text = """

Examine some parameters::

    $ cat /proc/modules
    $ lsmod

"""
    result_text = """
<p>Examine some parameters:
</p>
<pre>
<code>
    $ cat /proc/modules
    $ lsmod
</code>
</pre>
"""
    test_section = Section(title = 'Examples', key = 'examples')
    assert test_section.title_pattern == "^Examples\\s*?\n{1}$"

# Generated at 2022-06-25 16:30:23.086215
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    numpydoc_parser_0 = NumpydocParser()
    assert numpydoc_parser_0.sections is not None
    assert numpydoc_parser_0.titles_re is not None
    section_0 = Section("Title", "key")
    numpydoc_parser_0.add_section(section_0)
    assert numpydoc_parser_0.sections is not None
    assert numpydoc_parser_0.titles_re is not None



# Generated at 2022-06-25 16:30:25.704400
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    numpydoc_parser_0 = NumpydocParser()
    assert numpydoc_parser_0.sections is not None


# Generated at 2022-06-25 16:30:30.344245
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    numpydoc_parser_1 = NumpydocParser()
    assert numpydoc_parser_1.sections['Returns'] == ReturnsSection("Returns", "returns")
    assert numpydoc_parser_1.sections['Related'] == Section("Related", "see_also")


# Generated at 2022-06-25 16:30:43.453051
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    numpydoc_parser_1 = NumpydocParser()
    r_section = RaisesSection("Raises", "raises")
    assert(r_section.title == "Raises")
    assert(r_section.key == "raises")


# Generated at 2022-06-25 16:30:45.862495
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert True



# Generated at 2022-06-25 16:30:50.489473
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    parsed_docstring = NumpydocParser()
    modified_parsed_docstring = parsed_docstring.add_section(DeprecationSection("deprecated", "deprecation"))
    return modified_parsed_docstring


# Generated at 2022-06-25 16:30:59.995292
# Unit test for function parse
def test_parse():

    text0 = """
        This is a docstring.

        It has a short description
        and a long description.
    """

    d0 = parse(text0)
    assert d0.short_description == "This is a docstring."
    assert d0.long_description == "It has a short description and a long description."


# Generated at 2022-06-25 16:31:03.329925
# Unit test for constructor of class Section
def test_Section():
    print("Unit test for constructor of class Section")
    assert Section("title", "key").title == "title"
    assert Section("title", "key").key == "key"



# Generated at 2022-06-25 16:31:16.013755
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:31:17.558766
# Unit test for constructor of class _KVSection
def test__KVSection():
    section_0 = _KVSection("Parameters", "param")


# Generated at 2022-06-25 16:31:26.646399
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:31:35.328717
# Unit test for method parse of class Section
def test_Section_parse():
    section_0 = Section("Parameters", "param")
    text = '''
    Hello World
    '''
    ret = section_0.parse(text)
    assert next(ret) == DocstringMeta(["param"], description="Hello World")


# Generated at 2022-06-25 16:31:39.750209
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    numpydoc_parser_1 = NumpydocParser()
    text_2 = "value"
    numpydoc_parser_1.text_2 = text_2
    text_2 = "value"
    assert numpydoc_parser_1.text_2 == text_2



# Generated at 2022-06-25 16:31:49.271680
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    This is the description.
    Next line of description.
    """
    assert numpydoc_parser_0._KVSection.parse(text) == None


# Generated at 2022-06-25 16:31:53.214359
# Unit test for constructor of class Section
def test_Section():
    section = Section("title", "key")
    assert section.title == "title"
    assert section.key == "key"


# Generated at 2022-06-25 16:31:55.863026
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = 'something'
    key = 'stuff'
    section_0 = _SphinxSection(title, key)
    assert_equal(section_0.title, title)
    assert_equal(section_0.key, key)


# Generated at 2022-06-25 16:32:01.208520
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    """
    .. title:: Parameter for ``RaisesSection``

    """
    numpydoc_parser_1 = NumpydocParser(
        [RaisesSection(
            title="Raises",
            key="raises"
            )
        ]
        )


# Generated at 2022-06-25 16:32:06.021594
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection("Parameters", "param")
    assert p.title == "Parameters"
    assert p.key == "param"
    assert p.title_pattern == "^Parameters[\s]*?\n[-]*$"



# Generated at 2022-06-25 16:32:13.926954
# Unit test for method parse of class Section
def test_Section_parse():
    # Instantiation of the class Section
    numpydoc_parser_0 = Section("Parameters", "param")
    numpydoc_parser_1 = Section("Params", "param")
    numpydoc_parser_2 = Section("Arguments", "param")
    # Initialization of the variable text
    str_0 = "    :param str x: haha"
    str_1 = "    :params str x: haha"
    str_2 = "    :arguments str x: haha"
    numpydoc_parser_0.parse(str_0)
    numpydoc_parser_1.parse(str_1)
    numpydoc_parser_2.parse(str_2)


# Generated at 2022-06-25 16:32:16.510124
# Unit test for function parse
def test_parse():
    assert str(parse(__doc__).short_description) == "Numpydoc-style docstring parsing."

# Generated at 2022-06-25 16:32:22.561382
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters","param")
    text = "arg_name\n\targ_description\narg_2 : type, optional\n\tdescriptions can also span...\n\t... multiple lines"
    ret = section.parse(text)
    print(ret)


# Generated at 2022-06-25 16:32:33.979221
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc("""
        Some short description.

        Any longer description.

        Parameters:
            some_param (type): The first parameter.
            another_param : The second one.
        Raises:
            ValueError: When something bad happens.

        Returns:
            return_value: None.
        """)
    # print(text)
    docstring = parse(text)
    # print(docstring)
    assert docstring.short_description == "Some short description."
    assert docstring.long_description == "Any longer description."
    assert len(docstring.meta) == 4
    assert docstring.meta[0].description == "The first parameter."
    assert docstring.meta[0].args == ["param", "some_param"]
    assert docstring.meta[1].description == "The second one."

# Generated at 2022-06-25 16:32:41.702699
# Unit test for constructor of class ParamSection
def test_ParamSection():
    numpydoc_parser_1 = NumpydocParser()
    parse_1 = numpydoc_parser_1.parse
    meta_1 = parse_1(
        """
        Parameters
        ----------
        arg_name
        arg_description
        arg_2 : type, optional
        descriptions can also span
        multiple lines
        """
    )
    assert len(meta_1.meta) == 1
    assert len(meta_1.meta[0].args) == 1
    meta_1_0_0 = meta_1.meta[0].args[0]
    assert meta_1_0_0 == "param"
    assert meta_1.meta[0].description is None


# Generated at 2022-06-25 16:32:57.321471
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    return NumpydocParser(
        sections=[
            RaisesSection("Raises", "raises"),
            ReturnsSection("Returns", "returns"),
        ]
    ).parse(
        text="""Raises
            Nothing

            Returns
            -------
            str
                A string"""
    )

# Generated at 2022-06-25 16:33:03.864723
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.parse(text='deprecation warning')
    numpydoc_parser_0.parse(text='version,desc')
