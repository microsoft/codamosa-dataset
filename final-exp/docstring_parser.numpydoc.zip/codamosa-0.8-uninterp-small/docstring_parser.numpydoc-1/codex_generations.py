

# Generated at 2022-06-25 16:23:29.001811
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text_0 = "Deprecated since version 0.9.0:\n    Use :meth:`~Sample.f` instead."
    result = DeprecationSection("deprecated", "deprecation").parse(text_0)
    expected_result = [DocstringDeprecated(args=["deprecation"], description=" Use :meth:`~Sample.f` instead.", version='0.9.0:')]
    assert result == expected_result


# Generated at 2022-06-25 16:23:31.110429
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Test case data
    section = _KVSection("Parameters", "params")
    text = "Parameters\n----------\n"

    # Perform test
    result = section.parse(text).__next__().description

    # Check for expected results
    assert result == "Parameters"


# Generated at 2022-06-25 16:23:36.073354
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    from .common import DocstringMeta
    numpydoc_parser_1 = NumpydocParser()

    #
# <BLANKLINE>
# .. deprecated:: 0.1.10
#     This method is deprecated. Use
#     :py:meth:`~pathlib.Path.rename` instead.
# <BLANKLINE>
    deprecation_section_0_0 = numpydoc_parser_1.sections["deprecated"]
    deprecation_section_0_0.title = "deprecated"
    deprecation_section_0_0.key = "deprecation"
    deprecation_section_0_0.title_pattern = "^\.\.\s*(deprecated)\s*::"

# Generated at 2022-06-25 16:23:48.213893
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_1 = NumpydocParser()
    # DeprecationSection object: _SphinxSection.parse(text: str) -> T.Iterable[DocstringMeta]
    # Parameters:
    #     self: DeprecationSection object
    #     text: str
    # Return:T.Iterable[DocstringMeta]
    # Test case:
    #     text = '''
    #             text = '
    #     '''
    # expect output:
    #     None
    text = '''
            .. deprecated:: 0.1.4
                ....
            '''
    assert numpydoc_parser_1._SphinxSection.parse(self = numpydoc_parser_1._SphinxSection, text = text) == None
    # Test case:
    #     text = '

# Generated at 2022-06-25 16:23:58.420309
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    deprecation_parser_0 = Section("Deprecation Warning", "deprecated")
    assert deprecation_parser_0.title == "Deprecation Warning"
    assert deprecation_parser_0.key == "deprecated"
    assert deprecation_parser_0.title_pattern == "^Deprecation Warning\\s*?\\n------*\\s*$"
    text_0 = 'Deprecation Warning\n'
    text_1 = '-----\n'
    text_2 = 'Version 0.1\n'
    text_3 = '\n'
    text_4 = 'This is a deprecated function.\n'
    text_5 = '\n'
    text_6 = '\n'

# Generated at 2022-06-25 16:24:00.929116
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    target = DeprecationSection('title', 'key')
    text = 'something\npossibly over multiple lines\n'
    print(numpydoc_parser_0.parse(text))


# Generated at 2022-06-25 16:24:04.278849
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    docs = DeprecationSection("deprecated", "deprecation")
    docs.parse("test")


# Generated at 2022-06-25 16:24:11.115717
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    deprecation_section_0 = NumpydocParser().sections['deprecated']
    text = '.. deprecated:: 0.0.1\n    This is a long description which should\n    appear in the new docstring.'
    test_0 = deprecation_section_0.parse(text)
    assert test_0[0].description == 'This is a long description which should\nappear in the new docstring.'
    assert test_0[0].version == '0.0.1'


# Generated at 2022-06-25 16:24:14.754602
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section_0 = Section(title="deprecated", key="deprecation")
    text_0 = "deprecated\n    Some text."
    docstring_meta_0 = DocstringMeta(args=["deprecation"], description="Some text.")
    assert section_0.parse(text_0) == [docstring_meta_0]


# Generated at 2022-06-25 16:24:23.466137
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_1 = NumpydocParser()

    # Test case 0
    text_0 = "1.2.3\n\nA deprecation message."
    ret_0 = numpydoc_parser_1.parse(text_0)
    expected_0 = Docstring(
        short_description=None,
        long_description=None,
        meta=[
            DocstringDeprecated(
                description="A deprecation message.", args=["deprecation"], version="1.2.3"
            )
        ],
    )
    assert ret_0 == expected_0



# Generated at 2022-06-25 16:24:41.371804
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    numpydoc_parser_1 = NumpydocParser()
    text = 'arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines'

# Generated at 2022-06-25 16:24:49.518304
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Given
    kvsection = _KVSection("a","b")
    text = '''
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
        '''
    # When
    l = kvsection.parse(text)
    # Then
    assert list(l) == [DocstringMeta(['b', 'key'], description='value'), DocstringMeta(['b', 'key2'], description='values can also span...\n... multiple lines')]


# Generated at 2022-06-25 16:24:58.104316
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    ret_val_0 = numpydoc_parser_0.parse(str_0)
    assert isinstance(ret_val_0, Docstring)
    assert ret_val_0.short_description == "short desc"
    assert ret_val_0.blank_after_short_description
    assert ret_val_0.blank_after_long_description
    assert ret_val_0.long_description == "long\ndesc"
    assert len(ret_val_0.meta) == 0


# Generated at 2022-06-25 16:25:11.412523
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test Case 0
    """
    # Test Case 0
    numpydoc_parser_0 = NumpydocParser()
    text_0 = '''TestCase for parser.
    -----------

    TestCase for NumpydocParser.

    Parameters
    ----------
    cls : class

        TestCase for parser.

    '''
    result = numpydoc_parser_0.parse(text_0)
    assert result.short_description == 'TestCase for NumpydocParser.'
    assert len(result.meta) == 3
    assert result.meta[0].args == ['param', 'cls']
    assert result.meta[0].description == 'class'
    assert result.meta[1].args == ['param', None]
    assert result.meta[1].description == 'TestCase'
   

# Generated at 2022-06-25 16:25:14.285177
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    pass

# Generated at 2022-06-25 16:25:26.506327
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kVSection = _KVSection("title", "key")
    m = re.search("^({})\s*?\n{}\s*$".format("title", "-" * len("title")), "title\n------\nkey : type\n\tdescription\n")
    kVSection.parse("key : type\n\tdescription\n")
    kVSection.parse("key : type\n\tdescription\nkey2 : type\n\tdescription\n")
    kVSection.parse("key : type\n\tdescription\nkey2 : type, optional\n\tdescription\n")
    kVSection.parse("key : type, optional\n\tdescription\nkey2 : type\n\tdescription\n")

# Generated at 2022-06-25 16:25:29.704782
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

    assert numpydoc_parser_0.parse("") == Docstring()

# Generated at 2022-06-25 16:25:33.979877
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    s = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines"""
    numpydoc_parser_1 = NumpydocParser()
    s_1 = """key
        value
    key2 : type
        values can also span...
        ... multiple lines"""
    assert numpydoc_parser_1._KVSection.parse(s_1) == True


# Generated at 2022-06-25 16:25:36.001707
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    assert numpydoc_parser is not None


# Generated at 2022-06-25 16:25:48.865272
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    numpydoc_parser_1 = NumpydocParser()

    text = """\
            arg_name
                arg_description
            arg_2 : type, optional
                descriptions can also span...
                ... multiple lines
        """

# Generated at 2022-06-25 16:26:03.912491
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:26:14.477713
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "a function for testing the parser that returns a docstring"
    ret_0 = numpydoc_parser_0.parse(text_0)
    m = DocstringMeta(['example'], description='...\n')
    assert ret_0.meta[0] == m
    assert ret_0.short_description == "a function for testing the parser that returns a docstring"
    assert ret_0.long_description == "...\n"
    assert ret_0.blank_after_short_description == True
    assert ret_0.blank_after_long_description == False
    assert ret_0.warning == ""



# Generated at 2022-06-25 16:26:27.424002
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:26:39.604342
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    parsed_docstring_0 = numpydoc_parser_0.parse(test_string)
    assert parsed_docstring_0 == expected_docstring


# Generated at 2022-06-25 16:26:45.754490
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    numpydoc_parser
    docstring_0 = numpydoc_parser.parse('')
    assert_equal(docstring_0.long_description, None)
    assert_equal(docstring_0.short_description, None)
    assert_equal(docstring_0.blank_after_long_description, False)
    assert_equal(docstring_0.blank_after_short_description, False)
    assert_equal(docstring_0.meta, [])
    docstring_1 = numpydoc_parser.parse('   \n   ')
    assert_equal(docstring_1.long_description, None)
    assert_equal(docstring_1.short_description, None)

# Generated at 2022-06-25 16:26:53.103936
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    This is the short description.

    This is the long description.
    '''
    numpydoc_parser_0 = NumpydocParser()
    docstring = numpydoc_parser_0.parse(text)
    assert docstring.short_description == 'This is the short description.'
    assert (docstring.long_description == 'This is the long description.\n')


# Generated at 2022-06-25 16:27:06.929772
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    with open("tests/numpydoc.py") as f:
        test_docstring = f.read()

# Generated at 2022-06-25 16:27:17.732501
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = 'Returns the unit vector of the vector.\n'
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description == 'Returns the unit vector of the vector.'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    assert docstring_0.meta == []

    text_1 = 'Returns the unit vector of the vector.\n\nNormalizes the vector using Euclidean distance.\n'
    docstring_1 = numpydoc_parser_0.parse(text_1)
    assert docstring_1.short_

# Generated at 2022-06-25 16:27:29.201030
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print('\nTest parse')

    # Initialize the input parameters needed to parse the docstring
    numpydoc_parser_0 = NumpydocParser()

    # String containing the docstring to parse

# Generated at 2022-06-25 16:27:38.352246
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "arg_0 : type_0\n    value_0"

    assert numpydoc_parser_0.parse(text_0).meta == [DocstringParam(
        args=['param', 'arg_0'],
        type_name='type_0',
        description='value_0',
        arg_name='arg_0',
        is_optional=False,
        default=None
    )]

# Generated at 2022-06-25 16:27:56.168935
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "Clamp this array to ``[0, 1]``."
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description == "Clamp this array to ``[0, 1]``."


# Generated at 2022-06-25 16:28:08.536718
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    desc = """The function `f` returns a string.

    Parameters
    ----------
    x : float
        The first parameter.
    y : int
        The second parameter.

    Returns
    -------
    f : str
        A string.

    """
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:28:20.680695
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import doctest
    from . import numpydoc
    #from sphinx.application import Sphinx
    fail_samples = []
    pass_samples = []
    for sample in doctest.DocTestParser().get_examples(numpydoc.parse.__doc__):
        if sample.want != sample.got:
            fail_samples.append(sample)
        else:
            pass_samples.append(sample)
    assert len(fail_samples) == 0, "Failed examples:\n{}".format("\n".join([str(e) for e in fail_samples]))
    assert len(pass_samples) > 0, "{} is tested with no passing examples".format(numpydoc.parse.__name__)

if __name__ == '__main__':
    import sys

# Generated at 2022-06-25 16:28:33.094428
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()

    # Example from numpydoc
    text_2 = """First line of the summary.

First line of the extended summary, which may be several lines long.

Parameters
----------
param1 : type1
    Description of `param1` goes here. Optional continuation line.
param2 : type2
    Description of `param2` goes here.

Returns
-------
value : type
    Description of `value` goes here."""
    docstring_3 = numpydoc_parser_1.parse(text_2)

    assert docstring_3.short_description == "First line of the summary."
    assert docstring_3.long_description == "First line of the extended summary, which may be several lines long."
    assert docstring_3.blank_after_short_

# Generated at 2022-06-25 16:28:37.651848
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = Docstring()
    docstring_1 = numpydoc_parser_0.parse("")
    # There is a bug in Pylance (in PyCharm 2020.2) about the below instance comparison.
    # See https://youtrack.jetbrains.com/issue/PY-42220
    # assert docstring_0 == docstring_1


# Generated at 2022-06-25 16:28:48.546797
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_0 = \
"""This is a summary

    This is a detailed description, which can span multiple lines
    and contain section headers.

Parameters
----------
arg_1
    This is an argument name, whose type is optional.
arg2 : int
    This is an argument name, whose type is required.
    It also has a description spanning multiple lines.
    The description can also have multiple paragraphs,
    and more complicated formatting, e.g. math

Raises
------
ValueError
    An exception.
"""

    # Case 1 and 2

    # Call function under test
    ret_0 = NumpydocParser().parse(text_0)

    assert ret_0.short_description == "This is a summary"

    assert ret_0.blank_after_short_description is True

    assert ret_0.blank_after_long_

# Generated at 2022-06-25 16:29:00.149085
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_1 = NumpydocParser()
    numpydoc_parser_2 = NumpydocParser()

    # Test cases
    docstring_0 = Docstring()
    docstring_0.short_description = "This is the short description."
    docstring_0.blank_after_short_description = True
    docstring_0.blank_after_long_description = False
    docstring_0.long_description = "This is the long description."
    docstring_0.meta = []
    docstring_1 = Docstring()
    docstring_1.short_description = "This is the short description."
    docstring_1.blank_after_short_description = True
    docstring_1.blank_after_long

# Generated at 2022-06-25 16:29:10.752235
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 0
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "This is a short description    \n\nThis is a long description"
    result_0 = numpydoc_parser_0.parse(text_0)
    assert result_0 == Docstring(short_description="This is a short description",
    long_description="This is a long description", blank_after_short_description=False,
    blank_after_long_description=True, meta=[])
    # Test case 1
    numpydoc_parser_1 = NumpydocParser()
    text_1 = "This is a short description\nwith no trailing whitespace.\n\nThis is a long description"
    result_1 = numpydoc_parser_1.parse(text_1)
   

# Generated at 2022-06-25 16:29:14.430839
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = "short description\nlong description\n"
    docstring = numpydoc_parser_0.parse(text)
    assert docstring.short_description == "short description"
    assert docstring.long_description == "long description"
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description


# Generated at 2022-06-25 16:29:20.651107
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
   numpydoc_parser_0 = NumpydocParser()
   text = "This is a simple test string"
   try:
       assertEqual(numpydoc_parser_0.parse(text), Docstring('This is a simple test string'))
   except AssertionError as e:
       print(e)


if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-25 16:29:43.691251
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = "Default: None\n        Object to use to transform data.\n    "
    ret_val_0 = numpydoc_parser_0.parse(text)
    # Compare subject to result
    assert ret_val_0.short_description == None, "Expected %s but got %s" % (None, ret_val_0.short_description)
    assert (len(ret_val_0.meta) == 1), "Expected %s but got %s" % (1, (len(ret_val_0.meta)))


# Generated at 2022-06-25 16:29:57.387018
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Setup
    numpydoc_parser = NumpydocParser()
    text = "def func(a: int, b: float = 2.): pass"

    # Exercise
    result = numpydoc_parser.parse(text)

    # Verify
    assert result.short_description is None
    assert result.blank_after_short_description is None
    assert result.blank_after_long_description is None
    assert result.long_description is None

# Generated at 2022-06-25 16:30:10.702343
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()

    # Test case 0
    text_0 = "sdfsdfsdfsdf"
    docstring_0 = numpydoc_parser_1.parse(text_0)
    assert docstring_0.short_description == None
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.long_description == None
    assert len(docstring_0.meta) == 0

    # Test case 1
    text_1 = "    This is a docstring.\n"
    docstring_1 = numpydoc_parser_1.parse(text_1)
    assert docstring_1.short_description == "This is a docstring."


# Generated at 2022-06-25 16:30:21.437454
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 = """\
    This is an example test docstring.

    Arguments:
        arg_1 : str
            The first argument.
        arg_2 : int
            The second argument.
    """
    docstring = numpydoc_parser_0.parse(str_0)
    attr_value_0 = docstring.long_description
    assert attr_value_0 == "This is an example test docstring."
    attr_value_0 = docstring.short_description
    assert attr_value_0 == "This is an example test docstring."
    assert docstring.blank_after_long_description == True
    assert docstring.blank_after_short_description == False

# Generated at 2022-06-25 16:30:32.412151
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    test_string_0 = 'A test string'
    test_return = numpydoc_parser_1.parse(test_string_0)
    assert test_return.short_description == 'A test string'
    assert test_return.long_description is None
    assert test_return.blank_after_short_description is False
    assert test_return.blank_after_long_description is False
    assert len(test_return.meta) == 0

if __name__ == '__main__':
    
    numpydoc_parser_1 = NumpydocParser()
    test_string_0 = 'A test string'
    test_return = numpydoc_parser_1.parse(test_string_0)

# Generated at 2022-06-25 16:30:44.138310
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.add_section(Section("Test Section", "test_section"))
    text = ""
    docstring_0 = numpydoc_parser_0.parse(text)
    assert docstring_0 == Docstring()
    text = "A short description\n\n"
    docstring_0 = numpydoc_parser_0.parse(text)
    assert docstring_0.short_description == "A short description"
    text = "A short description\n\nA long description\n"
    docstring_0 = numpydoc_parser_0.parse(text)
    assert docstring_0.short_description == "A short description"
    assert docstring_0.long_description == "A long description"

# Generated at 2022-06-25 16:30:50.473646
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:30:52.095755
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 16:31:06.021781
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = ""
    assert numpydoc_parser_0.parse(text) == Docstring(
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=True,
        short_description=None,
        meta=[],
    )
    text = ""
    assert numpydoc_parser_0.parse(text) == Docstring(
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=True,
        short_description=None,
        meta=[],
    )
    text = ""

# Generated at 2022-06-25 16:31:09.726737
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = "\n        .. versionadded::\n            The name attribute.\n        "
    assert numpydoc_parser_0.parse(text) == Docstring()

# Generated at 2022-06-25 16:31:25.857714
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_str_0 = ''
    response = numpydoc_parser_0.parse(text_str_0)
    assert len(response.meta) == 0
    assert response.short_description is None
    assert response.long_description is None
    assert response.blank_after_short_description is False
    assert response.blank_after_long_description is False


# Generated at 2022-06-25 16:31:35.510616
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:31:42.417592
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = """\
    Some short description.

    Longer description::

        class Foo:
            """
    actual = numpydoc_parser_0.parse(text)
    assert actual.short_description == "Some short description."
    assert actual.long_description == "Longer description::\n\n    class Foo:\n        "
    assert actual.blank_after_short_description == True
    assert actual.blank_after_long_description == False
    assert actual.meta == []

# Generated at 2022-06-25 16:31:45.887830
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser([DeprecationSection("deprecated", "deprecation")])
    assert not numpydoc_parser_0.parse(
        """
    Do something great.
    """
    )


# Generated at 2022-06-25 16:31:55.822807
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Input
    text = """\
    Returns
        something
            returns something
        something_else
            returns sometinh else
    """
    # Expected output

# Generated at 2022-06-25 16:32:02.517574
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = '''Reads a file in PDBQT format, and returns a multi-model
              :class:`Molecule <BioSimSpace.Molecule>` object.
    '''
    docstring = numpydoc_parser_0.parse(text)


# Generated at 2022-06-25 16:32:12.820441
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # Default case
    str_0 = 'Hello World!'
    docstring_0 = numpydoc_parser_0.parse(str_0)
    assert docstring_0.short_description == str_0
    assert docstring_0.long_description == None
    assert docstring_0.meta == []
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False

    # Multiple words
    str_0 = 'Hello world! This is your first Python program!'
    docstring_0 = numpydoc_parser_0.parse(str_0)
    # print(docstring_0.short_description)
    # print(docstring_0.long_description)


# Generated at 2022-06-25 16:32:25.315917
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_text1 = '''
        Short description.

        Long description.

        Parameters
        ----------
        arg1
            Arg1 description.
        arg2 : type
            Arg2 description, with type.
        SomeParam, optional
            SomeParam description.

        Raises
        ------
        ValueError
            If something is bad.

        Returns
        -------
        The thing.
        '''


# Generated at 2022-06-25 16:32:34.988571
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_1 = numpydoc_parser_0.parse('\n    Summary line.\n\n    Extended description of function.\n\n    Parameters\n    ----------\n    param1 : int\n        Parameter 1.\n    param2 : str\n        Parameter 2.\n\n    Returns\n    -------\n    bool\n        True if successful, False otherwise.\n\n    ')
    description_2 = docstring_1.short_description
    description_3 = docstring_1.long_description
    blank_after_short_description_4 = docstring_1.blank_after_short_description
    blank_after_long_description_5 = docstring_1.blank_after_long_description
    doc

# Generated at 2022-06-25 16:32:43.066550
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()

    # Test with short_description = 'convert velocity to wavenumber'
    # Test with long_description = '\nParameters\n----------\nvelocity : value_type\n    velocity \n\nReturns\n-------\nwavenumber : value_type\n    wavenumber\n'
    # Test with meta = DocstringMeta(['param', 'velocity', 'value_type', None, None, True, None], 'velocity \n', DocstringMeta(['returns', None, 'value_type', None, None, False, None], 'wavenumber\n', []))

# Generated at 2022-06-25 16:32:55.624850
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()



# Generated at 2022-06-25 16:32:56.801024
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()


# Generated at 2022-06-25 16:33:09.739812
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()