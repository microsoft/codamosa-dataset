

# Generated at 2022-06-25 16:23:53.416346
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Initialize a list of tuples to store test input
    in_str = []
    in_str.append("")

# Generated at 2022-06-25 16:24:04.182785
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'T'
    str_1 = 'd9.A'
    str_2 = '&r=zidj+3q[AJl'
    docstring_0 = Docstring()
    docstring_1 = parse(str_1)
    docstring_2 = parse(str_2)
    docstring_3 = parse(str_0)
    numpydocparser_0 = NumpydocParser()
    numpydocparser_0.add_section(docstring_0)
    numpydocparser_1 = NumpydocParser()
    numpydocparser_1.add_section(docstring_1)
    numpydocparser_2 = NumpydocParser()
    numpydocparser_2.add_section(docstring_2)
    nump

# Generated at 2022-06-25 16:24:13.915367
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'hK6 c}SBe|F9`u/Oe#B'
    returns_section_0 = ReturnsSection(str_0, str_0)

    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.add_section(returns_section_0)

    str_1 = 'hK6 c}SBe|F9`u/Oe#B'
    docstring_0 = numpydoc_parser_0.parse(str_1)

    str_2 = 'hK6 c}SBe|F9`u/Oe#B'
    str_3 = 'hK6 c}SBe|F9`u/Oe#B'

# Generated at 2022-06-25 16:24:23.480193
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    method_name = 'NumpydocParser.parse'
    # from custom_injector import inject
    # inject(NumpydocParser, 'parse')
    # import requests
    # r = requests.get()
    # r.text
    
    # from unittest.mock import Mock, call
    # NumpydocParser.__init__ = Mock(return_value=None)
    # NumpydocParser.parse = Mock(return_value=None)
    # NumpydocParser.parse('a')
    # NumpydocParser.parse.assert_called_once()
    # NumpydocParser.parse.assert_called_once_with('a')
    # NumpydocParser.parse.assert_called_with('a')
    # NumpydocParser.parse.assert_any

# Generated at 2022-06-25 16:24:36.565129
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'hK6 c}SBe|F9`u/Oe#B'
    numpydocparser_0 = NumpydocParser()
    numpy_str_0 = 'hK6 c}SBe|F9`u/Oe#B'
    docstring_0 = numpydocparser_0.parse(numpy_str_0)

    # Verify that docstring_0 contains the correct text
    # (shorter than 50 characters)
    assert docstring_0.short_description == numpy_str_0

    # Verify that docstring_0 contains the correct text
    # (longer than 50 characters)
    assert docstring_0.long_description == numpy_str_0

    # Verify that docstring_0 contains the correct text
    # (blank after short description?)

# Generated at 2022-06-25 16:24:45.175150
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Unit test for method parse of class NumpydocParser"""
    parser_0 = NumpydocParser()
    str_0 = """This is a short description.
    Here is the long description.
    """
    docstring_0 = parser_0.parse(str_0)
    assert (docstring_0.short_description == "This is a short description.")
    assert (docstring_0.long_description == "Here is the long description.")


if __name__ == '__main__':
    test_NumpydocParser_parse()
    test_case_0()
    print('\nSuccess')

# Generated at 2022-06-25 16:24:49.157942
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = '_"7c%~4?+*tiLe}A'
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse(str_0)



# Generated at 2022-06-25 16:25:00.645301
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Input arguments
    text = 'j'

    # Output argument
    meta_keys = [
        'description',
        'param_name',
        'arg_name',
        'type_name',
        'is_optional',
        'default',
        'type_name',
        'is_optional',
        'default',
        'default',
        'type_name',
        'is_optional',
        'default',
        'type_name',
        'is_optional',
        'default',
        'description',
        'type_name',
        'default',
        'description',
        'description',
        'description',
        'description',
        'description',
        'description',
        'description',
        'description',
        'description',
        'description'
    ]

# Generated at 2022-06-25 16:25:09.958984
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from pdoc.doc import Doc
    from pdoc.parser import parse

    nupydoc_str = r"""
    Parse the numpy-style docstring into its components.

    Parameters
    ----------
    text: str
        The docstring text.

    Returns
    -------
    parsed: Docstring
        The parsed docstring.

    Warnings
    --------
    This function isn't very well tested yet.
    """

    ret = NumpydocParser().parse(nupydoc_str)

    assert len(ret.meta) == 3
    assert ret.short_description == "Parse the numpy-style docstring into its components."



# Generated at 2022-06-25 16:25:12.603719
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    obj = NumpydocParser()
    # Testing
    test_case_0()

# Generated at 2022-06-25 16:25:21.637508
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = \
    """
    This is a docstring
    """
    docstring_object = NumpydocParser().parse(docstring)
    assert docstring_object.short_description == 'This is a docstring'


# Generated at 2022-06-25 16:25:31.986695
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 = ""
    docstring_0 = numpydoc_parser_0.parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    str_1 = "short description"
    docstring_1 = numpydoc_parser_0.parse(str_1)
    assert docstring_1.short_description == "short description"
    assert docstring_1.long_description is None
    str_2 = "short description\n\nlong description"
    docstring_2 = numpydoc_parser_0.parse(str_2)
    assert docstring_2.short_description == "short description"

# Generated at 2022-06-25 16:25:38.161673
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = """
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    test_1
    -----
    
    
    
    
    
    
    
    
    """
    # Test the case where the method is called with an empty argument
    # and returns a Docstring object
    numpydoc_parser_0.parse(text_0)


test_case_0()

# Generated at 2022-06-25 16:25:49.606488
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    input_text = """
    Unit test parse method

    :param param_name: This is an input param
    :type param_name: str

    :param param_name2: This is another input param
    :type param_name2: int

    :return: This is the return value
    :rtype: dict

    :raises ValueError: This is the exception that is raised
    :raises KeyError: This is another exception that is raised

    :deprecated: 0.12.0
        This is the deprecation warning
    """

# Generated at 2022-06-25 16:26:02.846113
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 0
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "Some text\n  that goes on for a while and\n  might have some\n  line breaks."
    assert numpydoc_parser_0.parse(text_0).short_description == "Some text"
    assert numpydoc_parser_0.parse(text_0).long_description == "that goes on for a while and\n  might have some\n  line breaks."
    assert numpydoc_parser_0.parse(text_0).meta == []
    assert numpydoc_parser_0.parse(text_0).blank_after_short_description == True
    assert numpydoc_parser_0.parse(text_0).blank_after_long_description == False

    #

# Generated at 2022-06-25 16:26:14.569639
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = '\n    Args:\n        a: int\n\n    Returns:\n        b: int\n    '
    output_0 = numpydoc_parser_0.parse(text_0)

    assert output_0.short_description == ''
    assert output_0.long_description is None
    assert output_0.blank_after_short_description == True
    assert output_0.blank_after_long_description == False

    assert output_0.meta[0].args == ['param', 'a']
    assert output_0.meta[0].description == 'int'
    assert output_0.meta[0].arg_name == 'a'
    assert output_0.meta[0].type_name == 'int'


# Generated at 2022-06-25 16:26:27.552485
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    # Single newline after short description
    docstring = numpydoc_parser.parse("short\nlong")
    assert (docstring.short_description == "short")
    assert (docstring.long_description == "long")
    assert (docstring.blank_after_short_description == True)
    assert (docstring.blank_after_long_description == False)
    # Two newlines after short description
    docstring = numpydoc_parser.parse("short\n\nlong")
    assert (docstring.short_description == "short")
    assert (docstring.long_description == "long")
    assert (docstring.blank_after_short_description == True)
    assert (docstring.blank_after_long_description == True)
    #

# Generated at 2022-06-25 16:26:28.583872
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case_0()



# Generated at 2022-06-25 16:26:39.827233
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    string1 = ""
    return_object_1 = parse(string1)
    assert return_object_1 != None
    assert return_object_1.meta != None
    assert len(return_object_1.meta) == 0
    

# Generated at 2022-06-25 16:26:43.969307
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Method parse not implemented"""
    raise NotImplementedError(
        "Method parse not implemented in class NumpydocParser"
    )


# Generated at 2022-06-25 16:26:49.764136
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 = NumpydocParser()
    str_1 = str_0.parse("A docstring.")
    assert str_1.short_description == "A docstring."


# Generated at 2022-06-25 16:26:58.428990
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = """This is a single line docstring."""
    expected = inspect.cleandoc(text)
    actual = numpydoc_parser_0.parse(text).short_description
    assert actual == expected, "test_NumpydocParser_parse failed"
    text = """
    This
    is
    a
    multi
    line
    docstring.
    """
    expected = inspect.cleandoc(text)
    actual = numpydoc_parser_0.parse(text).short_description
    assert actual == expected, "test_NumpydocParser_parse failed"

# Generated at 2022-06-25 16:27:09.188670
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = '''Compute line integrals over closed curves in N-space.

    Parameters
    ----------
    func : function
        Vector-valued function of one variable.
    x0, x1, ..., xn : float
        Lower and upper limits for each dimension.
    args : tuple
        Extra arguments to pass to function.

    Returns
    -------
    float
        The vector line integral.
    '''
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert type(docstring_0) is Docstring
    assert _clean_str(docstring_0.short_description) == 'Compute line integrals over closed curves in N-space.'

# Generated at 2022-06-25 16:27:18.745244
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring_0 = NumpydocParser().parse("")
    assert docstring_0 == Docstring()
    docstring_1 = NumpydocParser().parse("This is a short description.")
    assert docstring_1 == Docstring(
        short_description="This is a short description."
    )
    docstring_2 = NumpydocParser().parse(
        "A short description of this function.\n"
        "A longer, more\n"
        "detailed description of this function."
    )

# Generated at 2022-06-25 16:27:29.575104
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    print('Testing method parse of class NumpydocParser')
    docstring_0 = '''This is the shortest possible docstring.'''
    print('Testing parse of '+docstring_0)
    docstring_1 = numpydoc_parser_0.parse(docstring_0)
    if docstring_1.short_description != 'This is the shortest possible docstring.':
        raise AssertionError
    docstring_0 = '''This is the shortest possible docstring.
    '''
    print('Testing parse of '+docstring_0)
    docstring_1 = numpydoc_parser_0.parse(docstring_0)
    if docstring_1.short_description != 'This is the shortest possible docstring.':
        raise Ass

# Generated at 2022-06-25 16:27:41.633324
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    input = """This is a one-line summary.

This is a longer, second paragraph. It can contain
multiple sentences.

    This is a code example.

This is a paragraph after the code example.

This is a short test of numpydoc.
"""
    expected_output = Docstring(
        short_description='This is a one-line summary.',
        long_description="This is a longer, second paragraph. It can contain\nmultiple sentences.",
    )
    # Output without blank_after_long_description attribute
    output_0 = numpydoc_parser_0.parse(input)
    # Output with blank_after_long_description attribute
    output_1 = parse(input)
    assert output_0 == expected_output
    assert output_

# Generated at 2022-06-25 16:27:52.919509
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:28:03.991632
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    dstring_0  = numpydoc_parser_0.parse("""First line of
    the description.\n
    .. seealso::
       :mod:`fis`
       :mod:`fis2`


    :param p1: param 1
    :type p1: int

    :param p2: param 2
    :type p2: float

    :returns: x squared

    :raises ValueError: if x is negative
    """)

    assert(dstring_0.short_description == "First line of the description.")
    assert(dstring_0.long_description == ("""

    .. seealso::
       :mod:`fis`
       :mod:`fis2`

    """))

# Generated at 2022-06-25 16:28:06.943775
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    with open("test/test_numpydoc_parser.txt", "r") as f:
        text = f.read()

    print(parse(text))

# Generated at 2022-06-25 16:28:14.794429
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = """This is a docstring.

This is a long description of the function that spans multiple lines.

:param A: First parameter
:type A: string
:returns: nothing
:rtype: None

"""

# Generated at 2022-06-25 16:28:20.851044
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()


# Generated at 2022-06-25 16:28:28.068293
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "This is a multi-line docstring.\n\nIt has a long description."

    assert numpydoc_parser_0.parse(text_0) == Docstring()


# Generated at 2022-06-25 16:28:40.432808
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''A function with a docstring.

:param a: Parameter a.
:type a: int

:param b: Parameter b.
:type b: str

Return something.

:returns: Something.
'''

# Generated at 2022-06-25 16:28:42.674456
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    for i in range(100):
        t = Docstring()
        assert t == NumpydocParser().parse(t)


# Generated at 2022-06-25 16:28:53.762041
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
  numpydoc_parser_0 = NumpydocParser()
  text_0 = """
  This is a very short description

  This is a much longer description.

  Parameters
  ----------
  x : int
      This is the first parameter.

  y : str, optional
      This is the second parameter.

  Returns
  -------
  bool
      True if everything went well, False otherwise.

  Raises
  ------
  ValueError
      If x is too high for some reason.
  """
  ret = numpydoc_parser_0.parse(text_0)
  assert ret.short_description == "This is a very short description"
  assert ret.blank_after_short_description == False
  assert ret.long_description == "This is a much longer description."
  assert ret.blank_after_long_description

# Generated at 2022-06-25 16:28:58.905847
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring = numpydoc_parser_0.parse("""\
        test function"""
    )
    assert docstring.short_description == "test function"
    assert docstring.long_description == None
    assert docstring.meta == []



# Generated at 2022-06-25 16:29:05.202244
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    result = numpydoc_parser_0.parse(" 1 2 3 4 5 6 7 8 9 10 ")
    assert result.short_description == "1 2 3 4 5 6 7 8 9 10"


# Generated at 2022-06-25 16:29:17.432194
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from itertools import chain
    numpydoc_parser_1 = NumpydocParser()
    numpydoc_parser_2 = NumpydocParser()
    numpydoc_parser_3 = NumpydocParser()
    numpydoc_parser_4 = NumpydocParser()
    numpydoc_parser_5 = NumpydocParser()
    numpydoc_parser_6 = NumpydocParser()
    numpydoc_parser_7 = NumpydocParser()
    numpydoc_parser_8 = NumpydocParser()
    numpydoc_parser_9 = NumpydocParser()
    numpydoc_parser_10 = NumpydocParser()
    numpydoc_parser_11 = NumpydocParser()
    numpyd

# Generated at 2022-06-25 16:29:30.098827
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring_text = """
    TODO: Longer description of function.

    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2

    Returns
    -------
    int
        Description of return value

    Raises
    ------
    ValueError
        Description of exception

    Examples
    --------
    >>> print([i for i in example_generator(4)])
    [0, 1, 2, 3]

    References
    ----------
    TODO

    Warnings
    --------
    TODO
    """
    docstring = numpydoc_parser_0.parse(docstring_text)

# Generated at 2022-06-25 16:29:31.426098
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert isinstance(NumpydocParser().parse(""), Docstring)

# Generated at 2022-06-25 16:29:37.791410
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()

# Testing the function parse

# Generated at 2022-06-25 16:29:50.461439
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:30:00.474425
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    argument_0 = """
    - b :
        - c :
            d
            e
    - f :
        g
        h
    """
    return_value_0 = numpydoc_parser_0.parse(argument_0)
    assert return_value_0.short_description == "-"
    assert return_value_0.long_description is None
    assert return_value_0.blank_after_short_description
    assert return_value_0.blank_after_long_description
    assert return_value_0.meta == [
        DocstringMeta(["param", "b"], description="c"),
        DocstringMeta(["param", "f"], description="g\n\nh"),
    ]



# Generated at 2022-06-25 16:30:13.736291
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = parser.parse(
        """
        This function computes something or other.

        Parameters
        ----------
        x : float
            The x coordinate.
        y : float
            The y coordinate.

        Returns
        -------
        float
            The computed value.
    """
    )
    assert docstring.short_description == "This function computes something or other."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 2
    for meta in docstring.meta:
        assert meta.args[0] in ["param", "returns"]
    docstring.meta[0].args[0] == "param"
   

# Generated at 2022-06-25 16:30:24.528809
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    section_dict = {}
    numpydoc_parser_1 = NumpydocParser(section_dict)

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # Expected Docstring object
    expected = Docstring()
    expected.short_description = "Parses a numpy-style docstring."
    expected.blank_after_short_description = True
    expected.blank_after_long_description = False
    expected.long_description = "It does not parse parts of a docstring which are not numpy-syntax."
    ret = numpydoc_parser_1.parse(numpydoc_parser_1.__doc__)
    assert (expected == ret)


# Generated at 2022-06-25 16:30:34.833034
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # test case 0
    numpydoc_parser_0 = NumpydocParser()
    input_0 = ''
    expected_output_0 = Docstring()
    actual_output_0 = numpydoc_parser_0.parse(input_0)
    assert actual_output_0 == expected_output_0, actual_output_0

    # test case 1
    numpydoc_parser_1 = NumpydocParser()
    input_1 = 'short-line\n\nlong-line'
    expected_output_1 = Docstring()
    actual_output_1 = numpydoc_parser_1.parse(input_1)
    assert actual_output_1 == expected_output_1, actual_output_1

    # test case 2
    numpydoc_parser_2 = Numpydoc

# Generated at 2022-06-25 16:30:36.840175
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # parse is a method of class NumpydocParser
    pass

# Generated at 2022-06-25 16:30:48.364279
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_1 = ""
    ret_1 = numpydoc_parser_0.parse(text_1)
    assert isinstance(ret_1, Docstring)
    assert ret_1.short_description is None
    assert ret_1.long_description is None
    assert ret_1.blank_after_short_description is False
    assert ret_1.blank_after_long_description is False
    assert ret_1.meta is not None
    assert len(ret_1.meta) == 0

    text_2 = """
    Description
    Description
    """
    ret_2 = numpydoc_parser_0.parse(text_2)
    assert ret_2.short_description == "Description"
    assert ret_2.long_description == "Description"
    assert ret_2.blank_after_short_description

# Generated at 2022-06-25 16:30:59.020255
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    input_text = '''
    Short description.

    Long description.

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    '''
    result = NumpydocParser().parse(input_text)
    assert result.short_description == 'Short description.'
    assert result.long_description == 'Long description.'
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert len(result.meta) == 2
    assert result.meta[0].args == ['param', 'arg_name']
    assert result.meta[0].arg_name == 'arg_name'


# Generated at 2022-06-25 16:31:09.000585
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case_0()
#     text = inspect.cleandoc(
#         """
#         Args:

#             new_base (pathlib.Path): Path to directory where the index will be created.
#             force (bool): Force creation, even if the index already exists.
#         """
#     )
#     parsed = NumpydocParser().parse(text)
#     assert parsed.short_description is None
#     assert parsed.long_description is None
#     assert parsed.meta == [
#         DocstringParam(
#             args=["param", "new_base"],
#             description="Path to directory where the index will be created.",
#             type_name="pathlib.Path",
#         ),
#         DocstringParam(
#             args=["param", "force"],
#             description="Force creation,

# Generated at 2022-06-25 16:31:17.231420
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Test the method parse from the class NumpydocParser"""

    numpydoc_parser_1 = NumpydocParser()
    assert numpydoc_parser_1.parse("") == Docstring()

# Generated at 2022-06-25 16:31:26.466337
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    numpydoc_parser_0 = NumpydocParser()
    assert numpydoc_parser_0.parse("") == Docstring()

# Generated at 2022-06-25 16:31:29.773982
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = ""
    ret = numpydoc_parser_0.parse(text)
    print(ret)

test_NumpydocParser_parse()

# Generated at 2022-06-25 16:31:41.140385
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser.parse(NumpydocParser, "") == Docstring()

# Generated at 2022-06-25 16:31:50.021978
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    result = parser.parse("""\
    Parse the numpy-style docstring into its components.

    :returns: parsed docstring
    """)

    assert result.short_description == "Parse the numpy-style docstring into its components."
    assert result.long_description == None
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert result.meta == [DocstringMeta(['returns'], description='parsed docstring')]


# Generated at 2022-06-25 16:31:50.647928
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert True


# Generated at 2022-06-25 16:31:58.327013
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test for an empty string
    docstring = numpydoc_parser_0.parse("")

    assert docstring.short_description == None, "Expected None but got \"%s\"" % docstring.short_description
    assert docstring.blank_after_short_description == False, "Expected False but got \"%s\"" % docstring.blank_after_short_description
    assert docstring.long_description == None, "Expected None but got \"%s\"" % docstring.long_description
    assert docstring.blank_after_long_description == False, "Expected False but got \"%s\"" % docstring.blank_after_long_description
    assert len(docstring.meta) == 0, "Expected 0 but got \"%s\"" % len(docstring.meta)

    # Test for a simple

# Generated at 2022-06-25 16:32:10.607778
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """foo
    bar
    args : int, optional
        foo bar
    baz : str, optional
        baz qux
    raises : ValueError
        if foo
        """

# Generated at 2022-06-25 16:32:23.375354
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()

# Generated at 2022-06-25 16:32:34.132573
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Test for NumpydocParser.parse
    # test case 0
    text = '''
    Return docstring from object

    :param obj: module, class, function or method
    :type obj: object
    :returns: docstring
    :rtype: string
    '''

# Generated at 2022-06-25 16:32:55.659448
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = """
    shorten: str = None
        The name of a shortening scheme to apply.
    format: str = '{type}({value})'
        A template to use for rendering.
    """
    docstring = numpydoc_parser_0.parse(text)
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False

# Generated at 2022-06-25 16:33:03.822049
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    numpydoc_parser_1 = NumpydocParser()
    assert numpydoc_parser_1.parse("this is a docstring that has no sections") \
        == Docstring(
            short_description = "this is a docstring that has no sections",
            long_description = None,
            blank_after_short_description = False,
            blank_after_long_description = False,
            meta = [],
        )

