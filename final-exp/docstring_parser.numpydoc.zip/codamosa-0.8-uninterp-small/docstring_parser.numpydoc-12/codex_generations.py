

# Generated at 2022-06-25 16:23:50.324184
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydocParser = NumpydocParser()
    docstring = numpydocParser.parse('/{ve:3')
    assert docstring.short_description == '/{ve:3'
    assert len(docstring.meta) == 0
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-25 16:23:58.888001
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = ' '
    str_1 = '/{ve:3'
    str_2 = ' '
    str_3 = '/{ve:3'
    str_4 = ' '
    str_5 = '/{ve:3'
    str_6 = ' '
    parser = NumpydocParser()
    # . . . . . . . . . . . . . . . . . .
    # test_case_0

    docstring_0 = parse(str_0)
    # assert that docstring_0 is not None
    assert(docstring_0 is not None)
    # assert that type(docstring_0) is Docstring
    assert(type(docstring_0) is Docstring)
    # assert that docstring_0.short_description is None

# Generated at 2022-06-25 16:24:01.380514
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = '{ve:3}'
    docstring_0 = NumpydocParser().parse(str_0)
    assert docstring_0.short_description == '{ve:3}'


# Generated at 2022-06-25 16:24:11.246196
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 1
    str_1 = '{\"card\": \"Ace\", \"value\": 1}'
    docstring_1 = parse(str_1)

    assert type(docstring_1) == Docstring
    assert docstring_1.short_description == '{\"card\": \"Ace\", \"value\": 1}'
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == False

    assert len(docstring_1.meta) == 0


    # Test case 2
    str_2 = 'Return the square value of the input number'
    docstring_2 = parse(str_2)

    assert type(docstring_2) == Docstring
    assert docstring_2.short_

# Generated at 2022-06-25 16:24:13.416187
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert(True)

################################################################################

if __name__ == "__main__":
    test_NumpydocParser_parse()
    test_case_0()

# Generated at 2022-06-25 16:24:24.879321
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Setup
    str_0 = 'Test string for docstring'
    str_1 = 'Test string for docstring  \n    \n    '
    str_2 = 'Test string for docstring  \n    '
    str_3 = 'Test string for docstring  \n '
    str_4 = 'Test string for docstring  \n '
    str_5 = 'Test string for docstring  \n \n '
    str_6 = 'Test string for docstring  \n\n '
    str_7 = 'Test string for docstring  \n  \n '
    str_8 = 'Test string for docstring  \n \n \n '
    str_9 = 'Test string for docstring  \n \n \n    '
    str_10 = 'Test string for docstring  \n \n '

# Generated at 2022-06-25 16:24:33.262562
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = '/{ve:3'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:24:34.455201
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_case_0()

# Generated at 2022-06-25 16:24:44.734200
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = ''
    docstring = NumpydocParser().parse(str_0)
    assert (isinstance(docstring._sections, dict))
    assert (docstring.short_description == None)
    assert (docstring.long_description == None)
    assert (docstring.blank_after_short_description == False)
    assert (docstring.blank_after_long_description == False)
    str_1 = 'This is a test string\nfor numpydoc parsing'
    docstring = NumpydocParser().parse(str_1)
    assert (isinstance(docstring._sections, dict))
    assert (docstring.short_description == 'This is a test string')
    assert (docstring.long_description == 'for numpydoc parsing')

# Generated at 2022-06-25 16:24:52.450541
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # setup
    parser = NumpydocParser()

    # exercise
    docstring_1 = parser.parse('/{ve:3')
    docstring_2 = parser.parse('/{ve:3\n')
    docstring_3 = parser.parse('/{ve:3\n\n')
    docstring_4 = parser.parse('/{ve:3\n\n\n')

    # verify
    assert docstring_1.short_description == '/{ve:3'
    assert docstring_2.short_description == '/{ve:3'
    assert docstring_3.short_description == '/{ve:3'
    assert docstring_4.short_description == '/{ve:3'

# Generated at 2022-06-25 16:25:15.060030
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring_0 = parse('/{ve:3')
    assert len(docstring_0.meta) == 0
    assert docstring_0.short_description == '/{ve:3'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False

    docstring_1 = parse('/{ve:3\n')
    assert len(docstring_1.meta) == 0
    assert docstring_1.short_description == '/{ve:3'
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is True
    assert docstring_1.blank_after_long_description is False


# Generated at 2022-06-25 16:25:21.002451
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser_0 = NumpydocParser()
    str_0 = 'E'
    docstring_0 = parser_0.parse(str_0)
    assert docstring_0.short_description == 'E'


# Generated at 2022-06-25 16:25:27.358920
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Set up the test object
    parser = NumpydocParser()

    # Set up the test arguments
    str_0 = '/{ve:3'

    # Invoke the method
    result = parser.parse(str_0)

    # Check the type
    assert type(result) is Docstring

    # Check the attributes
    assert result.short_description is None
    assert result.blank_after_short_description is False
    assert result.long_description is None
    assert result.blank_after_long_description is False
    assert result.meta == []


# Generated at 2022-06-25 16:25:37.236369
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser_0 = NumpydocParser()
    str_0 = '!This is a simple docstring.'
    docstring_0 = parser_0.parse(str_0)
    str_1 = '!This is a simple docstring.\n\n'
    docstring_1 = parser_0.parse(str_1)
    str_2 = '!This is a simple docstring.\n\n!\n'
    docstring_2 = parser_0.parse(str_2)
    str_3 = '!This is a simple docstring.\n\n!\n\n'
    docstring_3 = parser_0.parse(str_3)
    str_4 = '!This is a simple docstring.\n\n!\n\n!\n'
    docstring_4 = parser_

# Generated at 2022-06-25 16:25:38.548083
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # TODO write tests
    pass



# Generated at 2022-06-25 16:25:49.905450
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:26:02.888975
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    result = parser.parse(
        """
            Some description
            Some description

            Parameters
            ----------
            param : type
                description
            param2
                description2

            Returns
            -------
            str
                some return

            See Also
            --------
            some see also

            Deprecation Warning
            ---------------------------
            some deprecation
            """
    )
    print(result.meta)

    # assert result.meta[0].description == "some deprecation"

    # assert result.meta[1].description == "some see also"

    # assert result.meta[2].description == "some return"

    # assert result.meta[2].type_name == "str"

    # assert result.meta[3].description == "description2"

    # assert result.meta[

# Generated at 2022-06-25 16:26:05.713688
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # We do not need to test this method because it is extremely basic 
    # and we use it in tests for other methods
    pass


# Generated at 2022-06-25 16:26:10.028374
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_0 = 'a'
    numpydocParser_0 = NumpydocParser(DEFAULT_SECTIONS)
    docstring_0 = numpydocParser_0.parse(text_0)
    assert str(docstring_0) == 'Docstring()'

# Generated at 2022-06-25 16:26:19.281660
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:26:31.316481
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    np = NumpydocParser()
    docstring = np.parse('')
    assert docstring is None or docstring.short_description is None
    assert docstring is None or docstring.long_description is None
    assert docstring is None or docstring.blank_after_short_description is None
    assert docstring is None or docstring.blank_after_long_description is None

    docstring = np.parse('short description')
    assert docstring.short_description == 'short description'
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is None

    docstring = np.parse('short\ndescription')
    assert docstring.short_description == 'short'
    assert docstring.long_description == 'description'

# Generated at 2022-06-25 16:26:37.898441
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'a'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'a'
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.long_description == None

if __name__ == '__main__':
    test_NumpydocParser_parse()

# Generated at 2022-06-25 16:26:47.616542
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test case 0
    str_0 = '/{ve:3'
    docstring_0 = parse(str_0)

    # Test case 1
    str_1 = '/{ve::3'
    docstring_1 = parse(str_1)

    # Test case 2
    str_2 = '/{ve::3'
    docstring_2 = parse(str_2)

    # Test case 3
    str_3 = '/{ve::3'
    docstring_3 = parse(str_3)

    # Test case 4
    str_4 = '/{ve::3'
    docstring_4 = parse(str_4)


# Generated at 2022-06-25 16:26:56.238126
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = '''
    parses the docstring of a python object according to the numpydoc docstring standard

    Parameters
    ----------
    x: object
        The object to parse

    Returns
    -------
    the parsed docstring

    See Also
    --------
    https://numpydoc.readthedocs.io/en/latest/format.html

    >>> from numpydoc.parse import parse

    >>> class Foo(object):
    ...     '''

# Generated at 2022-06-25 16:27:02.738519
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = '/{ve:3'
    docstring = parser.parse(text)
    assert docstring.short_description == '/{ve:3'
    assert docstring.blank_after_short_description == False
    assert docstring.long_description == None

    text = '/{ve:3\n'
    docstring = parser.parse(text)
    assert docstring.short_description == '/{ve:3'
    assert docstring.blank_after_short_description == True
    assert docstring.long_description == None

    text = '/{ve:3\n\n'
    docstring = parser.parse(text)
    assert docstring.short_description == '/{ve:3'
    assert docstring.blank_after_short_description == True

# Generated at 2022-06-25 16:27:11.218790
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    NumpydocParser.parse: Test case 0
    """
    # Test case 0
    str_0 = '''
    """
    Parameters
    ----------
    a : int
        a is an integer.
    b : float, optional
        b is a float, defaults to 0.
    """
    '''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == ''
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 3
    assert docstring_0.meta[0].args == ['param', 'a']
    assert docstring_0.meta[0].description

# Generated at 2022-06-25 16:27:13.802927
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Setup
    instance = NumpydocParser()

    # Invoke method
    result = instance.parse()

    # Check for absence of exceptions
    assert True


# Generated at 2022-06-25 16:27:15.691948
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = '{ve:3}'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:27:18.754683
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    try:
        NumpydocParser_instance = NumpydocParser()
        NumpydocParser_instance.parse('/{ve:3')
        assert True
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-25 16:27:20.762640
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = '/{ve:3'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:27:29.336561
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    input_tuple = ('Yields', 'yields')
    input_section = YieldsSection(*input_tuple)
    assert type(input_section) is YieldsSection
    assert input_section._KVSection__title == 'Yields'
    assert input_section._KVSection__key == 'yields'
    assert input_section.title == 'Yields'
    assert input_section.key == 'yields'


# Generated at 2022-06-25 16:27:40.797036
# Unit test for constructor of class _KVSection
def test__KVSection():
    str_0 = '/{ve:3'
    docstring_0 = parse(str_0)
    # Testing for expected AttributeError
    try:
        test_0 = docstring_0.meta.pop().args
    except AttributeError:
        pass
    else:
        # If no exception was raised, this test fails
        raise AssertionError
    # Testing for unexpected AttributeError
    try:
        test_1 = docstring_0.meta.append("dummy string").meta
    except AttributeError:
        # If an exception was raised, this test fails
        raise AssertionError
    else:
        assert test_1 == "[dummy string]"
    

# Generated at 2022-06-25 16:27:52.471971
# Unit test for constructor of class _KVSection
def test__KVSection():
    print("Testing _KVSection Class:")
    try:
        section = _KVSection("Parameters", "param")
    except Exception as e:
        print(e)
        assert False
    assert section.title == "Parameters"

# Generated at 2022-06-25 16:28:03.425066
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = "\n"
    call_0 = NumpydocParser()
    docstring_0 = call_0.parse(str_0)
    assert docstring_0.long_description is None
    assert docstring_0.short_description is None
    assert docstring_0.meta == []
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.blank_after_short_description is False

    str_1 = "Hello.\n"
    call_1 = NumpydocParser()
    docstring_1 = call_1.parse(str_1)
    assert docstring_1.long_description is None
    assert docstring_1.short_description == "Hello."
    assert docstring_1.meta == []
    assert docstring_1.blank_after

# Generated at 2022-06-25 16:28:06.458885
# Unit test for method parse of class Section
def test_Section_parse():
    text_0 = 'a simple str'
    p1 = Section('', '').parse(text_0)
    assert next(p1).description == 'a simple str'


# Generated at 2022-06-25 16:28:08.623765
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    x = _SphinxSection('__init__', 'Parameters')
    x.title
    x.key
    x.title_pattern


# Generated at 2022-06-25 16:28:12.361077
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    str_0 = "1.0 \n old is deprecated, use new instead!"
    section_0 = DeprecationSection('deprecation', 'deprecation')
    result_0 = section_0.parse(str_0)
    assert result_0 == '1.0 old is deprecated, use new instead!'


# Generated at 2022-06-25 16:28:16.763860
# Unit test for constructor of class _KVSection
def test__KVSection():
    section = _KVSection('a', 'b')
    assert section.title == 'a'
    assert section.key == 'b'
    # Unit test for title_pattern of class _KVSection
    assert section.title_pattern == '^(a)\s*?\n---*\s*$'


# Generated at 2022-06-25 16:28:24.354837
# Unit test for method parse of class Section
def test_Section_parse():
    title = "Parameters"
    key = "param"
    section = Section(title, key)
    text = "arg_name\n\targ_description\narg_2 : type, optional\n\tdescriptions can also span...\n\t... multiple lines"
    results = section.parse(text)
    for result in results:
        assert isinstance(result, DocstringMeta)


# Generated at 2022-06-25 16:28:28.717498
# Unit test for constructor of class ParamSection
def test_ParamSection():
    section = ParamSection('Parameters', 'param')
    assert section.title == 'Parameters'


# Generated at 2022-06-25 16:28:42.636115
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_0 = 'Returns the imaginary part of a complex (or real) scalar.'
    expected_result_0 = {'short_description': 'Returns the imaginary part of a complex (or real) scalar.',
                         'blank_after_short_description': True,
                         'long_description': None,
                         'blank_after_long_description': None,
                         'meta': [DocstringMeta(args=['returns'],
                                                description=None,
                                                type_name=None,
                                                default=None,
                                                is_optional=None)]}
    result_0 = NumpydocParser().parse(text_0)
    assert result_0 == expected_result_0


# Generated at 2022-06-25 16:28:53.017401
# Unit test for method parse of class Section
def test_Section_parse():
    import re
    import inspect
    str_0 = """
        /{
            {
            }
        """
    lst_0 = re.finditer('/',str_0)
    for match, next_match in _pairwise(lst_0, 'end'):
        print(match, end=' ')
        print(next_match, end=' ')
        print( type(next_match)) # next_match is <class 're.Match'>
        start = match.end()
        end = next_match.start() if next_match != 'end' else None
        print(end)
        value = str_0[start:end]
        print(inspect.cleandoc(value))


if __name__ == '__main__':
    test_Section_parse()

# Generated at 2022-06-25 16:28:58.133039
# Unit test for constructor of class ParamSection
def test_ParamSection():
    title = 'Parameter'
    key = 'parameter'
    p = ParamSection(title, key)
    if p.title != title:
        raise RuntimeError
    if p.key != key:
        raise RuntimeError
    if p.title_pattern != 'Parameter':
        raise RuntimeError


# Generated at 2022-06-25 16:29:05.916145
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    str_0 = '/{ve:3'
    str_1 = 'see `as_matrix` for more details.'
    obj_0 = _KVSection(str_0, str_1)
    str_2 = 'sd:1'
    str_3 = 'See `as_matrix` for more details'
    assert obj_0.parse(str_2) == str_3


# Generated at 2022-06-25 16:29:14.569114
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    dep = DeprecationSection("deprecated", "deprecation")
    text = "  1.2.3 \n some description"
    for meta in dep.parse(text):
        assert(meta.args == [dep.key])
        assert(meta.description == "some description")
        assert(meta.version == "1.2.3")
    text = "  1.2.3 "
    for meta in dep.parse(text):
        assert(meta.args == [dep.key])
        assert(meta.description == "")
        assert(meta.version == "1.2.3")


# Generated at 2022-06-25 16:29:20.445979
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    some_str = "/{some:"
    some_str = some_str.strip()
    match = RETURN_KEY_REGEX.match(some_str)
    assert match
    if match:
      return_name, type_name = match.group("name"), match.group("type")
    assert return_name == "some"
    assert type_name == ""



# Generated at 2022-06-25 16:29:23.588273
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Create Instance
    obj_0 = _KVSection(title = str_1, key = str_0)

    # Test method parse
    obj_0.parse(text = str_2)


# Generated at 2022-06-25 16:29:24.797067
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    _SphinxSection('xx')


# Generated at 2022-06-25 16:29:27.516901
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    section = Section("Hello", "hello")
    parser.add_section(section)
    assert parser.sections["Hello"] == section


# Generated at 2022-06-25 16:29:35.982979
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r1 = RaisesSection("Raises", "raises")
    # expected output of test
    r1_out = inspect.cleandoc('Raises')
    r2 = RaisesSection("Raise", "raises")
    # expected output of test
    r2_out = inspect.cleandoc('Raise')
    # expected output of test
    r3_out = inspect.cleandoc('Raises\nRaise')
    r3 = RaisesSection(r1_out, r2_out)
    return


# Generated at 2022-06-25 16:29:48.378304
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Test case 0
    s = '.title: something \n Possibly over multiple lines'
    docstring = parse(s)



# Generated at 2022-06-25 16:29:52.428908
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
   str_0 = "Deprecated since version 2.4:\n    Use ``bar`` instead."
   section_0 = DeprecationSection("deprecated", "deprecation")
   section_0.parse(str_0)


# Generated at 2022-06-25 16:29:54.810213
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test Case 0
    str_0 = '\n    test_parse\n    ----------\n    Test method parse of class NumpydocParser\n    '
    docstring_0 = parse(str_0)

# Run tests

if __name__ == "__main__":
    test_case_0()
    test_NumpydocParser_parse()

# Generated at 2022-06-25 16:29:55.923467
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    ReturnsSection()


# Generated at 2022-06-25 16:29:57.430401
# Unit test for constructor of class _KVSection
def test__KVSection():
    from .common import DocstringMeta
    DocstringMeta()


# Generated at 2022-06-25 16:29:59.927577
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    np_0 = NumpydocParser()
    assert(hasattr(np_0, 'sections'))


# Generated at 2022-06-25 16:30:13.319374
# Unit test for function parse

# Generated at 2022-06-25 16:30:16.347102
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    try:
        parser_0 = NumpydocParser(sections={})
    except Exception as err:
        print(err)
        return False
    return True


# Generated at 2022-06-25 16:30:25.946773
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    m_KV_REGEX = re.compile(r'^[^\s].*$', flags=re.M)
    m_KV_REGEX.match('match_0')
    m_KV_REGEX.match('match_1')
    m_text = 'match_0\nmatch_1'
    m_text_0 = 'match_1'
    x = itertools.zip_longest(m_KV_REGEX.finditer(m_text), m_KV_REGEX.finditer(m_text_0), fillvalue=None)
    m_match, m_next_match = next(x)
    m_start = m_match.end()
    m_end = m_next_match.start() if m_next_match is not None else None
    m_

# Generated at 2022-06-25 16:30:28.222600
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = '/{ve:3'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:30:50.697632
# Unit test for constructor of class ParamSection
def test_ParamSection():
    str_0 = '/{ve:3'
    ParamSection('Parameters', 'param')


# Generated at 2022-06-25 16:30:54.026401
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text_0 = '_____-case-___u_n_i_t_-___'
    section_0 = RaisesSection('_____', '___')


# Generated at 2022-06-25 16:30:55.567316
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    title = "Returns"
    key = "returns"
    returns_section_0 = ReturnsSection(title, key)



# Generated at 2022-06-25 16:30:56.979454
# Unit test for constructor of class _KVSection
def test__KVSection():
    test_instance_0 = _KVSection('x', 'm')

# Generated at 2022-06-25 16:31:08.391507
# Unit test for function parse
def test_parse():
    # ensure trailing whitespace is removed
    str_0 = 'Lorem ipsum dolor sit amet.\n\n'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Lorem ipsum dolor sit amet.'
    assert docstring_0.blank_after_short_description == True

    str_1 = 'Lorem ipsum dolor sit amet.\n\n\t'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == ''
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.long_description == None

    str_2 = 'Lorem ipsum dolor sit amet.\n\n\n'
    docstring_2 = parse

# Generated at 2022-06-25 16:31:18.534894
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    str_0 = 'test'
    doc_0 = parser.parse(str_0)
    assert(doc_0.short_description == 'test')
    assert(doc_0.long_description == None)
    assert(len(doc_0.meta) == 0)
    
    str_1 = '''test
    some long description'''
    doc_1 = parser.parse(str_1)
    assert(doc_1.short_description == 'test')
    assert(doc_1.long_description == 'some long description')
    assert(len(doc_1.meta) == 0)
    
    str_2 = '''test
    
    some long description'''
    doc_2 = parser.parse(str_2)

# Generated at 2022-06-25 16:31:31.220400
# Unit test for method parse of class Section

# Generated at 2022-06-25 16:31:35.721510
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("deprecated", "deprecation")
    assert section.title == "deprecated"
    assert section.key == "deprecation"


# Generated at 2022-06-25 16:31:39.750319
# Unit test for function parse
def test_parse():
    from docstrings import NumpydocParser

    str_0 = '{ve'
    docstring_0 = NumpydocParser().parse(str_0)
    docstring_expected = Docstring()
    assert docstring_0 == docstring_expected



# Generated at 2022-06-25 16:31:44.266995
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    str_0 = '/{ve:3'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:32:29.439903
# Unit test for constructor of class Section
def test_Section():
    test_case_0()


# Generated at 2022-06-25 16:32:30.857816
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    str_0 = """pass"""
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:32:41.311819
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    str_0 = 'test short'
    res_0 = Docstring(short_description='test short')
    res = NumpydocParser().parse(str_0)
    assert res == res_0
    str_1 = 'test\n\nlong'
    res_1 = Docstring(short_description='test',
                                 blank_after_short_description=True,
                                 blank_after_long_description=True,
                                 long_description='long')
    res = NumpydocParser().parse(str_1)
    assert res == res_1
    str_2 = 'test\nlong'
    res_2 = Docstring(short_description='test',
                                 blank_after_short_description=False,
                                 blank_after_long_description=False,
                                 long_description='long')

# Generated at 2022-06-25 16:32:44.060452
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section_1 = ReturnsSection('Returns', 'returns')
    assert section_1.title == 'Returns'
    assert section_1.key == 'returns'
    assert section_1.title_pattern == '^Returns\\s*?\\n={2,}\\s*$'
    assert section_1.is_generator == False

# Generated at 2022-06-25 16:32:55.824648
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    # These cases will cover all possible combinations of the constructor arguments.
    # Case 0: title and key are strings
    title_0 = "deprecated"
    key_0 = "deprecation"
    try:
        DeprecationSection(title_0, key_0)
    except ValueError:
        assert 0

    # Case 1: title is a string, key is an integer
    title_1 = "deprecated"
    key_1 = 9
    try:
        DeprecationSection(title_1, key_1)
    except ValueError:
        assert 0
    
    # Case 2: title is an integer, key is a string
    title_2 = 0
    key_2 = "deprecation"

# Generated at 2022-06-25 16:33:02.095106
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    str_0 = '/{ve:3'
    title_1 = '{ve:3'
    key_1 = '{ve:3'
    obj_0 = _SphinxSection(str_0, key_1)
    assert obj_0.title == title_1
    assert obj_0.key == key_1
