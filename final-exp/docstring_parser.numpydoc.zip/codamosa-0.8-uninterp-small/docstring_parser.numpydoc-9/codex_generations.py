

# Generated at 2022-06-25 16:23:45.095949
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = ""
    assert NumpydocParser().parse(text) == Docstring()

# Generated at 2022-06-25 16:23:49.779341
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "A function that adds one.\n\n    Examples\n    --------\n    >>> add_one(2)\n    3\n\n"
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0 == expected_0


# Generated at 2022-06-25 16:23:55.068792
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:24:03.656701
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():

    # Input arguments for method parse
    name = "deprecated"
    self = DeprecationSection(DeprecationSection, name)
    text = 'deprecated'

    # Output argument of method parse
    self.parse(text)


# Generated at 2022-06-25 16:24:13.456967
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
	# Test cases from numpydoc README
	assert_Parse_Equals(
		"Single line only",
		"Single line only",
		None,
		[]
	)

	assert_Parse_Equals(
		"Single line only.\n",
		"Single line only",
		None,
		[]
	)

	assert_Parse_Equals(
		"Single line only.\n\n",
		"Single line only",
		None,
		[],
		True,
		True
	)


# Generated at 2022-06-25 16:24:24.876196
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Setup
    numpydoc_parser = NumpydocParser()
    text = """Test :class:`NumpydocParser` class.

    :param a: A number for testing.
    :type a: float
    :param b: Another number for testing.
    """

    # Act
    docstring = numpydoc_parser.parse(text)

    # Assert
    assert docstring.short_description == "Test :class:`NumpydocParser` class."
    assert (
        docstring.long_description
        == ":param a: A number for testing.\n:type a: float\n"
        + ":param b: Another number for testing."
    )
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True


# Generated at 2022-06-25 16:24:38.015347
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = 'funcname(arg1, arg2)\n\n  Short description.\n\n  Long description\n  goes on and on.\n'
    docstring_0 = numpydoc_parser_0.parse(text_0)
    assert docstring_0.short_description == 'Short description.'
    assert docstring_0.long_description == 'Long description\ngoes on and on.'
    assert docstring_0.blank_after_short_description
    assert docstring_0.blank_after_long_description
    assert len(docstring_0.meta) == 0

# Generated at 2022-06-25 16:24:39.857942
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecated", "deprecation").parse("Version 0.0.0\nDesc\nMore desc")


# Generated at 2022-06-25 16:24:45.892634
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = 'This is a test module for numpydoc. '
    result = numpydoc_parser_0.parse(text_0)
    assert result == Docstring(description='This is a test module for numpydoc. ', meta=[])
    text_1 = 'This is a test module for numpydoc. '
    result = numpydoc_parser_0.parse(text_1)
    assert result == Docstring(description='This is a test module for numpydoc. ', meta=[])
    text_2 = 'This is a test module for numpydoc. '
    result = numpydoc_parser_0.parse(text_2)

# Generated at 2022-06-25 16:24:51.583228
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = ".. deprecated:: 1.5"
    docstring_deprecated_0 = numpydoc_parser_0.sections['deprecated'].parse(text_0)
    assert docstring_deprecated_0[0].version == "1.5"
    assert docstring_deprecated_0[0].description == None
    assert docstring_deprecated_0[0].args == ['deprecation']

  

# Generated at 2022-06-25 16:25:08.756793
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    text_1 = "test_text"
    numpydoc_parser_1.parse(text_1)

    numpydoc_parser_2 = NumpydocParser()
    text_2 = "test_text\n\n"
    numpydoc_parser_2.parse(text_2)

    numpydoc_parser_3 = NumpydocParser()
    text_3 = "test_text\n\n\n"
    numpydoc_parser_3.parse(text_3)


# Generated at 2022-06-25 16:25:15.154276
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Create a setup
    numpydoc_parser_1 = NumpydocParser()
    docstringDeprecated_0 = DocstringDeprecated()
    docstringDeprecated_1 = DocstringDeprecated()
    # Call the method without a argument
    try:
        # Assign to docstringDeprecated_1
        docstringDeprecated_1 = numpydoc_parser_1.parse(docstringDeprecated_0)
    except:
        docstringDeprecated_1 = None
    return docstringDeprecated_1


# Generated at 2022-06-25 16:25:19.244340
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    assert numpydoc_parser_0.parse('') == 'nothing'

# Generated at 2022-06-25 16:25:22.440563
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
  # Example from numpydoc
  text = """.. deprecated:: 0.3.1
    This is the new deprecation warning for foo"""

  warning = list(DeprecationSection("deprecated", "deprecation").parse(text))[0]

  assert warning.version == "0.3.1"
  assert warning.description == """This is the new deprecation warning for foo"""



# Generated at 2022-06-25 16:25:29.552298
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    text = "\n    .. deprecated:: 0.14\n    \n    Deprecated\n    "
    ret = numpydoc_parser_0.sections['deprecated'].parse(text)
    assert ret == [DocstringDeprecated(
        args=['deprecated'],
        description='Deprecated',
        version='0.14')]



# Generated at 2022-06-25 16:25:38.777986
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert (
        parse("""Return a boolean array with True inside notnull cells and False outside."""
              ).long_description
        == "Return a boolean array with True inside notnull cells and False outside."
    )

    assert (
        parse("""Return a boolean array with True inside notnull cells and False outside."""
              ).short_description
        == "Return a boolean array with True inside notnull cells and False outside."
    )

    assert parse("""Return a boolean array with True inside notnull cells and False outside."""
                 ).blank_after_short_description is True

    assert (
        parse("""Return a boolean array with True inside notnull cells and False outside."""
              ).blank_after_long_description is False
    )


# Generated at 2022-06-25 16:25:39.794694
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()


# Generated at 2022-06-25 16:25:50.624445
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.add_section(DeprecationSection("deprecated", "deprecation"))
    text = inspect.cleandoc(
        '''
        .. deprecated:: 1.0.0
            this is a description of the deprecation.

            This is the second line of the description.
        '''
    )
    text = '''
    .. deprecated:: 1.0.0
        this is a description of the deprecation.

        This is the second line of the description.
    '''
    text = '''deprecated:: 1.0.0
        this is a description of the deprecation.

        This is the second line of the description.
    '''

# Generated at 2022-06-25 16:25:58.472983
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = '.. deprecated:: 0.3.2\n\n    This is deprecated, do not do this.'
    assert numpydoc_parser_0.sections['deprecated'].parse(text_0) == \
        [DocstringDeprecated(description='This is deprecated, do not do this.',
                             version='0.3.2', args=['deprecation'])]

# Generated at 2022-06-25 16:26:05.874996
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Test case 1
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.add_section(DeprecationSection("Deprecated", "deprecated"))
    numpydoc_parser_0.add_section(
        DeprecationSection("DeprecationWarning", "deprecation_warning")
    )
    numpydoc_parser_0.parse(".. deprecated:: 0.0.0\n")


# Generated at 2022-06-25 16:26:27.172678
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    text = """
        xor(a, b)

        This is a description that spans multiple lines

        Parameters
        ----------
        a : int, optional
           operand 1
        b : int, optional
           operand 1

        Returns
        -------
        list of int
        """

    numpydoc_parser_1.parse(text)


# Generated at 2022-06-25 16:26:31.268072
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    docstring_1 = numpydoc_parser_1.parse("")

# Generated at 2022-06-25 16:26:43.588208
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Example 0
    text = "This is a docstring summary\nfollowed by a blank line.\n\nThis is a longer description.\n\nThis is a paragraph in the long description.\n\nArgs:\n    arg_name : type\n        arg_description\n\nReturns:\n    type :\n        return_description"

# Generated at 2022-06-25 16:26:55.252422
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Section.__init__(title, key)
    sections = {
        "section_A": Section("section_A", "key_A"),
        "section_B": Section("section_B", "key_B"),
        "section_C": Section("section_C", "key_C"),
    }
    # NumpydocParser.__init__(sections=sections)
    numpydoc_parser_0 = NumpydocParser(sections=sections)
    # Test numpydoc_parser_0.parse()
    docstring_str = """
    This is a test docstring.

    section_A
        This is a test section.

    section_B
        This is another test section.
    """
    docstring = numpydoc_parser_0.parse(docstring_str)
    docstring_

# Generated at 2022-06-25 16:27:00.411069
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_0 = "Hello, world!\n"
    expected_result_0 = Docstring()
    expected_result_0.short_description = "Hello, world!"
    result_0 = parse(text_0)
    assert result_0 == expected_result_0


# Generated at 2022-06-25 16:27:10.340986
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-25 16:27:15.046040
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_1 = """This is a test
    with a brief description and multiple lines
    """
    assert numpydoc_parser_0.parse(text_1) == """This is a test
    with a brief description and multiple lines
    """


# Generated at 2022-06-25 16:27:17.869788
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()


if __name__ == "__main__":
    numpydoc_parser_2 = NumpydocParser()

# Generated at 2022-06-25 16:27:29.256222
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:27:41.409412
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    # Assign to constant attribute
    Docstring.short_description = "This is a function"
    # Assign to constant attribute
    Docstring.blank_after_short_description = True
    # Assign to constant attribute
    Docstring.long_description = "This is a function for testing"
    # Assign to constant attribute
    Docstring.blank_after_long_description = True
    # Assign to constant attribute
    DocstringMeta.args = ["returns", "some_output"]
    # Assign to constant attribute
    DocstringMeta.description = "The output of this function"
    

# Generated at 2022-06-25 16:27:59.074267
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Set up
    numpydoc_parser = NumpydocParser()
    # text = Mocked argument that is passed in as string
    # expected = Expected value
    # assert = checks if given value matches expected value

    text = """
    Function to execute
    the algorithm.

    Parameters
    ----------
    instance : DummyClass
        Dummy argument [default: DummyClass()].
    """

# Generated at 2022-06-25 16:28:05.597594
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    expected_0 = Docstring(short_description=None, long_description=None, meta=[])
    input_0 = ''
    actual_0 = numpydoc_parser_0.parse(input_0)
    assert actual_0 == expected_0


# Generated at 2022-06-25 16:28:08.275378
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    numpydoc_parser_1.parse(text = "A numpy-style docstring.")


# Generated at 2022-06-25 16:28:20.401354
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    docstring = """Count the number of non-overlapping occurrences of pattern in
    the string.  For each such match, add 1 to the result list.  The
    optional argument count specifies a maximum number of pattern
    occurrences to be replaced; count must be a non-negative integer.
    If omitted or zero, all occurrences will be replaced.  Empty matches
    for the pattern are replaced only when not adjacent to a previous
    empty match, so sub('x*', '-', 'abxd') returns '-a-b--d-'.
    """

# Generated at 2022-06-25 16:28:32.895792
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()

# Generated at 2022-06-25 16:28:43.054363
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print("test_NumpydocParser_parse")
    # Imports
    import unittest
    import jinja2

    # Initialization of parser
    numpydoc_parser = NumpydocParser()

    # Test cases

# Generated at 2022-06-25 16:28:54.502304
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    # Test 1: empty docstring
    #Expected output = Docstring(short_description=None, blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[])
    input_text = ""
    output = numpydoc_parser.parse(input_text)
    if output == Docstring(short_description=None, blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[]):
        print("Success for test 1 for empty docstring")
    else:
        print("Fail for test 1 for empty docstring")

    # Test 2: description only
    #Expected output = Docstring(short_description='a short description', blank_after_short_description

# Generated at 2022-06-25 16:28:58.227414
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    actual_result = NumpydocParser().parse("")
    expected_result = NumpydocParser()
    assert (actual_result, expected_result)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:29:09.089405
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse(
        'Parameters\n'
        '----------\n'
        'f : callable\n'
        '    Function to be decorated\n'
        'name : str\n'
        '    Name of the new function\n'
        '\n'
        'Returns\n'
        '-------\n'
        'g : callable\n'
        '    New function with name given by name.\n'
    )
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert len(docstring_0.meta) == 2
    assert docstring_0.meta[0].args == ['param', 'f']


# Generated at 2022-06-25 16:29:14.476549
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    try:
        numpydoc_parser_1 = NumpydocParser()
        text = "Numpydoc docstring.\n\n    :param x: a parameter\n    :type y: int\n    :returns: a dict\n\n"
        try:
            ret_val = numpydoc_parser_1.parse(text=text)
            print(ret_val)
        except Exception:
            print("Exception in test case {}".format(inspect.stack()[0][3]))
    except Exception:
        print("Exception in test case {}".format(inspect.stack()[0][3]))



# Generated at 2022-06-25 16:29:32.930084
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    docstring_0 = numpydoc_parser_0.parse("")
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None

# Generated at 2022-06-25 16:29:42.995835
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # GIVEN
    text="A little title\n------------\nThis is a little description.\n\n:parameter a: blablabla\n\nA little note.\n\n"

    # WHEN
    docstring=NumpydocParser().parse(text)

    # THEN
    assert docstring.short_description=="A little title"
    assert docstring.long_description=="This is a little description."
    assert len(docstring.meta)==2
    assert docstring.meta[0].description=="blablabla"
    assert docstring.meta[1].description=="A little note."



# Generated at 2022-06-25 16:29:57.338197
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_docstring_0 = numpydoc_parser_0.parse('Returns the magnitude of the vector.\n')
    numpydoc_docstring_1 = numpydoc_parser_0.parse('Returns\n-------\n\n')
    numpydoc_docstring_2 = numpydoc_parser_0.parse('A tuple ``(a, b)``')
    numpydoc_docstring_3 = numpydoc_parser_0.parse('A tuple ``(a, b)``')
    numpydoc_docstring_4 = numpydoc_parser_0.parse('A tuple ``(a, b)``')
    numpydoc_docstring_5 = numpydoc_parser_0.parse

# Generated at 2022-06-25 16:30:01.270164
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_1 = NumpydocParser()
    text_2 = ""
    actual = numpydoc_parser_1.parse(text_2)
    expected = Docstring()
    assert actual == expected


# Generated at 2022-06-25 16:30:14.618570
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_method_name = "parse"

# Generated at 2022-06-25 16:30:25.358317
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    string_0 = "test attribute"
    docstring_0 = numpydoc_parser_0.parse(string_0)
    long_description_0_0 = docstring_0.long_description
    short_description_0_0 = docstring_0.short_description
    assert docstring_0.meta == []
    assert short_description_0_0 == 'test attribute'
    assert long_description_0_0 == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False

# Generated at 2022-06-25 16:30:29.188239
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    str_0 = "This is a short description...\n\nThis is a longer description.\n\nThis is another line."
    docstring_0 = numpydoc_parser_0.parse(str_0)
    assert docstring_0.short_description == "This is a short description..."
    assert docstring_0.long_description == "This is a longer description.\n\nThis is another line."


# Generated at 2022-06-25 16:30:35.346255
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = "param1"
    ret_0 = numpydoc_parser_0.parse(text_0)
    assert ret_0.short_description == None
    assert ret_0.blank_after_short_description == True
    assert ret_0.blank_after_long_description == True
    assert ret_0.long_description == None
    assert ret_0.meta == [DocstringMeta(['param'], description='param1')]

# Generated at 2022-06-25 16:30:44.276032
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    string_0 = "line1\nline2\nline3\n"
    string_1 = "line1\nline2\nline3"
    Docstring_expected_0 = Docstring(short_description="line1", long_description=None, meta=[], blank_after_short_description=False, blank_after_long_description=False)
    assert(numpydoc_parser_0.parse(string_0) == Docstring_expected_0)
    assert(numpydoc_parser_0.parse(string_1) == Docstring_expected_0)
    string_0 = "line1\nline2\nline3\n\n\nmore lines"

# Generated at 2022-06-25 16:30:57.454408
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser_0 = NumpydocParser()
    assert numpydoc_parser_0.parse("This function solves a system of linear scalar equations.") is not None
    assert numpydoc_parser_0.parse("'params' : array_like, optional") is not None
    assert numpydoc_parser_0.parse("'params' : array_like, optional\nThe values of the parameters.") is not None
    assert numpydoc_parser_0.parse("'params' : array_like, optional\nThe values of the parameters.\n   Optional by default.") is not None
    assert numpydoc_parser_0.parse("'params' : array_like, optional\nThe values of the parameters.\n   Optional by default.\n'bounds' : sequence, optional") is not None


# Generated at 2022-06-25 16:31:19.664289
# Unit test for method parse of class Section
def test_Section_parse():
    # Bare minimum
    text = """\
    Returns
        return_name : type
            A description of this returned value"""

    ret = DocstringReturns(
        args=[], description="", type_name="", is_generator=False, return_name=""
    )

    # Unit test for method parse of class Section
    def test_Section_parse():
        # Bare minimum
        text = """\
        Returns
            return_name : type
                A description of this returned value"""
        ret = DocstringReturns(
            args=[],
            description="",
            type_name="",
            is_generator=False,
            return_name="",
        )



# Generated at 2022-06-25 16:31:25.814406
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # Testing default behavior
    test_1: Section = ParamSection("Parameters", "param")
    assert isinstance(test_1, _KVSection)
    # Testing title_pattern
    assert test_1.title_pattern == "^(Parameters)\s*?\n----------\s*$"


# Generated at 2022-06-25 16:31:30.761971
# Unit test for constructor of class ParamSection
def test_ParamSection():
    def __init__(self, title: str, key: str) -> None:
        self.title = title
        self.key = key


# Generated at 2022-06-25 16:31:41.201931
# Unit test for constructor of class _KVSection
def test__KVSection():
    numpydoc_parser_1 = NumpydocParser()
    #Test 1
    title = "Parameters"
    def test_case_1():
        numpydoc_parser_1._KVSection(title, "param")

    #Test 2
    title = "Params"
    def test_case_1():
        numpydoc_parser_1._KVSection(title, "param")

    #Test 3
    title = "Arguments"
    def test_case_1():
        numpydoc_parser_1._KVSection(title, "param")

    #Test 4
    title = "Args"
    def test_case_1():
        numpydoc_parser_1._KVSection(title, "param")

    #Test 5
    title = "Other Parameters"

# Generated at 2022-06-25 16:31:49.393846
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    numpydoc_parser_0 = NumpydocParser()
    text_0 = '.. deprecated:: v0.0.1\n    First version with a deprecation warning\n'
    test_output_0 = DocstringDeprecated(args = ['deprecation'], description = "First version with a deprecation warning", version = "v0.0.1")
    assert(numpydoc_parser_0.parse(text_0).meta == test_output_0)


# Generated at 2022-06-25 16:31:54.069981
# Unit test for constructor of class _KVSection
def test__KVSection():
    kv_section_1 = _KVSection(title="Test Title", key="test")
    assert kv_section_1.title == "Test Title"
    assert kv_section_1.key == "test"
    assert kv_section_1.title_pattern == r"^(Test Title)\s*?\n{}\s*$".format("-" * len("Test Title"))


# Generated at 2022-06-25 16:31:58.374253
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydoc_parser_0 = NumpydocParser()
    numpydoc_parser_0.add_section(Section("Returns", "returns"))
    assert numpydoc_parser_0.sections["Returns"] is not None



# Generated at 2022-06-25 16:32:10.651493
# Unit test for function parse
def test_parse():
    docstring = """
    Function Summary
    ---------------
    Function title

    Parameters
    ----------
    p0 : str, optional
        Description for p0
    p1 : int
        Description for p1

    Returns
    -------
    str
        Description for return value

    Raises
    ------
    TypeError
        When a type error occurs
    """

    docstring = parse(docstring)
    print(docstring)
    assert docstring.short_description == "Function title"
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    print(docstring.meta)

# Generated at 2022-06-25 16:32:11.903831
# Unit test for constructor of class _KVSection
def test__KVSection():
    m = _KVSection("Parameters", "param")


# Generated at 2022-06-25 16:32:24.569464
# Unit test for function parse
def test_parse():
    text = """This function does something.
    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.
    Raises
    ------
    KeyError
        When something else goes wrong.

    Returns
    -------
    bool
        If something went wrong, return True. Otherwise False.

    """
    docstring = parse(text)
    exp_short_description = "This function does something."
    exp_long_description = None
    exp_blank_after_short_description = True
    exp_blank_after_long_description = False

# Generated at 2022-06-25 16:32:34.613613
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    param_section_0 = RaisesSection("Param", "param")
    param_section_1 = RaisesSection("Param", "param")


# Generated at 2022-06-25 16:32:39.124033
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection("Yields", "yields")
    try:
        assert y.title == 'Yields'
        assert y.key == 'yields'
    except AssertionError:
        print("YieldsSection() test failed.")

# # Unit test for constructor of class ReturnsSection

# Generated at 2022-06-25 16:32:52.583781
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yieldssection_0 = YieldsSection('Yields', 'yields')
    yieldssection_1 = YieldsSection(yieldssection_0)
    yieldssection_2 = YieldsSection(yieldssection_0, 'Yields', 'yields')
    yieldssection_3 = YieldsSection(title='Yields', key='yields')
    yieldssection_4 = YieldsSection('Yields', 'yields')
    yieldssection_5 = YieldsSection(title='Yields', key='yields')
    yieldssection_6 = YieldsSection(title='Yields', key='yields')
    yieldssection_7 = YieldsSection('Yields', 'yields')

# Generated at 2022-06-25 16:33:00.667949
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    doc = parser.parse(
        """This docstring has a short description,
        a blank line, a long description,
        and a few parameters.

        Arguments
        ---------
        foo : str
            the first variable
        bar : str
            the second variable
        baz : int, optional
            the third variable
        Returns
        --------
        a : str
            the return variable

        """
    )
    assert doc.short_description == "This docstring has a short description, a blank line, a long description, and a few parameters."
    assert doc.long_description == "a long description"
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

# Generated at 2022-06-25 16:33:08.933564
# Unit test for constructor of class Section
def test_Section():
    string = 'Parameters'
    string_1 = 'Arguments'
    key = 'param'
    section = Section(string, key)
    assert(section.title == string)
    assert(section.key == key)
    assert(section.title_pattern == '^(Parameters)\s*?\n----\s*$')
    section_1 = Section(string_1, key)
    assert(section_1.title_pattern == '^(Arguments)\s*?\n----\s*$')
