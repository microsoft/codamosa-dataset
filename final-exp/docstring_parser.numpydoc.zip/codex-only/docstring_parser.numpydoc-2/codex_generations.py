

# Generated at 2022-06-23 17:05:55.424543
# Unit test for constructor of class ParamSection
def test_ParamSection():
    parser = ParamSection("Parameters", "param")



# Generated at 2022-06-23 17:05:59.009626
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section('Test', 'test'))
    assert 'Test' in parser.sections


# Generated at 2022-06-23 17:06:05.228667
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser(DEFAULT_SECTIONS)
    assert(parser.sections["Returns"].key == "returns")

test_docstring = """One-line summary that does not use variable names or the
function name.

Parameters
----------
arg1 : int
    Description of `arg1`
arg2 : str
    Description of `arg2`

Return
------
None
"""


# Generated at 2022-06-23 17:06:17.033259
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kv_test_string = '''
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
            {maybe a dict}
    '''
    params_section = ParamSection("Parameters", "param")
    expected_list = sorted([
        {'arg_name' : None, 'description' : 'arg_description', 'arg_name' : 'arg_name', 'type_name' : None, 'is_optional' : None, 'default': None},
        {'arg_name' : None, 'description' : 'descriptions can also span...\n... multiple lines\n{maybe a dict}', 'arg_name' : 'arg_2', 'type_name' : 'type', 'is_optional' : True, 'default': None}
    ])


# Generated at 2022-06-23 17:06:20.765947
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ss = YieldsSection("Yields","yields")
    assert ss.title == "Yields"
    assert ss.key == "yields"

# Generated at 2022-06-23 17:06:27.629261
# Unit test for function parse
def test_parse():
    text = """\
    Test
    Test
    Parameters
    ----------
    foo: a, optional
        bar

    bar : b
        foo
    """
    doc = parse(text)
    assert(doc.short_description == "Test\nTest")
    assert(len(doc.meta) == 2)
    assert(doc.meta[0].description == "bar")
    assert(doc.meta[1].description == "foo")

# Generated at 2022-06-23 17:06:30.694485
# Unit test for constructor of class Section
def test_Section():
    title = 'title'
    key = 'key'
    sec = Section(title, key)
    assert(sec.title==title)
    assert(sec.key==key)
    return sec


# Generated at 2022-06-23 17:06:34.814231
# Unit test for constructor of class _KVSection
def test__KVSection():
    kv = _KVSection("title", "key")
    assert kv.title == "title"
    assert kv.key == "key"
    assert kv.title_pattern == "^(title)\s*?\n------\s*$"

# Generated at 2022-06-23 17:06:41.123938
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section_text = '''key
        value
    key2 : type
        values can also span...
        ... multiple lines'''
    section = _KVSection("section_title", "section_key")
    meta = section.parse(section_text)
    meta = list(meta)
    expected = [DocstringMeta(['section_key'], description='value'), DocstringMeta(['section_key'], description='values can also span...\n... multiple lines')]
    assert meta == expected

# Generated at 2022-06-23 17:06:46.592920
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    from .common import DocstringMeta
    """
    .. deprecated :: 0.1
        This will be removed in the next version of Python,
        so do not use it.
    """
    dp = DeprecationSection("deprecated", "deprecated")
    res = dp.parse("deprecated\n------------\n0.1\nThis will be removed in the next version of Python,\nso do not use it.\n\n")
    assert(res == [DocstringMeta(["deprecated"], description = "This will be removed in the next version of Python,\nso do not use it.", version = "0.1")])


# Generated at 2022-06-23 17:06:50.823471
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param_section = ParamSection("Parameters", "param")
    assert param_section.title == "Parameters"
    assert param_section.key == "param"
    assert param_section.title_pattern == "^Parameters\\s*?\n---*\\s*$"

# Generated at 2022-06-23 17:07:01.848542
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    text = 'This is a silly docstring.\n\nThis is the first param:\n'\
           '    param1\n    This is param1\n\nThis is the second param:\n'\
           '    param2\n    This is param2\n\nThis is a note:\n'\
           '    This is a note.\n'
    numpydoc_parser = NumpydocParser()
    section_added = Section('First Param', 'param1')
    numpydoc_parser.add_section(section_added)
    docstring = numpydoc_parser.parse(text)
    # This test only tests that the new section is added to the parser
    assert section_added in numpydoc_parser.sections.values()

# Generated at 2022-06-23 17:07:03.435495
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    rs = ReturnsSection("Returns", "returns")
    assert isinstance(rs, ReturnsSection)


# Generated at 2022-06-23 17:07:06.054792
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection(title="Returns", key="returns").title == "Returns"
    assert _SphinxSection(title="Returns", key="returns").key == "returns"


# Generated at 2022-06-23 17:07:13.811089
# Unit test for constructor of class _KVSection
def test__KVSection():
    text =  """
    Parameters
    ----------
    - foo : bar
        A dummy
    - quux : quuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuux
        Another dummy
    """

    pattern = '^({})\s*?\n{}\s*$'.format("Parameters", "-" * len("Parameters"))
    re_pattern = re.compile(pattern, flags=re.M)
    match = re_pattern.search(text)
    if match:
        print("match: ", match)
        title = next(g for g in match.groups() if g is not None)
        print("title: ", title)

# Generated at 2022-06-23 17:07:15.915763
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    deprecation_section = DeprecationSection("Deprecated", "deprecated")
    deprecation_section.parse("Deprecated since version 2.0\n  Due to something wrong")
    deprecation_section.parse("Deprecated since version\n  2.0\n  Due to something wrong")

# Generated at 2022-06-23 17:07:18.261621
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    test_returns = ReturnsSection('Returns', 'returns')
    assert test_returns.title == 'Returns'


# Generated at 2022-06-23 17:07:21.756272
# Unit test for constructor of class Section
def test_Section():
    # default case
    assert "title" in Section("title", "key").__dict__.keys()
    assert "key" in Section("title", "key").__dict__.keys()
    assert type(Section("title", "key")) is Section


# Generated at 2022-06-23 17:07:25.383069
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section = RaisesSection("Raises", "raises")
    assert(section.key == "raises")
    assert(section.title == "Raises")


# Generated at 2022-06-23 17:07:29.376991
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    n=ReturnsSection('Returns','returns')
    assert n.title=='Returns'
    assert n.key=='returns'
    assert n.is_generator ==False

# Generated at 2022-06-23 17:07:37.189690
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstr = '''Parameters
    ----------
    arg_1 : str
        Argument type.

    arg_2 : int, optional(default=0)
        Argument type.

    Raises
    -------
    TypeError
        If a type error occurs.

    Returns
    -------
    str
        Description of return value.
    '''
    docstring = NumpydocParser().parse(docstr)
    assert(docstring.short_description is None)
    assert(docstring.long_description is None)
    assert(docstring.blank_after_short_description is False)
    assert(docstring.blank_after_long_description is False)
    assert(str(docstring.meta[0]) == "param: arg_1(str): Argument type.")

# Generated at 2022-06-23 17:07:42.078025
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection("Yields", "yields")
    assert y.is_generator == True, "is_generator class field should be True"
    assert y.key == "yields", "YieldsSection class key should be 'yields'"
    assert y.title == "Yields", "YieldsSection title should be 'Yields'"

# Generated at 2022-06-23 17:07:50.221602
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    This is an unittest for NumpydocParser.parse()
    """
    parser = NumpydocParser()
    print('Testing basic functionality of method NumpydocParser.parse')

# Generated at 2022-06-23 17:07:51.357712
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    test_text = "deprecated\n    Use qwe instead."
    res = DeprecationSection.parse(test_text)
    print(res)

# Generated at 2022-06-23 17:08:02.080080
# Unit test for function parse
def test_parse():
    docstring = """
    This is a function testing the parse functions.

    This is the long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.

    arg2 : float
        Description of arg2.

    arg3 : str
        Description of arg3.

    Returns
    -------
    int
        Description of return value.

    Raises
    ------
    ValueError
        Description of raised error.
    """


# Generated at 2022-06-23 17:08:14.574503
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # sample docstring
    doc_string='''
    Parameters
    ----------
    x : array_like, shape (M, N)
        An array of M-by-N dimensions.
    y : array_like, shape (N, K)
        An array of N-by-K dimensions.
    '''

    # checking length of return type of parse_docstring
    doc_string=NumpydocParser().parse(doc_string)
    assert len(doc_string)==6

    # checking return type and value of parse_docstring
    doc_string=NumpydocParser().parse(doc_string)
    assert type(doc_string)==Docstring
    assert doc_string.short_description==None
    assert doc_string.blank_after_short_description==False
    assert doc_string.blank_after

# Generated at 2022-06-23 17:08:23.992899
# Unit test for constructor of class Section
def test_Section():
    # Default object
    section = Section("test", "key")

    assert section.title == "test"
    assert section.key == "key"
    assert section.title_pattern == "^test\\s*?\n---*\\s*$"

    # With additional arguments
    section2 = Section("test2", "key2", "desc")

    assert section2.title == "test2"
    assert section2.key == "key2"
    assert section2.title_pattern == "^test2\\s*?\n---*\\s*$"


# Generated at 2022-06-23 17:08:24.953933
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    return_test = ReturnsSection("Return", "returns")
    assert return_test is not None


# Generated at 2022-06-23 17:08:27.012887
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    test = _SphinxSection('title','key')
    result = test.title 
    assert result == 'title'

# Generated at 2022-06-23 17:08:28.699211
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    docstr = """
    This is a simple example.

    Parameters
    ----------
    name : str
        A name

    Returns
    -------
    str
        The name
    """
    assert NumpydocParser().parse(docstr) == parse(docstr)


# Generated at 2022-06-23 17:08:33.088263
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section_name = ReturnsSection("Returns", "returns")
    assert(section_name.title == "Returns")
    assert(section_name.key == "returns")
    assert(section_name.is_generator == False)


# Generated at 2022-06-23 17:08:36.753783
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    testClass = ReturnsSection("Returns", "returns")
    assert testClass.is_generator == False
    assert testClass.key == "returns"
    assert testClass.title == "Returns"


# Generated at 2022-06-23 17:08:42.603117
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    doc = DeprecationSection('Deprecated', 'deprecation').parse('v.0.1\nThis method was deprecated in version 0.1, and will be removed in version 0.2.')
    assert doc[0].version == 'v.0.1'
    assert doc[0].description == "This method was deprecated in version 0.1, and will be removed in version 0.2."

# Unit testing for method parse of class YieldsSection

# Generated at 2022-06-23 17:08:53.247686
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    assert parser.sections == DEFAULT_SECTIONS
    # Test that new section is added to parser
    section = Section("NewTitle", "newkey")
    parser.add_section(section)
    assert section in parser.sections.values()
    # Test that modified title is not in parser
    assert "NewTitle" not in parser.sections.keys()
    # Test that section is replaced in parser
    parser.add_section(section)
    assert section in parser.sections.values()
    # Test that section is replaced in parser
    parser.add_section(section)
    assert section in parser.sections.values()

# Generated at 2022-06-23 17:08:55.470534
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises = RaisesSection("Raises", "raises")
    assert raises


# Generated at 2022-06-23 17:09:00.021018
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    section = Section('title_test', 'key_test')
    parser.add_section(section)
    assert not parser.sections==DEFAULT_SECTIONS

test_NumpydocParser_add_section()


# Generated at 2022-06-23 17:09:08.367482
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    """
    This method is a unit test for _KVSection's parse method
    """
    section = _KVSection("Parameters", "param")
    docstring = """
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
    """
    result = section.parse(docstring)
    assert len(result) == 2
    for item in result:
        assert isinstance(item, DocstringMeta)
        assert item.args == ['param', 'arg_name'] or item.args == ['param', 'arg_2']
        assert item.description == "arg_description" or item.description == "descriptions can also span...\n... multiple lines"

# Generated at 2022-06-23 17:09:13.644112
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print("Testing NumpydocParser.parse.")

# Generated at 2022-06-23 17:09:19.833004
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    # empty
    assert(NumpydocParser() is not None)
    # none
    assert(NumpydocParser(None) is not None)
    # regular
    sections = [
        ParamSection("Parameters", "param"),
        ParamSection("Arguments", "param")
    ]
    assert(NumpydocParser(sections) is not None)


# Generated at 2022-06-23 17:09:25.467725
# Unit test for function parse
def test_parse():
    ds = "foo bar"
    assert parse(ds).short_description == ds

    ds = "foo bar\n"
    assert parse(ds).short_description == "foo bar"
    assert parse(ds).blank_after_short_description

    ds = "foo bar\n\n"
    assert parse(ds).short_description == "foo bar"
    assert parse(ds).long_description == ""
    assert parse(ds).blank_after_short_description
    assert parse(ds).blank_after_long_description

    ds = "foo bar\n\nbaz\n"
    assert parse(ds).short_description == "foo bar"
    assert parse(ds).long_description == "baz"
    assert parse(ds).blank_after_short_description
    assert parse(ds).blank_after

# Generated at 2022-06-23 17:09:37.706772
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:09:41.211339
# Unit test for constructor of class _KVSection
def test__KVSection():
    n = _KVSection("Parameters", "param")
    assert n.title == "Parameters"
    assert n.key == "param"
    assert n.title_pattern == "^(Parameters)\\s*?\\n-*\\s*$"
    return _KVSection, "test__KVSection passed!"

# Generated at 2022-06-23 17:09:46.999936
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """NumpydocParser.parse: test"""
    # Arguments:
    test_text = '''\
    Short description
    Long description
    ~~~

    Parameters
    ----------
    arg1: str
        arg1 description

    arg2 : int
        arg2 description

    arg3, optional
        arg3 description

    args
        arg4 description
        args description
        also spans multiple lines

    Returns
    -------
    str
        Return description
    int
        Also has description
    '''

# Generated at 2022-06-23 17:09:58.027055
# Unit test for method parse of class _KVSection

# Generated at 2022-06-23 17:10:05.166658
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    ReturnsSection("Returns", "returns")
    ReturnsSection("Yields", "yields")
    ReturnsSection("Return", "returns")
    ReturnsSection("Yield", "yields")

if __name__ == "__main__":
    # Unit test for constructor of class ReturnsSection
    test_ReturnsSection()
    print("All tests passed!")

# Generated at 2022-06-23 17:10:08.777698
# Unit test for constructor of class _KVSection
def test__KVSection():
    sec = _KVSection("Parameters", "param")
    assert sec.title == "Parameters"
    assert sec.key == "param"
    title_pattern = sec.title_pattern
    assert title_pattern == r"^Parameters\s*?\n-*Parameters\s*$"


# Generated at 2022-06-23 17:10:11.484025
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    ndp = NumpydocParser()
    assert ndp.sections != None
    assert len(ndp.sections) > 0


if __name__ == "__main__":
    import pytest

    pytest.main(__file__)

# Generated at 2022-06-23 17:10:13.722870
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    r = ReturnsSection("Returns", "returns")
    assert r.is_generator == False


# Generated at 2022-06-23 17:10:19.294481
# Unit test for function parse
def test_parse():
    """Test case for function parse"""
    doc = """
    Test Numpy docstring parser

    Parameters
    ----------
    first : int
        a param
    second : str, optional
        another param
    last
        last param

    Returns
    -------
    tuple
        tuple of (first, second, last)
    """

    parsed = NumpydocParser().parse(doc)

    assert str(parsed.short_description) == "Test Numpy docstring parser"
    assert not parsed.blank_after_short_description
    assert not parsed.blank_after_long_description
    assert str(parsed.long_description) == ""

    assert len(parsed.meta) == 3


# Generated at 2022-06-23 17:10:23.074128
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    title = "test"
    key = "key"
    s = NumpydocParser(title, key)


# Generated at 2022-06-23 17:10:32.595987
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Get class of method parse
    parse_method = inspect.getmembers(NumpydocParser, predicate=inspect.ismethod)[2][1]
    # Get the docstring of method parse
    s = parse_method.__doc__

    # Print out the dostring
    print("Docstring of the method parse in class NumpydocParser:")
    print(s)

    # Check that the docstring of method parse is not empty
    assert len(s) > 0

    # Check that the docstring of method parse is not a single line
    assert len(s.split("\n")) > 0


# Testcase for method parse of class NumpydocParser

# Generated at 2022-06-23 17:10:36.876382
# Unit test for constructor of class ParamSection
def test_ParamSection():
    object = ParamSection("Parameters", "param")
    assert object.title == "Parameters"
    assert object.key == "param"
    assert object.title_pattern == r"^Parameters\s*?\n{3}\s*$"


# Generated at 2022-06-23 17:10:44.907854
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    s = str(DeprecationSection('title', 'key'))
    assert str(DeprecationSection('title', 'key')) == '<__main__.DeprecationSection object at 0x7f661436b2e8>'
    testfunction = DeprecationSection('title', 'key').parse
    text = 'title' 
    assert inspect.iscoroutinefunction(testfunction) == False
    assert inspect.isgeneratorfunction(testfunction) == False
    assert inspect.isfunction(testfunction) == True
    assert inspect.isroutine(testfunction) == True
    result = testfunction(text)
    assert isinstance(result,typing.Iterable)
    assert next(result) == DocstringDeprecated(description=None, reason=None, args=['key'], version=None, stacklevel=None)


# Generated at 2022-06-23 17:10:55.620398
# Unit test for method parse of class Section
def test_Section_parse():
    test_cases = [
        (
            "test_title\n"
            "----------\n"
            "test_value\n",
            DocstringMeta(["test_key"], description="test_value"),
        ),
        (
            "test_value\n",
            DocstringMeta(["test_key"], description="test_value"),
        ),
        (
            "test_value\n"
            "test_value\n",
            DocstringMeta(["test_key"], description="test_value\ntest_value"),
        ),
    ]

    for test_case in test_cases:
        section = Section(title="test_title", key="test_key")
        gen_result = section.parse(test_case[0])
        result = next(gen_result)

        assert result.args == test_

# Generated at 2022-06-23 17:11:02.978647
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Test with empty parameters
    a = _KVSection(title = "", key = "")
    assert a.title == ""
    assert a.key == ""
    assert a.title_pattern == r"^()\s*?\n\s*$"
    assert a.parse("") == []
    # Test with .title = "Parameters" and .key = "Parameter"
    b = _KVSection(title = "Parameters", key = "Parameter")
    assert b.title == "Parameters"
    assert b.key == "Parameter"
    assert b.title_pattern == r"^(Parameters)\s*?\n--------\s*$"
    assert b.parse("\n") == []


# Generated at 2022-06-23 17:11:04.004633
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert NumpydocParser() is not None

# Generated at 2022-06-23 17:11:06.536735
# Unit test for constructor of class Section
def test_Section():
    test_section = Section("title", "key")
    assert test_section.title == "title"
    assert test_section.key == "key"

# Generated at 2022-06-23 17:11:17.994442
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    text = """
    Deprecation warning

    The :class:`gevent.threadpool.ThreadPool` is deprecated. Use
    :class:`gevent.pool.Pool` with ``spawn`` instead.
    """
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.meta[0].args == ["deprecation"]
    assert docstring.meta[0].type_name == "deprecation"
    assert docstring.meta[0].description == "The :class:`gevent.threadpool.ThreadPool` is deprecated. Use :class:`gevent.pool.Pool` with ``spawn`` instead."
    assert docstring.meta[0].version == "Deprecation warning"



# Generated at 2022-06-23 17:11:20.219036
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection("title", "key")
    assert s.title == "title"
    assert s.key == "key"
    return


# Generated at 2022-06-23 17:11:21.386750
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection("Parameters", "param")



# Generated at 2022-06-23 17:11:26.637927
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    test_section = ParamSection("Arg_test", "arg_test")
    test_parser = NumpydocParser()
    assert test_section.title not in test_parser.sections
    test_parser.add_section(test_section)
    assert test_section.title in test_parser.sections

# Generated at 2022-06-23 17:11:29.324630
# Unit test for constructor of class Section
def test_Section():
    name = Section('title', 'key')
    assert name.title == 'title'
    assert name.key == 'key'


# Generated at 2022-06-23 17:11:40.862901
# Unit test for method parse of class Section
def test_Section_parse():
    sections = {
        "A": Section("A", "a"),
        "B": Section("B", "b"),
    }
    parser = NumpydocParser(sections)

    text = 'First line\n' \
           '\n' \
           'A\n' \
           '--\n' \
           'foo\n' \
           'bar\n' \
           '\n' \
           'B\n' \
           '--\n' \
           'baz\n' \
           'qux\n'
    docstring = parser.parse(text)
    assert docstring.short_description == "First line"
    assert docstring.blank_after_short_description is True
    assert docstring.long_description is None
    assert docstring.blank_after_long_description is True

# Generated at 2022-06-23 17:11:41.581627
# Unit test for constructor of class _KVSection
def test__KVSection():
    ParamSection("Parameters", "param")


# Generated at 2022-06-23 17:11:51.678631
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    # test basic case
    title = "Deprecation warning"
    key = "deprecation"
    DeprecationSection(title, key)
    # test for non-string type
    DeprecationSection(title, 123)
    DeprecationSection(title, None)
    # test for wrong type
    DeprecationSection(123, key)
    DeprecationSection(None, key)
    DeprecationSection(123, None)
    # test for empty string
    DeprecationSection("", "")
    DeprecationSection(key, "")
    DeprecationSection("", key)
    # test for edge case
    DeprecationSection(title, "a longer key")



# Generated at 2022-06-23 17:11:59.967032
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    docstring = inspect.cleandoc("""
        Parameters
        ----------
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
    """)
    expected = DocstringMeta(args=['param'], description='arg_name\n    arg_description')
    x = section.parse("arg_name\n    arg_description")
    assert next(x) == expected
    expected = DocstringMeta(args=['param'], description='arg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines')
    assert next(x) == expected




# Generated at 2022-06-23 17:12:02.692664
# Unit test for constructor of class _KVSection
def test__KVSection():
    section = _KVSection("Parameters", "param")
    assert section.title == "Parameters"
    assert section.key == "param"


# Generated at 2022-06-23 17:12:07.640428
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    test_section = Section('Test', 'test')
    test_numpydocParser = NumpydocParser()
    test_numpydocParser.add_section(test_section)
    assert test_numpydocParser.sections['Test'] == test_section


# Generated at 2022-06-23 17:12:15.727124
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:12:26.644817
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    from .common import DocstringReturns

    rsec = ReturnsSection("Returns", "returns")
    rdocs = rsec.parse("int\n    sample_int")
    assert rdocs is not None

    for d in rdocs:
        assert isinstance(d, DocstringReturns)

    assert d.args == ['returns']
    assert d.description == 'sample_int'
    assert d.type_name == 'int'

    rdocs = rsec.parse("sample_int: int")
    assert rdocs is not None
    for d in rdocs:
        assert isinstance(d, DocstringReturns)

    assert d.args == ['returns']
    assert d.description == None
    assert d.type_name == 'int'
    assert d.return_name == 'sample_int'

    rdocs = rsec

# Generated at 2022-06-23 17:12:36.533896
# Unit test for constructor of class Section
def test_Section():
    para_section = Section("Parameters","param")
    assert para_section.title == "Parameters"
    assert para_section.key == "param"
    assert para_section.title_pattern == "^Parameters\\s*?\\n-----\\s*$"
    para_section.parse("arg_name\n    arg_description")
    para_section.parse("arg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines")
    para_section.parse("arg_2 : type\n    descriptions can also span...\n    ... multiple lines")
    para_section.parse("arg_2 : type, optional\n    descriptions can also span...\n    ...")
    para_section.parse("arg_2 : type, optional\n    descriptions can also span...\n")

# Generated at 2022-06-23 17:12:42.071696
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    d = " This is deprecated since version 0.4.0"
    out = DeprecationSection("deprecated", "deprecation").parse(d)
    assert next(out) == DocstringDeprecated(args=['deprecation'], description=None,
                                            version='0.4.0')

# Generated at 2022-06-23 17:12:50.830127
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """
    Testing that after the call of the method add_section, 
    the attribute titles_re of the class NumpydocParser is composed with the data of test_section.
    """
    #Create new section with new title (not in the class NumpydocParser by default)
    test_section = Section("TEST", "test")
    parser = NumpydocParser()
    #add the new section to NumpydocParser
    parser.add_section(test_section)
    #test if the method _setup correct the re of titles_re
    assert (test_section.title_pattern in parser.titles_re.pattern)

test_section = Section("TEST", "test")
parser = NumpydocParser()


# Generated at 2022-06-23 17:12:57.173913
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    depr_section = DeprecationSection("Deprecated", "deprecated")
    text = "Changed in version 0.18: Deprecated.\n\n" \
           "Please use this instead."
    meta = depr_section.parse(text)
    assert "\n".join([next(meta).description, next(meta).version]) == \
        "Please use this instead.\nChanged in version 0.18"



# Generated at 2022-06-23 17:13:02.749108
# Unit test for constructor of class Section
def test_Section():
    title = "test title"
    key = "test_key"
    section = Section(title, key)
    assert section.title == "test title"
    assert section.key == "test_key"
    assert section.title_pattern == "^(test title)\s*?\n-----\s*$"


# Generated at 2022-06-23 17:13:11.044454
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    s='foo\n bar'
    print(list(KV_REGEX.finditer(s)))
    assert list(KV_REGEX.finditer(s)) == [re.match(KV_REGEX, 'foo'), re.match(KV_REGEX, 'bar')]
    assert list(_pairwise(KV_REGEX.finditer(s))) == [(re.match(KV_REGEX, 'foo'), re.match(KV_REGEX, 'bar'))]
    KVParser = _KVSection.__new__(_KVSection)
    KVParser.key = 'foo'
    assert KVParser.title == 'foo'
    assert KVParser.key == 'foo'
    KVParser._parse_item = lambda self, key, value: value

# Generated at 2022-06-23 17:13:19.393601
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    docstring = """
    Add or replace a section.

    :param section: The new section.
    """
    doc = parse(docstring)
    
    # fonction add_section (dans la classe NumpydocParser)
    # ne renvoie rien, on ne peut renvoyer None
    # donc on renvoie une valeur arbitraire
    return True


if __name__ == "__main__":
    import pytest

    pytest.main(["-s", __file__])

# Generated at 2022-06-23 17:13:24.138195
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    d = DeprecationSection('Deprecated','deprecation').parse('Since 0.1.0\nDeprecated\n')
    assert str(next(d)) == "deprecation(version='Since 0.1.0', description='Deprecated')"

# Generated at 2022-06-23 17:13:28.567677
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
	# test constructor 1
	assert DeprecationSection("title", "key")
	# test constructor 2
	assert DeprecationSection("arg_name", "Other Parameters")

# Generated at 2022-06-23 17:13:39.508444
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections_list = [Section("1", "1"), Section("2", "2")]
    sections_dict = {s.title: s for s in sections_list}
    numpydocParser1 = NumpydocParser()
    assert numpydocParser1.sections == {s.title: s for s in DEFAULT_SECTIONS}
    numpydocParser2 = NumpydocParser(sections_dict)
    assert numpydocParser2.sections == sections_dict
    assert numpydocParser2.sections != {s.title: s for s in DEFAULT_SECTIONS}
    numpydocParser3 = NumpydocParser(sections_list)
    assert numpydocParser3.sections == {s.title: s for s in sections_list}

# Generated at 2022-06-23 17:13:52.216099
# Unit test for function parse
def test_parse():
    def func():
        """
        Parameters
        ----------
        arg_name
            arg_description

        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines

        Other Parameters
        ----------------
        arg_3
            Another paragraph...
            ... of text

        Raises
        ------
        ValueError
            A description of what might raise ValueError

        Returns
        -------
        a : string
            a description of what is returned

        also : another_type
            Return names are optional, types are required
        """

    ds = parse(func.__doc__)

# Generated at 2022-06-23 17:13:56.002180
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():

    returnsSection = ReturnsSection("Returns", "returns")
    expected = '<Returns with key = returns>'
    actual = str(returnsSection)
    
    assert expected == actual, "Expected: " + expected + " Actual: " + actual



# Generated at 2022-06-23 17:13:57.599964
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert _KVSection("Parameters", "param")


# Generated at 2022-06-23 17:14:00.557669
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    sec = _SphinxSection("title", "key")
    assert sec.title_pattern == '^\.\.\\s*(title)\\s*::'



# Generated at 2022-06-23 17:14:04.589021
# Unit test for constructor of class _KVSection
def test__KVSection():
    p = _KVSection('title', 'key')
    assert p.title == 'title'
    assert p.key == 'key'
    assert p.title_pattern == '^(title)\s*?\n---*\s*$'



# Generated at 2022-06-23 17:14:08.246896
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection('title', 'key')
    assert s.title == 'title'
    assert s.key == 'key'
    assert s.title_pattern == '^\\.\\.\\s*(title)\\s*::'


# Generated at 2022-06-23 17:14:13.874777
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ParamSection("Parameters", "param")
    ParamSection("Params", "param")
    ParamSection("Arguments", "param")
    ParamSection("Args", "param")
    ParamSection("Other Parameters", "other_param")
    ParamSection("Other Params", "other_param")
    ParamSection("Other Arguments", "other_param")
    ParamSection("Other Args", "other_param")
    ParamSection("Receives", "receives")
    ParamSection("Receive", "receives")
    #assert False, "TODO: Unit test here"


# Generated at 2022-06-23 17:14:26.508858
# Unit test for method parse of class Section
def test_Section_parse():
    sections = [
        _SphinxSection("deprecated", "deprecation"),
    ]
    section = sections[0]
    
    # Testing deprecated section
    for title in [".. deprecated::", ".. deprecated:: "]:
        section.title_pattern = section.title_pattern.replace(section.title, title)
        if inspect.cleandoc(".. deprecated:: some version\n    deprecation message") == "some version\ndeprecation message":
            assert("some version" in str(section.parse(".. deprecated:: some version\n    deprecation message")))
            assert("deprecation message" in str(section.parse(".. deprecated:: some version\n    deprecation message")))

# Generated at 2022-06-23 17:14:29.669612
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    title = "Deprecated"
    key = "deprecation"
    #initialize object
    deprecation = DeprecationSection(title, key)
    assert deprecation.title == title
    assert deprecation.key == key


# Generated at 2022-06-23 17:14:30.687006
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    with pytest.raises(AttributeError):
        _SphinxSection().title_pattern

# Generated at 2022-06-23 17:14:43.272380
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    assert list(_KVSection("Section", "key").parse(" \r\n arg_name\r\n ")) == [
        DocstringMeta(["key", None], description=None)
    ]
    assert list(
        _KVSection("Section", "key").parse(
            """
            arg_name1
                value1
            arg_name2 : type, optional
                value2
        """
        )
    ) == [
        DocstringMeta(["key", "arg_name1"], description="value1\n"),
        DocstringMeta(
            ["key", "arg_name2"],
            description="value2\n",
            arg_name="arg_name2",
            type_name="type",
            is_optional=True,
        ),
    ]



# Generated at 2022-06-23 17:14:47.471612
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # Initialize with title and key
    raises_section = RaisesSection("Raises", "raises")
    assert(raises_section.key == "raises")

    # Initialize with title and key
    raises_section = RaisesSection("Raises", "raises")
    assert(raises_section.title == "Raises")


# Generated at 2022-06-23 17:14:54.341674
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    return_name = "Fred"
    type_name = "Mr"
    is_generator = "False"
    args=["returns"]

    returns1 = ReturnsSection(return_name, type_name, is_generator, args )
    assert returns1.return_name == return_name
    assert returns1.type_name == type_name
    assert returns1.is_generator == is_generator

# Generated at 2022-06-23 17:14:56.960845
# Unit test for constructor of class Section
def test_Section():
    title = "title"
    key = "key"
    section = Section(title, key)

    assert section.title == title
    assert section.key == key


# Generated at 2022-06-23 17:15:00.879958
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    obj=ReturnsSection("Returns", "returns")
    assert obj.title == "Returns"
    assert obj.key == "returns"
    assert obj.is_generator == False


# Generated at 2022-06-23 17:15:03.648064
# Unit test for constructor of class Section
def test_Section():
    sec = Section("Parameters", "param")
    sec_title = sec.title
    sec_key = sec.key
    assert sec_title == "Parameters"
    assert sec_key == "param"


# Generated at 2022-06-23 17:15:09.276331
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydoc_parser = NumpydocParser()
    section = Section("Revision History", "revision history")
    numpydoc_parser.add_section(section)
    for title,s in numpydoc_parser.sections.items():
        print(title, s)


# Generated at 2022-06-23 17:15:10.163014
# Unit test for constructor of class Section
def test_Section():
    assert (Section("a", "b") is not None)


# Generated at 2022-06-23 17:15:22.519928
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:15:26.424180
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
	
	newSection = RaisesSection("Raises","raises")
	
	text = "ValueError \n something "
	
	expectedRaises = []
	expectedRaises.append(DocstringRaises(args=["raises", "ValueError"], description="something", type_name="ValueError"))
	
	assert newSection.parse(text) == expectedRaises

# Generated at 2022-06-23 17:15:32.475607
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    source = '''
    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required
    '''
    parser = NumpydocParser().parse(source)
    # It has two returns
    assert len(parser.meta[0].args) == 2

# Generated at 2022-06-23 17:15:35.002661
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert re.match(r"^\.\.\s*({})\s*::".format('deprecated'), '.. deprecated::') != None

# Generated at 2022-06-23 17:15:38.368228
# Unit test for constructor of class Section
def test_Section():
    title = "Title"
    key = "key"
    section = Section(title, key)
    assert section.title == title
    assert section.key == key



# Generated at 2022-06-23 17:15:44.529350
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    assert parser.sections.__len__() > 0

    parser.add_section(Section('Test for add_section', 'add_section_test'))
    assert parser.sections.__len__() == DEFAULT_SECTIONS.__len__() + 1

    parser.add_section(Section('Returns', 'returns_test'))
    assert parser.sections.__len__() == DEFAULT_SECTIONS.__len__() + 1

# Generated at 2022-06-23 17:15:53.941433
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """
    Test for the method parse of class DeprecationSection
    """
    dp = DeprecationSection("deprecated", "deprecation")
    text = """.. deprecated:: 1.1.0
    It has been discovered that this function has been deprecated.
    """
    assert dp.parse(text) == [DocstringDeprecated(args=['deprecation'], description='It has been discovered that this function has been deprecated.', version='1.1.0')]
