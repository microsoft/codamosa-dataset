

# Generated at 2022-06-23 17:05:55.865457
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert(NumpydocParser())


# Generated at 2022-06-23 17:06:03.263809
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = inspect.cleandoc("""
        line 1
        line 2
        line 3
        line 4
        line 5
    """)

    def _parse_item(key: str, value: str) -> DocstringMeta:
        return DocstringMeta([key], description=value)

    seq = _KVSection("title", "key").parse(text)
    assert list(seq) == [DocstringMeta(["key"], description=text)]

# Generated at 2022-06-23 17:06:14.654532
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    """Test 1"""
    text = """
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    text = inspect.cleandoc(text)
    assert list(_KVSection("Parameters", "param").parse(text)) == [
        DocstringParam(args=['param', 'key'], description='value', arg_name='key', type_name=None, is_optional=None, default=None), 
        DocstringParam(args=['param', 'key2'], description='values can also span...\n... multiple lines', arg_name='key2', type_name='type', is_optional=False, default=None)
    ]


# Generated at 2022-06-23 17:06:23.009630
# Unit test for method parse of class Section
def test_Section_parse():
    header = "Parameters"
    text = "arg_name\n    arg_description"
    key = "param"
    section = Section(header, key)
    result = section.parse(text)
    assert result[0].args == [key, "arg_name"]
    assert result[0].description == "arg_description"
    assert result[0].arg_name == "arg_name"
    assert result[0].type_name == None
    assert result[0].is_optional == None
    assert result[0].default == None


# Generated at 2022-06-23 17:06:24.522284
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    ReturnsSection("Returns", "returns")


# Generated at 2022-06-23 17:06:30.750912
# Unit test for method parse of class Section
def test_Section_parse():
    sec = Section("Parameters", "param")
    text = '''Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines'''
    # print(sec.parse(text))
    for item in sec.parse(text):
        print(item.description)
        print(item.args)



# Generated at 2022-06-23 17:06:40.145449
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert(parser.sections["Parameters"].title == "Parameters")
    sections = DEFAULT_SECTIONS.copy()
    sections.remove(sections[1])
    sections.append(Section("Params", "params"))
    parser = NumpydocParser(sections)
    assert(parser.sections["Params"].title == "Params")
    assert(len(parser.sections.keys()) == 13)
    assert("Params" in parser.sections.keys())


# Generated at 2022-06-23 17:06:43.448658
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    my_section = Section(title='Test Section',key='test')
    my_parser = NumpydocParser()
    my_parser.add_section(my_section)

    text = 'Test Section\n------------\n'
    match = my_parser.titles_re.search(text)
    assert match.group(1) == 'Test Section'

# Generated at 2022-06-23 17:06:55.327735
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """Hello
    Test the docstring from numpydoc

    Parameters
    ----------
    string : string
        The string to be tested.

    Returns
    -------
    returns : string
        The output string.
    """

    ret = NumpydocParser().parse(text)
    assert ret.short_description == 'Hello'
    assert ret.long_description == 'Test the docstring from numpydoc'
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == True
    #meta is a list of DocstringMeta object
    assert ret.meta[0].args[0] == 'param'
    assert ret.meta[0].args[1] == 'string'
    assert ret.meta[0].description == 'The string to be tested.'

# Generated at 2022-06-23 17:07:05.339002
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param1 = ParamSection("Parameters", "param")
    param2 = ParamSection("Other Parameters", "other_param")
    expected_value = {'Parameters': 'param', 'Other Parameters': 'other_param'}
    assert isinstance(param1, Section), "Instance type is wrong"
    assert isinstance(param2, Section), "Instance type is wrong"
    assert expected_value == param1.parse("param\nparam"), "Data not correct"
    assert expected_value == param1.parse("param\nparam"), "Data not correct"
    assert param1.title == "Parameters", "Title is wrong"
    assert param2.title == "Other Parameters", "Title is wrong"
    assert param1.title_pattern == r"^Parameters\s*?\n-+\s*$", "Title pattern is wrong"
    assert param2

# Generated at 2022-06-23 17:07:07.661254
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    test = NumpydocParser()
    a = Section("Attribute", "attribute")
    test.add_section(a)
    assert test.sections["Attribute"] == a


# Generated at 2022-06-23 17:07:10.082508
# Unit test for constructor of class Section
def test_Section():
    assert (Section("Parameters", "param")).title == "Parameters"
    assert (Section("Parameters", "param")).key == "param"


# Generated at 2022-06-23 17:07:16.140270
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    class NewSection(Section):
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            pass
    parser = NumpydocParser()
    parser.add_section(NewSection("New Section", "new"))
    assert "New Section" in list(parser.sections.keys())


# Generated at 2022-06-23 17:07:18.817244
# Unit test for constructor of class Section
def test_Section():
    title = "Parameters"
    key = "param"
    test_object = Section(title, key)
    assert test_object.title == title
    assert test_object.key == key

# Generated at 2022-06-23 17:07:21.743616
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    rs = ReturnsSection("Returns", "returns")
    assert rs.title == "Returns"
    assert rs.key == "returns"

# Generated at 2022-06-23 17:07:24.684812
# Unit test for method parse of class Section
def test_Section_parse():
    """test parse method of class Section"""
    obj=Section('Parameters','a')
    match=obj.parse('b\n----')
    assert next(match).description=='b'


# Generated at 2022-06-23 17:07:27.719090
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    np = NumpydocParser()
    s = Section('My paragraph', 'my_paragraph')
    np.add_section(s)
    assert len(np.sections) == 28
    assert s in np.sections.values()



# Generated at 2022-06-23 17:07:28.442647
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    pass

# Generated at 2022-06-23 17:07:36.821612
# Unit test for function parse
def test_parse():
    text = """
    Sum of two numbers x and y.

    The result of sum is stored in x.

    Parameters
    ----------
    x, y
        description
    z: int
        description

    Returns
    -------
    type
        description

    Raises
    ------
    ValueError
        if z is negative
    """
    docstring = parse(text)
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "Sum of two numbers x and y."
    assert (
        docstring.long_description
        == "The result of sum is stored in x."
    )
    assert docstring.blank_after_short_description

    meta = docstring.meta
    assert len(meta) == 3

    assert isinstance(meta[0], DocstringParam)

# Generated at 2022-06-23 17:07:38.326270
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert issubclass(RaisesSection, Section)


# Generated at 2022-06-23 17:07:41.443017
# Unit test for constructor of class _KVSection
def test__KVSection():
  x = _KVSection("title", "key")
  assert x.title == "title"
  assert x.key == "key"
  assert x.title_pattern == r"^(title)\s*?\n{}\s*$".format("-" * len("title"))


# Generated at 2022-06-23 17:07:42.735027
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert len(ReturnsSection("Returns", "returns").title) == 7


# Generated at 2022-06-23 17:07:44.376537
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    with pytest.raises(TypeError):
        _SphinxSection()



# Generated at 2022-06-23 17:07:56.168142
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    s = """Docstring with a short description.

    Docstring with a long description.

    Parameters:
    -----------
    param1 : str
        description of param1
    param2 : str

        description of param2
        continued on a second line

    param3 : int = default_param3
        description of param3

    param4 : (int, int)
        description of param4

    param5 : int, optional
        description of param5

    Raises:
    -------
    KeyError
        when a key error
    OtherError
        when an other error

    Yields:
    -------
    int
        The ints

    Returns: float
        The float

    """

    res = parse(s)

    assert res.short_description == "Docstring with a short description."

# Generated at 2022-06-23 17:08:00.694617
# Unit test for method parse of class DeprecationSection

# Generated at 2022-06-23 17:08:09.264849
# Unit test for method parse of class Section
def test_Section_parse():
    # test1
    text = "Attributes\n" + "------------\n" + "attribute1\n" + "attribute1 description\n"
    s = Section("Attributes", "attributes")
    res = s.parse(text)
    assert next(res).args[0] == "attributes"
    assert next(res).args[1] == "attribute1"
    assert next(res).description == "attribute1 description"

    # test2
    text = "arg1\n" + "arg1 description\n"
    s = Section("Parameters", "param")
    res = s.parse(text)
    assert next(res).args[0] == "param"
    assert next(res).args[1] == "arg1"
    assert next(res).description == "arg1 description"


# Generated at 2022-06-23 17:08:14.531003
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")

    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"

    parser = NumpydocParser()
    assert parser.parse(text) is not None

# Generated at 2022-06-23 17:08:20.604481
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = "a\n    b\nc\n    d\n"
    assert list(_KVSection(None, None).parse(text)) == [
        DocstringMeta(["a"], description=_clean_str("b")),
        DocstringMeta(["c"], description=_clean_str("d")),
    ]



# Generated at 2022-06-23 17:08:32.392954
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    test_text = '''
    Short description.

    Long description.

    Long description, continued.

    Parameters
    ----------
    param1 : int
        Description of param1
    param2 : str
        Description of param2

    Returns
    -------
    int
        Description of return value
    '''

# Generated at 2022-06-23 17:08:43.385224
# Unit test for function parse
def test_parse():
    def func():
        """
        f: Short description.

        Longer description.

        Parameters
        ----------
        a : int
            desc # this comment is ignored

        b: some type
            desc

        Returns
        -------
        a : str
            desc

        b
            desc

        Warnings
        --------
        This is a warning!
        """
        pass

    from .common import Docstring
    from .common import DocstringParam
    from .common import DocstringReturns
    from .common import DocstringMeta

    doc = Docstring()
    doc.short_description = "Short description."
    doc.blank_after_short_description = False
    doc.long_description = "Longer description."
    doc.blank_after_long_description = True


# Generated at 2022-06-23 17:08:44.812121
# Unit test for method parse of class Section
def test_Section_parse():
    Section.parse()


# Generated at 2022-06-23 17:08:48.447177
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    sec = YieldsSection("yields","Yields")
    assert sec.is_generator == True

# Test section title_pattern

# Generated at 2022-06-23 17:08:56.091229
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This docstring is for testing purpose

    Parameters
    ----------

    num: int
        The number to be divided

    Returns
    -------
    int
        The divided number
    """ 
    docstring = NumpydocParser().parse(text)
    assert isinstance(docstring, Docstring)
    assert isinstance(docstring.short_description, str)
    assert isinstance(docstring.long_description, str)
    assert isinstance(docstring.meta, list)
    assert isinstance(docstring.meta[0], DocstringParam)
    assert isinstance(docstring.meta[1], DocstringReturns)

# Generated at 2022-06-23 17:08:59.907074
# Unit test for method parse of class Section
def test_Section_parse():
    """Test for method parse of class Section"""
    output = Section("title","key").parse("text")
    assert next(output) == DocstringMeta(["key"], description = 'text')


# Generated at 2022-06-23 17:09:02.129067
# Unit test for constructor of class Section
def test_Section():
    section = Section('title','key')
    assert section.title=='title'
    assert section.key=='key'


# Generated at 2022-06-23 17:09:04.784717
# Unit test for constructor of class _KVSection
def test__KVSection():
	title = "arg_name"
	key = "key"
	kv = _KVSection(title, key)
	assert kv.title == title
	assert kv.key == key


# Generated at 2022-06-23 17:09:06.976169
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    t = RaisesSection("Raises", "raises")
    assert t.title == "Raises"

# Generated at 2022-06-23 17:09:13.010362
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from docstring_parser import parse
    from docstring_parser.common import DocstringParam, DocstringReturns, DocstringRaises, DocstringMeta, DocstringDeprecated


# Generated at 2022-06-23 17:09:24.609535
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "test"
    key = "test_key"
    section = _SphinxSection(title, key)

    assert section.title == title
    assert section.key == key
    assert section.title_pattern == r"^\.\.\s*(test)\s*::"

    # Check if value error raised with no argument
    try:
        assert _SphinxSection()
    except ValueError as ve:
        assert str(ve) == (
            "missing 1 required positional argument: " "'title'"
        )

    # Check if value error raised with one argument
    try:
        assert _SphinxSection(title)
    except ValueError as ve:
        assert str(ve) == (
            "missing 1 required positional argument: " "'key'"
        )



# Generated at 2022-06-23 17:09:25.446188
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection("title","key")

# Generated at 2022-06-23 17:09:25.959584
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    pass

# Generated at 2022-06-23 17:09:38.313370
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    doc_string = '''Docstring description.
    Parameters
    ----------
    param1 : type
        param1 description
    param2 : type, optional
        param2 description
    Returns
    -------
    param1 : type
        return1 description
    param2 : type
        return2 description
    Warnings
    --------
    warning1
        warning1 description
    warning2
        warning2 description'''

    new_section = Section('Notes', 'notes')

# Generated at 2022-06-23 17:09:42.929806
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection('deprecated', 'deprecation')
    docstring = section.parse('Deprecated since version 0.1.0\nDescription of this deprecation')
    assert docstring[0].version == '0.1.0'
    assert docstring[0].description == 'Description of this deprecation'

# Generated at 2022-06-23 17:09:47.259524
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # Arrange
    expected = ParamSection("Parameters", "param")
    # Act
    actual = ParamSection("Parameters", "param")
    # Assert
    assert expected == actual

# Generated at 2022-06-23 17:09:50.473225
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rs = RaisesSection("Raises", "raises")
    assert rs.title == "Raises"
    assert rs.key == "raises"



# Generated at 2022-06-23 17:09:58.949326
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    class MySection(Section):
        def __init__(self):
            Section.__init__(self, "MySection", "mykey")
            self.value = None
    
    def _parse_item(self, key: str, value: str) -> DocstringMeta:
        self.value = value

    MySection.parse = _parse_item

    np = NumpydocParser()
    np.add_section(MySection())
    doc = np.parse("MySection\n----\nan example")
    assert len(doc.meta) == 1
    assert doc.meta[0].args == ["mykey"]
    assert doc.meta[0].description == "an example"

# Generated at 2022-06-23 17:10:04.334305
# Unit test for constructor of class Section
def test_Section():
    s = Section("title", "key")
    assert s.title == "title"
    assert s.title_pattern == "^(title)\\s*?\\n{}\\s*$".format("-" * len(s.title))
    assert s.key == "key"
    assert s.parse(" ") == (DocstringMeta([s.key], description=None),)
    assert s.parse("a") == (DocstringMeta([s.key], description="a"),)
    assert s.parse("a\n b\n  c") == (DocstringMeta([s.key], description="a\n b\n  c"),)

# Generated at 2022-06-23 17:10:05.530667
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection("deprecation warning", "deprecation")



# Generated at 2022-06-23 17:10:08.879005
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    assert list(_KVSection("", "").parse("key1\n    value1\nkey2\n    value2")) == [
        DocstringMeta(["", "key1"], description="value1"),
        DocstringMeta(["", "key2"], description="value2"),
    ]



# Generated at 2022-06-23 17:10:20.473026
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rs = RaisesSection(title = "Raises", key = "Raises")
    assert rs.title == "Raises"
    assert rs.key == "Raises"
    assert rs.title_pattern == "^Raises\s*?\n{}\s*$".format("-" * len("Raises"))
    assert rs.title_pattern == r"^Raises\s*?\n{}\s*$".format("Raises")
    assert rs._parse_item(key='ValueError', value="A description of what might raise ValueError") == DocstringRaises(args=['Raises', 'ValueError'], description='A description of what might raise ValueError', type_name='ValueError')


# Generated at 2022-06-23 17:10:26.056444
# Unit test for constructor of class ParamSection
def test_ParamSection():
    test_section = ParamSection("Parameters", "param")
    assert test_section.title == "Parameters"
    assert test_section.key == "param"
    assert test_section.title_pattern == '^(Parameters)\\s*?\\n-{9}\\s*$'


# Generated at 2022-06-23 17:10:31.876368
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    np_parser = NumpydocParser()
    org_section_len = len(np_parser.sections)
    new_section = Section("Unit testing", "unit_test")
    np_parser.add_section(new_section)
    assert len(np_parser.sections) == org_section_len + 1


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 17:10:35.026829
# Unit test for constructor of class Section
def test_Section():
    section = Section('Parameters', 'param')
    assert isinstance(section, Section)
    assert section.title == 'Parameters'
    assert section.key == 'param'


# Generated at 2022-06-23 17:10:37.761322
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
  parser = NumpydocParser()
  assert parser.parse("") == Docstring()
  assert parser.sections == DEFAULT_SECTIONS

# Generated at 2022-06-23 17:10:39.877442
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser


# Generated at 2022-06-23 17:10:52.815035
# Unit test for constructor of class Section
def test_Section():
    example = """Parameters
    ----------
    x: int
        Blah blah
        """
    section_title = "Parameters"
    section_key = "param"

# Generated at 2022-06-23 17:10:55.419684
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection("Yields", "yields").is_generator == True
    assert YieldsSection("Yield", "yields").is_generator == True

# Generated at 2022-06-23 17:10:57.192719
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    t = YieldsSection("Yields", "yields")
    assert t.is_generator == True

# Generated at 2022-06-23 17:11:00.771237
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    test_string = '''
.. deprecated:: 3.2
   
   This method has been deprecated
    '''
    assert DeprecationSection("deprecated", "deprecated").parse(test_string) == tuple([DocstringDeprecated(args=['deprecated'], description=None, version='3.2')])

# Generated at 2022-06-23 17:11:02.413992
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    di = DeprecationSection("a", "b")
    assert di.title == "a"
    assert di.key == "b"

# Generated at 2022-06-23 17:11:04.829732
# Unit test for constructor of class Section
def test_Section():
    section = Section("title", "key")
    assert section.title == "title"
    assert section.key == "key"


# Generated at 2022-06-23 17:11:10.966691
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    title = "Deprecation Warning"
    key = "deprecation"
    section = DeprecationSection(title, key)
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == r"^\.\.\s*(Deprecation Warning)\s*::"

# Generated at 2022-06-23 17:11:21.159451
# Unit test for function parse
def test_parse():
    import pprint

# Generated at 2022-06-23 17:11:28.672059
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    parser = NumpydocParser()
    parser.add_section(DeprecationSection("Deprecated", "deprecated"))
    x = parser.parse("""DeprecationWarning
        :: version 1.0
        ::
            This is a deprecation warning.
    """)
    y = Docstring()
    y.meta = [DocstringDeprecated(["deprecated"], "This is a deprecation warning.", "version 1.0")]
    assert(y == x)

# Generated at 2022-06-23 17:11:30.456457
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():

    assert _SphinxSection(".. title:: something", "title") is not None

# Generated at 2022-06-23 17:11:41.822046
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():      
    # Note that this is the docstring for this method. It is indented so that
    # it appears correctly in the documentation.
    
    numpydocparser = NumpydocParser()
    numpydocparser.add_section(Section("Test", "test"))
    docstring_out = numpydocparser.parse("""
    Short description.

    Long description.

    Test
        Test description.
    """)
    
    docstring_expected = Docstring()
    docstring_expected.short_description = "Short description."
    docstring_expected.blank_after_short_description = False
    docstring_expected.long_description = "Long description.\n"
    docstring_expected.blank_after_long_description = True

# Generated at 2022-06-23 17:11:45.687416
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    sections = [
        Section("Mytitle", "mytitle"),
        Section("Mytitle2", "mytitle2"),
    ]
    test_parser = NumpydocParser()
    for section in sections:
        test_parser.add_section(section)
    expected = {s.title:s for s in sections}
    sections = test_parser.sections
    assert sections == expected
    assert expected == sections

# Generated at 2022-06-23 17:11:49.321688
# Unit test for constructor of class _KVSection
def test__KVSection():
    test_object = _KVSection("Parameters", "param")
    assert test_object.title == "Parameters"
    assert test_object.key == "param"


# Generated at 2022-06-23 17:11:53.111963
# Unit test for constructor of class _KVSection
def test__KVSection():
    test_section = _KVSection("title", "key")
    assert test_section._KVSection__title == "title"
    assert test_section._KVSection__key == "key"

# Generated at 2022-06-23 17:11:59.384817
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    # test when title = "Test title"
    section = _SphinxSection('Test title', 'param')
    assert section.title == 'Test title'
    assert section.title_pattern == "^\\.\\.\\s*(Test title)\\s*::"

    # test when title = "Test title2"
    section = _SphinxSection('Test title2', 'param')
    assert section.title == 'Test title2'
    assert section.title_pattern == "^\\.\\.\\s*(Test title2)\\s*::"

# Generated at 2022-06-23 17:12:11.850621
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    # Test one
    text = """
    short_description
    
    long_description
    
    Parameters
    ----------
    param_1 : str, optional
        param_1 description
    param_2, optional
        param_2 description
    
    Returns
    -------
    type_1, type_2: 
        value_1, value_2
    
    """

    docstring = NumpydocParser().parse(text)

    assert docstring.short_description == "short_description"
    assert docstring.long_description == "long_description"

    # Test params
    assert docstring.meta[0].args[0] == "param"
    assert docstring.meta[0].args[1] == "param_1"
    assert docstring.meta[0].type_name == "str"

# Generated at 2022-06-23 17:12:21.389576
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """\
    a
        d
    b : ty
        d2
    c
        d3
    """
    parsed = _KVSection("", "").parse(text)
    assert [
        m._replace(description=m.description.replace("\n", " ")) for m in parsed
    ] == [
        DocstringMeta(["", "a"], "d"),
        DocstringMeta(["", "b"], "d2", type_name="ty"),
        DocstringMeta(["", "c"], "d3"),
    ]



# Generated at 2022-06-23 17:12:26.041749
# Unit test for function parse
def test_parse():

    def add(x, y):

        """
        Short description

        Long description

        Parameters
        ----------
        x : int
            Parameter x
        y : int, optional
            Parameter y (default is 2)

        Returns
        -------
        int
            Sum of x and y
        """

        return x + y

    docstring = parse(add.__doc__)

    assert docstring.short_description == "Short description"
    assert docstring.long_description == "Long description"
    assert len(docstring.meta) == 3

    param_info = docstring.meta[0]
    assert param_info.description == "Parameter x"
    assert param_info.key == "param"
    assert param_info.args == ["x"]
    assert param_info.arg_name == "x"
    assert param

# Generated at 2022-06-23 17:12:28.572400
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    test_section = _SphinxSection("title", "key")
    assert test_section.title == "title"
    assert test_section.key == "key"
    assert test_section.title_pattern == r"^\.\.\s*(title)\s*::"


# Generated at 2022-06-23 17:12:37.829257
# Unit test for function parse
def test_parse():
    doc = inspect.cleandoc("""
        Section 1
        ---------
        param foo
            Arg foo.
        param bar
            Arg bar is an optional argument.
        return
            Return value.
        yields
            Yield value.
        raisess
            Raised errors.
        .. deprecated:: 1.2
            Foobar is deprecated.
        a paragraph
        """)

# Generated at 2022-06-23 17:12:39.763518
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    NumpydocParser(sections=None)



# Generated at 2022-06-23 17:12:45.717866
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises_section = RaisesSection("Raises", "raises")
    assert isinstance(raises_section, Section)
    assert isinstance(raises_section, _KVSection)
    assert raises_section.title == "Raises"
    assert raises_section.key == "raises"
    assert isinstance(raises_section.title_pattern, str)


# Generated at 2022-06-23 17:12:52.037473
# Unit test for constructor of class ParamSection
def test_ParamSection():
    text = r"""
    Parameters
    ----------

    arg_name
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    paramSection = ParamSection("Parameters", "param")
    assert paramSection.parse(text) is not None


# Generated at 2022-06-23 17:12:58.694972
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    method = numpydoc_parser.DeprecationSection('deprecated','deprecation')
    #print(method.parse('.   deprecated:: 2.1.1\n\n        Replaced by :func:`get`.'))
    print(method.parse('.   deprecated:: 2.1.1'))
    print(method.parse('.   deprecated:: 2.1.1\n\n        Replaced by :func:`get`.'))
    print(method.parse('.   deprecated:: 2.1.1\n\n        Replaced by :func:`get`.'))

# Generated at 2022-06-23 17:13:03.501627
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection("Parameters", "param")
    assert p.title == 'Parameters'
    assert p.key == 'param'
    assert p.title_pattern == r'^(Parameters)\s*?\n{}\s*$'.format('-' * len('Parameters'))

# Generated at 2022-06-23 17:13:08.635890
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # test case 1
    section1 = Section('Parameters', 'param')
    parser = NumpydocParser()
    parser.add_section(section1)
    assert section1.title in parser.sections
    # test case 2
    section2 = Section('Yields', 'yields')
    assert section2.title in parser.sections
    parser.add_section(section2)
    assert parser.sections['Yields'] is section2

# Generated at 2022-06-23 17:13:14.574272
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    from .common import DocstringMeta
    from ._parser import _KVSection

    section = _KVSection("section", "section")
    test_str = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """

    docstring = Docstring()
    docstring.meta.extend(section.parse(test_str))

    expected = [
        DocstringMeta(["section"], description="value"),
        DocstringMeta(["section"], description="values can also span...\n... multiple lines"),
    ]

    assert docstring.meta == expected

# Generated at 2022-06-23 17:13:23.366902
# Unit test for constructor of class _KVSection

# Generated at 2022-06-23 17:13:25.272356
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Method name", "method")
    assert section.parse("1")[0].description == "1"


# Generated at 2022-06-23 17:13:26.805018
# Unit test for constructor of class _KVSection
def test__KVSection():
    print('Test case for the constructor of class _KVSection')
    print(inspect.getsource(_KVSection))

# Generated at 2022-06-23 17:13:29.263707
# Unit test for method parse of class Section
def test_Section_parse():
    section_obj = Section('Title','key')
    text = '       '
    assert section_obj.parse(text)



# Generated at 2022-06-23 17:13:40.197709
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection("Parameters", "param")
    assert p.parse("") == []
    assert p.parse(" : str\n    ") == []
    assert p.parse(" : str") == []
    assert p.parse("arg_name\n    arg_description") == [
        DocstringParam(
            args=["param", "arg_name"],
            description=None,
            arg_name="arg_name",
            type_name=None,
            is_optional=None,
            default=None,
        )
    ]

# Generated at 2022-06-23 17:13:47.431375
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    test_docstring = """\
    .. deprecated:: 1.2.3
        will be removed\n
    """

    ret = NumpydocParser().parse(test_docstring)
    assert ret.meta[0].args == ['deprecation']
    assert ret.meta[0].description == 'will be removed'
    assert ret.meta[0].version == '1.2.3'

# Generated at 2022-06-23 17:13:58.037971
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    text = """
Yields
    The next item in the iteration.
    """
    # test header
    header_tmp = re.compile(r"^\.\.\s*(Yields)\s*::", flags=re.M)
    match = header_tmp.search(text)
    title = next(g for g in match.groups() if g is not None)
    assert title == "Yields"

    # test body
    body = text[match.end():]
    factory = YieldsSection(title, "yields")
    ret = factory.parse(body)

    # test returned object
    ret_obj = next(ret)
    assert ret_obj.args == ["yields"]
    assert ret_obj.return_name == None
    assert ret_obj.type_name == None
   

# Generated at 2022-06-23 17:14:08.506083
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    test method
        This is a test method that does nothing.

    Parameters
    ----------
    arg0 : int
        Description of arg0
        Another line for arg0
    arg1 : float
        Description of arg1
    arg2 : str
        Description of arg2

    Returns
    -------
    int
        Description of return value
    """

    ret = NumpydocParser().parse(text)
    assert ret.short_description == "test method"
    assert ret.long_description == "This is a test method that does nothing."
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == True

    assert len(ret.meta) == 1
    assert ret.meta[0].args == ["param", "arg0"]

# Generated at 2022-06-23 17:14:12.350517
# Unit test for constructor of class _KVSection
def test__KVSection():
    obj = _KVSection("Parameters", "param")
    assert isinstance(obj, Section)
    assert obj.title == "Parameters"
    assert obj.key == "param"


# Generated at 2022-06-23 17:14:18.826918
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rs = RaisesSection("Raises", "raises")
    key = "ValueError"
    value = "A description of what might raise ValueError"
    assert rs._parse_item(key, value) == DocstringRaises(
        args=[rs.key, key],
        description=_clean_str(value),
        type_name=key if len(key) > 0 else None,
    )

# Generated at 2022-06-23 17:14:29.766645
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    test_section = _KVSection("key", "value")
    text = """
    key: type, optional
        value

    key2
        value2
    key3: type
    key4

    key5: type
        value5

    key6: type
        value6

    key7
        value7
        """
    assert len(list(test_section.parse(text)))==5
    assert list(test_section.parse(text))[0].args == ["value", "key"]
    assert list(test_section.parse(text))[1].args == ["value", "key2"]
    assert list(test_section.parse(text))[2].args == ["value", "key3"]
    assert list(test_section.parse(text))[3].args == ["value", "key5"]
    assert list

# Generated at 2022-06-23 17:14:33.016563
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Initialize a section
    section1 = _KVSection(title='Section 1', key='section_1')
    # Try to access the title and key attributes.
    assert section1.title == 'Section 1'
    assert section1.key == 'section_1'



# Generated at 2022-06-23 17:14:37.479019
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    some_stuff = ReturnsSection("Returns", "returns")
    assert some_stuff.title == "Returns"
    assert some_stuff.key == "returns"
    assert some_stuff.is_generator == False

# Generated at 2022-06-23 17:14:40.834309
# Unit test for method parse of class Section
def test_Section_parse():
    string = 'Paramaters : class\n'
    parser = Section('Paramaters', 'param')
    assert parser.parse(string) == [DocstringMeta(['param'], description=None)]



# Generated at 2022-06-23 17:14:49.729634
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # Create a default NumpydocParser instance
    parser = NumpydocParser()

    # Create a new section to be added to the parser
    title = "test_example"
    key = "test_example"
    section = Section(title, key)

    # Add the above created section to the parser
    parser.add_section(section)

    # Create a docstring to test the new section addition
    text = """test_example
    -----------
    Example:
        Key: This is a test
        Value: This is a test value
    """

    # Parse the docstring to test the new section
    parsed_doc = parser.parse(text)

    # Test the description attribute
    assert parsed_doc.short_description is None
    assert parsed_doc.blank_after_short_description is False

# Generated at 2022-06-23 17:14:59.984308
# Unit test for method parse of class Section
def test_Section_parse():
    parser = NumpydocParser()
    title = "Parameters"
    key = "param"
    test_text = " Parameters \n ----- \n arg_name \n arg_description \n arg_2 : type, optional \n descriptions can also span... \n ... multiple lines"
    parsed_output = parser.parse(test_text)
    assert parsed_output.meta[0].args == ['param', 'arg_name']
    assert parsed_output.meta[0].description == 'arg_description'
    assert parsed_output.meta[1].args == ['param', 'arg_2']
    assert parsed_output.meta[1].description == 'descriptions can also span...\n... multiple lines'
    assert parsed_output.meta[1].is_optional == True

# Generated at 2022-06-23 17:15:02.956827
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    # initializes all values as expected
    assert ReturnsSection("Returns", "returns").is_generator == False
    assert ReturnsSection("Returns", "returns").title == "Returns"
    assert ReturnsSection("Returns", "returns").key == "returns"

# Generated at 2022-06-23 17:15:08.238803
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    actual = DeprecationSection('Deprecated', 'deprecated')
    assert actual.title_pattern == r"^\.\.\s*(Deprecated)\s*::"
    assert actual.parse(""".. deprecated:: 2.1
  Use :func:`bar` instead.""") == [DocstringDeprecated(['deprecated'], None, '2.1')]

# Generated at 2022-06-23 17:15:12.054317
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yield", "yields")
    assert ys.key == "yields"
    assert ys.title == "Yield"
    assert ys.is_generator == True

# Generated at 2022-06-23 17:15:17.419379
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    dep = DeprecationSection("Deprecated", "deprecation")
    text = "3.0 \nSome deprecation warning"
    result = list(dep.parse(text))
    expected = [DocstringDeprecated(args=['deprecation'], description="Some deprecation warning", version="3.0")]
    assert result == expected


# Generated at 2022-06-23 17:15:21.915069
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    numpy_docstring = "deprecated:: 1.0\n\n"
    numpy_docstring += "This is an easy test"
    section_in_docstring = NumpydocParser().parse(numpy_docstring)
    assert section_in_docstring.meta[0].description == "This is an easy test"

# Generated at 2022-06-23 17:15:25.087539
# Unit test for method parse of class Section
def test_Section_parse():
    sect = Section("title", "key")
    assert list(sect.parse("\n\nfirst line \n Second line\n")) == [DocstringMeta(args=['key'], description='first line Second line')]



# Generated at 2022-06-23 17:15:30.035743
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r = RaisesSection('Raises','raises')
    assert(r.title == "Raises")
    assert(r.key == "raises")
    assert(r.title_pattern == r"^Raises\s*?\n-*$")
    assert(r._parse_item('ValueError','A Value Error') == \
    DocstringRaises(args=['raises', 'ValueError'], description='A Value Error', type_name='ValueError'))
    # Unit test for the parse function
    assert(r.parse('ValueError\nA ValueError') == \
    [DocstringRaises(args=['raises', 'ValueError'], description='A ValueError', type_name='ValueError')])

# Generated at 2022-06-23 17:15:34.240700
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yieldsSection = YieldsSection("Yields", "yields")
    assert yieldsSection.is_generator == True
    assert yieldsSection.key == "yields"
    assert yieldsSection.title == "Yields"

# Generated at 2022-06-23 17:15:45.039114
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    param_a : int
        Parameter a

    param_b : str, optional
        Parameter b

    Raises
    ------
    TypeError
        Parameter a must be int.

    ValueError
        Parameter b must be str.

    Returns
    -------
    bool
        Success or failure.
    """
    import sys

    reload(sys)
    # noinspection PyUnresolvedReferences
    sys.setdefaultencoding('utf-8')
    res = parse(doc)

    # Check short description
    exp_short = "This is a short description."
    assert(res.short_description == exp_short)

    # Check long description
    exp_long = "This is a long description."


# Generated at 2022-06-23 17:15:51.199965
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    nb_sections = len(DEFAULT_SECTIONS)
    numpydocParser = NumpydocParser()
    assert isinstance(numpydocParser, NumpydocParser)
    assert len(numpydocParser.sections) == nb_sections


# Generated at 2022-06-23 17:15:56.030514
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section_name = "Raises"
    section_key = "raises"
    raises_section = RaisesSection(section_name, section_key)
    assert raises_section.title == section_name
    assert raises_section.key == section_key
