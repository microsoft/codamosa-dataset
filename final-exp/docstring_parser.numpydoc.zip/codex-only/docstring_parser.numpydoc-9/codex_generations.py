

# Generated at 2022-06-23 17:06:01.897375
# Unit test for function parse
def test_parse():
    assert parse(
'''
Parameters:
    a: Type of a
        a description
        can be over multiple lines
    b: Type of b
        b description
    c: Type of c
        c description
'''
    ).meta == [
        DocstringMeta(['param', 'a'], description='a description\ncan be over multiple lines', type_name='Type of a', arg_name='a'),
        DocstringMeta(['param', 'b'], description='b description', type_name='Type of b', arg_name='b'),
        DocstringMeta(['param', 'c'], description='c description', type_name='Type of c', arg_name='c')
    ]


# Generated at 2022-06-23 17:06:09.204033
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 5.4.0
        The old behavior has been deprecated."""
    factory = DeprecationSection("deprecated", "deprecation")
    result = [
        DocstringDeprecated(
            args=["deprecation"], description="The old behavior has been deprecated.", version="5.4.0"
        )
    ]
    assert factory.parse(text) == result


# Generated at 2022-06-23 17:06:16.308272
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    python3 = """
    .. deprecated::
        This function is deprecated as of NumPy 1.14.0. Use
        :func:`numpy.stack` instead.
    """
    parser = NumpydocParser()
    deprecation = parser.parse(python3).meta[0]
    assert deprecation.version == "NumPy 1.14.0"
    assert deprecation.description == "Use :func:`numpy.stack` instead."



# Generated at 2022-06-23 17:06:23.714682
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

    class Cls:
        """
        Parse the numpy-style docstring into its components.

                :param text: docstring text.

                :returns: parsed docstring
                """
        pass

    text = inspect.getdoc(Cls)
    docstring = parser.parse(text)
    assert isinstance(docstring, Docstring)


# Generated at 2022-06-23 17:06:28.379462
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    deprecation_section = DeprecationSection("deprecated", "deprecation")
    text = """1.2
    Description
    Description
    """
    doc = deprecation_section.parse(text)
    assert next(doc).description == "Description\nDescription\n"

# Generated at 2022-06-23 17:06:34.506756
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    text = """
    Args:
    ------
    arg1: description
    arg2 = 12: description

    Returns:
    ---------
    return_value : int
        Description of returned value
    """
    parser = NumpydocParser()
    parsed_docstring = parser.parse(text)
    assert len(parsed_docstring.meta) > 0
    return


# Generated at 2022-06-23 17:06:36.357420
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection("Yields", "yields")
    assert y.is_generator == True

# Generated at 2022-06-23 17:06:42.404415
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    parser = NumpydocParser().parse
    section = DeprecationSection('Deprecated', 'deprecation')
    text = ".. deprecated:: 1.2.3\n    something is better""\n"
    assert parser(text.strip()) == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=None,
        blank_after_long_description=None,
        meta=[DocstringDeprecated(args=['deprecation'], description=u'something is better', version='1.2.3')]
    )

# Generated at 2022-06-23 17:06:45.216183
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    expected = YieldsSection("Yield", "yields")
    assert expected.is_generator == True

# Generated at 2022-06-23 17:06:49.841875
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Test that DeprecationSection.parse() splits text with "\n"
    section = DeprecationSection("Deprecated", "deprecated")
    result = section.parse("Text above the line\nDeprecated: Below the line")
    assert result.description == "Below the line"

# Generated at 2022-06-23 17:07:00.967242
# Unit test for function parse
def test_parse():
    docstring = """\
    This docstring is about a class.

    Parameters
    ----------
    something : str
        with some very, very long explanation
            over multiple lines.

    something_else : int, optional
        with some other explanation,
            which also spans multiple lines.

    Returns
    -------
    result : float, optional
        with some very, very long description
            over multiple lines
            and more
            and more

    Raises
    ------
    ValueError : if something is wrong.
    OtherError : if something else is wrong.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This docstring is about a class."
    assert parsed.long_description == None
    assert parsed.blank_after_short_description == False
    assert parsed.blank_after_long_description == False


# Generated at 2022-06-23 17:07:03.633077
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    test = YieldsSection('Yields', 'yields')
    if test.title != 'Yields':
        raise ValueError('Failed to test YieldsSection constructor')


# Generated at 2022-06-23 17:07:06.638885
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "deprecated"
    key = "deprecated"
    title_pattern = r"^\.\.\s*({})\s*::".format(title)
    assert Section(title, key).title_pattern == title_pattern

# Generated at 2022-06-23 17:07:08.544800
# Unit test for constructor of class Section
def test_Section():
    obj = Section("Parameters", "param")
    assert obj.title == "Parameters"
    assert obj.key == "param"



# Generated at 2022-06-23 17:07:13.145208
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # test fails because version and description are not taken into account

    ds = DeprecationSection("Deprecated", "deprecation")
    text = """
    .. deprecated:: 0.2.3
        This is a description of the deprecation.
    """
    meta = ds.parse(text)
    assert next(iter(meta)).description == "This is a description of the deprecation."
    assert next(iter(meta)).version == "0.2.3"



# Generated at 2022-06-23 17:07:14.662182
# Unit test for constructor of class Section
def test_Section():
    assert Section(title='Parameters', key='param').title == 'Parameters'
    assert Section(title='Parameters', key='param').key == 'param'


# Generated at 2022-06-23 17:07:19.183238
# Unit test for constructor of class NumpydocParser

# Generated at 2022-06-23 17:07:23.438161
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection("Section Title", "Test")
    assert s.title == "Section Title"
    assert s.title_pattern == "^\.\.\\s*(Section Title)\\s*::"



# Generated at 2022-06-23 17:07:33.175943
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    deprecation_section = DeprecationSection("Deprecated", "deprecation")
    parser = NumpydocParser([deprecation_section])
    text = """\
    This is a sample docstring with parameters and other sections.

    Parameters
    ----------
    arg_1 : int
        Argument number 1.
    arg_2
        Argument number 2.

    Deprecated
    ----------
    The deprecation section.

    Raises
    ------
    ValueError
        The base exception.
    """

# Generated at 2022-06-23 17:07:35.766836
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection( "Returns", "returns").is_generator == False
    assert ReturnsSection( "Yields", "yields").is_generator == True

# Generated at 2022-06-23 17:07:43.067438
# Unit test for constructor of class _KVSection
def test__KVSection():
    # The constructor of class _KVSection is not accessible,
    # nor can it be inherited, so it's necessary to create
    # a test case for it.
    import unittest

    class Test__KVSection(unittest.TestCase):
        def setUp(self):
            title = "Parameters"
            key = "param"
            self.section = _KVSection(title, key)

        def test__KVSection_init(self):
            self.assertEqual(self.section.title, "Parameters")
            self.assertEqual(self.section.key, "param")

        def test__KVSection_title_pattern(self):
            title_pattern = "[^\\n]*\\n[=-]+\\s*"

# Generated at 2022-06-23 17:07:49.104849
# Unit test for constructor of class RaisesSection
def test_RaisesSection():

    class RaisesSectionTest(RaisesSection):
        def __init__(self) -> None:
            self.title = "Raises"
            self.key = "raises"
    obj = RaisesSectionTest()
    docstring = """
        ValueError
            A description of what might raise ValueError
    """
    docstring_list = [DocstringRaises(['raises', 'ValueError'], 'A description of what might raise ValueError', 'ValueError')]
    assert list(obj.parse(docstring)) == docstring_list


# Generated at 2022-06-23 17:07:55.626031
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    _SphinxSection.title = 'test_title'
    _SphinxSection.key = 'test_key'
    expected_title_pattern = '^\.\.\\s*test_title\\s*:\\s*:'
    actual_title_pattern = _SphinxSection.title_pattern
    assert expected_title_pattern == actual_title_pattern


# Generated at 2022-06-23 17:08:00.644359
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """.. deprecated:: this is deprecated"""
    factory = DeprecationSection('deprecated', 'deprecation')
    result = factory.parse(text)
    print(result)

if __name__ == "__main__":
    test_DeprecationSection_parse()

# Generated at 2022-06-23 17:08:02.205922
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    parser = YieldsSection(title="Yields", key="yields")

# Generated at 2022-06-23 17:08:04.549362
# Unit test for constructor of class Section
def test_Section():
    sctn = Section("Parameters", "param")
    assert sctn.title == "Parameters"
    assert sctn.key == "param"


# Generated at 2022-06-23 17:08:16.098848
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Testing docstring with only a deprecation warning
    my_deprecation_section = DeprecationSection("Deprecated", "deprecated")
    text = "0.1\nDeprecated since version 0.5: Use another method instead.\n"
    expected_result = [
        DocstringDeprecated(
            args=[
                my_deprecation_section.key
            ],
            description="Deprecated since version 0.5: Use another method instead.",
            version="0.1"
        )
    ]
    assert list(my_deprecation_section.parse(text)) == expected_result

    # Testing docstring with a deprecation warning and other sections
    my_docs = NumpydocParser(sections=[my_deprecation_section])

# Generated at 2022-06-23 17:08:21.128089
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises_section = RaisesSection("Raises", "raises")
    assert raises_section.title == "Raises"
    assert raises_section.key == "raises"


# Generated at 2022-06-23 17:08:31.128613
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    parser = _KVSection(title="Test", key="test")
    text = (
        "a \b\n "
        "        a desc \n"
        "b: b_type\n"
        "        b desc\n"
        "c: c_type, optional\n"
        "        c desc\n"
        "d, optional\n"
        "        d desc\n"
    )

    str_ = inspect.cleandoc(text)
    ret = parser._KVSection.parse(str_)
    assert ret == ['a', 'b: b_type', 'c: c_type, optional', 'd, optional']


# Generated at 2022-06-23 17:08:41.534116
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    import pytest
    class TestSection(_KVSection):
        title = "test"
        key = "key"
        def _parse_item(self, key: str, value: str) -> DocstringMeta:
            assert key=='key'
            return DocstringMeta([self.key], description=_clean_str(value))
    obj = TestSection(title="Test", key="key")
    text = 'key\n    value\nkey : type\n    value\n'
    result = obj.parse(text)
    expected = [DocstringMeta(['key'], 'value'), DocstringMeta(['key'], 'value')]
    assert list(result) == expected


# Generated at 2022-06-23 17:08:53.771237
# Unit test for constructor of class _KVSection
def test__KVSection():
    title = 'Returns'
    key = 'returns'
    section = _KVSection(title, key)
    assert section.title==title
    assert section.key==key
    assert section.title_pattern==r'^(Returns)\s*?\n\s*$'
    title = 'Returns'
    key = 'returns'
    section = _KVSection(title, key)
    assert section.title==title
    assert section.key==key
    assert section.title_pattern==r'^(Returns)\s*?\n\s*$'
    title = 'Returns'
    key = 'returns'
    section = _KVSection(title, key)
    assert section.title==title
    assert section.key==key

# Generated at 2022-06-23 17:09:05.929304
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """
    Test method add_section of the class NumpydocParser
    """
    parser = NumpydocParser()
    title = "my_title"
    key = "my_key"
    text = "This is the text of my section"
    section_docstring = Section(title=title, key=key)
    parser.add_section(section_docstring)
    docstring = parser.parse(text)
    assert docstring.short_description == text
    assert docstring.meta[0].description == text
    assert docstring.meta[0].args == [key]
    assert docstring.meta[0].is_examples == False
    assert docstring.meta[0].is_long_description == False
    assert docstring.meta[0].is_short_description == False

# Generated at 2022-06-23 17:09:08.752351
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yields", "yields")
    assert ys.title == "Yields"
    assert ys.key == "yields"

# Generated at 2022-06-23 17:09:13.293121
# Unit test for method parse of class Section
def test_Section_parse():
    a = Section('a', 'a')
    assert a.parse('  1\n 2\n  3 ') == [DocstringMeta([1, 2, 3])]


# Generated at 2022-06-23 17:09:19.473098
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    text = "Returns\n   object\n   the returned object"
    assert ReturnsSection("Returns", "Returns").parse(text) == [
        DocstringReturns(
            args=["Returns"],
            description=None,
            type_name=None,
            is_generator=False,
            return_name=None,
        )
    ]


# Generated at 2022-06-23 17:09:21.754762
# Unit test for constructor of class _KVSection
def test__KVSection():
    title = "Pre"
    key = "Pre"
    test = _KVSection(title,key)
    assert test != None


# Generated at 2022-06-23 17:09:27.178464
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    text = """
    Some function.

    Parameters
    ----------
    x : int
        A parameter
    y : str
        Another parameter

    Returns
    -------
    str
        The result
    """

    np = NumpydocParser()
    expected = np.parse(text)
    assert len(expected.meta) == 2
    assert expected.meta[0].args == ['param', 'x']
    assert expected.meta[1].args == ['returns']

    sp = Section('Returns', 'returns')
    np.add_section(sp)
    assert np.titles_re.pattern == \
            r'^(Parameters)\s*?\n^-*$|^(Returns)\s*?\n^-*$'

    actual = np.parse(text)

# Generated at 2022-06-23 17:09:32.055780
# Unit test for constructor of class ParamSection
def test_ParamSection():
    section = ParamSection("Parameters", "param")
    assert section.title == "Parameters"
    assert section.key == "param"
    assert section.title_pattern == r"^Parameters\s*?\n----\s*$"


# Generated at 2022-06-23 17:09:34.005435
# Unit test for constructor of class ParamSection
def test_ParamSection():
    tmp= ParamSection('Parameters','param')
    assert tmp.title=='Parameters'
    assert tmp.key=='param'
    assert tmp.title_pattern==r'^(Parameters)\s*?\n-{8}\s*$'


# Generated at 2022-06-23 17:09:35.888045
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section = ReturnsSection("Returns", "returns")
    assert section.is_generator == False


# Generated at 2022-06-23 17:09:38.085910
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():

    assert NumpydocParser is not None
    assert len(NumpydocParser().sections) == len(DEFAULT_SECTIONS)


# Generated at 2022-06-23 17:09:43.108211
# Unit test for constructor of class _KVSection
def test__KVSection():
    section_title = 'section_title'
    section_key = 'section_key'
    my_section_object = _KVSection(section_title, section_key)
    assert my_section_object._KVSection__title == section_title
    assert my_section_object._KVSection__key == section_key


# Generated at 2022-06-23 17:09:53.224794
# Unit test for function parse
def test_parse():
    def foo(a, b=1, c=2):
        """ Parameters
        ----------
        a: int
            This is a
        b: int
        """
        pass

    doc = parse(foo.__doc__)
    assert doc.meta[0].meta_key == 'param'
    assert doc.meta[0].args[1] == 'a'
    assert doc.meta[0].description == 'This is a'
    assert doc.meta[1].args[1] == 'b'
    assert doc.meta[1].description == ''

# Generated at 2022-06-23 17:10:01.419896
# Unit test for function parse
def test_parse():
    s = """One line summary
    extended description

    Params
    -----

    one
        one desc.
    two : type
        two desc.

    Returns
    -------

    returns
        returns desc.
    """

    n = parse(s)
    # print(n.__dict__)
    assert n.__dict__ == {'short_description': 'One line summary', 'blank_after_short_description': True, 'blank_after_long_description': False, 'long_description': 'extended description', 'meta': [DocstringMeta(args=['param', 'one'], description='one desc.'), DocstringMeta(args=['param', 'two'], description='two desc.'), DocstringMeta(args=['returns'], description='returns desc.')]}



# Generated at 2022-06-23 17:10:04.129763
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    # This should be able to run without errors
    parser = NumpydocParser()
    assert len(parser.sections) > 0


# Generated at 2022-06-23 17:10:08.735358
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
	dep_section = DeprecationSection("deprecation", "deprecation")
	assert dep_section.title_pattern == r"^\.\.\s*(deprecation)\s*::", "Wrong title_pattern"
	assert dep_section.key == "deprecation", "Wrong key"
	assert dep_section.title == "deprecation", "Wrong title"
	

# Generated at 2022-06-23 17:10:10.551744
# Unit test for constructor of class ParamSection
def test_ParamSection():
    result = ParamSection("Parameters", "param")
    assert result.title == 'Parameters'
    assert result.key == 'param'

# Generated at 2022-06-23 17:10:14.887592
# Unit test for constructor of class Section
def test_Section():
    section = Section("title", "key")
    assert section.title == "title"
    assert section.key == "key"
    assert section.title_pattern == r"^(title)\s*?\n------\s*$"


# Generated at 2022-06-23 17:10:19.196947
# Unit test for constructor of class _KVSection
def test__KVSection():
    parser = _KVSection("Parameters", "param")
    assert parser.title == "Parameters"
    assert parser.key == "param"
    pattern = r"^(Parameters)\s*?\n-*\s*$"
    assert parser.title_pattern == pattern


# Generated at 2022-06-23 17:10:26.868540
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    with open('test_doc.txt', 'r') as f:
        text = f.read()
        doc = NumpydocParser().parse(text)
        assert doc.meta[4].args[1] == 'TypeError'
        assert doc.meta[4].args[0] == 'raises'
        assert doc.meta[4].description == 'This is used to test the RaisesSection function'


# Generated at 2022-06-23 17:10:38.222112
# Unit test for function parse
def test_parse():
    text = '''
        Test parse.
        This is a test of the parse function
        \n
        Parameters
        ----------
        x : float
            The value of x
        y : float, optional
            The value of y
        z : float, optional
            The value of z
        \n
        Returns
        -------
        x : float
            The value of x
    '''
    result = parse(text)
    assert result.short_description == 'Test parse.'
    assert result.blank_after_short_description == False 
    assert result.long_description == 'This is a test of the parse function'
    assert result.blank_after_long_description == True
    assert len(result.meta) == 2
    assert result.meta[0].args == ['param', 'x']

# Generated at 2022-06-23 17:10:43.661515
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    my_section = Section('test', 'test_key')
    parser = NumpydocParser()
    parser.add_section(my_section)
    assert parser.sections['test'] is my_section

# Generated at 2022-06-23 17:10:48.243620
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = "Remove in 2.0.0\n\t\t\tReason for deprecation"
    parsed_deprecation_section = NumpydocParser().parse(text)
    assert parsed_deprecation_section.meta[0].description == "Reason for deprecation"

# Generated at 2022-06-23 17:10:58.273296
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    Parameters
    ----------
    g: instance of :class:`networkx.Graph`

    Returns
    -------
    r : instance of :class:`networkx.Graph`

    Raises
    ------
    NetworkXError

    See Also
    --------
    numpy.random.randn
    '''
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "g"]
    assert docstring.meta[0].description == "instance of :class:`networkx.Graph`"
    assert docstring.meta[1].args == ["returns"]
    assert docstring

# Generated at 2022-06-23 17:11:03.671353
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = 'a\n    first value\nb\n    second value\nc\n    third value'
    kv_parser = _KVSection('KV', 'key')
    parser_returns = [i.args for i in kv_parser.parse(text)]
    assert parser_returns == [['key', 'a'], ['key', 'b'], ['key', 'c']]



# Generated at 2022-06-23 17:11:07.495740
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "Sphinx"
    key = "sphinx"
    s = _SphinxSection(title, key)
    assert s.title == title
    assert s.key == key

# Generated at 2022-06-23 17:11:09.484935
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    return "Raise"


# Generated at 2022-06-23 17:11:13.882796
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    deprecationSection = DeprecationSection("deprecated", "deprecation")
    assert deprecationSection.title == "deprecated"
    assert deprecationSection.key == "deprecation"
    assert deprecationSection.title_pattern == "^\\.\\.\\s*(deprecated)\\s*::"

# Generated at 2022-06-23 17:11:18.994045
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text = 'ValueError\nA description of what might raise ValueError'
    raises = RaisesSection("Raises", "raises")
    result = raises._parse_item("ValueError", "A description of what might raise ValueError")
    assert result.args == ["raises", "ValueError"]
    assert result.description == "A description of what might raise ValueError"
    assert result.type_name == "ValueError"

# Generated at 2022-06-23 17:11:21.288711
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ps = ParamSection("Parameters", "param")
    print(ps.title)
    print(ps.key)
    print(ps.title_pattern)


# Generated at 2022-06-23 17:11:24.226506
# Unit test for constructor of class Section
def test_Section():
    title = "Parameters"
    key = "parameters"
    s = Section(title, key)
    s.title_pattern

# Generated at 2022-06-23 17:11:26.213148
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("Something", "something"))

# Generated at 2022-06-23 17:11:38.358897
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringMeta

    text = '''
    This is the short description.
    The long description spans multiple lines.

    Parameters
    ----------
    arg1 : int
        The first parameter

    Returns
    -------
    str
        The return value
    '''
    text = inspect.cleandoc(text)
    doc = parse(text)
    assert isinstance(doc, Docstring)
    assert doc.short_description == 'This is the short description.'
    assert doc.long_description == 'The long description spans multiple lines.'
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta[0].description == 'The first parameter'
    assert doc.meta[0].type_name == 'int'
    assert doc

# Generated at 2022-06-23 17:11:46.459208
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    # test_ReturnsSection_constructor_1: ReturnSection(title, key), title=None
    try:
        ReturnsSection(None, "return")
        assert False
    except TypeError:
        assert True

    # test_ReturnsSection_constructor_2: ReturnSection(title, key), key=None
    try:
        ReturnsSection("Returns", None)
        assert False
    except TypeError:
        assert True

    # test_ReturnsSection_constructor_3: ReturnSection(title, key), title="Returns"
    # ReturnSection(title, key), key="returns"
    # test_ReturnsSection_constructor_4: ReturnSection(title, key), title="return"
    # ReturnSection(title, key), key="returns"

# Generated at 2022-06-23 17:11:56.612517
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    meta_text = """
    key1
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    
    meta = NumpydocParser().parse(meta_text)
    assert str(meta) == ('[\n'
                         '    Description(None, None, None),\n'
                         '    DocstringMeta(args=[\'key1\'], description=\'value\'),\n'
                         '    DocstringMeta(args=[\'key2\'], description=\'values can also span...\n'
                         '        ... multiple lines\'),\n'
                         ']')


# Generated at 2022-06-23 17:12:04.354240
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    section1 = Section("New Section", "new_section")
    section2 = Section("New Section", "old_section")
    parser = NumpydocParser()
    parser.add_section(section1)
    assert parser.parse("\n".join(["New Section"]) == Docstring())
    parser.add_section(section2)
    assert parser.parse("\n".join(["New Section"]) == Docstring())

# Generated at 2022-06-23 17:12:14.490049
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    Short description

    Long description

    Other info
    """

    docstring_short = """Short description"""

    docstring_long = """
    Short description
    Long description

    Other info
    """

    docstring_no_long = """Short description"""

    docstring_attribute = """Short description
    Attributes:
        attr1: attr description
        attr2:
            attr description
            spread over multiple lines
    """

    docstring_deprecated = """Short description
    .. deprecated:: 1.2.10
        Deprecated in version 1.2.10
    """

    parser = NumpydocParser()
    parsed_short = parser.parse(docstring_short).short_description
    parsed_long = parser.parse(docstring_long).long_description

# Generated at 2022-06-23 17:12:25.864439
# Unit test for function parse
def test_parse():
    txt = """This function does something.

    Parameters
    ----------
        x
            The x data.
        y
            The y data.

    Returns
    -------
        The AUC.
    """
    ret= parse(txt)
    assert ret.short_description == "This function does something."
    assert ret.blank_after_short_description == True
    assert ret.long_description == ""
    assert ret.blank_after_long_description == True
    assert ret.meta[0].args == ["param", "x"]
    assert ret.meta[0].description == "The x data."
    assert ret.meta[1].args == ["param", "y"]
    assert ret.meta[1].description == "The y data."
    assert ret.meta[2].args == ["returns"]

# Generated at 2022-06-23 17:12:29.909564
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    _r = RaisesSection("Raises", "raises")
    _r.parse("ValueError\n\tA description of what might raise ValueError")
    _r.parse("\tA description of what might raise ValueError")

# Generated at 2022-06-23 17:12:36.895874
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    title
        value
    title 2
        value 2
    """
    def parse_item(self, key: str, value: str) -> DocstringMeta:
        return DocstringMeta([self.key, key], description=_clean_str(value))

    a = _KVSection("title", "param")
    a.parse_item = parse_item.__get__(a)

    assert a.parse(text) == (
        DocstringMeta(["param", "title"], description="value"),
        DocstringMeta(["param", "title 2"], description="value 2"),
    )


# Generated at 2022-06-23 17:12:41.684011
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection("This is a test", "test")
    assert s.title == "This is a test"
    assert s.key == "test"
    assert s.title_pattern == r"^\.\.\s*(This is a test)\s*::"


# Generated at 2022-06-23 17:12:45.774188
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """This module is tested through:

        test_numpydoc.py TestNumpydoc.test_add_section

    See TestNumpydoc.test_add_section for details of the test.
    """
    pass

# Generated at 2022-06-23 17:12:52.516103
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    class TestSection(_SphinxSection):
        def __init__(self, title: str, key: str) -> None:
            self.title = title
            self.key = key

    x = TestSection("title1", "key1")
    assert x.title_pattern == r"^\.\.\s*(title1)\s*::"
    return x


# Generated at 2022-06-23 17:12:58.703369
# Unit test for constructor of class Section
def test_Section():
    '''
        test for constructor of Section and related attributes
    '''
    title = 'Parameters'
    key = 'param'
    s = Section(title, key)
    # test for title
    assert s.title == 'Parameters'
    # test for key
    assert s.key == 'param'
    # test for title_pattern
    assert s.title_pattern == r"^(Parameters)\s*?\n{}\s*$".format('-'*len(s.title))


# Generated at 2022-06-23 17:13:01.016685
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    title = "Deprecated"
    key = "deprecation"
    sec = DeprecationSection(title, key)
    assert sec.title == title
    assert sec.key == key

# Generated at 2022-06-23 17:13:05.369777
# Unit test for constructor of class _KVSection
def test__KVSection():
    s = _KVSection("LABEL", "LABEL_KEY")
    assert s.key == "LABEL_KEY"
    assert s.title == "LABEL"
    assert s.title_pattern == "^(LABEL)\s*?\n---*\s*$"
    
    

# Generated at 2022-06-23 17:13:12.615409
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Tests NumpydocParser.parse by passing multiple arguments.
    """
    # Example arguments to test this method
    args = [
        "Return the square of each element.",
        "    """
        "    Parameters\n"
        "    ----------\n"
        "    other :\n"
        "        0 to 3\n"
        "\n"
        "    Returns\n"
        "    -------\n"
        "    value : int\n"
        "        The return value.\n"
        "    """
        "\n"
        "    return xyzzy\n"
        "\n",
    ]

    # Expected output from parsed NumpydocParser()

# Generated at 2022-06-23 17:13:23.745007
# Unit test for function parse
def test_parse():
    def func(a, b=2, c=3):
        """A short desc.

        This is a
        longer desc.
        Blah blah.

        Parameters
        ==========
        a : str
            A required argument with a type.
        b : int, optional
            An optional argument, with default value.
        c : tuple
            A default argument with a tuple type.

        Returns
        =======
        ret : object

        Raises
        ======
        ValueError
            When things go wrong.

        Warns
        =====
        UserWarning
            If a user does something dumb.

        """
        pass

    docstring = parse(inspect.getdoc(func))
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "A short desc."
    assert docstring.long_description

# Generated at 2022-06-23 17:13:33.593899
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Test for good parameters
    test_key = 'name'
    test_value = 'value'
    _KVSection(test_key, test_value)
    # Test for bad parameter
    test_key = None
    test_value = 'value'
    try:
        _KVSection(test_key, test_value)
        assert False
    except:
        assert True

    test_key = 'name'
    test_value = None
    try:
        _KVSection(test_key, test_value)
        assert False
    except:
        assert True


# Generated at 2022-06-23 17:13:34.813881
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
  assert YieldsSection is not None

# Generated at 2022-06-23 17:13:36.307988
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    DeprecationSection('deprecated', 'deprecation')


# Generated at 2022-06-23 17:13:42.730843
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # text of the section
    t = "Deprecated in version 1.0.0\nRemoved in version 2.0.0.\n    Use some_other_func instead.\n"
    ret = list(DeprecationSection("Deprecated in version 1.0.0\nRemoved in version 2.0.0.\n    Use some_other_func instead.\n", "deprecated").parse(t))
    assert ret[0].version == "1.0.0"
    assert ret[0].description == "Removed in version 2.0.0.Use some_other_func instead."

# Generated at 2022-06-23 17:13:46.158240
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
  s = _SphinxSection('title', 'key')
  assert s.title_pattern == '^\.\.\s*(title)\s*::'

# Generated at 2022-06-23 17:13:56.685930
# Unit test for constructor of class _KVSection
def test__KVSection():
    section = _KVSection(
        title="Params",
        key="param",
    )

    # Verify that title_pattern has right value
    assert section.title_pattern == r'^(Params)\s*?\n{}\s*$'.format('-' * len(section.title))

    text = """\
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """

    # Verify that parse() for _KVSection works
    # for the correct text
    result = section.parse(text)
    result_list = list(result)
    assert len(result_list) == 2
    assert isinstance(result_list[0], DocstringMeta)
    assert result_list[0].description == "value"

    # Verify that parse() for _KVSection fails

# Generated at 2022-06-23 17:14:00.557406
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection("Section", "param")
    assert p.title == "Section"
    assert p.key == "param"
    assert p.title_pattern == "^Section\\s*?\n-*\\s*$"


# Generated at 2022-06-23 17:14:05.435710
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    test_cases = [
        ('title', 'something', r'^\.\.\s*(title)\s*::'),
        ('title_2', 'something', r'^\.\.\s*(title_2)\s*::'),
        ('title-3', 'something', r'^\.\.\s*(title-3)\s*::'),
    ]

    for title, description, expected_pattern in test_cases:
        section = _SphinxSection(title=title, key=description)
        assert section.title_pattern == expected_pattern

# Generated at 2022-06-23 17:14:07.178971
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    sec = YieldsSection("Yields", "yields")
    assert sec.is_generator == True
    assert sec.title == "Yields"

# Generated at 2022-06-23 17:14:12.939089
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .example import Example

    import pytest
    from pprint import pformat

    from .common import DocstringAttribute, DocstringMeta

    #########
    # Each test case is a tuple of
    # (test description, docstring text to be parsed, expected parsed result)
    #
    # The expected result is a dictionary which has some keys:
    # - short_description: expected short_description
    # - long_description: expected long_description
    # - blank_after_short_description: expected boolean of blank_after_short_description
    # - blank_after_long_description: expected boolean of blank_after_long_description
    # - meta: expected DocstringMeta
    #########

# Generated at 2022-06-23 17:14:16.362606
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    t = "Returns"
    k = "returns"

    r = ReturnsSection(t, k)
    assert r.title == t
    assert r.key == k


# Generated at 2022-06-23 17:14:25.343843
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    import pytest
    from unittest.mock import MagicMock
    from .common import DocstringReturns
    from logging import getLogger
    from .common import DocstringReturns
    from .common import Docstring
    from .common import DocstringParam
    from .common import DocstringRaises
    from .common import DocstringMeta
    from .numpydoc import NumpydocParser
    from .numpydoc import parse
    from .common import DocstringReturns
    from .common import DocstringDeprecated
    from .numpydoc import DEFAULT_SECTIONS
    from .numpydoc import Section
    from .numpydoc import RaisesSection
    from .numpydoc import ReturnsSection
    from .numpydoc import YieldsSection
    from .numpydoc import DeprecationSection

# Generated at 2022-06-23 17:14:27.234955
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    r = ReturnsSection("Returns", "returns")
    assert r.is_generator == False

# Generated at 2022-06-23 17:14:35.163766
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    test_cases = {
        "args": "Args\n---\n    x : int\n        A number.",
        "return": "Return\n------\n    returns a positive number.",
        "returns": "Returns\n-------\n    a positive number.",
        "param": "Params\n-----\n    x : int\n        A number.",
        "params": "Params\n-----\n    x : int\n        A number.",
        "parameters": "Parameters\n----------\n    x : int\n        A number.",
        "argument": "Arguments\n---------\n    x : int\n        A number.",
        "arguments": "Arguments\n---------\n    x : int\n        A number."
    }

    for title in test_cases.keys():
        test_doc

# Generated at 2022-06-23 17:14:37.771175
# Unit test for constructor of class _KVSection
def test__KVSection():
    s = _KVSection('Parameters','param')
    assert s.__class__.__name__ == "_KVSection"


# Generated at 2022-06-23 17:14:42.316438
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # Define some value
    title = 'Parameter'
    key = 'a'
    section = ParamSection(title, key)

    # Compare the result with what we know
    assert section.title == title
    assert section.key == key

# Generated at 2022-06-23 17:14:45.860248
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section = _SphinxSection("test", "key")
    print(_SphinxSection.title_pattern)
    print(_SphinxSection.title_pattern.findall(section.title_pattern))


# test__SphinxSection()

# Generated at 2022-06-23 17:14:50.954359
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("title", "key")
    text = "some_version\n    some_text"
    assert section.parse(text).next().version == "some_version"
    assert section.parse(text).next().description == "some_text"


# Generated at 2022-06-23 17:15:00.838670
# Unit test for method parse of class Section
def test_Section_parse():
    assert Section("Parameters", "param").parse("") == [
        DocstringMeta(args=["param"], description=None)
    ]
    assert Section("Parameters", "param").parse("text") == [
        DocstringMeta(args=["param"], description="text")
    ]
    assert Section("Parameters", "param").parse("text\nmore text") == [
        DocstringMeta(args=["param"], description="text\nmore text")
    ]
    assert Section("Parameters", "param").parse("text\n\n") == [
        DocstringMeta(args=["param"], description="text\n")
    ]
    assert Section("Parameters", "param").parse("text\n\nmore text") == [
        DocstringMeta(args=["param"], description="text\nmore text")
    ]

    # Unit test for method

# Generated at 2022-06-23 17:15:02.786552
# Unit test for constructor of class _KVSection
def test__KVSection():
    section = _KVSection("title", "key")
    assert section.title == "title"
    assert section.key == "key"

# Generated at 2022-06-23 17:15:08.470133
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    """test key-value structure in a docstring 
    """
    section = _KVSection("Parameters", "param")
    kw = text = """\
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    docstring = section.parse(text)
    with open("test/_KVSection_parse.txt", "w+") as f:
        for d in docstring:
            f.write(str(d))
        f.write("\n")
        f.write(kw)

# Generated at 2022-06-23 17:15:11.825012
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    test = RaisesSection("Raises", "raises")
    assert test.title == "Raises"
    assert test.key == "raises"


# Generated at 2022-06-23 17:15:15.932190
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    x = YieldsSection('Yields', 'yields')
    assert x.is_generator == True
    assert x.title == 'Yields'
    assert x.key == 'yields'


# Generated at 2022-06-23 17:15:19.556355
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section("Examples", "examples")
    result = s.parse("arg_name1\narg_description1\narg_name2 : type\narg_description2, optional")
    assert len(list(result)) == 2



# Generated at 2022-06-23 17:15:28.946376
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("Pickles", "pickles"))
    text1 = '''
    This is the short description.

    This is the long description.

    Pickles
    -------
    pickle, optional
        A pickled string.

    pickle_other, optional
        Another pickled string.
    '''

    docstring = parser.parse(text1)
    docstring = docstring.to_dict()

    assert docstring["short_description"] == "This is the short description."
    assert docstring["long_description"] == "This is the long description."
    assert docstring["blank_after_short_description"] == True
    assert docstring["blank_after_long_description"] == True

    assert len(docstring["meta"]) == 2

    pickles = doc

# Generated at 2022-06-23 17:15:31.650968
# Unit test for constructor of class _KVSection
def test__KVSection():
    parser = _KVSection("test", "test")
    assert parser._parse_item("test", "test")


# Generated at 2022-06-23 17:15:38.731370
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """Test adding a new section to NumpydocParser"""
    # Create a new test section
    new_section = ParamSection('New Section', 'new_section')

    # Test sections are not added
    parser = NumpydocParser()
    assert parser.sections['New Section'] is None

    # Test sections are added
    parser.add_section(new_section)
    assert parser.sections['New Section'] is not None

# Generated at 2022-06-23 17:15:47.068161
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section('Parameters','param')
    text = """
    arg_name1
        arg_description
    arg_name2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    ans = s.parse(text)
    exp = [DocstringMeta(args = ['param', 'arg_name1'], description = 'arg_description'),
            DocstringMeta(args = ['param', 'arg_name2'], description = 'descriptions can also span...\n... multiple lines')]
    print(next(ans).description)
    print(next(ans).description)
    assert next(ans).description == exp[0].description
    assert next(ans).description == exp[1].description


# Generated at 2022-06-23 17:15:53.420974
# Unit test for constructor of class _KVSection
def test__KVSection():
    section = _KVSection("Parameters", "param")
    assert section.title == "Parameters"
    assert section.key == "param"
    assert section.title_pattern == r"^Parameters\s*?\n\-*\s*$"

#Unit test for constructor of class _SphinxSection