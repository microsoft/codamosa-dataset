

# Generated at 2022-06-23 17:06:07.351601
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    test_param = """arg_name
    arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    test_returns = """return_name : type
    A description of this returned value
    another_type
    Return names are optional, types are required"""
    test_raises = """ValueError
        A description of what might raise ValueError"""
    test_param_blank_lines = """arg_name
    arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """

    test_param_title_pattern = """param : type
    param_description"""
    test_param_title_pattern_blank_lines = """param : type

    param_description"""

    # type: list[DocstringParam]
    param_result

# Generated at 2022-06-23 17:06:17.288721
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    class TestSection(Section):
        def __init__(self, title=None, key=None) -> None:
            super().__init__(title, key)
    assert TestSection.parse is not None
    newparser = NumpydocParser()
    newparser.add_section(TestSection(title='Test', key='test'))
    newsection = newparser.sections['Test']
    assert newsection is not None
    assert newsection.key == 'test'
    assert newsection.title == 'Test'
    assert newsection.title_pattern == '^Test\\s*?\\n-*$'
    assert newsection.parse is not None


# Generated at 2022-06-23 17:06:18.490507
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns").is_generator == False

# Generated at 2022-06-23 17:06:24.931987
# Unit test for constructor of class Section
def test_Section():
    # Test if the constructor is initialized with the following arguments
    # title: section title. For most sections, this is a heading like
    #       "Parameters" which appears on its own line, underlined by
    #       en-dashes ('-') on the following line.
    # key: meta key string. In the parsed ``DocstringMeta`` instance this
    #      will be the first element of the ``args`` attribute list.
    s = Section(title='Parameters', key='param')
    assert hasattr(s, 'title') == True
    assert hasattr(s, 'key') == True


# Generated at 2022-06-23 17:06:27.634628
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
  ys = YieldsSection("Yields", "yields")
  print(ys.is_generator)


# Generated at 2022-06-23 17:06:28.235110
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    NumpydocParser()

# Generated at 2022-06-23 17:06:31.013460
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    sample_Section = RaisesSection("Raises", "raises")
    print(type(sample_Section))
    print(sample_Section)
    print(sample_Section.title)
    print(sample_Section.key)

if __name__ == "__main__":
    # Unit test for constructor of class RaisesSection
    test_RaisesSection()

# Generated at 2022-06-23 17:06:37.410833
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rs = RaisesSection("Raises", "raises")
    assert rs.title == "Raises"
    assert rs.key == "raises"
    assert rs.title_pattern == "^Raises\s*?\n-*$"
    assert rs.parse("ValueError\n\tA description of what might raise ValueError") == [DocstringMeta(['raises', 'ValueError'], description='A description of what might raise ValueError')]

# Generated at 2022-06-23 17:06:45.325071
# Unit test for method parse of class Section
def test_Section_parse():
    test_section = Section("Arguments", "arg")
    text = ""
    assert list(test_section.parse(text)) == [DocstringMeta(["arg"],
                                                                       None)]
    text = "arg_name : type\n"
    text += "    arg_description"
    assert list(test_section.parse(text)) == [DocstringMeta(["arg", "arg_name"],
                                                                       "arg_description",
                                                                       type_name="type",
                                                                       is_optional=False)]
    text += "arg_2 : type, optional\n"
    text += "    description can also span...\n"
    text += "    ... multiple lines"

# Generated at 2022-06-23 17:06:49.535343
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kvs = _KVSection(title="title", key="key")
    text = '''body1
    value1
body2
    value2'''
    res = list(kvs.parse(text))
    print(res)


# Generated at 2022-06-23 17:06:52.452895
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert(len(parser.sections) == len(DEFAULT_SECTIONS))
    assert(parser.sections == {s.title: s for s in DEFAULT_SECTIONS})

# Generated at 2022-06-23 17:07:02.296173
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    parser = _KVSection("", "")
    assert parser.parse("\n") == []
    assert parser.parse("\n    \n") == []
    assert parser.parse("  \n  \n  \n") == []
    assert parser.parse("\n\n\n") == []
    assert parser.parse("\n\n\n    \n") == []
    assert parser.parse("  \n  \n  \n  \n") == []
    assert parser.parse("asdf") == []
    assert parser.parse("asdf\n") == []
    assert parser.parse("asdf\n\n") == []
    assert parser.parse("asdf\n\n\n") == []
    assert parser.parse("asdf\n\n\n    \n") == []
    assert parser

# Generated at 2022-06-23 17:07:04.245336
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection("test", "key").title_pattern==r"^\.\.\s*(test)\s*::"


# Generated at 2022-06-23 17:07:10.756965
# Unit test for method parse of class DeprecationSection

# Generated at 2022-06-23 17:07:22.025490
# Unit test for method parse of class DeprecationSection

# Generated at 2022-06-23 17:07:34.396782
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:07:37.936955
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    # Tests if new instance of ReturnsSection is created correctly
    r = ReturnsSection("Returns","returns")
    assert isinstance(r, ReturnsSection)
    assert r.key == "returns"
    assert r.title == "Returns"
    assert r.is_generator == False


# Generated at 2022-06-23 17:07:41.021684
# Unit test for method parse of class Section
def test_Section_parse():
    docstring = NumpydocParser().parse('''
    test
        This is a test
    ''')
    assert docstring.meta[0].description == 'This is a test'


# Generated at 2022-06-23 17:07:49.514272
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

    docstring = """ 
    function_name(arg1, arg2, arg3, arg4)

    This is a short description.

    Here we have a long description.

    Parameters
    ----------
    arg1 : int
        This is the first parameter.
    arg2 : dict
        This is the second parameter.
    arg3 : numpy.array, optional
        This is the third parameter that is optional.
    arg4
        This is the fourth parameter that does not have a type.

    Returns
    -------
    dict
        This is the return type.

    See Also
    --------
    func2

    Examples
    --------
    >>> func1(1, 2)
    2
    """
    func1 = parser.parse(docstring)

# Generated at 2022-06-23 17:08:00.093619
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    sample_docstring = """
    Method to import a data file from the cluster.

    Parameters
    ----------
    filename: str
        name of the file to import

    Returns
    -------
    dict:
        pandas DataFrame in dict form per pandas.read_csv
    """
    docstring = NumpydocParser().parse(sample_docstring)
    assert docstring.short_description == "Method to import a data file from the cluster."
    assert docstring.long_description == ""
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].description == "pandas DataFrame in dict form per pandas.read_csv"


# Generated at 2022-06-23 17:08:03.246736
# Unit test for method parse of class Section
def test_Section_parse():
    title = "This is the title"
    key = "key"
    text = "This is the description"
    meta = Section(title, key)
    print(meta.parse(text))


# Generated at 2022-06-23 17:08:06.524251
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    DeprecationSection("deprecated", "deprecation").parse("\n".join(
        ["version", "description", "", "", "", "", ""]
    ))


# Generated at 2022-06-23 17:08:08.609074
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    NumpydocParser().add_section(YieldsSection("yields", "yields"))

# Generated at 2022-06-23 17:08:18.242998
# Unit test for method parse of class Section
def test_Section_parse():
    class MySection(Section):
        def __init__(self):
            super().__init__(title = 'title', key = 'key')
        
        def _parse_item(self, key: str, value: str) -> DocstringMeta:
            return DocstringMeta([self.key], key, _clean_str(value))

    section = MySection()
    text = '''
    title
    ---
    key1
        value1
    key2
        value2
    '''

    text = inspect.cleandoc(text)
    res = section.parse(text)
    tmp = [obj.description for obj in res]
    assert tmp[0] == 'value1'
    assert tmp[1] == 'value2'

# Generated at 2022-06-23 17:08:25.261269
# Unit test for constructor of class Section
def test_Section():
    section = Section('title', 'key')
    assert "'title' 'key'" == str(section.title) + ' ' + str(section.key)
    assert section.title_pattern == r"^title\s*?\n{0}\s*$".format("-" * len(section.title))
    assert section.parse("") == DocstringMeta([section.key], description=_clean_str(""))

# Generated at 2022-06-23 17:08:32.739789
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises = RaisesSection("Raises", "raises")
    text = """\
.. note::
    This function always returns ``True`` for backwards compatibility
    with older versions.
    """
    out = raises.parse(text)
    expect = [
        DocstringRaises(
            args=["raises"],
            description="This function always returns ``True`` for backwards compatibility\nwith older versions.",
            type_name=None,
        )
    ]
    assert list(out) == expect

# Generated at 2022-06-23 17:08:41.490352
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = NumpydocParser()
    depre_section = DeprecationSection("Deprecated", "deprecation")
    match = re.search(depre_section.title_pattern, ".. Deprecated:: 1.0")
    if match:
        docstring = depre_section.parse(".. Deprecated:: 1.0\nwarning description")
        assert(str(docstring) == 'Deprecation(args=[\'deprecation\'], description=\'warning description\', version=\'1.0\')')


if __name__ == "__main__":
    test_DeprecationSection_parse()

# Generated at 2022-06-23 17:08:46.380713
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    """
    Test to see whether the constructor of class works well
    """
    actual = DeprecationSection("deprecation", "deprecation")
    expected = DeprecationSection("deprecation", "deprecation")
    assert actual == expected


# Generated at 2022-06-23 17:08:51.193498
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    t = """arg_name
            arg_description
        arg_2 : type
            descriptions can also span...
            ... multiple lines"""
    f = _KVSection("section", "section")
    assert f.parse(t) is not None


# Generated at 2022-06-23 17:08:53.336291
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ps = ParamSection("Parameters", "param")
    assert ps.key == 'param' 
    assert ps.title == 'Parameters' 


# Generated at 2022-06-23 17:08:58.394438
# Unit test for method parse of class Section

# Generated at 2022-06-23 17:09:09.987349
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecated", "deprecation")
    string = None

# Generated at 2022-06-23 17:09:22.242523
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import pytest
    text = """This is the title

    subheader
    ----------
    This is the start of a long description.

    Parameters
    ----------
    param_1 : string
        This is the first param.
    param_2 : int, optional
        This is the second param. (default is 5)
    param_3 : bool (optional)
        This is the third param. (Default is False)
    param_4 : int (optional, default 3)
        This is the fourth param.
    param_5 : int (optional, Default is 4)
        This is the fifth param.

    Raises
    ------
    Exception
        Raised if this gets raised.
    """
    description = parse(text)
    assert description.short_description == "This is the title"

# Generated at 2022-06-23 17:09:29.176136
# Unit test for function parse
def test_parse():
    # Set up an input
    text = """
        Summon a bounding box shader for drawing wireframe boxes.

        :param transform: XForm4x4 for the bounding box.
        :param bounds: Min and max points of the box.
        :param color: Optional color to set the shader to.
        :returns: Shader to draw the bounding box.

        This is a somewhat complex method.

        :raises: ``RuntimeError`` when there is a problem compiling the
                 shader.

        See Also
            :meth:`bbb.bbb`
    """
    # Parse text into a Docstring
    d = parse(text)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:09:33.249578
# Unit test for constructor of class Section
def test_Section():
    title = "Parameters"
    key = "param"
    section = Section(title, key)
    assert(section.title == title)
    assert(section.key == key)


# Generated at 2022-06-23 17:09:42.360306
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = '''
    This is the short description.

    This is a long description.

    Parameters
    ----------
    arg_name: str
        arg_description, it can also span multiple lines.

    arg_name_2 : int, optional
        arg_description

    arg_name_3 : int, optional
        arg_description, Default is 3
    '''

    parsed_docstring = NumpydocParser().parse(text)
    assert parsed_docstring.short_description == "This is the short description."
    assert parsed_docstring.long_description == "This is a long description."
    assert parsed_docstring.blank_after_short_description is True
    assert parsed_docstring.blank_after_long_description is False
    assert len(parsed_docstring.meta) == 3


# Generated at 2022-06-23 17:09:44.277805
# Unit test for constructor of class _KVSection
def test__KVSection():
    sections = _KVSection("test_title", "test_key")


# Generated at 2022-06-23 17:09:56.591058
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    from .common import DocstringParam
    def test_function(a):
        pass
    title = "Variable"
    key = "var"
    section = Section(title, key)
    test_source = """"
    Variable
        a
            variable
        b : int, optional
            variable
    """
    parser = NumpydocParser()
    parser.add_section(section)
    doc = parser.parse(inspect.cleandoc(test_source))
    assert len(doc.meta) == 2
    assert doc.meta[0] == DocstringParam(args=[key, 'a'], description='variable', arg_name='a', type_name=None, is_optional=False, default=None)

# Generated at 2022-06-23 17:09:58.837992
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p=ParamSection("Parameters", "param")
    assert(p.title=="Parameters")
    assert(p.key=="param")
    assert(p.title_pattern=='^(Parameters)\s*?\n------------------\s*$')

#Unit test for function _parse_item in class ParamSection

# Generated at 2022-06-23 17:10:03.043842
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    sections = [
            YieldsSection("Yield", "yields"),
    ]
    assert sections[0].is_generator

# Generated at 2022-06-23 17:10:05.809546
# Unit test for constructor of class _KVSection
def test__KVSection():
    section = _KVSection('title', 'key')
    print(section)

# Execute test of class _KVSection
if __name__ == '__main__':
    test__KVSection()

# Generated at 2022-06-23 17:10:10.928822
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    titles_list = ['deprecation', 'deprecated']
    for title in titles_list:
        section = DeprecationSection(title, 'deprecation')
        assert section.title_pattern == r'^\.\.\s*({})\s*::'.format(title)
        assert section.title == 'deprecation'
        assert section.key == 'deprecation'
    return True

if __name__ == "__main__":
    test_DeprecationSection()

# Generated at 2022-06-23 17:10:12.721102
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yieldS = YieldsSection("Yields", "yields")
    assert yieldS.is_generator == True

# Generated at 2022-06-23 17:10:17.938375
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Parameters", "param")
    s = "    key\n        value\n    key2 : type\n        values can also span...\n        ... multiple lines"
    assert section.parse(s) == [DocstringMeta(['param'], description=_clean_str(s))]



# Generated at 2022-06-23 17:10:21.970043
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    def custom_section1(text):
        return {
            "text": text
        }

    def custom_section2(text):
        return {
            "text": text
        }

    custom_sections = [
        custom_section1,
        custom_section2,
    ]

    NumpydocParser(custom_sections)



# Generated at 2022-06-23 17:10:32.348242
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = NumpydocParser([DeprecationSection("deprecated", "deprecation")])
    docs = parser.parse("""
    .. deprecated:: 1.0.0
        This function was deprecated
    """)
    assert docs.short_description == None
    assert docs.long_description == None
    assert docs.blank_after_short_description == False
    assert docs.blank_after_long_description == False
    assert docs.meta[0].key == "deprecation"
    assert docs.meta[0].args == ["deprecation"]
    assert docs.meta[0].version == "1.0.0"
    assert docs.meta[0].description == "This function was deprecated"



# Generated at 2022-06-23 17:10:37.424391
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    assert list(_KVSection("","").parse("first_value\nsecond_value")) == [
        DocstringMeta(
            args=[], description="first_value"
        ),
        DocstringMeta(
            args=[], description="second_value"
        ),
    ]



# Generated at 2022-06-23 17:10:44.991961
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    ds=DeprecationSection("deprecated", "deprecation")
    test_string="Deprecated since version 7.0.0\n" \
                "This statement is being deprecated. Please do not use."

    # test_string should be parsed into DocstringDeprecated:
    #    args: [self.key], description=desc, version=_clean_str(version)
    result=ds.parse(test_string)
    assert result.args==["Deprecated since version 7.0.0\nThis statement is being deprecated. Please do not use."]
    assert result.description == "This statement is being deprecated. Please do not use."
    assert result.version=="Deprecated since version 7.0.0"
    assert result.key()=="deprecation"



# Generated at 2022-06-23 17:10:49.375404
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """Test DeprecationSection parse method."""
    result = DeprecationSection("test", "deprecation").parse("")
    assert result is not None
    result = DeprecationSection("test", "deprecation").parse("deprecated")
    assert result is not None

# Generated at 2022-06-23 17:10:56.731104
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    sections = [
        ReturnsSection("Returns", "returns"),
        YieldsSection("Yields", "yields"),
    ]
    sections_dict = {s.title: s for s in sections}
    assert (sections_dict["Yields"].is_generator == True), "Error"
    assert (sections_dict["Returns"].is_generator == False), "Error"
    assert (ReturnSection1.is_generator == False), "Error"
    assert (YieldSection1.is_generator == True), "Error"


# Generated at 2022-06-23 17:11:00.739572
# Unit test for constructor of class ParamSection
def test_ParamSection():
    title = "Parameters"
    key = "param"
    a = ParamSection(title, key)
    assert a.title == title
    assert a.key == key
    assert a.title_pattern == r"^(Parameters)\s*?\n{}\s*$".format("-" * len(title))



# Generated at 2022-06-23 17:11:05.093415
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    s = Section("title", "key")
    parser = NumpydocParser()
    assert parser.sections["title"] != s

    parser.add_section(s)
    assert parser.sections["title"] == s


# Generated at 2022-06-23 17:11:11.686448
# Unit test for constructor of class _KVSection
def test__KVSection():
    kv_sec = _KVSection("test_title", "test_key")
    assert kv_sec.title == "test_title"
    assert kv_sec.key == "test_key"
    assert kv_sec.title_pattern == "^(test_title)\s*?\n\s*$"

# Generated at 2022-06-23 17:11:21.386968
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import pytest

    text = """
    Short description

    Long description

    Examples
    --------
    >>> f(x)  # doctest: +ELLIPSIS
    <...>

    Parameters
    ----------
    x : int
        The meaning of x
    y : str, optional
        The meaning of y. [default is ...]

    Other Parameters
    ----------------
    z : bool
        Whatever.
    w : str
        Blah.

    Returns
    -------
    int
        The meaning of the return value.
    """

    text2 = """
    Short description.

    Long description.

    Parameters
    ----------
    x : int
        The meaning of x
    y : str
        The meaning of y

    """
    parser = NumpydocParser()
    parsed = parser.parse(text)

# Generated at 2022-06-23 17:11:25.268234
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("yields", "key")
    assert ys.title == "yields"
    assert ys.key == "key"
    assert ys.is_generator == True

# Generated at 2022-06-23 17:11:28.145492
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param = ParamSection("Parameters", "param")
    assert param.title == "Parameters"
    assert param.key == "param"
    return


# Generated at 2022-06-23 17:11:35.465530
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():

    input_text = """
    This is the short description.


    This is the long description. It can span over
    multiple lines.


    .. warning:: This is a warning
        with a continuation line

    This is the rest of the long description.

    Parameters
    ----------
    arg1 : str
    
        This is the first argument.
    arg2 : int
    

        This is the second argument.
        It spans multiple lines.

    Returns
    -------
    str
        This is the return value.
        It spans multiple lines.

    Other Parameters
    ----------------
    arg3 : str
    
        This is the third parameter.
    arg4 : int
    

        This is the fourth parameter.
        It spans multiple lines.

    """

    exp_short_description = "This is the short description."

    exp_long_

# Generated at 2022-06-23 17:11:37.441305
# Unit test for method parse of class Section
def test_Section_parse():
    assert Section('Parameters', 'param').parse('a') == (DocstringMeta([], description='a'),)


# Generated at 2022-06-23 17:11:42.687193
# Unit test for constructor of class _KVSection
def test__KVSection():
    
    title = "This is a test"
    key = "test"
    section = _KVSection(title=title, key=key)
    
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == r"^(This is a test)\s*?\n{}\s*$".format("-" * len(title))
    
    

# Generated at 2022-06-23 17:11:46.176519
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param_section = ParamSection("Param", "param")
    title = param_section.title
    key = param_section.key
    title_pattern = param_section.title_pattern
    return title, key, title_pattern


# Generated at 2022-06-23 17:11:58.150005
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    np = NumpydocParser()
    assert list(np.sections.keys()) == ["Parameters", "Params", "Arguments", "Args",
                                        "Other Parameters", "Other Params",
                                        "Other Arguments", "Other Args",
                                        "Receives", "Receive", "Raises", "Raise",
                                        "Warns", "Warn", "Attributes",
                                        "Attribute", "Returns", "Return",
                                        "Yields", "Yield", "Examples",
                                        "Example", "Warnings", "Warning",
                                        "See Also", "Related", "Notes", "Note",
                                        "References", "Reference", "deprecated"]
    new_section = Section("test", "test")
    np.add_section(new_section)
    assert np.sections["test"]

# Generated at 2022-06-23 17:12:09.777811
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kv_section = _KVSection('Parameters', 'param')
    text = 'param_name\n    param_description\nparam_2 : type\n    param_description_2'
    docstring_meta_list = []
    for meta in kv_section.parse(text):
        docstring_meta_list.append(meta)
    assert docstring_meta_list[0].args == ['param', 'param_name']
    assert docstring_meta_list[0].description == 'param_description'
    assert docstring_meta_list[1].args == ['param', 'param_2']
    assert docstring_meta_list[1].description == 'param_description_2'


# Generated at 2022-06-23 17:12:20.905060
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section = _KVSection("Title", "key")

    assert list(section.parse("""
        key1
            value
        key2
        key3 : type , other
            value
        key4: value
    """)) == [
        DocstringMeta(
            ["key", "key1"],
            description="value",
        ),
        DocstringMeta(
            ["key", "key2"],
            None,
        ),
        DocstringMeta(
            ["key", "key3"],
            description="value",
        ),
        DocstringMeta(
            ["key", "key4"],
            description="value",
        ),
    ]


# Generated at 2022-06-23 17:12:25.590549
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a short description

    This is a long description. It might span multiple lines.
    Or not.

    Warnings
    --------
    This method is dangerous.

    Parameters
    ----------
    a : bool
        Description of a
    b : int, optional
        Description of b
    c : float
        Description of c

    Returns
    -------
    float
        Return value of the function

    """

    # for fun, we test a custom parser as well
    parser = NumpydocParser([ParamSection('Parameters', 'param')])
    d = parser.parse(text)
    assert d.meta[0].description == text.split('\n    ')[1]

    assert d.meta[1].description == 'This method is dangerous.'

# Generated at 2022-06-23 17:12:29.864012
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
.. deprecated:: 1.0
    This is deprecated
    """
    section = DeprecationSection("deprecated", "deprecated")
    meta = section.parse(text)
    assert next(meta).description == "This is deprecated"

# Generated at 2022-06-23 17:12:32.624896
# Unit test for constructor of class _KVSection
def test__KVSection():
    example = _KVSection("Parameters", "param")
    assert example.title == "Parameters"
    assert example.key == "param"


# Generated at 2022-06-23 17:12:38.258949
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = '.. deprecated:: Version with bugfix'
    factory = NumpydocParser().sections['deprecated']
    result = factory.parse(text).__next__()
    assert result.__dict__ == {'args': ['deprecation'], 'description': None, 'version': 'Version with bugfix'}


# Generated at 2022-06-23 17:12:41.086560
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert Section('title', 'key').title == 'title'
    assert Section('title', 'key').key == 'key'



# Generated at 2022-06-23 17:12:45.627525
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    from pdoc3 import docscrape_numpydoc as docscrape
    assert (
            docscrape._SphinxSection("deprecated","deprecation").title_pattern
            == r"^\.\.\s*(deprecated)\s*::"
    )


# Generated at 2022-06-23 17:12:47.313890
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    print("Running unit test !")
    YieldsSection("Yields","yields")

# Generated at 2022-06-23 17:12:53.657059
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("A section", "key"))
    parser.add_section(Section("Another section", "key"))
    parser.add_section(Section("A section", "key2"))
    assert len(parser.sections)==3


# Generated at 2022-06-23 17:13:00.670826
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Parameters:
    # text:
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    # Return value:
    returns = [
        DocstringMeta(['key'], description='value'),
        DocstringMeta(['key2 : type'], description='values can also span...\n... multiple lines'),
    ]

    # Function call:
    ret = ParamSection("Parameters", "param").parse(text)

    # Unit test:
    assert tuple(ret) == tuple(returns)

    return



# Generated at 2022-06-23 17:13:09.915604
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Example from numpydoc
    text = """
    Example numpydoc-formatted docstring

    Parameters
    ----------
    arg1 : int
        The first parameter.
    arg2 : str
        The second parameter.

    Returns
    -------
    str
        The return value.

    """

# Generated at 2022-06-23 17:13:16.724770
# Unit test for function parse
def test_parse():
    def my_fun(a, b, c=1, d=2, e=3):
        """
        Parameters
        ----------
        arg1 : int
            The first parameter.
        arg2 : str
            The second parameter.
        arg3 : {'value', 'other'}, optional
            The third parameter.
        arg4, arg5 : int, optional
            Parameter with no type specified.
        arg6: int, optional
            Parameter with no name specified.

        Returns
        -------
        None
            This function does not return anything.

        """

    docstring = parse(inspect.getdoc(my_fun))
    print(docstring)
    print(docstring.short_description)
    print(docstring.blank_after_short_description)
    print(docstring.blank_after_long_description)

# Generated at 2022-06-23 17:13:21.811601
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    title = 'NewSection'
    key = 'new_section'
    text = 'NewSection\n' + '-' * len(title) + '\ntext'
    newSection = Section(title,key)
    assert NumpydocParser().add_section(newSection).parse(text).meta[0].args == [key]

# Generated at 2022-06-23 17:13:28.810583
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert parse('') == Docstring()
    
    assert parse('This is short description.') == \
        Docstring(
        short_description='This is short description.',
    )

    assert parse('This is short description.\n\nAnd this is long description.') == \
        Docstring(
        short_description='This is short description.',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description='And this is long description.',
    )


# Generated at 2022-06-23 17:13:33.925864
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section = RaisesSection("Raises", "raises")
    assert section.parse("ValueError \n A description of what might raise ValueError") == [DocstringRaises(
    args=["raises", "ValueError"], description=_clean_str("A description of what might raise ValueError"), type_name="ValueError")], "constructor did not set instance variables"

# Generated at 2022-06-23 17:13:40.565865
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section(title="Parameters", key="param")
    text = '''
    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    '''
    assert section.parse(text) == [
        DocstringMeta(args=['param'], description='arg_description'),
        DocstringMeta(args=['param'], description='descriptions can also span...\n        ... multiple lines')
    ]

# Generated at 2022-06-23 17:13:44.497963
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    ndp = NumpydocParser()
    assert ndp.sections != {}
    ndp.add_section(Section("coucou", "other"))
    assert ndp.sections != {}

# Generated at 2022-06-23 17:13:46.940515
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section = ReturnsSection("Returns", "returns")
    assert isinstance(section, ReturnsSection)



# Generated at 2022-06-23 17:13:52.050415
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """sum of two numbers

    Parameters
    ---------
    a : int
        first number
    b : int
        second number

    Returns
    -------
    int
        sum of a and b
    """
    parser = NumpydocParser()
    assert parser.parse(text).short_description == "sum of two numbers"


# Generated at 2022-06-23 17:13:59.553585
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("Dummy", "dummy"))
    assert parser.sections["Dummy"].title == "Dummy"
    assert parser.sections["Dummy"].key == "dummy"
    assert parser.sections["Dummy"].title_pattern == "^(Dummy)\s*?\n{}\s*$".format("-" * len("Dummy"))


# Generated at 2022-06-23 17:14:09.678998
# Unit test for function parse
def test_parse():
    def _test_snippet(content, expected):
        result = parse(content)
        assert result == expected, "%s != %s" % (result, expected)

    _test_snippet('short description without newline',
                  Docstring(None, 'short description without newline',
                            None, False, False))
    _test_snippet('short\nlong\n',
                  Docstring(None, 'short', 'long', False, True))
    _test_snippet('\nshort\nlong\n',
                  Docstring(None, 'short', 'long', True, True))
    _test_snippet('\n\nshort\n\nlong\n\n',
                  Docstring(None, 'short', 'long', True, True))

# Generated at 2022-06-23 17:14:13.113265
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = [
        Section("Parameters", "param"),
        Section("Raises", "raises"),
    ]
    parser = NumpydocParser(sections=sections)
    print(parser)



# Generated at 2022-06-23 17:14:17.074991
# Unit test for constructor of class Section
def test_Section():
    """
    >>> s = Section("title", "key")
    >>> s.__dict__
    {'title': 'title', 'key': 'key'}
    """
    pass


# Generated at 2022-06-23 17:14:21.590765
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection("Yields", "yields").is_generator == True
    assert YieldsSection("Yield", "yields").is_generator == True

# Unit tests for _KVSection.parse

# Generated at 2022-06-23 17:14:30.754457
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    data = [
        ('key1\n'
         '\tvalue1',
         [{'key': 'key1', 'value': 'value1'}]),
        ('key2\n'
         '\tvalue\n'
         '\tvalue\n'
         'key3\n'
         '\tvalue3',
         [{'key': 'key2', 'value': 'value\nvalue'}, {'key': 'key3', 'value': 'value3'}]),
        ('key4\n'
         '\tvalue4\n'
         'key5',
         [{'key': 'key4', 'value': 'value4'}, {'key': 'key5', 'value': ''}])
    ]

# Generated at 2022-06-23 17:14:32.223543
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection("deprecated warning", "deprecated")

# Generated at 2022-06-23 17:14:32.766684
# Unit test for constructor of class _KVSection
def test__KVSection():
    pass

# Generated at 2022-06-23 17:14:36.650883
# Unit test for constructor of class _KVSection
def test__KVSection():
   x = _KVSection("a","b")
   assert x._KVSection("a","b") == _KVSection("a","b")


# Generated at 2022-06-23 17:14:44.567008
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    new_section = Section("A new section", "new_section")
    parser.add_section(new_section)
    assert parser.sections[new_section.title] == new_section
    # Test that new section name is in titles_re
    assert re.search(new_section.title, parser.titles_re.pattern)


if __name__ == "__main__":
    test_NumpydocParser_add_section()

# Generated at 2022-06-23 17:14:49.289986
# Unit test for method parse of class Section
def test_Section_parse():
    assert Section("Example", "example").parse("Example") == [DocstringMeta(["example"], description="Example")]


if __name__ == "__main__":
    test_Section_parse()

# Generated at 2022-06-23 17:14:59.660370
# Unit test for function parse
def test_parse():
    doc = """
        The short summary
        Line two of the short summary

        The long description
        This can span multiple lines, unlike the short summary.

        Parameters
        ----------
        arg1
            Long description of arg1
        arg2 : type, optional
            Long description of arg2
        arg3, optional
            Long description of arg3

        Returns
        -------
        return_name : type
            Long description of the return value
        """
    assert parse(doc) == parse(doc)
    assert parse(doc).short_description == "The short summary"
    assert parse(doc).long_description == "The long description\nThis can span multiple lines, unlike the short summary."
    assert parse(doc).meta[0].args == ["param", "arg1"]

# Generated at 2022-06-23 17:15:08.088597
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    class ParamSection__KVSection_parse( _KVSection ):
        def _parse_item(self, key: str, value: str) -> DocstringParam:
            m = PARAM_KEY_REGEX.match(key)
            arg_name = type_name = is_optional = None
            if m is not None:
                arg_name, type_name = m.group("name"), m.group("type")
                if type_name is not None:
                    optional_match = PARAM_OPTIONAL_REGEX.match(type_name)
                    if optional_match is not None:
                        type_name = optional_match.group("type")
                        is_optional = True
                    else:
                        is_optional = False

            default = None
            if len(value) > 0:
                default_match = PARAM_DE

# Generated at 2022-06-23 17:15:10.232805
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert isinstance(RaisesSection('Raises', 'raises'), _KVSection)
    return


# Generated at 2022-06-23 17:15:16.650835
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    dep_section = DeprecationSection('deprecated', 'deprecation')
    text = """
    .. deprecated:: something
        .. deprecated:: something
            possibly over multiple lines
    """
    docstring = dep_section.parse(text)
    assert docstring.args[0] == 'deprecation'
    assert docstring.description == 'something'
    assert docstring.version == 'something'


# Generated at 2022-06-23 17:15:18.852941
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    NumpydocParser()
    NumpydocParser(sections=DEFAULT_SECTIONS)



# Generated at 2022-06-23 17:15:24.257203
# Unit test for method parse of class Section
def test_Section_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    s = Section('Parameters', 'param')
    actual = s.parse(text)
    expected = [DocstringMeta(['param'], description="value"), DocstringMeta(['param'], description="values can also span...\n... multiple lines")]
    assert actual == expected



# Generated at 2022-06-23 17:15:27.034615
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    docstring = NumpydocParser()
    new_section = Section("Test", "test_section")
    docstring.add_section(new_section)
    assert new_section in docstring.sections.values()

# Generated at 2022-06-23 17:15:29.242893
# Unit test for function parse
def test_parse():
    return Docstring()



# Generated at 2022-06-23 17:15:41.511302
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """ Do the foo, give me the bar.

    Parameters
    ----------
    foo : int
        foo is a number.

    bar : str
        bar is a string

    Returns
    -------
    str
        foo plus bar, stringified.

    Other Parameters
    ----------------
    baz : str
        baz is a string too

    Warnings
    --------
    This is a warning!
    """

    d = Docstring()
    d.short_description = "Do the foo, give me the bar."
    d.long_description = "foo is a number.\n\nbar is a string\n\nThis is a warning!"

# Generated at 2022-06-23 17:15:42.438781
# Unit test for constructor of class _KVSection
def test__KVSection():
    _KVSection(title="TestTitle", key="test_key")

# Generated at 2022-06-23 17:15:44.981086
# Unit test for constructor of class Section
def test_Section():
    sec_tab = Section("Tableau", "t")
    assert sec_tab.title == "Tableau"
    assert sec_tab.key == "t"
    assert sec_tab.parse("tableau : .json") == [DocstringMeta(["t"], description="tableau : .json")]


# Generated at 2022-06-23 17:15:58.295094
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    title = "Returns"
    key = "returns"
    section = ReturnsSection(title, key)
    if section.title != "Returns":
        return False
    if section.key != "returns":
        return False
    # test title_pattern method
    if section.title_pattern != "^Returns\s*?\n=*\s*$":
        return False
    # test parse method
    if section.parse('') != ():
        return False
    parsed_result = section.parse('return_name : type\n    A description of this returned value')
    desired_result = [DocstringReturns(args=['returns'], description='A description of this returned value', type_name='type', is_generator=True, return_name='return_name')]