

# Generated at 2022-06-23 17:06:02.282957
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    """
    Test the parse method of class _KVSection
    """

    # Test with empty text
    section = _KVSection(title="Title", key="key")
    assert(list(section.parse("")) == [])

    # Test with valid text
    section = _KVSection(title="Title", key="key")
    text = """
    key
        value
    """
    assert(list(section.parse(text)) == [DocstringMeta(["key"], description="value")])



# Generated at 2022-06-23 17:06:06.709231
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection("Args", "args")
    expected = "^\.\.\\s*(Args)\\s*::"
    assert s.title_pattern == expected, "Expected {} but got {}".format(expected, s.title_pattern)

# Generated at 2022-06-23 17:06:18.107587
# Unit test for constructor of class _KVSection
def test__KVSection():
    section_title = 'SOME TEXT'
    section_key = 'SECTION_KEY'
    section_text = '''\
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    '''

    expected_1 = ['key', 'value']
    expected_2 = ['key2', 'type', 'values can also span...\n... multiple lines']

    section = _KVSection(section_title, section_key)
    start = KV_REGEX.search(section_text).start()
    end = len(section_text)

    ret_list = []
    for item in section.parse(section_text[start:end]):
        ret_list.append([item.key, item.value])

    assert ret_list == [expected_1, expected_2]


# Generated at 2022-06-23 17:06:30.182952
# Unit test for method parse of class DeprecationSection

# Generated at 2022-06-23 17:06:34.660641
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    returnSection = ReturnsSection("Returns", "returns")
    returnSection.is_generator = False
    value = returnSection._parse_item("return_name : type", "A description")
    assert value.return_name == "return_name"


# Generated at 2022-06-23 17:06:39.552032
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert parse(
        """
        .. deprecated:: 0.0.1 (soon)
            Use the ``.format()`` method instead.
    """
    ) == Docstring(deprecated=DocstringDeprecated(description='Use the ``.format()`` method instead.', version='0.0.1 (soon)'))

# Generated at 2022-06-23 17:06:41.043034
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    # test docstring
    section = YieldsSection('Yields', 'yields')

# Generated at 2022-06-23 17:06:47.560580
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rs = RaisesSection("Raises", "raises")
    assert rs.title == "Raises"
    assert rs.key == "raises"

# Generated at 2022-06-23 17:06:52.792433
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert _KVSection("test","test").title == "test"
    assert _KVSection("test","test").key == "test"
    assert _KVSection("test","test").title_pattern == r"^(test)\s*?\n{}\s*$".format("-" * len("test"))


# Generated at 2022-06-23 17:07:03.827075
# Unit test for function parse
def test_parse():
    # Example provided by https://numpydoc.readthedocs.io/en/latest/format.html
    text = """
    This is a function.

    This function does something.
    And some more of it.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : ndarray
        Description of `arg2`
    kw1 : {'option1', 'option2'}, optional
        Description of `kw1`

    Returns
    -------
    out : {float, array_like}, shape (n, m)
        Description of `out`
    """

# Generated at 2022-06-23 17:07:07.198897
# Unit test for constructor of class _KVSection
def test__KVSection():
    a = _KVSection("Parameters")
    assert a.title == "Parameters"
    assert a.key == "param"
    assert a.title_pattern == "^(Parameters)\\s*?\\n-{11}\\s*$"


# Generated at 2022-06-23 17:07:09.401271
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = {
        'a': 'b',
        'c': 'd'
    }
    parser = NumpydocParser(sections)
    assert parser.sections == sections

# Generated at 2022-06-23 17:07:11.800285
# Unit test for method parse of class Section
def test_Section_parse():
    from .examples import test_docstrings

    for docstring_text in test_docstrings.values():
        parsed_docstring = parse(docstring_text)
        print(parsed_docstring.meta)

if __name__ == "__main__":
    test_Section_parse()

# Generated at 2022-06-23 17:07:17.142278
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param_section = ParamSection("Parameters", "param")
    assert param_section.title == "Parameters"
    assert param_section.key == "param"
    assert param_section.title_pattern == r"^(Parameters)\s*?\n{}\s*$"


# Generated at 2022-06-23 17:07:21.841941
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    returnsSection = ReturnsSection("Returns", "returns")
    assert returnsSection.title == "Returns"
    assert returnsSection.key == "returns"
    assert returnsSection.is_generator == False
    assert returnsSection.title_pattern == "^Returns\s*?\n={12}$"
    assert returnsSection.parse("") == []


# Generated at 2022-06-23 17:07:25.437368
# Unit test for constructor of class Section
def test_Section():
    x=Section("Parameters", "parameters")
    assert x.title == "Parameters"
    assert x.key == "parameters"
    assert x.title_pattern == r"^(Parameters)\s*?\n{}\s*$".format("-" * len("Parameters"))

# Generated at 2022-06-23 17:07:28.474343
# Unit test for constructor of class ParamSection
def test_ParamSection():
    test = ParamSection("Parameters", "param")
    assert "parameters" in test.title_pattern.lower()

# Generated at 2022-06-23 17:07:30.184428
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yieldsection = YieldsSection("Yields", "yields:")
    assert yieldsection.is_generator == True, "Is YieldsSection a generator? Should be True."


# Generated at 2022-06-23 17:07:39.402073
# Unit test for function parse
def test_parse():
    docstring = """
    Parses numpydoc.

    Parameters
    ----------
    param : int
        docstring 2

    Returns
    -------
    returns_value : bool
        Return values
    """

    doc = parse(docstring)

    # Test description
    assert doc.short_description == "Parses numpydoc."
    assert doc.long_description == "Parameters"

    # Test meta
    assert doc.meta[0].args == ['param']
    assert doc.meta[0].description == "docstring 2"
    assert doc.meta[1].args == ['returns_value']
    assert doc.meta[1].description == "Return values"


# Generated at 2022-06-23 17:07:47.645399
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # Setup
    parser = NumpydocParser()
    new_section = Section("New Section", "new")
    new_section_ref = {new_section.title: new_section}
    
    def test_case_1():
        """
        Test Case 1: Add new section
        """
        parser.add_section(new_section)
        assert parser.sections == new_section_ref
    
    def test_case_2():
        """
        Test Case 2: Replace the section
        """
        # Adding new section to replace the old one
        parser.add_section(new_section)
        assert parser.sections == new_section_ref
    
    # Run all tests
    test_case_1()
    test_case_2()

# Generated at 2022-06-23 17:07:54.640559
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    with pytest.raises(ValueError):
        DeprecationSection("deprecated", "hello", [1, 2, 3])
    with pytest.raises(TypeError):
        DeprecationSection("deprecated", "hello", 1, 2, 3)
    assert(DeprecationSection("deprecated", "hello") is not None)



# Generated at 2022-06-23 17:08:00.901001
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
  title = "_SphinxSection"
  key = "test_key"
  parser = _SphinxSection(title, key)
  assert parser.key == key
  assert parser.title == title
  assert parser.title_pattern == r'^\.\.\s*({})\s*::'.format(title)

# Generated at 2022-06-23 17:08:04.206058
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    S_test = _SphinxSection("test",'12')
    assert S_test.title == 'test'
    assert S_test.key == '12'

if __name__ == "__main__":
    test__SphinxSection()

# Generated at 2022-06-23 17:08:06.066564
# Unit test for constructor of class _KVSection
def test__KVSection():
    ds = _KVSection("args", "param")
    assert ds.title == "args"
    assert ds.key == "param"

# Generated at 2022-06-23 17:08:08.422308
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    a = ReturnsSection("Returns", "returns")
    assert a.is_generator == False
    b = ReturnsSection("Yields", "yields")
    assert b.is_generator == True

# Generated at 2022-06-23 17:08:12.630661
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    with pytest.raises(TypeError):
        _SphinxSection([1,2,3])
    # Test the constructor of Section
    assert _SphinxSection("title", "key")

# Generated at 2022-06-23 17:08:21.174367
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param = ParamSection("Parameters", "param")
    # print(param._KVSection__parse_item("arg_name", "arg_description"))
    # print(param._KVSection__parse_item("arg_2 : type", "values can also span..."))
    # print(param._KVSection__parse_item("arg_2 : type, optional", "values can also span..."))
    print(param._KVSection__parse_item("arg_name", "arg_description"))
    print(param._KVSection__parse_item("arg_2 : type, optional", "Default is 1"))
    print(param._KVSection__parse_item("arg_2 : type, optional", "Default : 1"))
    print(param._KVSection__parse_item("arg_2 : type, optional", "Default=1"))

# Generated at 2022-06-23 17:08:22.508853
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    numpydoc_parser = NumpydocParser()

# Generated at 2022-06-23 17:08:24.479791
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    a = ReturnsSection("Returns", "returns")
    assert a.is_generator == False

# Generated at 2022-06-23 17:08:27.642830
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ParamSection("Parameters", "param")
    ParamSection("Params", "param")
    ParamSection("Arguments", "param")
    ParamSection("Args", "param")
    ParamSection("Other Parameters", "other_param")
    ParamSection("Other Params", "other_param")
    ParamSection("Other Arguments", "other_param")
    ParamSection("Other Args", "other_param")
    ParamSection("Receives", "receives")
    ParamSection("Receive", "receives")


# Generated at 2022-06-23 17:08:39.949302
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    Short description.

    Long description is broken into multiple lines.

    Notes
    -----
    A note.

    Parameters
    ----------
    arg_name : bool, optional
        A description of this argument, it's type, and if it's optional.
    another_arg : int
        Another argument. Also optional.

    Attributes
    ----------
    attr : str
        An attribute.

    Returns
    -------
    int
        A return value.

    Raises
    ------
    TypeError
        How not to use this function.

    Warns
    -----
    UserWarning
        How to use this function.

    """
    parser = NumpydocParser()
    doc = parser.parse(docstring)
    assert "Short description." in doc.short_description

# Generated at 2022-06-23 17:08:41.819802
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection("foo", "bar").title_pattern == r'^\.\.\s*(foo)\s*::'

# Generated at 2022-06-23 17:08:46.505543
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    docstring = '''.. deprecated::
    something'''
    assert DeprecationSection("deprecated", "deprecation").parse(docstring) == [DocstringDeprecated(
            args=['deprecation'], description=None, version='something')]

# Generated at 2022-06-23 17:08:51.796875
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    dep_sectionC = DeprecationSection("Deprecated", "deprecated")
    assert dep_sectionC.title == "Deprecated"
    assert dep_sectionC.key == "deprecated"
    assert dep_sectionC.title_pattern == "^\.\.\s*(Deprecated)\s*::"



# Generated at 2022-06-23 17:08:53.906274
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    sections = [ReturnsSection("Returns", "returns")]


# Generated at 2022-06-23 17:09:00.653539
# Unit test for constructor of class Section
def test_Section():
    test1 = Section('Parameters', 'param')
    assert test1.title == 'Parameters' 
    assert test1.key == 'param' 
    assert test1.title_pattern == "^Parameters\\s*?\n{}\\s*$".format('-' * len('Parameters')) 
    assert test1.parse('test 1') == [DocstringMeta(['param'], description='test 1')]


# Generated at 2022-06-23 17:09:04.512451
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    sec = ReturnsSection("Returns", "returns")
    assert sec.title == "Returns"
    assert sec.key == "returns"
    assert sec.is_generator == False


# Generated at 2022-06-23 17:09:06.221177
# Unit test for constructor of class Section
def test_Section():
    with pytest.raises(TypeError):
        s = Section()


# Generated at 2022-06-23 17:09:09.987281
# Unit test for constructor of class ParamSection
def test_ParamSection():
    test_section = ParamSection("Parameters", "param")
    assert test_section.title == "Parameters"
    assert test_section.key == "param"
    assert test_section.title_pattern == "^(Parameters)\s*?\n---*\s*$"


# Generated at 2022-06-23 17:09:15.005831
# Unit test for constructor of class _KVSection
def test__KVSection():
    test_title = "test_title"
    test_key = "test_key"

    section = _KVSection(test_title, test_key)

    assert section.title == test_title
    assert section.key == test_key


# Generated at 2022-06-23 17:09:18.318856
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection('deprecated', 'deprecation')
    assert(section.title == 'deprecated')
    assert(section.key == 'deprecation')


# Generated at 2022-06-23 17:09:21.448808
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    a = _SphinxSection(title="deprecated", key="deprecation")
    assert a.title == "deprecated"
    assert a.key == "deprecation"


# Generated at 2022-06-23 17:09:24.302619
# Unit test for constructor of class _KVSection
def test__KVSection():
    obj = _KVSection('title', 'key')
    assert obj == obj
    assert not obj != obj
    
# Unit tests for constructor of class _SphinxSection

# Generated at 2022-06-23 17:09:30.579135
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section = _KVSection("Parameters", "param")
    text = textwrap.dedent(
        """
        arg1
            arg1 description
        arg2 : type, optional
            arg2 description
        arg3
            arg3 description
        """
    )
    docstring = section.parse(text)
    meta = list(docstring)
    assert len(meta) == 3
    assert meta[0].args == ["param", "arg1"]
    assert meta[0].arg_name == "arg1"
    assert meta[0].type_name is None
    assert meta[0].is_optional is False
    assert meta[0].default is None
    assert meta[0].description == "arg1 description"

    assert meta[1].args == ["param", "arg2"]

# Generated at 2022-06-23 17:09:40.706606
# Unit test for function parse

# Generated at 2022-06-23 17:09:45.207558
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section('Section1', 'sec')
    print('Section title: {}'.format(section.title))
    res = section.parse('test')
    print('Section parsed: {}'.format(res))



# Generated at 2022-06-23 17:09:48.118978
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection("Parameters", "param")
    assert p.title == "Parameters"
    assert p.key == "param"

# Generated at 2022-06-23 17:09:51.678876
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section = ReturnsSection("Returns", "returns")
    assert section.key == "returns"
    assert section.title == "Returns"
    assert section._parse_item("", "") is not None


# Generated at 2022-06-23 17:10:00.885034
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    sphinx_sec = _SphinxSection("SphinxSection", "sphinx")
    kv_sec = _KVSection("KVSection", "kv")
    sec = Section("Section", "sec")
    parser = NumpydocParser()
    parser.add_section(sphinx_sec)
    parser.add_section(kv_sec)
    parser.add_section(sec)
    doc = parser.parse("""
.. SphinxSection::
    .. code-block::

        .. code-block::

            a
            b
            c
.. KVSection
    key1
        value1
    key2
        value2
.. Section
    value3
        value4
    """)

# Generated at 2022-06-23 17:10:09.804205
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import inspect
    import pprint


    def doc_str(str):
        def _func():
            return str
        return inspect.cleandoc(_func.__doc__)

    def dump_docstring(doc):
        return pprint.pformat(dict((k, v) for (k, v) in doc.__dict__.items() if v), indent=4, compact=False)



# Generated at 2022-06-23 17:10:11.127891
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection.is_generator

# Generated at 2022-06-23 17:10:14.835370
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
  my_title = ".. title:: something"
  object_SphinxSection = _SphinxSection(title="title", key="key")
  assert(object_SphinxSection.title_pattern == my_title)

# Generated at 2022-06-23 17:10:17.798080
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
  text = "Deprecated since version 3.0: Use :func:`backend.backend` instead.\n\n    """

  dep = DocstringDeprecated()
  dep.args = ["deprecation"]
  dep.description = "Use backend.backend instead."
  dep.version = "3.0"

  assert NumpydocParser().parse(text).meta == [dep]


# Generated at 2022-06-23 17:10:24.931286
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Test passing argument text = ".. deprecated:: 0.0.1"
    text = ".. deprecated:: 0.0.1"
    # Test passing argument self = DeprecationSection(
    #       title = "deprecated", key = "deprecation")
    self = DeprecationSection(title = "deprecated", key = "deprecation")
    # Test passing argument DeprecationSection.parse(text = ".. deprecated:: 0.0.1")
    DeprecationSection.parse(text = ".. deprecated:: 0.0.1")
    # Test passing argument self.parse(text = ".. deprecated:: 0.0.1")
    self.parse(text = ".. deprecated:: 0.0.1")
    # Test passing argument NumpydocParser().parse(text = ".. deprecated:: 0.0.1")
    Nump

# Generated at 2022-06-23 17:10:34.733028
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = NumpydocParser()
    section = DeprecationSection("deprecated", "deprecation")
    docstring = parser.parse("Deprecated since version 1.0:\ndeprecation_information")
    deprecation = section.parse("Deprecated since version 1.0:\ndeprecation_information")
    deprecation_iter = iter(deprecation)
    deprecation_instance = next(deprecation_iter)
    assert deprecation_instance.args == ["deprecation"]
    assert deprecation_instance.description == "deprecation_information"
    assert deprecation_instance.version == "1.0"
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ["deprecation"]

# Generated at 2022-06-23 17:10:41.575637
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    from .common import Docstring, DocstringDeprecated
    from .numpydoc import DeprecationSection, parse

    deprecated = DeprecationSection('Deprecated', 'deprecated')
    dep_text = '.. deprecated:: 1.0.0\n\n    Deprecation text.'

    docstring = parse(dep_text)

    assert isinstance(docstring, Docstring)
    assert isinstance(docstring.meta[0], DocstringDeprecated)
    assert docstring.meta[0].version == '1.0.0'

# Generated at 2022-06-23 17:10:53.811721
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    from .common import DocstringReturns

    a = ReturnsSection('Returns', 'returns')
    b = DocstringReturns(
        args=['returns'],
        description=None,
        type_name=None,
        is_generator=False,
        return_name=None,
    )
    assert a._parse_item(key='return_name : type', value='A description of this returned value') == b
    assert a._parse_item(key='another_type', value='Return names are optional, types are required') == b

    a._parse_item(key='return_name: type', value='A description of this returned value')
    assert a._parse_item(key='another_type', value='Return names are optional, types are required') == b

# Generated at 2022-06-23 17:10:56.109074
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r = RaisesSection("Raises","raises")
    assert r._KVSection__section_name == "raises"


# Generated at 2022-06-23 17:10:59.581512
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section(title="Title", key="Key")
    text = """Description"""
    result = section.parse(text)
    expected = [DocstringMeta(['Key'], description='Description')]
    assert list(result) == expected, "Assertion failed"


# Generated at 2022-06-23 17:11:00.573972
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    a = ReturnsSection("Returns", "returns")

# Generated at 2022-06-23 17:11:04.781154
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    results = DeprecationSection("deprecated", "deprecation").parse("DoNotUse\nDeprecation")
    assert results[0].description == "Deprecation"
    assert results[0].version == "DoNotUse"


# Generated at 2022-06-23 17:11:17.414872
# Unit test for method parse of class _KVSection
def test__KVSection_parse():

    # Create a ParamSection mock object
    s = ParamSection("Parameters", "param")
    assert s.title == "Parameters", "Title not defined correctly"
    assert s.key == "param", "Key not defined correctly"

    # Test for a method parse inside class _KVSection
    # Return a list of parsed sections

# Generated at 2022-06-23 17:11:22.233379
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
	import pdb; pdb.set_trace()
	docstring = """
            Test re module.

            This is a test docstring.

            Parameters
            ----------
            param1
               This is a parameter.
            param2 : str, optional
               This is another parameter.

            Raises
            ------
            ValueError
               Something broke.
            """

	print(NumpydocParser().parse(docstring))


# Generated at 2022-06-23 17:11:28.722293
# Unit test for constructor of class _KVSection
def test__KVSection():
    section_title = "Parameters"
    key = "param"
    kv_section = _KVSection(section_title, key)
    assert kv_section.title == section_title
    assert kv_section.key == key
    assert kv_section.title_pattern == "^(Parameters)\\s*?\\n---*\\s*$"


# Generated at 2022-06-23 17:11:31.909289
# Unit test for constructor of class _KVSection
def test__KVSection():
    print("## Unit test for constructor of class _KVSection:")
    title = "title"
    key = "key"
    kv = _KVSection(title=title,key=key)
    print("    kv.title: {}".format(kv.title))
    print("    kv.key: {}".format(kv.key))


# Generated at 2022-06-23 17:11:41.864885
# Unit test for function parse
def test_parse():
    parser = NumpydocParser()
    text = '''
    This is a description of the top level

    Parameters
    ----------
    param : str
        Description of param

    Returns
    -------
    str
        Description of return
    
    See Also
    --------
    related : func
    '''
    docstring = parser.parse(text)
    assert docstring.short_description == 'This is a description of the top level'
    assert docstring.long_description == 'Parameters\n----------\nparam : str\n    Description of param\n\nReturns\n-------\nstr\n    Description of return'
    assert docstring.meta[1].args == ['param']


# Generated at 2022-06-23 17:11:45.718480
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    ndp = NumpydocParser()
    yield compare, ndp.sections['See Also'].key, 'see_also'
    yield compare, ndp.sections['See Also'].title, 'See Also'
    yield compare, ''.join(ndp.sections['See Also'].title_pattern), '^See Also\\s*?\n{2}\\s*$'


# Generated at 2022-06-23 17:11:51.680087
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections['Parameters'].title == 'Parameters'
    assert parser.sections['Parameters'].key == 'param'
    assert parser.sections['Yields'].title == 'Yields'
    assert parser.sections['Yields'].key == 'yields'


# Generated at 2022-06-23 17:11:56.575533
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "title"
    key = "key"
    section = _SphinxSection(title, key)
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == ("^\.\.\s*({}\s*::)").format(title)


# Generated at 2022-06-23 17:12:00.632089
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    title="Title"
    key="key"
    d = DeprecationSection(title, key)
    assert d.title==title
    assert d.key==key

# Generated at 2022-06-23 17:12:02.277422
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser is not None


# Generated at 2022-06-23 17:12:06.725274
# Unit test for constructor of class Section
def test_Section():
    section = Section('title', 'key')
    assert section.title == 'title'
    assert section.key == 'key'
    assert section.title_pattern == r'^(title)\s*?\n{}\s*$'.format('-' * 5)

# Generated at 2022-06-23 17:12:15.295508
# Unit test for function parse
def test_parse():
    def inspect_assert(expected, actual):
        assert expected == actual, \
            "expected:\n'{}'\nactual:\n'{}'".format(expected, actual)

    # test inspect.cleandoc
    inspect_assert("A\n  single\n  line.", inspect.cleandoc("A\n  single\n  line."))
    inspect_assert("A\n\n  single\n\n  line.", inspect.cleandoc("A\n\n  single\n\n  line."))
    inspect_assert("A\n\n  indented\n  line.", inspect.cleandoc("A\n\n  indented\n  line."))
    inspect_assert("Unindented\n  line.", inspect.cleandoc("Unindented\n  line."))
    inspect_

# Generated at 2022-06-23 17:12:26.399606
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydoc_parser = NumpydocParser()
    new_section = Section("New", "new")
    numpydoc_parser.add_section(new_section)

    new_section_title = new_section.title
    new_section_header = "New\n-" * len(new_section_title)
    text = "this is the description of my function\n{new_section_header}\n\n" \
           "this is what my function does and it is important to know that" \
           " this is a new section".format(new_section_header=new_section_header)
    docstring = numpydoc_parser.parse(text)
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ['new']


# Generated at 2022-06-23 17:12:36.384832
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    text1 = '''
    This is short description.

    This is long description.

    :param arg: arg description
    :type arg: arg type
    :returns: return description
    :rtype: return type
    '''
    text2 = '''
    This is short description.

    This is long description.

    :Args:
     arg: arg description
     type: arg type
    :Returns:
     return description
     return type
    '''
    text3 = '''
    This is short description.

    This is long description.

    Arguments
    ---------
     arg: arg description
     type: arg type
    Returns
    -------
     return description
     return type
    '''

# Generated at 2022-06-23 17:12:38.094402
# Unit test for method parse of class Section
def test_Section_parse():
    pass


# Generated at 2022-06-23 17:12:40.500933
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yields = YieldsSection("Yields", "yields")
    assert yields.is_generator == True

# Generated at 2022-06-23 17:12:45.438053
# Unit test for constructor of class _KVSection
def test__KVSection():
    class _KVSectionTest(_KVSection):
        def _parse_item(self, key: str, value: str) -> DocstringMeta:
            pass
    assert _KVSectionTest("Params","param").title == "Params"
    assert _KVSectionTest("Params","param").key == "param"

# Generated at 2022-06-23 17:12:46.202825
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert _KVSection()


# Generated at 2022-06-23 17:12:49.180993
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yields_section = YieldsSection("Yields", "returns")
    assert yields_section.is_generator == True
    yields_section = YieldsSection("Yield", "returns")
    assert yields_section.is_generator == True

# Generated at 2022-06-23 17:12:51.685023
# Unit test for constructor of class Section
def test_Section():
    s = Section('Parameters', 'param')
    assert s.title == 'Parameters'
    assert s.key == 'param'


# Generated at 2022-06-23 17:12:53.771495
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
	assert YieldsSection("Yields","yields")

# Generated at 2022-06-23 17:12:54.865895
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert RaisesSection("Raises", "raises")

# Generated at 2022-06-23 17:13:03.162911
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """Tests the DeprecationSection parser class"""
    test_docstring = """.. deprecated:: 0.0.0
    
    woop woop"""
    dp_section = DeprecationSection("deprecated","deprecated")
    result = dp_section.parse(test_docstring)
    print(result)
    answer = [DocstringDeprecated(args=['deprecated'], description='woop woop', version='0.0.0')]
    assert result == answer


if __name__ == '__main__':
    test_DeprecationSection_parse()

# Generated at 2022-06-23 17:13:05.634609
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    test_section = Section(title = 'Parameters', key = 'param')
    assert test_section.title == 'Parameters'
    assert test_section.key == 'param'


# Generated at 2022-06-23 17:13:13.826772
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    from .common import DocstringMeta
    class TestSection(_KVSection):
        def __init__(self):
            super().__init__("Parameters", "param")

        def _parse_item(self, key: str, value: str) -> DocstringMeta:
            return DocstringMeta([self.key, key], description=_clean_str(value))
    p = TestSection()
    text = inspect.cleandoc("""
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """)
    result = []
    for m in p.parse(text):
        result.append(m)

# Generated at 2022-06-23 17:13:15.778083
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    test_section = YieldsSection("Yields", "yields")
    assert test_section.title == "Yields"
    assert test_section.key == "yields"
    assert test_section.title_pattern == "Yields"


# Generated at 2022-06-23 17:13:19.120083
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    # Test 1
    a = YieldsSection("Yields", "yields").__init__("Yields", "yields")
    assert (a == None)


# Generated at 2022-06-23 17:13:26.106231
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    string = textwrap.dedent(
        """
        name : str, default=None
            The name of the model.
            # blah blah blah
    """
    )
    parser = NumpydocParser()
    parser.add_section(ParamSection("Params", "param"))
    docstring = parser.parse(string)
    docstring.get_meta_as(DocstringParam, "param", "name")


# Generated at 2022-06-23 17:13:28.750792
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    """
    Test to check that the correct sections are created when called with
    no parameters.
    """
    np = NumpydocParser()
    for title in np.sections.keys():
        assert title in DEFAULT_SECTIONS


# Generated at 2022-06-23 17:13:37.400887
# Unit test for function parse
def test_parse():
    def f(a, b=2, c=3):
        """
        Some function


        :param a: a param

        :param b: another param

        :param c: yet another param

        :returns: return value


        See Also
        --------
        test_numpydoc_parser.test_parse : this function

        """

    d = parse(f.__doc__)

    # The last part of the docstring is a bit special
    # It is a section without a header, but with a title
    d.meta[-1].args[0].lower() == "see also"

# Generated at 2022-06-23 17:13:44.900186
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    c = DeprecationSection()
    assert c.parse("1.2\nUse foo instead.") == [DocstringDeprecated(
        version="1.2",
        description="Use foo instead.",
    )]
    assert c.parse("1.2\nUse foo instead.\nMore details.") == [DocstringDeprecated(
        version="1.2",
        description="Use foo instead.\nMore details.",
    )]
    assert c.parse("1.2") == [DocstringDeprecated(version="1.2", description=None)]
    assert c.parse("1.2\n") == [DocstringDeprecated(version="1.2", description=None)]
    assert c.parse("1.2\n\n") == [DocstringDeprecated(version="1.2", description=None)]

# Generated at 2022-06-23 17:13:48.399958
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    """
    Make sure the NumpydocParser object is initialized correctly with the default sections
    """
    parser = NumpydocParser()
    assert isinstance(parser, NumpydocParser)
    assert parser.sections is not None
    assert len(parser.sections) == 27
    assert parser.titles_re is not None
    assert parser.titles_re.pattern is not None
    assert parser.titles_re.groups is not None
    assert parser.titles_re.groups == 2



# Generated at 2022-06-23 17:13:52.731314
# Unit test for method parse of class Section
def test_Section_parse():
    text = "Raises\n------\nValueError\n    A description of what might raise ValueError"
    doc = NumpydocParser().parse(text)
    print(doc)


if __name__ == "__main__":
    test_Section_parse()

# Generated at 2022-06-23 17:13:56.547327
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Parameter 'end' is not needed in this test
    assert _KVSection.__init__(title='Parameters', key='param') is None

# Generated at 2022-06-23 17:13:58.172469
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection.is_generator == True


# Generated at 2022-06-23 17:14:06.032567
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    input_docstring =\
    """Parse the numpy-style docstring into its components.

    :returns: parsed docstring
    """
    doc_parser = NumpydocParser()

    # Test if comments are parsed correctly
    assert(doc_parser.parse(input_docstring).short_description ==
    'Parse the numpy-style docstring into its components.')

    # Test if return type and return type are parsed correctly
    assert(doc_parser.parse(input_docstring).meta[0].type_name == 'parsed docstring')


# Generated at 2022-06-23 17:14:18.837283
# Unit test for function parse
def test_parse():
    docstr = '''
    Calculate Awesome Things for objects.

    This function does some very awesome things for objects.

    Parameters
    ----------
    x : int or float
        The first parameter for calculating awesome things.
    y : int or float
        The second parameter for calculating awesome things.

    Returns
    -------
    float
        The result of the awesomeness.

    Examples
    --------
    >>> import superawesome
    >>> awesome_result = superawesome.calculate_awesome_things(x, y)

    See Also
    --------
    superawesome.calculate_awesome_things_too : another awesome function

    Warnings
    --------
    Some warning about this function.
    '''
    result = parse(docstr)
    assert result.short_description == "Calculate Awesome Things for objects."


# Generated at 2022-06-23 17:14:22.498363
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text = "\nRaises\n\nValueError\n    exception Error\n"
    raises = RaisesSection("Raises","raises")

# Generated at 2022-06-23 17:14:26.125079
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    parser = NumpydocParser()
    assert isinstance(parser, NumpydocParser)
    assert parser.sections
    assert isinstance(parser.sections, dict)
    assert parser.sections["Raises"]

# Generated at 2022-06-23 17:14:27.928752
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection('Yields', 'yields')
    assert ys is not None

# Generated at 2022-06-23 17:14:30.574901
# Unit test for constructor of class Section
def test_Section():
    from .common import DocstringMeta
    section = Section("hostname","hostname")
    assert section.parse("myhostname") == [DocstringMeta(["hostname"],description="myhostname")]


# Generated at 2022-06-23 17:14:37.713391
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    """RaisesSection constructor"""
    myRaisesSection = RaisesSection("Raises","raises")
    # Check instance type
    assert type(myRaisesSection) == RaisesSection
    # Check section title
    assert myRaisesSection.title == "Raises"
    # Check section key
    assert myRaisesSection.key == "raises"
    # Check meta key string
    assert myRaisesSection.key == "raises"


# Generated at 2022-06-23 17:14:40.380285
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection("Yields", "yields")
    assert y.is_generator == True



# Generated at 2022-06-23 17:14:46.645895
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # Do the test here
    param_Section=ParamSection("Parameters", "param")
    # check the title of the parser
    assert param_Section.title=="Parameters"
    # check the key of the parser
    assert param_Section.key=="param"
    # check the pattern of the title_pattern
    assert param_Section.title_pattern==r"^Parameters\s*?\n-\s*$"

# Generated at 2022-06-23 17:14:56.518236
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("deprecated", "deprecation")
    assert section.title == "deprecated"
    assert section.key == "deprecation"
    assert section.title_pattern == '^\\.\\.\\s*(deprecated)\\s*::'
    assert section.parse(
        """0.0.1
            for the purpose of testing"""
    ) == (
        DocstringDeprecated(
            args=["deprecation"],
            description="for the purpose of testing",
            version="0.0.1",
        ),
    )

# Test for the property title_pattern of class YieldsSection

# Generated at 2022-06-23 17:15:04.124510
# Unit test for constructor of class Section
def test_Section():
    title1 = "Parameters"
    key1 = "param"
    title_pattern1 = "^(Parameters)\s*?\n{}\s*$".format("-" * len(title1))
    title2 = "Raises"
    key2 = "raises"
    title_pattern2 = "^(Raises)\s*?\n{}\s*$".format("-" * len(title2))
    title3 = "Returns"
    key3 = "returns"
    title_pattern3 = "^(Returns)\s*?\n{}\s*$".format("-" * len(title3))
    title4 = "Examples"
    key4 = "examples"
    title_pattern4 = "^(Examples)\s*?\n{}\s*$".format("-" * len(title4))
    title

# Generated at 2022-06-23 17:15:06.443471
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert _KVSection.__doc__ is not None


# Generated at 2022-06-23 17:15:09.678371
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    a = YieldsSection("Yields","yields")
    assert a.is_generator == True
    assert a.title == "Yields"

# Generated at 2022-06-23 17:15:22.069470
# Unit test for constructor of class Section
def test_Section():
    # Header with two underlines
    with pytest.raises(ValueError):
        Section(title='First Class', key='first_class')
    # Header with one underline
    with pytest.raises(ValueError):
        Section(title='First Class ', key='first_class')
    # Header with three underlines
    with pytest.raises(ValueError):
        Section(title='First Class  ', key='first_class')
    # Header with no underlines
    with pytest.raises(ValueError):
        Section(title='First Class', key='first_class')
    # Header with no title
    with pytest.raises(ValueError):
        Section(title=' ', key='first_class')
    # Header with no key

# Generated at 2022-06-23 17:15:25.666467
# Unit test for method parse of class Section
def test_Section_parse():
    sec = Section("title", "key")
    assert sec.parse("\n") == [DocstringMeta(["key"], description=None)]
    with pytest.raises(NotImplementedError):
        sec = Section("title", "key")
        sec.parse("\n")


# Generated at 2022-06-23 17:15:38.827965
# Unit test for method parse of class Section
def test_Section_parse():
	s = Section("Description","description")
	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                

# Generated at 2022-06-23 17:15:42.557421
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    # Unit test for constructor of class ReturnsSection
    section = ReturnsSection("Returns", "returns")
    assert section.title == "Returns"
    assert section.key == "returns"
    assert section.is_generator == False


# Generated at 2022-06-23 17:15:47.037998
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    class TestSection(_KVSection):
        def _parse_item(self, key: str, value: str) -> str:
            return value
    section = TestSection("title", "key")
    text = """
        key
            value
        key2
            values can also span...
            ... multiple lines
    """
    assert list(section.parse(text)) == ['value', 'values can also span...\n... multiple lines']


# Generated at 2022-06-23 17:15:53.352805
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = ".. deprecated:: 0.1.0\nThis method is deprecated"
    parser = NumpydocParser()
    section = parser.sections['Deprecated']
    results = list(section.parse(text))
    assert results[0].version == '0.1.0'



# Generated at 2022-06-23 17:16:00.145941
# Unit test for function parse
def test_parse():
    assert bool(parse('  This is a fn\n')) == False
    assert bool(parse('  This is a fn\n\nThis is a test\n')) == True
    assert bool(parse('This is a fn\n\nThis is a test\n')) == True
    assert bool(parse('\nThis is a fn\n\nThis is a test\n')) == True
    assert bool(parse('\nThis is a fn\n\nThis is a test\n\n')) == True
    assert bool(parse('This is a fn with a params\n\nThis is a test\n\nParameters\n----------\n\narg : int\n    arg description\n')) == True