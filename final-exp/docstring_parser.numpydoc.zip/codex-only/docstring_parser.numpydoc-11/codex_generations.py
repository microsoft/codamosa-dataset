

# Generated at 2022-06-23 17:05:53.478210
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    '''
    .. This is a docstring for the unit test of YieldsSection
    '''
    return

# Generated at 2022-06-23 17:06:01.234917
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = textwrap.dedent('''
    this is the first item
      the first item value spans multiple lines
    a second item
      the second item likewise spans multiple lines
      and continues to span multiple lines
    ''')
    text = inspect.cleandoc(text)
    items = _KVSection('section', 'key').parse(text)
    assert items[0].description == 'the first item value spans multiple lines'
    assert items[1].description == textwrap.dedent('''
      the second item likewise spans multiple lines
      and continues to span multiple lines
    ''')


# Generated at 2022-06-23 17:06:04.728219
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    x = ReturnsSection("Returns","returns")
    assert(x.title == "Returns")
    assert(x.key == "returns")
    assert(x.title_pattern == r'^Returns\s*?\n=-=+\s*$')
    assert(x.is_generator == False)





# Generated at 2022-06-23 17:06:10.452172
# Unit test for constructor of class Section
def test_Section():
    # 1. test with default parameter
    section = Section("Parameters", "param")
    assert section.title == "Parameters"
    assert section.key == "param"

    # 2. test without default parameter
    section = Section("Parameters", "params")
    assert section.title == "Parameters"
    assert section.key == "params"



# Generated at 2022-06-23 17:06:12.706481
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    __test_title__ = "test title"
    __test_key__ = "test key"
    __test_section__ = _SphinxSection(__test_title__, __test_key__)
    assert __test_section__.title == __test_title__
    assert __test_section__.key == __test_key__
    return

# Generated at 2022-06-23 17:06:13.832330
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    sec = DeprecationSection("Deprecated", "deprecated")
    assert sec


# Generated at 2022-06-23 17:06:20.452147
# Unit test for method parse of class Section
def test_Section_parse():
    class Section_test(Section):
        pass
    s = Section_test("Parameters", "param")
    assert s.title_pattern == r"^(Parameters)\s*?\n---\s*$"
    assert list(s.parse("arg_name\n    arg_description")) == [DocstringMeta(['param'], description='arg_description')]
    assert list(s.parse("arg_name\n    arg_description\narg_name2\n    arg_description")) == [
        DocstringMeta(['param'], description='arg_description'),
        DocstringMeta(['param'], description='arg_description')
    ]


# Generated at 2022-06-23 17:06:24.311097
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    text = '''
            A description of this returned value
        another_type
            Return names are optional, types are required
    '''
    assert isinstance(ReturnsSection("Returns", "returns").parse(text), tuple)



# Generated at 2022-06-23 17:06:35.975806
# Unit test for method parse of class Section
def test_Section_parse():
    test_section_title = "Parameters"
    test_section_key = "param"
    test_section_text = """arg_name
        arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines"""
    section_args = [test_section_key, "arg_name"]

    new_section = ParamSection(test_section_title, test_section_key)
    # Check if the function .parse() finds the correct number of parameters
    assert len(list(new_section.parse(test_section_text))) == 2
    # Check if the function .parse() assigns the correct values to the keys
    section_keys = [section.args for section in new_section.parse(test_section_text)]

# Generated at 2022-06-23 17:06:43.878741
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Basic test
    parsed = parse(
        text=
        """
    Hello world
    """
    )
    assert parsed.short_description == "Hello world"

    # Test sections
    parsed = parse(
        text=
        """
    Hello world

    Raises
    ------
    ValueError
        Test raise
    """
    )
    assert parsed.short_description == "Hello world"
    assert list(parsed.meta) == [
        DocstringRaises(
            args=[
                "raises",
                "ValueError",
            ],
            description="Test raise",
            type_name="ValueError",
        )
    ]

    # Test empty numpydoc docstring will still parse
    parsed = parse(text="")
    assert parsed.short_description is None



# Generated at 2022-06-23 17:06:47.279865
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("test", "test"))
    assert parser.sections["test"]
    assert "test" in parser.sections

# Generated at 2022-06-23 17:06:53.216213
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    test_sections = []
    test_sections.append(DeprecationSection("deprecated", "DeprecationWarning"))
    test_sections.append(DeprecationSection("deprecated", "DeprecationWarning"))
    test_sections.append(DeprecationSection("deprecated", "DeprecationWarning"))
    for s in test_sections:
        assert(s.title == "deprecated")
        assert(s.key == "DeprecationWarning")

# Generated at 2022-06-23 17:06:57.036563
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    t=ReturnsSection("Returns", "returns")
    assert(t.is_generator==False)
    assert(t.key=="returns")
    assert(t.title=="Returns")

# Generated at 2022-06-23 17:07:01.588854
# Unit test for constructor of class Section
def test_Section():
    """Unit test for constructor of class Section"""
    section = Section("title", "key")
    assert section.title == "title"
    assert section.key == "key"
    assert section.title_pattern == r"^title\s*?\n-*\s*$"


# Generated at 2022-06-23 17:07:06.680335
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """key
            value
        key2 : type
            values can also span...
            ... multiple lines"""
    kv_section = _KVSection("title", "key")
    res = {"key": "key",
           "value": "value"}

    for n, i in enumerate(kv_section.parse(text)):
        assert i.args == [res["key"]]
        assert i.description == res["value"]

# Generated at 2022-06-23 17:07:08.584910
# Unit test for constructor of class ParamSection
def test_ParamSection():
    sec = ParamSection("Parameters", "param")
    assert sec.title == "Parameters"
    assert sec.key == "param"


# Generated at 2022-06-23 17:07:10.945207
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    parser = RaisesSection("Raises", "raises")
    my_text = "ValueError\n    Parameter a is greater than 10"
    result = parser.parse(my_text)
    assert next(result).description == "Parameter a is greater than 10"



# Generated at 2022-06-23 17:07:22.224962
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # This function is for testing the NumpydocParser class
    # It is being used for testing the functionality of the NumpydocParser
    # class.
    # Input:
    #    text: a string of the numpy style docstring
    # Output:
    #    a Docstring object
    parser = NumpydocParser()
    text = "   """
    text += "\n   Test function"
    text += "\n        Test line 4"
    text += "\n        Test line 5"
    text += "\n    Parameters"
    text += "\n    ----------"
    text += "\n    sub_index : int"
    text += "\n        Description: Description of the sub_index parameter"
    text += "\n        Default: 5"
    text += "\n    root_dir : str, optional"

# Generated at 2022-06-23 17:07:27.044938
# Unit test for constructor of class ParamSection
def test_ParamSection():
    test = ParamSection("Parameters", "param")
    assert test.title == "Parameters"
    assert test.key == "param"


# Generated at 2022-06-23 17:07:28.556814
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    my_parser = NumpydocParser()
    assert my_parser.sections


# Generated at 2022-06-23 17:07:31.678252
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
	deprecation_section = DeprecationSection("Deprecated", "deprecation")
	expected = "deprecation"
	assert deprecation_section.key == expected


# Generated at 2022-06-23 17:07:35.517621
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    numpydoc_exception = "ValueError\n    A description of what might raise ValueError"
    actual = RaisesSection("Raises", "raises").parse(numpydoc_exception)
    actual = next(actual)
    assert isinstance(actual, DocstringRaises)
    assert actual.type_name == "ValueError"

# Generated at 2022-06-23 17:07:45.857377
# Unit test for function parse
def test_parse():
    # These are based on real examples from numpy
    numpy_docstring = r"""
    This is the docstring.

    This is a longer description.

    Parameters
    ----------
    arg_name : str
        Description of the first argument
    arg_2 : type
        Description of the second argument

    Examples
    --------
    >>> 1 + 1
    2
    >>> 2 * 2
    4
    """
    parsed = parse(numpy_docstring)
    assert parsed.short_description == 'This is the docstring.'
    assert parsed.long_description == 'This is a longer description.'
    assert parsed.blank_after_short_description is False
    assert parsed.blank_after_long_description is True
    assert parsed.meta[0].args == ['param', 'arg_name']

# Generated at 2022-06-23 17:07:58.520296
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    test_cases = [(".. deprecated:: 1.0 \n    Deprecation warning \n    \n", "1.0", "Deprecation warning"),(".. deprecated:: 1.0 \n    Deprecation warning \n\n", "1.0", "Deprecation warning"),(".. deprecated:: 1.0 \n    \n\n", "1.0", None)]

    for case in test_cases:
        section = DeprecationSection("deprecated", "deprecation")
        result = section.parse(case[0])
        version, desc, *_ = case[1:]
        result_version = list(result)[0].version
        result_desc = list(result)[0].description
        assert result_version == version and result_desc == desc


# Generated at 2022-06-23 17:08:05.278780
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    A short description.

    A longer description
    that spans over multiple lines.

    """

    docstring = NumpydocParser().parse(text)
    assert docstring.short_description == "A short description."
    assert docstring.blank_after_short_description is False
    assert docstring.long_description == (
        "A longer description\n"
        "that spans over multiple lines."
    )
    assert docstring.blank_after_long_description is True



# Generated at 2022-06-23 17:08:16.626154
# Unit test for method parse of class Section
def test_Section_parse():
    text = """
    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    Returns
    -------
    The following types of object are returned:
    type : type
        A description of this returned value
    another_type
        Return names are optional, types are required
    """

# Generated at 2022-06-23 17:08:19.392785
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ParamSection(title="Parameters", key="param")


# Generated at 2022-06-23 17:08:25.756882
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    p = NumpydocParser()
    p.add_section(Section("A", "b"))
    assert p.sections["A"] == Section("A", "b")
    assert p.sections["A"] != Section("A", "a")
    p.add_section(Section("A", "a"))
    assert p.sections["A"] == Section("A", "a")


# Generated at 2022-06-23 17:08:29.906076
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yields", "yields")
    assert ys.title == "Yields"
    assert ys.key == "yields"
    assert ys.is_generator is True


# Generated at 2022-06-23 17:08:34.634738
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    test_text = """
    Parameters
    ----------
    arg1
        arg1 description
    arg2 : type
        arg2 description
    arg3, optional
        arg3 description
    type, optional
        arg4 description
    """
    test_instance = ParamSection("Parameters", "param")
    test_text = inspect.cleandoc(test_text)

    for test_match, test_next_match in _pairwise(KV_REGEX.finditer(test_text)):
        start = test_match.end()
        end = test_next_match.start() if test_next_match is not None else None
        value = test_text[start:end]

# Generated at 2022-06-23 17:08:44.463705
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """A one-line summary that does not use variable names or the
    function name.
    A longer, multi-line description that may contain equations and
    paragraphs. Use variables names (:math:`r`, :math:`m`, etc.) and the
    function name (``f``, ``g``, etc.) in the first line of the summary,
    as this may be used by automatic indexing tools.
    Parameters
    ----------
    r : array_like of floats
        Input.
    m : int
        Input.
    Raises
    ------
    TypeError
        If a parameter is the wrong type.
    Returns
    -------
    n : int
        Output.
    """
    section = ParamSection("Parameters", "param")
    list = list(section.parse(text))
    assert len(list) == 1
   

# Generated at 2022-06-23 17:08:53.156266
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    ds = DeprecationSection("deprecated", "deprecation")
    assert ds.parse("asdf\n") == [DocstringDeprecated(args=["deprecation"], description="asdf", version="None")]
    assert ds.parse("asdf") == [DocstringDeprecated(args=["deprecation"], description="None", version="asdf")]
    assert ds.parse("asdf\nasdf\n") == [DocstringDeprecated(args=["deprecation"], description="asdf", version="asdf")]

# Generated at 2022-06-23 17:08:54.999783
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection('Parameters', 'param').__class__ == ParamSection


# Generated at 2022-06-23 17:08:59.512274
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    title = "Yields"
    key = "yields"
    instance = YieldsSection(title, key)
    assert (instance.title == title)
    assert (instance.key == key)
    assert (instance.is_generator == True)


# Generated at 2022-06-23 17:09:00.013363
# Unit test for method parse of class Section
def test_Section_parse():
    assert True

# Generated at 2022-06-23 17:09:11.147387
# Unit test for constructor of class NumpydocParser

# Generated at 2022-06-23 17:09:15.479338
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpy_obj = NumpydocParser()
    param_section = ParamSection("Parameters", "param")
    numpy_obj.add_section(param_section)
    assert numpy_obj.sections["Parameters"] == param_section


# Generated at 2022-06-23 17:09:24.302654
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    custom_section = DeprecationSection("deprecation_info","Deprecation_info")
    parser = NumpydocParser()
    parser.add_section(custom_section)
    assert parser.sections.__contains__(custom_section.title)

    text = """
    .. deprecated:: 3.2.1

        Use the new, improved fun().
    """
    assert parser.parse(text).meta == [
        DocstringDeprecated(
            args=["Deprecation_info"],
            description=None,
            version="3.2.1",
        )
    ]



# Generated at 2022-06-23 17:09:36.136609
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section = ReturnsSection("Returns", "returns")
    print(section.title_pattern)
    text = 'Returns\n-------\nx : y\n    a\n    b\n    c\n    d'
    for i in section.parse(text):
        print(i)



# Generated at 2022-06-23 17:09:39.626474
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section = _SphinxSection(title="Title", key="key")
    assert section.key == "key"
    assert section.title == "Title"
    assert section.title_pattern == r"^\.\.\s*(Title)\s*::"



# Generated at 2022-06-23 17:09:40.466365
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    # TODO: Add some tests
    assert True == True

# Generated at 2022-06-23 17:09:42.574472
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    with pytest.raises(IndexError):
        ReturnsSection('Returns', 'returns').is_generator

# Generated at 2022-06-23 17:09:54.439452
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection(title="Deprecation warning", key="deprecation")
    result = section.parse(text="version\n    desc\nk")
    assert next(result) == DocstringDeprecated(args=['deprecation'], description='desc', version='version')
    # test no desc
    result = section.parse(text="version\n    \nk")
    assert next(result) == DocstringDeprecated(args=['deprecation'], description=None, version='version')
    # test empty text
    result = section.parse(text="")
    assert next(result) == DocstringDeprecated(args=['deprecation'], description=None, version=None)

# Generated at 2022-06-23 17:09:59.448642
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    # Test parsing a section with a new title
    section = Section("Test", "test")
    parser.add_section(section)
    result = parser.parse("Test\n----\nvalue\nkey : value\n")
    assert result == \
        Docstring(short_description=None, long_description=None, meta=[DocstringMeta(args=['test'],description='value\nkey : value'),])
    # Test parsing a section with an existing title, which should replace the old section with the new one.
    section = RaisesSection("Test", "test")
    parser.add_section(section)
    result = parser.parse("Test\n----\nvalue\nkey : value\n")

# Generated at 2022-06-23 17:10:09.274624
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    text = """
    Parameters
    ----------
    x : int
        A parameter.

    y : float
        Another parameter.

    Raises
    ------
    ValueError
        An error.
    """

    result = parser.parse(text)
    assert result.short_description == ""
    assert result.long_description == ""
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == False
    assert len(result.meta) == 2

    assert result.meta[0].args == ['param', 'x']
    assert result.meta[0].type_name == None
    assert result.meta[0].is_optional == False
    assert result.meta[0].default == None

# Generated at 2022-06-23 17:10:19.452850
# Unit test for constructor of class Section
def test_Section():
    # Test__init___basic: default constructor
    # Input:
    # title : section title. For most sections, this is a heading like
    # "Parameters" which appears on its own line, underlined by
    # en-dashes ('-') on the following line
    # key : meta key string. In the parsed DocstringMeta instance this
    # will be the first element of the args attribute list.
    title = 'param'
    key = 'key'
    # Output:
    # section title = "param"
    # meta key string = "key"
    assert Section(title, key).title == 'param'
    assert Section(title, key).key == 'key'


# Generated at 2022-06-23 17:10:23.976817
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    ds = DeprecationSection("title","key")

    #Testing the pattern that the title matches against
    assert ds.title_pattern == r"^\.\.\s*(title)\s*::"


# Generated at 2022-06-23 17:10:34.434359
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert parse("Test\n\nLonger description")
    assert parse("Test\nLonger description")
    assert parse("Test")
    assert parse("")
    assert parse("\n")
    assert parse("\n\n")
    assert parse("Test\n\nLonger description\nArgs:\nx\n\n   1\n")
    assert parse("Test\n\nLonger description\nReturns:\n1\n")
    assert parse("Test\n\nLonger description\nReturns:\nx\n\n   1\n")
    # Testing for method add_section, of class NumpydocParser
    parser = NumpydocParser()
    assert parser
    section = Section("x", "y")
    parser.add_section(section)
    assert parser.sections["x"] == section

# Generated at 2022-06-23 17:10:38.793318
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    doc = "parm1\n description\nparm2: type"
    section = _KVSection('title','key')
    doc_meta = section.parse(doc)

    assert next(doc_meta).description == 'description'
    return True


# Generated at 2022-06-23 17:10:43.971293
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    text='''
    :param text: section body text. Should be cleaned with
                 ``inspect.cleandoc`` before parsing.'''

    result=NumpydocParser().parse(text)

# Generated at 2022-06-23 17:10:51.808483
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    # Given
    title = "deprecated"
    key = "deprecation"
    obj = DeprecationSection(title, key)
    version = "0.0.2"
    desc = "deprecated desc"
    text = version + "\n" + desc
    # When
    result = obj.parse(text)
    # Then
    assert(str(result) == "[deprecation] deprecated desc")
    item = next(result)
    assert(item.args == [key])
    assert(item.version == version)


# Generated at 2022-06-23 17:10:54.500906
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    ts = DeprecationSection('deprecated', 'deprecated')
    assert(ts.title=='deprecated')
    assert(ts.key=='deprecated')

# Generated at 2022-06-23 17:10:57.423114
# Unit test for constructor of class _KVSection
def test__KVSection():
    with pytest.raises(TypeError) as excinfo:
        _KVSection()
    assert str(excinfo.value) =='_KVSection() missing 2 required positional arguments: \'title\' and \'key\''

# Generated at 2022-06-23 17:11:04.673383
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert RaisesSection.__doc__ == """Parser for numpydoc raises sections.

    E.g. any section that looks like this:
        ValueError
            A description of what might raise ValueError"""
    assert RaisesSection.__init__.__doc__ == """Initializer

    :param title: section title. For most sections, this is a heading like
                  "Parameters" which appears on its own line, underlined by
                  en-dashes ('-') on the following line.
    :param key: meta key string. In the parsed ``DocstringMeta`` instance this
                will be the first element of the ``args`` attribute list.
    """
    assert isinstance(RaisesSection.title, property)
    assert isinstance(RaisesSection.key, property)
    assert isinstance(RaisesSection._parse_item, RaisesSection)
   

# Generated at 2022-06-23 17:11:09.923880
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    b = Section(title="Parameters2", key="parameters2")
    parser = NumpydocParser()
    parser.add_section(b)
    assert "Parameters2" in parser.sections
    assert parser.sections["Parameters2"] == b

# Generated at 2022-06-23 17:11:18.964475
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p_section = ParamSection("Parameters", "param")
    assert p_section.parse("""a
    Desc of a
    b : str, optional
        Desc of b""") == [
        DocstringParam(
            args=["param", "a"],
            description="Desc of a",
            arg_name="a",
            type_name=None,
            is_optional=False,
            default=None,
        ),
        DocstringParam(
            args=["param", "b"],
            description="Desc of b",
            arg_name="b",
            type_name="str",
            is_optional=True,
            default=None,
        ),
    ]

# Generated at 2022-06-23 17:11:21.476026
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    new_section = Section("Some Section", "section")
    parser.add_section(new_section)
    assert parser.sections["Some Section"] == new_section

# Generated at 2022-06-23 17:11:23.219505
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    s = ReturnsSection("Returns", "returns")



# Generated at 2022-06-23 17:11:27.506321
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection("Parameters", "param")
    assert p.title == "Parameters"
    assert p.key == "param"
    assert p.title_pattern == r"^Parameters\s*?\n-+\s*$"

# Generated at 2022-06-23 17:11:35.084308
# Unit test for constructor of class ParamSection
def test_ParamSection():
    paramSection = ParamSection('Parameters','params')
    assert paramSection.title_pattern == r"^Parameters\s*?\n-----*\s*$"
    assert paramSection.title == 'Parameters'
    assert paramSection.key == 'params'


# Generated at 2022-06-23 17:11:44.566394
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    # returns_section = ReturnsSection()
    ret = ReturnsSection("Returns", "returns")
    assert ret.title == "Returns"
    assert ret.key == "returns"
    assert ret.title_pattern == "^Returns\s*?\n=+\s*$"
    assert ret.is_generator == False
    assert ret.is_generator == False
    #test parse method
    text1 = "return_name : type\nA description of this returned value"
    text2 = "another_type\nReturn names are optional, types are required"
    ret1 = ret._parse_item(key="return_name : type",
                           value="A description of this returned value")
    ret2 = ret._parse_item(key="another_type",
                           value="Return names are optional, types are required")


# Generated at 2022-06-23 17:11:48.179778
# Unit test for constructor of class Section
def test_Section():
    title = "[Section]"
    key = "key"
    section = Section(title, key)
    assert section.key == key
    assert section.title == title


# Generated at 2022-06-23 17:11:54.662672
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r1 = RaisesSection("Raises", "raises")
    parsedText = r1.parse("ValueError \n A description of what might raise ValueError")
    expected = [DocstringRaises(
            args=["raises", "ValueError"],
            description="A description of what might raise ValueError",
            type_name="ValueError")]

    assert list(parsedText) == expected

# Generated at 2022-06-23 17:12:01.887008
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    inp = """
    Simple example function with types documented in the docstring.

    Args:
      param1 (int): The first parameter.
      param2 (str): The second parameter.

    Returns:
      bool: The return value. True for success, False otherwise.
    """
    out = parse(inp)
    assert out.short_description == "Simple example function with types documented in the docstring."
    assert out.blank_after_short_description is True
    assert out.blank_after_long_description is True
    assert out.long_description is None
    assert out.meta[0].__repr__() == DocstringMeta([
        'param', 'param1'
    ], description='The first parameter.').__repr__()

# Generated at 2022-06-23 17:12:09.152774
# Unit test for method parse of class Section
def test_Section_parse():
    title = "Section"
    key = "Key"
    text = "Text"
    section = Section(title, key)
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == r"^({})\s*?\n{}\s*$".format(title, "-" * len(title))
    assert section.parse(text) == [DocstringMeta([key], description=text)]


# Generated at 2022-06-23 17:12:13.040528
# Unit test for constructor of class ParamSection
def test_ParamSection():
    """The constructor should set the title and key properly."""
    p = ParamSection("Foo","Bar")
    assert p.title == "Foo"
    assert p.key == "Bar"

# Generated at 2022-06-23 17:12:15.791242
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ps = ParamSection("Parameters", "param")
    if ps.title == "Parameters" and ps.key == "param":
        return True
    else:
        return False

# Generated at 2022-06-23 17:12:21.495971
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert RaisesSection("Raises", "raises").key == "raises"
    assert RaisesSection("Raises", "raises").title == "Raises"
    assert RaisesSection("Raises", "raises").title_pattern == "^Raises\s*?\n-+\s*$"

# Generated at 2022-06-23 17:12:30.321113
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():

    class testSection(Section):
        def __init__(self, title: str, key: str) -> None:
            self.title = title
            self.key = key

        @property
        def title_pattern(self) -> str:
            return r"^test\s*$"

        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            return

    numpydocParser = NumpydocParser()
    numpydocParser.add_section(testSection("test", "test_key"))
    assert numpydocParser.sections["test"] == testSection("test", "test_key")

# Generated at 2022-06-23 17:12:33.543772
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # Test the docstring param parsing
    assert str(ParamSection("Parameters", "param")) == "<class ParamSection>"


# Generated at 2022-06-23 17:12:35.674849
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert RaisesSection("Raises", "raises") is not None

# Generated at 2022-06-23 17:12:46.239941
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "Deprecated"
    key = "deprecation"
    obj = _SphinxSection(title, key)
    expected = (
        r"^\.\.\s*Deprecated\s*::\s*\n"
        r"^\s*?\n"
        r"^\s*?\n"
        r"^\s*?\n"
        r"^\s*?\n"
        r"^\s*?\n"
        r".*?"
    )
    assert re.compile(
        obj.title_pattern,
        flags=re.MULTILINE
    ).match(expected) is not None

# Generated at 2022-06-23 17:12:48.567842
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    a = ReturnsSection("Returns","returns")
    print(a.title)
    print(a.key)
    print(a.title_pattern)


# Generated at 2022-06-23 17:12:54.704372
# Unit test for method parse of class Section
def test_Section_parse():
    args = [1, 2, 3]
    description = 1
    section = Section(args[0], args[1])
    expected = DocstringMeta(args[2:], description=description)
    actual = section.parse(description)
    assert actual.args == expected.args
    assert actual.description == expected.description


# Generated at 2022-06-23 17:13:01.458963
# Unit test for constructor of class _KVSection
def test__KVSection():
    s = _KVSection("Parameters", "param")
    assert s.title == "Parameters"
    assert s.key == "param"
    assert s.parse("") == []
    assert s.parse("arg_name\n\targ_description\narg_2 : type, optional\n\tdescriptions can also span...\n\t... multiple lines") == []
    assert s._parse_item("key", "value") == None


# Generated at 2022-06-23 17:13:03.781590
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param = ParamSection("Parameters", "param")
    assert param.key == "param"
    assert param.title == "Parameters"


# Generated at 2022-06-23 17:13:04.787863
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()

# Generated at 2022-06-23 17:13:11.152619
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    np = NumpydocParser()
    new_s = Section('Titulo', 'key')
    new_s.title_pattern = r'^Título\s*?\n{}\s*$'.format('-' * len('Título'))

    # Primeiro teste: nova seção adicionada
    np.add_section(new_s)
    assert new_s.title_pattern == '^Título\s*?\n{}\s*$'.format('-' * len('Título'))

# Generated at 2022-06-23 17:13:17.265207
# Unit test for constructor of class ParamSection
def test_ParamSection():
    sections = [ParamSection("Parameters", "param")]
    assert sections[0].key == "param"
    assert sections[0].title == "Parameters"
    assert sections[0].title_pattern == '^(Parameters)\s*?\n{}\s*$' \
        .format('-' * len(sections[0].title))


# Generated at 2022-06-23 17:13:19.027094
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ParamSection(title= "arg_name: type, optional", key = "param")


# Generated at 2022-06-23 17:13:21.811972
# Unit test for constructor of class Section
def test_Section():
    assert Section("Parameters", "param")


# Generated at 2022-06-23 17:13:26.967523
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raiseSection = RaisesSection("Raises", "raises")
    text = """
        ValueError
            A description of what might raise ValueError
         """
    res = [
        DocstringMeta(
            args=["raises","ValueError"],
            description="A description of what might raise ValueError",
            type_name="ValueError",
        )
    ]
    assert list(raiseSection.parse(text)) == res


# Generated at 2022-06-23 17:13:34.921715
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("Deprecated", "deprecated")
    assert section.parse("issue 7444\nThis is the text of the warning") == [DocstringDeprecated(args=["deprecated"], description='This is the text of the warning', version='issue 7444')]
    assert section.parse("issue 7444") == [DocstringDeprecated(args=["deprecated"], description=None, version='issue 7444')]
    assert section.parse("") == [DocstringDeprecated(args=["deprecated"], description=None, version=None)]

# Generated at 2022-06-23 17:13:37.346954
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    ob = ReturnsSection("Returns", "returns")
    assert ob.title == "Returns"
    assert ob.key == "returns"



# Generated at 2022-06-23 17:13:50.089179
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raise_text = '''Raises
    ------
    ValueError
        A description of what might raise ValueError
    '''
    assert RaisesSection("Raises", "raises").parse(raise_text) == [
        DocstringRaises(
            args=[
                'raises',
                'ValueError',
            ],
            description='A description of what might raise ValueError',
            type_name='ValueError',
        ),
    ]
    raise_2_text = '''Raises
    ------
    ValueError
        A description of what might raise ValueError
    TypeError
        A description of what might raise TypeError'''

# Generated at 2022-06-23 17:13:57.870984
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """ Tests the method NumpydocParser.add_section
    """
    text = """ This is the short description.
    
    This is the long description.
    
    Warnings
    --------
    A warning
    """
    section = Section("Warnings", "WARNING")
    parser = NumpydocParser()
    parser.add_section(section)
    parsed_docstring = parser.parse(text)
    assert parsed_docstring.meta[0].args == ['WARNING']
    assert parsed_docstring.meta[0].description == "A warning"

# Generated at 2022-06-23 17:14:00.798658
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rs = RaisesSection("Raises", "raises")
    assert rs.title == "Raises"
    assert rs.key == "raises"


# Generated at 2022-06-23 17:14:03.177861
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("Test", "test"))
    assert parser.sections["Test"]


# Generated at 2022-06-23 17:14:12.214243
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    from . import shells
    from .common import Docstring, DocstringMeta
    from .sphinx import SphinxParser
    from .shells import ShellParser

    # Test the default behaviour
    parser = NumpydocParser()

# Generated at 2022-06-23 17:14:25.195277
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """This is a short description.

    This is a very long
    description which spans multiple
    lines.

    It might also look something like this:
    par1: type1
        This is a param
        It may take multiple lines
    par2: type2
        This is a param
        It may take multiple lines
    Attributes
        This is a param
        It may take multiple lines

    Parameters
    ----------
    par1: type1
        This is a param
        It may take multiple lines
    par2: type2
        This is a param
        It may take multiple lines
    Attributes
        This is a param
        It may take multiple lines
    """

    docstring = parse(text)
    assert docstring.short_description == "This is a short description."

# Generated at 2022-06-23 17:14:26.218572
# Unit test for constructor of class Section
def test_Section():
     section = Section('tt', 'key')
     asser

# Generated at 2022-06-23 17:14:32.547470
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-23 17:14:37.311732
# Unit test for constructor of class _KVSection
def test__KVSection():
    kv = _KVSection("Parameters", "param")
    ac = r"^(Parameters)\s*?\n-{11}\s*$"
    assert(kv.title_pattern == ac)


# Generated at 2022-06-23 17:14:41.121123
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    # Check the inheritance
    numpy_yields_section = YieldsSection("Yields", "yields")
    assert isinstance(numpy_yields_section, ReturnsSection)

# Generated at 2022-06-23 17:14:43.161763
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert isinstance(RaisesSection("Raises","raises"),_KVSection)

# Generated at 2022-06-23 17:14:47.661922
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # Creating a dummy section which doesn't exist in the default sections
    section = Section("test", "test")
    # Creating an instance of the class NumpydocParser
    np = NumpydocParser()
    # Adding the section to the instance
    np.add_section(section)
    # The section should be in the list of sections
    assert section.title in np.sections

# Generated at 2022-06-23 17:14:48.772010
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    numpydoc_parser = NumpydocParser()
    print(numpydoc_parser.sections)



# Generated at 2022-06-23 17:14:52.812281
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
	test = YieldsSection(title="Yields",key="yields");
	assert test.is_generator == True
	assert test.title == "Yields"
	assert test.key == "yields"


# Generated at 2022-06-23 17:14:58.539244
# Unit test for constructor of class Section
def test_Section():
    """Test function for class Section"""
    p = Section("Parameters", "param")
    assert(p.title == "Parameters")
    assert(p.key == "param")
    assert(p.title_pattern == "^(Parameters)\\s*?\n{}\\s*$".format("-"*11))
    assert(p.parse("arg_name\narg_description") == [DocstringMeta([])])
    

# Generated at 2022-06-23 17:15:07.581048
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Function to test the class NumpydocParser in the module numpydocparse.
    :return:
    """
    def _test_case(docstring, expected_docstring):
        """
        Internal function to test if the result is as expected
        :param docstring: Docstring to be parsed
        :param expected_docstring: Expected result of the parsing
        :return:
        """
        result = NumpydocParser().parse(docstring)
        assert result == expected_docstring


# Generated at 2022-06-23 17:15:20.257256
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test docstring with no sections
    docstring_no_sections = parse("single line docstring")

    assert docstring_no_sections.short_description == 'single line docstring'
    assert docstring_no_sections.long_description == None
    assert docstring_no_sections.meta.all_meta == []

    # Test docstring with only short description and long description
    docstring_long_desc = parse("first line\nsecond line")

    assert docstring_long_desc.short_description == 'first line'
    assert docstring_long_desc.long_description == 'second line'
    assert docstring_long_desc.meta.all_meta == []

    # Test docstring with short description,
    # long description with blank lines, and a single section
    docstring_long_desc_with_blank_lines = parse

# Generated at 2022-06-23 17:15:29.298883
# Unit test for function parse
def test_parse():
    docstring = """
    Parse the numpy-style docstring into its components.

    Parameters
    ----------
    text : str
        Text to parse

    Returns
    -------
    A parsed docstring

    Raises
    ------
    ValueError
        For bad things

    Warns
    -----
    UserWarning
        For good things
    """

    parsed = parse(docstring)
    print(parsed)
    print(parsed.meta)
    assert parsed.short_description == "Parse the numpy-style docstring into its components."

# Generated at 2022-06-23 17:15:41.559675
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:15:48.270175
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    """
    Test _KVSection attributes
    """
    parser = NumpydocParser()

# Generated at 2022-06-23 17:15:59.884579
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    my_parser = NumpydocParser()