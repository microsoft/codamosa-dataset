

# Generated at 2022-06-23 17:05:58.938394
# Unit test for constructor of class Section
def test_Section():
    sec = Section("title", "key")
    assert sec.title == "title"
    assert sec.key == "key"
    assert sec.title_pattern == "^(title)\s*?\n{}\s*$".format("-" * len(sec.title))
    assert sec.parse("") == []

test_Section()


# Generated at 2022-06-23 17:06:03.263784
# Unit test for constructor of class _KVSection
def test__KVSection():
    s = _KVSection(title="Something", key="s")
    assert s.title == "Something"
    assert s.key == "s"
    assert s.title_pattern == "^(Something)\\s*?\\n\\-*\\s*$"


# Generated at 2022-06-23 17:06:04.922194
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    a = RaisesSection("Raises", "raises")


# Generated at 2022-06-23 17:06:09.258605
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yields", "yields")
    assert ys.key == "yields"
    assert ys.is_generator == True
    assert ys.title == "Yields"

# Generated at 2022-06-23 17:06:13.024446
# Unit test for constructor of class ParamSection
def test_ParamSection():
    paramSection = ParamSection("testSection", "testSectionKey")
    assert paramSection.title == "testSection"
    assert paramSection.key == "testSectionKey"


# Generated at 2022-06-23 17:06:21.425285
# Unit test for constructor of class ParamSection
def test_ParamSection():
    test1 = ParamSection("Parameters", "param")
    test2 = ParamSection("Params", "param")
    test3 = ParamSection("Arguments", "param")
    test4 = ParamSection("Args", "param")
    test5 = ParamSection("Other Parameters", "other_param")
    test6 = ParamSection("Other Params", "other_param")
    test7 = ParamSection("Other Arguments", "other_param")
    test8 = ParamSection("Other Args", "other_param")
    test9 = ParamSection("Receives", "receives")
    test10 = ParamSection("Receive", "receives")
    assert test1.title == "Parameters"
    assert test1.key == "param"

# Generated at 2022-06-23 17:06:23.875525
# Unit test for constructor of class _KVSection
def test__KVSection():
    section = _KVSection("title", "key")
    assert section.title == "title"
    assert section.key == "key"

# Generated at 2022-06-23 17:06:25.580809
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections != None

# Generated at 2022-06-23 17:06:30.745882
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    ds = DeprecationSection("deprecation warning", "deprecation")
    text = '''deprecation warning
    since 2.0
    advice on replacement
    ''' 
    assert ds.parse(text) == (DocstringDeprecated(args=[ds.key], description='advice on replacement', version='since 2.0'),)

# Generated at 2022-06-23 17:06:36.070931
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    # Test constructor of class YieldsSection
    assert YieldsSection('Yields', 'yields').is_generator == True
    assert YieldsSection('Yields', 'yields').key == 'yields'
    assert YieldsSection('Yields', 'yields').title == 'Yields'


# Generated at 2022-06-23 17:06:42.195755
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    example = "\n"+\
"""Yields
--------
A dictionary of the different properties specified."""
    y = YieldsSection("Yields", "yields")
    for item in y.parse(example):
        assert(item.type_name == "A dictionary of the different properties specified")
        assert(item.is_generator == True)
        assert(item.return_name == None)
        assert(item.description == item.type_name)
        assert(item.args[0] == "yields")
        assert(y.key == "yields")

# Generated at 2022-06-23 17:06:54.506431
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():

    numpydoc_parser = NumpydocParser()

    # Initialize a new section
    section = Section('TestSection','test_section')
    numpydoc_parser.add_section(section)

    # Find the section if it has been added
    assert len([
                 s for s in numpydoc_parser.sections if s == 'TestSection'
                 ]) == 1

    # Modify the new section
    section.title = 'NewTestSection'
    numpydoc_parser.add_section(section)

    # Find the new section if it has been added
    assert len([
                 s for s in numpydoc_parser.sections if s == 'NewTestSection'
                 ]) == 1

    # Delete the new section
    del numpydoc_parser.sections['NewTestSection']

    # Check if the

# Generated at 2022-06-23 17:07:04.793913
# Unit test for function parse

# Generated at 2022-06-23 17:07:12.934942
# Unit test for function parse
def test_parse():
    # Testing a simple function
    def parse_test(x):
        """
        Prints 'Hello World'

        :param x: int.

        :returns: x**2
        """
        pass
    parsed = parse(parse_test.__doc__)
    assert parsed.short_description == "Prints 'Hello World'"
    assert parsed.long_description == None
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert len(parsed.meta) == 1
    assert parsed.meta[0].args == ['param', 'x']
    assert parsed.meta[0].type_name == 'int.'
    assert parsed.meta[0].description == None
    assert parsed.meta[0].arg_name == 'x'

# Generated at 2022-06-23 17:07:18.817231
# Unit test for method parse of class Section
def test_Section_parse():
    section_obj = Section("title", "key")
    dict = {}
    dict['args'] = ['key']
    dict['description'] = _clean_str("" + "\n")

    res = section_obj.parse("")
    assert str(res) == str(dict)



# Generated at 2022-06-23 17:07:21.743602
# Unit test for method parse of class Section
def test_Section_parse():
    t = Section('Parameters','param')
    assert t.parse('text') == [
        DocstringMeta(['param'], description='text')
    ]

# Generated at 2022-06-23 17:07:27.040118
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    test_section = ReturnsSection("Returns", "returns")
    assert test_section.title == "Returns"
    assert test_section.key == "returns"
    assert test_section.title_pattern == r"^Returns\s*?\n={3}\s*$"
    assert test_section.parse("test_string") == [
        DocstringReturns(
            args=["returns"],
            description=None,
            type_name=None,
            is_generator=False,
            return_name=None,
        )
    ]

# Generated at 2022-06-23 17:07:28.557656
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    x = YieldsSection("Yields", "yields")

# Generated at 2022-06-23 17:07:31.868616
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "Attributes"
    key = "attribute"
    sec = _SphinxSection(title, key)
    assert sec.title_pattern == r"^\.\.\s*(Attributes)\s*::"


# Generated at 2022-06-23 17:07:33.672151
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Arrange:
    # Act:
    # Assert:
    assert _KVSection('title', 'key')

# Generated at 2022-06-23 17:07:35.681115
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection('Yields', 'yields')
    assert(y.is_generator == True)


# Generated at 2022-06-23 17:07:43.016396
# Unit test for function parse

# Generated at 2022-06-23 17:07:45.991446
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert DeprecationSection(title='deprecated',key='deprecation').parse("""
        This module will be removed in version 0.22.
        Use ``sklearn.neighbors.KNeighborsClassifier`` instead.
    """) == [DocstringDeprecated(args=['deprecation'], description='This module will be removed in version 0.22.', version='0.22')]

# Generated at 2022-06-23 17:07:51.688624
# Unit test for constructor of class ParamSection
def test_ParamSection():
    title = "Test"
    key = "test"

    # default value when consturctor is called without any argument
    assert ParamSection(title, key).title_pattern == r"^(Test)\s*?\n---\s*$"



# Generated at 2022-06-23 17:07:54.050128
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection("class", "").parse("") == []

# Generated at 2022-06-23 17:08:03.687157
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section(title='Parameters', key='param')
    text = """
    :param some: parameter
    :type some: str
    :returns: some value
    :rtype: int
    """
    text = inspect.cleandoc(text)
    ret = section.parse(text)
    for x in ret:
        print(x)

    text = """
    :param some: parameter
    :type some: str
    :returns: some value
    """
    text = inspect.cleandoc(text)
    ret = section.parse(text)
    for x in ret:
        print(x)


# Generated at 2022-06-23 17:08:15.473816
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:08:24.637628
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    numpydoc_parser = NumpydocParser()
    assert numpydoc_parser.sections["Raises"].key == "raises"
    assert numpydoc_parser.sections["Raises"].title == "Raises"
    assert numpydoc_parser.sections["Raises"].title_pattern == "^Raises\\s*?\n-----\\s*$"
    assert numpydoc_parser.sections["Raises"].parse("") == []


# Generated at 2022-06-23 17:08:29.686734
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """Test the method add_section of class NumpydocParser"""

    numpydoc_parser = NumpydocParser()
    section = Section("Test","test")
    numpydoc_parser.add_section(section)
    assert numpydoc_parser.sections["Test"] == section

# Generated at 2022-06-23 17:08:40.247676
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    class UnitTest(_KVSection):
        def _parse_item(self, key: str, value: str) -> DocstringMeta:
            return DocstringMeta([self.key, key, value], description=None)

    test_str = """\
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """

    test_ret = [
        DocstringMeta(['UnitTest', 'key', 'value'], description=None),
        DocstringMeta(['UnitTest', 'key2 : type', 'values can also span...\n... multiple lines'], description=None)
    ]

    assert UnitTest('UnitTest', 'UnitTest').parse(test_str) == test_ret

# Generated at 2022-06-23 17:08:42.927747
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = [
        Section("Parameters", "param")
    ]
    parser = NumpydocParser(sections)
    assert parser.sections["Parameters"].key == "param"

# Generated at 2022-06-23 17:08:49.800008
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    title = "deprecated"
    key = "deprecation"
    example = "Deprecated since version 1.0.0"
    dep_sec = DeprecationSection(title, key)
    assert dep_sec.parse(example) == [DocstringDeprecated(
            args=[key], description=None, version="1.0.0")]


# Generated at 2022-06-23 17:08:57.779906
# Unit test for function parse
def test_parse():
    parsers = NumpydocParser()
    docstring = '''Parses numpydoc-style docstrings into components.

A numpydoc docstring consists of a main description, some metadata
sections, and a long description.

Each section of the docstring is parsed into a separate
``DocstringMeta`` instance. The description is split into a short
description and a long description.

Example:
    >>> from docstamp import numpydoc
    >>> import inspect
    >>> example_docstring = inspect.cleandoc('''

# Generated at 2022-06-23 17:09:00.876010
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    section = Section("My New Section", "new_section")
    parser.add_section(section)
    assert(section in parser.sections.values())

# Generated at 2022-06-23 17:09:05.564294
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ps = ParamSection("M", "numpydoc")

    assert ps.title == "M"
    assert ps.key == "numpydoc"
    assert ps.title_pattern == r"^(M)\s*?\n-{1}\s*$"


# Generated at 2022-06-23 17:09:07.670713
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yields_sect = YieldsSection('Yields', 'yields')
    assert yields_sect


# Generated at 2022-06-23 17:09:08.700400
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser is not None


# Generated at 2022-06-23 17:09:20.036663
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    test_section = _KVSection(title="test section", key="key")
    test_text = "a\n    a description\nb : b type\n    b description\n"
    test_results = test_section.parse(test_text)
    for result in test_results:
        assert result.args[0] == test_section.key
    i = 0
    for key, value in [("a", "a description"),
                       ("b : b type", "b description")]:
        assert result[i].args[1] == key
        assert result[i].description == value
        i += 1


# Generated at 2022-06-23 17:09:21.906069
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser: NumpydocParser = NumpydocParser()
    parser.sections



# Generated at 2022-06-23 17:09:23.665247
# Unit test for constructor of class Section
def test_Section():
    title = 'param'
    key = 'param'
    s = Section(title, key)
    assert (title == s.title)
    assert (key == s.key)


# Generated at 2022-06-23 17:09:31.659049
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Provide the constructor with three different parameter values
    section1 = _KVSection("Parameters", "param")
    section2 = _KVSection("Params", "param")
    section3 = _KVSection("Arguments", "param")
    assert section1.title == "Parameters"
    assert section2.title == "Params"
    assert section3.title == "Arguments"
    assert section1.key == "param"
    assert section2.key == "param"
    assert section3.key == "param"



# Generated at 2022-06-23 17:09:34.200794
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections == {s.title: s for s in DEFAULT_SECTIONS}


# Generated at 2022-06-23 17:09:36.437604
# Unit test for constructor of class Section
def test_Section():
    test = Section("Test", "test")
    assert test.title == "Test"
    assert test.key == "test"


# Generated at 2022-06-23 17:09:42.766685
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():

    # Test if we can parse a deprecation warning
    deprecation_section2 = DeprecationSection("Deprecated", "deprecated")
    assert str(deprecation_section2.parse("0.1.0\nDouble quote strings are deprecated")) == "{'description': 'Double quote strings are deprecated'}"

    # Test if we can parse a deprecation warning without a version
    deprecation_section3 = DeprecationSection("Deprecated", "deprecated")
    assert str(deprecation_section3.parse("Double quote strings are deprecated")) == "{'description': 'Double quote strings are deprecated'}"

# Generated at 2022-06-23 17:09:51.778831
# Unit test for constructor of class Section
def test_Section():
    class MySection(Section):
        def parse(self, text):
            print('parser for MySection')

    s = MySection('title', 'key')
    print('title=%s' % s.title)
    print('key=%s' % s.key)
    print('title pattern=%s' % s.title_pattern)
    print('s.parse(text) is iterable=%s' % (isinstance(s.parse(''), collections.Iterable)))



# Generated at 2022-06-23 17:09:56.048351
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yield_section = YieldsSection("Yields", "yields")
    assert yield_section.is_generator == True
    assert yield_section.key == "yields"
    assert yield_section.title == "Yields"

# Generated at 2022-06-23 17:10:01.331734
# Unit test for method parse of class Section
def test_Section_parse():
    test_title = "Section_test"
    test_key = "key"
    text = """Section_test
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    key = "key"
    section = Section(test_title, test_key)
    class_section = _KVSection(test_title, test_key)
    assert section.parse(text).__next__().description == "value"
    assert class_section._parse_item(key, text).description == "value"

# Generated at 2022-06-23 17:10:02.875446
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    # Unit test for constructor of YieldsSection
    s = ReturnsSection('Returns', 'returns')
    assert s.is_generator == False


# Generated at 2022-06-23 17:10:06.095458
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    obj_numpydoc = NumpydocParser()
    obj_numpydoc.add_section(Section(title="foo", key="bar"))
    test1 = obj_numpydoc.sections["foo"]
    test2 = Section(title="foo", key="bar")
    assert test1 == test2

# Generated at 2022-06-23 17:10:11.479772
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    mytext = ".. deprecated:: 0.0"
    mytext += "\n" + "   A description of this deprecation"
    factory = DeprecationSection("deprecated", "deprecation")
    docstring_list = factory.parse(mytext)
    assert isinstance(docstring_list, list)
    #doc_dep = docstring_list[0]
    #assert isinstance(doc_dep, DocstringDeprecated)
    #assert doc_dep.args == ['deprecation']

# Generated at 2022-06-23 17:10:14.398934
# Unit test for constructor of class Section
def test_Section():
    section = Section("Parameters", "param")
    assert section.title == "Parameters"
    assert section.key == "param"


# Generated at 2022-06-23 17:10:19.498446
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    if __name__ == "__main__":
        d = DeprecationSection("deprecation","key")
        print(d.title)
        print(d.key)
        print(d.title_pattern)
        text = "::=::word\n"
        r = d.parse(text)
        print(r)


# Generated at 2022-06-23 17:10:21.906708
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    d = DeprecationSection("deprecated", "deprecated")


# Generated at 2022-06-23 17:10:24.627874
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yields", "yields")
    assert ys.is_generator == True

# Generated at 2022-06-23 17:10:32.177525
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    class RaisesSection(_KVSection):
        """Parser for numpydoc raises sections.

        E.g. any section that looks like this:
            ValueError
                A description of what might raise ValueError
        """

        def _parse_item(self, key: str, value: str) -> DocstringRaises:
            return DocstringRaises(
                args=[self.key, key],
                description=_clean_str(value),
                type_name=key if len(key) > 0 else None,
            )


# Generated at 2022-06-23 17:10:42.252797
# Unit test for method parse of class Section
def test_Section_parse():
    text1 = '''
    Parameters
    ----------
    x : torch.Tensor
        The tensor to be normalized.
    p : float
        The norm degree. Default is 2.
    dim : int
        The dimension to reduce. Default: ``dim=-1``.

    Returns
    -------
    torch.Tensor
        The normalized tensor with the same size as `x`.
    '''

    text2 = '''
    Parameters
    ----------
    x : torch.Tensor
        The tensor to be normalized.

    Returns
    -------
    torch.Tensor
        The normalized tensor with the same size as `x`.
    '''
    section = Section(title="Parameters", key='param')
    assert section.parse(text1) == NumpydocParser().sections['Parameters'].parse(text1)
   

# Generated at 2022-06-23 17:10:47.768125
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kv_section = ParamSection("Parameters", "param")
    text = """
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)

# Generated at 2022-06-23 17:10:48.862461
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection.is_generator == T

# Generated at 2022-06-23 17:10:53.479405
# Unit test for constructor of class Section
def test_Section():
    title = 'Functions'
    key = 'func'
    s = Section(title,key)
    assert s.title == 'Functions'
    assert s.key == 'func'
    assert s.title_pattern == r'^(Functions)\s*?\n{}\s*$'.format('-' * len(title))


# Generated at 2022-06-23 17:11:00.019878
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert NumpydocParser().sections["Parameters"] == ParamSection("Parameters", "param")
    assert NumpydocParser().sections["Raises"] == RaisesSection("Raises", "raises")
    assert NumpydocParser().sections["Returns"] == ReturnsSection("Returns", "returns")
    assert NumpydocParser().sections["Yields"] == YieldsSection("Yields", "yields")
    assert NumpydocParser().sections["deprecated"] == DeprecationSection("deprecated", "deprecation")



# Generated at 2022-06-23 17:11:02.348021
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    # Test for default constructor and constructor with given sections

    # Should not raise an exception
    NumpydocParser()

    # Should not raise an exception
    NumpydocParser({'Test': Section('Test', 'test')})

# Generated at 2022-06-23 17:11:07.759574
# Unit test for function parse
def test_parse():
    text = """
        A short description.

        A long description that can span
        multiple lines. This can also be
        empty.

        Parameters
        ----------
        some_param : str
            Some description.
            This spans multiple lines.
            Can also be empty.
            Default: 'foo'

        SomeOtherParam : int
            Another description.
            This spans multiple lines.
            Can also be empty.
            Default: 100

        other : bool, optional
            A final description.
            This spans multiple lines.
            Can also be empty.
            Default: False

        Raises
        ------
        ValueError
            This can span multiple lines.
            Can also be empty.

        See Also
        --------
        my_module.my_func : References a function
            in another module

    """

    doc = parse(text)

# Generated at 2022-06-23 17:11:19.292039
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    numpydoc_parser = NumpydocParser()
    example_docstring = '''
    This is a short description.

    This is a long description:
    * with a list
    * with a second item

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span multiple lines.
    other_params
        You can include other params.


    Attributes
    ----------
    some_property : str
        A property that exists.
    other_property : list
        Another property.



    Raises
    ------
    ValueError
        A description of what might raise ValueError
    Exception
        Raising other kinds of exceptions
    """
    '''

    assert numpydoc_parser.parse(example_docstring)


# Generated at 2022-06-23 17:11:30.717616
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:11:33.133576
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections == DEFAULT_SECTIONS



# Generated at 2022-06-23 17:11:37.512417
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = "Deprecated since version 0.0.1:\nasdf\n"
    factory = DeprecationSection("Deprecation Warning", "deprecation")

# Generated at 2022-06-23 17:11:39.434699
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    s = NumpydocParser()
    assert(s.parse("") == Docstring())

# Generated at 2022-06-23 17:11:49.765598
# Unit test for constructor of class ParamSection
def test_ParamSection():
    from inspect import cleandoc

    s = ParamSection("Parameters", "param")
    meta = s.parse(cleandoc("""
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """))

    i = iter(meta)

    m = next(i)
    assert m.args == ['param', 'arg_name']
    assert m.description == 'arg_description'
    assert m.is_optional is False
    assert m.arg_name == 'arg_name'
    assert m.type_name is None
    assert m.default is None

    m = next(i)
    assert m.args == ['param', 'arg_2']
    assert m.description == 'descriptions can also span...\n... multiple lines'

# Generated at 2022-06-23 17:11:58.973590
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # Valid title
    a = ParamSection(title="Parameters", key="param")
    # Invalid title
    b = ParamSection(title="Params", key="param")
    assert a.title == "Parameters" and b.title == "Params"
    assert a.key == "param" and b.key == "param"
    # Valid title pattern
    a_pattern = r"^(Parameters)\s*?\n\-\-\-\-\-\-\s*$"
    b_pattern = r"^(Params)\s*?\n\-\-\-\-\-\-\s*$"
    assert a.title_pattern == a_pattern
    assert b.title_pattern == b_pattern


# Generated at 2022-06-23 17:12:11.539474
# Unit test for method parse of class DeprecationSection

# Generated at 2022-06-23 17:12:17.897391
# Unit test for constructor of class ParamSection
def test_ParamSection():
    """Test constructor of class ParamSection.
    """
    param_section = ParamSection("Parameters", "param")
    assert param_section.title == "Parameters"
    assert param_section.key == "param"
    assert param_section.title_pattern == r"^(Parameters)\s*?\n-*\s*$"


# Generated at 2022-06-23 17:12:21.819002
# Unit test for constructor of class _KVSection
def test__KVSection():
    section = _KVSection("Parameters", "param")
    expected_title = "Parameters"
    expected_key = "param"
    assert section.title == expected_title
    assert section.key == expected_key


# Generated at 2022-06-23 17:12:30.110241
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raise_param = ["Raises", "ValueError"]
    raise_desc = "A description of what might raise ValueError"
    raise_type = "ValueError"
    raise_test_object = RaisesSection(raise_param[0], raise_param[1])
    raise_test_object._parse_item(raise_param[1],raise_desc)
    assert(raise_test_object.args == raise_param)
    assert(raise_test_object.description == raise_desc)
    assert(raise_test_object.type_name == raise_type)


# Generated at 2022-06-23 17:12:33.941860
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    parser = RaisesSection("Raise", "raises")
    s = parser.parse("Exception\nHappen when divisor is zero")
    assert next(s).description == "Happen when divisor is zero"


# Generated at 2022-06-23 17:12:43.227665
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = inspect.cleandoc(
        """
        .. deprecated:: 1.7.3
            Arguments ``axis``, ``keepdim`` and ``inplace`` deprecated.
    """
    )
    sections = [DeprecationSection("deprecated", "deprecated")]
    assert [item.description for item in
            sections[0].parse(text)] == ["Arguments ``axis``, ``keepdim`` and ``inplace`` deprecated."]
    assert sections[0].parse(text)[0].version == "1.7.3"


# Generated at 2022-06-23 17:12:49.411930
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    parser = NumpydocParser()
    parser.add_section(DeprecationSection("Deprecated", "deprecated"))
    a = parser.parse(".. deprecated:: 2.12.0\n\n  This module is..")
    assert(a.meta[0].type_name == "deprecated")
    assert(a.meta[0].version == "2.12.0")
    assert(a.meta[0].description == "This module is..")


# Generated at 2022-06-23 17:12:59.921415
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-23 17:13:09.416876
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    test_text = "Anything before first title\n" + \
                "Custom Title\n" + \
                "==========\n" + \
                "key1\n" + \
                "    value of key 1\n" + \
                "key2\n" + \
                "    value of key 2\n" + \
                "key3: type\n" + \
                "    value of key 3\n"
    np = NumpydocParser()
    np.add_section(Section("Custom Title", "cust"))
    d = np.parse(test_text)
    m = d.meta
    assert len(m) == 3
    assert m[0].key == "cust"
    assert m[1].key == "cust"
    assert m[2].key == "cust"


# Generated at 2022-06-23 17:13:18.505248
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Arrange
    text = inspect.cleandoc('''
    key1
        value1
    key2 : type1
        value2
    key3 : type2
        value3
    ''')
    expected_ret = inspect.cleandoc('''
    key1
        value1
    key2 : type1
        value2
    key3 : type2
        value3
    ''')
    # Act
    ret = text
    # Assert
    assert ret == expected_ret

# Generated at 2022-06-23 17:13:22.085344
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    a = RaisesSection("Raises","raises")
    assert a.title=="Raises"
    assert a.key=="raises"
    assert a.title_pattern=="^Raises\\s*?\n{1}$"


# Generated at 2022-06-23 17:13:29.170320
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    p = ParamSection(title="Parameters", key="param")
    text = """def foo(bar):
        Parameters
        ----------
        bar1
            bar1 description
        bar2 : str, optional
            bar2 description
        """
    text = inspect.cleandoc(text)
    result = ""
    sections = p.parse(text)
    for section in sections:
        result += section.args[0] + ", " + section.args[1] + ", " + section.description + "\n"
    expected = "other_param, bar1, bar1 description\nother_param, bar2, bar2 description\n"
    assert result == expected, result

# Generated at 2022-06-23 17:13:31.934279
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section('TestSection', 'test'))
    # The number of sections should increase
    assert len(parser.sections) == 1
    # The custom section should be found
    assert parser.sections['TestSection'].title == 'TestSection'


# Generated at 2022-06-23 17:13:34.540769
# Unit test for constructor of class Section
def test_Section():
    s = Section("region", "param")
    assert (s.title == "region") & (s.key == "param")


# Generated at 2022-06-23 17:13:36.099308
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection ("Yields","yields")

# Generated at 2022-06-23 17:13:41.793019
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    parser = YieldsSection("Yields", "yields")
    text = "Something of type ``boo``.\n"
    expected = DocstringReturns(
        args=["yields"],
        description=_clean_str(text),
        type_name="``boo``",
        is_generator=True,
        return_name=None,
    )
    ret = list(parser.parse(text))[0]
    assert ret == expected

# Generated at 2022-06-23 17:13:47.285551
# Unit test for constructor of class Section
def test_Section():
    title = "abcd"
    key = "abcd"
    s = Section(title,key)
    assert s.title == title
    assert s.key == key
    assert s.title_pattern == r"^(abcd)\s*?\n-{4}\s*$"


# Generated at 2022-06-23 17:13:54.909960
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    dep = DeprecationSection("deprecation", "deprecation")
    assert dep.parse("1.2.3\n because it is.") == [DocstringDeprecated(args=['deprecation'], description='because it is.', version='1.2.3')]
    assert dep.parse("some string") == [DocstringDeprecated(args=['deprecation'], description=None, version='some string')]


if __name__ == "__main__":
    import pytest

    pytest.main(["-v", __file__])

# Generated at 2022-06-23 17:14:05.414141
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # expected result
    expected = [DocstringMeta(args=['param', 'arg_name'], description='arg_description'),
                DocstringMeta(args=['param', 'arg_2'], description='descriptions can also span...\n... multiple lines')]
    # actual result
    test__KVSection = ParamSection("Parameters", "param")
    actual = test__KVSection.parse("arg_name\narg_description\n\narg_2 : type, optional\ndescriptions can also span...\n... multiple lines")
    for i, j in zip(expected, actual):
        assert(i.args == j.args)
        assert(i.description == j.description)
    pass


# Generated at 2022-06-23 17:14:09.301935
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    parser.add_section(Section("hello", "hello"))
    doc = parser.parse("hello")

    assert len(doc.meta) == 1
    assert doc.meta[0].args == ["hello"]
    assert doc.meta[0].description is None


# Generated at 2022-06-23 17:14:10.519852
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    import doctest
    doctest.testmod()


# Generated at 2022-06-23 17:14:14.265777
# Unit test for constructor of class _KVSection
def test__KVSection():
    text = "arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines"
    try:
        _KVSection("Parameters", "param").parse(text)
        raise AssertionError("_KVSection.parse() should raise NotImplementedError, but it does not")
    except NotImplementedError:
        pass
    finally:
        pass


# Generated at 2022-06-23 17:14:16.365802
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section = ParamSection("Other Parameters", "other_param")
    text = "key\n    value\nkey2 : type\n    values can also span...\n    ... multiple lines"
    items = section.parse(text)
    assert(next(items).arg_name == "key")



# Generated at 2022-06-23 17:14:20.657452
# Unit test for method parse of class Section
def test_Section_parse():
    text = "a\nb\nc"
    assert Section("a", "b").parse(text)[0].args == ["b"]
    assert Section("a", "b").parse(text)[0].description == "b\nc"


# Generated at 2022-06-23 17:14:26.765916
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "title"
    key = "key"
    section = _SphinxSection(title, key)
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == r"^\.\.\s*title\s*::"
    with pytest.raises(NotImplementedError):
        section.parse("")


# Generated at 2022-06-23 17:14:29.944682
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    code = ''
    expected = [DocstringDeprecated(['deprecation'], description=None, version='0.1.1')]
    section = DeprecationSection('deprecated', 'deprecation')
    doc = section.parse(code)
    assert list(doc) == expected



# Generated at 2022-06-23 17:14:38.960976
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    
    class Test:
        def __init__(self):
            self.text = ".. deprecated:: 2.5 \n   Use the function instead."
    
    obj = Test()
    obj.docstring = NumpydocParser().parse(obj.text)
    
    assert obj.docstring.meta[0].args[0] == "deprecation"
    assert obj.docstring.meta[0].args[1] == None
    assert obj.docstring.meta[0].description == "Use the function instead."
    assert obj.docstring.meta[0].version == "2.5"



# Generated at 2022-06-23 17:14:42.543277
# Unit test for constructor of class Section
def test_Section():
    title = "title"
    key = "key"
    section = Section(title,key)
    assert section.title == title
    assert section.key == key



# Generated at 2022-06-23 17:14:50.363441
# Unit test for function parse
def test_parse():
    """Test docstring parsing."""
    lines = [
        'Add two numbers.',
        '',
        '    Example:',
        '',
        '    >>> add(2, 3)',
        '    5',
        '    >>> add(100, 200)',
        '    300',
        '',
        'Args:',
        '    a: first value',
        '    b: second value',
        '',
        'Returns:',
        '    Sum of the two values.',
    ]
    doc = parse("\n".join(lines))
    assert doc.short_description == "Add two numbers."
    assert doc.blank_after_short_description
    assert doc.long_description == 'Example:\n\n>>> add(2, 3)\n5\n>>> add(100, 200)\n300'

# Generated at 2022-06-23 17:14:50.919546
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection



# Generated at 2022-06-23 17:15:00.809539
# Unit test for function parse

# Generated at 2022-06-23 17:15:06.025586
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    # Test the creation of NumpydocParser using the default section list
    parser = NumpydocParser()
    assert len(DEFAULT_SECTIONS) == len(parser.sections)
    assert all(section.title in DEFAULT_SECTIONS for section in parser.sections)
    # Test the creation of NumpydocParser using a non-default section list
    # The non-default section list is a subset of the default section list
    parser = NumpydocParser(DEFAULT_SECTIONS[:4])
    assert len(DEFAULT_SECTIONS[:4]) == len(parser.sections)
    assert all(section.title in DEFAULT_SECTIONS[:4] for section in parser.sections)

# Generated at 2022-06-23 17:15:10.233131
# Unit test for constructor of class _KVSection
def test__KVSection():
    dummy_section = _KVSection("title", "key")
    print(inspect.cleandoc(dummy_section.title))
    print(inspect.cleandoc(dummy_section.key))


# Generated at 2022-06-23 17:15:12.987540
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("yields", "yields")
    assert ys.is_generator == True

test_YieldsSection()

# Generated at 2022-06-23 17:15:22.396655
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert_string = NumpydocParser(sections=DEFAULT_SECTIONS)
    with open("./test/test_documentation.txt", "r") as test_docstring_file:
        test_docstring = test_docstring_file.read()
    parsed_docstring = assert_string.parse(test_docstring)
    assert_string.add_section(Section("Hello", "says"))
    assert_string.add_section(Section("Hello", "says"))
    assert_string.add_section(Section("World", "says"))
    parsed_docstring = assert_string.parse(test_docstring)




# Generated at 2022-06-23 17:15:26.362363
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns").key == "returns"
    assert ReturnsSection("returns", "returns").title == "Returns"
    assert ReturnsSection("Returns", "returns").title_pattern == "^Returns\\s*?\\n={2,}\\s*$"
    assert ReturnsSection("Returns", "returns").description == "ReturnsSection(_KVSection)"

# Generated at 2022-06-23 17:15:32.034424
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "title"
    key = "key"
    section = _SphinxSection(title, key)
    assert section.title == title
    assert section.title_pattern == "^\.\.\s*(title)\s*::"
    assert section.key == key


# Generated at 2022-06-23 17:15:36.151304
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
	
	assert ReturnsSection("Returns", "returns").title == "Returns"
	assert ReturnsSection("Returns", "returns").key == "returns"
	assert ReturnsSection("Returns", "returns").is_generator == False



# Generated at 2022-06-23 17:15:46.199757
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    
    parser = NumpydocParser()
    assert parser.sections['Parameters']
    assert parser.sections['Param']
    assert parser.sections['Params']
    assert parser.sections['Arguments']
    assert parser.sections['Args']
    assert parser.sections['Other Parameters']
    assert parser.sections['Other Params']
    assert parser.sections['Other Arguments']
    assert parser.sections['Other Args']
    assert parser.sections['Receives']
    assert parser.sections['Receive']
    assert parser.sections['Raises']
    assert parser.sections['Raise']
    assert parser.sections['Warns']
    assert parser.sections['Warn']
    assert parser.sections['Attributes']
    assert parser.sections['Attribute']
    assert parser.sections['Returns']
    assert parser.sections['Return']

# Generated at 2022-06-23 17:15:59.273264
# Unit test for constructor of class ParamSection
def test_ParamSection():
    section_name = "Parameters"
    section_key = "param"

    section_class_instance = ParamSection(section_name, section_key)

    expected = section_name
    actual = section_class_instance.title

    assert actual == expected

    expected = section_key
    actual = section_class_instance.key

    assert actual == expected

    expected = r"^(Parameters)\s*?\n{}\s*$".format(len(section_name) * "-")
    actual = section_class_instance.title_pattern

    assert actual == expected

    text = inspect.cleandoc(
        """
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines"""
    )
