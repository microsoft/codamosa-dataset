

# Generated at 2022-06-23 17:05:58.369065
# Unit test for method parse of class Section
def test_Section_parse():
    """ Unit test for method parse of class Section. """
    section=Section('Parameters', 'param')
    text = '''Parameters
    ----------
    arg1 : str
       A description of arg1'''
    docstring_meta = section.parse(text)
    assert docstring_meta == [DocstringMeta([section.key], description=_clean_str(text))]


# Generated at 2022-06-23 17:06:06.691732
# Unit test for constructor of class _KVSection
def test__KVSection():
    text = "key\n    value\nkey2 : type\n    values can also span...\n    ... multiple lines"
    text = inspect.cleandoc(text)
    factory = _KVSection("section", "key")
    assert factory.title_pattern == "^(section)\\s*?\\n-{8}\\s*$"
    ret = factory.parse(text)
    assert len(ret) == 2
    assert ret[0].args == ["key", "key"]
    assert ret[1].args == ["key", "key2"]


# Generated at 2022-06-23 17:06:09.878167
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # testing if the class's function parse is returning the correct result
    # for the input argument "text" as ""
    # create an instance of class RaisesSection
    # expecting this object to have attribute "key" equal to "raises", title equal to "Raises"
    test_object = RaisesSection("Raises", "raises")
    result = test_object.parse("")
    assert list(result) == []



# Generated at 2022-06-23 17:06:18.852633
# Unit test for constructor of class _KVSection
def test__KVSection():
    text = 'arg_name\n    arg_description\narg_2 : type, optional\n    descriptions can also span...\n    ... multiple lines'
    section = _KVSection(title="Parameters", key="param")
    assert section.parse(text) == [
        DocstringParam(args=['param', 'arg_name'], description='arg_description', arg_name='arg_name', type_name=None, is_optional=False, default=None),
        DocstringParam(args=['param', 'arg_2'], description='descriptions can also span...\n... multiple lines', arg_name='arg_2', type_name='type', is_optional=True, default=None)
    ]

# Generated at 2022-06-23 17:06:29.041814
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection(title="Returns", key="returns").title == "Returns"
    assert ReturnsSection(title="Returns", key="returns").key == "returns"
    assert ReturnsSection(title="Returns", key="returns").title_pattern == r"^Returns\s*?\n={3}\s*$"
    assert ReturnsSection(title="Returns", key="returns").__doc__ == "Parser for numpydoc raises sections.\n\nE.g. any section that looks like this:\n    return_name : type\n        A description of this returned value\n    another_type\n        Return names are optional, types are required"


# Generated at 2022-06-23 17:06:30.713736
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    rs = ReturnsSection("Returns","returns")
    assert rs.is_generator == False

if __name__ == "__main__":
    test_ReturnsSection()

# Generated at 2022-06-23 17:06:39.389018
# Unit test for method parse of class Section
def test_Section_parse():
    test_string = '''
    Parameters
    ----------
        a : int
            This is the description of param a
        
        b : str
            This is the description of param b

    Raises
    ------
        ValueError
            This is the description of what might raise ValueError

    Returns
    -------
        This is the description of the return type

    '''
    section = Section('Parameters', 'param')
    print(section.parse(test_string))

# Generated at 2022-06-23 17:06:42.593430
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = "since 1.0\nThis is the description"
    factory = DeprecationSection("deprecated", "deprecation")
    assert factory.parse(text) == DocstringDeprecated(
        args=["deprecation"],
        description="This is the description",
        version="since 1.0",
    )

# Generated at 2022-06-23 17:06:47.609048
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    text = """
    a : int
        This is the description
    
    a2
        This is the description 2
    """
    ret = NumpydocParser(sections=([ReturnsSection("Returns", "returns")])).parse(text)
    title = ret.meta[0].args[1]
    typeName = ret.meta[0].type_name
    returnName = ret.meta[0].return_name
    assert(title == "a")
    assert(typeName == "int")
    assert(returnName == None)
    title = ret.meta[1].args[1]
    typeName = ret.meta[1].type_name
    returnName = ret.meta[1].return_name
    assert(title == "a2")
    assert(typeName == "None")

# Generated at 2022-06-23 17:06:52.418555
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    print('Testing numpydoc.RaisesSection')
    text = """
Raises:
    PermissionError: when a user doesn't have proper credentials
    """
    _KVSection(title="Raises", key="raises").parse(text)

if __name__ == '__main__':
    test_RaisesSection()

# Generated at 2022-06-23 17:06:56.730403
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert(RaisesSection.__bases__[0] == _KVSection)
    assert(RaisesSection.__bases__[1] == Section)
    assert(RaisesSection.__init__.__annotations__['title'] == str)
    assert(RaisesSection.__init__.__annotations__['key'] == str)

# Generated at 2022-06-23 17:07:06.281843
# Unit test for function parse
def test_parse():
    all_doc = inspect.getdoc(parse)
    assert(all_doc['short_description'] == 'Parse the numpy-style docstring into its components.')
    assert(len(all_doc['meta']) == 1)
    assert(all_doc['meta'][0]['args'] == ['returns'])
    assert(all_doc['meta'][0]['description'] is not None)
    assert(all_doc['long_description'] is not None)
    assert(all_doc['blank_after_long_description'] is True)
    assert(all_doc['blank_after_short_description'] is False)


# Generated at 2022-06-23 17:07:10.491227
# Unit test for method parse of class Section
def test_Section_parse():
    """Unit test for method parse of class Section"""
    from tests.test_extract import _test_docstring

    text = """
    .. title:: test section
        Test section description
    """

    assert _test_docstring(text) == {'examples': [{'description': 'Test section description', 'args': ['examples']}]}


# Generated at 2022-06-23 17:07:12.290624
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert(YieldsSection("Yields", "yields"))

test_YieldsSection()

# Generated at 2022-06-23 17:07:12.850609
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    YieldsSection()

# Generated at 2022-06-23 17:07:24.231683
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    test_section = ReturnsSection("Returns", "returns")
    assert test_section.key == "returns"
    assert test_section.title == "Returns"
    assert test_section._parse_item("", "") == DocstringReturns(args=['returns'], description=None, type_name=None, is_generator=False, return_name=None)
    assert test_section._parse_item("return_name : type", "description") == DocstringReturns(args=['returns'], description='description', type_name='type', is_generator=False, return_name='return_name')

# Generated at 2022-06-23 17:07:33.200704
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Setup
    DEPRECATED_SECTION = DeprecationSection("Deprecation", "deprecation")
    text = "deprecated\n"\
           "    deprecated section\n"\
           "    warning\n"\
           "    version 0.1\n"

    # Act
    result = DEPRECATED_SECTION.parse(text)

    # Assert
    assert list(result) == [
        DocstringDeprecated(
            args=["deprecation"],
            version="version 0.1",
            description="deprecated section\nwarning",
        )
    ]



# Generated at 2022-06-23 17:07:35.361319
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection
    assert DeprecationSection.title == DeprecationSection.title
    assert DeprecationSection.key == DeprecationSection.key


# Generated at 2022-06-23 17:07:38.924208
# Unit test for method parse of class Section
def test_Section_parse():
    sections = NumpydocParser()
    docstring = sections.parse(__doc__)
    assert docstring.long_description is not None
    assert docstring.short_description is None

# Generated at 2022-06-23 17:07:47.840205
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # Initialize NumpydocParser with no arguments
    parser = NumpydocParser()

    # Add a custom section
    title = "Custom Section"
    key = "custom"
    custom_section = Section(title, key)
    parser.add_section(custom_section)

    # Add another custom section
    title = "Custom Section 2"
    key = "custom2"
    custom_section2 = Section(title, key)
    parser.add_section(custom_section2)

    # Update an existing section
    title = "Parameters"
    key = "param2"
    param_section2 = Section(title, key)
    parser.add_section(param_section2)

    # Check all sections are present
    assert parser.sections.keys() == {"Parameters", "Custom Section", "Custom Section 2"}

# Generated at 2022-06-23 17:07:51.632560
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    d = DeprecationSection("deprecated", "some key")
    assert d.title == "deprecated"
    assert d.key == "some key"



# Generated at 2022-06-23 17:07:56.528601
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section1 = ReturnsSection('Returns', 'returns')
    ret = section1.parse('return_name : type\n'
                         '    A description of this returned value\n'
                         'another_type\n'
                         '    Return names are optional, types are required')
    assert ret


# Generated at 2022-06-23 17:08:05.131471
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yields_section = YieldsSection("Yields", "yields").parse("return_name : type\n    A description of this returned value\nanother_type\n    Return names are optional, types are required")
    return_name, type_name = yields_section[0].return_name, yields_section[0].type_name
    if return_name is not None:
        assert return_name == 'return_name'
    else:
        assert return_name is None
    if type_name is not None:
        assert type_name == 'type'
    else:
        assert type_name is None

# Generated at 2022-06-23 17:08:06.648157
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    a = DeprecationSection("deprecation", "deprecated")

# Generated at 2022-06-23 17:08:16.470686
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text = "Raises\n"+"-"*len("Raises")+"\n"+"ValueError"+"\n"+" "*8+"A description of what might raise ValueError"
    text = inspect.cleandoc(text)
    section =  RaisesSection("Raises", "raises")
    ret = section.parse(text)
    # iterables can't be directly used in assert statement
    ret1 = list(ret)[0]
    assert ret1.args == ["raises", "ValueError"]
    assert ret1.description == "A description of what might raise ValueError"
    assert ret1.type_name == "ValueError"


# Generated at 2022-06-23 17:08:29.745415
# Unit test for function parse
def test_parse():
    from pprint import pprint
    from .common import DocstringParam, DocstringRaises, DocstringReturns
    from .common import DocstringAttribute, DocstringDeprecated
    from .common import DocstringMeta


# Generated at 2022-06-23 17:08:41.429496
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = inspect.cleandoc("""
        Test function.

        Add two numbers together.

        Parameters
        ----------
        a : int
            The first number.
        b : int
            The second number.

        Returns
        -------
        c : int
            The sum of `a` and `b`.

        Raises
        ------
        OverflowError
            If the result is too large.
    """)
    res = parse(docstring)
    assert res.short_description=="Test function."
    assert res.long_description=="Add two numbers together."
    assert res.blank_after_short_description==True
    assert res.blank_after_long_description==False
    assert res.meta[0].args[0]=="param"
    assert res.meta[0].args[1]=="a"

# Generated at 2022-06-23 17:08:46.152413
# Unit test for method parse of class Section
def test_Section_parse():
    from docstring_parser.common import DocstringMeta
    from docstring_parser.parser.numpydoc import Section
    text = '''Deprecated since version 1.7.0: Use ``series2`` instead.
Note: This is no longer supported starting from version 2.0.0.
'''
    s = Section("Deprecation warning", "deprecation")
    r = s.parse(text)
    assert r == [DocstringMeta(['deprecation'], 'Use ``series2`` instead.')]



# Generated at 2022-06-23 17:08:56.391845
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section_text_1 = ('a' + '\n' + '    b' + '\n' + 'c' + '\n' + '    d')
    section_text_2 = ('e' + '\n' + 'f' + '\n' + '    g' + '\n' + 'h' + '\n' + '    i')
    section_text = section_text_1 + '\n' + section_text_2
    kv_regex = re.compile(r"^[^\s].*$", flags=re.M)
    def _parse_item(self, key: str, value: str) -> DocstringMeta:
        return DocstringMeta(['key',key], description=value)

# Generated at 2022-06-23 17:09:08.753536
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Setup
    title = 'title'
    key = 'key'
    text = 'text'
    my_var = _KVSection(title, key)
    paramKey = 'paramKey'
    value = 'value'
    my_var.parse(paramKey + "\n    " + value)
    # Check the instance variables
    assert(my_var.title == title)
    assert(my_var.key == key)
    assert(my_var._KVSection__kvRegex.match(paramKey + "\n    " + value))
    assert(my_var._KVSection__kvRegex.match(paramKey + "\n        " + value))
    assert(my_var._KVSection__kvRegex.match(paramKey + "    " + value) is None)

# Generated at 2022-06-23 17:09:13.683116
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    text = """
    """
    parser = NumpydocParser()
    assert parser.sections == DEFAULT_SECTIONS
    assert parser.parse(text) == parse(text)


# Generated at 2022-06-23 17:09:25.287098
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    from .common import DocstringMeta
    from .numpydoc import NumpydocParser, DeprecationSection, Section
    parser = NumpydocParser()
    parser.add_section(Section("Sections", "Sections"))
    parser.add_section(DeprecationSection("Deprecation","Deprecation"))
    assert parser.sections == {'Sections': Section("Sections", "Sections"),
                               'Deprecated': DeprecationSection("Deprecated", "Deprecation")}

# Generated at 2022-06-23 17:09:37.470212
# Unit test for method parse of class Section
def test_Section_parse():

    s = Section("Parameters", "param")
    assert "^Parameters\s*?\n---+\s*$" == s.title_pattern
    assert "param" == s.key

    text = """
    Parameters
    ----------
    arg_name
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines"""

    section = ParamSection("Parameters", "param")
    actual = list(section.parse(text))

# Generated at 2022-06-23 17:09:39.699307
# Unit test for constructor of class Section
def test_Section():
    title = "abc"
    key = "def"
    section = Section(title=title, key=key)
    assert section.title == title
    assert section.key == key

# Generated at 2022-06-23 17:09:47.786886
# Unit test for function parse
def test_parse():
    test_text = """Calculate the length of a sample.

    Calculates the length of a sample.  This function is only intended to
    operate on 1D samples.
    If the sample is not enclosed in an iterable object, it is first converted
    to a tuple.

    Parameters
    ----------
    sample : iterable of numbers
        A sample consisting of N items
    """
    assert parse(test_text).short_description == 'Calculate the length of a sample.'


# Generated at 2022-06-23 17:09:50.919692
# Unit test for method parse of class Section
def test_Section_parse():
    assert Section('Parameters', 'param').parse('x\n    Description of x') == [DocstringMeta(['param'], description='Description of x')]


# Generated at 2022-06-23 17:10:00.422979
# Unit test for function parse
def test_parse():
    text1 = """This is a short description.

    Properties created with the ``property`` builtin are special descriptors.
    If you define new properties in a class, they are automatically converted
    to property objects. If you define them outside of a class, they are just
    data descriptors. See the example below.

    Parameters
    ----------
    arg1: int
        Description of arg1
    arg2: str
        Description of arg2
    arg3: bool, optional
        Description of arg3 (default True)

    Returns
    -------
    int
        Description of return value
    """

    ds = parse(text1)
    assert ds.short_description == "This is a short description."
    assert ds.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-23 17:10:01.616505
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yields = YieldsSection("Yields", "yields")
    assert yields.is_generator == True


# Generated at 2022-06-23 17:10:05.589775
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecation")
    assert section.parse("deprecation\n    v1.2.3") == [DocstringDeprecated(args=["deprecated"], description=None, version="v1.2.3")]


# Generated at 2022-06-23 17:10:09.790038
# Unit test for constructor of class Section
def test_Section():
    section=Section("hello","world")
    actual=section.title_pattern
    expected= r"^(hello)\s*?\n{}\s*$".format("-" * len("hello"))
    assert actual==expected
    actual=section.parse("hi")
    expected=[DocstringMeta(["world"], description="hi")]
    assert list(actual)==expected

# Generated at 2022-06-23 17:10:14.124490
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    sec = _SphinxSection("Section", "KEY")
    assert sec.title == "Section"
    assert sec.key == "KEY"
    assert sec.title_pattern == r"^\.\.\s*(Section)\s*::"

# Generated at 2022-06-23 17:10:21.188281
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    test_section = ParamSection("", "")
    test_text = """
        abc
            123
        456
            789
        xyz
            123
    """
    def _parse_item(key, value):
        return key + ":" + value
    test_section._parse_item = _parse_item
    test_list = [x for x in test_section.parse(test_text)]
    assert test_list == ["abc:123", "456:789", "xyz:123"]



# Generated at 2022-06-23 17:10:32.757659
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kvs = _KVSection("test1","test2")

    text = """
    param1
        a parameter with a long
        description
    param2 : type, optional
        another parameter

    """

    params = kvs.parse(text)
    param = next(params)

    assert param.args == ['test2', 'param1']
    assert param.description == "a parameter with a long description"
    assert param.arg_name == 'param1'
    assert param.type_name is None
    assert param.is_optional is False
    assert param.default is None

    param = next(params)

    assert param.args == ['test2', 'param2']
    assert param.description == "another parameter"
    assert param.arg_name == 'param2'
    assert param.type_name == 'type'


# Generated at 2022-06-23 17:10:33.749102
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection('Return', 'returns')

# Generated at 2022-06-23 17:10:36.876408
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    rs = ReturnsSection("Returns", "returns")
    return rs


if __name__ == "__main__":
    rs = test_ReturnsSection()

# Generated at 2022-06-23 17:10:49.344568
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """\
    key
    value

    key2 : type
        values can also span...
        ... multiple lines"""

    sections = [Section("sectiontitle", "sectionkey")]
    s = _KVSection(title="sectiontitle", key="sectionkey")
    sections[0] = s

    parser = NumpydocParser(sections)

    parsed = parser.parse(text)

    assert parsed.short_description is None
    assert parsed.long_description is None
    assert parsed.blank_after_short_description is False
    assert parsed.blank_after_long_description is False
    assert len(parsed.meta) == 2

    # key
    assert parsed.meta[0].args[0] == "sectionkey"
    assert parsed.meta[0].args[1] == "key"

# Generated at 2022-06-23 17:10:59.183352
# Unit test for function parse

# Generated at 2022-06-23 17:11:11.837644
# Unit test for function parse
def test_parse():
    """
    Test the numpydoc parsing.
    """
    first_docstring = """
    Just a test function.

    Parameters
    ----------
    *args :
        Variable length argument list.
    **kwargs :
        Arbitrary keyword arguments.
    a : int
        An integer argument.
    b : {'foo', 'bar', 'baz'}, optional
        Another optional argument.

    Returns
    -------
    str
        A string.
    """

    parsed_docstring = parse(first_docstring)
    assert parsed_docstring.short_description == 'Just a test function.'
    assert parsed_docstring.meta[0].args == ['param', 'args']
    assert parsed_docstring.meta[0].description == (
        'Variable length argument list.'
    )

# Generated at 2022-06-23 17:11:20.555353
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    a = RaisesSection("Raise", "raises")
    b = a.parse("Some description")
    assert b.args == ["raises", "Some description"]
    assert b.description == "Some description"
    assert b.type_name == "Some description"

    b = a.parse("Some description with : colon")
    assert b.args == ["raises", "Some description with : colon"]
    assert b.description == "Some description with : colon"
    assert b.type_name == "Some description with : colon"

    b = a.parse("")
    assert b.args == ["raises", ""]
    assert b.description == None
    assert b.type_name == ""


# Generated at 2022-06-23 17:11:27.096303
# Unit test for function parse
def test_parse():
    text = """
    The short description goes here.

    The long description goes here.
    It can span multiple lines.

    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str, optional
        The second parameter.
    param3 : str
        The third parameter.

    Returns
    -------
    str
        The return value.
    """

    ret = parse(text)
    assert ret.short_description == "The short description goes here."
    assert ret.long_description == "The long description goes here.\nIt can span multiple lines."
    assert ret.blank_after_long_description == False
    assert ret.blank_after_short_description == True
    assert len(ret.meta) == 3
    assert isinstance(ret.meta[0], DocstringParam)

# Generated at 2022-06-23 17:11:36.158833
# Unit test for function parse
def test_parse():
    docstring = r"""The value to set the field to.

    .. deprecated:: 1.5
        Use :attr:`fieldvalue` instead.
    """

    expected = Docstring(
        short_description="The value to set the field to.",
        meta=[
            DocstringDeprecated(
                args=["deprecation"],
                version="1.5",
                description="Use :attr:`fieldvalue` instead.",
            )
        ]
    )
    result = parse(docstring)
    assert result == expected, "Did not parse docstring correctly"


# Generated at 2022-06-23 17:11:38.507718
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    return_value = _KVSection("Raises", "raises")
    assert return_value is not None


# Generated at 2022-06-23 17:11:44.456963
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()

    # Test a section that is not present
    parser.add_section(DeprecationSection("test title", "test key"))
    assert len(parser.titles_re.findall(parser.titles_re.pattern)) == len(
        DEFAULT_SECTIONS
    ) + 1

    # Test a section that is already present
    parser.add_section(RaisesSection("Raises", "raises"))
    assert len(parser.titles_re.findall(parser.titles_re.pattern)) == len(
        DEFAULT_SECTIONS
    )

# Generated at 2022-06-23 17:11:56.825792
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test_string = """
    Parameters
    ----------
    a : type
        a description

    b : type
        b description

    Returns
        ------
    c : type
        c description

    Raises
    ------
    d : type
        d description

    Attributes
    ----------
    e : type
        e description
    """

    result = NumpydocParser().parse(test_string)

    assert (dict(result.meta[0])) == {
        "args": ["param", "a"],
        "description": "a description",
        "type_name": "type",
    }

    assert (dict(result.meta[1])) == {
        "args": ["param", "b"],
        "description": "b description",
        "type_name": "type",
    }


# Generated at 2022-06-23 17:12:01.229074
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yields = YieldsSection('Yields', 'yields')
    assert yields.is_generator == True
    assert yields.key == 'yields'
    assert yields.title == 'Yields'

# Generated at 2022-06-23 17:12:04.685140
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param_section_obj = ParamSection(title='Params', key='param')
    assert param_section_obj.title == 'Params'
    assert param_section_obj.key == 'param'


# Generated at 2022-06-23 17:12:14.629511
# Unit test for function parse

# Generated at 2022-06-23 17:12:25.980774
# Unit test for method parse of class Section
def test_Section_parse():
    parser = Section("Parameters", "param")
    result = parser.parse("""
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines""")
    test_list = [DocstringParam(['param', 'arg_name'], 'arg_description', 'arg_name', None, False, None),
                 DocstringParam(['param', 'arg_2'], 'descriptions can also span... ... multiple lines', 'arg_2', 'type', True, None)]
    assert(str(result) == str(test_list))
    
    parser = ParamSection("Parameters", "param")
    result = parser.parse("""
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines""")

# Generated at 2022-06-23 17:12:33.532503
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    # No arguments
    with pytest.raises(TypeError):
        ReturnsSection()
    # Arguments must have right type
    with pytest.raises(TypeError):
        ReturnsSection("x")
    with pytest.raises(TypeError):
        ReturnsSection(1, "x")
    with pytest.raises(TypeError):
        ReturnsSection("x", 1)
    # Correct use
    ReturnsSection("x", "y").__class__


# Generated at 2022-06-23 17:12:46.025416
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    exp_docstring = Docstring()
    exp_docstring.short_description = "Short description."
    exp_docstring.long_description = "Long description."
    exp_docstring.blank_after_short_description = True
    exp_docstring.blank_after_long_description = False
    
    exp_docstring.meta = [DocstringMeta(["param"], description="arg_1 : str"), 
                          DocstringMeta(["param"], description="arg_2 : int")]
    
    docstring = parser.parse(text = '''Short description.

Long description.

Parameters
----------
arg_1 : str
    
arg_2 : int''')
    
    assert exp_docstring == docstring



# Generated at 2022-06-23 17:12:53.484721
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section = _KVSection("Returns", "returns")
    r = section._parse_item("return_name: type", "A description of this returned value")
    assert r.type_name == "type", "Type name is wrong"
    assert r.return_name == "return_name", "Return name is wrong"
    assert r.description == "A description of this returned value", "Description is wrong"



# Generated at 2022-06-23 17:12:57.742892
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection("Yields","yields")
    assert y.title == "Yields" and y.key == "yields"
    assert y.is_generator == True
    assert y.title_pattern == r"^\.\.\s*(Yields)\s*::"


# Generated at 2022-06-23 17:13:02.800348
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
        parámetro_1
            Descripción del parámetro
        parámetro_2 : tipo, optional
            Descripción del parámetro
    """

    assert len(list(RaisesSection("Raises", "raises").parse(text))) == 2


# Generated at 2022-06-23 17:13:12.723200
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text="""
    Args:
        A: B
        C:
            d
        (optional)
            e
        F, optional
            g
        (optional):
            h
    """
    parser = NumpydocParser()
    doc = parser.parse(text)
    assert doc.meta[0].__class__ == DocstringParam
    assert doc.meta[0].args == ['param', 'A']
    assert doc.meta[0].description == 'B'
    assert doc.meta[0].arg_name == 'A'
    assert doc.meta[0].type_name is None
    assert doc.meta[0].is_optional is None
    assert doc.meta[0].default is None

    assert doc.meta[1].__class__ == DocstringParam

# Generated at 2022-06-23 17:13:19.703947
# Unit test for constructor of class _KVSection
def test__KVSection():
    text = "This is test"
    KV = _KVSection("Parameters", "param")
    assert KV.title == "Parameters"
    assert KV.key == "param"
    assert KV.title_pattern == "^(Parameters)\s*?\n-*\s*$"
    assert KV.parse(text) == [DocstringMeta(['param'],
        description=None)]


# Generated at 2022-06-23 17:13:23.451775
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert DeprecationSection("Deprecated", "deprecated").parse("test") == [DocstringDeprecated(args=['deprecated'], description='test', version=None)]

# Generated at 2022-06-23 17:13:36.097821
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    a = RaisesSection("Raises")
    assert a.title == "Raises"
    assert a.key == "raises"
    assert a.title_pattern == "^Raises\\s*?\\n---*\\s*$"
    assert a._parse_item("ValueError", "some value").args == ["raises", "ValueError"]
    assert a._parse_item("ValueError", "some value").type_name == "ValueError"
    assert a._parse_item("ValueError", "some value").description == "some value"
    assert a._parse_item("ValueError", "some value").arg_name == None
    assert a._parse_item("ValueError", "some value").is_optional == None
    assert a._parse_item("ValueError", "some value").default == None
    assert a._parse_item

# Generated at 2022-06-23 17:13:36.838167
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    ReturnsSection("Returns", "returns")


# Generated at 2022-06-23 17:13:43.494928
# Unit test for constructor of class _KVSection
def test__KVSection():
    keywords = ['Parameters', 'Params', 'Arguments', 'Args', 'Other Parameters', 'Other Params', 'Other Arguments', 'Other Args', 'Receives', 'Receive', 'Raises', 'Raise', 'Warns', 'Warn', 'Attributes', 'Attribute', 'Returns', 'Return', 'Yields', 'Yield', 'Examples', 'Example', 'Warnings', 'Warning', 'See Also', 'Related', 'Notes', 'Note', 'References', 'Reference', 'Deprecated']
    for keyword in keywords:
        s = _KVSection(keyword, keyword)
        #print(s.title_pattern)


# Generated at 2022-06-23 17:13:44.709180
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    DeprecationSection("deprecated", "deprecation")

# Generated at 2022-06-23 17:13:48.004493
# Unit test for method parse of class Section
def test_Section_parse():
    str = "Parameters\n----------\n:param str: This is the first parameter\n:param is_generator: This is the second parameter"
    parsed_obj = parse(str)
    params = parsed_obj.meta[0].args
    is_generator = parsed_obj.meta[0].is_generator
    assert params[0] == 'param'
    assert params[1] == 'str'
    assert is_generator == 0


# Generated at 2022-06-23 17:13:52.368750
# Unit test for constructor of class _KVSection
def test__KVSection():
    Section_1 = _KVSection("a", "b")
    assert Section_1.title == "a"
    assert Section_1.key == "b"
    assert Section_1.title_pattern == r"^(\w+)\s*?\n-+\s*$"

# Generated at 2022-06-23 17:13:56.752777
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection("deprecated", "deprecation").parse("x.x \n yyy") == [DocstringDeprecated(args=['deprecation'], description='yyy', version='x.x')]

# Generated at 2022-06-23 17:14:07.534742
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    return_section = ReturnsSection("Returns", "returns")
    assert return_section.title == "Returns"
    assert return_section.key == "returns"
    assert return_section.is_generator == False
    assert return_section.title_pattern == r"^Returns\s*?\n=-+\s*$"
    
    assert return_section.parse("") == []
    assert return_section.parse("return_name : type")[0][0] == DocstringReturns(
            args=["returns"],
            description=None,
            type_name=None,
            is_generator=False,
            return_name=None,
        )
    

# Generated at 2022-06-23 17:14:13.347219
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param_section = ParamSection("Parameters", "param")
    assert param_section.title == "Parameters"
    assert param_section.key == "param"
    assert param_section.title_pattern == "^(Parameters)\s*?\n{}\s*$".format("-" * len("Parameters"))


# Generated at 2022-06-23 17:14:16.854553
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    section = Section("title", "key")
    parser = NumpydocParser()
    parser.add_section(section)
    assert section == parser.sections["title"]


# Generated at 2022-06-23 17:14:17.559095
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    pass

# Generated at 2022-06-23 17:14:22.497787
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yield_title = YieldsSection("Yields", "yields")
    assert(yield_title.title_pattern == "^\.\.\s*(Yields)\s*::")
    assert(yield_title.key == "yields")


# Generated at 2022-06-23 17:14:25.010952
# Unit test for constructor of class ParamSection
def test_ParamSection():
    section = ParamSection("Test", "test")
    assert (section.title == "Test")

# Generated at 2022-06-23 17:14:29.381031
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    _title = "title"
    _key = "key"
    _title_pattern = "^\.\.\s*(title)\s*::"

    _section = _SphinxSection(_title, _key)
    assert _section.title == _title
    assert _section.key == _key
    assert _section.title_pattern == _title_pattern

# Generated at 2022-06-23 17:14:32.514707
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert len(list(DeprecationSection("deprecated", "deprecation").parse("1.0\nDeprecated version"))) == 1
    assert len(list(DeprecationSection("deprecated", "deprecation").parse("Deprecated version"))) == 1



# Generated at 2022-06-23 17:14:34.913989
# Unit test for method parse of class Section
def test_Section_parse():
    test_section = Section('test_section', 'test_key')
    assert test_section.parse('test description') == [
        DocstringMeta(['test_key'], description='test description')
    ]


# Generated at 2022-06-23 17:14:36.154117
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert NumpydocParser()

# Generated at 2022-06-23 17:14:47.510221
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = NumpydocParser()
    title = "Deprecated"
    text = ".. deprecated:: 1.2.3\n\tA description of what is deprecated."
    sections = list(parser.titles_re.finditer(text))
    match = sections[0]
    nextmatch = None
    start = match.end()
    end = nextmatch.start() if nextmatch is not None else None
    dep_section = text[start:end]
    dep_section_chunk = DeprecationSection(title, "deprecated")
    dep_result = list(dep_section_chunk.parse(dep_section))
    dep_result_meta = dep_result[0]
    assert dep_result_meta.args == ["deprecated"]
    assert dep_result_meta.description == "A description of what is deprecated."

# Generated at 2022-06-23 17:14:57.105540
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    from .registry import REGISTRY

    text = inspect.cleandoc("""
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """)
    parser = NumpydocParser(sections=REGISTRY.numpydoc_sections)
    meta = parser.parse(text).meta
    assert meta[0].description == "value"
    assert len(meta) == 2
    assert meta[1].arg_name == "key2"
    assert meta[1].type_name == "type"
    assert meta[1].description == "values can also span...\n... multiple lines"

# Generated at 2022-06-23 17:15:03.408183
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = ".. deprecated:: 8.123"
    deprecated = DeprecationSection("deprecation", "deprecated")
    docstrings = list(deprecated.parse(text))
    assert len(docstrings) == 1
    assert docstrings[0].args[0] == "deprecated"
    assert docstrings[0].args[1] == "deprecation"
    assert docstrings[0].version == "8.123"


# Generated at 2022-06-23 17:15:04.341305
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    NumpydocParser()


# Generated at 2022-06-23 17:15:14.771238
# Unit test for method parse of class Section
def test_Section_parse():
    # Set test parameters
    title = 'Parameters'
    key = 'param'
    # Initialize the class
    tp = Section(title, key)
    # Run the tests
    assert tp.title == title
    assert tp.key == key
    assert tp.title_pattern == r'^Parameters\s*?\n\-\-\-*\s*$'
    with pytest.raises(NotImplementedError) as excinfo:
        with pytest.warns(None) as record:
            tp.parse('text')
    assert excinfo.type == NotImplementedError


# Generated at 2022-06-23 17:15:18.338084
# Unit test for constructor of class ParamSection
def test_ParamSection():
    section = ParamSection("Parameters", "param")
    assert section.title == "Parameters"
    assert section.key == "param"
    assert section.title_pattern == r"^Parameters\s*?\n-*$"


# Generated at 2022-06-23 17:15:28.027129
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    """
    A function to test the constructor of class NumpydocParser

    Returns:
        bool: return True if it gives the expected result, and False if not.
    """
    #-----Case 1: it should return a NumpydocParser object with default sections
    #-----Case 2: it should return a NumpydocParser object with given sections
    #-----Case 3: it should return a NumpydocParser object with given sections and overwrite existing ones if needed
    parser1 = NumpydocParser()
    parser2 = NumpydocParser(sections={"Raises": RaisesSection("Raises", "raises")})
    parser3 = NumpydocParser(sections={"Raises": RaisesSection("Raises", "raises"), "Returns": ReturnsSection("Returns", "returns")})

# Generated at 2022-06-23 17:15:32.826477
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    deprec = NumpydocParser().parse("""
    .. deprecated:: 1.0.0
        Use :func:`a`.
    """)

    deprec.meta[0].version
    deprec.meta[0].description

# Generated at 2022-06-23 17:15:43.297692
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    def _parse_item(key: str, value: str) -> DocstringMeta:
        return DocstringMeta([key], description=_clean_str(value))
    for match, next_match in _pairwise(KV_REGEX.finditer(text)):
        start = match.end()
        end = next_match.start() if next_match is not None else None
        value = text[start:end]
        if len(value) > 0:
            value = inspect.cleandoc(value)
        print(_parse_item(key=match.group(), value=value))


# Generated at 2022-06-23 17:15:53.029468
# Unit test for constructor of class Section
def test_Section():
  section = Section(title="General", key="general")
  assert section.title_pattern == r"^(General)\s*?\n\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\s*$"

# Generated at 2022-06-23 17:15:56.445170
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # instantiate one parameter
    _new_section = ParamSection("Parameters", "param")
    # check title
    assert _new_section.title == "Parameters"
    # check key
    assert _new_section.key == "param"