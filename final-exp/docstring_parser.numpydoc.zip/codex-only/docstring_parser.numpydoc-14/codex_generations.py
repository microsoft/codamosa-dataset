

# Generated at 2022-06-23 17:05:59.660757
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    kv_text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    kv_text = inspect.cleandoc(kv_text)
    assert _KVSection('title', 'key').parse(kv_text) == [DocstringMeta([_parse_item(key='key\n', value='value\n'), _parse_item(key='key2 : type\n', value='values can also span...\n... multiple lines\n')])]


# Generated at 2022-06-23 17:06:06.621984
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    d = DeprecationSection("DeprecationWarning", "deprecated")
    assert d.title == "DeprecationWarning"
    assert d.title_pattern == r"^\.\.\s*(DeprecationWarning)\s*::"
    
    #parse('.. DeprecationWarning:: version number\n    deprecation message')
    text = '.. DeprecationWarning:: version number\n    deprecation message'
    ret = d.parse(text)
    
    assert len(ret) == 1
    assert isinstance(ret[0], DocstringDeprecated)
    assert ret[0].description == 'deprecation message'
    assert ret[0].version == 'version number'
    assert ret[0].args == ['deprecated']

# Generated at 2022-06-23 17:06:10.126470
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection('Returns', 'returns')
    assert ReturnsSection('Return', 'returns')
    assert not ReturnsSection('Return', 'return')


# Generated at 2022-06-23 17:06:14.222803
# Unit test for method parse of class Section
def test_Section_parse():
    x = Section('Parameters','param')
    text = """
    Parameter p1 : int, optional
        description of p1
    """
    x.parse(text) == 'description of p1'

# Generated at 2022-06-23 17:06:18.352710
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert len(parser.sections) == len(DEFAULT_SECTIONS)
    parser = NumpydocParser({"title1": "section1"})
    assert len(parser.sections) == 1
    parser.add_section({"title2": "section2"})
    assert len(parser.sections) == 2


# Generated at 2022-06-23 17:06:27.897576
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    # Test case 1: add a new section - title does not exist in default section
    title = "Test"
    key = "test"
    new_section = Section(title, key)
    numpydoc_parser_1 = NumpydocParser()
    assert numpydoc_parser_1.parse(".. test::\n   Section")[title] is None
    numpydoc_parser_1.add_section(new_section)
    assert numpydoc_parser_1.parse(".. test::\n   Section")[title][key] == "Section"


# Generated at 2022-06-23 17:06:33.615259
# Unit test for function parse
def test_parse():
    def x (a, b, c):
        """ This is a test docstring.

        Params:
            a : char
                description of a
            b : float
                description of b
            c : float
                description of c
        Returns:
            float
                description of returned value
        See Also:
            y, z
            """
        return a+b+c

# Generated at 2022-06-23 17:06:35.084732
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
	assert ReturnsSection("Returns", "returns") != None

# Generated at 2022-06-23 17:06:39.602071
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        # Cause all warnings to always be triggered.
        DeprecationSection("Deprecated", "deprecation")
        # Verify some things
        assert len(w) == 1
        assert issubclass(w[-1].category, DeprecationWarning)


# Generated at 2022-06-23 17:06:45.260846
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    """
    test _KVSection.parse
    """
    text = "Param1\n    value1\nParam2:type\n    value2"

    exp = [DocstringMeta([], description="value1"),
            DocstringMeta([], description="value2")]
    got = [i for i in _KVSection('title', 'key').parse(text)]

    assert exp == got



# Generated at 2022-06-23 17:06:56.791825
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    start = ReturnsSection("Returns", "returns")
    # Change key and title
    start.title = "Return"
    start.key = "returns"
    # Test that key and title are changed
    assert(start.title == "Return")
    assert(start.key == "returns")
    # Set return_name and type_name
    return_name = 'different'
    type_name = 'type'
    # Test that parse function works
    start.parse(return_name + ' : ' + type_name + '\n' + 'description')
    assert(start.parse(return_name + ' : ' + type_name + '\n' + 'description') == DocstringReturns(args=['returns'],description='description',type_name='type',is_generator=False,return_name='different'))

# Generated at 2022-06-23 17:07:00.229505
# Unit test for constructor of class _KVSection
def test__KVSection():
    KS = _KVSection("Parameters", "param")
    assert KS.title_pattern == "^Parameters\s*?\n\-\-\-\-\-\-*-*$"
    assert KS.key == "param"

# Generated at 2022-06-23 17:07:02.296364
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r = RaisesSection("Raises", "raises")
    # not used in this test
    raise r


# Generated at 2022-06-23 17:07:05.228698
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection("Yields", "yields")
    # Test constructor does its job properly
    assert y.is_generator == True
    assert y.key == "yields"
    assert y.title == "Yields"

# Generated at 2022-06-23 17:07:07.289914
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    a = YieldsSection("Yields", "yields")
is_generator = a.is_generator
assert(is_generator == True)
print("Test Passed. Python is awesome!")

# Generated at 2022-06-23 17:07:13.133200
# Unit test for function parse

# Generated at 2022-06-23 17:07:24.233043
# Unit test for function parse
def test_parse():
    docstring = """
        Dummy function

        Parameters
        ----------
        arg_name
            arg_description

        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines

        Attributes
        ----------
        attr
            attr_description

        Returns
        -------
        return_name : type
            A description of this returned value

        another_type
            Return names are optional, types are required

        Raises
        ------
        ValueError
            A description of what might raise ValueError

        Warnings
        --------
        UserWarning
            A description of what might raise UserWarning

            This description can span multiple lines

        Notes
        -----
        Note that this is a note
        """

    doc = parse(docstring)

    assert doc.short_description == "Dummy function"
    assert doc.blank_after

# Generated at 2022-06-23 17:07:27.295101
# Unit test for method parse of class Section
def test_Section_parse():
    with open('./test_data/numpydoc_test_data.txt', 'r') as f:
        text = f.read()
        section = Section('Parameters', 'param')
        assert all(isinstance(item, DocstringMeta) for item in section.parse(text))
        print('test passed')


# Generated at 2022-06-23 17:07:35.288967
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text = (
        "Raises\n"
        "------\n"
        ":ErrorActionPreference\n"
        "    If not included, the default value is 'Stop'.\n"
        ":Exception: An error occurred\n"
        "    Includes 2 or more newlines."
    )
    clean_text = inspect.cleandoc(text)
    matches = [m.group(0) for m in re.finditer(KV_REGEX, clean_text)]
    keys = [
        ":ErrorActionPreference",
        ":Exception: An error occurred",
    ]
    value = ""
    assert keys == matches
    assert value == ""

# Generated at 2022-06-23 17:07:37.815415
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    sec = ReturnsSection("Returns", "returns")
    assert sec.is_generator == False
    assert sec.title == "Returns"
    assert sec.key == "returns"


# Generated at 2022-06-23 17:07:39.401864
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
	rs = RaisesSection("Raises", "raises")
	print("Test: ", rs.__repr__())

# Generated at 2022-06-23 17:07:43.271821
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse(): 
    doc = '.. deprecated:: 1.0.0\n   The deprecatedVersion.'
    text = inspect.cleandoc(doc)
    section = DeprecationSection('deprecated', 'deprecation')
    yieldDoc = list(section.parse(text))[0]
    assert yieldDoc.args == ['deprecation']
    assert yieldDoc.description == 'The deprecatedVersion.'
    assert yieldDoc.version == '1.0.0'


# Generated at 2022-06-23 17:07:44.144596
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Parse the numpy-style docstring into its components."""



# Generated at 2022-06-23 17:07:46.009531
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection("Depends On", "depends_on")
    assert s.title == "Depends On"
    assert s.key == "depends_on"


# Generated at 2022-06-23 17:07:49.104116
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection().is_generator == False
    assert ReturnsSection(is_generator=True).is_generator == True

# Generated at 2022-06-23 17:07:55.288267
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    d = DeprecationSection("Deprecated", "deprecated")
    text = """
    .. deprecated:: 1.0.0
        **Important Notice**

    """
    result = [DocstringDeprecated(args=['deprecated'], description='Important Notice', version='1.0.0')]
    assert list(d.parse(text)) == result


# Generated at 2022-06-23 17:08:06.273294
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection('Parameters', 'param').title == 'Parameters'
    assert ParamSection('Params', 'param').title == 'Params'
    assert ParamSection('Arguments', 'param').title == 'Arguments'
    assert ParamSection('Args', 'param').title == 'Args'
    assert ParamSection('Other Parameters', 'other_param').title == \
            'Other Parameters'
    assert ParamSection('Other Params', 'other_param').title == 'Other Params'
    assert ParamSection('Other Arguments', 'other_param').title == \
            'Other Arguments'
    assert ParamSection('Other Args', 'other_param').title == 'Other Args'
    assert ParamSection('Receives', 'receives').title == 'Receives'

# Generated at 2022-06-23 17:08:07.989825
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection("Parameters", "param").title == "Parameters"


# Generated at 2022-06-23 17:08:18.306970
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:08:30.929964
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def foo(a,b=c):
        """
        some short desc here
        and some longer desc that spans
        multiple lines

        Parameters
        ----------
        a
            the first param with some longer desc
        b : type(c) or str, optional
            the second param

        Returns
        -------
        return_name : type
            A description of this returned value
        """
        pass

    ds = NumpydocParser().parse(foo.__doc__)
    assert ds.short_description == 'some short desc here'
    assert(ds.long_description == 'and some longer desc that spans\nmultiple lines')
    assert(ds.blank_after_short_description == True)
    assert(ds.blank_after_long_description == False)
    param = ds.meta[0]

# Generated at 2022-06-23 17:08:42.397872
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    docstring = "\
        arg_1\n\
            arg_1 description\n\
        arg_2 : arg_2_type\n\
            arg_2 description\n\
        arg_3 : arg_3_type, optional\n\
            arg_3 description\n\
    "
    kv_parser = _KVSection(title="Parameters", key="param")

# Generated at 2022-06-23 17:08:46.165883
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    try:
        d = DeprecationSection("deprecated", "deprecation")
    except:
        print("Unexpected error:", sys.exc_info()[0])


# Generated at 2022-06-23 17:08:49.331228
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section_text = ".. deprecated:: 1.2.0\n   Use the new version:3.2.1"
    d = DeprecationSection("deprecated", "deprecation")
    test_meta = d.parse(section_text)

    assert test_meta[0].version == "1.2.0"
    assert test_meta[0].args == ["deprecation"]
    assert test_meta[0].description == "Use the new version:3.2.1"


# Generated at 2022-06-23 17:08:55.286476
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises = RaisesSection(title = "Raises", key = "raises")
    text = "TypeError\n\tYou will get TypeError if you pass a string as input."
    text = inspect.cleandoc(text)
    result = raises.parse(text)
    final_result = []
    for each in result:
        final_result.append(each)
    assert (final_result[0].args == ["raises","TypeError"])


# Generated at 2022-06-23 17:09:03.101016
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("::", "deprecated")
    assert section.parse("Since v0.1.3") == []
    assert section.parse("Since v0.1.3\n") == []
    assert section.parse("Since v0.1.3\n\n") == []
    assert section.parse("Since v0.1.3\nSomething") == [
        DocstringDeprecated(
            args=["deprecated"], description="Something", version="v0.1.3"
        )
    ]

# Generated at 2022-06-23 17:09:08.980508
# Unit test for constructor of class ParamSection
def test_ParamSection():
    section = ParamSection("Parameters", "param")
    assert section.title == "Parameters"
    assert section.key == "param"
    assert section.title_pattern == r"^Parameters\s*?\n-{12}\s*$"
    assert section.parse("text") == [DocstringMeta([section.key], description="text")]


# Generated at 2022-06-23 17:09:12.087553
# Unit test for constructor of class Section
def test_Section():
    """Test that Section class is initialized with its right parameters"""
    numpydocParser = NumpydocParser()
    for section in numpydocParser.sections:
        sectionInstance = numpydocParser.sections[section]
        assert sectionInstance.title == section
        

# Generated at 2022-06-23 17:09:14.541066
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    with open("../test_functions/deprecated.test") as f:
        text = f.read()
    # print(text)
    assert(DeprecationSection("deprecated", "deprecation").parse(text))


# Generated at 2022-06-23 17:09:15.238780
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert NumpydocParser()

# Generated at 2022-06-23 17:09:24.914510
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    title = "deprecated"
    key = "deprecation"
    description = "Since 0.14.0"

    # Using expected result
    expected_description = "description:\n    Since 0.14.0\n"

    # Instance of DeprecationSection
    deprecation = DeprecationSection(title, key)

    # Parsing using DeprecationSection instance
    result = next(deprecation.parse(description))

    # Cleaning results using cleandoc
    result_description = inspect.cleandoc(result.description)
    expected_description = inspect.cleandoc(expected_description)

    # Comparing parsing results
    assert result_description == expected_description

# Generated at 2022-06-23 17:09:33.732047
# Unit test for constructor of class Section
def test_Section():
    # Constructor and attribute check
    section = Section("test title", "test key")
    assert section.title == "test title"
    assert section.key == "test key"

    # Test title_pattern (attribute)
    assert section.title_pattern == "^test title\s*?\n----*$"

    # Test parse
    text = "This is the body of a section"
    docstring = DocstringMeta([section.key], description=text)
    assert section.parse(text) == [docstring]



# Generated at 2022-06-23 17:09:38.355212
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yields", "yields")
    assert ys.is_generator == True
    assert ys.key == "yields"
    assert ys.title == "Yields"
    assert ys.title_pattern == "^\.\.\s*({})\s*::".format("Yields")

# Generated at 2022-06-23 17:09:40.660805
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    ndp = NumpydocParser()
    assert ndp.sections is not None
    assert ndp._setup is not None


# Generated at 2022-06-23 17:09:53.077484
# Unit test for constructor of class ParamSection
def test_ParamSection():
    foo = ParamSection("Parameters", "param")
    assert foo.title == "Parameters", "The title should be 'Parameters' but it is" + foo.title
    assert foo.key == "param", "The key should be 'param' but it is" + foo.key
    assert foo.title_pattern == "^(Parameters)\s*?\n-*\s*$", "The title pattern is not correct."
    text = "arg_name\n    arg_description\n    arg_2 : type, optional\n        descriptions can also span...\n        ... multiple lines"
    assert foo.parse(text) == DocstringMeta([foo.key], description=_clean_str(text)), "The function parse() is not correct."



# Generated at 2022-06-23 17:09:54.760274
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert NumpydocParser().sections['See Also'] is not None

# Generated at 2022-06-23 17:09:57.170598
# Unit test for constructor of class Section
def test_Section():
    title = "Title"
    key = "key"
    section = Section(title,key)
    assert section.title == title
    assert section.key == key
    

# Generated at 2022-06-23 17:10:02.402869
# Unit test for method parse of class Section
def test_Section_parse():
    def test_func(x):
        """
        Parameters
        ----------
        x: int

        Returns
        -------
        y: int
            Return x+1
        """
        return x+1

    (test_func.__doc__)
    (parse(test_func.__doc__).meta)
    for meta in parse(test_func.__doc__).meta:
        assert meta.key in ("param", "returns")
        if meta.key == "param":
            assert meta.args == ["param", "x"]
            assert meta.arg_name == "x"
            assert meta.type_name == "int"
            assert meta.is_optional == False
        else:
            assert meta.args == ["returns"]
            assert meta.type_name == "int"
            assert meta.is_generator

# Generated at 2022-06-23 17:10:06.315424
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    name
        description

    another_name : type, optional
        another description
        spanning multiple lines

    no_newline
        no
        multiple
        lines

    type_only : type
    """
    kv_section = _KVSection("title", "key")
    assert len(list(kv_section.parse(text))) == 4



# Generated at 2022-06-23 17:10:13.104890
# Unit test for function parse
def test_parse():
    # Coverage for parse
    assert parse("")
    assert parse("Hello World!")
    assert parse("Hello World!\n")
    assert parse("Hello World!\n\n")
    assert parse("Hello World!\n\nMore\n")
    assert parse("Hello World!\n\nMore\n\n")
    assert parse("Hello World!\n\nMore\nAgain\n\n")
    assert parse("Hello World!\n\nMore\nAgain\n\nMore\n")
    assert parse("Hello World!\n\nMore\nAgain\n\nMore\n\n")

if __name__ == "__main__":
    # Coverage for function parse
    test_parse()

# Generated at 2022-06-23 17:10:19.660226
# Unit test for constructor of class Section
def test_Section():
    section = Section('title','key')
    assert(section.title == 'title')
    assert(section.key == 'key')
    assert(section.title_pattern == r'^(title)\s*?\n{}\s*$'.format('-'*5))
    assert(section.parse('description') == [DocstringMeta(['key'],
                                                           description='description')])


# Generated at 2022-06-23 17:10:27.508822
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    text = """
    output_name : type
        possible description
    """
    parser = NumpydocParser()
    parser.add_section(ReturnsSection("Output", "outputs"))
    docstring = parser.parse(inspect.cleandoc(text))
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ['outputs']
    assert docstring.meta[0].description == 'possible description'

# Generated at 2022-06-23 17:10:33.552851
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpyParser = NumpydocParser()
    section = Section("Parameter", "param")
    numpyParser.add_section(section)
    assert numpyParser.sections[section.title] is not None
    assert numpyParser.sections[section.title].key == "param"
    assert numpyParser.sections[section.title].title == "Parameter"
    assert numpyParser.titles_re.pattern.find("Parameter") is not None


# Generated at 2022-06-23 17:10:37.085436
# Unit test for constructor of class Section
def test_Section():
    title = 'Parameters'
    key = 'param'
    section = Section(title, key)
    assert section.title == 'Parameters'
    assert section.key == 'param'

# Generated at 2022-06-23 17:10:38.781243
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    a = ReturnsSection("Returns", "returns")
    assert (a.is_generator == False)



# Generated at 2022-06-23 17:10:51.909351
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test different types of numpy style docstring
    # Simple case with only short and long descriptions
    short_desc = 'This function does something'
    long_desc = 'And here is a lot of text explaining it'
    docstring_simple = short_desc + '\n\n' + long_desc

    parsed_simple = parse(docstring_simple)
    assert parsed_simple.short_description == short_desc
    assert parsed_simple.long_description == long_desc
    assert parsed_simple.blank_after_short_description == True
    assert parsed_simple.blank_after_long_description == False

    # Docstring with description but no long description
    docstring_no_long = short_desc + '\n'
    parsed_no_long = parse(docstring_no_long)

# Generated at 2022-06-23 17:10:53.794854
# Unit test for constructor of class _KVSection
def test__KVSection():
    _KVSection(title="title", key="key")


# Generated at 2022-06-23 17:10:58.966827
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    return_name, type_name = "name", "type"
    description = "A description"
    
    ret = ReturnsSection("Returns", "returns")._parse_item(
        key=f"{return_name} : {type_name}", value=description
    )
    
    assert ret.description == description
    assert ret.return_name == return_name
    assert ret.type_name == type_name

# Generated at 2022-06-23 17:11:11.456683
# Unit test for function parse
def test_parse():
    doc = """
    A function.

    Parameters
    ----------
    first_param : type
        A positional argument.
    trailing_comma : type, optional
        An optional `str` argument.
    **kwargs
        Keyword arguments.

    Returns
    -------
    res : type
        A return value.
    """

# Generated at 2022-06-23 17:11:13.720505
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    NumpydocParser({"title": Section("title", "key")})

# Generated at 2022-06-23 17:11:15.630910
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("Deprecated", "deprecation")
    assert section.title == "Deprecated"


# Generated at 2022-06-23 17:11:18.784377
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydocParser = NumpydocParser()
    section = Section("Test", "test")
    numpydocParser.add_section(section)
    assert numpydocParser.sections.__contains__(section.title)

# Generated at 2022-06-23 17:11:21.601739
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection("title", "key")
    assert s.title == "title"
    assert s.key == "key"
    assert s.title_pattern == r"^\.\.\s*(title)\s*::"

# Generated at 2022-06-23 17:11:25.163145
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section = _SphinxSection(title= "title", key="key")
    assert(section.title_pattern == r"^\.\.\s*(title)\s*::")

# Generated at 2022-06-23 17:11:32.716461
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    dep = NumpydocParser()
    dep_text = """.. deprecated:: 0.2.2
        This is an example of a deprecation warning."""
    dep_result = dep.parse(dep_text)
    # print(dep_result)
    print(dep_result.meta)
    assert dep_result.meta[0].description == "This is an example of a deprecation warning."
    assert dep_result.meta[0].version == "0.2.2"

# Generated at 2022-06-23 17:11:41.040835
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    factory = DeprecationSection("deprecated", "deprecation")
    text = """deprecated ::

        test
        test"""
    doc = factory.parse(text)
    doc = next(doc)
    assert doc.args == ["deprecation"]
    assert doc.description == "test\ntest"
    assert doc.version == None
    text = """deprecated ::

        version 1
        test"""
    doc = factory.parse(text)
    doc = next(doc)
    assert doc.args == ["deprecation"]
    assert doc.description == "test"
    assert doc.version == "version 1"

# Generated at 2022-06-23 17:11:46.459030
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 1.4.1
        my_deprecated_function does not work anymore, please use my_function instead
    """
    result = DeprecationSection("deprecated", "deprecation").parse(text)
    expected = [DocstringDeprecated(args=['deprecation'], description='my_deprecated_function does not work anymore, please use my_function instead', version='1.4.1')]
    assert [x.__dict__ for x in result] == [x.__dict__ for x in expected]


# Generated at 2022-06-23 17:11:58.262219
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    obj = ReturnsSection("Returns", "returns")
    assert obj.is_generator == False
    assert obj._parse_item("", "") == DocstringReturns(args=['returns'], description=None, type_name=None, is_generator=False, return_name=None)
    assert obj._parse_item("return type", "") == DocstringReturns(args=['returns'], description=None, type_name='return type', is_generator=False, return_name=None)
    assert obj._parse_item(" : return type", "") == DocstringReturns(args=['returns'], description=None, type_name='return type', is_generator=False, return_name=None)

# Generated at 2022-06-23 17:12:01.024538
# Unit test for constructor of class Section
def test_Section():
    section = Section('Parameters', 'param')
    assert section.title == 'Parameters'
    assert section.key == 'param'

# Generated at 2022-06-23 17:12:12.688574
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("hello") == Docstring(
        short_description="hello",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=list(),
    )
    assert parse("hello\nworld") == Docstring(
        short_description="hello",
        long_description="world",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=list(),
    )
    assert parse("hello\n\nworld") == Docstring(
        short_description="hello",
        long_description="world",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=list(),
    )
   

# Generated at 2022-06-23 17:12:18.116124
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    a = DeprecationSection("Deprecation warning", "deprecation")
    assert a.title == "Deprecation warning"
    assert a.key == "deprecation"
    assert a.title_pattern == r"^\.\.\s*(Deprecation warning)\s*::"


# Generated at 2022-06-23 17:12:22.484100
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    try:
        s = _SphinxSection("Parameters", "param")
    except:
        raise Exception("Class _SphinxSection can't construct object!")
    print("Class _SphinxSection can construct object!")


test__SphinxSection()

# Generated at 2022-06-23 17:12:33.600819
# Unit test for constructor of class _KVSection
def test__KVSection():
    str1 = "param1: int"
    str2 = " param description is here "
    str3 = "param2: int\n\tparam description is here"
    str4 = "param2: int\t\nparam description is here"

    title = "Parameters"
    key = "param"

    a = _KVSection(title, key)
    assert a != None

    b = _KVSection(title, key)
    assert a == b

    assert a.title == b.title
    assert a.key == b.key

    assert textwrap.dedent(str3) == inspect.cleandoc(str3)

    c = _KVSection(title + key, key)
    assert c != a



# Generated at 2022-06-23 17:12:38.424728
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    text = NumpydocParser().parse("""
        '''
        Yields
            A
        '''
        """)
    assert text.long_description == None
    assert text.meta[0].description == "A"


# Generated at 2022-06-23 17:12:40.389265
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert RaisesSection("Raises", "raises")


# Generated at 2022-06-23 17:12:50.316663
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert 'desc' == NumpydocParser({'title':Section('title','arg')}).parse('desc').short_description
    assert 'desc\nlong desc' == inspect.cleandoc(NumpydocParser({'title':Section('title','arg')}).parse('desc\n long desc').long_description)
    assert 'desc\nlong desc' == inspect.cleandoc(NumpydocParser({'title':Section('title','arg')}).parse('desc\n\n long desc').long_description)
    assert 'desc\nlong\ndesc' == inspect.cleandoc(NumpydocParser({'title':Section('title','arg')}).parse('desc\n\n\nlong\ndesc\n').long_description)

# Generated at 2022-06-23 17:13:00.595193
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """Unit test for method add_section of class NumpydocParser"""
    # Instantiate NumpydocParser
    np_parser = NumpydocParser()
    # Let's assume we want to parse a section title
    # called "Misc" with key "misc"
    sec_title = "Misc"
    sec_key = "misc"
    # Instantiate a Section class
    sec = Section(sec_title, sec_key)
    # Add the new section to the NumpydocParser
    # This new section is used to parse the docstrings
    # and also to build the regexes to parse the docstrings
    np_parser.add_section(sec)

    # Loading the example docstrings

# Generated at 2022-06-23 17:13:03.660697
# Unit test for constructor of class _KVSection
def test__KVSection():
    s = _KVSection("Parameters","param")
    assert s.title == "Parameters"
    assert s.key == "param"


# Generated at 2022-06-23 17:13:07.103389
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "Example"
    key = "Example"
    expected_pattern = r"^\.\.\s*Example\s*::"
    s = _SphinxSection(title=title, key=key)
    assert(s.title_pattern == expected_pattern)


# Generated at 2022-06-23 17:13:13.649265
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Test with only one key-value pair
    section = _KVSection(title='', key='')
    text = """
    key1
        value1
    """

    # Should return a single DocstringMeta object
    result = list(section.parse(text))
    assert len(result) == 1
    assert type(result[0]) == DocstringMeta

    # Test with multiple key-value pairs
    section = _KVSection(title='', key='')
    text = """
    key1
        value1
    key2
        value2
    key3
        value3
    """
    # Should return a list of 3 DocstringMeta objects
    result = list(section.parse(text))
    assert len(result) == 3

# Generated at 2022-06-23 17:13:22.817472
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    NumpydocParser()
    sections = [
        ParamSection("Parameters", "param"),
        Section("Examples", "examples"),
        Section("Example", "examples"),
        Section("Warnings", "warnings"),
        Section("Warning", "warnings"),
        Section("See Also", "see_also"),
        Section("Related", "see_also"),
        Section("Notes", "notes"),
        Section("Note", "notes"),
        Section("References", "references"),
        Section("Reference", "references"),
    ]
    NumpydocParser(sections)


# Generated at 2022-06-23 17:13:28.815173
# Unit test for constructor of class _KVSection
def test__KVSection():
    parser = NumpydocParser()
    assert parser.parse("do nothing")
    assert parser.parse("do nothing\n")
    assert parser.parse("do nothing\n\n")
    assert parser.parse("do nothing\n\n\n")
    assert parser.parse("do nothing\n\n\n\n")
    assert parser.parse("do nothing\n\n\n\n")
    assert parser.parse("do nothing\n\n\n\n")
    assert parser.parse("do nothing\n\n\n\n")

# Generated at 2022-06-23 17:13:33.483347
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """Unit test for method add_section of class NumpydocParser"""
    my_section = Section("my-section", "my-section")
    ndparser = NumpydocParser()
    ndparser.add_section(my_section)

    assert "my-section" in ndparser.sections

# Generated at 2022-06-23 17:13:40.925674
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    ds = DeprecationSection("deprecated", "deprecation")
    text = "deprecated something"

# Generated at 2022-06-23 17:13:52.998781
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():

    # Test parser with string containing tags deprecated:: and versionchanged::
    text =  '.. deprecated:: 2.3 \n This is a code sample'
    parsed_text = list(DeprecationSection("deprecated", "deprecation").parse(text))[0]
    assert parsed_text.version == "2.3"
    assert parsed_text.description == "This is a code sample"

    #Test parser with string containing deprecated:: and versionchanged:: tags
    text = '.. deprecated:: 2.3 \n This is a code sample \n .. versionchanged:: 3.1'
    parsed_text = list(DeprecationSection("deprecated", "deprecation").parse(text))[0]
    assert parsed_text.version == "3.1"
    assert parsed_text.description == "This is a code sample"

# Generated at 2022-06-23 17:14:02.058443
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection('Deprecation', 'deprecation')  # instance DeprecationSection
    text = '.. deprecated:: 1.2.3\n   The parameter `foo` has been deprecated.'
    docstring_deprecated = section.parse(text).__next__()  # instance DocstringDeprecated
    assert docstring_deprecated.args == ['deprecation']
    assert docstring_deprecated.version == '1.2.3'
    assert docstring_deprecated.description == 'The parameter `foo` has been deprecated.'



# Generated at 2022-06-23 17:14:07.534183
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    myRaisesSection = RaisesSection("Raises", "raises")
    assert myRaisesSection.title == "Raises"
    assert myRaisesSection.key == "raises"
    assert myRaisesSection.title_pattern == "^(Raises)\\s*?\\n={2}\\s*$"
    assert myRaisesSection.parse == RaisesSection.parse



# Generated at 2022-06-23 17:14:18.413736
# Unit test for function parse
def test_parse():
    doc=parse("""This function does something

    Parameters
        ----------
        x : int
            Description of first parameter x
        y : float
            Description of second parameter y

    Returns
        -------
        z : z_type
            Description of return value z
    """)

    for key in ["short_description", "long_description", "blank_after_short_description", "blank_after_long_description"]:
        assert hasattr(doc, key)
    assert hasattr(doc.meta[0], "args")
    assert hasattr(doc.meta[0], "description")
    assert len(doc.meta) == 3



# Generated at 2022-06-23 17:14:25.193428
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert ReturnsSection.__name__ == "ReturnsSection"
    assert YieldsSection.__name__ == "YieldsSection"
    assert ReturnsSection.__bases__[0] == YieldsSection.__bases__[0] == _KVSection
    assert ReturnsSection.is_generator == False
    assert YieldsSection.is_generator == True

# Generated at 2022-06-23 17:14:27.330673
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    from .common import DocstringReturns
    a = ReturnsSection("abc", "abc")
    assert a.is_generator == False


# Generated at 2022-06-23 17:14:35.220193
# Unit test for function parse
def test_parse():
    """Test parsing a simple numpy-style docstring."""
    doc = """
    Sum a list of integers.

    This is a long description. The first sentence can be separated from the
    rest of the description by a blank line.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : float
        The second argument.

    Returns
    -------
    int
        The sum of all values in the list.

    See Also
    --------
    abs, mul

    Notes
    -----
    This function does not work with negative values.
    """
    parsed = parse(doc)
    assert parsed.short_description == "Sum a list of integers."
    assert parsed.long_description is not None
    assert parsed.long_description.startswith("This is a long description.")
    assert parsed.blank_after

# Generated at 2022-06-23 17:14:39.285893
# Unit test for constructor of class Section
def test_Section():
    a = Section("Parameters", "param")
    assert a.title == "Parameters"
    assert a.key == "param"
    assert a.title_pattern == "^Parameters\\s*?\n-{9}\\s*$"

# Generated at 2022-06-23 17:14:49.132965
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # TODO: use tests from sphinxcontrib-napoleon
    assert ParamSection("Parameters", "param")._parse_item("a", "something").args \
        == ['param', 'a']
    assert ParamSection("Parameters", "param").parse("") == []
    assert ParamSection("Parameters", "param").parse("param_name") == [
        DocstringParam(args=['param', 'param_name'], description='', arg_name='param_name', type_name=None, is_optional=None, default=None)]

# Generated at 2022-06-23 17:14:53.606107
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """Testing the add_section method of class NumpydocParser"""
    parser = NumpydocParser()
    mySection = Section(title='title', key='key')
    parser.add_section(mySection)
    assert(parser.sections['title'] == mySection)

# Generated at 2022-06-23 17:14:56.274162
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    section = Section('Test Title', 'test_title')
    parser.add_section(section)
    assert parser.sections['Test Title'] is section

# Generated at 2022-06-23 17:14:58.371743
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    d = DeprecationSection("Deprecated", "deprecated")
    assert d.title == "Deprecated"
    assert d.key == "deprecated"

# Generated at 2022-06-23 17:15:07.491205
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def echo(
        arg_1: int, arg_2="hello", arg_3: "world" = "world"
    ) -> "What do i return?":
        """An example function.

        A long paragraph explaining in detail what this function does.
        This is a typical numpy-style function docstring which may contain
        multiple paragraphs, mathematics and formatting.

        Parameters
        ----------
        arg_1 : int
            a parameter.
        arg_2 : str, optional
            another parameter, defaults to "hello".
        arg_3 : str, optional, default: "world"
            another parameter.

        Returns
        -------
        str
            What am I returning?

        Raises
        ------
        TypeError
            when an error occurs
        """
        return "hello, world"

# Generated at 2022-06-23 17:15:11.747723
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    # ReturnsSection is a subclass of Section.
    # In this test we instantiate a subclass of ReturnsSection, YieldsSection.
    # Then we test the output of the constructor of ReturnsSection.
    yields = YieldsSection("title", "key")
    assert yields.title == "title"
    assert yields.key == "key"
    assert yields.is_generator == True



# Generated at 2022-06-23 17:15:14.764658
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection('Parameters','param')
    assert p.title == 'Parameters'
    assert p.key == 'param'


# Generated at 2022-06-23 17:15:17.931412
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()


if __name__ == "__main__":
    import pytest

    pytest.main(["-x", __file__[:-3] + "_test.py"])

# Generated at 2022-06-23 17:15:24.547684
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("deprecated")
    assert section.title == "deprecated"
    assert section.key == "deprecation"
    assert section.title_pattern == "^\.\.\s*(deprecated)\s*::"

    section = DeprecationSection("deprecation")
    assert section.title == "deprecation"
    assert section.key == "deprecation"
    assert section.title_pattern == "^\.\.\s*(deprecation)\s*::"

# Generated at 2022-06-23 17:15:26.259761
# Unit test for method parse of class Section
def test_Section_parse():
    Section.parse("foo", "bar")
    Section("title", "meta_key").parse("foo")

# Generated at 2022-06-23 17:15:27.162879
# Unit test for constructor of class ParamSection
def test_ParamSection():
    y = ParamSection("Parameters", "param")

# Generated at 2022-06-23 17:15:37.653641
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    import re
    import inspect

    text = """.. deprecated:: 0.1.1
        Deprecation message"""

    # Parser
    depr_s = DeprecationSection("deprecated", "deprecation")
    result = depr_s.parse(text)
    my_result = ["deprecation", "Deprecation message"]

    for x in result:
        k = x.args
        y = next(iter(k))
        assert(y == my_result[0])
        break

    for x in result:
        k = x.description
        assert(k == my_result[1])
        break

# Generated at 2022-06-23 17:15:39.997126
# Unit test for constructor of class Section
def test_Section():
    assert Section("Parameters", "param").title == "Parameters"
    assert Section("Parameters", "param").key == "param"

# Generated at 2022-06-23 17:15:48.075311
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    text = '''
    Return the square of a number.

    Parameters
    ----------
    a : number
        The number to be squared.

    Returns
    -------
    a^2 : number
        The square of the input.
    '''
    ret = parser.parse(text)
    # parse docstring into a Docstring object
    if ret.short_description == 'Return the square of a number.' and ret.long_description == 'The number to be squared.' and ret.meta[0].description == 'The number to be squared.' and ret.meta[1].description == 'The square of the input.':
        print("Unit test passed: NumpydocParser()")
    else:
        print("Unit test failed: NumpydocParser()")



# Generated at 2022-06-23 17:15:56.989964
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    docstring = '10.0.0\n\n  This function was deprecated in version 10.0.0.'
    function = DeprecationSection("deprecated", "deprecation")
    function_parsed = function.parse(docstring)
    assert hasattr(function_parsed, '__iter__')
    assert list(function_parsed)[0].args == ['deprecation']
    assert list(function_parsed)[0].description == 'This function was deprecated in version 10.0.0.'
