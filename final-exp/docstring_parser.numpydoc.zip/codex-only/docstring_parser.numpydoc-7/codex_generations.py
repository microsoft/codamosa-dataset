

# Generated at 2022-06-23 17:06:03.880448
# Unit test for function parse
def test_parse():
    from .common import Docstring, DocstringMeta, DocstringParam

    text = """
        this is the short description
        this is the long description
        below is the first section
        Parameters
        ----------
        foo : int
            this is foo
        bar : str
            this is bar
        baz
            this is baz
        """
    docstring = parse(text)

    expected = Docstring()

    expected.short_description = "this is the short description"
    expected.long_description = "this is the long description\nbelow is the first section"
    expected.blank_after_short_description = True
    expected.blank_after_long_description = True


# Generated at 2022-06-23 17:06:07.881183
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert DeprecationSection.parse("1.2.1\nHere is a description.") == (
    [DocstringDeprecated(args=['deprecation'], description='Here is a description.', version='1.2.1')]
    )

# Generated at 2022-06-23 17:06:10.423059
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text = """ValueError
            A description of what might raise ValueError"""
    rs = RaisesSection("Raises", "raises")
    rs_result = list(rs.parse(text))
    assert rs_result[0].args == ['raises', 'ValueError']
    assert rs_result[0].description == 'A description of what might raise ValueError'
    assert rs_result[0].type_name == 'ValueError'


# Generated at 2022-06-23 17:06:14.073789
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    rt_section = ReturnsSection("Returns", "returns")
    assert (rt_section.is_generator == False)

# Test for parse function 

# Generated at 2022-06-23 17:06:25.580977
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Test for value 1, for string is a valid deprecation section
    text = "                                        "
    text += ".. deprecated:: 1.3.3                    "
    text += "                                        "
    text += "  This method is deprecated. Please use "
    text += "  the new one instead.                  "
    text += "                                        "

    test = NumpydocParser().parse(text)
    assert test.meta[0].args[0] == "deprecation"
    assert test.meta[0].args[1] == None
    assert test.meta[0].version == "1.3.3"
    assert test.meta[0].description == "This method is deprecated. Please use  the new one instead."

    # Test for value 2, for string is a valid deprecation section

# Generated at 2022-06-23 17:06:30.341839
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    # Send valid parameters
    dep = DeprecationSection("deprecated", "deprecation")

    # Send invalid parameters
    try:
        dep1 = DeprecationSection("deprecateded", "deprecation")
        assert False, "Should not work!"
    except:
        pass


# Generated at 2022-06-23 17:06:31.744759
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection("deprecated", "deprecation")

# Generated at 2022-06-23 17:06:41.596186
# Unit test for constructor of class Section
def test_Section():
    from .common import DocstringParam
    from .numpydoc import ParamSection
    text = """
    Parameters
    ----------
    name : str
        Name of the world
    num : int, optional
        Number of the world
        Default is None
    """
    numpydoc_section = ParamSection("Parameters", "param").parse(text)

# Generated at 2022-06-23 17:06:49.430644
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    deprecationSection = DeprecationSection("deprecated", "deprecation")
    text = inspect.cleandoc("""
            .. deprecated:: 1.2.0
            This is deprecated.
            """)
    results = list(deprecationSection.parse(text))
    assert results[0].description == "This is deprecated."
    assert results[0].version == "1.2.0"


# Generated at 2022-06-23 17:07:00.586893
# Unit test for function parse

# Generated at 2022-06-23 17:07:09.441935
# Unit test for function parse
def test_parse():
    """Test function for parse"""
    string_for_test = '''
    This is a docstring. It will be parsed by numpydoc
    Parameters
        arg : type
            Description of this argument.
            
        arg2 : int, optional
            Description of this argument
    Returns
    -------
    type
        Description of the return value.
    Raises
    ------
    ValueError
        If something goes wrong.
    '''
    ret = parse(string_for_test)
    assert(ret.short_description=='This is a docstring. It will be parsed by numpydoc')

# Generated at 2022-06-23 17:07:09.978467
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    return True

# Generated at 2022-06-23 17:07:14.192522
# Unit test for function parse
def test_parse():
    from . import common

    docstring = inspect.cleandoc(
        """
    This is a short description.

    This is a long description. It may contain
    multiple lines.
    """
    )
    doc = common.parse_docstring(docstring)
    assert isinstance(doc, common.Docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description. It may contain\nmultiple lines."

# Generated at 2022-06-23 17:07:21.053658
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecated", "deprecation")
    docstring_text = """
    :deprecated:: 1.0

    Will be removed without warning in 1.2
    """
    result = section.parse(docstring_text)
    assert inspect.isgenerator(result)
    assert list(result)[0] == DocstringDeprecated(
        args=["deprecation"],
        description="Will be removed without warning in 1.2",
        version="1.0",
    )

# Generated at 2022-06-23 17:07:24.127242
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    a = YieldsSection("Yield", "yields")
    if a.is_generator == False:
        raise AssertionError("test_YieldsSection fails")
    else:
        return True

# Generated at 2022-06-23 17:07:30.251103
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text="""This function does a lot of things and it takes a lot of
    parameters.
    :param param1: This is the first param.
    :param param2: This is a second param.
    :param param3: This is a third param.
    """
    param1, param2, param3=KVSection('Parameters','param').parse(text)

    assert param2.arg_name == 'param2', "arg_name of param2 should be 'param2'"
    assert param1.description =='This is the first param.', "Description of param1 should be 'This is the first param.'"
    assert param2.description =='This is a second param.', "Description of param2 should be 'This is a second param.'"

# Generated at 2022-06-23 17:07:40.619279
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    from .common import Docstring, DocstringParam, DocstringRaises, DocstringReturns, NumpydocParser
    from .common import DocstringDeprecated
    import inspect
    import re

    
    sections = NumpydocParser()
    text = '''
    Parameters
    ----------
    arg1 : int
        description 1
    arg2 : str
        description 2
    arg3 : list
        description 3

    Raises
    ------
    NotImplementedError
        description 4
    ValueError
        description 5

    Returns
    -------
    str
        description 6

    Yields
    ------
    list
        description 7
    '''

# Generated at 2022-06-23 17:07:45.122990
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    title = "Deprecation warning"
    key = "deprecated"
    ds = DeprecationSection(title, key)
    text = "0.3.3\nthis is a Deprecation warning"
    assert key == ds.key
    assert title == ds.title
    assert ".. Deprecation warning::" == ds.title_pattern


# Generated at 2022-06-23 17:07:50.911925
# Unit test for constructor of class _KVSection
def test__KVSection():
    KV_REGEX = re.compile(r"^[^\s].*$", flags=re.M)

# Generated at 2022-06-23 17:08:01.921640
# Unit test for method parse of class Section

# Generated at 2022-06-23 17:08:14.354773
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    # Test empty string
    section = YieldsSection("Yields", "yields")
    text = ""
    result = section.parse(text)
    expected = [
        DocstringReturns(
            args=["yields"],
            description=None,
            type_name=None,
            is_generator=True,
            return_name=None,
        )
    ]
    assert result == expected

    # Test one item
    text = "return_name : type\n    A description of this returned value"
    result = section.parse(text)

# Generated at 2022-06-23 17:08:17.370827
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    dep_sec = DeprecationSection("deprecated", "deprecation")
    assert dep_sec.title == "deprecated"
    assert dep_sec.key == "deprecation"



# Generated at 2022-06-23 17:08:26.682513
# Unit test for constructor of class Section
def test_Section():
    class TestSection(Section):
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            for match, next_match in _pairwise(KV_REGEX.finditer(text)):
                start = match.end()
                end = next_match.start() if next_match is not None else None
                value = text[start:end]
                yield DocstringMeta(
                    [self.key], description=_clean_str(value)
                )
    return TestSection("Parameters", "param")



# Generated at 2022-06-23 17:08:39.053831
# Unit test for function parse
def test_parse():
    text = """
    Compute a + b

    Parameters
    ----------

    a aaaa
    b bbbb
    c cccc
    d dddd

    Returns
    -------

    a+b

    Examples
    --------

    >>> a = 3
    >>> b = 4
    >>> c = 4
    >>> a + b
    7

    Other Parameters
    ----------------

    arg1 : int
        arg1 long description
    arg2 : float
        arg2 long description

    Raises
    ------
    IOError:
        On various issues

    Warnings
    --------

    Warns when value of arg2 is outside some interval.

    References
    ----------

    [1] The reference.

    """
    doc = parse(text)
    print(doc)

# Generated at 2022-06-23 17:08:40.476179
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    YieldsSection("Yields", "yields")

# Generated at 2022-06-23 17:08:47.240664
# Unit test for method parse of class Section
def test_Section_parse():
    # Description for the test
    # We test the parse method and then we see that the result is equal to
    # the expected one
    test_paragraph = """
    This is a dummy long description of the function.

    And it has multiple lines
    """

    docstring = Docstring(
        short_description="This is a dummy function",
        long_description=test_paragraph,
        meta=[
            DocstringParam(
                args=["param", "arg_name"],
                description="This is the description of the arg_name parameter",
                arg_name="arg_name",
                type_name="string",
                is_optional=False,
            )
        ],
    )

    my_section = Section("Parameters","param")

    observed = my_section.parse(test_paragraph)
    expected = docstring


# Generated at 2022-06-23 17:08:56.391840
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    short description
    
    long description
    
    Parameters
    ----------
    params : string
        this is a string
        that spans two lines
    other_params : string, optional
        this is another string
    
    Returns
    -------
    something : string
        this is something else
        
    See Also
    --------
    link to something
    """
    ret = parse(text)
    assert ret.short_description == "short description"
    assert ret.long_description == "long description"
    assert len(ret.meta) == 7
    for m in ret.meta:
        print(m)
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description
    return ret

# Generated at 2022-06-23 17:09:00.301249
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    p = DeprecationSection("Anything", "anything")
    match = re.search(p.title_pattern,".. Anything :: something\n")
    if(match):
        assert match.group(1) == "Anything"

# Generated at 2022-06-23 17:09:02.337502
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    try:
        assert False
    except AssertionError:
        print('Test _SphinxSection: pass')

# Generated at 2022-06-23 17:09:12.590674
# Unit test for method parse of class Section
def test_Section_parse():
    example1 = '''\
    Arguments

    ---------
    h : int
        Some description.

    Returns
    -------
    int
        Some description.\
    '''
    example2 = '''\
    Arguments

    ---------
    h : int
        Some description.

    x : int
        Some description.
    '''
    assert Section('Arguments','param').parse(example1) == [DocstringMeta(['param','h'],description='Some description.')]
    assert Section('Arguments','param').parse(example2) == [DocstringMeta(['param','h'],description='Some description.'), DocstringMeta(['param','x'],description='Some description.')]

# Generated at 2022-06-23 17:09:17.381674
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    a = ''' 
    a
    aa

    b
    bb
    '''
    b = '''
    a: aa

    b: bb
 
    '''
    for txt in [a, b]:
        for key, value in _KVSection(a, a).parse(txt):
           assert key == "a"
           assert value == "aa"
           break
        for key, value in _KVSection(a, a).parse(txt):
           assert key == "b"
           assert value == "bb"
           break


# Generated at 2022-06-23 17:09:24.407494
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Test 1
    text = """\
    .. deprecated:: 0.0.1

       Message of the deprecation"""

    doc_string = Docstring()
    doc_string.meta.append(
        DocstringDeprecated(
            args=[
                "deprecation"
            ],
            version="0.0.1",
            description="Message of the deprecation",
        )
    )

    assert DeprecationSection("deprecated", "deprecation").parse(text) == doc_string



# Generated at 2022-06-23 17:09:25.417764
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()

# Generated at 2022-06-23 17:09:28.788540
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section('section_title', 'section_key')
    text = 'some\ntext\n'
    r = section.parse(text)


# Generated at 2022-06-23 17:09:35.439312
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # normal case
    paramSection = ParamSection('Parameters', 'param')
    assert paramSection.key == 'param'
    assert paramSection.title == 'Parameters'

    # abnormal case
    with pytest.raises(TypeError) as TE:
        paramSection = ParamSection()
    assert "__init__() missing 2 required positional arguments: 'title' and 'key'" in str(TE.value)

# Generated at 2022-06-23 17:09:36.885009
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection("Parameters", "param").parse("") is not None

# Generated at 2022-06-23 17:09:38.351404
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "title"
    key = "key"
    section = _SphinxSection(title, key)

    assert section.title == title
    assert section.key == key


# Generated at 2022-06-23 17:09:51.306349
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    p = ParamSection("Parameters", "param")
    text = """
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
        arg_3
            Default: 2
    """

    res = list(p.parse(text))
    assert len(res) == 3

    assert res[0].description == 'arg_description'
    assert res[0].arg_name == 'arg_name'
    assert res[0].type_name is None
    assert res[0].is_optional is None
    assert res[0].default is None

    assert res[1].description == 'descriptions can also span...\n... multiple lines'
    assert res[1].arg_name == 'arg_2'
    assert res[1].type_name == 'type'


# Generated at 2022-06-23 17:09:54.016010
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yields_section = YieldsSection("Yields", "yields")
    assert yields_section.is_generator == True

# Generated at 2022-06-23 17:09:55.561452
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yield_section = YieldsSection("Yields", "yields")
    return_section = ReturnsSection("Returns", "returns")
    assert yield_section.is_generator == True
    assert return_section.is_generator == False



# Generated at 2022-06-23 17:09:57.825961
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    test_obj = RaisesSection("Raises","raises")
    assert test_obj.title == "Raises"
    assert test_obj.key == "raises"

# Generated at 2022-06-23 17:10:08.026313
# Unit test for constructor of class Section
def test_Section():
    title = "Para"
    key = "param"
    test_section = Section(title, key)
    assert test_section.title == title
    assert test_section.key == key
    pattern = r"^({})\s*?\n{}\s*$".format(test_section.title, "-" * len(test_section.title))
    assert test_section.title_pattern == pattern
    text = "The parameter\n-----------\nThis parameter is a number"
    assert list(test_section.parse(text))[0].args[0] == key
    assert list(test_section.parse(text))[0].args[1] == title


# Generated at 2022-06-23 17:10:15.061713
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    npd = NumpydocParser()
    text = """Title.

    Short description.

    Long description.

    Parameters
    ----------
    param1 : str
        The first parameter.

    param2 : :obj:`int`, optional
        The second parameter.

    Params
    ------
    paramb : str
        The first parameter.

    paramc : :obj:`int`, optional
        The second parameter.

    Returns
    -------
    int
        Some return value.

    See Also
    --------
    OtherFunc : the other function
        which can do similar things

    """
    doc = npd.parse(text)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert len(doc.meta) == 4

# Generated at 2022-06-23 17:10:23.743986
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    str1 = 'TypeError\n    value of i is not an integer\n'\
            'IndexError\n    d is out of bounds'
    r = RaisesSection("Raises","raises")
    r.parse(str1)
    str1 = 'ValueError\n    Error raised when value is not acceptable.\n'
    r.parse(str1)
    # Test to see if the key and value are set properly.
    assert r.title == "Raises"
    assert r.key == "raises"
    # Test examples to see if the key and value are set properly in 
    # the _parse_item function.
    assert r._parse_item(key = 'TypeError', value = 'value of i is not an integer') is not None

# Generated at 2022-06-23 17:10:32.796138
# Unit test for constructor of class _KVSection
def test__KVSection():
    """Testing constructor of class _KVSection"""
    try:
        test_section = _KVSection(title="notes", key="notes")
    except:
        assert False, "Failed to create object of class _KVSection"

    assert test_section.title == "notes", "Failed to initialize title of class _KVSection object"
    assert test_section.key == "notes", "Failed to initialize key of class _KVSection object"
    assert test_section.title_pattern == "^(notes)\\s*?\\nnotes\\s*$", "Failed to initialize title_pattern of class _KVSection object"


# Generated at 2022-06-23 17:10:35.376595
# Unit test for constructor of class Section
def test_Section():
    section = Section(title='title', key='key')
    assert section.title == 'title'
    assert section.key == 'key'


# Generated at 2022-06-23 17:10:38.043627
# Unit test for method parse of class Section
def test_Section_parse():
    assert next(Section("Parameters", "param").parse("a description")) \
        == DocstringMeta(['param'], description="a description")

# Generated at 2022-06-23 17:10:42.733955
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert list(DeprecationSection("deprecated", "deprecation").parse("1.0 removed"))[0].version == "1.0"


# Generated at 2022-06-23 17:10:46.737467
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    depr = DeprecationSection(title="test",
                              key="here")
    assert depr.title == "test"
    assert depr.key == "here"


# Generated at 2022-06-23 17:10:55.281214
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    class UsageSection(_KVSection):
        def _parse_item(self, key: str, value: str) -> DocstringMeta:
            return DocstringMeta(args=[self.key], description=_clean_str(value))

    sections = NumpydocParser([UsageSection("Usage", "usage")])
    docstring = sections.parse(
        """Usage
    Example::

        >>> import numpydoc
        >>> print(numpydoc.parse())
    """
    )

    usage = docstring.meta[0]
    assert usage.description == (
        "Example:\n\n    >>> import numpydoc\n    >>> print(numpydoc.parse())"
    )


# Generated at 2022-06-23 17:10:57.793248
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section = _SphinxSection("title", "key")
    assert section.title == "title"
    assert section.key == "key"


# Generated at 2022-06-23 17:11:01.512146
# Unit test for constructor of class Section
def test_Section():
    my_section = Section("Attribute", "Att")
    assert my_section.title == "Attribute"
    assert my_section.key == "Att"
    assert my_section.title_pattern == "^({})\s*?\n{}\s*$".format(
        my_section.title, "-" * len(my_section.title)
    )


# Generated at 2022-06-23 17:11:07.540442
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "Deprecated"
    key = "deprecation"
    section = _SphinxSection(title, key)

    assert section.title == title
    assert section.key == key
    assert section.title_pattern == r"^\.\.\s*(Deprecated)\s*::"

# Generated at 2022-06-23 17:11:15.258488
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("Section", "key"))
    text = """Section
-----------
value
"""
    assert parser.parse(text) == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(
                args=["key"],
                description="value",
            )
        ],
    )

# Generated at 2022-06-23 17:11:19.119443
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydoc_parser = NumpydocParser()
    section_to_add = Section("Fake Section", "fake_section")
    numpydoc_parser.add_section(section_to_add)
    assert section_to_add in numpydoc_parser.sections.values()

# Generated at 2022-06-23 17:11:21.676326
# Unit test for constructor of class _KVSection
def test__KVSection():
    title = "parameter"
    key = "key"
    test = _KVSection(title, key)
    assert(test.title == title)
    assert(test.key == key)

# Generated at 2022-06-23 17:11:34.514161
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    '''
    unit test for method parse of class _KVSection
    '''

# Generated at 2022-06-23 17:11:39.857895
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    npdp = NumpydocParser(sections=None)
    section = Section('Unit Test', 'ut')
    npdp.add_section(section)
    assert npdp.sections['Unit Test'].title == 'Unit Test'
    assert npdp.sections['Unit Test'].key == 'ut'
    npdp = NumpydocParser(sections=None)

# Generated at 2022-06-23 17:11:45.941573
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert_str = "Returns"
    assert_key = "returns"
    assert_is_generator = False
    classObj = ReturnsSection(assert_str,assert_key)
    assert_result = classObj.title == assert_str
    assert_result = classObj.key == assert_key
    assert_result = classObj.is_generator == assert_is_generator
    assert_result = classObj.title_pattern == r"^(Returns)\s*?\n{}\s*$".format(
        "-" * len(assert_str)
        )
    return "test success"

# Generated at 2022-06-23 17:11:48.228511
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    DeprecationSection("deprecated", "deprecation")


# Generated at 2022-06-23 17:11:53.863488
# Unit test for constructor of class _KVSection
def test__KVSection():
    s = _KVSection("a","b")
    print(s.title)
    print(s.key)
    print(s.title_pattern)
    assert s.title=="a"
    assert "b"==s.key
    assert "^(a)\s*?\n----\s*$" == s.title_pattern

# Generated at 2022-06-23 17:11:55.513602
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    a = _SphinxSection('a', 'b')


# Generated at 2022-06-23 17:12:05.972308
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():

    empty_string = ""
    filled_string = "foo"
    none_value = None
    filled_value = "foo"
    ReturnsSection = ReturnsSection("Returns","returns")

    filled_text = "return_name : type\n description\n Return names are optional, types are required"
    empty_text = filled_text[:10]
    
    # Unit test for the method parse()
    def test_parse(self):
        filled_return = ReturnsSection.parse(self, filled_text)
        empty_return = ReturnsSection.parse(self, empty_text)
        assert filled_return is not None
        assert empty_return is not None

# Generated at 2022-06-23 17:12:08.656538
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises = RaisesSection("Raises", "raises")
    assert raises.__class__.__name__ == "RaisesSection"

# Generated at 2022-06-23 17:12:12.065261
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert str(next(DeprecationSection("deprecated", "deprecation").parse("0.2.2\n\nSome description."))) == "deprecation: 0.2.2\nSome description."


# Generated at 2022-06-23 17:12:17.070788
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    try:
        raises = RaisesSection("This is the section title", "my argument")
        print("PASSED")
    except AssertionError as e:
        print("FAILED")
        print(str(e))


# Generated at 2022-06-23 17:12:24.157991
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    """Numpydoc-style docstring parser."""
    test_obj = RaisesSection("Raises", "raises")
    assert test_obj.title == "Raises"
    assert test_obj.key == "raises", "The key should be raises"
    assert test_obj.title_pattern == "^Raises\s*?\n-*$"
    assert isinstance(test_obj,_KVSection)
    assert isinstance(test_obj,Section)


# Generated at 2022-06-23 17:12:32.778597
# Unit test for constructor of class Section
def test_Section():
    # Zero param.
    sec = Section()
    assert(sec == None)
    # One param
    sec = Section('parameters')
    assert(sec == None)
    # Three params
    sec = Section('parameters', 'param', 'parameters')
    assert(sec == None)
    # Two params
    sec = Section('parameters', 'param')
    assert(sec != None)
    assert(sec.title == 'parameters')
    assert(sec.key == 'param')

section = Section('Parameters', 'param' )


# Generated at 2022-06-23 17:12:45.438386
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():

    def _parse_item(key: str, value: str) -> DocstringParam:
        return DocstringParam(
            args=[self.key, key],
            description=_clean_str(value),
            arg_name=key,
            type_name="int",
            is_optional=True,
            default=None,
        )

    section = ParamSection("Other Parameters", "other_param")
    section._parse_item = _parse_item
    parser = NumpydocParser()
    parser.add_section(section)

    docstr = """
        Other Parameters
        ----------------
        arg_name
            arg_description
        arg_2 : int, optional
            descriptions can also span...
            ... multiple lines
    """

    result = parser.parse(inspect.cleandoc(docstr))
    expected = Docstring

# Generated at 2022-06-23 17:12:48.042829
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert (RaisesSection('Raises','raises').title == 'Raises')
    assert (RaisesSection('Raises','raises').key == 'raises')


# Generated at 2022-06-23 17:12:54.112328
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section=_SphinxSection("xx","yy")
    assert section.title=="xx"
    assert section.key=="yy"
    assert section.title_pattern==r"^\.\.\s*(xx)\s*::"

if __name__ == "__main__":
    test__SphinxSection()

# Generated at 2022-06-23 17:13:04.266693
# Unit test for constructor of class Section
def test_Section():
    title = 'Parameters'
    key = 'param'
    title_pattern = r"^({})\s*?\n{}\s*$".format(title,
        "-" * len(title))
    section = Section(title, key) 
    assert section.title == title
    assert section.key == key
    assert section.title_pattern == title_pattern
    assert section.parse(title + "\n" + "-" * len(title)) == DocstringMeta(
        [key], description=None)
    assert section.parse("what") == DocstringMeta([key], description='what')
    assert section.parse("") == DocstringMeta([key], description=None)


# Generated at 2022-06-23 17:13:09.758055
# Unit test for method parse of class Section
def test_Section_parse():

    text = "Example\n---------\n\nExample1\nExample1\n"

    # Create Section instance
    section = Section("Example", "example")

    # Call parse method
    docstring_meta_list = section.parse(text)

    # Asserts
    docstring_meta = list(docstring_meta_list)[0]
    assert docstring_meta.args == ["example"]
    assert docstring_meta.description == "Example1\nExample1"



# Generated at 2022-06-23 17:13:11.197182
# Unit test for constructor of class _KVSection
def test__KVSection():
    meta = _KVSection('test', 'params')
    assert meta.title == 'test'
    assert meta.key == 'params'

# Generated at 2022-06-23 17:13:22.775726
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """Test the method add_section of class NumpydocParser"""
    text = (
        '''
        This is a test string
        .. versionchanged:: 1.3
            Raise a ``ValueError`` if `dtype` is an :class:`~numpy.dtype` subclass.
        '''
    )
    sections = {}
    sections["versionchanged"] = Section(
        title="versionchanged", key="versionchanged"
    )
    sections["versionadded"] = Section(title="versionadded", key="versionadded")
    NumpydocParser(sections).add_section(
        Section(title="versionchanged", key="versionchanged")
    )
    assert NumpydocParser(sections).parse(text).meta[0].args == (
        "versionchanged",
        "1.3",
    )

# Generated at 2022-06-23 17:13:30.803677
# Unit test for function parse
def test_parse():
    shownotes = "This is some shownotes"
    assert parse(shownotes) == Docstring(short_description=shownotes)

    test1_description = "This is a long description, of a function."
    test1 = shownotes + "\n\n" + test1_description
    assert parse(
        test1
    ) == Docstring(
        short_description=shownotes,
        long_description=test1_description,
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    test2_description = "This is the second line of the description."
    test2 = shownotes + "\n\n" + test2_description + "\n\n"

# Generated at 2022-06-23 17:13:36.799544
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
.. deprecated:: 0.15
    Use ``f1_score(y_true, y_pred, labels=None, pos_label=1,
            average='binary', sample_weight=None)``

    .. deprecated:: 0.17
        ``None`` is deprecated and ``'binary'`` is the
        default value.
"""
    section = DeprecationSection("deprecated", "deprecated")


# Generated at 2022-06-23 17:13:44.585989
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    This is a docstring.

    Parameters
    ----------
    num1: int
        The first number
    num2: number, optional
        The second number (default is 0)
    """
    d = NumpydocParser().parse(text)
    assert d.short_description == "This is a docstring."
    assert d.long_description == "The first number"
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == True
    # Test for parsed parameter num1
    assert [meta.args for meta in d.meta if meta.args[0]=='param'][0][1] == 'num1'
    assert [meta.type_name for meta in d.meta if meta.args[0]=='param'][0] == 'int'

# Generated at 2022-06-23 17:13:55.833253
# Unit test for function parse

# Generated at 2022-06-23 17:14:00.961003
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = '''
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    '''

    s = _KVSection("title", "key")
    print(s.parse(text))


if __name__ == "__main__":
    test__KVSection_parse()

# Generated at 2022-06-23 17:14:03.757353
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    a='a \n b \n c \n \n a \n b \n c'
    assert(len(list(ParamSection._KVSection.parse(a)))==2)

# Generated at 2022-06-23 17:14:12.577360
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
  # Positive case.
  text = "ValueError\n" + \
         "  A description of what might raise ValueError" + \
         "\n\n" + \
         "TypeError\n" + \
         "  A description of what might raise TypeError"
  raise_section = RaisesSection("Raises", "raises")
  meta = raise_section.parse(text)
  meta_list = list(meta)
  assert len(meta_list) == 2
  assert meta_list[0].type_name == "ValueError"
  assert meta_list[0].description == \
         "A description of what might raise ValueError"
  assert meta_list[1].type_name == "TypeError"
  assert meta_list[1].description == \
         "A description of what might raise TypeError"
  #

# Generated at 2022-06-23 17:14:16.411538
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    section = Section("Section", "section")
    parser.add_section(section)
    s = parser.sections["Section"]
    assert(s == section)


# Generated at 2022-06-23 17:14:18.927010
# Unit test for constructor of class Section
def test_Section():
    sec = Section("Example", "examples")
    assert sec.title == "Example"
    assert sec.key == "examples"


# Generated at 2022-06-23 17:14:21.646587
# Unit test for constructor of class ParamSection
def test_ParamSection():
    title = "Params"
    m = ParamSection(title, "param")
    assert(m)


# Generated at 2022-06-23 17:14:30.778165
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    input = """Summary line.

Extended description of function.

Parameters
----------
param1 : int
    Description of `param1`.
param2 : str
    Description of `param2`.

Returns
-------
bool
    Description of return value.

"""

# Generated at 2022-06-23 17:14:43.383318
# Unit test for constructor of class ParamSection
def test_ParamSection():
    """
    Test case for the constructor of ParamSection class. It is expected to
    initialize the object with the following:
    :param title: section title. For most sections, this is a heading like
                  "Parameters" which appears on its own line, underlined by
                  en-dashes ('-') on the following line.
    :param key: meta key string. In the parsed ``DocstringMeta`` instance this
                will be the first element of the ``args`` attribute list.
    """
    try:
        section = ParamSection("Parameters", "param")
        assert section.title == 'Parameters'
        assert section.key == 'param'
    except AssertionError:
        print("test_ParamSection FAILED")
        return
    print("test_ParamSection PASSED")


# Generated at 2022-06-23 17:14:50.617175
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert len(parser.sections) == 41
    assert isinstance(parser.sections["Parameters"], ParamSection)
    assert isinstance(parser.sections["Params"], ParamSection)
    assert isinstance(parser.sections["Arguments"], ParamSection)
    assert isinstance(parser.sections["Args"], ParamSection)
    assert isinstance(parser.sections["Other Parameters"], ParamSection)
    assert isinstance(parser.sections["Other Params"], ParamSection)
    assert isinstance(parser.sections["Other Arguments"], ParamSection)
    assert isinstance(parser.sections["Other Args"], ParamSection)
    assert isinstance(parser.sections["Receives"], ParamSection)
    assert isinstance(parser.sections["Receive"], ParamSection)
    assert isinstance(parser.sections["Raises"], RaisesSection)

# Generated at 2022-06-23 17:14:54.132535
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    # test for constructor with title "deprecated" and key "deprecation"
    assert DeprecationSection("deprecated", "deprecation").__dict__ == {"title": "deprecated", "key": "deprecation"}

# Generated at 2022-06-23 17:15:02.724199
# Unit test for function parse
def test_parse():
    r = parse("""
        A test docstring to check parsing.

        Parameters
        ----------
        testparam1
            description of testparam1
        testparam2 : int, optional (default=3)
            description of int line 1
            description of int line 2
        testparam3 : int, optional (default=42)
            description of int line 1
            description of int line 2

        Returns
        -------
        out1 : int
            description of out1
        out2 : int
            description of out2
        """)

    _s = lambda x: None if x is None else x.strip()
    _p = lambda x: _s(x) if x else None

    assert _s(r.short_description) == "A test docstring to check parsing."
    assert r.blank_after_short_description == True

# Generated at 2022-06-23 17:15:04.830371
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r = RaisesSection("Keys", "keys")
    k = "key"
    value = "v"
    r._parse_item(k, value)

# Generated at 2022-06-23 17:15:09.565893
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    test_section = Section("Test", "test")
    numpy_parser = NumpydocParser()
    numpy_parser.add_section(test_section)
    assert len(numpy_parser.sections) == len(DEFAULT_SECTIONS) + 1

# Generated at 2022-06-23 17:15:22.028789
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test file
    filename = "../" + "samples/pandas/pandas._libs/reshape.py"
    # Read text
    with open(filename, "r") as file:
        text = file.read()
    # Parse
    parser = NumpydocParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "stack Format a DataFrame as stacked."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.long_description == "This function provides a way to unstack the\nSeries into the DataFrame with multi-level index."
    assert docstring.meta[0].args == ["param", "invar"]

# Generated at 2022-06-23 17:15:30.467873
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # test with null text
    assert NumpydocParser().parse("") == Docstring()

    # test with a short text
    assert NumpydocParser().parse("this is a short text") == Docstring(
        short_description="this is a short text"
    )

    # test with the  pydocstyle's docstring example

# Generated at 2022-06-23 17:15:33.846503
# Unit test for constructor of class Section
def test_Section():
    section = Section("Parameters", "param")
    # check __init__
    assert section.title == "Parameters"
    assert section.key == "param"
    

# Generated at 2022-06-23 17:15:36.497086
# Unit test for method parse of class Section
def test_Section_parse():
    result = DocstringMeta([''], description=None)
    assert Section('title', 'key').parse('text') == [result]


# Generated at 2022-06-23 17:15:37.089765
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ParamSection("Parameters", "param")


# Generated at 2022-06-23 17:15:38.946032
# Unit test for constructor of class Section
def test_Section():
    sec = Section("Parameters", "param")
    assert sec.title == "Parameters"
    assert sec.key == "param"


# Generated at 2022-06-23 17:15:43.000731
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    d = _SphinxSection("title", "key")
    assert(d.key == "key")
    assert(d.title == "title")
    assert(d.title_pattern == r"^\.\.\s*(title)\s*::")


# Generated at 2022-06-23 17:15:50.252820
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    '''
    Test if the constructor of class RaisesSection is working.
    Test by checking if the string title and key are correctly
    extracted from the given parameters.
    '''
    assert RaisesSection("Raises", "raises").title == "Raises"
    assert RaisesSection("Raises", "raises").key == "raises"


# Generated at 2022-06-23 17:15:53.889557
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # test constructor
    obj = RaisesSection('Raises', 'raises')
    assert obj.key == 'raises'
    assert obj.title == 'Raises'


# Generated at 2022-06-23 17:16:00.185247
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    example = """
    Raises:
          ValueError: If a callable is given a ``store_locally`` attribute.
    """
    def test(example):
        if True:
            raise ValueError('If a callable is given a ``store_locally`` attribute.')
    try:
        test(example)
    except ValueError as e:
        section = RaisesSection('Raises', 'raises')
        list_meta = list(section.parse(example))
        if list_meta[0].type_name == 'ValueError' and list_meta[0].description == 'If a callable is given a ``store_locally`` attribute.' and list_meta[0].description is not None:
            print('RaisesSection [Passed]')
            assert True
        else:
            print('RaisesSection [Failed]')