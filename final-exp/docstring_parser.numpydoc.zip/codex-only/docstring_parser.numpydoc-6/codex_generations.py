

# Generated at 2022-06-23 17:06:00.017499
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = NumpydocParser()
    section = parser.sections["deprecated"]
    example = [". .. deprecated:: 1.0\n  Deprecation Warning"]
    result = section.parse(example[0])
    expected = [
        DocstringDeprecated(
            args=["deprecation"], description=" Deprecation Warning", version="1.0"
        )
    ]
    assert list(result) == expected



# Generated at 2022-06-23 17:06:07.325268
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section_class = type(
        "_KVSection",
        (_KVSection,),
        {"_parse_item": lambda self, key, value: DocstringMeta([self.key, key], description=value)},
    )
    section = section_class("Parameters", "param")
    docstring = inspect.cleandoc(
        """
    arg1
        arg1's description
    arg2
        arg2's description which can be multiline

    arg3
        arg3's description
    """
    )

# Generated at 2022-06-23 17:06:14.270643
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text='Attribute\n\n'
    parser=_KVSection('Attribute','attribute')
    result=parser.parse(text)
    try:
        assert repr(result) == repr([])
        print(repr(result))
        print("Test passed")
        return True
    except AssertionError as e:
        print(e)
        return False


# Generated at 2022-06-23 17:06:17.183196
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section("Title", "key")
    meta = s.parser("""Content""")
    assert meta.description == "Content"
    assert meta.args[0] == "key"
    assert len(meta.args) == 1



# Generated at 2022-06-23 17:06:20.005186
# Unit test for constructor of class ParamSection
def test_ParamSection():
    section = ParamSection("Attributes", "attribute")
    assert section.title == "Attributes"
    assert section.key == "attribute"


# Generated at 2022-06-23 17:06:23.242570
# Unit test for constructor of class Section
def test_Section():
    title = "parameters"
    key = "param"
    s = Section(title, key)
    assert s.title == title
    assert s.key == key



# Generated at 2022-06-23 17:06:33.766791
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc("""
    This function does something.

    Parameters
    ----------
    param_1 : str
        A string param.
    param_2 : int, optional
        An optional int param.
    """)

    parsed = parse(text)
    # print(parsed)

    assert parsed.short_description == "This function does something."
    assert parsed.meta[0].args == ["param", "param_1"]
    assert parsed.meta[1].args == ["param", "param_2"]

    assert parsed.meta[0].type_name == "str"
    assert parsed.meta[1].type_name == "int"
    assert parsed.meta[1].is_optional

# Generated at 2022-06-23 17:06:37.137537
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    test_text = """
    arg_name
        arg_description
    """
    arg = _KVSection.parse(text=test_text)
    assert arg.split() == ['arg_name', 'arg_description']


# Generated at 2022-06-23 17:06:45.325076
# Unit test for function parse
def test_parse():
    # Test for the default parser
    func_text = """
    Test Function

    This is the long description

    Parameters
    ----------
    a : int
        required argument
        can span multiple lines
    b : float, optional
        defaults to `1`
    c : float, optional. Default is 1
        another way to specify the default

    Returns
    -------
    int
        return value
    """
    d = parse(func_text)
    assert d.short_description == "Test Function"
    assert len(d.meta) == 3
    assert d.meta[0].args == ['param', 'a']
    assert d.meta[0].description == "required argument\ncan span multiple lines"
    assert d.meta[1].args == ['param', 'b']
    assert d.meta[1].description == None
   

# Generated at 2022-06-23 17:06:50.337415
# Unit test for constructor of class _KVSection
def test__KVSection():
    s = _KVSection(title='fake_title', key='fake_key')
    assert s.title == 'fake_title'
    assert s.key == 'fake_key'
    assert s.title_pattern == '([f]ake[\s][t]itle)'


# Generated at 2022-06-23 17:06:52.797578
# Unit test for constructor of class _KVSection
def test__KVSection():
    parser = ParamSection
    parser = ParamSection('title', 'key')
    assert parser.title == 'title'
    assert parser.key == 'key'


# Generated at 2022-06-23 17:06:53.888003
# Unit test for method parse of class Section
def test_Section_parse():
    pass


# Generated at 2022-06-23 17:07:03.088292
# Unit test for method parse of class Section
def test_Section_parse():
    text_1 =  """this is a test section
                - this is a test section
                - this is a test section"""
    text_2 =  """this is a test section
                this is a test section
                this is a test section"""
    test_instance = Section(title='a title', key='a key')

    result_1 = list(test_instance.parse(text_1))[0].description
    assert result_1 == 'this is a test section'

    result_2 = list(test_instance.parse(text_2))[0].description
    assert result_2 == 'this is a test section'

    assert 1


# Generated at 2022-06-23 17:07:11.646180
# Unit test for method parse of class Section
def test_Section_parse():
    sections = [
        Section("Parameters", "param"),
        Section("Other Parameters", "other_param"),
        Section("Raises", "raises"),
        Section("Warns", "warns"),
        Section("Returns", "returns"),
        Section("Yields", "yields"),
        Section("Examples", "examples"),
        Section("Warnings", "warnings"),
        Section("Notes", "notes"),
        Section("References", "references"),
        DeprecationSection("deprecated", "deprecation"),
    ]
    parser = NumpydocParser(sections)

# Generated at 2022-06-23 17:07:16.519139
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yield_sect = YieldsSection("Yields", "yields")
    assert yield_sect.is_generator
    assert not yield_sect.title == "Yield"
    assert not yield_sect.key == "Return"

# Generated at 2022-06-23 17:07:20.565794
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    test_YieldsSection = YieldsSection("Yields", "yields")
    test_YieldsSection.is_generator = False
    assert test_YieldsSection.is_generator == False


# Generated at 2022-06-23 17:07:28.963751
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = NumpydocParser()
    parser.add_section(DeprecationSection("Deprecated", "deprecation"))
    text = "Deprecated since version 1.23.4: Use of this function will throw an \
Error in the future.\n\nThis function is deprecated since version 1.23.4. \
Use of this function will throw an Error in the future."
    docstring = parser.parse(text)
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args[0] == "deprecation"
    assert docstring.meta[0].args[1] == "1.23.4"

if __name__ == "__main__":
    test_DeprecationSection_parse()

# Generated at 2022-06-23 17:07:30.620485
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    result = DeprecationSection("title", "key").__init__()
    assert result is not None


# Generated at 2022-06-23 17:07:36.682752
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    import numpydoc_parser
    
    numpydoc_parser.NumpydocParser().parse("""This function does something.

Parameters
----------
x : int
    The first value.
y : int
    The second value.

Returns
-------
z : int
    The sum of ``x`` and ``y``.
""")



# Generated at 2022-06-23 17:07:42.526570
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    _kv = _KVSection(title="testTitle", key="testKey")
    text = "key\n    value\nkey2 : type\n    values can also span...\n    ... multiple lines"
    res = _kv.parse(text)

    assert res is not None
    assert next(res).description == "value"

    assert next(res).description == "values can also span...\n    ... multiple lines"

# Generated at 2022-06-23 17:07:50.515688
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    n = NumpydocParser()
    assert len(n.sections) == 32
    assert list(n.sections.keys()) == ['Parameters', 'Params', 'Arguments', 'Args', 'Other Parameters', 'Other Params', 'Other Arguments', 'Other Args', 'Receives', 'Receive', 'Raises', 'Raise', 'Warns', 'Warn', 'Attributes', 'Attribute', 'Returns', 'Return', 'Yields', 'Yield', 'Examples', 'Example', 'Warnings', 'Warning', 'See Also', 'Related', 'Notes', 'Note', 'References', 'Reference', 'deprecated']
    assert isinstance(next(iter(n.sections.values())), Section)

# Generated at 2022-06-23 17:08:01.705431
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Tests the parse method of NumpyDocParser class."""
    # mock data
    short_desc = "This is short description"
    long_desc = "This is long description. This is long description.  This is long description."
    meta_chunk = """
    Parameters
    ----------
    production_year : int
        The year of the film release."""

    ret = Docstring()
    ret.short_description = short_desc
    ret.long_description = long_desc
    ret.meta.extend([DocstringMeta(args = ['param', 'production_year'], arg_name = 'production_year', type_name = 'int', description = 'The year of the film release.', is_optional = False, default = None)])


# Generated at 2022-06-23 17:08:09.892372
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    class NewSection(Section):
        def __init__(self):
            Section.__init__(self, "New", "new")
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            yield DocstringMeta([self.key], description=_clean_str(text))
    
    sections = DEFAULT_SECTIONS[:]
    sections.append(NewSection())
    np = NumpydocParser(sections)
    class TestClass:
        """This is a NumpydocParser test.
        
        This is a test body.
        
        .. New::
            More text.
            
        Other text.
        """
        pass
    test_docstring = TestClass.__doc__

# Generated at 2022-06-23 17:08:19.105098
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yields", "yields")
    assert ys.title == "Yields"
    assert ys.key == "yields"
    assert ys.title_pattern == r"^\.\.\s*Yields\s*::"
    assert ys.is_generator == True
    ys1 = YieldsSection("Yielded", "yielded")
    assert ys1.title == "Yielded"
    assert ys1.key == "yielded"
    assert ys1.title_pattern == r"^\.\.\s*Yielded\s*::"
    assert ys1.is_generator == True


# Generated at 2022-06-23 17:08:31.128694
# Unit test for constructor of class NumpydocParser

# Generated at 2022-06-23 17:08:42.567136
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .examples import numpydoc_example1, numpydoc_example2
    parser = NumpydocParser()

# Generated at 2022-06-23 17:08:46.166361
# Unit test for constructor of class Section
def test_Section():
    title = 'Args'
    key = 'param'
    section = Section(title, key)
    assert section.title == title
    assert section.key == key


# Generated at 2022-06-23 17:08:53.727957
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # Test to see if the constructor of the class RaisesSection works
    raises_section = RaisesSection('Raises', 'raises')
    assert raises_section.title == 'Raises'
    assert raises_section.key == 'raises'
    # Test to see if the constructor of the class RaisesSection fails
    raises_section = RaisesSection('Raises', 'raises')
    assert raises_section.title == 'Raises'
    assert raises_section.key == 'rais'


# Generated at 2022-06-23 17:08:55.635345
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    check_returns = ReturnsSection("Returns", "returns")
    check_returns.parse()

# Generated at 2022-06-23 17:09:03.042981
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # Arrange
    # Act
    parser = NumpydocParser()
    text = ".. deprecated:: 0.5\n   This is a description"
    sections = parser.parse(text)
    # Assert
    assert len(sections.meta) > 0
    assert sections.meta[0].args == ['deprecation']
    assert sections.meta[0].description == "This is a description"
    assert sections.meta[0].version == "0.5"


# Generated at 2022-06-23 17:09:05.003545
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    #print(help(DeprecationSection))
    pass



# Generated at 2022-06-23 17:09:14.023455
# Unit test for function parse
def test_parse():
    import pytest


# Generated at 2022-06-23 17:09:18.998373
# Unit test for constructor of class _KVSection
def test__KVSection():
    kv = _KVSection("test", "test")
    assert kv.__repr__() == "<_KVSection title=test>"
    assert kv.__str__() == "test"
    assert kv.__bool__() is True


# Generated at 2022-06-23 17:09:27.023620
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert DeprecationSection("deprecated", "deprecation").parse("1.0.0\nFoo") == [DocstringDeprecated(["deprecation"], "Foo", "1.0.0")]
    assert DeprecationSection("deprecated", "deprecation").parse("1.0.0") == [DocstringDeprecated(["deprecation"], None, "1.0.0")]
    assert DeprecationSection("deprecated", "deprecation").parse("1.0.0\n\n") == [DocstringDeprecated(["deprecation"], None, "1.0.0")]


# Generated at 2022-06-23 17:09:31.942133
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():

    return_section = ReturnsSection("Returns", "returns")
    assert return_section.is_generator == False

    yield_section = YieldsSection("Yields", "yields")
    assert yield_section.is_generator == True

# Generated at 2022-06-23 17:09:41.582016
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # KV_REGEX
    assert re.search(KV_REGEX, "a b c\n").span() == (0, 3)
    assert re.search(KV_REGEX, "\na b c\n").span() == (1, 4)
    assert re.search(KV_REGEX, "a b c\n\n") is None
    assert re.search(KV_REGEX, "\n") is None
    assert re.search(KV_REGEX, "\na b c d").span() == (1, 8)
    assert re.search(KV_REGEX, "\na b c d\n") is None
    assert re.search(KV_REGEX, "\na b c d\n") is None

    # key-value item

# Generated at 2022-06-23 17:09:45.270461
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raisesSection = RaisesSection("Raises", "raises")
    assert raisesSection.title == "Raises"
    assert raisesSection.key == "raises"


# Generated at 2022-06-23 17:09:56.269699
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = {
        'Raises': RaisesSection('Raises', 'raises'),
    }
    doc_parser = NumpydocParser(sections)

    sample_docstring = """
    Raises
        ValueError
            A description of what might raise ValueError
    """
    sample_docstring = inspect.cleandoc(sample_docstring)
    sample_docstring = doc_parser.titles_re.split(sample_docstring)
    assert doc_parser.sections['Raises'] == doc_parser.sections['Raises']
    # assert sample_docstring == NumpydocParser(sections).titles_re.split(sample_docstring)

if __name__ == "__main__":
    test_NumpydocParser()

# Generated at 2022-06-23 17:10:02.499818
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    example = """ValueError
    A description of what might raise ValueError"""
    parse_rs = RaisesSection("Raises", "raises")
    parse_rs.parse(example)
    # In the class RaisesSection, the attribute self.key is "raises"
    # and the attribute self.title is "Raises".
    # Define expected to be the DocstringRaises expected to be returned
    expected = DocstringRaises(["raises",  "ValueError"], "A description of what might raise ValueError", type_name = "ValueError")
    # for loop to check if the expected is equal to the output
    for i in parse_rs.parse(example):
        assert i == expected


# Generated at 2022-06-23 17:10:03.789990
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser is not None

# Generated at 2022-06-23 17:10:12.121290
# Unit test for function parse
def test_parse():
    text = '''
    Parameters
    ----------
    request : :class:`~rest_framework.request`, optional
       The incoming request object
    a : int
        The first argument
    b : str, optional
        The second argument
    user : :class:`~rest_framework.User`, optional
        The third argument
    kwargs : key-word only arguments
        A summary of the keyword-only arguments

    Returns
    -------
    success : bool
        A Boolean, True if successful
    '''
    result = parse(text)
    assert isinstance(result, Docstring)
    assert isinstance(result.short_description, str)
    assert result.short_description == ''
    assert isinstance(result.long_description, str)
    assert result.long_description == ''
    assert result.blank_after_short_

# Generated at 2022-06-23 17:10:17.347190
# Unit test for constructor of class Section
def test_Section():
    # Test constructor of class Section
    section = Section('Example Code', 'example')
    assert section.title_pattern == '^(Example Code)\s*?\n-----\s*$'
    assert section.parse('example code') == [DocstringMeta(['example'], description='example code')]



# Generated at 2022-06-23 17:10:22.379883
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydoc_parser = NumpydocParser()
    new_section = Section("Author", "author")
    numpydoc_parser.add_section(new_section)
    assert numpydoc_parser.sections["Author"] == new_section
    assert len(numpydoc_parser.sections) == len(DEFAULT_SECTIONS) + 1
    assert numpydoc_parser.titles_re.match("Author\n-----")

# Generated at 2022-06-23 17:10:29.840400
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
        a
            b
        c : d
            e
        f : g, optional
            h
    """
    section = _KVSection('Section','None')
    key_value_pairs = section.parse(text)

    assert next(key_value_pairs) == ('a','b')
    assert next(key_value_pairs) == ('c','d')
    assert next(key_value_pairs) == ('f','g, optional')


# Generated at 2022-06-23 17:10:30.890039
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    NumpydocParser()


# Generated at 2022-06-23 17:10:35.026866
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ps = ParamSection("Parameters", "param")
    assert ps.title == "Parameters"
    assert ps.key == "param"
    assert ps.title_pattern == '^Parameters\s*?\n---*$'

# Generated at 2022-06-23 17:10:39.199279
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()

    # add new section
    title = "TEST"
    section = Section(title, "TEST")
    parser.add_section(section)
    assert parser.sections[title] == section

    # replace old section
    section = Section('Example', "Example")
    parser.add_section(section)
    assert parser.sections['Example'] == section

# Generated at 2022-06-23 17:10:45.292677
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises_section=RaisesSection('Raises','raises')
    assert raises_section.title == 'Raises'
    assert raises_section._parse_item('test','test') == DocstringRaises(
            args=['raises','test'], description='test', type_name='test')

# Generated at 2022-06-23 17:10:46.685211
# Unit test for constructor of class Section
def test_Section():
    pass


# Generated at 2022-06-23 17:10:51.859899
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = ".. deprecated:: 1.4.0\n    Use :func:`decoder` instead."
    s = DeprecationSection("deprecated", "deprecation")
    ret = s.parse(text)
    print(ret)
    assert ret[0].description == "Use :func:`decoder` instead."
    assert ret[0].version == "1.4.0"

# Generated at 2022-06-23 17:10:55.228852
# Unit test for constructor of class Section
def test_Section():
    section = Section('Parameters', 'param')
    assert section.title == 'Parameters'
    assert section.key == 'param'
    assert section.title_pattern == '^Parameters\s*?\n----\s*$'


# Generated at 2022-06-23 17:11:00.476595
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    """Test DeprecationSection.__init__() method
    
    If initiliztion succeeds, the attribute "title" is "deprecated" and the attribute "key" is "deprecation"
    """
    deprecationSection = DeprecationSection("deprecated", "deprecation")
    assert (deprecationSection.title == "deprecated") and (deprecationSection.key == "deprecation")


# Generated at 2022-06-23 17:11:03.517836
# Unit test for constructor of class ParamSection
def test_ParamSection():
    factory = ParamSection("Parameters", "param")
    assert factory.title == "Parameters"
    assert factory.key == "param"

# Generated at 2022-06-23 17:11:08.767847
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    a = _SphinxSection("a", "b")
    assert (a.title == "a")
    assert (a.key == "b")
    assert (a.title_pattern == "^\.\.\\s*(a)\\s*::")


# Generated at 2022-06-23 17:11:19.580784
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # create raises section with a title and a comment
    raises_section = RaisesSection("Raises", "raises")
    # create new text variable and set the text variable to the desired string
    text = "ValueError\n A description of what might raise ValueError"
    # retrieve the required docstring_meta object
    doc = raises_section.parse(text)
    # type(doc) returns a generator, so convert it to a list to get the actual value
    doc = list(doc)
    # assert that the length of the list is 1
    assert(len(doc) == 1)
    # get the actual value of doc
    doc = doc[0]
    # assert that the args is a list of strings
    assert(type(doc.args) == list)
    # assert that the length of the args is 2

# Generated at 2022-06-23 17:11:23.757266
# Unit test for constructor of class _KVSection
def test__KVSection():

    # Test the initilization of _KVSection
    title = "titleA"
    key = "keyA"
    section = _KVSection(title, key)

    assert isinstance(section, _KVSection)
    assert section.title == "titleA"
    assert section.key == "keyA"
    assert section.title_pattern == r"^(titleA)\s*?\n-----\s*$"


# Generated at 2022-06-23 17:11:36.170542
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()

# Generated at 2022-06-23 17:11:39.749194
# Unit test for constructor of class _KVSection
def test__KVSection():
    x = _KVSection("Parameters", "param")
    assert x.title == "Parameters"
    assert x.key == "param"


# Tests for _KVSection.parse()
# Tests that parse() yields no elements when the section text is empty

# Generated at 2022-06-23 17:11:42.885039
# Unit test for constructor of class ParamSection
def test_ParamSection():
    section = ParamSection("Parameters","param")
    assert section.title == "Parameters"
    assert section.key == "param"
    assert section.title_pattern == "^Parameters\s*?\n-*$"


# Generated at 2022-06-23 17:11:44.631536
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert "return" == DocstringParser().ReturnsSection(
        "Returns", "returns").key


# Generated at 2022-06-23 17:11:48.654720
# Unit test for constructor of class ParamSection
def test_ParamSection():
    section_default_parameters = ParamSection("Parameters", "param")
    assert section_default_parameters.title == "Parameters"
    assert section_default_parameters.key == "param"


# Generated at 2022-06-23 17:11:59.158220
# Unit test for function parse
def test_parse():
    # Param Section
    # Test 1
    doc_test1 = """Param
    blah blah blah description
    another description line
    Arg: arg1"""
    param = parse(doc_test1).meta
    assert len(param) == 1
    assert param[0].arg_name == "Param"
    assert param[0].description == "blah blah blah description\nanother description line\nArg: arg1"
    # Test 2
    doc_test2 = """Param : int, optional
    Another description line
    Arg: arg2"""
    param = parse(doc_test2).meta
    assert len(param) == 1
    assert param[0].arg_name == "Param"
    assert param[0].type_name == "int"
    assert param[0].is_optional == True

# Generated at 2022-06-23 17:12:04.519593
# Unit test for constructor of class Section
def test_Section():
    # Given
    expected_title='Test'
    expected_key='TestKey'
    # When
    actual_section = Section(title=expected_title, key=expected_key)

    # Then
    assert actual_section.title == expected_title
    assert actual_section.key == expected_key


# Generated at 2022-06-23 17:12:09.554031
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    parser = NumpydocParser()
    assert parser.sections['Yields'].is_generator == True
    assert parser.sections['Yield'].is_generator == True

if __name__ == "__main__":
    test_YieldsSection()

# Generated at 2022-06-23 17:12:16.461639
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    import unittest

    class DeprecationSectionParseTestCase(unittest.TestCase):
        """ Unit tests for method parse of class DeprecationSection. """

        def test_description_prefix_with_newline(self):
            factory = DeprecationSection("deprecated", "deprecation")
            text = '''.. deprecated:: 0.0.0
               this is a deprecated message
            '''
            meta = list(factory.parse(text))
            self.assertEqual(len(meta), 1)
            meta = meta[0]
            self.assertEqual(meta.args, ["deprecation"])
            self.assertEqual(meta.description, "this is a deprecated message")
            self.assertEqual(meta.version, "0.0.0")


# Generated at 2022-06-23 17:12:19.145515
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    dp = NumpydocParser()
    dp.add_section(Section("hello", "hello"))
    assert dp.sections.keys() == DEFAULT_SECTIONS + ['hello']
    dp.add_section(Section("hello", "world"))
    assert dp.sections.keys() == DEFAULT_SECTIONS + ['hello']
    assert dp.sections["hello"].key == 'world'


# Generated at 2022-06-23 17:12:20.078547
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    npdp = NumpydocParser()
    assert npdp is not None


# Generated at 2022-06-23 17:12:26.296749
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    test_data = "value\nvalue2\nvalue3"
    test_data = inspect.cleandoc(test_data)
    test_data = KV_REGEX.finditer(test_data)
    test_data = _pairwise(test_data)
    result = "value\nvalue2\nvalue3"
    result = inspect.cleandoc(result)
    result = KV_REGEX.finditer(result)
    result = _pairwise(result)
    assert test_data == result

# Generated at 2022-06-23 17:12:36.324016
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .reader import reader
    from .writer import writer

    text = """
        Page of documentation that describes the function.
        Can be short or long

        Parameters
        ----------
        x, y : int
            Description of x and y
        z (str, optional)
            Description of z

        Raises
        ------
        ValueError
            If the value is invalid, this is why.

        Returns
        -------
        int :
            The Sum of x and y

        See Also
        --------
        this, that
    """

    doc = reader.NumpydocReader().read(text)
    reparsed_text = writer.NumpydocWriter().write(doc)
    reparsed_doc = reader.NumpydocReader().read(reparsed_text)

    assert doc == reparsed_doc


# Unit

# Generated at 2022-06-23 17:12:40.609302
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    section = Section("Test", "test")
    parser.add_section(section)
    assert "Test" in parser.sections
    assert parser.sections["Test"] == section

# Generated at 2022-06-23 17:12:42.610589
# Unit test for constructor of class Section
def test_Section():
    section = Section("test","test")
    assert section.title == "test"
    assert section.key == "test"

# Generated at 2022-06-23 17:12:48.609902
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    a = "Returns"
    b = "Yield"
    c = "Yields"
    d = "Return"
    assert YieldsSection(a, b).is_generator == False
    assert YieldsSection(c, b).is_generator == True
    assert YieldsSection(a, d).is_generator == False
    assert YieldsSection(c, d).is_generator == False


# Generated at 2022-06-23 17:12:51.988709
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    d = DeprecationSection("Deprecated", "deprecated")
    assert d.title == "Deprecated"
    assert d.key == "deprecated"



# Generated at 2022-06-23 17:12:57.006268
# Unit test for method parse of class Section
def test_Section_parse():
    numpydoc_parser = NumpydocParser()
    docstring = '''Returns
        this
    '''
    docstring_parsed = numpydoc_parser.parse(docstring)
    assert docstring_parsed.meta == [DocstringMeta(['returns'], description='this')]


# Generated at 2022-06-23 17:13:03.736141
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # Create instance of class ParamSection
    paramSection = ParamSection("Parameters", "param")

    # Assert the title of the section
    assert paramSection.title == "Parameters"

    # Assert the key for the section
    assert paramSection.key == "param"
    
    # Assert the regular expression of the title
    assert paramSection.title_pattern == "^Parameters\s*?\n-{10}\s*$"


# Generated at 2022-06-23 17:13:04.739233
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r = RaisesSection('Raises','raises')

# Generated at 2022-06-23 17:13:12.231045
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:13:18.079021
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    deprecation_section = DeprecationSection("Deprecated", "deprecated")
    assert deprecation_section.title == "Deprecated"
    assert deprecation_section.key == "deprecated"
    assert deprecation_section.title_pattern == \
           "^\.\.\s*(Deprecated)\s*::"

# Generated at 2022-06-23 17:13:20.486682
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    ds = DeprecationSection('title', 'key')
    assert ds.title == 'title'
    assert ds.key == 'key'


# Generated at 2022-06-23 17:13:25.886884
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    class TestSection(_KVSection):
        def _parse_item(self, key: str, value: str) -> DocstringMeta:
            return DocstringMeta(
                args=["test"], description=_clean_str(value), name=key
            )
    parser = NumpydocParser({'test': TestSection('test', 'test')})
    doc = '.. test::\n   val1\n   val2'
    result = parser.parse(doc)
    assert len(result.meta) == 1
    assert result.meta[0].name == 'val1'
    assert result.meta[0].description == 'val2'

# Generated at 2022-06-23 17:13:27.874143
# Unit test for constructor of class Section
def test_Section():
    x = Section("name", "key")
    assert isinstance(x, Section)

# Generated at 2022-06-23 17:13:31.287751
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    import re
    pattern = DeprecationSection("","").title_pattern
    assert re.match("^\.\.\s*{}\s*::".format(""), pattern) is not None



# Generated at 2022-06-23 17:13:36.042639
# Unit test for constructor of class _KVSection
def test__KVSection():
    a = _KVSection("This is a title", "key")
    assert a._KVSection__title == "This is a title"
    assert a._KVSection__key == "key"
    assert a.title == "This is a title"
    assert a.key == "key"


# Generated at 2022-06-23 17:13:40.807031
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    # Arrange
    title = "Returns"
    key = "returns"
    is_generator = False

    # Act
    test_section = ReturnsSection(title, key)

    # Assert
    assert test_section.title == title
    assert test_section.key == key
    assert test_section.is_generator == is_generator


# Generated at 2022-06-23 17:13:42.730867
# Unit test for constructor of class Section
def test_Section():
    test_section = Section("Parameters", "param")
    assert test_section.title == "Parameters"
    assert test_section.key == "param"


# Generated at 2022-06-23 17:13:47.384473
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection("title", "key")
    assert s.title == "title"
    assert s.key == "key"
    assert s.title_pattern == r"^\.\.\s*(title)\s*::"


# Generated at 2022-06-23 17:13:50.899833
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    section=YieldsSection("Yields", "yields")
    assert section.title == "Yields"
    assert section.key == "yields"
    assert section.is_generator == True


# Generated at 2022-06-23 17:13:52.727554
# Unit test for constructor of class _KVSection
def test__KVSection():
    raise NotImplementedError("TODO")


# Generated at 2022-06-23 17:13:58.322872
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = [
        ParamSection("My Parameters", "my_param"),
        ParamSection("Second Params", "second_param"),
        ParamSection("Third Arguments", "third_param"),
        ParamSection("Fourth Args", "fourth_param"),
    ]
    testParser = NumpydocParser(sections)
    for section in testParser.sections.values():
        assert section is not None
        assert isinstance(section,Section)


# Generated at 2022-06-23 17:14:03.759233
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    assert tuple(_KVSection("sample title", "sample key").parse("key1\n value1\nkey2 : type2\nvalue2\n")) == (
        DocstringMeta(["sample key", "key1"], description="value1"),
        DocstringMeta(["sample key", "key2"], description="value2", type_name="type2"),
    )

# Generated at 2022-06-23 17:14:09.089359
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
	
	# Positive test

	# No arguments given
	test_RaisesSection_1 = RaisesSection("Raises", "raises")
	assert test_RaisesSection_1 is not None

	# Both arguments given
	test_RaisesSection_2 = RaisesSection("Raises", "warns")
	assert test_RaisesSection_2 is not None
	
	# Negative test
	
	try:
		test_RaisesSection_3 = RaisesSection("Raises", "blah")
		test_RaisesSection_4 = RaisesSection("Raises")
	except TypeError:
		assert True
	except:
		assert False



# Generated at 2022-06-23 17:14:21.535747
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    parser.add_section(Section("Unrelated", "unrelated"))
    docstring = parser.parse(
        """
        """
    )
    assert docstring.short_description == ""
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert docstring.long_description is None
    assert docstring.meta == []

    docstring = parser.parse(
        """
        Short description
        and
        more!
        """
    )
    assert docstring.short_description == "Short description"
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert docstring.long_description == "and\nmore!"
    assert docstring.meta == []

   

# Generated at 2022-06-23 17:14:31.393642
# Unit test for method parse of class Section
def test_Section_parse():
    # Section1 is a instance of a subclass of Section
    # which provides a parse method
    Section1 = Section("Parameters", "param")
    text = '''Parameters
    ----------
    arg1
        arg1 description
    arg2
        arg2 value can also span...
        ... multiple lines
    '''
    expected = [DocstringMeta(["param", "arg1"], description="arg1 description"),
                DocstringMeta(["param", "arg2"], description="arg2 value can also span...\n... multiple lines")]
    result = Section1.parse(text)
    result = list(result)
    assert result == expected

    # Section2 is a instance of a subclass of Section
    # which does not provide a parse method
    Section2 = Section("Parameters", "param")

# Generated at 2022-06-23 17:14:35.767414
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    deprecation = DeprecationSection("deprecated", "deprecation")
    assert deprecation.title == "deprecated"
    assert deprecation.key == "deprecation"



# Generated at 2022-06-23 17:14:42.203279
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    
    a = DeprecationSection("deprecated", "deprecation")
    
    assert a == DeprecationSection("deprecated", "deprecation")
    assert a.title == "deprecated"
    assert a.key == "deprecation"
    assert a.title_pattern == "^\.\.\s*deprecated\s*::"


# Generated at 2022-06-23 17:14:48.020186
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    new_section = ParamSection("New Section", "new_section")

    # Test if the new section is added to the parser
    assert new_section.title not in parser.sections
    parser.add_section(new_section)
    assert new_section.title in parser.sections

    # Test if the new section is placed in the correct position
    # in the title pattern
    assert "New Section" in parser.titles_re.pattern

# Generated at 2022-06-23 17:14:52.704767
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # test for title and key
    assert ParamSection(title="Parameters", key="param").title == "Parameters"
    assert ParamSection(title="Parameters", key="param").key == "param"
    print('Test for constructor of class ParamSection ... ok')


# Generated at 2022-06-23 17:15:01.851077
# Unit test for function parse
def test_parse():
    docstring = """\
        Parameters
        ----------
        x : int
            A simple parameter.
        y : str, optional
            A default parameter.
        """
    doc = parse(docstring)
    assert len(doc.meta) == 1
    param = doc.meta[0]
    assert isinstance(param, DocstringParam)
    assert param.arg_name == "x"
    assert param.type_name == "int"
    assert param.is_optional is False
    assert param.default is None
    param = doc.meta[1]
    assert isinstance(param, DocstringParam)
    assert param.arg_name == "y"
    assert param.type_name == "str"
    assert param.is_optional is True
    assert param.default is None
    assert len(doc.meta) == 2

# Generated at 2022-06-23 17:15:03.981309
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    sec = _SphinxSection('title', 'key')
    assert sec.title == 'title'
    assert sec.key == 'key'
    assert sec.title_pattern == '^\\.\\.\\s*(title)\\s*::'


# Generated at 2022-06-23 17:15:16.894863
# Unit test for constructor of class ParamSection
def test_ParamSection():
    parser = NumpydocParser()
    parser.add_section(ParamSection("Args", "param"))
    parser.add_section(ParamSection("Other Args", "other_param"))
    parser.add_section(ParamSection("Receives", "receives"))
    parser.add_section(ParamSection("Attributes", "attribute"))
    parser.add_section(ParamSection("Arguments", "param"))
    parser.add_section(ParamSection("Other Arguments", "other_param"))
    parser.add_section(ParamSection("Params", "param"))
    parser.add_section(ParamSection("Other Params", "other_param"))
    parser.add_section(ParamSection("Receive", "receives"))
    parser.add_section(ParamSection("Attribute", "attribute"))

# Generated at 2022-06-23 17:15:20.256123
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections == {s.title: s for s in DEFAULT_SECTIONS}



# Generated at 2022-06-23 17:15:22.069325
# Unit test for constructor of class ParamSection
def test_ParamSection():
    paramSection = ParamSection("Parameters", "param")
    print(paramSection)


# Generated at 2022-06-23 17:15:23.349256
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yield_section = YieldsSection("Yields","yields")
    assert yield_section.title == "Yields"
    assert yield_section.key == "yields"


# Generated at 2022-06-23 17:15:25.906325
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert RaisesSection("Raises", "raises").key == "raises"
    assert RaisesSection("Raise", "raises").key == "raises"


# Generated at 2022-06-23 17:15:29.170319
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    YieldsSection.__init__(YieldsSection, "Yields", "yields")
    assert YieldsSection.is_generator
    assert YieldsSection.key == "yields"
    assert YieldsSection.title == "Yields"


# Generated at 2022-06-23 17:15:38.629147
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    arg_name
        arg_description

    arg_2
        descriptions can also span...
        ... multiple lines
    """

    result = """
            description: arg_description
            description: descriptions can also span...
            description: ... multiple lines
            """

    #  This class is abstract, so we have to create a dummy object of class
    #  _KVSection in order to call its parse method
    dummy = _KVSection("Parameters", "param")
    dummy_result = "\n".join(
        str(doc) for doc in dummy.parse(text)
    )
    assert dummy_result == result

# Generated at 2022-06-23 17:15:42.381408
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    np = NumpydocParser()
    section = Section("Dummy title", "dummy")
    np.add_section(section)

    assert section.title in np.sections
    assert np.sections[section.title] == section

# Generated at 2022-06-23 17:15:43.297833
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    ReturnsSection("Returns","returns")

# Generated at 2022-06-23 17:15:48.458524
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    d = _KVSection(title='test', key='test')
    text = '''
    key
    value

    key2 : type
    values can also span...
    ... multiple lines
    '''
    lst = list(d.parse(text))
    assert lst[0].args == ['test','key']
    assert lst[0].description == 'value'
    assert lst[1].args == ['test','key2 : type']
    assert lst[1].description == 'values can also span...\n... multiple lines'


# Generated at 2022-06-23 17:15:53.353265
# Unit test for constructor of class Section
def test_Section():
    tmp  = Section("Parameters", "param")
    assert tmp.title == "Parameters"
    assert tmp.key == "param"
    assert tmp.title_pattern == "^Parameters\s*?\n-{9}\s*$"
