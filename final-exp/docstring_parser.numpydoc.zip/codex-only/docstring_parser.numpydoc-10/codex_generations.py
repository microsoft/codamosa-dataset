

# Generated at 2022-06-23 17:05:57.484951
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection.__base__ is Section


# Generated at 2022-06-23 17:05:59.870771
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section = ReturnsSection("Returns", "returns")
    assert section.title == "Returns"
    assert section.key == "returns"
    assert section.is_generator == False

# Generated at 2022-06-23 17:06:03.140089
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    tmep_title = "title"
    tmp_key = "key"
    my_section = _SphinxSection(tmep_title, tmp_key)
    assert my_section.title == tmep_title
    assert my_section.key == tmp_key

# Generated at 2022-06-23 17:06:07.392082
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection()
    print(s.title_pattern, "<- Should match")
    assert s.title_pattern == "^\.\.\\s*(.*)\\s*::"

if __name__ == '__main__':
    test__SphinxSection()

# Generated at 2022-06-23 17:06:11.965879
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:06:21.122018
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section('Parameters', 'param')
    test_params = [('arg_name\n    arg_description\narg_2 : int, optional\n    description can also span...\n    ... multiple lines',
                    [{'args': ['param', 'arg_name'],
                      'description': 'arg_description',
                      'arg_name': 'arg_name',
                      'type_name': None,
                      'is_optional': False,
                      'default': None},
                      {'args': ['param', 'arg_2'],
                      'description': 'description can also span...\n... multiple lines',
                      'arg_name': 'arg_2',
                      'type_name': 'int',
                      'is_optional': True,
                      'default': None}])]


# Generated at 2022-06-23 17:06:24.432075
# Unit test for constructor of class ParamSection
def test_ParamSection():
    obj = ParamSection('Parameters', 'param')
    test = '^(Parameters)\s*?\n---\s*$'
    obj._setup_re(obj.title)
    assert obj.title_pattern == test


# Generated at 2022-06-23 17:06:29.040563
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text = """
    ValueError
        A description of what might raise ValueError
    """
    a = _clean_str(inspect.cleandoc(text))
    section = RaisesSection("Raises", "raises")
    assert section.parse(a)!=None


# Generated at 2022-06-23 17:06:33.504389
# Unit test for constructor of class ParamSection
def test_ParamSection():
    title = "Parameters"
    key = "param"
    param_section = ParamSection(title,key)
    assert param_section.title == "Parameters"
    assert param_section.key == "param"
    return True

# Unit test _parse_item in class RaisesSection

# Generated at 2022-06-23 17:06:36.164993
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser=NumpydocParser()
    parser.add_section(Section("Tests", "test"))
    assert "Tests" in parser.sections


# Generated at 2022-06-23 17:06:41.196764
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    
    raises = RaisesSection('Raises','raises')
    assert raises.title == 'Raises'
    assert raises.key == 'raises'
    assert raises.parse('ValueError\nA description of what might raise ValueError')
    assert raises.title_pattern == '^Raises\\s*?\n----\\s*$'


# Generated at 2022-06-23 17:06:52.091118
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    sample_string = """
    first_key
        value

    second_key : type
        value
    """
    section_instance = _KVSection("title", "key")
    parsed_meta_content = [m for m in section_instance.parse(sample_string)]
    assert parsed_meta_content[0].args == ['key', 'first_key']
    assert parsed_meta_content[0].description == 'value'
    assert parsed_meta_content[1].args == ['key', 'second_key']
    assert parsed_meta_content[1].description == 'value'
# Unit Test for _PARAM_KEY_REGEX

# Generated at 2022-06-23 17:06:55.165746
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    test = RaisesSection("Raises", "raises")
    assert test.title == "Raises"
    assert test.key == "raises"


# Generated at 2022-06-23 17:07:05.223320
# Unit test for function parse
def test_parse():
    """
    Test function parse()
    """
    def f():
        """
        This is a short description.
        This is a
        Long
        description which can span
        over multiple lines.

        .. note:: This is a note

        Parameters
        ----------
        x : int
            Parameter description for x

        y : int, optional
            Parameter description for y

        z : int, optional(optional)
            Parameter description for z

        Returns
        -------
        : int
            The return value
        """
        pass

    # Set up expected values
    expected = Docstring()
    expected.short_description = "This is a short description."
    expected.long_description = "This is a\nLong\ndescription which can span\nover multiple lines."
    expected.blank_after_short_description = False
    expected

# Generated at 2022-06-23 17:07:08.207425
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    ndp = NumpydocParser()
    ndp.add_section(Section("Sphinx", "sphinx"))
    assert ndp.sections["Sphinx"].parse("") == (DocstringMeta([], description=None), )

# Generated at 2022-06-23 17:07:10.578861
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser
    assert parser.sections


# Generated at 2022-06-23 17:07:22.025567
# Unit test for constructor of class ParamSection
def test_ParamSection():
    kv = "arg_name \n arg_description"

    # Initialize the necessary parameters for section
    section = ParamSection("Parameters", "param")
    text = inspect.cleandoc(kv)
    ret = DocstringParam(
            args=["param", "arg_name"],
            description=_clean_str(text),
            arg_name="arg_name",
            type_name=None,
            is_optional=False,
            default=None
        )
    # Assert the result of parsing section
    assert(ret == next(section.parse(kv)))

    # Test for optional parameter
    kv = "arg_2 : type, optional \n descriptions can also span... \n ...multiple lines"
    # Initialize the necessary parameters for section
    section = ParamSection("Parameters", "param")
    text = inspect

# Generated at 2022-06-23 17:07:34.396515
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    ndp = NumpydocParser()
    text = """
        This is a single line description.
        This is a description over multiple lines.

        Parameters
        ----------
        arg_a : int
            This is the description for arg_a

        Other Parameters
        ----------------
        arg_b : float, optional
            This is the description for arg_b.

        param_c : str, optional(default='hello world')
            This is the description for param_c.

        Returns
        -------
        ret_a : int
            This is the description for ret_a
        """
    print(ndp.parse(text))

# Generated at 2022-06-23 17:07:45.255724
# Unit test for method parse of class Section

# Generated at 2022-06-23 17:07:50.791679
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title_pattern = re.compile(r"^\.\.\s*(something)\s*::")
    title = "something"
    s = _SphinxSection(title, "deprecated")
    match = title_pattern.search(s.title)
    assert match.group(1) == title


# Generated at 2022-06-23 17:07:53.883099
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises_section = RaisesSection("Raises", "raises")
    assert raises_section is not None


# Generated at 2022-06-23 17:08:01.487084
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    doc = parser.parse("""
    One-line description of the object.

    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.

    Returns
    -------
    None
        This method has no return value.

    """
    )

    print(doc.meta)

if __name__ == '__main__':
    test_NumpydocParser_parse()

# Generated at 2022-06-23 17:08:09.748617
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("short desc") == Docstring(short_description="short desc")

    assert parse('''
    short desc

    long desc
    ''') == Docstring(
        short_description="short desc",
        long_description="long desc",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

    assert parse('''
    short desc


    long desc
    ''') == Docstring(
        short_description="short desc",
        long_description="long desc",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )


# Generated at 2022-06-23 17:08:14.307487
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    print("Inside test_DeprecationSection")
    title = "Deprecation Warning"
    key = "deprecation"
    section = DeprecationSection(title, key)
    assert section.title == title
    assert section.key == key


# Generated at 2022-06-23 17:08:27.015108
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # numpy style
    text = (
        "arg_name\n"
        "    arg_description\n"
        "arg_2 : type, optional\n"
        "    descriptions can also span...\n"
        "    ... multiple lines"
    )

    result = ParamSection("Parameters", "param").parse(text)
    assert next(result).description == "arg_description"
    assert next(result).description == "descriptions can also span...\n... multiple lines"
    with pytest.raises(StopIteration):
        next(result)

    # google style
    text = (
        "arg_name: arg_description\n"
        "arg_2 : type, optional: descriptions can also span...\n"
        "    ... multiple lines"
    )


# Generated at 2022-06-23 17:08:28.113686
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert len(DEFAULT_SECTIONS[5].title) == len(DEFAULT_SECTIONS[5].title_pattern) -3



# Generated at 2022-06-23 17:08:32.963764
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    sec = _SphinxSection("The title", "the key")
    assert sec.title == "The title"
    assert sec.key == "the key"
    assert sec.title_pattern == '^\\.\\.\\s*(The title)\\s*::'


# Generated at 2022-06-23 17:08:35.616509
# Unit test for constructor of class _KVSection
def test__KVSection():
    section = _KVSection("title", "key")
    assert section.title == "title"
    assert section.key == "key"



# Generated at 2022-06-23 17:08:39.006091
# Unit test for constructor of class Section
def test_Section():
    title = "Parameters"
    key = "param"
    section = Section(title, key)
    assert(section.title == title)
    assert(section.key == key)
    title_pattern = r"^(Parameters)\s*?\n\-{9}\s*$"
    assert(section.title_pattern == title_pattern)


# Generated at 2022-06-23 17:08:46.498032
# Unit test for method parse of class DeprecationSection

# Generated at 2022-06-23 17:08:50.013941
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert isinstance(ReturnsSection("Returns", "returns"),_KVSection)
    assert issubclass(ReturnsSection("Returns", "returns"),_KVSection)

# Generated at 2022-06-23 17:08:52.696196
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # testing constructor
    meta = RaisesSection("Raises", "raises")
    assert meta.title == "Raises"
    assert meta.key == "raises"


# Generated at 2022-06-23 17:09:05.284040
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('''.  
        test_function
        abbr: test
        ''') == Docstring(short_description='test_function')
    assert parse('''.
        test_function
        abbr: test
        ''') == Docstring(short_description='test_function')
    assert parse('''.
        test_function
        ''') == Docstring(short_description='test_function')

# Generated at 2022-06-23 17:09:11.028494
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    class MySection(_SphinxSection):
        def __init__(self, title: str, key: str) -> None:
            super().__init__(title, key)
    section = MySection("title","key")
    assert(section.key == "key")
    assert(section.title == "title")
    assert(section.title_pattern == "^\.\.\\s*(title)\\s*::")



# Generated at 2022-06-23 17:09:16.676740
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yields", "yields")
    assert ys.is_generator == True
    assert ys.title == "Yields"
    assert ys.title_pattern == r"^\.\.\s*({})\s*::".format("Yields")


# Generated at 2022-06-23 17:09:17.803699
# Unit test for constructor of class ParamSection
def test_ParamSection():
    title = 'Args'
    key = 'args'
    ps = ParamSection(title, key)
    assert ps.title == title
    assert ps.key == key

# Generated at 2022-06-23 17:09:27.556436
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:09:39.399259
# Unit test for function parse

# Generated at 2022-06-23 17:09:40.660540
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    # Private constructor, called through the factory, Not sure if this is testable
    assert True

# Generated at 2022-06-23 17:09:54.012059
# Unit test for function parse
def test_parse():
    text = """
    Short description

    Long description

    Parameters
    ----------


    Arguments
    ---------

    a : 
    The first argument.

    b :
    The second argument.

    Raises
    ------

    ``ValueError``
    A description of what might raise ValueError.


    """

    from .common import DocstringParam, DocstringRaises, DocstringReturns
    from .common import DocstringMeta

    res = parse(text)

    assert res.short_description == "Short description"
    assert res.long_description == 'Long description'
    assert res.blank_after_short_description == True
    assert res.blank_after_long_description == True

    assert len(res.meta) == 2

# Generated at 2022-06-23 17:09:58.963238
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    _KVSection_parsed_text = \
"""
key1
    value1
key2 : type
    values can also span...
    ... multiple lines
"""
    _KVSection_obj = _KVSection('title','key')
    _KVSection_parsed_value = _KVSection_obj.parse(_KVSection_parsed_text)
    try:
        assert(len(_KVSection_parsed_value) == 2)
    except:
        raise Exception('Unexpected Value')
    try:
        assert(_KVSection_parsed_value[0].get_description() == 'value1')
    except:
        raise Exception('Unexpected Value')

# Generated at 2022-06-23 17:10:04.078379
# Unit test for method parse of class Section
def test_Section_parse():
    """
    test_Section_parse
    """
    # testcase 1
    class SubSection(Section):
        def __init__(self, title: str, key: str) -> None:
            super().__init__(title, key)
        def parse(self, text: str) -> T.Iterable[DocstringMeta]:
            yield DocstringMeta([self.key], description="_clean_str(text)")
    # case 1.1
    title1 = "Parameters"
    key1 = "param"
    actual_output = SubSection(title1, key1).parse("")
    expected_output = (DocstringMeta(['param'], description=""))
    assert str(actual_output) == str(expected_output)
    # case 1.2
    title2 = "Params"
    key2 = "param"

# Generated at 2022-06-23 17:10:05.681693
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
	sections = YieldsSection("Yields", "yields")
	print(sections.is_generator)

# Generated at 2022-06-23 17:10:16.333508
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    parser = _KVSection("title", "key")
    s = """
    a
        a description
    b : int
        b description
    c, optional : str
        c description
    d(optional) : bool
        d description
    e(Optional): float
        e description
    """
    meta = parser.parse(s)
    assert list(meta)[1].arg_name == "b"
    assert list(meta)[1].type_name == "int"
    assert list(meta)[2].arg_name == "c"
    assert list(meta)[2].type_name == "str"
    assert list(meta)[2].is_optional
    assert list(meta)[3].arg_name == "d"
    assert list(meta)[3].type_name == "bool"

# Generated at 2022-06-23 17:10:24.268187
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert (_SphinxSection("Parameters","param").title_pattern == r"^\.\.\s*(Parameters)\s*::")

# Generated at 2022-06-23 17:10:26.109089
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert isinstance(NumpydocParser(), NumpydocParser)

# Generated at 2022-06-23 17:10:30.057254
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section('Parameters', 'param')
    text = '''
    key_1
        value_1
    key_2
        value_2
    '''
    assert s.parse(text) == [
        DocstringMeta(['param'], description='value_1'),
        DocstringMeta(['param'], description='value_2'),
    ]



# Generated at 2022-06-23 17:10:38.693950
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # check whether the instantiation of RaisesSection can work
    section = RaisesSection("Raises", "raises")
    assert section.title == "Raises"
    assert section.key == "raises"
    assert section.title_pattern == r"^({})\s*?\n{}\s*$".format("Raises", "-" * len("Raises"))
    assert section.parse(
        text = """\
            ValueError
                A description of what might raise ValueError
            """
        )
    # check whether the value of section.key is "raises"
    assert next(section.parse(
        text = """\
            ValueError
                A description of what might raise ValueError
            """
        )
    ).args[0] == "raises"
    # check whether the instantiation of section is Raises


# Generated at 2022-06-23 17:10:51.909185
# Unit test for method parse of class Section
def test_Section_parse():
    test_docstring = inspect.cleandoc(r'''
        Parameters
        ----------
        key : type
            value
        key2 : type, optional
            values can also span...
            ... multiple lines
    ''')
    expected = [DocstringMeta(['param', 'key'], description='value'), DocstringMeta(['param', 'key2'], description='values can also span...\n\n... multiple lines')]
    actual = ParamSection('Parameters', 'param').parse(test_docstring)
    assert list(actual) == expected

    test_docstring = inspect.cleandoc(r'''
        Params
        ------
        key : type
            value
        key2 : type, optional
            values can also span...
            ... multiple lines
    ''')

# Generated at 2022-06-23 17:10:59.332725
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    # Normal case
    a = _SphinxSection("title", "key")
    assert(a.title == 'title')
    assert(a.key == 'key')

    # Invalid case: empty title
    try:
        b = _SphinxSection("", "key")
    except (ValueError, IndexError):
        pass

    # Invalid case: empty key
    try:
        c = _SphinxSection("title", "")
    except (ValueError, IndexError):
        pass

    # Invalid case: empty title and empty key
    try:
        d = _SphinxSection("", "")
    except (ValueError, IndexError):
        pass

# Generated at 2022-06-23 17:11:07.320688
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = r"""
    doctest.DONT_ACCEPT_TRUE_FOR_1
    True and False also do not compare equal to 1 and 0
    respectively.

    Examples
    --------
    >>> 1 == True
    False
    >>> 0 == False
    False
    >>> 1 is True
    False
    """

    ds = NumpydocParser().parse(text)
    assert len(ds.meta) == 1
    assert ds.meta[0].args[0] == 'example'

# Generated at 2022-06-23 17:11:13.469420
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection("Yields", "yields")
    assert ys.is_generator is True
    assert ys.title == "Yields"
    assert ys.key == "yields"
    assert ys.title_pattern == "^\\.\\.\\s*Yields\\s*::"


# Generated at 2022-06-23 17:11:15.038381
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section = _SphinxSection("X", None)
    assert section.title == "X"


# Generated at 2022-06-23 17:11:21.198095
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():

    parser = NumpydocParser()
    parser.add_section(Section('This is test', 'is_test'))
    assert parser.parse('''This is test
        -
        This is test description
        ''') == Docstring(short_description=None, long_description=None, blank_after_long_description=False, blank_after_short_description=False, meta=[DocstringMeta(['is_test'], description='This is test description')])


# Generated at 2022-06-23 17:11:25.538235
# Unit test for constructor of class _KVSection
def test__KVSection():
    sec = _KVSection("Parameters")
    assert sec.title == "Parameters"
    assert sec.title_pattern == r"^(Parameters)\s*?\n{}\s*$".format("-" * len("Parameters"))



# Generated at 2022-06-23 17:11:27.121075
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser is not None


# Generated at 2022-06-23 17:11:31.285846
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
  docstring = """Deprecated since version 0.5: use :func:`~arch.compat.numpy.nanmedian` instead
All NaN values will be deleted."""
  numpydoc_parsed_docstring = NumpydocParser()
  deprecations_section = numpydoc_parsed_docstring.parse(docstring)
  assert deprecations_section.meta

# Generated at 2022-06-23 17:11:39.026804
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    str1 = "ValueError \n\
        The arg_1 has to be a positive integer."

    str2 = "TypeError \n\
        The arg_1 has to be a positive integer."

    f1 = RaisesSection("Raises", "raise")
    f2 = RaisesSection("Raises", "raise")

    RaisesSection("Raises", "raise")

    assert f1._parse_item("ValueError", str1)
    assert f2._parse_item("TypeError", str2)

# Generated at 2022-06-23 17:11:40.460546
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section("a","b")
    print(s.parse("""   a

    1

"""))

# Generated at 2022-06-23 17:11:51.152926
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert ParamSection("Parameters", "param").title_pattern == r'^(Parameters)\s*?\n---\s*$'
    assert ParamSection("Params", "param").title_pattern == r'^(Params)\s*?\n---\s*$'
    assert ParamSection("Arguments", "param").title_pattern == r'^(Arguments)\s*?\n---\s*$'
    assert ParamSection("Args", "param").title_pattern == r'^(Args)\s*?\n---\s*$'
    assert ParamSection("Other Parameters", "other_param").title_pattern == r'^(Other Parameters)\s*?\n---------------\s*$'

# Generated at 2022-06-23 17:11:53.058289
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    sec = DeprecationSection(title="deprecated", key="deprecation")

# Generated at 2022-06-23 17:11:59.126839
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    ReturnsSection_obj = ReturnsSection('Returns', 'returns')
    ReturnsSection_obj.parse('return_name : type\nA description of this returned value')
    assert ReturnsSection_obj.args == ['returns']
    assert ReturnsSection_obj.description == 'A description of this returned value'
    assert ReturnsSection_obj.is_generator == False
    assert ReturnsSection_obj.return_name == 'return_name'
    assert ReturnsSection_obj.type_name == 'type'



# Generated at 2022-06-23 17:12:03.585343
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yv = YieldsSection("Yields","yields")
    # Test of constructor of class YieldsSection
    assert yv.is_generator == True, "test of constructor of class YieldsSection failed"


# Generated at 2022-06-23 17:12:07.844237
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.parse("\n".join(["z: int", "", "Z description", "---------------", "x: int", "", "X description"]))
    parser.add_section(Section("Z", "Z"))
    assert(parser.parse("\n".join(["z: int", "", "Z description", "---------------", "x: int", "", "X description"])).to_primitive() == {'short_description': '', 'long_description': '', 'meta': []})



# Generated at 2022-06-23 17:12:09.937255
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section = ReturnsSection("Returns", "returns")
    assert section.is_generator == False


# Generated at 2022-06-23 17:12:18.279826
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = """
    title of method
    *******************

    hello world

    Parameters
    ----------
    data_length : int
        Number of data

    Returns
    -------
    str
        title of method

    Raises
    ------
    Exception
        When data_length is not a positive integer
    """

    parser = NumpydocParser()
    parsed_docstring = parser.parse(text)
    parsed_docstring.short_description



# Generated at 2022-06-23 17:12:21.710083
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    depre_section = DeprecationSection("Deprecated", "deprecation")
    assert depre_section.parse("0.1.2\n description") == "0.1.2 description"


# Generated at 2022-06-23 17:12:23.090665
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection('Yields', 'yields')

# Generated at 2022-06-23 17:12:26.052819
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    actual = DeprecationSection("Deprecated", "deprecated").title_pattern
    expected = r"^\.\.\s*(Deprecated)\s*::"
    assert actual == expected, "Pattern did not match expected"



# Generated at 2022-06-23 17:12:27.176137
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    section = ReturnsSection(
        "Returns", "returns"
    )
    assert section.is_generator == False
    assert section.title == "Returns"

# Generated at 2022-06-23 17:12:33.293053
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    # Test with title, key
    test_obj = _SphinxSection('title', 'key')
    assert test_obj.title == 'title'
    assert test_obj.key == 'key'
    # This should return the pattern needed to find the section header in the docstring
    assert test_obj.title_pattern == r'^\.\.\s*(title)\s*::'

# Generated at 2022-06-23 17:12:39.524992
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section('title', 'key')
    text = '''
            section_description
                section_description can span multiple lines
        '''
    for meta in s.parse(text):
        assert meta.args == ['key']
        assert meta.description == 'section_description\n    section_description can span multiple lines'


# Generated at 2022-06-23 17:12:43.685890
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    s = DeprecationSection("Deprecated", "deprecated")
    text = ".. deprecated::\n   Use :func:`~asyncio.wait_for` instead.\n\n"
    assert s.parse(text).args[0] == "deprecated"

# Generated at 2022-06-23 17:12:45.866426
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ps = ParamSection("Parameters", "param")
    assert ps.title == "Parameters"
    assert ps.key == "param"
    assert ps.title_pattern == "^Parameters\s*?\n-----*\s*$"


# Generated at 2022-06-23 17:12:57.704870
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = r"""
    Parses a docstring into its constituent parts.

    This function parses a docstring and returns a :class:`Docstring <Docstring>` object that can be
    queried for individual parts of the docstring. The parsing is done according to the `NumPy
    docstring
    guidelines <https://github.com/numpy/numpy/blob/master/doc/HOWTO_DOCUMENT.rst.txt>`_.

    :param text: docstring
    :returns: parsed `Docstring` object
    :raises InvalidDocstring: if the docstring is not a valid NumPy docstring

    """

    ds = NumpydocParser().parse(text)
    assert isinstance(ds, Docstring)
    for meta in ds.meta:
        assert isinstance(meta, DocstringMeta)

# Generated at 2022-06-23 17:13:08.187866
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():

    text = """
    .. deprecated:: 0.1
        Some deprecation information
    """
    text = inspect.cleandoc(text)
    match = re.match(r"^\.\.\s*deprecated\s*::", text)
    start = match.end()
    end = re.search(r"\n{2,}", text).start()
    text = text[start:end]
    print(text)




# parse(test_doc)


# if __name__ == "__main__":
# >>>
# >>> print(parse(test_doc))
# Docstring(
#     short_description='A short description.',
#     blank_after_short_description=True,
#     blank_after_long_description=False,
#     long_description='Returns data and labels.\n\

# Generated at 2022-06-23 17:13:09.413436
# Unit test for function parse
def test_parse():
    print(parse.__doc__)


# Generated at 2022-06-23 17:13:16.431330
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import Docstring
    from .common import DocstringMeta

    # An old-style docstring
    test1 = """
    This is a short description.

    This is a long
    description.

    :param arg: arg description
    :type arg: str
    :return: return description
    :rtype: str
    """
    result = NumpydocParser().parse(test1)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert len(result.meta) == 4
    assert result.meta[0].key == 'param'
    assert result.meta[0].description == 'arg description'

# Generated at 2022-06-23 17:13:17.750339
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r=RaisesSection("Raise","raise")
    assert r.key == "raise"
    assert r.title == "Raise"

# Generated at 2022-06-23 17:13:21.729246
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("Path", "path"))
    assert parser.sections["Path"].key == "path"
    assert parser.sections["Path"].title == "Path"
    assert "Path" in parser.titles_re.pattern


# Generated at 2022-06-23 17:13:29.897619
# Unit test for function parse
def test_parse():
    class Example:
        """This is a short description

        This is a longer description. It can spread over multiple lines.

        Parameters
        ----------
        param_1 : str
            desc param 1
        param_2 : int
            desc param 2

        Returns
        -------
        Example
            desc example

        Examples
        --------
        >>> import coffeescript
        >>> print(coffeescript.compile())
        <BLANKLINE>
        """

    docstring = parse(Example.__doc__)
    assert docstring.short_description == "This is a short description"
    assert docstring.long_description == (
        "This is a longer description. It can spread over multiple lines."
    )

# Generated at 2022-06-23 17:13:40.768656
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    doc = """param_1
            This is the first param's description.
    param_2 : type
            This is the second param's description.
            It spans multiple lines.
    param_3
        This is the third param's description.
        It also spans multiple lines, but
        they are tabs, not spaces.
    param_4 : type, optional
            This param's description
            is over multiple lines,
            and it's optional.
    param_5
        This param's description mentions the default,
        and it's default is a value like 5.
    param_6
        This param's description mentions the default,
        and it's default is another value like 0.0.
    """

    lines = NumpydocParser().parse(doc).meta[0].description.splitlines()
    assert lines[0] == "param_1"


# Generated at 2022-06-23 17:13:44.605156
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises_section = RaisesSection("Raises", "raises")
    assert repr(raises_section) == '<_KVSection key="raises" title="Raises">'


# Generated at 2022-06-23 17:13:49.077934
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # test for class _KVSection
    section = _KVSection("test", "test")

    text = "a\n    abc\nd\n    efg\nh\n    ijk\n"
    res = list(section.parse(text))
    assert res == ['abc', 'efg', 'ijk']


    # test for class ParamSection
    section = ParamSection("test", "test")

    text = "a\n    abc\nd\n    efg\nh\n    ijk\n"
    res = list(section.parse(text))
    assert res == ['abc', 'efg', 'ijk']



# Generated at 2022-06-23 17:13:52.574625
# Unit test for constructor of class _KVSection
def test__KVSection():
    key = 'test'
    title = 'Args'
    section = _KVSection(title, key)
    assert(section.title == title)
    assert(section.key == key)


# Generated at 2022-06-23 17:14:01.609350
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test for method parse of class NumpydocParser

    """
    text = """
    Some short description.

    More elaborate description.

    Parameters
    ------------
    arg
        Normal arg
    arg2 : str, optional
        More arg, with type
    arg3 : :class:`ext.MyClass`
        Some class
    arg4 : int, optional, default=0
        More arg, with default

    See Also
    ---------
    Some other stuff

    """

    print(parse(text))


# Generated at 2022-06-23 17:14:07.506687
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    expected_result = {
        'args': ['returns'],
        'description': 'Return a list of all the ways to write n as a sum of 1s and 2s.',
        'type_name': None,
        'is_generator': False,
        'return_name': 'ways'
    }

    parser = NumpydocParser()
    result = parser.parse("""
    Return a list of all the ways to write n as a sum of 1s and 2s.

    Returns:
         ways: Return a list of all the ways to write n as a sum of 1s and 2s.
    """)
    assert result.meta[0] == DocstringReturns(**expected_result)

# Generated at 2022-06-23 17:14:09.140925
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    r = ReturnsSection("Returns", "returns")
    assert r != None


# Generated at 2022-06-23 17:14:11.564782
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param = ParamSection('Parameters', 'param')
    assert param.title == 'Parameters'
    assert param.key == 'param'


# Generated at 2022-06-23 17:14:13.927548
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    npyp = NumpydocParser()
    npyp.add_section(Section("Members", "members"))
    # section titles
    assert set(npyp.sections) == set([s.title for s in DEFAULT_SECTIONS]) | set(["Members"])
    # section content
    assert npyp.sections['Members'].key == "members"



# Generated at 2022-06-23 17:14:15.816252
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    # TODO: tests are missing
    pass


# Generated at 2022-06-23 17:14:20.062295
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection("Yields","yields")
    assert y.is_generator == True
    assert y.key == "yields"
    assert y.title == "Yields"


# Generated at 2022-06-23 17:14:26.940634
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    title = "Deprecation Warning"
    key = "deprecation"
    text = """
    This example has been deprecated in 0.0.1
    Some desc"""
    parser = DeprecationSection(title, key)
    assert type(parser.title) == str
    assert type(parser.key) == str
    assert type(parser.title_pattern) == str
    assert type(parser.parse(text)) == list


# Generated at 2022-06-23 17:14:32.878058
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc("""The docstring.

    Parameters
    ----------
    arg1 : int
        Argument 1.
    arg2 : numpy.ndarray
        Argument 2.

    Returns
    -------
    int
        The return value.
    """)


# Generated at 2022-06-23 17:14:42.202561
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    tests = [
        ("", None, None),
        ("1.0", None, "1.0"),
        ("1.0\ndescription", "description", "1.0"),
    ]

    section = DeprecationSection("deprecated", "deprecation")
    for test, expected_description, expected_version in tests:
        doc = section.parse(test)
        doc = next(doc)
        assert doc.description == expected_description
        assert doc.version == expected_version


# Generated at 2022-06-23 17:14:43.875408
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser


# Generated at 2022-06-23 17:14:45.251377
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert _KVSection("Parameters", "param")


# Generated at 2022-06-23 17:14:54.079833
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("Unittest", "unittest"))
    parser.add_section(ParamSection("Unittest", "unittest"))
    parser.add_section(RaisesSection("Unittest", "unittest"))
    parser.add_section(ReturnsSection("Unittest", "unittest"))
    parser.add_section(YieldsSection("Unittest", "unittest"))
    parser.add_section(DeprecationSection("Unittest", "unittest"))

# Generated at 2022-06-23 17:15:02.691808
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:15:05.737606
# Unit test for constructor of class _KVSection
def test__KVSection():
    title = "Attributes"
    key = "attribute"
    kv_section = _KVSection(title, key)

    assert(kv_section.title == title)
    assert(kv_section.key == key)



# Generated at 2022-06-23 17:15:11.492842
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    text = inspect.cleandoc(text)
    kv_text = KV_REGEX.finditer(text)
    assert len(list(kv_text)) == 2

# Generated at 2022-06-23 17:15:15.320505
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    section = Section("Test", "test")
    parser.add_section(section)
    assert parser.sections == {"Test": section}


# Generated at 2022-06-23 17:15:16.929939
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    ss = DeprecationSection("deprecated", "deprecation")
    assert ss is not None


# Generated at 2022-06-23 17:15:22.729539
# Unit test for constructor of class Section
def test_Section():
    my_section = Section("Parameters", "param")
    assert my_section.title == "Parameters"
    assert my_section.key == "param"
    assert my_section.title_pattern == "^Parameters\s*?\n\-\-\-\-\-\-\-\-\-\-\-\-\-\s*$"


# Generated at 2022-06-23 17:15:25.380953
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text = "ValueError\n    A description of what might raise ValueError"
    assert RaisesSection("Raises", "raises").parse(text).description == "A description of what might raise ValueError"

# Generated at 2022-06-23 17:15:27.226699
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    obj = YieldsSection("Yields", "yields")
    assert(obj.is_generator == True)

# Generated at 2022-06-23 17:15:40.708557
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    d = Docstring()
    d.short_description = 'fun is a function'
    d.long_description = 'good things are coming'
    d.blank_after_short_description = True
    d.blank_after_long_description = True

# Generated at 2022-06-23 17:15:52.399383
# Unit test for method parse of class Section
def test_Section_parse():
    from .common import DocstringMeta
    from . import __path__ as pypdg_path
    from .__main__ import docstring_file
    import os
    import unittest
    import doctest
    # class parameter
    class_parameter = "class_parameter.py"
    class_parameter_full_path = os.path.join(pypdg_path[0],class_parameter)
    text = docstring_file(file_path=class_parameter_full_path)
    title = "class_parameter"
    key = "param"
    # Expected object
    expected_object_1 = DocstringMeta(["param","class_parameter_1"], description="This is class parameter 1")

# Generated at 2022-06-23 17:15:55.762260
# Unit test for constructor of class Section
def test_Section():
    section = Section(title="Parameters", key="param")
    assert section.title == "Parameters"
    assert section.key == "param"
    assert section.title_pattern == "^(Parameters)\s*?\n{}\s*$"


# Generated at 2022-06-23 17:15:59.344686
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("deprecated", "deprecation")
    assert section.title == "deprecated"
    assert section.key == "deprecation"
    assert section.title_pattern == r"^\.\.\s*(deprecated)\s*::"
