

# Generated at 2022-06-23 17:05:57.220685
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    r = ReturnsSection("Returns", "returns")
    assert r.title == "Returns"
    assert r.key == "returns"
    assert r.is_generator == False

# Generated at 2022-06-23 17:06:05.490755
# Unit test for function parse
def test_parse():
    def foo(x: "int", y: "int"):
        """
        Returns x+y

        Parameters
        ----------
        x: int
            The first number
        y: int, optional
            The second number

        Returns
        -------
        int
            The sum of x and y
        """
        return x + y

    doc = parse(inspect.getdoc(foo))

    assert len(doc.meta) == 2
    assert doc.meta[0] == DocstringParam(
        ["param", "x"],
        description="The first number",
        arg_name="x",
        type_name="int",
        is_optional=False,
        default=None,
    )

# Generated at 2022-06-23 17:06:17.220368
# Unit test for function parse
def test_parse():
    def foo():
        """Returns the square of the input.

        :param x: The number to square.
        :type x: int, float

        :returns: x**2

        :raises TypeError: If x is not a number.

        """
        return

    # Inspect the docstring...
    d = parse(inspect.getdoc(foo))
    assert d.meta == [
        DocstringMeta(['other_param', 'x'], description='The number to square.'),
        DocstringMeta(['returns'], description='x**2'),
        DocstringRaises(['raises', 'TypeError'], description='If x is not a number.')
    ]
    assert d.short_description == 'Returns the square of the input.'
    assert d.long_description == None
    assert d.blank_after_

# Generated at 2022-06-23 17:06:29.488855
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    sec1 = DeprecationSection("deprecated", "deprecated")
    sec2 = DeprecationSection("deprecate", "deprecate")
    assert sec1.title == "deprecated"
    assert sec2.title == "deprecate"
    assert sec1.key == "deprecated"
    assert sec2.key == "deprecate"
    assert sec1.title_pattern == "^\.\.\s*(deprecated)\s*::"
    assert sec2.title_pattern == "^\.\.\s*(deprecate)\s*::"

# Generated at 2022-06-23 17:06:36.404721
# Unit test for function parse
def test_parse():
    def foo():
        """
        Short summary for foo

        Longer summary for foo.

        Parameters
        ----------
        a : int
            a param type
        b : str, optional
            params can also have defaults
            with more than one line
            and stuff

        Returns
        -------
        int
            this func returns a an int
        """
        pass

    ret = parse(foo.__doc__)
    assert ret.short_description == 'Short summary for foo'


# Generated at 2022-06-23 17:06:39.864588
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    returnsSection = ReturnsSection("Returns","returns")
    assert returnsSection.is_generator is False
    assert returnsSection.key == "returns"
    assert returnsSection.title == "Returns"


# Generated at 2022-06-23 17:06:45.079178
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    parser = NumpydocParser()
    class YieldsSection(_SphinxSection):
        is_generator = True
    section = YieldsSection("Yields", "yields")
    parser.add_section(section)
    assert parser.sections["Yields"] == section
    assert parser.sections["Yield"] == section
    assert parser.sections["Attributes"] == None
    assert parser.sections["Attribute"] == None
    assert parser.sections["Yields"] == section
    assert parser.sections["Yield"] == section



# Generated at 2022-06-23 17:06:47.775850
# Unit test for constructor of class ParamSection
def test_ParamSection():
    s = ParamSection("Parameters", "param")
    assert s.title == "Parameters"
    assert s.key == "param"


# Generated at 2022-06-23 17:06:55.906756
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    p = NumpydocParser()
    assert len(p.sections) == len(DEFAULT_SECTIONS)
    assert p.sections['Raise'].key == 'raises'
    assert p.sections['Raises'].key == 'raises'
    assert p.sections['Warn'].key == 'warns'
    assert p.sections['Warns'].key == 'warns'
    assert p.sections['See Also'].key == 'see_also'


# Generated at 2022-06-23 17:07:01.012127
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    deprecation_section = DeprecationSection("deprecation", "deprecation")
    assert deprecation_section.title == "deprecation"
    assert deprecation_section.key == "deprecation"
    assert deprecation_section.title_pattern == "^\.\.\s*(deprecation)\s*::"



# Generated at 2022-06-23 17:07:06.097490
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    docstring = NumpydocParser()
    custom_sections = [Section("Parameters", "param")]
    for section in custom_sections:
        docstring.add_section(section)
    assert len(docstring.sections) == 1
    assert docstring.sections['Parameters'] == custom_sections[0]

if __name__ == "__main__":
    test_NumpydocParser_add_section()

# Generated at 2022-06-23 17:07:07.289447
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
  x = YieldsSection("Yields", "yields")
  assert(x)

# Generated at 2022-06-23 17:07:12.545440
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    # test for class YieldsSection
    yields_section = YieldsSection("yields", "yields")
    assert yields_section.is_generator == True
    assert yields_section.title == "yields"
    assert yields_section.title_pattern == "^\.\.\s*(yields)\s*::"
    assert yields_section.key == "yields"


# Generated at 2022-06-23 17:07:23.912365
# Unit test for constructor of class Section
def test_Section():
    sections = [
        "Parameters",
        "Params",
        "Arguments",
        "Args",
        "Other Parameters",
        "Other Params",
        "Other Arguments",
        "Other Args",
        "Receives",
        "Receive",
        "Raises",
        "Raise",
        "Warns",
        "Warn",
        "Attributes",
        "Attribute",
        "Returns",
        "Return",
        "Yields",
        "Yield",
        "Examples",
        "Example",
        "Warnings",
        "Warning",
        "See Also",
        "Related",
        "Notes",
        "Note",
        "References",
        "Reference",
        "deprecated",
    ]

# Generated at 2022-06-23 17:07:29.166902
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydoc_parser = NumpydocParser()
    section1 = Section("Params", "param")
    numpydoc_parser.add_section(section1)
    section2 = Section("Params1", "param1")
    numpydoc_parser.add_section(section2)
    section3 = Section("Params", "param")
    numpydoc_parser.add_section(section3)
    assert numpydoc_parser.sections["Params"] is section3
    assert numpydoc_parser.sections["Params1"] is section2
    assert len(numpydoc_parser.sections) == 2

# Generated at 2022-06-23 17:07:38.060613
# Unit test for method parse of class Section
def test_Section_parse():
    text = ""
    assert Section("Section", "key").parse(text) == []

    text = "Section\n" \
           "-------\n"
    assert Section("Section", "key").parse(text) == []

    text = "Section\n" \
           "-------\n" \
           "arg_name\n" \
           "    arg_description\n" \
           "arg_2 : type, optional\n" \
           "    descriptions can also span...\n" \
           "    ... multiple lines"
    assert Section("Section", "key").parse(
        text) == [DocstringMeta(["key"], description=None)]


# Generated at 2022-06-23 17:07:47.410600
# Unit test for method parse of class Section
def test_Section_parse():
    # Testcase: section title without a meta key
    class SectionTest1(Section):
        def __init__(self):
            super().__init__(title="Title Testcase 1", key="key1")
        def _parse_item(self, key: str, value: str) -> DocstringMeta:
            return DocstringMeta([self.key], description=_clean_str(value))
    section1 = SectionTest1()
    text = """Title Testcase 1
--------------
value
"""
    docstring_meta1 = section1.parse(text)
    assert(next(docstring_meta1).description == "value")

    # Testcase: section title with a meta key
    class SectionTest2(Section):
        def __init__(self):
            super().__init__(title="Title Testcase 2", key="key2")


# Generated at 2022-06-23 17:07:57.219131
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    # Test data
    test_data = ".. deprecated:: 1.0-alpha\n    This is a deprecation warning"
    dict_results = dict()
    dict_results["version"] = "1.0-alpha"
    dict_results["description"] = "This is a deprecation warning"

    # Test constructor
    testing = DeprecationSection("deprecated", "deprecation")

    # Test parse
    result = testing.parse(test_data)
    for key in dict_results:
        assert key == result.args[1]
        assert dict_results[key] == result.description


# Generated at 2022-06-23 17:08:03.729730
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    sections = {
        "Parameters": ParamSection("Parameters", "param"),
        "Returns": ReturnsSection("Returns", "returns"),
    }

    numpydoc_parser = NumpydocParser()
    new_section = DeprecationSection("deprecated", "deprecation")
    numpydoc_parser.add_section(new_section)

    assert new_section == numpydoc_parser.sections["deprecated"]


# Generated at 2022-06-23 17:08:04.953620
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert _KVSection is not None

# Generated at 2022-06-23 17:08:16.427781
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    text = """Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """
    parser = NumpydocParser()
    section = ParamSection("Parameters", "param")
    parser.add_section(section)
    docstring = parser.parse(text)
    assert docstring.meta[0].args[0] == "param"
    assert docstring.meta[0].args[1] == "arg_name"
    assert docstring.meta[0].description == "arg_description"
    assert docstring.meta[1].args[0] == "param"
    assert docstring.meta[1].args[1] == "arg_2"

# Generated at 2022-06-23 17:08:20.313590
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    # It should be created
    assert(isinstance(parser, NumpydocParser))


# Generated at 2022-06-23 17:08:24.315600
# Unit test for constructor of class Section
def test_Section():
    test = Section("Parameters", "param")
    assert test.key == "param"
    assert test.title == "Parameters"
    assert test.title_pattern == "^Parameters\s*?\n-{9}\s*$"


# Generated at 2022-06-23 17:08:26.304240
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    NpdocParser = NumpydocParser()
    assert isinstance(NpdocParser.parse('hello'), Docstring)

# Generated at 2022-06-23 17:08:29.556952
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    m = RaisesSection("Raises", "raises")
    assert m.title == "Raises"
    assert m.key == "raises"


# Generated at 2022-06-23 17:08:41.265234
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text = inspect.cleandoc(
        """
        First line of short description

        Second line of short description

        Third line is long description.

        Parameters
        ----------
        param : int
            First parameter.
        other_param : str
            Second parameter.
    """
    )

# Generated at 2022-06-23 17:08:45.889106
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    from .test_numpydoc import TEST_SECTION
    parser = NumpydocParser(sections=TEST_SECTION)
    section = Section("Other", "other")
    parser.add_section(section)
    assert(section in parser.sections.values())

# Generated at 2022-06-23 17:08:50.760230
# Unit test for method parse of class Section
def test_Section_parse():
    section_1 = Section("Parameters", "param")
    assert list(section_1.parse("param_name\n    param_description")) == [DocstringMeta(["param", "param_name"], description="param_description")]
    section_2 = ParamSection("Parameters", "param")
    print(list(section_2.parse("param_name\n    param_description")))
    assert list(section_2.parse("param_name\n    param_description")) == [DocstringParam(["param", "param_name"], description="param_description", arg_name="param_name")]
    assert list(section_2.parse("param_name\n    Default: 10")) == [DocstringParam(["param", "param_name"], description="Default: 10", arg_name="param_name")]

# Generated at 2022-06-23 17:08:54.950905
# Unit test for constructor of class Section
def test_Section():
    d = Section("Parameters", "param")

    # Testing title and key
    assert d.title == "Parameters"
    assert d.key == "param"

    # Testing title_pattern
    assert d.title_pattern == "^(Parameters)\s*?\n------*\s*$"


# Generated at 2022-06-23 17:08:58.970888
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section = _SphinxSection("Parameters", "param")
    assert section.title == "Parameters"
    assert section.key == "param"
    assert section.title_pattern == "^\.\.\s*(Parameters)\s*::"



# Generated at 2022-06-23 17:09:01.573078
# Unit test for constructor of class _KVSection
def test__KVSection():
    parser = _KVSection('Parameter', 'param')
    assert parser._parse_item('key', 'value')



# Generated at 2022-06-23 17:09:05.337838
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    new_section = Section("Test", "test")
    parser = NumpydocParser()
    parser.add_section(new_section)
    assert parser.sections["Test"] == new_section


# Generated at 2022-06-23 17:09:10.357461
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    class TestSection(Section):
        def __init__(self):
            super().__init__("TestSection","test_section")
        def parse(self, text: str) -> T.Iterable[Section]:
            return text
    TestSection = TestSection()
    TestNumpydocParser = NumpydocParser()
    TestNumpydocParser.add_section(TestSection)
    TestNumpydocParser.parse(".. TestSection:: \n    Test")
    assert TestNumpydocParser.sections["TestSection"] is TestSection

# Generated at 2022-06-23 17:09:15.124230
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises = RaisesSection("Raises","raises")
    if raises is not None:
        print ("RaisesSection() is OK")
        print (raises.title)
        print (raises.key)
    else:
        print ("RaisesSection() is Wrong")



# Generated at 2022-06-23 17:09:16.298265
# Unit test for constructor of class ParamSection
def test_ParamSection(): 
	ps = ParamSection("param", "param")
	assert isinstance(ps, ParamSection)


# Generated at 2022-06-23 17:09:18.716987
# Unit test for constructor of class _KVSection
def test__KVSection():
    kv_section = _KVSection("Parameters", "param")
    assert kv_section.title == "Parameters"
    assert kv_section.key == "param"
    assert kv_section.title_pattern == "^Parameters\s*?\n-+\s*$"


# Generated at 2022-06-23 17:09:19.689056
# Unit test for constructor of class _KVSection
def test__KVSection():
    p = ParamSection("Parameters", "param")
    assert p.title == "Parameters"
    assert p.key == "param"


# Generated at 2022-06-23 17:09:20.327756
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    s = RaisesSection('Raises','raises')
    assert s is not None

# Generated at 2022-06-23 17:09:22.989270
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert isinstance(parser.sections, dict)
    assert isinstance(parser.titles_re, re.Pattern)



# Generated at 2022-06-23 17:09:28.352849
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 0.3.3
        Renamed to :func:`~funguilds.extract_guilds_from_dict`
    """
    section = DeprecationSection('deprecated', 'deprecation')
    expected = [DocstringDeprecated([section.key], 'Renamed to :func:`~funguilds.extract_guilds_from_dict`', '0.3.3')]
    actual = section.parse(text)
    assert actual == expected

# Generated at 2022-06-23 17:09:38.225452
# Unit test for constructor of class _KVSection
def test__KVSection():
    sec = _KVSection("title", "key")
    assert sec.title == "title"
    assert sec.key == "key"
    # Unit test for constructor of class _SphinxSection
    def test__SphinxSection():
        sec = _SphinxSection("title", "key")
        assert sec.title == "title"
        assert sec.key == "key"
        # Unit test for method _parse_item of class _KVSection
        def test__KVSection__parse_item():
            sec = _KVSection("title", "key")
            assert sec._parse_item("a", "b") == None
            # Unit test for constructor of class ParamSection

# Generated at 2022-06-23 17:09:40.386815
# Unit test for method parse of class Section
def test_Section_parse():
    func = Section("title", "meta")

    assert list(func.parse("text")) == [DocstringMeta(["meta"], "text")]


# Generated at 2022-06-23 17:09:53.688781
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:10:01.780958
# Unit test for function parse
def test_parse():
    def func(a, b=1.0, c=True):
        """
        Short description.

        Long description with an
        indent.

        Parameters
        ----------
        a : type
            Parameter a.
        b : optional
            Parameter b.
        c : bool, optional
            Parameter c.
        """
        pass

    doc = parse(inspect.getdoc(func))
    
    assert  doc.short_description == "Short description."
    assert  doc.long_description == "Long description with an\nindent."
    assert  doc.blank_after_short_description == True
    assert  doc.blank_after_long_description == True

# Generated at 2022-06-23 17:10:04.258987
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection("Yields","yields")
    # check if boolean is_generator is set to True
    assert y.is_generator == True

# Generated at 2022-06-23 17:10:12.393455
# Unit test for function parse
def test_parse():
    text = """
    Parse the numpy-style docstring into its components.

    :returns: parsed docstring

    Parameters
    ----------
    arg_name
        arg_description
    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines

    Raises
    ------
    ValueError
        A description of what might raise ValueError
    
    Returns
    -------
    return_name : type
        A description of this returned value
    another_type
        Return names are optional, types are required
    """

# Generated at 2022-06-23 17:10:22.663607
# Unit test for function parse
def test_parse():
    docstring = """
    This is a short description of the function.

    This is the longer description of the function. It can span multiple
    lines.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.
    arg3 : list
        The third argument. This can span multiple lines,
        and be split over multiple lines.

    arg4 (optional) : tuple
        If you use the positional form, you can't have an optional argument.

    Returns
    -------
    return_value : str
        The description of the returned value.
        This can span multiple lines.
    """


# Generated at 2022-06-23 17:10:25.995143
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    c = DeprecationSection('deprecated', 'deprecation')

    assert c.title == 'deprecated'
    assert c.key == 'deprecation'

# Generated at 2022-06-23 17:10:29.052229
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ps = ParamSection("TEST", "TEST")
    assert ps.title == "TEST"
    assert ps.key == "TEST"


# Generated at 2022-06-23 17:10:36.393234
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Setup
    text = "key\n    value\nkey2 : type\n    values can also span...\n    ... multiple lines"
    # Exercise
    ret = _KVSection("Parameters", "param").parse(text)
    # Verify
    assert bool(re.search("param", str(ret))) is True
    assert bool(re.search("key", str(ret))) is True
    assert bool(re.search("value", str(ret))) is True
    assert bool(re.search("key2", str(ret))) is True
    assert bool(re.search("type", str(ret))) is True
    assert bool(re.search("other", str(ret))) is False


# Generated at 2022-06-23 17:10:39.035057
# Unit test for constructor of class Section
def test_Section():
    title = "hello"
    key = "me"
    sec = Section(title, key)
    assert sec.title == title
    assert sec.key == key


# Generated at 2022-06-23 17:10:50.111708
# Unit test for constructor of class Section
def test_Section():
    title = 'test1'
    key = 'test2'
    s = Section(title, key)
    if s.title != title:
        assert False
    if s.key != key:
        assert False
    if s.title_pattern != '^(test1)\s*?\n{0}\s*$'.format('-' * len(title)):
        assert False
    if s.parse('test3') != [DocstringMeta(['test2'], description='test3')]:
        assert False
    try:
        print(s.par)
        assert False
    except AttributeError:
        pass



# Generated at 2022-06-23 17:10:51.638719
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    s = YieldsSection("Yields", "yields")
    assert (s is not None)

# Generated at 2022-06-23 17:10:53.759567
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    my_parser = NumpydocParser()
    rv = my_parser.parse.__doc__
    assert rv is not None



# Generated at 2022-06-23 17:10:59.267937
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = textwrap.dedent("""\
        .. deprecated:: 0.1.0
            Some additional information.
    """)
    d = DeprecationSection("deprecated", "deprecation")
    assert list(d.parse(text)) == [DocstringDeprecated(args=['deprecation'],
                                                       description='Some additional information.',
                                                       version='0.1.0')]


# Generated at 2022-06-23 17:11:05.781349
# Unit test for function parse
def test_parse():
    d = parse.__doc__.replace("\n", " ")
    assert isinstance(d, str), d
    d = parse(d)
    assert isinstance(d, Docstring), d
    assert d.short_description == "Parse the numpy-style docstring into its components.", d
    assert d.long_description == "        :returns: parsed docstring", d
    assert len(d.meta) == 0, d

    d = parse("foo")
    assert isinstance(d, Docstring), d
    assert d.short_description == "foo", d
    assert d.long_description is None, d
    assert len(d.meta) == 0, d

    d = parse("foo\nbar")
    assert isinstance(d, Docstring), d
    assert d.short_description == "foo", d

# Generated at 2022-06-23 17:11:12.106427
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    deprecation_section = DeprecationSection("deprecated", "deprecation")
    assert deprecation_section.title == "deprecated"
    assert deprecation_section.key == "deprecation"
    assert deprecation_section.title_pattern == r"^\.\.\s*(deprecated)\s*::"
    

# Generated at 2022-06-23 17:11:16.486632
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    d = DeprecationSection("deprecation warning", "deprecated")
    assert d.title == "deprecation warning"
    assert d.key == "deprecated"
    assert d.title_pattern == r"^\.\.\s*(deprecation warning)\s*::"


# Generated at 2022-06-23 17:11:21.159138
# Unit test for constructor of class ParamSection
def test_ParamSection():
    title = "Parameters"
    key = "param"
    section = ParamSection(title, key)
    assert section.title_pattern == "^({})\s*?\n{}\s*$".format(title, "-" * len(title))
    assert section.title == title
    assert section.key == key


# Generated at 2022-06-23 17:11:33.700006
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """Unit test for method parse of class NumpydocParser."""
    docstring = """
    test whether or not model is fitted
    Parameters
    ----------
    model : object
        Estimator object to test.
    Returns
    -------
    out : bool
        True if the model is fitted
    Raises
    ------
    AttributeError
        Something is wrong with the model
    Examples
    --------
    There are some examples in :ref:`/build/html/index.html#examples`.
    """

# Generated at 2022-06-23 17:11:37.917776
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section_title = "Raises"
    section_key = "raises"

    raise_section = RaisesSection(section_title, section_key)

    assert(raise_section.title == section_title)
    assert(raise_section.key == section_key)


# Generated at 2022-06-23 17:11:46.209398
# Unit test for constructor of class ParamSection
def test_ParamSection():
    # Case 1: Given the name of the section and the key, the constructor
    # returns a parameterSection object with title = ARGUMENSTS, key = param
    # and the regular expression
    newParamSection = ParamSection("Arguments", "param")
    title = "Arguments"
    key = "param"
    assert newParamSection.title == title
    assert newParamSection.key == key
    assert newParamSection.title_pattern == '^Arguments\\s*?\\n-*$'
    parameterSection = ParamSection("Arguments", "param")
    title = "Arguments"
    key = "param"
    assert parameterSection.title == title
    assert parameterSection.key == key
    assert parameterSection.title_pattern == '^Arguments\\s*?\\n-*$'
    # Case 2: Given the

# Generated at 2022-06-23 17:11:51.360967
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    """Assert that ReturnsSection is correctly constructed."""
    assert ReturnsSection("Returns","returns").title == "Returns"
    assert ReturnsSection("Returns","returns").key == "returns"
    assert ReturnsSection("Returns","returns").is_generator == False



# Generated at 2022-06-23 17:11:53.730569
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    a=ReturnsSection("Returns", "returns")
    assert a.key=="returns"

# Generated at 2022-06-23 17:11:56.529801
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    section = Section("Attributes", "attribute")
    parser = NumpydocParser()
    parser.add_section(section)
    assert section in parser.sections.values()


# Generated at 2022-06-23 17:12:02.907883
# Unit test for method parse of class Section
def test_Section_parse():
    a = Section(title = "A", key = "x")
    b = a.parse("This is a text.\nThis is a second text.")
    b = list(b)
    assert b[0].args == ['x']
    assert b[0].description == 'This is a text.This is a second text.'
   

# Generated at 2022-06-23 17:12:05.895214
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    r = ReturnsSection("Returns", "returns")
    assert r.title == "Returns"
    assert r.key == "returns"


# Generated at 2022-06-23 17:12:14.955423
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection("Parameters","param").title == "Parameters"
    assert ParamSection("Parameters","param").key == "param"
    assert ParamSection("Params","param").title == "Params"
    assert ParamSection("Params","param").key == "param"
    assert ParamSection("Arguments","param").title == "Arguments"
    assert ParamSection("Arguments","param").key == "param"
    assert ParamSection("Args","param").title == "Args"
    assert ParamSection("Args","param").key == "param"
    assert ParamSection("Other Parameters","other_param").title == "Other Parameters"
    assert ParamSection("Other Parameters","other_param").key == "other_param"
    assert ParamSection("Other Params","other_param").title == "Other Params"

# Generated at 2022-06-23 17:12:26.193243
# Unit test for method parse of class Section
def test_Section_parse():
    parser = NumpydocParser()

# Generated at 2022-06-23 17:12:29.133065
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    # create a dummy section
    section = _SphinxSection("title", "key")
    assert section.title_pattern == r"^\.\.\s*(title)\s*::"

# Generated at 2022-06-23 17:12:34.756458
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    sec = ReturnsSection("Returns", "returns")
    with pytest.raises(TypeError):
        sec = ReturnsSection("Returns", None)
        sec = ReturnsSection(None, "returns")
        sec = ReturnsSection(None, None)
    sec = ReturnsSection("Returns", "returns")
    with pytest.raises(TypeError):
        sec = ReturnsSection(1, 2)


# Generated at 2022-06-23 17:12:43.383685
# Unit test for method parse of class Section
def test_Section_parse():
    text = """\
    PARAMETERS:
        :param title: this is the title
    """
    sections = [Section("PARAMETERS:", "key")]
    assert len(NumpydocParser(sections).parse(text).meta) == 1

    text = """\
    PARAMETERS:
        this is not a title
    """
    sections = [Section("PARAMETERS:", "key")]
    assert len(NumpydocParser(sections).parse(text).meta) == 0



# Generated at 2022-06-23 17:12:48.726269
# Unit test for function parse
def test_parse():
    def do_parse(text):
        return parse(text)

    assert do_parse("") == Docstring()
    assert do_parse("foo") == Docstring(
        short_description="foo",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="",
        meta=[],
    )
    assert do_parse("foo\n") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="",
        meta=[],
    )

# Generated at 2022-06-23 17:12:54.279213
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    section = Section("Name", "name")
    parser.add_section(section)

    assert parser.sections["Name"] == section
    assert parser.titles_re == re.compile(r"^Name\s*?\n-*$", flags=re.M)

# Generated at 2022-06-23 17:13:01.405857
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 4.0.0
        Test deprecated this method
    """

    deprecation = DeprecationSection("deprecated", "deprecation")
    deprecated = deprecation.parse(text)
    for _deprecated in deprecated:
        assert len(_deprecated.description) > 0
        assert repr(_deprecated) == "DeprecationWarning(deprecation, '4.0.0', None, None)"

# Generated at 2022-06-23 17:13:11.111986
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    print("Unit test for method parse of class NumpydocParser")
    test_docstring1 = """Compute the sigmoid of x.

Parameters
----------
x
y
    y value

Returns
-------
sigmoid(x)

Examples
--------
>>> sigmoid(2)
0.8807970779778823"""

    test_docstring2 = """Reverse a string

Parameters
----------
my_str : str
    String to be reversed

Returns
-------
reversed_str : str
    String in reverse order

Examples
--------
>>> reverse_str("Hello World")
Dlrow olleH"""

    NumpydocParser().parse(test_docstring1)
    NumpydocParser().parse(test_docstring2)
    print("Unit test successful")

# Generated at 2022-06-23 17:13:21.349928
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # test empty docstring
    value = ''
    expected_result = DocstringMeta([], description=None)
    section = _KVSection('', '')
    result = list(section.parse(value))
    assert result == [expected_result]
    # test with two keys
    value = 'first_key\n\tfirst_value\nsecond_key\n\tsecond_value'
    expected_result = [DocstringMeta(['', 'first_key'], description='first_value'),
                       DocstringMeta(['', 'second_key'], description='second_value')]
    section = _KVSection('', '')
    result = list(section.parse(value))
    assert result == expected_result

# Generated at 2022-06-23 17:13:23.203189
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
	a = YieldsSection("Yields", "yields")
	return None

test_YieldsSection()

# Generated at 2022-06-23 17:13:30.601682
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    assert parser.parse("") == Docstring()

    text = """
    Do something to a pandas DataFrame.
    
    Parameters
    ----------
    df : dataframe
        A pandas DataFrame
    """

    assert parser.parse(text) == Docstring(
        short_description="Do something to a pandas DataFrame.",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(
                ["param", "df"],
                description='A pandas DataFrame',
                arg_name='df',
                type_name='dataframe',
            )
        ],
    )

# Generated at 2022-06-23 17:13:32.906824
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = """
    Parses method name and parses docstring to get meta datas
    :param b: something
    :type text: str
    :returns: doc
    :rtype: dict
    """
    parser = NumpydocParser()
    ret = parser.parse(docstring)
    print(ret)


if __name__ == "__main__":
    test_NumpydocParser_parse()

# Generated at 2022-06-23 17:13:37.601143
# Unit test for method parse of class Section
def test_Section_parse():
    sec = Section("See also", "see_also")
    text = """
    Something
    """
    desired_result = [
        DocstringMeta(args=["see_also"], description="Something")
    ]
    results = sec.parse(text)
    assert list(results) == desired_result



# Generated at 2022-06-23 17:13:46.487728
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
   #Testing the title_pattern
    title_pattern = _SphinxSection("Params","param").title_pattern
    assert title_pattern == "^\\.\\.\\s*(Params)\\s*::", "Title pattern is not correct"
    #Testing the parse function
    parse_results = _SphinxSection("Params","param").parse(".. params:: \n a \n b")
    assert parse_results == [], "Parse function is not correct"
    return

# Generated at 2022-06-23 17:13:53.379031
# Unit test for method parse of class Section
def test_Section_parse():
    text = """
    .. deprecated:: 1.0

    This function is deprecated. Use *new_function* instead.
    """
    assert DeprecationSection(
        title="deprecated",
        key="deprecation",
    ).parse(text) == [DocstringDeprecated(
        args=['deprecation'],
        description='This function is deprecated. Use *new_function* instead.',
        version='1.0'
    )]



# Generated at 2022-06-23 17:13:56.851968
# Unit test for constructor of class ParamSection
def test_ParamSection():
    """Unit test for constructor of class ParamSection"""
    actual = ParamSection("Parameters", "param")
    assert actual.key == "param"


# Generated at 2022-06-23 17:14:00.575712
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    test_section = ParamSection("Params","param")
    parser = NumpydocParser()
    parser.add_section(test_section)
    assert test_section.title in parser.sections.keys()


# Generated at 2022-06-23 17:14:04.072923
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    text_of_docstring = """
    what:str
        what is this
    """
    section = Section("what", "what")
    parser = NumpydocParser()
    parser.add_section(section)
    docstring = parser.parse(text_of_docstring)
    assert docstring.meta==[DocstringMeta(args=['what'], description='what is this')]

# Generated at 2022-06-23 17:14:06.323163
# Unit test for constructor of class Section
def test_Section():
    section1 = Section("Parameters", "param")
    assert section1.title == "Parameters"
    assert section1.key == "param"


# Generated at 2022-06-23 17:14:10.361802
# Unit test for constructor of class ParamSection
def test_ParamSection():
    test_param = ParamSection("Parameters", "param")
    print(test_param.title)
    print(test_param.key)

# test_param = ParamSection("Parameters", "param")
# print(test_param.title)
# print(test_param.key)
# print(test_param.title_pattern)


# Generated at 2022-06-23 17:14:12.502572
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert(YieldsSection.is_generator is True)
    
test_YieldsSection()

# Generated at 2022-06-23 17:14:16.804923
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    NumpydocParser(sections=[ParamSection("Parameters", "param")])._KVSection.parse("")
    NumpydocParser(sections=[ParamSection("Parameters", "param")])._KVSection.parse("\n")

# Generated at 2022-06-23 17:14:22.807439
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    my_section = Section('Topic', 'topic')
    parser.add_section(my_section)
    assert parser.parse('Topic\n------\nabc.').meta == [DocstringMeta(['topic'], description='abc.')]
    assert parser.parse('abc.').meta == []

# Generated at 2022-06-23 17:14:27.534648
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    parser = ReturnsSection("Returns", "returns")
    assert parser.is_generator == False
    assert parser.title == "Returns"
    assert parser.key == "returns"
    assert parser.title_pattern == "^Returns\s*?\n=+\s*$"


# Generated at 2022-06-23 17:14:28.104198
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    pass

# Generated at 2022-06-23 17:14:31.027918
# Unit test for constructor of class ParamSection
def test_ParamSection():
    constr = ParamSection("Parameters", "param")
    assert constr.title == "Parameters"
    assert constr.key == "param"
    assert constr.title_pattern == "^(Parameters)\s*?\n\s*$"

# Generated at 2022-06-23 17:14:36.542776
# Unit test for constructor of class Section
def test_Section():
    test_S = Section("Title", "key")
    assert test_S.title == "Title"
    assert test_S.key == "key"
    assert test_S.title_pattern == "^(Title)\s*?\n{}\s*$".format('-' * len("Title"))


# Generated at 2022-06-23 17:14:46.567408
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    original_text = inspect.cleandoc(
        """
        .. deprecated:: 2.0.0
            Should not be used any more as it has major issues.
        """
    )
    cleaned_text = inspect.cleandoc(
        """
        deprecated:: 2.0.0
        Should not be used any more as it has major issues.
        """
    )
    section = DeprecationSection("deprecated", "deprecation")
    parsed_return = section.parse(cleaned_text)
    for ret in parsed_return:
        assert ret.description == "Should not be used any more as it has major issues."
        assert ret.version == "2.0.0"

# Generated at 2022-06-23 17:14:58.329851
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstr = """
    get_expectation_value(self, i, j, operator, x, derivative=0)
    Return expectation value of 1-body operator.
    Parameters
    ----------
    i: int
        First particle index
    j: int
        Second particle index
    x: array_like
        Position matrix
    operator: str
        One-body operator
    derivative: int, optional
        Derivative of the expectation value with respect to the
        variational parameter (default: 0)
    Returns
    -------
    e: array_like
        Expectation value
    """

# Generated at 2022-06-23 17:15:03.737133
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    numpydoc_parser = NumpydocParser()
    numpydoc_parser.add_section(Section("New Section", "new_section"))
    _, _, keywords = numpydoc_parser.titles_re.partition("deprecated")
    assert keywords == " |New Section"
    assert numpydoc_parser.sections["New Section"] == Section("New Section", "new_section")

# Generated at 2022-06-23 17:15:16.651259
# Unit test for function parse
def test_parse():
    global parse
    assert parse("\n") == Docstring(
        short_description=None,
        blank_after_short_description=True,
        long_description=None,
        meta=[],
    )
    assert parse("") == Docstring(
        short_description=None,
        blank_after_short_description=False,
        long_description=None,
        meta=[],
    )
    assert parse("foo") == Docstring(
        short_description="foo",
        blank_after_short_description=False,
        long_description=None,
        meta=[],
    )
    assert parse("foo\n    ") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        long_description=None,
        meta=[],
    )
    assert parse

# Generated at 2022-06-23 17:15:20.796183
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    title = 'Yields'
    key = 'yields'
    test_obj = YieldsSection(title, key)
    assert test_obj.title == title
    assert test_obj.key == key
    assert test_obj.is_generator

# Generated at 2022-06-23 17:15:25.309974
# Unit test for constructor of class ParamSection
def test_ParamSection():
    title = "Parameters"
    key = "param"
    param_object = ParamSection(title, key)
    assert param_object.title == title and param_object.key == key
    param_object.title = "Arguments"
    param_object.key = "args"
    assert param_object.title != title and param_object.key != key



# Generated at 2022-06-23 17:15:27.158679
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection("Yields", "yields")
    assert y.key == "yields"
    assert y.is_generator == True
    assert y.title =="Yields"

# Generated at 2022-06-23 17:15:30.692170
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    data = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    assert True

# Generated at 2022-06-23 17:15:38.877993
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    test
        val1
        val2
    test2
        val3
    test3:int
        val5
    """
    assert list(_KVSection('test', 'test').parse(text))[0].description == 'val1\nval2'
    assert list(_KVSection('test', 'test').parse(text))[1].description == 'val3'
    assert list(_KVSection('test', 'test').parse(text))[2].description == 'val5'

# Generated at 2022-06-23 17:15:47.641148
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.
    Long description.

    Parameters
    ----------
    arg1 : int
        description for arg1

    arg2 : str
        description for arg2.
        spans 2 lines

    Raises
    ------
    ValueError
        description for ValueError
        spans 2 lines

    """
    parsed = parse(docstring)

    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False

    assert len(parsed.meta) == 2

    param = parsed.meta[0]
    assert param.arg_name == "arg1"
    assert param.type_name == "int"
    assert param.is_optional == False


# Generated at 2022-06-23 17:15:56.686461
# Unit test for method parse of class Section
def test_Section_parse():
    """Unit test for Section.parse()"""
    section_text = """

    .. deprecated :: 0.6.0
        Use :func:`~fatiando.seismic.greens.gaussianbeam.kinematic` instead.
        It has the same interface but is more efficient.

    .. versionadded:: 0.6.0

    """
    section_instance = DeprecationSection("deprecated", "deprecation")
    section_parse = section_instance.parse(section_text)
    assert str(list(section_parse)) == '[deprecation]'