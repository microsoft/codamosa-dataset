

# Generated at 2022-06-23 17:06:02.831215
# Unit test for function parse
def test_parse():
    text = """
    Line 1
    Line 2
    Line 3
    Line 4
    Line 5
    """

    docstring = parse(text)
    assert docstring.short_description == "Line 1"
    assert docstring.long_description == "Line 2\nLine 3\nLine 4"
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == True
    assert docstring.meta == []

    text = """
    Line 1
    Line 2
    Line 3
    Line 4
    Line 5

    """

    docstring = parse(text)
    assert docstring.short_description == "Line 1"
    assert docstring.long_description == "Line 2\nLine 3\nLine 4"
    assert docstring.blank_after_short_description == False

# Generated at 2022-06-23 17:06:05.717402
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    deprecation_section = DeprecationSection('a', 'b')
    assert deprecation_section.title == 'a'
    assert deprecation_section.key == 'b'
    assert deprecation_section.title_pattern == '^\.\.\\s*(a)\\s*::'


# Generated at 2022-06-23 17:06:17.351776
# Unit test for function parse
def test_parse():
    import pytest

    def func():
        """
        Docstring first line is a short description
        Additional lines of the docstring are the long description.

        Parameters
        ----------
        arg1 : int
            Description for arg1, with an optional default
            value (default is None)
        arg2 : str, optional
            Description for arg2, it's optional

        Returns
        -------
        None
            Description for the return value
        """
        pass

    docstring_obj = parse(inspect.cleandoc(func.__doc__))
    docstring_obj.meta["param"] = list(docstring_obj.meta["param"])
    assert docstring_obj.short_description == "Docstring first line is a short description"
    assert docstring_obj.long_description == "Additional lines of the docstring are the long description."

# Generated at 2022-06-23 17:06:21.213205
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    sect = DeprecationSection("Deprecated", "deprecated")
    if (sect.title != "Deprecated" or
        sect.key != "deprecated" or
        sect.title_pattern != "^\.\.\s*(Deprecated)\\s*::"):
        raise AssertionError("Failed to instantiate DeprecationSection")


# Generated at 2022-06-23 17:06:23.660064
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
	title = "Yields"
	key = "yields"
	YieldsSection(title, key)


# Generated at 2022-06-23 17:06:26.981036
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "title"
    key = "key"
    s = _SphinxSection(title, key)
    assert s.title == title
    assert s.key == key

# Generated at 2022-06-23 17:06:37.801883
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    p = ParamSection("Parameters", "param")
    text = """
        arg_name
            arg_description
        arg_2 : type, optional
            descriptions can also span...
            ... multiple lines
    """
    pa = p.parse(text)
    assert pa is not None
    assert len(pa) == 2
    assert pa[0].args == ["param", "arg_name"]
    assert pa[0].arg_name == "arg_name"
    assert pa[0].type_name == None
    assert pa[0].is_optional == None
    assert pa[0].default == None
    assert pa[0].description == "arg_description"
    assert pa[1].args == ["param", "arg_2"]
    assert pa[1].arg_name == "arg_2"
    assert pa[1].type_

# Generated at 2022-06-23 17:06:40.650201
# Unit test for constructor of class _KVSection
def test__KVSection():
    try:
        title = "Parameter"
        key = "param"
        _KVSection(title, key)
    except Exception as e:
        print("Exception thrown in constructor of class _KVSection")
        print(e)


# Generated at 2022-06-23 17:06:43.570475
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    """Unit test for constructor of class ReturnsSection"""
    rs = {"returns": "some_var", "return_type":"type_name"}
    assert(ReturnsSection('Returns', rs['returns']).__dict__ == {'key': 'returns', 'title': 'Returns'})


# Generated at 2022-06-23 17:06:49.843407
# Unit test for function parse
def test_parse():
    def foo(x, y=1):
        """
        Short description

        Long description is optional
        but can span multiple lines
        """
        pass

    # TODO: test using the doctest for docstringparser by creating classes
    # with doctest-style docstrings.
    x = foo.__doc__
    print(parse(x))



# Generated at 2022-06-23 17:06:56.825258
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert NumpydocParser.__doc__ == """Setup sections.

        :param sections: Recognized sections or None to defaults.
        """
    assert NumpydocParser._setup.__doc__ == ""
    assert NumpydocParser.add_section.__doc__ == """Add or replace a section.

        :param section: The new section."""
    assert NumpydocParser.parse.__doc__ == """Parse the numpy-style docstring into its components.

        :returns: parsed docstring
        """


# Generated at 2022-06-23 17:06:57.856696
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # TODO
    pass



# Generated at 2022-06-23 17:07:00.491589
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    print("test_DeprecationSection:")
    assert DeprecationSection("deprecated", "deprecation").title == "deprecated"



# Generated at 2022-06-23 17:07:04.592851
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert DeprecationSection("deprecated","deprecation").parse("v1.0.1\nA description of what might raise DeprecationWarning") == \
    [DocstringDeprecated(args=['deprecation'], description='A description of what might raise DeprecationWarning', version='v1.0.1')]



# Generated at 2022-06-23 17:07:12.784405
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:07:15.416707
# Unit test for constructor of class _KVSection
def test__KVSection():
    _=_KVSection("Parameters", "param")

# Generated at 2022-06-23 17:07:24.648963
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    parser = ReturnsSection("Returns", "returns")
    return_name, type_name = parser.parse("Returns: type\n    Some description")
    assert return_name.args == ["returns"]
    assert return_name.description == "Some description"
    assert type_name == "type"

    return_name, type_name = parser.parse("type\n    Some description")
    assert return_name.args == ["returns"]
    assert return_name.description == "Some description"
    assert type_name == "type"

    return_name, type_name = parser.parse("Some description")
    assert return_name.args == ["returns"]
    assert return_name.description == "Some description"
    assert type_name is None


# Generated at 2022-06-23 17:07:28.465978
# Unit test for constructor of class _KVSection
def test__KVSection():
    assert _KVSection.__name__ == "_KVSection"
    s = _KVSection(title = "Test", key = "key")
    assert s.title == "Test"
    assert s.key == "key"
    assert s.title_pattern == "^(Test)\s*?\n---*\s*$"


# Generated at 2022-06-23 17:07:38.574978
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    #Example 1
    kvs = _KVSection("Test", "other_param")
    text = "arg_name\n    arg_description\n" + \
           "arg_2 : type, optional\n    descriptions can also span..." + \
           "\n    ... multiple lines"
    meta = kvs.parse(text)
    ret = next(meta)
    assert ret.args == ['other_param', 'arg_name']
    assert ret.arg_name == 'arg_name'
    assert ret.type_name == None
    assert ret.is_optional == False
    ret = next(meta)
    assert ret.args == ['other_param', 'arg_2']
    assert ret.arg_name == 'arg_2'
    assert ret.type_name == 'type'

# Generated at 2022-06-23 17:07:44.538905
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    doc = """
This is the short description. It can span multiple lines
and is separated from the long description by a blank line.

The long description can contain entire paragraphs.

.. deprecated:: 0.2.0
    This feature is deprecated, please don't use this.

Parameters
----------
param : int
    This is a parameter.

Returns
-------
int
    The return value.

Raises
------
ValueError
    This is an exception.
    It's description can span multiple lines.

See Also
--------
func
    Another function.
"""
    ret = NumpydocParser().parse(doc)
    assert ret.short_description == 'This is the short description. It can span multiple lines\nand is separated from the long description by a blank line.'

# Generated at 2022-06-23 17:07:46.302712
# Unit test for constructor of class _KVSection
def test__KVSection():
    section = _KVSection("", "")
    assert section.title == ""
    assert section.key == ""


# Generated at 2022-06-23 17:07:48.348339
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section = _SphinxSection("Params", "param")
    assert section.title == "Params"
    assert section.key == "param"
    assert section.title_pattern == "^\.\.\\s*(Params)\\s*::"

# Generated at 2022-06-23 17:07:51.078307
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection("title", "key").title_pattern == r"^\.\.\s*(title)\s*::"

# Generated at 2022-06-23 17:07:56.841960
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection(title="Deprecation", key="deprecated")
    text = ".. deprecated:: \n    This is a deprecation warning"
    docstring = section.parse(text)
    assert list(docstring)[0] == DocstringDeprecated(args=[section.key],\
    description=None, version="This is a deprecation warning")


# Generated at 2022-06-23 17:08:07.306733
# Unit test for method parse of class _KVSection

# Generated at 2022-06-23 17:08:08.658793
# Unit test for constructor of class ParamSection
def test_ParamSection():
    ParamSection("Parameters", "param")


# Generated at 2022-06-23 17:08:10.657074
# Unit test for constructor of class _KVSection
def test__KVSection():
    with pytest.raises(TypeError):
        _KVSection()

# Generated at 2022-06-23 17:08:13.093643
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    print("\nUnit test for constructor of class DeprecationSection:")
    a = DeprecationSection("deprecated", "deprecation")
    print("\nTest 1: ", a.key == "deprecation")
    print("Test 2: ", a.title == "deprecated")


# Generated at 2022-06-23 17:08:25.108063
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    """
    This method is created to test the add_section method of the class NumpydocParser.
    add_section method of NumpydocParser is used to add or replace a section,
    this method allows us to customize the title of the section.
    """
    parser = NumpydocParser()
    # In this test case, the section test is added,
    # and the title is assigned with the valye "test"
    parser.add_section(Section("test", "test"))
    # The test case parses the text to return the parsed docstring
    docstring = parser.parse("test\n---")
    # The meta attribute of docstring object is taken and iterated to check if the length of the iterated object is 1
    assert len(list(docstring.meta)) == 1
    # The first element of the iterated object is

# Generated at 2022-06-23 17:08:37.398073
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:08:45.804219
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:08:49.379094
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    assert inspect.cleandoc(".. deprecated:: 0.0.1\n    description") == "0.0.1\n    description\n"


# Generated at 2022-06-23 17:08:53.882285
# Unit test for function parse
def test_parse():
    """Test parse docstring"""

# Generated at 2022-06-23 17:08:57.744917
# Unit test for constructor of class Section
def test_Section():
    title = "this is a test title"
    key = "this is a test key"
    test_section = Section(title, key)
    assert test_section.title == title
    assert test_section.key == key


# Generated at 2022-06-23 17:08:59.393263
# Unit test for constructor of class _KVSection
def test__KVSection():
    return _KVSection("Parameters", "param")


# Generated at 2022-06-23 17:09:03.648763
# Unit test for method parse of class Section
def test_Section_parse():
    sec = Section('Parameters', 'param')
    text ='''
    gdf
        Graph dataframe
    '''
    assert DocstringMeta([sec.key], description = 'Graph dataframe') in sec.parse(text)


# Generated at 2022-06-23 17:09:07.623744
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    test_section = _SphinxSection("title:: something", "key")
    test_pattern = r"^\.\.\s*(title:: something)\s*::"
    assert test_section.title_pattern == test_pattern

# Generated at 2022-06-23 17:09:15.492934
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser().parse("") == Docstring()
    assert NumpydocParser().parse(None) == Docstring()
    assert NumpydocParser().parse("short") == Docstring(short_description="short")
    assert NumpydocParser().parse("short\n\nlong") == Docstring(short_description="short", \
                                                                long_description="long")
    assert NumpydocParser().parse("short\nlong") == Docstring(short_description="short", \
                                                               long_description="long")
    assert NumpydocParser().parse("short\n\nlong\n\n") == Docstring(short_description="short", \
                                                                    long_description="long")


# Generated at 2022-06-23 17:09:26.477891
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc('''
    A function that ties it all together.

    Parameters
    ----------
    value : str
        Description of the important parameter

    Returns
    -------
    Output: str
        Description of what this function returns

    Raises
    ------
    ValueError
        If the value is high

    Warns
    -----
    UserWarning
        If the user does something stupid

    Other Parameters
    ----------------
    kwarg : str
        Description of kwarg
    ''')

# Generated at 2022-06-23 17:09:38.444164
# Unit test for function parse
def test_parse():
    assert parse('Test function.\n\nThis function can do nothing.\n') == Docstring(
        short_description="Test function.",
        blank_after_short_description=True,
        long_description="This function can do nothing.",
        blank_after_long_description=True
    )
    assert parse("Test function.\n") == Docstring(
        short_description="Test function.",
        blank_after_short_description=True
    )
    assert parse("Test function.") == Docstring(
        short_description="Test function."
    )
    # test blank after short description
    assert parse("Test function.\n\nArgs:") == Docstring(
        short_description="Test function.",
        blank_after_short_description=True
    )
    assert parse("Test function.\nArgs:") == Docstring

# Generated at 2022-06-23 17:09:47.434908
# Unit test for constructor of class ParamSection
def test_ParamSection():
    i = ParamSection("Parameters", "param")
    assert i.parse("a: int\nThe first parameter\nb: str\nThe second parameter") == [DocstringParam([
        'param', 'a'], description=str('The first parameter'), arg_name='a', type_name='int', is_optional=False, default=None), DocstringParam([
        'param', 'b'], description=str('The second parameter'), arg_name='b', type_name='str', is_optional=False, default=None)]
    

# Generated at 2022-06-23 17:09:58.301024
# Unit test for function parse
def test_parse():
    """Test the numpy-style docstring parser against sample docstrings.

    The example docstrings are taken from the numpy ``numpy.count_nonzero``
    function.

    https://github.com/numpy/numpy/blob/master/numpy/core/fromnumeric.py#L1835-L1847
    """

    from . import Docstring, DocstringMeta


# Generated at 2022-06-23 17:10:02.944839
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert len(DeprecationSection("deprecated", "deprecation").parse("1.0\ndeprecation")) == 1


# Generated at 2022-06-23 17:10:04.991038
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    YieldsSection.is_generator = True
    section = YieldsSection("Yields", "yields")
    pass

# Generated at 2022-06-23 17:10:12.891886
# Unit test for method parse of class _KVSection

# Generated at 2022-06-23 17:10:20.150611
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    r=ReturnsSection("Returns","returns")
    print(r.__dict__)
    print(r.is_generator)

if __name__ == "__main__":
    test_ReturnsSection()
"""
# pprint.pprint(parse("Takes \n\n\n something else"))
print("*"*30)
print(parse("Takes \n\n\n something else").__dict__)
print("*"*30)
"""

# Generated at 2022-06-23 17:10:26.869223
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    print("test in constructor of class DeprecationSection:")
    ds = DeprecationSection("deprecated", "deprecation")
    assert ds.key == "deprecation"
    assert ds.title == "deprecated"
    assert ds.title_pattern == r"^\.\.\s*({})\s*::".format(ds.title)


# Generated at 2022-06-23 17:10:35.801932
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert(str(NumpydocParser()) == "[<Section object>]")

# Generated at 2022-06-23 17:10:38.093507
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raise_section = RaisesSection("Raises", "raises")
    print(raise_section)

# Generated at 2022-06-23 17:10:42.737022
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    section = Section("Title", "title")
    parser = NumpydocParser()
    parser.add_section(section)
    assert section == parser.sections["Title"]



# Generated at 2022-06-23 17:10:46.736678
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    testFunction = ReturnsSection("Returns", "returns")
    assert testFunction.title == "Returns"
    assert testFunction.key == "returns"
    assert testFunction.is_generator == False


# Generated at 2022-06-23 17:10:48.735104
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section = RaisesSection("Raises",1)
    assert section.key == 1

# Generated at 2022-06-23 17:10:49.779497
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rs = RaisesSection("Raises", "raises")

# Generated at 2022-06-23 17:10:55.917462
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstring = NumpydocParser().parse(
        """
    show mapping from the given column name(s) to the new ones.

    Parameters
    ----------
    a : type
        description of `a`

    b : type
        description of `b`

    c : type, optional
        description of `c`

    Returns
    -------
    d : type
        description of `d`

    e : type
        description of `e`

    """
    )
    return docstring

# Generated at 2022-06-23 17:11:00.972041
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    parser = NumpydocParser()

    text = """Deprecation Warning
deprecated since version 0.1.0"""

    expected_result = {'args': ['deprecation'],
                       'description': 'deprecated since version 0.1.0',
                       'version': 'deprecated since version 0.1.0'}

    result = list(parser.parse(text).meta)[0]
    assert result == expected_result



# Generated at 2022-06-23 17:11:05.297984
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = [ParamSection("Parameters", "param"), ReturnsSection("Returns", "returns"),
                RaisesSection("Raises", "raises")]
    s = NumpydocParser(sections)
    assert len(s.sections) == 3

# Generated at 2022-06-23 17:11:16.244319
# Unit test for method parse of class Section
def test_Section_parse():
    # checking for all types of sections, here this is Section, not Subsection

    lineNumbers = ['1', '2', '3', '4', '5']
    lineTypes = ['param', 'returns', 'raises', 'other_param', 'examples']
    # lineNames = ['x1', 'x2', 'x3', 'x4', 'x5']


    for i in range (len(lineNumbers)):
        s = Section(lineTypes[i], lineTypes[i])
        st = f"{lineTypes[i]}\n------------\n{lineNumbers[i]}"
        print(s.parse(st))


if __name__ == "__main__":
    test_Section_parse()

# Generated at 2022-06-23 17:11:19.159271
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    name = "Returns"
    key = "returns"
    test = ReturnsSection(name, key)
    assert test.title == name
    assert test.key == key
    assert test.is_generator == False

# Generated at 2022-06-23 17:11:20.663312
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    test = YieldsSection("Yields", "yields")
    assert test.is_generator == True

# Generated at 2022-06-23 17:11:33.027958
# Unit test for method parse of class Section
def test_Section_parse():
    text = """.. title:: something
            possibly over multiple lines"""
    assert inspect.cleandoc(text) == "something possibly over multiple lines"

if __name__ == "__main__":
    d = Docstring()
    text = """
        Function description.

        More description.

        Parameters
        ----------
        param_name : str
            Parameter description.

        Returns
        -------
        return_name : type
            Return description.

        Notes
        -----
        Some notes.
        """
    d = parse(text)
    print(d)
    print(d.meta)
    print(d.long_description)
    text = """
        .. title:: something
            possibly over multiple lines
        """
    assert inspect.cleandoc(text) == "something possibly over multiple lines"

# Generated at 2022-06-23 17:11:37.923015
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecated", "deprecation")
    text = """
    .. deprecated:: 1.0.0

        Use ``something_else`` instead.
    """
    text = inspect.cleandoc(text)
    r = section.parse(text)
    # test return instance DocstringDeprecated
    assert isinstance(r, tuple) and isinstance(r[0], DocstringDeprecated)
    # test contents of args
    assert r[0].args == ["deprecation"]
    # test contents of version
    assert r[0].version == "1.0.0"
    # test contents of description
    assert r[0].description == "Use ``something_else`` instead."

# Generated at 2022-06-23 17:11:41.263097
# Unit test for constructor of class Section
def test_Section():
    """
    Test the constructor of class Section.
    """
    assert Section("Parameters", "param") is not None
    assert Section("Parameters", "param").title == "Parameters"
    assert Section("Parameters", "param").key == "param"


# Generated at 2022-06-23 17:11:43.017509
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yields = YieldsSection("Yields", "yields")
    assert yields.is_generator



# Generated at 2022-06-23 17:11:55.406412
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    desc = "short description"
    long_desc = "long description"
    deprecation_version = "3.4"
    deprecation_description = "description of deprecation"

    text = "\n".join(
        [
            desc,
            "",
            ".. deprecated:: {}".format(deprecation_version),
            "",
            deprecation_description,
            "",
            long_desc,
        ]
    )
    result = parse(text)

    expected_meta = [
        DocstringDeprecated(
            args=["deprecation"],
            description=deprecation_description,
            version=deprecation_version,
        )
    ]

    assert result.short_description == desc
    assert result.long_description == long_desc


# Generated at 2022-06-23 17:12:00.684551
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    method_body = DeprecationSection("deprecated", "Deprecation warning for deprecated section").parse("\n3.3.3\n    A description of this deprecated section\n")
    assert method_body == (DocstringDeprecated(['deprecated'], 'A description of this deprecated section', '3.3.3'),)

# Generated at 2022-06-23 17:12:07.015018
# Unit test for method parse of class Section
def test_Section_parse():
    section = Section("Section", "key")
    text = "description\n"
    assert(section.parse(text) == [DocstringMeta(args=['key'], description='description')])
    text = "description\n\n"
    assert(section.parse(text) == [DocstringMeta(args=['key'], description='description')])



# Generated at 2022-06-23 17:12:12.279305
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    expected = ['deprecation', '1.0', 'Use `f` instead.']
    doc = NumpydocParser()
    doc.add_section(DeprecationSection("deprecated", "deprecation"))
    docstring = doc.parse(".. deprecated:: 1.0\n    Use `f` instead.")
    assert [x.key for x in docstring.meta] == expected

# Generated at 2022-06-23 17:12:22.139752
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    input_string = """
    .. deprecated:: 0.0.1
        Deprecated section
    """
    test_section = _SphinxSection.__new__(_SphinxSection)
    test_section.title = "deprecated"
    test_section.key = "deprecation"
    test_parsed = test_section.parse(input_string)
    for parsed in test_parsed:
        assert parsed.args[0] == "deprecation"
        assert parsed.args[1] == "0.0.1"
        assert parsed.description == "Deprecated section"

# Generated at 2022-06-23 17:12:33.814730
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection('Parameters', 'param').key == 'param'
    assert ParamSection('Params', 'param').key == 'param'
    assert ParamSection('Arguments', 'param').key == 'param'
    assert ParamSection('Args', 'param').key == 'param'
    assert ParamSection('Other Parameters', 'other_param').key == 'other_param'
    assert ParamSection('Other Params', 'other_param').key == 'other_param'
    assert ParamSection('Other Arguments', 'other_param').key == 'other_param'
    assert ParamSection('Other Args', 'other_param').key == 'other_param'
    assert ParamSection('Receives', 'receives').key == 'receives'
    assert ParamSection('Receive', 'receives').key == 'receives'

# Generated at 2022-06-23 17:12:46.681399
# Unit test for function parse

# Generated at 2022-06-23 17:12:53.554957
# Unit test for function parse
def test_parse():
    doc = """
    Function specification

    This is an example function specification.  Normally this would be
    called by autodoc.

    Args
    ----
    arg1 : str
        first argument
    arg2 : int
        second argument

    Returns
    -------
    out1 : int
        first output
    out2 : float
        second output

    Raises
    ------
    ValueError
        if unsuccessful
    """

# Generated at 2022-06-23 17:13:02.416669
# Unit test for function parse
def test_parse():
    text = """
    This is a sample docstring
    
    Parameters
    ----------
    param_a : int
        this is a description of param_a
    param_b : str
        this is a description of param_b
        spread over
        multiple lines
    
    Returns
    -------
    :obj:`thing`
        a thing"""

    docstring=parse(text)
    assert docstring.short_description == "This is a sample docstring"
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description
    assert docstring.long_description == None
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'param_a']

# Generated at 2022-06-23 17:13:07.347250
# Unit test for constructor of class Section
def test_Section():
    title = 'Parameters'
    key = 'param'
    section = Section(title, key)
    assert section.title_pattern == r'^(Parameters)\s*?\n------*\s*$'
    assert section.title == title
    assert section.key == key


# Generated at 2022-06-23 17:13:10.505505
# Unit test for constructor of class Section
def test_Section():
    sec = Section("Parameters", "param")
    assert sec.title == "Parameters"
    assert sec.key == "param"
    assert sec.title_pattern == r"^Parameters\s*?\n----------\s*$"
    sec.parse("hello world")


# Generated at 2022-06-23 17:13:11.568760
# Unit test for constructor of class Section
def test_Section():
    assert Section("Parameters", "param")


# Generated at 2022-06-23 17:13:16.735289
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    test1 = DeprecationSection("deprecated", "deprecation")
    assert test1.title_pattern == '^\.\.\s*(deprecated)\s*::' and test1.key == 'deprecation' and test1.title == 'deprecated'


# Generated at 2022-06-23 17:13:21.732448
# Unit test for constructor of class _KVSection
def test__KVSection():
    # In case of raising a error, the code will be stoped
    with open('test.txt', 'r') as csvfile:
        lines = csvfile.readlines()
    # The number of lines of test.txt
    t_lines = len(lines)
    for i in range(t_lines):
        # The number of ' ' in the lines
        t_space = lines[i].count(' ')
        # The number of ':' in the lines
        t_colon = lines[i].count(':')
        # The number of '\n' in the lines
        t_enter = lines[i].count('\n')
        # print(t_space, t_colon, t_enter)
        # The number of '\n' should be 1

# Generated at 2022-06-23 17:13:24.941099
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    section = Section('Section', 'new_section')
    parser = NumpydocParser()
    assert parser.sections.get('Section') is None
    parser.add_section(section)
    assert parser.sections.get('Section') is not None

# Generated at 2022-06-23 17:13:37.183060
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = """
    arg_name
        arg_description

    arg_2 : type, optional
        descriptions can also span...
        ... multiple lines
    """

    def _parse_item(key: str, value: str) -> DocstringParam:
        m = PARAM_KEY_REGEX.match(key)
        arg_name = type_name = is_optional = None
        if m is not None:
            arg_name, type_name = m.group("name"), m.group("type")
            if type_name is not None:
                optional_match = PARAM_OPTIONAL_REGEX.match(type_name)
                if optional_match is not None:
                    type_name = optional_match.group("type")
                    is_optional = True
                else:
                    is_optional = False

        default = None

# Generated at 2022-06-23 17:13:38.914971
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    section = YieldsSection("Yields", "yields")
    assert section.is_generator == True

# Generated at 2022-06-23 17:13:51.998107
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    from .base import DocstringMeta
    section = ReturnsSection("Returns", "returns")
    assert section.is_generator == False
    assert section.key == "returns"
    assert section.title == "Returns"
    assert section.title_pattern == r"^Returns\s*?\n=+\s*$"

# Generated at 2022-06-23 17:13:54.593198
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns")
    assert ReturnsSection("Return", "returns")


# Generated at 2022-06-23 17:14:02.217483
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("Deprecated", "deprecated")
    assert (section.parse("0.0.1") == [DocstringDeprecated(
            args=["deprecated"], description=None, version="0.0.1",
        )])
    assert (section.parse("0.0.1\nExtended\ndescription") == [DocstringDeprecated(
            args=["deprecated"], description="Extended\ndescription", version="0.0.1",
        )])


# Generated at 2022-06-23 17:14:08.028349
# Unit test for constructor of class Section
def test_Section():
    title = "Title"
    key = "key"
    s = Section(title, key)
    assert s.title == title
    assert s.title_pattern == r"^(Title)\s*?\n{}\s*$".format("-" * len(title))
    assert s.parse("") == DocstringMeta([key], description=None)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 17:14:12.350470
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    test_title = "test_title"
    test_key = "test_key"
    section = _SphinxSection(test_title, test_key)
    assert(section.title == test_title)
    assert(section.key == test_key)
    assert(section.title_pattern == r"^\.\.\s*(test_title)\s*::")



# Generated at 2022-06-23 17:14:17.496834
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    class SphinxTestSection(_SphinxSection):
        pass
    st = SphinxTestSection("test", "test")
    assert st.key == "test"
    assert st.title == "test"
    assert st.title_pattern == r"^\.\.\s*test\s*::"

# Generated at 2022-06-23 17:14:27.017346
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    teststr = """
.. deprecated:: 1.0.0
    Use :func:`pandas.DataFrame.from_records`.. deprecated:: 1.0.0
    Use :func:`pandas.DataFrame.from_records`"""
    dep_sections = DeprecationSection("Deprecated", "deprecated")
    meta_infos = dep_sections.parse(teststr)
    assert(next(meta_infos).args[1] == "1.0.0")
    assert(next(meta_infos).args[1] == "1.0.0")


# Generated at 2022-06-23 17:14:29.971680
# Unit test for constructor of class ParamSection
def test_ParamSection():
    parser = ParamSection("Parameters", "param")
    assert parser.title == "Parameters"
    assert parser.key == "param"



# Generated at 2022-06-23 17:14:30.956095
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection('Parameters', 'param')



# Generated at 2022-06-23 17:14:37.443679
# Unit test for function parse

# Generated at 2022-06-23 17:14:40.393378
# Unit test for constructor of class _KVSection
def test__KVSection():
    x = _KVSection("Parameters", "param")
    assert x.title == "Parameters"
    assert x.key == "param"


# Generated at 2022-06-23 17:14:46.152566
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    from .common import Docstring, DocstringMeta
    from .numpydoc import NumpydocParser
    numpydoc_parser = NumpydocParser()


# Generated at 2022-06-23 17:14:57.985723
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert RaisesSection("Raises", "raises").title == "Raises"
    assert RaisesSection("Raises", "raises").key == "raises"
    assert RaisesSection("Raises", "raises").title_pattern == "^Raises\\s*?\\n{}\\s*$"
    assert RaisesSection("Raises", "raises").parse("") == []
    assert RaisesSection("Raises", "raises").parse("ValueError\nA description of what might raise ValueError") == []
    assert RaisesSection("Raises", "raises").parse("ValueError\nA description of what might raise ValueError").append("") == [""]
    assert RaisesSection("Raises", "raises").parse("ValueError\nA description of what might raise ValueError").append("") == [""]
    assert Raises

# Generated at 2022-06-23 17:15:02.913909
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():

    parsed = NumpydocParser()
    print("\nUnit test for constructor of class NumpydocParser:")
    print("parsed = NumpydocParser()\nChecking parsed is not none and type is NumpydocParser:")
    print("Assertion passed\n")
    print("\n")
    return parsed


# Generated at 2022-06-23 17:15:15.317452
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:15:25.602933
# Unit test for function parse
def test_parse():
    parser = NumpydocParser()
    doc = """
    This is a one-line description.

    This is the first part of the long description.
    It spans multiple lines.

    This is the second part of the long description. It spans multiple
    lines.

    Parameters
    ----------
    arg1 : int
        The first parameter. It has a long description that spans multiple
        lines.

    arg2 : str
        The second parameter.

    arg3 : float, optional
        The third parameter. Here we have indented parameters.

    Returns
    -------
    str
        The return string.

    """

    parsed = parser.parse(doc)

# Generated at 2022-06-23 17:15:29.436263
# Unit test for constructor of class Section
def test_Section():
    test = Section("test_title", "test_key")
    assert test.title == "test_title"
    assert test.key == "test_key"



# Generated at 2022-06-23 17:15:41.700364
# Unit test for function parse
def test_parse():
    """
    to make sure parse is working.
    """
    s = parse("""
    test function
    
    Parameters
    ----------
    arg1 : type
        arg1 description. default is 3
    arg2 : str
        arg2 description. default is 'test_str'
    arg3 : int, optional
        arg3 description.
        
        has multiple lines
        
        default is 4
    arg4 : list of int, optional
        arg4 description. default is [1, 2, 3]

    Returns
    -------
    list
        same length as `arg4`
    """)
    assert (s.short_description == "test function")
    assert (s.long_description is None)
    assert (s.blank_after_short_description == True)

# Generated at 2022-06-23 17:15:45.573592
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    dep = DeprecationSection("Deprecated", "deprecation")
    params = dep.parse("1.0.0\nSome warning")
    expected = [DocstringDeprecated(
            ["deprecation"],
            description="Some warning",
            version="1.0.0"
        )]
    assert list(params) == expected


# Generated at 2022-06-23 17:15:50.369616
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    # ERROR:C0111
    assert DeprecationSection("DeprecationWarning", "deprecated")

if __name__ == "__main__":
    test_DeprecationSection()

# Generated at 2022-06-23 17:15:54.350776
# Unit test for function parse
def test_parse():
    doc = """Tests parse()
        :returns: parsed docstring
        """
    docstring = parse(doc)
    assert docstring.short_description == "Tests parse"
