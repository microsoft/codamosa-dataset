

# Generated at 2022-06-23 17:06:03.549022
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    """
    Test Method of NumpydocParser's parse method
    """

    text = """A test docstring.
    This docstring may have multiple lines.

    Parameters
    ----------
    Some param
        Some description
        Can be multiple lines
    Another param
        Another description

    Returns
    -------
    Return value name
        Return description
    Another return value name
        Another description

    Raises
    ------
    SomeError
        Something that raises SomeError
    """
    docstring = NumpydocParser().parse(text)
    assert type(docstring) == Docstring
    assert docstring.short_description == 'A test docstring.'
    assert docstring.long_description == 'This docstring may have multiple lines.'
    assert docstring.blank_after_long_description == False
    assert docstring.blank_after_

# Generated at 2022-06-23 17:06:15.983078
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    # test a numpy-style docstring which has one section
    text = """
        This is a numpy-style docstring.
        This is its long description.

        Parameters
        ----------
        param_1 : int
            Description of param_1

        Returns
        -------
        int
            Description of return value
    """
    parsed = parser.parse(text)
    assert parsed.short_description == 'This is a numpy-style docstring.'
    assert parsed.long_description == 'This is its long description.'
    assert parsed.meta[0].args[1] == 'param_1'
    assert parsed.meta[0].description == 'Description of param_1'
    assert parsed.meta[1].args[1] == 'int'

# Generated at 2022-06-23 17:06:22.396378
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """Deprecated since version 1.2.0: Use function ``blah()`` instead."""
    assert DeprecationSection("deprecated", "deprecation").parse(text) == [DocstringDeprecated(args=['deprecation'], description='Use function ``blah()`` instead.', version='1.2.0')]

# Generated at 2022-06-23 17:06:26.602536
# Unit test for constructor of class ParamSection
def test_ParamSection():
    parameters=ParamSection("Parameters", "param")
    assert parameters.title=="Parameters"
    assert parameters.key=="param"
    assert parameters.title_pattern=="^(Parameters)\s*?\n--------\s*$"


# Generated at 2022-06-23 17:06:37.500040
# Unit test for function parse
def test_parse():
    text = inspect.cleandoc("""
    This is short description.

    This is long description.
    It spans multiple lines.
    And has some :math:`math` in it.

    Parameters
    ----------
    arg1: int
        Arg one.
    arg2: str, optional
        Arg two, defaults to "foo".
    kwarg=10 : int
        Kwarg.
    kwarg2 : int
        Kwarg2.
    *args : list
        Args.

    Returns
    -------
    str
        Whatever.
    """)
    e = Docstring()
    e.short_description = "This is short description."
    e.long_description = "This is long description."\
                         "It spans multiple lines."\
                         "And has some :math:`math` in it."
   

# Generated at 2022-06-23 17:06:38.142704
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert isinstance(ReturnsSection("Returns","returns"), ReturnsSection)

# Generated at 2022-06-23 17:06:41.246854
# Unit test for constructor of class _KVSection
def test__KVSection():
    s = Section("Parameters", "param")
    assert s.title == "Parameters"
    assert s.key == "param"
    assert s.title_pattern == "^(Parameters)\\s*?\\n{8}\\s*$"



# Generated at 2022-06-23 17:06:46.119204
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    x = _SphinxSection("section", "key")
    x.title
    x.key
    x.title_pattern
    x.parse("text")

# Generated at 2022-06-23 17:06:48.482498
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    a=ParamSection("Parameters", "param")
    assert a.title=="Parameters"
    assert a.key=="param"

# Generated at 2022-06-23 17:06:53.425241
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    parser = NumpydocParser()
    parser._setup()
    parser.add_section(RaisesSection("Raises", "raises"))
    parser.add_section(RaisesSection("Raises", "raises"))
    parser.add_section(RaisesSection("Raises", "raises"))
    parser.add_section(RaisesSection("Raises", "warning"))

# Generated at 2022-06-23 17:06:58.476817
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    depreSection = DeprecationSection("Deprecation", "deprecation")
    text = "Deprecated since version 0.1.0: Use ``sklearn.metrics.roc_auc_score`` instead."
    meta = depreSection.parse(text)
    meta = list(meta)
    assert meta[0].version == "0.1.0"
    assert meta[0].description == "Use ``sklearn.metrics.roc_auc_score`` instead."

# Generated at 2022-06-23 17:07:05.976108
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    """
    This test is used to ensure that the constructor of class NumpydocParser is implemented correctly.
    """
    parser = NumpydocParser

    # Setup NumpydocParser
    assert parser != None
    assert parser.sections != None
    assert parser.sections != []
    assert parser.titles_re != None

    # Verify that the setup of NumpydocParser worked
    assert parser != None
    assert parser.sections != None
    assert parser.sections != []
    assert parser.titles_re != None
    assert parser.titles_re.pattern != None
    assert parser.titles_re.pattern != ""


# Generated at 2022-06-23 17:07:10.209315
# Unit test for constructor of class Section
def test_Section():
    section = Section('Title', 'key')
    if (section.title != 'Title'):
        raise AssertionError()
    if (section.key != 'key'):
        raise AssertionError()
    if (section.title_pattern != r'^(Title)\s*?\n-*\s*$'):
        raise AssertionError()




# Generated at 2022-06-23 17:07:21.586360
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 1.3.3
        Some text
    """
    section = DeprecationSection("deprecated", "deprecation")
    sections = NumpydocParser()
    sections.add_section(section)
    deprecation = sections.parse(text).meta[0]
    assert deprecation.version == "1.3.3"
    assert deprecation.description == "Some text"

# PUT THIS IN A TEST IF YOU WANT TO TEST THAT IT WORKS
# def test_numpydoc_sections(numpydoc_sections):
#     import os
#     from pprint import pprint

#     for path in numpydoc_sections:
#         with open(path) as f:
#             print(path)
#             pprint(parse(f.read()).

# Generated at 2022-06-23 17:07:24.212847
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection("Given Title", "Argument")
    assert s.title == "Given Title"
    assert s.key == "Argument"


# Generated at 2022-06-23 17:07:26.574623
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection("title", "key")
    assert s.title == "title"
    assert s.key == "key"


# Generated at 2022-06-23 17:07:35.918079
# Unit test for function parse
def test_parse():
    doc = """A very short description.
    
    This is a much longer description.
    
    It can span multiple lines.
    
    Parameters
    ----------
    arg1
        A description of parameter ``arg1``.
    arg2 : tuple
        A description of parameter ``arg2``.
    kwarg1 : str, optional (default=None)
        A description of keyword ``kwarg1``.
    kwarg2 : None or str (default=None)
        A description of keyword ``kwarg2``.
    
    Returns
    -------
    arg3 : tuple
        A description of what is returned by this function.
    
    Raises
    ------
    Exception
        
        Another description of an exception this function might raise.
    """
    assert len(parse(doc)) == 36

# Generated at 2022-06-23 17:07:46.311004
# Unit test for function parse
def test_parse():
    # Test for example docstring
    text = '''Example function with types documented in the docstring.

    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.

    Returns
    -------
    bool
        True if successful, False otherwise.

    '''

# Generated at 2022-06-23 17:07:50.662885
# Unit test for constructor of class Section
def test_Section():
    section = Section(title = "title", key = "key")
    assert section.title == "title"
    assert section.key == "key"


# Generated at 2022-06-23 17:07:56.648365
# Unit test for constructor of class _KVSection
def test__KVSection():
    p = _KVSection('title', 'key')
    assert p.title == 'title'
    assert p.key == 'key'
    assert p.title_pattern == r'^(title)\s*?\n{}\s*$'.format(len('title'))
    assert p.parse('A\nB\nC\n') == 'A'


# Generated at 2022-06-23 17:08:00.233277
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
	x = ReturnsSection("Returns", "returns")
	assert x.title == "Returns", 'error'
	assert x.key == "returns", 'error'

# Generated at 2022-06-23 17:08:09.042429
# Unit test for function parse
def test_parse():
    test_docstring = """
    Short description.

    Long description

        of the docstring.

    Parameters
    ----------
    test_param : int
        An integer.
    other_param : float, optional
        A float.

    Returns
    -------
    test_return : int or float
        The return value.

    Raises
    ------
    SomeError
        Some description of an error that might occur.

    Notes
    -----
    Note that the return value is either an integer or a float.

    References
    ----------
    https://en.wikipedia.org/wiki/Python_(programming_language)
    """

    # define expected result
    test_result = Docstring()
    test_result.short_description = "Short description."
    test_result.blank_after_short_description = False

# Generated at 2022-06-23 17:08:19.280297
# Unit test for constructor of class ParamSection
def test_ParamSection():
    import inspect

    def func():
        """
        Parameters
        ----------
        a: int
            a info
            test
            test

        Raises
        ------
        ValueError
            desc

        Returns
        -------
        b: int
        """
        pass

    sections = DEFAULT_SECTIONS
    parser = NumpydocParser(sections)
    text = inspect.cleandoc(inspect.getdoc(func))
    rep = parser.parse(text)

    assert rep.short_description is None
    assert rep.long_description is None
    assert rep.blank_after_short_description is False
    assert rep.blank_after_long_description is False

# Generated at 2022-06-23 17:08:23.500621
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yield_section = YieldsSection('Yields', 'yields')
    assert yield_section.is_generator == True
    assert yield_section.key == 'yields'
    assert yield_section.title == 'Yields'

# Generated at 2022-06-23 17:08:24.455033
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    YieldsSection("Yields", "yields")
    YieldsSection("Yield", "yields")

# Generated at 2022-06-23 17:08:26.903131
# Unit test for constructor of class Section
def test_Section():
    test = Section("Title", "key")
    assert test.title == "Title"
    assert test.key == "key"



# Generated at 2022-06-23 17:08:39.251428
# Unit test for method parse of class Section
def test_Section_parse():
    ds = Section(title=1, key=2)

    assert [list(ds.parse(text=''))[0].args == ['2']]
    assert [list(ds.parse(text='\n'))[0].args == ['2']]
    assert [list(ds.parse(text='abcd'))[0].args == ['2']]
    assert [list(ds.parse(text='abcd\n'))[0].args == ['2']]
    assert [list(ds.parse(text='\nabcd'))[0].args == ['2']]
    assert [list(ds.parse(text='\nabcd\n'))[0].args == ['2']]
    assert [list(ds.parse(text='abcd\nefgh'))[0].args == ['2']]

# Generated at 2022-06-23 17:08:43.381191
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    print(parser.sections)
    print(parser.titles_re.pattern)
    new_section = Section('Test', 'test')
    parser.add_section(new_section)
    print(parser.sections)
    print(parser.titles_re.pattern)


# Generated at 2022-06-23 17:08:47.991487
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    x = ReturnsSection("Returns", "returns")
    if(not x.is_generator):
        print("not a generator")
    else:
        print("it is a generator")


# Generated at 2022-06-23 17:08:57.025452
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert re.search(
        _SphinxSection(title="abc", key="abc").title_pattern,
        ".. abc::",
        re.M
    )

    assert re.search(
        _SphinxSection(title="abc", key="abc").title_pattern,
        ".. abc::\n    abc",
        re.M
    )

    assert re.search(
        _SphinxSection(title="abc", key="abc").title_pattern,
        ".. abc::\n    abc\n    abc\n    abc",
        re.M
    )


# Generated at 2022-06-23 17:09:00.301496
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    parser = DeprecationSection("deprecated", "deprecation")
    assert parser.title == "deprecated"
    assert parser.key == "deprecation"

# Generated at 2022-06-23 17:09:02.874701
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yields = YieldsSection("Yields", "yields")
    assert yields.is_generator == True

# Generated at 2022-06-23 17:09:12.911077
# Unit test for method parse of class Section
def test_Section_parse():
    from .pytoml import pytoml_parse
    with open("conf_test.toml") as res:
        config = pytoml_parse(res)
    docstring = parse(config["docstring"])
    assert docstring.short_description == 'Returns the (simplified) fractional part of x with sign.'
    assert docstring.meta[2].description == 'If x is not a float, delegates to x.__mod__(1.0).'
    assert docstring.meta[2].args == ['returns']
    assert docstring.meta[3].description == 'If x is not finite, returns x.'
    assert docstring.meta[3].args == ['returns']
    assert docstring.meta[4].description == 'Return value is always a float.'

# Generated at 2022-06-23 17:09:24.506983
# Unit test for function parse
def test_parse():
    txt = """
    just a line
    """
    d = parse(txt)
    assert isinstance(d, Docstring)
    assert d.short_description == "just a line"
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert isinstance(d.meta, list)
    assert len(d.meta) == 0

    txt = """just a line"""
    d = parse(txt)
    assert isinstance(d, Docstring)
    assert d.short_description == "just a line"
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False

# Generated at 2022-06-23 17:09:27.909497
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("Deprecation Warning", "deprecation")

    assert str(section.title) == 'Deprecation Warning'
    assert str(section.key) == 'deprecation'

# Generated at 2022-06-23 17:09:38.528931
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    def function():
        """A numpy-style docstring.
        Description can span
        multiple lines.

        Parameters
        ----------
        foo : int
            foo description
            can span multiple lines
        bar : str, optional
            bar description
        baz : int, default is ``5``
            baz description

        Raises
        ------
        ValueError
            if value is invalid.

        Returns
        -------
        int
            description
        """

    docstring = NumpydocParser().parse(function.__doc__)
    assert docstring.short_description == "A numpy-style docstring."
    assert docstring.long_description == "Description can span multiple lines."
    assert docstring.blank_after_short_description == False
  

# Generated at 2022-06-23 17:09:51.306489
# Unit test for function parse
def test_parse():
    def test():
        """Numpy-style docstring.

        :param name: Name of person.
        :type name: str
        :param date: Date of documentation

        The documentation is for test purpose.

        :raises NotImplementedError: If the function is not implemented.

        :returns: Test Value.
        """
        pass
    result = parse(test.__doc__)
    assert result.short_description == "Numpy-style docstring."

    params = result.meta[0]
    assert params.args == ["param", "name"]
    assert params.description == "Name of person."

    types = result.meta[1]
    assert types.args == ["param", "date"]
    assert types.description == "Date of documentation"

    description = result.meta[2]

# Generated at 2022-06-23 17:09:55.268065
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    yield_section = ReturnsSection("Yield", "yields")
    assert "Yield" in yield_section.title
    assert "yields" in yield_section.key
    assert yield_section.is_generator is True
    

# Generated at 2022-06-23 17:10:02.542714
# Unit test for function parse
def test_parse():
    """Test parse funcion"""
    text = """\
    String containing "Title", possibly on a different line.

    Parameters
    ----------
    first : str
        The first parameter.
    second : int, optional
        The second parameter.

    Returns
    -------
    str
        The return value.
    """
    result = parse(text)

    assert result.short_description == "String containing \"Title\", possibly on a different line."
    assert len(result.long_description) == 0
    assert result.blank_after_short_description is True
    assert result.blank_after_long_description is True

    assert len(result.meta) == 2

    result = result.meta[0]
    assert isinstance(result, DocstringParam)
    assert result.arg_name == "first"

# Generated at 2022-06-23 17:10:06.658201
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yield_text = '''
        Yields
        ------
        int
            The next integer in the sequence described by the
            generator.

        type_2
            The second type yielded by the generator.
    '''
    yieldSection = YieldsSection("Yields", "yields")
    for i in yieldSection.parse(yield_text):
        print(i)


# Generated at 2022-06-23 17:10:09.303921
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    text = """
    .. deprecated:: 1.4.4
        Deprecation message
    """
    assert len(DeprecationSection("deprecated", "deprecation").parse(text)) == 1

# Generated at 2022-06-23 17:10:20.744030
# Unit test for method parse of class Section
def test_Section_parse():
    # test _pairwise
    assert list(_pairwise(range(5))) == [(0, 1), (1, 2), (2, 3), (3, 4), (4, None)]
    assert list(_pairwise(range(5), None)) == [(0, 1), (1, 2), (2, 3), (3, 4), (4, None)]
    assert list(_pairwise([2])) == [(2, None), (None, None)]
    assert list(_pairwise([2], None)) == [(2, None), (None, None)]
    # test _clean_str
    assert _clean_str("   ") == None
    assert _clean_str("str") == "str"
    assert _clean_str(" str ") == "str"
    # test __init__ and title_pattern

# Generated at 2022-06-23 17:10:32.431287
# Unit test for constructor of class ReturnsSection

# Generated at 2022-06-23 17:10:42.572872
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    # Test function have params and return
    text = '''
        Test function have params and return

        Parameters
        ----------
        a : type
            a description
        b : float
            b description
        c
            c description

        Returns
        -------
        c : type
            c description
    '''

    doc_string = NumpydocParser().parse(text)
    assert(doc_string.short_description == "Test function have params and return")
    assert(doc_string.long_description == "")
    assert(len(doc_string.meta) == 10)
    assert(doc_string.meta[0].args[0] == "line_number")
    assert(doc_string.meta[0].args[1] == "1")
    assert(doc_string.meta[0].description == "")

# Generated at 2022-06-23 17:10:46.628107
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "title"
    key = "key"
    s = _SphinxSection(title,key)
    assert s.title == title
    assert s.key == key


# Generated at 2022-06-23 17:10:52.936149
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
	text = '''
		key
			value
		key2 : type
			values can also span...
			... multiple lines
	'''
	text_cleaned = inspect.cleandoc(text)
	exp = [['key', 'value'], ['key2', 'values can also span...\n... multiple lines']]
	assert exp == [i for i in _KVSection('','key').parse(text_cleaned)]
	

# Generated at 2022-06-23 17:11:02.054098
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    test = DeprecationSection("Deprecated", "deprecated_version")
    doc = test.parse("Deprecated since version 1.1:\n\n    Deprecated")
    expected = DocstringDeprecated(
            args=[test.key],
            description="Deprecated",
            version="1.1"
        )
    if doc != expected:
        raise Exception("Description not extracted properly")
    if doc.description != expected.description:
        raise Exception("Description not extracted properly")
    if doc.version != expected.version:
        raise Exception("Version not extracted properly")
    if doc.args != expected.args:
        raise Exception("Args not extracted properly")

    test = DeprecationSection("Deprecated", "deprecated")
    doc = test.parse("\n    Deprecated")

# Generated at 2022-06-23 17:11:04.004208
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    assert YieldsSection("Yields", "yields") is not None

# Generated at 2022-06-23 17:11:08.968815
# Unit test for constructor of class Section
def test_Section():
    section = Section('title', 'key')
    assert section.title == 'title'
    assert section.key  == 'key'
    assert section.title_pattern == '^(title)\s*?\n------\s*$'


# Generated at 2022-06-23 17:11:14.338948
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecated","deprecated")
    assert section.parse("2.0\nSomething") == [DocstringDeprecated(args=["deprecated"], description="Something", version="2.0")]
    assert section.parse("2.0: Something") == [DocstringDeprecated(args=["deprecated"], description="Something", version="2.0")]

# Generated at 2022-06-23 17:11:17.718486
# Unit test for constructor of class ParamSection
def test_ParamSection():
    text = """
    test_title
        test_value
    """
    section = ParamSection('test_title', 'test_key')
    assert(section.parse(text) ==
        [DocstringMeta(['test_key'], description='test_value')])


# Generated at 2022-06-23 17:11:19.372905
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    y = YieldsSection("Yields", "yields")
    assert y.is_generator == True

# Generated at 2022-06-23 17:11:24.307951
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    text = inspect.cleandoc("""
    ValueError
        A description of what might raise ValueError
    IndexError
        A description of what might raise IndexError
    """)
    result = RaisesSection("Raises", "raises").parse(text)
    assert len(result) == 2
    result = list(result)
    r0 = result[0]
    assert r0.args == ['raises', 'ValueError']
    r1 = result[1]
    assert r1.args == ['raises', 'IndexError']

# Generated at 2022-06-23 17:11:36.483102
# Unit test for function parse

# Generated at 2022-06-23 17:11:40.036122
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    title = "Raises"
    key = "raises"
    assert RaisesSection(title, key).title_pattern == r"^({})\s*?\n{}\s*$".format(title, "-" * len(title))

# Generated at 2022-06-23 17:11:44.588815
# Unit test for constructor of class Section
def test_Section():
    assert Section("", "").title == ""
    assert Section("", "").key == ""
    assert Section("test", "").title == "test"
    assert Section("test", "").key == ""
    assert Section("", "test").title == ""
    assert Section("", "test").key == "test"
    assert Section("test", "test").title == "test"
    assert Section("test", "test").key == "test"



# Generated at 2022-06-23 17:11:53.115806
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    from .parser import NumpydocParser

    np = NumpydocParser({})

    class aSection(Section):
        def __init__(self, title: str, key: str) -> None:
            super(aSection, self).__init__(title, key)

    bs = aSection("a", "b")
    np.add_section(bs)

    # Test that
    if bs != np.sections["a"]:
        raise Exception("Expected aSection not added")

# Generated at 2022-06-23 17:12:03.641742
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    # 1. Empty Sections
    numpydoc_parser_obj = NumpydocParser([])
    assert numpydoc_parser_obj.sections == {}

    # 2. Non Empty Sections
    sections = DEFAULT_SECTIONS
    numpydoc_parser_obj = NumpydocParser(sections)

    # Check the sections

# Generated at 2022-06-23 17:12:12.875533
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    # Test 1: A normal case.
    sections = NumpydocParser()
    assert len(sections.sections.keys()) == 26

    # Test 2: An empty case.
    sections = NumpydocParser([])
    assert len(sections.sections.keys()) == 0

    # Test 3: A wrong case.
    try:
        sections = NumpydocParser(1)
    except TypeError as e:
        # print(e)
        assert str(e) == "parameter 'sections' of method '__init__' of NumpydocParser should be List[Section] or None, got <class 'int'>"


# Generated at 2022-06-23 17:12:15.212716
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert RaisesSection("Raises","raises").__dict__ == {'title': 'Raises', 'key': 'raises'}


# Generated at 2022-06-23 17:12:18.637437
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param = ParamSection("Parameters", "param")
    assert param.title == "Parameters"
    assert param.key == "param"


# Generated at 2022-06-23 17:12:27.718613
# Unit test for function parse
def test_parse():

    _example1 = '''
    header example

    first line of the description
    this line is joined to the first one

    :param param1: short description

        full description for param1

    :param param2: short description for param2
    :type param2: type description for param2
    :returns: short description for return value
    :rtype: type description for return value

    .. warning::

        this is a warning
    '''


# Generated at 2022-06-23 17:12:37.251108
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    Parser = YieldsSection("Yields", "yields")
    assert Parser.title == "Yields"
    assert Parser.key == "yields"
    assert Parser.is_generator == True
    assert Parser.title_pattern == r"^\.\.\s*(Yields)\s*::"
    assert Parser.parse("") == []
    assert Parser.parse("a : str")[0].args == ["yields"]
    assert Parser.parse("a : str")[0].description == None
    assert Parser.parse("a : str")[0].type_name == "str"
    assert Parser.parse("a : str")[0].is_generator == True
    assert Parser.parse("a : str")[0].return_name == "a"

# Generated at 2022-06-23 17:12:40.659458
# Unit test for constructor of class RaisesSection
def test_RaisesSection():

    section = RaisesSection("Raises", "raises")
    assert(section.title == "Raises")
    assert(section.key == "raises")


# Generated at 2022-06-23 17:12:50.473772
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    assert(NumpydocParser().sections != None)
    assert(len(NumpydocParser().sections) == 28)
    assert('Parameters' in NumpydocParser().sections)
    assert(isinstance(NumpydocParser().sections["Parameters"], ParamSection))
    assert('Receives' in NumpydocParser().sections)
    assert(isinstance(NumpydocParser().sections["Receives"], ParamSection))
    assert('Warns' in NumpydocParser().sections)
    assert(isinstance(NumpydocParser().sections["Warns"], RaisesSection))
    assert('Params' in NumpydocParser().sections)
    assert(isinstance(NumpydocParser().sections["Params"], ParamSection))
    assert('Arguments' in NumpydocParser().sections)
   

# Generated at 2022-06-23 17:12:59.758711
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    with open("test_cases/test_raises_section.py", "r") as fh:
        for line in fh:
            line = line.strip()
            if line.startswith("#"):
                print()
                continue
            print("input:", line)
            doc = parse(line)
            print("output:")
            print("    meta:", doc.meta)
            print("    short:", doc.short_description)
            print("    long:", doc.long_description)
            print("    blank_after_short:", doc.blank_after_short_description)
            print("    blank_after_long:", doc.blank_after_long_description)



# Generated at 2022-06-23 17:13:03.400564
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises = RaisesSection("Raise", "raises")
    assert raises.parse("some exception")[0].description == "some exception"
    assert raises.parse("some exception")[0].type_name == "Raise"


# Generated at 2022-06-23 17:13:06.888878
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = DEFAULT_SECTIONS
    ndp1 = NumpydocParser(sections)
    ndp2 = NumpydocParser()
    assert sections == list(ndp2.sections.values())
    assert sections != list(ndp1.sections.values())

# Generated at 2022-06-23 17:13:14.050683
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    """
    Test for method parse of class DeprecationSection
    """
    # Create an instance of DeprecationSection
    deprecation_section = DeprecationSection("deprecated", "deprecation")
    # Create a string where deprecation is marked
    text = """
    Deprecated since version 0.2.
    This is a deprecated function
    """
    # Parse the string in text
    deprecation_section.parse(text)
    # Assert whether the deprecation is parsed correctly
    assert deprecation_section.deprecation.version == "0.2"
    assert (
        deprecation_section.deprecation.description
        == "This is a deprecated function"
    )

# Generated at 2022-06-23 17:13:20.314675
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    with open('./unit_test/test_numpydocparser.txt') as f:
        text = f.read()

    parser = NumpydocParser([DeprecationSection("deprecated", "deprecation")])
    docstring = parser.parse(text)
    result = "3.3.0"
    assert result == docstring.meta[3].version

# Generated at 2022-06-23 17:13:24.457457
# Unit test for constructor of class DeprecationSection

# Generated at 2022-06-23 17:13:29.827840
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    parser = ReturnsSection("Returns", "returns")
    item = parser._parse_item(key="name : type", value="description")
    assert item.type_name == "type"
    assert item.return_name == "name"
    assert item.description == "description"

# Generated at 2022-06-23 17:13:40.688079
# Unit test for method parse of class Section
def test_Section_parse():
    title = 'Parameters'
    key = 'param'
    section = Section(title, key)
    assert section.title == title
    assert section.key == key
    text = "arg_name\narg_description"
    meta_list = list(section.parse(text))
    assert meta_list[0].key == key
    assert meta_list[0].description == "arg_description"
    assert meta_list[0].args == ['param']
    # test end None in function _pairwise
    text = "arg_name\narg_description"
    section = Section(title, key)
    assert section.title == title
    assert section.key == key
    iterable = [1, 2, 3]
    first_iter = itertools.tee(iterable)
    second_iter = itertools.te

# Generated at 2022-06-23 17:13:52.894343
# Unit test for constructor of class ParamSection
def test_ParamSection():
    a = ParamSection("Parameters","param")

# Generated at 2022-06-23 17:13:57.780097
# Unit test for function parse
def test_parse():
    text = """
    Parse the numpy-style docstring into its components.

    This is a longer description.

    :returns: parsed docstring

    Parameters
    ----------
    text : str
        Input docstring to parse.

    Returns
    -------
    Docstring
        Parsed docstring.
    """
    print(parse(text))


# Generated at 2022-06-23 17:14:08.301088
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    inputtext = ".. deprecated:: Something\n   Some description"
    title = "deprecated"
    key = "deprecation"
    section = _SphinxSection(title, key)
    assert section.title_pattern == "^\.\.\\s*(deprecated)\\s*::", "_SphinxSection(): The title_pattern do not match."
    section_description = section.parse(inputtext)
    assert len(section_description) == 1, "_SphinxSection(): The length of section_description do not match"
    assert isinstance(section_description, DocstringDeprecated), "_SphinxSection(): The type of section_description do not match"
    assert section_description.args[0] == "deprecation", "_SphinxSection(): The first element of section_description.args do not match"
    assert section_description

# Generated at 2022-06-23 17:14:13.502138
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():

    section = DeprecationSection("Deprecated", "deprecated")
    text = '''
        .. deprecated:: 0.5.0
            This is a test.
    '''

    result = section.parse(text)
    iterator = iter(result)
    res1 = next(iterator)
    assert isinstance(res1, DocstringDeprecated)
    assert res1.description == 'This is a test.'
    assert res1.version == '0.5.0'
    assert res1.args[0] == 'deprecated'


# Generated at 2022-06-23 17:14:16.043371
# Unit test for method parse of class Section
def test_Section_parse():
    # Test for method parse of class Section
    # Given
    s = Section('test', 'test1', )
    assert s.title == 'test'
    assert s.key == 'test1'

    # When
    result = list(s.parse("test"))

    # Then
    assert result[0] == DocstringMeta(['test1'], description=None)



# Generated at 2022-06-23 17:14:25.936821
# Unit test for function parse
def test_parse():
    """Test numpydoc parser for a simple docsysrting"""
    
    test_docstring = """
    test_function
    Test function docstring. 
    Parameters
    ----------
    param1: int or float
    param2: str
        Description of param1
        Parameters can span multiple lines.
    Return
    ------
    Return for test_function
    
    """
    docstring = parse(test_docstring)
    assert(docstring.meta[0].args[0] == 'param')
    assert(docstring.meta[1].args[0] == 'returns')

# Generated at 2022-06-23 17:14:34.367951
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    text = """Takes a file object or filename and attempts to translate it into
    an image.

    Parameters
    ----------
    arg : float
        Description.
    other_arg : str, optional
        Description with a default of 'a string'.

    Other Parameters
    ----------------
    other_arg2 : str
        Another description.
    """
    numpyparser = NumpydocParser()
    assert numpyparser.parse(text).short_description == "Takes a file object or filename and attempts to translate it into an image."
    assert numpyparser.parse(text).long_description == "Parameters ---------- arg : float Description. other_arg : str, optional Description with a default of 'a string'. Other Parameters ---------------- other_arg2 : str Another description."
    assert numpyparser.parse(text).blank_after_short_description

# Generated at 2022-06-23 17:14:36.815850
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert isinstance(parser, NumpydocParser)

# Generated at 2022-06-23 17:14:44.663806
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    docstr = inspect.cleandoc('''
    Docstring
    ----------

    Key
        Value

    Key2
        Value

    - asd
        - asdasd
    ''')

    doc = NumpydocParser().parse(docstr)
    assert doc.short_description == 'Docstring'
    assert doc.meta.pop().description == 'Key\nValue'
    assert doc.meta.pop().description == 'Key2\nValue'

# Generated at 2022-06-23 17:14:57.103136
# Unit test for function parse
def test_parse():
    doc = """Docstring test
    Parameters
    ----------
    a: int
        A description of arg a
    b : str
        A description of arg b
    c (int):
        A description of arg c
    d, optional: bool
        A description of arg d
    Returns
    -------
    int
        A description of the return value
    """
    test = parse(doc)
    assert test.short_description == "Docstring test"
    assert test.blank_after_short_description
    assert test.blank_after_long_description
    assert test.long_description is None
    assert test.meta[0].args == ["param","a"]
    assert test.meta[0].description == "A description of arg a"
    assert test.meta[0].arg_name == "a"

# Generated at 2022-06-23 17:15:03.091153
# Unit test for method parse of class Section
def test_Section_parse():
    section_parse_test = inspect.cleandoc('''
    Parameters
    ----------
    text : str
        section body text. Should be cleaned with
        ``inspect.cleandoc`` before parsing.
    ''')
    section_object = Section("Parameters", "param")
    section_array = [section_object.parse(section_parse_test)]
    final_object = inspect.getmembers(section_array[0])[1][1]
    assert final_object.args == ["param"]
    assert final_object.description == "section body text. Should be cleaned with ``inspect.cleandoc`` before parsing."

# Generated at 2022-06-23 17:15:06.279415
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
  # Single paragraph
  doc = """
  Single paragraph docstring
  """
  doc = NumpydocParser().parse(doc)
  doc_ref = Docstring()
  doc_ref.short_description='Single paragraph docstring'

  assert doc == doc_ref


# Generated at 2022-06-23 17:15:13.524570
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raisesSection = RaisesSection("Raises", "raises")
    text = "ValueError\nA description of what might raise ValueError"
    result = raisesSection.parse(text)
    assert type(result) == dict
    assert result.get('key') == "raises"
    assert result.get('description') == "A description of what might raise ValueError"
    assert result.get('type') == "ValueError"

# Generated at 2022-06-23 17:15:17.131152
# Unit test for constructor of class Section
def test_Section():
    section = Section('section title', 'section_key')
    assert section.title == 'section title'
    assert section.title_pattern == '^section title\\s*?\n-*$'
    assert section.key == 'section_key'


# Generated at 2022-06-23 17:15:20.719658
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns") == ("Returns section: {}".format("Returns"), "returns")


# Generated at 2022-06-23 17:15:25.688860
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = ".. deprecated:: 1.0\n \n \tThis is deprecated."
    expected = DocstringDeprecated(
                args=["deprecation"],
                description= "This is deprecated.",
                version="1.0")

    out = list(DeprecationSection("deprecated", "deprecation").parse(section))
    assert out[0] == expected


# Generated at 2022-06-23 17:15:30.150691
# Unit test for constructor of class Section
def test_Section():
    title = 'Parameters'
    key = 'param'
    s = Section(title, key)
    assert(s.key == key)
    assert(s.title == title)


# Generated at 2022-06-23 17:15:37.764147
# Unit test for function parse
def test_parse():
    docstring = """
        Return the value of the elementwise function `f` at the single point `a`.
        """

    result = parse(docstring)
    assert result.short_description == 'Return the value of the elementwise function `f` at the single point `a`.'
    assert result.blank_after_short_description == False
    assert result.long_description == None
    assert result.blank_after_long_description == False
    assert result.meta == []


# Generated at 2022-06-23 17:15:39.569268
# Unit test for constructor of class ParamSection
def test_ParamSection():
    arg = 'Parameters'
    key = 'param'
    p = ParamSection(arg, key)
    assert p.title == arg
    assert p.key == key
    

# Generated at 2022-06-23 17:15:42.247178
# Unit test for constructor of class _KVSection
def test__KVSection():
    kvs = _KVSection("parameters", "param")
    assert kvs.title == "parameters"
    assert kvs.key == "param"


# Generated at 2022-06-23 17:15:46.021256
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Creating a _KVSection object
    sec = _KVSection('key', 'value')

    # Testing parse method
    s = 'key\n    value\nkey2 : type\n    values can also span...\n    ... multiple lines'
    expected = _KVSection('key', 'value')
    s.parse(s)

# Generated at 2022-06-23 17:15:55.832895
# Unit test for constructor of class ParamSection
def test_ParamSection():
   sec = ParamSection("Parameter","param")
   assert sec.title == "Parameter"
   assert sec.key == "param"
   assert sec.title_pattern == r"^(Parameter)\s*?\n-*$"
   assert sec.parse("arg_name\n\targ_description")[0].args == ["param","arg_name"]
   assert sec.parse("arg_2 : type, optional\n\tdescriptions can also span...")[0].args == ["param","arg_2"]
