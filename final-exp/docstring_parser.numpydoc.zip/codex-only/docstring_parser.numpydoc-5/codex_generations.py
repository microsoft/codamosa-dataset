

# Generated at 2022-06-23 17:06:05.529391
# Unit test for constructor of class NumpydocParser

# Generated at 2022-06-23 17:06:06.956657
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section = RaisesSection("Raises","raises")
    assert section.title == "Raises"
    assert section.key == "raises"

# Generated at 2022-06-23 17:06:14.701905
# Unit test for constructor of class Section
def test_Section():
    sections = "Parameters"
    key = "param"
    title_pattern_test = r"\^({})\s\*\?\n\^{}\s\*\$".format(sections, "-"*len(sections))
    section_test = Section(sections, key)
    assert section_test.title == sections
    assert section_test.key == key
    assert section_test.title_pattern == title_pattern_test


# Generated at 2022-06-23 17:06:27.037856
# Unit test for constructor of class _KVSection
def test__KVSection():
  key = "key"
  value = "Text\n"
  class TestSection(_KVSection):
    def __init__(self):
      super().__init__("title", key)

    def _parse_item(self, key: str, value: str) -> object:
      return (key, value)

  section = TestSection()
  assert section.key == key
  assert section.title == "title"
  assert section.title_pattern == r"^(title)\s*?\n\-{5}\s*$"

  assert list(section.parse("key\nText\n")) == [(key, value)]
  assert list(section.parse("key\nText")) == [(key, value)]

# Generated at 2022-06-23 17:06:29.390824
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    assert RaisesSection("Raises", "raises").parse("ValueError\nA description of what might raise ValueError\nRuntimeError") is not None

# Generated at 2022-06-23 17:06:31.644841
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    test_case = YieldsSection("Yields", "yields")
    assert test_case.is_generator == True


# Generated at 2022-06-23 17:06:34.988708
# Unit test for constructor of class Section
def test_Section():
    title = 'Returns'
    key = 'returns'
    section = Section(title, key)
    assert section.title == title
    assert section.key == key


# Generated at 2022-06-23 17:06:37.137508
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    obj_section = _SphinxSection("Title", "key")
    assert isinstance(obj_section, _SphinxSection) == True

# Generated at 2022-06-23 17:06:42.957784
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    text = """This is a test

    Args:
        arg1 (str): description
        arg2 (str): description
    """

    assert NumpydocParser().parse(text).meta['returns'].args == ['returns']
    assert NumpydocParser().parse(text).meta['returns'].type_name == 'None'
    assert NumpydocParser().parse(text).meta['returns'].return_name == None
    assert NumpydocParser().parse(text).meta['returns'].is_generator == False



# Generated at 2022-06-23 17:06:47.771144
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    parser= _KVSection("","")
    assert str(parser.parse("""
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
        """)) == "['key', 'key2 : type']"


# Generated at 2022-06-23 17:06:49.891955
# Unit test for constructor of class Section
def test_Section():
    s = Section("Parameters", "param")
    s.title == "Parameters"
    s.key == "param"

# Generated at 2022-06-23 17:06:53.807060
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    ys = YieldsSection('Yields', 'yields')
    assert ys.is_generator == True
    # assert isinstance(ys, ReturnsSection)
    assert isinstance(ys, _KVSection)



# Generated at 2022-06-23 17:06:58.608407
# Unit test for constructor of class Section
def test_Section():

	section = Section("Parameters", "param")
	
	assert section.title == "Parameters"
	assert section.key == "param"
	assert section.title_pattern == "^(Parameters)\\s*?\n{}\s*$".format("-" * len("Parameters"))

# Generated at 2022-06-23 17:07:04.233888
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection.__init__.__doc__ == '''
        Parameters:
            title: section title. For most sections, this is a heading like
                       "Parameters" which appears on its own line, underlined by
                       en-dashes ('-') on the following line.
            key: meta key string. In the parsed `DocstringMeta` instance this
                     will be the first element of the `args` attribute list.
        '''

# Generated at 2022-06-23 17:07:06.234894
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    section = DeprecationSection("key", "string")
    assert section.title == "key"
    assert section.key == "string"

# Generated at 2022-06-23 17:07:13.923785
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    docstring = "Here is the first line of this docstring. \n Here is the second line of this docstring."

    # Test that a docstring is returned of type Docstring
    assert(isinstance(NumpydocParser().parse(docstring), Docstring))

    # Test that if no string is provided, an empty Docstring is returned
    assert(NumpydocParser().parse("") == Docstring())

    # Test that the docstring is cleaned by the PEP-257
    assert(NumpydocParser().parse("    Here is the first line of this docstring. \n Here is the second line of this docstring.") == NumpydocParser().parse(docstring))

    # Test that the docstring is split into short and long part
    # and that the short part is stored into short_description,
    # the long part is stored into long

# Generated at 2022-06-23 17:07:15.243755
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    yieldSection = YieldsSection("Yield", "yield")
    assert yieldSection.is_generator == True


# Generated at 2022-06-23 17:07:21.743141
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    assert _SphinxSection('deprecated', 'dep').title == 'deprecated'
    assert _SphinxSection('Parameters', 'dep').key == 'dep'
    assert _SphinxSection('deprecated', 'dep').title_pattern == '^\\.\\.\\s*(deprecated)\\s*::'
    assert _SphinxSection('Parameters', 'dep').key == 'dep'

# Generated at 2022-06-23 17:07:30.209681
# Unit test for constructor of class ParamSection
def test_ParamSection():
    test_ps = ParamSection("test_title_1", "test_key_1")
    # Test title and key
    assert test_ps.title == "test_title_1"
    assert test_ps.key == "test_key_1"
    # Test title_pattern
    assert test_ps.title_pattern == r"^(test_title_1)\s*?\n{}\s*$".format("-" * len("test_title_1"))


# Generated at 2022-06-23 17:07:38.374546
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raise_title = "Raises"
    raise_key = "raises"
    raise_text = "ValueError" + '\n' + "None"
    raises_section = RaisesSection(raise_title, raise_key)
    assert raises_section.key == raise_key
    assert raises_section.title == raise_title
    for rais in raises_section.parse(raise_text):
        print(rais.type_name)
        assert rais.type_name == "ValueError"
        assert rais.description == "None"


# Generated at 2022-06-23 17:07:45.254228
# Unit test for constructor of class _KVSection
def test__KVSection():
    # Assert instance is created with valid arguments
    def test_init_valid():
        test = _KVSection('title', 'key')
        assert test.title == 'title'
        assert test.key == 'key'

    # Assert instance is created with invalid arguments
    def test_init_invalid():
        try:
            test = _KVSection('title', 'key', 'extra')
        except TypeError:
            assert True
        else:
            assert False

    test_init_valid()
    test_init_invalid()


# Generated at 2022-06-23 17:07:58.201823
# Unit test for method parse of class Section
def test_Section_parse():
    text = """
        value
        type
            value
        """
    doc = inspect.cleandoc(text)
    p = ParamSection("Parameters", "param")
    ret = [docstring_meta([('param', 'value'), ('type', 'value')])]
    assert p.parse(doc) == ret
    text = """
        value
        type
            value
            value 2
            """
    doc = inspect.cleandoc(text)
    ret = [docstring_meta([('param', 'value'), (None, 'value')],
        description='value 2\n')]
    assert p.parse(doc) == ret
    text = """
        value
        type
            value
            value 2
        """
    doc = inspect.cleandoc(text)

# Generated at 2022-06-23 17:08:06.834745
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecated", "deprecation")
    result = section.parse("4.3\nthis is a test to see what happens\n")
    expected = [DocstringDeprecated(args=["deprecation"], description="this is a test to see what happens", version="4.3")]
    assert(list(result)==expected)
    result = section.parse("4.3, this is a test to see what happens")
    assert(list(result)==expected)
    result = section.parse("\n")
    expected = [DocstringDeprecated(args=["deprecation"], description=None, version=None)]
    assert(list(result)==expected)



# Generated at 2022-06-23 17:08:11.603147
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    test_section = Section("TestParams", "param")
    parser.add_section(test_section)
    section_list = list(parser.sections.keys())
    assert("TestParams" in section_list)

# Generated at 2022-06-23 17:08:16.222512
# Unit test for method parse of class Section
def test_Section_parse():
    w = Section("Params", "param")
    assert w.title == "Params"
    assert w.key == "param"
    assert w.title_pattern == "^(Params)\\s*?\\n-*\\s*$"
    assert w.parse("test1\ntest2") is None

# Generated at 2022-06-23 17:08:22.622382
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    try:
        param_section = _SphinxSection(title="Params", key="param")
        assert param_section.title_pattern == "^\.\.\s*(Params)\s*::"
    except:
        raise AssertionError("_SphinxSection constructor error")


# Generated at 2022-06-23 17:08:26.792067
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    # Arrange
    title = ""
    key = ""
    returnsSection = ReturnsSection(title, key)

    # Act and Assert
    assert returnsSection.is_generator == False
    assert returnsSection.key == ""
    assert returnsSection.title == ""

# Generated at 2022-06-23 17:08:31.279039
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    sphinx_section = _SphinxSection("title", "key")
    assert isinstance(sphinx_section, _SphinxSection)
    assert sphinx_section.title == "title"
    assert sphinx_section.key == "key"


# Generated at 2022-06-23 17:08:41.309460
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    """
    Test for method parse of class _KVSection
    """
    from .common import DocstringMeta
    nd_kv = _KVSection("title","key")

    # the input string for testing
    s ="""key
    value
    key2 : type
        descriptions can also span
        ... multiple lines
    """

    # expected output
    expected_output_list = [DocstringMeta(["key"], description="value"),
                            DocstringMeta(["key2"], description="descriptions can also span\n... multiple lines")]

    output_list = list(nd_kv.parse(s))
    assert output_list == expected_output_list


# Generated at 2022-06-23 17:08:43.371909
# Unit test for constructor of class ParamSection
def test_ParamSection():
    params = ParamSection("Parameters", "param")
    assert params.key == "param"
    assert params.title == "Parameters"



# Generated at 2022-06-23 17:08:49.114423
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    # TODO: Move this to a test case!
    assert ReturnsSection("Returns", "returns").is_generator == False
    assert ReturnsSection("Yields", "yields").is_generator == True

# Unit tests for _parse_item method of class ReturnsSection

# Generated at 2022-06-23 17:08:57.484138
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    with open("../../../tests/test_numpydoc_parser/fixtures/example_readme.rst") as f:
        _readme_content = f.read()
    _readme_docstring_content = [
        _readme_content[start:end]
        for match, nextmatch in _pairwise(
            re.compile("\.\. test\-fixture\.\.\n").finditer(_readme_content)
        )
        for start, end in [(match.end(), nextmatch.start() if nextmatch is not None else None)]
    ]
    for _docstring_content in _readme_docstring_content:
        _docstring = parse(_docstring_content)
        assert len(_docstring.meta) > 1

# Generated at 2022-06-23 17:09:09.380754
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    text_sample_1 = '''
    Docstring for simple function.

    Parameters
    ----------
    x : int
        number 1
    y : int
        number 2

    Returns
    -------
    int
        sum of x and y
    '''
    ret = Docstring()
    ret.short_description = "Docstring for simple function."
    ret.long_description = None
    ret.blank_after_short_description = True
    ret.blank_after_long_description = False

# Generated at 2022-06-23 17:09:13.011090
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    a = RaisesSection("Raises","raises")
    assert(a.__class__.__name__ == "RaisesSection")


# Generated at 2022-06-23 17:09:19.986339
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    section = DeprecationSection("deprecated", "deprecation")
    text = ".. deprecated:: 1.2\n" \
           "   Deprecation description\n"
    test_case = [
        DocstringDeprecated(
            args=["deprecation"],
            description="Deprecation description",
            version="1.2"
        )
    ]
    assert section.parse(text) == test_case


# Generated at 2022-06-23 17:09:24.867170
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    key = "something"
    value = "multi\nline\ntext"
    text = ".".join([key, "\n", value])
    instance = _KVSection("", "")
    # Test method parse of class _KVSection
    assert instance.parse(text) == [("something", "multi\nline\ntext")]

# Generated at 2022-06-23 17:09:26.438468
# Unit test for constructor of class ParamSection
def test_ParamSection():
    param = ParamSection("Args", "param")
    assert param.title == "Args"


# Generated at 2022-06-23 17:09:29.273166
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert(ReturnsSection("description", "name").description == "description")
    assert(ReturnsSection("description", "name").name == "name")


# Generated at 2022-06-23 17:09:32.929791
# Unit test for function parse
def test_parse():
    """
    Test parse function
    """

# Generated at 2022-06-23 17:09:42.166881
# Unit test for function parse
def test_parse():
    #print("testing parse")
    docstring = """\
        Some longer description.
        Parameters
        ----------
        param_name : str, optional
            Some short description.
        param_2 : float, optional
            Another short description.
    """

    from pnp.parsers import NumpydocParser

    d = NumpydocParser().parse(docstring)
    assert d.short_description == "Some longer description."
    assert d.long_description == "\nSome short description.\nAnother short description."
    assert d.blank_after_short_description
    assert d.blank_after_long_description
    assert len(d.meta) == 2
    assert d.meta[0].key == "param"
    assert d.meta[1].key == "param"

# Generated at 2022-06-23 17:09:46.294231
# Unit test for constructor of class ParamSection
def test_ParamSection():
    title = 'Parameters'
    key = 'param'
    p = ParamSection(title, key)
    assert p.title == title
    assert p.k

# Generated at 2022-06-23 17:09:57.586578
# Unit test for function parse
def test_parse():
    text  = """
    NumpyDoc

    This function parses numpy doc.

    Parameters
        text : string
            input doc to be parsed

    Returns
        parsed : NumpyDoc
            the parsed doc

    Warns
        ValueError
            If the input doc is malformed
    """
    ret = parse(text)
    assert ret.short_description == 'NumpyDoc'
    assert ret.long_description == 'This function parses numpy doc.'
    assert len(ret.meta) == 3
    assert ret.meta[0].args == ['param', 'text']
    assert ret.meta[0].type_name == 'string'
    assert ret.meta[0].description == 'input doc to be parsed'
    assert ret.meta[1].args == ['returns']
    assert ret.meta[1].type_name

# Generated at 2022-06-23 17:10:05.910522
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()
    docstring = "Parse the numpy-style docstring into its components.\n\
                 :returns: parsed docstring"
    result = parser.parse(docstring)
    expected = Docstring(short_description="", long_description="", meta=[])
    assert expected.short_description == result.short_description
    assert expected.long_description == result.long_description
    assert expected.meta == result.meta


# Generated at 2022-06-23 17:10:09.020387
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    sections = {
        "Parameters" : "param",
        "Raise" : "raises"
    }
    npdp = NumpydocParser(sections)
    assert "Parameter" in npdp.sections
    assert "Raise" in npdp.sections


# Generated at 2022-06-23 17:10:11.035249
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    assert ReturnsSection("Returns", "returns")



# Generated at 2022-06-23 17:10:20.233578
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    section = RaisesSection("Raises", "raises")
    dict = {}
    dict["KeyError"] = "This is a KeyError exception."
    dict["TypeError"] = "This is a TypeError exception."
    dict["ZeroDivisionError"] = "This is a ZeroDivisionError exception."

    for key in dict:
        ans_key = key
        ans_value = dict[key]
        result = section._parse_item(key, value=dict[key])
        assert(result.args == ['raises', ans_key])
        assert(result.description == ans_value)
        assert(result.type_name == key)


# Generated at 2022-06-23 17:10:22.522564
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    par = ReturnsSection('Returns','returns')
    print(par)


# Generated at 2022-06-23 17:10:26.706215
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():

    parser = NumpydocParser()
    docstring = parser.parse.__doc__

    assert(docstring == """
    Parse the numpy-style docstring into its components.

    :returns: parsed docstring
    """)

# Generated at 2022-06-23 17:10:29.735100
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    sec = _SphinxSection(title='title', key='key')
    assert sec.title_pattern == r'^\.\.\s*(title)\s*::'


# Generated at 2022-06-23 17:10:38.178089
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    # DeprecationSection object initialized
    deprec = DeprecationSection("Deprecation", "deprecated")

    # Title checked
    assert deprec.title == "Deprecation"

    # Key checked
    assert deprec.key == "deprecated"

    # Title pattern checked
    assert deprec.title_pattern == r"^\.\.\s*(Deprecation)\s*::"

    # Parse the docstring
    deprec.parse("1.1.0\nThis function will be deprecated")

# Main function

# Generated at 2022-06-23 17:10:40.760139
# Unit test for constructor of class Section
def test_Section():
    s = Section("Parameters", "param")
    assert s.key == "param"
    assert s.title == "Parameters"

# Generated at 2022-06-23 17:10:46.464821
# Unit test for constructor of class ParamSection
def test_ParamSection():
    p = ParamSection("Parameters", "param")
    assert len(p.parse("""
    param_name
        description of param_name
    param_name : type
        description of param_name
    """)) == 2



# Generated at 2022-06-23 17:10:56.725663
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    test0 = """
        This is a module for doing everything.

        Parameters
        ----------
        filename: str (default: 'foobar.txt')
            The name of the output file.

        Returns
        -------
        0: int
            Exit status.

        See Also
        --------
        Other module
            For other things
    """

    print('test0')

    parsed0 = NumpydocParser().parse(test0)
    print('short_description: {}'.format(parsed0.short_description))
    ls0 = parsed0.long_description.split('\n')
    for l0 in ls0:
        print(l0)
    print('blank_after_short_description: {}'.format(parsed0.blank_after_short_description))

# Generated at 2022-06-23 17:10:58.926033
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    print("PARAM_KEY_REGEX",PARAM_KEY_REGEX.match("param : int"))

# Generated at 2022-06-23 17:11:02.129568
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    section = _KVSection("","")
    text = """
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    for item in section.parse(text):
        print (item)

# Generated at 2022-06-23 17:11:14.691798
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:11:18.131769
# Unit test for constructor of class _KVSection
def test__KVSection():
    with pytest.raises(NotImplementedError):
        _KVSection("test", "test")._parse_item("test", "test")


# Unit tests for function _clean_str

# Generated at 2022-06-23 17:11:25.630751
# Unit test for function parse
def test_parse():
    from .common import DocstringParam, DocstringReturns
    from .common import DocstringRaises, DocstringDeprecated
    from .common import DocstringMeta

# Generated at 2022-06-23 17:11:34.226136
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    text = (
        ("This format is now deprecated and will be removed in a future "
         "version.\n\nPlease use the more formal `numpy-style docstring`."
         "\n\nSee :ref:`pandas.api.extensions.register_dataframe_accessor`.")
    )
    d = DeprecationSection("Deprecated", "deprecation")
    assert d.parse(text) is not None
    assert d.parse(text).args == ["deprecation"]
    assert d.parse(text).description is not None

# Generated at 2022-06-23 17:11:36.635782
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    r = RaisesSection("Raises", "raises")
    assert callable(r.parse)
    assert callable(r.__init__)

# Generated at 2022-06-23 17:11:38.619323
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = "title"
    key = "key"
    _SphinxSection(title, key)


# Generated at 2022-06-23 17:11:42.279242
# Unit test for method parse of class Section
def test_Section_parse():
    s = Section("Paramètres", "param")
    assert (
        s.title_pattern
        == r"^(Paramètres)\s*?\n{}\s*$".format("-" * len("Paramètres"))
    )



# Generated at 2022-06-23 17:11:53.116574
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    for text in ["text", "text\n", "text\n\n"]:
        assert DeprecationSection("title", "key").parse(text) != DocstringDeprecated(
            args=["key"], description=_clean_str(text), version=None
        ), "Test parse of DeprecationSection"
    for text in ["20.7\ntext", "20.7\ntext\n", "20.7\ntext\n\n"]:
        assert DeprecationSection("title", "key").parse(text) == DocstringDeprecated(
            args=["key"], description=_clean_str("text"), version="20.7"
        ), "Test parse of DeprecationSection"

# Generated at 2022-06-23 17:11:54.082382
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    print(DeprecationSection('deprecated', 'deprecation'))


# Generated at 2022-06-23 17:12:01.652250
# Unit test for function parse
def test_parse():
    import pytest
    def foo(a: int, b: str=None):
        '''
        My function.

        Parameters
        ----------
        a
            1st integer param.
        b : str
            2nd optional parameter

        Raises
        ------
        RuntimeError
            always!

        Returns
        -------
        double a
        '''
        raise RuntimeError

    doc = parse(foo.__doc__)

    assert doc.short_description == 'My function.'
    assert doc.long_description == (
        '1st integer param.\n'
        '\n'
        '2nd optional parameter'
    )
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    #print(doc.meta)

# Generated at 2022-06-23 17:12:12.109673
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    docstring = '''
    This is a module.

    This is
    a
    docstring.
    '''

    class Parser(NumpydocParser):
        def __init__(self):
            super().__init__()
            self.add_section(Section("Original", "meta"))

    parser = Parser()
    result = parser.parse(docstring)
    assert result.short_description == 'This is a module.'
    assert result.long_description == 'This is\na\ndocstring.'
    assert len(result.meta) == 1
    assert isinstance(result.meta[0], DocstringMeta)
    assert result.meta[0].args == ('meta', )

# Generated at 2022-06-23 17:12:14.497049
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    ReturnsSection("Returns", "returns")
    ReturnsSection("Return", "returns")


# Generated at 2022-06-23 17:12:17.789000
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    parser = NumpydocParser()
    assert parser.sections['Parameters'] == ParamSection("Parameters", "param")



# Generated at 2022-06-23 17:12:19.450264
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    assert NumpydocParser().parse('') == Docstring()


# Generated at 2022-06-23 17:12:22.763439
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    assert len(parser.titles_re.findall(
        "Add or replace a section.\n\n:param section: The new section.\n")) == 1

# Generated at 2022-06-23 17:12:25.139719
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    parser = RaisesSection("Raises", "raises")
    assert parser != None
    assert parser.title != None
    assert parser.key != None


# Generated at 2022-06-23 17:12:33.532444
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    parser = NumpydocParser()
    numpydoc_text = inspect.cleandoc('''
    .. deprecated:: 0.1.2
        details about deprecation
    ''')
    output = parser.parse(numpydoc_text)
    expected = Docstring(
        meta=[DocstringDeprecated(
            args=['deprecation'], version='0.1.2',
            description='details about deprecation'
        )],
    )
    assert output == expected

# Generated at 2022-06-23 17:12:40.031026
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    return_section = ReturnsSection("Returns", "returns")
    assert return_section.title == "Returns"
    assert return_section.key == "returns"
    assert return_section.is_generator == False
    assert return_section.title_pattern == r"^Returns\s*?\n=+\s*$"


# Generated at 2022-06-23 17:12:41.575897
# Unit test for constructor of class ParamSection
def test_ParamSection():
    assert ParamSection("Parameters", "param") is not None


# Generated at 2022-06-23 17:12:51.043778
# Unit test for constructor of class Section
def test_Section():
    param = Section("Parameters", "param")
    assert param.title == "Parameters"
    assert param.key == "param"

    param = Section("Params", "param")
    assert param.title == "Params"
    assert param.key == "param"

    param = Section("Arguments", "param")
    assert param.title == "Arguments"
    assert param.key == "param"

    param = Section("Args", "param")
    assert param.title == "Args"
    assert param.key == "param"

    param = Section("Other Parameters", "other_param")
    assert param.title == "Other Parameters"
    assert param.key == "other_param"

    param = Section("Other Params", "other_param")
    assert param.title == "Other Params"

# Generated at 2022-06-23 17:12:59.757081
# Unit test for method parse of class Section
def test_Section_parse():
    sections = NumpydocParser(sections=[
        Section("Parameters", "param")
    ]).sections["Parameters"]

    assert sections.parse("") == [
        DocstringMeta(["param"], description="")
    ]
    assert sections.parse("\n\n") == [
        DocstringMeta(["param"], description="")
    ]
    assert sections.parse("A \n B \n C") == [
        DocstringMeta(["param"], description="A B C")
    ]
    assert sections.parse("A \n B \n \n \n C") == [
        DocstringMeta(["param"], description="A B C")
    ]



# Generated at 2022-06-23 17:13:09.437411
# Unit test for method parse of class NumpydocParser

# Generated at 2022-06-23 17:13:16.964401
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    rsection = RaisesSection("Raises", "raises")
    # verify that the string rsection.title in the object rsection is equal to "Raises"
    assert rsection.title == "Raises"
    # verify that the string rsection.key in the object rsection is equal to "raises"
    assert rsection.key == "raises"
    
    

# Generated at 2022-06-23 17:13:20.527535
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    # Create instance of class RaisesSection and get attributes
    testRaisesSection = RaisesSection("Raises", "raises")
    assert testRaisesSection.title == "Raises"
    assert testRaisesSection.key == "raises"


# Generated at 2022-06-23 17:13:22.904440
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    section = _SphinxSection("Title", "key")
    assert section.title_pattern == r"^\.\.\s*(Title)\s*::"

# Generated at 2022-06-23 17:13:30.892883
# Unit test for function parse
def test_parse():
    def fn():
        """
        Short desc
            Long desc
        Parameters
            a : int
                A param a
            b: float
                A param b

        Raises
            ValueError
                description
        Returns
            int
                description
            float

        Examples
            >>> fn(1, 2)
            3

        Warnings
            This function is useless

        See Also
            antoher_function
        References
            http://example.com

        .. deprecated:: 1.0
            Use some_other_function instead.
        """
        pass

    docstring = parse(fn.__doc__)

    assert docstring.short_description == "Short desc"
    assert docstring.long_description == "Long desc"
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description



# Generated at 2022-06-23 17:13:39.640816
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    # Create test docstring
    text = """
        key
            value
        key2 : type
            values can also span...
            ... multiple lines
    """
    # Pre-process test docstring
    text = inspect.cleandoc(text)
    # Create _KVSection instance
    kv_section = _KVSection("title", "key")
    # Get parse result
    parse_result = kv_section.parse(text)
    # Check type of parse_result
    assert isinstance(parse_result, list)
    # Check number of items of parse_result
    assert len(parse_result) == 2


# Generated at 2022-06-23 17:13:52.369063
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    parser = NumpydocParser()

# Generated at 2022-06-23 17:13:56.452552
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    print("Testing __init__ method of class ReturnsSection.")
    r = ReturnsSection("Returns", "returns")
    assert r.is_generator == False

    r = YieldsSection("Yields", "yields")
    assert r.is_generator == True


# Generated at 2022-06-23 17:14:01.605378
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
    test = YieldsSection("Yields", "yields")
    if test is not None:
        print("Unit test for constructor of class YieldsSection passed")
    else:
        print("Unit test for constructor of class YieldsSection failed")

if __name__ == "__main__":
    test_YieldsSection()

# Generated at 2022-06-23 17:14:04.022097
# Unit test for method parse of class Section
def test_Section_parse():
    if __name__ == '__main__':
        section_class = Section(title="Section", key="Section")
        text = """
        Example of a docstring
        """
        section_class.parse(text=text)



# Generated at 2022-06-23 17:14:06.661445
# Unit test for constructor of class Section
def test_Section():
    section = Section(title = "Title", key = "key")
    assert section.title == "Title"
    assert section.key == "key"


# Generated at 2022-06-23 17:14:09.002335
# Unit test for method add_section of class NumpydocParser
def test_NumpydocParser_add_section():
    parser = NumpydocParser()
    parser.add_section(Section("Test", "test"))
    assert parser.parse('Test\n---\nTest') == Docstring(
        meta=[DocstringMeta(args=['test'], description='Test')]
    )

# Generated at 2022-06-23 17:14:12.911385
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    a = _SphinxSection(".. deprecated:: 0.0.0", "deprecated")
    b = re.compile(a.title_pattern)
    assert len(b.findall(".. deprecated:: 0.0.0\n")) == 1
    assert len(b.findall(".. deprecated:: 0.0.0\n")) == 1
    assert len(b.findall(".. deprecated:: 0.0.0\n")) == 1
    assert len(b.findall(".. deprecated:: 0.0.0\n")) == 1

# Generated at 2022-06-23 17:14:16.865951
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    s = _SphinxSection(".. hello", "hello")
    assert(s.title_pattern == "^\\.\\.\s*(hello)\s*::$")


# Generated at 2022-06-23 17:14:19.776016
# Unit test for constructor of class DeprecationSection
def test_DeprecationSection():
    try:
        the_test = DeprecationSection(title="Deprecation Warning", key="deprecation")
    except Exception as e:
        print(e)
        assert(False)
    assert(True)


# Generated at 2022-06-23 17:14:23.498315
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    """
    _KVSection.parse() takes a string of form

    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    pass



# Generated at 2022-06-23 17:14:29.501332
# Unit test for constructor of class _SphinxSection
def test__SphinxSection():
    title = 'something'
    key = 'key'
    section = _SphinxSection(title,key)
    assert section.title == 'something'
    assert section.key == 'key'
    assert section.title_pattern == r'^\.\.\s*(something)\s*::'
    # assert that the parse method defined in parent class is used
    assert section.parse.__func__ == Section.parse



# Generated at 2022-06-23 17:14:40.844302
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    n = NumpydocParser()
    n.add_section(YieldsSection("Yields", "yields"))
    n.parse("""
    Create an image from a given array.
    The shape of the array must be (rows, columns, 3) for RGB images,
    or (rows, columns) for grayscale images.

    Parameters
    ----------
    arr : numpy.ndarray
        Array containing the image data.  If ``mode`` is one of the
        standard mode strings, the array must be of the correct shape
        (it is made into a :class:`~PIL.Image.Image` object).

    Yields
    ------
    images : numpy.ndarray
        Yields an array containing the image data.
    """)



# Generated at 2022-06-23 17:14:49.132966
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = '''
        arg1
            arg1 description
        arg2 : int, optional
            arg2 description
    '''
    meta = list(ParamSection("Parameters", "param").parse(text))
    assert len(meta) == 2
    assert repr(meta[0]) == 'DocstringParam(args=["param", "arg1"], arg_name="arg1", type_name=None, is_optional=False, default=None, description="arg1 description")'
    assert repr(meta[1]) == 'DocstringParam(args=["param", "arg2"], arg_name="arg2", type_name="int", is_optional=True, default=None, description="arg2 description")'
    

# Generated at 2022-06-23 17:14:55.628235
# Unit test for constructor of class NumpydocParser
def test_NumpydocParser():
    # setup
    title = 'title'
    key = 'key'
    section = Section(title, key)
    sections = {title: section}
    expected = NumpydocParser(sections)
    
    # test
    actual = NumpydocParser()
    actual.sections = sections
    actual._setup()
    
    assert actual.sections == expected.sections
    assert actual.titles_re == expected.titles_re


# Generated at 2022-06-23 17:15:03.626588
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    """
    Test method _KVSection.parse
    """
    from . import Docstring        
    from . import DocstringMeta

    docstring_meta = DocstringMeta(["key", "arg_name"], description=_clean_str("value"))
    # print("docstring_meta =", docstring_meta)  

    def _parse_item(key, value):
        # print("_parse_item(", key, value, ")")
        return docstring_meta

    text = """
    key
        value
    key2 : type
        values can also span...
        ... multiple lines
    """
    docstring = _KVSection("title", "key").parse(text)
    # print("docstring =", docstring)
    assert docstring._parse_item("key", "value") == docstring_meta



# Generated at 2022-06-23 17:15:09.275224
# Unit test for constructor of class ReturnsSection
def test_ReturnsSection():
    t = ReturnsSection("Returns", "returns")
    assert t.title == "Returns"
    assert t.key == "returns"
    assert t.title_pattern == r"^Returns\s*?\n(===)?\s*$"
    assert t.is_generator == False


# Generated at 2022-06-23 17:15:21.413788
# Unit test for constructor of class YieldsSection
def test_YieldsSection():
  if __name__ == '__main__':
    docstring = inspect.cleandoc('''
      .. title:: something
          possibly over multiple lines
    ''')
    print(docstring)
    #creating object of class
    section = YieldsSection("Yields", "yields")
    #testing the parse method
    print(section.parse(docstring))
    
    docstring = inspect.cleandoc('''
      Yields
          return_name : type
              A description of this returned value
          another_type
              Return names are optional, types are required
    ''')
    print(docstring)
    #calling the parse method
    print(section.parse(docstring))

test_YieldsSection()


# Generated at 2022-06-23 17:15:28.027379
# Unit test for constructor of class _KVSection
def test__KVSection():
    key = "key"
    value = "value"
    text = "key\n    value"
    new_KVSection = _KVSection(key, value)
    assert new_KVSection.title == key
    assert new_KVSection.key == value
    assert new_KVSection._parse_item(key, value) == None
    assert new_KVSection.parse(text) == None
    assert new_KVSection.title_pattern == "^{}\s*?\n{}\s*$".format(key, "-")

# Generated at 2022-06-23 17:15:31.007739
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    raises_section = RaisesSection("Raises","raises")
    assert raises_section.key == "raises"


# Generated at 2022-06-23 17:15:39.721688
# Unit test for method parse of class _KVSection
def test__KVSection_parse():
    text = "key\n" \
        + "    value\n" \
        + "key2 : type\n" \
        + "    values can also span...\n" \
        + "    ... multiple lines"
    section = _KVSection("Parameters", "param")
    meta_list = section.parse(text)
    assert meta_list is not None
    assert next(meta_list).description == "value"
    assert next(meta_list).description == "values can also span...\n" \
        + "    ... multiple lines"

# Generated at 2022-06-23 17:15:41.263404
# Unit test for constructor of class RaisesSection
def test_RaisesSection():
    RaisesSection("Raises", "raises")


# Generated at 2022-06-23 17:15:45.004510
# Unit test for method parse of class DeprecationSection
def test_DeprecationSection_parse():
    assert parse(
        """
.. deprecated:: 1.0

   Use something else
"""
    ) == Docstring(
        short_description="",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            DocstringDeprecated(
                args=["deprecation"],
                description="Use something else",
                version="1.0",
            )
        ],
    )

# Generated at 2022-06-23 17:15:51.591931
# Unit test for constructor of class _KVSection
def test__KVSection():
    text = "_KVSection\n-----------\nkey\n    value\nkey2 : type\n    values can also span...\n    ... multiple lines"
    ps = _KVSection("_KVSection", "key").parse(text)
    assert(next(ps).description == "value")


# Generated at 2022-06-23 17:16:01.528966
# Unit test for method parse of class NumpydocParser
def test_NumpydocParser_parse():
    
    text = """
    This is a long description.

    Parameters
    ----------
    j : any, optional
        The long description of j.

    k : {int, float, bool, str}, optional
        The long description of k.

    Returns
    -------
    bool
        The return value. True for success.
    """

    parser = NumpydocParser()
    docs = parser.parse(text)

    assert(docs.short_description == 'This is a long description.')

    assert(docs.long_description == 'The long description of j.\nThe long description of k.')

    assert(len(docs.meta) == 2)
    meta = docs.meta[0]
    assert(meta.args == ['param', 'j'])
    assert(meta.arg_name == 'j')