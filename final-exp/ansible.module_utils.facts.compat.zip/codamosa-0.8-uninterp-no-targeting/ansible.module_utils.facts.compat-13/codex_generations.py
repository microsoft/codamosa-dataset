

# Generated at 2022-06-20 16:56:58.885198
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import os
    import shutil
    import tempfile

    class MockAnsibleModule:

        def __init__(self):
            self.params = dict(gather_subset=['platform'])
            self.debug = dict()

        def fail_json(self, msg):
            raise RuntimeError(msg)

    class SadMockOs:
        '''Overwrite os.uname with this mock to return a os name that we can't collect via the normal
        Collector.get_facts_platform method.'''

        @staticmethod
        def uname():
            return ('Linux', 'mock-hostname', 'mock-kernel-release', 'mock-kernel-version', '', '')


# Generated at 2022-06-20 16:57:03.982492
# Unit test for function get_all_facts
def test_get_all_facts():
    module = AnsibleModuleMock({})
    facts = get_all_facts(module)
    assert 'ansible_default_ipv4' in facts
    assert 'ansible_all_ipv4_addresses' in facts


# Generated at 2022-06-20 16:57:10.591115
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test_get_all_facts()

    Unit test for function get_all_facts() in module_utils/facts/ansible_facts.py
    '''

    # Mock module
    module = Mock()
    module.params = {'gather_subset': 'all', 'gather_timeout': 10}

    # Execute function
    result = get_all_facts(module)

    # Assert result
    assert result is not None
    assert type(result) == dict


# Generated at 2022-06-20 16:57:11.700501
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts.__doc__ == get_all_facts.__doc__

# Generated at 2022-06-20 16:57:18.642764
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test the ansible_facts function'''
    # pylint: disable=E1101,R0903,R0904
    import os
    import sys
    import mock
    import tempfile
    import datetime

    import pytest
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.system import distribution, dns, fips, local, lsbrelease, pkg_mgr
    from ansible.module_utils.facts.user import user
    from ansible.module_utils.facts import ansible_collector

    # Mock the get_all_collector_classes method to return a fake collector class
    # that returns a constant when it is called.

# Generated at 2022-06-20 16:57:27.526593
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        from ansible.module_utils.facts.namespace import PrefixFactNamespace
        from ansible.module_utils.facts import ansible_collector
        from ansible.module_utils.facts import default_collectors
    except ImportError:
        return

    class ModuleMock(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    # Test a normal call
    module = ModuleMock()

    facts_dict = get_all_facts(module)

    assert isinstance(facts_dict, dict)
    assert len(facts_dict) > 0
    assert 'default_ipv4' in facts_dict, "Facts gathering failed"

# Generated at 2022-06-20 16:57:40.942455
# Unit test for function get_all_facts
def test_get_all_facts():

    import pytest
    from mock import MagicMock

    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class Module(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class AnsibleModule(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    opts=Options(gather_subset='all')
    module=Module(params=opts)
    ansible_module=AnsibleModule(params=opts)
    ansible_module.ansible=MagicMock(Ansible=MagicMock(Module=MagicMock(return_value=module)))
    ansible_module.Ans

# Generated at 2022-06-20 16:57:48.064879
# Unit test for function ansible_facts
def test_ansible_facts():
    # mock gather_subset
    gather_subset = frozenset(['network', 'virtual'])

    # mock module with gather_subset=gather_subset, gather_timeout=gather_timeout
    from mock import Mock
    module = Mock()
    module.params = dict(gather_subset=gather_subset, gather_timeout=4)

    result = ansible_facts(module=module, gather_subset=gather_subset)

    assert 'ansible_all_ipv4_addresses' in result
    assert 'ansible_all_ipv6_addresses' in result

    # mock gather_subset
    gather_subset = frozenset(['network', 'hardware'])

    result = ansible_facts(module=module, gather_subset=gather_subset)

# Generated at 2022-06-20 16:58:00.290580
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.virtual

    import ansible.module_utils.facts.system

    # Note: we are relying on the module loader to get this list of collectors,
    # since it's already tested elsewhere.
    # This is to avoid having to import the default_collector module, which
    # will import everything it can find and slow things down unnecessarily
    # for the unit test
    from ansible.module_utils.facts.collector import BaseFactCollector

    # need to monkey patch the 'virtual' os facts so that we can run this code on a real machine
    # not ideal, since we no longer test that the code actually works in a virtual env
    # but this is a unit test and there are better places to do that
    # (namely integration tests with docker)
    virtual_collector = ansible.module_utils.facts

# Generated at 2022-06-20 16:58:06.520380
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.basic import AnsibleModule
    # Create a fake module.
    module = AnsibleModule(argument_spec={})
    facts_dict = ansible_facts(module=module)
    assert len(facts_dict) > 0

# Generated at 2022-06-20 16:58:17.228787
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import facts

    variant_func = facts.get_all_facts
    # test the func works with a class instance
    assert len(variant_func(FakeModule())) == 16

    # test the func works with a dict
    assert len(variant_func(FakeModuleDict())) == 16



# Generated at 2022-06-20 16:58:20.932556
# Unit test for function ansible_facts
def test_ansible_facts():
    test_module = object()
    test_gather_subset = None
    test_facts = ansible_facts(test_module,
                               gather_subset=test_gather_subset)
    assert test_facts == {}

# Generated at 2022-06-20 16:58:33.716205
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Fake AnsibleModule test object'''
    class FakeModule():
        params = {}

    class FakeResults():
        '''
        Fake results dict as returned by ansible_facts. Must match the structure of what ansible_facts would return.
        '''

# Generated at 2022-06-20 16:58:45.623100
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.collector.ansible_collector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    from ansible.module_utils.facts import namespace

    # This is needed for the import above to work on python 2 and for the code
    # in the module_utils to work.
    ansible.module_utils.facts.utils.CACHE_TIMEOUT = 0

    from ansible_collections.community.general.tests.unit.compat import unittest

    class FakeModule:
        def __init__(self):
            self.params = {}


# Generated at 2022-06-20 16:58:53.647121
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic
    cls = basic.AnsibleModule
    module = cls(argument_spec = dict(gather_subset = dict(type='list', default=['!all'])))
    facts_dict = get_all_facts(module)
    assert facts_dict is not None
    assert 'distribution' in facts_dict


# Generated at 2022-06-20 16:59:05.627816
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 16:59:17.738845
# Unit test for function ansible_facts
def test_ansible_facts():
    import argparse
    import unittest

    class FakeModuleUtil(object):
        '''mock module_util to fake out ansible_facts method'''

        @staticmethod
        def params():
            return {}

    class FakeModule(object):
        '''mock ansible Module to fake out ansible_facts method'''

        def __init__(self):
            self.params = argparse.Namespace()
            self.params.gather_subset = ['default', 'fake']
            self.module_util = FakeModuleUtil()

    class FakeFactsCollector(object):
        '''mock FactsCollector to fake out ansible_facts method'''

        @staticmethod
        def collect():
            return {}

    # test with empty module
    ansible_facts(FakeModule())

    # test with module

# Generated at 2022-06-20 16:59:29.328969
# Unit test for function ansible_facts
def test_ansible_facts():
    # load in fake ansible module
    import ansible.module_utils.facts.ansible_facts
    import ansible.module_utils.basic
    import ansible.module_utils.facts.namespace

    class FakeAnsibleModule(object):

        def __init__(self, params):
            self.params = params
            self.default_ipv4 = {'address': '192.0.2.1', 'interface': 'eth0'}
            self.default_ipv6 = {'address': '2003:db8:1:0:0:0:1:1', 'interface': 'eth0'}

# Generated at 2022-06-20 16:59:40.547531
# Unit test for function ansible_facts
def test_ansible_facts():
    import mock

    class MockAnsibleModule(object):
        def __init__(self, params=None):
            self.params = params or {}

    class MockFactCollector(object):
        def __init__(self, module=None,
                     all_collector_classes=None,
                     namespace=None,
                     filter_spec=None,
                     gather_subset=None,
                     gather_timeout=None,
                     minimal_gather_subset=None):
            self.module = module
            self.all_collector_classes = all_collector_classes
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.minimal_gather_subset = minimal_gather

# Generated at 2022-06-20 16:59:49.008947
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import os
    import sys

    orig_sys_path = sys.path

    # Need to insert a directory into the sys.path so we can find the module to test.
    test_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ansible_module_test')
    sys.path.insert(0, test_path)

    from ansible_module_test.network_cli_argspec import get_argspec, argspec as cli_argspec
    from ansible_module_test.network_json_argspec import get_argspec, argspec as json_argspec
    from ansible_module_test.network_module import main as module_main


# Generated at 2022-06-20 16:59:59.353399
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    import json

    fact_dict = ansible_facts(AnsibleModule(argument_spec={'gather_subset': dict(type='list')}))

    # make sure the ansible_facts dict is JSON serializable
    json.dumps(fact_dict)

# Generated at 2022-06-20 17:00:06.557574
# Unit test for function ansible_facts
def test_ansible_facts():
    # setup the mock module
    mock_module = MockAnsibleModule()
    mock_module.params = dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*'
    )

    # call the function we are testing
    results = ansible_facts(mock_module)

    assert 'all' in results
    assert 'ansible' not in results
    assert 'default_ipv4' in results


# Generated at 2022-06-20 17:00:15.186447
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import add_prefix
    import mock
    module_mock = mock.MagicMock()
    module_mock.params = {
        'gather_subset': None
    }

    class TestFactCollector(BaseFactCollector):
        _fact_ids = ('test_fact',)

        def collect(self, module=None):
            return {'test_fact': 'test_value'}

    # test_ansible_facts collects the ansible_facts subset by default
    assert ansible_facts(module=module_mock) == {'test_fact': 'test_value'}

    # test_ansible_facts can collect the ansible_facts subset

# Generated at 2022-06-20 17:00:23.137614
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import mock

    class MockAnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': None}

    module = MockAnsibleModule()


# Generated at 2022-06-20 17:00:33.744543
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts

    # This is a minimal AnsibleModule stub
    class AnsibleModule:
        def __init__(self):
            self.params = {}
            self.called = False
            self.fail_json_called = False
            self.warned_facts = []

        def fail_json(self, *args, **kwargs):
            self.fail_json_called = True

        def warn(self, fact, version=None):
            self.warned_facts.append(fact)

    am = AnsibleModule()
    facts = ansible_facts(am)

    # 'system' fact should be present in all facts
    assert 'system' in facts
    assert facts['system'] != ''
    # 'distribution' fact should be present in all facts

# Generated at 2022-06-20 17:00:40.520553
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test ansible 2.2/2.3: module_utils.facts.get_all_facts'''

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    # test to make sure no collect() method is called on
    # module_utils.facts.get_all_facts() or
    # module_utils.facts.ansible_facts()
    class FailingCollector(BaseFactCollector):
        '''raise an exception if collect() is called'''

        def collect(self, module=None, collected_facts=None):
            '''raise an exception if collect() is called'''
            raise Exception('collect() should not be called')


# Generated at 2022-06-20 17:00:46.480969
# Unit test for function get_all_facts
def test_get_all_facts():
    mock_module = AnsibleModule()
    mock_module.params = {'gather_subset': ['all']}

    facts = get_all_facts(mock_module)
    assert 'ansible_default_ipv4' in facts
    assert 'ansible_os_family' in facts


# Generated at 2022-06-20 17:00:58.020553
# Unit test for function ansible_facts
def test_ansible_facts():

    def _mock_module_params(gather_subset, gather_timeout):
        return {
            'gather_subset': gather_subset,
            'gather_timeout': gather_timeout,
        }

    class _MockAnsibleModule():
        def __init__(self, gather_subset, gather_timeout):
            self.params = _mock_module_params(gather_subset, gather_timeout)

    # Check gather_timeout defaults to 10
    module = _MockAnsibleModule(['all'], None)
    facts_dict = ansible_facts(module)
    assert facts_dict['gather_timeout'] == 10

    # Check gather_timeout can be overridden
    module = _MockAnsibleModule(['all'], 20)
    facts_dict = ansible_

# Generated at 2022-06-20 17:01:09.067167
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FauxCmdLine:
        def __init__(self, bits):
            self.bits = bits

        def get_cmdline_dict(self):
            return {'ansible_command_line': self.bits}

    class FauxAnsibleModule:
        def __init__(self, params):
            self.params = params

    def test_collector(module):
        xtra_fields = module.params['filter']

# Generated at 2022-06-20 17:01:19.152195
# Unit test for function get_all_facts
def test_get_all_facts():
    import os

    import pytest

    # The function under test depends on get_ansible_collector, which is provided with the
    # ansible modules.  So mock the modules that the function under test uses.

    # Mock AnsibleModule
    class MockAnsibleModule:
        ''' A trivial mock of AnsibleModule, so that the test can exercise get_all_facts()

        which expects to be passed an AnsibleModule.'''

        params = {
            'gather_subset': ['all'],
            'gather_timeout': 10,
            'filter': '*'
        }

        def __init__(self):
            self.exit_json = lambda: None

    # Mock AnsibleModule._connection_plugins_path

# Generated at 2022-06-20 17:01:39.142667
# Unit test for function get_all_facts
def test_get_all_facts():

    import unittest2 as unittest
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_net_tools
    from ansible.module_utils.facts import ansible_system
    from ansible.module_utils import facts
    import ansible.module_utils.facts.system.distribution as distro_module
    import ansible.module_utils.facts.system.distribution.redhat as distro_redhat_module
    import ansible.module_utils.facts.system.distribution.suse as distro_s

# Generated at 2022-06-20 17:01:46.920003
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts._collection import AnsibleFactCollector

    # monkey patch AnsibleFactCollector._run_collector so it returns predictable facts
    run_collector_orig = AnsibleFactCollector._run_collector
    AnsibleFactCollector._run_collector = \
        lambda self, *args: {'default_ipv4': {'address': '1.2.3.4'}}

    # unit test with gather_subset as a param
    module = MockAnsibleModule(params=dict(gather_subset=['all']))
    facts = get_all_

# Generated at 2022-06-20 17:01:59.291154
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test ansible_facts method.'''

    class FakeModule:  # pylint: disable=too-few-public-methods
        '''Fake module class'''

        def __init__(self):
            self.params = {'filter': '*'}

    fake_module = FakeModule()
    ansible_facts_dict = ansible_facts(module=fake_module)

    # assertions
    # simple one to ensure something got returned
    assert 'distribution' in ansible_facts_dict.keys()

    # ensure filter_spec of '*' returned all known fact names.
    # Note: When this test runs on a system with a real OS distribution, extra facts will be
    # returned that are not in the 'always_collect' list. That is ok.

# Generated at 2022-06-20 17:02:02.826788
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts import module_utils
    class FakeModule:
        def __init__(self, gather_subsets):
            self.params = ImmutableDict(gather_subset=gather_subsets)
    module = FakeModule(['all'])
    got_all_facts = get_all_facts(module)
    assert got_all_facts['default_ipv4']['address']

# Generated at 2022-06-20 17:02:12.771152
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector

    # mock AnsibleModule, with facts_module=True (so it will add it's params, including gather_subset)
    from ansible.module_utils.facts import samefile
    from ansible.module_utils.basic import AnsibleModule

    class TestAnsibleModule(AnsibleModule):
        def __init__(self):
            self.argument_spec = dict()
            self.params = dict(gather_subset=['all'])
            self.ansible_facts = dict()

# Generated at 2022-06-20 17:02:20.367547
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils._text import to_bytes
    class FakeAnsibleModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = lambda *args, **kwargs: None
            self.exit_json = lambda *args, **kwargs: None

    class FakeCollector(object):
        def __init__(self, name, facts_dict):
            self.name = name
            self.facts = facts_dict

        def collect(self, module):
            module.exit_json = lambda *args, **kwargs: None
            return self.facts


# Generated at 2022-06-20 17:02:30.712740
# Unit test for function get_all_facts
def test_get_all_facts():

    import ansible.module_utils.facts.processor
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    import os
    import tempfile

    test_env_var = 'ANSIBLE_UNIT_TEST_test_get_all_facts'
    os.environ[test_env_var] = 'True'

    # Create an empty module object
    module = ansible.module_utils.facts.processor.FactsModule([])

    # Set the gather_subset arg to a provided list of subsets
    module.params['gather_subset'] = ['min']

    # Create an empty module object
    module = ansible.module_utils.facts.processor.FactsModule([])
    module.params['gather_subset'] = ['all']

    # Create a test namespace
    namespace

# Generated at 2022-06-20 17:02:36.186476
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector

    class Module:
        params = {'gather_subset': ['!all', 'network', '!foo']}


# Generated at 2022-06-20 17:02:47.968680
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.hardware.base import HardwareCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

    module = MockModule()

    # Verify default arguments
    all_collector_classes = default_collectors.collectors
    assert all_collector_classes
    ansible_facts(module, gather_subset=['all'])
    # Make sure all the default collectors get called
    for collector_class in all_collector_classes:
        if collector_class is not BaseFactCollector and collector_class is not HardwareCollector:
            assert collector_class.called

# Generated at 2022-06-20 17:02:59.661494
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.modules.system import setup
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_all_collector_classes

    module = setup.AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['all'], type='list')),
        bypass_checks=True,
    )

    fact_collector = FactCollector()
    all_collector_classes = get_all_collector_classes()

    # namespace set to ansible for ansible 2.0 compat
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    gather_subset = ['all']
    collect_all_facts

# Generated at 2022-06-20 17:03:29.246683
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_text

    orig_get_all_facts = ansible_collector.get_all_facts
    orig_ansible_facts = ansible_collector.ansible_facts

    class MockAnsibleModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = lambda x: "fail_json %s" % x
            self.run_command = lambda x: "%s" % x

    orig_PrefixFactNamespace = ansible_collector.PrefixFactNamespace
    orig_default_

# Generated at 2022-06-20 17:03:37.674828
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.compat.module_utils_facts_ansible
    import ansible.module_utils.facts.compat.test_module_utils_facts_ansible

    failed, total = ansible.module_utils.facts.compat.test_module_utils_facts_ansible.do_test_ansible_facts(
        ansible.module_utils.facts.compat.module_utils_facts_ansible.ansible_facts)

    assert failed == 0

# Generated at 2022-06-20 17:03:39.345038
# Unit test for function ansible_facts
def test_ansible_facts():
    assert False, "Fix this"

# Generated at 2022-06-20 17:03:50.259465
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts import to_text
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    # To test for the py26-py27 code path first we need to remove NetworkCollector from
    # the default collectors.
    all_collector_classes = default_collectors.collectors
    del all_collector_classes[NetworkCollector.__name__]

    # Make sure the NetworkCollector is not present
    assert NetworkCollector not in all_collector_classes.values()

    # So we need to install a NetworkCollector so we don't hit the py3 code path.
    all_collect

# Generated at 2022-06-20 17:04:01.299757
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    sys.path.append('/home/vagrant/ansible/lib/ansible/module_utils')
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-20 17:04:11.067960
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_collector

    module = AnsibleModule(argument_spec={'gather_subset': dict(type=list),
                                          'gather_timeout': dict(type=int),
                                          'filter': dict(type=str)})
    module.params = {'gather_subset': ['all'], 'gather_timeout': 10, 'filter': '*'}
    ansible_facts = get_all_facts(module)
    assert 'distribution' in ansible_facts
    assert 'distribution_release' in ansible_facts
    assert 'distribution_version' in ansible_facts
    assert 'architecture' in ansible_facts
    assert 'default_ipv4' in ans

# Generated at 2022-06-20 17:04:21.738356
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import os

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'utils'))
    from ansible_module_utils.compat import AnsibleModule

    class FakeModule(AnsibleModule):
        '''AnsibleModule class is an abstract base class. We need to provide
        it our own implementation to test ansible_facts.
        '''

        def __init__(self, params):
            self.params = params

    module = FakeModule(params={
        'gather_subset': ['!all', 'network', 'virtual'],
        'filter': 'foo.bar',
        'gather_timeout': 1,
    })

    # To test:
    #  - the filter
    #  - subset/minimal_gather_subset

# Generated at 2022-06-20 17:04:28.031885
# Unit test for function get_all_facts
def test_get_all_facts():
    module = FakeModule()
    actual_facts = get_all_facts(module)
    expected_facts = {'default_ipv4': 'default_ipv4 value'}
    assert actual_facts == expected_facts, 'compat_api.get_all_facts did not return expected facts'


# Generated at 2022-06-20 17:04:39.788885
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.modules.system import setup
    from ansible.module_utils import basic
    import ansible.constants as C

    module = setup.AnsibleModule(
        argument_spec=setup.setup_args(),
        supports_check_mode=True
    )

    if C.DEFAULT_GATHERING == 'implicit':
        gather_subset = [x['name'] for x in module.params['gather_subset']]
        gather_timeout = module.params['gather_timeout']
    else:
        gather_subset = None
        gather_timeout = 0

    print(ansible_facts(module, gather_subset=gather_subset))

if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-20 17:04:48.559825
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit test for ansible_facts method'''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'gather_timeout': dict(type='int', default=1)})
    module_facts = ansible_facts(module)

    # test that module_facts includes the bare default_ipv4
    assert 'default_ipv4' in module_facts.keys()

# Generated at 2022-06-20 17:05:32.117448
# Unit test for function get_all_facts
def test_get_all_facts():

    class Module:
        def __init__(self, params):
            self.params = params

    module = Module(params={'gather_subset': ['all']})

    facts_dict = get_all_facts(module)

    assert isinstance(facts_dict, dict)

    # The ansible_ namespace should be stripped
    assert facts_dict.get('default_ipv4', False)
    assert not facts_dict.get('ansible_default_ipv4', False)



# Generated at 2022-06-20 17:05:37.632772
# Unit test for function get_all_facts
def test_get_all_facts():
    class AnsibleModule:
        def __init__(self, params):
            self.params = params

    assert isinstance(get_all_facts(AnsibleModule({'gather_subset': ['all']})), dict)


# Generated at 2022-06-20 17:05:44.365801
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    # we expect the function to return a dict with one key,
    # the name of the fact 'default_ipv4', and the same value
    # that was returned by the ansible_default_ipv4 fact.

    dummy_module = AnsibleModule(argument_spec={'gather_subset': dict(required=False)})

    def mock_ansible_facts(module, gather_subset=set()):
        # assert that that the func is calling ansible_facts with the same module instance
        assert module is dummy_module

        # return a dict that test_ansible_facts_compat would return

# Generated at 2022-06-20 17:05:53.189621
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule:
        def __init__(self, params):
            self.params = params

    # test that if gather_subset is set and gather_timeout is not set, default will be set
    params = {'gather_subset': ['!minimal']}
    module = FakeModule(params=params)
    fact_dict = ansible_facts(module=module)
    assert 'ansible_all_ipv4_addresses' in fact_dict

    # test that if gather_subset is not set and gather_timeout is set, default will be set
    params = {'gather_timeout': 1}
    module = FakeModule(params=params)
    fact_dict = ans

# Generated at 2022-06-20 17:06:04.769756
# Unit test for function ansible_facts
def test_ansible_facts():
    # Mock class for AnsibleModule
    class MockModule():
        def __init__(self):
            self.params = {'gather_subset': ['all'],
                           'filter': 'ansible_ls*',
                           'gather_timeout': 10}

    mock_module = MockModule()
    facts_dict = ansible_facts(mock_module)

    # The following  line is for debugging purpose only, comment it out for unit test
    # import pprint
    # pprint.pprint(facts_dict)

    assert 'lsb' in facts_dict
    assert 'lsb.distcodename' in facts_dict
    assert facts_dict['lsb.distcodename'] == 'xenial'
    assert 'lsb.distdescription' in facts_dict

# Generated at 2022-06-20 17:06:16.732253
# Unit test for function get_all_facts
def test_get_all_facts():
    # Load the actual module, since we are just testing the function and not the module.
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system import DistributionFactModule

    # Set up the test fixture

# Generated at 2022-06-20 17:06:27.557028
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    from ansible.module_utils.facts import FactsParameters
    from ansible.module_utils.facts.test_utils import TestAnsibleModule

    test_module = TestAnsibleModule(params=FactsParameters.get_default_params())

    def mock_type_and_version(self):
        return {'distribution': None,
                'distribution_release': None,
                'distribution_version': None}

    from ansible.module_utils.facts import system
    system.System.get_distribution = mock_type_and_version

    def mock_ip_addresses(self, module):
        return ['1.1.1.1', '2.2.2.2']

    from ansible.module_utils.facts import interface
    interface.Interface.ip_addresses = mock_ip_

# Generated at 2022-06-20 17:06:36.539106
# Unit test for function get_all_facts
def test_get_all_facts():

    class ansible_module:
        params = {}

    # gather_subset=None should not cause errors
    assert get_all_facts(ansible_module) is not None

    # If gather_subset is 'all' facts should be collected
    ansible_module.params = {'gather_subset': 'all'}
    all_facts = get_all_facts(ansible_module)
    assert 'ansible_facts' in all_facts
    assert 'ansible_distribution_release' in all_facts['ansible_facts']

    # If gather_subset is not 'all' facts should not be collected
    ansible_module.params = {'gather_subset': 'not-all'}
    all_facts = get_all_facts(ansible_module)

# Generated at 2022-06-20 17:06:46.418911
# Unit test for function get_all_facts
def test_get_all_facts():
    import mock
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Interface
    from ansible.module_utils.facts.network.base import NetworkConfig
    from ansible.module_utils.facts.network.hardware_info import HardwareInfoCollector
    from ansible.module_utils.facts.network.interfaces import InterfacesCollector
    from ansible.module_utils.facts.network.local import LocalCollector
    from ansible.module_utils.facts import namespace as facts_ns
    from ansible.module_utils.facts import ansible_collector

    gather_subset = ['!all', 'network']