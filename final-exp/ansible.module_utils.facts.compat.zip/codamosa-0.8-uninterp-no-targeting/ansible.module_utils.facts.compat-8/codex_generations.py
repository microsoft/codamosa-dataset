

# Generated at 2022-06-20 16:56:57.817793
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    all_facts = get_all_facts()
    assert set(all_facts.keys()) == set(['default_ipv4', 'default_ipv6', 'fqdn', 'hostname', 'kernel', 'kernel_version',
                                         'machine', 'machine_id', 'manufacturer', 'network', 'operating_system',
                                         'operating_system_release', 'product_name', 'product_serial',
                                         'product_uuid', 'system', 'system_vendor', 'system_vendor_id',
                                         'virtualization_role', 'virtualization_type'])

    # module_utils.facts.ansible_facts is deprecated, but test it

# Generated at 2022-06-20 16:57:09.969759
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.default_collectors import NetworkCollector
    from ansible.module_utils.facts.default_collectors import PlatformCollector
    from ansible.module_utils.facts.default_collectors import DistributionCollector
    from ansible.module_utils.facts.default_collectors import LocalCollector
    import ansible.module_utils.facts.hardware.base as hardware_base
    import ansible.module_utils.facts.network.base as network_base
    import ansible.module_utils.facts.system.base as system_base

    # Note: can't stub AnsibleModule directly, so mimic its interface
    class AnsibleModule:
        def __init__(self, params):
            self.params = params

    params = {
        'gather_subset': ['all']
    }

# Generated at 2022-06-20 16:57:13.502055
# Unit test for function get_all_facts
def test_get_all_facts():
    class Test:
        def __init__(self, params):
            self.params = params
    params = dict(gather_subset=['all'], gather_timeout=10)
    module = Test(params)
    facts = get_all_facts(module)
    assert len(facts) > 0

# Generated at 2022-06-20 16:57:23.307684
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector.hardware import Hardware
    from ansible.module_utils.facts.collector.network import Network
    from ansible.module_utils.facts.collector.mount import Mount
    from ansible.module_utils.facts.collector.systemd import Systemd
    from ansible.module_utils.facts.collector.local import Local
    from ansible.module_utils.facts.collector.platform import Platform
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

# Generated at 2022-06-20 16:57:29.788503
# Unit test for function ansible_facts
def test_ansible_facts():
    '''test ansible facts collection'''
    class TestModule(object):
        '''Ansible compatible module class'''
        params = {'gather_subset': ['all']}

    module = TestModule()
    facts_dict = ansible_facts(module=module)

    assert 'all' in facts_dict
    assert 'merged_facts' in facts_dict['all']
    for fact in facts_dict['all']['merged_facts']:
        assert fact in facts_dict

# Generated at 2022-06-20 16:57:42.727153
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_native
    from ansible.module_utils import basic

    class FakeModule(object):
        '''Fake module class to test get_all_facts()'''

        def __init__(self, ansible_facts):
            self.ansible_facts = ansible_facts

    class FakeAnsibleModule(object):
        '''Fake ansible module class to test get_all_facts()'''

        def __init__(self, params):
            self.params = params
            self.module = FakeModule({})

        def fail_json(self, msg, **kwargs):
            raise AssertionError(to_native(msg))

    all_facts_module = FakeAnsibleModule(params={'gather_subset': ['all']})

    all_facts = get_

# Generated at 2022-06-20 16:57:50.950826
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.collector as collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import hardware
    import ansible.module_utils.facts as facts
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector

    class TestModule():
        def __init__(self):
            self.params = {}

    class TestHardWare(hardware.Hardware):
        @collector.collector
        def populate(self):
            self

# Generated at 2022-06-20 16:57:55.734634
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all'])})
    result = get_all_facts(module=module)
    assert 'all_ipv4_addresses' in result
    assert 'default_ipv4' in result
    assert result['all_ipv4_addresses'] == result['default_ipv4']['address']



# Generated at 2022-06-20 16:57:57.763981
# Unit test for function get_all_facts
def test_get_all_facts():

    result = get_all_facts(MockAnsibleModule())
    assert result.get('virtualization_role') == 'guest'
    assert result.get('virtualization_type') == 'kernel'



# Generated at 2022-06-20 16:58:11.316300
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class Test_AnsibleModule(object):
        class AnsibleModule(object):

            def __init__(self, name, **kwargs):
                self.name = name
                self.params = kwargs


            def exit_json(self, **kwargs):
                return kwargs



# Generated at 2022-06-20 16:58:18.962409
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for ansible_facts method.

    This is a simple unit test to just show that the ansible_facts is still a valid
    function for 2.0/2.1/2.2/2.3.

    The actual functionality of ansible_facts is covered in tests for the
    module_util.facts.ansible_collector module.
    '''

    from ansible.module_utils.facts import ansible_facts

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    data = ansible_facts(module)

    # simply assert we got a dict back
    assert isinstance(data, dict)

    # and that this key exists
    assert 'distribution' in data

# Generated at 2022-06-20 16:58:21.263206
# Unit test for function ansible_facts
def test_ansible_facts():
    from mock import MagicMock
    module = MagicMock()
    module.params = {'gather_subset': ['all']}
    assert 'ipv4' in ansible_facts(module)
    assert 'distribution' in ansible_facts(module)

# Generated at 2022-06-20 16:58:33.855524
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts.utils import FactsParams
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.utils import get_collector_classes_for_subset
    from ansible.module_utils.facts.utils import get_sorted_namespace_facts
    from ansible.module_utils.facts import collectors

    import mock
    import os.path

    # mock a module instance
    #
    # This particular mock is the bare stub of a ModuleUtil which doesn't actually
    # execute any commands, or load any modules.
    # It's 'execute_command' method just returns a dict with an rc and stdout
    # attributes.
    #
    # Our test will use this mock_module to test the functionality of the module_utils/facts.

# Generated at 2022-06-20 16:58:42.560165
# Unit test for function get_all_facts
def test_get_all_facts():

    results = get_all_facts(module)

    assert results is not None
    assert isinstance(results, dict)

    assert 'distribution' in results
    assert results['distribution'] is not None

    assert 'distribution_version' in results
    assert results['distribution_version'] is not None

    assert 'architecture' in results
    assert results['architecture'] is not None

    assert 'lsb' in results
    assert results['lsb'] is not None

    assert 'default_ipv4' in results

    assert 'fips' in results

    assert 'python' in results

    assert 'platform_version' in results
    assert results['platform_version'] is not None

    assert 'platform_full' in results
    assert results['platform_full'] is not None

    assert 'platform_major_version' in results

# Generated at 2022-06-20 16:58:56.424633
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import sys
    sys.path.append('lib')

    module = os.path.join(os.getcwd(), 'ansible/modules/system/setup.py')
    test_module = os.path.join(os.getcwd(), 'test/test_modules/test_setup.py')
    test_plugin_path = os.path.join(os.getcwd(), 'test/test_modules')


# Generated at 2022-06-20 16:59:06.549250
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import FactsCollector

    class FakeModule():
        def __init__(self, gather_subset=None, gather_timeout=10):
            self.params = {}
            if gather_subset:
                self.params['gather_subset'] = gather_subset
            if gather_timeout and gather_timeout != 10:
                self.params['gather_timeout'] = gather_timeout


# Generated at 2022-06-20 16:59:14.113316
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.facts.network.base import NetworkCollector
    if PY3:
        from importlib import reload

    # monkey patch the network collector module
    network_collector_module = getattr(default_collectors, 'network')
    default_collectors.network = reload(network_collector_module)

    class FakeNetworkCollector(NetworkCollector):
        def __init__(self, *a, **kw):
            super(FakeNetworkCollector, self).__init__(*a, **kw)

        def collect(self, *a, **kw):
            return {}

    default_collectors.network.NetworkCollector = FakeNetworkCollector

    # restore original network collector class after the test completes

# Generated at 2022-06-20 16:59:26.299298
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeAnsibleModule:
        params = {
            'gather_timeout': 10,
            'gather_subset': ['network', 'virtual'],
            'filter': "ansible_eth*",
        }

    fake_module = FakeAnsibleModule()
    all_collector_classes = default_collectors.collectors
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-20 16:59:38.550893
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    import copy
    from ansible.module_utils.facts import ansible_collector

    from unit.modules.utils import set_module_args
    from ansible.module_utils.facts.namespace import PrefixFactNamespace


    original_all_collectors = copy.deepcopy(default_collectors.collectors)

    class TestFactCollector(object):

        def __init__(self, *args, **kwargs):
            pass

        def collect(self, module=None):
            return {'fact_one': 'value1', 'fact_two': 'value2'}

    # Replace the original FactCollector

# Generated at 2022-06-20 16:59:41.230839
# Unit test for function ansible_facts
def test_ansible_facts():
    module = mock_ansible_module('foo')
    ansible_facts(module)
    assert module.exit_json.called

# Generated at 2022-06-20 16:59:58.732833
# Unit test for function ansible_facts
def test_ansible_facts():
    def fake(module):
        return {}

    from ansible.module_utils._text import to_bytes

    from ansible.module_utils import basic
    from ansible.module_utils.facts import ansible_collector

    old_get_all_facts = ansible_collector.get_all_facts

# Generated at 2022-06-20 16:59:59.200466
# Unit test for function get_all_facts
def test_get_all_facts():
    pass

# Generated at 2022-06-20 17:00:02.333400
# Unit test for function get_all_facts
def test_get_all_facts():
    # Module is a dummy object
    module = object()
    # Calling the function doesn't raise an exception
    get_all_facts(module)

# Generated at 2022-06-20 17:00:10.969082
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'gather_timeout': dict(type='int', default=1)})
    facts = ansible_facts(module, gather_subset=['all', 'hardware'])
    assert facts['docker_container']['running'] is False
    assert isinstance(facts['memory']['swap'], dict)
    assert isinstance(facts['ansible_processor_vcpus'], int)
    assert isinstance(facts['ansible_processor_count'], int)
    assert isinstance(facts['ansible_processor_cores'], int)
    assert isinstance(facts['ansible_processor_threads_per_core'], int)
    assert isinstance(facts['ansible_memtotal_mb'], int)

# Generated at 2022-06-20 17:00:18.784118
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts.system.distribution as distro_collector
    import ansible.module_utils.facts.system.platform as platform_collector
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr_collector

    # Create a module
    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['!all', 'min']}


    # Create a dictionary with fake facts for the three collectors

# Generated at 2022-06-20 17:00:30.289702
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test the ansible_facts function with an AnsibleModule with gather_subset
    param value as 'all' .'''

    from ansible.module_utils.facts import Facts
    import ansible.module_utils.facts.hardware.sunos as hardware_sunos
    import ansible.module_utils.facts.system.sunos as system_sunos

    module = Facts()
    module.params = dict(gather_subset='all')

    hardware_sunos.__salt__ = {}
    hardware_sunos.__grains__ = {}
    hardware_sunos.__opts__ = {}
    hardware_sunos.__pillar__ = {}
    hardware_sunos.__salt__ = {}
    hardware_sunos.__context__ = {}
    hardware_sunos.__utils__ = {}
   

# Generated at 2022-06-20 17:00:38.950184
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'

    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    all_collector_classes = default_collectors.collectors

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-20 17:00:50.159921
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.test.test_ansible_facts
    import ansible.module_utils.facts.test.test_dummy_collector
    import ansible.module_utils.facts.test.test_file_collector
    import ansible.module_utils.facts.test.test_plugins

    ansible.module_utils.facts.test.test_ansible_facts.test_ansible_facts()
    ansible.module_utils.facts.test.test_dummy_collector.test_dummy_collector()
    ansible.module_utils.facts.test.test_file_collector.test_file_collector()
    ansible.module_utils.facts.test.test_plugins.test_plugins()


# Generated at 2022-06-20 17:01:01.739361
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.collector import FactsCollector

    class MockModule(object):
        def __init__(self, params=None):
            self.params = params or dict()

    # Test that if gather_subset is not defined in params,
    # the 'all' gather_subset will be used
    mock_module = MockModule()
    assert get_all_facts(mock_module) == ansible_facts(mock_module, gather_subset=['all'])

    # Test that the defined gather_subset in params will be used
    mock_module = MockModule(params={'gather_subset': ['network']})

# Generated at 2022-06-20 17:01:10.924936
# Unit test for function ansible_facts
def test_ansible_facts():
    # FakeAnsibleModule simulates a AnsibleModule() object

    class FakeAnsibleModule(object):
        class FakeModuleParams(object):
            def __init__(self, gather_subset, gather_timeout, filter_spec):
                self.gather_subset = gather_subset
                self.gather_timeout = gather_timeout
                self.filter = filter_spec

            def get(self, key, default_val):
                return getattr(self, key, default_val)

        def __init__(self, gather_subset, gather_timeout, filter_spec):
            self.params = self.FakeModuleParams(gather_subset=gather_subset,
                                                gather_timeout=gather_timeout,
                                                filter_spec=filter_spec)


# Generated at 2022-06-20 17:01:28.280651
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.basic import AnsibleModule

    class TestFact1(BaseFactNamespace):
        name = 'test_fact1'

    class TestFactCollector(BaseFactCollector):
        name = 'mytest'
        _namespaces = [TestFact1().namespace]

    def _test_module(params):
        def define_module():
            return AnsibleModule(argument_spec=dict(gather_subset=params.get('gather_subset')),
                                 supports_check_mode=True)

        return define_module()

    # Test gather_subset is passed in and it is a list

# Generated at 2022-06-20 17:01:33.716228
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.platform.freebsd
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.service_mgr

    class FakeModule:
        params = {
            'filter':'*',
        }

    # facts.ansible_facts() should return a dict without the 'ansible_' prefix

# Generated at 2022-06-20 17:01:39.066710
# Unit test for function get_all_facts
def test_get_all_facts():

    # create a fake module for testing get_all_facts
    class FakeModule(object):
        def __init__(self, params=None):
            self.params = params

        def fail_json(self, msg, **kwargs):
            pass

        def base_param_spec(self):
            return {}

    test_params = {}
    test_params['gather_subset'] = ['all']

    fake_module = FakeModule(params=test_params)

    # collect all facts
    facts = get_all_facts(fake_module)

    # should get a dict back with some facts
    assert isinstance(facts, dict)
    assert len(facts) > 0

# Generated at 2022-06-20 17:01:45.912609
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    facts_dict = ansible_facts(module, gather_subset=['network'])

    assert isinstance(facts_dict, dict)
    assert 'network' in facts_dict
    assert 'default_ipv4' in facts_dict['network']

    # test no gather_subset arg
    facts_dict = ansible_facts(module)

    assert isinstance(facts_dict, dict)
    assert 'network' in facts_dict
    assert 'default_ipv4' in facts_dict['network']



# Generated at 2022-06-20 17:01:49.876471
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    facts = ansible_facts(dict(), gather_subset=None)
    assert 'ansible_hostname' in facts

# Generated at 2022-06-20 17:02:01.810412
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_collector
    mock_module = MagicMock()
    mock_module.params = {'gather_subset': 'all'}
    mock_module.fail_json.side_effect = AssertionError

    mock_ansible_collector = MagicMock()
    mock_ansible_collector.collect.return_value = {'actual_fact': 'actual_fact_value'}
    ansible_collector.AnsibleCollector = MagicMock(return_value=mock_ansible_collector)

    facts = get_all_facts(mock_module)
    assert facts == {'actual_fact': 'actual_fact_value'}
    mock_module.fail_json.assert_not_called()



# Generated at 2022-06-20 17:02:11.538856
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    import sys
    import io
    import os
    import unittest
    import tempfile
    import platform
    import shutil
    import copy

    #This is a fake AnsibleModule class.
    #This code is used by both a unit test, and the module_utils.facts.get_all_facts method.
    #The module_utils.facts.get_all_facts method expects 'module' to be an instance of AnsibleModule.
    #When ansible-test is run, this test is run against an instance of AnsibleModule.
    #However

# Generated at 2022-06-20 17:02:19.582517
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts as facts_utils
    import ansible.module_utils.facts.legacy as module_utils_facts_legacy
    import ansible.module_utils.facts.generic as generic_facts
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*',
    )
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.params = module_args

    facts_dict = ansible_facts(module)

    # just do some basic testing here, in case someone uses this function elsewhere
    # core tests are in module_utils/facts/generic

# Generated at 2022-06-20 17:02:29.537479
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts

    returns a dict mapping the bare fact name ('default_ipv4' with no 'ansible_' namespace) to
    the fact value.
    '''

    module = AnsibleModule(argument_spec={
        'gather_subset': {'default': ['all'], 'type': 'list'},
        'gather_timeout': {'default': 10, 'type': 'int'},
        'filter': {'default': '*', 'type': 'str'}
        })

    result = ansible_facts(module, gather_subset=['all'])
    assert ('kernel' in result)
    assert ('os_family' in result)

# Generated at 2022-06-20 17:02:33.744572
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts.default_collectors

    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['apparmor', 'caps', 'cmdline', 'date_time',
                                             'distribution', 'dns', 'env', 'fips', 'local',
                                             'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                             'service_mgr', 'ssh_pub_keys', 'user'],
                           'gather_timeout': 1}
            ansible.module_utils.facts.default_collectors.DEFAULT_GATHER_TIME

# Generated at 2022-06-20 17:02:58.614198
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'gather_subset': {'type': 'list', 'default': ['all']}})

    gathered_facts = get_all_facts(module)

    assert 'default_ipv4' in gathered_facts
    assert 'default_ipv6' in gathered_facts

    assert gathered_facts['default_ipv4']['address'] is not None


# Generated at 2022-06-20 17:03:11.085432
# Unit test for function ansible_facts
def test_ansible_facts():
    # mock module object
    class MockModule:
        def __init__(self, params):
            self.params = params
        def fail_json(self, *args, **kwargs):
            assert False
        def exit_json(self, *args, **kwargs):
            assert False


# Generated at 2022-06-20 17:03:21.526968
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.facts import get_all_facts as get_all_facts_22
    from ansible.module_utils.facts.facts import get_all_facts as get_all_facts_23
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.basic import AnsibleModule

    # capture output of module_utils.facts.get_all_facts()
    am = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all']),
                                      'gather_timeout': dict(type='int', default=10),
                                      'filter': dict(type='str', default='*')})

    gaf22 = get_all_facts_22(am)
    af = ansible_facts(am)
    g

# Generated at 2022-06-20 17:03:26.790072
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    # real module_utils/facts.py gets imported in ansible.module_utils.basic.AnsibleModule
    # so we can't use that module here.
    import ansible.module_utils.basic
    def param(name, val):
        return {'name': name,
                'type': type(val).__name__,
                'default': val,
                'no_log': False,
                'required': True,
                'aliases': [],
                'choices': []}

    module = ansible.module_utils.basic.AnsibleModule(argument_spec=[param('gather_subset', ['all']),
                                                                     param('filter', '*')])

    facts_dict = ansible_facts(module)
    assert facts_dict['lsb']['distcodename']

# Generated at 2022-06-20 17:03:39.049225
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    if sys.version_info >= (3, 0):
        from importlib import reload
    else:
        from imp import reload

    reload(default_collectors)
    reload(ansible_collector)
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    class FakeModule(object):
        # noinspection PyPep8Naming
        def __init__(self):
            self.params = {'gather_subset': None, 'filter': '*', 'gather_timeout': 10}

        def get_bin_path(self, *cmds, **kw):
            return '/usr/bin/fake_bin_path'

        def fail_json(self, *args, **kw):
            raise AssertionError

# Generated at 2022-06-20 17:03:46.824282
# Unit test for function ansible_facts
def test_ansible_facts():
    import unittest
    import sys
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class _AnsibleModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, command, required=False, opt_dirs=None):
            if command == 'cat':
                return 'cat'

    class _TestFacts(object):
        def __init__(self, module):
            pass

        def populate(self):
            return {'hello': 'world'}

    class _BaseAnsibleFactsTestCase(unittest.TestCase):
        def setUp(self):
            # Save original imports
            self.real_import = __import__


# Generated at 2022-06-20 17:03:59.596226
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import facts
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.namespace_loader as loader

    #collectors = ansible.module_utils.facts.default_collectors.collectors
    #modules = ansible.module_utils.facts.ansible_collector.get_ansible_collector(collectors)
    #all_facts = ansible.module_utils.facts.ansible_collector.collect(modules)

    # test module class
    class AnsibleModuleTest:
        params = dict(gather_subset=['all'])

    # test module
    module = AnsibleModuleTest()

    # test namespace
    namespace.PrefixFactNamespace(namespace_name='ansible', prefix='')

    # test namespace

# Generated at 2022-06-20 17:04:10.261087
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'filter': {'required': False, 'type': 'str', 'default': '*'}})
    filter_spec = module.params.get('filter', '*')
    fact_dict = ansible_facts(module)

    assert isinstance(fact_dict, dict)
    assert 'distribution' in fact_dict
    assert 'distribution_version' in fact_dict
    assert 'distribution_release' in fact_dict
    assert 'os_family' in fact_dict
    assert 'distribution_major_version' in fact_dict
    assert 'ansible_all_ipv4_addresses' in fact_dict
    assert 'ansible_all_ipv6_addresses' in fact_dict

# Generated at 2022-06-20 17:04:21.443035
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.common._collections_compat import Mapping
    import ansible.module_utils.facts.facts
    module_name = 'ansible.module_utils.facts.facts'
    import sys
    my_module = sys.modules[module_name]
    # reload this module after patching it
    my_module = reload(sys.modules[module_name])

    # patch module_utils.facts.ansible_facts
    def mocked_ansible_facts(module, gather_subset=None):
        expected_module = module

        assert isinstance(expected_module, Mapping)

        # ensure gather_subset is gathered from module
        assert gather_subset == expected_module['gather_subset']
        return {'default_ipv4': '10.20.30.40'}



# Generated at 2022-06-20 17:04:30.711996
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    try:
        from ansible.module_utils.facts.namespace import Namespace
        from ansible.module_utils.facts.collector import BaseFactCollector, \
            NamespaceCollector, FactCollector
        from ansible.module_utils.facts.system.distribution import DistributionCollector
        from ansible.module_utils.facts.system.pkg_mgr import PkgMgrCollector
        from ansible.module_utils.facts.system.user import UserCollector

        from ansible.module_utils.facts.system.local import LocalCollector
        NS = Namespace
    except ImportError:
        raise ImportError('Unable to import ansible module_utils')

    # The full namespace is namespaces[0]

# Generated at 2022-06-20 17:05:15.620643
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import sys
    import pytest
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # Dummy test, doesn't call a real collector
    class Dummy(object):
        name = 'ansible_dummy'
        def __init__(self, **kwargs):
            pass
        def collect(self, module):
            return {'a':1, 'b':2}

    class DummyCollector(ansible_collector.BaseFactCollector):
        name = 'dummy'

# Generated at 2022-06-20 17:05:26.489305
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockParams(object):
        def __init__(self, facts_dict):
            self.facts_dict = facts_dict

        def __getattr__(self, item):
            if item == 'gather_subset':
                return self.facts_dict.keys()
            elif item == 'filter':
                return '*'
            else:
                return None

    #  mock AnsibleModule class
    class MockModule(object):
        def __init__(self, region):
            self.params = MockParams(region.facts_dict)


# Generated at 2022-06-20 17:05:36.874581
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.virtual.lspci import LspciFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    from ansible.module_utils.facts.system.date_time import DateTimeFactCollector
    from ansible.module_utils.facts.system.cmdline import CmdLineFactCollector
    from ansible.module_utils.facts.system.env import EnvFactCollector
    from ansible.module_utils.facts.system.local import LocalFactCollector
    from ansible.module_utils.facts.system.dns import DnsFactCollector

# Generated at 2022-06-20 17:05:44.363717
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import _get_plugin
    from ansible.module_utils.facts.collector import BaseFactCollector

    collect_all_facts_called = False

    class FakeFactCollector(BaseFactCollector):
        name = 'fake'
        def collect(self, module=None, collected_facts=None):
            nonlocal collect_all_facts_called
            collect_all_facts_called = True
            return dict(name='fake', value=1)

    all_collectors = default_collectors.collectors + [FakeFactCollector]

    class FakeModule(object):
        def __init__(self):
            self.params = dict(
                gather_subset=['all'],
                gather_timeout=10,
                filter='*'
            )

    fake_module = FakeModule

# Generated at 2022-06-20 17:05:53.253750
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import is_package_installed
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Fake module instance
    class FakeModule:
        params = {'gather_subset': ['all'],
                  'gather_timeout': 10,
                  'filter': '*',
                  }

        # This is an empty base class
        class AnsibleModule:
            pass

    facts = ansible_facts(FakeModule)

    assert facts['system'] == 'Linux'
    assert 'lsb' in facts
    assert 'date_time' in facts
    assert 'pkg_mgr' in facts
    assert 'fips' in facts


# Generated at 2022-06-20 17:06:04.801160
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors, ansible_collector
    all_collector_classes = default_collectors.collectors

    # If the function is called without a gather_subset param, then it should default to ['all']

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    fact_collector = \
        ansible_collector.get_ansible_collector(all_collector_classes=all_collector_classes,
                                                namespace=namespace,
                                                filter_spec='*',
                                                gather_subset=None,
                                                gather_timeout=10)

    # mock the module

# Generated at 2022-06-20 17:06:16.441922
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.collector import AnsibleCollector

    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    # get_all_facts should pass through to ansible_facts
    ansible_facts_result = {'a': 'A', 'b': 'B'}

    def mock_ansible_facts(module, gather_subset=None):
        assert isinstance(module, MockModule)
        assert gather_subset == ['all']
        return ansible_facts_result

    results = get_all_facts(MockModule())
    assert results == ansible_facts_result



# Generated at 2022-06-20 17:06:17.651118
# Unit test for function get_all_facts
def test_get_all_facts():
    # TODO: Add unit tests for get_all_facts
    # TODO: Update this test for Python3
    pass

# Generated at 2022-06-20 17:06:20.706592
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(MockModule(gather_subset=['all']))



# Generated at 2022-06-20 17:06:24.576940
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    facts_dict = ansible_facts(module)

    assert 'machine_id' in facts_dict
    assert 'distribution' in facts_dict['lsb']
