

# Generated at 2022-06-20 16:56:58.402255
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils import basic
    from ansible.module_utils.facts import default_collectors

    def mock_ansible_facts(module, gather_subset=None):
        # capture what this function was called with
        mock_ansible_facts.params = (module, gather_subset)
        return {}

    # true argument needed so that general facts are collected
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params['gather_subset'] = ['all']

    # mock ansible_facts module utils function so that we can
    # capture the arguments it is called with
    saved_ansible_facts = default_collectors.ansible_facts
    default_collectors.ansible_facts = mock_ansible_facts


# Generated at 2022-06-20 16:57:04.161730
# Unit test for function get_all_facts
def test_get_all_facts():

    class FakeModule(object):
        params = {'gather_subset': ['all']}

    try:
        get_all_facts(FakeModule())
    except Exception as exc:
        assert False, 'get_all_facts() raised %s unexpectedly' % exc



# Generated at 2022-06-20 16:57:13.429596
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestFacts(Facts):

        def __init__(self):
            super(Facts, self).__init__()
            self.__facts_cache = dict()

        def populate_facts(self, cached=False, module=None):
            return dict(foo=True, bar=False)

    # Test ansible_facts with valid subset and all defaults
    test_collectors = [TestFacts()]
    test_namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    test_timeout = 5


# Generated at 2022-06-20 16:57:22.326594
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors

    # create an instance of an AnsibleModule
    module = AnsibleModule(argument_spec={})

    # test both with and without the 'gather_subset' param
    #   - without the param, it should collect all facts

    # get_all_facts() method defaults to all facts if no gather_subset param
    facts_dict = get_all_facts(module=module)
    assert 'distribution' in facts_dict
    assert facts_dict['distribution'] == 'unknown'

    # get_all_facts() method uses the 'gather_subset' param
    module.params['gather_subset'] = ['network']
    facts_dict = get_all_facts(module=module)

# Generated at 2022-06-20 16:57:28.920073
# Unit test for function get_all_facts
def test_get_all_facts():

    # empty params
    params = dict(gather_subset=['!all'], gather_timeout=10)
    fake_module = FakeAnsibleModule(params=params)
    assert not get_all_facts(fake_module)

    # minimal gather subset
    minimal_gather_subset = ['minimal', '!all', '!hardware', '!network', '!virtual']
    params = dict(gather_subset=minimal_gather_subset, gather_timeout=10)
    fake_module = FakeAnsibleModule(params=params)
    assert get_all_facts(fake_module)

    # no gather subset
    params = dict(gather_timeout=10)
    fake_module = FakeAnsibleModule(params=params)
    assert get_all_facts(fake_module)



# Generated at 2022-06-20 16:57:41.914320
# Unit test for function ansible_facts
def test_ansible_facts():
    from .mock_module_utils.module import AnsibleModule
    # Make a module that only has a params dict.
    module_params = dict(gather_subset=['network'],
                         gather_timeout=10,
                         filter='*')
    module = AnsibleModule(argument_spec=dict(), params=module_params)

    # get facts for the module
    facts = ansible_facts(module)

    # Check that the facts we got back include at least one network fact
    assert facts['interfaces'] is not None
    # Check that the network fact we got back is a list
    assert isinstance(facts['interfaces'], list)
    # Check that the list of interfaces is non-empty
    assert len(facts['interfaces']) > 0



# Generated at 2022-06-20 16:57:50.630463
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import FACT_SUBSETS
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import mock

    class MockModule(object):
        def __init__(self):
            self.fail_json = mock.Mock()
            self.params = dict()

    def mock_collect_all(self):
        return dict()

    mock_module = MockModule()
    mock_module.params = dict()

    mock_module.params['gather_subset'] = None
    mock_module.params['filter'] = '*'
    mock_module.params['gather_timeout'] = 10

    mock

# Generated at 2022-06-20 16:57:57.584831
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import module_utils_facts_get_all_facts
    module = module_utils_facts_get_all_facts()
    all_facts = get_all_facts(module=module)
    assert isinstance(all_facts, dict)
    assert len(all_facts) > 1
    assert 'distribution' in all_facts


# Generated at 2022-06-20 16:58:04.376797
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    params = {'gather_subset': ['network', 'hardware']}
    module = AnsibleModule(argument_spec={}, params=params)
    assert get_all_facts(module) == ansible_facts(module)

# Generated at 2022-06-20 16:58:13.167974
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_collector

    class FakeCollector(ansible_collector.BaseFactCollector):
        def collect(self, module=None):
            return dict(foo='bar')

    module = AnsibleModule(argument_spec={'gather_subset': dict(default='all', required=False, type='list')})
    all_collector_classes = default_collectors.collectors + [FakeCollector]

# Generated at 2022-06-20 16:58:21.469805
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import cache

    base_facts = cache.get_cache(timeout=0)
    module_params = {
        'gather_subset': ['min'],
    }
    class FakeModule:
        params = {}
        def __init__(self, params):
            self.params = params
    fake_module = FakeModule(module_params)
    ansible_facts_dict = get_all_facts(fake_module)

    for fact in base_facts['ansible_facts']:
        assert fact in ansible_facts_dict

# Generated at 2022-06-20 16:58:33.955771
# Unit test for function ansible_facts
def test_ansible_facts():
    import inspect
    import sys
    import tempfile
    import time

    class MockAnsibleModule:
        def exit_json(self, *args, **kwargs):
            if self.fail_exit:
                self.fail_json(*args, **kwargs)
            else:
                raise FakeAnsibleExitJson(*args, **kwargs)

        def fail_json(self, *args, **kwargs):
            raise FakeAnsibleFailJson(*args, **kwargs)

    def MockAnsibleModule_run_command(module, command, check_rc=True):
        if command == ['lsb_release', '-is']:
            stdout = module.lsb_in_fail_mode and b'failed \n' or b'RedHat\n'

# Generated at 2022-06-20 16:58:34.644684
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-20 16:58:43.496775
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test function get_all_facts'''
    from ansible.module_utils.facts import get_all_facts
    class AnsibleModule:
        '''fake class'''
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['all']}
    module = AnsibleModule(params=params)
    all_facts = get_all_facts(module=module)

    assert(all_facts['default_ipv4']['address'] != '')

# unit tests for function ansible_facts

# Generated at 2022-06-20 16:58:56.745098
# Unit test for function ansible_facts
def test_ansible_facts():
    import tempfile
    import shutil
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform

    class FakeModule():
        def __init__(self):
            self.params = {}

    test_module = FakeModule()

    # Fake a system without any package manager
    with tempfile.NamedTemporaryFile() as temp:
        temp.write('#!/bin/sh\n')
        temp.flush()
        test_module.ansible_pkg_mgr = 'noop'
        test_module.ansible_package_mgr = 'noop'
        ansible.module_utils.facts.system.pkg_

# Generated at 2022-06-20 16:59:03.220099
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    # Here is all we have to do to make test_ansible_facts pass.
    # We need to make the collector cache available to the module_utils.facts.ansible_collector
    collector.setup_cache()

    # Then we just assert that the function returns something
    assert ansible_facts(basic.AnsibleModule(argument_spec={}))

# Generated at 2022-06-20 16:59:04.502761
# Unit test for function ansible_facts
def test_ansible_facts():
    pass


# Generated at 2022-06-20 16:59:17.212980
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    class FakeAnsibleModule(object):

        def __init__(self, params):
            self.params = params

    # Set gather_subset to the bare minimum, so we don't rely on facts from other modules,
    # which might not be in the test enviornment
    params = dict(gather_subset=['min'], gather_timeout=1, filter='*')
    module = FakeAnsibleModule(params)
    result = get_all_facts(module)

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-20 16:59:26.571296
# Unit test for function ansible_facts
def test_ansible_facts():
    class Module(object):
        def __init__(self, params):
            self.params = params

        # Fake ansible_facts, so get_all_facts doesn't complain
        def __getattr__(self, attr):
            if attr in ['ansible_facts', 'ansible_version']:
                return True

    module = Module(params={'gather_timeout': 1})
    module.params['gather_subset'] = ['!all', '!min', 'network']
    facts = ansible_facts(module)
    assert facts != {}

    module.params['gather_subset'] = ['network']
    facts = ansible_facts(module)
    assert facts != {}

# Generated at 2022-06-20 16:59:38.729333
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeAnsibleModule:
        def __init__(self, params):
            self.params = params
            self.changed = False
            self.failed = False
            self.error_message = ''

    # Test all facts
    test_module = FakeAnsibleModule({'gather_subset': ['all']})
    ret = get_all_facts(test_module)
    assert 'local' in ret
    assert 'lsb' in ret
    assert 'dns' in ret
    assert 'user' in ret
    assert 'python' in ret

    # Test a single fact and catch the exception if it fails
    test_module = FakeAnsibleModule({'gather_subset': ['local']})
    ret = get_all_facts(test_module)
    assert 'local' in ret

# Generated at 2022-06-20 16:59:49.492288
# Unit test for function get_all_facts
def test_get_all_facts():
    import pytest

    class TestModule():
        pass

    # no gather_subset is provided
    module = TestModule()
    module.params = dict()
    assert get_all_facts(module) == dict()

    # a valid gather_subset is provided
    module.params['gather_subset'] = ['all']
    assert get_all_facts(module)

    # an invalid gather_subset is provided
    module.params['gather_subset'] = []
    with pytest.raises(AssertionError):
        get_all_facts(module)

# Generated at 2022-06-20 17:00:00.116797
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    fake_module = FakeModule()

    # gather_subset is not set, so should be copied from ansible_facts to get_all_facts
    try:
        del fake_module.params['gather_subset']
    except KeyError:
        pass
    facts = get_all_facts(fake_module)
    assert facts == ansible_facts(fake_module)

    # gather_subset is set, so should not be copied from ansible_facts to get_all_facts
    fake_module.params['gather_subset']

# Generated at 2022-06-20 17:00:10.786636
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule

    def verify_module_exists(modulename):
        try:
            __import__(modulename)
        except ImportError:
            return False
        else:
            return True

    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(type='list', default=['all']),
        gather_timeout=dict(type='int', default=10),
        filter=dict(default='*'),
    ), supports_check_mode=True)
    # check if we have access to all the required libs
    if not verify_module_exists('platform'):
        module.fail_json(msg='platform python module required for this module')

    results = ansible_facts

# Generated at 2022-06-20 17:00:16.969682
# Unit test for function get_all_facts
def test_get_all_facts():

    class AnsibleModule:
        def __init__(self, params, *args, **kwargs):
            self.params = params

    params = {'gather_subset': ['all']}
    ansible_module = AnsibleModule(params)
    facts = get_all_facts(ansible_module)

    assert facts is not None
    assert len(facts) > 0
    assert 'distribution' in facts
    assert 'distribution_version' in facts
    assert facts['distribution'] == 'RedHat'
    assert facts['distribution_version'] == '6.7'

# Generated at 2022-06-20 17:00:26.797874
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    fake_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    fake_module.exit_json = lambda x: x
    data = ansible_facts(fake_module)
    assert isinstance(data, dict)
    assert data['lsb']['distcodename'] == 'jessie'
    assert data['distribution'] == 'Debian'
    assert data['distribution_version'] == '8'

# Generated at 2022-06-20 17:00:32.349637
# Unit test for function ansible_facts
def test_ansible_facts():
    class TestModule:
        def fail_json(self, **kwargs):
            raise AssertionError(kwargs)

    test_module = TestModule()

    facts = ansible_facts(test_module)
    assert facts['architecture'] == 'x86_64'

# Generated at 2022-06-20 17:00:39.969534
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.platform import Linux
    from ansible.module_utils.facts.system import Distro
    from collections import OrderedDict

    # mock for a module instance
    class FakeAnsibleModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            pass

    module = FakeAnsibleModule()
    module.params['gather_subset'] = [Distro.name]
    module.params['gather_timeout'] = 0

    # mock for a ansible_facts collector instance
    class FakeFactCollector(object):
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-20 17:00:50.630170
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class FakeAnsibleModule:
        def __init__(self):
            self.params = dict(gather_subset=['default'])
    module = FakeAnsibleModule()


# Generated at 2022-06-20 17:01:02.091780
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test for ansible <= 2.2
    from ansible.module_utils.facts import ansible_facts

    class TestAnsibleModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, **kwargs):
            raise AssertionError(kwargs)

    params = dict(gather_subset=['all'])
    module = TestAnsibleModule(params)
    facts_dict = ansible_facts(module)
    assert isinstance(facts_dict, dict)
    assert 'default_ipv4' in facts_dict

    # Test for ansible >= 2.3
    from ansible.module_utils.facts import ansible_facts


# Generated at 2022-06-20 17:01:11.212302
# Unit test for function get_all_facts
def test_get_all_facts():
    ''' Test function get_all_facts '''
    from ansible.module_utils.facts.base import BaseFactCollector
    import ansible.module_utils.facts.accelerate
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system

    # Create a fake module object for testing
    class FakeModule():
        def __init__(self, params):
            self.params = params
            self.check_mode = False
            self.fail_json = lambda *args, **kwargs: None

    params = {'gather_subset': '!all,foo'}
    module = FakeModule(params)
    result = {}

# Generated at 2022-06-20 17:01:26.737033
# Unit test for function get_all_facts
def test_get_all_facts():

    # mock ansible module
    module = AnsibleModule()

    # set mock params
    module.params = {'gather_subset': ['all']}

    # ensure that facts are being collected as expected
    all_facts = get_all_facts(module=module)

    assert type(all_facts) is dict
    assert 'ansible_distribution' in all_facts
    assert all_facts['ansible_distribution'] == 'Ubuntu'

    assert 'ansible_distribution_release' in all_facts
    assert all_facts['ansible_distribution_release'] == '16.04'

    assert 'ansible_virtualization_role' in all_facts
    assert all_facts['ansible_virtualization_role'] in ['guest', 'host']

    # ensure that facts are being collected as expected
    ansible

# Generated at 2022-06-20 17:01:38.477100
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    import ansible
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Load a mock module to provide the 'params' dict with the 'gather_subset' param
    from ansible.module_utils.facts import get_all_facts

    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all'])})
    module.params = {'gather_subset': ['all']}

    all_facts = get_all_facts(module)

    assert module.params['gather_subset'] == ['all']

    # test that the resulting dict of facts has a key named 'ansible_all_ipv4_addresses'

# Generated at 2022-06-20 17:01:46.422835
# Unit test for function ansible_facts
def test_ansible_facts():

    import ansible.module_utils.facts.platform.linux
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.dns
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.cmdline
    import ansible.module_utils.facts.network.interface
    import ansible.module_utils.facts.network.default_ipv4
    import ansible.module_utils.facts.network.local
    import ansible.module_utils.facts.network.route
    import ansible.module

# Generated at 2022-06-20 17:01:53.066680
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.six import PY3
    from ansible.module_utils import basic
    if not PY3:
        module = basic.AnsibleModule({'gather_subset': ['network']})
        assert isinstance(ansible_facts(module), dict)

# Generated at 2022-06-20 17:02:05.038608
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Example of how to use the ansible_facts module_utils api in a unit test.
    '''

    # This call expects to be passed an AnsibleModule instance with the 'gather_subset'
    # param set in the module.params dict.
    # This is what happens when gather_facts is called from a module, the module param is
    # set, and the module_utils.facts.get_all_facts is called via AnsibleModule.run_command.
    #
    # In our unit test we'll create a mock instance of AnsibleModule, and pass that in.
    #
    # We'll also mock the run_command method, and make it do what AnsibleModule.run_command
    # does normally, which is to munch on the module.params dict and call the module_utils.facts.get_all_facts
    #

# Generated at 2022-06-20 17:02:17.899037
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.dns import DnsFactCollector

    # stub a module class
    class AnsibleModule():
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['dns']

    # stub a fact collector class to return some interesting data
    class StubFactCollector(collector.BaseFactCollector):
        NAME = 'stub'
        def __init__(self, module):
            super(StubFactCollector, self).__init__(module=module)
            self.collect_called = False

        def collect(self, module=None, collected_facts=None):
            self

# Generated at 2022-06-20 17:02:29.105788
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''
    import json

    class MockArgs:
        def __init__(self):
            self.gather_subset = ['all']

    class MockModule:
        def __getattribute__(self, item):
            if item == 'params':
                return MockArgs()
            else:
                return MockModule()

        def __call__(self, *args, **kwargs):
            return MockModule()

    print('TESTING with gather_subset = ALL')
    print('\nFact Dump for gather_subset=all:')
    print(json.dumps(get_all_facts(MockModule()), indent=4))
    print('------------------------------------------------------------------------------------------')



# Generated at 2022-06-20 17:02:34.869551
# Unit test for function get_all_facts
def test_get_all_facts():
    '''unit test for function get_all_facts()'''
    import sys
    import os
    sys.path.append('../lib')
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import get_default_collectors

    def _load_params(self):
        '''fake method to mock the AnsibleModule api'''
        return dict(gather_subset=['all'], foo='bar', _ansible_version='2.4')

    module = type('Ansible', (object,), dict(_ansible_version='2.4', params=_load_params))()

    # Pretend to be able to import psutil

# Generated at 2022-06-20 17:02:47.495535
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    # Compat Mock for ansible 2.3
    try:
        from unittest.mock import Mock, patch
    except ImportError:
        from mock import Mock, patch


    # ansible_facts/ansible_collector.py will use 'module' within namespace to get
    # the collect_only, verbose, and timeout attrbiutes.

    # Therefore, we need to create a mock module with the attributes needed
    # by the unit test, plus the attributes needed by ansible_collector.
    # We only need the attributes of the module that are used by ansible_facts.
    # We do not

# Generated at 2022-06-20 17:02:59.509340
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system import loadavg
    from ansible.module_utils.facts.system import uptime
    from ansible.module_utils.facts.network import acl
    from ansible.module_utils.facts.system import domainname
    from ansible.module_utils.facts.system import fqdn
    from ansible.module_utils.facts.system import hostname
   

# Generated at 2022-06-20 17:03:21.107214
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import tempfile

    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    def get_distro_test_collector(namespace, **kwargs):
        class TestDistroCollector(DistributionFactCollector):
            _platform = 'Linux'

            _distribution = None

            @classmethod
            def distribution(cls):
                # if cls._distribution is None:
                #     cls._distribution = cls.get_distribution(cls._platform)
                # return cls._distribution
                return 'Linux'  # Kernel

        return TestDistroCollector(namespace=namespace, **kwargs)


# Generated at 2022-06-20 17:03:28.881552
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector.system import LinuxDistributionFactCollector
    from ansible.module_utils.facts.collector.system import DefaultIpFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.ansible_collector
    import mock

    mock_module = mock.Mock()
    mock_module.params = {'gather_subset':['network','system']}

    assert "Linux" in ansible.module_utils.facts.ansible_collector.ansible_facts(mock_module,gather_subset='network')['network']['distribution_version']


# Generated at 2022-06-20 17:03:39.777522
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.basic
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system
    import sys
    dummy_logger = ansible.module_utils.facts.collector.get_logger()
    dummy_logger.addHandler(ansible.module_utils.basic._AnsibleSilentNullHandler())
    dummy_module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    all_collector_classes = ansible.module_utils.facts.system.collectors
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-20 17:03:48.598359
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.modules.system.setup as setup
    module = setup.AnsibleModule(argument_spec=setup.argument_spec,
                                 supports_check_mode=setup.supports_check_mode,
                                 bypass_checks=setup.bypass_checks)

    # want to test that we return a dict mapping from fact name w/o namespace to value
    result = ansible_facts(module)
    assert isinstance(result, dict)
    assert 'default_ipv4' in result
    assert 'ansible_default_ipv4' not in result

# Generated at 2022-06-20 17:04:00.657827
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import FACT_CACHE
    from ansible.module_utils.facts.test_collector import MockAnsibleModule

    module = MockAnsibleModule()
    # Use the 2.3 style gather_subsets param.
    facts_dict = ansible_facts(module, ['default'])
    assert('default_ipv4' in facts_dict)
    assert(FACT_CACHE.get('default_ipv4'))
    assert(FACT_CACHE.get('ansible_default_ipv4'))

    # Ensure if we use the 2.0 way of passing gather_subset as a param, that we get the same thing
    module.params['gather_subset'] = ['default']
    facts_dict = ansible_facts(module)

# Generated at 2022-06-20 17:04:07.971521
# Unit test for function get_all_facts
def test_get_all_facts():

    # setup test

    class MockAnsibleModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = 'all'

    module = MockAnsibleModule()


    # run test

    result = get_all_facts(module)

    # check result

    assert(type(result) == dict)


# Generated at 2022-06-20 17:04:20.632513
# Unit test for function get_all_facts
def test_get_all_facts():

    import ansible.module_utils.basic
    import ansible.module_utils.facts

    facts = ansible.module_utils.facts.get_all_facts(ansible_module)
    assert set(facts.keys()) == set(['default_ipv4', 'default_ipv6', 'fqdn',
                                     'hostname', 'ip_addresses', 'ip_domain',
                                     'ip_fqdn', 'ip_hostname', 'macaddress',
                                     'python_version', 'system', 'system_vendor'])


# Generated at 2022-06-20 17:04:31.959020
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import module_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    import os
    import sys

    os_facts = ansible_facts(module=module_facts)

    assert isinstance(os_facts, dict)
    assert len(os_facts) > 0
    platform_facts = os_facts['platform']
    assert isinstance(platform_facts, dict)
    assert platform_facts['system'] == 'Linux'

    # ensure that calling ansible_facts works with and without passing gather_subset

# Generated at 2022-06-20 17:04:41.694124
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import module_provisioner
    from ansible.module_utils.facts import module_extender
    from ansible.module_utils.facts import module_loader
    from ansible.module_utils.facts import module_utils_loader
    from ansible.module_utils.facts import module_tree_builder

    fact_collector_classes = default_collectors.collectors
    fact_collector_classes = module_extender.extend_collector_classes(fact_collector_classes)
    fact_collector_classes = module_tree_builder.build_collector_tree(fact_collector_classes)

# Generated at 2022-06-20 17:04:52.762503
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector

    # mock-up a module
    class MockAnsibleModule():
        def __init__(self):
            self.params = {'gather_timeout': 10}

    def mock_collect(self, module):
        '''mock up the BaseFactCollector.collect method'''
        return {'key1': 'value1', 'key2': 'value2'}

    # use mock-patch to mock-up BaseFactCollector.collect
    # so that BaseFactCollector.collect() calls mock_collect
    with mock.patch.object(BaseFactCollector, 'collect', new=mock_collect) as mock_collect:
        module = MockAnsibleModule()
        ansible_facts = ansible_facts(module)
        assert ansible

# Generated at 2022-06-20 17:05:26.034887
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.linux.distribution as d
    import ansible.module_utils.facts.system.linux.interfaces as i
    import ansible.module_utils.facts.system.linux.pkg_mgr as p

    f = ansible_facts

    # fill in the stubs for facts
    d.Distribution.get_distribution = lambda x: 'centos'
    i.Interfaces.get_interfaces_info = lambda x: {}
    p.PkgMgr.get_package_mgr_info = lambda x: {}

    class AnsibleModule:
        def __init__(self, params):
            self.params = params

    module = AnsibleModule({'gather_subset': ['all']})

    facts = f(module, gather_subset=['all'])

# Generated at 2022-06-20 17:05:37.597897
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import get_all_facts

    import ansible.module_utils.facts.collector.platform

    class FakeAnsibleModule:
        def __init__(self, params):
            self.params = params

    # Setup the FakeAnsibleModule
    params = {'gather_subset': ['!all', 'network']}
    fake_module = FakeAnsibleModule(params=params)

    all_facts = get_all_facts(fake_module)
    ansible_facts_facts = ansible_facts(fake_module, gather_subset=['!all', 'network'])
    platform_facts = ansible.module_utils.facts.collector.platform.get_platform_facts()
    assert ansible_facts_facts == all_facts == platform_facts

# Generated at 2022-06-20 17:05:42.437493
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['all'], type='list')})

    facts_dict = ansible_facts(module)

    module.fail_json(msg=to_text(facts_dict))



# Generated at 2022-06-20 17:05:53.743513
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors

    class FakeModule(object):
        def __init__(self, module_args):
            self.params = module_args

    # set up a couple of collectors and a name space
    collector1 = default_collectors.DefaultCollector()
    collector2 = default_collectors.DefaultCollector()
    collector2.FACTS['global_fact'] = 'global_value'
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    # Test with a fake module
    module = FakeModule({'gather_subset': ['all']})
    facts_dict = ansible_facts(module=module, gather_subset=None)
    assert 'global_fact' in facts_dict.keys()

# Generated at 2022-06-20 17:06:04.948239
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network import network_lsb
    from ansible.module_utils.facts.network.generic_bsd import NetBSDNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import FreeBSDNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import OpenBSDNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import DragonFlyBSDNetworkCollector
    import ansible.module_utils.facts.network.ios
    import ansible.module_utils.facts.network.asa
    import ansible.module_utils.facts.network.eos
   

# Generated at 2022-06-20 17:06:16.767682
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import os
    import tempfile
    import shutil
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    # monkey patching required for unit testing, because ansible_facts
    # calls ansible.module_utils.facts.ansible_collector.get_ansible_collector
    # which imports a fact collector from each fact_dir.  This is normally
    # fine, but we don't want these fact collectors, as fact collectors might
    # not be compatible with python2 "import" statement.  So, monkey patch
    # this function to return just the base fact collector.

# Generated at 2022-06-20 17:06:27.585010
# Unit test for function ansible_facts
def test_ansible_facts():
    module = Mock(params=dict(gather_subset=['all'], filter='*', gather_timeout=10))

    gather_subset = module.params['gather_subset']
    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    empty_filter_spec = None
    facts_dict = ansible_facts(module, gather_subset)

    assert facts_dict.get('lsb', None) is not None
    assert facts_dict.get('lsb', None)

# Generated at 2022-06-20 17:06:32.589108
# Unit test for function get_all_facts
def test_get_all_facts():
    module = mock.Mock()
    gather_subset = ["all"]
    module.params = {"gather_subset": gather_subset}
    facts = get_all_facts(module)
    assert facts is not None
    assert "ansible_architecture" in facts


# Generated at 2022-06-20 17:06:45.393067
# Unit test for function get_all_facts