

# Generated at 2022-06-20 16:56:54.743667
# Unit test for function get_all_facts
def test_get_all_facts():
    test_module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(type='list', default=['all']),
    ))
    all_facts = get_all_facts(test_module)

    # Verify that the facts dictionary has at least one element
    assert len(list(all_facts.keys())) >= 1



# Generated at 2022-06-20 16:57:03.332057
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import namespace

    class AnsibleModuleFake(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

    def ansible_facts_fake(module):
        return {'a': 1}

    default_collectors.ansible_collector.ansible_collector.get_ansible_collector = ansible_facts_fake
    module = AnsibleModuleFake({'gather_subset': ['all']})
    assert get_all_facts(module) == {'a': 1}
    module = AnsibleModuleFake({})
    assert get_all_facts(module) == {'a': 1}
    module = AnsibleModuleFake({'gather_subset': []})

# Generated at 2022-06-20 16:57:13.054720
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit test for this module.
    Requires the following pip packages to be installed:
        - mock
        - pytest
    '''
    import mock
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockCollector(object):
        '''
        A mock collector
        '''
        def __init__(self, name):
            self._name = name

        def collect(self, module):
            return {
                '_name': self._name,
            }

    class MockModule(object):
        '''
        A mock AnsibleModule.
        '''

# Generated at 2022-06-20 16:57:22.261919
# Unit test for function get_all_facts
def test_get_all_facts():

    import os
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock
    from ansible.module_utils.facts import ansible_facts

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = dict()

        def fail_json(self, msg=None, **kwargs):
            self.exit_args = dict(failed=True, msg=msg, **kwargs)
            self.exit_called = True

    class FactsModuleTestCase(unittest.TestCase):

        def setUp(self):
            self.module = AnsibleModuleMock()


# Generated at 2022-06-20 16:57:28.870709
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.legacy
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace

    # Make sure module_utils.facts *is* ansible.module_utils.facts
    assert ansible.module_utils.facts == ansible.module_utils.facts
    assert ansible.module_utils.facts.system == ansible.module_utils.facts.system
    assert ansible.module_utils.facts.network == ansible.module_utils.facts.network
    assert ansible.module_utils.facts.virtual == ansible.module_utils.facts.virtual

# Generated at 2022-06-20 16:57:42.205920
# Unit test for function get_all_facts
def test_get_all_facts():
    import modules.command
    import modules.script
    import modules.setup
    import modules.systemd
    import modules.systemd.systemctl

    def get_module_mock(params):
        return AnsibleModuleMock(params)

    # A mock AnsibleModule object.
    class AnsibleModuleMock(object):
        def __init__(self, params):
            self.params = params

    # Module schemas (to make the AnsibleModuleMock object work)
    command_schema = modules.command.Command.argument_spec
    command_schema.pop('free_form')
    script_schema = modules.script.Script.argument_spec
    script_schema.pop('free_form')
    systemctl_schema = modules.systemd.systemctl.Systemctl.argument_spec
    systemctl_

# Generated at 2022-06-20 16:57:48.071985
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    test_get_all_facts() is a unit test for function get_all_facts

    It tests get_all_facts when gather_subset is a single value

    It tests get_all_facts when gather_subset is a list
    '''

    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.network.base import NetworkCollector

    class AnsibleModule(object):

        def __init__(self, params):
            self.params = params

    class AllNetworkCollector(NetworkCollector):

        def __init__(self, *args, **kwargs):
            super(AllNetworkCollector, self).__init__(*args, **kwargs)


# Generated at 2022-06-20 16:58:00.004977
# Unit test for function ansible_facts
def test_ansible_facts():
    # To run this test, you need an Ansible module to mock.
    #
    # import ansible.modules.network
    # module = ansible.modules.network.iosxr.iosxr_facts
    #
    # Then provide module as the arg to the test_ansible_facts function
    #   test_ansible_facts(module)

    import ansible.modules.network
    module = ansible.modules.network.iosxr.iosxr_facts
    #module = ansible.modules.network.cisco.asa_facts

    facts_dict = ansible_facts(module)
    assert type(facts_dict) is dict
    #assert 'default_ipv4' in facts_dict
    #assert 'default_ipv6' in facts_dict

# Generated at 2022-06-20 16:58:11.695794
# Unit test for function ansible_facts
def test_ansible_facts():
    # When using the facts module, gather_subset is set to all,
    # and gather_timeout is set to 10.
    module = MockFactsModule(gather_subset='all', gather_timeout=10)


# Generated at 2022-06-20 16:58:23.727398
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr

    class MockModule():
        def __init__(self, params):
            self.params = params

    # gather_subset not set and gather_subset not set in params
    m = MockModule({})
    actual = ansible_facts(module=m)

    # Only delcaration of ansible_distribution doesn't get added by ansible_facts function
    # ansible_facts function adds the prefix 'ansible_' to each key.
    expected = {'ansible_lsb': {}, 'ansible_platform': '', 'ansible_pkg_mgr': ''}

    # ansible_facts function injects the date

# Generated at 2022-06-20 16:58:29.839832
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import ansible_facts
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'


# Generated at 2022-06-20 16:58:37.651774
# Unit test for function ansible_facts
def test_ansible_facts():
    # mock an AnsibleModule()
    class MockModule:
        def __init__(self):
            self.params = {}
            self.params['filter'] = '*'

    class MockAnsibleModule:
        def __init__(self):
            self.params = {}
            self.params['filter'] = '*'
            self.params['gather_subset'] = ['network', 'system']
            self.params['gather_timeout'] = 30

    mock_module = MockModule()
    ansible_facts(mock_module)

    mock_module = MockAnsibleModule()
    ansible_facts(mock_module)

# Generated at 2022-06-20 16:58:47.835420
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_version

    class FakeArgs(object):
        pass

    # Importing a module will set ANSIBLE_VERSION
    module = FakeArgs()
    module.params = {'gather_subset': ['all'],
                     'gather_timeout': 0}

    other_fact = __import__('ansible.module_utils.facts.other',
                            globals(), locals(), 'other')

    ansible_facts = ansible_facts(module)
    assert 'system' in ansible_facts
    assert 'distribution' in ansible_facts['system']
    assert ansible_facts['ansible_version']['full'] == ans

# Generated at 2022-06-20 16:58:59.396569
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # mock out the module, we're only testing the get_all_facts function
    class FakeModule(object):
        '''
            pretend to be an ansible module
        '''
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}
            self.fail_json = fail_json
            self.exit_json = exit_json

# Generated at 2022-06-20 16:59:08.785727
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.core import get_all_facts as _get_all_facts

    def get_all_facts_new_style(module, timeout=10):
        '''compat api for ansible 2.2/2.3 module_utils.facts.get_all_facts method

        Expects module to be an instance of AnsibleModule, with a 'gather_subset' param.

        returns a dict mapping the bare fact name ('default_ipv4' with no 'ansible_' namespace) to
        the fact value.'''

        gather_subset = module.params['gather_subset']

# Generated at 2022-06-20 16:59:16.872736
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.modules.system import setup
    # Module is not used, but it's good to pass in something that uses 'gather_subset'
    # It's probably better to inject a mock module, but this works
    facts_dict = ansible_facts(module=setup.AnsibleModule(argument_spec={}))
    assert 'all_ipv4_addresses' in facts_dict
    assert 'ansible_all_ipv4_addresses' not in facts_dict
    assert isinstance(facts_dict['all_ipv4_addresses'], list)

# Generated at 2022-06-20 16:59:25.115538
# Unit test for function get_all_facts
def test_get_all_facts():

    class AnsibleModuleMock(object):
        def __init__(self, gather_subset=None, gather_timeout=None):
            self.params = {'gather_subset': gather_subset, 'gather_timeout': gather_timeout}

    for gather_timeout in [None, 10]:
        module = AnsibleModuleMock(gather_subset=['all', 'network'], gather_timeout=gather_timeout)
        module_facts = get_all_facts(module=module)
        assert module_facts



# Generated at 2022-06-20 16:59:35.948740
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts

    class FakeModule():
        def __init__(self):
            pass

    fake_module = FakeModule()
    fake_module.params = {'gather_subset': 'all'}
    results = get_all_facts(fake_module)

    # Note the keys are NOT namespaced
    assert 'default_ipv4' in results
    assert results['default_ipv4']['network'] == '127.0.0.1'
    assert 'distribution' in results
    assert results['distribution'] == 'RedHat'


# Generated at 2022-06-20 16:59:47.879509
# Unit test for function get_all_facts
def test_get_all_facts():
    # import just here so unit tests don't fail if ansible is not installed on test systems
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class MockModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    gather_subset = ['hardware', 'virtual']
    mock_module = MockModule(gather_subset=gather_subset)
    facts = get_all_facts(mock_module)

    # import pprint and run pprint.pprint(facts) for debugging
    assert 'default_ipv4' in facts

# Generated at 2022-06-20 16:59:59.736045
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts, ansible_facts
    from ansible.module_utils._text import to_bytes

    class ModuleStub(object):
        def __init__(self, params):
            self._params = params

        def params(self):
            return self._params

    # Smoke test to make sure it works with stubs, but do not validate the output
    module = ModuleStub({'gather_subset': 'all'})

    try:
        get_all_facts(module)
    except Exception as ex:
        assert False, 'get_all_facts(module) raised exception: {}'.format(to_bytes(ex))


# Generated at 2022-06-20 17:00:13.399443
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.facts import ansible_facts

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    class TestFactCollector(BaseFactCollector):
        '''Test Fact Collector for get_all_facts'''

        name = 'test_collector_name'
        _fact_ids = frozenset(['test_fact_1', 'test_fact_2'])

        def collect(self, module=None, collected_facts=None):
            fact_data = dict()

# Generated at 2022-06-20 17:00:22.124110
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts, default_collectors, ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts.hardware as hardware_collector
    import ansible.module_utils.facts.network as network_collector
    import ansible.module_utils.facts.system as system_collector

    # mock the module
    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}
    module = FakeModule()

    gather_subset = module.params.get('gather_subset', ['all'])
    gather_timeout = module.params.get('gather_timeout', 10)

# Generated at 2022-06-20 17:00:32.691160
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    import os

    now = os.environ['ANSIBLE_EPOCH']

    class AnsibleModuleFake:
        def __init__(self, params):
            self.params = params
            self.fail_json = lambda msg: msg

    class FakeCollector:
        def __init__(self, name):
            self.name = name

        def fact(self, fact_name):
            return '{0}.{1}'.format(self.name, fact_name)

        def all(self):
            return {'a': 1, 'b': 2}


# Generated at 2022-06-20 17:00:40.110050
# Unit test for function get_all_facts
def test_get_all_facts():

    import collections

    from ansible.module_utils.facts.system.apparmor import Apparmor
    from ansible.module_utils.facts.system.lsb import Lsb
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.platform import Platform
    from ansible.module_utils.facts.system.service_mgr import ServiceMgr
    from ansible.module_utils.facts.system.user import User
    from ansible.module_utils.facts.system.selinux import Selinux
    from ansible.module_utils.facts.system.ssh_pub_keys import SshPubKeys

# Generated at 2022-06-20 17:00:48.926362
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 17:00:55.691294
# Unit test for function get_all_facts
def test_get_all_facts():
    class Module(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    module = Module()

    facts = get_all_facts(module)

    assert 'default_ipv4' in facts
    assert 'os_version' in facts
    assert 'ansible_all_ipv4_addresses' in facts



# Generated at 2022-06-20 17:01:06.272417
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Unit test function for the function get_all_facts()
    '''
    import ansible.module_utils.basic

    from ansible.module_utils.facts import default_collectors

    global_default_collector_classes = default_collectors.collectors

    class FakeAnsibleModule(object):
        '''
        Fake Ansible Module class that has a gather_subset param, which
        ansible_facts expects to be present.
        '''

        def __init__(self, gather_subset=['all']):
            self.gather_subset = gather_subset
            self.params = {'gather_subset': gather_subset}

    # use a fake minimal_gather_subset and a fake all_collect_classes, to
    # make sure that the minimal_gather_

# Generated at 2022-06-20 17:01:16.536250
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all'])},
                           supports_check_mode=True)
    # This test needs to run on a system where /etc/ansible/facts.d exists
    result = get_all_facts(module)
    assert isinstance(result, dict)
    assert 'ansible_mounts' in result
    assert 'ansible_distribution_version' in result
    assert 'ansible_selinux' in result
    assert 'ansible_distribution' in result

# Generated at 2022-06-20 17:01:23.631847
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils._text import to_text
    import ansible.module_utils.facts.hardware as hardware
    import ansible.module_utils.facts.os as os
    import ansible.module_utils.facts.platform as platform
    import ansible.module_utils.facts.virtual as virtual
    import ansible.module_utils.facts.system as system
    import ansible.module_utils.facts.cache as cache
    import pprint

    class FakeModule:
        def __init__(self):
            self.params = dict()

    real_collect_func = ansible_collector

# Generated at 2022-06-20 17:01:32.510127
# Unit test for function ansible_facts
def test_ansible_facts():

    import sys
    import tempfile
    import ansible.module_utils.facts.system.distribution as distribution

    # create a temp file to write the encoded result to
    encoding_file_fd, encoding_file_path = tempfile.mkstemp()
    os.close(encoding_file_fd)

    # try to determine the current distribution
    current_distro = distribution.detect()

    # if we succeeded and the current distribution is redhat-like, then use one of the
    # redhat-like distros for the test
    if current_distro['name'] and distribution.is_redhat_like(current_distro['name']):
        distro = 'redhat'
    else:
        distro = 'debian'

    # create a module that we can use to test the facts

# Generated at 2022-06-20 17:01:48.800872
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts.collector.actual_default import ActualDefaultCollector

    module = MockModule()
    module.params = {'gather_subset': ['all'], 'gather_timeout': 10}

    fact_collector = ActualDefaultCollector()
    fact_collector.collect(module=module)

    all_facts = get_all_facts(module)

    assert type(all_facts) is dict
    assert 'default_ipv4' in all_facts
    assert all_facts['default_ipv4']['address'] == '10.0.2.15'


# Generated at 2022-06-20 17:02:01.244459
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector

    GATHER_SUBSET = 'default'
    GATHER_TIMEOUT = 30

    class FakeAnsibleModule:

        def __init__(self, params):
            self.params = params

    class FakeFactCollector(BaseFactCollector):
        name = 'Faker'

        def collect(self, module=None, collected_facts=None):
            return {'faker_fact': 'faker_fact_value'}

    all_fact_collector_classes = default_collectors.collectors
    all_fact_collector_classes.append(FakeFactCollector)


# Generated at 2022-06-20 17:02:05.903412
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Unit test for function get_all_facts

    Use unittest.mock.mock_open to simulate opening files in the filesystem
    and provide mock content to read.
    '''

    import unittest.mock

    ansible_module_instance = unittest.mock.Mock()
    ansible_module_instance.params = {'gather_subset': 'all'}

    with unittest.mock.patch('ansible.module_utils.facts.collector.DistributionFactCollector.get_distribution') as mock_get_distribution:
        mock_get_distribution.return_value = 'distribution'


# Generated at 2022-06-20 17:02:18.122295
# Unit test for function ansible_facts
def test_ansible_facts():
    # This test needs to create a fake module and fake facts.  The following
    # classes are used to do that
    class FakeModule(object):
        def __init__(self, fake_params):
            self.params = fake_params
    class FakeFact(object):
        def __init__(self, fake_name, fake_val):
            self.name = fake_name
            self.val = fake_val

    #
    # Test 1
    #
    # Test the code when gather_subset is not present in the params dict
    # Returns a dict of just the fake (base) fact
    #
    fake_params = {'gather_timeout': 100}
    fake_mod = FakeModule(fake_params)
    fake_fact = FakeFact('not_ansible_distribution', 'fake_distribution')
    fake

# Generated at 2022-06-20 17:02:29.775501
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts.

    Simply tests that ansible_facts doesn't throw an exception.

    Although we're also asserting that ansible_facts returns an instance of dict, this
    is only an assertion to quiet down pylint.
    The actual return type of ansible_facts is a fact of whatever ansible_facts_collector
    returns, which is the type of ansible_facts_collector.  The returned value is
    a data structure that contains bare fact names mapped to fact values.

    The test method itself is identical to what Ansible does to test the ansible_facts method.
    '''

    from ansible.module_utils.facts import modules_module_loader
    from ansible.module_utils.facts.facts import get_facts_as_dict
    from ansible.module_utils.facts import ansible_facts

# Generated at 2022-06-20 17:02:35.368859
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    from ansible.module_utils.facts import ansible_facts

    test_facts = ansible_facts(sys, gather_subset=['min'])
    assert isinstance(test_facts, dict)
    assert 'distribution' in test_facts
    assert 'python' in test_facts

# Generated at 2022-06-20 17:02:47.777744
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    # AnsibleModule compat stub class
    # we only need it to pass the basic sanity checks in retrieve_facts()
    # we don't actually use its params
    class FakeModule(AnsibleModule):
        def __init__(self):
            self.params = {'gather_subset': '!all'}
            super(FakeModule, self).__init__(argument_spec={})

    sys.modules['__main__'] = FakeModule()

    # unit test the function, with the fake module object
    from ansible.module_utils import facts
    facts_dict = facts.ansible_facts(module=FakeModule())

    assert 'default_ipv4' in facts_dict

    # cleanup
    FakeModule.exit_json = None

# Generated at 2022-06-20 17:02:59.569832
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts.network import default_ipv4

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import RedHatFactCollector
    from ansible.module_utils.facts.system.distribution import UbuntuFactCollector
    from ansible.module_utils.facts.utils import get_module_object

    import ansible.module_utils.facts.system.network as network
    import ansible.module_utils.facts.system.distribution as distribution

    all_collector_classes = default_collectors.collectors

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-20 17:03:11.178762
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.utils import FactsFiles
    from ansible.module_utils import basic

    import tempfile

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.basic = basic

        def exit_json(self, **kwargs):
            print('%s' % kwargs)

        def fail_json(self, **kwargs):
            print('%s' % kwargs)

    fake_module = FakeModule()

    tmp_dir = tempfile.mkdtemp(prefix='ansible_test_ansible_facts_')
    fact_files = FactsFiles(tmp_dir)


# Generated at 2022-06-20 17:03:16.667235
# Unit test for function ansible_facts
def test_ansible_facts():
    class Module:
        def __init__(self):
            self.params = {'gather_subset':['all']}
    module = Module()
    test_dict = ansible_facts(module)
    assert 'ansible_local' in test_dict

# Generated at 2022-06-20 17:03:37.666844
# Unit test for function get_all_facts
def test_get_all_facts():
    test_module = type('AnsibleModule', (object,), {
        'params': {
            'gather_subset': ['all']
        }
    })()

    facts_dict = get_all_facts(test_module)
    assert facts_dict['distribution'] == 'Debian'


# Generated at 2022-06-20 17:03:44.790900
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import gather_subset_for_test
    run_count = 1
    (play_context, gather_facts_args, filter_spec) = gather_subset_for_test(run_count)
    gather_subset = play_context['gather_subset']
    gather_timeout = play_context['gather_timeout']
    filter_spec = filter_spec
    module_params = {}
    module_params.update(dict(gather_subset=gather_subset, gather_timeout=gather_timeout, filter=filter_spec))
    #import pdb; pdb.set_trace()

# Generated at 2022-06-20 17:03:47.419421
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test case: user specifies subset param
    assert ansible_facts(get_ansible_module(params={'gather_subset': ['min']})) == \
        get_ansible_module(params={'gather_subset': ['min']}).ansible_facts



# Generated at 2022-06-20 17:03:59.936832
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''

    import pprint

    class Module(object):

        def __init__(self, subset):
            self.params = {
                'gather_subset': subset,
                'gather_timeout': 10,
                'filter': [],
            }

        def get_bin_path(self, binary, required=False, opt_dirs=[]):
            if binary == 'which':
                if sys.platform.startswith('linux'):
                    return '/usr/bin/which'
                else:
                    return '/usr/bin/which'

    pp = pprint.PrettyPrinter(indent=2)
    pp.pprint(get_all_facts(Module(['all'])))
    pp.pprint(get_all_facts(Module(['min'])))

# Generated at 2022-06-20 17:04:09.168832
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import libvirt_collector
    from ansible.module_utils.facts import network_collector
    from ansible_collections.ansible.community.plugins.module_utils.facts import cpuinfo_collector
    from ansible_collections.ansible.community.plugins.module_utils.facts import memory_collector

    module = None # stub to avoid using an actual AnsibleModule object
    gather_subset = ['network']
    gather_timeout = 10
    filter_spec = '*'


# Generated at 2022-06-20 17:04:21.106062
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts
    import unittest

    class AnsibleModuleStub():
        def __init__(self):
            self.params = {}

    class TestFacts(unittest.TestCase):
        def test_get_all_facts(self):
            old_collector = ansible.module_utils.facts.ansible_collector
            ansible.module_utils.facts.ansible_collector = get_all_facts
            try:
                am = AnsibleModuleStub()
                res = get_all_facts(am)
                self.assertTrue(res)
            finally:
                ansible.module_utils.facts.ansible_collector = old_collector

    suite = unittest.TestLoader().loadTestsFromTestCase(TestFacts)

# Generated at 2022-06-20 17:04:24.577510
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        from ansible.module_utils.facts import get_all_facts
        return True
    except ImportError:
        return False

# Generated at 2022-06-20 17:04:33.410369
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.namespace as ansible_namespace
    import ansible.module_utils.facts as ansible_facts

    module = None
    gather_subset = ['min']
    fail_on_errors = True
    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    class FakeModule:
        def __init__(self):
            self.params = dict(
                gather_subset=gather_subset,
                filter='*'
            )

# Generated at 2022-06-20 17:04:42.338019
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    # Test double-run to make sure that collectors know to not run twice.
    # This is important to preserve global state in collectors like the Distribution fact collector
    # which loads modules that had __init__ code that sets up global state.
    # if a collector runs more than once, it will re-load the module and reset global state.
    import sys
    import os
    import tempfile
    import mock
    import __main__

    # This test needs to be run outside of the ansible context, in stdlib mode.
    # Create ansible module stub

# Generated at 2022-06-20 17:04:53.035283
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import os

    sys.path.append("..")
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class DummyAnsibleModule(object):
        def __init__(self):
            self.facts = {}
            self.params = {}
            self.result = {}

        def exit_json(self, *args, **kwargs):
            pass

    class DummyModuleManager(object):
        def __init__(self):
            self.module = DummyAnsibleModule()
            self.module_name = 'dummy'

    module_manager = DummyModuleManager()

# Generated at 2022-06-20 17:05:35.332945
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible_module_mock
    import ansible_module_utils
    import os

    # module_runner uses this to find modules.  In this case, the 'ansible' module is required.
    # We do not really want to run any of the ansible module in this test, so we mock it to
    # not run anything.
    class MockAnsibleModule(ansible_module_mock.AnsibleModule):
        def __init__(self):
            self.params = {
                'gather_subset': '!all',
                'gather_timeout': 0,
                'filter': '*'
            }
            module_args = {}
            super(MockAnsibleModule, self).__init__('ansible', module_args)


# Generated at 2022-06-20 17:05:38.033637
# Unit test for function get_all_facts
def test_get_all_facts():
    '''unit test for get_all_facts
    '''

    # get_all_facts is just a wrapper around ansible_facts
    assert get_all_facts == ansible_facts



# Generated at 2022-06-20 17:05:45.510326
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import FACT_CACHE

    FACT_CACHE.clear()

    import ansible.module_utils.facts as facts
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    module.params = {'gather_subset': ['!all']}
    result = ansible_facts(module)
    assert result == {}

    module.params = {'gather_subset': ['!minimal']}
    result = ansible_facts(module)
    assert len(result) == 0

    module.params = {'gather_subset': ['all', '!minimal']}
    result = ansible_facts(module)
    assert len(result) != 0


# Generated at 2022-06-20 17:05:55.215407
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    all_collector_classes = default_collectors.collectors

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-20 17:06:03.418953
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    module = AnsibleModule(argument_spec={})
    # test that, with no gather_subset specified, we get all facts
    module.params['gather_subset'] = None

    all_collector_classes = default_collectors.collectors

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-20 17:06:16.221430
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.ansible_collector import AnsibleCollector

    # for test purposes make a very simple minimal_gather_subset
    minimal_gather_subset = frozenset(['platform'])

    # mock up a AnsibleModule 'module'
    class FakeAnsibleModule():
        def __init__(self):
            return
        def params(self):
            '''return module params'''

# Generated at 2022-06-20 17:06:27.390507
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    ansible_facts is the only function that is called by get_all_facts(), so test only
    ansible_facts.  This is more complicated than it needs to be, but ansible_facts()
    is not tested in its own right, so testing ansible_facts() via get_all_facts()
    simplifies things.
    '''

    # pylint: disable=too-many-locals, import-error
    try:
        from ansible.module_utils.facts import module_utils_facts
        from ansible.module_utils._text import to_bytes
    except ImportError:
        # prior to ansible 2.4, the functions we need were in the main module_utils module
        from ansible.module_utils import module_utils as module_utils_facts

# Generated at 2022-06-20 17:06:35.045472
# Unit test for function ansible_facts
def test_ansible_facts():
    module = None

    gather_subset = ['!all', 'network']

    # import module_utils.basic only if necessary to avoid circular imports in
    # ansible.module_utils
    try:
        import ansible.module_utils.basic
    except ImportError:
        pass
    else:
        module = ansible.module_utils.basic.AnsibleModule(argument_spec={'gather_subset': gather_subset})

    if module is None:
        from ansible.module_utils.facts import basic
        module = basic.AnsibleModule(argument_spec={'gather_subset': gather_subset})

    facts = ansible_facts(module, gather_subset=gather_subset)
    assert facts

# Generated at 2022-06-20 17:06:44.556779
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(AnsibleModule):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    module = TestModule()
    all_facts = get_all_facts(module)
    assert set(all_facts.keys()) == {'default_ipv4', 'distribution', 'distribution_version', 'ipv4', 'ipv6',
                                     'kernel', 'os_family', 'path', 'pkg_mgr'}

