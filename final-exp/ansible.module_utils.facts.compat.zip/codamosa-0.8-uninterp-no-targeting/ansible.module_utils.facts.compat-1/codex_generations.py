

# Generated at 2022-06-20 16:56:58.599819
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        import ansible
    except ImportError:
        raise AssertionError("Unable to import ansible")

    if not hasattr(ansible, 'module_utils'):
        raise AssertionError("Unable to access module_utils")

    if not hasattr(ansible.module_utils, 'facts'):
        raise AssertionError("Unable to access ansible.module_utils.facts")

    if not hasattr(ansible.module_utils.facts, 'namespace'):
        raise AssertionError("Unable to access ansible.module_utils.facts.namespace")

    # make mock module
    from ansible.module_utils.facts import module
    mod = module.AnsibleModule(argument_spec={})

# Generated at 2022-06-20 16:57:07.356999
# Unit test for function get_all_facts
def test_get_all_facts():
    def mock_module(params):
        return type('AnsibleModule', (), params)

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    params = dict(gather_subset=['all'], gather_timeout=10)
    module = mock_module(params)

    try:
        get_all_facts(module)
    except AnsibleExitJson:
        pass
    except AnsibleFailJson:
        pass

# Generated at 2022-06-20 16:57:15.564258
# Unit test for function get_all_facts
def test_get_all_facts():
    import collections
    import pytest

    class AnsibleModuleFake:
        def __init__(self, gather_subset_param):
            self.params = collections.MutableMapping(gather_subset=gather_subset_param)

    # Gather_subset as a list and a string should work
    f = AnsibleModuleFake(gather_subset_param=['all'])
    assert get_all_facts(module=f) == ansible_facts(f)

    f = AnsibleModuleFake(gather_subset_param=['dummy'])
    assert get_all_facts(module=f) == ansible_facts(f)

    f = AnsibleModuleFake(gather_subset_param=['all', 'dummy'])

# Generated at 2022-06-20 16:57:17.146706
# Unit test for function get_all_facts
def test_get_all_facts():
    #  after this we should have a get_all_facts function that we can use in any module's code
    assert get_all_facts

# Generated at 2022-06-20 16:57:23.969366
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({}, supports_check_mode=False)
    facts = ansible_facts(module, gather_subset=['!all'])
    assert facts['dns'] == {}  # Via AnsibleModule.fail_json


# Generated at 2022-06-20 16:57:30.338742
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=None),
        ),
    )
    facts_dict = get_all_facts(module)
    assert 'system' in facts_dict
    assert 'distribution' in facts_dict
    assert 'distribution_version' in facts_dict
    assert 'ipv4' in facts_dict
    assert 'fips' in facts_dict
    assert 'selinux' in facts_dict



# Generated at 2022-06-20 16:57:42.923508
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils._text import to_bytes

    class AnsibleModule:
        params = {'gather_subset': None}

    # Mock module
    module = AnsibleModule()

    # Call the get_all_facts
    fact_dict = get_all_facts(module)

    # Test if all the facts are present
    assert type(fact_dict['local']) == dict
    assert type(fact_dict['local']['lsb']) == dict
    assert type(fact_dict['local']['lsb']['distrib_id']) == str

# Generated at 2022-06-20 16:57:51.064838
# Unit test for function get_all_facts
def test_get_all_facts():
    '''unit test for get_all_facts legacy compat'''

    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule(object):
        '''fake ansible module class to simulate the one that ansible uses'''

        def __init__(self, gather_subset):
            '''init the class'''

            self.params = {}
            self.params['gather_subset'] = gather_subset

    test_fact_collector = BaseFactCollector()
    test_fact_collector.add_fact('foo', 'bar')
    test_fact_collector.add_fact('warble', 'blarg')

    module = FakeModule(['foo'])
    result = get_all_facts(module)
    assert result == {'foo': 'bar'}

    module

# Generated at 2022-06-20 16:57:55.914107
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)
    # test with default gather subset ('all')
    assert(get_all_facts(FakeModule(None)) == get_all_facts(FakeModule([])))
    # test with 'hardware' gather subset
    assert(get_all_facts(FakeModule(['hardware'])) == ansible_facts(FakeModule(['hardware'])))

# Generated at 2022-06-20 16:57:58.885763
# Unit test for function get_all_facts
def test_get_all_facts():
    class AnsibleModule(object):
        def __init__(self, params):
            self.params = params

    params = dict(
        gather_subset='!all'
    )

    module = AnsibleModule(params)

    facts = get_all_facts(AnsibleModule(params))
    assert isinstance(facts['distribution'], str)

# Generated at 2022-06-20 16:58:12.082427
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''
    class FakeModule:
        '''For testing'''
        def __init__(self):
            self.params = {'gather_subset': ['all'],
                           'gather_timeout': 10,
                           'filter': '*'}
    module = FakeModule()
    # add in a fake file to the facts module
    class FakeCollector:
        '''For testing'''
        def __init__(self):
            self.plugin_name = 'fake_collector'

        def collect(self, module, collected_facts=None):
            '''For Testing'''
            collected_facts = {'fake_fact': 'fake_fact_value'}
            return collected_facts

    # add in a fake collector module to the facts module
    import ansible

# Generated at 2022-06-20 16:58:20.379345
# Unit test for function get_all_facts
def test_get_all_facts():
    def guess_os_family(distribution, platform):
        if os.path.isfile(os.path.join('/usr', 'bin', 'apt-get')):
            return 'Debian'
        if os.path.isfile(os.path.join('/usr', 'bin', 'yum')):
            return 'RedHat'
        if os.path.isfile(os.path.join('/etc', 'SuSE-release')):
            return 'SUSE'

        return 'Unknown'

    from ansible.module_utils.facts import ansible_facts
    facts = ansible_facts(dict(), ['all'])
    os_family = guess_os_family(facts['distribution'], facts['platform'])

# Generated at 2022-06-20 16:58:33.445081
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import module_proto
    from ansible.module_utils.facts.utils import get_collector_for
    import pprint

    class MockModule(object):
        def __init__(self):
            self.params = {u'gather_subset': [u'all']}

        def fail_json(self, msg):
            print('FAILED: ' + msg)
            raise ValueError(msg)

    module = MockModule()

    test_facts = ansible_facts(module)
    assert isinstance(test_facts, dict)

    test_fact_collector = get_collector_for(module_proto, 'ansible')

    collector_result = test_fact_collector.collect(module=module)
    assert isinstance(collector_result, dict)



# Generated at 2022-06-20 16:58:38.275171
# Unit test for function get_all_facts
def test_get_all_facts():
    '''There is no useful way to unit-test this method, because it always returns the same
     value.  For example, you cannot update 'ansible_os_family' on the fly in a unit test. '''
    pass

# Generated at 2022-06-20 16:58:48.112145
# Unit test for function ansible_facts
def test_ansible_facts():
    # WIP, this is a very simple test.
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector.network import NetworkCollector

    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    all_collector_classes = default_collectors.collectors
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')



# Generated at 2022-06-20 16:58:54.213050
# Unit test for function get_all_facts
def test_get_all_facts():

    # Define a mock module with a few valid subset
    class AnsibleModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset' : gather_subset}

    # Create a module with a specific subset of facts to gather
    modules = [
        AnsibleModule(['min', 'hardware']),
        AnsibleModule(['network', 'virtual']),
        AnsibleModule(['all']),
        AnsibleModule(['min'])
    ]

    for module in modules:

        # Gather the module specific facts
        facts = get_all_facts(module)

        # Check if a subset of facts is present
        fact_subelement = 0

# Generated at 2022-06-20 16:59:05.901342
# Unit test for function get_all_facts
def test_get_all_facts():
    ''' Unit test for function get_all_facts '''
    from ansible.module_utils.facts import get_all_facts

    # Mock for AnsibleModule object
    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {'gather_subset': 'all'}

    my_module = AnsibleModuleMock()

    facts_dict = get_all_facts(my_module)
    assert 'environment' in facts_dict
    assert 'lsb' in facts_dict
    assert 'timezone' in facts_dict
    assert 'distribution' in facts_dict
    assert 'python' in facts_dict
    assert 'system' in facts_dict
    assert 'locale' in facts_dict
    assert 'fips' in facts_dict

# Generated at 2022-06-20 16:59:17.862627
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.alpine
    import ansible.module_utils.facts.system.distribution.amazon
    import ansible.module_utils.facts.system.distribution.arch
    import ansible.module_utils.facts.system.distribution.debian
    import ansible.module_utils.facts.system.distribution.fedora
    import ansible.module_utils.facts.system.distribution.gentoo
    import ansible.module_utils.facts.system.distribution.mandriva
    import ansible.module_utils.facts.system.distribution.nixos
    import ansible.module_utils.facts.system.distribution.oracle

# Generated at 2022-06-20 16:59:26.371335
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    import json

    fake_module = AnsibleModule(argument_spec={})
    facts = get_all_facts(fake_module)
    assert 'default_ipv4' in facts
    assert json.dumps(facts['default_ipv4']) == '{"address": "192.168.1.1", "alias": "eth0", "gateway": "192.168.1.254"}'

# Generated at 2022-06-20 16:59:38.589268
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest
    # pylint: disable=import-error
    from ansible.module_utils.facts import ansible_facts
    # pylint: disable=import-error
    from ansible.module_utils.facts.collector import BaseFactCollector
    # pylint: disable=import-error
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeAnsibleModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    class FakeFactCollector(BaseFactCollector):
        @classmethod
        def get_collector_name(cls):
            return 'testcollector'


# Generated at 2022-06-20 16:59:52.869426
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Unit test for get_all_facts
    '''
    # (pylint: disable=R0903)

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_text

    class MockAnsibleModule:
        # pylint: disable=too-few-public-methods
        '''Mock for AnsibleModule'''
        def __init__(self, params):
            self.params = params
            self.fail_json = fail_json
            self._result = dict()

        def exit_json(self, **kwargs):
            # pylint: disable=unused-argument
            self._result.update(**kwargs)


# Generated at 2022-06-20 17:00:03.968599
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import cache
    from . import test_collection
    import tempfile

# Generated at 2022-06-20 17:00:06.342227
# Unit test for function get_all_facts
def test_get_all_facts():
    # For now just make sure it exists.
    # TODO: implement unit test.
    pass


# Generated at 2022-06-20 17:00:15.211032
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    dummy_module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'])})
    actual_result = get_all_facts(dummy_module)
    expected_result = ansible_facts(dummy_module, gather_subset=['!all'])
    assert actual_result == expected_result

# Generated at 2022-06-20 17:00:22.308173
# Unit test for function get_all_facts
def test_get_all_facts():
    import pytest
    import os.path
    local_working_path = os.getcwd()
    data_basedir = os.path.join(local_working_path, "test/unittests/testdata/ansible_facts")
    test_file_path = os.path.join(data_basedir, "test-facts.json")
    with open(test_file_path, "rb") as f:
        test_facts = json.load(f)
        module = AnsibleModule(argument_spec={
            'filter': {'type': 'str', 'default': '*'},
            'gather_subset': {'default': ['all']},
            'gather_timeout': {'type': 'int', 'default': 10},
        })

        # Override load_platform_subclass() to avoid it

# Generated at 2022-06-20 17:00:26.074506
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # TODO: Actually test something here, this will just run the code and make sure it doesn't crash
    get_all_facts(module)

# Generated at 2022-06-20 17:00:36.184079
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.test.test_all import TestAllFacts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    m_module = TestAllFacts()
    m_module.params['gather_subset'] = ['all']

    ansible_facts = get_all_facts(m_module)

    assert isinstance(ansible_facts, dict)
    assert 'default_ipv4' in ansible_facts
    assert ansible_facts['default_ipv4']['address'] == '10.0.0.1'

# Generated at 2022-06-20 17:00:47.236692
# Unit test for function ansible_facts
def test_ansible_facts():
    # There's no easy way to unit test this function,  it requires an instance of an ansible module.
    # So we just confirm that this compiles and runs without errors.
    class MockAnsibleModule():

        def __init__(self):
            self.params = dict(filter='ansible_architecture', gather_subset=['hardware'],)

    module = MockAnsibleModule()
    facts = ansible_facts(module)
    assert isinstance(facts, dict)
    assert len(facts) == 1
    assert set(facts.keys()) == set(['architecture'])



# Generated at 2022-06-20 17:00:53.115823
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.facts import ansible_collector
    testers = {'a_module': dict(method='get_all_facts')}
    get_all_facts(testers)
    assert testers['a_module']['method'] == 'ansible_facts'

# Generated at 2022-06-20 17:01:04.375484
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit tests for ansible_facts function'''
    from ansible.module_utils._text import to_bytes

    class MockAnsibleModule:
        '''Mock class for AnsibleModule'''

        def __init__(self, params, test_config_file_data=None):
            self.params = params

        def get_bin_path(self, module_name, required=False, opt_dirs=None):
            return module_name

        def read_config_file(self):
            # Return data from test config file
            return self.test_config_file_data

        def fail_json(self, **kwargs):
            '''mock failure method'''
            raise RuntimeError(repr(kwargs))


# Generated at 2022-06-20 17:01:23.980317
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils._text as text
    PATH_INFO = {'ansible_module_flags': 'skippret=true'}

    class FakeAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs.get('params', {})
            self.path = kwargs.get('path', PATH_INFO)

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

    # test ansible_facts calling get_all_facts

# Generated at 2022-06-20 17:01:32.723842
# Unit test for function get_all_facts
def test_get_all_facts():
    '''does the get_all_facts function work as expected?'''
    from ansible.module_utils.six import PY3
    if PY3:
        from unittest import mock
    else:
        import mock

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # Setup an AnsibleModule instance
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 17:01:40.732053
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.modules.system import setup
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts

    assert get_all_facts == ansible_facts

    # get_all_facts and ansible_facts returns dicts that look like:
    #  {'ipv4': {u'ip_addresses': [u'fe80::f816:3eff:fe20:57c5', u'192.168.56.10']},
    #   'default_ipv4': {u'address': u'192.168.56.10', u'alias': u'enp0s8', u'mask': u'255.255.255.0', u'macaddress': u'08:16:3e:20:57:c5', u

# Generated at 2022-06-20 17:01:44.833852
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(default=['all'], type='list'),
        filter=dict(default='*', type='str'),
    ))

    retval = get_all_facts(module=module)
    assert isinstance(retval, dict)

# Generated at 2022-06-20 17:01:57.787502
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    # Using the DistributionFactCollector as a simplified example
    class DummyAnsibleModule:
        '''A class that pretends to be an AnsibleModule'''
        def __init__(self, gather_subset=None, gather_timeout=None, filter=None):
            self.params = {
                'gather_subset': gather_subset,
                'gather_timeout': gather_timeout,
                'filter': filter,
            }
        def exit_json(self, **results):
            '''Just make a note of the results'''
            self.results = results

    class CollectedDummyDistributionFactCollector(DistributionFactCollector):
        '''A DistributionFactCollector that records the call args of collect()'''

# Generated at 2022-06-20 17:02:07.711459
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    test_collectors = default_collectors.collectors

    # don't add a prefix
    test_namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    test_filter_spec='*'
    test_gather_subset=['all']
    test_gather_timeout=1
    test_minimal_gather_subset=frozenset(['platform'])


# Generated at 2022-06-20 17:02:18.746170
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.network.base import NetworkCollector

    class FakeAnsibleModule(object):
        def __init__(self, params):
            self.params = params

    class FakeModule(object):
        def __init__(self, m_name, m_facts):
            self.name = m_name
            self.facts = m_facts
            self.exit_json = None
            self.fail_json = None
            self.run_command = None

    class FakeNetworkCollector(NetworkCollector):
        def collect(self, module):
            return {'ansible_default_ipv4': '192.168.1.1'}


# Generated at 2022-06-20 17:02:28.644665
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for get_all_facts'''

    DEFAULT_GATHER_SUBSET = frozenset(['all'])

    class FakeModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    # Test gather_subset=[]
    module = FakeModule(gather_subset=[])
    test_facts = get_all_facts(module)
    # test_facts should contain all the facts included in DEFAULT_GATHER_SUBSET
    for fact in test_facts:
        assert fact in DEFAULT_GATHER_SUBSET

# Generated at 2022-06-20 17:02:34.409442
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes

    import ansible.module_utils.facts.system.distribution as distribution

    # Test filtering out result of a single fact
    filter_spec = 'distribution.distro'
    output = ansible_facts(module=None,
                           gather_subset=None,
                           filter_spec=filter_spec)

    assert len(output) == 1
    assert 'distribution.distro' in output
    assert output['distribution.distro'] == distribution._get_distro()

    # Test for ansible_facts with gather_subset != all
    output = ansible_facts(module=None,
                           gather_subset=['selinux'])

    assert len(output) > 1
    assert 'distribution' in output
    assert output['distribution']

# Generated at 2022-06-20 17:02:43.345551
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.six import iteritems

    from ansible.module_utils.facts import local_collectors

    c = ansible_collector.AnsibleCollector()
    c.add_collector(namespace="python", collector=local_collectors.PythonFactCollector)

    class TestModule(object):
        '''
        Note this is not a real AnsibleModule class. It's just a pretend one,
        without the full functionality of AnsibleModule.
        '''


# Generated at 2022-06-20 17:03:07.944389
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Test the get_all_facts function.
    '''

    import ansible.module_utils.facts
    ansible.module_utils.facts.DEFAULT_GATHER_SUBSET = ['all']

    import ansible.module_utils.basic
    class FakeModule(object):
        def __init__(self):
            self.params = dict()

    fake_module = FakeModule()
    res = get_all_facts(fake_module)
    assert 'default_ipv4' in res

# Generated at 2022-06-20 17:03:17.625891
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_all_facts
    # for testing compat wrapper, we need to create a mock AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'gather_subset': {'type': 'list', 'default': ['all']}})

    facts_dict = ansible_facts(module=module)
    assert not facts_dict.get('ansible_facts')
    # TODO: test that the subset of facts matches the requested subset

# Generated at 2022-06-20 17:03:29.247335
# Unit test for function ansible_facts
def test_ansible_facts():
    '''ansible_facts should work with ansible 2.0-2.3'''

    from ansible.module_utils._text import to_text

    from ansible.modules.system import setup

    # Make a fake module with all the same parameters as the real thing
    module = setup.AnsibleModule(argument_spec=dict(
        gather_subset=dict(default=['!all'], type='list'),
        gather_timeout=dict(required=False, type='int', default=10),
        filter=dict(required=False, type='str'),
        # no_log=dict(default=False, type='bool'),
    ),
                                 supports_check_mode=True)

    gathered_facts = ansible_facts(module, gather_subset=['!all', 'min'])


# Generated at 2022-06-20 17:03:34.295675
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import unittest

    # paths to test modules
    current_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.join(current_dir, 'testdata')

    # we need to specify module_utils so it can import the module_utils.facts namespace
    module_utils_path = os.path.dirname(current_dir)
    module_utils_path = os.path.join(module_utils_path, 'module_utils')

    # do this in a subprocess so we don't contaminate the ansible module_utils.facts namespace
    import subprocess

# Generated at 2022-06-20 17:03:43.770977
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' this is a unit test for the ansible_facts method '''

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.ansible_collector import AnsibleDefaultFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        # Mocking up an AnsibleModule object.
        class params(object):
            # mock up the params object
            def __init__(self, gather_subset=None, gather_timeout=None,
                         filter_spec=None):
                self.gather_subset = gather_subset

# Generated at 2022-06-20 17:03:51.672009
# Unit test for function ansible_facts
def test_ansible_facts():
    import inspect
    import sys
    import re

    # Assert Python version is supported
    python_version = sys.version_info[:3]
    assert python_version >= (2, 7) or python_version >= (3, 5), 'Unsupported Version of Python'

    # Import dependent modules
    from ansible.module_utils import basic
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector


# Generated at 2022-06-20 17:04:01.239175
# Unit test for function ansible_facts
def test_ansible_facts():
    import unittest
    import mock
    from ansible.compat.tests.mock import patch

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = {'filter': '*',
                           'gather_timeout': 10
                          }
            for k in kwargs.keys():
                self.params[k] = kwargs[k]
        def get_option(self, name):
            return self.params.get(name)

    class MockFactCollector(object):
        def __init__(self, fact_namespace, filter_spec, gather_subset, gather_timeout):
            self.fact_namespace = fact_namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset

# Generated at 2022-06-20 17:04:10.833164
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        from ansible.module_utils.facts import ansible_collector
    except ImportError:
        ansible_collector = None

    if ansible_collector is None:
        # can't actually test this function, because it depends on a method
        # created by the AnsibleModule class metaclass.
        return

    from ansible.module_utils.facts import default_collectors

    # mock module APIs

# Generated at 2022-06-20 17:04:21.623307
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.compat import mock

    # apply some mocking magic to plugins.module_utils.facts.ansible_collector.get_ansible_collector
    # so that it returns a basic mock object instead of actually attempting to collect facts
    module = mock.MagicMock()
    module.params = dict(gather_subset=['all'])
    with mock.patch('ansible.module_utils.facts.ansible_collector.get_ansible_collector') as p:
        p.return_value = dict(lsb=dict(distdescription='foo'))

        # return value from get_all_facts should still be a dict keyed on bare fact names (no 'ansible_' namespace)
        facts = get_all_facts(module)
        assert isinstance(facts, dict)

# Generated at 2022-06-20 17:04:22.638308
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-20 17:04:57.931502
# Unit test for function ansible_facts
def test_ansible_facts():
    # deliberately do not use the mock module
    import os
    import sys
    import tempfile

    class AnsiModule:
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

        def get_bin_path(self, binary, required=False, opt_dirs=[]):
            return None

        def params(self):
            return {}

        def get_module_path(self):
            return None

    def get_module_path(self):
        return None

    test_spec = dict(gather_subset=dict(default=['all']),
                     gather_timeout=dict(default=10),
                     filter=dict(default='*'))


# Generated at 2022-06-20 17:05:05.990888
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.system import distribution

    class MockFactsModule(AnsibleModule):

        def __init__(self, *args, **kwargs):
            super(MockFactsModule, self).__init__(*args, **kwargs)
            self.params = {}

    class MockAnsibleFactCollector(ansible_collector.BaseFactCollector):

        NAME = 'test_ansible_facts'


# Generated at 2022-06-20 17:05:06.853005
# Unit test for function get_all_facts
def test_get_all_facts():
    pass

# Generated at 2022-06-20 17:05:15.248247
# Unit test for function get_all_facts
def test_get_all_facts():
    import os
    import sys
    import ansible.module_utils.facts.ansible_collector
    import ansible.module_utils.facts.cache
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    from ansible.module_utils._text import to_bytes

    class DummyModule():

        def __init__(self, params):
            self.params = params

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return '/bin/' + arg

    if sys.platform == 'win32':
        import ansible.module_utils.facts.windows.setup_facts

# Generated at 2022-06-20 17:05:26.306129
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import unittest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import get_all_facts
    if sys.version_info[0] < 3:
        set_type = set
    else:
        set_type = frozenset

    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['network', 'virtual']}

    class TestGetAllFacts(unittest.TestCase):
        def test_get_all_facts(self):
            result = get_all_facts(FakeModule())

            self.assertTrue(all(isinstance(fact, bytes) for fact in result.values()))

            # test a couple of facts

# Generated at 2022-06-20 17:05:36.657136
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import BaseFactCollectionModule

    class TestCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            pass

    class TestModule(BaseFactCollectionModule):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)
            self.params['gather_subset'] = ['test']


# Generated at 2022-06-20 17:05:44.195561
# Unit test for function get_all_facts
def test_get_all_facts():

    from mock import Mock

    class Param:
        def __init__(self, name, value=None):
            self.name = name
            self.value = value

    class Parameters:
        def __init__(self, params=[]):
            self.params = params
            self.get = self._get

        def _get(self, param):
            for p in self.params:
                if p.name == param:
                    return p.value
            return None

        def __getitem__(self, item):
            return self._get(item)

    class Module:
        def __init__(self, params=None, **kwargs):
            self.params = params

        def fail_json(self, *args):
            pass

    module = Module(params=Parameters([Param('gather_subset')]))

    facts

# Generated at 2022-06-20 17:05:55.092596
# Unit test for function get_all_facts
def test_get_all_facts():

    # Mock the module to return some gather_subset params
    class FakeModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    fake_module = FakeModule(['apparmor'])
    # For this mock module, our mocked ansible_facts should just
    # return the mock_data defined in our fake 'apparmor' collector.
    # so just verify that our ansible_facts returns that data.

# Generated at 2022-06-20 17:06:01.073507
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Test method get_all_facts
    '''
    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ["min"]

    fake_module = FakeModule()
    result = get_all_facts(fake_module)
    assert(len(result) > 0)
    assert(result['os_family'] == 'RedHat')

# Generated at 2022-06-20 17:06:11.002422
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}
    # test that gather_subset is passed through correctly
    gather_subset = frozenset(['!not_there'])
    module = MockModule(gather_subset=gather_subset)
    facts = get_all_facts(module=module)
    assert facts.keys() == ['ansible_distribution']

