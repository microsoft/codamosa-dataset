

# Generated at 2022-06-20 16:56:50.774645
# Unit test for function ansible_facts
def test_ansible_facts():
    # In ansible 2.0/2.1, gather_subset was not an arg to ansible_facts
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.six import PY2
    assert get_all_facts is ansible_facts

    # In ansible 2.2+ gather_subset is a required argument
    from ansible.module_utils.facts import ansible_facts as ansible_facts22
    from ansible.module_utils.facts import ansible_facts as ansible_facts23
    if PY2 and hasattr(ansible_facts22, '__self__'):
        ansible_facts22 = ansible_facts22.__self__.ansible_facts

# Generated at 2022-06-20 16:56:57.356252
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import FactsCollection
    # test that ansible_facts will return facts dict with a minimal set of facts
    # when given a minimal gather_subset
    class TestModule:
        def __init__(self):
            self.params = {'gather_subset': ['!all', '!virtual', '!nonsense']}

    assert sorted(ansible_facts(TestModule()).keys()) == sorted(FactsCollection().minimal_facts)

# Generated at 2022-06-20 16:57:09.688688
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import json
    import pytest

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts import default_collectors

    all_collector_classes = default_collectors.collectors

    # Most of the collector tests come from ansible.module_utils.facts.tests
    # This is a test of the new function 'ansible_facts', which adds the
    # 'ansible_' prefix

    class AnsibleModule:
        def __init__(self, params=None):
            self.params = params or {}
            for key, value in self.params.items():
                setattr(self, key, value)


# Generated at 2022-06-20 16:57:17.406783
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    sys.modules['ansible'] = object()
    sys.modules['ansible.module_utils.facts'] = object()
    sys.modules['ansible.module_utils.facts.default_collectors'] = default_collectors
    sys.modules['ansible.module_utils.facts.collector'] = ansible_collector

    from ansible.module_utils.facts.compat import get_all_facts
    from ansible.module_utils.facts.compat import ansible_facts

    def fake_ansible_module():
        return object()

    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'all', 'gather_timeout': 10}


# Generated at 2022-06-20 16:57:19.186179
# Unit test for function ansible_facts
def test_ansible_facts():
    # TODO: add unit tests
    pass

# Generated at 2022-06-20 16:57:26.467756
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system

    sys_collector = ansible.module_utils.facts.system.SystemCollector()

    class FakeModule(object):
        class FakeParams(object):
            gather_subset = ['all']

        def __init__(self):
            self.params = self.FakeParams()

        def fail_json(self, *args, **kwargs):
            pass

    m = FakeModule()
    test_dict = get_all_facts(m)
    assert type(test_dict) == dict
    assert 'ansible_hostname' in test_dict.keys

# Generated at 2022-06-20 16:57:32.986989
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.module_lldp as lldp
    # TODO: mock module to contain a 'gather_subset' param

    ansible_facts_dict = get_all_facts(module=lldp)

    expected_keys = {'distribution', 'distribution_version', 'fips', 'kernel', 'machine', 'machine_id', 'operating_system', 'os_family', 'processor', 'selinux',
                     'system', 'virtualization_role', 'virtualization_type'}  # These keys are expected to be in ansible_facts_dict, so if any of them are missing, an error is raised

    for key in expected_keys:
        assert key in ansible_facts_dict


# Generated at 2022-06-20 16:57:43.646381
# Unit test for function ansible_facts
def test_ansible_facts():
    import unittest
    import sys
    from ansible.module_utils.basic import AnsibleModule

    class AnsibleModuleForTest(unittest.TestCase):
        # Inherit everything from AnsibleModule except migrate_params_to_module
        # Implement migrate_params_to_module to return the params passed to it
        def __init__(self, *args, **kwargs):
            super(AnsibleModuleForTest, self).__init__(*args, **kwargs)
            self.exit_json = sys.exit
            self.fail_json = sys.exit

        def migrate_params_to_module(self, *args, **kwargs):
            return self.params

        def get_bin_path(self, *args, **kwargs):
            return "/bin"

    AM = AnsibleModuleForTest

    test

# Generated at 2022-06-20 16:57:49.653273
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        from ansible.module_utils.facts import ansible_collector
    except ImportError:
        pytest.skip('Test requires 2.3 facts module, which is not available.')

    class MockModule:
        def __init__(self, params):
            self.params = params

    MockModule.fail_json = lambda self, **kwargs: None

    module = MockModule({'gather_timeout': 10, 'filter': '*'})
    facts_dict = ansible_facts(module=module)
    assert 'distribution' in facts_dict
    assert 'distribution' not in facts_dict['ansible_facts']
    assert 'fqdn' in facts_dict
    assert 'fqdn' not in facts_dict['ansible_facts']
    assert 'ipv4' in facts_dict
   

# Generated at 2022-06-20 16:58:00.890988
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module_args_dict = dict(
        gather_subset='!all,!min',
        gather_timeout=10,
    )
    module_args_bytes = to_bytes(module_args_dict)
    test_module = AnsibleModule(argument_spec=dict(), bypass_checks=True, no_log=True)
    test_module.params = module_args_dict
    try:
        all_facts = ansible_facts(test_module)
    except Exception as err:
        all_facts = str(err)

    assert type(all_facts) is dict
    assert 'distribution' in all_facts

#

# Generated at 2022-06-20 16:58:12.750738
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import _get_all_facts
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import NoWhichException

    # create dummy ansible module
    try:
        # python2
        from collections import Mapping
        import mock
    except ImportError:
        # python3
        from collections.abc import Mapping
        from unittest import mock

    class AnsibleModule:

        def __init__(self, *args, **kwargs):
            self.params = {}
            self.exit_json = mock.Mock()


# Generated at 2022-06-20 16:58:24.013633
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    import ansible.module_utils.facts.collector.platform as platform_collector
    import ansible.module_utils.facts.collector.distribution as distribution_collector

    module = MockAnsibleModule()
    gather_subset = ['all']
    module.params = {'gather_subset': gather_subset}
    # mock the 'all' collectors
    all_collector_classes = {'distribution': distribution_collector.DistributionCollector,
                             'platform': platform_collector.PlatformFactCollector}

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    fact_

# Generated at 2022-06-20 16:58:34.676686
# Unit test for function get_all_facts
def test_get_all_facts():
    # Setup
    import json
    import os
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import NamespaceCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MyCollector(BaseFactCollector):
        name = 'mycollector'

        def collect(self, module=None, collected_facts=None):
            return {'fact_name1': 'fact_value1', 'fact_name2': 'fact_value2'}

    # This is the json string that should be produced by the collector object
    testdata_fixture_str = '{"fact_name1": "fact_value1", "fact_name2": "fact_value2"}'

    # Compose a NamespaceCollector object, with a

# Generated at 2022-06-20 16:58:43.004349
# Unit test for function get_all_facts
def test_get_all_facts():
    # If we don't have argspec, just call assert True
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    all_collector_classes = default_collectors.collectors
    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    import ansible.module_utils.facts.system.distribution as distribution

# Generated at 2022-06-20 16:58:51.410567
# Unit test for function get_all_facts
def test_get_all_facts():
    import mock
    from ansible.module_utils.facts import get_all_facts

    m = mock.Mock()
    m.params = {'gather_subset': 'all' }
    actual = get_all_facts(module=m)
    # not testing values, just testing keys and if we get any error
    assert 'ansible_all_ipv4_addresses' in actual



# Generated at 2022-06-20 16:59:03.958218
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ansible_collector
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    all_collector_classes= [MyFactCollector]
    gather_subset = ['all']
    filter_spec = 'foo'
    gather_timeout = 10

    # Try with a function instead of a class
    def foo_collector():
        pass
    all_collector_classes = [foo_collector]

# Generated at 2022-06-20 16:59:16.872955
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import ansible.utils
    import ansible.module_utils.facts
    import ansible.module_utils.facts.ansible_collector

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}
        def get_bin_path(self, binary, required=False, opt_dirs=[]):
            return os.getenv('PATH')

    module = AnsibleModuleMock()

    # Make sure we have the correct version of gather_subset defaults for Ansible 2.2 and 2.3
    if ansible_collector.__version__ in ('2.2', '2.3'):
        assert ansible_facts(module)['gather_subset'] == ['all']

    # Make sure we have the

# Generated at 2022-06-20 16:59:18.379470
# Unit test for function ansible_facts
def test_ansible_facts():
    x = ansible_facts(module, gather_subset=['!all', 'network'])
    assert isinstance(x, dict)
    x = ansible_facts(module, gather_subset=None)
    assert isinstance(x, dict)

# Generated at 2022-06-20 16:59:26.504548
# Unit test for function get_all_facts
def test_get_all_facts():

    class MockModule(object):
        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)

    mock_module = MockModule(gather_subset=['all', 'network'])

    facts_dict = get_all_facts(mock_module)
    assert hasattr(facts_dict, 'items')
    assert 'default_ipv4' in facts_dict.keys()

# Generated at 2022-06-20 16:59:34.096948
# Unit test for function ansible_facts
def test_ansible_facts():
    class MockModule:
        params = {
            'gather_subset': None,
            'gather_timeout': 10,
            'filter': '*',
        }

    all_facts = ansible_facts(MockModule)

    assert isinstance(all_facts, dict)
    assert len(all_facts.keys()) > 0

# Generated at 2022-06-20 16:59:43.306852
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # get the class names of all the collectors in the default_collectors module
    class_names = [cls.__name__ for cls in default_collectors.collectors]

    # create a dict mapping all the class names to True
    all_collector_classes = dict([(name, True) for name in class_names])

    # create a namespace prefix named 'ansible'
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='ansible_')

    # create an ansible_collector object

# Generated at 2022-06-20 16:59:53.398997
# Unit test for function get_all_facts
def test_get_all_facts():

    import unittest

    class FakeAnsibleModule(object):
        def __init__(self, param_dict):
            self.params = param_dict

    class FakeCollector(object):
        def __init__(self, name):
            self.name = name

        def collect(self, module):
            return {self.name: True}

    class FakeCollectorFactory(object):
        def __init__(self, name):
            self.name = name

        def __call__(self, *args, **kwargs):
            return FakeCollector(self.name)

    class AnsibleFactsTests(unittest.TestCase):

        def test_get_all_facts(self):
            ansible_module = FakeAnsibleModule({'gather_subset': ['all']})
            all_collector

# Generated at 2022-06-20 17:00:05.947954
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.ns_fact_subset import NsFactSubset
    from ansible.module_utils._text import to_bytes
    import os

    # Expected facts.  The facts are a subset of the facts for a minimal system
    # with ssh key data added for the unit test.

# Generated at 2022-06-20 17:00:18.794728
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils._text import to_bytes
    import six
    import sys

    class my_module():
        def __init__(self):
            self.params = {
                'gather_subset': ['all'],
            }

    class my_fact_collector(ansible_collector.BaseFactCollector):
        _fact_namespace = 'my_fact_namespace'
        _fact_class_names = ()

    class atom_fact_collector(ansible_collector.BaseFactCollector):
        _fact_namespace = 'atom_fact_namespace'


# Generated at 2022-06-20 17:00:30.290025
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list'),
                                          'gather_timeout': dict(type='int'),
                                          'filter': dict(type='list', default='*'),})

    facts = ansible_facts(module)
    assert 'distribution' in facts
    assert 'distribution_file_parsers' in facts
    assert 'distribution_major_version' in facts
    assert 'distribution_version' in facts
    assert 'python' in facts
    assert 'python_version' in facts
    assert 'cmdline' in facts
    assert 'pythonpath' in facts
    assert 'executable' in facts

# Generated at 2022-06-20 17:00:35.349654
# Unit test for function get_all_facts
def test_get_all_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default='all', choices=['all'])
        )
    )
    facts = get_all_facts(module)
    assert 'distribution' in facts


# Generated at 2022-06-20 17:00:42.203912
# Unit test for function get_all_facts
def test_get_all_facts():
    test_module = _AnsibleModuleMock()
    test_module.params['gather_subset'] = ['!all', 'network', 'virtual']
    facts = ansible_facts(test_module)
    assert facts['os_family'] == 'RedHat'
    assert facts['domain'] == 'novalocal'
    assert facts['ipv4'] == {'address': '1.2.3.4', 'netmask': '255.255.255.0', 'network': '1.2.3.0'}
    assert 'virtualization_type' in facts


# Generated at 2022-06-20 17:00:45.391868
# Unit test for function get_all_facts
def test_get_all_facts():
    module = ansible_module_mock('all')
    assert get_all_facts(module) == ansible_facts(module)


# Generated at 2022-06-20 17:00:55.586522
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts

    ansible_facts is just calling a fact collector method, so we don't mock anything.
    '''
    from ansible.module_utils import basic
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import is_executable

    try:
        from test.support import EnvironmentVarGuard
    except ImportError:
        from test.test_support import EnvironmentVarGuard

    try:
        from test.support import TempdirManager
    except ImportError:
        from test.test_support import TempdirManager

    try:
        from test.support import cpython_only
    except ImportError:
        from test.test_support import cpython_only


# Generated at 2022-06-20 17:01:06.192566
# Unit test for function get_all_facts
def test_get_all_facts():
    ''' test the get_all_facts function.
        This function uses the AnsibleModule class and is therefore tested indirectly
        along with the AnsibleModule class.
    '''

    # Import module_utils.ansible_facts.get_all_facts()
    from ansible.module_utils import facts as module_utils_facts

    # Import AnsibleModule class
    from ansible.module_utils.basic import AnsibleModule

    # Instantiate an AnsibleModule object.
    module = AnsibleModule(argument_spec={'gather_subset': {'type': 'list', 'default': ['!all']}})

    # Execute the get_all_facts api.
    facts = module_utils_facts.get_all_facts(module)

    # we are not checking for the facts themselves here.  get_all_facts has been


# Generated at 2022-06-20 17:01:26.009852
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.basic import AnsibleModule

    # gather_subset=all should return full set of facts.
    module = AnsibleModule({'gather_subset': 'all'})
    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert len(facts) > 0

    # verify the type of each value
    for k, v in iteritems(facts):
        assert isinstance(k, str)
        assert isinstance(v, (str, list, int, dict))

    # gather_subset=network should return dict of network facts.
    module = AnsibleModule({'gather_subset': 'network'})
    facts = get

# Generated at 2022-06-20 17:01:33.966019
# Unit test for function ansible_facts
def test_ansible_facts():

    import unittest2 as unittest

    class TestParams(object):
        '''
        Mock object to emulate a AnsibleModule params dict
        '''

        def __init__(self, params):
            self._params = params

        def __getitem__(self, item):
            return self._params[item]

        def __contains__(self, item):
            return item in self._params

        def get(self, item, default):
            return self._params.get(item, default)

    class TestModule(object):
        '''
        Mock object to emulate an AnsibleModule object
        '''

        def __init__(self, params):
            self.params = TestParams(params)

    from ansible.module_utils.facts import default_collectors

# Generated at 2022-06-20 17:01:41.058604
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector

    class FakeAnsibleModule:

        def __init__(self, params):
            self.params = params

    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'

    module = FakeAnsibleModule(params={'gather_subset': gather_subset,
                                       'gather_timeout': gather_timeout,
                                       'filter': filter_spec})


# Generated at 2022-06-20 17:01:51.209968
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic
    import os, tempfile
    (fd, path) = tempfile.mkstemp()
    os.close(fd)
    if os.path.exists(path):
        os.remove(path)
    assert not os.path.exists(path)
    m = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default='all', type='list'),
            filter=dict(default=None, type='str'),
        ),
        supports_check_mode=True,
    )
    m.params['gather_subset'] = ['all']
    results = get_all_facts(m)
    assert 'distribution' in results
    assert 'default_ipv4' in results
    assert 'ipv4' in results


# Generated at 2022-06-20 17:01:58.360044
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit tests for function ansible_facts

    Verifies 'gather_subset' parameter is respected

    Verifies 'filter' parameter is respected

    Verifies 'gather_timeout' parameter is passed to fact collection

    Verifies that an ansible_facts dict is returned
    '''

    #
    # Some minimal mocks
    #

    # these mock classes need to be a real classes, not an object
    # otherwise we get "TypeError: can't pickle __Proxy__ objects"
    class AnsibleModuleMock:
        '''mock the API of AnsibleModule'''
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

        # just need a basic comparison method

# Generated at 2022-06-20 17:02:07.950799
# Unit test for function get_all_facts
def test_get_all_facts():
    import unittest

    import json

    from ansible.module_utils.facts import facts_module

    class FakeModule():
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = '!all'

    class TestGetAllFacts(unittest.TestCase):
        def setUp(self):
            self.module = FakeModule()

        def test_get_all_facts(self):
            all_facts = get_all_facts(self.module)

# Generated at 2022-06-20 17:02:18.828177
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_all_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MyTestCollector(BaseFactCollector):
        name = 'my_test'
        _fact_ids = set(['a', 'b'])

        def collect(self, module=None, collected_facts=None):
            return dict(a=1, b=2)

    class MyCollector(BaseFactCollector):
        name = 'my_collector'
        _fact_ids = set(['a', 'b', 'c', 'd'])


# Generated at 2022-06-20 17:02:28.005808
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.facts import get_all_facts

    class MockModule:
        class params(dict):
            gather_subset = ['all']

    module = MockModule()

    with patch('ansible.module_utils.facts.ansible_facts') as mock_ansible_facts:
        mock_ansible_facts.return_value = {'a': 'foo'}
        facts_dict = get_all_facts(module)
    assert facts_dict == {'a': 'foo'}

# Generated at 2022-06-20 17:02:39.162946
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import fact_cache
    fact_cache.clear_facts()

    # This function is not avaiable in ansible 2.9+
    if ansible_facts.__doc__ != None:
        assert ansible_facts.__doc__ == get_all_facts.__doc__
    else:
        assert ansible_facts.__doc__ == None

    class AnsibleModule(object):
        def __init__(self, params=None):
            self.params = params or {}

    # Test only with subset of facts
    gather_subset = ['!all', 'network']
    ansible_module = AnsibleModule({'gather_subset': gather_subset})

# Generated at 2022-06-20 17:02:49.303576
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.test_dummy_module import DummyModule

    module = DummyModule(
        params=dict(gather_subset=['all'], gather_timeout=10)
    )

    facts = ansible_facts(module=module)

    assert facts['network'] == {'default_ipv4': {'address': '192.168.0.1', 'alias': 'em1', 'macaddress': '00:11:22:33:44:55', 'mtu': 1500, 'type': 'ether'}, 'default_ipv6': {'address': 'fe80::a00:27ff:fe00:1', 'alias': 'em1', 'mtu': 1500, 'type': 'ether'}, 'interfaces': ['em1']}

# Generated at 2022-06-20 17:03:17.894114
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    unit test for ansible_facts function
    '''
    from ansible.module_utils.facts import ansible_facts

    class FakeParams:
        def __init__(self, gather_subset=None, gather_timeout=None, minimal_gather_subset=None):
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.minimal_gather_subset = minimal_gather_subset

    class FakeModule:
        def __init__(self, params):
            self.params = params

    module = FakeModule(FakeParams(gather_subset=['all']))
    facts = ansible_facts(module)

    assert 'ansible_facts' in facts

# Generated at 2022-06-20 17:03:29.365655
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.ansible_collector import AnsibleCollector
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.platform as platform
    import ansible.module_utils.facts.system.selinux as selinux
    from ansible.module_utils.facts.utils import get_file_content

    # mock ansible module

# Generated at 2022-06-20 17:03:35.002458
# Unit test for function ansible_facts
def test_ansible_facts():
    # Fact collector returns a dict mapping fact name to value.
    # The value should be a dict, mapping one or more key/value pairs.
    # These tests expect a full dictionary to be returned.

    # import AnsibleModule to provide a compat module instance
    from ansible.module_utils.basic import AnsibleModule

    # create a fake AnsibleModule instance
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    # gather_subset is a required parameter.  AnsibleModule has no default for it.
    # So for compat purposes, supply one.
    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'

    # ansible_facts should return a dict, keyed by fact name
    facts_dict = ansible_facts(module, gather_subset)



# Generated at 2022-06-20 17:03:44.190794
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import tempfile
    import time
    import shutil
    import json

    from ansible.module_utils.facts.collector import BaseFactCollector

    # example json output from a real fact module

# Generated at 2022-06-20 17:03:49.351357
# Unit test for function get_all_facts
def test_get_all_facts():

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)

    fake_module = FakeModule(gather_subset=['kernel'])
    result = get_all_facts(fake_module)
    assert type(result) == dict
    assert 'kernel' in result
    print(result)



# Generated at 2022-06-20 17:03:56.379168
# Unit test for function ansible_facts
def test_ansible_facts():
    module = MockAnsibleModule()

    assert isinstance(ansible_facts(module), dict)
    assert isinstance(ansible_facts(module, ['all']), dict)
    assert isinstance(ansible_facts(module, ['network']), dict)
    assert isinstance(ansible_facts(module, ['fips']), dict)



# Generated at 2022-06-20 17:04:03.420491
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.distribution as distribution_collector
    test_inputs = [
        {'foo': 'bar'},
        {'ansible_foo': 'bar'},
        {'ansible_bar': 'foo'},
    ]
    expected_output = {'foo': 'bar', 'bar': 'foo'}
    actual_output = ansible_facts(test_inputs[0], gather_subset=['all'])
    for test_input in test_inputs[1:]:
        actual_output.update(ansible_facts(test_input, gather_subset=['all']))
    assert actual_output == expected_output
    # Test the case when a subset of the facts is desired

# Generated at 2022-06-20 17:04:11.391470
# Unit test for function get_all_facts
def test_get_all_facts():
    '''unit test for get_all_facts'''

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    all_collector_classes = default_collect

# Generated at 2022-06-20 17:04:21.875557
# Unit test for function get_all_facts
def test_get_all_facts():
    import unittest

    class TestAnsibleModule(object):
        class ModuleFailException(Exception):
            pass

        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            raise TestAnsibleModule.ModuleFailException(kwargs)

    class TestModule(unittest.TestCase):

        def test_get_all_facts(self):
            ansible_module = TestAnsibleModule()

            ansible_module.params = {
                'gather_subset': 'all'
            }

            facts = get_all_facts(ansible_module)

            self.assertIsNot(facts, None)

            self.assertIsInstance(facts, dict)


# Generated at 2022-06-20 17:04:30.740966
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.system.distribution as distribution_collector
    import ansible.module_utils.facts.system.platform as platform_collector
    import ansible.module_utils.facts.system.lsb as lsb_collector

    ansible_distribution = distribution_collector.DistributionCollector()
    ansible_platform = platform_collector.PlatformFactCollector()
    ansible_lsb = lsb_collector.LsbFactCollector()

    # Mock AnsibleModule from Ansible 2.3 and 2.4
    class AnsibleModule23and24(object):
        def __init__(self, params):
            self.params = params

    # Mock AnsibleModule from Ansible 2.0 and 2.1

# Generated at 2022-06-20 17:05:12.287456
# Unit test for function get_all_facts
def test_get_all_facts():
    '''This is a unit test to make sure that get_all_facts properly calls
    ansible_facts with the appropriate arguments.  ansible_facts is the
    new-style facts collection method introduced in Ansible 2.3.
    '''

    # We'll use AnsibleModule to provide an appropriate mock module object.
    from ansible.module_utils.basic import AnsibleModule

    # Module parameters for this mock AnsibleModule object
    module_args = {
        'gather_subset': '!all',
        'gather_timeout': 10
    }

    # Create a mock AnsibleModule object to serve as our test subject
    module = AnsibleModule(argument_spec=module_args)

    # Define a set of facts appropriate for the gather_subset we're testing
    # (so we can compare the result of our call to get

# Generated at 2022-06-20 17:05:16.695386
# Unit test for function get_all_facts
def test_get_all_facts():
    real_ansible_module = ansible_module.AnsibleModule
    try:
        ansible_module.AnsibleModule = FakeAnsibleModule
        fake_module = ansible_module.AnsibleModule(argument_spec=dict(
            gather_subset=dict(type='list', default=['all']),
            gather_timeout=dict(type='int', default=10),
            filter=dict(default='*', type='str'),
        ))
        all_facts = get_all_facts(fake_module)
        assert isinstance(all_facts, dict)
    finally:
        ansible_module.AnsibleModule = real_ansible_module

# Generated at 2022-06-20 17:05:23.112610
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.compat.tests.mock import patch
    # pretend we have a module object
    module = mock.Mock()
    module.params = {'gather_subset': ['all']}
    all_facts = get_all_facts(module)
    assert isinstance(all_facts, dict)


# Generated at 2022-06-20 17:05:31.756758
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.utils.module_docs as md

    basic_module_spec = {'argument_spec': {'filter': {'type': 'list', 'required': False},
                                           'gather_subset': {'type': 'list', 'required': False}},
                         'supports_check_mode': True}

    basic_module_kwargs = {'argument_spec': basic_module_spec['argument_spec'], 'check_invalid_arguments': False,
                           'supports_check_mode': basic_module_spec['supports_check_mode']}

    basic_module_path = md.get_docstring_module_info(basic_module_spec, basic_module_kwargs)

    m = AnsibleModule(**basic_module_kwargs)

    # Should give just the default facts
   

# Generated at 2022-06-20 17:05:40.927399
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests import unittest

    class FakeModule(AnsibleModule):

        def __init__(self, gather_subset=None, gather_timeout=None, filter=None):
            self.params = {}
            if gather_subset:
                self.params['gather_subset'] = gather_subset

# Generated at 2022-06-20 17:05:53.265273
# Unit test for function ansible_facts
def test_ansible_facts():
    # This unit test can be run standalone
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all']),
                                          'filter': dict(type='str', default='*'),
                                          'gather_timeout': dict(type='int', default=10),
                                          'src': dict(type='str')},
                           supports_check_mode=True)

    actual_facts = ansible_facts(module)

    # Verify that the facts had been collected.
    #
    # input validation
    assert 'ansible_facts' in actual_facts
    assert 'ansible_all_ipv4_addresses' in actual_facts['ansible_facts']

    # Make sure that all the facts were collected via namespaces

# Generated at 2022-06-20 17:05:55.245843
# Unit test for function ansible_facts
def test_ansible_facts():
    from test.unit.module_utils import AnsibleModuleMock

    for module_utils_param in [dict(gather_subset=None), dict()]:
        module = AnsibleModuleMock(module_utils_params=module_utils_param)
        facts_dict = ansible_facts(module)

        assert facts_dict['distribution'] == 'unknown'

# Generated at 2022-06-20 17:05:58.209859
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    facts = get_all_facts(FakeModule(['dummy']))
    assert 'dummy' in facts

# Generated at 2022-06-20 17:06:04.766352
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.utils import get_file_content

    module_path = 'ansible.module_utils.facts.test.test_ansible_facts.module'
    module = __import__(module_path, globals(), locals(), ['AnsibleModule'], 0)
    test_module = module.AnsibleModule()

    assert get_all_facts(test_module) == ansible_facts(test_module)

    # test filtering
    result_raw = ansible_facts(test_module, filter_spec='ansible_architecture')
    assert result_raw == {'architecture': 'x86_64'}

    # test excluded fact
   

# Generated at 2022-06-20 17:06:16.735565
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import FACT_CACHE
    from ansible.module_utils._text import to_bytes
    # load all plugin facts from the default paths
    from ansible.module_utils.facts.default_collectors import PluginCollector
    from ansible.plugins.cache import FactCache
    from ansible.plugins.loader import add_all_plugin_dirs

    # setup a fake module object
    MODULE_NAME = 'nxos'
    MODULE_ARGS = {}
    DATA = {'ansible_facts': {}}

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.fail_json = lambda msg: msg

        def exit_json(self, **kwargs):
            pass
