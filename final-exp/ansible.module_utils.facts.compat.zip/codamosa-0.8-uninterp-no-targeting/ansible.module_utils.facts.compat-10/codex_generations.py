

# Generated at 2022-06-20 16:56:48.903426
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import os
    import pprint
    import unittest
    # Insert ansible source directory at front of sys path, so we load the correct versions
    # of modules rather than those already in the system path, which might be an older version.
    ansible_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    if ansible_path not in sys.path:
        sys.path.insert(0, ansible_path)

    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors, ansible_collector
    from ansible.module_utils.facts.timeout import TimedOutError

# Generated at 2022-06-20 16:56:54.163063
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import module_utils
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    module_utils.INTERNAL_DATA = dict()
    ansible_collector._ANSIBLE_COLLECTOR = None

    assert module_utils.INTERNAL_DATA == dict()
    assert ansible_collector._ANSIBLE_COLLECTOR is None

    data_file = 'ansible/module_utils/facts/ansible_facts.json'
    with open(data_file, 'r') as f:
        data = f.read()

    mock_params = dict(gather_timeout=10,
                       gather_subset=['all'])

    mock_module = dict(params=mock_params)


# Generated at 2022-06-20 16:56:59.296923
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=[]),
            gather_timeout=dict(type='int', default=10),
            filter=dict(type='str', default='*'))
    )

    all_facts = get_all_facts(module)

    print(all_facts)

    print('SUCCESS')



# Generated at 2022-06-20 16:57:11.018167
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    import json

    gather_subset = ['all']
    gatherer_classes = default_collectors.collectors

    module = basic.AnsibleModule(argument_spec={'gather_subset': {'type': 'list', 'default': gather_subset}},
                                 supports_check_mode=True)

    all_the_facts = ansible_facts(module, gather_subset=gather_subset)

    assert 'ansible_all_ipv4_addresses' in all_the_facts
    assert 'ansible_all_ipv6_addresses' in all_the_facts

# Generated at 2022-06-20 16:57:18.174326
# Unit test for function ansible_facts
def test_ansible_facts():
    '''ansible_facts returns the same data structure as
    ansible.module_utils.facts.get_all_facts'''
    try:
        from ansible.module_utils.facts import get_all_facts
    except ImportError:
        return

    class DummyModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

        def exit_json(self, **kwargs):
            pass

        def fail_json(self, **kwargs):
            pass

    original_facts = get_all_facts(DummyModule())
    my_facts = ansible_facts(DummyModule())

    assert my_facts.keys() == original_facts.keys()
    assert my_facts == original_facts


# Generated at 2022-06-20 16:57:29.856486
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.system import LinuxDistribution
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.fan import Fan
    from ansible.module_utils.facts.local_link_connection import LocalLinkConnection
    from ansible.module_utils.facts.pci import Pci
    from ansible.module_utils.facts.processor import Processor
    from ansible.module_utils.facts.switch_physical import SwitchPhysical
    from ansible.module_utils.facts.system import System
    from ansible.module_utils.facts.thermal import Thermal

    # Mock ansible module

# Generated at 2022-06-20 16:57:42.760648
# Unit test for function ansible_facts
def test_ansible_facts():
    '''mock test for ansible_facts'''

    import os
    import sys
    import unittest

    import ansible.module_utils.facts.namespace_factory as namespace_factory

    # require_ansible_omit is True, so omit ansible_facts
    # can't mock require_ansible_omit=True, so don't set require_ansible_omit=True
    # and skip test

    # patch out init_module_params as we don't need it

# Generated at 2022-06-20 16:57:50.979638
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.namespace as ansible_module_utils_facts_namespace

    class AnsibleModuleFake:
        def __init__(self, params):
            self.params = params

    class FakeCollector(ansible_module_utils_facts_namespace.BaseFactNamespace):
        namespace = 'ansible_fake'
        namespace_prefix = 'ansible_fake'

        def collect(self, module, collected_facts=None):
            return {}

    class AnsibleFactCollectorFake:
        def __init__(self):
            pass


# Generated at 2022-06-20 16:57:58.106232
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    from ansible import constants as C
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(required=False, type='list', default=None),
            gather_timeout=dict(required=False, type='int', default=C.DEFAULT_GATHER_TIMEOUT),
            filter=dict(required=False, type='str', default='*'),
        ),
        supports_check_mode=False,
    )

    gather_subset = ['!all']
    gather_timeout = 5
    filter_spec = '!*'

# Generated at 2022-06-20 16:58:08.510080
# Unit test for function ansible_facts
def test_ansible_facts():

    # Create a mock ansible module object
    class Parameters(object):
        gather_subset = ['all']
        filter = '*'
    module = type('Foo', (object,), dict(params=Parameters()))

    # Get the facts
    facts = ansible_facts(module=module)

    # Check for the 'ansible' namespace
    assert 'ansible' in facts

    # Check for the expected fact - 'architecture'
    assert 'architecture' in facts['ansible']

# Generated at 2022-06-20 16:58:15.277590
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    assert get_all_facts == ansible_facts

# Generated at 2022-06-20 16:58:25.072323
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import get_network_primary_ip

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, *args, **kwargs):
            raise Exception('fail_json called')

    class FakeFactsCollector(object):
        '''mocks ansible.module_utils.facts.FactsCollector'''
        def __init__(self, namespace, filter_spec=None, gather_subset=None, gather_timeout=10, minimal_gather_subset=None):
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.minimal_gather_

# Generated at 2022-06-20 16:58:30.775137
# Unit test for function ansible_facts
def test_ansible_facts():
    display.info('BEGIN TESTS FOR ANSIBLE_FACTS')
    display.info('STUBBED OUT UNIT TESTS.  NO ACTUAL CODE YET')
    display.info('END TESTS FOR ANSIBLE_FACTS')
# END test_ansible_facts

# Generated at 2022-06-20 16:58:39.312437
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'filter': dict(type='str', default='*')})

    facts_dict = ansible_facts(module)

    assert facts_dict['ansible_facts']['distribution'] in ['ubuntu', 'redhat']
    assert 'ansible_' not in facts_dict['ansible_facts'].keys()

# Generated at 2022-06-20 16:58:45.511092
# Unit test for function get_all_facts
def test_get_all_facts():
    import json
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    module = mock.MagicMock()
    module.params = {'gather_subset': 'all'}

    ansible_facts_dict = get_all_facts(module)
    assert 'ansible_architecture' in ansible_facts_dict
    assert 'ansible_all_ipv4_addresses' in ansible_facts_dict



# Generated at 2022-06-20 16:58:58.133570
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.all import AllFactCollector

    # mock module
    # module.params is a dict mapping param name to param value
    # module.params['gather_subset'] should be a list of fact subsets - we're only testing 'all'
    class MockAllModule(object):
        def __init__(self):
            self.params = dict(gather_subset=['all'])

    module = MockAllModule()

    # mock all collector
    class MockAllCollector(AllFactCollector):
        def __init__(self):
            super(MockAllCollector, self).__init__()
            # mock facts

# Generated at 2022-06-20 16:59:05.716289
# Unit test for function ansible_facts
def test_ansible_facts():
    import mock
    import sys
    import yaml

    # AnsibleModule class is not defined for Python3
    if sys.version_info[0] < 3:
        class AnsibleModule:
            def __init__(self, params):
                self.params = params

        mock_module = AnsibleModule

        module = mock_module(dict(
            gather_subset=['network']
        ))

        assert isinstance(module, mock_module)

        facts = ansible_facts(module, gather_subset=[])
        print(yaml.dump(facts))

# Generated at 2022-06-20 16:59:17.814009
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.network.bond import BondCollector
    from ansible.module_utils.facts.network.interfaces import InterfacesCollector
    from ansible.module_utils.facts.system.distribution import DistributionCollector
    from ansible.module_utils.facts.system.install_date import InstallDateCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.system.platform import PlatformCollector

# Generated at 2022-06-20 16:59:29.398522
# Unit test for function ansible_facts
def test_ansible_facts():
    class MockModule(object):
        def __init__(self, param1):
            self.params = {'filter': 'foo',
                           'gather_timeout': 1,
                           'gather_subset': ['!all', 'network', 'virtual']}

    module = MockModule('bar')
    # Test defaults
    assert ansible_facts(module) == ansible_facts(module, gather_subset=None)

    # Test gather_subset
    gather_subset = module.params['gather_subset']

    # Test filter
    filter_spec = module.params['filter']

    # Test gather_timeout
    gather_timeout = module.params['gather_timeout']

    # Test minimal_gather_subset

# Generated at 2022-06-20 16:59:36.249439
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual

    module = MockAnsibleModule()
    all_fact_classes = (ansible.module_utils.facts.collector.Collector,
                        ansible.module_utils.facts.hardware.Hardware,
                        ansible.module_utils.facts.network.Network,
                        ansible.module_utils.facts.system.System,
                        ansible.module_utils.facts.virtual.Virtual
                        )

    # all facts should have been collected
    expected_gather_subset = ['all']

    all_facts_expected_dict = {}

# Generated at 2022-06-20 16:59:48.844191
# Unit test for function get_all_facts
def test_get_all_facts():

    # imports for side effects (registering collectors)
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform

    import ansible.module_utils.facts.virtual.virtualbox
    import ansible.module_utils.facts.virtual.kvm
    import ansible.module_utils.facts.virtual.openvz
    import ansible.module_utils.facts.virtual.xen
    import ansible.module_utils.facts.virtual.zvm

    import ansible.module_utils.facts.hardware.cpu
    import ansible.module_utils.facts.hardware.dmi
    import ansible.module_utils.facts.hardware.lspci
    import ansible.module_utils.facts.hardware.system_profiler


# Generated at 2022-06-20 16:59:56.621375
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.selinux import SELinuxFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector
    from ansible.module_utils.facts.network.interface import InterfaceFactCollector
    from ansible.module_utils.facts.network.default import DefaultFactCollector

    from ansible.module_utils.facts.virtual.base import VirtualFactCollector
    from ansible.module_utils.facts.virtual.chroot import ChrootFactCollector

# Generated at 2022-06-20 17:00:06.920524
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts as af

    # stub out the module_params for get_all_facts, since get_all_facts is
    # called in the context of an ansible module, we need to provide the
    # calling ansible module with a gather_subset param.
    class MyAnsibleModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}
    facts1 = get_all_facts(MyAnsibleModule(['all']))
    facts2 = af(MyAnsibleModule(['all']))
    assert facts1 == facts2

# Generated at 2022-06-20 17:00:13.621639
# Unit test for function get_all_facts
def test_get_all_facts():
    ''' Unit test for function get_all_facts '''

    from ansible.module_utils.facts.test_module import TestAnsibleModule
    module = TestAnsibleModule()
    facts = get_all_facts(module)
    assert 'foo' in facts
    assert facts['foo'] == 'bar'

# Generated at 2022-06-20 17:00:18.247677
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic
    import sys

    module_mock = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)

    import re
    assert re.match('^\d+\.\d+\.\d+(\.\d+)?$', ansible_facts(module_mock).get('distribution_version'))

# Generated at 2022-06-20 17:00:29.589748
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class AnsibleModule:
        def __init__(self, gather_subset=None):
            self.params = {}
            self.params['gather_subset'] = gather_subset

    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'
    all_collector_classes = default_collectors.collectors
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-20 17:00:33.960874
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import Facts

    fake_module = Facts()
    fake_module._ansible_module = FakeAnsibleModule()
    facts_dict = get_all_facts(module=fake_module)

    assert 'default_ipv4' in facts_dict



# Generated at 2022-06-20 17:00:44.270883
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    from ansible.compat.tests import unittest
    from ansible.module_utils.facts import DEFAULT_GATHER_SUBSET, DEFAULT_GATHER_TIMEOUT, default_collectors
    from ansible.module_utils.facts import get_default_collector_names
    # have to be able to handle this case because it's real
    if DEFAULT_GATHER_SUBSET is None:
        raise unittest.SkipTest('Default gather subset is None. Not expected.')

    # We're not testing the actual collectors here, all we want to do is
    # make sure the function doesn't error out.
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector


# Generated at 2022-06-20 17:00:51.209477
# Unit test for function get_all_facts
def test_get_all_facts():
    # This test is called via the meta plug-in:
    # meta: end_with('_facts.py')

    # fake out the module parameter
    gather_subset = None

    # get_all_facts uses ansible_facts as below, but with gather_subset=None.
    # ansible_facts is deprecated
    from ansible.module_utils.facts import ansible_facts
    facts = ansible_facts(None, gather_subset)
    assert isinstance(facts, dict)
    assert len(facts) >= 1
    assert 'os_family' in facts

    assert 'ansible_architecture' not in facts.keys()


# Generated at 2022-06-20 17:01:02.771237
# Unit test for function get_all_facts
def test_get_all_facts():
    '''compat api for ansible 2.3 module_utils.facts.get_all_facts method

    returns a dict mapping the bare fact name ('default_ipv4' with no 'ansible_' namespace) to
    the fact value.'''

    import os
    from ansible.module_utils.facts import ansible_collector

    class MockAnsibleModule:

        def __init__(self):
            self.params = dict(
                gather_timeout=5,
                gather_subset='all'
            )

        def exit_json(self, **kwargs):
            print(kwargs)
            os._exit(0)

    module = MockAnsibleModule()
    all_facts = get_all_facts(module)

    assert 'default_ipv4' in all_facts

# Generated at 2022-06-20 17:01:19.538528
# Unit test for function get_all_facts

# Generated at 2022-06-20 17:01:29.697270
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    # Create an AnsibleModule stub with the appropriate params
    module = AnsibleModule({'gather_subset': ['all', '!virtual']})

    # Call the module under test
    facts_dict = ansible_facts(module)

    # Is the result a dict?
    assert isinstance(facts_dict, dict)

    # Keys must be strings (convert to unicode to be sure)
    for k in facts_dict.keys():
        assert isinstance(to_bytes(k, errors='surrogate_or_strict'), str)
    # Values must be strings
    for v in facts_dict.values():
        assert isinstance(v, str)

# Generated at 2022-06-20 17:01:39.832018
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function module_utils.facts_utils.ansible_facts'''

    module_params = {'gather_subset': ['all']}

    from ansible.module_utils.facts import FACT_CACHE

    # test with just the minimal_gather_subset
    module_params['gather_subset'] = ['min']
    module_params['filter'] = 'ansible_*'
    # test the basic sanity of the function
    assert ansible_facts(AnsibleModuleMock(module_params))

    # test for missing facts

# Generated at 2022-06-20 17:01:50.083293
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['network']

    fact_results = get_all_facts(module)

    import json
    import pprint
    pprint.pprint(json.dumps(fact_results))

    assert fact_results

    # the default_gather_subset should include module names in the 'ansible_' namespace
    assert 'ansible_default_ipv4' in fact_results
    assert len(fact_results) > 1

    # verify that the fact is the expected type and not just a placeholder/skeleton object
    assert type(fact_results['ansible_default_ipv4']) is dict

# Generated at 2022-06-20 17:01:57.863733
# Unit test for function get_all_facts
def test_get_all_facts():
    module = mock_ansible_module()

    # return value of mock_ansible_module.params
    module.params = dict(gather_subset=['network', 'all'])


# Generated at 2022-06-20 17:02:03.254979
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    if sys.version_info[0] >= 3:
        from unittest.mock import MagicMock
    else:
        from mock import Mock as MagicMock
    module = MagicMock()
    module.params = dict(ansible_facts=True)
    fact_dict = ansible_facts(module)
    assert 'hostname' in fact_dict

# Generated at 2022-06-20 17:02:09.254034
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts

    gather_subset = ['all']
    facts = ansible_facts(gather_subset=gather_subset)

    assert(facts.get('default_ipv4', None) is not None)
    assert(facts.get('ansible_default_ipv4', None) is None)

    assert(facts.get('ansible_version', None) is not None)



# Generated at 2022-06-20 17:02:10.334029
# Unit test for function get_all_facts
def test_get_all_facts():
    assert get_all_facts.__name__ == 'get_all_facts'
    assert callable(get_all_facts)

# Generated at 2022-06-20 17:02:16.017560
# Unit test for function ansible_facts
def test_ansible_facts():
    class Module():
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

    facts = ansible_facts(Module())
    assert 'version' in facts

# Generated at 2022-06-20 17:02:28.839489
# Unit test for function get_all_facts
def test_get_all_facts():
    # unit test for get_all_facts() compatibility
    # we don't want to bother properly mocking and running the AnsibleModule for real
    # so instead we just run the get_all_facts() function directly and assert it returns
    # a dict of sorted facts
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    class FakeAnsibleModule(object):
        def __init__(self, params):
            self.params = params

    params = dict(
        gather_subset=None  # this means the default set, which is minimal
    )
    fake_module = FakeAnsibleModule(params=params)

    ansible

# Generated at 2022-06-20 17:02:51.079457
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_version
    from ansible.module_utils.facts.collection import NetworkFacts
    module = type('AnsibleModule', (), {'params': {'gather_subset': ['all']} })()
    facts = get_all_facts(module)
    assert isinstance(facts, dict), 'Expected fact to be a dict, got {}'.format(facts)
    assert 'ansible_version' in facts, 'Expected ansible_version in facts, got {}'.format(facts)
    assert isinstance(ansible_version, str), 'Expected ansible_version to be a str, got {}'.format(ansible_version)

# Generated at 2022-06-20 17:03:00.696822
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test_get_all_facts

    Tests that the get_all_facts function returns a dict with a single key, 'ansible_facts'.

    Tests that the ansible_facts key contains the dict that the ansible_facts function returns.
    '''

    import mock
    import os

    module = mock.MagicMock()
    module.params = {'gather_subset': ['all']}

    facts = get_all_facts(module)

    assert 'ansible_facts' in facts
    assert isinstance(facts['ansible_facts'], dict)

    stripped_facts = facts['ansible_facts']

    for k, v in stripped_facts.items():
        assert not k.startswith('ansible')

# Generated at 2022-06-20 17:03:11.545065
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.system.base as base
    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset':['!all']}
        pass
    x = FakeModule()
    base.get_file_lines = lambda a: ['a\n']
    base.get_file_content = lambda a: 'a'
    base.get_mount_size = lambda a: 1
    base.get_mount_size_reserved = lambda a: 1
    y = get_all_facts(x)
    assert y['is_linux'] == 1
    assert y['file_exists'] == 'a'
    assert y['file_lines'] == 'a'

# Generated at 2022-06-20 17:03:21.783293
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import base
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts.collector import add_default_collectors
    from ansible.module_utils.facts import default_collectors

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    class MockFactNamespace(object):
        def __init__(self, name):
            self.name = name

        def populate(self, module, collected_facts):
            if self.name == 'system':
                collected_facts[self.name]['path'] = '/usr/bin:/bin:/usr/sbin:/sbin'

# Generated at 2022-06-20 17:03:30.728371
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_fact_cache
    import pytest

    class AnsibleModuleStub():
        def __init__(self, gather_subset=None):
            self.params = {'gather_subset': gather_subset}

    gathered_facts = set(ansible_facts(AnsibleModuleStub()).keys())
    cached_facts = ansible_fact_cache.CACHE.get('ansible_facts', {}).keys()
    assert gathered_facts == cached_facts
    # test with a non-empty subset
    gathered_facts = set(ansible_facts(AnsibleModuleStub(gather_subset=['os'])).keys())
    cached_facts = ansible_fact_cache.CACHE.get('ansible_facts', {}).keys()


# Generated at 2022-06-20 17:03:42.074904
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule:
        pass
    fake_module = FakeModule()
    fake_module.params = {'gather_subset': ['all']}

    gather_subset = fake_module.params['gather_subset']
    gather_timeout = fake_module.params.get('gather_timeout', 10)
    filter_spec = fake_module.params.get('filter', '*')


# Generated at 2022-06-20 17:03:48.852907
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    sys.modules['ansible.module_utils.facts'] = sys.modules[__name__]

    from ansible.module_utils.facts import get_all_facts

    class MockModule:
        def __init__(self):
            self.params = {}

    m = MockModule()
    m.params['gather_subset'] = ['a', 'b']
    assert get_all_facts(m) == ansible_facts(m)

# Generated at 2022-06-20 17:04:00.753460
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import get_collector_class

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    all_collector_classes = default_collectors.collectors

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    # get collector class with minimal set
    fact_collector = get_collector_class(all_collector_classes, namespace, ['!all', 'min', '!network'])
    # create module with param gather_subset
    module = FakeModule(params={'gather_subset':['!all', 'min', '!network']})
    # get ansible facts dict

# Generated at 2022-06-20 17:04:05.790913
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.module import AnsibleModule
    module = AnsibleModule()
    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert len(facts) > 0


# Generated at 2022-06-20 17:04:16.382688
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts.virtual.qemu import QemuHardware
    from ansible.module_utils.facts.virtual.lxc import LXCHardware
    from ansible.module_utils.facts.virtual.openvz import OpenVZHardware
    from ansible.module_utils.facts.virtual.systemd import SystemdHardware
    from ansible.module_utils.facts.virtual.xenapi import XenAPIHardware
    from ansible.module_utils.facts.virtual.xen import XenHardware

# Generated at 2022-06-20 17:04:54.425637
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts
    import ansible.module_utils.facts.network.generic
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts import ansible_collector
    ansible_facts = ansible.module_utils.facts.ansible_facts
    default_collectors.collector_classes['distribution'] = DistributionFactCollector
    default_collectors.collectors.append('distribution')
    ansible.module_utils.facts.network.generic.FactsBase.get_func_facts = lambda self, module: {'default_ipv4': {}}
    ansible_collector.get_ansible_collector()

# Generated at 2022-06-20 17:05:03.658644
# Unit test for function get_all_facts
def test_get_all_facts():

    import ansible.module_utils.facts.namespace as namespace_module
    import ansible.module_utils.facts.collector as collector_module

    def test_ansible_collect(self, module, collected_facts=None, filter_spec=None, gather_subset=None, gather_timeout=None):
        return {'one': 'one', 'two': {'three': 3}, 'four': [4, 5, 6, 7]}

    collector_module.AnsibleCollector = type('AnsibleCollector',
                                             (collector_module.AnsibleCollector,),
                                             {'collect': test_ansible_collect})

    class AnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': None}


# Generated at 2022-06-20 17:05:14.034459
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import sys

    # mock out ansible module
    class MockModule():
        def __init__(self, params):
            self.params = params
            self.exit_json = sys.exit
            self.fail_json = sys.exit

    # build a minimal param dict that will exercise the function
    mock_param_dict = dict(gather_subset=['all'],
                           gather_timeout=10,
                           filter=['*'],
                           )
    # mock module import
    mock_mod_path = os.path.join(os.path.dirname(__file__), '../../../')
    sys.modules["ansible.modules.network.nxos"] = mock_mod_path
    sys.path.append(mock_mod_path)

    # build a mock ansible module

# Generated at 2022-06-20 17:05:22.380326
# Unit test for function ansible_facts
def test_ansible_facts():
    # Mock the AnsibleModule class
    class AnsibleModule:
        def __init__(self, params):
            self.params = params

    # Mock the module params
    params = {'gather_subset': ['all']}

    # Run the test
    test_module = AnsibleModule(params)
    facts = ansible_facts(test_module)

    # check that a valid fact was returned
    assert facts['distribution_file_parsers']

# Generated at 2022-06-20 17:05:29.186169
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils import basic

    import os

    class AnsibleModule(basic.AnsibleModule):
        def __init__(self):
            super(AnsibleModule, self).__init__()

            self.params = {
                'gather_timeout': 10,
                'filter': 'ansible_os_family',
            }

    test_module = AnsibleModule()
    facts = ansible_facts(module=test_module)
    
    assert 'os_family' in facts['ansible_facts']
    assert facts['ansible_facts']['os_family'] == 'RedHat'

# Generated at 2022-06-20 17:05:38.944108
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # mock module
    m = MockModule('get_all_facts', 'ansible2.2')
    m.gather_subset = ['all']

    # mock fact dict
    fact_dict = {'name': 'whatever'}

    # mock minimal_gather_subset
    # build a set of the minimal gather subset

# Generated at 2022-06-20 17:05:42.862988
# Unit test for function ansible_facts
def test_ansible_facts():
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.facts = {}

    am = DummyModule()
    facts = ansible_facts(am)
    assert len(facts) > 0
    assert 'hostname' in facts
    assert 'fqdn' in facts
    assert 'domain' in facts

    for k in facts:
        assert not k.startswith('ansible_')

# Generated at 2022-06-20 17:05:53.952595
# Unit test for function ansible_facts
def test_ansible_facts():
    import time

    # mock module
    class Module(object):
        class params(object):
            pass
    module = Module()

    module.params.gather_subset = ['all']
    module.params.gather_timeout = 0.1

    # setup a collector that adds the number of seconds the system has been up
    class MockUptimeCollector(object):
        name = 'uptime'

        @staticmethod
        def collect(module):
            return {'seconds_up': time.time()}

    # setup a collector that adds the number of seconds the system has been up
    class MockFooCollector(object):
        name = 'foo'

        @staticmethod
        def collect(module):
            return {'bar': 'baz'}

    module.params.filter = '*'

    # test that we

# Generated at 2022-06-20 17:06:00.091308
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    result = get_all_facts(None)
    assert isinstance(result, dict)
    result = get_all_facts(None, gather_subset='all')
    assert isinstance(result, dict)

# Generated at 2022-06-20 17:06:06.865910
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.utils.display import Display
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.default_collectors as default_collectors
    import ansible.module_utils.facts.hardware.base as hardware_base
    import ansible.module_utils.facts.network.base as network_base

    # patch display
    ansible.module_utils.facts.collector.display = Display()

    # patch PathResolver
    ansible.module_utils.facts.collector.PathResolver = lambda: None
    collect_file = lambda *args, **kwargs: None
    ansible.module_utils.facts.collect