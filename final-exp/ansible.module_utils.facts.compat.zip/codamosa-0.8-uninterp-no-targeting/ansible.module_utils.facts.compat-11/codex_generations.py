

# Generated at 2022-06-20 16:56:53.075406
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.collector
    module = ansible.module_utils.facts.collector.BaseFileParserCollector('test')
    result = ansible_facts(module, gather_subset=['all'])
    assert 'processor' in result


# Generated at 2022-06-20 16:56:59.702887
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.facts import is_ansible_2_3

    # unit test for ansible_facts
    if is_ansible_2_3(ansible_version):
        if sys.version_info[0] < 3:
            # Mock the module
            class MockModule(object):
                def __init__(self, **kwargs):
                    self.params = kwargs


            module = MockModule(
                gather_subset=['all'],
                gather_timeout=10
            )

            # now unit test the method
            facts_dict = ansible_facts(module)
            assert isinstance(facts_dict, dict)

# Generated at 2022-06-20 16:57:05.993441
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.test.test_utils import AnsibleModuleMock
    module = AnsibleModuleMock(param_dict={'gather_filter': '*'})
    result = get_all_facts(module)
    assert 'facter_os_distro' in result

# Generated at 2022-06-20 16:57:17.484344
# Unit test for function get_all_facts
def test_get_all_facts():
    # pylint: disable=unused-variable
    import sys

    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', required=True)})
    result = get_all_facts(module)
    ansible_version = [int(x) for x in sys.modules['ansible'].__version__.split('.')]
    if ansible_version < [2, 3]:
        module.fail_json(msg='get_all_facts returned a non-dict value: %s(%s)' % (type(result), result))
    if not result:
        module.fail_json(msg='get_all_facts returned an empty dict')

# Generated at 2022-06-20 16:57:29.688261
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.facts.utils import get_all_facts

    # Patch module utils so we can mock
    from ansible.module_utils.facts import ansible_collector
    ansible_collector.get_ansible_collector = _mock_get_ansible_collector
    ansible_collector.DEFAULT_GATHER_SUBSET = ['!config', 'network']

    module = _mock_ansible_module(
        params={
            'gather_subset': ['!all'],
            'gather_timeout': 9,
        }
    )

    all_facts = get_all_facts(module)
    expected_facts = {'fact1': 'string1', 'fact2': 'string2'}



# Generated at 2022-06-20 16:57:42.607949
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.network import NetworkDefaultIpCollector
    from ansible.module_utils.facts.collector.network import NetworkHardwareCollector
    from ansible.module_utils.facts.collector.network import NetworkInterfacesCollector

    test_module = MockModule()

    # param gather_subset=[all], gather_timeout=10, filter='*'
    test_gather_subset = ['all']
    test_gather_timeout = 10
    test_filter_spec = '*'
    test_facts_dict = ansible_facts(module=test_module)

    # try to lookup each of the expected fact keys

# Generated at 2022-06-20 16:57:48.885034
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    import os
    import tempfile
    import shutil
    import json

    test_config_file = os.path.join(os.path.dirname(__file__), 'ansible.cfg')

    # update ANSIBLE_CONFIG and ANSIBLE_CONFIG_FILE to this directory, so that ansible_facts can find it when constructing an AnsibleModule
    old_ansible_config = os.environ.get('ANSIBLE_CONFIG')
    old_ansible_config_file = os.environ.get('ANSIBLE_CONFIG_FILE')
    os.environ['ANSIBLE_CONFIG'] = test_config_file
    os.environ['ANSIBLE_CONFIG_FILE'] = test_config_file


# Generated at 2022-06-20 16:58:00.659310
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector

    module_mock = type('module_mock', (object,), {})()
    module_mock.params = {'filter': 'ansible_default_ipv4'}
    module_mock.fail_json = lambda self, msg: msg

    minimized_namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    assert get_ansible_facts(module_mock) == {'default_ipv4': None}


# Generated at 2022-06-20 16:58:03.265473
# Unit test for function ansible_facts
def test_ansible_facts():
    GATHER_SUBSET = ['min', '!other']
    FILTER = 'ansible_distribution*'
    module = MockAnsibleModule(gather_subset=GATHER_SUBSET, filter=FILTER)
    facts = FactCollector.collect(module)
    assert facts['distribution'] == 'mock'



# Generated at 2022-06-20 16:58:12.843988
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import facts

    # Fake class to override default option values
    class FakeOptions(object):
        def __init__(self):
            self.timeout = 10
            self.gather_subset = ['all']
            self.gather_timeout = 10

    class AnsibleModuleMock(AnsibleModule):
        def __init__(self, *args, **kwargs):
            opts = FakeOptions()
            kwargs['argument_spec'] = {}
            super(AnsibleModuleMock, self).__init__(*args, **kwargs)
            self.params = opts

    class ModuleFailer(object):
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-20 16:58:17.440247
# Unit test for function get_all_facts
def test_get_all_facts():
    # TODO: Provide unit test for function get_all_facts
    pass


# Generated at 2022-06-20 16:58:21.074654
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.compat.tests import mock

    mock_module = mock.MagicMock()
    mock_module.params = {
        'gather_subset': ['!all'],
    }
    mock_module.params['gather_subset'] = ['network']
    assert get_all_facts(mock_module)



# Generated at 2022-06-20 16:58:33.746661
# Unit test for function get_all_facts
def test_get_all_facts():

    import sys
    import os.path
    sys.modules['_ansible_module_generated_by_test'] = None

    # Mock the module object
    module = mock.MagicMock(name='module', spec=AnsibleModule)
    module.params = {'gather_subset': ['network']}
    setattr(sys.modules['_ansible_module_generated_by_test'], 'AnsibleModule', lambda spec: module)

    # load the module_utils/facts code under test
    import ansible_collections.ansible.netcommon.plugins.module_utils.facts.facts as facts_module

    # mock the submodule so it doesn't actually run
    facts_module.ansible_collector = mock.MagicMock(name='ansible_collector', spec=module)

    # call get_all

# Generated at 2022-06-20 16:58:44.210430
# Unit test for function ansible_facts
def test_ansible_facts():
    # Make a Stub AnsibleModule object to test the change.
    class AnsibleModuleStub():
        def __init__(self, gather_subset, gather_timeout):
            self.params = {'gather_subset': gather_subset, 'gather_timeout': gather_timeout}
    module = AnsibleModuleStub(['!all'], 5)

    facts_dict = ansible_facts(module)

    if 'all' in facts_dict:
        assert False, "The 'all' key should have been excluded by the fact collector"

    assert 'distribution' in facts_dict, "The 'distribution' key should have been included by the fact collector"



# Generated at 2022-06-20 16:58:56.994638
# Unit test for function get_all_facts
def test_get_all_facts():
    # import only at test time
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.system import SystemCollector
    from ansible.module_utils.facts.distribution import DistributionCollector
    from ansible.module_utils.facts.platform import PlatformCollector
    from ansible.module_utils.facts.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.date_time import DateTimeCollector
    from ansible.module_utils.facts.command import CommandCollector
    from ansible.module_utils.facts.config import ConfigCollector
    from ansible.module_utils.facts.processor import ProcessorCollector

# Generated at 2022-06-20 16:59:03.651848
# Unit test for function get_all_facts
def test_get_all_facts():
    # This module doesn't actually get run, so just test the interface
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(default=['!all'], type='list')
        ),
        supports_check_mode = True
    )
    module.exit_json(ansible_facts=get_all_facts(module))

# Generated at 2022-06-20 16:59:14.442750
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    args = dict(filter='*')

    # AnsibleModule instance is required to call ansible_facts
    module = AnsibleModule(argument_spec=dict(filter=dict(type='str', default='*')))

    actual_dict = ansible_facts(module=module, gather_subset=['!fake'])

    assert isinstance(actual_dict, dict)
    for key in actual_dict:
        assert not key.startswith('ansible_')

    return actual_dict


# Generated at 2022-06-20 16:59:24.767106
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    # Create a mock AnsibleModule with a gather_subset argument.
    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(required=True, type='list', default=['all'])
    ))
    all_facts = get_all_facts(module)
    assert isinstance(all_facts, dict)
    for key, value in all_facts.items():
        assert key.startswith('ansible_')
        assert isinstance(value, (str, unicode, int, float, list, dict))



# Generated at 2022-06-20 16:59:37.569946
# Unit test for function get_all_facts
def test_get_all_facts():
    'Unit test for function get_all_facts'

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors, ansible_collector

    # setup expected values
    gather_subset = ['all', 'network', 'virtual']
    gather_timeout = 10
    filter_spec = '*'


    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    all_collector_classes = default_

# Generated at 2022-06-20 16:59:42.762215
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit tests for function ansible_facts'''

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_facts

    # Mock the AnsibleModule object
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(type='list', default=['all']),
            'gather_timeout': dict(type='int', default=10),
            'filter': dict(type='str', default='*')
        },
        supports_check_mode=True
    )

    # Test normal case - uses 'gather_subset' param
    module.params['gather_subset'] = ['network']

    # Test that ansible_facts returns a dict
    assert ansible_facts(module) == dict

    # Test that ansible

# Generated at 2022-06-20 16:59:59.393652
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import FactModule
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    module = FactModule()

    # DEFAULT_GATHER_SUBSET = frozenset(['all'])
    # GATHER_SUBSET_ALL = frozenset(['all'])

    gather_subset = module.params['gather_subset']
    # gather_subset=gather_subset, gather_timeout=gather_timeout,
    #    minimal_gather_subset=minimal_gather_subset, filter_spec=filter_spec,

    # all_collector_classes = default_collectors.collect

# Generated at 2022-06-20 16:59:59.882736
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-20 17:00:03.383371
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts

    '''unit test for get_all_facts function'''
    ansible_module = MockAnsibleModule()
    ansible_module.params = {'gather_subset': ['all']}
    fact_distribution_info = get_all_facts(ansible_module)
    print(fact_distribution_info)
    assert 'distribution' in fact_distribution_info



# Generated at 2022-06-20 17:00:05.563237
# Unit test for function ansible_facts
def test_ansible_facts():
    # TODO - mock out module param and module class
    pass

# Generated at 2022-06-20 17:00:13.196947
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    facts = ansible_facts(module=module)

    assert isinstance(facts, dict)
    assert 'distribution' in facts
    assert 'distribution' in facts['ansible_facts']

# Generated at 2022-06-20 17:00:21.996574
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import DefaultGatherFactsModule

    # Test passing of gather_subset, passing of gather_timeout (None)
    with pytest.raises(TypeError) as excinfo:
        get_all_facts(module=DefaultGatherFactsModule({}, gather_subset=['a','b','1','2'], gather_timeout=None))
    assert "get_all_facts() got unexpected keyword argument 'gather_timeout'" in excinfo.exconly()

    # Test passing of gather_subset, but not gather_timeout
    with pytest.raises(TypeError) as excinfo:
        get_all_facts(module=DefaultGatherFactsModule({}, gather_subset=['a','b','1','2']))

# Generated at 2022-06-20 17:00:27.123305
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.modules.system.ping import AnsibleModule

    module_args = {}
    module = AnsibleModule(argument_spec=module_args)
    result = get_all_facts(module)
    assert 'default_ipv4' in result
    assert 'ansible_default_ipv4' not in result

# Generated at 2022-06-20 17:00:36.893242
# Unit test for function get_all_facts
def test_get_all_facts():

    # This test relies on the oracle running in the host where the test is running.
    # If this is not the case, this test will fail.

    from ansible.module_utils.facts.oracle import get_oracle_facts
    from ansible.module_utils.facts.scaleway import get_scaleway_facts

    from ansible.module_utils.facts.virtual import get_virtual_facts
    from ansible.module_utils.facts.system import get_system_facts
    from ansible.module_utils.facts.distribution import get_distribution_facts
    from ansible.module_utils.facts.pip import get_pip_facts
    from ansible.module_utils.facts.virt_who import get_virt_who_facts
    from ansible.module_utils.facts.pkg_mgr import get

# Generated at 2022-06-20 17:00:46.688723
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    import json

    results = ansible_facts(AnsibleModule(argument_spec=dict(gather_subset=dict(default=['all'], type='list'))))
    print(json.dumps(results, indent=4, sort_keys=True, ensure_ascii=False))
    assert 'ansible_all_ipv4_addresses' in results

# Generated at 2022-06-20 17:00:54.436452
# Unit test for function ansible_facts
def test_ansible_facts():
    # This unit test can't actually test the "ansible_" namespaced facts because they're
    # platform-specific and would only run successfully on one platform.
    from ansible.module_utils.facts.network.base import Virtual

    test_module = MockAnsibleModule()

    virtual_facts = {
        "virtual": Virtual('kvm', 'kvm').get_facts()
    }

    test_ansible_facts = ansible_facts(test_module, ['virtual'])
    assert test_ansible_facts == virtual_facts



# Generated at 2022-06-20 17:01:11.281516
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts import ansible_collector

    class DummyAnsibleModule(object):

        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

        def get_bin_path(self, binary, required=False, opt_dirs=[]):
            return None

    class DummyFactCollector(object):
        def __init__(self, namespace, all_collector_classes, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            self.namespace = namespace
            self.all_collector_classes = all_collector_classes
            self.filter_spec = filter_spec
            self.g

# Generated at 2022-06-20 17:01:23.101164
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    import json

    class FakeAnsibleModule:
        def __init__(self, gather_subset=['all']):
            self.params = dict(gather_subset=gather_subset)

    # test get_all_facts
    fake_module = FakeAnsibleModule();
    facts = get_all_facts(fake_module)
    # test ansible_facts
    assert ansible_facts(fake_module) == facts
    assert type(facts) == dict
    assert facts['ansible_distribution'] == to_text(facts['distribution'], errors='surrogate_or_strict')
   

# Generated at 2022-06-20 17:01:32.047250
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts

    class FakeModule(object):
        def __init__(self):
            self.params = {}

    facts = get_all_facts(FakeModule())


# Generated at 2022-06-20 17:01:40.536518
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    # ansible_facts relies on ansible_collector, which does a bunch of 'import socket' and
    # 'import platform'.
    # However 'import platform' fails in py3.7, because it does 'from _sysconfigdata_m import build_time_vars'.
    # 'from _sysconfigdata_m import build_time_vars' fails with error:
    #     ImportError: cannot import name 'build_time_vars'
    #
    # So, don't do the unittest if we are running in py3.7. But, do the unittest if we are in py3.6,3.5,3.4,2.7
    import sys

# Generated at 2022-06-20 17:01:47.466760
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils import basic

    # instantiate a basic AnsibleModule
    am = basic.AnsibleModule(argument_spec={'gather_subset': dict(default=['all'])})

    facts_dict = get_all_facts(am)

    assert 'ansible_distribution' in facts_dict
    assert 'ansible_distribution_version' in facts_dict
    assert 'ansible_domain' in facts_dict
    assert 'ansible_hostname' in facts_dict
    assert 'ansible_interfaces' in facts_dict
    assert 'ansible_kernel' in facts_dict
    assert 'ansible_memtotal_mb' in facts_dict
    assert 'ansible_os_family' in facts_dict
   

# Generated at 2022-06-20 17:01:59.580523
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    fake_module = object()
    # Minimal facts
    minimal_facts = ansible_facts(module=fake_module, gather_subset=['min'])
    # Minimal and all facts
    minimal_and_all_facts = ansible_facts(module=fake_module, gather_subset=['min', 'all'])
    # Minimal and network facts
    minimal_and_network_facts = ansible_facts(module=fake_module, gather_subset=['min', 'network'])

    # If we're running on Python 3, we need to ensure that all of the fact strings
    # are in bytes format.  This is

# Generated at 2022-06-20 17:02:09.581963
# Unit test for function ansible_facts
def test_ansible_facts():
    """Ansible facts unit test."""

    import types
    import copy
    import test.support

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace


# Generated at 2022-06-20 17:02:18.245678
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts

    Requires a dummy, instrospectable AnsibleModule class.
    '''

    # create mock AnsibleModule class
    class MockAnsibleModule(object):

        def __init__(self, expected_subset):
            self.params = {'gather_subset': expected_subset}

    # create mock AnsibleModule object
    mock_module = MockAnsibleModule('all')

    # call the function
    facts = get_all_facts(mock_module)

    # check it collected the santized 'subset'
    assert facts['gather_subset'] == 'all'

# Generated at 2022-06-20 17:02:29.843472
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils import basic
    from ansible.module_utils.facts import default_collectors

    # Create a mocked AnsibleModule
    module = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', required=False),
            min=dict(type='bool', required=False),
            filter=dict(type='str', required=False)
        )
    )
    # Create a wrapped get_all_facts that uses the "module" above
    wrapped_get_all_facts = lambda: get_all_facts(module)
    # Create a wrapped ansible_facts that also uses the mocked module

# Generated at 2022-06-20 17:02:40.342867
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.collector
    import collections

    # if we run this from the toplevel, we have to make sure we can load the plugins
    # from the roles/test/shared directory
    if 'ansible.module_utils.facts.namespace' not in sys.modules:
        ansible_path = os.path.join(os.path.dirname(__file__), '..', '..', '..')
        sys.path.append(ansible_path)

    # import a fake version of AnsibleModule so we can pass it to ansible_facts

# Generated at 2022-06-20 17:03:09.719075
# Unit test for function ansible_facts
def test_ansible_facts():
    import argparse
    import unittest
    from ansible.module_utils.facts import ansible_collector

    parser = argparse.ArgumentParser()
    parser.add_argument('--collect-only', action='store_true', default=False)
    parser.add_argument('--debug', action='store_true', default=False)
    parser.add_argument('--gather-subset', action='append', default=None)
    parser.add_argument('--filter', action='store', default='*')
    parser.add_argument('-t', '--tree', action='store', default=None)

    args = parser.parse_args()

    # Make the ansible.module_utils.facts.ansible_collector package available to the other tests
    ansible_collector.__dict__['args'] = args



# Generated at 2022-06-20 17:03:12.257841
# Unit test for function get_all_facts
def test_get_all_facts():
    module = Mock()
    # gather_subset should be ignored
    module.params = {'gather_subset': ['!all']}

    result = get_all_facts(module)

    # we should have at least hostvars and ansible_facts
    assert result['hostvars']
    assert result['ansible_facts']


# Generated at 2022-06-20 17:03:16.677266
# Unit test for function get_all_facts
def test_get_all_facts():
    class Module:
        params = {'gather_subset': ['all']}
    module = Module()

    assert 'ansible_distribution' in get_all_facts(module)



# Generated at 2022-06-20 17:03:17.867425
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-20 17:03:29.328791
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_all_facts

    import mock

    module = mock.Mock()
    module.params = {
        'filter': '',
        'gather_subset': ['all'],
        'gather_timeout': 10,
        'custom_fact': 10
    }

    # any value that's not None, 0, or '', triggers the filter_spec in the facts module
    # here we filter all facts to prevent the unit test from running, since it takes a bit of time
    module.params['filter'] = 'filtered'

    facts = get_all_facts(module)

    assert isinstance(facts, dict)

# Generated at 2022-06-20 17:03:34.333388
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils._text import to_bytes

    # create a mock module
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, **args):
            pass

    params = dict(gather_subset='all', debug=False, fact_path="/does/not/exist")
    module = MockModule(params)
    all_facts = get_all_facts(module)

    ## assert that we got a dict back
    assert isinstance(all_facts, dict)
    assert all_facts

    # make sure the 'ansible_' namespace is not in the dict keys

# Generated at 2022-06-20 17:03:41.613310
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'gather_subset': {'type': 'list', 'default': ['all']}})
    all_facts = get_all_facts(module)

    assert len(all_facts) > 1
    assert all_facts['architecture'] in ('x86_64', 'i386', 'i686')
    assert all_facts['distribution'] in ('Ubuntu', 'Debian', 'CentOS', 'Fedora', 'RedHat')
    assert all_facts['kernel'] in ('Linux', 'Darwin')

# Generated at 2022-06-20 17:03:50.912247
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.facts import FactsModule

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    mock_module = FactsModule()
    mock_module.params = {'gather_subset': ['all']}

    results = get_all_facts(mock_module)

    assert results['python']['version']['major'] == sys.version_info[0]
    assert results['python']['version']['minor'] == sys.version_info[1]
    assert results['lsb']['distrib_codename'] == DistributionFactCollector().distrib_codename


# Generated at 2022-06-20 17:03:59.863534
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={
        'gather_subset': {'type': 'list', 'default': ['!all']},
        'gather_timeout': {'type': 'int', 'default': 10}
    })
    facts = ansible_facts(module)
    assert 'date_time' in facts
    assert 'ansible_date_time' not in facts
    assert 'facter_date_time' not in facts
    assert facts['date_time']['timezone'] == 'UTC'



# Generated at 2022-06-20 17:04:05.265634
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts.virtual import VirtualFactsCollector

    # Mock module - need it to have a gather_subset parameter
    class MockAnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    # Create mock collecter that returns 'mock' as a fact
    class MockCollector(VirtualFactsCollector):
        name = 'mock'
        _fact_ids = ['mock']
        def collect(self, module=None, collected_facts=None):
            return {'ansible_mock': 'mock'}

    # Patch default_collectors.collectors to return mock collector
    import ansible.module_utils.facts.default_collectors
    saved_collectors = ansible.module_utils.facts.default

# Generated at 2022-06-20 17:04:43.850376
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_module
    from ansible.module_utils.facts.collector import BaseFactCollector

    class CustomCollector(BaseFactCollector):

        name = 'custom'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            self._collected_facts['test_fact'] = 'test_fact_value'
            return self._collected_facts

    extra_module_utils_dir = to_bytes(os.path.dirname(__file__))

# Generated at 2022-06-20 17:04:49.075939
# Unit test for function get_all_facts
def test_get_all_facts():

    class MockedModule(object):

        def __init__(self, **kwargs):
            self.params = kwargs

    module = MockedModule(gather_subset=['all'])

    facts = get_all_facts(module)

    assert 'default_ipv4' in facts

# Generated at 2022-06-20 17:05:01.793847
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.basic import AnsibleModule

    # Stub out the collect method of the collectors
    # This will be invoked when ansible_facts is called
    def stub_collect_distribution(module):
        return {'distribution': 'Ubuntu', 'distribution_version': '16.04' }
    DistributionFactCollector.collect = stub_collect_distribution

    def stub_collect_platform(module):
        return {'system': 'Linux', 'kernel': '4.4.0-87-generic'}
    PlatformFactCollector.collect = stub_collect_platform


# Generated at 2022-06-20 17:05:13.306707
# Unit test for function ansible_facts
def test_ansible_facts():

    import ansible.module_utils.facts.network.default as network_fact_module
    import ansible.module_utils.facts.network.nxos as nxos_fact_module
    import ansible.module_utils.facts.network.ios as ios_fact_module

    import mock
    import sys

    class FakeModule:
        def __init__(self, params=None):
            self.params = params or {}

        def get_option(self, opt):
            return self.params.get(opt)

    class FakeNetworkModule(FakeModule):
        def __init__(self, params=None):
            super(FakeNetworkModule, self).__init__(params)
            fact_collector = ansible_facts(self)
            self.facts = fact_collector.collect(module=self)


# Generated at 2022-06-20 17:05:19.015087
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.virtual import BaseVirtual
    from ansible.module_utils.facts.virtual.lxd import Lxd, LxdFactCollector

    all_collectors = default_collectors.collectors

    # Don't run any tests that require the platform collector, because we can't
    # force the platform collector to lie to us
    all_collectors.remove(default_collectors.PlatformFactCollector)

    # Don't run the iosxr collector, since that one requires a real plugin
    all_collectors.remove(default_collectors.IOSXRFactCollector)

    # replace BaseVirtual with a mocked class
    class MockBaseVirtual(BaseVirtual):
        def running_in_virtual(self):
            return False

    all_collect

# Generated at 2022-06-20 17:05:27.869230
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible_module_utils._text import to_text
    from ansible.module_utils import basic
    import json

    test_module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    returned_dict = ansible_facts(test_module)

# Generated at 2022-06-20 17:05:37.909470
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts

    class FakeModule(object):
        '''An object that mimics the api of an ansible 2.3+ AnsibleModule'''

        def __init__(self, params):
            self.params = params

    # module_utils.facts.get_all_facts should just be a wrapper around module_utils.facts.ansible_facts
    # with no gather_subset argument

# Generated at 2022-06-20 17:05:44.440680
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import (cache, collector, defaults)
    from ansible.module_utils.facts.defaults import DEFAULT_GATHER_SUBSET, DEFAULT_GATHER_TIMEOUT
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts

    class MockModule(object):
        def __init__(self):
            self.params = {}

    # test backward compatibility with previous DEFAULT_GATHER_SUBSET/DEFAULT_GATHER_TIMEOUT
    # set on ansible.module_utils.facts module.
    mock_module = MockModule()
    ansible.module_utils.facts.DEFAULT_GATHER_SUBSET = 'foo'


# Generated at 2022-06-20 17:05:53.232186
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule:
        def __init__(self, params=None):
            self.params = params or {}

        def fail_json(self, *args, **kwargs):
            pass

    fake_module = FakeModule()
    facts = ansible_facts(fake_module)


# Generated at 2022-06-20 17:06:04.812398
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    all_