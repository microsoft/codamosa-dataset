

# Generated at 2022-06-20 16:56:57.759180
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MyCollector(BaseFactCollector):
        provider = None
        platform = 'test'
        fact_namespace = PrefixFactNamespace(namespace_name='test', prefix='test_')

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test'}

    def mocked_module(*args, **kwargs):
        module = MockAnsibleModule(*args, **kwargs)
        module.params = {}

        # use our fake collector
        module.collect_facts = MagicMock()
        module.collect_facts.return_value = {'test_fact': 'test'}

        return module



# Generated at 2022-06-20 16:57:09.252074
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''

    # OK, I admit it. This is a pretty lame test. All I'm checking is that get_all_facts
    # doesn't blow up with a typical AnsibleModule. I'm having a hard time mocking module directly,
    # so I created a fake AnsibleModule class with the minimum needed attributes.
    #
    # But it's sufficient to run a simple pylint, and make sure that the get_all_facts function has a
    # docstring and a pytest unit test.
    class FakeAnsibleModule:
        params = {
            'gather_subset': ['all']
        }

    fake_module = FakeAnsibleModule()

    get_all_facts(fake_module)

# Generated at 2022-06-20 16:57:17.120955
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Test the ansible_facts() function by passing in a fake AnsibleModule.
    '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={
            'gather_subset': {'type': 'list', 'default': ['all'], 'aliases': ['subset']},
            'gather_timeout': {'type': 'int', 'default': 10},
            'filter': {'type': 'str', 'default': '*'},
        },
        supports_check_mode=False,
    )

    ansible_facts = ansible_facts(module)

    assert isinstance(ansible_facts, dict)
    assert isinstance(ansible_facts['lsb'], dict)

# Generated at 2022-06-20 16:57:29.658224
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test to  test helper function ansible_facts.

    Some quick tests to ensure that the Getters are being called as expected by a module
    using this code.
    '''
    from ansible.module_utils.facts import collector

    # subclassing to ensure that we're actually calling the get_all_facts method.
    # this is only needed for the test
    class TestAnsibleCollector(collector.BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(TestAnsibleCollector, self).__init__(*args, **kwargs)
            self.called_get_all_facts = False

        def get_all_facts(self, module):
            self.called_get_all_facts = True


# Generated at 2022-06-20 16:57:38.185724
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec=dict())
    assert ansible_facts(module) != None
    assert ansible_facts(module, gather_subset=['version']) != None
    assert ansible_facts(module, gather_subset=['min']) != None

if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-20 16:57:43.076883
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule():
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    fake_module = FakeModule(['all'])
    actual_facts = get_all_facts(fake_module)
    assert 'default_ipv4' in actual_facts, "expected 'default_ipv4' fact in output"



# Generated at 2022-06-20 16:57:51.141058
# Unit test for function get_all_facts
def test_get_all_facts():
    '''The point of this unit test is mainly to make sure that the get_all_facts
    function signature is stable, so that the signature in the docs matches
    the signature in the code. Other unit tests already test the functionality
    of get_all_facts, so this test is just a signpost so that the signature
    can be easily seen.
    '''

    from ansible.module_utils.facts.network import get_network_interfaces
    from ansible.module_utils.facts import cache

    class MockModule(object):
        def __init__(self):
            self.params = {}

        class fail_json(object):
            def __init__(self, *args, **kwargs):
                pass

        class deprecate(object):
            def __init__(self, *args, **kwargs):
                pass

    #

# Generated at 2022-06-20 16:57:55.381023
# Unit test for function get_all_facts
def test_get_all_facts():
    module = AnsibleModule(argument_spec={'gather_subset': {'default': 'all', 'type': 'list'}})
    facts = get_all_facts(module)

    assert isinstance(facts, dict)

    assert 'ansible_facts' in facts
    ansible_facts = facts['ansible_facts']
    assert ansible_facts is not None
    assert isinstance(ansible_facts, dict)

    assert 'default_ipv4' in ansible_facts
    default_ipv4 = ansible_facts['default_ipv4']
    assert default_ipv4 is not None
    assert isinstance(default_ipv4, dict)

    assert 'ipv4' in default_ipv4
    ipv4 = default_ipv4['ipv4']

# Generated at 2022-06-20 16:58:01.257878
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import Collector, FactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestFactCollector(FactCollector):
        def __init__(self, *args, **kwargs):
            super(TestFactCollector, self).__init__(*args, **kwargs)

        def collect(self, module=None, collected_facts=None):
            return {'ansible_test': 'foo'}

    class TestCollector(Collector):
        def __init__(self, *args, **kwargs):
            super(TestCollector, self).__init__(namespace=kwargs['namespace'])


# Generated at 2022-06-20 16:58:12.201782
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import sys

    import pytest
    from mock import MagicMock

    @pytest.fixture()
    def mock_ansible_module(request):
        sys.modules['ansible'] = MagicMock()
        from ansible.module_utils.facts.namespace import PrefixFactNamespace
        from ansible.module_utils.facts import default_collectors
        from ansible.module_utils.facts import ansible_collector

        ansible_module = MagicMock()
        ansible_module.params = {
            'gather_subset': ['all']
        }

        return ansible_

# Generated at 2022-06-20 16:58:22.253329
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.processor.file import FileProcessor
    from ansible.module_utils.facts.processor.pkg_mgr import PackageManagerProcessor
    from ansible.module_utils.facts.processor.service_mgr import ServiceMgrProcessor
    from ansible.module_utils.facts.processor.system import SystemProcessor
    from ansible.module_utils.facts.processor.user import UserProcessor
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

# Generated at 2022-06-20 16:58:34.082008
# Unit test for function get_all_facts
def test_get_all_facts():

    import sys
    import os
    import json

    sys.path.append(os.path.dirname(__file__) + "/../../../lib")

    from ansible.module_utils.facts.utils.test.test_namespace import test_module_utils_namespace
    from ansible.module_utils.facts.utils.test.test_ansible_collector import test_module_utils_facts_ansible_collector
    from ansible.module_utils.facts.utils.test.test_default_collectors import test_module_utils_facts_default_collectors

    test_module_utils_namespace()
    test_module_utils_facts_ansible_collector()
    test_module_utils_facts_default_collectors()

    test_obj = FakeModule()


# Generated at 2022-06-20 16:58:42.582156
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts

    confirms that ansible_facts returns a dict of fact names to values
    and that no namespace has been added'''

    from ansible.module_utils import basic
    import json

    # make a fake module
    module = basic.AnsibleModule(argument_spec=dict())

    # collect all the facts
    facts_dict = ansible_facts(module)

    # confirm it returned a dict
    assert isinstance(facts_dict, dict)

    # confirm all the keys are fact names (no 'ansible_' prefix)
    assert all([fact_name.startswith('ansible_') is False for fact_name in facts_dict])

    # confirm it's not an empty dict
    assert len(facts_dict) > 0

    # confirm it only contains 'text'
    all_

# Generated at 2022-06-20 16:58:56.419334
# Unit test for function get_all_facts
def test_get_all_facts():
    # test get_all_facts against a real module
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class AnsibleFactCollectorTestCase(unittest.TestCase):

        def assert_all_facts_match_ansible_facts(self, gather_subset):
            '''Assert that get_all_facts and ansible_facts return the same list of facts when run with gather_subset'''
            module = AnsibleModule(argument_spec={'gather_subset': {'type': 'list', 'default': gather_subset}})
            get_all_facts_facts = get_all_facts(module)
            ansible_facts_

# Generated at 2022-06-20 16:59:06.511761
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_all_collector_classes

    class FakeModule:
        def __init__(self):
            self.params = {'filter': '*'}

    fm = FakeModule()
    all_collector_classes = get_all_collector_classes(fact_classes=default_collectors.collectors)

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    fact_collector = \
        ansible_

# Generated at 2022-06-20 16:59:14.086827
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Mock module for testing
    class AnsibleModule(object):
        params = {}

    test_module = AnsibleModule()

    all_collector_classes = default_collectors.collectors

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-20 16:59:26.301904
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.facts as facts
    from ansible.module_utils import facts

    # use the default collectors
    all_collector_classes = facts.default_collectors.collectors

    # don't add a prefix
    namespace = facts.PrefixFactNamespace(namespace_name='ansible', prefix='')

    class FakeAnsibleModule:

        def __init__(self):
            self.params = dict(gather_subset=['!all'])
            self.facts = dict(all={'ansible_all_ipv4_addresses': '192.0.2.10'})

        def exit_json(self, **kwargs):
            self.facts.update(kwargs)

    # create a fake ansible module
    fake_module = FakeAnsibleModule()

   

# Generated at 2022-06-20 16:59:38.549737
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import AddPrefixFactNamespace
    from ansible.module_utils.facts.network.base import NetworkCollector

    class NetworkCollectorStub(NetworkCollector):
        def collect(self, module=None):
            return {'os_family': 'RedHat'}

    class TestModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    test_module = TestModule(['network'])
    all_collector_classes = {'network': NetworkCollectorStub}

    namespace = AddPrefixFactNamespace(namespace_name='ansible', prefix='ansible_')

    facts = ansible_facts(test_module, gather_subset=['network'])
    assert facts

# Generated at 2022-06-20 16:59:49.715333
# Unit test for function ansible_facts
def test_ansible_facts():
    import types
    import unittest
    import unittest.mock
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector

    '''Example of ansible_facts implementation for internal unit test'''

    class MockCollector(namespace.BaseFactNamespace):
        '''mock collector for unit test'''

        def __init__(self, namespace_name, prefix=None):
            super(MockCollector, self).__init__(namespace_name=namespace_name, prefix=prefix)
            self.namespace_name = namespace_name

        def get_fact_names(self):
            return ['test_fact']

        def collect(self, module=None):
            return {'test_fact': 'test value'}


# Generated at 2022-06-20 17:00:00.206561
# Unit test for function get_all_facts
def test_get_all_facts():
    #pylint: disable=missing-docstring
    #pylint: disable=protected-access
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts import collectors

    class MockModule:
        def __init__(self, params):
            self.params = params

    class MockCollector(collectors.BaseFactCollector):
        name = 'mock_collector'

        def collect(self, module=None, collected_facts=None):
            gathered_facts = dict(myfact='myfactvalue')
            return gathered_facts

        def should_collect(self, module=None):
            return True

    class MockNamespace(BaseFactNamespace):
        name = 'mynamespace'

    # no gather subset given
    module = MockModule({})
   

# Generated at 2022-06-20 17:00:18.596522
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.common import AnsibleModule
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import sys

    class MockTargetFile():
        def __init__(self, value):
            self.value = value

        def read(self):
            return self.value


# Generated at 2022-06-20 17:00:19.723397
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-20 17:00:29.800383
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''
    import datetime
    import sys
    import tempfile
    import time
    import unittest

    TEST_OUTPUT_PREFIX = 'test_facts_output'
    if sys.version_info.major < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    TESTS_DIR = os.path.dirname(os.path.realpath(__file__))
    OUTPUT_DIR = os.path.join(TESTS_DIR, 'test_output')
    if not os.path.exists(OUTPUT_DIR):
        os.mkdir(OUTPUT_DIR)

    #
    # AnsibleModule mocks
    #

# Generated at 2022-06-20 17:00:38.987492
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.network.base import NetworkCollector
    import ansible.module_utils.facts.network.default as network_facts

    module = MockModule()

    # Test default args & no gather_subset
    subset = None
    facts = get_all_facts(module)
    assert facts['ssh_pub_keys'] is None
    assert facts['default_ipv4']['address'] == '127.0.0.1'
    assert facts['default_ipv4']['interface'] == 'lo'

    # Test ssh_pub_keys cached
    del network_facts.ipaddrs_cache
    facts = get_all_facts(module)
    assert facts['ssh_pub_keys'] is None

    # Test ssh

# Generated at 2022-06-20 17:00:48.552812
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.modules.system import setup

    global get_all_facts
    # Old module_utils
    assert get_all_facts is ansible_facts

    # module_utils for Ansible 2.0
    setup.setansible_module_instance(ansible_version="2.0")
    assert get_all_facts is ansible_facts

    # module_utils for Ansible 2.2
    setup.setansible_module_instance(ansible_version="2.2")
    assert get_all_facts is ansible_facts

    # module_utils for Ansible 2.3
    setup.setansible_module_instance(ansible_version="2.3")
    assert get_all_facts is ansible_facts

    # module_utils for Ansible 2.4
    setup.setansible_module_instance

# Generated at 2022-06-20 17:00:58.590317
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict()
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )
    # collect_default_collectors.collect will read from
    # module.params['filter']
    # module.params['gather_subset']
    # module.params['gather_timeout']

    # Set these arguments to something non-default
    module.params['filter'] = 'dns*'
    module.params['gather_subset'] = ['!all', 'dns']
    module.params['gather_timeout'] = 3

    # 'ansible_facts' is what the legacy ansible module_utils.facts.ansible_

# Generated at 2022-06-20 17:01:08.513478
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts.system.distribution as distribution

    # verify that we get subset of the facts when a subset is specified
    module = FakeAnsibleModule({'gather_subset': ['!all', '!min']})
    facts_dict = get_all_facts(module)

    # On some platforms, the 'architecture' key is not available, so check for it.
    if 'architecture' in facts_dict:
        assert 'architecture' in facts_dict
    else:
        # If 'architecture' is not available, then 'kernel' should be
        # available instead.
        assert 'kernel' in facts_dict

    assert 'fqdn' in facts_dict

    # verify that we get

# Generated at 2022-06-20 17:01:18.156891
# Unit test for function ansible_facts
def test_ansible_facts():
    class AnsibleModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    module = AnsibleModule(['all'])
    subset = ansible_facts(module=module)['gather_subset']
    assert subset == ['all']

    module = AnsibleModule(gather_subset=['all'])
    subset = ansible_facts(module=module)['gather_subset']
    assert subset == ['all']

    module = AnsibleModule(gather_subset=['network'])
    subset = ansible_facts(module=module)['gather_subset']
    assert subset == ['network']

# Generated at 2022-06-20 17:01:29.485314
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import Namespace

    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.called = dict()

    # create a FakeModule for testing
    module = FakeModule()

    # init params dict
    module.params['gather_subset'] = ['all']

    # get_all_facts() should return a dict
    assert isinstance(get_all_facts(module), dict)

    # get_all_facts() should call ansible_facts()
    module.called['ansible_facts'] = False
    ansible_facts_orig = ansible_facts

    def ansible_facts(module, gather_subset=None):
        module.called['ansible_facts'] = True
        return {}


# Generated at 2022-06-20 17:01:39.739987
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts.collector import BaseFactCollector

    class MyCollector(BaseFactCollector):

        def collect(self, module=None, collected_facts=None):
            return dict(fact='value')

    assert get_all_facts(instant_ansible_module(params={'gather_subset': [], 'filter': '*'})) \
        == dict(fact='value')

    assert get_all_facts(instant_ansible_module(params={'gather_subset': [], 'filter': ['fact']})) \
        == dict(fact='value')

    assert get_all_facts(instant_ansible_module(params={'gather_subset': [], 'filter': ['other_fact']})) \
        == dict()

    assert get_all_

# Generated at 2022-06-20 17:02:01.735086
# Unit test for function ansible_facts
def test_ansible_facts():


    # test that 'ansible_facts' function returns default_ipv4 fact when
    # gather_subset is not defined
    #
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(type='list', default=['all'])),
                               supports_check_mode=True)
    # setup mock objects

    # 'ansible_facts' must return at least one fact - one of the facts must be
    # default_ipv4.
    # Create a mock facts dict with default_ipv4 key and value.
    mock_ansible_facts_dict = dict()
    mock_ansible_facts_dict['default_ipv4'] = '127.0.0.1'

    # Create a mock 'PreFixFactCollector' object to simulate a fact collector object
    # that 'ansible

# Generated at 2022-06-20 17:02:09.254624
# Unit test for function ansible_facts
def test_ansible_facts():
    class Module:
        pass

    module = Module()
    module.params = {
        'gather_subset': ['!all', 'network', 'virtual'],
        'filter': 'ansible_.*',
        'gather_timeout': 5
    }

    facts_dict = ansible_facts(module, gather_subset=['!all', 'network', 'virtual'])
    assert facts_dict
    assert 'ansible_all_ipv4_addresses' in facts_dict, 'Expected all_ipv4_addresses in facts'



# Generated at 2022-06-20 17:02:12.657269
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.distribution

    class FakeModule(object):
        def __init__(self):
            self.params = {'filter': '*'}

    module = FakeModule()

    fact_collector = ansible_facts(module)
    assert isinstance(fact_collector, PrefixFactNamespace) == True
    assert isinstance(fact_collector.collectors, list) == True
    assert isinstance(fact_collector.collectors[0], ansible.module_utils.facts.system.distribution.Distribution) == True


# Generated at 2022-06-20 17:02:20.292528
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.hardware import HardwareCollector
    from ansible.module_utils.facts import default_collectors

    original_dict = default_collectors.collectors

    # Replace default collector dict with a dict with a fake 'HardwareCollector'
    class FakeHardwareCollector(HardwareCollector):
        def collect(self, module=None, collected_facts=None):
            facts_dict = {}
            facts_dict['fake_hardware'] = 'fake_hardware_val'
            return facts_dict

    default_collectors.collectors = {'hardware': FakeHardwareCollector}

    # Create a mock module instance
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 17:02:26.683081
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['all'])
        )
    )
    fact_dict = get_all_facts(test_module)
    assert isinstance(fact_dict, dict)



# Generated at 2022-06-20 17:02:38.790218
# Unit test for function ansible_facts
def test_ansible_facts():
    import unittest2 as unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import AnsibleModuleMock

    class TestAnsibleFacts(unittest.TestCase):

        def setUp(self):
            '''This method sets up the test case.'''
            self.gather_subset = ['all']
            self.filter_spec = '*'
            self.gather_timeout = 10

# Generated at 2022-06-20 17:02:48.987776
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import os

    class FakeCollector(BaseFactCollector):
        def __init__(self, module, namespace, filter_spec, gather_subset, gather_timeout):
            pass

        def collect(self, module=None, collected_facts=None):
            return {
                'test_fact': 'test_value'
            }

    class FakeAnsibleModule():
        def __init__(self, params):
            self.params = params

    os.environ["ANSIBLE_COLLECTIONS_PATHS"] = "./collections"
    for gather_subset in ['!all', None, []]:
        params = dict(gather_subset=gather_subset)
        fake_module = FakeAnsibleModule(params)


# Generated at 2022-06-20 17:03:00.069643
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import gather_subset
    from ansible.module_utils.facts import gather_timeout
    from ansible.module_utils.facts import filter_spec
    from ansible.module_utils.facts import minimal_gather_subset
    from ansible.module_utils.facts.collector import BaseFactCollector

    # create mock 'anisble module'
    class MockAnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': gather_subset}

    class MockBaseFactCollector:
        def collect(module):
            return { "ansible_os_family": "RedHat" }

    # override default BaseFactCollector class
    orig_base_fact_collector = BaseFactCollector
    BaseFactCollector = MockBaseFact

# Generated at 2022-06-20 17:03:11.383499
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    module = AnsibleModule()
    module.params['gather_subset'] = '!all'
    gather_subset = module.params['gather_subset']
    assert isinstance(gather_subset, str)

# Generated at 2022-06-20 17:03:21.703713
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test ansible_facts function'''

    # Create a minimal ansible module argument spec
    argument_spec = dict(
        gather_subset=dict(type='list', default=['all']),
    )

    # Create a minimal ansible module
    dummy_module = AnsibleModule(argument_spec=argument_spec)

    # get facts
    facts = ansible_facts(dummy_module)

    # facts should be a dict (like a namespace)
    assert isinstance(facts, dict), "facts should be a dict, but is type %s" % type(facts)

    for fact in facts:
        assert isinstance(fact, str), "fact name '%s' is type %s" % (fact, type(fact))

# Generated at 2022-06-20 17:03:50.990704
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import get_all_collector_classes, NamespaceKeyError

    # create the module
    module = FakeAnsibleModule()

    # set params, then create the facts collector
    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'
    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    all_collector_classes = get_all_collector_classes()

    # don't add a

# Generated at 2022-06-20 17:04:00.486902
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # dummy module for testing - a subclass of AnsibleModule used for compat tests
    # receives an initializer kwargs, and simulates setting the kwargs as a module's params
    class DummyAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    # note mock_ansible_module.params is a dict
    mock_ansible_module = DummyAnsibleModule(filter='test_*', gather_timeout=10)

    ansible_facts(mock_ansible_module, gather_subset=['test_facts'])

    # check that default_collectors.collectors is the same as mock_ansible_module

# Generated at 2022-06-20 17:04:06.971333
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import FactsParams
    module_args = dict(
        gather_subset=[],
        gather_timeout=10,
        filter='*'
    )
    # Until we have a way to mock the module, just do this as a unit test instead of a functional test
    class DummyModule:
        def __init__(self, params):
            self.params = params
    module = DummyModule(module_args)
    facts = ansible_facts(module)
    assert facts is not None and len(facts) > 0

# Generated at 2022-06-20 17:04:17.507363
# Unit test for function get_all_facts
def test_get_all_facts():
     from ansible.module_utils.facts.namespace import PrefixFactNamespace
     from ansible.module_utils.facts import default_collectors
     from ansible.module_utils.facts import ansible_collector
     from ansible.module_utils._text import to_bytes, to_text
     from ansible.module_utils.six import PY3
     from ansible.module_utils.six.moves import shlex_quote
     from ansible.module_utils.urls import open_url
     from ansible.module_utils.urls import ConnectionError, SSLValidationError
     try:
         from __main__ import display
     except ImportError:
         from ansible.utils.display import Display
         display = Display()
     from ansible.module_utils.six.moves.urllib.parse import urls

# Generated at 2022-06-20 17:04:19.211225
# Unit test for function get_all_facts
def test_get_all_facts():
    # Unit test will be written when we can write a test for a 2.3 module which uses
    # this method.
    pass


# Generated at 2022-06-20 17:04:31.480054
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    import base64
    import platform
    import sys

    class TestModule:
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-20 17:04:33.878430
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts._vmware import vmware_distribution
    vmware_distribution()

# Generated at 2022-06-20 17:04:41.174076
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.platform
    from ansible.module_utils.facts import default_collectors
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.virtual

    module = FakeAnsibleModule()
    # make sure not already loaded from a previous test
    del module.params['gather_subset']
    del module.params['gather_timeout']

    gather_subset = ['all']
    result = ansible_facts(module, gather_subset=gather_subset)

    assert len(result) > 0, "Expected at least one fact, found none"

    # make sure ansible_architecture is present

# Generated at 2022-06-20 17:04:52.694976
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    import json

    # create a fake module for testing
    module_args = dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*'
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # call our local injector api
    facts_dict = ansible_facts(module, gather_subset=['all'])

    # test that all the facts injected by this module are there, with the correct values
    assert 'default_ipv4' in facts_dict
    # and so on...
    assert 'fips' in facts_dict
    assert facts_dict['fips'] is False


# Generated at 2022-06-20 17:05:03.022021
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import unittest

    class TestModule(object):
        def __init__(self, subset):
            self.params = {'gather_subset': subset}

    class TestAnsibleModule(object):
        def __init__(self, subset):
            self.params = {'gather_subset': subset}

    # gather_subset = 'all'
    test_module = TestModule(['all'])
    test_ansible_module = TestAnsibleModule(['all'])

# Generated at 2022-06-20 17:05:43.511191
# Unit test for function get_all_facts
def test_get_all_facts():
    pass

# Generated at 2022-06-20 17:05:53.102720
# Unit test for function get_all_facts
def test_get_all_facts():
    class Module(object):
        def __init__(self, params):
            self.params = params

    class AnsibleModule(object):
        def __init__(self, argument_spec):
            self.params = {}

    params = dict(gather_subset='!all,!min')

    module = Module(params=params)
    am = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    facts = ansible_facts(module=am)
    assert 'default_ipv4' in facts

    facts = get_all_facts(module)
    assert 'default_ipv4' in facts

# Generated at 2022-06-20 17:06:04.737727
# Unit test for function get_all_facts
def test_get_all_facts():
    import platform
    import ansible.module_utils.facts.collector.base
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.processor.platform
    import ansible.module_utils.facts.processor.pkg_mgr
    import ansible.module_utils.facts.processor.python
    import ansible.module_utils.facts.processor.sysctl
    import ansible.module_utils.facts.processor.service_mgr

    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = lambda **kv: kv

    # use all the default collectors, but have them return very simple facts

# Generated at 2022-06-20 17:06:15.587700
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_facts

    class MockSubsetModule(object):
        def __init__(self):
            self.params = dict(
                gather_subset=['all'],
                gather_timeout=10,
                filter='*',
            )

    mock_ansible_module = MockSubsetModule()

    facts = ansible_facts(mock_ansible_module)
    # test a few random facts to confirm they're present.
    assert facts['lsb']['id']
    assert facts['dns']['nameservers']
    assert len(facts['dns']['search']) > 0



# Generated at 2022-06-20 17:06:27.095274
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts.sysctl import SysctlFactCollector
    from ansible.module_utils.facts.system import SystemFactCollector
    from ansible.module_utils.facts.system import VirtualizationFactCollector
    from ansible.module_utils.facts.system import NetworkFactCollector

    # Create a FakeAnsibleModule instance
    import json
    module = FakeAnsibleModule(
        argument_spec=dict(),
        json_str='',
        bypass_checks=True,
    )

    # Gather facts

# Generated at 2022-06-20 17:06:36.140950
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.cache import FactsCache

    def side_effect_func(module, gather_subset=None):
        return {'ansible_all_ipv4_addresses': ['192.168.0.10', '10.0.0.1']}

    class FakeAnsibleModule(object):
        def __init__(self):
            self.params = {
                'gather_subset': 'all',
            }

    module = FakeAnsibleModule()
    facts_cache = FactsCache(module, [])
    facts_cache._ansible_facts = None
    facts_cache.ansible_facts = side_effect_func
    cmd = "ansible_facts = ansible_facts(module, gather_subset=module.params['gather_subset'])"
    exec

# Generated at 2022-06-20 17:06:45.706630
# Unit test for function ansible_facts
def test_ansible_facts():
    module = MockAnsibleModule()
    facts_dict = ansible_facts(module)
    assert isinstance(facts_dict, dict)
    assert len(facts_dict) > 0
    assert 'default_ipv4' in facts_dict
    assert 'lsb' in facts_dict
    assert 'lsb' in facts_dict
    assert 'distribution' in facts_dict
    assert 'distribution_version' in facts_dict
    assert 'distribution_major_version' in facts_dict
    assert 'dns' in facts_dict
    assert 'dns' in facts_dict
    assert 'date_time' in facts_dict
    assert 'python' in facts_dict
