

# Generated at 2022-06-20 16:56:58.130615
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collection import ansible_managed
    from ansible.module_utils.facts import ansible_version
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.facts.utils import get_file_lines, get_file_size

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, required=False, opt_dirs=None):
            return "/usr/bin/ansible"


# Generated at 2022-06-20 16:57:10.122182
# Unit test for function get_all_facts
def test_get_all_facts():
    '''compat api for ansible 2.2/2.3 module_utils.facts.get_all_facts method

    Expects module to be an instance of AnsibleModule, with a 'gather_subset' param.

    returns a dict mapping the bare fact name ('default_ipv4' with no 'ansible_' namespace) to
    the fact value.'''

    class FakeAnsibleModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}
            self.__dict__['_name'] = 'test_module'

    module = FakeAnsibleModule()

    # ansible 2.0 returned a dict, ansible 2.1/2.2/2.3 return an instance of AnsibleCollection
    returned = get_all_facts(module)

# Generated at 2022-06-20 16:57:14.013297
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic
    m = basic.AnsibleModule(argument_spec=dict(a='foo', b='bar'))
    m.params['gather_subset'] = ['network']
    facts = ansible_facts(m)
    assert isinstance(facts, dict)
    assert facts['default_ipv4']['addr'] == '127.0.0.1'
    assert facts['default_ipv4']['netmask'] == '255.0.0.0'
    assert facts['default_ipv4']['broadcast'] == '0.255.255.255'
    assert facts['default_ipv4']['network'] == '127.0.0.0'
    assert facts['default_ipv6']['addr'] == '::1'
    assert facts

# Generated at 2022-06-20 16:57:20.066583
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from unittest.mock import MagicMock, Mock
    import pytest

    AnsibleModule = Mock()

    class StateModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    def get_all_collector_classes():
        collectors = ['a', 'b', 'c']

        class_mock = Mock()
        class_mock.name = 'a'
        class_mock_b = Mock()
        class_mock_b.name = 'b'
        class_mock_c = Mock()
        class_mock_c.name = 'c'


# Generated at 2022-06-20 16:57:27.180661
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import ansible.module_utils.facts.system.distribution

    module = ansible.module_utils.facts.system.distribution.DistributionLinuxModule()
    gather_subset = ['!all']

    # Interpose our own private ansible_collector that returns a fixed set
    # of facts
    class FakeAnsibleCollector():

        def collect(self, module):
            return {'distribution': 'Ubuntu',
                    'distribution_version': '16.04',
                    'lsb': 'linux'}



# Generated at 2022-06-20 16:57:39.380868
# Unit test for function get_all_facts
def test_get_all_facts():
    #
    # Test cases
    #
    #  ansible_<name>:<value>

    # Get all facts
    get_all_facts(module=None)
    # Test 1
    # get all facts
    # Test 2
    # Test 3
    # Test 4
    # Test 5
    # Test 6
    # Test 7
    # Test 8
    # Test 9
    # Test 10
    # Test 11
    # Test 12
    # Test 13
    # Test 14
    # Test 15
    # Test 16
    # Test 17
    # Test 18
    # Test 19
    # Test 20


# Generated at 2022-06-20 16:57:43.457034
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    input_facts = {'gather_subset': ['all'], 'filter': '*'}
    output_facts = get_all_facts(AnsibleModule(argument_spec=input_facts))
    assert 'default_ipv4' in output_facts


# Generated at 2022-06-20 16:57:51.295972
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_legacy_facts_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import mock
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class AnsibleModuleMock(object):
        def fail_json(self, msg, **kwargs):
            self.fail_json_called = True
            self.failure_msg = msg


# Generated at 2022-06-20 16:57:58.494885
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        from ansible.module_utils.facts.namespace import PrefixFactNamespace
        from ansible.module_utils.facts import default_collectors
        from ansible.module_utils.facts import ansible_collector
    except ImportError:
        # is this a path issue?
        return

    # Collect tests
    # =============
    # Run all tests against a single, static set of facts.

    all_collectors = default_collectors.collectors

    from collections import namedtuple

    test_module = namedtuple('AnsibleModule', ['params'])

    # Argument processing
    # ===================

    # default params should be okay

# Generated at 2022-06-20 16:58:11.352506
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import os
    import unittest
    import tempfile
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import FactNamespace

    class FakeModule(object):
        def __init__(self, gather_subset=None,
                    gather_timeout=None,
                    filter_spec=None,
                    params=None):
            self.gather_subset = gather_subset or ['all']
            self.gather_timeout = gather_timeout or 10

            self.params = params or {}
            self.params['filter'] = filter_spec or '*'



# Generated at 2022-06-20 16:58:19.098266
# Unit test for function get_all_facts
def test_get_all_facts():
    import os
    import sys
    import json
    import inspect
    import pytest
    import ansible.module_utils.basic
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector

    from ansible.module_utils.facts import module as module_utils_facts_module
    from ansible.module_utils.facts import ansible_collector

    # import ansible module specific modules
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils._text import to_native, to_text
    if sys.version_info < (2, 7):
        pytest.skip("Test requires Python 2.7 or above")

    # class FakeModule(object

# Generated at 2022-06-20 16:58:25.235281
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.modules.system import setup_module as anssetup
    anssetup.init(load_params=False)

    # pass a mock module that responds to params as AnsibleModule would.
    # in particular, params['gather_subset']
    mock_module = mock.Mock(spec=ansible.module_utils.basic.AnsibleModule)
    mock_module.params = {'gather_subset': ['!all', 'network']}
    result = get_all_facts(mock_module)
    assert(result)

# This is for Python 2.4 support.

# Generated at 2022-06-20 16:58:26.064323
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-20 16:58:35.185184
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts import fact_collector
    from ansible.module_utils.basic import AnsibleModule

    # We are testing for the module_utils.ansible_collector function.
    # In order to get a valid list of collectors, we need a valid ansible_module_utils path.
    # This function, test_ansible_facts, is not in any particular module_utils package, so we will
    # set the ansible_module_utils path here.
    # Do not change the path to the ansible_module_utils.  Ansible module_utils are expected to be
    # found under /usr/lib/ansible/module_utils.
    # If you want to add module_utils to your list of collectors (to test them or to use them, do
    # so by adding them to AnsibleFactsCollector.

# Generated at 2022-06-20 16:58:46.103250
# Unit test for function get_all_facts
def test_get_all_facts():
    import imp, tempfile, os
    from ansible.module_utils.basic import AnsibleModule
    module_utils_path = tempfile.mkstemp(dir=os.path.dirname(__file__), suffix='.py')[1]

    with open(module_utils_path, 'w') as f:
        f.write('ANSIBLE_MODULE_ARGS={\'gather_subset\':[\'all\'], \'gather_timeout\':3}')

    test_module = imp.load_source('ansible_module', module_utils_path)
    test_module.AnsibleModule = AnsibleModule

    all_facts = get_all_facts(test_module.AnsibleModule)
    assert all_facts is not None
    assert 'all_ipv4_addresses' in all_facts

# Generated at 2022-06-20 16:58:53.247708
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import FactsError
    from ansible.module_utils import basic

    class FakeAnsibleModule(basic.AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(FakeAnsibleModule, self).__init__(*args, **kwargs)
            self.params = dict()

    facts = {}

    gather_subset = ['all']
    fake_module = FakeAnsibleModule()
    fake_module.params['gather_subset'] = gather_subset
    # this one should work and raise no exceptions
    facts = get_all_facts(module=fake_module)

    gather_subset = ['!all']
    fake_module.params['gather_subset'] = gather_subset
    # this one should not

# Generated at 2022-06-20 16:59:05.432039
# Unit test for function get_all_facts
def test_get_all_facts():

    import os
    import sys
    import tempfile
    import textwrap

    #
    # Mock up AnsibleModule and AnsibleMockTerminalAlert class, using a temp file to simulate
    # stdin and stdout
    #
    # (mocking stdin/stdout with a tempfile.TemporaryFile is not working.  Use tempfile.NamedTemporaryFile
    # instead)
    #

    import io
    from ansible.module_utils.facts import AnsibleMockTerminalAlert
    from ansible.module_utils.basic import AnsibleModule

    # TODO: change to use builtin mock once we're running ansible 2.4+
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # we need a file name for mocking stdin/stdout,

# Generated at 2022-06-20 16:59:13.538247
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import module_utils
    import ansible.module_utils.basic
    module_utils.HAS_DBUS = True
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    facts = ansible_facts(module)
    assert(facts['python']['version']['major'] == '2')

# Generated at 2022-06-20 16:59:26.248752
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from mock import Mock, patch
    from datetime import datetime

    now = datetime.utcnow().isoformat()

    module = Mock()
    module.params = { 'gather_subset': ['all'], 'gather_timeout': 10 }

    module.get_bin_path = Mock(return_value=now)

    all_collector_classes = ansible_collector._get_all_collector_classes()

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    filter_spec = '*'

# Generated at 2022-06-20 16:59:38.512406
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.namespace

    class FakeModule(object):
        params = {'gather_subset': ['min', 'hardware']}

    test_fact_collector = ansible.module_utils.facts.namespace.NamespaceCollector(namespace_name='foo')
    test_collector = ansible.module_utils.facts.namespace.NamespaceCollector(namespace_name='bar')

    class TestFactNamespace(ansible.module_utils.facts.namespace.Namespace):
        name = 'test'
        label = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'foo'}

    class TestFactCollector(ansible.module_utils.facts.namespace.NamespaceCollector):
        namespace_

# Generated at 2022-06-20 16:59:52.911827
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.collectors.network as network
    import ansible.module_utils.facts.collectors.platform as platform
    import ansible.module_utils.facts.collectors.distribution as distribution

    import mock
    import unittest


# Generated at 2022-06-20 17:00:05.560281
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test_get_all_facts() tests the new get_all_facts() function, which should be a drop in replacement for
    the ansible 2.2/2.3 ansible.module_utils.facts.get_all_facts() method.

    It does this by mocking out the AnsibleModule class, and the params dict, that get_all_facts is expecting,
    and mocks the declaration of the 'ansible_facts' AnsibleModule return value.

    Since get_all_facts returns a dict, we check to see if isinstance(dict) is true.

    Since get_all_facts calls ansible_facts, we mock that function too, returning a dict again.
    '''
    # Mock out AnsibleModule class, and params dict

# Generated at 2022-06-20 17:00:18.684304
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_file_lines
    from ansible.module_utils.facts.collector import register_collector
    from ansible.module_utils.facts.utils import get_collector_class
    import os

    class MockModule:
        def __init__(self):
            self.params = dict()

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = ['test_fact']

        def collect(self, module=None, collected_facts=None):
            collected_facts['test_fact'] = 111
            return collected_facts

    class TestCollector2(BaseFactCollector):
        name = 'test2'

# Generated at 2022-06-20 17:00:30.109905
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.modules.system.setup import is_final_default_impl
    import sys
    import os

    # This is the simplest way to mock a module object that we need for AnsibleModule
    test_module = type('AnsibleModule', (object,),
                       dict(params=dict(gather_subset=['all'])))()
    sys.modules['ansible'] = type('ansible', (), {})()
    sys.modules['ansible.module_utils'] = type('ansible.module_utils', (), {})()
    sys.modules['ansible.module_utils.facts'] = type('ansible.module_utils.facts', (),
                                                     dict(default_collectors=default_collectors))

    test_module.params['gather_subset']=['all']

# Generated at 2022-06-20 17:00:38.987503
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import mock

    class FakeCollector(BaseFactCollector):

        def collect(self, module=None, collected_facts=None):
            return {'foo': 'bar'}

    fc = FakeCollector(namespace=None)

    all_collector_classes = {
        'FakeCollector': fc
    }

    class FakeModule(object):
        def __init__(self, gather_subset=None, gather_timeout=None,
                     filter=None):
            self.params = mock.Mock()
            self.params.get.return_value = gather_subset
            self.params.get.return_value = gather_timeout
            self.params.get.return_value = filter


# Generated at 2022-06-20 17:00:48.554319
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.ansible_facts import get_all_facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import _variable_manager

    module_args = {'gather_subset': ['all']}

    _variable_manager.clear_facts()

    # ansible_facts added by fact_collector.collect() and fact_collector.get_facts()
    assert not _variable_manager.get_vars(loader=None, play=None, host=None).get('ansible_facts')

    # ansible_facts added by this unit test
    assert not _variable_manager.get_vars(loader=None, play=None, host=None).get('ansible_facts')


# Generated at 2022-06-20 17:01:00.123017
# Unit test for function get_all_facts
def test_get_all_facts():

    module_mock = MockModule()
    module_mock.params = {u'gather_subset': ['hardware']}

    facts = get_all_facts(module_mock)

    assert facts['architecture'] == 'x86_64'
    assert facts['fqdn'] == 'testhost.example.com'
    assert facts['memfree_mb'] == 125
    assert facts['memtotal_mb'] == 502
    assert facts['mounts'] == [{u'device': u'/dev/sdc1', u'filesystem': u'ext4', u'mount': u'/boot'},
                               {u'device': u'swap', u'filesystem': u'swap', u'mount': u'none'}]
    assert facts['vendor'] == 'RedHat'


# Unit

# Generated at 2022-06-20 17:01:09.764391
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.six import PY3

    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.fail_json = lambda *args: None
            self.exit_json = lambda *args: None

    class MockExitJson(object):
        def __init__(self):
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True

    class MockFailJson(object):
        def __init__(self):
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True

    # make sure library exists before calling it
    import module_utils.facts

    # test basic usage with no args
    module = MockModule()
   

# Generated at 2022-06-20 17:01:19.428100
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace as namespace_util

    def fake_module_class():
        class FakeClass():
            def __init__(self):
                self.params = {'gather_subset': ['all']}
        return FakeClass()

    class FakeAnsibleModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    class FakeFactCollector(object):
        def __init__(self, namespace_list, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            assert isinstance(namespace_list, list)
            assert isinstance(filter_spec, str)
            assert isinstance(gather_subset, frozenset)

# Generated at 2022-06-20 17:01:29.973937
# Unit test for function ansible_facts
def test_ansible_facts():

    import pytest
    from ansible import constants as C
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import dict_merge

    from ansible.module_utils import basic
    from ansible.module_utils.six import iteritems

    class TestAnsibleModule(object):
        def __init__(self, params):
            self.params = params

    class AnsibleModuleStub(object):
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-20 17:01:48.913920
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        from ansible.module_utils.facts import _get_plugin_class
        _get_plugin_class('apparmor').available()
    except Exception:
        # ansible.module_utils.facts is not a thing in 2.0/2.1
        return

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    all_collector_classes = default_collectors.collectors

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-20 17:02:01.282213
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import namespace
    import io

    # Mock up some AnsibleModule kwargs
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    gather_subset = ['network']
    gather_timeout = 10
    filter_spec = '*'

    all_collector_classes = default_collectors.collectors

    # don't add a prefix
    namespace = namespace.PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-20 17:02:09.253914
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    class FakeAnsibleModule(object):
        class Params(object):
            def __init__(self):
                self.gather_subset = ['!all']
                self.gather_timeout = 10
                self.filter = '*'
        params = Params()

    module = FakeAnsibleModule()

    facts_dict = ansible_facts(module, gather_subset=None)
    assert isinstance(facts_dict, dict)
    for fact_name in ['python', 'system', 'platform_linux', 'platform_distribution']:
        assert fact_name in facts_dict

# Generated at 2022-06-20 17:02:11.797571
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import module_utils.facts
    import ansible.module_utils.facts
    # ansible.module_utils.facts.ansible_facts = ansible_facts
    module = PrefixFactNamespace(namespace_name='ansible', prefix='')
    facts = module_utils.facts.get_all_facts(module)
    assert('ansible_fqdn' in facts)

# Generated at 2022-06-20 17:02:19.722510
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace
    import ansible.module_utils.facts.ansible_interpreter as interpreter
    import ansible.module_utils.facts.network as network
    import ansible.module_utils.facts.system as system
    import ansible.module_utils.facts.platform as platform
    import ansible.module_utils.facts.distribution as distribution
    import ansible.module_utils.facts.service_mgr as service_mgr
    import ansible.module_utils.facts.pkg_mgr as pkg_mgr
    import ansible.module_utils.facts.local as local
    import ansible.module_utils.facts.virtual

# Generated at 2022-06-20 17:02:21.343494
# Unit test for function get_all_facts
def test_get_all_facts():
    pass


# Generated at 2022-06-20 17:02:26.862340
# Unit test for function get_all_facts
def test_get_all_facts():

    def test_module(**kwargs):
        # Module class stub
        return type('AnsibleModule', (object,), kwargs)

    module = test_module(params={'gather_subset': ['all']})
    facts = get_all_facts(module)
    assert isinstance(facts, dict)



# Generated at 2022-06-20 17:02:29.842564
# Unit test for function ansible_facts
def test_ansible_facts():
    ansible_facts = ansible_facts(None)
    assert 'lsb' in ansible_facts, ansible_facts

# Generated at 2022-06-20 17:02:31.182424
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Verify the ansible_facts function is working as expected'''

    from ansible.module_utils.facts import ansible_facts

    assert ansible_facts is get_all_facts

# Generated at 2022-06-20 17:02:43.003749
# Unit test for function ansible_facts
def test_ansible_facts():

    # mock AnsibleModule so we don't need to have actual args to run the module
    class AnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode, bypass_checks):
            self.parameters = dict()
            self.check_mode = False
            self.params = dict()

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=False, bypass_checks=False)

    # test that running all collectors results in a dict with no None values
    facts = ansible_facts(module)

    for k, v in facts.items():
        assert v is not None, "{0} key returned a None value".format(k)

    # test that running all collectors and passing a gather_subset arg results in a dict
    # with no None values
    facts = ansible_facts

# Generated at 2022-06-20 17:03:11.051204
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import iteritems
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(argument_spec={})

    # The 'ansible_pkg_mgr' fact is one of a few that are not available on
    # Windows, so this is an easy way to test that we got the right platform.
    facts = ansible_facts(module=test_module)
    assert isinstance(facts['pkg_mgr'], type('' if PY2 else str))

    # get_all_facts() is a compat wrapper for ansible_facts(), so test that too.
    facts = get_all_facts(module=test_module)

# Generated at 2022-06-20 17:03:21.515998
# Unit test for function get_all_facts
def test_get_all_facts():
    # AnsibleModule requires these args and kwargs to be present
    argspec = dict(
        gather_subset=dict(required=True),
        gather_timeout=dict(required=True)
    )
    params = dict(
        gather_subset=['network'],
        gather_timeout=10
    )

    # mock AnsibleModule object
    class FakeAnsibleModule:
        def __init__(self, argspec, params):
            self.params = params

    module = FakeAnsibleModule(argspec, params)

    all_facts = get_all_facts(module)

    # all_facts will be a dict mapping fact name like 'ansible_eth0' to its value
    assert isinstance(all_facts, dict)
    assert 'ansible_eth0' in all_facts


# Unit test

# Generated at 2022-06-20 17:03:27.649096
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.test.test_get_all_facts_module import TestGet_all_facts
    from ansible.module_utils.facts import dict_merge

    test_module = TestGet_all_facts()

    gather_subset = ['!all', 'network']

    expected_all_facts = ansible_facts(module=test_module, gather_subset=gather_subset)
    actual_all_facts = get_all_facts(module=test_module)

    assert actual_all_facts == expected_all_facts, \
           'get_all_facts did not return the expected facts.  Expected: %s  Actual: %s' % \
           (expected_all_facts, actual_all_facts)


# Generated at 2022-06-20 17:03:39.407782
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import get_distribution
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.utils import is_executable
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import default_collectors


# Generated at 2022-06-20 17:03:40.786430
# Unit test for function get_all_facts
def test_get_all_facts():
    # TODO: write unit tests
    pass

# Generated at 2022-06-20 17:03:50.140925
# Unit test for function get_all_facts
def test_get_all_facts():

    # mock module instance
    class MockModule(object):

        def __init__(self, params=None):
            self.params = params or {}

    # test that gather_subset is correctly added to params
    module = MockModule()
    get_all_facts(module)
    assert 'gather_subset' in module.params

    # test that specified gather_subset is passed to ansible_facts()
    module = MockModule(params={'gather_subset': ['!all']})
    get_all_facts(module)
    assert ansible_facts(module, gather_subset=['!all']) == ansible_facts(module, gather_subset=['!all'])


# Generated at 2022-06-20 17:04:01.280901
# Unit test for function get_all_facts
def test_get_all_facts():
    import datetime
    from ansible.module_utils.facts.collector import FactsCollector

    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockAnsibleModule:
        def __init__(self, params):
            self.params = params

    class MockFactsCollector:
        def __init__(self, fact_dict):
            self.fact_dict = fact_dict

    class MockFactCollector(FactsCollector):
        def collect(self, module=None, collected_facts=None):
            return self.fact_dict

        def get_filesystem_facts(self, module):
            return self.fact_dict['filesystem']

    # test with all default parameters
    # in this case we expect the '

# Generated at 2022-06-20 17:04:03.538254
# Unit test for function get_all_facts
def test_get_all_facts():
    test_module = MockAnsibleModule(params={'gather_subset': ['!all', 'network']})
    test_fa

# Generated at 2022-06-20 17:04:06.971746
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic
    module_args = {'gather_subset': 'all', 'gather_timeout': 1}
    module = basic.AnsibleModule(argument_spec=module_args)
    assert get_all_facts(module) == ansible_facts(module)



# Generated at 2022-06-20 17:04:17.545121
# Unit test for function ansible_facts
def test_ansible_facts():
    import mock_module_util
    import ansible.module_utils.facts.collector.docker as docker_collector
    from ansible.module_utils.facts import namespace

    module = mock_module_util.AnsibleModule(argument_spec={'gather_subset': dict(default=['all'], type='list'),
                                                           'filter': dict(required=False, type='str'),
                                                           'gather_timeout': dict(default=10, type='int')},
                                            supports_check_mode=True)

    # TODO: Add tests for things that aren't just in the global namespace
    # test with multiple gather_subsets
    filter_spec = 'd*'
    ansible_collector.get_ansible_collector = mock_get_ansible_collector()

# Generated at 2022-06-20 17:05:01.687945
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.network.ios
    module_utils = ansible.module_utils.facts.network.ios
    import ansible.module_utils.facts.network.ios.ios_facts
    module = ansible.module_utils.facts.network.ios.ios_facts.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list')
        ),
        supports_check_mode=False,
        bypass_checks=False
    )
    module.params['gather_subset'] = ['!config']
    ansible_facts = ansible.module_utils.facts.get_all_facts(module=module)
    print(ansible_facts)


# Generated at 2022-06-20 17:05:13.235783
# Unit test for function get_all_facts
def test_get_all_facts():
    import collections
    import sys

    class AnsibleModule(collections.namedtuple('AnsibleModule', ['params'])):
        '''mock for AnsibleModule'''

    gather_subset = '!all,network'

    module = AnsibleModule(params={'gather_subset': gather_subset})

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestGetAllFacts(unittest.TestCase):
        '''unit tester for module_utils.facts.ansible.get_all_facts'''

        def test_get_all_facts(self):
            all_facts = get_all_facts(module)

            self.assertIsInstance(all_facts, dict)

    unittest

# Generated at 2022-06-20 17:05:25.316536
# Unit test for function get_all_facts
def test_get_all_facts():

    import sys
    import pytest
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector

    mock_gather_subset = {
        '!all': [],
        'all': ['all', 'foo'],
        'lorem': ['bar'],
        'foo': ['foo'],
        'bar': ['bar', 'spam'],
        'spam': ['eggs'],
        'eggs': []
    }

    mock_gather_order = {
        'all': [],
        'foo': ['foo'],
        'bar': ['bar', 'spam', 'eggs'],
        'spam': ['eggs'],
        'eggs': []
    }


# Generated at 2022-06-20 17:05:30.730222
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule(object):
        params = {}

    facts_dict = ansible_facts(FakeModule())

    assert facts_dict
    assert isinstance(facts_dict, dict)
    assert len(facts_dict.keys()) > 0

    for key in facts_dict:
        assert not key.startswith('ansible_')
        assert facts_dict[key] is not None

# Generated at 2022-06-20 17:05:42.489540
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.python

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.service_mgr import Service

# Generated at 2022-06-20 17:05:53.775178
# Unit test for function ansible_facts
def test_ansible_facts():
    import json

    import ansible.module_utils.facts.collectors.hardware.base as hardware_base
    import ansible.module_utils.facts.collectors.network.base as network_base
    import ansible.module_utils.facts.collectors.platform.base as platform_base
    import ansible.module_utils.facts.collectors.system.base as system_base
    import ansible.module_utils.facts.collectors.virtual.base as virtual_base

    from ansible.module_utils.facts import Collector

    class MockModule(object):
        params = {
            'gather_subset': ['hardware', 'network', 'platform', 'system', 'virtual'],
            'gather_timeout': 10,
            'filter': '*'
        }


# Generated at 2022-06-20 17:06:01.652755
# Unit test for function get_all_facts
def test_get_all_facts():

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.hardware
    # import ansible.module_utils.facts.network

    fact_collector = ansible.module_utils.facts.collector.get_fact_collector()
    fact_collector.collectors = [ansible.module_utils.facts.hardware.Hardware()]
    fact_collector.collect()
    # fact_collector.collectors = [ansible.module_utils.facts.network.Network()]
    # fact_collector.collect()
    fact_collector.populate()
    print (fact_collector.fact_cache)

# Generated at 2022-06-20 17:06:07.251923
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Unit test for function `get_all_facts`

    :return: ``True``
    :rtype: ``Boolean``
    '''

    print(get_all_facts())
    return True


# Generated at 2022-06-20 17:06:11.533145
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=None)})
    assert ansible_facts(module)



# Generated at 2022-06-20 17:06:24.930323
# Unit test for function get_all_facts
def test_get_all_facts():

    # Mock the module and its params
    class MockParams():
        def __init__(self):
            self.params = ['all']

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    def get_all_facts(module):
        '''compat api for ansible 2.2/2.3 module_utils.facts.get_all_facts method'''

        gather_subset = MockParams.params
        return ansible_facts(module, gather_subset=gather_subset)
