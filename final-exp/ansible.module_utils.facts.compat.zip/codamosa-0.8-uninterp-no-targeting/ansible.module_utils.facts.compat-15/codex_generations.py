

# Generated at 2022-06-20 16:56:48.548002
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-20 16:56:55.386550
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(gather_subset=dict()))
    module.params['gather_subset'] = ['all']
    facts = get_all_facts(module)
    assert facts['distribution'] == 'RedHat'


# Generated at 2022-06-20 16:57:09.007611
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import gather_subset_definitions
    from ansible.module_utils.facts import gather_facts_funcs
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import cache

    # empty cache
    cache.FACT_CACHE = {}

    # create an ansible module argspec mock
    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}

    # create an ansible_facts mock
    class AnsibleFactsMock(object):
        def __init__(self):
            self.gather_subset = None

# Generated at 2022-06-20 16:57:17.515149
# Unit test for function get_all_facts
def test_get_all_facts():

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # test with no gather_subset configured
    fm = FakeModule({})
    results = get_all_facts(fm)

    assert results['fqdn'] == 'foo.example.com'

    # test with gather_subset configured
    fm = FakeModule({'gather_subset': ['foo']})
    results = get_all_facts(fm)

    assert results['fqdn'] == 'foo.example.com'



# Generated at 2022-06-20 16:57:29.688278
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Test no collect
    module = FakeAnsibleModule(gather_subset=[])
    facts_dict = get_all_facts(module)

    assert facts_dict == {}

    # Test minimal collect
    module = FakeAnsibleModule(gather_subset=['!all', '!min'])
    facts_dict = get_all_facts(module)

    substr = {'local', 'date_time', 'pkg_mgr', 'platform', 'python', 'service_mgr', 'user'}
    assert substr.issubset(facts_dict.keys())

    # Test all collect
    module = FakeAnsibleModule(gather_subset=['all'])
    facts_dict = get_all_facts(module)

# Generated at 2022-06-20 16:57:42.607887
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import unittest

    if sys.version_info[0] == 2:
        from ansible.module_utils.facts import ansible_facts as ansible_facts_2
        from ansible.module_utils.facts import get_all_facts as get_all_facts_2
    else:
        from ansible.module_utils.facts import ansible_facts as ansible_facts_3
        from ansible.module_utils.facts import get_all_facts as get_all_facts_3

    class TestAnsibleFacts(unittest.TestCase):
        '''AnsibleFacts class'''

        def _get_ansible_facts(self):
            from ansible.module_utils.facts import get_all_facts
            return get_all_facts


# Generated at 2022-06-20 16:57:47.633278
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        from ansible.module_utils.facts.test.test_ansible_module import AnsibleModuleMock
    except ImportError:
        from ansible.module_utils.facts.test.test_ansible_module import AnsibleModuleMock

    module = AnsibleModuleMock(argument_spec={})
    facts = ansible_facts(module)
    assert isinstance(facts, dict)

# Generated at 2022-06-20 16:58:00.149272
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    # setup the test
    from ansible.module_utils.basic import AnsibleModule

    fake_module_args = {
        'gather_subset': ['all'],
        'gather_timeout': 10,
        'filter': '*',
    }

    # can't fully test ansible_facts without access to all the facts modules
    # (in test_module_utils/facts/modules).
    #
    # so just test that the function returns a non-empty dict, and that the
    # dict has an entry that most fact modules should supply.
    ansible_facts_dict = ansible_facts(AnsibleModule(argument_spec=fake_module_args))

    assert isinstance(ansible_facts_dict, dict)

# Generated at 2022-06-20 16:58:06.462106
# Unit test for function get_all_facts
def test_get_all_facts():
    ''' unit test for old api get_all_facts method '''
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create a new collector with a stub method for get_facts()
    class StubCollector(BaseFactCollector):
        def get_facts(self):
            return {'stub_foo': 'stub_bar'}

    # inject our stub collector into the ansible_facts collector map
    collectors_map = {'stub_collector': StubCollector}
    ansible_collector.FACT_COLLECTOR_MAP = collectors_map

    # A mock module to pass to get_all_facts()
    mock_module_params = {'gather_subset': ['stub_collector']}
   

# Generated at 2022-06-20 16:58:12.207103
# Unit test for function get_all_facts
def test_get_all_facts():
    import os
    os.environ['PATH'] = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    from ansible.module_utils.facts import get_all_facts
    module = None

    facts = get_all_facts(module)
    assert 'default_ipv4' in facts

# Generated at 2022-06-20 16:58:24.549372
# Unit test for function get_all_facts
def test_get_all_facts():
    '''unit test for get_all_facts'''

    import re

    import ansible.module_utils.facts
    from ansible.module_utils.facts import is_ipv6_enabled
    from ansible.module_utils import facts

    import ansible.module_utils.basic
    class FakeAnsibleModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self):
            arg_spec = dict()
            arg_spec['gather_subset'] = dict(default=['all'], type='list')
            super(FakeAnsibleModule, self).__init__(argument_spec=arg_spec)

    module = FakeAnsibleModule()
    ansible_facts_from_get_all_facts = get_all_facts(module)

    # test that the returned modules

# Generated at 2022-06-20 16:58:30.475494
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}
    module = FakeModule()
    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert len(facts) > 0


# Generated at 2022-06-20 16:58:39.166179
# Unit test for function get_all_facts
def test_get_all_facts():
    import pytest
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    class InnerAnsibleModule():
        def __init__(self):
            self.params = {'gather_subset': 'all'}

    def fail_json_fake(msg):
        pytest.fail(msg)

    def get_all_facts_fake(module):
        return {'fact1': 'value1', 'fact2': 'value2'}

    all_collector_classes = []

# Generated at 2022-06-20 16:58:41.986953
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=[])})
    facts = get_all_facts(module)
    assert facts is not None

# Generated at 2022-06-20 16:58:46.081951
# Unit test for function get_all_facts
def test_get_all_facts():
    test_module = ['all']
    result = get_all_facts(test_module)
    assert len(result) > 0


# Generated at 2022-06-20 16:58:53.249049
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Test for function get_all_facts'''
    from ansible.module_utils.facts.facts import AnsibleModule

    class MockModule(AnsibleModule):
        def __init__(self, *_, **kwargs):
            super(MockModule, self).__init__(*_, **kwargs)
            self.params = {
                'gather_subset': kwargs.get('gather_subset'),
                'gather_timeout': kwargs.get('gather_timeout'),
                'filter': kwargs.get('filter'),
            }

    module = MockModule(gather_subset=['all'], gather_timeout=10, filter='*')
    assert get_all_facts(module) == ansible_facts(module)


# Generated at 2022-06-20 16:59:05.432403
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.utils import get_collector_namespace
    from ansible.module_utils.facts.utils import prefix_collector_namespace

    from ansible.module_utils.facts.collector import AnsibleFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    import collections

    # Test get_all_facts calls with a Collector class that has no 'collect'
    # method It should wrap the class with an AnsibleFactCollector and then
    # collect.

# Generated at 2022-06-20 16:59:11.290759
# Unit test for function get_all_facts
def test_get_all_facts():
    module = MockAnsibleModule()
    module.params = dict(gather_subset=['all'])
    facts = get_all_facts(module)
    assert 'ansible_default_ipv4' in facts



# Generated at 2022-06-20 16:59:14.829141
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.script.script_rbac import ScriptModuleRbac

    module = ScriptModuleRbac()

    # make sure the 'ansible' namespace is not prefixed
    ansible_facts = get_all_facts(module)
    assert list(ansible_facts.keys()) == ['local', 'platform', 'distribution', 'python', 'platform_version',
                                          'system', 'manufacturer', 'processor', 'distribution_version',
                                          'distribution_release']

# Generated at 2022-06-20 16:59:26.542224
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.utils import get_all_collector_classes

    # ANSIBLE_CACHE_PLUGIN=memory
    cache_plugin = None
    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='ansible_')

    all_collector_classes = get_all_collector_classes()

    fact_collector = \
        ansible_collector.get_ansible_collector(all_collector_classes=all_collector_classes,
                                                namespace=namespace,
                                                filter_spec=filter_spec,
                                                gather_subset=gather_subset,
                                                gather_timeout=gather_timeout)

# Generated at 2022-06-20 16:59:33.324223
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.facts import get_all_facts
    print("get_all_facts ", get_all_facts)

# Generated at 2022-06-20 16:59:34.236226
# Unit test for function ansible_facts
def test_ansible_facts():
    # test with a module object
    # test with gather_subset != all
    pass

# Generated at 2022-06-20 16:59:47.284833
# Unit test for function get_all_facts
def test_get_all_facts():
    # Named a class with a dictionary to match AnsibleModule API
    class MyModule:
        def __init__(self, params):
            self.params = params

    class MyFactCollector:
        # Facts to return from this dummy fact collector
        # {bare_fact_name: fact_value}
        facts = {'default_ipv4': dict(interface='eth0', address='10.0.0.5')}

        def collect(self, module, collected_facts=None):
            return self.facts

    # Test a couple collect subsets
    cases = [
        ('all', MyFactCollector.facts),
        ('network', {})
    ]

    for gather_subset, expected_facts in cases:
        # Make a mock module
        params = {'gather_subset': gather_subset}
        module

# Generated at 2022-06-20 16:59:56.705281
# Unit test for function get_all_facts
def test_get_all_facts():

    # Create a 'ansible.module_utils.facts.ansible_facts.AnsibleModule' instance
    # obj that satisfies the expected args for get_all_facts

    class AnsibleModule(object):
        def __init__(self):

            self.params = dict(
                gather_subset=['all'],
                filter='*'
            )

    ansible_module = AnsibleModule()

    result = get_all_facts(ansible_module)

    assert result is not None

# Generated at 2022-06-20 17:00:05.227615
# Unit test for function get_all_facts
def test_get_all_facts():

    # Mock a module with default gather_subset
    mock_module = Mock(params=dict(gather_subset=None))
    facts = get_all_facts(mock_module)
    assert len(facts) > 0

    # Mock a module with specific gather_subset
    mock_module = Mock(params=dict(gather_subset=['platform']))
    facts = get_all_facts(mock_module)
    assert len(facts) > 0



# Generated at 2022-06-20 17:00:18.533019
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class TestCollector(BaseFactCollector):

        @classmethod
        def is_available(cls, *args, **kwargs):
            return True

    default_collectors.register(TestCollector)

    gather_subsets = ['min', '!min']
    gather_timeout = 10
    filter_spec = '*'

    def empty_module():
        return None

    for gather_subset in gather_subsets:
        fact_collector = \
            ansible_collector.get_ansible_collector

# Generated at 2022-06-20 17:00:29.673587
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_facts

    # Params for AnsibleModule
    module_params = dict(
        gather_subset=[],
    )

    # instance of AnsibleModule
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    # load facts
    all_facts = ansible_facts(module, gather_subset=['all'])

    # check minimum facts exist
    assert all_facts.get('default_ipv4')
    assert all_facts.get('distribution')
    assert all_facts.get('distribution_version')
    assert all_facts.get('distribution_major_version')
    assert all_facts.get('python')

# Generated at 2022-06-20 17:00:38.737704
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionGrains
    from ansible.module_utils.facts.system.distribution import LinuxDistributionMapper
    collect_ansible_facts = DistributionFactCollector
    collect_distribution = LinuxDistributionCollector
    distribution_grains = LinuxDistributionGrains
    distribution = LinuxDistribution
    distribution_mapper = LinuxDistributionMapper

# Generated at 2022-06-20 17:00:46.084154
# Unit test for function get_all_facts
def test_get_all_facts():

    # create an instance of AnsibleModule to set the gather_subset argument
    module = MagicMock()
    # gather_subset value is None if not set, so test that too
    module.params = {'gather_subset': None, 'gather_timeout': 10}
    assert get_all_facts(module) == {}



# Generated at 2022-06-20 17:00:57.915531
# Unit test for function ansible_facts
def test_ansible_facts():
    class _AnsibleModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    module = _AnsibleModule(gather_subset=['all'])
    facts = ansible_facts(module=module)
    assert facts['system']['distribution'] == 'RedHat'

    module = _AnsibleModule(gather_subset=['all_extensive'])
    facts = ansible_facts(module=module)
    assert facts['system']['distribution'] == 'RedHat'
    assert facts['virtualization']['role'] == 'guest'

    module = _AnsibleModule(gather_subset=['network'])
    facts = ansible_facts(module=module)

# Generated at 2022-06-20 17:01:17.656370
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''
    import ansible.module_utils.facts # this is a relatively new module and only available in Ansible 2.0+
    # The 2.0 module doesn't have the 2.3 get_all_facts func, so use the 2.1 module which does
    import ansible.module_utils.facts.facts as facts_module # pylint: disable=import-error
    import ansible.module_utils.facts.ansible_collector as ansible_collector_module # pylint: disable=import-error
    import mock

    class FakeAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = mock.Mock()
            self.fail_json = mock.Mock()


# Generated at 2022-06-20 17:01:23.825004
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.runtime_facts as module
    fact_dict = get_all_facts(module)

    assert isinstance(fact_dict, dict)

    assert 'processor' in fact_dict
    assert 'os_family' in fact_dict
    assert 'fqdn' in fact_dict


# Generated at 2022-06-20 17:01:32.633124
# Unit test for function get_all_facts
def test_get_all_facts():
    '''unit test for get_all_facts'''
    import os
    import sys
    import tempfile
    import shutil


# Generated at 2022-06-20 17:01:40.708069
# Unit test for function ansible_facts
def test_ansible_facts():
    test_module = mock_module()
    result = ansible_facts(test_module)
    assert 'distribution_version' in result
    assert 'env' in result
    assert 'system' in result
    assert 'network' in result
    assert 'python' in result
    assert 'dns' in result
    assert 'virtualization' in result
    assert 'distribution' in result
    assert 'pkg_mgr' in result
    assert 'date_time' in result
    assert 'service_mgr' in result
    assert 'default_ipv4' in result
    assert 'ipv6' in result
    assert 'cloud' in result
    assert 'selinux' in result
    assert 'os_family' in result
    assert 'architecture' in result
    assert 'lsb' in result
    assert 'system'

# Generated at 2022-06-20 17:01:48.174534
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import cache

    # create a mock ansible module
    import mock
    mock_module = mock.Mock()
    mock_module.params = {'filter': '*'}

    # use an empty cache
    cache._CACHE = {}

    facts = ansible_facts(mock_module)
    assert len(facts)
    assert 'distribution' in facts
    assert isinstance(facts['distribution'], dict)
    assert 'lsb' in facts
    assert isinstance(facts['lsb'], dict)

# Generated at 2022-06-20 17:01:48.729064
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-20 17:02:01.199472
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for get_all_facts function'''

    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        '''Fake module for testing'''

        class FakeParams:
            '''fake params for FakeModule'''

            def __init__(self, gather_subset='all'):
                self.gather_subset = gather_subset

        def __init__(self, gather_subset='all'):
            self.params = FakeModule.FakePar

# Generated at 2022-06-20 17:02:04.694296
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    facts = ansible_facts(module)
    assert facts['distribution'] == 'RedHat', facts

# Generated at 2022-06-20 17:02:17.794573
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespaceDict

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    fake_facts = {'default_ipv4': {'address': '1.1.1.1', 'interface': 'eth0'},
                  'os_version': '2.2.2',
                  'machine': 'fake_machine'}
    ansible_facts_dict_class = PrefixFactNamespaceDict(namespace=PrefixFactNamespace(namespace_name='ansible',
                                                                                     prefix=''),
                                                       facts_dict=fake_facts)

    assert ansible_facts_dict_class.get_

# Generated at 2022-06-20 17:02:29.610798
# Unit test for function ansible_facts

# Generated at 2022-06-20 17:02:45.172678
# Unit test for function get_all_facts
def test_get_all_facts():
    pass


# Generated at 2022-06-20 17:02:58.844569
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    To run this unit test and get a coverage report, run:
    coverage run -a test_ansible_facts.py
    (Requires installing the coverage package)

    To get a html report on the coverage, run:
    coverage html
    and open htmlcov/index.html in a browser to see the results
    '''
    import unittest
    from mock import Mock

    class TestAnsibleFacts(unittest.TestCase):
        '''
        Test that ansible_facts returns a dict mapping bare fact names to values
        '''

        def test_ansible_facts_module_requires_module_params(self):
            '''
            We expect the module passed to ansible_facts to have a params attribute
            '''
            with self.assertRaises(AttributeError) as context:
                ansible_

# Generated at 2022-06-20 17:03:04.267603
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test compat api for ansible 2.0/2.2/2.3 module_utils.facts.ansible_facts method'''

    from ansible.compat.tests.mock import patch, MagicMock
    import pytest

    mock_module = MagicMock()
    mock_module.params = {}
    mock_module.params['gather_subset'] = ['!minimal']

    class Namespace(object):
        def __init__(self, namespace_name, prefix):
            self.namespace_name = namespace_name
            self.prefix = prefix

    with patch.object(default_collectors, 'collectors') as mock_collector_classes:
        mock_collector_classes.__iter__ = MagicMock(return_value=[Namespace])


# Generated at 2022-06-20 17:03:12.564423
# Unit test for function get_all_facts
def test_get_all_facts():
    # pylint: disable=too-many-instance-attributes
    # Initialize module and args
    class ModuleArgs(object):
        def __init__(self):  # pylint: disable=useless-super-delegation
            super(ModuleArgs, self).__init__()
            self.params = {
                'filter': '*',
            }

    class AnsibleModule(object):
        def __init__(self):
            self.params = ModuleArgs().params

    from ansible.module_utils.facts.collector import Facts
    collector = Facts(filter_spec=self.params['filter'])
    result = collector.get_all_facts()

    # assert result is not None
    assert result is not None

    # assert get_all_facts returns a dict
    assert isinstance(result, dict)



# Generated at 2022-06-20 17:03:22.278420
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.ansible_collector as acol
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        '''Dummy class for testing ansible_facts'''
        def __init__(self, gather_subset, gather_timeout, filter_spec):
            self.params = dict()
            self.params['gather_subset'] = gather_subset
            self.params['gather_timeout'] = gather_timeout
            self.params['filter'] = filter_spec


# Generated at 2022-06-20 17:03:29.055545
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts as facts
    import ansible.module_utils.facts.distribution as distro_collector
    import ansible.module_utils.facts.network as network_collector

    # We want to mock out all the facts.

    # 1. mock the module and class imports
    facts.collectors = [distro_collector, network_collector]

    # 2. mock out the class methods
    distro_collector.DistributionCollector.collect = lambda self: {'distribution': 'RedHat', 'distribution_version': '6.7'}
    network_collector.NetworkCollector.collect = lambda self: {'default_ipv4': {"address": "192.168.1.1", "interface": "eth0"}}

    # 3. Create a fake ansible module

# Generated at 2022-06-20 17:03:39.813904
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import platform
    import ansible.module_utils.facts.platform

    # Use stub to make sure we are testing against the system platform
    # and not the platform we happen to be running the tests on.
    stub_platform = platform.system()

    class StubModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = self.__fail_json
            self.warn = self.__warn

        def __warn(self, msg):
            print(msg)

        def __fail_json(self, msg):
            self.warn(msg)
            sys.exit(1)
            return {}

    class StubFacts(object):
        def __init__(self):
            self.argspec = {}

        def get_all(self, module):
            return

# Generated at 2022-06-20 17:03:49.490893
# Unit test for function get_all_facts
def test_get_all_facts():
    # stub out the module class and params
    class Module:
        class ArgumentSpec:
            pass

    MockModule = Module()
    MockModule.params = {'gather_subset': ['all']}

    ansible_facts = get_all_facts(MockModule)
    # do some checks for expected results
    assert isinstance(ansible_facts, dict)
    # check for existence of all facts
    for k in ansible_facts:
        assert k in ['all', 'ansible_all', 'min', 'ansible_minimal']
    # check for existence of a specific fact
    assert 'ansible_hostname' in ansible_facts['all']['ansible_facts']

# Generated at 2022-06-20 17:04:00.957008
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Exercise ansible_facts compat api'''

    import os
    import sys
    import tempfile
    import pytest
    import textwrap
    from contextlib import contextmanager

    import ansible
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils import basic

    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    class MockAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    def get_ansible_module(**kwargs):
        return MockAnsibleModule(**kwargs)

    ansible_version = ansible.__version__


# Generated at 2022-06-20 17:04:10.738163
# Unit test for function get_all_facts
def test_get_all_facts():
    '''get_all_facts should set gather_subset to params['gather_subset'],
    then call ansible_facts() with the gather_subset arg set'''
    import sys
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'test_subset'}
        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

    class MockCollector(object):
        def __init__(self):
            self.collect_called = False

        def collect(self, module):
            self.collect_called = True
            self.collect_module = module
            return {'default_ipv4': 'default_ipv4_value'}

    mam = MockAnsibleModule()
    mc

# Generated at 2022-06-20 17:04:52.552741
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native, to_text
    from ansible.module_utils.facts.facts import ansible_facts

    class TestModule(object):
        def __init__(self, gather_subset=None, gather_timeout=None, filter=None):
            self.params = dict(gather_subset=gather_subset, gather_timeout=gather_timeout, filter=filter)

    m = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    module_facts = ansible_facts(m)
    assert isinstance(module_facts, dict)
    assert len(module_facts) > 0


# Generated at 2022-06-20 17:05:01.966379
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import timeout
    import mock
    import sys

    # need to mock out the import
    mock_module = mock.MagicMock()
    mock_module.params = {'gather_subset': ['all']}

    # mock out the timeout function - we don't want our tests to take a long time!
    original_timeout_func = timeout.timeout
    mock_timeout_func = mock.MagicMock()
    timeout.timeout = mock_timeout_func

    fact_collector = ansible_facts(module=mock_module)

    assert fact_collector

    # put timeout function back
    timeout.timeout = original_timeout_func

# Generated at 2022-06-20 17:05:13.306579
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.facts.test_collectors import (
        TestCollector,
        TestSubsetCollector,
        TestMinimalSubsetCollector,
    )

    import tempfile
    import os
    import shutil

    # setup test fixtures
    tempdir = tempfile.mkdtemp()
    tempdir_path = os.path.abspath(tempdir)
    test_fact_data = 'test_fact_data'
    test_fact_path = os.path.join(tempdir_path, test_fact_data)

# Generated at 2022-06-20 17:05:18.063437
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        from ansible.module_utils.facts import get_all_facts
    except ImportError:
        # if we're running in Ansible < 2.4, then there is no get_all_facts
        return

# Generated at 2022-06-20 17:05:27.488446
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.facts import get_default_collectors
    from ansible.module_utils._text import to_bytes

    class MockAnsibleModule(object):
        params = dict()

    module = MockAnsibleModule()

    module.params['gather_subset'] = ['all']
    module.params['gather_timeout'] = 10
    module.params['filter'] = '*'

    facts_dict = ansible_facts(module)

    # 'ansible_facts' is a default fact, it should be present
    assert 'ansible_facts' in facts_dict
    assert facts_dict['ansible_facts']['fact_collection_time'] >= facts_dict['ansible_facts']['collection_start_time']

# Generated at 2022-06-20 17:05:37.780581
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import unittest
    from ansible.module_utils import basic
    from ansible.module_utils.six.moves import StringIO

    test_json = '''{
        "argument_spec": { "gather_subset": {"default": "!all", "type": "list"} },
        "params": { "gather_subset": ["network", "all", "!facter"] }
    }'''

    class TestModule(object):
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-20 17:05:45.339767
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import get_all_files
    from ansible.module_utils.facts.collector import add_cache
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import pytest
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    os.environ['FACTS_CACHE_TIMEOUT'] = 0

    # stub out required AnsibleModule methods

# Generated at 2022-06-20 17:05:55.119624
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import CollectAllFactCollector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import collector

    import argparse
    import collections
    import copy
    import pytest
    import sys
    import types

    class FakeAnsibleModule(collections.defaultdict):
        def __init__(self):
            super(FakeAnsibleModule, self).__init__(dict)
            self.params = dict()


# Generated at 2022-06-20 17:06:03.418122
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    import os
    import json
    import tempfile
    from ansible.module_utils._text import to_bytes

    def get_test_module(test_params):
        return FakeAnsibleModule(test_params)

    test_params = {'gather_subset': ['all'],
                   'gather_timeout': 10}

    test_module = get_test_module(test_params)


# Generated at 2022-06-20 17:06:12.771539
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import FACT_CACHE

    FACT_CACHE.clear()

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    class TestAnsibleModule(object):
        def __init__(self):
            self.params = {}

    test_module = TestAnsibleModule()
    ansible_facts(module=test_module)
    FACT_CACHE.clear()

