

# Generated at 2022-06-20 16:56:58.399602
# Unit test for function get_all_facts
def test_get_all_facts():
    # As written, this test passes on a real 2.3 release
    from ansible.module_utils.facts import get_all_facts
    import ansible.module_utils.basic as mod

    class AModule(mod.AnsibleModule):
        def __init__(self):
            pass

    module = AModule()
    module.params = {'gather_subset': 'all'}

    all_facts = get_all_facts(module)

    # Check that we really did get some facts back
    assert len(all_facts) > 0

    # Check that the namespaced version of the fact exists
    assert all_facts['ansible_all_ipv4_addresses']

    # Check that the non-namespaced version of the fact exists
    assert all_facts['all_ipv4_addresses']




#

# Generated at 2022-06-20 16:57:10.509379
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.lsb as lsb
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr
    import ansible.module_utils.facts.system.platform as platform
    import ansible.module_utils.facts.system.service_mgr as service_mgr
    import ansible.module_utils.facts.system.user as user

    # create a mock module with a gather_subset arg
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    module = MockModule(params={'filter': '*', 'gather_subset': ['all']})

    # create a mock ansible_facts module with stubbed out fact

# Generated at 2022-06-20 16:57:11.995221
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''

    # TODO: figure out how to test this

# Generated at 2022-06-20 16:57:22.156524
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    assert get_all_facts.__code__.co_argcount == 1
    assert id(get_all_facts.__code__) == id(ansible_collector.get_all_facts.__code__)
    assert get_all_facts.__code__.co_consts[5] == PrefixFactNamespace.__name__
    assert id(get_all_facts.__code__.co_consts[11]) == id(default_collectors)
    assert id(get_all_facts.__code__.co_consts[12]) == id(ansible_collector)

#

# Generated at 2022-06-20 16:57:22.634141
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-20 16:57:29.176447
# Unit test for function ansible_facts
def test_ansible_facts():
    import tempfile
    import pytest
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.ansible_facts import ansible_facts
    from ansible.module_utils.facts import ansible_collector
    import ansible.module_utils.facts.ansible_facts


# Generated at 2022-06-20 16:57:42.396447
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        ''' fake module used for unit test of get_all_facts'''

        def __init__(self, params=None):
            self.params = params or {}

    fake_module = FakeModule(params={'gather_subset': ['network']})
    # we expect gather_subset to be network, and filter to be ipv4
    # we also expect to get a fact named 'changeme' in the ansible namespace

# Generated at 2022-06-20 16:57:47.180122
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Called when this module is imported.  Checks to see that
    the get_all_facts method is available.
    '''

    import ansible.module_utils.facts as facts_utils
    import ansible.module_utils.facts.system as system_facts

    assert hasattr(facts_utils, 'get_all_facts')

    # TODO: test the function



# Generated at 2022-06-20 16:57:56.891359
# Unit test for function get_all_facts
def test_get_all_facts():
    module = dict(version="2.1.1.0-1",
                  selinux=dict(status="enabled",
                               policy="targeted"),
                  ansible_selinux=dict(status="enabled",
                                       policy="targeted",
                                       mode="enforcing")
                  )

    facts_dict = get_all_facts(module)
    assert facts_dict == dict(selinux=dict(status="enabled",
                                           policy="targeted"))


# Generated at 2022-06-20 16:58:02.870538
# Unit test for function ansible_facts
def test_ansible_facts():
    '''tests for ansible_facts'''
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.processor
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.service

    import random
    import string

    #
    # Make a random identifier to use to fake a module name
    #
    rnd = ''.join(random.choice(string.ascii_uppercase + string.digits + string.ascii_lowercase) for _ in range(10))

    #
    # Build a fake module for testing
    #
    class FakeModule:
        def __init__(self):
            self.params = dict

# Generated at 2022-06-20 16:58:13.967889
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.default_collectors
    reload(ansible.module_utils.facts.default_collectors)
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts.collector.hardware import HardwareCollector,\
        gather_platform_facts, gather_distribution_facts

    def mock_collect(module):
        return {'architecture': 'x86_64'}

    ansible.module_utils.facts.default_collectors.HardwareCollector = HardwareCollector
    HardwareCollector.collect = mock_collect
    HardwareCollector.gather_platform_facts = gather_platform_facts
    HardwareCollector.gather_distribution_facts = gather_distribution_facts


# Generated at 2022-06-20 16:58:24.494103
# Unit test for function get_all_facts
def test_get_all_facts():

    ## Mock module and params ##

    class MockModule:

        def __init__(self, params):
            self.params = params

    class MockParams:
        def __init__(self, gather_subset=None, gather_timeout=10, filter=None):
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.filter = filter
            self.get = self.__getitem__

        def __getitem__(self, key):
            return getattr(self, key)

    mock_params = MockParams(gather_subset='fake_subset',
                             gather_timeout=10,
                             filter='fake_filter')
    mock_module = MockModule(mock_params)

    ## Mock fact collector ##


# Generated at 2022-06-20 16:58:34.798081
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    # Set up a class MimicAnsibleModule so we can use the get_all_facts() function which is normally
    # called by the AnsibleModule class.
    class MimicAnsibleModule():
        def __init__(self):
            self.params = {'gather_subset': ['platform', 'lsb', 'distribution'],
                           'gather_timeout': 5,
                           'filter': '*'}
    # Create instance of class MimicAnsibleModule.
    mimansmod = MimicAnsibleModule()
    # Call get_all_facts() using an instance of MimicAnsibleModule.

# Generated at 2022-06-20 16:58:45.936510
# Unit test for function ansible_facts
def test_ansible_facts():

    from .fixtures.mock_ansible_module import MockAnsibleModule

    module = MockAnsibleModule()


# Generated at 2022-06-20 16:58:48.890210
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.modules.system import setup
    module = setup.AnsibleModule(argument_spec={})
    facts_dict = get_all_facts(module)
    assert isinstance(facts_dict, dict)


# Generated at 2022-06-20 16:58:59.941931
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class TestModule():
        '''Fake AnsibleModule class'''

        def __init__(self, params):
            self.params = params

    test_gather_subset = ['all', 'network']
    test_params = {'gather_subset': test_gather_subset}
    test_module = TestModule(test_params)
    test_facts_dict = get_all_facts(module=test_module)

    # check that some expected ansible_facts are present
    assert 'distribution' in test_facts_dict
    assert 'os_family' in test_facts_dict


# Generated at 2022-06-20 16:59:06.511798
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.modules.system.setup

    setup_module = ansible.modules.system.setup.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all']),
        ),
        check_invalid_arguments=False,
    )

    facts_dict = ansible_facts(module=setup_module)
    assert isinstance(facts_dict, dict)
    assert 'ansible_local' in facts_dict

# Generated at 2022-06-20 16:59:09.581679
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test ansible_facts function'''

    # no gather_subset arg
    result = ansible_facts(module=object())
    assert isinstance(result, dict)

    # explicit gather_subset arg
    result = ansible_facts(module=object(), gather_subset=['min'])
    assert isinstance(result, dict)

# Generated at 2022-06-20 16:59:16.636537
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    import ansible.module_utils.facts.namespace
    module = ansible.module_utils.facts.namespace.AnsibleModule(
        argument_spec={})
    facts = get_all_facts(module)
    assert 'ansible_os_family' in facts, facts
    assert facts['ansible_os_family'] == "OpenBSD", facts
    assert 'ansible_facts' not in facts, facts


# Generated at 2022-06-20 16:59:26.624188
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.facts import ansible_facts

    module = AnsibleModule(argument_spec={
        "gather_subset": {"default": ['all'], 'type': 'list'},
        "gather_timeout": {"default": 10, 'type': int},
        "filter": {"default": "*", 'type': str}
    })

    all_facts = ansible_facts(module)
    assert len(all_facts) > 0

    filtered_facts = ansible_facts(module, gather_subset=['facter'])
    assert len(filtered_facts) > 0

# Generated at 2022-06-20 16:59:40.957482
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_str', 'test2_str'])

        def collect(self, module=None, collected_facts=None):
            return dict(test_str="this is a test", test2_str="this is another test")

    fact_collector = TestCollector()

    all_collectors = {
        'test': TestCollector,
        'network': NetworkCollector,
    }

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    gathered_facts = ansible_collector.get_ansible_collect

# Generated at 2022-06-20 16:59:51.763296
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.six import PY3

    module = DummyAnsibleModule(params={'gather_subset': 'all'})

    facts_dict = get_all_facts(module)

    assert facts_dict['ansible_facts'] is facts_dict
    assert facts_dict['ansible_version'] == __version__
    assert facts_dict['ansible_architecture'] == 'x86_64'
    assert facts_dict['ansible_python_version'] == '2.7.11'
    assert facts_dict['ansible_system'] == 'Darwin'
    assert facts_dict['ansible_distribution'] == 'Darwin'
   

# Generated at 2022-06-20 16:59:58.191414
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleModule
    import __builtin__
    try:
        __builtin__.__dict__['ANSIBLE_PYTHON_INTERPRETER'] = 'fake/python'
    except Exception:
        # py3.5 has already added the ANSIBLE_PYTHON_INTERPRETER to the builtins
        pass

    # mock out module_utils.network.common.get_default_interface() to return 'fake_interface'
    import ansible.module_utils.network.common

# Generated at 2022-06-20 17:00:08.402509
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts import ansible_collector

    test_module = MockAnsibleModule(params={'gather_subset': ['all']})
    test_filter_spec = '*'
    test_gather_subset = ['all']

# Generated at 2022-06-20 17:00:19.116510
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts
    import ansible.module_utils.facts.collector

    # clear all the collected facts
    if hasattr(ansible.module_utils.facts, 'FACT_CACHE'):
        del ansible.module_utils.facts.FACT_CACHE

    # stub out the ansible_facts function
    # so we can check what it would return if called without a gather_subset param
    # (which is the case in Ansible 2.0/2.1)
    ansible.module_utils.facts.ansible_facts = lambda: {'ansible_platform': 'FAKE_PLATFORM'}

    # default gather_subset should match what the stubbed out ansible_facts() call would return

# Generated at 2022-06-20 17:00:30.334381
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit test for ansible_facts function in compat module'''
    import os
    import sys

    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    import ansible.module_utils.basic
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual


# Generated at 2022-06-20 17:00:38.977478
# Unit test for function ansible_facts
def test_ansible_facts():
    class TestModule(object):
        def __init__(self, params):
            self.params = params

    def do_test(params, expected_facts):
        test_module = TestModule(params=params)
        test_facts = ansible_facts(module=test_module)
        assert test_facts == expected_facts

    # Test when gather_subset is not provided
    params = {'filter': 'ansible_*'}
    expected_facts = {'date_time': {'epoch': '1498158580', 'iso8601': '2017-06-24T13:16:20Z'}}
    do_test(params=params, expected_facts=expected_facts)

    # Test when gather_subset is provided

# Generated at 2022-06-20 17:00:48.519814
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Unit test for function get_all_facts
    '''
    import ansible.module_utils.facts.namespace as ns

    class MockModule(object):
        '''A fake AnsibleModule'''
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    # test
    # call get_all_facts with mocked module
    mock_module_1 = MockModule(['!all'])
    facts_dict_1 = get_all_facts(mock_module_1)
    assert 'os_version' not in facts_dict_1

    mock_module_2 = MockModule(['all', '!os'])
    facts_dict_2 = get_all_facts(mock_module_2)

# Generated at 2022-06-20 17:00:55.265162
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {
                'gather_subset': ['all'],
                'gather_timeout': 10,
            }

    module = MockModule()
    all_facts = get_all_facts(module)
    assert 'ansible_architecture' in all_facts

# Generated at 2022-06-20 17:01:05.951595
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    import sys

    import pytest
    from test.support.config_data import gather_subset_data
    from test.support.unit.mock import MagicMock

    module = MagicMock()

    @pytest.mark.parametrize('gather_subset', gather_subset_data)
    def test_get_all_facts_parametrize(gather_subset):
        # first test that we get back a dict for all of gather_subset values
        fact_dict = get_all_facts(module)
        assert isinstance(fact_dict, dict)
        # then test

# Generated at 2022-06-20 17:01:14.285365
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-20 17:01:26.036851
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import namespace

    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.facts.base import FactsBase
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.facts.default.default import Default

    # Mock out an AnsibleModule and the params for module_utils.facts.get_all_facts (backward compat)
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    module = Mock()

    # default gather_subset is all
    module.params = {'gather_subset': ['all']}

    # gather_subset=['all'] means to include all default collectors


# Generated at 2022-06-20 17:01:33.991366
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils import basic
    import ansible.module_utils.facts.collector.base
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.low_level


# Generated at 2022-06-20 17:01:41.058801
# Unit test for function ansible_facts
def test_ansible_facts():
    '''test the ansible_facts function, exercising the caller side of
    AnsibleFactsCollector

    For this test, patch AnsibleFactsCollector to return hardcoded results

    '''
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import default_collectors

    # we can't patch a class yet (https://bugs.python.org/issue23078) so patch module func
    def mock_facts(module, gather_subset=None):

        # assume caller passes in default values for collector args:
        # simple spec
        # all collectors
        # all same priority,
        # for both collection and filtering

        all_collector_classes = default_collectors.collectors
        namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

        expected_collect

# Generated at 2022-06-20 17:01:47.775202
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts.collector

    # set config params, just in case the calling module didn't do that
    ansible.module_utils.facts.collector.DEFAULT_GATHER_TIMEOUT=10
    ansible.module_utils.facts.collector.DEFAULT_GATHER_SUBSET=['all']

    class MockModule(object):
        def __init__(self):
            self.params = dict(gather_subset=[])

        def run_command(self, arg):
            return '1'

    mock_module = MockModule()

    facts_dict = ansible_facts(module=mock_module)


# Generated at 2022-06-20 17:01:55.144972
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={
        'gather_subset': {'type': 'list', 'default': ['!all', 'min']},
        'gather_timeout': {'type': 'int', 'default': 10},
        'filter': {'type': 'str', 'default': '*'},
    })

    # call the function
    result = get_all_facts(module)

    # validate the result
    assert isinstance(result, dict), "Result is not a dict"
    assert len(result) == 0, "Result is not empty"



# Generated at 2022-06-20 17:01:59.156090
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test_get_all_facts
    unit test for get_all_facts
    '''
    unittest.TestCase.assertEqual(get_all_facts, ansible_facts)



# Generated at 2022-06-20 17:02:07.594144
# Unit test for function get_all_facts
def test_get_all_facts():
    mock_module = MockAnsibleModule()

    expected_result = {'subset_test': 'subset_test',
                       'subset_test_1': 'subset_test_1',
                       'subset_test_2': 'subset_test_2',
                       'subset_test_3': 'subset_test_3',
                       'subset_test_4': 'subset_test_4',
                       'subset_test_5': 'subset_test_5',
                       'subset_test_6': 'subset_test_6'}

    result = get_all_facts(module=mock_module)

    assert expected_result == result



# Generated at 2022-06-20 17:02:18.717711
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_native
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FailsafeCollector, BaseFileGlobFactCollector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import os

    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr
    import ansible.module_utils.facts.system.platform as platform
    import ansible.module_utils.facts.system.user as user

    # This unit test

# Generated at 2022-06-20 17:02:27.969725
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' test_ansible_facts

    Unit test function for ansible_facts called with a list
    of fact names. This test is designed to fail if the
    ansible_facts function is called with kwargs and not a
    keyword argument list.
    '''

    from ansible.module_utils.basic import AnsibleModule

    ansible_facts('arg')

    try:
        module = AnsibleModule('arg')
        ansible_facts(module=module)
    except TypeError:
        # If the function was called with kwargs, a TypeError is raised
        assert False

# Generated at 2022-06-20 17:02:51.189291
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test the legacy get_all_facts compat API'''
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector.compat_collect import get_all_facts, ansible_facts
    from ansible.module_utils.facts.test.test_ansible_collector import FakeModuleArgs
    from ansible.module_utils.facts.test.test_ansible_collector import fake_get_file_content

    filter_spec = 'mocked'
    test_module = FakeModuleArgs(filter=filter_spec)

    fact_collector = \
        ansible_collector.get_ansible_

# Generated at 2022-06-20 17:03:00.744678
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.compat.tests import unittest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import shutil
    import tempfile

    class FakeAnsibleModule(object):
        def __init__(self, params={}):
            self.params = params
            self.fail_json = lambda **kwargs: None
            self.run_command = lambda **kwargs: None
            self.register_presence_option = lambda **kwargs: None

    class TestNetworkCollector(NetworkCollector):
        BOOTPROTO_FILE = 'bootproto'

# Generated at 2022-06-20 17:03:11.572518
# Unit test for function ansible_facts
def test_ansible_facts():
    '''this test method is not called by ansible, or by any tests.  It is intended to be used
    manually by a developer to test changes in this module.'''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(default=None, type='list'),
        gather_timeout=dict(default=10, type='int'),
        filter=dict(default='*', type='str'),
        test_param=dict(default='', type='str'),
    ))
    module_facts = ansible_facts(module)
    for fact_name, fact_value in module_facts.items():
        print('%s: %s' % (fact_name, fact_value))


if __name__ == '__main__':
    test_

# Generated at 2022-06-20 17:03:12.585024
# Unit test for function get_all_facts
def test_get_all_facts():
    assert callable(get_all_facts)


# Generated at 2022-06-20 17:03:22.266916
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for ansible_facts function'''
    import ansible.module_utils.facts.addon_facts

    class AnsibleModule:
        '''AnsibleModule compat class for unit test'''
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            '''fail_json compat method for unit test'''
            raise Exception('Unexpected failure')

    facts = ansible_facts(AnsibleModule())

    # assert that all required facts are present
    base_facts = ansible.module_utils.basic._load_params()
    for key in base_facts.keys():
        assert key in facts

    assert len(base_facts) < len(facts)

# Generated at 2022-06-20 17:03:29.827904
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts as facts
    import ansible.module_utils.facts.collector as collector
    import ansible.module_utils.facts.namespace as namespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import system
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes, to_text

    class FakeClass:
        def __init__(self):
            pass

    class FakeModule(FakeClass):
        def __init__(self):
            self.params = {}
            self.debug = False
            self.run_command = FakeClass()
            self.get_bin_path

# Generated at 2022-06-20 17:03:32.848216
# Unit test for function get_all_facts
def test_get_all_facts():
    # TODO
    pass

    def setUp(self):
        pass

    def tearDown(self):
        pass



# Generated at 2022-06-20 17:03:40.355132
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import module_facts_cache

    class FakeModule:
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': '!all'}
    module = FakeModule(params)

    all_facts = get_all_facts(module)

    if all_facts:
        # if module_facts_cache exists, then this function is using the new
        # ansible_collector module and ansible_collector module is working.
        assert module_facts_cache

# Generated at 2022-06-20 17:03:50.679731
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import unittest.mock as mock
    from ansible.module_utils import facts

    # Need to mock facts.__file__, otherwise it will try to load
    # ansible/module_utils/facts/resource_module/<filename>.py
    # and fail because we haven't copied over the <filename>.py files yet.
    module_utils_path = os.path.abspath(os.path.join(os.path.dirname(facts.__file__), '..', '..'))
    mock.patch.dict(
        facts.__dict__,
        {'__file__': os.path.join(module_utils_path, 'ansible', 'module_utils', 'facts.py')}
    ).start()

    import ansible.module_utils.facts.namespace

# Generated at 2022-06-20 17:04:01.472568
# Unit test for function ansible_facts
def test_ansible_facts():
    import mock
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    def fake_collect(self, module):
        return {'testing': 'unit testing', 'foo': 'bar'}

    class FakeFactCollector(BaseFactCollector):
        name = 'fake_fact_collector'
        _fact_ids = []

        def collect(self, module=None, collected_facts=None):
            return {'testing': 'unit testing', 'foo': 'bar'}

    class FakeCollector2(BaseFactCollector):
        name = 'fake_fact_collector2'


# Generated at 2022-06-20 17:04:42.087123
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors as dc
    from ansible.module_utils.facts import ansible_collector as ac

    module = AnsibleModule(argument_spec={'gather_subset': dict(type='str', default='all')})
    result = {}
    for collector in dc.collectors:
        result[collector] = {}
    result['ansible_local'] = {}
    result['ansible_local']['command_modules'] = ac.command_modules
    result['ansible_local']['inventory_sources'] = ac.inventory_sources
    result['ansible_local']['fact_cacheable'] = ac.fact_cacheable

# Generated at 2022-06-20 17:04:49.104739
# Unit test for function get_all_facts
def test_get_all_facts():
    class AnsibleModule:
        def __init__(self, params):
            self.params = params

    # Gather all the facts
    params = {"gather_subset": "all"}
    module = AnsibleModule(params)
    all_fact_dict = get_all_facts(module)

    # Make sure there's at least some facts populated
    assert len(all_fact_dict) > 10



# Generated at 2022-06-20 17:04:52.421487
# Unit test for function get_all_facts
def test_get_all_facts():
    # TODO: add unittest for get_all_facts
    pass


# Generated at 2022-06-20 17:05:02.196292
# Unit test for function get_all_facts
def test_get_all_facts():

    # NOTE: not adding a test for gather_subset because python3.5 doesn't support it
    # gather_subset would need to be 'all' in this case

    gather_timeout = 20

    test_module = _create_module_mock(gather_timeout=gather_timeout,
                                      gather_subset=None)

    facts = get_all_facts(test_module)

    assert 'system_platform' in facts
    assert facts['system_platform'] == 'foo'

    assert 'gather_subset' not in facts

    assert 'gather_timeout' in facts
    assert facts['gather_timeout'] == gather_timeout

    assert 'filter' not in facts



# Generated at 2022-06-20 17:05:13.408731
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts.system.apparmor import AppArmorFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector
    from ansible.module_utils.facts.system.capabilities import CapabilitiesFactCollector
    from ansible.module_utils.facts.system.selinux import SELinuxFactCollector
    from ansible.module_utils.facts.system.fips import Fips

# Generated at 2022-06-20 17:05:20.197109
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Test get_all_facts'''

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all'])})

    facts = ansible_facts(module)
    assert isinstance(facts, dict)

# Generated at 2022-06-20 17:05:30.716433
# Unit test for function ansible_facts
def test_ansible_facts():
    # import only for test
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    class AnsibleModuleStub(object):
        class params(object):
            gather_subset = ['all']
            gather_timeout = 10

    class CollectedFactStub(object):
        def __init__(self, name, value, origin='', version=1.0, raw_data=None):
            self.name = name
            self.value = value
            self.origin = origin
            self.version = version
            self.raw_data = raw_data

        def __repr__(self):
            return '<CollectedFact: %s = %s>' % (self.name, self.value)


# Generated at 2022-06-20 17:05:40.201256
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import utils
    from ansible.module_utils.facts.collector import BaseFactCollector

    # import mock
    import unittest

    import ansible.module_utils.facts.namespace

    ansible.module_utils.facts.namespace.ansible_prefix = \
        PrefixFactNamespace(namespace_name='ansible', prefix='ansible_')

    class ModuleTest(object):
        def __init__(self, params=None):
            self.params = params


# Generated at 2022-06-20 17:05:49.792176
# Unit test for function ansible_facts
def test_ansible_facts():
    # TODO: We do not have a way to unit test these yet.
    # So this is just an example unit test.
    # Real unit tests should be done once we have something
    # that shows what will be returned
    # and how we can get a module to test with
    # The code contains a place to put a breakpoint.
    # Right now it seems the code will run fine
    # if we just return False.
    print(ansible_facts(None))
    return False

# Generated at 2022-06-20 17:05:59.936136
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):
        '''Test double for an AnsibleModule'''
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['network', 'virtual']}
    ansible_module = FakeModule(params)
    facts = get_all_facts(ansible_module)
    assert facts['default_ipv4']['ipv4']['address'] == '192.168.208.1'