

# Generated at 2022-06-20 16:56:53.360600
# Unit test for function get_all_facts
def test_get_all_facts():
    """Test get_all_facts function returns dict of ansible facts"""
    module = MockAnsibleModule()
    facts = get_all_facts(module)
    assert isinstance(facts, dict)


# Generated at 2022-06-20 16:57:00.023471
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import search_dict_equality
    from ansible.module_utils.facts import ansible_module
    from ansible.module_utils.facts import default_collectors


    # create an instance of an AnsibleModule, with state and config args.
    fake_module = ansible_module('fake_module', state={}, config={})

    # test calling ansible_facts, with minimal args
    # should return all 'minimal' facts.
    #
    # minimal facts are:
    # apparmor
    # caps
    # cmdline
    # date_time
    # distribution
    # dns
    # env
    # fips
    # local
    # lsb
    # pkg_mgr
    # platform


# Generated at 2022-06-20 16:57:09.038564
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    This tests the ansible_facts function with the bare minimum set of all_collector_classes
    to get it working.
    '''

    # Create a minimal mock instance of an AnsibleModule
    class MockAnsibleModule:
        def __init__(self, params):
            self.params = params

    module = MockAnsibleModule({'gather_subset': ['all'], 'filter': '*'})

    # Create a minimal mock for the ansible.module_utils.facts.namespace.PrefixFactNamespace class
    class MockPrefixFactNamespace:
        def __init__(self):
            pass

        def populate(self):
            pass

    # Create a minimal mock for the ansible.module_utils.facts.collector.BaseFactCollector class

# Generated at 2022-06-20 16:57:19.187588
# Unit test for function ansible_facts
def test_ansible_facts():
    '''test the ansible_facts compat api'''
    # mock out module and collect
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual

    import inspect
    import tempfile

    # pylint: disable=unused-variable
    @staticmethod
    def mock_module_setup(module):
        '''Mock out module.run_command'''
        import os
        import socket

        def mock_run_command(command):
            '''Mock out module.run_command'''
            # hostname
            if command.strip() == 'hostname' and 'ansible_' not in command:
                return 0, 'localhost', ''
            # whoami (current user)

# Generated at 2022-06-20 16:57:26.467695
# Unit test for function ansible_facts
def test_ansible_facts():
    import tempfile
    import shutil
    import os
    import sys
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    # this test does not use a real ansible module, or actually run the ansible module_utils
    # it just uses the real system and filesystem
    # create a fake ansible module to use
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 16:57:33.502357
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_ansible_version
    from ansible.module_utils.basic import AnsibleModule

    if get_ansible_version() < '2.0':
        raise Exception("Unit test only supported for ansible version > 2.0")

    # use a mock module that uses the compat fact collection APIs
    # to collect facts via the compat fact collecting APIs for test purposes
    class MockModule(AnsibleModule):

        def __init__(self):
            super(MockModule, self).__init__()
            self.params = {
                'filter': 'ansible_distribution',
            }

    # the tested method
    test_app = MockModule()
    test_facts = ansible_facts(test_app)

# Generated at 2022-06-20 16:57:43.858998
# Unit test for function ansible_facts
def test_ansible_facts():
    import re
    import sys
    import traceback
    import unittest
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.default_collectors import (NetworkCollector, HardwareCollector)
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule():
        def __init__(self, gather_subset, filter_spec):
            self.params = {'gather_subset': gather_subset,
                           'filter': filter_spec}


# Generated at 2022-06-20 16:57:49.258214
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    mock_ansible_module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    facts_dict = ansible_facts(mock_ansible_module)

    # AnsibleModule must die with failure when gather_subset is not provided
    assert mock_ansible_module.fail_json.call_args[0] == (dict(msg='gather_subset is required'),)

    # Ensure the returned fact is a dictionary
    assert isinstance(facts_dict, dict)

    # Ensure the returned facts are in unicode format
    for _, fact in facts_dict.items():
        assert isinstance(fact, to_bytes)

# Generated at 2022-06-20 16:57:57.543832
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'gather_subset': {'default': None}})

    fact_dict = get_all_facts(module=module)

    assert 'default_ipv4' in fact_dict
    assert 'hostname' in fact_dict
    assert 'domain' in fact_dict
    assert 'fqdn' in fact_dict



# Generated at 2022-06-20 16:58:11.132496
# Unit test for function ansible_facts
def test_ansible_facts():
    class TestAnsibleModule:
        def __init__(self, params={}):
            self.params = params

    test_module_facts = {'facts_dict': {'myfact': 'myvalue'}}

    subset = ['all']
    module = TestAnsibleModule(params={'gather_subset': subset})
    facts = ansible_facts(module=module, gather_subset=subset)
    assert facts == test_module_facts

    subset = []
    module = TestAnsibleModule(params={'gather_subset': subset})
    facts = ansible_facts(module=module, gather_subset=subset)
    assert facts == test_module_facts

    subset = None
    module = TestAnsibleModule(params={'gather_subset': subset})
    facts = ans

# Generated at 2022-06-20 16:58:17.417021
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for module util get_all_facts method'''

    from ansible.module_utils.six import PY3
    if not PY3:
        import mock
        from ansible.module_utils.facts import get_all_facts as gaf

        module = mock.MagicMock()
        module.params = {'gather_subset': ['all']}

        res = gaf(module)
        assert isinstance(res, dict)



# Generated at 2022-06-20 16:58:21.051679
# Unit test for function get_all_facts
def test_get_all_facts():
    module = MockAnsibleModule()
    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert 'default_ipv4' in facts
    assert 'date_time' in facts


# Generated at 2022-06-20 16:58:28.528660
# Unit test for function ansible_facts
def test_ansible_facts():

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    module = TestModule({'filter': '*'})

    facts = ansible_facts(module)

    assert 'default_ipv4' in facts
    assert 'default_ipv4.interface' in facts


# Generated at 2022-06-20 16:58:35.734976
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import json
    import shutil
    import tempfile
    import pytest

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import default_collectors


# Generated at 2022-06-20 16:58:46.382094
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.local import Processor

    module = Facts()
    module.params = dict(
        filter='*',
        gather_subset=['!all', '!min'],
        gather_timeout=10
    )
    module.facts = {}
    module.gather_subset = module.params['gather_subset']
    module.gather_timeout = module.params['gather_timeout']

    # from ansible_facts
    module.filter = module.params['filter']
    if module.filter == '*':
        module.filter = None
    module.gather_subset = module.params['gather_subset']
    module.gather_timeout = module.params['gather_timeout']


# Generated at 2022-06-20 16:58:53.441941
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.lsb import LsbFactCollector
    from ansible.module_utils.facts import default_collectors

    class MockFactCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'mock': 'yes'}

    # save the original classes list in case other tests depend on it
    orig_collector_classes = default_collectors.collectors

    # temporarily replace the default collectors with a mocked collector
    # that just records 'mock':'yes'
    # so we don't

# Generated at 2022-06-20 16:59:01.955953
# Unit test for function get_all_facts
def test_get_all_facts():
    class Module:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    all_facts = get_all_facts(Module(gather_subset=['min', '!something', 'else']))
    assert isinstance(all_facts, dict)
    assert isinstance(all_facts, dict)
    assert len(all_facts.keys()) > 0



# Generated at 2022-06-20 16:59:09.935990
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts

    class FakeModule:
        pass

    # Test gather_subset=True (default)
    m = FakeModule()
    m.params = dict(gather_subset=True)
    fact_dict = get_all_facts(m)

    assert 'ansible' in fact_dict
    assert 'ansible_all_ipv4_addresses' in fact_dict['ansible']
    assert 'ansible_distribution' in fact_dict['ansible']

    # Test gather_subset=False
    m = FakeModule()
    m.params = dict(gather_subset=False)
    fact_dict = get_all_facts(m)

    assert 'ansible' in fact_

# Generated at 2022-06-20 16:59:17.394174
# Unit test for function get_all_facts
def test_get_all_facts():

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = dict()
            self.params['gather_subset'] = gather_subset

    fake_module = FakeModule(gather_subset=['all'])

    subset_facts_dict = get_all_facts(fake_module)

    assert subset_facts_dict['default_ipv4']['address'] in ['127.0.0.1', '::1'], \
        "Expected 'default_ipv4' fact to exist, but it does not"



# Generated at 2022-06-20 16:59:20.435207
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    ansible/test/unit/module_utils/test_facts.py
    :return:
    '''
    pass

# Generated at 2022-06-20 16:59:37.681115
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.test.test_platform_facts import MockModule

    # test ansible_facts with no gather_subset
    module = MockModule()
    module.params = dict(gather_subset=None)
    fact_collector = ModuleFacts.collector(module)

    assert fact_collector.gather_subset == module.params['gather_subset']

    # test ansible_facts with gather_subset
    module = MockModule()
    module.params = dict(gather_subset=['all'])
    fact_collector = ModuleFacts.collector(module)

    assert fact_collector.gather_subset == module.params['gather_subset']



# Generated at 2022-06-20 16:59:42.896642
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import NamespacePrefixDict
    from ansible.module_utils.facts import default_collectors

    mock_module_class = None
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.params['gather_timeout'] = 10

        def get_bin_path(self, *args, **kwargs):
            return 'something'
    sut_mod = MockModule(filter='*', gather_subset=['!all'])
    results = get_all_facts(sut_mod)
    assert results
    assert len(results) > 0
    assert isinstance(results, NamespacePrefixDict)
    assert len(results) == len(default_collectors.collectors)
   

# Generated at 2022-06-20 16:59:52.962438
# Unit test for function get_all_facts
def test_get_all_facts():
    # Create a mock module
    import ansible.module_utils.facts.namespace as facts_module
    import copy
    module = copy.deepcopy(facts_module.TEST_ANALOG_MODULE_PARAMS)
    module['gather_subset'] = 'network'
    import ansible.module_utils.facts.network as network_module
    network_module.get_all_ipv4_interfaces = lambda *args, **kwargs: {'ansible_em2': '192.168.14.1'}
    from ansible.module_utils.facts import default_collector
    default_collector.get_all_interfaces = lambda *args, **kwargs: {'all': set(['em2'])}

    facts_dict = get_all_facts(module)

# Generated at 2022-06-20 17:00:05.596516
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import fact_cache
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_module

    module = ansible_module.AnsibleModule(
                argument_spec=dict(
                    gather_subset=dict(default=['!all'], type='list'),
                )
            )

    # Cache the module so facts can be accessed
    fact_cache.module_cache_shared._module_cache[module] = AnsibleModuleProxy(module)

    # Setup gather_subset
    gather_subset = module.params.get('gather_subset', ['all'])

# Generated at 2022-06-20 17:00:18.713614
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils._text import to_native
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self):
            self.params = dict(gather_subset=['all'])
            self.gather_subset = ['all']

    module = MockModule()

    facts_dict = get_all_facts(module)

    # all the facts

# Generated at 2022-06-20 17:00:27.081733
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class AnsibleModuleMock():

        def __init__(self):
            self.params = {'gather_subset': ['all']}

    test_module = AnsibleModuleMock()
    # Gather facts and verify that it is not empty
    facts_dict = get_all_facts(test_module)
    assert facts_dict != {}



# Generated at 2022-06-20 17:00:37.502270
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts import __get_all_facts

    class TestNetworkCollector(NetworkCollector):

        def populate(self, module=None):
            super(TestNetworkCollector, self).populate(module=module)
            self.ansible_facts['test_network_facts'] = True

        def fact_namespace(self):
            return 'test_network'

    default_collectors.collectors.append(TestNetworkCollector)
    try:
        all_facts = __get_all_facts()
        assert 'test_network_facts' in all_facts['ansible_test_network']
    finally:
        default_collectors.collectors.pop()

# Generated at 2022-06-20 17:00:49.662808
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.network.default
    import ansible.module_utils.facts.cache
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.discovery
    import ansible.module_utils.facts.other
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.cloud
    import ansible.module_utils.facts.processor
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.python

    class MockedModule(object):

        def __init__(self, params):
            self.params = params

    mocked_collectors = default_collectors

# Generated at 2022-06-20 17:01:01.258283
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import FactsCollector

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)

    class FakeCollector(FactsCollector):
        def __init__(self, all_collector_classes):
            self.all_collector_classes = all_collector_classes
        def collect(self, module):
            return {'foo': 'bar'}

    module = FakeModule('all')
    temp_get_ansible_collector = ansible_collector.get_ansible_collector

# Generated at 2022-06-20 17:01:10.519768
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.network.linux import hardware as linux_iface_hw
    from ansible.module_utils.facts.network.linux import logic as linux_iface_logic
    from ansible.module_utils.facts.network.netbsd import hardware as netbsd_iface_hw
    from ansible.module_utils.facts.network.netbsd import logic as netbsd_iface_logic
    from ansible.module_utils.facts.network.openbsd import hardware as openbsd_iface_hw
    from ansible.module_utils.facts.network.openbsd import logic as openbsd_iface_logic
    from ansible.module_utils.facts.network.solaris import hardware as solaris_iface_hw

# Generated at 2022-06-20 17:01:29.932960
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.test_collector import TestAnsibleModule
    import sys
    import pprint
    kwargs = {}
    if sys.version_info[0] >= 3:
        from importlib import reload
        reload(sys)

    sys.setdefaultencoding('utf-8')
    if sys.version_info[0] < 3:
        import imp
        kwargs = {'fromlist': ['ansible.module_utils.facts.test_collector']}
        f, pathname, desc = imp.find_module('ansible.module_utils.facts.test_collector')
        test_ansible_module = imp.load_module('test_ansible_module', f, pathname, desc)
    else:
        import importlib
        spec = importlib.util.spec

# Generated at 2022-06-20 17:01:33.439779
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    fake_module = FakeModule({'gather_subset': ['!all', 'network']})
    facts = get_all_facts(module=fake_module)

    assert 'network' in facts
    assert facts['network']['interfaces'].keys()



# Generated at 2022-06-20 17:01:40.938917
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts as facts_m_u
    import sys
    import os
    import time

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'support'))
    from modules.unit.utils import set_module_args, AnsibleExitJson, AnsibleFailJson

    test_instance = AnsibleExitJson(dict(totally=dict(facts='are awesome')))
    test_instance._ansible_module.exit_json = lambda x: x
    test_instance._ansible_module.fail_json = lambda x: x
    set_module_args(dict(
        gather_subset=['!all'],
        gather_timeout=3
    ))

    # Can't just patch ansible_collector.get_ansible_

# Generated at 2022-06-20 17:01:51.118251
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    sys.modules['ansible'] = type('ansible', (object,), {})
    sys.modules['ansible.module_utils'] = type('module_utils', (object,), {})
    sys.modules['ansible.module_utils.facts'] = type('facts', (object,), {'ansible_collector': ansible_collector})
    sys.modules['ansible.module_utils.facts.collector'] = type('collector', (object,), {'FACT_SUBSETS': {'all': None}})
    from ansible.module_utils.facts import default_collectors
    default_collectors.collectors = [type('collector', (object,), {'collect': lambda self: {'ansible_lsbin' : '/usr/bin/ls'}})]()

# Generated at 2022-06-20 17:02:02.637548
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class MockFactCollector(BaseFactCollector):
        name = 'mock'
        def collect(self, module=None, collected_facts=None):
            self.collected_facts = {'ansible_foo': '1'}

    all_collector_classes = {'mock': MockFactCollector}

    filter_spec = '*'
    gather_subset = ['all']
    gather_timeout = 10

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-20 17:02:10.852642
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit tests for get_all_facts, specifically to ensure backward compatibility
    with the function signature of module_utils.facts.get_all_facts.

    get_all_facts requires the AnsibleModule to have a 'gather_subset' parameter.
    '''

    class DummyModule(object):
        pass

    module = DummyModule()
    module.params = {'gather_subset': ['all']}

    # call the method
    facts = get_all_facts(module)

    # validate the result
    assert 'default_ipv4' in facts
    assert 'distribution' in facts
    assert 'mounts' not in facts



# Generated at 2022-06-20 17:02:19.152571
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import FactsCollector

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, **kwargs):
            raise Exception("Exception encountered")

        def exit_json(self, **kwargs):
            raise Exception("Exception encountered")

    class MockCollector(FactsCollector):
        def __init__(self, namespace, **kwargs):
            self.namespace = namespace
            super(MockCollector, self).__init__(**kwargs)

        def collect(self, module):
            return {
                'gather_subset': module.params['gather_subset']
            }

    module = MockModule(params={
        'gather_subset': ['all']
    })



# Generated at 2022-06-20 17:02:30.116692
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace

    all_collector_classes = default_collectors.collectors
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    all_collector_classes_dict = {}
    for c in all_collector_classes:
        all_collector_classes_dict[c.name()] = c
    assert not ('fib' in all_collector_classes_dict)


# Generated at 2022-06-20 17:02:35.092426
# Unit test for function ansible_facts

# Generated at 2022-06-20 17:02:40.757904
# Unit test for function get_all_facts
def test_get_all_facts():
    module = FakeAnsibleModule()
    gather_subset = ['all']

    result = get_all_facts(module)
    assert result == ansible_facts(module, gather_subset=gather_subset)


# Generated at 2022-06-20 17:03:11.118985
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule(object):
        def __init__(self):
            pass

        def fail_json(self, **kwargs):
            pass

        def get_bin_path(self, executable, required=False, opt_dirs=None):
            pass

        def get_platform(self):
            pass


# Generated at 2022-06-20 17:03:21.553452
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors as dc
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from io import StringIO
    from sys import stdout

    # create a mock module object
    class MockModule:
        params = {}

    mock_module = MockModule()
    mock_module.params['gather_timeout'] = 5

    # create a mock collect method that returns a fixed set of facts
    def mock_collect_method(self, module):
        facts = {'fact1': 'value1',
                 'fact2': 'value2'}
        return facts



# Generated at 2022-06-20 17:03:29.256579
# Unit test for function ansible_facts
def test_ansible_facts():
    # Note this doesn't actually test the ansible_facts method as written, as that
    # method depends on AnsibleModule to be set up in a very specific way.
    # It does however ensure that the real test code will be executed.

    # Test the call to the fact collector which is the meat of this method.
    # We'll create a fake all_collectors, and fake the module args:

    # Make a fake module arg.
    module = type('module', (object,), {})()
    module.params = {}
    module.params['gather_subset'] = ['all']
    module.params['gather_timeout'] = 10
    module.params['filter'] = '*'

    # We use the default_collectors module as it contains most of the facts.
    # We do however have to monkeypatch some of the methods to ensure they

# Generated at 2022-06-20 17:03:34.905405
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test_get_all_facts()
    '''

    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors.system
    import ansible.module_utils.facts.collectors.cmdline
    import ansible.module_utils.facts.collectors.distribution
    import ansible.module_utils.facts.collectors.service_mgr
    import ansible.module_utils.facts.collectors.pkg_mgr
    import ansible.module_utils.facts.collectors.python
    import ansible.module_utils.facts.legacy
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 17:03:40.609198
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', required=False),
            gather_timeout=dict(type='int', required=False)
        )
    )

    module.params['gather_subset'] = []

    result = get_all_facts(module)
    assert result is not None
    assert len(result) > 0


# Generated at 2022-06-20 17:03:50.751492
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.urls import fetch_url
    import json
    import re

    # Mimic the logic in ansible/module_utils/facts/__init__.py
    # to set up a 'module' that looks like a real AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 17:03:58.701638
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.legacy

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)

    fake_module = FakeModule(['default_ipv4'])

    assert 'ansible_default_ipv4' in ansible_facts(fake_module)
    assert isinstance(ansible_facts(fake_module), dict)
    assert isinstance(ansible_facts(fake_module)['ansible_default_ipv4'], dict)



# Generated at 2022-06-20 17:04:10.017345
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for ansible_facts'''
    from ansible.module_utils.facts.collector.system.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.system.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.system.platform import PlatformCollector
    from ansible.module_utils.facts.collector import BaseFileReadCollector
    import ansible.module_utils.facts.collector
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})


# Generated at 2022-06-20 17:04:15.733191
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''
    import os
    import tempfile
    import ansible.module_utils.facts.system.distribution
    assert True
    # TODO: need to implement a unittest for function ansible_facts

# Generated at 2022-06-20 17:04:23.089771
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.ansible_facts as ansible_facts
    import fact_collector
    import mock

    # create a mock of AnsibleModule, simulating a 'gather_subset' param
    mock_module = mock.Mock()
    mock_module.params = {'gather_subset': ['all']}

    # create a mock of the fact_collector.get_fact_collector()
    @mock.patch.object(fact_collector, 'get_fact_collector')
    def _test_ansible_facts(mock_get_fact_collector):
        # set up a mock of the fact_collector.get_fact_collector() results
        # return a mock of fact_collector.FactCollector()
        mock_collector = mock.Mock()


# Generated at 2022-06-20 17:05:13.119698
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    if sys.version_info[0] == 2:
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleFacts(unittest.TestCase):
        def test_bare_facts(self):
            import ansible.modules.system.setup
            module = ansible.modules.system.setup.AnsibleModule(argument_spec=dict(
                gather_subset=dict(default='!all'),
                filter=dict(default='*'),
            ))
            facts = ansible_facts(module)
            assert 'all_ipv4_addresses' in facts
            assert 'default_ipv4' in facts
            assert facts['default_ipv4']['address'] == '192.0.2.1'

# Generated at 2022-06-20 17:05:18.891967
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.modules.system import setup
    from ansible.module_utils._text import to_bytes, to_native

    module = setup.AnsibleModule(argument_spec=dict(
        gather_subset=dict(default=['all'], type='list'),
        gather_timeout=dict(default=10, type='int')
    ))

    facts = get_all_facts(module)

    assert facts

    # from ansible.module_utils.facts import ansible_facts
    # from ansible.modules.system.setup import AnsibleModule
    # from ansible.module_utils._text import to_bytes, to_native
    #
    # module = AnsibleModule(argument_spec=dict(
    #     gather_subset=dict(default

# Generated at 2022-06-20 17:05:27.850947
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit test for ansible_facts function'''

    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.facts import default_collectors

    class TestModule(object):
        pass

    facts_dict = ansible_facts(TestModule())

    for collector_class in default_collectors.collectors:
        fact_name = collector_class.name()
        assert fact_name in facts_dict

    # ansible_facts returns a dict mapping the bare fact name ('default_ipv4' with no 'ansible_' namespace) to
    # the fact value.
    assert 'distribution' in facts_dict
    assert 'default_ipv4' in facts_dict

    # ansible_facts takes a gather_subset parameter.  So check the file system

# Generated at 2022-06-20 17:05:37.868854
# Unit test for function ansible_facts
def test_ansible_facts():

    class FakeAnsibleModule(object):
        class FakeModuleObject(object):
            def __init__(self, params):
                self.params = params

        def __init__(self, params):
            self.params = params

            self.fail_json = None
            self.exit_json = None

            self.check_mode = False

        @staticmethod
        def fail_json(msg):
            assert False

        @staticmethod
        def exit_json(msg):
            assert False

        def set_options(self, **kwargs):
            self.params = kwargs

    FakeModule = FakeAnsibleModule
    FakeAnsibleModule.AnsibleModule = FakeModuleObject

    module = FakeAnsibleModule({'gather_subset': ['all']})
    module.params['gather_subset']

# Generated at 2022-06-20 17:05:45.398198
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit test for ansible_facts function

    Creates dummy AnsibleModule object, and calls the ansible_facts function
    with it.
    '''

    # pylint: disable=too-few-public-methods
    class DummyAnsibleModule:

        def __init__(self, params=None):
            if params:
                self.params = params
            else:
                self.params = {}

    # test ansible_facts with no params
    module = DummyAnsibleModule()
    result = ansible_facts(module)

    # make sure we got back a python dict
    assert(isinstance(result, dict))
    assert('distribution' in result.keys())
    assert('distribution_version' in result.keys())
    assert('distribution_release' in result.keys())



# Generated at 2022-06-20 17:05:55.151457
# Unit test for function get_all_facts
def test_get_all_facts():
    import mock
    import sys
    import types

    #import module_utils.facts

    with mock.patch('ansible.module_utils.facts.get_all_facts') as mock_get_all_facts:
        # mock_get_all_facts.return_value = {'myfact' : {'mykey' : 'myvalue'}}
        mock_get_all_facts.return_value = {'mykey' : 'myvalue'}

        # mock_ansible_module = mock.Mock()
        # mock_ansible_module.configure_mock(params={'gather_subset' : 'all'})

        # module_utils.facts.get_all_facts(mock_ansible_module)
        mock_ansible_module = mock.Mock()

# Generated at 2022-06-20 17:06:05.448804
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.make

    # Module instantiation
    import ansible.module_utils.facts
    import ansible.module_utils.basic

    class SubsetModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self, subset):
            self.params = {'gather_subset': subset}
            super(SubsetModule, self).__init__(argument_spec={}, supports_check_mode=False)

    gs = ['!all', '!authorization', '!dns', '!hardware', '!network', '!virtual']

# Generated at 2022-06-20 17:06:16.978362
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    facts_dict = ansible_facts(module)

    # Without this assert the unit test would succeed with no assertion
    # https://www.owasp.org/index.php/Inputs_that_are_not_sanitized_before_being_used_as_a_command_in_the_system
    assert not facts_dict['lsb']['distro'] == "sh,'-c','rm'"

    # Make sure common facts are present
    assert facts_dict['distribution']
    assert facts_dict['distribution_version']

    # Make sure we find a network interface for the common device fact
    assert facts_dict['default_ipv4']['device']  # DEVNAME



# Generated at 2022-06-20 17:06:27.652058
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Unit test for function ansible_facts.

    This test requires the unit test framework in ansible 2.2+.
    '''
    try:
        from ansible.module_utils import basic
        from ansible.module_utils.facts import default_collectors
        from ansible.module_utils.facts import ansible_collector
    except ImportError:
        # not running under ansible 2.2+
        return

    # instantiate an AnsibleModule
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)

    # get a fact collector

# Generated at 2022-06-20 17:06:36.596498
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    import json

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    result = ansible_facts(module, gather_subset=['command', 'service', 'virtual'])
    result_keys = list(result.keys())
    result_keys.sort()
    print('result keys: %s' % json.dumps(result_keys))

    assert result['virtualization']
    assert isinstance(result['virtualization'], dict)
    assert 'guest_id' in result['virtualization']
    assert 'guest_type' in result['virtualization']
    assert 'host_type' in result['virtualization']
    assert 'product_name' in result['virtualization']