

# Generated at 2022-06-20 16:56:55.712964
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Test for get_all_facts
    '''
    class ModuleStub:
        def __init__(self):
            self.params = {}

    module = ModuleStub()
    module.params['gather_subset'] = ['all']
    result = get_all_facts(module)
    assert isinstance(result, dict), 'result is not a dictionary'


# Generated at 2022-06-20 16:57:09.213061
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # mock open_mock to raise error
    open_mock = lambda x,y :_open_mock(x,y)

    mock_builtin = {'open': open_mock,
                    '__builtin__': builtins if PY3 else __builtin__,
                    'ansible': __import__('ansible')}

    with mock.patch.dict('sys.modules', mock_builtin):
        from ansible.module_utils.facts import get_all_facts

        class AnsibleParams(object):
            module = {'params': dict(
                      gather_subset = ['network']
                     )}

            def __init__(self):
                self.module = self

# Generated at 2022-06-20 16:57:17.078985
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import namespace

    # Setup fake ansible module
    class FakeModule:
        def __init__(self, module_name, gather_subset):
            self.params = {'gather_subset': gather_subset}
            self.name = 'fake_ansible_module'

    # Setup fake ansible fact collector
    class FakeFactCollector(BaseFactCollector):
        def __init__(self, namespaces):
            super(FakeFactCollector, self).__init__(namespaces=namespaces)

        def collect(self, module=None):
            return {'ansible_test': 'test_value'}

    # Add fake ansible fact collector to

# Generated at 2022-06-20 16:57:20.245109
# Unit test for function ansible_facts
def test_ansible_facts():
    gather_subset = ['all']
    # results = ansible_facts(module, gather_subset)

# Generated at 2022-06-20 16:57:27.277401
# Unit test for function ansible_facts
def test_ansible_facts():
    FROM_HERE = '../unit/module_utils/facts/ansible_facts_unit_test'

    import sys
    import os
    import nose

    sys.path.append(os.path.join(os.path.dirname(__file__), FROM_HERE))

    from ansible_facts_unit_test import test_ansible_facts

    test_ansible_facts()

# Generated at 2022-06-20 16:57:40.743478
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    class MockModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}


# Generated at 2022-06-20 16:57:45.111595
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.basic import AnsibleModule

    def gather_facts():
        pass

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    module.run_command = gather_facts
    results = get_all_facts(module)
    assert isinstance(results, dict)
    assert 'distribution' in results.keys()


# Generated at 2022-06-20 16:57:53.367985
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test function ansible_facts(module)

    Test function returns a dict mapping fact name to value.
    Test it also works when called without 'gather_subset' arg
    '''
    import os
    import ansible.module_utils.facts.facts as facts
    import ansible.module_utils.facts.platform.linux as linux
    import ansible.module_utils.facts.platform.posix as posix
    import ansible.module_utils.facts.platform.sunos as sunos
    import ansible.module_utils.facts.system as system
    import ansible.module_utils.facts.utils as utils

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector

# Generated at 2022-06-20 16:58:01.990783
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector

    class MyNetworkCollector(NetworkCollector):
        def populate(self):
            self.facts['ansible_interfaces'] = ['lo', 'eth0']
            self.facts['ansible_default_ipv4'] = {'address': '10.0.0.9', 'network': '10.0.0.0'}

    class MyModule:
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['network']}
    module = MyModule(params)
    all_collectors = default_collectors.collectors
    all_collectors['network'] = MyNetworkCollector
    output = ansible_facts(module)

# Generated at 2022-06-20 16:58:12.420401
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.plugins.loader import module_loader
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.system

    # Insert test_collector into the dict of collectors, so it can be loaded for this test.
    ansible.module_utils.facts.collector.collectors['test_collector'] = \
        ansible.module_utils.facts.test_collector

    module = module_loader._load_module_source('setup', None, None)

    # Add gather_subset=['all'] param to module.params. What is not set here will default to
    # the module's default params for the gather_subset and gather_timeout params.
    # Here we are testing that the default params are used.
    module.params

# Generated at 2022-06-20 16:58:19.653497
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import module_utils
    module_utils.get_all_facts = get_all_facts

    from ansible.module_utils.facts import get_all_facts
    assert get_all_facts is get_all_facts



# Generated at 2022-06-20 16:58:33.135312
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.facts import DictFacts, Proxy
    from ansible.module_utils.facts.facts import _get_collector_classes_from_gather_subset
    import ansible.module_utils.facts.__main__ as main

# Generated at 2022-06-20 16:58:45.266720
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import module_utils, ansible_facts
    import os, tempfile
    # make a fake module object with params, which is what the ansible module would normally
    #   instantiate and pass to us
    class ModuleDummy(object):
        def __init__(self):
            self.params = {'gather_subset': ['all'], 'gather_timeout': 10, 'filter': '*'}
            # ansible_facts() will look at module.env.get('PYTHONINSPECT','') to decide if it's
            #  running under a debugger and shouldn't daemonize.  That check shouldn't be done
            #  in the unit test (which can't daemonize anyway), so let's disable the call to daemonize
            del self.params['gather_timeout']
   

# Generated at 2022-06-20 16:58:55.744452
# Unit test for function get_all_facts
def test_get_all_facts():
    os_module_path = '/usr/lib/python2.7/site-packages/ansible/modules/extras/bases/basic.py'
    my_module = imp.load_source('basic', os_module_path)
    module = my_module.AnsibleModule(argument_spec={'gather_subset': {'type': 'list','default': ['all']}})
    my_facts = get_all_facts(module)
    assert my_facts is not None
    for x in my_facts:
        assert type(my_facts[x]) is not None


# Generated at 2022-06-20 16:59:06.465990
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.facts import FactsBase
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import os

    class MockAnsibleModule(object):

        def __init__(self, name, args):
            self.debug = False
            self.async_timeout = 10
            self.check_mode = False
            # self.connection = None
            self.no_log = False
            self.no_log_values = list()
            self.fail_json = dict()
            self.exit_json = dict()
            self.params = args
            self._ansible_version

# Generated at 2022-06-20 16:59:08.492707
# Unit test for function get_all_facts
def test_get_all_facts():
    assert get_all_facts is not None

# Generated at 2022-06-20 16:59:18.522363
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Exercise compat shim to get_all_facts'''
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    from ansible.module_utils.facts.system.distribution import DistributionFact

    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector


# Generated at 2022-06-20 16:59:30.148041
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes

    class AnsibleModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    # In order to test code that needs "CAP_SYS_PTRACE", we need to run the test as
    # root. If we're not root and we can't run the test as root, skip the test
    # altogether.
    if not test_as_root():
        from nose.plugins.skip import SkipTest
        raise SkipTest('Skipping test because user is not root.')

    # test that it returns something
    module = AnsibleModule(None)

    import sys

# Generated at 2022-06-20 16:59:40.755700
# Unit test for function get_all_facts
def test_get_all_facts():
    '''unit test for get_all_facts'''

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class DummyFactCollector(BaseFactCollector):
        '''A dummy fact collector'''
        name = 'dummy'
        _fact_ids = ('dummy', 'gather_subset')

        def collect(self, module=None, collected_facts=None):
            '''Collect the facts'''

            # This is a simple version that just returns the gather_subset
            # which would typically be used to determine what data to collect.
            # This is just a toy example
            return {'dummy': self.gather_subset}


# Generated at 2022-06-20 16:59:49.528657
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_filter_specs

    # Check that this is the same as the ansible 2.3 version
    assert get_all_facts is ansible_facts
    # Check that this is the same as the ansible 2.2 version
    assert get_all_facts is ansible_facts



# Generated at 2022-06-20 17:00:04.253158
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(argument_spec={
        'filter': {'required': False, 'type': 'list', 'default': '*'},
        'gather_subset': {'required': False, 'type': 'list', 'default': ['all']},
        'gather_timeout': {'required': False, 'type': 'int', 'default': 10},
    })

    # test default arg values
    facts = ansible_facts(test_module)

    # test setting gather_subset
    facts = ansible_facts(test_module, ['min'])
    assert 'distribution' not in facts

# Generated at 2022-06-20 17:00:13.637607
# Unit test for function ansible_facts
def test_ansible_facts():
    import mock
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes

    class Module(object):
        def __init__(self):
            self.params = dict()

    module = Module()
    module.params['gather_subset'] = ['all']
    module.params['gather_timeout'] = 10

    facts_dict = ansible_facts(module, gather_subset=None)

    # the test is an example of how the function should be used.
    # Basically it ensures it does not fail.

    # ensure that the dns fact is present, as an example
    assert facts_dict.get('dns') is not None

    # ensure that at least one fact is present


# Generated at 2022-06-20 17:00:21.073705
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import _module_setup
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils import basic
    from ansible.module_utils.facts import default_collectors

    class TestFactCollector(BaseFactCollector):
        name = 'fact_name'
        priority = 10
        version = 1.2

        def collect(self, module=None, collected_facts=None):
            return {'fact_name': 'fact_value'}

    # Patch BaseFactCollector to make test_fact_collector the default collector
    default_collectors.collectors = [TestFactCollector]

    module = basic.AnsibleModule(argument_spec={})

    module.params['gather_subset'] = ['all']
    module.params

# Generated at 2022-06-20 17:00:31.817634
# Unit test for function ansible_facts
def test_ansible_facts():
    import platform
    import time
    import random

    # can't use unittest because python 2.6/2.7 compat, with no unittest.mock
    # Until we get rid of py2.6/py2.7 compat, use assert_equal, assert_true
    # rather than the more pythonic assertEqual, assertTrue

    # We'll make a mock AnsibleModule with the minimum required
    # params, to test the module_utils.get_all_facts call

    class AnsibleModule(object):
        def __init__(self, params):
            self.params = params
            self.called = False
            self.exit_json_return_value = None

        def exit_json(self, **kwargs):
            self.called = True
            self.exit_json_return_value = kwargs


# Generated at 2022-06-20 17:00:39.732102
# Unit test for function ansible_facts
def test_ansible_facts():
    facts = ansible_facts(base_module)

# Generated at 2022-06-20 17:00:49.127419
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils._text import to_bytes

    test_helper = AnsibleModuleTestHelper()

    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=None, type='list')
        )
    )

    facts = ansible_facts(test_module)

    assert isinstance(facts, dict)
    assert facts == test_helper.ansible_facts
    assert facts == dict((to_bytes(k), v) for k, v in test_helper.ansible_facts.items())



# Generated at 2022-06-20 17:01:00.716046
# Unit test for function get_all_facts
def test_get_all_facts():

    from unittest import TestCase
    from unittest.mock import Mock, patch

    class TestCollector(object):

        def __init__(self):
            self.params_run = None

        def collect(self, module, params):
            self.params_run = params

    class TestModule(object):

        def __init__(self):
            self.params = {'a': 'alpha', 'b': 'bravo', 'gather_subset': 'subset'}

    mock_collector_class = Mock()
    mock_collector_class.return_value = TestCollector()

    with patch('ansible.module_utils.facts.namespace.AnsiblePrefixFactNamespace') as mock_namespace_class:
        mock_namespace = mock_namespace_class.return_value

       

# Generated at 2022-06-20 17:01:10.168570
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.system.networking
    import ansible.module_utils.facts.system.distribution
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import ansible_collector

    class DummyModule:
        def __init__(self):
            self.params = {
                'gather_timeout': 0,
                'gather_subset': ['all'],
                'filter': '*'
            }

    cache.FACT_CACHE = None
    m = DummyModule()
    facts_dict = get_all_facts(m)

    assert 'ansible_all_ipv4_addresses' in facts_dict

    facts_dict2 = ansible_facts(m)


# Generated at 2022-06-20 17:01:20.924862
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.system.distribution
    def fake_module_params(gather_subset):
        return {'gather_subset': gather_subset}

    class FakeAnsibleModule():
        def __init__(self, test_module_set):
            self.module_set = test_module_set

        def params(self):
            return fake_module_params(test_module_set)

    # Case with gather_subset ALL
    test_module_set = ['all']
    fake_module = FakeAnsibleModule(test_module_set)
    fact_dict = get_all_facts(fake_module)
    ansible_system = fact_dict['system']
    ansible_distribution = ansible_system['distribution']

    # Check if distribution is correctly detected


# Generated at 2022-06-20 17:01:28.535327
# Unit test for function get_all_facts
def test_get_all_facts():

    import ansible.module_utils.facts.namespace
    ansible.module_utils.facts.namespace.PrefixFactNamespace = \
        lambda n, p: n

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector.file import FileCollector
    from ansible.module_utils.facts.collector.platform import PlatformCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector

    class MockModule():
        def __init__(self, params, facts_dict):
            self.params = params
            self.ansible_facts = facts_dict


# Generated at 2022-06-20 17:01:48.058787
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector.hardware import Hardware
    try:
        import test.support
    except ImportError:
        import unittest.mock as mock

    class FakeHardware(Hardware):
        platform = 'darwin'
        distribution = None
        osfamily = 'Darwin'
        release = None
        version = None

    orig_get_file_content = Hardware.get_file_content

    # stub out get_file_content to avoid accessing actual hardware
    @staticmethod
    def get_file_content(path):
        return '"model_name" : "Intel(R) Core(TM) i7-3615QM CPU @ 2.30GHz"\n'

    Hardware.get_file_content = get_file_content
    FakeHardware.get_file_content = get_file_

# Generated at 2022-06-20 17:02:00.013597
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    import mock

    # mock is a named tuple, subclassing tuple and defining __getattr__ to return a mock object.
    # so mock_module and mock_module.params can return mocks

    mock_module = mock.Mock(name='module')
    mock_module.params = {'gather_subset': ['all']}
    mock_module.params['filter'] = '*'

    mock_module.fail_json.side_effect = RuntimeError('fail_json called')

    all_collector_classes = mock.Mock(name='collector_classes')
    all_collector_classes.return_value = ['a_collector_class']

    mock_collect

# Generated at 2022-06-20 17:02:09.859127
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        from ansible.module_utils.facts import facts as facts_module
    except ImportError:
        return

    import ansible.module_utils.facts as facts
    from ansible.module_utils.facts import default_collectors, ansible_collector
    import ansible.module_utils.facts.normalizers as normalizers

    class ModuleMock(object):
        def __init__(self, params=None):
            self.params = params or {}

    class AnsibleModuleMock(ModuleMock):
        def __init__(self, params=None):
            super(AnsibleModuleMock, self).__init__(params)
            self.fail_json = self.fail_json_mock

        def fail_json_mock(self, **args):
            return args

    # collect all possible facts

# Generated at 2022-06-20 17:02:19.333105
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils._text import to_text

    # create a mock module
    mock_module = Mock()
    # set gather_subset
    mock_module.params = {'gather_subset': ['all']}
    # run function
    all_facts = get_all_facts(mock_module)
    # check that the functions returned successfully
    assert all_facts
    # check that ansible_lsb key exists and not empty
    assert all_facts['lsb'] != {}
    # check that ansible_lsb['codename'] exists and not empty
    assert all_facts['lsb']['codename'] != {}
    # check that ansible_lsb['description'] exists and not empty
    assert all_

# Generated at 2022-06-20 17:02:28.839749
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.dict_transformations import merge_dicts

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        params = {'gather_subset': ['!all', 'min']}

    # instantiate the module class
    module = FakeModule()

    # call get_all_facts
    facts = get_all_facts(module=module)
    assert len(facts['ansible_facts']) > 0



# Generated at 2022-06-20 17:02:39.463694
# Unit test for function get_all_facts
def test_get_all_facts():
    import os
    import sys
    from ansible.module_utils.facts import ansible_facts

    print(sys.modules.keys())
    file_path = os.path.realpath(__file__)
    print(file_path)
    file_name = os.path.split(file_path)[1]
    print(file_name)
    print(sys.modules[__name__])
    my_facts = ansible_facts(None)

    print(my_facts)
    print('cpu_count=', my_facts['cpu_count'])
    print('virtualization_role=', my_facts['virtualization_role'])


if __name__ == '__main__':
    test_get_all_facts()

# Generated at 2022-06-20 17:02:46.800487
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.utils import FactsCollector
    from ansible.module_utils.facts import ansible_collector

    # create a fake ansible_module
    class params(dict):
        gather_subset = ['min']
    class ansible_module(object):
        params = params()

    # create a fake FactCollector
    class fake_fact_collector(FactsCollector):
        def collect(self, module=None):
            return {'test': 'test'}
    ansible_collector.get_ansible_collector = lambda *args: fake_fact_collector()
    assert get_all_facts(ansible_module) == {'test': 'test'}

# Generated at 2022-06-20 17:02:59.446597
# Unit test for function ansible_facts
def test_ansible_facts():
    all_collector_classes = default_collectors.collectors

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    fact_collector = \
        ansible_collector.get_ansible_collector(all_collector_classes=all_collector_classes,
                                                namespace=namespace,
                                                filter_spec='*',
                                                gather_subset=['all'],
                                                gather_timeout=10,
                                                minimal_gather_subset=frozenset(['lsb']))

    # Patch module_utils.facts.ansible_collector.get_ansible_collector
    from ansible.module_utils.facts import ansible_collector

# Generated at 2022-06-20 17:03:05.800053
# Unit test for function ansible_facts
def test_ansible_facts():
    import mock
    module = mock.Mock()
    module.params = {
        'filter': '*',
        'gather_subset': ['all', 'network'],
        'gather_timeout': 10
    }
    assert ansible_facts(module)

# Generated at 2022-06-20 17:03:18.489696
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test function ansible_facts'''

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_text

    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.distribution as distribution2

    class DummyModule:
        params = {}

    module = DummyModule()

    for fact in ansible_facts(module=module).values():
        assert isinstance(fact, (basestring, Mapping))
        assert not isinstance(fact, to_text)

    # 2.3+ == 2.3.1+ == 2.4.0-dev
    import ansible.module_utils.facts.system.distribution as distribution3
    assert distribution.__version__ == distribution

# Generated at 2022-06-20 17:03:41.479660
# Unit test for function get_all_facts
def test_get_all_facts():
    module_mock = Mock()
    module_mock.params = {'gather_subset': ['all']}
    gathered_facts = {'hostname': 'bar_host'}
    m_collect = MagicMock()
    m_collect.return_value = gathered_facts
    with patch.dict('module_utils.module_utils_facts_ansible_2_2_3.ansible_collector.fact_collectors',
                    {'all': m_collect}):
        assert get_all_facts(module_mock) == gathered_facts
        m_collect.assert_called_once_with(module_mock)


# Generated at 2022-06-20 17:03:51.066499
# Unit test for function get_all_facts
def test_get_all_facts():
    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(type='list', default=['min', 'hardware', 'facter', 'ohai'])
    ))

    with patch.object(DefaultFactCollector, 'collect'):
        with patch.object(HardwareFactCollector, 'collect'):
            with patch.object(FacterFactCollector, 'collect'):
                with patch.object(OhaiFactCollector, 'collect'):
                    with patch.object(NetworkFactCollector, 'collect'):
                        get_all_facts(module)

    assert_equals(DefaultFactCollector.collect.call_count, 1)
    assert_equals(HardwareFactCollector.collect.call_count, 1)

# Generated at 2022-06-20 17:04:01.585655
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    # We need a ansible_module to test with, so let's build one
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'gather_subset': ['all']})

    # run the function
    facts_dict = ansible_facts(module)

    # verify it returns a dict
    assert isinstance(facts_dict, dict)

    # verify it has the right structure (all bare fact names, no namespace prefix)
    for key in facts_dict:
        assert key.startswith('ansible_') is False

    # verify it returns at least some facts
    assert 'distribution' in facts_dict
    assert 'distribution_release' in facts_dict
    assert 'distribution_version' in facts_dict

# Generated at 2022-06-20 17:04:11.246285
# Unit test for function get_all_facts
def test_get_all_facts():

    import ansible.module_utils.facts
    from ansible.module_utils.facts import _get_all_facts

    # 1. Test that the original function still works
    test_module = TestModule(get_all_facts=True)
    result = ansible.module_utils.facts.get_all_facts(test_module)
    assert result == {'default_ipv4': '2.2.2.2'}

    # 2. Test that the 2.3/2.4 api works
    test_module = TestModule(get_all_facts=True)
    result = _get_all_facts(test_module)
    assert result == {'default_ipv4': '2.2.2.2'}

    # 3. Test that the 2.1 api works

# Generated at 2022-06-20 17:04:19.512372
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)

    # Test with a dict gather_subset
    gather_subset = dict(gather_subset=['all'])
    module = FakeModule(gather_subset)
    facts = get_all_facts(module)

    assert(facts['architecture'])
    assert(facts['fqdn'])



# Generated at 2022-06-20 17:04:31.614622
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import pytest
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    class fake_module:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = None

    # test ansible_collector.get_ansible_collector()
    class TestCollector:
        name = "test"

        def collect(self, module=None, collected_facts=None):
            return collected_facts

    class TestCollector2:
        name = "test2"

        def collect(self, module=None, collected_facts=None):
            return collected_facts

    class TestCollector3:
        name = "test3"


# Generated at 2022-06-20 17:04:41.576548
# Unit test for function ansible_facts
def test_ansible_facts():

    import json
    import time
    import uuid
    import pytest

    import ansible.module_utils.facts.collector

    # don't run the collector, just fake out the data layer
    ansible.module_utils.facts.collector.FACT_CACHE = {'ansible_' + uuid.uuid4().hex: str(time.time()) for i in range(4)}

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all'])})
    module.gather_facts = lambda x: None

    facts = ansible_facts(module)

    assert len(facts) == 4

# Generated at 2022-06-20 17:04:43.470851
# Unit test for function ansible_facts
def test_ansible_facts():
    # can't test this in a unit test, since it requires running a function that requires a real
    # AnsibleModule instance

    # test that it returns dict mapping fact names with no ansible namespace to fact values
    # test that it does not return fact names with ansible namespace
    pass

# Generated at 2022-06-20 17:04:51.375307
# Unit test for function get_all_facts
def test_get_all_facts():

    gather_subset = ['all']

    class MockAnsibleModule(object):

        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    fake_module = MockAnsibleModule(gather_subset=gather_subset)

    facts_dict = get_all_facts(fake_module)
    assert facts_dict.get('distribution', '').startswith('RedHat')
    assert facts_dict.get('hostname') == 'foobar'



# Generated at 2022-06-20 17:04:58.535222
# Unit test for function get_all_facts
def test_get_all_facts():

    # facts.get_all_facts(module) expects a module object with a gather_subset param
    module_mock = {'params': {'gather_subset': ['all']}}
    facts = get_all_facts(module=module_mock)

    assert 'default_ipv4' in facts



# Generated at 2022-06-20 17:05:37.324522
# Unit test for function ansible_facts
def test_ansible_facts():
    # create a mock module object, with a mock 'ansible' param
    class MockModule:
        class MockAnsibleModule:
            def __init__(self, params):
                self.params = params

        def __init__(self, params):
            self.ansible_module = self.MockAnsibleModule(params)

    module = MockModule({'filter': 'ansible_*'})

    ansible_facts_dict = ansible_facts(module)

    # assert that a few basic facts exist
    assert 'ansible_all_ipv4_addresses' in ansible_facts_dict
    assert 'ansible_architecture' in ansible_facts_dict
    assert 'ansible_default_ipv4' in ansible_facts_dict
    assert 'ansible_distribution' in ansible_facts

# Generated at 2022-06-20 17:05:42.742061
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.utils import get_file_content

    expected_facts = get_file_content('test/unit/module_utils/facts/all_facts_json')

    class Module:
        def __init__(self):
            self.params = {'gather_subset': ['all']}
            self.args = {}

    m = Module()

    actual_facts = ansible_facts(module=m)

    assert actual_facts == expected_facts

# Generated at 2022-06-20 17:05:53.868085
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Integration test for get_all_facts

    Calls get_all_facts with an AnsibleModule instance using an in-memory backend.

    Asserts that a non-empty dict is returned.
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.loader import module_loader

    module_name = 'setup'
    backend = 'memory'
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=False, check_invalid_arguments=False)
    module.params['gather_subset'] = 'all'

    fact_module = module_loader.get_module_path(module_name, backend)

    result = get_all_facts(module=fact_module)
    assert result
    assert isinstance(result, dict)

# Generated at 2022-06-20 17:06:00.016448
# Unit test for function ansible_facts
def test_ansible_facts():
    # Dummy module for testing purpose
    module = DummyModule()

    # Make an ansible_facts call
    facts_dict = ansible_facts(module)

    # Testing purpose
    # Check ansible_facts return a dictionary
    assert isinstance(facts_dict, dict)



# Generated at 2022-06-20 17:06:06.842771
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import mock
    import os
    import pytest
    import sys
    import test

    # Mock AnsibleModule
    class MockAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    #noinspection PyUnresolvedReferences

# Generated at 2022-06-20 17:06:11.259544
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import timeout_secs

    # Timeout must be less than 40 secs for travis ci run.
    # Timeout must be less than 20 secs for github Actions run.
    module = AnsibleModule(argument_spec={'gather_timeout': dict(type='int', default=10)})
    module.params.update(
        dict(
            gather_subset=['all'],
        )
    )
    facts = ansible_facts(module)

    assert isinstance(facts, dict)
    assert timeout_secs(facts['ansible_env']['TEST_TIMEOUT']) == module.params['gather_timeout']

# Generated at 2022-06-20 17:06:24.773955
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # import module_utils/ansible_module here to get a reference to the AnsibleModule class
    from ansible.module_utils.basic import AnsibleModule

    class TestAnsibleModule(AnsibleModule):
        pass

    module = TestAnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all']),
                                              'gather_timeout': dict(type='int', default=10),
                                              'filter': dict(type='str', default='*'),
                                              })

    gather_subset = module.params['gather_subset']

# Generated at 2022-06-20 17:06:30.475201
# Unit test for function ansible_facts
def test_ansible_facts():
    mock_module = MockAnsibleModule()
    facts_dict = ansible_facts(mock_module, gather_subset=None)

    expected_keys = frozenset(['distribution', 'date_time'])

    assert frozenset(facts_dict.keys()) == expected_keys



# Generated at 2022-06-20 17:06:37.747867
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.default_collectors import DefaultCollector

    class TestDefaultCollector(DefaultCollector):
        name = 'test_default_collector'

        def collect(self, module=None, collected_facts=None):
            return dict(test_fact='test_fact_value')

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors

    # save the real collectors
    real_default_collectors = default_collectors.collectors

    # register the test collectors
    default_collectors.collectors = [
        TestDefaultCollector(),
        TestDefaultCollector(name='test_default_collector2'),
    ]

    # Register the test collector as a plugin

# Generated at 2022-06-20 17:06:46.810396
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import cache

    from ansible.module_utils.facts.default_collectors import Collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest

    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.cache = dict()

    class MockFactCollector(object):
        def __init__(self, all_collector_classes, namespace, filter_spec, gather_subset=None, gather_timeout=None,
                     minimal_gather_subset=None):
            self.all_collector_classes = all_collector_classes
            self.namespace = namespace
            self.filter