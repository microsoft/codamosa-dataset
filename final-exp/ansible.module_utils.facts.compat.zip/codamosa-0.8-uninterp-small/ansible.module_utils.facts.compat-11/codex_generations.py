

# Generated at 2022-06-24 21:37:49.744763
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1150
    var_0 = ansible_facts(int_0)


# Generated at 2022-06-24 21:37:56.911274
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -967
    bool_0 = bool(0)
    str_0 = str('')
    var_0 = get_all_facts(int_0)
    var_1 = ansible_facts(int_0, bool_0)
    var_2 = ansible_facts(int_0, bool_0)
    var_3 = ansible_facts(int_0, str_0)
    var_4 = ansible_facts(int_0)
    var_5 = ansible_facts(int_0, str_0)
    var_6 = ansible_facts(int_0, int_0)
    var_7 = ansible_facts(var_4, int_0)
    var_8 = ansible_facts(int_0, int_0)
    var_9 = ans

# Generated at 2022-06-24 21:37:58.400445
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:38:02.362059
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    var_0 = ansible_facts(int_0)


if __name__ == "__main__":
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:38:06.690651
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1206
    var_0 = ansible_facts(int_0)
    assert var_0 is None


if __name__ == "__main__":
    # Run module directly
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:38:09.675039
# Unit test for function get_all_facts
def test_get_all_facts():
    print("Testing get_all_facts")

    int_0 = -1799
    var_0 = get_all_facts(int_0)


# Generated at 2022-06-24 21:38:13.359424
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True


# Generated at 2022-06-24 21:38:14.175227
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True


# Generated at 2022-06-24 21:38:16.267879
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    ansible_0 = ansible_facts(int_0)
    print('ansible_0 = %s' % (ansible_0,))


# Generated at 2022-06-24 21:38:20.529355
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    var_0 = ansible_facts(int_0)

if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:38:29.151256
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    print("In function: test_get_all_facts")
    int_0 = -2829
    var_0 = get_all_facts(int_0)



# Generated at 2022-06-24 21:38:31.624467
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -540
    var_0 = ansible_facts(int_0)
    assert(var_0 == int_0)

# Generated at 2022-06-24 21:38:33.420474
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:38:34.191334
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-24 21:38:36.946284
# Unit test for function get_all_facts
def test_get_all_facts():
    module_under_test = AnsibleModuleMock()
    assert var_0 == module_under_test.get_all_facts(int_0)


# Generated at 2022-06-24 21:38:43.603622
# Unit test for function ansible_facts
def test_ansible_facts():
    opt_0 = 0
    arg_0 = None
    int_0 = -1799
    str_0 = '-1799'
    var_0 = ansible_facts(opt_0, arg_0)
    var_1 = ansible_facts(int_0, str_0)


if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-24 21:38:46.086610
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -1799
    var_0 = get_all_facts(int_0)
#   assert var_0 == , "Expected , but got: %s" % var_0



# Generated at 2022-06-24 21:38:50.523228
# Unit test for function ansible_facts
def test_ansible_facts():
    #expect no failures
    int_0 = -1799
    var_0 = ansible_facts(int_0)

if __name__ == '__main__':
    # main program
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:38:52.329666
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 1799
    assert ansible_facts(int_0) == get_all_facts(int_0)

# Generated at 2022-06-24 21:38:54.818006
# Unit test for function ansible_facts
def test_ansible_facts():
    module = {
        'gather_subset': 'gather_subset'
    }
    x = ansible_facts(module)
    assert x is not None
    print(x)

# Generated at 2022-06-24 21:39:05.504939
# Unit test for function ansible_facts
def test_ansible_facts():
    # SUT
    from ansible.module_utils.facts.core import ansible_facts

    # Setup test parameters
    module = MagicMock()
    module.params = dict(
        gather_subset=dict(),
        gather_timeout=dict(),
        filter=dict(),
    )
    gather_subset = dict()
    gather_timeout = dict()
    filter_spec = dict()

    # Exercise SUT
    ansible_facts(module, gather_subset, gather_timeout, filter_spec)



# Generated at 2022-06-24 21:39:09.295442
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(77) is None


# Generated at 2022-06-24 21:39:13.063380
# Unit test for function ansible_facts
def test_ansible_facts():
    class ansible_module_obj(object):
        def __init__(self, *arg):
            self.params = {
                           "gather_subset": [
                                          "all"
                                      ],
                           "filter": "*"
                       }

    int_0 = ansible_module_obj()
    assert ansible_facts(int_0)



# Generated at 2022-06-24 21:39:24.763656
# Unit test for function ansible_facts
def test_ansible_facts():
    test_1 = """
    module.params['default_ipv4'] = dict(address='192.0.2.1',
                                         alias='eth0',
                                         interface='eth0',
                                         macaddress='dead:beef:dead',
                                         network='192.0.2.0',
                                         type='ether',
                                         ipv4_address='192.0.2.1',
                                         ipv4_network='192.0.2.0',
                                         ipv4_netmask='255.255.255.0',
                                         ipv4_prefixlen='24',
                                         ipv4_broadcast='192.0.2.255')
    """

# Generated at 2022-06-24 21:39:33.177179
# Unit test for function ansible_facts
def test_ansible_facts():
    test_0 = 'gather_subset'
    test_1 = None
    test_2 = 'gather_subset'
    test_3 = 'gather_subset'
    test_4 = None
    test_5 = 'gather_subset'
    test_6 = 'gather_subset'
    test_7 = 'gather_subset'
    test_8 = None
    test_9 = 'gather_subset'
    test_10 = 'gather_subset'
    test_11 = None
    test_12 = 'gather_subset'
    test_13 = 'gather_subset'
    test_14 = None
    test_15 = 'gather_subset'
    test_16 = 'gather_subset'
    test_17 = None
   

# Generated at 2022-06-24 21:39:43.158080
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.collectors.system
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import merge_facts
    from ansible.module_utils.facts import collector
    import argparse

    # AnsibleModule compat

    class AnsibleModule():

        def __init__(self, all_collector_classes, *args, **kwargs):
            self.all_collector_classes = all_collector_classes
            self.args = args
            self.kwargs = kwargs

    class AnsibleArgs():

        def __init__(self):
            self.gather_subset

# Generated at 2022-06-24 21:39:44.812512
# Unit test for function get_all_facts
def test_get_all_facts():
    results = get_all_facts(1, )
    assert results == 1


# Generated at 2022-06-24 21:39:52.886719
# Unit test for function ansible_facts
def test_ansible_facts():
    # Getting the module object
    from ansible.module_utils import facts
    module = facts._AnsibleModuleStub(
        params={
            'gather_subset': ['!config_encryption_key'],
            'gather_timeout': 12,
            'filter': '*',
            '_ansible_verbosity': 3,
            '_ansible_version': 2.7,
            '_ansible_no_log': False,
            '_ansible_debug': True,
            'ANSIBLE_MODULE_ARGS': {
                'gather_subset': ['!config_encryption_key'],
                'gather_timeout': 12,
                'filter': '*'
            }
        }
    )
    # Getting fact

# Generated at 2022-06-24 21:39:55.008501
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -139192130
    var_0 = get_all_facts(int_0)


# Generated at 2022-06-24 21:40:02.214943
# Unit test for function ansible_facts
def test_ansible_facts():
    p0 = AnsibleModule()
    p1 = 'gather_subset'
    p2 = ''
    p3 = 10
    p4 = 'filter'
    p5 = '*'
    class dummy_class:
        def __init__(self):
            self.facts = {}
        def get(self, var_0, var_1):
            if (var_0 == 'gather_subset'):
                return None
            elif (var_0 == 'gather_timeout'):
                return var_1
    p0.params = dummy_class()
    return ansible_facts(p0, p1, p2, p3, p4, p5)


# Generated at 2022-06-24 21:40:10.781842
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 1856
    var_0 = ansible_facts(int_0)


# Generated at 2022-06-24 21:40:13.769662
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:40:18.144344
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:40:19.476134
# Unit test for function get_all_facts
def test_get_all_facts():
    assert ansible_facts(0, 0) is None


# Generated at 2022-06-24 21:40:21.341056
# Unit test for function ansible_facts
def test_ansible_facts():
    # Check if the expected output matches the actual ouptut 
    assert ansible_facts == ansible_facts


# Generated at 2022-06-24 21:40:26.945321
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:40:30.188343
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    assert (ansible_facts(int_0) == {'default_ipv4': {'network': '', 'address': ''}})



# Generated at 2022-06-24 21:40:32.649937
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:40:34.195171
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:40:36.481670
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    result = ansible_facts(None)
    assert result != None


# Generated at 2022-06-24 21:40:52.042270
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -914995545
    str_0 = "ansible_eth0"
    var_0 = get_all_facts(str_0)
    assert (var_0 != int_0)


# Generated at 2022-06-24 21:40:52.635928
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True

# Generated at 2022-06-24 21:40:53.685086
# Unit test for function get_all_facts
def test_get_all_facts():
    test_case_0()

# Generated at 2022-06-24 21:40:55.523879
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -1799
    var_0 = ansible_facts(int_0)
    get_all_facts(int_0)
    print(var_0)


# Generated at 2022-06-24 21:40:57.473972
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    result = ansible_facts(int_0)
    assert type(result) == dict


# Generated at 2022-06-24 21:41:06.360041
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test case 0
    int_0 = -1799
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:41:16.230378
# Unit test for function ansible_facts
def test_ansible_facts():
    # Create mock module and return values
    class MockModule:
        def __init__(self, params):
            self.params = params
            self.result = dict()

        def fail_json(self, **kwargs):
            self.result['failed'] = kwargs
            assert False

        def exit_json(self, **kwargs):
            self.result['changed'] = kwargs
            assert True

    module = MockModule(dict())

    assert ansible_facts(module, gather_subset=['all']) == {}



# Generated at 2022-06-24 21:41:17.348116
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    var_0 = ansible_facts(int_0)


# Generated at 2022-06-24 21:41:20.535706
# Unit test for function ansible_facts
def test_ansible_facts():
    # This test does nothing, just prints the name and the line number of the test.
    print("Test: {0}".format(inspect.stack()[0][3]))
    print("Line number: {0}".format(inspect.stack()[0][2]))
    int_0 = -1799
    var_0 = ansible_facts(int_0)
    var_0 = ansible_facts(int_0)


# Generated at 2022-06-24 21:41:25.981437
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -1799
    var_0 = get_all_facts(int_0)


# Generated at 2022-06-24 21:41:57.418030
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -1799
    var_0 = get_all_facts(int_0)
    print("Output #0 {0}:".format(str(var_0)))



# Generated at 2022-06-24 21:41:58.156332
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts() == ansible_facts()

# Generated at 2022-06-24 21:42:01.955047
# Unit test for function ansible_facts
def test_ansible_facts():
    arg_0 = {"gather_subset": [
        "all"
    ], "filter": "*"}
    arg_1 = None # default value
    # Testing with excluded subset
    ansible_facts(arg_0, arg_1)


# Generated at 2022-06-24 21:42:03.511751
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1
    get_all_facts(int_0)


# Generated at 2022-06-24 21:42:08.924180
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1888
    var_0 = ansible_facts(int_0)


int_0 = -1630
var_0 = get_all_facts(int_0)

int_1 = -1173
var_1 = ansible_facts(int_1)



# Generated at 2022-06-24 21:42:10.947548
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    var_1 = ansible_facts(int_0)
    assert var_1 == {}

# Generated at 2022-06-24 21:42:12.511146
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    var_0 = ansible_facts(int_0)


# Generated at 2022-06-24 21:42:16.994890
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test 2.0/2.1 behavior, where gather_subsets is not an arg
    int_0 = -1799
    var_0 = ansible_facts(int_0)
    # Test 2.3 behavior, where gather_subsets is an arg
    int_0 = -1799
    var_0 = ansible_facts(int_0, gather_subset="all")

# Generated at 2022-06-24 21:42:18.200261
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(27) == (27)


# Generated at 2022-06-24 21:42:28.765905
# Unit test for function ansible_facts
def test_ansible_facts():
    assert default_collectors.ANSIBLE_COLLECTORS

    all_facts = ansible_facts(None)
    assert isinstance(all_facts, dict)
    assert all_facts['lsb']
    assert all_facts['facter']
    assert all_facts['ohai']
    assert all_facts['python']
    assert all_facts['virtualization']
    assert all_facts['ansible_all_ipv4_addresses']

    all_facts = ansible_facts(None, gather_subset=['all'])
    assert isinstance(all_facts, dict)
    assert all_facts['lsb']
    assert all_facts['facter']
    assert all_facts['ohai']
    assert all_facts['python']
    assert all_facts['virtualization']

# Generated at 2022-06-24 21:43:31.232621
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True == False


# Generated at 2022-06-24 21:43:34.240283
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    int_1 = -1344
    int_2 = -1682
    var_0 = ansible_facts(int_0, int_1)
    var_1 = ansible_facts(int_2)

# Generated at 2022-06-24 21:43:35.048782
# Unit test for function ansible_facts
def test_ansible_facts():
    test_case_0()

# Generated at 2022-06-24 21:43:38.108047
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True == True


# Generated at 2022-06-24 21:43:48.838535
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1848
    var_0 = ansible_facts(int_0)
    #assert var_0 == "10.1.1.1, 10.2.2.2", "Expected: 10.1.1.1, 10.2.2.2, got {0}".format(var_0)
    assert var_0 == "10.1.1.1, 10.2.2.2", "Expected: {0}, got {1}".format("10.1.1.1, 10.2.2.2", var_0)


# AssertionError: Expected: 10.1.1.1, 10.2.2.2, got {'ansible_facts': {'ansible_all_ipv4_addresses': ['10.1.1.1', '10.2

# Generated at 2022-06-24 21:43:51.557842
# Unit test for function ansible_facts
def test_ansible_facts():
    src_0 = """
        module.fail_json(msg='AnsibleModule argument "module" is missing')
    """.strip()
    expected_0 = """
        module.fail_json(msg='AnsibleModule argument "module" is missing')
    """.strip()
    assert(ansible_facts(src_0) == expected_0)



# Generated at 2022-06-24 21:43:53.080280
# Unit test for function ansible_facts
def test_ansible_facts():
    assert 'default_ipv4' in ansible_facts(['all'], 'ansible')


# Generated at 2022-06-24 21:43:59.626130
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -760
    int_1 = -674
    var_0 = 'command'
    var_1 = 'package'
    var_2 = 'system'
    var_3 = ansible_facts(var_0)
    var_4 = ansible_facts(var_1)
    var_5 = ansible_facts(var_2)
    assert var_3 == var_4 == var_5


# Generated at 2022-06-24 21:44:04.488835
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    var_0 = ansible_facts(int_0)


if __name__ == "__main__":
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:44:05.787128
# Unit test for function get_all_facts
def test_get_all_facts():
    with pytest.raises(FailedConditionalCall):
        test_case_0()

# Generated at 2022-06-24 21:46:17.118418
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True

# Generated at 2022-06-24 21:46:20.325757
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = 217
    var_0 = get_all_facts(int_0)
    assert var_0 is not None, "func must return a value"
    assert var_0 is not False, "func must return a value"

# Validation for function get_all_facts

# Generated at 2022-06-24 21:46:28.899415
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -1799
    var_0 = get_all_facts(int_0)
    assert {'default_ipv4': {'address': '172.16.231.149', 'alias': 'eth0', 'broadcast': '172.16.231.255', 'gateway': '172.16.231.254', 'interface': 'eth0', 'macaddress': '52:54:00:49:05:6a', 'mtu': 1500, 'netmask': '255.255.255.0', 'network': '172.16.231.0', 'type': 'ether'}}  == var_0, "Return value is \"{}\" which is not correct.".format(var_0)
    int_1 = -4443
    var_1 = get_all_facts(int_1)

# Generated at 2022-06-24 21:46:34.211253
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Make sure that the function works.
    '''
    
    try:
        ansible_facts()
    except NameError:
        assert False, 'Do you need to initialize the var?'
    except:
        assert False, 'There is a problem here!'
    
    assert True


# Generated at 2022-06-24 21:46:36.643494
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    
    # Call function ansible_facts with args
    result = ansible_facts(int_0)
    assert result is None
    return result

# Generated at 2022-06-24 21:46:42.585202
# Unit test for function ansible_facts
def test_ansible_facts():
    # Validate function ansible_facts
    verbose = 1
    int_0 = -1799
    # Good values to start with
    #var_0 = ansible_facts(int_0)
    #assert(isinstance("var_0", dict))
    #assert("1.6" in var_0)
    #assert("1.1" in var_0)
    #assert("2.6" in var_0)
    #assert("1.3" in var_0)
    #assert("1.9" in var_0)
    #assert("3.3" in var_0)
    #assert("1.7" in var_0)
    #assert("1.4" in var_0)
    #assert("1.5" in var_0)
    #assert("2.2" in var

# Generated at 2022-06-24 21:46:51.194156
# Unit test for function ansible_facts
def test_ansible_facts():

    var_0 = ansible_facts(int_0)
    assert (u'ansible_default_ipv4' in var_0)
    assert (u'ansible_default_ipv6' in var_0)
    assert (u'ansible_distribution' in var_0)
    assert (u'ansible_distribution_file_parsed' in var_0)
    assert (u'ansible_distribution_file_path' in var_0)
    assert (u'ansible_distribution_file_variety' in var_0)
    assert (u'ansible_distribution_major_version' in var_0)
    assert (u'ansible_distribution_release' in var_0)
    assert (u'ansible_distribution_version' in var_0)

# Generated at 2022-06-24 21:46:53.362652
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -1799
    var_0 = ansible_facts(int_0)
    # Should return a dict
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 21:46:53.854962
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True

# Generated at 2022-06-24 21:46:56.482706
# Unit test for function get_all_facts
def test_get_all_facts():
    map_0 = {}
    map_1 = {}
    map_0['gather_subset'] = map_1

    assert get_all_facts(map_0) == ansible_facts(map_0)
