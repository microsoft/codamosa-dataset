

# Generated at 2022-06-24 21:37:55.811682
# Unit test for function get_all_facts

# Generated at 2022-06-24 21:37:58.763612
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = ansible_facts(bytes_0)


# Generated at 2022-06-24 21:38:00.972642
# Unit test for function ansible_facts
def test_ansible_facts():

    var_0 = ansible_facts(module=None)


# Generated at 2022-06-24 21:38:05.608647
# Unit test for function get_all_facts
def test_get_all_facts():
    assert callable(get_all_facts)


# Generated at 2022-06-24 21:38:14.969094
# Unit test for function get_all_facts
def test_get_all_facts():
    # Setup
    content = """
module_utils.facts.get_all_facts()
"""
    lines = content.split('\n')
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = get_all_facts(bytes_0)

    # Testing if the set of "type(var_0)" is a superset of the set of ("dict")
    # Testing if the set of "type(var_0)" is a superset of the set of ("str")
    # Testing if the set of "type(var_0)" is a superset of the set of ("int")
    # Testing if the set of "type(var_0)" is a supers

# Generated at 2022-06-24 21:38:20.794033
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xf0\xcb\x13\x09u\x9e\x8d\x1c\xa5\xcf!\xe8\xb4\xab'
    var_0 = ansible_facts(bytes_0)


if __name__ == '__main__':
    test_case_1()

# Generated at 2022-06-24 21:38:29.338585
# Unit test for function get_all_facts
def test_get_all_facts():
    import base64
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import execute_collector_function
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceDict

    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = get_all_facts(bytes_0)

# Generated at 2022-06-24 21:38:29.970923
# Unit test for function ansible_facts
def test_ansible_facts():
    assert callable(ansible_facts)


# Generated at 2022-06-24 21:38:39.362410
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:38:50.558337
# Unit test for function get_all_facts
def test_get_all_facts():
    assert type(get_all_facts) == type(lambda: None)
    class module:
        def __init__(self, params):
            self.params = params
        def fail_json(self, msg, **kwargs):
            msg_dict = {'failed': True, 'msg': msg}
            msg_dict.update(kwargs)
            raise Exception(json.dumps(msg_dict))
        def exit_json(self, **kwargs):
            kwargs['changed'] = False
            msg_dict = {'failed': False}
            msg_dict.update(kwargs)
            raise Exception(json.dumps(msg_dict))
    params = {
        'gather_subset': ['all'],
    }
    module_instance = module(params)
    test_case_0()


#

# Generated at 2022-06-24 21:39:02.098920
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x8e\xa3\xce\xde\x9e\xd3c\xfd\x14\xdf\xa0\x8b\x91\x0e'

# Generated at 2022-06-24 21:39:03.289475
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True # make sure we have some tests here


# Generated at 2022-06-24 21:39:09.727990
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = ansible_facts(bytes_0)


# Generated at 2022-06-24 21:39:12.880600
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = ansible_facts(bytes_0)


# Generated at 2022-06-24 21:39:18.361298
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = ansible_facts(bytes_0)

# Generated at 2022-06-24 21:39:25.519280
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(None) == {}

    class AnsibleModuleMock(object):
        def __init__(self, params):
            self.params = params

    assert ansible_facts(AnsibleModuleMock(None)) == {}

    # default values
    params = {'gather_subset': 'all'}
    assert ansible_facts(AnsibleModuleMock(params)) == {}
    params['gather_subset'] = 'fake'
    assert ansible_facts(AnsibleModuleMock(params)) == {}



# Generated at 2022-06-24 21:39:37.014319
# Unit test for function ansible_facts
def test_ansible_facts():
    # Make sure booleans are properly coerced to ints
    assert(ansible_facts(True) == 1)
    assert(ansible_facts(False) == 0)
    # Make sure ints are properly coerced to floats
    assert(ansible_facts(42) == 42)
    assert(ansible_facts(-42) == -42)
    assert(ansible_facts(-0) == 0)
    # Make sure that the default namespace is always used
    assert(ansible_facts(b'ansible_test') == 'ansible_test')
    # Make sure that the default namespace is not included in variable
    # names if it appears in the prefix
    assert(ansible_facts(b'ansible_test', prefix=b'ansible_test') == 'test')
    # Make sure that the user-supplied prefix is properly joined

# Generated at 2022-06-24 21:39:44.668452
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:39:52.775451
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''
    # Check that the fact collector exists in this version of Ansible
    assert 'ansible_local' in dir(ansible_collector), \
        'ansible_local not defined in ansible_collector'

    # Check that the default value of gather_subset == ['all']
    assert ansible_collector.ansible_local.params['gather_subset'] == ['all'], \
        'ansible_collector gather_subset not all'

    # Check that the default value of gather_timeout == 10
    assert ansible_collector.ansible_local.params['gather_timeout'] == 10, \
        'ansible_collector gather_timeout not 10'

    # Check that the default value of filter == '*'

# Generated at 2022-06-24 21:39:54.441801
# Unit test for function ansible_facts
def test_ansible_facts():
    r = ansible_facts()  # noqa
    assert r is not None


# Generated at 2022-06-24 21:40:03.029537
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = ansible_facts(bytes_0)

# Generated at 2022-06-24 21:40:03.829983
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True


# Generated at 2022-06-24 21:40:14.574769
# Unit test for function ansible_facts
def test_ansible_facts():
    assert 'get_all_facts' in globals() or 'get_all_facts' in locals()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    int_0 = 0
    invert_dict_0 = dict()
    invert_dict_0['b'] = 'a'
    invert_dict_0['a'] = 'b'
    invert_dict_0['c'] = 'c'
    set_0 = frozenset()
    set_1 = frozenset()
    set_2 = frozenset()
    set_3 = frozenset()
    set_4 = frozenset()
    set_5 = frozenset()
    set_6 = frozenset()
    set_7 = frozenset()
    set_8 = frozens

# Generated at 2022-06-24 21:40:15.742403
# Unit test for function ansible_facts
def test_ansible_facts():
    var = ansible_facts()
    print(var)
    assert var is None

# Generated at 2022-06-24 21:40:18.342056
# Unit test for function ansible_facts
def test_ansible_facts():
    # NOTE: I can't unit-test this function without a real ansible module,
    # because it relies on .params, .fail_json, .exit_json, etc attributes.

    # So for now, just pass.
    pass

# Generated at 2022-06-24 21:40:19.127558
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True


# Generated at 2022-06-24 21:40:23.317265
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = ansible_facts(bytes_0)


# Generated at 2022-06-24 21:40:32.282708
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts as af

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import BaseFactNamespace

    class Collector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {}

    class Namespace(BaseFactNamespace):
        name = 'ns'

    class MockModule:
        params = {
            'gather_subset': ['all'],
            'gather_timeout': 2,
            'filter': '*'
        }

    assert af(MockModule()) == {
        'test': {},
        'ns': {},
    }

# Generated at 2022-06-24 21:40:36.327401
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = ansible_facts(bytes_0)


# Generated at 2022-06-24 21:40:44.506326
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        assert True
    except:
        var_1 = get_ansible_facts(b'\xd5\x91\xe0\xfb\x8a\x1a\x92\xa7\x9d\x8f\xfe\x8c\xa3\x93\x90\xac\x1e\x94\x93\xde')


# Generated at 2022-06-24 21:41:03.168465
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x0c!\x8cT\xa0\x90\x9e\x8b\xcf\xab\xe7\xe0\xf8\xb7\xcd\x10'
    dict_0 = dict()
    dict_0['gather_subset'] = ['all']
    dict_1 = dict()
    dict_1['param'] = 'gather_subset'
    dict_0['gather_timeout'] = 10
    dict_2 = dict()
    dict_2['param'] = 'gather_timeout'
    dict_0['filter'] = '*'
    dict_3 = dict()
    dict_3['param'] = 'filter'
    dict_3['instance'] = dict_0
    dict_3['module'] = bytes_0
    dict

# Generated at 2022-06-24 21:41:07.479716
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = ansible_facts(bytes_0)
    # TODO: add assertions.
    return var_0


# Generated at 2022-06-24 21:41:14.678976
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import inspect
    import json
    from ansible.module_utils.facts import ansible_collector
    from collections import OrderedDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    # Initializing the list of modules
    list_of_modules = []

    def get_all_subclasses(cls):
        return cls.__subclasses__() + [g for s in cls.__subclasses__()
                                       for g in get_all_subclasses(s)]

    # Listing the subclasses of ansible_collector.BaseFactsCollector
    list_of_modules = get_all_subclasses(ansible_collector.BaseFactsCollector)
    #print("List of sub

# Generated at 2022-06-24 21:41:26.185494
# Unit test for function ansible_facts
def test_ansible_facts():

    # Testing with bytes
    bytes_0 = b'\xd2w\x8e\x07[\xfb\x9c\xde{\xa1\xaa\xbbe\xeb\xc8\x97\xcb\xdc\xd9\x0c\x0c\xb2\xfe\xa6\x85'
    var_0 = ansible_facts(bytes_0)
    bytes_1 = b'\xfa\xd4\x01\xca\x96\xab\xdb\x8f\xbe\xbf:\xbf\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_1 = ansible_facts(bytes_1)

# Generated at 2022-06-24 21:41:35.695721
# Unit test for function ansible_facts
def test_ansible_facts():
    import collections
    import sys
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.utils.file_digest_facts

    # File: tests/utils/mock_module.py
    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.check_mode = False

    # File: tests/utils/mock_module.py
    class FakeParameters:
        def __init__(self):
            self.gather_subset = ['all']
            self.gather_timeout = 10
            self.filter = '*'

    gather_subset = FakeParameters()
    gather_timeout = FakeParameters()
    filter_spec = FakeParameters()
    module = ansible.module_utils.facts.namespace
    namespace

# Generated at 2022-06-24 21:41:42.107168
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = ansible_facts(bytes_0)

# Generated at 2022-06-24 21:41:45.503712
# Unit test for function ansible_facts
def test_ansible_facts():
    # Input parameters
    module = None

    # Output parameters
    facts_dict = dict()

    # Test the Ansible module
    facts_dict = ansible_facts(module)

# Code that actually executes
if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:41:50.308993
# Unit test for function get_all_facts
def test_get_all_facts():
    # assert the return value of function is equal to the expected value
    assert get_all_facts('module') == 'return_value'


# Generated at 2022-06-24 21:41:51.733997
# Unit test for function ansible_facts
def test_ansible_facts():
    module = '[1, 2, 3]'
    assert ansible_facts(module) == [1, 2, 3]

# Generated at 2022-06-24 21:42:02.025429
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    # List of dictionaries, where each dictionary represents an AnsibleModule
    # param as a key=>value pair.

# Generated at 2022-06-24 21:42:29.277220
# Unit test for function get_all_facts
def test_get_all_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = get_all_facts(bytes_0)

# Generated at 2022-06-24 21:42:31.714582
# Unit test for function ansible_facts
def test_ansible_facts():
    # Invoke function: ansible_facts
    try:
        ansible_facts(module)
        assert True
    except:
        assert False


# Generated at 2022-06-24 21:42:39.219509
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = ansible_facts(bytes_0)
    assert var_0 == b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'


# Generated at 2022-06-24 21:42:50.536409
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = ansible_facts(bytes_0)
    assert (var_0 == bytes_0)
    bytes_1 = b'\x8e\xab\x95\x1a\x9b\x8e3\xdbA\xfe\x98$\xba\xab\x86\x1d|\xe2\x83\xc3'
    var_1 = ansible_facts(bytes_1)
    assert (var_1 == bytes_1)

# Generated at 2022-06-24 21:42:53.245380
# Unit test for function get_all_facts
def test_get_all_facts():
    ansible_collections.f5networks.f5_modules.plugins.modules.bigip_device_dns.get_all_facts(module)

# Generated at 2022-06-24 21:43:04.078074
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xd8\xdd\xe3\x0f\x7f\xc5\x88\x0f\x03\x87\xa5\x168\xef\xfa\x84\xf6\xdb'
    bytes_1 = b'h\xa9'
    bytes_2 = b'\xac\x1em\xc8\xad\x00\x1cY\x9d\xe6\x0bP\x01\x88\xdb'
    int_0 = 1467658623
    int_1 = 819044573
    module_0 = make_module(int_0, int_1, bytes_0, bytes_1, bytes_2)
    assert(ansible_facts(module_0))



# Generated at 2022-06-24 21:43:11.964197
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test if the basic usage works
    ansible_facts('module')
    # Test if the basic usage with gather_subset works
    ansible_facts('module', 'gather_subset')
    # Test if the basic usage with gather_timeout works
    ansible_facts('module', 'gather_timeout')
    # Test if the basic usage with filter works
    ansible_facts('module', 'filter')
    # Test if the basic usage with gather_subset, gather_timeout and filter works
    ansible_facts('module', 'gather_subset', 'gather_timeout', 'filter')

# Generated at 2022-06-24 21:43:22.993282
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = ansible_facts(bytes_0)
    if var_0 != bytes_0:
        print('FAILED: var_0 != bytes_0')
        print(var_0)
        print(bytes_0)
        return False
    var_1 = ansible_facts(var_0)
    var_2 = ansible_facts(var_1)
    var_3 = ansible_facts(var_2)
    var_4 = ansible_facts(var_3)
    var_5 = ansible_facts(var_4)

# Generated at 2022-06-24 21:43:23.780930
# Unit test for function ansible_facts
def test_ansible_facts():
    print(ansible_facts())


# Generated at 2022-06-24 21:43:26.566197
# Unit test for function get_all_facts
def test_get_all_facts():
    var_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    assert_equal(get_all_facts(bytes_0), 'module')

# Generated at 2022-06-24 21:44:22.515277
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = ansible_facts(bytes_0)

    compare_dicts(var_0, {'ansible':'ansible'})


# Generated at 2022-06-24 21:44:23.536691
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        ansible_facts()
    except:
        pass


# Generated at 2022-06-24 21:44:24.803044
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts('ansible_facts', 'ansible_facts') == 'ansible_facts'



# Generated at 2022-06-24 21:44:25.880519
# Unit test for function get_all_facts
def test_get_all_facts():
    assert get_all_facts(get_all_facts) == get_all_facts


# Generated at 2022-06-24 21:44:30.065778
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = ansible_facts(bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:44:31.866563
# Unit test for function ansible_facts
def test_ansible_facts():
    test_case_0()

# Run unit test for function ansible_facts
test_ansible_facts()

# Generated at 2022-06-24 21:44:40.146143
# Unit test for function get_all_facts
def test_get_all_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    var_0 = get_all_facts(bytes_0)
    assert var_0 == '\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_1 = get_all_facts(bytes_1)
    assert var_

# Generated at 2022-06-24 21:44:41.931709
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(module=None, gather_subset=['a']) == 'variable'

# Generated at 2022-06-24 21:44:45.898766
# Unit test for function ansible_facts
def test_ansible_facts():

    # Check if the function can identify the right class type
    if not isinstance(test_case_0(), dict):
        raise Exception("Ansible AnsibleModule not returning dict")

ansible_facts()

# Generated at 2022-06-24 21:44:46.983885
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True == False


# Generated at 2022-06-24 21:46:44.612817
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
    bytes_1 = b'\xbf\x8a\x1dU\x9f\x9bs\x91y\xde\x13\x99\x17?\xc8\xa7\xce\xe2R\x16'
    bytes_2 = b'\xf3\xcf0\x00\x00\x00\x08\x00\x89I\x00\x00\x00\x00'

# Generated at 2022-06-24 21:46:52.471996
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:46:53.149992
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True



# Generated at 2022-06-24 21:46:53.654047
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-24 21:47:02.600082
# Unit test for function ansible_facts
def test_ansible_facts():
    input_0 = False
    var_0 = ansible_facts(input_0)

    input_1 = True
    var_1 = ansible_facts(input_1)

    input_2 = '$'
    var_2 = ansible_facts(input_2)

    input_3 = '%'
    var_3 = ansible_facts(input_3)

    input_4 = '&'
    var_4 = ansible_facts(input_4)

    input_5 = '('
    var_5 = ansible_facts(input_5)

    input_6 = ')'
    var_6 = ansible_facts(input_6)

    input_7 = '*'
    var_7 = ansible_facts(input_7)

    input_8 = '+'
    var_8

# Generated at 2022-06-24 21:47:10.762752
# Unit test for function get_all_facts
def test_get_all_facts():
  bytes_0 = b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3'
  var_0 = get_all_facts(bytes_0)
  assert(var_0 == b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3')
  assert(get_all_facts(bytes_0) == b'\xa6\x9dm\xf9M\xb4\xc5U)\xa3\x9c\xfd\x8a\x0f?D\xa1\xc3')


# Generated at 2022-06-24 21:47:11.744622
# Unit test for function ansible_facts
def test_ansible_facts():
    assert False


# Generated at 2022-06-24 21:47:12.660196
# Unit test for function get_all_facts
def test_get_all_facts():
    assert test_case_0()

# Generated at 2022-06-24 21:47:14.734543
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        test_case_0()
    except Exception as exception_0:
        print(exception_0)
        assert False


# Generated at 2022-06-24 21:47:17.068803
# Unit test for function get_all_facts
def test_get_all_facts():
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(type='list')))
    result = get_all_facts(module)
    assert(result == {})
