

# Generated at 2022-06-24 21:37:53.592101
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = ansible_facts(bytes_0)



# Generated at 2022-06-24 21:37:57.260808
# Unit test for function ansible_facts
def test_ansible_facts():
    assert(ansible_facts(get_all_facts).__class__.__name__ == 'dict')


# Generated at 2022-06-24 21:38:06.523157
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    module = None
    filter_spec = None
    gather_subset = frozenset(['all'])
    gather_timeout = 10
    all_collector_classes = default_collectors.collectors

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-24 21:38:11.376784
# Unit test for function get_all_facts
def test_get_all_facts():
    bytes_0 = b'\xbd\xcd\xc8\x9e\x99\x83\xf1\xd8\x83\xe4\xc4\xa1\x14\x0b\x04\xcc\x8a[\xeb'
    var_0 = get_all_facts(bytes_0)



# Generated at 2022-06-24 21:38:12.693279
# Unit test for function ansible_facts
def test_ansible_facts():
    pass


if __name__ == '__main__':
    # test_case_0()
    pass

# Generated at 2022-06-24 21:38:14.862355
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = ansible_facts(bytes_0)

# Generated at 2022-06-24 21:38:24.641763
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    dict_0 = {}
    bytes_1 = b'\x8c\xdb\xb5\x86\x86\x9e\x85\xe0\xcf\xe2\x10'
    var_1 = ansible_facts(bytes_0, dict_0)
    dict_1 = {}
    dict_2 = {}
    var_2 = ansible_facts(dict_1, dict_2)
    bytes_2 = b'\x8c\xdb\xb5\x86\x86\x9e\x85\xe0\xcf\xe2\x10'
    dict_3 = {}
    var

# Generated at 2022-06-24 21:38:30.193877
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Unit test for function get_all_facts
    '''

    bytes_0 = b'V\x88\x16\x7f\x91eM\x9c\x1a\x1e'
    var_0 = get_all_facts(bytes_0)



# Generated at 2022-06-24 21:38:36.918658
# Unit test for function ansible_facts
def test_ansible_facts():

  # Make sure there are no ansible_facts yet
  assert len(ansible_facts().keys()) == 0


# Generated at 2022-06-24 21:38:43.538642
# Unit test for function get_all_facts
def test_get_all_facts():
    bytes_0 = b'\x00'
    var_0 = get_all_facts(bytes_0)
    bytes_1 = b'\x00\x00'
    var_1 = get_all_facts(bytes_1)
    bytes_2 = b'\x00\x00'
    var_2 = get_all_facts(bytes_2)


# Generated at 2022-06-24 21:38:46.958583
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True



# Generated at 2022-06-24 21:38:47.486459
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True

# Generated at 2022-06-24 21:38:48.732628
# Unit test for function get_all_facts
def test_get_all_facts():
    assert get_all_facts is not None


# Generated at 2022-06-24 21:38:53.333965
# Unit test for function ansible_facts
def test_ansible_facts():
    assert 'ansible_' in ansible_facts('\x81\x83\x0fw\xbe\xe9\x8a\x0c\xe8KY\xac\x14\n')
# END Unit test for function ansible_facts


# Generated at 2022-06-24 21:38:55.097206
# Unit test for function ansible_facts
def test_ansible_facts():
    # Simple test case
    # TODO: add additional tests
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_1 = ansible_facts(bytes_0)


# Generated at 2022-06-24 21:38:57.268884
# Unit test for function get_all_facts
def test_get_all_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = get_all_facts(bytes_0)
    for k in var_0.keys():
        if (k == 'var_0'):
            assert bytes_0 == var_0[k]


# Generated at 2022-06-24 21:39:02.885354
# Unit test for function ansible_facts
def test_ansible_facts():

    assert True  # TODO: implement your test here


# Generated at 2022-06-24 21:39:08.403060
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = ansible_facts(bytes_0)

# Generated at 2022-06-24 21:39:09.343182
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True



# Generated at 2022-06-24 21:39:10.213974
# Unit test for function get_all_facts
def test_get_all_facts():
    test_case_0()


# Generated at 2022-06-24 21:39:20.311908
# Unit test for function get_all_facts
def test_get_all_facts():
    # Setup test environment
    set_test_environment()
    # Test get_all_facts
    print('Testing get_all_facts')
    try:
        test_case_0()
    except NameError as e:
        print('test_case_0 failed: ' + str(e))



# Generated at 2022-06-24 21:39:20.865394
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True

# Generated at 2022-06-24 21:39:25.479437
# Unit test for function ansible_facts
def test_ansible_facts():

    # set up object
    module = AnsibleModule()

    # set up params
    params = {
        "gather_subset": "all",
        "gather_timeout": 10,
        "filter": "*"
    }
    module.params = params

    # invoke the function
    ansible_facts(module)


# Generated at 2022-06-24 21:39:28.679382
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True

# Generated at 2022-06-24 21:39:37.506976
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:39:42.814421
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = ansible_facts(bytes_0)

if __name__ == "__main__":
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:39:46.201512
# Unit test for function ansible_facts
def test_ansible_facts():
    # Try to access a protected member _AnsibleModule__ansible_facts
    # This should fail and throw an exception
    with pytest.raises(AttributeError):
        ansible_facts._AnsibleModule__ansible_facts

# Basic test of get_all_facts

# Generated at 2022-06-24 21:39:57.555751
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = module_utils.facts.ansible_facts(bytes_0)
    assert 'ansible_apparmor' in var_0
    assert 'ansible_architecture' in var_0
    assert 'ansible_all_ipv4_addresses' in var_0
    assert 'ansible_all_ipv6_addresses' in var_0
    assert 'ansible_bios_date' in var_0
    assert 'ansible_bios_version' in var_0
    assert 'ansible_cmdline' in var_0
    assert 'ansible_date_time' in var_0

# Generated at 2022-06-24 21:40:02.964103
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = ansible_facts(bytes_0)

# Generated at 2022-06-24 21:40:06.595959
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    module = bytes_0
    gather_subset = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    assert len(ansible_facts(module, gather_subset)) == 0


# Generated at 2022-06-24 21:40:22.826089
# Unit test for function ansible_facts
def test_ansible_facts():

    # From /usr/lib/python2.7/unittest/case.py:182
    class NoneTestCase(unittest.TestCase):
        '''Test case that defaults setup and teardown to do nothing.'''

        def __init__(self, methodName='runTest'):
            '''Create an instance of the class that will use the named test
               method when executed. Raises a ValueError if the instance does
               not have a method with the specified name.
            '''

            unittest.TestCase.__init__(self, methodName)

        # From /usr/lib/python2.7/unittest/case.py:193

        def __eq__(self, other):
            '''Check for test equality'''

            if type(self) is not type(other):
                return NotImplemented



# Generated at 2022-06-24 21:40:26.488964
# Unit test for function get_all_facts
def test_get_all_facts():
    with pytest.raises(TypeError):
        bytes_0 = b'\x84\x82\x9b\x03\x9d"\xb5\x91*(\xcb\xb5\x1f'
        get_all_facts(bytes_0)


# Generated at 2022-06-24 21:40:34.395458
# Unit test for function ansible_facts
def test_ansible_facts():

    # These tests should probably be in their own files.
    # Or we could use testscenarios - https://pypi.python.org/pypi/testscenarios
    # This is a bit of a hack, but I'm trying to keep it simple and not use any
    # extra dependencies.

    from unittest import TestCase
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.six import iteritems

    class TestAnsibleFactsCase(TestCase):
        '''
            TestCase class for the ansible_facts function
        '''


# Generated at 2022-06-24 21:40:38.310924
# Unit test for function ansible_facts
def test_ansible_facts():
    assert func() == 1



# Generated at 2022-06-24 21:40:41.839353
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xf0\xc4\x8f\xef\x06\xbb5\x07\x9e\x15t\xe5\xc3\xb3'
    var_0 = ansible_facts(bytes_0)

# Generated at 2022-06-24 21:40:47.970998
# Unit test for function get_all_facts
def test_get_all_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = get_all_facts(bytes_0)


# Generated at 2022-06-24 21:40:52.150283
# Unit test for function get_all_facts
def test_get_all_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = get_all_facts(bytes_0)
    assert var_0 == bytes_0


# Generated at 2022-06-24 21:40:56.506670
# Unit test for function get_all_facts
def test_get_all_facts():
    buf = StringIO()
    out = StringIO()
    sess = Session()
    
    j = get_all_facts(buf, out, sess)

    assert j['out'] == out
    assert j['buf'] == buf
    assert j['sess'] == sess


# Generated at 2022-06-24 21:40:57.232127
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True


# Generated at 2022-06-24 21:41:01.899091
# Unit test for function get_all_facts
def test_get_all_facts():
    module = MockAnsibleModule(gather_subset=['all'])
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = get_all_facts(module)
    var_1 = ansible_facts(module, 'all')


# Generated at 2022-06-24 21:41:27.715598
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = ansible_facts(bytes_0)


if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:41:35.780005
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_arg = bytearray(b'\x8c\x16\x80\xf0\x01\xb8\xee\xf7\x9a\xd2\x8e\x85\xb1\x00\xe0\x96\xc8\xfd\x9f\x8f\x17r0\xe2\x99z\x91\x8c\xd5\x87\x1a\x9a\x18\x89')
    assert callable(ansible_facts)
    call_0 = ansible_facts(bytes_arg)
    assert call_0 is None

# Generated at 2022-06-24 21:41:42.921653
# Unit test for function ansible_facts
def test_ansible_facts():
    # get_all_facts (ansible 2.2/2.3) is a wrapper for ansible_facts.
    # compare ansible_facts output to get_all_facts output
    all_facts = get_all_facts(bytes_0)
    ansible_facts = ansible_facts(bytes_0)

    assert all_facts == ansible_facts

# Generated at 2022-06-24 21:41:47.357023
# Unit test for function ansible_facts
def test_ansible_facts():
    import inspect
    import json

    # The module might not have implement all facts so we have catch the NotImplementedError
    try:
        test_dict = ansible_facts('')
    except NotImplementedError:
        pass
    else:
        assert type(test_dict) is dict, "ansible_facts did not return a dict"
        # Check if the returned  ansible_facts is a subset of the default ansible_facts
        # Using set intersection to compare two sets

# Generated at 2022-06-24 21:41:51.724156
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        module = AnsibleModule(
            argument_spec = dict()
        )
    except TypeError:
        module = AnsibleModule(
            argument_spec=dict(),
        )

    assert module is not None
    assert ansible_facts(module) is not None

# Generated at 2022-06-24 21:42:02.026111
# Unit test for function ansible_facts
def test_ansible_facts():
    # set up test data
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    bytes_1 = b'\x0c\xfd\xea'
    bytes_2 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    dict_0 = dict()
    dict_0['gather_subset'] = ['all']
    dict_0['gather_filter'] = '*'
    dict_0['gather_timeout'] = 10
    dict_1 = dict()
    dict_1['gather_timeout'] = 10
    dict_1['gather_filter'] = '*'

# Generated at 2022-06-24 21:42:02.790957
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True

# Generated at 2022-06-24 21:42:12.859152
# Unit test for function ansible_facts
def test_ansible_facts():
    pass
    # Test case 0
    # bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    # var_0 = ansible_facts(bytes_0)
    # assert var_0 == True
    # Test case 1
    # module_1 = AnsibleModule('ansible_facts', 'ansible module')
    # bytes_1 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    # var_1 = ansible_facts(module_1)
    # assert var_1 == True



# Generated at 2022-06-24 21:42:15.139707
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts == get_all_facts

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 21:42:21.105209
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = ansible_facts(bytes_0)



# Generated at 2022-06-24 21:43:00.698506
# Unit test for function get_all_facts
def test_get_all_facts():
    """Test the get_all_facts function from the module.
    """
    from ansible.module_utils.facts import Facts

    my_facts = Facts()
    my_facts.populate()

    test_case_0(my_facts)

# Generated at 2022-06-24 21:43:06.153175
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    # Testing if the type of first param 'module' is correct
    assert isinstance(bytes_0, object)
    # Testing if the type of second param 'gather_subset' is correct
    assert isinstance(b'abc', object)
    # Testing if function generates expected output
    assert ansible_facts(bytes_0, b'abc')


# Generated at 2022-06-24 21:43:11.439687
# Unit test for function ansible_facts
def test_ansible_facts():
    load_fixture('ansible_facts')
    load_fixture('ansible_facts')
    load_fixture('ansible_facts')
    load_fixture('ansible_facts')
    load_fixture('ansible_facts')
    load_fixture('ansible_facts')
    load_fixture('ansible_facts')
    load_fixture('ansible_facts')
    load_fixture('ansible_facts')
    assert callable(ansible_facts)



# Generated at 2022-06-24 21:43:15.860765
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(bytes,str) == True


# Generated at 2022-06-24 21:43:18.468206
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = ansible_facts(bytes_0)


# Generated at 2022-06-24 21:43:21.097625
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = ansible_facts(bytes_0)

# Generated at 2022-06-24 21:43:27.664628
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest

    from mock import MagicMock

    from ansible_collections.ansible.netcommon.plugins.module_utils.facts import ansible_collector

    m_ansible_collector__AnsibleFactCollector = MagicMock()
    ansible_collector.AnsibleFactCollector = m_ansible_collector__AnsibleFactCollector
    m_ansible_collector__AnsibleFactCollector.get_ansible_collector = MagicMock()
    m_ansible_collector__AnsibleFactCollector.get_ansible_collector.return_value = ''
    m_ansible_collector__AnsibleFactCollector.collect = MagicMock()
    m_ansible_collector__AnsibleFactCollector.collect.return_value = ''


# Generated at 2022-06-24 21:43:39.464944
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:43:41.263881
# Unit test for function ansible_facts
def test_ansible_facts():
    assert(isinstance(ansible_facts(None), dict))

# Generated at 2022-06-24 21:43:45.889693
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = ansible_facts(bytes_0)


# Generated at 2022-06-24 21:45:12.207801
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xc3\xfb\xc8@w\x8a\x1a)d\x82\x82\xf8\x83\xc1F\x81'
    module_0 = bytes_0
    dict_0 = ansible_facts(module_0)

    bytes_1 = b'1\x80ek\xe4\x88?\x87\x10\xac\xfe\xf6\xdb\x94\x8e'
    module_1 = bytes_1
    dict_1 = ansible_facts(module_1)


# Generated at 2022-06-24 21:45:13.113978
# Unit test for function ansible_facts
def test_ansible_facts():
    assert not ansible_facts()


# Generated at 2022-06-24 21:45:17.578970
# Unit test for function ansible_facts
def test_ansible_facts():
    ret_2 = None
    ansible_2 = None

    # PASS: Call ansible_facts(module: None, gather_subset: None)
    pass
    # PASS: No exception was thrown()



# Generated at 2022-06-24 21:45:22.014212
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'9\xdc\xe0+\xdd\x00\xc8\xab\x08'
    int_0 = test_case_0()
    var_0 = ansible_facts(bytes_0, int_0)
    if (var_0 != int_0):
        print("ansible_facts: ERROR - 0")


# Generated at 2022-06-24 21:45:29.479998
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xbb\xc5\xb1\x0b\x0e\xcd\xea\xb8\xcb\x80 \x07\xaa\x8e\x07{\n\xda\x7f\x1e\x7f\xe1\x15'
    var_0 = ansible_facts(bytes_0)


# Generated at 2022-06-24 21:45:33.901934
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    var_0 = ansible_facts(bytes_0)


# Generated at 2022-06-24 21:45:42.235747
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    my_param_0 = ansible_collector.AnsibleEthtoolCollector
    my_param_1 = my_param_0[0].capitalize()
    my_param_2 = default_collectors._get_fact_classes(namespace=PrefixFactNamespace)
    my_param_3 = my_param_2.replace('.', '').split('\n')
    my_param_4 = my_param_0.get(my_param_2)
    my_param_5 = my_param_4.encode()
    my_param_6 = my_param_5.strip

# Generated at 2022-06-24 21:45:46.414705
# Unit test for function ansible_facts
def test_ansible_facts():
    for _ in range(4):
        bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
        var_0 = ansible_facts(bytes_0)

# Generated at 2022-06-24 21:45:48.708438
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        assert get_all_facts('ansible_eth0') == 'ansible_eth0'
    except AssertionError:
        raise


# Generated at 2022-06-24 21:45:52.947014
# Unit test for function get_all_facts
def test_get_all_facts():
    bytes_0 = b'\x89\x8a\x85\xdbv\x8c|`\xcd\t\xd7\xe7\xfd'
    # verify the result is correct type
    assert isinstance(get_all_facts(bytes_0), dict)
