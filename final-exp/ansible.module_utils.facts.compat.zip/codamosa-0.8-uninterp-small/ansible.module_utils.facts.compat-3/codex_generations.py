

# Generated at 2022-06-24 21:37:56.399600
# Unit test for function get_all_facts
def test_get_all_facts():
    assert callable(get_all_facts)
    assert isinstance(int(), object)
    assert isinstance(int(123), object)
    assert isinstance(dict(), object)
    assert isinstance(dict(a=1, b=2), object)
    assert isinstance(list(), object)
    assert isinstance(list(range(10)), object)
    assert isinstance(set(), object)
    assert isinstance(set(range(10)), object)
    assert isinstance(slice(), object)
    assert isinstance(slice(10), object)
    assert isinstance(str(), object)
    assert isinstance(str('abc'), object)
    assert isinstance(bytes(), object)
    assert isinstance(bytes(10), object)
    assert isinstance(bytes(range(10)), object)
    assert isinstance(object(), object)

# Generated at 2022-06-24 21:37:57.774605
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -2116
    assert ansible_facts(int_0)


# Generated at 2022-06-24 21:38:07.089396
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -2116
    int_1 = 9412
    int_2 = 3008
    int_3 = 846269549
    int_4 = 5237
    int_5 = -213763127
    int_6 = -757673859
    int_7 = 8532473
    int_8 = -745051399
    int_9 = 3789
    int_10 = 0
    int_11 = -537154867
    int_12 = -58885515
    int_13 = -753711558
    int_14 = -632908565
    int_15 = -175786407
    int_16 = -222739809
    int_17 = -966195059
    int_18 = 562449575
    int_19 = 782817761


# Generated at 2022-06-24 21:38:15.147302
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:38:17.893256
# Unit test for function get_all_facts
def test_get_all_facts():
    assert callable(get_all_facts)


# Generated at 2022-06-24 21:38:20.362071
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test with valid arguments:
    int_0 = -2116
    var_0 = get_all_facts(int_0)
    assert var_0


# Generated at 2022-06-24 21:38:24.579001
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -2116
    var_0 = get_all_facts(int_0)



# Generated at 2022-06-24 21:38:36.352777
# Unit test for function ansible_facts
def test_ansible_facts():

    import ansible.module_utils.facts.hardware as hardware
    import ansible.module_utils.facts.system as system

    import mock
    import sys

    # Mock out all the imports that are not used by the function to be tested
    sys.modules['json'] = mock.MagicMock()
    sys.modules['json.decoder'] = mock.MagicMock()
    sys.modules['json.decoder.JSONDecodeError'] = mock.MagicMock()
    sys.modules['platform'] = mock.MagicMock()
    sys.modules['configparser'] = mock.MagicMock()
    sys.modules['subprocess'] = mock.MagicMock()
    sys.modules['subprocess.Popen'] = mock.MagicMock()
    sys.modules['subprocess.PIPE'] = mock.MagicMock()


# Generated at 2022-06-24 21:38:43.727139
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = 1
    int_1 = -1
    int_2 = 0
    var_0 = get_all_facts(int_0)
    var_1 = get_all_facts(int_1)
    var_2 = get_all_facts(int_2)
    assert var_0 == var_1 == var_2, "Fact did not return equal values"


# Generated at 2022-06-24 21:38:45.156759
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -2116
    var_0 = ansible_facts(int_0)


# Generated at 2022-06-24 21:38:51.928487
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -2116
    var_0 = ansible_facts(int_0)

if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:38:54.335576
# Unit test for function ansible_facts
def test_ansible_facts():
    # mock ansible module
    module = MockAnsibleModule()

    # test
    namespace = ansible_facts(module)
    assert namespace.get(u'localhost') is None



# Generated at 2022-06-24 21:38:56.022991
# Unit test for function ansible_facts
def test_ansible_facts():
    args = { }
    rv = ansible_facts(**args)

    assert rv is not None

# Generated at 2022-06-24 21:39:07.140425
# Unit test for function get_all_facts
def test_get_all_facts():
    p = Patch()
    int_0 = -2977
    str_0 = "a*fhv"
    str_1 = "wAcJ.>j"
    dict_0 = {str_0: var_0}
    dict_1 = {str_1: var_0}
    set_0 = frozenset({var_0, dict_0, dict_1})
    dict_2 = {str_0: var_0}
    dict_3 = {str_1: var_0}
    set_1 = frozenset({var_0, dict_2, dict_3})
    dict_4 = {str_0: var_0}
    dict_5 = {str_1: var_0}
    set_2 = frozenset({var_0, dict_4, dict_5})
   

# Generated at 2022-06-24 21:39:11.724277
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -2116
    var_0 = get_all_facts(int_0)

# Generated at 2022-06-24 21:39:23.421794
# Unit test for function get_all_facts

# Generated at 2022-06-24 21:39:26.441418
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -2116
    var_0 = ansible_facts(int_0)


if __name__ == '_' + '_main_' + '_':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:39:37.139684
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test: basic selection everything
    module = AnsibleModule(argument_spec=dict(gather_subset='all',
                                              fact_path='/usr/share/ansible',
                                              filter='*',
                                              vars='',
                                              gather_timeout=10))

# Generated at 2022-06-24 21:39:47.238192
# Unit test for function ansible_facts
def test_ansible_facts():
    src0 = "/etc/hosts"
    src1 = "/etc/hosts"
    src2 = "/etc/hosts"
    src3 = "/etc/hosts"
    src4 = "/etc/hosts"
    src5 = "/etc/hosts"
    src6 = "/etc/hosts"

    # Input arguments
    gather_subset = set(["min", "!all"])

    # Output return type
    ansible_facts_return_type = dict

# Generated at 2022-06-24 21:39:51.153458
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -2116
    var_0 = get_all_facts(int_0)



# Generated at 2022-06-24 21:39:56.936633
# Unit test for function get_all_facts
def test_get_all_facts():
    facts = get_all_facts(test_case_0)
    print(facts)
    assert facts is not None
    assert facts['distribution']['distribution'] is not None


# Generated at 2022-06-24 21:40:01.816035
# Unit test for function get_all_facts
def test_get_all_facts():
    var_0 = {}
    # Testing actual function output
    result = get_all_facts()



# Generated at 2022-06-24 21:40:10.843875
# Unit test for function ansible_facts
def test_ansible_facts():
    module = mock_module()
    cmd = 'module'
    out = 'out'
    rc = 0
    module.run_command.return_value = (rc, out, 'error')

    subject_0 = {'cmd': cmd, 'rc': rc, 'stdout': out, 'stderr': 'error', 'changed': True}

    # Test with no optional args
    result_0 = ansible_facts(module)
    assert result_0 == subject_0, "Expected {}, got {}".format(result_0, subject_0)




# Generated at 2022-06-24 21:40:11.805840
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True

# Generated at 2022-06-24 21:40:13.452369
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True


# Generated at 2022-06-24 21:40:18.466238
# Unit test for function ansible_facts
def test_ansible_facts():
    module = var_0
    gather_subset = {}
    
    
    
    
    ansible_facts(module, gather_subset=gather_subset)

# Generated at 2022-06-24 21:40:28.451063
# Unit test for function ansible_facts
def test_ansible_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(type='list'),
            gather_timeout = dict(type='int'),
            filter = dict(type='str'),
        ),
        supports_check_mode=True
    )

    # set up mock objects

    # set up test data

    # call the method under test
    result = ansible_facts(module)

    # check the result
    assert result == dict()
    # set up test data

    # call the method under test
    result = ansible_facts(module)

    # check the result
    assert result == dict()
    # set up test data

    # call the method under test
    result = ansible_facts(module)

    # check the result
    assert result == dict()
    # set up test data

    #

# Generated at 2022-06-24 21:40:36.764836
# Unit test for function ansible_facts
def test_ansible_facts():
    module = AnsibleModule({}, {}, {})

    # test with default args
    ansible_facts(module)
    ansible_facts(module, gather_subset=None)
    # test with explicit args
    ansible_facts(module, gather_subset=['all'])

    with pytest.raises(AssertionError):
        # gather_subsets is a required arg in 2.3/2.2, but not in 2.0/2.1
        ansible_facts(module, gather_subset=None)

    # test with gather_subsets
    ansible_facts(module, gather_subset=['all'])



# Generated at 2022-06-24 21:40:46.045726
# Unit test for function ansible_facts
def test_ansible_facts():
    import tempfile

    # create a dummy module for testing
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes

    def my_module(arguments):
        module = AnsibleModule(arguments=arguments)
        return module

    # create a fake ansible.module_utils.facts.cache._CACHE_FILE
    fake_cache_file = tempfile.NamedTemporaryFile(delete=False)
    fake_cache_file_name = fake_cache_file.name
    fake_cache_file.close()
    setattr(ansible_collector, '_CACHE_FILE', fake_cache_file_name)


# Generated at 2022-06-24 21:40:47.258575
# Unit test for function get_all_facts
def test_get_all_facts():
    assert False

# Generated at 2022-06-24 21:40:51.243050
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -2116
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:40:54.743018
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 0
    var_0 = ansible_facts(int_0)
    print('ANSIBLE_FACTS = {}'.format(var_0))

if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-24 21:40:55.342774
# Unit test for function get_all_facts
def test_get_all_facts():
    pass

# Generated at 2022-06-24 21:41:02.575275
# Unit test for function ansible_facts
def test_ansible_facts():
    ansible_facts_0 = '*'
    ansible_facts_1 = 'ansible_devices'
    ansible_facts_2 = 'ansible_machine'
    ansible_facts_3 = 'ansible_system'
    ansible_facts_4 = 'ansible_processor'
    ansible_facts_5 = 'ansible_kernel'
    var_0 = ansible_facts(ansible_facts_0, ansible_facts_4)
    var_1 = ansible_facts(ansible_facts_1, ansible_facts_5)
    var_2 = ansible_facts(ansible_facts_2, ansible_facts_3)

# Generated at 2022-06-24 21:41:04.500411
# Unit test for function get_all_facts
def test_get_all_facts():
    x = {}
    # Test case 0
    ret = get_all_facts(x)
    assert ret == 'return_value'


# Generated at 2022-06-24 21:41:06.186304
# Unit test for function get_all_facts
def test_get_all_facts():
    int_1 = -2116
    var_1 = get_all_facts(int_1)


# Generated at 2022-06-24 21:41:12.396329
# Unit test for function get_all_facts
def test_get_all_facts():
  try:
    test_case_0()
  except Exception as err:
    print("Caught exception: " + str(err))

test_get_all_facts()


# Generated at 2022-06-24 21:41:14.584113
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -2116
    var_0 = get_all_facts(int_0)
    assert var_0 == -2116


# Generated at 2022-06-24 21:41:20.409035
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        assert type(ansible_facts(int())) == dict
    except AssertionError:
        raise AssertionError("Argument has type '%s'" % type(ansible_facts(int())))

# Generated at 2022-06-24 21:41:26.644896
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True
    # assert get_all_facts(module=None,
    #                      gather_subset=None) == {'bogon_asic_io_enabled': 'false'}



# Generated at 2022-06-24 21:41:33.403987
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True == True

# Generated at 2022-06-24 21:41:35.176819
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -2116
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:41:40.168094
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -12
    var_0 = get_all_facts(int_0)

    assert var_0 == -12


# Generated at 2022-06-24 21:41:48.027936
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -2116
    tuple_0 = (int_0, )
    list_0 = [tuple_0] * 3
    list_1 = [int_0] * 2
    list_2 = []
    int_1 = -844

# Generated at 2022-06-24 21:41:57.655630
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test with single string input
    int_0 = -2116

    assert ansible_facts(int_0) == ansible_facts(int_0)
    # Test with single integer input
    int_1 = -2116

    assert ansible_facts(int_1) == ansible_facts(int_1)
    # Test with single tuple input
    int_2 = -2116
    int_3 = -2116

    assert ansible_facts(int_2, int_3) == ansible_facts(int_2, int_3)
    # Test with single list input
    int_4 = -2116
    int_5 = -2116

    assert ansible_facts(int_4, int_5) == ansible_facts(int_4, int_5)
    # Test with multiple string inputs
   

# Generated at 2022-06-24 21:41:59.740325
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -2116
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:42:03.196979
# Unit test for function get_all_facts
def test_get_all_facts():
    global int__0
    var_0 = -1637
    ansible_facts(var_0)

# Test case for importing ansible_facts module

# Generated at 2022-06-24 21:42:04.332115
# Unit test for function ansible_facts
def test_ansible_facts():
    assert 3 == 3


# Generated at 2022-06-24 21:42:06.993841
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(int_0) == var_0
#
# main() function
#

# Generated at 2022-06-24 21:42:12.377121
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -7237
    var_1 = ansible_facts(int_0)
    print(var_1)



# Generated at 2022-06-24 21:42:28.669895
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -2739
    var_1 = ansible_facts(int_0)


# Generated at 2022-06-24 21:42:30.156994
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -50
    var_0 = get_all_facts(int_0)
    if (var_0 is not None):
        raise Exception("Expected {}, but got {}".format(None, var_0) )


# Generated at 2022-06-24 21:42:31.770907
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 9912
    dict_0 = ansible_facts(int_0)


# Generated at 2022-06-24 21:42:37.137825
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -4157
    var_0 = ansible_facts(int_0)
    assert var_0 is None



# Generated at 2022-06-24 21:42:38.604828
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -2116
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:42:39.869724
# Unit test for function ansible_facts
def test_ansible_facts():
    # Input parameters tests
    assert isinstance(ansible_facts(int_0), dict)



# Generated at 2022-06-24 21:42:45.866170
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        func_0 = get_all_facts(int_0)
    except NameError:
        pass

    func_1 = get_all_facts(int_1)
    assert func_1['fqdn'] == 'localhost.localdomain'



# Generated at 2022-06-24 21:42:51.989943
# Unit test for function ansible_facts
def test_ansible_facts():
    var_0 = mock.MagicMock(name='ansible_facts', return_value=['apparmor', 'caps', 'cmdline', 'date_time', 'distribution', 'dns', 'env', 'fips', 'local', 'lsb', 'pkg_mgr', 'platform', 'python', 'selinux', 'service_mgr', 'ssh_pub_keys', 'user'])
    var_1 = mock.MagicMock(name='gather_subset', return_value=[])
    var_2 = mock.MagicMock(name='gather_timeout', return_value=10)
    var_3 = mock.MagicMock(name='filter', return_value='*')
    test_case_0(var_0, var_1, var_2, var_3)

# Generated at 2022-06-24 21:42:59.065830
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -9606
    dict_0 = ansible_facts(int_0)

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        call_function_name = sys.argv[1]
        globals()[call_function_name]()
    else:
        print("No function specified to call")

# Generated at 2022-06-24 21:43:04.886548
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:43:39.521680
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -2116
    var_0 = ansible_facts(int_0)
    print(var_0)


##            modname = get_module_name()
##            obj = None
##            custom_facts = {}
##
##            # sys.path manipulations to find and import base/extending modules
##            # add path of module to sys.path to make sure we can import it
##            if module.params['_original_basepath']:
##                # if the module being called is already on disk, we don't need to do anything
##                # but if somebody is calling a module from a location other than the default
##                # library path (i.e. a role) then we need to help them out
##                basepaths = [module.params['_original_basepath']]
##                file_path

# Generated at 2022-06-24 21:43:42.066841
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -2116
    var_0 = ansible_facts(int_0)
    assert var_0 == int_0


# Generated at 2022-06-24 21:43:44.913213
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -54687
    var_0 = ansible_facts(int_0, "gather_subset")

# Generated at 2022-06-24 21:43:54.305553
# Unit test for function ansible_facts
def test_ansible_facts():
    list_0 = [False, True]
    list_1 = [False, True]
    bool_0 = bool(int_0)
    bool_1 = bool(int_0)
    int_0 = -2116
    dict_0 = dict((35, -5.39822915622055E+17), (79, -2.42862379671712E+18), (81, 1.38604065028179E+18), (10, 9.17277771870053E+17))
    list_2 = [dict_0]

# Generated at 2022-06-24 21:43:59.551425
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = '<module>'
    var_0 = ansible_facts(str_0)
    str_1 = 'main'
    var_1 = ansible_facts(str_1, str_0)
    str_2 = '<module>'
    var_2 = ansible_facts(str_2, var_1)
    str_3 = 'main'
    var_3 = ansible_facts(str_3, str_2)


# Generated at 2022-06-24 21:44:05.830741
# Unit test for function ansible_facts
def test_ansible_facts():
    # Mocking a module
    class Module:
        def __init__(self):
            self.params = {'gather_subset':['all']}
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'
    
    module = Module()
    ansible_facts(module=module)


# Generated at 2022-06-24 21:44:07.049353
# Unit test for function get_all_facts
def test_get_all_facts():
    get_all_facts(
        module={
            'gather_subset': 'foo'
        }
    )



# Generated at 2022-06-24 21:44:14.399140
# Unit test for function ansible_facts
def test_ansible_facts():
    # set up test input
    ansible_facts_module = None

    ansible_facts_gather_subset = ['!all']


# Generated at 2022-06-24 21:44:16.879489
# Unit test for function get_all_facts
def test_get_all_facts():
    assert('The module_utils.facts.get_all_facts method is not yet implemented. Please see '
           'https://github.com/ansible/ansible/issues/60444 for more information.' == get_all_facts())

# Generated at 2022-06-24 21:44:18.272864
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ('cmdline' in ansible_facts({'gather_subset': ['all']}))

# Generated at 2022-06-24 21:45:10.283346
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        int_0 = -2116
        get_all_facts(int_0)
    except Exception:
        raise



# Generated at 2022-06-24 21:45:12.986460
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test function_exists
    assert 'test_case_0' in globals(), 'function: test_case_0 not found'
    try:
        test_case_0()
    except Exception as e:
        if 'actual: ' not in str(e):
            raise e


# Generated at 2022-06-24 21:45:16.482463
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -2116
    var_0 = get_all_facts(int_0)



# Generated at 2022-06-24 21:45:24.743352
# Unit test for function ansible_facts
def test_ansible_facts():
    import tempfile
    import os
    import yaml
    import mock
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.system import system_collector
    from ansible.module_utils.facts.virtual import virtual_collector

    sys_collector = system_collector.VirtualSystemCollector()
    virt_collector = virtual_collector.LinuxVirtualCollector()
    surpress_warnings = False
    log = mock.Mock()
    gather_subset = 'minimal'
    gather_timeout = 1
    filter_spec = '*'
    all_collector_classes = default_collectors.collectors
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    fact_collector = \
        ansible_

# Generated at 2022-06-24 21:45:29.479459
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -5828
    int_1 = -10
    int_2 = -3785
    str_0 = u'*.capabilities.*'
    var_0 = ansible_facts(int_0, int_1)
    var_1 = ansible_facts(int_1, str_0)
    var_2 = ansible_facts(int_2)

# Generated at 2022-06-24 21:45:30.388252
# Unit test for function ansible_facts
def test_ansible_facts():
    assert  ansible_facts() == 2

# Generated at 2022-06-24 21:45:34.051493
# Unit test for function ansible_facts
def test_ansible_facts():
    ansible_facts_unittest(ansible_facts, "/home/travis/build/test-ansible/test-ansible/test/test_utils.py")

# Generated at 2022-06-24 21:45:39.019709
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = -2116
    var_0 = ansible_facts(int_0)
    assert isinstance(var_0, dict)
    assert len(var_0) == 0

if __name__ == '__main__':
    import sys

    print(__file__)
    print(globals().get('__doc__'))
    for test_name, test_impl in list(globals().items()):
        if test_name.startswith('test_'):
            print('%s: %s' % (test_name, test_impl.__doc__))
            test_impl()

# Generated at 2022-06-24 21:45:46.457063
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:45:48.092004
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = -2116
    var_0 = get_all_facts(int_0)
