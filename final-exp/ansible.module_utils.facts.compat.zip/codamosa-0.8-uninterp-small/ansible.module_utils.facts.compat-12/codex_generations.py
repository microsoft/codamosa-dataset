

# Generated at 2022-06-24 21:37:53.184216
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1876.27
    var_0 = ansible_facts(float_0)
    print(var_0)


if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:37:57.220705
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts (float_0)

# Generated at 2022-06-24 21:37:57.980613
# Unit test for function ansible_facts
def test_ansible_facts():
    assert callable(ansible_facts)


# Generated at 2022-06-24 21:37:58.863613
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True
    test_case_0()

# Generated at 2022-06-24 21:38:02.439694
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -987.813
    bool_0 = False

    var_0 = ansible_facts(float_0, bool_0)

    assert var_0 == False


# Generated at 2022-06-24 21:38:05.208205
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(float_0) == float_0
    #assert ansible_facts(str_0, str_1) == str_1
    #assert ansible_facts(dict_0, str_0) == str_1

# Generated at 2022-06-24 21:38:06.303527
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = 577.67
    var_0 = ansible_facts(float_0)
    assert var_0 is None

# Generated at 2022-06-24 21:38:11.184597
# Unit test for function ansible_facts
def test_ansible_facts():
    x_0 = ansible_facts(x_1)
    x_1 = AnsibleModule(ansible_facts, ansible_facts)
    x_2 = get_all_facts(x_1)
    x_3 = get_all_facts(x_1)
    x_4 = ansible_facts(x_1)
    x_5 = ansible_facts(x_1)
    x_6 = ansible_facts(x_1)
    x_7 = ansible_facts(x_1)
    x_8 = ansible_facts(x_1)
    x_9 = ansible_facts(x_1)
    x_10 = ansible_facts(x_1)
    x_11 = ansible_facts(x_1)

# Generated at 2022-06-24 21:38:15.469378
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)

    try:
        float_1 = -832.67
        str_0 = 'fips'
        ansible_facts(float_1, str_0)
    except NameError:
        pass

# Generated at 2022-06-24 21:38:18.992885
# Unit test for function get_all_facts
def test_get_all_facts():
    # Checking with float as argument
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-24 21:38:26.962401
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -15
    dict_0 = { 'gather_subset': ['all'], 'gather_timeout': 10,
               'filter': '*', 'name': 'test_arg_var' }

    var_0 = ansible_facts(dict_0, float_0)

    assert var_0[True]

# Generated at 2022-06-24 21:38:37.407377
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts == test_ansible_facts
    var_0 = -2.78
    var_1 = ansible_facts(var_0)
    assert var_1 == 2.78
    var_2 = -727.35
    var_3 = ansible_facts(var_2, 15)
    assert var_3 == 727.35
    var_4 = -2.03
    var_5 = ansible_facts(var_4, 9)
    assert var_5 == 2.03
    var_6 = -1398.8
    var_7 = ansible_facts(var_6, 9)
    assert var_7 == 1398.8
    var_8 = -2.59
    var_9 = ansible_facts(var_8, 8)
    assert var_9 == 2.59

# Generated at 2022-06-24 21:38:48.677482
# Unit test for function ansible_facts
def test_ansible_facts():
    # fake args needed by AnsibleModule
    fake_args = dict(
        gather_subset='fake_gather_subset',
        gather_timeout='fake_gather_timeout',
        filter='fake_filter',
        files='fake_files'
    )

    fake_module = None

# Generated at 2022-06-24 21:38:54.879798
# Unit test for function ansible_facts
def test_ansible_facts():
    param = {
        'gather_subset': 'all'
    }

    ansible_facts(param)

# Unit tests for function test_case_0

# Generated at 2022-06-24 21:38:57.964926
# Unit test for function ansible_facts
def test_ansible_facts():
    # module, gather_subset = None
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)
    print(var_0)

if __name__ == "__main__":

    test_case_0()
    # test_ansible_facts()

# Generated at 2022-06-24 21:39:05.481878
# Unit test for function ansible_facts
def test_ansible_facts():
    # Create a dummy AnsibleModule for testing.
    class AnsibleModule(object):
        def __init__(self, params):
            self.params = params

    module = AnsibleModule({'gather_subset': ['!all']})

    # Test case 0.
    print('test_case_0')
    float_0 = -1424.59
    ansible_facts(module, gather_subset=float_0)


if __name__ == "__main__":
    # Unit test case 0
    test_ansible_facts()

# Generated at 2022-06-24 21:39:09.570138
# Unit test for function get_all_facts
def test_get_all_facts():
    var_1 = 17.9
    get_all_facts(var_1)


# Generated at 2022-06-24 21:39:11.978937
# Unit test for function get_all_facts
def test_get_all_facts():
    float_0 = -1424.59
    var_0 = get_all_facts(float_0)
    var_0 = get_all_facts(float_0)
    return var_0


# Generated at 2022-06-24 21:39:22.516693
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        import json
    except ImportError:
        import simplejson as json

    class AnsibleModule:
        def __init__(self, gather_subset=None):
            self.params = dict(gather_subset=gather_subset)

    am = AnsibleModule()
    am.params['gather_timeout'] = 10

    all_facts = ansible_facts(am)

    keys = list(all_facts.keys())
    keys.sort()
    for k in keys:
        print(k, json.dumps(all_facts[k]))


if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:39:25.430149
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -6197.97
    var_0 = ansible_facts(float_0)


if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:39:29.340769
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts, "ansible_facts()"

# Generated at 2022-06-24 21:39:34.168080
# Unit test for function ansible_facts
def test_ansible_facts():
    dest_dir = './test/unit/output/ansible_facts'
    try:
        os.makedirs(dest_dir)
    except OSError as exc:  # Python >2.5
        if exc.errno == errno.EEXIST and os.path.isdir(dest_dir):
            pass
        else:
            raise
    float_0 = -1424.59
    assert ansible_facts(float_0) == {}



# Generated at 2022-06-24 21:39:37.636277
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)
    print(var_0)


# Generated at 2022-06-24 21:39:39.067152
# Unit test for function get_all_facts
def test_get_all_facts():
    var_0 = ansible_facts(float_0)
    assert var_0 is not None



# Generated at 2022-06-24 21:39:46.814856
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts({'DUMMY'}, ['apparmor', 'caps', 'cmdline', 'date_time', 'distribution', 'dns', 'env', 'fips', 'local', 'lsb', 'pkg_mgr', 'platform', 'python', 'selinux', 'service_mgr', 'ssh_pub_keys', 'user'])
    assert ansible_facts({'DUMMY'}, ['apparmor', 'caps', 'cmdline', 'date_time'])
    assert ansible_facts({'DUMMY'})



# Generated at 2022-06-24 21:39:57.975096
# Unit test for function ansible_facts
def test_ansible_facts():
    module_0 = mock_ansible_module()

    # Case 1: gather_subset has none of the elements of minimal_gather_subset
    gather_subset_0 = ['all']
    filter_spec_0 = '*'
    float_0 = 3102.95
    float_1 = -2096.25
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()

# Generated at 2022-06-24 21:40:05.292555
# Unit test for function get_all_facts
def test_get_all_facts():
    ansible_0 = {
        'gather_timeout': -49,
        'filter': '*',
        'gather_subset': [
            'all'
        ]
    }
    float_0 = -1424.59

    with pytest.raises(TypeError):
        get_all_facts(float_0)

    ansible_1 = {
        'gather_timeout': -49,
        'filter': '*',
        'gather_subset': [
            'all'
        ]
    }
    str_0 = 'str'

    with pytest.raises(TypeError):
        get_all_facts(str_0)


# Generated at 2022-06-24 21:40:09.825369
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)
    assert var_0 == ''

# Generated at 2022-06-24 21:40:11.264174
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        ansible_facts(float_1)
    except NameError:
        pass



# Generated at 2022-06-24 21:40:20.381418
# Unit test for function ansible_facts
def test_ansible_facts():
    # Source: Inputs
    gather_subset = ['all', 'network', 'hardware', 'virtual']

# Generated at 2022-06-24 21:40:26.798955
# Unit test for function get_all_facts
def test_get_all_facts():
    float_0 = -1424.59
    var_0 = get_all_facts(float_0)
    assert var_0 == False



# Generated at 2022-06-24 21:40:30.439212
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible_module_test import AnsibleModule
    module = AnsibleModule()
    ansible_facts(module)


if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:40:34.542675
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)

# For testing AnsibleFacts.
if __name__ == '__main__':
    import sys
    import unittest

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestAnsibleFacts))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(not result.wasSuccessful())

# Generated at 2022-06-24 21:40:39.884217
# Unit test for function get_all_facts
def test_get_all_facts():
    assert func_0() == 'F'


# Generated at 2022-06-24 21:40:48.607582
# Unit test for function ansible_facts
def test_ansible_facts():
    hostname = "10.10.10.45"
    ipaddress = "10.10.10.45"
    macaddress = "44:38:39:ff:ef:57"
    interface = "enp0s8"
    module = "ansible_facts"
    ansible_architecture = "x86_64"
    ansible_bios_date = "12/01/2006"
    ansible_bios_version = "6.00"

# Generated at 2022-06-24 21:40:50.729290
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts('apparmor') == ('float_1', 'float_2', 'var_0')


# Generated at 2022-06-24 21:40:55.248387
# Unit test for function get_all_facts
def test_get_all_facts():
    # Test any exceptions raised
    try:
        test_case_0()
    except:
        assert False, 'An exception is raised'
    else:
        pass
    # Test return type
    assert isinstance(test_case_0(), dict), 'Return type of function "get_all_facts" is not a dict'


# Generated at 2022-06-24 21:40:57.556534
# Unit test for function ansible_facts
def test_ansible_facts():
    with pytest.raises(AnsibleFilterError):
        float_0 = -1424.59
        var_0 = ansible_facts(float_0)

# Generated at 2022-06-24 21:40:58.683078
# Unit test for function ansible_facts
def test_ansible_facts():
    assert not isinstance(ansible_facts(), str)


# Generated at 2022-06-24 21:41:03.085907
# Unit test for function get_all_facts
def test_get_all_facts():
    print("get_all_facts test")
    test_case_0()

# Generated at 2022-06-24 21:41:15.934129
# Unit test for function ansible_facts
def test_ansible_facts():
    # Defining a test case 0
    float_0 = -74.455
    # Defining a test case 1
    int_0 = -2725
    float_1 = -60.57
    # Defining a test case 2
    int_1 = -2071
    float_2 = -6.75
    int_2 = -1666
    # Defining a test case 3
    int_3 = -8
    float_3 = -62.61
    # Defining a test case 4
    int_4 = -2
    # Defining a test case 5
    int_5 = -68
    float_4 = -38.41
    # Defining a test case 6
    int_6 = -258
    float_5 = -58.35
    # Defining a test case 7
    int_7 = -838

# Generated at 2022-06-24 21:41:18.991400
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True == True  # TODO: implement your test here


# Generated at 2022-06-24 21:41:27.138336
# Unit test for function ansible_facts
def test_ansible_facts():
    # Setup test data
    # Runtime variable 1, type: <type 'dict'>
    my_hostname = {"hostname": "foo.local"}

    # Runtime variable 2, type: <type 'dict'>
    my_os = {"os_family": "RedHat"}

    # Runtime variable 3, type: <type 'dict'>
    my_distribution = {"version": "7.7", "name": "CentOS"}

    # Runtime variable 4, type: <type 'dict'>
    my_distribution_release = {"name": "Final", "full": "Final"}

    # Runtime variable 5, type: <type 'dict'>
    my_distribution_codename = {"version": "7.7", "name": "CentOS Linux 7.7.1908"}

    # Runtime variable 6, type: <type 'dict'>
    my_

# Generated at 2022-06-24 21:41:27.774898
# Unit test for function get_all_facts
def test_get_all_facts():
    assert 1 == 1

# Generated at 2022-06-24 21:41:38.570062
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)
    float_1 = -1211.30
    var_1 = ansible_facts(float_1)
    float_2 = -1719.88
    var_2 = ansible_facts(float_2)
    float_3 = 1713.41
    var_3 = ansible_facts(float_3)
    float_4 = -1472.42
    var_4 = ansible_facts(float_4)
    float_5 = 237.50
    var_5 = ansible_facts(float_5)
    float_6 = -1702.69
    var_6 = ansible_facts(float_6)
    float_7 = 1301.76

# Generated at 2022-06-24 21:41:40.118233
# Unit test for function ansible_facts
def test_ansible_facts():
    assert callable(ansible_facts)


# Generated at 2022-06-24 21:41:42.194629
# Unit test for function get_all_facts
def test_get_all_facts():
    float_0 = -1424.59
    assert (get_all_facts(float_0) == 'NameError')


# Generated at 2022-06-24 21:41:44.407333
# Unit test for function get_all_facts
def test_get_all_facts():
    var_1 = -748.37
    var_0 = get_all_facts(var_1)
    assert var_0 == -748.37

# Generated at 2022-06-24 21:41:49.581630
# Unit test for function ansible_facts
def test_ansible_facts():
    for test_case in test_cases:
        test_case()


# Generated at 2022-06-24 21:41:50.817337
# Unit test for function ansible_facts
def test_ansible_facts():
    var_1 = ansible_facts(var_0)
    assert var_1 == None

# Generated at 2022-06-24 21:42:06.167575
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)


if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:42:08.273020
# Unit test for function ansible_facts
def test_ansible_facts():
    # This is a dummy test case
    assert True == True, "Test case 0 failed!"

# Generated at 2022-06-24 21:42:11.490784
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)


# Generated at 2022-06-24 21:42:19.571567
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Mock an instance of AnsibleModule, and mock the '_ansiballz_facts' module action.
    relative to the 'ansible.module_utils.facts' module
    '''
    from ansible.module_utils.facts import AnsibleModule
    from ansible.module_utils.facts.facts import _ansiballz_facts

    from ansible.module_utils.facts.parsers import default_parser
    from ansible.module_utils.facts.collectors import base
    from ansible.module_utils.facts.collectors.hardware.dmi import DMIHardwareCollector
    from ansible.module_utils.facts.collectors.hardware.ps import PSHardwareCollector
    from ansible.module_utils.facts.collectors.network.azure import AzureCloudCollector

# Generated at 2022-06-24 21:42:21.240364
# Unit test for function get_all_facts
def test_get_all_facts():
    # Basic test for function get_all_facts
    # Insert your code here
    assert True == True

# Generated at 2022-06-24 21:42:22.176689
# Unit test for function get_all_facts
def test_get_all_facts():
    pass

# Generated at 2022-06-24 21:42:24.582743
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)


# Generated at 2022-06-24 21:42:33.736502
# Unit test for function ansible_facts
def test_ansible_facts():
    import json

    # Fixture 1 #
    float_0 = -1424.59
    subset_0 = '*'
    filter_spec_0 = None
    gather_timeout_0 = -1424.59
    expected_0 = None
    actual_0 = ansible_facts(float_0, subset_0, filter_spec_0, gather_timeout_0)
    print('Results 0...')
    pprint(actual_0)
    assert expected_0 == actual_0

    # Fixture 2 #
    float_0 = -1424.59
    subset_0 = '*'
    filter_spec_0 = None
    gather_timeout_0 = 10
    expected_0 = None

# Generated at 2022-06-24 21:42:35.218954
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)

# Generated at 2022-06-24 21:42:35.998898
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True == True # implemented

# Generated at 2022-06-24 21:43:01.452872
# Unit test for function ansible_facts
def test_ansible_facts():
    var_0 = ansible_facts()

# Generated at 2022-06-24 21:43:02.900580
# Unit test for function get_all_facts
def test_get_all_facts():
    assert get_all_facts('get_all_facts') == 'get_all_facts'


# Generated at 2022-06-24 21:43:04.049465
# Unit test for function get_all_facts
def test_get_all_facts():
    assert callable(get_all_facts)


# Generated at 2022-06-24 21:43:09.846794
# Unit test for function get_all_facts
def test_get_all_facts():
    float_0 = -1424.59
    assert get_all_facts(float_0) is not None


# Generated at 2022-06-24 21:43:13.223003
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)
    # All tests should pass, but we don't want to use the values
    test_data = [(var_0, -1424.59)]
    for actual, expected in test_data:
        assert actual == expected

# Generated at 2022-06-24 21:43:17.588785
# Unit test for function get_all_facts
def test_get_all_facts():
    float_0 = -1424.59
    var_0 = get_all_facts(float_0)



# Generated at 2022-06-24 21:43:19.964827
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)


if __name__ == "__main__":
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:43:24.792762
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)


# Generated at 2022-06-24 21:43:27.063111
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)


'''
=====================================================================================
  NO_OUTPUT_TEST

=====================================================================================
'''



# Generated at 2022-06-24 21:43:37.111708
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceCollector
    from ansible.module_utils.facts.namespace import resolve_collector_classes

    from ansible.module_utils.six import iteritems

    collector_classes = default_collectors.collectors
    fact_collector = ansible_collector.get_ansible_collector(all_collector_classes=collector_classes)
    facts_dict = fact_collector.collect(module=float_0)

    facts_dict = fact_collect

# Generated at 2022-06-24 21:44:34.266352
# Unit test for function get_all_facts
def test_get_all_facts():
    float_0 = -1424.59
    var_0 = get_all_facts(float_0)
    var_0 = get_all_facts(float_0)
    var_0 = get_all_facts(float_0)
    assert var_0 == -1424.59


# Generated at 2022-06-24 21:44:35.689056
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts('test_default').get('test_default') == None


# Generated at 2022-06-24 21:44:40.462133
# Unit test for function get_all_facts
def test_get_all_facts():
    var_0 = None
    var_0 = get_all_facts(var_0)
    assert var_0 == '''
'''


# Generated at 2022-06-24 21:44:45.031528
# Unit test for function get_all_facts
def test_get_all_facts():
    float_0 = -1424.59
    var_0 = get_all_facts(float_0)
    # Return should not be null
    assert var_0
    # Return should be a dict
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 21:44:47.284853
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -711.07
    var_0 = ansible_facts(float_0)
    assert var_0 == 3

# Generated at 2022-06-24 21:44:48.217427
# Unit test for function get_all_facts
def test_get_all_facts():
    pass


# Generated at 2022-06-24 21:44:51.073097
# Unit test for function ansible_facts
def test_ansible_facts():
    print("Testing function: ansible_facts")
    assert ansible_facts(None, gather_subset=None)


# Generated at 2022-06-24 21:44:55.505873
# Unit test for function ansible_facts
def test_ansible_facts():
    var_2 = 3

# Generated at 2022-06-24 21:44:56.630267
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible
    assert ansible.VERSION <= '2.4'



# Generated at 2022-06-24 21:44:58.027910
# Unit test for function get_all_facts
def test_get_all_facts():
    float_0 = -1424.59
    var_0 = get_all_facts(float_0)
    assert not var_0


# Generated at 2022-06-24 21:46:51.497905
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)

# Generated at 2022-06-24 21:46:53.653619
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_0 = ansible_facts(float_0)
    if var_0 == 1:
        return var_0
    else:
        return None

# Generated at 2022-06-24 21:46:54.869272
# Unit test for function get_all_facts
def test_get_all_facts():
    print("testing function get_all_facts")
    test_case_0()


# Generated at 2022-06-24 21:46:56.730361
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = -1424.59
    var_1 = ansible_facts(float_0)
    var_1 = ansible_facts(float_0, subset=[])


# Generated at 2022-06-24 21:46:58.963556
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = 1.2
    var_0 = get_all_facts(float_0)
    assert var_0 != 1.2
    assert var_0 == 1.2

# Generated at 2022-06-24 21:47:02.054882
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        test_case_0()
    except:
        print("An exception occurred in test case 0")


# Generated at 2022-06-24 21:47:03.915170
# Unit test for function get_all_facts
def test_get_all_facts():
    var_0 = ansible_facts(test_case_0)


if __name__ == '__main__':
    test_get_all_facts()

# Generated at 2022-06-24 21:47:05.632141
# Unit test for function ansible_facts
def test_ansible_facts():
    var_6 = 552.41
    var_1 = ansible_facts(var_6)


# Generated at 2022-06-24 21:47:06.706215
# Unit test for function ansible_facts
def test_ansible_facts():
    assert False



# Generated at 2022-06-24 21:47:09.932011
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test case for when gather_subset is not specified.
    # The default gather_subset is set to ['all'].
    gather_subset = None
    module = mock
    assert True == ansible_facts(module, gather_subset=gather_subset)