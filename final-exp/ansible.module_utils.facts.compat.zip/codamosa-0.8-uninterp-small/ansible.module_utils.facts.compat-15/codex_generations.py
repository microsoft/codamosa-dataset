

# Generated at 2022-06-24 21:37:50.982015
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ('f' in get_all_facts('i')) == False
    assert ('t' in ansible_facts('t')) == False

# Generated at 2022-06-24 21:37:51.515792
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True

# Generated at 2022-06-24 21:37:53.740788
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = 'e5t\'dW'
    var_0 = get_all_facts(str_0)
    assert var_0 is None


# Generated at 2022-06-24 21:37:58.816595
# Unit test for function get_all_facts
def test_get_all_facts():
    # Input parameters
    str_0 = 't/Wc}'
    # Output parameters
    expected_var_0 = 'string'
    # Perform the test
    test_case_0()
    # Validate the results
    assert var_0 == expected_var_0


# Generated at 2022-06-24 21:38:04.319147
# Unit test for function ansible_facts
def test_ansible_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(type='list'),
            gather_timeout = dict(type='int'),
            filter = dict(type='str'),
        )
    )

    # Get all facts
    all_facts = ansible_facts(module)
    assert('ansible_all_ipv4_addresses' in all_facts)

# Generated at 2022-06-24 21:38:05.817071
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't/Wc}'
    var_0 = ansible_facts(str_0)

# Generated at 2022-06-24 21:38:14.352712
# Unit test for function ansible_facts
def test_ansible_facts():
    """Unit test for function ansible_facts"""

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    module = ansible_collector.AnsibleCollectorBase()
    namespace = PrefixFactNamespace(namespace_name='test', prefix='test_')

    facts_dict = ansible_facts(module, ['all'])
    assert facts_dict

    # cleanup attributes added by the collector
    del module.ansible_facts
    del module.ansible_facts_cache


# Generated at 2022-06-24 21:38:24.466673
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = "WwKjNuiZ5"
    str_1 = "fKb^p.e"
    str_2 = "GwU>7"
    str_3 = "M-jX"
    str_4 = "C{I"
    str_5 = "g-<"
    str_6 = ":8q3"
    str_7 = "jnW"
    str_8 = "eTW"
    str_9 = "8S$"
    str_10 = "y,Q"
    str_11 = "i#<A5"
    str_12 = "9jNH"
    str_13 = "Uj"
    str_14 = "=ou"
    str_15 = "g^"
    str_16 = "N?N"
   

# Generated at 2022-06-24 21:38:27.228654
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(str)


# Generated at 2022-06-24 21:38:29.274379
# Unit test for function ansible_facts
def test_ansible_facts():
    print('=== ansible_facts:')
    ansible_facts('t/Wc}')

# Generated at 2022-06-24 21:38:41.011939
# Unit test for function ansible_facts
def test_ansible_facts():
    data = {'gather_subset': ['network'], 'gather_timeout': 10, 'filter': '*'}
    str_0 = 't/Wc}'

# Generated at 2022-06-24 21:38:50.062800
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = 't/Wc}'
    str_1 = '_Sz{'
    var_0 = get_all_facts(str_0)

# Generated at 2022-06-24 21:38:56.955304
# Unit test for function ansible_facts
def test_ansible_facts():
    var_1 = ansible_facts()
    assert 'ansible_os_family' in var_1
    assert 'ansible_all_ipv4_addresses' in var_1
    assert 'ansible_architecture' in var_1
    assert 'ansible_bios_date' in var_1
    assert 'ansible_bios_version' in var_1
    assert 'ansible_cmdline' in var_1
    assert 'ansible_date_time' in var_1
    assert 'ansible_default_ipv4' in var_1
    assert 'ansible_distribution' in var_1
    assert 'ansible_distribution_release' in var_1
    assert 'ansible_distribution_version' in var_1
    assert 'ansible_hostname' in var_1


# Generated at 2022-06-24 21:39:01.726002
# Unit test for function get_all_facts
def test_get_all_facts(): # Change this name to test different unit
    test_case_0()

# Generated at 2022-06-24 21:39:02.622797
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True


# Generated at 2022-06-24 21:39:03.404603
# Unit test for function ansible_facts
def test_ansible_facts():
    pass


# Generated at 2022-06-24 21:39:04.659305
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True


# Generated at 2022-06-24 21:39:11.978175
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't/Wc}'
    str_1 = 't/Wc}'
    dict_2 = {'subset': 'all'}
    dict_0 = ansible_facts(str_0, gather_subset=str_1)
    dict_1 = ansible_facts(str_0)
    dict_3 = ansible_facts(str_0, gather_subset=dict_2)

# Generated at 2022-06-24 21:39:17.460217
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't/Wc}'
    str_1 = '`#H[r'
    var_0 = ansible_facts(str_0)
    var_1 = ansible_facts(str_0, gather_subset=str_1)


# Generated at 2022-06-24 21:39:19.134117
# Unit test for function get_all_facts
def test_get_all_facts():
    facts = get_all_facts(module)
    if facts:
        return 0
    else:
        raise Exception('Ansible core facts gathering failed')
        return 1



# Generated at 2022-06-24 21:39:28.300516
# Unit test for function ansible_facts
def test_ansible_facts():
    var_1 = 1
    var_2 = 1
    str_1 = 't/Wc}'
    str_2 = 't/Wc}'
    str_3 = 't/Wc}'
    var_3 = ansible_facts(str_1, gather_subset=var_1, gather_timeout=var_2, filter=str_2, ansible_facts={str_3})
    print(var_3)

# Generated at 2022-06-24 21:39:29.925726
# Unit test for function ansible_facts
def test_ansible_facts():

    str_0 = 't/Wc}'
    var_0 = ansible_facts(str_0)

# Generated at 2022-06-24 21:39:36.788509
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'q'
    str_1 = 's'
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    str_8 = ''
    value_0 = None
    str_9 = 'O1%'
    str_10 = ''
    str_11 = ''
    str_12 = ''
    str_13 = ''
    str_14 = ''
    str_15 = ''
    str_16 = ''
    str_17 = ''
    str_18 = ''
    str_19 = ''
    str_20 = 'X'
    str_21 = ''
    str_22 = 'ybH'
    str_23 = ''
    str_24 = '}G'


# Generated at 2022-06-24 21:39:38.339995
# Unit test for function ansible_facts
def test_ansible_facts():
    assert get_all_facts('zT/d]') == None
    assert ansible_facts(False) == None

# Generated at 2022-06-24 21:39:41.156324
# Unit test for function ansible_facts
def test_ansible_facts():
    with pytest.raises(TypeError):
        ansible_facts(str())

# Generated at 2022-06-24 21:39:50.279507
# Unit test for function ansible_facts
def test_ansible_facts():
    str_1 = 'g'
    str_2 = 't/Wc}'
    str_3 = 't/Wc}'
    str_4 = 't/Wc}'
    str_5 = 'z0X'
    str_6 = 'f'
    set_1 = set(['t/Wc}'])
    dict_1 = {'z0X': set_1}
    dict_2 = {'f': dict_1}
    var_1 = ansible_facts(str_1, str_2, str_3, str_4, str_5, str_6, set_1, dict_1, dict_2)

if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:39:51.848535
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'y{^d'
    fact_dict = ansible_facts(str_0, gather_subset=None)

# Generated at 2022-06-24 21:40:00.398631
# Unit test for function ansible_facts
def test_ansible_facts():
    function_name = "ansible_facts"

    # We'll load the module and make a mock AnsibleModule, and have it return
    # what we need for the various params
    module_path = 'ansible.module_utils.facts.ansible_collector'

    imported_items = __import__(module_path, globals(), locals(), ['AnsibleModule'], 0)
    AnsibleModule = imported_items.AnsibleModule
    ansible_module = AnsibleModule(argument_spec=dict())

    # AnsibleModule has a method called get_bin_path that returns a path to
    # a default executable when called with no args.  It caches the result
    # in a private var, and we need to clear that
    ansible_module._default_executable = None

    # So we can see what args were used to call

# Generated at 2022-06-24 21:40:07.362634
# Unit test for function ansible_facts
def test_ansible_facts():


    # Test case: 0
    # Passing an incorrect type for 'module' simulates a AnsibleModule that fails
    # with the message:
    #   "ansible_facts() got an unexpected keyword argument 'module'"
    # because get_ansible_facts() is expecting a AnsibleModule
    # expected behavior is that we get a TypeError.
    # actual behavior is that we get a AnsibleFailJson exception with a message that
    # is not a TypeError
    str_0 = 't/Wc}'
    try:
        get_all_facts(str_0)
    except TypeError:
        # Test case: 0
        # Test case: 1
        pass


test_ansible_facts()

# Generated at 2022-06-24 21:40:09.960864
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't/Wc}'
    var_0 = ansible_facts(str_0)


# Generated at 2022-06-24 21:40:21.966617
# Unit test for function ansible_facts
def test_ansible_facts():
    # str_0 is a string
    str_0 = 'ansible'
    # str_1 is a string
    str_1 = 't/Wc}'
    var_0 = ansible_facts(str_0, str_1)



# Generated at 2022-06-24 21:40:26.426704
# Unit test for function ansible_facts
def test_ansible_facts():
    str_1 = 't/Wc}'
    var_1 = ansible_facts(str_1)
    assert var_1 is not False


# Generated at 2022-06-24 21:40:27.957749
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts('ansible', ['all']) == {}

# Generated at 2022-06-24 21:40:31.138825
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't/Wc}'
    var_0 = ansible_facts(str_0)

if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:40:37.308282
# Unit test for function ansible_facts
def test_ansible_facts():
    """
    Unit test for function ansible_facts
    """

    import string
    import random
    import tempfile

    test_module_path = tempfile.mktemp()
    test_module_name = ''.join(random.choice(string.ascii_lowercase) for _ in range(random.randint(8, 16)))
    test_module_file = '{0}.py'.format(test_module_name)
    test_module_action = 'run'

# Generated at 2022-06-24 21:40:43.874050
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # Assign result of function 'ansible_facts' to a new variable
    ansible_facts_0 = ansible_facts(str_0)
    
    # Assert if the result of function 'ansible_facts' equals to 'None'
    assert ansible_facts_0 == None



# Generated at 2022-06-24 21:40:44.964025
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True

# Generated at 2022-06-24 21:40:46.163706
# Unit test for function ansible_facts
def test_ansible_facts():
    pass # unit test for function ansible_facts

# Generated at 2022-06-24 21:40:48.447954
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Test case for ansible_facts.

    '''
    # Test with all default arguments
    ansible_facts()


# Generated at 2022-06-24 21:40:56.239229
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:41:15.236991
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't/Wc}'
    var_0 = ansible_facts(str_0)

# Test function directly
if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-24 21:41:19.588107
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't/Wc}'
    var_0 = ansible_facts(str_0)
    return var_0

# Generated at 2022-06-24 21:41:20.694656
# Unit test for function ansible_facts
def test_ansible_facts():
    # assert True
    pass


# Generated at 2022-06-24 21:41:21.708026
# Unit test for function ansible_facts
def test_ansible_facts():
    assert False, 'test failed'


# Generated at 2022-06-24 21:41:26.261677
# Unit test for function ansible_facts
def test_ansible_facts():
    module = get_all_facts('t/Wc}')
    assert type(ansible_facts(module)) == dict


# Generated at 2022-06-24 21:41:32.915889
# Unit test for function get_all_facts
def test_get_all_facts():
    inp0 = "X O7V"
    inp1 = "u?.a"
    inp2 = "2t?_"
    inp3 = "EtO`"
    inp4 = "B0^>"
    inp5 = "MvG)"
    inp6 = "^?hW"
    inp7 = ":E$R"
    inp8 = "vM7b"
    inp9 = "SPhp"
    inp10 = "*hCf"
    inp11 = "3<9%"
    inp12 = "}%vj"
    inp13 = "i>C>"
    inp14 = "2bak"
    inp15 = "!(q]"
    inp16 = "Vy$@"

# Generated at 2022-06-24 21:41:34.361503
# Unit test for function ansible_facts
def test_ansible_facts():
    print('unit test: get all facts')
    ansible_facts('')

# Generated at 2022-06-24 21:41:36.186678
# Unit test for function get_all_facts
def test_get_all_facts():
    tests = [
        test_case_0,
    ]

    for test in tests: test()

# Generated at 2022-06-24 21:41:43.132361
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't/Wc}'
    var_0 = ansible_facts(str_0)
    str_1 = 't/Wc}'
    var_1 = ansible_facts(str_1)

# Generated at 2022-06-24 21:41:44.647092
# Unit test for function get_all_facts
def test_get_all_facts():
    var_0 = 't/Wc}'
    var_1 = get_all_facts(var_0)
    assert isinstance(var_1, dict)


# Generated at 2022-06-24 21:42:21.397857
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'Z\x1b'
    str_1 = '*'
    str_2 = '\x0e:a'
    var_0 = ansible_facts(str_0, str_1)
    var_1 = ansible_facts(str_2, str_1)

# Generated at 2022-06-24 21:42:25.387793
# Unit test for function ansible_facts
def test_ansible_facts():

    # If the given module is an instance of AnsibleModule, run the function ansible_facts with the given module and check the output
    assert ansible_facts(module) == {"x": "y"}


# Generated at 2022-06-24 21:42:25.994919
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True

# Generated at 2022-06-24 21:42:29.196888
# Unit test for function get_all_facts
def test_get_all_facts():
    # TestCase 0
    str_0 = 't/Wc}'
    var_0 = get_all_facts(str_0)
    assert var_0 is not False, 'Failed asserting that var_0 is not False'


# Generated at 2022-06-24 21:42:30.168852
# Unit test for function ansible_facts
def test_ansible_facts():
    assert func(1) == 1

# Generated at 2022-06-24 21:42:35.514860
# Unit test for function ansible_facts
def test_ansible_facts():
    print('test_ansible_facts start')

    str_0 = 't/Wc}'
    var_0 = ansible_facts(str_0)

    print('test_ansible_facts done.')

# Generated at 2022-06-24 21:42:38.177311
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't/Wc}'
    var_0 = ansible_facts(str_0)

    str_1 = 't/Wc}'
    var_1 = ansible_facts(str_1)

# Generated at 2022-06-24 21:42:40.257213
# Unit test for function get_all_facts
def test_get_all_facts():
    var_0 = 'G'
    str_0 = 't/Wc}'
    # test case
    var_0 = test_case_0(str_0, var_0)


# Generated at 2022-06-24 21:42:42.643866
# Unit test for function ansible_facts
def test_ansible_facts():
    class str_0(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['ansible_distribution']
            self.params['gather_timeout'] = 5

    ansible_facts(str_0())

# Generated at 2022-06-24 21:42:43.010829
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True

# Generated at 2022-06-24 21:44:02.450607
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys

    # Test with bare minimum args
    str_0 = 't/Wc}'
    str_1 = '74"s'
    str_2 = '<(`m'
    str_3 = 'z~j'
    dict_0 = {'gather_timeout': str_1, 'gather_subset': str_2, 'filter': str_3}

    try:
        ansible_facts(str_0, **dict_0)
    except TypeError as e:
        if str(e) == "'module' is a required argument":
            # Out of all the available options, we choose the exact message which
            # will help us to identify the type error
            pass
        else:
            assert False, 'Unexpected TypeError raised: {}'.format(str(e))
    else:
        assert False

# Generated at 2022-06-24 21:44:03.990134
# Unit test for function ansible_facts
def test_ansible_facts():
    ut = ansible_facts()
    assert not ut


# Generated at 2022-06-24 21:44:06.333238
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = 't/Wc}'
    var_0 = get_all_facts(str_0)
    assert str_0 == 't/Wc}'

# Generated at 2022-06-24 21:44:10.205579
# Unit test for function ansible_facts
def test_ansible_facts():
    var_0 = ansible_facts()
    res_0 = 'FQn%'
    assert var_0 == res_0, 'Expected var_0 == res_0'


if __name__ == '__main__':
    test_case_0()

    test_ansible_facts()

#  vim: set ft=py:

# Generated at 2022-06-24 21:44:15.383864
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'j+L-T'
    var_1 = ansible_facts(str_0)
    print(var_1)


# Generated at 2022-06-24 21:44:19.623109
# Unit test for function ansible_facts
def test_ansible_facts():
    with patch('ansible.module_utils.facts.namespace.PrefixFactNamespace') as mock_PrefixFactNamespace:
        with patch('ansible.module_utils.facts.default_collectors.collectors') as mock_collectors:
            with pytest.raises(AttributeError) as excinfo:
                result = ansible_facts("test")
            assert excinfo.value.args[0] == "No module provided"


# Generated at 2022-06-24 21:44:23.426298
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't/Wc}'
    var_0 = ansible_facts(str_0)

# Generated at 2022-06-24 21:44:30.531950
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:44:32.097214
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = '0'
    dict_0 = ansible_facts(str_0)


# Generated at 2022-06-24 21:44:35.770687
# Unit test for function ansible_facts
def test_ansible_facts():
    test_module = 'ansible.module_utils.facts.host.main'
    gather_subset = None
    expected_result = {}
    result = ansible_facts(test_module, gather_subset)
    assert result == expected_result


# Generated at 2022-06-24 21:47:22.323694
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'kqs'
    str_1 = 'h#=oo'
    str_2 = 'n=w'
    int_0 = get_all_facts(str_1)
    int_1 = ansible_facts(str_0)
    str_3 = 'q]*'
    str_4 = 'gL['
    str_5 = 'ur'
    str_6 = ansible_facts(str_4)
    str_7 = '=J'
    str_8 = 'Ey'
    int_2 = ansible_facts(str_7)
    int_3 = ansible_facts(str_2)
    str_9 = 'xP'
    str_10 = '~Bt'
    str_11 = '-'
    str_12 = 'x'
    str_

# Generated at 2022-06-24 21:47:24.783901
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(get_all_facts) == ansible_facts
test_ansible_facts()

# Generated at 2022-06-24 21:47:26.128891
# Unit test for function ansible_facts
def test_ansible_facts():
    with pytest.raises(TypeError):
        assert ansible_facts('t/Wc}')


# Generated at 2022-06-24 21:47:28.453485
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't/Wc}'
    var_0 = ansible_facts(str_0)

if __name__ == '__main__':
    test_ansible_facts()
    test_case_0()

# Generated at 2022-06-24 21:47:29.140173
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True



# Generated at 2022-06-24 21:47:34.113499
# Unit test for function ansible_facts
def test_ansible_facts():
    """ Test function ansible_facts() """
    str_0 = 't/Wc}'
    var_0 = ansible_facts(str_0)

if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:47:37.677609
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        find_str
    except NameError:
        find_str = None

    # isinstance(value, class-or-type-or-tuple)
    if not isinstance(find_str, int):
        find_str = None
    return find_str


# Generated at 2022-06-24 21:47:39.043451
# Unit test for function ansible_facts
def test_ansible_facts():
    var_0 = ansible_facts(A())


# Generated at 2022-06-24 21:47:40.358580
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't/Wc}'
    var_0 = ansible_facts(str_0)

# Generated at 2022-06-24 21:47:41.684524
# Unit test for function get_all_facts
def test_get_all_facts():
    assert get_all_facts('t/Wc}') == get_all_facts('t/Wc}')