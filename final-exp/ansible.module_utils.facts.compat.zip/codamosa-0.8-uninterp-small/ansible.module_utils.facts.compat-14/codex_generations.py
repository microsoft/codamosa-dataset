

# Generated at 2022-06-24 21:37:49.646014
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = 'str'
    var_0 = get_all_facts(str_0)


# Generated at 2022-06-24 21:37:56.858758
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'm'
    bool_0 = bool()
    bool_1 = bool()
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float_12 = float()
    float_13 = float()
    float_14 = float()
    float_15 = float()
    float_16 = float()
    float_17 = float()
    float_18 = float()
    float_19 = float()
    float_20 = float()
    float_21 = float

# Generated at 2022-06-24 21:38:06.240442
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:38:07.025745
# Unit test for function get_all_facts
def test_get_all_facts():
    assert get_all_facts(str_0) == str_0


# Generated at 2022-06-24 21:38:09.977168
# Unit test for function get_all_facts
def test_get_all_facts():
    assert callable(get_all_facts)
    assert get_all_facts.__doc__ != None
    assert get_all_facts.__doc__ != ""


# Generated at 2022-06-24 21:38:14.267915
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't'
    var_0 = ansible_facts(str_0, ['all'])
    str_1 = "t"
    var_1 = ansible_facts(str_1, ['all'])
    str_2 = "t"
    var_2 = ansible_facts(str_2, ['all'])
    str_3 = 't'
    var_3 = ansible_facts(str_3, ['all'])

# Generated at 2022-06-24 21:38:18.572834
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = 't'
    str_1 = 't'
    var_1 = ansible_facts(str_0, gather_subset=str_1)


# Generated at 2022-06-24 21:38:20.909447
# Unit test for function get_all_facts
def test_get_all_facts():
    with pytest.raises(Exception) as excinfo:
        assert get_all_facts('test') == 'test'
    assert str(excinfo.value) == 'get_all_facts() takes exactly 2 arguments (1 given)'


# Generated at 2022-06-24 21:38:24.897436
# Unit test for function ansible_facts
def test_ansible_facts():
    str_1 = 't'
    assert ansible_facts(str_1) == {}


# Generated at 2022-06-24 21:38:27.507966
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't'
    obj_0 = ansible_facts(str_0)



# Generated at 2022-06-24 21:38:39.592576
# Unit test for function ansible_facts
def test_ansible_facts():

    # ansible_facts() is testing decorator @collects_subset
    # which is not mocked right now
    return

    facts = dict()
    facts.update(
        {'MOCK_DETECTED_OS': 'RedHat'},
        {'MOCK_VARIABLE': 'mock_value'},
    )

    mock_module = MagicMock(return_value=facts)
    mock_module.params.get.return_value = None

    with patch('ansible.module_utils.facts.ansible_collector.AnsibleCollector.collect',
               Mock(return_value=facts)):
        result = ansible_facts(mock_module)

    assert result == result
    assert 'MOCK_VARIABLE' in result
    assert 'ansible_' not in result.keys

# Generated at 2022-06-24 21:38:43.353397
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't'
    var_0 = ansible_facts(str_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 21:38:49.275390
# Unit test for function ansible_facts
def test_ansible_facts():
    get_ansible_collector = 'ansible_collector'
    namespace = 'namespace'
    module = 'module'

    # Replace the following line with your actual test.
    assert test_case_0() == ('ansible_default_ipv4', 'ansible_default_ipv4_address') and \
        ansible_facts(module) == get_ansible_collector and \
        ansible_facts(str_0) == namespace



# Generated at 2022-06-24 21:38:53.328480
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True


# Generated at 2022-06-24 21:38:54.727129
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = 'h'
    var_0 = get_all_facts(str_0)


# Generated at 2022-06-24 21:38:58.104320
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't'
    bool_0 = False
    str_1 = 't'
    bool_1 = True
    int_0 = 0
    var_0 = ansible_facts(str_0, bool_0)
    var_1 = ansible_facts(str_1, bool_1, int_0)


# Generated at 2022-06-24 21:39:02.369479
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 't'
    var_0 = ansible_facts(str_0)


# Generated at 2022-06-24 21:39:03.813260
# Unit test for function ansible_facts
def test_ansible_facts():
    ansible_facts('ansible_facts')
    assert True

# Generated at 2022-06-24 21:39:14.099089
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'c'
    var_0 = ansible_facts(str_0)
    assert var_0 == 'c'
    str_0 = 'a'
    var_0 = ansible_facts(str_0)
    assert var_0 == 'a'
    str_0 = 'a'
    var_0 = ansible_facts(str_0)
    assert var_0 == 'a'
    str_0 = 'a'
    var_0 = ansible_facts(str_0)
    assert var_0 == 'a'
    str_0 = 'a'
    var_0 = ansible_facts(str_0)
    assert var_0 == 'a'
    str_0 = 'a'
    var_0 = ansible_facts(str_0)
    assert var_0

# Generated at 2022-06-24 21:39:15.485718
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(get_all_facts)

# Generated at 2022-06-24 21:39:22.566109
# Unit test for function get_all_facts
def test_get_all_facts():
    # Assign parameters
    gather_subset = 'var_0'
    param = {}
    param['gather_subset'] = gather_subset

    # Pass parameter to the module
    ansible_module = AnsibleModule(argument_spec=param)
    get_all_facts(ansible_module)

# Generated at 2022-06-24 21:39:25.218461
# Unit test for function ansible_facts
def test_ansible_facts():
    # All
    var__0 = ansible_facts(1, 2)
    # Min
    var__1 = ansible_facts(1)
    # All Subset
    var__2 = ansible_facts(1, ['all'])
    # Min Subset
    var__3 = ansible_facts(1, ['min'])

# Generated at 2022-06-24 21:39:26.400801
# Unit test for function ansible_facts
def test_ansible_facts():

    bytes_0 = b''
    var_0 = ansible_facts(bytes_0)

# Generated at 2022-06-24 21:39:31.691187
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xaa\xc4\x9d\x94\x8eW\x83JBw\xfa\x82T\xf8\xfd\xc9\x91'
    var_0 = ansible_facts(bytes_0)

# Generated at 2022-06-24 21:39:41.448688
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test with integer argument
    bytes_0 = b'3\xee\xc0\xd1\x8f\x9c.\x13\x85Y\xb8\x15'
    var_0 = ansible_facts(bytes_0)

    # Test with float argument
    float_0 = -0.00119
    var_1 = ansible_facts(float_0)

    # Test with list argument
    int_0 = -3
    list_0 = ['', 0, int_0]
    var_2 = ansible_facts(list_0)

    # Test with tuple argument
    tuple_0 = (['', -3, 'G'],)
    var_3 = ansible_facts(tuple_0)

    # Test with dictionary argument

# Generated at 2022-06-24 21:39:42.336262
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(None, None) == {}
    assert ansible_facts(None, '*') == {}

# Generated at 2022-06-24 21:39:47.815669
# Unit test for function get_all_facts
def test_get_all_facts():
    bytes_0 = b'\x03\x17\x9c\x8d\x85\xe3\xaa7\xda\xd1\xfa\x12\x9a\x8a\x04\x90\xd0\xb6'
    module = bytes_0
    gather_subset = 'all'
    assert callable(get_all_facts)
    assert isinstance(get_all_facts(module), dict)


# Generated at 2022-06-24 21:39:55.905370
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xed\x08\xe5\xe1Y\x83\xcb\x9f\x8c\x9b\x95\xcc'
    bytes_1 = b'\x08\x0eI\x0c\xed\x07\xc0\x8d\xc0\x80\x0a'

    with pytest.raises(Exception):
        var_0 = get_all_facts(bytes_0)
    var_1 = ansible_facts(bytes_1)

# Generated at 2022-06-24 21:40:00.780042
# Unit test for function ansible_facts
def test_ansible_facts():
    module = {"test": ""}
    gather_subset = None
    assert ansible_facts(module, gather_subset=gather_subset) == {}



# Generated at 2022-06-24 21:40:04.426842
# Unit test for function ansible_facts
def test_ansible_facts():
    func_name = 'ansible_facts'
    assertion_msg = '{0} is {1}, expected {2}'
    is_equal_msg = '{0} is {1}, but expected {2}'

    # Make the necessary calls to action/assertion functions
    ansible_facts()



# Generated at 2022-06-24 21:40:14.952267
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        arg_0 = None
        arg_1 = ['any']
        retval = ansible_facts(arg_0, arg_1)
        assert type(retval) == dict
    except Exception:
        raise  # TODO: Add better exception handling


# Generated at 2022-06-24 21:40:18.683022
# Unit test for function get_all_facts
def test_get_all_facts():
    bytes_0 = b'\x00\x0e\x04\x08\x03\x07\x02\x06\x01\x05'
    var_0 = get_all_facts(bytes_0)

    assert func.__name__ == 'get_all_facts'


# Generated at 2022-06-24 21:40:23.601933
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'+\x15\x90\x9a\xe4\x8a$\x9e\xed\xca%'
    for var_0 in get_all_facts(bytes_0):
        var_1 = ansible_facts(var_0)


if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-24 21:40:32.778571
# Unit test for function ansible_facts
def test_ansible_facts():
    #from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.network.dns import DNSFactCollector
    from ansible.module_utils.facts.network.network import NetworkFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.selinux import SELinuxFactCollector


# Generated at 2022-06-24 21:40:33.996133
# Unit test for function ansible_facts
def test_ansible_facts():
    assert 1 == 1, 'Module test not implemented'

# Generated at 2022-06-24 21:40:37.369068
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        assert (ansible_facts == 2) # Test fail
    except:
        pass

    try:
        assert (ansible_facts == 1) # Test fail
    except:
        pass

    try:
        assert (ansible_facts == 0) # Test pass
    except:
        pass
    return 0 # Test pass


# Generated at 2022-06-24 21:40:46.538658
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    all_collector_classes = ansible_collector.get_fact_collector_classes()

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-24 21:40:56.487522
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\xab\xd1\x8a\x1c\x9e&\x8a$\x9e\xed\xca%\x0e:\xfd\xdc\x83\x88\xa0\x1d\xf1'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['ansible_lsb'] = {'major_release': '7', 'codename': 'Core', 'distro_id': 'CentOS', 'description': 'CentOS Linux release 7.4.1708 (Core) ', 'minor_release': '4'}
    dict_1['ansible_selinux'] = {'status': 'disabled', 'policyvers': '0'}

# Generated at 2022-06-24 21:41:03.263011
# Unit test for function ansible_facts
def test_ansible_facts():
    get_all_facts(b'\xbd\xdb\x93\x1e\xfe-\xed\xf9\x95\xca\xad\xce')
    get_all_facts(b'\x80\xb1\xcd\xae\x86\xd7\xb5m\x11\xcc@\xab\xce')
    get_all_facts(b':\xc4\x1d\xcb\xcf\xe8\xab\x83\x01\xd3!\xb1\xce')
    get_all_facts(b'H\x16\x82\x93\xb1\x9c.\xe2\xc8\x93\xc0\xab\xce')

# Generated at 2022-06-24 21:41:11.565845
# Unit test for function ansible_facts
def test_ansible_facts():
    var_0 = {'gather_timeout': 10, 'gather_subset': ['all']}
    var_1 = ansible_facts(var_0)

# Generated at 2022-06-24 21:41:30.295358
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'\x1d\xf2\x14P\x84\x98\x98\x1a\xea\xf5\x0f\xec\x89\xfc\xb2\x81\xfe\x17'
    var_0 = ansible_facts(bytes_0)
    assert isinstance(var_0, dict)
    str_0 = '\x91\xc9\xbc\xb7\xa1\x02\x1f\x8a_\xa2<'

# Generated at 2022-06-24 21:41:33.141129
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'h'
    class_1 = ansible_facts
    var_0 = class_1(bytes_0)
    assert var_0 is not None

# Generated at 2022-06-24 21:41:40.466389
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'z\xed\xe8\xac\xf2\x9a\x0c\xec>\x02t\xa3\xcb\xf3\xcb'
    dict_0 = ansible_facts(bytes_0)
    assert isinstance(dict_0, dict)

# Generated at 2022-06-24 21:41:48.211158
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:41:58.999832
# Unit test for function get_all_facts

# Generated at 2022-06-24 21:42:03.138412
# Unit test for function ansible_facts
def test_ansible_facts():
    res = ansible_facts()
    assert res is not None
    assert res['kernel'] == 'GNU/Linux'
    assert res['distribution'] == 'Ubuntu'

# Generated at 2022-06-24 21:42:13.736998
# Unit test for function get_all_facts
def test_get_all_facts():
    assert type(get_all_facts(b'1')) == dict
    assert type(get_all_facts(b'2')) == dict
    assert type(get_all_facts(b'3')) == dict
    assert type(get_all_facts(b'4')) == dict
    assert type(get_all_facts(b'5')) == dict
    assert type(get_all_facts(b'6')) == dict
    assert type(get_all_facts(b'7')) == dict
    assert type(get_all_facts(b'8')) == dict
    assert type(get_all_facts(b'9')) == dict
    assert type(get_all_facts(b'10')) == dict
    assert type(get_all_facts(b'11')) == dict
   

# Generated at 2022-06-24 21:42:14.650240
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True


# Generated at 2022-06-24 21:42:22.394859
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    assert callable(ansible_facts)


# Generated at 2022-06-24 21:42:23.949889
# Unit test for function ansible_facts
def test_ansible_facts():

    assert ansible_facts(test_case_0) == b'+\x15\x90\x9a\xe4\x8a$\x9e\xed\xca%'


# Generated at 2022-06-24 21:42:48.907290
# Unit test for function get_all_facts
def test_get_all_facts():
    assert callable(get_all_facts)


# Generated at 2022-06-24 21:43:00.600363
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:43:06.279451
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'+\x15\x90\x9a\xe4\x8a$\x9e\xed\xca%'
    var_1 = ansible_facts(bytes_0)
    assert var_1 is not None

# Generated at 2022-06-24 21:43:07.367436
# Unit test for function ansible_facts
def test_ansible_facts():

    assert ansible_facts(1) == 1



# Generated at 2022-06-24 21:43:13.383750
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts as facts_module_utils

    b'\x00\x90\xec\x84\x90\x9c\xed\x9c\x94\x90\xec\xd0\x95\xcc\x99\x9c\x9c\x94PK'

    facts_module_utils = facts_module_utils.ansible_facts(b'\x00\x90\xec\x84\x90\x9c\xed\x9c\x94\x90\xec\xd0\x95\xcc\x99\x9c\x9c\x94PK')

# Generated at 2022-06-24 21:43:17.948648
# Unit test for function ansible_facts
def test_ansible_facts():
    class AnsibleModule(object):
        def __init__(self, gather_subset, gather_timeout, params):
            self.params = params
            self.params['gather_subset'] = gather_subset
            self.params['gather_timeout'] = gather_timeout


    params = dict()
    params['filter'] = '*'
    ansible_facts(AnsibleModule(gather_subset=['all'], gather_timeout=10, params=params))



# Generated at 2022-06-24 21:43:21.808729
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b"\x0b\x01\xda\xd2H\x16\x91"
    stdin_0 = b'l\xba\x05\x08\x07\xc3\xeb\x02\x07\xf7'
    assert ansible_facts(bytes_0, stdin_0) == ('ansible_kernel', 'Linux')

# Generated at 2022-06-24 21:43:28.587618
# Unit test for function ansible_facts
def test_ansible_facts():
    with pytest.raises(AnsibleFailJson) as exc:
        # Call method ansible_facts with wrong types of arguments
        ansible_facts(bytes_0, gather_subset=bytes_0)
    with pytest.raises(AnsibleFailJson) as exc:
        # Call method ansible_facts with wrong types of arguments
        ansible_facts(bytes_0, filter_spec=bytes_0)
    with pytest.raises(AnsibleFailJson) as exc:
        # Call method ansible_facts with wrong types of arguments
        ansible_facts(bytes_0, gather_subset=bytes_0, filter_spec=bytes_0)

# Generated at 2022-06-24 21:43:39.521958
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:43:40.269271
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True

# Generated at 2022-06-24 21:44:37.500215
# Unit test for function get_all_facts
def test_get_all_facts():
    bytes_0 = b'+\x15\x90\x9a\xe4\x8a$\x9e\xed\xca%'
    var_0 = get_all_facts(bytes_0)




# Generated at 2022-06-24 21:44:41.223202
# Unit test for function get_all_facts
def test_get_all_facts():
    testcase_0()


if __name__ == "__main__":
    # Unit test
    module = ansible_module_get_all_facts()
    test_get_all_facts()
    module.exit_json(changed=False, ansible_facts=ansible_facts(module))

# Generated at 2022-06-24 21:44:42.155126
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(None)


# Generated at 2022-06-24 21:44:46.436619
# Unit test for function get_all_facts
def test_get_all_facts():
    assert False


# Generated at 2022-06-24 21:44:54.041374
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_collector

    bytes_0 = b'+\x15\x90\x9a\xe4\x8a$\x9e\xed\xca%'
    var_0 = get_all_facts(bytes_0)

    bytes_1 = b'+\x15\x90\x9a\xe4\x8a$\x9e\xed\xca%'
    var_1 = ansible_facts(bytes_1)


# Generated at 2022-06-24 21:45:02.255015
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:45:06.159131
# Unit test for function get_all_facts
def test_get_all_facts():
    bytes_0 = b'\x93\xb4\x04\xdb\x9f\xab\x92H\x8c\xf4'
    var_0 = get_all_facts(bytes_0)
    bytes_1 = b'A\xe8\xfd\xf1\xef\x8c\xda\x9f\x85\x88\x15'
    var_1 = get_all_facts(bytes_1)



# Generated at 2022-06-24 21:45:12.526210
# Unit test for function ansible_facts
def test_ansible_facts():
    bytes_0 = b'+\x15\x90\x9a\xe4\x8a$\x9e\xed\xca%'
    var_0 = ansible_facts(bytes_0)
    assert len(var_0) > 0


# Generated at 2022-06-24 21:45:22.265754
# Unit test for function ansible_facts
def test_ansible_facts():
    prv_bytes_0 = b'\xf3\xe9Y\xcf\x8b\xebh\x1e'
    public_bytes_0 = b'xs\x9c\x1f\xe6\x8a\xeb\x1b'
    with mock.patch('ansible.module_utils.facts.ansible_collector.get_ansible_collector', return_value=prv_bytes_0):
        with mock.patch('ansible.module_utils.facts.ansible_collector.AnsibleCollector.collect', return_value=public_bytes_0):
            assert ansible_facts(private_bytes_0) == public_bytes_0



# Generated at 2022-06-24 21:45:33.190278
# Unit test for function ansible_facts
def test_ansible_facts():
	a = '10'
	gather_subset = ['all']
	b = '20'
	gather_timeout = '30'
	filter_spec = '40'
	minimal_gather_subset = ['50']
	all_collector_classes = '{'
	namespace = PrefixFactNamespace(namespace_name = 'ansible', prefix = '')
	fact_collector = ansible_collector.get_ansible_collector(all_collector_classes, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset)
	facts_dict = fact_collector.collect(a)
	print(facts_dict)
# test_ansible_facts()

# Generated at 2022-06-24 21:47:42.415314
# Unit test for function get_all_facts
def test_get_all_facts():
    gather_subset = 'all'
    bytes_0 = b'+\x15\x90\x9a\xe4\x8a$\x9e\xed\xca%'
    module = bytes_0
    gather_timeout = 10.
    filter_spec = '*'
    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time', 'distribution', 'dns', 'env', 'fips', 'local', 'lsb', 'pkg_mgr', 'platform', 'python', 'selinux', 'service_mgr', 'ssh_pub_keys', 'user'])
    all_collector_classes = 'all'
    namespace = 'ansible'
    ansible_gather_facts = ansible_collector.get_ansible_