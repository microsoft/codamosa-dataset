

# Generated at 2022-06-24 21:37:50.249953
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = 2335.2657300185524
    assert 2335.2657300185524 == ansible_facts(float_0)


# Generated at 2022-06-24 21:37:54.085056
# Unit test for function ansible_facts
def test_ansible_facts():
    #assert ansible_facts(1) == 1 # insert your test code here
    
    #assert ansible_facts(float_0) == 2335.2657300185524
    #assert ansible_facts(var_0) == 2335.2657300185524
    assert test_case_0() == None # insert your test code here


# Generated at 2022-06-24 21:37:58.358873
# Unit test for function ansible_facts
def test_ansible_facts():
    module = AnsibleModule(
        argument_spec = dict(
            module = dict(type='str', required=False),
            gather_subset = dict(type='list', required=False),
            gather_timeout = dict(type='int', required=False),
            filter = dict(type='str', required=False),
        ),
        supports_check_mode=True,
    )

    result = ansible_facts(module)
    assert result

# Generated at 2022-06-24 21:38:07.714465
# Unit test for function ansible_facts
def test_ansible_facts():

    float_0 = 288.935
    float_1 = 649.405
    float_2 = 971.872
    int_0 = 107
    int_1 = 2
    str_0 = '7'
    str_1 = '8'
    str_2 = '9'
    dict_0 = dict()
    dict_0['m'] = 7
    dict_1 = dict()
    dict_0['m'] = int_0
    dict_0['n'] = str_1
    dict_0['o'] = dict_1
    dict_2 = dict()
    dict_2['l'] = dict_0
    dict_2['m'] = float_1
    dict_2['n'] = float_0
    dict_3 = dict()
    dict_3['k'] = dict_2
   

# Generated at 2022-06-24 21:38:12.138227
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = 2335.2657300185524

    # Call function ansible_facts using only the first argument (float_0)
    var_0 = ansible_facts(float_0)
    # Call function ansible_facts using only the first argument (float_0)
    var_0 = ansible_facts(float_0)



# Generated at 2022-06-24 21:38:13.547340
# Unit test for function ansible_facts
def test_ansible_facts():
    assert callable(ansible_facts)



# Generated at 2022-06-24 21:38:15.883142
# Unit test for function ansible_facts
def test_ansible_facts():
    float_0 = 2335.2657300185524
    assert (int((ansible_facts(float_0))) == 1)

# Generated at 2022-06-24 21:38:19.821222
# Unit test for function ansible_facts
def test_ansible_facts():
    with pytest.raises(TypeError):
        ansible_facts(1)


# Generated at 2022-06-24 21:38:21.686441
# Unit test for function get_all_facts
def test_get_all_facts():
    float_0 = 2335.2657300185524
    var_0 = get_all_facts(float_0)


# Generated at 2022-06-24 21:38:27.021092
# Unit test for function ansible_facts
def test_ansible_facts():
    '''test ansible_facts'''

    # ansible 2.2/2.3 gather_subset arg
    # 2.1/2.0 do not except a gather_subset arg
    # So make gather_subsets an optional arg, defaulting to configured DEFAULT_GATHER_TIMEOUT

    # run test case
    test_case_0()

# Generated at 2022-06-24 21:38:30.743368
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = 'test get_all_facts'


# Generated at 2022-06-24 21:38:34.856100
# Unit test for function ansible_facts
def test_ansible_facts():
    # For python 2.6-2.6, the executation of 'yield' is not allowed.
    # And this function is not use in ansible 2.6
    # The function is compatiable with  python 3.5
    assert True == True


# Generated at 2022-06-24 21:38:46.058245
# Unit test for function ansible_facts
def test_ansible_facts():
    # Initialize test variables
    module = AnsibleModule(ansible_facts={})
    gather_subset = frozenset(['all'])
    gather_timeout = 10
    filter_spec = '*'
    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time', 'distribution', 'dns', 'env', 'fips', 'local', 'lsb', 'pkg_mgr', 'platform', 'python', 'selinux', 'service_mgr', 'ssh_pub_keys', 'user'])

    all_collector_classes = default_collectors.collectors
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-24 21:38:54.085776
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import argparse
    argparse.ArgumentParser(
        description='asdf').print_help()
    argparse.ArgumentParser(
        description='asdf').add_argument(
        '--version', action='version', version='%(prog)s 3.0')
    test_case_0()

if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-24 21:38:56.101514
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'test ansible_facts'
    str_1 = ansible_facts(str_0)
    assert str_0 is str_1


# Generated at 2022-06-24 21:39:03.896184
# Unit test for function ansible_facts
def test_ansible_facts():
    ansible_facts = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(type='list', default=['all']),
            gather_timeout = dict(type='int', default=10),
            filter = dict(type='str', default='*'),
        ),
        supports_check_mode=False
    )
    assert ansible_facts

# Generated at 2022-06-24 21:39:08.746861
# Unit test for function ansible_facts
def test_ansible_facts():
    assert test_case_0() == 'test ansible_facts'

if __name__ == '__main__':
    test_ansible_facts()
    print('Test finished successfully')

# Generated at 2022-06-24 21:39:11.826563
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        ansible_facts()
    except NameError as err:
        assert True
    except Exception as err:
        assert False,'Unexpected exception raised:' + str(err)
    else:
        assert False,'No exception raised'
        

# Generated at 2022-06-24 21:39:12.841262
# Unit test for function get_all_facts
def test_get_all_facts():
    pass


# Generated at 2022-06-24 21:39:17.938041
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = 'test ansible_facts'
    test_module = TestAnsibleModule(str_0)
    ansible_facts(test_module)

    print(ansible_facts(test_module))


# Generated at 2022-06-24 21:39:30.061196
# Unit test for function ansible_facts
def test_ansible_facts():
    # https://github.com/ansible/ansible/blob/a3c3d9f9cc74e56c18b076d16e6b8c6f1e2d452c/lib/ansible/module_utils/facts/network/__init__.py#L5-L11
    # gather_subset:
    #   - all
    #   - !all
    #     - '!ipv6'
    # gather_timeout: 60
    # filter: '*'
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.legacy import LegacyNetworkCollector
    from ansible.module_utils.facts.network.junos import JunosNetworkCollector

# Generated at 2022-06-24 21:39:34.590972
# Unit test for function ansible_facts
def test_ansible_facts():
    kwargs = {}
    kwargs['namespace'] = 'ansible'
    kwargs['filter_spec'] = '*'
    kwargs['gather_subset'] = ['all']
    kwargs['gather_timeout'] = 10
    kwargs['minimal_gather_subset'] = ['apparmor', 'caps', 'cmdline', 'date_time', 'distribution', 'dns', 'env', 'fips', 'local', 'lsb', 'pkg_mgr', 'platform', 'python', 'selinux', 'service_mgr', 'ssh_pub_keys', 'user']
    kwargs['module'] = str_0
    func_0 = ansible_facts(**kwargs)

# Generated at 2022-06-24 21:39:36.816157
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True is True


# Generated at 2022-06-24 21:39:46.900495
# Unit test for function ansible_facts
def test_ansible_facts():
    source_0 = '4@E<j\t7D'
    source_1 = 'lPhZINh1'
    source_2 = '@$uJ:0%8j'
    source_3 = 'x'
    source_4 = 'p5N;'
    source_5 = 'lPhZINh1'
    source_6 = 't*d4'
    source_7 = 'E'
    source_8 = '\r[1(?\t}g3q'
    source_9 = '@$uJ:0%8j'
    source_10 = '@$uJ:0%8j'
    var_0 = ansible_facts(source_0, source_1)
    var_1 = ansible_facts(source_2, source_3)
    var_

# Generated at 2022-06-24 21:39:49.574039
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(str_0)


# Generated at 2022-06-24 21:39:51.382912
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = '(W'
    var_0 = ansible_facts(str_0, (b'0', '.'))
    str_1 = '6Ux$['
    var_1 = ansible_facts(str_1)


# Generated at 2022-06-24 21:39:52.933253
# Unit test for function get_all_facts
def test_get_all_facts():
    u'Unit tests for get_all_facts'
    test_case_0()



# Generated at 2022-06-24 21:39:56.146387
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = '4@E<j\t7D'
    var_0 = get_all_facts(str_0)
    assert var_0 == '4@E<j\t7D'


# Generated at 2022-06-24 21:40:01.338059
# Unit test for function ansible_facts
def test_ansible_facts():
  # Input parameters
  module = 0

  # Expected return value
  expected = {}

  # Call the function
  actual = ansible_facts(module)

  # Check for expected result
  assert(expected == actual)

  return

# Generated at 2022-06-24 21:40:11.899151
# Unit test for function ansible_facts
def test_ansible_facts():
    f_var_0 = 'p>$r6Kjx'
    f_var_1 = ansible_facts(f_var_0)

if __name__ == '__main__':
    import sys
    import __builtin__
    sys.modules['__builtin__'] = __builtin__
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:40:18.714695
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = '3T/T'
    var_0 = get_all_facts(str_0)
    assert var_0 == None


# Generated at 2022-06-24 21:40:24.817389
# Unit test for function ansible_facts
def test_ansible_facts():
    # This function will not be called directly, so we need to
    # simulate the inpourt parameters
    arg_module = ''
    arg_gather_subset = '*'
    arg_filter = '*'
    arg_gather_timeout = 10

    # Calls ansible_facts() to test
    ansible_facts(arg_module,
                  arg_gather_subset,
                  arg_filter,
                  arg_gather_timeout)


# Generated at 2022-06-24 21:40:27.839814
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = '4@E<j\t7D'
    var_0 = ansible_facts(str_0)

if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-24 21:40:34.954902
# Unit test for function ansible_facts
def test_ansible_facts():
    # Testing with module from tests/unit/lib/ansible/modules/system/setup.py
    from ansible.modules.system.setup import main as module_main
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # gather_subset = ['all', '!fips']
    gather_subset = ['all', '!fips']

    if False:
        gather_subset = None
    gather_timeout=10
    filter_spec = '*'


# Generated at 2022-06-24 21:40:40.694542
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = '4@E<j\t7D'
    var_0 = get_all_facts(str_0,\
                          gather_subset=[])


# Generated at 2022-06-24 21:40:49.129790
# Unit test for function get_all_facts
def test_get_all_facts():
    var_0 = '2`{f<-j'
    var_1 = 'Gv&3z(W\x1f;\nX1Vm-n'

# Generated at 2022-06-24 21:40:54.401526
# Unit test for function ansible_facts
def test_ansible_facts():
    class AnsibleModule:
        def __init__(self, *args, **kwargs):
            self.params = kwargs

    module = AnsibleModule(gather_subset=['!all'])

    assert isinstance(ansible_facts(module), dict)


# Generated at 2022-06-24 21:41:01.104884
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = '4@E<j\t7D'
    str_1 = '\x7f\x03d\x7f\x03\x7fV\x7f1\x7f'
    str_2 = '\x03'
    str_3 = '\x7f'
    dict_0 = dict()
    dict_0['attr'] = str_1
    dict_0['val'] = str_2
    list_0 = [str_3, '\x7f']
    ansible_facts(str_0, filter=dict_0)
    ansible_facts(str_0, gather_subset=list_0)

# Generated at 2022-06-24 21:41:03.632820
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        assert callable(get_all_facts)
    except AssertionError as e:
        raise(e)


# Generated at 2022-06-24 21:41:11.841022
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:41:21.706708
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts("1") == "1"


# Generated at 2022-06-24 21:41:26.936368
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = '4@E<j\t7D'
    var_0 = ansible_facts(str_0)


if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:41:28.521369
# Unit test for function get_all_facts
def test_get_all_facts():
    str_1 = 'G@V7y'
    var_1 = get_all_facts(str_1)


# Generated at 2022-06-24 21:41:32.108105
# Unit test for function get_all_facts
def test_get_all_facts():

    result = get_all_facts()
    assert result is not None

# Generated at 2022-06-24 21:41:33.288296
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True


# Generated at 2022-06-24 21:41:34.685335
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import _get_all_facts
    # Calling get_all_facts(module)
    result = get_all_facts(module=None)

# Generated at 2022-06-24 21:41:35.587109
# Unit test for function ansible_facts
def test_ansible_facts():
    assert callable(ansible_facts)

# Generated at 2022-06-24 21:41:39.818937
# Unit test for function get_all_facts
def test_get_all_facts():
    assert callable(get_all_facts)


# Generated at 2022-06-24 21:41:41.900516
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = '4@E<j\t7D'
    var_0 = ansible_facts(str_0)


# Generated at 2022-06-24 21:41:44.135626
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'b\x1bH\x1d'
    var_0 = ansible_facts(str_0)
    print(var_0.values())

# Generated at 2022-06-24 21:42:03.296890
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = '4@E<j\t7D'
    var_0 = get_all_facts(str_0)
    print(var_0)


# Generated at 2022-06-24 21:42:13.839129
# Unit test for function ansible_facts
def test_ansible_facts():

    m1 = {'gather_subset': ['all'], 'gather_timeout': 30, 'filter': '*'}
    assert ansible_facts(m1, gather_subset=['all']) == ansible_facts(m1)

    m2 = {'gather_subset': ['network'], 'gather_timeout': 30, 'filter': '*'}
    assert ansible_facts(m2, gather_subset=['network']) == ansible_facts(m2)

    m3 = {'gather_subset': ['all'], 'gather_timeout': 30, 'filter': 'ansible_os_family'}
    assert ansible_facts(m3, gather_subset=['all']) == ansible_facts(m3)


# Generated at 2022-06-24 21:42:16.634765
# Unit test for function ansible_facts
def test_ansible_facts():
    var_1 = True
    var_2 = True
    with pytest.raises(AnsibleExitJson):
        ansible_facts(var_1, collect_subset=var_2)


# Generated at 2022-06-24 21:42:18.324308
# Unit test for function get_all_facts
def test_get_all_facts():
    with pytest.raises(TypeError):
        get_all_facts()



# Generated at 2022-06-24 21:42:28.902556
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = '4@E<j\t7D'
    var_0 = ansible_facts(str_0)

# Generated at 2022-06-24 21:42:32.350186
# Unit test for function get_all_facts
def test_get_all_facts():
    # Setup
    str_0 = '4@E<j\t7D'
    
    # Testing
    var_0 = get_all_facts(str_0)

    # Teardown
    del str_0
    del var_0


# Generated at 2022-06-24 21:42:36.617863
# Unit test for function ansible_facts
def test_ansible_facts():
    # This test does not make sense
    assert True


# Generated at 2022-06-24 21:42:39.209897
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = '4@E<j\t7D'
    var_0 = get_all_facts(str_0)
    assert var_0 == '4@E<j\t7D'


# Generated at 2022-06-24 21:42:43.419429
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True



# Generated at 2022-06-24 21:42:44.775901
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = '4@E<j\t7D'
    var_0 = get_all_facts(str_0)
    assert var_0 == 0


# Generated at 2022-06-24 21:43:20.044491
# Unit test for function ansible_facts
def test_ansible_facts():
    str_1 = '4@E<j\t7D'
    var_1 = ansible_facts(str_1)

# Generated at 2022-06-24 21:43:25.223402
# Unit test for function ansible_facts
def test_ansible_facts():
    source = '{\'gather_subset\': [\'network\', \'all\'], \'gather_timeout\': 10, \'ansible_network_os\': \'ios\'}'
    expected = "gather_timeout"
    actual = ansible_facts(source)
    assert actual == expected, "Expected {}, got {}".format(expected, actual)


# Generated at 2022-06-24 21:43:25.887344
# Unit test for function ansible_facts
def test_ansible_facts():
    pass


# Generated at 2022-06-24 21:43:27.567550
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = '@'
    var_0 = ansible_facts(str_0)


# Generated at 2022-06-24 21:43:33.781694
# Unit test for function ansible_facts
def test_ansible_facts():

    value = ansible_facts(
        {'_ansible_version': 'v2.3.0'},
        gather_subset=['_ansible_version'])

    assert value == {'_ansible_version': 'v2.3.0'}


# Generated at 2022-06-24 21:43:39.137700
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = '4@E<j\t7D'
    str_1 = ',h(:t-p)tZ'
    str_2 = 's%h'
    str_3 = 'vM^$e!'
    var_0 = ansible_facts(str_0)
    str_0 = '4@E<j\t7D'
    str_1 = ',h(:t-p)tZ'
    str_2 = 's%h'
    str_3 = 'vM^$e!'
    var_0 = ansible_facts(str_0)
    str_0 = '4@E<j\t7D'
    str_1 = ',h(:t-p)tZ'
    str_2 = 's%h'

# Generated at 2022-06-24 21:43:42.018531
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = '4@E<j\t7D'
    var_0 = ansible_facts(str_0)

# Unit test function for function get_all_facts

# Generated at 2022-06-24 21:43:47.504070
# Unit test for function ansible_facts
def test_ansible_facts():
    # mock AnsibleModule
    module = Mock(AnsibleModule)

    # container for the return value
    result = {}

    # the function under test
    ansible_facts(module)

    # compare actual return value with expected return value
    assert result == ansible_facts(module)


# Generated at 2022-06-24 21:43:50.747639
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'i'
    str_1 = 'j'
    str_2 = 'k'
    var_0 = ansible_facts(str_0, str_1, str_2)

    assert(var_0 == '6')

# Generated at 2022-06-24 21:43:52.044312
# Unit test for function get_all_facts
def test_get_all_facts():
    assert callable(get_all_facts)


# Generated at 2022-06-24 21:45:04.321620
# Unit test for function ansible_facts
def test_ansible_facts():
    test_case_0()


# Generated at 2022-06-24 21:45:11.744307
# Unit test for function ansible_facts
def test_ansible_facts():
    list_0 = []
    dict_0 = dict()
    var_0 = ansible_facts(list_0, dict_0)
    if var_0 is not None:
        raise Exception('Expected None, got ' + repr(var_0))

    dict_0 = dict()
    dict_0['ansible_module'] = list_0
    dict_0['module'] = list_0
    var_0 = ansible_facts(list_0, dict_0)
    if var_0 is not None:
        raise Exception('Expected None, got ' + repr(var_0))

    dict_0 = dict()
    dict_0['gather_subset'] = list_0
    var_0 = ansible_facts(list_0, dict_0)
    if var_0 is not None:
        raise

# Generated at 2022-06-24 21:45:13.458669
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(get_all_facts()) == 'test_value_2'


# Generated at 2022-06-24 21:45:16.554298
# Unit test for function get_all_facts
def test_get_all_facts():
    assert not get_all_facts('PYwI')


# Generated at 2022-06-24 21:45:24.804861
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = '4@E<j\t7D'
    var_0 = ansible_facts(str_0)

# Generated at 2022-06-24 21:45:28.574857
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = '>'
    str_1 = 'd'
    str_2 = 'R'
    var_0 = ansible_facts(str_0,
                          gather_subset=str_1,
                          filter=str_2)


# Generated at 2022-06-24 21:45:30.356416
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = '4@E<j\t7D'
    var_0 = get_all_facts(str_0)


# Generated at 2022-06-24 21:45:37.419678
# Unit test for function ansible_facts
def test_ansible_facts():

    # Mock up a module for testing with a param specified from the ansible cli
    # when running this test.
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['all'])
        )
    )

    # These are the values we expect the function to return
    expected_results = dict()

    # Execute the function, passing the module object and any other args needed
    # to execute the function.
    results = ansible_facts(module)

    # Finally, assert how we expect the results to look
    assert results == expected_results



# Generated at 2022-06-24 21:45:39.661451
# Unit test for function ansible_facts
def test_ansible_facts():
    class TestAnsibleModule:
        params = {'filter': '*'}
    module_0 = TestAnsibleModule()
    ansible_facts(module_0)


# Generated at 2022-06-24 21:45:41.708088
# Unit test for function ansible_facts
def test_ansible_facts():
    # Setup test
    str_0 = '4@E<j\t7D'

    # Test call
    ansible_facts(str_0)

