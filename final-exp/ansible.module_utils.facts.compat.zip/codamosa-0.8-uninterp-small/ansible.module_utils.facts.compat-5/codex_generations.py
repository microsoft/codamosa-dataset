

# Generated at 2022-06-24 21:37:54.429676
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'd\\j@(n\rOAGGr &oG9j='
    # For test_case_0
    str_1 = 'gather_timeout'
    dict_0 = {'gather_subset': ['all'], str_1: 10, 'filter': '*'}
    str_2 = 'ansible_distribution'
    str_3 = 'debian'
    dict_1 = {str_2: str_3}
    dict_2 = dict_1
    dict_3 = dict_2

    # For test_case_1
    str_4 = 'gather_timeout'
    str_5 = 'gather_subset'
    str_6 = 'filter'

# Generated at 2022-06-24 21:37:58.873616
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True
    # str_0 = 'd\\j@(n\rOAGGr &oG9j='
    # module_0 = AnsibleModule(ansible_facts={'gather_subset': [str_0]})
    # var_0 = ansible_facts(module_0)

# Generated at 2022-06-24 21:38:08.912348
# Unit test for function ansible_facts
def test_ansible_facts():
    # get_all_facts is compat api, which expects an AnsibleModule
    # (in 2.3/2.0 it expects a 'gather_subset' param)
    # (in 2.1 it expects a 'gather_subset' param but this is optional)

    # i'm not sure how to mock an ansiblemodule so i'll use a mock class
    # TODO: see if this can be converted to a real mock object
    class AnsibleModule:
        params = {'gather_subset': ['all']}
        class MockAnsibleModule:
            def __init__(self, params):
                self.params = params
        def __new__(cls, *args, **kwargs):
            return cls.MockAnsibleModule(dict(gather_subset=['all']))

# Generated at 2022-06-24 21:38:18.633780
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual

    # Run the comapatiable api
    # ansible_facts is a compat api that inludes 2.0/2.1/2.2 support.
    # So it is used in place of the 2.3 get_all_facts
    # or the 3.2 ansible_facts api.

    # There is a problem with this test running in the Travis environment getting
    # in a loop or creating a zombie process.
    # The exact cause is not known, but a work around is to skip the test
    # if the environment variable TRAVIS is set.
    import os
    if os.getenv('TRAVIS') is not None:
        return

# Generated at 2022-06-24 21:38:19.656742
# Unit test for function ansible_facts
def test_ansible_facts():
    assert test_case_0() == 'PASS'

# Generated at 2022-06-24 21:38:26.428721
# Unit test for function ansible_facts
def test_ansible_facts():
    a = '?4A{f\x1a%\x1b\x0f\x12\x03:z\x0e\x1e\x1b\x1f\x13\x16\x1b\x00\x0f\x11\x1c'
    b = '\x1b\x1f\x0e\x11\x19:z\x0e\x1e\x1b\x1f\x13\x16\x1b\x00\x0f\x11\x1c\x1b\x1f\x0e\x11\x19\x1d'

# Generated at 2022-06-24 21:38:31.454181
# Unit test for function get_all_facts
def test_get_all_facts():
    module = 'module'
    expected = 'expected'
    actual = 'actual'

    # Test with correct arguments
    assert expected == actual

    # Test with extra/few arguments
    try:
        get_all_facts(module, extra='args')
    except Exception as e:
        assert type(e) == TypeError



# Generated at 2022-06-24 21:38:34.318314
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test if method 'ansible_facts' defined in ansible module_utils.facts is implemented
    assert hasattr(ansible_facts, '__call__')


# Generated at 2022-06-24 21:38:36.926184
# Unit test for function ansible_facts
def test_ansible_facts():
    # assert ansible_facts() == "value"
    assert True == True



# Generated at 2022-06-24 21:38:43.161139
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        from ansible.module_utils.facts import ansible_facts
    except ImportError:
        print("SKIP: Could not import module_utils.facts.ansible_facts")
        return

    assert ansible_facts(6) == '6'
    assert ansible_facts(7) == 7



# Generated at 2022-06-24 21:38:46.502267
# Unit test for function get_all_facts
def test_get_all_facts():
    assert callable(get_all_facts)



# Generated at 2022-06-24 21:38:51.930605
# Unit test for function ansible_facts
def test_ansible_facts():
    # string = 'K3F3I[C`H|E5p9hU'
    # var_0 = ansible_facts(string)
    assert True


if __name__ == '__main__':
    test_ansible_facts()
    print("Ansible 2.4 compatibility check for module " + "passed!")

# Generated at 2022-06-24 21:38:53.492185
# Unit test for function ansible_facts
def test_ansible_facts():
    var_0 = ansible_facts()
    assert issubclass(type(var_0), dict)



# Generated at 2022-06-24 21:38:59.843486
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'K3F3I[C`H|E5p9hU'
    int_0 = [6, 1, 4, 2, 5]
    float_0 = float(int_0)
    var_0 = ansible_facts(str_0, gather_subset=int_0)
    str_1 = '?:r2j'
    int_1 = [3, 1, 2]
    float_1 = float(int_1)
    var_1 = ansible_facts(str_0, gather_subset=int_0, gather_timeout=int_1)

if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:39:08.816384
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test case 0

    str_0 = 'K3F3I[C`H|E5p9hU'
    var_0 = ansible_facts(str_0)


# Generated at 2022-06-24 21:39:12.691269
# Unit test for function ansible_facts
def test_ansible_facts():
    # Python 2 and 3 compatibility: unittest module renamed this assertion method
    if not hasattr(unittest.TestCase, 'assertCountEqual'):
        unittest.TestCase.assertCountEqual = unittest.TestCase.assertItemsEqual
    test_case_0()

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-24 21:39:16.979252
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'K3F3I[C`H|E5p9hU'
    var_0 = ansible_facts(str_0)


# Generated at 2022-06-24 21:39:21.646540
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'K3F3I[C`H|E5p9hU'
    str_1 = 't'
    str_2 = '*'
    dict_0 = ansible_facts(str_0, str_1, str_2)

# Generated at 2022-06-24 21:39:23.933962
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'hWGk8NvbYp0}oX9Oh'
    var_0 = ansible_facts(str_0)

# Generated at 2022-06-24 21:39:29.218244
# Unit test for function ansible_facts
def test_ansible_facts():
    assert hasattr(ansible_facts, '__call__')

# Generated at 2022-06-24 21:39:38.300536
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = 'K3F3I[C`H|E5p9hU'
    var_0 = get_all_facts(str_0)

    assert(var_0 == 1)


# Generated at 2022-06-24 21:39:43.451968
# Unit test for function ansible_facts
def test_ansible_facts():
    src_0 = u'z$Y)_h:F}1Q4<'
    with patch.object(module_utils.facts, "ansible_collector", side_effect=mock_ansible_collector):
        # Call method
        ansible_facts(src_0)


# Generated at 2022-06-24 21:39:49.431899
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Test the module get_all_facts with arguments:
    '''
    my_module = get_all_facts

    # from ansible.module_utils.facts import get_all_facts
    # @patch("ansible.module_utils.facts.get_all_facts")
    # def test_get_all_facts(x):
    #     return get_all_facts("test")

    # assert my_module.test_get_all_facts("test") == "test"



# Generated at 2022-06-24 21:39:54.086634
# Unit test for function ansible_facts
def test_ansible_facts():
    var_0 = 'RUH[82U6'
    var_1 = ansible_facts(var_0)


# Generated at 2022-06-24 21:40:02.397852
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = ansible.module_utils.six.moves.urllib.parse.quote_plus("rh_rhel_password")
    str_1 = 'ansible_' + str_0
    var_0 = ('ansible_rh_rhel_password', 'pass', 'string')
    var_0 = [var_0]
    ansible.module_utils.basic._ANSIBLE_ARGS = None
    var_1 = ansible.module_utils.basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    var_1.params = {'gather_subset': var_0}
    var_2 = ansible_facts(var_1)
    assert type(var_2) == dict

if __name__ == '__main__':
    test_case_0

# Generated at 2022-06-24 21:40:07.937419
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 's3(x3v>g3'
    var_19 = 'T[8bv:n1C'
    var_20 = 'h@ZR'
    str_1 = 'm6~3*q3_3'
    var_21 = '6'
    var_22 = 'h4X'
    str_2 = 'B[hN'
    var_23 = '|'
    var_24 = '=3q'
    str_3 = 'E2%s3s1'
    var_25 = '-N'
    str_4 = '_9X<O'
    str_5 = 'u4L'
    var_26 = '('
    str_6 = 'Q9B'
    str_7 = 'G[z3'
    var_27

# Generated at 2022-06-24 21:40:10.516338
# Unit test for function ansible_facts
def test_ansible_facts():
    with pytest.raises(Exception):
        str_0 = 'Yd^O[++3q!9&ZE'
        var_0 = ansible_facts(str_0)

# Generated at 2022-06-24 21:40:14.836469
# Unit test for function get_all_facts
def test_get_all_facts():
    var_1 = 'E|;NtD{sHs9sVk'
    var_2 = get_all_facts(var_1)
    assert(var_2 == var_1)

test_case_0()

# Generated at 2022-06-24 21:40:24.622248
# Unit test for function ansible_facts
def test_ansible_facts():
    
    # Arguments used for creating the new namespace object
    namespace_name = 'test'
    prefix = 'test_fact'

    # Arguments used for creating the ansible_facts function
    module = 'test'
    gather_subset = ['A', 'B']
    gather_timeout = 100
    filter_spec = '*'

    # Creating an instance of the Namespace class
    namespace = PrefixFactNamespace(namespace_name=namespace_name, prefix=prefix)

    # Creating an instance of the ansible_facts function
    ansible_facts_object = ansible_facts(module=module, gather_subset=gather_subset,
        gather_timeout=gather_timeout, filter_spec=filter_spec, namespace=namespace)

    # Check if the object created is an instance of the AnsibleFacts

# Generated at 2022-06-24 21:40:27.641681
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'K3F3I[C`H|E5p9hU'
    with pytest.raises(Exception):
        var_1 = ansible_facts(str_0)


# Generated at 2022-06-24 21:40:37.029658
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True
    # TODO: Implement unit test


# Generated at 2022-06-24 21:40:37.612053
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True


# Generated at 2022-06-24 21:40:39.871242
# Unit test for function get_all_facts
def test_get_all_facts():
    with pytest.raises(TypeError):
        get_all_facts(str_0=str_0)



# Generated at 2022-06-24 21:40:41.255597
# Unit test for function ansible_facts
def test_ansible_facts():
    var_1 = ansible_facts()
    assert var_1 == None

# Generated at 2022-06-24 21:40:49.489903
# Unit test for function ansible_facts
def test_ansible_facts():
    var_0 = 0x0000
    var_1 = 0x0000
    var_0 = var_0 ^ var_1
    var_2 = 0x0000
    var_2 = var_2 ^ var_1
    var_3 = 0x0000
    var_4 = 0x0000
    var_3 = var_3 | var_4
    var_5 = 0x0000
    var_6 = 0x0000
    var_5 = var_5 | var_6
    var_7 = 0x0000
    var_7 = var_7 ^ var_6
    var_6 = 0x0000
    var_8 = 0x0000
    var_6 = var_6 | var_8
    var_9 = 0x0000
    var_10 = 0x0000
    var_9 = var_9 | var_10


# Generated at 2022-06-24 21:40:59.066915
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:41:03.789842
# Unit test for function ansible_facts
def test_ansible_facts():
    test_params = dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*'
    )
    module = AnsibleModule(argument_spec=test_params, supports_check_mode=True)
    result = ansible_facts(module, gather_subset=['all'])

    # Fail the module if there is any exception during setup and initialization of the facts collector
    assert not result.get('failed', False)

    expected_subset = set(('all', 'min', '!config'))
    assert result['ansible_facts_gather_subset'] == expected_subset



# Generated at 2022-06-24 21:41:11.975968
# Unit test for function get_all_facts

# Generated at 2022-06-24 21:41:12.710302
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True


# Generated at 2022-06-24 21:41:16.020571
# Unit test for function ansible_facts
def test_ansible_facts():
    pass


# Generating test cases for the function ansible_facts
#
# Method:
#     Tested in the unit tests
#
# Prerequisites of the test case:
#     None
#
# Input of the test case:
#     None
#
# Expected output of the test case:
#     None
#
# Output of the test case:
#     None
#
# Test result:
#     None

# Generated at 2022-06-24 21:41:34.732825
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'K3F3I[C`H|E5p9hU'
    var_0 = ansible_facts(str_0)

# Generated at 2022-06-24 21:41:36.151249
# Unit test for function ansible_facts
def test_ansible_facts():
    result = ansible_facts()
    assert isinstance(result, dict)

# Generated at 2022-06-24 21:41:42.550988
# Unit test for function ansible_facts
def test_ansible_facts():

    # First call to function ansible_facts
    assert test.call(a)
    assert test.call(b)
    assert test.call(c)
    assert test.call(d)

# Generated at 2022-06-24 21:41:46.157243
# Unit test for function get_all_facts
def test_get_all_facts():
    str_0 = 'K3F3I[C`H|E5p9hU'
    var_0 = get_all_facts(str_0)
    str_1 = 'C_!!T_u8/'
    var_1 = get_all_facts(str_1)


# Generated at 2022-06-24 21:41:51.174985
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'K3F3I[C`H|E5p9hU'
    tuple_0 = (
        'K3F3I[C`H|E5p9hU',
        'K3F3I[C`H|E5p9hU',
        'K3F3I[C`H|E5p9hU',
        'K3F3I[C`H|E5p9hU',
    )
    var_0 = ansible_facts(str_0, tuple_0)

    assert var_0 == tuple_0


# Generated at 2022-06-24 21:42:00.263254
# Unit test for function ansible_facts
def test_ansible_facts():
    ansible_facts(str_0)


if __name__ == '__main__':

    # ansible 2.4 compat
    # this is where we run the things, if we should
    # generate_ansible_facts(module)
    # test_ansible_facts(module)

    # 2.4-2.6 compat
    # generate_ansible_facts(str_0, list_0)
    # test_ansible_facts(str_0)

    # 2.3 compat
    # test_case_0(str_0, list_0)
    test_case_0()

# Generated at 2022-06-24 21:42:02.443770
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True


# Generated at 2022-06-24 21:42:09.527242
# Unit test for function ansible_facts

# Generated at 2022-06-24 21:42:12.818369
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'K3F3I[C`H|E5p9hU'
    var_0 = ansible_facts(str_0)


if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:42:16.341824
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'K3F3I[C`H|E5p9hU'
    var_0 = ansible_facts(str_0)


if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:43:00.023682
# Unit test for function ansible_facts
def test_ansible_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(default=None, type='list')
        )
    )
    res = ansible_facts(module)
    assert 'ansible_facts' in res.keys(), 'ansible_facts was not in returned dict'
    assert isinstance(res['ansible_facts'], dict), 'ansible_facts is not a dict'
    assert res['ansible_facts']['default_ipv4']['address'] is not None, \
        'default_ipv4 was not populated correctly'
    module.exit_json(ansible_facts=res)


# Generated at 2022-06-24 21:43:01.142783
# Unit test for function ansible_facts
def test_ansible_facts():
    # RuntimeError: Attempted to use a closed connection.
    pass


# Generated at 2022-06-24 21:43:02.579024
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts()

# Function to prove that the above test case can be used as an import

# Generated at 2022-06-24 21:43:03.702301
# Unit test for function get_all_facts
def test_get_all_facts():
    arg0 = ''
    test_case_0()


# Generated at 2022-06-24 21:43:09.010285
# Unit test for function ansible_facts
def test_ansible_facts():
    var_0 = ansible_facts()

# Generated at 2022-06-24 21:43:09.426776
# Unit test for function ansible_facts
def test_ansible_facts():
    assert False

# Generated at 2022-06-24 21:43:11.397215
# Unit test for function get_all_facts
def test_get_all_facts():
    string_0 = 'K3F3I[C`H|E5p9hU'
    var_0 = get_all_facts(string_0)
    assert var_0 == None



# Generated at 2022-06-24 21:43:12.828918
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts() == {}


# Generated at 2022-06-24 21:43:18.312495
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'K3F3I[C`H|E5p9hU'
    var_0 = ansible_facts(str_0)

if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:43:19.465485
# Unit test for function ansible_facts
def test_ansible_facts():
    assert callable(ansible_facts)


# Generated at 2022-06-24 21:44:32.652861
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'K3F3I[C`H|E5p9hU'
    var_0 = ansible_facts(str_0)



# Generated at 2022-06-24 21:44:35.229918
# Unit test for function ansible_facts
def test_ansible_facts():
    module = ansible_facts
    # No parameters testcase
    module()
    # This testcase ensures that parameters are getting passed correctly
    get_all_facts(module)

# Generated at 2022-06-24 21:44:45.748156
# Unit test for function get_all_facts

# Generated at 2022-06-24 21:44:53.533721
# Unit test for function ansible_facts
def test_ansible_facts():
    # This module is called directly by test_utils_module.py, to verify that
    # get_all_facts and ansible_facts have the same signature.
    # We need to verify that both have the same signature and the same calling
    # semantics. So we verify that get_all_facts and ansible_facts both expect
    # a gather_subset option.
    ansible_facts_module = \
        get_all_facts(
            module=None,
            gather_subset=None
        )

    isinstance(ansible_facts_module, dict)
    len(ansible_facts_module) > 0



# Generated at 2022-06-24 21:44:54.672941
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts


# Generated at 2022-06-24 21:44:56.815094
# Unit test for function ansible_facts
def test_ansible_facts():
    str_0 = 'K3F3I[C`H|E5p9hU'
    var_0 = ansible_facts(str_0)


# Generated at 2022-06-24 21:44:58.637442
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts('PAM_FAIL_CHECK=1') == ('2', '2x', '2.3', '3', '3x', '3.3', '4')


# Generated at 2022-06-24 21:45:01.209081
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True


# Generated at 2022-06-24 21:45:01.951333
# Unit test for function get_all_facts
def test_get_all_facts():
    assert callable(get_all_facts)




# Generated at 2022-06-24 21:45:08.133831
# Unit test for function ansible_facts
def test_ansible_facts():
    # Given
    var_0 = ansible_collector.Collector
    var_1 = var_0.__module__
    with mock.patch.object(ansible_collector, "Collector", autospec=True) as mock_ansible_collector_collector:
        mock_ansible_collector_collector.return_value = var_0
        mock_ansible_collector_collector.__module__ = var_1

        var_2 = ansible_collector.CollectorMethod
        var_3 = var_2.__module__
        with mock.patch.object(ansible_collector, "CollectorMethod", autospec=True) as mock_ansible_collector_collectormethod:
            mock_ansible_collector_collectormethod.return_value = var_2
            mock_