

# Generated at 2022-06-24 21:37:51.962721
# Unit test for function get_all_facts
def test_get_all_facts():
    # Input parameters
    int_0 = None

    # Output parameters
    var_0 = None

    # Call the method
    var_0 = get_all_facts(int_0)

    # Assert we got the correct result
    assert var_0 is None, "Got incorrect value for get_all_facts"



# Generated at 2022-06-24 21:38:01.214054
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)

if __name__ == "__main__":
    import sys
    import random
    import traceback
    #from native.debugger.debugger_unittest import run_unittest
    from native.debugger.python_debugger_unittest import run_unittest

    try:
        from native.debugger.backend import start_debugging
    except ImportError:
        traceback.print_exc()
        sys.exit(1)

    # Set the debugging options
    start_debugging(enabled=True, client_id=None, module_name=None, options=None, process_id=None, wait_on_error=None,
                    redirect_output=None, trace_python=None, timeout=None)



# Generated at 2022-06-24 21:38:05.056149
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    str_0 = 'test_filter'
    int_1 = 4087
    list_0 = ['test_gather_subset']
    test_dict = {'filter': str_0, 'gather_subset': list_0}
    var_0 = ansible_facts(int_0, **test_dict)

# Generated at 2022-06-24 21:38:13.607121
# Unit test for function get_all_facts

# Generated at 2022-06-24 21:38:15.519888
# Unit test for function get_all_facts
def test_get_all_facts():
    with pytest.raises(AssertionError):
        get_all_facts(module=None)


# Generated at 2022-06-24 21:38:20.150708
# Unit test for function ansible_facts
def test_ansible_facts():
    # t0.0 "get_all_facts"
    var_0 = get_all_facts(module=int)
    # t0.1 "ansible_facts"
    var_1 = ansible_facts(module=int)



# Generated at 2022-06-24 21:38:22.842796
# Unit test for function ansible_facts
def test_ansible_facts():

    module = ansible_facts.AnsibleModule(
        argument_spec={
            'gather_subset': {'required': True, 'type': 'list', 'default': ['all']},
        }
    )

    ansible_facts(module)

# Generated at 2022-06-24 21:38:27.831224
# Unit test for function get_all_facts
def test_get_all_facts():
    var_0 = 4087
    result = get_all_facts(var_0)
    assert isinstance(result, dict)


# Generated at 2022-06-24 21:38:29.884001
# Unit test for function ansible_facts
def test_ansible_facts():
    assert callable(ansible_facts)
    assert isinstance(ansible_facts(1), dict)


# Generated at 2022-06-24 21:38:31.821824
# Unit test for function ansible_facts
def test_ansible_facts():
    assert(get_all_facts(None)).keys() == ansible_facts(None).keys()

# Generated at 2022-06-24 21:38:37.186356
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)
    print(var_0)

if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-24 21:38:43.460772
# Unit test for function ansible_facts
def test_ansible_facts():
    facts = ansible_facts(int_0)

test_case_0.__doc__ = u'Function get_all_facts'
test_ansible_facts.__doc__ = u'Function ansible_facts'

if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

    pass

# Generated at 2022-06-24 21:38:52.941474
# Unit test for function ansible_facts
def test_ansible_facts():
    hostname = 'host_name'
    module_name = 'module_name'

    # read in test data
    fixture_path = 'fixtures/ansible_collected_facts.json'
    test_data = read_test_data(fixture_path)

    # Inject data into module
    test_module = AnsibleModule(argument_spec=dict())
    test_module.params = json.loads(test_data)

    # get ansible_facts
    ansible_facts = ansible_facts(module=test_module)

    assert ansible_facts['hostname'] == hostname
    assert ansible_facts['module_setup'] == True
    assert ansible_facts['fips'] == False


# Generated at 2022-06-24 21:38:56.724946
# Unit test for function ansible_facts
def test_ansible_facts():
    test_ansible_facts.__doc__ = ansible_facts.__doc__
    test_ansible_facts.__name__ = ansible_facts.__name__
    test_ansible_facts.__annotations__ = ansible_facts.__annotations__

    int_0 = 4087
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:39:03.804584
# Unit test for function ansible_facts
def test_ansible_facts():
    print("\nCalling function ansible_facts")
    r_0 = ansible_facts(4087)
    print("\nAsserting equality of:")
    print("\tvar_0 = %s" % format(ansible_facts(4087)))
    assert r_0 == 0

# Generated at 2022-06-24 21:39:05.890510
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    str_0 = '*'
    var_0 = ansible_facts(int_0, str_0)

# Generated at 2022-06-24 21:39:12.709405
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = None
    int_1 = None
    int_2 = None
    var_0 = ansible_facts(int_0, gather_subset=int_1)
    var_1 = ansible_facts(int_2)


# Generated at 2022-06-24 21:39:17.428216
# Unit test for function get_all_facts
def test_get_all_facts():
    # Setup
    int_0 = 4087

    # Act
    var_0 = get_all_facts(int_0)

    # Verify
    assert var_0 is None


# Generated at 2022-06-24 21:39:19.205926
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)


# Generated at 2022-06-24 21:39:23.779342
# Unit test for function ansible_facts
def test_ansible_facts():
    # Calling ansible_facts without required arguments
    try:
        ansible_facts()
    except TypeError as err:
        # Assert error is raised
        assert True
    else:
        # Assert error is not raised
        assert False


if __name__ == "__main__":
    test_ansible_facts()

# Generated at 2022-06-24 21:39:31.732823
# Unit test for function ansible_facts
def test_ansible_facts():
    # Mock module
    module = {
        'params': {
            'filter': '*',
            'gather_subset': ['*'],
            'gather_timeout': 10
        }
    }
    assert ansible_facts(module) is not None

# Generated at 2022-06-24 21:39:34.729125
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Test with arguments '''
    module = AnsibleModule(argument_spec=dict())
    var_0 = ansible_facts(module)
    assert var_0 is None



# Generated at 2022-06-24 21:39:38.379557
# Unit test for function ansible_facts
def test_ansible_facts():
    var_0 = ansible_facts('AnsibleModule')
    assert isinstance(var_0, dict)
    assert var_0['distribution'] == 'Ubuntu'


# Generated at 2022-06-24 21:39:48.912714
# Unit test for function ansible_facts
def test_ansible_facts():

    # dict, dict()
    var_0 = ansible_facts(module={})

    # dict, dict()
    var_1 = ansible_facts(module={})

    # dict, dict()
    var_2 = ansible_facts(module={})

    # dict, dict()
    var_3 = ansible_facts(module={})

    # dict, dict()
    var_4 = ansible_facts(module={})

    # dict, dict()
    var_5 = ansible_facts(module={})

    # dict, dict()
    var_6 = ansible_facts(module={})

    # dict, dict()
    var_7 = ansible_facts(module={})

    # dict, dict()
    var_8 = ansible_facts(module={})

    # dict, dict()
    var_

# Generated at 2022-06-24 21:39:54.616608
# Unit test for function ansible_facts
def test_ansible_facts():
    # call function ansible_facts with args
    var_0 = ansible_facts()
    ansible_module_facts()
    # return a dict mapping the bare fact name ('default_ipv4' with no 'ansible_' namespace) to the fact value.

# Generated at 2022-06-24 21:39:56.607838
# Unit test for function ansible_facts
def test_ansible_facts():
    # TODO: Work in progress: Unit test for function ansible_facts
    # TODO: Work in progress: Not yet implemented
    pass
    return

# Generated at 2022-06-24 21:40:02.325179
# Unit test for function ansible_facts
def test_ansible_facts():
    #set up and execute the function
    var_0 = ansible_facts()
    expected_result = {}
    assert expected_result == var_0


# Generated at 2022-06-24 21:40:03.656580
# Unit test for function ansible_facts
def test_ansible_facts():
    var_1 = ansible_facts()
    assert(var_1 == 'ansible_facts')


# Generated at 2022-06-24 21:40:09.250372
# Unit test for function ansible_facts
def test_ansible_facts():
    f = ansible_facts(module, gather_subset)


# Generated at 2022-06-24 21:40:10.552736
# Unit test for function get_all_facts
def test_get_all_facts():
    print('Testing get_all_facts')
    res_0 = get_all_facts(module)


# Generated at 2022-06-24 21:40:19.586394
# Unit test for function ansible_facts
def test_ansible_facts():
    gather_subset = ['apparmor', 'caps', 'cmdline', 'date_time', 'distribution', 'dns', 'env', 'fips', 'local', 'lsb', 'pkg_mgr', 'platform', 'python', 'selinux', 'service_mgr', 'ssh_pub_keys', 'user']
    filter_spec = '*'
    module = ''

    sub_test_ansible_facts()


# Generated at 2022-06-24 21:40:23.683128
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 1881
    dict_0 = ansible_facts(int_0)
    var_0 = dict_0.get('swapfree_mb')
    return var_0


# Basic test of function ansible_facts to make sure the function doesn't crash.
#
test_ansible_facts()

# Generated at 2022-06-24 21:40:26.010023
# Unit test for function ansible_facts
def test_ansible_facts():
    print("\n\n")

    int_0 = 4087
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:40:34.084252
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    str_0 = '<module_utils.facts.ansible_collector.AnsibleCollector object at 0x7f86174546d0>'
    str_1 = '<module_utils.facts.namespace.PrefixFactNamespace object at 0x7f8617466c10>'
    frozenset_0 = frozenset(['apparmor', 'caps', 'cmdline', 'date_time', 'distribution', 'dns', 'env', 'fips', 'local', 'lsb', 'pkg_mgr', 'platform', 'python', 'selinux', 'service_mgr', 'ssh_pub_keys', 'user'])
    frozenset_1 = frozenset(['all'])

# Generated at 2022-06-24 21:40:43.752527
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = 4087
    var_0 = get_all_facts(int_0)
# Testing if the type of var_0 is dict
    assert isinstance(var_0, dict)
# Testing if the value of var_0[0] is dict
    assert isinstance(var_0[0], dict)

# Testing if the value of var_0[0] is empty
    assert not var_0[0]
# Testing if the length of var_0[0] is 0
    assert len(var_0[0]) == 0

# Testing if the value of var_0[1] is dict
    assert isinstance(var_0[1], dict)

# Testing if the value of var_0[1][u'date_time'] is dict

# Generated at 2022-06-24 21:40:44.977062
# Unit test for function ansible_facts
def test_ansible_facts():

    # Call function ansible_facts
    ansible_facts()

# Generated at 2022-06-24 21:40:47.258440
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 1
    int_1 = 3949
    var_0 = ansible_facts(int_0, int_1)

# Generated at 2022-06-24 21:40:52.353227
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    str_0 = 'filter'
    dict_0 = dict()
    dict_0['filter'] = '*'
    var_0 = ansible_facts(int_0, filter=dict_0)
    var_1 = True
    if var_0 == var_1:
        print('Success')
    else:
        print('Failed')

if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:40:53.390223
# Unit test for function ansible_facts
def test_ansible_facts():
    test_case_0()


# Generated at 2022-06-24 21:40:56.315406
# Unit test for function ansible_facts
def test_ansible_facts():
    for i in range(4):
        lst = []
        for i in range(4):
            lst.append(i * 10)
        ansible_facts(lst)


# Generated at 2022-06-24 21:41:03.953012
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)

# Generated from test_id_7

# Generated at 2022-06-24 21:41:12.114378
# Unit test for function get_all_facts
def test_get_all_facts():
    with patch("ansible.module_utils.facts.namespace.PrefixFactNamespace") as mocked_PrefixFactNamespace:
        with patch("ansible.module_utils.facts.ansible_collector.get_ansible_collector") as mocked_get_ansible_collector:
            with patch("ansible.module_utils.facts.default_collectors.collectors") as mocked_collectors:
                mocked_PrefixFactNamespace_instance = Mock()
                mocked_PrefixFactNamespace.return_value = mocked_PrefixFactNamespace_instance
                mocked_get_ansible_collector_instance = Mock()
                mocked_get_ansible_collector.return_value = mocked_get_ansible_collector_instance
                assert get_all_facts(self.int_0) == mocked_get_ans

# Generated at 2022-06-24 21:41:14.016574
# Unit test for function ansible_facts
def test_ansible_facts():
    # Assert statements will be gathered from various parts of the code
    # so we can test that the facts module executes in its entirety.
    assert True

# Generated at 2022-06-24 21:41:26.158304
# Unit test for function ansible_facts
def test_ansible_facts():
    assert callable(ansible_facts)
    get_all_facts(get_all_facts(get_all_facts(None)))
    ansible_facts(ansible_facts(ansible_facts(None)))
    ansible_facts(ansible_facts(None))
    ansible_facts(None)

    assert callable(get_all_facts)
    get_all_facts(get_all_facts(None))
    get_all_facts(None)

    ansible_facts(ansible_facts(None))
    get_all_facts(get_all_facts(ansible_facts(None)))
    get_all_facts(get_all_facts(None))
    get_all_facts(ansible_facts(None))
    ansible_facts(ansible_facts(get_all_facts(None)))


# Generated at 2022-06-24 21:41:27.025863
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:41:31.796607
# Unit test for function ansible_facts
def test_ansible_facts():
    get_all_facts = get_all_facts
    int_0 = 4087
    var_0 = ansible_facts(int_0)
    test_case_0()

# Generated at 2022-06-24 21:41:35.328939
# Unit test for function ansible_facts
def test_ansible_facts():
    class AnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': "none"}
    int_0 = 4087
    var_0 = ansible_facts(AnsibleModule())

if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:41:42.194294
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    test_dict = ansible_facts()
    assert isinstance(test_dict, dict), "Ansible Facts failed to return a dictionary"
    assert 'processor' in test_dict, "Ansible Facts is missing the 'processor' fact"


# Generated at 2022-06-24 21:41:43.235936
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 1625
    var_0 = ansible_facts(int_0)


# Generated at 2022-06-24 21:41:44.707875
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)



# Generated at 2022-06-24 21:42:03.287460
# Unit test for function ansible_facts
def test_ansible_facts():
    # W0613: Unused argument 'module'
    # pylint: disable=W0613
    def fake_ansible_module(argspec):
        '''create a fake ansible module'''
        return {'params': argspec,
                'params.get': lambda arg_name, default_val: argspec.get(arg_name, default_val)}

    module = fake_ansible_module({'gather_subset': ['all']})
    assert ansible_facts(module) is not None, 'assert #1 failed'
    module = fake_ansible_module({'gather_subset': ['network']})
    assert ansible_facts(module) is not None, 'assert #2 failed'

# Generated at 2022-06-24 21:42:06.008742
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)

# test call of functions with parameters

# Generated at 2022-06-24 21:42:10.059994
# Unit test for function ansible_facts
def test_ansible_facts():
    var_1 = 'module'
    int_1 = 4087
    var_0 = ansible_facts(var_1, int_1)
    assert var_0 == {'example_fact': 'I am a fact'}

# Generated at 2022-06-24 21:42:12.615435
# Unit test for function ansible_facts
def test_ansible_facts():

    try:
        ansible_facts()
    except Exception as err:
        print("Error: {0}".format(err))
        assert False
    # tests complete
    assert True


# Generated at 2022-06-24 21:42:14.522106
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    str_0 = ansible_facts(int_0)
    assert str_0 == None


# Generated at 2022-06-24 21:42:18.750995
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True == True

# Generated at 2022-06-24 21:42:20.044171
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(int) == int


# Generated at 2022-06-24 21:42:24.636893
# Unit test for function ansible_facts
def test_ansible_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Call to ansible_facts()
    result = ansible_facts(module)
    assert result


if __name__ == '__main__':
    pass

# Generated at 2022-06-24 21:42:26.036372
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:42:27.383861
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:42:52.568746
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:42:54.452224
# Unit test for function get_all_facts
def test_get_all_facts():
    assert callable(get_all_facts)

# Generated at 2022-06-24 21:42:59.546385
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)


if __name__ == '__main__':
    test_case_0()
    test_ansible_facts()

# Generated at 2022-06-24 21:43:05.357641
# Unit test for function ansible_facts
def test_ansible_facts():
    # Testing the return value of function ansible_facts
    assert ansible_facts(True)


# class SquareTest(unittest.TestCase):
#     # Testing the return value of function get_all_facts
#     def test_square_with_true(self):
#         self.assertEqual(get_all_facts(True), True)
#
#     # Testing the return value of function get_all_facts
#     def test_square_with_false(self):
#         self.assertEqual(get_all_facts(False), False)
#
#     # Testing the return value of function get_all_facts
#     def test_square_with_string(self):
#         self.assertEqual(get_all_facts(4087), "abcd")
#
#     # Testing the return value of function

# Generated at 2022-06-24 21:43:06.798387
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = 4087
    var_0 = get_all_facts(int_0)


# Generated at 2022-06-24 21:43:09.569638
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:43:11.729739
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = 4087
    var_0 = get_all_facts(int_0)
    assert var_0 == "get_all_facts"


# Generated at 2022-06-24 21:43:17.733033
# Unit test for function ansible_facts
def test_ansible_facts():
    module = AnsibleModule({},
                           {'gather_subset': ['all'],
                            'filter': '*',
                            'gather_timeout': 10})

    ansible_facts(module, gather_subset=['all'])

# Generated at 2022-06-24 21:43:19.231537
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)


# Generated at 2022-06-24 21:43:26.266827
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        assert callable(get_all_facts)
        # Call the function.
        test_case_0()
    except AssertionError as e:
        print("[FAIL] get_all_facts() raises AssertionError exception.")

if __name__ == "__main__":
    import sys
    import traceback
    import types

    # If --pdb, enable debugger, else handle exceptions
    if "--pdb" in sys.argv:
        try:
            import ipdb as pdb
        except ImportError:
            import pdb
        pdb.post_mortem()

# Generated at 2022-06-24 21:44:28.184156
# Unit test for function ansible_facts
def test_ansible_facts():

    kwargs = {}

    # expected defaults
    kwargs['gather_subset'] = ['all']
    kwargs['gather_timeout'] = 10
    kwargs['filter'] = '*'

    # modify some arg values
    kwargs['gather_subset'] = ['min']
    kwargs['gather_timeout'] = 3
    kwargs['filter'] = {'ansible_all_ipv4_addresses': '10.*'}

    # run the code to be tested
    result = ansible_facts(**kwargs)

    # check for correct result
    assert result == 42

# Generated at 2022-06-24 21:44:38.815395
# Unit test for function get_all_facts

# Generated at 2022-06-24 21:44:41.123797
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test case 0
    int_0 = 4087
    var_0 = ansible_facts(int_0)
    assert var_0 == "4087"

# Generated at 2022-06-24 21:44:44.579130
# Unit test for function ansible_facts
def test_ansible_facts():
    target = int
    if isinstance(target, int):
        test_case_0()

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-24 21:44:49.538124
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    test_case_1(int_0)
    test_case_1(int_0)
    test_case_1(int_0)
    test_case_1(int_0)
    test_case_2()
    test_case_1(int_0)


# Generated at 2022-06-24 21:44:51.669669
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True

if __name__ == '__main__':
    testcase_0()

# Generated at 2022-06-24 21:45:01.803890
# Unit test for function ansible_facts
def test_ansible_facts():
    int_1 = 5296
    str_2 = "*"
    str_3 = "ansible_all"
    str_4 = "ansible_network"
    str_5 = "ansible_local"
    int_6 = 10
    str_7 = "ansible"
    var_8 = ansible_facts(int_1, gather_subset=str_2)
    var_9 = ansible_facts(int_1, gather_subset=str_3)
    var_10 = ansible_facts(int_1, gather_subset=str_4)
    var_11 = ansible_facts(int_1, gather_subset=str_5)
    var_12 = ansible_facts(int_1, gather_subset=int_6)
    var_13 = ansible_facts

# Generated at 2022-06-24 21:45:03.843257
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)
    assert var_0 == "ansible_all_ipv4_addresses"


# Generated at 2022-06-24 21:45:05.583131
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = 4087
    var_0 = get_all_facts(int_0)



# Generated at 2022-06-24 21:45:09.028310
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Unit test for function get_all_facts

    No parameters tested.
    '''
    test_case_0()

# Generated at 2022-06-24 21:47:09.164199
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)
    # state 1
    int_1 = int_0
    var_1 = ansible_facts(int_1)
    # state 2
    int_2 = int_1
    var_2 = ansible_facts(int_2)
    # state 3
    int_3 = int_2
    var_3 = ansible_facts(int_3)
    # state 4
    int_4 = int_3
    var_4 = ansible_facts(int_4)
    # state 5
    int_5 = int_4
    var_5 = ansible_facts(int_5)
    # state 6
    int_6 = int_5
    var_6 = ansible_facts(int_6)
    #

# Generated at 2022-06-24 21:47:11.538016
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    func_0 = ansible_facts(int_0, gather_subset=None)


# Generated at 2022-06-24 21:47:12.741307
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)

# Generated at 2022-06-24 21:47:15.496331
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 1073741824
    list_0 = ['a', 'b', 'c', 'd', 'e']
    var_0 = ansible_facts(int_0, list_0)

# Generated at 2022-06-24 21:47:16.572885
# Unit test for function get_all_facts
def test_get_all_facts():
    int_0 = 4087
    test_case_0()


# Generated at 2022-06-24 21:47:17.858911
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4087
    var_0 = ansible_facts(int_0)


# Generated at 2022-06-24 21:47:22.104095
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test with no args
    try:
        ansible_facts()
    except TypeError:
        assert True
    # Test with correct args
    assert ansible_facts(module=object)
    # Test with incorrect args
    try:
        ansible_facts(test_param_0=False)
    except TypeError:
        assert True

# Generated at 2022-06-24 21:47:24.673398
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = 4088
    var_0 = ansible_facts(int_0)



# Generated at 2022-06-24 21:47:25.151091
# Unit test for function get_all_facts
def test_get_all_facts():
    assert True


# Generated at 2022-06-24 21:47:31.379062
# Unit test for function ansible_facts
def test_ansible_facts():
    int_0 = OrderedDict()
    str_0 = 'uname'
    str_1 = 'summit_ezbox'
    int_0[str_0] = str_1
    str_2 = 'ansible_fqdn'
    str_3 = 'summit_ezbox'
    int_0[str_2] = str_3
    str_4 = 'ansible_domain'
    str_5 = 'default'
    int_0[str_4] = str_5
    str_6 = 'ansible_distribution_version'
    str_7 = '16.04'
    int_0[str_6] = str_7
    str_8 = 'ansible_hostname'
    str_9 = 'summit_ezbox'
    int_0[str_8]