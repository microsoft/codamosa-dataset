

# Generated at 2022-06-22 22:43:29.093594
# Unit test for function get_all_facts
def test_get_all_facts():

    class Module(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}


    assert get_all_facts(Module(['all'])) == ansible_facts(Module(['all']))
    assert get_all_facts(Module(['!all'])) == ansible_facts(Module(['!all']))
    assert get_all_facts(Module(['network'])) == ansible_facts(Module(['network']))
    assert get_all_facts(Module(['network', '!all'])) == ansible_facts(Module(['network', '!all']))
    assert get_all_facts(Module(None)) == ansible_facts(Module(None))



# Generated at 2022-06-22 22:43:38.598119
# Unit test for function get_all_facts
def test_get_all_facts():
    # Import AnsibleModule to get around circular dependency
    from ansible.module_utils.basic import AnsibleModule
    # Set up module arguments for test
    module = AnsibleModule(argument_spec={'gather_subset': {'type': 'list', 'default': ['!all']}},
                           bypass_checks=True)
    # run the test and verify the results
    facts = get_all_facts(module)
    assert 'ansible_facts' in facts
    assert 'ansible' in facts['ansible_facts']
    assert 'architecture' in facts['ansible_facts']['ansible']
    assert 'lsb' in facts['ansible_facts']['ansible']


# Generated at 2022-06-22 22:43:49.591461
# Unit test for function ansible_facts
def test_ansible_facts():
    import mock
    import platform
    from ansible.module_utils.facts import default_collectors

    distro = platform.dist()[0]
    distro_version = platform.dist()[1]

    class_name = "ansible.module_utils.facts.{0}_collector.{0}_collector".format(distro)
    class_path = "{0}.{1}".format(default_collectors.__name__, distro)
    path = "ansible.module_utils.facts.{0}_collector".format(distro)
    with mock.patch(class_path) as patcher:
        instance = patcher.return_value
        instance.distribution.return_value = distro
        instance.distribution_version.return_value = distro_version

# Generated at 2022-06-22 22:43:57.422913
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for get_all_facts'''
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=None, type='list'),
            filter=dict(default='*', type='str'),
            gather_timeout=dict(default=10, type='int'),
        ),
    )

    get_all_facts(module)

# Generated at 2022-06-22 22:44:01.776110
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import unittest
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_gather_subset
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.system import distro
    from ansible.module_utils.facts.system import default_ipv4
    from ansible.module_utils.facts.system import default_ipv6
    from ansible.module_utils.facts.system import identity

# Generated at 2022-06-22 22:44:07.891274
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule(object):

        def __init__(self, params=None):
            self.params = params

    all_facts = get_all_facts(MockModule(params={'gather_subset': ['all']}))

    assert 'default_ipv4' in all_facts

# Generated at 2022-06-22 22:44:15.398680
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeAnsibleModule(object):
        def __init__(self):
            self.params = {}

    fake_module = FakeAnsibleModule()

    # Empty gather_subset
    fake_module.params['gather_subset'] = []
    collected_facts = get_all_facts(fake_module)
    assert len(collected_facts) > 0

    # Not empty gather_subset
    fake_module.params['gather_subset'] = ['all']
    collected_facts = get_all_facts(fake_module)
    assert len(collected_facts) > 0

# Generated at 2022-06-22 22:44:18.891129
# Unit test for function get_all_facts
def test_get_all_facts():
    # test backwards compat with ansible 2.2/2.3
    module = {'params': {'gather_subset': ['all']}}
    assert get_all_facts(module)


# Generated at 2022-06-22 22:44:29.959978
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import json
    import unittest

    class TestClass:
        pass

    class FakeModule:
        def __init__(self, **kwargs):
            self.params = {}
            for k, v in kwargs.items():
                self.params[k] = v

        def fail_json(self, **kwargs):
            self.fail_json_called = True
            self.fail_json_kwargs = kwargs
            raise Exception('fail_json called')

        def exit_json(self, **kwargs):
            self.exit_json_called = True
            self.exit_json_kwargs = kwargs


# Generated at 2022-06-22 22:44:37.087331
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        from ansible.module_utils.facts.network.base import NetworkCollector
    except ImportError:
        NetworkCollector = None
    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    fake = FakeModule()
    if NetworkCollector is not None:
        assert 'default_ipv4' in get_all_facts(fake)
    else:
        assert 'default_ipv4' not in get_all_facts(fake)



# Generated at 2022-06-22 22:44:48.204306
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import cache
    from ansible.module_utils import common_koji
    from ansible.module_utils._text import to_bytes, to_native

    class FakeModule():
        '''A Fake AnsibleModule'''

        def __init__(self):
            self.params = dict()

        def get_bin_path(self, executable, required=False):
            '''fake implementation of AnsibleModule.get_bin_path (which returns the path to the bin)'''
            if executable in ('rpm', 'yum'):
                return '/usr/bin/yum'
            elif executable == 'dnf':
                return '/usr/bin/dnf'
            elif executable in ('apt', 'apt-get'):
                return '/usr/bin/apt-get'

# Generated at 2022-06-22 22:45:00.227541
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    This is a test for get_all_facts
    '''
    import os
    import sys

    # Adding ansible includes path
    ans_path = os.path.join(os.getcwd(), 'includes')
    sys.path.append(ans_path)

    from ansible.module_utils import facts

    # Creating a ansible module to call get_all_facts
    class AnsModule(object):
        def __getattr__(self, item):
            if item == 'params':
                return dict()
            else:
                return None
    ans_mod = AnsModule()

    # Calling the get_all_facts function
    test_facts = facts.get_all_facts(ans_mod)

    # Testing values

# Generated at 2022-06-22 22:45:00.868136
# Unit test for function get_all_facts
def test_get_all_facts():
    get_all_facts

# Generated at 2022-06-22 22:45:10.832834
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts, ansible_facts
    import module_utils.facts

    fact_collector = module_utils.facts.ansible_collector.AnsibleDefaultFactCollector(filter_spec='*')

    class TestAnsibleModule():

        def __init__(self):
            self.params = {'gather_subset': ['all']}

        def get_bin_path(self, executable, opts='', required=False):
            # AnsibleModule.get_bin_path was only introduced in 2.3
            return 'fake_path'

        def _handle_aliases(self):
            # AnsibleModule._handle_aliases was only introduced in 2.3
            pass


# Generated at 2022-06-22 22:45:16.794017
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import Facts

    facts = Facts(None, gather_subset=['all'])
    fact_dict = get_all_facts(facts)

    # We should get something back
    assert fact_dict

    # check that we get a fact from a specific collector
    assert fact_dict['default_ipv4']



# Generated at 2022-06-22 22:45:27.600374
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import caching
    import json
    import os

    # This unit test can use the ansible_facts_cache as a way of returning pre-canned facts
    # without having to actually collect facts from the system.  The resource_cache
    # module is stubbed out in this test  so this unit test can run without needing
    # access to the filesystem to actually read or write the cached facts.

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeResourceCache(object):
        def __init__(self):
            self.cache = {}

        def get(self, key):
            return self.cache.get(key)

        def set(self, key, value):
            self.cache

# Generated at 2022-06-22 22:45:34.299577
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):

        def __init__(self, gather_subset):
            self.params = dict()
            self.params['gather_subset'] = gather_subset

    gather_subset = ['network', 'virtual']
    fake_module = FakeModule(gather_subset=gather_subset)
    facts_dict = get_all_facts(module=fake_module)
    assert 'distribution' in facts_dict
    assert 'distribution_release' in facts_dict
    assert 'network' not in facts_dict
    assert 'virtualization_role' not in facts_dict



# Generated at 2022-06-22 22:45:38.848356
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    assert expected results when calling ansible_facts()
    '''
    # TODO: stub out a fake AnsibleModule, and verify that the facts collector gets called with the
    #       expected options
    assert True

# Generated at 2022-06-22 22:45:46.619349
# Unit test for function get_all_facts
def test_get_all_facts():
    # test_ansible_facts
    from ansible.module_utils import basic
    from io import StringIO

    from ansible.module_utils.facts.sys_info.proc_fact_collector import ProcMemInfo
    from ansible.module_utils.facts.sys_info.proc_fact_collector import ProcCpuInfo
    from ansible.module_utils.facts.sys_info.proc_fact_collector import LCProcNetDev

    # Basic ansible module for passing into function
    basic_module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Create custom collecters
    custom_proc_mem = ProcMemInfo(module=basic_module, gather_subset=['!all'])

# Generated at 2022-06-22 22:45:53.153542
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=None),
                                                'filter': dict(type='str', default='*')})
    facts = ansible_facts(module)

    assert isinstance(facts, Mapping)

# Generated at 2022-06-22 22:46:00.022913
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'gather_subset': ['all']})
    all_facts = get_all_facts(module)
    assert isinstance(all_facts, dict)
    assert 'all' in all_facts
    # get_all_facts wraps the facts inside the 'ansible' key - pop it off
    facts = all_facts['ansible']
    assert isinstance(facts, dict)
    assert facts['default_ipv4']['address'] == '127.0.0.1'



# Generated at 2022-06-22 22:46:10.540866
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Test for ansible 2.2/2.3 module_utils.facts.get_all_facts method'''
    class TestModule(object):
        def __init__(self):
            self.params = {'gather_subset': {'all'}}

    test_module = TestModule()

    facts_dict = get_all_facts(test_module)

    assert 'default_ipv4' in facts_dict
    assert 'default_ipv4' in facts_dict
    assert 'system' in facts_dict
    assert facts_dict['system'] in ['Linux', 'OpenBSD', 'FreeBSD', 'NetBSD']


if __name__ == '__main__':
    test_get_all_facts()

# Generated at 2022-06-22 22:46:19.109265
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.core as facts_core

    facts_core.ansible_module_instance = None

    import ansible.module_utils.facts
    class FakeModule:
        def __init__(self, params=None):
            if params is None:
                params = {}
            self.params = params
    m = FakeModule({'gather_subset': ['all']})
    all_facts = facts_core.get_all_facts(m)
    assert all_facts['distribution'] == ansible.module_utils.facts.distribution()

# Generated at 2022-06-22 22:46:27.106506
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test ansible_facts gather_subset arg handling'''
    # Ensure that gather_subset defaults to module.params['gather_subset']
    # if not passed explicitly
    class MockAnsibleModule():
        def __init__(self):
            self.params = {'gather_subset': ['!all']}
    module = MockAnsibleModule()

    # AnsibleModule.params['gather_subset'] is not empty, so it is not used as the
    # default value for ansible_facts' gather_subset arg
    facts_dict = ansible_facts(module=module)
    assert set(facts_dict.keys()) == set(['module_setup'])

    # The default gather_subset value is used if not empty

# Generated at 2022-06-22 22:46:36.137875
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import module_proto

    # Note we do not pass a gather_timeout, so gather_timeout should default to 10
    raw_params = '''{
        "gather_subset": [
            "facter",
            "hardware",
            "virtual"
        ]
    }'''
    params = module_proto.ModuleParams.from_json(to_bytes(raw_params, errors='surrogate_or_strict'))
    test_module = module_proto.AnsibleModule(
        argument_spec=params.argument_spec,
        bypass_checks=False,
        no_log=True,
        params=params
    )

    facts = get_all_facts(test_module)


# Generated at 2022-06-22 22:46:47.075046
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Mock up an ansible module and test calling ansible_facts'''

    import ansible.module_utils.facts.namespace
    from ansible.module_utils.facts.namespace import NamespaceCollector

    class MockModule:
        class params(dict):
            pass

        def exit_json(self, **kwargs):
            print(kwargs)

    class MockNamespaceCollector(NamespaceCollector):
        """Mock the NamespaceCollector to return fixed facts dict,
        instead of calling the real collector classes
        """
        def collect(self, module=None):
            return {'a': 'b'}

    # Mock up a mock module and mock NamespaceCollector to test ansible_facts
    mock_module = MockModule()

    old_mock_collector = None
    old_mock_

# Generated at 2022-06-22 22:46:58.710794
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    import sys
    import os
    import mock

    # Set sys.argv to an array containing "ansible" and the file path to this file
    # The module load teardown code will run it as the entry point and call the module.exit_json()
    # function in this file
    sys.argv = ['ansible', __file__]

    # Create a mock AnsibleModule
    with mock.patch.object(sys, 'argv', ['ansible', __file__]):
        from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-22 22:47:03.722299
# Unit test for function get_all_facts
def test_get_all_facts():
    '''returns a dict mapping the bare fact name ('default_ipv4' with no 'ansible_' namespace) to
    the fact value.'''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=[])})
    assert isinstance(get_all_facts(module), dict)


# Generated at 2022-06-22 22:47:12.939991
# Unit test for function get_all_facts
def test_get_all_facts():

    # Import needed to construct the module object
    from ansible.module_utils.facts.tests.collector_stub_module import StubModule

    # stub module
    module = StubModule(
        params={
            'gather_subset': 'minimum',
            'gather_timeout': 3,
            'filter': '*'
        },
        ansible_facts={},
    )

    # call
    facts = get_all_facts(module=module)

    # note: whether or not the fact is gathered is not tested. def now we can
    # just check the fact is present.

    assert facts['cidr_ipv4'] == '0.0.0.0/24'

# Generated at 2022-06-22 22:47:24.410448
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import users
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.facts.network.base import NetworkCollector
    import ansible.module_utils.facts.network.linux
    import ansible.module_utils.facts.network.bsd
    import ansible.module_utils.facts.network.aix
    import ansible.module_utils.facts.network.solaris
    import ansible.module_utils.facts.network.hpux
    import ansible.module_utils.facts.network.ios
    import ansible.module_utils.facts.network.nxos
    import ansible.module_utils.facts.network.windows
    from ansible.module_utils.facts import ansible_collector


# Generated at 2022-06-22 22:47:33.321207
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['all', ]}
    my_module = MockModule(params)
    facts_dict = get_all_facts(my_module)
    assert isinstance(facts_dict, dict)
    assert 'distribution' in facts_dict
    assert 'ansible_os_family' in facts_dict
    assert 'ansible_distribution_major_version' in facts_dict
    assert 'ansible_distribution_release' in facts_dict
    assert 'ansible_distribution_version' in facts_dict
    assert 'ansible_distribution' in facts_dict
    assert 'ansible_user_dir' in facts_dict
    assert 'ansible_selinux' in facts

# Generated at 2022-06-22 22:47:43.443933
# Unit test for function get_all_facts
def test_get_all_facts():
    ''' Test the get_all_facts function

    get_all_facts is a compatibility wrapper over the newer AnsibleModule subclass to
    allow 2.3 modules to run under 2.2 and earlier versions.  The 2.3 AnsibleModules
    have a gather_subset parameter that is used by get_all_facts.

    The compat module_utils/facts.py defines a compatibility shim for get_all_facts
    that takes the ansible_facts return value and strips out the 'ansible_' prefix

    So,  test_get_all_facts expects a dict object with keys that start with 'ansible_'
    '''

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFact

# Generated at 2022-06-22 22:47:51.498570
# Unit test for function get_all_facts
def test_get_all_facts():
    import string
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils._text import to_bytes

    for char in string.ascii_letters:
        VirtualCollector.add_fact('foo' + char, 'bar')

    vc = VirtualCollector()
    facts = vc.collect()

    for char in string.ascii_letters:
        assert facts[to_bytes('foo') + char] == 'bar'


if __name__ == '__main__':
    test_get_all_facts()

# Generated at 2022-06-22 22:47:59.781509
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.default_collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # helper to prevent annoying flake8 errors about the
    # use of the BaseFactCollector, BaseFactNamespace and PrefixFactNamespace
    # classes defined in this file, which are used as superclasses in
    # ansible.module_utils.facts.namespace/collector and ansible.module_utils.facts.default_

# Generated at 2022-06-22 22:48:11.410905
# Unit test for function ansible_facts
def test_ansible_facts():
    class TestModule:
        def __init__(self):
            self.params = dict(gather_subset=['platform'],
                               filter='*ip*',
                               gather_timeout=10)

    mod = TestModule()
    result = ansible_facts(mod)

    import os

    assert 'default_ipv4' in result
    assert 'default_ipv4' in result.keys()
    if 'default_ipv6' in result:
        assert result['default_ipv6'] == 'default'
    assert result['default_ipv4']['address'] == os.environ.get('ANSIBLE_TEST_INET_LOOPBACK', '127.0.0.1')

# Generated at 2022-06-22 22:48:17.433623
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    from ansible.module_utils.facts.system import distro as distro_collector
    from ansible.module_utils.facts.network.generic import GenericNetworkCollector
    import ansible.module_utils.facts.cache
    import ansible.module_utils.facts.system.distro

    class TestModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}


# Generated at 2022-06-22 22:48:28.274571
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import default_collectors

    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=False)

    # get_all_facts
    facts = get_all_facts(module)

    # test that there are facts, and they are all non-empty
    assert facts
    for k, v in facts.items():
        assert v

    # test that ansible_local is non-empty
    assert facts['ansible_local']
    for k, v in facts['ansible_local'].items():
        assert v

    # test that ansible_net_all_ipv4_addresses is a list


# Generated at 2022-06-22 22:48:35.912982
# Unit test for function ansible_facts
def test_ansible_facts():
    def test_ansible_module(params):
        class Module(object):
            def __init__(self, params):
                self.params = params

        return Module(params)

    module = test_ansible_module({'gather_subset': ['all'], 'gather_timeout': 10})
    f = ansible_facts(module)

    assert 'python' in f
    assert f['python']['version'] > '2.7'
    assert 'ssh' in f

# Generated at 2022-06-22 22:48:38.879825
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    # import pudb; pudb.set_trace()
    assert ansible_facts(module=dict(), gather_subset=['all']) == {}

# Generated at 2022-06-22 22:48:48.642510
# Unit test for function ansible_facts
def test_ansible_facts():
    class MockAnsibleModule():
        def __init__(self, params):
            self.params = params

    class MockCollector():
        '''Mock AnsibleCollector class'''
        def __init__(self, name):
            pass

        def collect(self, module):
            '''Return a dummy fact value'''
            return {'fact_name': 'fact_value'}

    def mock_get_ansible_collector(all_collector_classes=None, namespace=None, filter_spec=None,
                                   gather_subset=None, gather_timeout=None,
                                   minimal_gather_subset=None):
        assert gather_subset == ['all']
        assert gather_timeout == 2
        assert isinstance(namespace, PrefixFactNamespace)
        assert namespace.namespace_name

# Generated at 2022-06-22 22:48:59.273663
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.test import MockModule
    from ansible.module_utils.facts import FACT_SUBSETS
    import sys

    # create a mock AnsibleModule
    module = MockModule()

    # fake out sys.modules so facts will load
    sys.modules['ansible'] = MockModule()

    # call the function
    fact_dict = get_all_facts(module)

    # validate it returns a dictionary
    assert isinstance(fact_dict, dict)
    # validate it contains the expected number of facts
    assert len(fact_dict) > 150

    # validate it contains the expected keys (fact names)
    for subset in FACT_SUBSETS['all']:
        if subset in ['hardware']:
            continue

# Generated at 2022-06-22 22:49:07.233309
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils._text import to_text
    from .test_utils import AnsibleModuleStub
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Setup
    module_name = "test_ansible_facts"
    g_timeout = 30
    filter_spec = "*"
    # the subset will get expanded to "all"
    gather_subset = ["*"]
    params = {'gather_subset': gather_subset,
              'gather_timeout': g_timeout,
              'filter': filter_spec}
    module = AnsibleModuleStub(module_name, params=params)
    all_collector_classes = default_collectors.collectors

    # Execute


# Generated at 2022-06-22 22:49:17.533964
# Unit test for function get_all_facts
def test_get_all_facts():
    # Imports
    from ansible.module_utils import basic
    import pytest

    # Setup module
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)
    module.params['gather_subset'] = ['all']

    # Test
    facts = get_all_facts(module)

    # Asserts
    assert isinstance(facts, dict)
    assert 'ansible_all_ipv4_addresses' in facts

    # Test minimal
    module.params['gather_subset'] = ['minimal']
    minimal_facts = get_all_facts(module)
    assert len(minimal_facts) < len(facts)

    # Test subset
    module.params['gather_subset'] = ['network']
    subset_facts = get

# Generated at 2022-06-22 22:49:24.072595
# Unit test for function get_all_facts
def test_get_all_facts():

    import os
    import uuid

    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    # initialize fact collector

# Generated at 2022-06-22 22:49:27.852641
# Unit test for function get_all_facts
def test_get_all_facts():
    # Stub out the class that AnsibleModule actually expects
    class FakeAnsibleModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

        def fail_json(self, **kwargs):
            assert False

    fake_gather_subset = ['all']
    fake_module = FakeAnsibleModule(fake_gather_subset)

    # test get_all_facts
    facts = get_all_facts(fake_module)
    assert 'default_ipv4' in facts
    assert facts['default_ipv4']['address'] == '127.0.0.1'


# unit test for function ansible_facts

# Generated at 2022-06-22 22:49:36.087495
# Unit test for function get_all_facts
def test_get_all_facts():
    import json
    from ansible.module_utils._text import to_bytes

    # Unit test for function get_all_facts
    import ansible.module_utils.basic
    from ansible.module_utils.facts import get_all_facts

    # Make sure we don't blow up on old ansible.module_utils
    try:
        from ansible.module_utils.facts import default_collectors
    except ImportError:
        default_collectors = None

    # Make sure we don't blow up on old ansible.module_utils
    try:
        from ansible.module_utils.facts import ansible_collector
    except ImportError:
        ansible_collector = None

    # convert to bytes as this is what a module would get

# Generated at 2022-06-22 22:49:36.807111
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-22 22:49:46.956525
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': 'all'}

    module = FakeModule()

    facts = ansible_facts(module)
    assert isinstance(facts, dict)

    # make sure at least some facts have the right namespaces
    assert facts['ansible_lsb']['version'] == '4.4'
    assert facts['ansible_python']['version'] == '2.7'

    # make sure at least some facts are bare

# Generated at 2022-06-22 22:49:55.393992
# Unit test for function get_all_facts
def test_get_all_facts():

    class MockModule(object):
        '''used to simulate results of an AnsibleModule'''

        def __init__(self, params={}):
            self.params = params

    m = MockModule(params={'gather_subset': '!all'})
    assert get_all_facts(m) == {}

    m = MockModule(params={'gather_subset': '!fake'})
    assert get_all_facts(m) == {}

    m = MockModule(params={'gather_subset': 'all'})
    assert 'fqdn' in get_all_facts(m)



# Generated at 2022-06-22 22:50:04.943631
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.network import interfaces_ipv4


# Generated at 2022-06-22 22:50:17.184341
# Unit test for function get_all_facts
def test_get_all_facts():
    # import is here because unit test framework runs this file multiple times,
    # and therefore module import errors are not reported
    from ansible.module_utils.facts import get_all_facts

    # TODO: remove 'mock' from test requirements
    from mock import MagicMock

    module = MagicMock()
    # the gather_subset param is a 2.3 addition
    module.params = {'gather_subset': ['all']}
    facts = get_all_facts(module)
    assert facts['os_family'] == 'Linux'

    # Ensure get_all_facts is compatible with older ansible versions
    del get_all_facts
    from ansible.module_utils.facts import get_all_facts
    facts = get_all_facts(module)
    assert facts['os_family'] == 'Linux'

   

# Generated at 2022-06-22 22:50:21.625467
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Tests for get_all_facts.'''

    # Call the function under test
    # Some day we will make a real module object. Today is not that day.
    all_facts = get_all_facts(dict(gather_subset='all'))

    assert isinstance(all_facts, dict)
    assert len(all_facts) > 0



# Generated at 2022-06-22 22:50:26.273752
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils

    module = ansible.module_utils.basic.AnsibleModule(argument_spec={'gather_subset': dict(required=False, type='list', default=['all'])})
    facts = get_all_facts(module=module)
    assert 'distribution' in facts

# Generated at 2022-06-22 22:50:34.582126
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts as get_all_facts_old_api
    from ansible.module_utils.facts import get_all_facts as get_all_facts_new_api
    from mock import Mock,patch

    # First test that 2.3+ api gets a gather_subset, where 2.1-/2.2- did not.
    # Mock out the 'current' version of the facts api, call it.
    # Make sure it gets a gather_subset
    with patch('ansible.module_utils.facts.ansible_facts') as mock_get_all_facts:
        mock_module = Mock(params={'gather_subset': ['test']})
        get_all_facts_new_api(mock_module)

# Generated at 2022-06-22 22:50:43.991945
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    import json

    # get a module
    module = AnsibleModule(argument_spec={})

    # get ansible facts
    ansible_facts = ansible_facts(module, ['network'])

    # check that the dns fact is in the dict
    assert('dns' in ansible_facts)

    # check that the dns fact has at least one dns server.
    assert(len(ansible_facts['dns']['nameservers']) > 0)

    # check that the the json marshalling doesn't fail.
    json.dumps(ansible_facts)



# Generated at 2022-06-22 22:50:55.890039
# Unit test for function ansible_facts
def test_ansible_facts():
    '''mocking needs to be updated to work in Python 3'''
    raise NotImplementedError("test_ansible_facts has not been ported to Python 3")
    # pylint: disable=no-member,no-name-in-module
    from mock import patch, MagicMock
    module = MagicMock(spec_set=False)
    module.params = {'gather_subset': 'all', 'gather_timeout': 1}
    with patch('ansible.module_utils.facts.ansible_collector.get_ansible_collector', return_value=MagicMock(collect=lambda module: {'a': 'b'})):
        facts = ansible_facts(module)

    assert facts['a'] == 'b'

# Generated at 2022-06-22 22:51:07.679502
# Unit test for function get_all_facts
def test_get_all_facts():
    # mock 'ansible.plugins.action.collect' to return the following dict.
    test_facts_dict = {'network_config': 'value1', 'network_facts': 'value2'}
    # mock 'ansible.plugins.collector.get_collectors' to return the following dict.
    test_all_collectors = {'col1': ['network_config', 'network_facts'], 'col2': ['version']}

    test_module = MagicMock(params={'gather_subset': ['all'], 'gather_timeout': 10})
    test_module.get_bin_path = MagicMock(return_value='/usr/bin/python')
    test_module.get_module_path = MagicMock(return_value='/a/b/c')

# Generated at 2022-06-22 22:51:18.959747
# Unit test for function get_all_facts
def test_get_all_facts():
    '''unit test for compat api get_all_facts method'''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', elements='str', default=['!all'])})

    facts_dict = get_all_facts(module)

    # expect a dict of fact name/fact value pairs

    assert isinstance(facts_dict, dict)
    for fact_name in list(facts_dict.keys()):
        fact_value = facts_dict[fact_name]
        assert isinstance(fact_name, basestring)
        assert fact_name not in ['ansible_facts']
        assert isinstance(fact_value, ansible_collector.FactsBaseType)



# Generated at 2022-06-22 22:51:29.064688
# Unit test for function ansible_facts
def test_ansible_facts():
    class MockModule(object):
        def __init__(self, params):
            self.params = params
        def exit_json(self, **kwargs):
            pass

    # test case 1:
    # gather_subset is passed in
    # ansible_local should be filtered out (not in subset)
    module = MockModule(
        params=dict(
            gather_subset=['all'],
            gather_timeout=10,
            filter='ansible_*'
        )
    )
    facts_dict = ansible_facts(module, gather_subset=['all', 'ansible_local'])
    assert 'ansible_local' not in facts_dict

    # test case 2:
    # ansible_gather_subset is passed in
    # ansible_local should be filtered out (not in subset

# Generated at 2022-06-22 22:51:30.639327
# Unit test for function get_all_facts
def test_get_all_facts():
    # TODO: Use mock module and gather_subset
    #
    pass



# Generated at 2022-06-22 22:51:41.327043
# Unit test for function ansible_facts
def test_ansible_facts():

    class AnsibleModule:

        def __init__(self):
            self.params = dict()

    a_module = AnsibleModule()
    facts_dict = ansible_facts(a_module, gather_subset=None)
    assert isinstance(facts_dict, dict)

    a_module.params['gather_subset'] = ['all']
    a_module.params['filter'] = 'dns'

    facts_dict = ansible_facts(a_module, gather_subset=None)
    assert isinstance(facts_dict, dict)
    assert len([k for k in facts_dict.keys() if 'dns' in k]) > 0




# Generated at 2022-06-22 22:51:48.656993
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import collector

    # wrap the fact collector class in a function to support mocking
    def get_fact_collector():
        return collector.FactCollector

    try:
        from unittest.mock import Mock, patch
    except ImportError:
        from mock import Mock, patch

    a_module = Mock()
    a_module.params = {'gather_subset': ['all']}

    # test pre-2.3 ansible_facts

# Generated at 2022-06-22 22:51:58.604631
# Unit test for function get_all_facts
def test_get_all_facts():
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', required=True)})
    module.params['gather_subset'] = ['all']
    facts = get_all_facts(module)
    assert "@timestamp" in facts
    assert "ansible_os_family" in facts
    assert "ansible_distribution" in facts
    assert "ansible_machine" in facts
    assert "ansible_system" in facts
    assert "ansible_pkg_mgr" in facts
    assert "ansible_all_ipv4_addresses" in facts
    assert "ansible_all_ipv6_addresses" in facts
    assert "ansible_default_ipv4" in facts


# Generated at 2022-06-22 22:52:11.206938
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test for ansible_facts.

    Unit test for ansible_facts, which does not use an AnsibleModule
    but instead uses a dict to simulate the module parameter list.
    '''

    # import together with tests
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.network.base import NetworkCollector

    gather_subset = ['network']
    gather_timeout = 1
    filter_spec = 'ansible_eth*'

    module = {'name': 'test.py'}

    # save the network facts to restore them after the test
    saved_facts = ansible_collector.FACT_CACHE.FACTS['ansible_network_resources']


# Generated at 2022-06-22 22:52:20.995128
# Unit test for function get_all_facts
def test_get_all_facts():
    # Create a function object corresponding to the get_all_facts function
    # in this module, then create a mock object to simulate an ansible module,
    # and finally call the get_all_facts function using the mock object.
    call_function = get_all_facts
    get_all_facts_expects_module = call_function.__code__.co_varnames[0]
    mock_module = MockAnsibleModule(get_all_facts_expects_module)
    facts = call_function(mock_module)
    assert isinstance(facts, dict)
    # Check for a few facts for sanity
    assert 'default_ipv4' in facts
    assert facts['default_ipv4']
    assert 'machine' in facts
    assert facts['machine']


# Generated at 2022-06-22 22:52:32.895012
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    #from ansible.module_utils.facts import network_collectors

    # gather all facts
    fact_subset = ['all']
    gather_subset = fact_subset
    gather_timeout = 10
    filter_spec = '*'


# Generated at 2022-06-22 22:52:43.673527
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import collected_facts
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.kernel as kernel

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = {
                'gather_subset': [],
                'gather_timeout': 5,
                'filter': '*',
            }
            self.params.update(kwargs)

    fake_module = FakeModule()
    facts_dict = ansible_facts(fake_module)
    assert isinstance(facts_dict, dict)
    assert 'distribution' in facts_dict
    assert 'distribution_release' in facts_dict
    assert 'kernel' in facts_dict

# Generated at 2022-06-22 22:52:54.383832
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    class FakeMgr:
        def __init__(self):
            self.module = FakeModule()

    class FakeCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'a': 1}

    class FakeFactFinder:
        def __init__(self):
            self.collectors = [FakeCollector]
            self.namespace = Namespace()

    module = FakeModule()
    mgr = FakeMgr()


# Generated at 2022-06-22 22:53:05.204070
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_text

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'distribution',
                                       'env', 'lsb', 'pkg_mgr', 'platform', 'python',
                                       'selinux', 'service_mgr', 'ssh_pub_keys', 'user'])

    all_collector_classes = default_collectors.collectors

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-22 22:53:15.559550
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {'filter': '*'}

    mock_module = MockAnsibleModule()

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    # ansible_collector.get_ansible_collector should return an instance of a subclass of
    # AnsibleCollector

# Generated at 2022-06-22 22:53:26.031620
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes

    import os
    import json
    import mock
    import pytest

    ###############################################
    # mock module
    ###############################################
    class MockAnsibleModule:
        def __init__(self, **kwargs):
            self.params = kwargs

    ###############################################
    # mock utils
    ###############################################
    class MockUtil:
        @staticmethod
        def is_executable(path):
            if path.endswith('is_executable.py'):
                return True
           