

# Generated at 2022-06-22 22:43:25.821238
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector

    # Create a mock class for testing
    class MockModule:
        def __init__(self, params):
            self.params = params

    # Provide a fake_ansible_facts_dict to compare against the dict
    # that is returned from the real ansible_facts method
    fake_ansible_facts_dict = {
        'a': 'A',
        'b': 'B',
        'c_c': 'C_C',
        'd': {'da': 'DA',
              'dc_dc': 'DC_DC'}
    }

    # Create a new class that wraps a dict with the methods necessary for
    # testing the ansible_facts method

# Generated at 2022-06-22 22:43:28.503624
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''
    from ansible.module_utils.facts import _get_all_facts
    _get_all_facts()



# Generated at 2022-06-22 22:43:35.668399
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.gather import BaseFactCollector
    class MyGroup(BaseFactCollector):
        name = 'mygroup'
        _fact_ids = ['fact0', 'fact1', 'fact2']

    class MyFactsCollector(BaseFactCollector):
        name = 'myfacts'
        _fact_ids = ['fact3', 'fact4', 'fact5']

    class AnsibleModule:
        def __init__(self, params=None):
            self._params = params or {}

        def params(self):
            return self._params

    t = AnsibleModule({'gather_subset': ['all']})
    get_all_facts(t)
    assert t.params()['_ansible_facts']


# Generated at 2022-06-22 22:43:44.521715
# Unit test for function ansible_facts
def test_ansible_facts():

    class MockAnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': ['!all', 'network'], 'gather_timeout': 2.5, 'filter': 'ansible_*'}

    module = MockAnsibleModule()
    fact_dict = ansible_facts(module)

    # Make sure we got some expected keys from the ansible fact namespace
    fact_keys = fact_dict.keys()
    assert 'default_ipv4' in fact_keys
    assert 'default_ipv6' in fact_keys

    # change gather_subset, make sure we get different keys (from network fact namespace)
    module.params['gather_subset'] = ['network']
    fact_dict = ansible_facts(module)
    fact_keys = fact_dict.keys

# Generated at 2022-06-22 22:43:54.043739
# Unit test for function ansible_facts
def test_ansible_facts():
    # ansible_facts is going to call get_all_facts
    # so need to mock that out to prevent error.
    import mock
    import types

    # mock out the get_all_facts method
    fixture = types.ModuleType('ansible.module_utils.facts')
    mock.patch.object(fixture, 'get_all_facts', return_value=True).start()

    # import AnsibleModule from the original module_utils/facts.py
    from ansible.module_utils.facts import AnsibleModule

    # create an instance of AnsibleModule

# Generated at 2022-06-22 22:44:01.615186
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # Mock an AnsibleModule
    mock_module = AnsibleModuleStub()
    # mock module params
    mock_module.params = dict(collect_all=True, gather_subset=['all'], gather_timeout=10, filter='*')

    # patch gather_subset to always return ['all']
    mock_module.gather_subset = lambda: ['all']

    all_collector_classes = default_collectors.collectors
    # don't prefix the fact names when collecting
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    fact_collector

# Generated at 2022-06-22 22:44:13.038588
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts

    def _get_all_facts(module):
        import os
        import platform
        import socket
        import sys

        facts = dict()
        facts['distribution'] = platform.dist()[0]
        facts['distribution_version'] = platform.dist()[1].split('.')[0]
        facts['distribution_release'] = platform.dist()[1]
        facts['distribution_major_version'] = int(facts['distribution_version'])
        facts['machine'] = platform.machine()
        facts['kernel'] = platform.system()
        if facts['kernel'] == 'Linux':
            dpkg = distro_defaults.get('LSB_DPKG_QUERY', ['dpkg', '-s'])
            rpm = distro_

# Generated at 2022-06-22 22:44:22.907900
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import collector

    class FakeCollector(collector.BaseFactCollector):
        _fact_ids = frozenset(['bare_fact_name'])

        def collect(self, module=None, collected_facts=None):
            return {'bare_fact_name': 'ansible value'}

    # Create a fake ansible module class
    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': frozenset(['all']),
                           'gather_timeout': 0,
                           'filter': '*'}

    # Create a fake AnsibleModule.
    module = FakeModule()

    # Create a FakeCollector and add it to default_collectors

# Generated at 2022-06-22 22:44:33.484850
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.facts import AnsibleModuleMock
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    import json

    module = AnsibleModuleMock(dict(
        gather_subset=['all']
    ))

    facts_dict = ansible_facts(module)

    assert facts_dict['distribution'] == 'RedHat'
    assert facts_dict['network']['default_ipv4']['address'] == '1.1.1.1'

    facts_dict = ansible_facts(module, gather_subset=['!min'])
    assert facts_dict['os_family'] == 'RedHat'

# Generated at 2022-06-22 22:44:39.663275
# Unit test for function get_all_facts
def test_get_all_facts():
    """Test function get_all_facts

    :return:
    """
    test_facts = get_all_facts(None)
    print(test_facts)
    assert test_facts.has_key('distribution')
    assert test_facts.has_key('distribution_version')
    assert test_facts.has_key('fqdn')
    assert test_facts.has_key('uptime_seconds')

# Run the function test if this script is called directly.
if __name__ == '__main__':
    test_get_all_facts()

# Generated at 2022-06-22 22:44:45.100856
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict(
        gather_subset=[],
    )

    mod = AnsibleModule(
        argument_spec=module_args,
    )

    gathered_facts = get_all_facts(mod)
    assert isinstance(gathered_facts, dict)


# Generated at 2022-06-22 22:44:52.284104
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import unittest

    if sys.version_info.major < 3:
        import mock
    else:
        from unittest import mock
    from ansible.module_utils.facts import default_collectors

    gathered_facts = [{'fact1': 101}, {'fact2': 202}, {'fact3': 303}, {'fact4': 404}]

    module_params = {'gather_timeout': 5,
                     'filter': '*',
                     'gather_subset': ['!all', 'network', 'virtual']}

    # The facts.network module mocks the fact_collector.collect function, to return the facts
    # defined in the list above, rather than calling all of the fact collectors
    network_mock = mock.MagicMock(spec=default_collectors.NetworkCollector)

   

# Generated at 2022-06-22 22:45:00.382924
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''
    try:
        from ansible.module_utils.facts.namespace import PrefixFactNamespace
        from ansible.module_utils.facts import default_collectors
        from ansible.module_utils.facts import ansible_collector
    except ImportError:
        print("failed=True msg=Can't import from module_utils/facts")
        sys.exit(1)
    module = DummyModule()
    get_all_fact = get_all_facts(module)
    assert(get_all_fact['distribution'] == 'Ubuntu')


# Generated at 2022-06-22 22:45:05.543942
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    fake_module = AnsibleModule({'gather_subset': ['all']})
    facts = ansible_facts(fake_module)

    assert facts is not None
    assert type(facts) == dict
    assert len(facts) > 0

# Generated at 2022-06-22 22:45:09.177036
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.gather

    # assert that the function is truthy
    assert ansible_facts
    # assert that calling it returns a dict
    assert isinstance(ansible_facts(ansible.module_utils.facts.gather.AnsibleModule({})), dict)

# Generated at 2022-06-22 22:45:21.668283
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.facts.network
    module = AnsibleModule({'gather_subset': 'all'})
    facts = get_all_facts(module)
    assert module.params['gather_subset'] == 'all'

# Generated at 2022-06-22 22:45:30.187153
# Unit test for function get_all_facts
def test_get_all_facts():
    module_mock = Mock()
    module_mock.params = {'gather_subset': ['all']}
    result = get_all_facts(module_mock)
    # should return a dict
    assert isinstance(result, dict)
    # result should have an 'ansible_facts' key.
    assert 'ansible_facts' in result
    # ansible_facts should map to a dict
    assert isinstance(result['ansible_facts'], dict)

if __name__ == '__main__':
    from ansible.module_utils.facts import ansible_collector
    ansible_collector
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 22:45:33.103258
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={})
    facts = ansible_facts(module)
    assert 'distribution' in facts
    assert 'distribution_version' in facts
    assert 'distribution_major_version' in facts

# Generated at 2022-06-22 22:45:35.260391
# Unit test for function ansible_facts
def test_ansible_facts():
    print("test_ansible_facts")
    print(ansible_facts(module))

# Generated at 2022-06-22 22:45:45.349583
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.lsb

    ansible_collector = ansible.module_utils.facts.collector.AnsibleCollector
    distro = ansible.module_utils.facts.system.distribution.Distribution
    lsb = ansible.module_utils.facts.system.lsb.Lsb

    all_collector_classes = {
        'distribution': distro,
        'lsb': lsb,
    }
    namespace_name = 'ansible'
    namespace_prefix = 'ansible_'

# Generated at 2022-06-22 22:45:57.012822
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import BaseFactNamespace, PrefixFactNamespace
    from ansible.module_utils.facts.ansible_collector import AnsibleCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all', '!min'], type='list')})

    assert get_all_facts(test_module) == ansible_facts(test_module)
    assert isinstance(get_all_facts(test_module), dict)
    assert isinstance(ansible_facts(test_module), dict)


# Generated at 2022-06-22 22:46:02.514199
# Unit test for function ansible_facts
def test_ansible_facts():

    module_mock = Mock()
    module_mock.params = dict()
    module_mock.params['gather_subset'] = None
    module_mock.params['gather_timeout'] = 10

    ansible_facts_dict = ansible_facts(module_mock)

    assert type(ansible_facts_dict) == dict
    assert len(ansible_facts_dict) > 0
    assert type(ansible_facts_dict['default_ipv4']) == dict
    assert len(ansible_facts_dict['default_ipv4']) == 1
    assert type(ansible_facts_dict['default_ipv4']['address']) == str

# Generated at 2022-06-22 22:46:13.237066
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        from ansible.module_utils.facts.module_utils.module_facts_utils import get_all_facts
    except ImportError:
        # ansible 2.3/2.4 import is different
        from ansible.module_utils.facts.module_utils.module_facts_utils import get_all_facts
    # compat interfaces to test
    from ansible.module_utils.basic import AnsibleModule

    # make a module to pass in
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list')})

    # run against our compat module
    got = get_all_facts(module)

    # todo: make a test that checks the actual results.


# Generated at 2022-06-22 22:46:20.837105
# Unit test for function ansible_facts
def test_ansible_facts():
    class MockModule(object):
        def __init__(self):
            self.fail_json = lambda **kwargs: None
            self.params = {'gather_timeout': 3,
                           'filter': '*',
                           'gather_subset': ['all']}

    import mock
    from ansible.module_utils.facts import timed_subset_function

    module = MockModule()

    with mock.patch('ansible.module_utils.facts.timed_subset_function') as mock_timed_function:
        mock_timed_function.return_value = None
        result = ansible_facts(module, gather_subset=module.params['gather_subset'])
        assert mock_timed_function.call_count == 1

        function = mock_timed_function.call_args

# Generated at 2022-06-22 22:46:30.371953
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''
    # create a mock ansible module, mock_params holds the params
    class Mock_AnsibleModule:
        def __init__(self, params):
            self.params = params
    # create a mock ansible module, mock_results holds the results, and mock_results.ansible_facts
    # is a mock facts dict
    class Mock_AnsibleModule_Results:
        def __init__(self, results_dict):
            self.ansible_facts = results_dict
    # create a mock ansible module for in the function under test
    module = Mock_AnsibleModule(params={'gather_subset': ['all'], 'gather_timeout': 10,
                                        'filter': '*'})
    # create a mock results dict

# Generated at 2022-06-22 22:46:37.676493
# Unit test for function get_all_facts
def test_get_all_facts():
    # Mock module obj
    module = Mock()
    module.params = {'gather_subset': 'all'}

    mock_ansible_facts = {u'fact1': 'value1', u'fact2': 'value2'}

    # Mock the ansible_facts() to return mock_ansible_facts
    @patch('ansible.module_utils.facts.ansible_facts')
    def mock_ansible_facts_function(module):
        return mock_ansible_facts

    ansible_facts.side_effect = mock_ansible_facts_function

    facts_dict = get_all_facts(module)
    # Assert mock_ansible_facts is returned
    assert facts_dict == mock_ansible_facts


# Generated at 2022-06-22 22:46:42.517081
# Unit test for function get_all_facts
def test_get_all_facts():

    import collections
    import json
    import sys

    import ansible.module_utils.facts as a_facts

    class FakeModule:

        def __init__(self, gather_subset=None, gather_timeout=None, filter=None):
            self.params = collections.defaultdict(lambda: None)
            self.params.update(gather_subset=gather_subset, gather_timeout=gather_timeout, filter=filter)

    class MockAnsibleModule:
        pass

    for gather_subset in [[], ['all'], ['network'], ['hardware']]:
        for gather_timeout in range(1, 15):
            for filter_spec in ['*', 'ansible_*', '!ansible_*', 'ansible_mounts', 'ansible_mounts*']:
                module = FakeModule

# Generated at 2022-06-22 22:46:47.879844
# Unit test for function ansible_facts
def test_ansible_facts():
    test_params = dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*'
    )
    fake_module = FakeAnsibleModule(test_params)
    facts_dict = ansible_facts(fake_module)
    assert facts_dict['test_fact'] == 'test_value'
    assert facts_dict['test_fact2'] == 'test_value2'
    assert facts_dict['test_fact3'] == 'test_value3'


# Generated at 2022-06-22 22:46:56.967374
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest

    # these are imports to test the import statement
    # in the module
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import namespace

    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.ansible_release import __version__ as ansible_version

    def test_ansible_facts_functions_import():
        pass

# Generated at 2022-06-22 22:46:58.872325
# Unit test for function ansible_facts
def test_ansible_facts():
    pass


# Generated at 2022-06-22 22:47:09.789498
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector

    class MockModule:
        def __init__(self, gather_subset=[], filter_spec='*', gather_timeout=10):
            self.params = {}
            self.params['gather_subset'] = gather_subset
            self.params['filter'] = filter_spec
            self.params['gather_timeout'] = gather_timeout

    mock_module = MockModule(gather_subset=['network'])

    facts_dict = ansible_facts(mock_module)

    assert type(facts_dict) == dict
    # check to see if interface's ipv4 facts exist
    assert 'default_ipv4' in facts_dict
    assert 'interfaces' in facts_dict

# Generated at 2022-06-22 22:47:21.507246
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import core as facts_core

    default_collectors.default_collectors = default_collectors.default_collectors
    default_collectors.all_collectors = default_collectors.default_collectors

    class FakeAnsibleModule:
        params = dict(
            gather_subset=None,
            gather_timeout=10, )

        class FakeModuleExit:
            def __init__(self, module):
                pass

            def __call__(self, **kwargs):
                pass

        exit_json = FakeModuleExit(module=None)
        fail_json = FakeModuleExit(module=None)

    fake_ansible_module = FakeAnsibleModule()
    filter_spec = 'a*'

# Generated at 2022-06-22 22:47:27.552279
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.ansible_collector
    import ansible.module_utils.facts.default_collectors
    import ansible.module_utils.facts.processor
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.utils


if __name__ == '__main__':
    test_get_all_facts()

# Generated at 2022-06-22 22:47:31.932481
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts

    :return:
    '''
    module = MockAnsibleModule()
    result = ansible_facts(module=module)
    assert result == { 'distribution': 'ubuntu' }



# Generated at 2022-06-22 22:47:42.709579
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Fake up a module and test the ansible_facts function'''

    # For this test, only test the platform collector, and assert that all the
    # facts are populated, and that they have the correct default value of
    # 'unknown'
    class TestModule():
        def __init__(self):
            self.params = dict(gather_subset=['platform'],
                               gather_timeout=1,
                               filter='*')

    test_facts = \
        ansible_facts(module=TestModule())

    platform_collector = default_collectors.get_platform_collector()
    for fact in platform_collector.FACTS:
        fact_name = fact['fact_name']
        assert test_facts[fact_name] == 'unknown'

# Generated at 2022-06-22 22:47:53.854197
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.six import PY3
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.hardware.base import HardwareCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    if PY3:
        from importlib import reload
    else:
        from imp import reload
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(gather_subset=dict(type='list'), gather_timeout=dict(type='int')))

    ##########################
    # Full Fact Collection
    ##########################

# Generated at 2022-06-22 22:48:06.167606
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import timeout
    import ansible.module_utils.facts.namespace

    class ModuleDouble(object):
        # stub out the bare minimum to run get_all_facts()
        def __init__(self, params):
            self.params = params

    # test with valid gather_subset
    params = dict(gather_subset=['default'])
    module = ModuleDouble(params)
    facts = get_all_facts(module)

    # test with invalid gather_subset
    params = dict(gather_subset=9999)
    module = ModuleDouble(params)
    facts = get_all_facts(module)
    assert facts == {}, 'gather_subset=9999 should return empty dict of facts'

    # test with gather

# Generated at 2022-06-22 22:48:14.114283
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import get_distribution

    DUMMY_DISTRIBUTION = 'dummy_distro'
    DUMMY_LSB_RELEASE_CONTENT = '''
DISTRIB_ID=%s
DISTRIB_RELEASE=101
DISTRIB_CODENAME=minty
DISTRIB_DESCRIPTION="Ubuntu 17.10"
''' % DUMMY_DISTRIBUTION

    def fake_get_distribution(module):
        return DUMMY_DISTRIBUTION, '101'

    def fake_open(path, mode):
        return StringIO.StringIO(DUMMY_LSB_RELEASE_CONTENT)

    import StringIO
    import os

    # Replace this system call with a

# Generated at 2022-06-22 22:48:26.377020
# Unit test for function get_all_facts
def test_get_all_facts():
    import unittest
    from ansible.module_utils.basic import AnsibleModule

    class AnsibleModuleMock(object):
        class _module(object):
            params = {
                'gather_subset': '!all'
            }

        def __init__(self, *args, **kwargs):
            self._module = self._module()
            self.params = self._module.params

    def setup_module():
        return AnsibleModuleMock()

    class TestModuleUtilsFactsGetAllFacts(unittest.TestCase):

        def test_get_all_facts(self):
            module = setup_module()
            self.assertEqual(get_all_facts(module), ansible_facts(module))

    unittest.main()

# The following code is to assert that the above function

# Generated at 2022-06-22 22:48:30.195795
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={
        'gather_subset': dict(type='list', default=['all']),
        'filter': dict(type='str', default='*'),
    })

    print(ansible_facts(module))
    print(get_all_facts(module))

# Generated at 2022-06-22 22:48:42.572061
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import imp
    module_name = 'test_ansible_module_utils_facts'
    module_path = __file__.rstrip('.py') + '_test.py'
    fake_module = imp.load_source(module_name, module_path)

    assert fake_module.params['gather_subset'] == ['!all', 'network']
    assert fake_module.ANSIBLE_VERSION == '2.4.4.0'

    fake_module.params['gather_subset'] = ['all']
    fake_module.params['filter'] = 'ansible_os_family'

    facts = get_all_facts(module=fake_module)

    assert isinstance(facts, dict)

# Generated at 2022-06-22 22:48:54.507922
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import FactsNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector, get_collector_class

    class TestFact(FactsNamespace):
        def __init__(self, name, version, version_string, release_string):
            self.name = name
            self.version = version
            self.version_string = version_string
            self.release_string = release_string

    class TestFactCollector(BaseFactCollector):
        name = 'lucky'
        _fact_class = TestFact
        _platform = 'linux'

        def collect(self, module=None):
            return self._fact_class(name=self.name, version=1, version_string='2', release_string='3')


# Generated at 2022-06-22 22:49:03.068452
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test code for function ansible_facts, using the mock module.

    Using mocks here, since the module_utils.facts functions are quite brittle, and
    hard to unit test.
    Instead, we can just make sure that the input args are passed through to the
    ansible_collector.get_ansible_collector function.
    '''

    import sys
    import os
    import mock

    # We need to mock the module_utils.facts.ansible_collector.get_ansible_collector() function,
    # so that we can control the return value.
    #
    # Since this function is part of the module_utils.facts.ansible_collector module, it is not
    # available as a global in the scope of this test file.
    # But we can fake it, by importing a temporary copy of the ansible

# Generated at 2022-06-22 22:49:13.635602
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_all_facts_if_possible
    import ansible.module_utils.facts.system.distribution as distribution

    class MockModule(object):
        params = {}

    mock_module = MockModule()

    # baseline test with filter_spec=* and gather_subset=['all']
    mock_module.params = {
        'filter': '*',
        'gather_subset': ['all']
    }
    facts = ansible_facts(mock_module)
    distro_keys = set(distribution.LinuxDistribution().__dict__.keys()).union(
        set(distribution.BaseLinuxDistribution().__dict__.keys()))

    # all facts keys in LinuxDistribution should be in the facts return

# Generated at 2022-06-22 22:49:22.515141
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.modules.system import setup
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes

    # Create a mock module object
    class MockModule(object):

        def __init__(self, var_name, var_value=None):
            self._name = to_bytes(var_name, errors='surrogate_or_strict')
            self._args = None
            self._result = dict()
            self._ansible_facts = dict()
            self._ansible_version = (1, 9, 1, 'final', 1)

            if var_value:
                self._ansible_facts = var_value

            self.params = dict()

        def exit_json(self, **kwargs):
            self._result = kwargs
           

# Generated at 2022-06-22 22:49:33.934803
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    This unit test does not actually run any of the fact collectors
    It just tests that the ansible_facts method will return a dict

    TODO: we should actually test that the method returns the expected keys in the dict,
    with the expected values.
    '''

    class AnsibleModuleFake(object):
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['all']}
    fake_ansible_module = AnsibleModuleFake(params=params)

    facts_dict = ansible_facts(module=fake_ansible_module)

    assert isinstance(facts_dict, dict)



# Generated at 2022-06-22 22:49:44.873688
# Unit test for function get_all_facts
def test_get_all_facts():

    class FakeAnsibleModule(object):
        def __init__(self, params):
            self.params = params

    # Just test that the correct method gets called, don't test the facts gathering logic
    class FakeAnsibleFacts(object):

        def __init__(self, params):
            self.params = params
            self.expected_result = params['gather_subset']
            self.result = None

        def ansible_facts(self, filter_spec, gather_subset, gather_timeout):

            assert filter_spec == '*'
            assert gather_subset == self.expected_result
            assert gather_timeout == 10
            self.result = True
            return None

    # Just test that the correct method gets called, don't test the facts gathering logic

# Generated at 2022-06-22 22:49:52.269720
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    This function is checked in to get code coverage of the function so that
    we can verify that we have 100% code coverage of the ansible_facts function
    in the unit tests.
    '''
    import ansible.module_utils.facts.dummy_module
    module = ansible.module_utils.facts.dummy_module.DummyModule()
    ansible_facts(module)
    ansible_facts(module, gather_subset=['all'])
    ansible_facts(module, gather_subset=['all', 'network'])



# Generated at 2022-06-22 22:50:02.767827
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts.facts import F_EMPTY_COLLECTION, F_SUB_COLLECTION

    class ModuleClass(object):
        '''AnsibleModule compatibility class

        facts module uses self.params attribute
        to access module params.
        This is a helper class to mock an AnsibleModule'''

        def __init__(self, params):
            self.params = params

    module = ModuleClass(params={'gather_subset': ['all']})

    fact_dict = ansible_facts(module)

    # facts_dict should be a dict with top level facts
    assert isinstance(fact_dict, dict)

    for (fact_name, fact_value) in fact_dict.items():
        assert isinstance(fact_name, str)

        # Fact value should be a dict which can map

# Generated at 2022-06-22 22:50:06.448638
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'])
        )
    )

    # this should not raise an error
    get_all_facts(mod)


# Generated at 2022-06-22 22:50:09.154279
# Unit test for function get_all_facts
def test_get_all_facts():

    class _AnsibleModule(object):
        def __init__(self, params):
            self.params = params

    module = _AnsibleModule({'gather_subset': ['network']})

    assert get_all_facts(module)



# Generated at 2022-06-22 22:50:20.655636
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    ansible_facts() unit test
    '''

    try:
        # pylint: disable=import-error
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        # ansible 2.0/2.1
        from ansible.module_utils.basic import *     # pylint: disable=wildcard-import,redefined-builtin,unused-wildcard-import

    # pylint: disable=missing-docstring, no-self-use, invalid-name
    class TestAnsibleModule(object): # pylint: disable=too-few-public-methods
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-22 22:50:28.608512
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    class StubModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(StubModule, self).__init__(*args, **kwargs)
            self.params = {
                'gather_subset': ['all'],
            }

    ansible_module = StubModule(argument_spec={})

    # nothing is mocked out, so this will fail without a network connection at least
    gathered_facts = get_all_facts(ansible_module)

    assert isinstance(gathered_facts, dict)

# Generated at 2022-06-22 22:50:35.549283
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.collector

    ansible.module_utils.facts.utils.yum.YUMDNFRepoFacts.collect = lambda self: {'ansible_facts': {'local_repos': {'yumrepo': 'yum_repo_value'}}}
    ansible.module_utils.facts.system.PlatformFacts.collect = lambda self: {'ansible_facts': {'platform': 'platform_value'}}
    ansible.module_utils.facts.system.DistributionFacts.collect = lambda self: {'ansible_facts': {'system_distribution': 'system_distribution_value'}}

# Generated at 2022-06-22 22:50:36.005539
# Unit test for function get_all_facts
def test_get_all_facts():
    # TODO write this!
    assert 1 == 1

# Generated at 2022-06-22 22:50:45.467948
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts import default_collectors

    collectors = default_collectors.collectors

    class FakeAnsibleModule():
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, opts=None, required=False):
            return ''

    # Test with gather_subset=['all']
    module = FakeAnsibleModule(params={'gather_subset': ['all']})

    assert len(ansible_facts(module=module)) > 0

    # Test with gather_subset=['!all']
    module = FakeAnsibleModule(params={'gather_subset': ['!all']})

    assert len(ansible_facts(module=module)) == 0

# Generated at 2022-06-22 22:50:56.552555
# Unit test for function ansible_facts
def test_ansible_facts():
    gather_timeout = 10
    gather_subset = ['all']
    filter_spec = '*'
    all_collector_classes = default_collectors.collectors
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    fact_collector = ansible_collector.get_ansible_collector(all_collector_classes=all_collector_classes,
                                                             namespace=namespace,
                                                             filter_spec=filter_spec,
                                                             gather_subset=gather_subset,
                                                             gather_timeout=gather_timeout,
                                                             minimal_gather_subset=None)

    assert fact_collector

# Generated at 2022-06-22 22:51:08.373043
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils._text import to_bytes
    import sys
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def __init__(self, gather_subset, gather_timeout, filter_spec):
            self.params = dict()
            self.params['gather_subset'] = gather_subset
            self.params['gather_timeout'] = gather_timeout
            self.params['filter'] = filter_spec


# Generated at 2022-06-22 22:51:17.283843
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.ansible_collector import AnsibleCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

    # gather_subset should default to configured DEFAULT_GATHER_SUBSET
    module = MockModule()
    assert ansible_facts(module=module)

    # gather_subset should default to ['all'] if not configured
    AnsibleCollector.DEFAULT_GATHER_SUBSET = None
    assert ansible_facts(module=module)

# Generated at 2022-06-22 22:51:24.000472
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeAnsibleModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    module = FakeAnsibleModule(['network'])
    facts_dict = get_all_facts(module)
    assert facts_dict is not None
    assert 'interfaces' in facts_dict
    assert 'default_ipv4' in facts_dict


# Generated at 2022-06-22 22:51:32.737928
# Unit test for function get_all_facts
def test_get_all_facts():
    import os
    import tempfile
    import yaml

    class TestModule(object):
        def __init__(self, inventory_hostname='test.example.com', params={}):
            self.params = params
            self.params['inventory_hostname'] = inventory_hostname

    class FakeAnsibleModule(object):
        def __init__(self, module_args={}):
            self.params = module_args
            self.exit_json = lambda x: x

    # Use a tempfile for the cache file to avoid polluting the root directory.
    cache_file = tempfile.NamedTemporaryFile(delete=False)
    cache_file.close()

    inventory_hostname = 'test.example.com'
    gather_subset = ['all']


# Generated at 2022-06-22 22:51:44.276693
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    from ansible.module_utils.facts.service_mgr import ServiceMgrCollector
    from ansible.module_utils.facts.system.distribution import DistributionCollector

    filters = 'network,system,distribution,virtualization'
    class MockModule:

        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)

    # test when gather_subset=None
    module = MockModule(gather_subset=None)
    module.params['gather_subset'] = None
    module.params['filter'] = filters

# Generated at 2022-06-22 22:51:55.060826
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import utils

    default_ipv4 = utils.get_default_ipv4()
    if not isinstance(default_ipv4, dict) or len(default_ipv4) != 1:
        print("expected ansible_default_ipv4 to be a dictionary with 1 key/value pair")

    default_ipv4_fact = default_ipv4['default_ipv4']
    if not isinstance(default_ipv4_fact, dict) or len(default_ipv4_fact) != 3:
        print("expected ansible_default_ipv4 to have 3 key/value pairs")

    default_ipv4_fact_addr = default_ipv4_fact['address']

# Generated at 2022-06-22 22:52:02.941397
# Unit test for function get_all_facts
def test_get_all_facts():
    module = AnsibleModule()
    module.params['gather_subset'] = ('all',)

    fact_dict = get_all_facts(module)

    assert fact_dict['default_ipv4']['address'] == '192.168.0.2'
    assert fact_dict['default_ipv4']['network'] == '192.168.0.0'
    assert fact_dict['default_ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-22 22:52:11.065626
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.default_collectors import Collectors
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.ansible_collector import AnsibleCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceCollection
    from ansible.module_utils.facts.utils import to_text
    import sys

    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = None

    # test with a module FakeModule that is missing some params from params,
    # and also has an incompatible type for some params
   

# Generated at 2022-06-22 22:52:17.638383
# Unit test for function get_all_facts
def test_get_all_facts():

    class MockModule():
        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)

    module = MockModule(gather_subset='all')
    facts = get_all_facts(module)

    assert facts['distribution']
    assert facts['distribution_version']
    assert facts['distribution_major_version']
    assert facts['python']['version']

# Generated at 2022-06-22 22:52:28.932739
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.basic import AnsibleModule
    import pytest

    module = AnsibleModule(argument_spec={})
    facts_dict = get_all_facts(module)

    # Can't guarantee the system we run on has certain facts -
    # so just test a few facts we expect to be present
    # We can add additional tests as we think of other facts that
    # are worth testing for
    assert 'default_ipv4' in facts_dict, "Expected 'default_ipv4' to be in ansible facts dict"
    assert 'default_ipv4' in facts_dict['ansible_facts'], "Expected 'default_ipv4' to be in ansible_facts dict"

# Generated at 2022-06-22 22:52:33.635916
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    params = {'filter': '*'}
    module = AnsibleModule(argument_spec={'filter': dict(default='*', type='raw')},
                           supports_check_mode=False)

    module.params = params
    # sanity check the test
    assert 'ansible_eth0' in ansible_facts(module)

# Generated at 2022-06-22 22:52:39.326269
# Unit test for function get_all_facts
def test_get_all_facts():
    test_cases = [{'gather_subset': ['network']}]
    
    for gather_subset in test_cases:
        result = get_all_facts(gather_subset)
        for key in gather_subset.keys():
            assert key in result
        

# Generated at 2022-06-22 22:52:39.822577
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-22 22:52:44.979297
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils import basic

    mymodule = basic.AnsibleModule(argument_spec={'gather_subset': {'default': ['all']}})
    all_facts = get_all_facts(mymodule)
    assert 'default_ipv4' in all_facts

# Generated at 2022-06-22 22:52:55.549176
# Unit test for function ansible_facts
def test_ansible_facts():
    # A unit test that depends on a real module is not that useful
    import sys
    import unittest

    class TestModule(object):
        def __init__(self):
            self.params = dict()

    class AnsibleModule(object):
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, executable, required=True, opt_dirs=[]):
            for path in sys.path:
                if path.endswith('module_utils'):
                    if os.path.exists(os.path.join(path, executable)):
                        return os.path.join(path, executable)

    class AnsibleModule_ansible23(AnsibleModule):
        def __init__(self):
            super(AnsibleModule_ansible23, self).__init

# Generated at 2022-06-22 22:53:00.372283
# Unit test for function get_all_facts
def test_get_all_facts():
    module = MockModule({'gather_subset': ['all']})
    facts = get_all_facts(module)
    assert facts['fips'] == 'True'
    assert facts['local']['localhost']['localhostname'] == 'localhost'



# Generated at 2022-06-22 22:53:09.880674
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic

    # I know this is bad form to import a module you are testing, but
    #  I'd rather do it this way than mock the module import.
    #  I *think* I'd have to mock __import__ and the lookup of module.params
    #  and other stuff.
    from ansible.module_utils.facts import facts

    # Test function
    def test_function(module):
        return dict(ansible_facts=get_all_facts(module))

    # Test data
    module_args = dict(
        gather_subset='!all,foo'
    )

# Generated at 2022-06-22 22:53:14.573779
# Unit test for function get_all_facts
def test_get_all_facts():
    m = MockAnsibleModule()
    facts = get_all_facts(m)
    assert 'default_ipv4' not in facts
    assert 'default_ipv4.address' in facts
    assert 'default_ipv4.interface' in facts
    assert 'default_ipv4.gateway' in facts



# Generated at 2022-06-22 22:53:25.186492
# Unit test for function get_all_facts
def test_get_all_facts():
    import json
    import sys
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils._text import to_bytes

    # Simulate an AnsibleModule with gather_subset=['all']
    class AnsibleModule:
        def __init__(self):
            self.params = dict()

        def fail_json(self, kwargs):
            print('FAILED: ' + json.dumps(kwargs, indent=4))
            sys.exit(1)

    module = AnsibleModule()