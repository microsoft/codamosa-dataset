

# Generated at 2022-06-22 22:43:29.190870
# Unit test for function get_all_facts
def test_get_all_facts():
    # mock module
    class module(object):
        class AnsibleModule(object):
            def __init__(self, argspec, **kwargs):
                self.params = dict()

                # unique to this unit test
                self.params['gather_subset'] = 'filter_spec'
                self.params['gather_timeout'] = 'gather_timeout'
                self.params['filter'] = 'filter'

        def __init__(self, argspec, **kwargs):
            self.module = self.AnsibleModule(argspec, **kwargs)

    # mock ansible_facts, which calls ansible_collector

# Generated at 2022-06-22 22:43:35.155544
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule:
        params = dict(
            gather_subset=['all'],
            gather_timeout=10,
            filter='*',
        )
    module = FakeModule()
    facts = get_all_facts(module)
    assert isinstance(facts, dict), 'get_all_facts should return a dict'
    assert facts['system'] == 'Linux', 'Facts should contain a system key'

# Generated at 2022-06-22 22:43:47.306941
# Unit test for function ansible_facts
def test_ansible_facts():

    import os
    os.system('mkdir -p /tmp/testfacts/')
    os.system('touch /tmp/testfacts/facts.txt')
    os.system('cp -f /etc/ansible/facts.d/testfacts.fact /tmp/testfacts/testfacts.fact')

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import default_collectors

    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'all'}

        def set_fact(self, key, value):
            pass

        def fail_json(self, msg):
            pass

    test_module = MockModule()
    fake

# Generated at 2022-06-22 22:43:57.396965
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts

    module = MagicMock()

    # Test gather_subset=None; use the module's default
    module.params = {'gather_subset': None}
    # Test gather_subset=None; use the module's default
    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert facts['os_family'] == 'Linux'

    # Test gather_subset=None; use the module's default
    module.params = {'gather_subset': ['all']}
    # Test gather_subset=None; use the module's default
    facts = get_all_facts(module)
    assert isinstance(facts, dict)

# Generated at 2022-06-22 22:44:08.751165
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFact
    from ansible.module_utils.facts.utils import uniquify_list
    from ansible.module_utils.facts.system.distribution import UbuntuFactCollector
    from ansible.module_utils.facts.system.distribution import DebianFactCollector
    from ansible.module_utils.facts.system.distribution import FreeBSDFactCollector
    from ansible.module_utils.facts.system.distribution import FedoraFactCollector
    from ansible.module_utils.facts.system.distribution import OSXFactCollector
    from ansible.module_utils.facts.system.distribution import SunOSFactCollector

# Generated at 2022-06-22 22:44:19.194468
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock
    from ansible.module_utils.facts import ansible_facts

    # Mock objects to work around a bug in Ansible 2.0 and 2.1.
    class NullModule(object):
        def __init__(self, params=None):
            super(NullModule, self).__init__()
            self.params = params

        def fail_json(self, **kwargs):
            pass

    class NullModuleFailJson(object):
        def __init__(self, params=None):
            super(NullModuleFailJson, self).__init__()
            self.params = params

        def fail_json(self, **kwargs):
            raise RuntimeError('Fail JSON')


# Generated at 2022-06-22 22:44:30.281124
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    module_args = {}
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(choices=['all', 'min', '!all', '!network'], default='all'),
            filter=dict(default='*'),
            gather_timeout=dict(type='int', default=10),
            ansible_facts_cache={'cacheable': True, 'type': 'dict', 'default': {}}
        ),
        supports_check_mode=True,
        required_one_of=[['filter', 'ansible_facts_cache']]
    )

    # this is a compat module, so just get minimal facts
    gather_subset = ['min']


# Generated at 2022-06-22 22:44:39.891516
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.facts import Facts

    class MockAnsibleModule(object):
        def __init__(self, params=None):
            self.params = params

    class MockFacts(Facts):
        def __init__(self):
            super(MockFacts, self).__init__()

        def populate(self):
            self['test'] = 'test'

    def mock_collect(cls, instance, module):
        return {'test': 'test'}

    module = MockAnsibleModule

# Generated at 2022-06-22 22:44:47.046999
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test to check function ansible_facts
    '''
    class FakeModule:
        def __init__(self):
            self.params = dict()

    fake_params = dict()
    fake_params['gather_subset'] = ['all']
    fake_params['gather_timeout'] = 100
    fake_params['filter'] = '*'
    fake_module = FakeModule()
    fake_module.params = fake_params
    assert ansible_facts(fake_module)

# Generated at 2022-06-22 22:44:59.587311
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.collector.base as collector_base
    import ansible.module_utils.facts.collector.local as local
    import ansible.module_utils.facts.collector.network as network

    module_mock = Mock()

    # Make sure ansible_facts with no args defaults to all facts
    ansible_facts(module_mock)
    module_mock.run_command.assert_called_with(['test', '-e', '/proc/1/cmdline'], check_rc=False)
    module_mock.run_command.assert_called_with(['python', '-V'], check_rc=False)

    # Make sure ansible_facts with requested subset doesn't call all
    module_mock.reset_mock()

# Generated at 2022-06-22 22:45:09.898726
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollectorTimeout
    from ansible.module_utils import facts

    class TestFactCollector(BaseFactCollector):
        name = 'test_fact'

        def __init__(self, *args, **kwargs):
            BaseFactCollector.__init__(self, *args, **kwargs)
            self.collected_facts = dict()

        def collect(self, module=None, collected_facts=None):
            return dict()

    default_collectors.collectors = default_collectors.collectors + (TestFactCollector,)

    from ansible.module_utils.facts import get_all_

# Generated at 2022-06-22 22:45:21.368717
# Unit test for function ansible_facts
def test_ansible_facts():

    # mocks for the module needed by the facts module
    class MockModule(object):
        def __init__(self, params=None):
            self.params = {
                'gather_subset': [ '!all' ],
                'filter': 'ansible_all_ipv4_addresses',
                'gather_timeout': 10,
            }

        def fail_json(self, *args, **kwargs):
            pass

    mock_module = MockModule()

    facts_dict = ansible_facts(module=mock_module, gather_subset=['network'])

    assert 'all_ipv4_addresses' in facts_dict
    assert facts_dict['all_ipv4_addresses'] == ['192.0.2.1']


# Generated at 2022-06-22 22:45:30.821534
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    gather_subset = ['all']
    gather_timeout = 10

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    fact_collector = \
        ansible_collector.get_ansible_collector(all_collector_classes=default_collectors.collectors,
                                                namespace=namespace,
                                                filter_spec='*',
                                                gather_subset=gather_subset,
                                                gather_timeout=gather_timeout,
                                                minimal_gather_subset=None)

# Generated at 2022-06-22 22:45:35.055434
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule:
        class FakeParams:
            gather_subset = []
        params = FakeParams()
    module = FakeModule()

    # pretend gather_subset is empty
    result = ansible_facts(module)

    assert 'all' in result
    assert type(result['all']) is dict
    assert type(result['all']['default_ipv4']) is dict

# unit test complete


# Generated at 2022-06-22 22:45:40.859267
# Unit test for function ansible_facts
def test_ansible_facts():

    class MockAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    module = MockAnsibleModule(gather_subset=['all'])
    facts_dict = ansible_facts(module)
    assert 'all_ipv4_addresses' in facts_dict

# Generated at 2022-06-22 22:45:52.049260
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_collector
    import os
    import sys

    class MockModule:
        pass

    module = MockModule()
    module.params = {'gather_subset': ['all']}
    facts_dict = get_all_facts(module=module)

    assert facts_dict['distribution'] == 'unknown'

    # set env var so it isn't 'unknown'
    os.environ['ANSIBLE_COLLECT_FACT_ENV'] = 'TESTENV'
    facts_dict = get_all_facts(module=module)

    assert facts_dict['distribution'] == 'unknown'

    # set env var so it isn't 'unknown'
    os.environ['ANSIBLE_COLLECT_FACT_ENV'] = 'TESTENV'
    facts

# Generated at 2022-06-22 22:46:01.072269
# Unit test for function ansible_facts
def test_ansible_facts():

    class MockAnsibleModule:

        def __init__(self, **kwargs):
            self.params = kwargs

    # Without gather subset
    module = MockAnsibleModule(gather_subset=None)
    os_facts = ansible_facts(module)
    assert 'distribution' in os_facts
    assert 'distribution_version' in os_facts
    assert 'distribution_release' in os_facts

    # With subset
    module = MockAnsibleModule(gather_subset=['network'])
    os_facts = ansible_facts(module)
    assert 'all_ipv4_addresses' in os_facts
    assert 'all_ipv6_addresses' in os_facts
    assert 'default_ipv4' in os_facts

# Generated at 2022-06-22 22:46:13.089247
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test the ansible_facts function in this module'''

    # Mock out module and import
    class MockModule(object):
        '''mock class for module object'''
        def __init__(self, module_name, params={}):
            self.name = module_name
            self.params = params
            self.called = False

    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector.apt import AptFactCollector
    from ansible.module_utils.facts.collector.apt_pkg import AptPkgFactCollector

# Generated at 2022-06-22 22:46:16.312183
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    params = dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*'
    )

    assert ansible_facts(FakeModule(params))

# Generated at 2022-06-22 22:46:25.473898
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.basic import AnsibleModule

    class FakeArgs(object):
        '''Fake argparse object'''
        def __init__(self, args=None):
            if args is not None:
                for key, val in args.items():
                    setattr(self, key, val)

    def fake_ansible_module(parsed_args):
        '''Fake AnsibleModule class

        Get args from a FakeArgs instance, and pretend to be a real AnsibleModule
        instance
        '''

# Generated at 2022-06-22 22:46:34.807845
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    def gather_subset_params(module, subscope):
        return [module.params[subscope]] if subscope in module.params else []
    AnsibleModule.gather_subset_params = gather_subset_params

    class AnsibleModuleMock(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(AnsibleModuleMock, self).__init__(*args, **kwargs)
            self.params = {
                'filter': 'ansible_virtualization*'
            }

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return "/path/to/a/mock/binary"

    mod = AnsibleModuleMock(argument_spec={})

# Generated at 2022-06-22 22:46:45.076796
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import fallback_ipv4_address
    from ansible.module_utils.facts.util import get_file_content
    import getpass
    import os

    # Use ansible 2.3 module_utils to create a fake AnsibleModule
    from ansible.module_utils import basic
    import sys
    if sys.version < '3':
        import __builtin__ as builtins
    else:
        import builtins
    import module_utils.facts.get_all_facts as m_u_facts
    import json



    # Stub the builtin open() method.
    # If anyone looks for the 'facts' file from ansible 2.3 module_utils.get_all_facts(),
    # return a dummy facts file

# Generated at 2022-06-22 22:46:57.006184
# Unit test for function get_all_facts
def test_get_all_facts():

    import os

    import pytest

    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils import facts as facts_base

    @pytest.fixture
    def AnsibleModule():
        # return class, not instance
        return FakeAnsibleModule

    def test_get_all_facts(AnsibleModule):
        #
        # Verify that get_all_facts returns all the expected bare facts
        #
        # capture args passed to ansible_facts
        all_fact_collector_classes = default_collectors.collectors

        # return pre-provided value (from ansible_facts())

# Generated at 2022-06-22 22:47:08.794552
# Unit test for function ansible_facts
def test_ansible_facts():
    # Mock module:

    class MockModule:
        params = {'fact_path': '/path/to/fake/fact'}

    # Mock functions used by ansible_facts:

    def mock_get_ansible_collector(all_collector_classes, namespace, filter_spec, gather_subset,
                                   gather_timeout, minimal_gather_subset):
        # Mock fact_collector:

        class MockFactCollector:
            def __init__(self, module):
                pass

            def collect(self, module):
                return self.facts_dict

        # Mock AnsibleCollector
        module_name = namespace.namespace_name
        prefix = namespace.prefix
        collector = MockFactCollector(module=module)

# Generated at 2022-06-22 22:47:21.361611
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts.collector.system import DistributionFactCollector
    from ansible.module_utils.facts.collector.system import DistributionFilesFactCollector
    from ansible.module_utils.facts.collector.system import LsblkFactCollector
    from ansible.module_utils.facts.collector.system import LsmodFactCollector

    # expected is a dict mapping the bare fact name to
    # the value of that fact.
    # A bare fact name is the fact name with no ansible_ namespace
    # So ansible_lsmod_path becomes lsmod_path

# Generated at 2022-06-22 22:47:30.057248
# Unit test for function ansible_facts
def test_ansible_facts():
    # Stubbed out AnsibleModule
    class TestModule(object):
        def __init__(self, params):
            self.params = params

    test_module = TestModule({'gather_subset': None,
                              'gather_timeout': 10,
                              'filter': 'ansible_eth*'})

    # Use the ansible_facts method to run collect on all the collectors.
    all_facts = ansible_facts(test_module)

    # Check the facts dictionary returned by ansible_facts
    assert 'ansible_eth0' in all_facts
    assert 'ansible_eth1' not in all_facts

# Generated at 2022-06-22 22:47:39.411614
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils import basic

    class MockModule(object):
        def __init__(self, gather_subset=None):
            self.params = {}
            if gather_subset:
                self.params['gather_subset'] = gather_subset

    s = ansible_facts(MockModule(gather_subset=['hardware', 'network']))

    assert s != None

# Generated at 2022-06-22 22:47:48.635107
# Unit test for function get_all_facts
def test_get_all_facts():
    # The unittest module cannot import a module for group 'all', so we will fake AnsibleModule.
    # We could also create a fake module in tests/support/ansible_fake_module.py, but there is
    # nothing in it that we need to fake.
    module = lambda: None
    module.params = dict(
        gather_subset=['all'],
    )

    facts_dict = get_all_facts(module)

    assert facts_dict is not None
    assert len(facts_dict) > 0
    assert isinstance(facts_dict, dict)

# Generated at 2022-06-22 22:47:56.581834
# Unit test for function get_all_facts
def test_get_all_facts():
    import unittest
    import ansible.module_utils.facts.system.aix as aix_facts
    from ansible.module_utils.facts.hardware import Hardware
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.selinux import SELinux
    from ansible.module_utils.facts.system.platform import Platform
    from ansible.module_utils.facts.system.user import User
    from ansible.module_utils.facts.system.group import Group
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.lspci import Lspci

# Generated at 2022-06-22 22:48:03.105964
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.ansible
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.default_collectors

    import test.unit.module_utils.facts.test_facts_collector

    from ansible.module_utils.facts.facts import AnsibleModule

    test_fact_collector_classes = \
        test.unit.module_utils.facts.test_facts_collector.get_test_fact_collector_classes()

    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'


# Generated at 2022-06-22 22:48:06.410769
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts

    facts_dict = get_all_facts()
    assert isinstance(facts_dict, dict)


# unit test for function ansible_facts

# Generated at 2022-06-22 22:48:14.306643
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts
    # note we are not going to test the 'all' gather subset, because it would take
    # the full 10 seconds timeout, which is too long

    # test iterable gather_subsets.
    gathering = ['network', 'hardware', 'virtual']
    module = MockAnsibleModule(gather_subset=gathering)
    # call compat api
    fact_dict = get_all_facts(module)

    # Gather facts
    ansible_gathering_facts = ansible.module_utils.facts.gather_subset(module, gather_subset=gathering)

    # Verify that facts have been gathered
    assert ansible_gathering_facts == fact_dict

    # test string gather_subsets.
    gathering = 'hardware'
    module = MockAnsibleModule

# Generated at 2022-06-22 22:48:26.543479
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    class MinimalFactCollector(BaseFactCollector):
        def should_collect(self, subset=None):
            return True

        def collect(self, module=None, collected_facts=None):
            return {'minimal_fact': 'minimal_fact'}

    # add this class to the collections of fact collectors
    default_collectors.collectors += (MinimalFactCollector,)

    # create a module with a gather_subset param
    class TestModule:
        def __init__(self, gather_subset):
            self.params = {}

            # expected params from ansible.module_

# Generated at 2022-06-22 22:48:36.214554
# Unit test for function ansible_facts
def test_ansible_facts():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    # run 'ansible_facts' function
    module = MockModule({'gather_subset':['!all']})
    ansible_facts_ret = ansible_facts(module)
    assert ansible_facts_ret == {'default_ipv4': {'device': 'eth0', 'gateway': '192.0.2.1', 'interface': 'eth0', 'ipv4': '192.0.2.15', 'netmask': '255.255.255.0'}}

# Generated at 2022-06-22 22:48:46.610671
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic import GenericNetworkCollector

    class NetworkModuleStub(AnsibleModule):

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            if arg in ['ip', 'route']:
                return arg
            else:
                return None

        def run_command(self, cmd):
            self.cmd_result = cmd
            self.run_command_called = True

    ansible_module = NetworkModuleStub(argument_spec=dict(), check_invalid_arguments=False, bypass_checks=False)

    # With gather_subset=None, should use defaults
    ansible_facts

# Generated at 2022-06-22 22:48:56.447393
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    ansible_facts() needs to be tested with a real AnsibleModule instance.
    But AnsibleModule is only avaiable in AnsibleModule.

    So pull in a copy of the AnsibleModule class from ansible.module_utils.basic
    '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list'),
            gather_timeout=dict(default=10, type='int'),
            filter=dict(default='*', type='str'),
        ),
        supports_check_mode=True,
    )

    ansible_facts(module)

# Generated at 2022-06-22 22:49:00.937001
# Unit test for function get_all_facts
def test_get_all_facts():
    module_params = {'gather_subset': 'all'}

    class TestModule(object):
        def __init__(self, module_params):
            self.params = module_params

    module = TestModule(module_params)
    fact_dict = get_all_facts(module)

    assert isinstance(fact_dict, dict)
    assert len(fact_dict) > 0



# Generated at 2022-06-22 22:49:08.026666
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class fakemodule(object):
        params = {'gather_timeout': 10,
                  'filter': '*',
                  'gather_subset': ['all']}

        class fake_ansible_module(object):
            params = params

        def __init__(self):
            self.module = self.fake_ansible_module()

    gather_subset = ['all']
    module = fakemodule()

    # get_all_facts
    result = get_all_facts(module)

    # ansible_facts
    result

# Generated at 2022-06-22 22:49:18.536617
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for ansible_facts function.'''

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])
    all_collector_classes = default_collectors.collectors

# Generated at 2022-06-22 22:49:25.599479
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import get_collector_namespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import system

    m = mock.mock_module.MockModule(argument_spec={'a_param': dict(required=False, type='str')})
    # this is what ansible_facts and get_all_facts do, so mock m.params
    m.params = dict(gather_subset=['all'], filter='*', a_param='a_param_value')

# Generated at 2022-06-22 22:49:35.065253
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFileCacheCollector

    class TestCollector(BaseFileCacheCollector):
        name = 'test_collector'
        _FILE_SIZE_CACHE_KEY = 'ansible_test_file_size'
        _FILE_CONTENT_CACHE_KEY = 'ansible_test_file_content'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact_name': 'test_fact_value'}


# Generated at 2022-06-22 22:49:45.777357
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.facts import Facts
    import pytest

    class MockAnsibleModule:
        def __init__(self, params, gather_subset=None):
            self.params = params
            self.gather_subset = gather_subset

    mock_params = {
        'gather_subset': ['all'],
        'filter': '*',
    }

    facts = ansible_facts(MockAnsibleModule(params=mock_params), gather_subset=['all'])
    assert isinstance(facts, dict)
    assert isinstance(facts['ansible_local'], Facts)

    facts = ansible_facts(MockAnsibleModule(params=mock_params))
    assert isinstance(facts, dict)

# Generated at 2022-06-22 22:49:55.917745
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.basic

    class fake_module(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, **kwargs):
            pass

        def log(self, msg):
            pass

    fake_params = {
        'filter': 'ansible_date_time',
        'gather_subset': ['!all', 'network'],
        'gather_timeout': 10,
        'hostvars': True
    }

    m = fake_module(fake_params)

    # confirm that date_time is not in the result.
    assert get_all_facts(m) == {}

    fake_params['filter'] = 'ansible_all'
    m = fake_module(fake_params)
    # confirm that date_time is in

# Generated at 2022-06-22 22:50:01.676142
# Unit test for function ansible_facts
def test_ansible_facts():

    # we need a real ansible module to test this function
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    # test defaults
    facts_dict = ansible_facts(module)
    assert 'default_ipv4' in facts_dict

# Generated at 2022-06-22 22:50:09.776732
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import collections

    import ansible.module_utils.facts.namespace

    # The py2to3 shim is silly and doesn't handle imported submodules
    # So we run this test under 2.7 and manually 'fix' the py3 error
    if sys.version_info[0] == 2:
        fake_ansible_module = collections.namedtuple('AnsibleModule', ['params'])
        fake_ansible_module.params = {'gather_subset': 'all'}

        facts = get_all_facts(fake_ansible_module)

        assert isinstance(facts, dict)
        # just verify that a couple of top level, non-empty namespaces
        # are in the collected facts
        assert 'system' in facts
        assert 'network' in facts

# Generated at 2022-06-22 22:50:21.009898
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.namespace
    from ansible.module_utils.facts.collector.parsers.network import parse_default_ipv4, parse_default_ipv6

    class FakeNetworkCollector(ansible.module_utils.facts.namespace.BaseFactNamespaceCollector):
        name = 'network'
        _fact_ids = ['default_ipv4', 'default_ipv6']

        def get_facts(self, *args, **kwargs):
            return {'default_ipv4': parse_default_ipv4,
                    'default_ipv6': parse_default_ipv6}

    from ansible.module_utils.facts import SNMP_FACTS

    class AnsibleModule(object):

        def __init__(self):
            self.params = {}

# Generated at 2022-06-22 22:50:31.123616
# Unit test for function ansible_facts
def test_ansible_facts():
    import unittest
    import mock
    from ansible.module_utils import basic

    class TestClass(unittest.TestCase):

        def setUp(self):

            # Mock the AnsibleModule class
            self.mock_module = mock.MagicMock(name='AnsibleModule')
            self.mock_module.params = dict()
            self.mock_module.params['gather_subset'] = ['all']

        def test_get_all_facts(self):

            self.mock_module.params['gather_subset'] = ['all']
            result = get_all_facts(self.mock_module)

            # Assert that a dict was returned
            self.assertTrue(result, dict)

            # Assert that some facts exist.

# Generated at 2022-06-22 22:50:39.226594
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    mock_module = MockModule()

    fact_dict = get_all_facts(mock_module)

    assert isinstance(fact_dict, dict)
    assert fact_dict
    assert fact_dict['default_ipv4']['address'] == '10.10.10.10'



# Generated at 2022-06-22 22:50:46.613170
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    module_name = 'test_ansible_facts'
    if module_name not in sys.modules:
        # import the module that declares the AnsibleModule
        # Note that this is currently not a public ansible api
        import ansible.module_utils
        from ansible.module_utils.basic import AnsibleModule
        sys.modules[module_name] = AnsibleModule
    # import ansible_facts function
    from ansible.module_utils.facts import ansible_facts
    # import AnsibleModule class
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        '''mock up the AnsibleModule class'''
        def __init__(self, params={}):
            self.params = params


# Generated at 2022-06-22 22:50:58.659820
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts()'''

    import ansible.module_utils.facts.namespace
    import unittest.mock

    class AnsibleModuleMock:
        '''Mock of the AnsibleModule class to make a mock instance which can be
           passed to get_all_facts()'''
        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)

    # First test when gather_subset is specified as a param:
    ansible_module_mock = AnsibleModuleMock(['hardware', 'network'])
    facts = get_all_facts(ansible_module_mock)
    assert sorted(facts.keys()) == sorted(['network', 'hardware'])

    # Next test when gather_

# Generated at 2022-06-22 22:51:10.070240
# Unit test for function get_all_facts
def test_get_all_facts():
    # pylint: disable=import-error
    '''Tests for get_all_facts'''
    from ansible.module_utils.facts.facts import DEFAULT_GATHER_SUBSET
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.hardware.cpu import HardwareCPU
    from ansible.module_utils.facts.hardware.memory import HardwareMemory
    from ansible.module_utils.facts.system.platform import SystemPlatform
    from ansible.module_utils.facts.system.distribution import SystemDistribution
    from ansible.module_utils.facts.system.pkg_mgr import SystemPkgMgr
    from ansible.module_utils.facts.system.service_mgr import SystemServiceMgr

# Generated at 2022-06-22 22:51:16.761208
# Unit test for function ansible_facts
def test_ansible_facts():
    import tempfile
    import os
    import json
    import pytest
    from ansible.module_utils.facts import ansible_facts

    class FakeAnsibleModule(object):
        def __init__(self, params):
            self.params = params

    def subsets_containing(gather_subset, subset):
        assert(subset in gather_subset)
        return gather_subset

    with tempfile.NamedTemporaryFile(mode='wr') as f:
        os.environ['ANSIBLE_INVENTORY'] = f.name
        f.write('[localhost]\nlocalhost ansible_connection=local\n')
        f.flush()

        # ansible_facts doesn't take a gather_subset param in Ansible 2.0/2.1.
        # 2.2/2.3

# Generated at 2022-06-22 22:51:24.853710
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    import ansible.module_utils.facts.system.distribution
    show_distribution_facts = ansible.module_utils.facts.system.distribution.DistributionFactCollector._show_distribution_facts
    ansible.module_utils.facts.system.distribution.DistributionFactCollector._show_distribution_facts = lambda x: {}
    assert ansible_facts(ansible_facts)
    ansible.module_utils.facts.system.distribution.DistributionFactCollector._show_distribution_facts = show_distribution_facts

# Generated at 2022-06-22 22:51:33.440029
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeAnsibleModule:
        def __init__(self, fact_filter, fact_namespace):
            self.params = {'fact_filter': fact_filter, 'fact_namespace': fact_namespace}

    module = FakeAnsibleModule(fact_filter='dns*', fact_namespace='ansible_')

    dns_facts_dict = ansible_facts(module)

    for required_fact in ['domain', 'fqdn', 'hostname', 'search']:
        assert required_fact in dns_facts_dict, 'Expected fact %s to be present' % required_fact
        assert 'ansible_%s' % required_fact in dns_facts_dict, 'Expected fact %s to be present' % 'ansible_%s' % required_fact

    assert 'ipv4'

# Generated at 2022-06-22 22:51:44.646452
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeAnsibleModule(object):
        def __init__(self):
            params = dict(gather_subset=['foo'])
            self.params = params

    class FakeFactCollector(BaseFactCollector):
        def __init__(self, module, minimal_gather_subset=None, filter_spec=None):
            super(FakeFactCollector, self).__init__(module=module,
                                                    minimal_gather_subset=minimal_gather_subset,
                                                    filter_spec=filter_spec)


# Generated at 2022-06-22 22:51:55.398572
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import FactsParams
    params = FactsParams()

    # set test defaults
    params.facts_module_params = dict(
        gather_timeout=10,
        gather_subset=['all'],
        gather_network_resources=['all'],
        fact_path=[],
        filter='*',
    )
    module = FakeAnsibleModule(params=params)

    fake_all_collector_classes = [FakeFactCollector]
    # avoid getting a real fact collector, use a fake one
    ansible_collector.get_ansible_collector = MagicMock(return_value=fake_all_collector_classes[0])

    # set up a fake fact_collector class, which will act as a collector for all the facts that
    # ansible_

# Generated at 2022-06-22 22:52:06.017718
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    from ansible.module_utils._text import to_bytes


    class TestModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'min'}
            self.user = to_bytes("not_root")
            self.tmpdir = to_bytes("/tmp")

    tested_module = TestModule()

    import os
    import tempfile
    distro_path = os.path.join(os.path.dirname(ansible.module_utils.facts.system.distribution.__file__), "tests/") # pylint: disable=no-member
   

# Generated at 2022-06-22 22:52:10.630447
# Unit test for function get_all_facts
def test_get_all_facts():
    module = MockAnsibleModule(params={
        'gather_subset': ['all']
    })

    facts = get_all_facts(module)

    assert facts['default_ipv4']['address'] == '10.1.1.1'



# Generated at 2022-06-22 22:52:20.642809
# Unit test for function ansible_facts
def test_ansible_facts():
    class AnsibleModuleMock(object):
        def __init__(self, params):
            self.params = params

        def add_facts(self, facts):
            self.facts = facts

    def mock_collect(module):
        return {'foo': 'bar'}

    orig_get_ansible_collector = ansible_collector.get_ansible_collector

    # Set up a mock for the ansible_collector

# Generated at 2022-06-22 22:52:32.589218
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.modules.system.setup import SetupModule
    import json
    import os

    # Create an AnsibleModule object to test the function get_all_facts
    module = SetupModule()

    module.params['gather_subset'] = 'all'
    module.params['filter'] = '*'
    module.params['gather_timeout'] = 10

    fact_file_path = '/tmp/ansible_facts'

    # Write all facts to a json file for verification
    with open(fact_file_path, 'w') as fact_file:
        json.dump(module.get_all_facts(), fact_file)

    # Get the all facts, and compare it with the facts written in json file

# Generated at 2022-06-22 22:52:38.577102
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.cache

    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.peripheral
    import ansible.module_utils.facts.pkg_mgr
    import ansible.module_utils.facts.service_mgr
    import ansible.module_utils.facts.cache
    import ansible.module_utils.facts.user
    import ansible.module_utils.facts.local


# Generated at 2022-06-22 22:52:46.029536
# Unit test for function get_all_facts
def test_get_all_facts():
    ''' unit test for function get_all_facts '''

    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    module = MockModule()

    fact_dict = get_all_facts(module)

    assert type(fact_dict) is dict

    assert type(fact_dict['os_family']) is str
    assert type(fact_dict['system']) is str



# Generated at 2022-06-22 22:52:56.282802
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils import basic

    if not PY3:
        import sys
        reload(sys)
        sys.setdefaultencoding('utf-8')

    def assert_facts(ansible_facts, fact, value):
        assert to_text(ansible_facts[fact]) == to_text(value)

    m = basic.AnsibleModule(
        argument_spec={
            'gather_subset': dict(default='all', type='list'),
            'gather_timeout': dict(default=10, type='int'),
            'filter': dict(default='*', type='str')
        }
    )

# Generated at 2022-06-22 22:53:05.940422
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import os

    # Mock an AnsibleModule
    class AnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    module = AnsibleModule(gather_subset=['all'])

    facts = get_all_facts(module)
    assert facts['distribution'] == 'Linux'
    for collector in default_collectors.collectors:
        assert collector._namespace.name in facts
        for fact in facts[collector._namespace.name]:
            assert fact.name in facts
            break

# Generated at 2022-06-22 22:53:16.064938
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    module = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_timeout=dict(default=10, type='int'),
            filter=dict(default='*', type='str')
        )
    )

    gather_subset = module.params['gather_subset']
    gather_timeout = module.params.get('gather_timeout')
    filter_spec = module.params.get('filter', '*')


# Generated at 2022-06-22 22:53:26.356903
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def __init__(self):
            self.params = {
                'gather_subset': ['!all'],
                'gather_timeout': 1,
                'filter': '*',
            }

    fake_module = FakeModule()

    fake_cache_dir = 'fake_cache_dir'
    cache_provider = cache.get_cache_provider(cache_class=cache.OnDiskCache, cache_dir=fake_cache_dir)
    gather_subset = fake_module.params['gather_subset']