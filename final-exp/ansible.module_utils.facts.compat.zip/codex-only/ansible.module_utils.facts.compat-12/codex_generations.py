

# Generated at 2022-06-22 22:43:21.937976
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.facts.ansible_facts as ansible_facts
    local_facts = ansible_facts.ansible_facts(AnsibleModule(argument_spec={}, supports_check_mode=True))
    assert local_facts['distribution'] is not None

# Generated at 2022-06-22 22:43:29.048364
# Unit test for function ansible_facts
def test_ansible_facts():

    # Fake module.
    import ansible.module_utils.facts
    module = ansible.module_utils.facts.AnsibleModule({})

    # Fake module's params.
    module.params = {'filter': '*', 'gather_subset': ['all']}

    from ansible.module_utils._text import to_bytes
    facts = ansible_facts(module)

    # Test that a known fact is in the facts.
    assert to_bytes('ansible_selinux') in facts

# Generated at 2022-06-22 22:43:37.363866
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'gather_subset': {'type': 'list'}})
    module._ansible_debug = True

    # We need to set the gather_subset parameter to something.
    module.params['gather_subset'] = ['network', 'hardware']

    # Call to get_all_facts()
    facts_dict = get_all_facts(module)
    assert module.exit_json.called
    assert 'ansible_all_ipv4_addresses' in facts_dict



# Generated at 2022-06-22 22:43:46.902706
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_facts

    ansible_module_instance = AnsibleModule({'gather_subset': '!all,ansible_distribution,ansible_distribution_version'})
    results = ansible_facts(ansible_module_instance)
    assert type(results) == dict
    assert 'ansible_distribution' in results
    assert 'ansible_distribution_version' in results
    assert 'ansible_machine' not in results

# Generated at 2022-06-22 22:43:57.075062
# Unit test for function get_all_facts
def test_get_all_facts():
    import os
    libdir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'module_utils'))
    module_utils_paths = [libdir]
    # import module_utils here, before mock.patch
    from ansible.module_utils.basic import AnsibleModule

    fake_module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all'])})
    fake_module.params = dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*',
    )
    facts_dict = get_all_facts(fake_module)
    # facts_dict should not be empty
    assert facts_dict



# Generated at 2022-06-22 22:43:59.003454
# Unit test for function get_all_facts
def test_get_all_facts():

    # Ensure changes to ansible_facts are reflected by get_all_facts
    assert ansible_facts is get_all_facts

# Generated at 2022-06-22 22:44:10.182803
# Unit test for function ansible_facts
def test_ansible_facts():
    # For now, just import AnsibleModule and call ansible_facts.
    # If ansible_facts() ever has any other parameters, we'll need
    # to do something more specific here.
    from ansible.module_utils.facts import AnsibleModule
    # Inject fake param data
    module = AnsibleModule({'filter': '*', 'collect_timeout': 10})
    fact_dict = ansible_facts(module)

    # some basic fact validation
    assert fact_dict['lsb']['distrib_id'] == 'RedHatEnterpriseServer'
    assert fact_dict['python']['version']['major'] == 3
    assert fact_dict['platform_version'].startswith('7')
    assert fact_dict['uptime_seconds'] > 0

# Generated at 2022-06-22 22:44:20.559744
# Unit test for function get_all_facts
def test_get_all_facts():

    # Stub out the module class, as we're not loading the module on the controller
    # For now, just define that fact_collector is an attrib.
    class StubModule(object):
        def __init__(self, params):
            self.params = params
            self.fact_collector = None

        def exit_json(self, rc, ansible_facts, **kwargs):
            self.fact_collector = ansible_facts

    # Set up the params, which we'll pass to the module when we initialize it
    params = dict(
        gather_subset='!all',
    )

    # Create a module instance, passing in the params
    m = StubModule(params)

    # Execute the function under test.
    get_all_facts(m)

    # Assert that get_all_facts has populated the fact

# Generated at 2022-06-22 22:44:25.157454
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'gather_subset': ['all']})
    result = ansible_facts(module=module)
    assert isinstance(result, dict)
    assert result

# Generated at 2022-06-22 22:44:30.690030
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        import ansible
        from ansible.module_utils.facts import get_module_facts
        has_ansible = True
    except ImportError:
        has_ansible = False

    if has_ansible:
        from ansible.module_utils.facts import ansible_facts
        import ansible.module_utils.facts.system.distribution

        class DummyModule(object): pass

        d = DummyModule()
        d.params = {'filter': '*'}

        all_facts = ansible_facts(d)
        assert all_facts is not None
        assert len(all_facts) > 0

        # get a subset of facts
        d.params = {'filter': 'ansible_distribution', 'gather_subset': 'all'}
        facts = ansible_facts(d)

# Generated at 2022-06-22 22:44:40.473856
# Unit test for function ansible_facts
def test_ansible_facts():
    # TODO: this is not even close to a full unit test. It just tests that
    # the function runs from start to end, and returns something that looks like a dict.
    import mock
    import sys
    import json
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.base import BaseFactCollector
    from ansible.module_utils.facts.namespace import FactsNamespace
    mock_module_params = {
        'gather_subset': ['all'],
        'gather_timeout': 10,
        'filter': '*'
    }
    class MockCollector(BaseFactCollector):
        def get_facts(self):
            return {'test': 'stuff'}

# Generated at 2022-06-22 22:44:50.176878
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.six import PY2
    if PY2:
        from ansible.module_utils.pycompat24 import get_exception
    else:
        from ansible.module_utils.six import get_exception

    import os
    import sys
    import tempfile
    # Unittest is a lib on Python 2, but module on Python 3.
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    # Stubbed AnsibleModule class used to test get_all_facts method
    class AnsibleModule():
        def __init__(self):
            self.params = {'gather_subset': ['!all']}


# Generated at 2022-06-22 22:44:57.166505
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule:
        def __init__(self):
            self.params = {
                'filter': '*',
                'gather_subset': ['network', 'virtual'],
                'gather_timeout': 10,
                }

    mock_module = MockModule()
    facts = get_all_facts(mock_module)

    assert isinstance(facts, dict)
    assert 'virtual' in facts

# Generated at 2022-06-22 22:45:03.851589
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    facts_dict = get_all_facts(module)
    assert isinstance(facts_dict, dict)
    assert 'default_ipv4' in facts_dict



# Generated at 2022-06-22 22:45:11.935596
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys

    import ansible.module_utils.facts.namespace
    from ansible.module_utils.facts.namespace import AnsibleCollector, PrefixFactNamespace
    from ansible.module_utils.facts import collector

    from ansible.module_utils._text import to_text

    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils.facts.ansible_collector import get_ansible_collector, AnsibleFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

# Generated at 2022-06-22 22:45:21.179449
# Unit test for function get_all_facts
def test_get_all_facts():
    class Module():
        def __init__(self, params):
            self.params = params

    module = Module({'gather_subset': ['!all', 'network']})

    ansible_facts = get_all_facts(module)

    # This should be enough to figure out if the function works
    assert 'ansible_distribution' in ansible_facts
    assert 'ansible_distribution_version' in ansible_facts
    assert 'ansible_os_family' in ansible_facts
    assert 'ansible_selinux' in ansible_facts


# Generated at 2022-06-22 22:45:25.998444
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    fake_module = FakeModule()
    assert get_all_facts(fake_module) == dict(ansible=dict(default_ipv4=dict(network='192.0.2.0', address='192.0.2.1')))



# Generated at 2022-06-22 22:45:34.698252
# Unit test for function ansible_facts
def test_ansible_facts():
    # Just test that get_all_facts works with a module with a subset and no subset arg
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import ansible_collector
    import ansible.module_utils.facts.collector.base as base
    class TestAnsibleModule(object):
        params = dict(
            gather_timeout = 10,
            gather_subset = ['network','hardware'],
            filter='ansible_*',
        )
    class TestCollector(base.BaseFactCollector):
        @property
        def name(self):
            return 'test'

        @property
        def fact_namespace(self):
            return 'ansible'


# Generated at 2022-06-22 22:45:45.143558
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_distribution
    from ansible.module_utils._text import to_bytes

    class MyFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = ['test_fact']

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'oo'}

    FakeModule = type('FakeModule', (object,), {
        'params': {
            'gather_subset': ['all'],
            'filter': '*'
        }
    })

    module_instance = FakeModule()

    fake_all_collector_classes = {'test': MyFactCollector}

    fake_distribution = get_

# Generated at 2022-06-22 22:45:50.866660
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.collector
    reload(ansible.module_utils.facts.collector)

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import module_utils


    # make facts visible to the funcs
    module_utils.SYSTEM_DEFAULT_PATHS = dict(
        ansible_local=[
            '/usr/local/bin',
            '/usr/local/sbin',
            '/usr/bin',
            '/usr/sbin',
            '/bin',
            '/sbin',
        ],
        ansible_bin=[
            '/usr/bin', '/usr/sbin', '/bin', '/sbin'
        ]
    )

    test_module_utils = module_utils()

    test_module_utils.FACTS

# Generated at 2022-06-22 22:46:00.816060
# Unit test for function ansible_facts
def test_ansible_facts():
    class MockAnsibleModule:
        def __init__(self, params):
            self.params = params

    gather_timeout = 3

    # create module object
    module = MockAnsibleModule({'gather_timeout': gather_timeout})

    # call ansible_facts
    facts_dict = ansible_facts(module)

    assert facts_dict

    assert 'system' in facts_dict
    assert 'distribution' in facts_dict
    assert 'distribution_version' in facts_dict
    assert 'distribution_major_version' in facts_dict
    assert 'path' in facts_dict
    assert 'python' in facts_dict
    assert 'filesystems' in facts_dict
    assert 'default_ipv4' in facts_dict
    assert 'default_ipv6' in facts_dict

    # check

# Generated at 2022-06-22 22:46:12.883249
# Unit test for function ansible_facts
def test_ansible_facts():
    # Mock the module so the parameter 'gather_subset' can be added.
    # This is used by the optional arg gather_subset in the ansible_facts function.
    # It is actually a module parameter, but we don't want to require an instance of
    # an ansible module to be passed in.
    class AnsibleModuleInstance:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    test_gather_subset = ['all']
    module = AnsibleModuleInstance(test_gather_subset)
    facts_dict = ansible_facts(module)
    assert type(facts_dict) is dict
    assert facts_dict.get('default_ipv4')
    assert facts_dict.get('ansible_facts')
   

# Generated at 2022-06-22 22:46:23.279350
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import os

    test_file_path = os.path.join(os.path.dirname(sys.argv[0]), '..')
    ansible_repodir = os.path.abspath(test_file_path)
    sys.path.insert(0, os.path.join(ansible_repodir, 'lib'))
    sys.path.insert(0, os.path.join(ansible_repodir, 'module_utils'))

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector


# Generated at 2022-06-22 22:46:33.140168
# Unit test for function ansible_facts
def test_ansible_facts():
    import collections

    # Fake result of AnsibleModule()
    module = collections.namedtuple('module', ['params'])()

    module.params = {'gather_subset': ['!all', 'network']}

    # Check that facts are correctly loaded
    facts = ansible_facts(module)
    assert 'default_ipv4' in facts
    assert 'default_ipv6' in facts
    assert facts['default_ipv4']['address'] == '172.16.42.1'

    # Check that subset 'network' is correctly taken into account
    module.params = {'gather_subset': ['!all', '!network']}
    facts = ansible_facts(module)
    assert 'default_ipv4' not in facts
    assert 'default_ipv6' not in facts

    # Check

# Generated at 2022-06-22 22:46:43.170680
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test value of get_all_facts return dict.

    expected to have a dict with key value pairs where the key is a bare factname,
    and the value is the fact value for that fact.

    '''
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import AnsibleModuleMock
    from ansible.module_utils.facts.test.test_default_collectors import FakeDefaultFactCollector

    module = AnsibleModuleMock(name='mymodule')
    module.params = dict(gather_subset='all')

   

# Generated at 2022-06-22 22:46:50.702268
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.extras import _virtual_distribution
    from ansible.module_utils.facts.hardware import Hardware
    from ansible.module_utils.facts.virtual.virtualbox import VirtualBox
    from ansible.module_utils.facts.virtual.xenapi import XenServer
    from ansible.module_utils.facts.virtual.vmware import VMWare
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.system import Distro

    try:
        cached_facts = cache.facts_cache()
    except Exception:
        raise

    # Cache facts
    if not cached_facts.is_valid():
        facts = {}
        facts_collector = FactsCollector()


# Generated at 2022-06-22 22:46:59.420768
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' ansible_facts() returns a dict mapping the bare fact name ('default_ipv4' with no 'ansible_' namespace) to
    the fact value.
    '''

    import sys
    import ansible.modules.system.setup as ansible_setup_module

    # test that ansible_facts returns expected dict
    args = dict(
    )
    module = ansible_setup_module.AnsibleModule(**args)
    facts_dict = ansible_facts(module=module)

    assert isinstance(facts_dict, dict)
    assert facts_dict['default_ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-22 22:47:01.750535
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts

    module = ''
    facts = get_all_facts(module)
    assert ansible_facts(module) == facts

# Generated at 2022-06-22 22:47:06.593409
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['!all'], type='list'),
                                              gather_timeout=dict(type='int', default=10)))
    gather_subset = module.params['gather_subset']
    assert_equals(gather_subset, ['!all'])

    facts = get_all_facts(module)
    assert_equals(facts, {})

# Generated at 2022-06-22 22:47:13.766788
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test function with fake input data
    import ansible.module_utils.facts.ansible_facts as ans_facts

    fake_module = ans_facts.AnsibleModule(argument_spec={
        "gather_subset": {"required": False, "type": "list"}
    })

    ansible_facts = ans_facts.ansible_facts(module=fake_module, gather_subset=['all'])

    assert 'uname' in ansible_facts
    assert 'platform_system' in ansible_facts
    assert 'distribution' in ansible_facts

# Generated at 2022-06-22 22:47:25.925703
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self):
            self.params = {}

    class TestModuleWithGatherSubset(object):
        def __init__(self):
            self.params = {'gather_subset': ['!all', 'network', 'virtual']}

    class TestModuleWithTimeout(object):
        def __init__(self):
            self.params = {'gather_timeout': 60}

    module = TestModule()
    ansible_facts(module)
    namespaces = module._ansible_facts.namespaces
    assert 'ansible' in namespaces

# Generated at 2022-06-22 22:47:33.774692
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import collections
    import pytest


    class AnsibleModuleMock:
        class Params(dict):
            # dict subclass for pep8 compliance
            pass

        def __init__(self, params):
            self.params = AnsibleModuleMock.Params(params)


    def get_empty_module_obj(module_name):
        elf = '/lib/libc.so.6'
        sysctl = '/sbin/sysctl'
        if not os.path.exists(elf) or not os.path.exists(sysctl):
            return AnsibleModuleMock({})

# Generated at 2022-06-22 22:47:42.540565
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.network_info as network_info_mod
    module_mock = network_info_mod.AnsibleModuleMock()
    module_mock.params = dict(
        gather_subset='all',
    )

    # run the function being tested
    facts = get_all_facts(module_mock)

    # provided by the NetworkCollector
    assert 'ansible_net_all_ipv4_addresses' in facts
    assert 'ansible_net_all_ipv6_addresses' in facts
    assert 'ansible_net_hostname' in facts

# Generated at 2022-06-22 22:47:48.536460
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.facts as mf
    ansible_module = mf.AnsibleModule()
    ansible_module.params = {'gather_subset': ['all']}
    facts = get_all_facts(ansible_module)
    assert 'distribution' in facts
    assert 'distribution_version' in facts
    assert 'domain' in facts

# Generated at 2022-06-22 22:47:53.287589
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts

    class TestModule:
        def __init__(self):
            self.params = dict()

    module = TestModule()

    module.params = {'gather_subset': 'all'}
    assert get_all_facts(module)


# Generated at 2022-06-22 22:48:04.903048
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts as facts_mod
    import ansible.module_utils.facts.linux.system as system_module
    import ansible.module_utils.facts.linux.date_time as date_time_module
    import ansible.module_utils.facts.linux.distribution as distribution_module
    import ansible.module_utils.facts.linux.pkg_mgr as pkg_mgr_module
    import ansible.module_utils.facts.platform as platform_module
    import ansible.module_args as argspec
    import imp
    import json
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    import sys
    import time

    # need this to work on py2.6

# Generated at 2022-06-22 22:48:13.696597
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    all_collector_classes = default_collectors.collectors


# Generated at 2022-06-22 22:48:26.076459
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule, missing_required_lib

    class TestModule(AnsibleModule):
        def __init__(self):
            self.params = {}
            self.fail_json = self.fail

    module = TestModule()
    module.run_command = my_run_command
    module.fail_json = my_fail_json

    # this 'ansible_facts' should be ignored
    my_env = {
        'ansible_facts': 'silly',
        'ansible_user_id': 'testuser'
    }
    module.run_command = lambda *args, **kwargs: ('', '', 0)
    module.get_bin_path = lambda *args, **kwargs: ''
    module.fail_json = my_fail_json
    module.params

# Generated at 2022-06-22 22:48:38.429237
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import fallback_collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class AnsibleModuleMock():
        def __init__(self, params, **kwargs):
            self.params = params

    # Mock cache.run_command
    cache_run_command_orig = fallback_collector.cache_run_command
    fallback_collector.cache_run_command = lambda *args, **kwargs: (0, 'ansible-mock')

    # Mock AnsibleModule
    module = AnsibleModuleMock(
        params={
            'gather_subset': ['all'],
            'gather_timeout': 10
        })

    # Mock platform_type

# Generated at 2022-06-22 22:48:48.244950
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import module_arg_spec
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.basic import AnsibleModule

    params = dict(
        filter='*',
        gather_subset=['min'],
        gather_timeout=10,
    )

    module = AnsibleModule(
        argument_spec=module_arg_spec,
        supports_check_mode=False,
        mutually_exclusive=[],
    )

    module.params.update(params)
    result = get_all_facts(module)
    assert isinstance(result, dict)



# Generated at 2022-06-22 22:48:58.096149
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts

    class AnsibleModule:
        def __init__(self, argspec):
            # argspec is unused in this test
            self.params = {'gather_subset': ['all']}

    class AnsibleModuleWithNoParams(AnsibleModule):
        def __init__(self):
            super(AnsibleModuleWithNoParams, self).__init__(argspec={})

    # fake out ansible.module_utils.facts.ansible_facts so we don't spend a lot of time collecting real facts
    real_ansible_facts = ansible_facts

# Generated at 2022-06-22 22:49:04.499488
# Unit test for function get_all_facts
def test_get_all_facts():
    test_m = mock_module
    test_m.params = {'gather_subset': ['all']}
    test_m.params['gather_timeout'] = 10
    test_m.params['filter'] = '*'

    test_m.ansible.module_utils.facts.ansible_collector.get_ansible_collector = \
        mock_get_ansible_collector

    facts_dict = get_all_facts(test_m)
    assert facts_dict['test_fact'] == 'test_fact'


# Generated at 2022-06-22 22:49:15.300175
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts as get_all_facts_real
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils import basic
    from sys import version_info
    from collections import namedtuple

    class Args(object):
        def __init__(self, params):
            self.params = params

    args = Args({'gather_subset': 'all'})

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        no_log=True,
        add_file_common_args=True
    )

# Generated at 2022-06-22 22:49:22.021658
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Unit test for function ansible_facts
    '''
    class AnsibleModuleMock():
        class params():
            gather_subset = None
            gather_timeout = 10
            filter = '*'
        
        def __init__(params):
            pass
        def fail_json(self, msg, **kwargs):
            print(msg)
        def exit_json(self, **kwargs):
            print(kwargs)

    try:
        module = AnsibleModuleMock()
        ansible_facts(module, ['all'])
    except Exception as e:
        print(str(e))

# Generated at 2022-06-22 22:49:27.274531
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.distribution
    MOCK_FACT_DICT = {'bogus_fact': 'mock_value'}

    def mock_collect(module):
        return MOCK_FACT_DICT

    # temporarily replace the collect method with our mock_collect()
    real_collect = ansible.module_utils.facts.system.distribution.DistributionCollector.collect
    ansible.module_utils.facts.system.distribution.DistributionCollector.collect = mock_collect


# Generated at 2022-06-22 22:49:35.849811
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.modules.system.setup import main as setup_main
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.compat.tests.mock import MagicMock
    from ansible.compat.tests.mock import patch

    class FauxModule(object):
        '''mock ansible module implementation'''
        params = {u'filter': u'*',
                  u'gather_subset': ['all'],
                  u'gather_timeout': 10}

    module = FauxModule()

    # patch BaseFactCollector so it can be

# Generated at 2022-06-22 22:49:46.330404
# Unit test for function ansible_facts
def test_ansible_facts():
    import os.path

    import pytest
    import ansible
    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_facts

    # For Ansible 2.2; remove this test when dropping 2.2 support
    from ansible.module_utils.facts import get_all_facts

    fixture_files = []
    for filename in os.listdir(os.path.join(os.path.dirname(__file__), 'fixtures')):
        if filename.startswith('ansible_') and filename.endswith('.fact'):
            fixture_files.append(os.path.join(os.path.dirname(__file__), 'fixtures', filename))


# Generated at 2022-06-22 22:49:56.584221
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class AnsibleModule:
        def __init__(self, params):
            self.params = params

    class Collector:
        def __init__(self, *args, **kwargs):
            # The tests only use the basic collector so won't pass in args
            pass
        def collect(self, module):
            return {'test_key': 'test_val'}

    # test with a subset of facts
    class Collectors(object):
        def __init__(self):
            self.collector_classes = {}
            self.collector_classes['test'] = Collector


# Generated at 2022-06-22 22:50:05.928398
# Unit test for function get_all_facts
def test_get_all_facts():
    import mock
    import json
    import os
    import pytest

    mock_module = mock.MagicMock()
    mock_module.params = {'gather_subset': ['!all']}

    # Mock the function get_file_content
    mock_get_file_content = '{"ansible_facts": {"ansible_distribution": "CentOS"}}'
    with mock.patch.object(ansible_collector, "get_file_content", return_value=mock_get_file_content) as mocked_method:
        # Call the function
        result_dict = get_all_facts(module=mock_module)

        # Check if the method was called
        mocked_method.assert_called_once()

        # Check the result
        assert result_dict == {"distribution": "CentOS"}

   

# Generated at 2022-06-22 22:50:11.923526
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes

    class MockModule(object):
        def __init__(self):
            self.params = {}

    module = MockModule()

    # Mock all the different gather subset returns
    module.params['gather_subset'] = ['all']
    all_facts = get_all_facts(module)
    assert len(all_facts) > 100

    module.params['gather_subset'] = ['network']
    network_facts = get_all_facts(module)
    assert len(network_facts) > 10

    module.params['gather_subset'] = ['!network']
    non_network_facts = get_all_facts(module)
    assert len(non_network_facts) < 100

    module.params['gather_subset'] = ['min']

# Generated at 2022-06-22 22:50:21.897225
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import tempfile
    from ansible.module_utils.facts import __file__ as facts_file

    facts_dir = os.path.dirname(facts_file)
    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, 'test_facts_file.py')
    with open(tmpfile, 'w') as f:
        f.write("#!/usr/bin/python\n")
        f.write("#\n")
        f.write("# (c) 2018 Red Hat Inc.\n")
        f.write("#\n")
        f.write("# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)\n")
        f.write("\n")

# Generated at 2022-06-22 22:50:31.704538
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.compat.tests import unittest
    from ansible.module_utils.facts import ansible_facts

    class TestAnsibleModule(object):
        '''
        A mock module class
        '''

        def __init__(self, module_args):
            self.module_args = module_args
            self.params = module_args

    module_args = {'gather_subset': ['all']}
    test_ansible_module = TestAnsibleModule(module_args)

    test_facts_dict = ansible_facts(module=test_ansible_module)

    try:
        assert test_facts_dict['distribution'] == 'RedHat'
    except ImportError:
        assert test_facts_dict['distribution'] == 'Fedora'

# Generated at 2022-06-22 22:50:44.037774
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import json

    import ansible.module_utils.facts.facts as facts_module

    path = os.path.dirname(os.path.realpath(__file__))
    with open(os.path.join(path, 'test_facts_dict.json'), 'r') as f:
        exp_facts_dict = json.load(f)

    exp_facts_dict = {unicode(k): v for k, v in exp_facts_dict.items()}

    class DummyModule(object):
        def __init__(self, params=None):
            self.params = params or {}

    module = DummyModule(params={'gather_subset': ['all']})

    facts_dict = ansible_facts(module)

# Generated at 2022-06-22 22:50:56.747863
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import module_facts
    import pytest

    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.facts = {}

        def exit_json(self, ansible_facts, changed=False, msg=None):
            self.exit_args = {'ansible_facts': ansible_facts, 'changed': changed}
            if msg:
                self.exit_args['msg'] = msg

    class FakeAnsibleModule(object):
        def __init__(self, params):
            self.params = params
            self.facts = {}

        def exit_json(self, ansible_facts, changed=False):
            self.exit_args = {'ansible_facts': ansible_facts, 'changed': changed}


# Generated at 2022-06-22 22:51:08.498432
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping

    module = basic.AnsibleModule(argument_spec={'gather_subset': dict(type='list', elements='str', default=['all'])})

    # Returns a dict
    assert isinstance(get_all_facts(module), MutableMapping)

    # Is not bytes
    try:
        assert not isinstance(get_all_facts(module)['ansible_date_time']['date'], to_bytes)
    except KeyError:
        pass

    # Check if one fact exists (or not)
    assert not get_all_facts(module).get('ansible_lvm')

# Generated at 2022-06-22 22:51:19.863542
# Unit test for function get_all_facts
def test_get_all_facts():

    # Uncomment to test locally in py27
    #from ansible.module_utils.facts.namespace import create_namespace_manager
    #create_namespace_manager(globals(), 'ansible.module_utils.facts')

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.common.removed import removed_module

    # Test cases

# Generated at 2022-06-22 22:51:29.864226
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Unit test for function ansible_facts'''

    # mock ansible_module
    class mock_ansible_module(object):
        '''mock ansible module'''

        def __init__(self, gather_subset=None):
            self.params = {}
            self.params['gather_subset'] = gather_subset

    # ensure that ansible_facts works with gather_subset=['all'], the default
    ansible_facts_all = ansible_facts(mock_ansible_module())
    assert 'default_ipv4' in ansible_facts_all

    # ensure that ansible_facts works with gather_subset=[], which should return an empty dict
    ansible_facts_empty = ansible_facts(mock_ansible_module([]))

# Generated at 2022-06-22 22:51:31.894706
# Unit test for function ansible_facts
def test_ansible_facts():
    # stub out AnsibleModule
    class DummyModule(object):
        def __init__(self, **kwargs):
            self.params = {}

    # We need ansible facts to be available
    assert 'ansible_facts' in ansible_facts(DummyModule())

# Generated at 2022-06-22 22:51:44.151010
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import ansible.module_utils.facts.network.base as network_base

    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.distribution import DistributionCollector
    from ansible.module_utils.facts.system.platform import LinuxDistributionService
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    class FakeAnsibleModule():

        def __init__(self, params=None):
            self._params = params or {}

        def params(self, key):
            return self._params.get(key, None)

        def exit_json(self, ansible_facts):
            self.facts = ansible_facts

# Generated at 2022-06-22 22:51:54.959332
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    import collections
    import json
    import os
    import pytest
    import sys
    import uuid
    from ansible import module_utils
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr

    class TestNamespace(BaseFactNamespace):
        def __init__(self, *args, **kwargs):
            super(TestNamespace, self).__init__(*args, **kwargs)
            self.collectors = []

# Generated at 2022-06-22 22:51:59.705918
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest
    from ansible.module_utils.facts.ansible_facts import ansible_facts, default_collectors
    from ansible.module_utils.facts.collector.text_file import TextFileFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class ParamMock(object):
        def __init__(self, *args, **kwargs):
            pass

    class RcMock(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_hostname(self):
            return 'fake_hostname'


# Generated at 2022-06-22 22:52:12.583615
# Unit test for function get_all_facts
def test_get_all_facts():
    '''This is a unit test for get_all_facts.  Not a real unit test - it doesn't have
    any asserts.  It just runs get_all_facts and prints the output

    It exercises the code and can be used as a starting point for a real unit test.'''

    from ansible.module_utils.facts import get_all_facts

    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(type='list', default=['all']),
    ))

    # call get_all_facts
    facts = get_all_facts(module)

    # print the results of get_all_facts
    print('facts {}'.format(facts))

    # This is the output from my system (Ansible 2.3.1.0)
    #
    #     facts {'fips': False,

# Generated at 2022-06-22 22:52:21.213021
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''

    from ansible.module_utils.facts import ansible_facts

    class AnsibleModuleMock(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    mock_module = AnsibleModuleMock(gather_subset=['all'])

    # test with 'all'
    facts = get_all_facts(mock_module)
    assert 'virtualization_role' in facts

    # test with 'min'
    mock_module = AnsibleModuleMock(gather_subset=['min'])
    facts = get_all_facts(mock_module)
    assert facts == {}

# Generated at 2022-06-22 22:52:33.105247
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule
    import sys

    # unit test for ansible_facts (compat for 2.0/2.2)
    # Unit test for function ansible_facts

    # set the module args
    stdout = StringIO()
    sys.stdout = stdout
    sys.argv = ['/path/to/ansible/lib/ansible/module_utils/facts/ansible_facts.py',
                '--filter', '*_interface', '--gather_subset', 'network']

# Generated at 2022-06-22 22:52:43.874558
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace as m_facts_namespace
    import ansible.module_utils.facts.system.distribution as m_facts_distribution
    import ansible.module_utils.facts.system.platform as m_facts_platform

    # create stubs for module and config objects
    class AnsibleModuleStub():
        def __init__(self, params={}):
            self.params = params

    ansible_parameters = {'gather_subset': ['all']}
    # create stub module
    module = AnsibleModuleStub(ansible_parameters)

    # stub out the collector subclasses
    class StubDistributionCollector(m_facts_distribution.Distribution):
        def collect(self, module=None):
            self.fact_name = 'distribution'
           

# Generated at 2022-06-22 22:52:54.596685
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.utils import _normalize_to_dict  # pylint: disable=protected-access

    # This test needs to run against a module that has _ansible_version set to at least 2.3
    from ansible.modules.system.setup import _ansible_version  # pylint: disable=import-error

    # The prefered way to subscript a dict in py2 is dict[key]
    # In py3 dict.get(key) is prefered.
    try:
        dict[None]
        def _get_key(d, key):
            return d[key]
    except TypeError:
        def _get_key(d, key):
            return d.get(key, None)

    # Gather all the facts
    facts = get_all_facts(module=None)

# Generated at 2022-06-22 22:53:04.309542
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for get_all_facts

    2.0/2.1 does not except a gather_subset arg.
    2.3/2.3 expects a gather_subset arg.

    So make gather_subsets an optional arg, defaulting to configured DEFAULT_GATHER_TIMEOUT

    This test requires mock.
    '''

    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import Mock as MagicMock

    module = MagicMock()
    module.params = {'gather_subset': ['all']}

    facts = get_all_facts(module=module)

    assert 'default_ipv4' in facts

# Generated at 2022-06-22 22:53:11.579026
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import pprint
    import pytest
    import unittest

    class FakeModule:
        params = {'gather_subset': ['all']}

    # test with a test module that includes only a few facts to keep runtime down
    facts = ansible_facts(FakeModule())

    # TODO: create a real unit test for the ansible_facts function,
    # using an instance of AnsibleModule with a mocked GatherFactsCollector.
    assert facts['distribution'] == 'Ubuntu'

# Generated at 2022-06-22 22:53:19.743529
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector.hardware.dmi import DmiCpuCollector
    from ansible.module_utils.facts.collector.hardware.lspci import LspciCollector
    from ansible.module_utils.facts.collector.virtual.openvz import OpenVzCollector

    # Unit test for function ansible_facts
    class MockModule():
        def __init__(self, module_name, params={}):
            self.name = module_name
            self.params = params

    # assume fact gathering on any Linux system with these files
    assert '/proc/cpuinfo' in open('/proc/filesystems').read()