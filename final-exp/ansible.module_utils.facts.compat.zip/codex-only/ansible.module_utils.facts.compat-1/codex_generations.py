

# Generated at 2022-06-22 22:43:24.318582
# Unit test for function ansible_facts
def test_ansible_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['all']),
            gather_timeout=dict(type='int', default=10),
            filter=dict(type='str', default='*')
        )
    )

    # run it
    results = ansible_facts(module)
    print("result: %s" % results)

# Generated at 2022-06-22 22:43:35.306999
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import facts
    from ansible.module_utils.facts import default_collectors

    #
    # get_all_facts(self, module), for 2.2/2.3
    #    module.params['gather_subset'] (optional list of fact subsets to collect)
    #
    # ensure gather_subset param is optional
    mod1 = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert len(get_all_facts(mod1)) > 0

    # ensure 'all' is not collected when gather_subset is not specified
    mod1 = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert 'all' not in get_all_facts(mod1)



# Generated at 2022-06-22 22:43:47.300129
# Unit test for function ansible_facts
def test_ansible_facts():

    try:
        from ansible.module_utils.facts.collector import _collect_subset
    except ImportError:
        return False, "Unable to find ansible.module_utils.facts.collector"

    try:
        from ansible.module_utils.facts.namespace import PrefixFactNamespace
        from ansible.module_utils.facts.utils import get_mount_size
    except ImportError:
        return False, "Unable to find ansible.module_utils.facts.namespace"

    from ansible.module_utils.facts.utils import get_filesystem_info

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import get_all_facts

# Generated at 2022-06-22 22:43:57.393694
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import module_specific_facts
    from ansible.module_utils.facts import namespace_to_prefix
    from ansible.module_utils.facts import fallback_facts_collector
    from ansible.module_utils.facts import filter_collection

    # These are the fact collectors that are expected to run by default when
    # the 'gather_subset' (formerly 'gather_facts') option is set to 'all'

# Generated at 2022-06-22 22:43:58.081189
# Unit test for function get_all_facts

# Generated at 2022-06-22 22:44:09.325546
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        '''class representing an AnsibleModule, so that
        ansible_facts() can be unit tested.'''

        def __init__(self, params):
            self.params = params
            # not sure what collector expects for these
            # but they aren't relevant to this test
            self._socket_path = None
            self._terminal = None
            self._binary_test_dir = None
            self._binary_test_file = None


# Generated at 2022-06-22 22:44:19.626421
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit test for ansible_facts compat api'''

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    # test default case
    tm = TestModule()
    assert 'ansible_all_ipv4_addresses' in ansible_facts(tm)

    # test that a gather_subset param filters facts
    tm = TestModule(gather_subset=['network'])
    assert 'ansible_all_ipv4_addresses' in ansible_facts(tm)
    assert 'ansible_machine_id' not in ansible_facts(tm)
    assert 'ansible_processor_cores' not in ansible_facts(tm)

    # test the filter_spec param

# Generated at 2022-06-22 22:44:29.621484
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.facts.system.distribution as distribution

    module = AnsibleModule()
    test_distro = distribution.Distribution()

    distro_data = {
        'distribution': 'ubuntu',
        'distribution_release': 'trusty',
        'distribution_version': '14.04',
    }
    distribution.Distribution.distro = distro_data

    facts = ansible_facts(module)
    assert(facts['distribution'] == 'Ubuntu')
    assert(facts['distribution_release'] == 'trusty')
    assert(facts['distribution_version'] == '14.04')

# Generated at 2022-06-22 22:44:35.158863
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts

    gather_subset = ['all']
    fact_cache = get_all_facts(gather_subset)

    for fact in fact_cache:
        assert fact_cache[fact]

    gather_subset = ['network', 'hardware']
    fact_cache = get_all_facts(gather_subset)

    for fact in fact_cache:
        assert fact_cache[fact]

    gather_subset = ['fake']
    fact_cache = get_all_facts(gather_subset)

    assert fact_cache is {}

# Generated at 2022-06-22 22:44:39.565460
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    module = MockModule()
    fact_dict = get_all_facts(module)
    assert 'system' in fact_dict
    assert 'default_ipv4' in fact_dict
    assert 'facter_ipaddress_lo' not in fact_dict


# Generated at 2022-06-22 22:44:49.605128
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import DEFAULT_GATHER_SUBSET
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.facts import FACT_CACHE

    # test that get_all_facts calls ansible_facts with a gather_subset
    module_mock = MagicMock(
        params={'gather_subset': ['all']}
    )
    get_all_facts(module_mock)
    ansible_facts.assert_called_with(module_mock, gather_subset=['all'])

    # test that get_all_facts calls ansible_facts with default gather_subset if not set
    ansible_facts.reset_mock()

# Generated at 2022-06-22 22:45:00.890953
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts import ansible_collector

    # create a mock module_utils.basic.AnsibleModule for unit test
    class FakeModule():
        def __init__(self, **kwargs):
            self.params = ImmutableDict(kwargs)

    # create fake facts
    def fake_collect_func(module=None):
        fake_facts = {'foo': 'bar'}
        return fake_facts

    # create a mock ansible_collector.FactCollector
    class FakeFactCollector():
        def __init__(self, **kwargs):
            self.all_collector_classes = kwargs.get('all_collector_classes', [])

# Generated at 2022-06-22 22:45:10.828946
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from difflib import unified_diff
    import doctest

    # mock AnsibleModule to use
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    # mock AnsibleModule.fail_json
    def fail_json(msg):
        fail_json.msg = msg
    fail_json.msg = None

    # mock AnsibleModule.exit_json
    def exit_json(**kwargs):
        exit_json.kwargs = kwargs
    exit_json.kwargs = None

    #

# Generated at 2022-06-22 22:45:23.059484
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    import pytest
    from tests.unit.module_utils.facts.test_ansible_collector import TestGatherSubset

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    test_module = TestModule({'gather_subset': ['all'], 'gather_timeout': 10,
                              'filter': '*'})

    collector_classes = [TestGatherSubset]
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-22 22:45:30.431768
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.facts as facts

    class FakeAnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': [
                '!all',
                'min',
                '!network',
                '!hardware'
            ]}

    module = FakeAnsibleModule()
    # Patch it to use the facts module under test
    module.module_utils.facts = facts
    facts_dict = get_all_facts(module)
    assert facts_dict['distribution'] == 'Raspbian GNU/Linux'
    assert 'devices' not in facts_dict

# Generated at 2022-06-22 22:45:33.983370
# Unit test for function get_all_facts
def test_get_all_facts():
    class AnsibleModuleMock(object):
        def __init__(self, params):
            self.params = params

    module = AnsibleModuleMock(params={'gather_subset':['all']})
    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert len(facts) > 0


# Generated at 2022-06-22 22:45:39.440901
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts import module_finds_facter
    from ansible.module_utils.facts import module_finds_ohai
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.fips import FipsFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.fips import FipsFactCollector
    from ansible.module_utils.facts.system.system import SystemFactCollector

# Generated at 2022-06-22 22:45:46.745635
# Unit test for function ansible_facts
def test_ansible_facts():
    import time
    import random
    import pytest
    from ansible.module_utils.facts.utils import FactsCollector

    # 2.3 module_utils.facts.get_all_facts method expects a module instance with 'gather_subset' param
    class DummyModule(object):
        def __init__(self, gather_subset=None):
            self.params = {'gather_subset': gather_subset, 'gather_timeout': 1}

    class DummyFactCollector(FactsCollector):
        _COLLECTORS = ()

        def collect(self, module):
            time.sleep(0.1)
            return {'fact_name': "fact_value"}

    # Mock facts.utils.AnsibleFactCollector which will be used by
    #  ansible.module_utils.facts.

# Generated at 2022-06-22 22:45:51.459471
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    # ansible_module is method of AnsibleModule
    # cs_module is method of AnsibleModule
    m_instance = mock.Mock()
    assert get_all_facts(m_instance) == ansible_facts(m_instance)
    assert m_instance.params['gather_subset'] == ['all']

test_get_all_facts()

# Generated at 2022-06-22 22:45:56.563575
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import module_utils
    test_module = module_utils.get_module_utils('basic').AnsibleModule(argument_spec={})
    ansible_facts_dict = get_all_facts(test_module)
    assert isinstance(ansible_facts_dict, dict)


# Generated at 2022-06-22 22:45:58.117905
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import Facts

    get_all_facts(Facts())

# Generated at 2022-06-22 22:46:04.356405
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_text
    import sys

    if sys.version_info.major < 3:
        from ansible.module_utils.facts import module_provisioner
        class StubModule():
            def __init__(self, gather_subset):
                self.params = {'gather_subset': gather_subset}
                self.ansible_facts = {}
                self.resource_facts = {}
                self.provisioned_facts = {}
                self.deprecations = []
                self.fail_json_msg = None
                self.fail_json = False
                self.exit_args = None
        m = StubModule(None)
        module_provisioner.set_provisioning_facts(m)

# Generated at 2022-06-22 22:46:15.766002
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import os
    import yaml
    from ansible.module_utils._text import to_text

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # Same code as ansible_debug.py
    mock_module = AnsibleModuleMock()
    mock_module.params = {
        'gather_subset': '!all',
        'gather_timeout': 5,
    }

    facts_dict = get_all_facts(mock_module)

    the_real_ansible_module = AnsibleModuleMock()

# Generated at 2022-06-22 22:46:25.103242
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.cache import FactsCache
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    import ansible.module_utils.facts.logical_disk as logical_disk_collector
    import ansible.module_utils.facts.system as system_collector
    import ansible.module_utils.facts.system_hw as system_hw_collector
    import ansible.module_utils.facts.virtual as virtual_collector

    import tempfile

    import json

    # construct a mock AnsibleModule class

# Generated at 2022-06-22 22:46:31.267880
# Unit test for function ansible_facts
def test_ansible_facts():
    """
    Unit test for function ansible_facts
    """
    # Mock instance of an AnsibleModule
    class AnsibleModule(object):
        def __init__(self):
            self.params = {}

    module = AnsibleModule()
    module.params = {'gather_subset': ['all'], 'gather_timeout': 10, 'filter': '*'}
    result = ansible_facts(module)

    assert isinstance(result, dict)

# Generated at 2022-06-22 22:46:38.617710
# Unit test for function ansible_facts
def test_ansible_facts():
    # import here so that this test can be ran independently of ansible
    from ansible.module_utils.basic import AnsibleModule

    # create a fake module
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all'])})

    # fetch all facts
    ansible_facts = ansible_facts(module)

    # make sure some expected facts are found
    assert 'local' in ansible_facts

    assert ansible_facts['local']['hostname'] is not None
    assert ansible_facts['local']['fqdn'] is not None
    assert ansible_facts['local']['domain'] is not None

    assert 'network' in ansible_facts
    assert ansible_facts['network'] != {}

# Generated at 2022-06-22 22:46:43.275570
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactsNamespace

    class TestModule:
        def fail_json(self, name, msg):
            assert False, (name, msg)
        def params(self):
            return {'gather_subset': ['!all', '!min']}

    module = TestModule()

    collector_classes = [MockCollector]


# Generated at 2022-06-22 22:46:50.775732
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collection import get_distribution

    distribution = get_distribution()
    if distribution == 'Fedora':
        expected_facts = {'lsb': {u'id': u'Fedora', u'version': u'24'},
                          'pkg_mgr': u'dnf',
                          'service_mgr': u'systemd'}
    else:
        expected_facts = {'lsb': {u'id': u'Ubuntu', u'version': u'16.04'},
                          'pkg_mgr': u'apt',
                          'service_mgr': u'upstart'}

# Generated at 2022-06-22 22:47:01.711818
# Unit test for function ansible_facts
def test_ansible_facts():

    import os
    import json
    import tempfile
    from ansible.module_utils.facts import ansible_facts

    # make a tempfile that acts like a module
    class DummyAnsibleModule:
        def __init__(self, params, **kwargs):
            self.params = dict()
            self.params.update(params)
            for k, v in kwargs.items():
                setattr(self, k, v)

    tmp_file, tmp_path = tempfile.mkstemp()
    os.close(tmp_file)

    # minimal_gather_subset is an internal parameter.  Fact collector uses it to calculate which
    # collectors are required, when running in minimal mode.
    # If a module_utils.facts.ansible_facts call doesn't set it, then it's value will be set to

# Generated at 2022-06-22 22:47:12.498496
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    module = AnsibleModule({'gather_subset': ['!all', 'network']})
    gather_subset = module.params['gather_subset']
    gather_timeout = module.params.get('gather_timeout', 10)
    filter_spec = module.params.get('filter', '*')


# Generated at 2022-06-22 22:47:19.205233
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import json

    environ = {'ANSIBLE_SYSTEM_WARNINGS': 'false', 'ANSIBLE_FACT_CACHE': '/tmp',
               'ANSIBLE_CACHE_PLUGIN': 'jsonfile', 'ANSIBLE_CACHE_PLUGIN_CONNECTION': '',
               'ANSIBLE_STDOUT_CALLBACK': 'debug', 'ANSIBLE_CONFIG': '',
               'PYTHONUNBUFFERED': '1', 'PATH': '/usr/bin:/bin:/usr/sbin:/sbin:/opt/aws/bin'}

    for k in environ:
        if k not in os.environ:
            os.environ[k] = environ[k]

    from ansible.module_utils import basic

# Generated at 2022-06-22 22:47:24.600447
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(gather_subset=dict(required=False, type='list', default=None)),
                           supports_check_mode=True)

    # test any dict returned
    assert isinstance(get_all_facts(module), dict)


# Generated at 2022-06-22 22:47:25.829031
# Unit test for function get_all_facts
def test_get_all_facts():
    pass

# Generated at 2022-06-22 22:47:27.310409
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' unit test for function ansible_facts'''
    pass

# Generated at 2022-06-22 22:47:40.094886
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import textwrap
    import json

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    from ansible.module_utils.facts import ansible_collector


    class FakeAnsibleModule(object):

        def __init__(self, gather_subset='all'):
            self.params = {'gather_subset': gather_subset}

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return executable

    class EmptyDistributionFactCollector(DistributionFactCollector):

        def get_facts(self):

            return {}

        # Run this test on any platform
        @classmethod
        def platform_requirements_met(cls):

            return True

    def test_fact_namespace():
        facts

# Generated at 2022-06-22 22:47:52.056100
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.collector

    # Create a mock ansible module object
    from ansible.modules.system import setup
    from ansible.utils.module_docs import get_docstring
    m = setup._AnsibleModule(argument_spec={
        'filter': {'required': False, 'type': 'str'},
        'gather_subset': {'required': False, 'type': 'list'},
        'gather_timeout': {'default': 10, 'type': 'int'},
    }, supports_check_mode=False)
    m.params = ansible.module_

# Generated at 2022-06-22 22:47:52.633674
# Unit test for function get_all_facts
def test_get_all_facts():
    pass

# Generated at 2022-06-22 22:48:00.472575
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    if sys.version_info[0] == 2:
        import imp
        try:
            imp.find_module('ansible_module_test')
            skip = False
        except ImportError:
            skip = True
    else:
        from importlib import util
        if util.find_spec("ansible_module_test"):
            skip = False
        else:
            skip = True
    if skip:
        return
    from ansible_module_test import AnsibleModule


# Generated at 2022-06-22 22:48:00.892264
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-22 22:48:12.184623
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.network.base as base
    import ansible.module_utils.facts.network.generic as generic
    import ansible.module_utils.facts.network.ios as ios
    import ansible.module_utils.facts.network.iosxr as iosxr
    import ansible.module_utils.facts.network.nxos as nxos
    import ansible.module_utils.facts.network.junos as junos
    import ansible.module_utils.facts.network.linux as linux
    import ansible.module_utils.facts.network.eos as eos
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    # test ansible_facts() with a minimal gather_subset

# Generated at 2022-06-22 22:48:24.765518
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    def get_all_collectors(gather_subset=None, fact_filter=None, namespace=None, collectors=None):
        '''returns a subset of AnsibleModule.get_all_collectors, based on the params.'''
        if collectors is None:
            collectors = default_collectors.collectors
        if namespace is None:
            namespace = PrefixFactNamespace(namespace_name='ansible', prefix='ansible_')
        if gather_subset is None:
            gather_subset = ['all']
        if fact_filter is None:
            fact_filter = '*'


# Generated at 2022-06-22 22:48:30.535671
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''

    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    module = FakeModule()
    facts_dict = get_all_facts(module)
    assert type(facts_dict) == dict


# Generated at 2022-06-22 22:48:42.926898
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.implementation.linux import \
        DistributionFactCollector as Collector

    class MockModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    class MockDistro:
        name = 'RedHat'
        version = '6.3'

    class MockDistroCollector(Collector):
        """MockDistroCollector that returns a mock system distribution
        """
        @classmethod
        def get_distribution(cls):
            return MockDistro()

    facts = get_all_facts(MockModule(gather_subset=["all"]))
    assert 'distribution' in facts
    assert facts['distribution']['name'] == 'RedHat'

# Generated at 2022-06-22 22:48:43.506119
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-22 22:48:51.023271
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    # This is a bit of a hack; but ansible_facts() needs to import ansible_collector,
    #   which dynamically imports os_* collector classes, which will choke if any
    #   os_* classes are not importable.  We want to test that ansible_facts works
    #   on unsupported platforms, so we need to disable import of unsupported os_*
    #   collector classes so that the os_* collectors don't blow up when they
    #   get referenced in a test.
    # A better solution would be to refactor ansible_facts() so that we don't need
    #   to import ansible_collector.py, but that will be more work.

    from ansible.module_utils.facts.system.platform import LinuxFactCollector

# Generated at 2022-06-22 22:49:01.570407
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Unit test for module_utils.facts.ansible_facts '''

    # unit test the following.mechanics
    #   ansible_collector.get_ansible_collector
    #   ansible_collector.collect
    #   ansible_collector._merge_facts
    #   ansible_collector._write_debug_file
    #   default_collectors.collectors
    #   ansible_collector.get_namespace
    #   ansible_collector.get_bare_namespace_name
    #   PrefixFactNamespace.collect
    #   PrefixFactNamespace.namespace_name
    #   PrefixFactNamespace.prefix

    # stubs

# Generated at 2022-06-22 22:49:08.353337
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_text
    import json

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {
                'gather_subset': gather_subset,
            }

    # Return all facts
    subset_gather = ['all']
    fake_module = FakeModule(subset_gather)
    facts_dict = get_all_facts(fake_module)
    assert isinstance(facts_dict, dict)
    assert facts_dict['fqdn'] == 'localhost.localdomain'

    subset_gather = ['network', 'hardware']
    fake_module = FakeModule(subset_gather)
    facts_dict = get_all_facts(fake_module)

# Generated at 2022-06-22 22:49:17.602472
# Unit test for function ansible_facts
def test_ansible_facts():

    class AnsibleModule:
        class params:
            gather_subset = ['all']
            gather_timeout = 10
            filter = '*'

    try:
        # the real AnsibleModule class is only available in ansible 2.0 and above.
        from ansible.module_utils.facts import module_utils_loader
        AnsibleModule = module_utils_loader.get_ansible_module_instance()
    except ImportError:
        pass

    module = AnsibleModule()
    fact_dict = ansible_facts(module)

    # assert some fact is in the fact dict
    assert fact_dict['lsb']['distcodename'] == 'xenial'



# Generated at 2022-06-22 22:49:23.655628
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    test_params = dict(gather_subset='!all')
    test_ansible_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        check_invalid_arguments=False,
        bypass_checks=False,
        no_log=False,
        mutually_exclusive=None,
        required_together=None,
        required_one_of=None)

    test_ansible_module.params = test_params
    test_ansible_facts = ansible_facts(test_ansible_module)
    assert test_ansible_facts
    assert 'default_ipv4' in test_ansible_facts

# Generated at 2022-06-22 22:49:26.330616
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts

    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': '!all'}

    module = FakeModule()

    facts_dict = ansible_facts(module, ['!all'])
    assert facts_dict == {}



# Generated at 2022-06-22 22:49:35.464841
# Unit test for function get_all_facts
def test_get_all_facts():
    # Define Mock module for testing
    class MockModule(object):
        def __init__(self, gather_subset=None, gather_timeout=None, filter=None):
            self.params = {'gather_subset': gather_subset,
                           'gather_timeout': gather_timeout,
                           'filter': filter}

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return arg

    assert get_all_facts(MockModule())
    assert get_all_facts(MockModule(gather_subset=["all"]))
    assert not get_all_facts(MockModule(gather_subset=["not_valid_subset"]))
    assert get_all_facts(MockModule(gather_subset=["network"]))


# Generated at 2022-06-22 22:49:46.016630
# Unit test for function get_all_facts
def test_get_all_facts():
    _module = AnsibleModule(argument_spec=dict(gather_subset=dict(type='list', default=['all'])))
    _module.params['gather_subset'] = ['dns']

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors as orig_default_collectors
    from ansible.module_utils.facts import ansible_collector

    gather_subset = _module.params['gather_subset']
    all_collector_classes = orig_default_collectors.collectors
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-22 22:49:56.203279
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts

    verify that the compat method get_all_facts is compatible with
    ansible 2.2/2.3 get_all_facts and returns a dict mapping the bare fact name
    ('default_ipv4' with no 'ansible_' namespace) to the fact value.
    '''

    import sys
#    sys.path.append('../../../../lib/ansible/module_utils/facts')
#    sys.path.append('../../../../lib/ansible/module_utils/facts/collector')
    from ansible.module_utils.facts import get_all_facts, ansible_facts
    from ansible.module_utils import facts

    # ansible 2.0/2.1/2.2/2.3 facts/ansible_facts function expects a module arg


# Generated at 2022-06-22 22:50:05.556802
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        '''Fake module class to inittalize an AnsibleModule

        https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/basic.py
        '''

        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)

    # create a fake AnsibleModule
    module = FakeModule(['all'])
    # get all facts
    facts = ansible_facts(module)

    # perform checks
    assert 'ansible_lsb' in facts
    assert 'default_ipv4' in facts

# Generated at 2022-06-22 22:50:18.048321
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.nxos as nxos_facts
    from ansible.compat.tests import unittest

    class AnsibleModuleMock():
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    class test_get_all_facts(unittest.TestCase):
        def test_no_gather_subset(self):
            my_module = AnsibleModuleMock(['!config'])
            result = nxos_facts.get_all_facts(my_module)
            # This is a mock, so we can't expect any specific set of results
            # Just make sure it's a dict
            self.assertEqual(type(result), dict)


# Generated at 2022-06-22 22:50:28.861826
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule
    # We need to mock this function to avoid forking for testing
    def mock_get_bin_path(exe, opts=None, required=False):
        return ''

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    module.params = {
        'gather_subset': 'all',
        'gather_timeout': 2
    }

    # For now we just do some basic testing
    import platform
    facts = ansible_facts(module)

    assert facts['python']['version']['major'] == platform.python_version_tuple()[0]
    assert facts['python']['version']['minor'] == platform.python_version_

# Generated at 2022-06-22 22:50:34.871336
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Return value depends on ansible facts, so just validate return type
    '''
    from ansible.module_utils.facts import get_all_facts, ansible_facts
    from ansible.module_utils.basic import AnsibleModule

    module_fake = AnsibleModule({'gather_subset': ['all']})
    results = get_all_facts(module_fake)
    assert isinstance(results, dict)

    results = ansible_facts(module_fake)
    assert isinstance(results, dict)

    results = ansible_facts(module_fake, ['all', 'network'])
    assert isinstance(results, dict)

# Generated at 2022-06-22 22:50:45.186758
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Runs a unit test on get_all_facts

    If this is called from the command line, it will run its own unit test, and then exit.
    It it is imported as a module, it will return the dict of facts.

    It expects to be run in a dir containing the file test/unit/library/get_all_facts.py
    which contains a subclass of AnsibleModule.
    '''

    import sys
    import get_all_facts

    # if this file is being loaded as a module, then return the result of the get_all_facts
    # function.
    if __name__ != "__main__":
        return get_all_facts.get_all_facts(get_all_facts.AnsibleMockModule)

    # otherwise, run the unit test

    from test.unit.library import get_all_

# Generated at 2022-06-22 22:50:57.664124
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit test for ansible_facts function.
    '''

    # mock an AnsibleModule object to pass in
    class AnsibleModuleMock():
        def __init__(self):
            self.params = dict()

    module = AnsibleModuleMock()

    # get facts using default gather_subsets
    facts = ansible_facts(module)

    # test some basic stuff
    assert facts['distribution'] == 'CentOS'
    assert facts['distribution_version'] == '7'
    assert facts['distribution_major_version'] == '7'
    assert facts['python_version'] == '2.7.5'
    assert facts['selinux'] == False

    # test this fact is present
    assert ('fips' in facts)

    # specify gather_subset
    facts = ansible_

# Generated at 2022-06-22 22:51:09.239687
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    # for testing, build a mock module that returns the facts it is passed when the get_all_facts function is called.
    class MockModule(object):
        def __init__(self, fact_values=None, gather_subset=None):
            self.fact_values = fact_values
            self.params = dict(gather_subset=gather_subset)

    def get_all_facts(self):
        return self.fact_values

    def get_bin_path(self, executable, required=False, opt_dirs=[]):
        if executable == 'apparmor_parser':
            return '/sbin/apparmor_parser'

# Generated at 2022-06-22 22:51:14.594559
# Unit test for function get_all_facts
def test_get_all_facts():
    class Module(object):
        def __init__(self, params):
            self.params = params
    gather_subset = ['all']
    module = Module({'gather_subset': gather_subset})
    facts = get_all_facts(module)
    assert 'ansible_python' in facts


# Generated at 2022-06-22 22:51:25.086695
# Unit test for function ansible_facts
def test_ansible_facts():
    import mock
    import sys

    # Import module_utils.common.facts.ansible_collector for testing.
    # below code taken from ansible.module_utils.facts.ansible_collector
    # (which is not directly importable) and modified to work with namespace
    from ansible.module_utils.facts.ansible_collector import AnsibleFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

        # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    # this is a bit of a hack, but we can't really import the same module twice
    # in different namespaces and AnsibleModule is required for the collector
    # to resolve facts and validate the module args.

# Generated at 2022-06-22 22:51:30.037086
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Unit test for function get_all_facts
    '''

    mock_module = MagicMock()
    mock_module.params = dict(gather_subset=['all'])

    # Call the module
    actual_results = get_all_facts(module=mock_module)

    # Assert correct return type
    assert isinstance(actual_results, dict)



# Generated at 2022-06-22 22:51:30.440310
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-22 22:51:37.440087
# Unit test for function get_all_facts
def test_get_all_facts():

    # Arrange
    class AnsibleModule():
        def __init__(self, **kwargs):
            self.params = kwargs
    module = AnsibleModule(gather_subset=['all'])

    # Act
    facts = get_all_facts(module)

    # Assert
    assert isinstance(facts, dict)


# Generated at 2022-06-22 22:51:38.056519
# Unit test for function get_all_facts
def test_get_all_facts():
    pass

# Generated at 2022-06-22 22:51:49.740184
# Unit test for function ansible_facts
def test_ansible_facts():
    class MockModule(object):

        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

        def get_bin_path(self, executable, required=True, opt_dirs=None):
            if executable in ('date', 'hostname', 'uptime', '/bin/hostname'):
                return executable
            raise Exception(executable + ' not found')

    module = MockModule(['platform', 'network'])

    facts = ansible_facts(module, gather_subset=module.params['gather_subset'])
    assert 'platform' in facts
    assert 'network' in facts
    assert 'default_ipv4' in facts['network']

# Generated at 2022-06-22 22:52:00.579984
# Unit test for function ansible_facts
def test_ansible_facts():
    import platform
    import json

    class AnsibleModuleStub:
        def __init__(self,
                     params=None,
                     filter='*'):
            self.params = params if params else {
                'gather_subset': ['all'],
                'gather_timeout': 10,
                'filter': filter,
            }
            self.facts = dict()

        def exit_json(self, facts):
            self.facts = facts
            self.exit_args = {'changed': False}
            self.exit_called = True

    module_stub = AnsibleModuleStub()

    ansible_facts(module=module_stub)

    assert module_stub.exit_called
    assert 'ansible_system' in module_stub.facts

# Generated at 2022-06-22 22:52:10.530811
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.module_facts import ModuleFacts

    # Set up the module parameters
    module = ModuleFacts()
    module.params = dict(
        gather_subset=['all']
    )

    # full dict
    result = get_all_facts(module)
    assert isinstance(result, dict)

    # add another subset
    result = get_all_facts(module, ['network'])
    assert isinstance(result, dict)

    # add a fake subset
    result = get_all_facts(module, ['fake'])
    assert isinstance(result, dict)

# Generated at 2022-06-22 22:52:20.005059
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible import constants as C
    class ModuleMock(object):

        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = None
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, arg, required=False, opt_dirs=None):
            return '/usr/bin/python'

    m = ModuleMock()
    result = ansible_facts(m)

    # Test for python version
    assert result['python']['version']['full'] == C.DEFAULT_MODULE_UTILS_PATH + \
         '/ansible/module_utils/facts/facts.py'

# Generated at 2022-06-22 22:52:31.931754
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestFactCollector(BaseFactCollector):
        name = 'test_fact'
        _fact_ids = frozenset(['test1', 'test2'])
        _platform = 'all'

        def collect(self, module=None, collected_facts=None):
            return {'test1': 1, 'test2': 2}

    # stub out the 'cls.collector_classes' in ansible_collector.get_ansible_collector
    # so it will only have 'test_fact' collector, allowing us to test get_all_facts.
    ansible_collector.get_ansible_collector.collector_classes = [TestFactCollector]


# Generated at 2022-06-22 22:52:42.910001
# Unit test for function ansible_facts
def test_ansible_facts():

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # fake ansible module params
    module = FakeModule({
        'gather_subset': 'all',
        'gather_timeout': 10,
        'filter': '*',
    })

    # the list of all this module can gather, including custom ones
    all_fact_classes = default_collectors.collectors

    # set some custom facts to return.
    #
    # Values can also be functions returning the value
    # these functions can have a parameter for an AnsibleModule instance if needed.
    #
    # Values can also be classes (subclasses of AnsibleAbstractFactCollector)
    #
    # Values can also be a list of either of the above.
    #
    # If a value is a class or list

# Generated at 2022-06-22 22:52:53.555344
# Unit test for function ansible_facts
def test_ansible_facts():
    module = AnsibleModule(argument_spec={})

    facts = ansible_facts(module)


# Generated at 2022-06-22 22:53:04.622717
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts as module_utils_facts
    import ansible.module_utils.facts.system as module_utils_facts_system

    class FakeModule(object):
        class FakeNoopClass(object):
            @classmethod
            def to_string(cls, val):
                return val

        params = {'gather_subset': ['all']}
        noop_class = FakeNoopClass

        def get_option(cls, optname):
            return cls.params[optname]

    fake_module = FakeModule()


# Generated at 2022-06-22 22:53:15.309754
# Unit test for function get_all_facts
def test_get_all_facts():
    """Unit test for module_utils.facts.get_all_facts
    """
    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    class FakeModule2(object):
        class FakeModuleParams(object):
            def __init__(self, gather_subset):
                self.gather_subset = gather_subset
        def __init__(self, gather_subset):
            self.params = FakeModuleParams(gather_subset)

    for m in (FakeModule(gather_subset=['all']), FakeModule2(gather_subset=['all'])):
        result = get_all_facts(m)
        assert 'distribution' in result


# Generated at 2022-06-22 22:53:25.875456
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit test for function ansible_facts

    This test is to make sure that changes to the fact-gathering code do not
    break modules that rely on the ansible_facts fact.
    '''

    # Note: this is a "mock" module.
    #  It implements a small subset of AnsibleModule, only the things that AnsibleFacts needs.
    class MockAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    module = MockAnsibleModule()

    # In this basic test, we collect all defaults
    ansible_facts_only = ansible_facts(module)