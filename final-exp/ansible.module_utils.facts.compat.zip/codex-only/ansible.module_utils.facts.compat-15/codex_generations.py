

# Generated at 2022-06-22 22:43:29.581783
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.ansible_collector import AnsibleCollector
    from ansible.module_utils.facts.hardware.cpu import CPUCollector
    # monkey patch so we can know if this function was called.
    original_collector = CPUCollector()
    monkey_patched_collector_factory = lambda namespace: original_collector
    AnsibleCollector.get_collector_cls = monkey_patched_collector_factory
    import ansible.module_utils.facts.ansible_facts
    module = FakeAnsibleModule()
    facts = ansible_facts(module)

    # this should be called
    assert original_collector.was_called
    # this should not be called.
    assert not FakeHardwareCollector.was_called

    # here's what the first few keys in

# Generated at 2022-06-22 22:43:40.063474
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import get_collector_members

    try:
        from ansible.modules.system import setup as ansible231_setup_module
        from ansible.module_utils.facts import ansible_version, get_all_facts
    except ImportError:
        pass

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    # test get_collector_members
    got_collector_classes = get_collector_members()
    assert len(got_collector_classes) > 1
    assert got_collector_classes[0].__name__.endswith('CommandLine')

    # test get_ansible_collector
    got_collectors = default_collectors.collectors
    assert len(got_collectors) > 1

# Generated at 2022-06-22 22:43:47.819083
# Unit test for function ansible_facts
def test_ansible_facts():
    # Unit test function
    def run_ansible_module(ansible_args):
        from ansible.module_utils.facts import ansible_facts
        from ansible.module_utils.facts.collector import AnsibleCollector
        module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all']),
                                              'gather_timeout': dict(type='int', default=10),
                                              'filter': dict(type='str', default='*')})
        module.params.update(ansible_args)
        ansible_facts(module)
        return module.exit_json

    # Unit test for function ansible_facts
    # Test: 'all' subset, with no filter.

# Generated at 2022-06-22 22:43:57.423723
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import MemoryFactCollector
    from ansible.module_utils.facts.collector import BaseFileTextCollector
    import platform
    import os

    # dummy module to act as a mock AnsibleModule
    class MockAnsibleModule:
        def __init__(self):
            self.params = {}

    # mock class to collect facts
    class MockCollector(FactsCollector):
        def __init__(self, *args, **kwargs):
            self.value = kwargs.pop('value', 0)
            super(MockCollector, self).__init__(*args, **kwargs)

        def collect(self, module=None, collected_facts=None):
            facts_dict = super

# Generated at 2022-06-22 22:44:01.744122
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts

    # Mock module
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_facts

    handle, path = tempfile.mkstemp()


# Generated at 2022-06-22 22:44:10.539497
# Unit test for function ansible_facts
def test_ansible_facts():
    # pylint: disable=unused-argument
    class MockModule(object):
        def __init__(self, gather_subset, gather_timeout, filter_spec):
            self.params = {'gather_subset': gather_subset, 'gather_timeout': gather_timeout, 'filter': filter_spec}

    module = MockModule(gather_subset=['all'], gather_timeout=30, filter_spec='*')
    fact_dict = ansible_facts(module=module)
    assert fact_dict

# Generated at 2022-06-22 22:44:16.094248
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import cache
    cache.FACTS_CACHE = 'shippable/ansible_facts.fact_cache'

    class MockModule(object):
        def __init__(self):
            self.params = {'filter': 'ansible_lsb', 'gather_subset': None, 'gather_timeout': 2}

    module = MockModule()
    facts = ansible_facts(module)

    assert facts.get('lsb')

# Generated at 2022-06-22 22:44:24.385775
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import load_collectors
    from ansible.module_utils.facts.collector.system import SystemLegacyCollector
    from ansible.module_utils.facts.collector.distribution import DistributionLegacyCollector

    class TestModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    test_module = TestModule()
    all_collectors = load_collectors()
    all_collectors[0] = SystemLegacyCollector
    all_collectors[2] = DistributionLegacyCollector
    ansible_facts = ansible_facts(test_module, gather_subset=['all'])

    assert type(ansible_facts) is dict
    assert type(ansible_facts['distribution']) is dict

# Generated at 2022-06-22 22:44:30.387607
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    module = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['all']),
            gather_timeout=dict(type='int', default=10),
            filter=dict(type='str', default='*')
        )
    )
    # run the module
    factsDict = ansible_facts(module)

    # Test each of the returned facts
    assert 'system' in factsDict
    assert 'distribution' in factsDict
    assert 'distribution_release' in factsDict
    assert 'distribution_version' in factsDict
    assert 'virtualization_type' in factsDict

# Generated at 2022-06-22 22:44:32.143168
# Unit test for function get_all_facts
def test_get_all_facts():
    assert get_all_facts(default_collectors.ALL_SUBSETS) == ansible_facts(default_collectors.ALL_SUBSETS)

# Generated at 2022-06-22 22:44:35.126111
# Unit test for function get_all_facts
def test_get_all_facts():
    module = MockAnsibleModule(gather_subset='all')
    assert(get_all_facts(module) == ansible_facts(module, gather_subset='all'))


# Generated at 2022-06-22 22:44:35.705412
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-22 22:44:43.104228
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.utils import dict_merge

    # Mock up some dummy ansible facts and a minimal mocked ansible module object
    # to test ansible_facts with

    # Make some test facts
    test_facts = {
        'test_fact_1': 'test_fact_1_value',
        'test_fact_2': 'test_fact_2_value',
        'test_fact_3': 123,
    }

    # Make a minimal mocked ansible module object
    class MockAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = ImmutableDict(kwargs)

    mocked_module = Mock

# Generated at 2022-06-22 22:44:47.200606
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import importlib

    # unit tests should not make network connections
    import requests
    try:
        importlib.reload(requests)
    except AttributeError:
        reload(requests)

    class MockModule(object):
        params = {'gather_subset': 'min'}


    print('Testing on Python %s' % sys.version)
    facts_dict = get_all_facts(MockModule)
    print(facts_dict)


if __name__ == '__main__':
    test_get_all_facts()

# Generated at 2022-06-22 22:44:59.587713
# Unit test for function ansible_facts
def test_ansible_facts():
    '''test for ansible_facts. Requires a running docker daemon'''

    import pytest
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector

    # 1. check that ansible_facts has been imported correctly and is callable
    # 2. check that it returns a dict
    # 3. check that some key/value pairs are present in the dict as expected
    pytest.importorskip('docker')
    import docker

    client = docker.from_env()
    info = client.info()
    ID = info.get('ID')
    arch = info.get('Architecture')
    os = info.get('OSType')

    # mock the module and gather_subset so we can test ansible_facts without
    # actually

# Generated at 2022-06-22 22:45:09.901188
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.test_collector import TestAnsibleModule
    from ansible.module_utils.facts.test_ansible_facts import TestFactsCollector
    from ansible.module_utils.facts.test_ansible_facts import TestGatherTimeoutFactCollector
    import sys

    assert hasattr(TestAnsibleModule, 'get_ansible_facts')

    results = TestAnsibleModule.get_ansible_facts()

    assert 'name' in results
    assert results['name'] == 'dummy'

    # verify that if we pass in an custom fact_collector_class, we get the expected results
    results = TestAnsibleModule.get_ansible_facts(fact_collector_class=TestFactsCollector)
    assert 'name' in results

# Generated at 2022-06-22 22:45:12.746429
# Unit test for function ansible_facts
def test_ansible_facts():
    '''ansible_facts function test'''

    from ansible.module_utils.facts import version_info
    assert version_info.__version__ is not None

# Generated at 2022-06-22 22:45:24.687319
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Parametrized unit test for function ansible_facts
    '''

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils import facts

    fact_collectors = ansible_collector.get_all_collector_classes()
    default_collectors = facts.default_collectors.collectors

    # We need to make sure we have the same number of fact collectors for the test to be meaningful
    assert len(fact_collectors) == len(default_collectors)

    # Using mock to emulate 'module' instance
    import mock

    # We need to make sure we have the same number of fact collectors for the test to be meaningful
    assert len(fact_collectors) == len(default_collectors)

    # Trying to emulate AnsibleModule class object instance

# Generated at 2022-06-22 22:45:32.766195
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Unit test for ansible_facts method.

    This test verifies that the ansible facts collector returns a facts dict from
    the 'ansible_facts' namespace
    '''

    from ansible.module_utils.facts import ansible_facts

    class FakeModule:
        def __init__(self):
            self.params = {}

    fake_module = FakeModule()
    facts = ansible_facts(module=fake_module, gather_subset=['all'])

    assert isinstance(facts, dict)

    if 'ansible_facts' in facts:
        return

    assert False, 'ansible facts collector did not return facts dictionary with ansible_facts prefix '

# Generated at 2022-06-22 22:45:38.619124
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import Namespace

    class AnsibleModule:
        def __init__(self, params=None):
            self.params = params

    class Collector(Namespace):
        def collect(self, module=None):
            return {'ansible_a': 'a'}

        @property
        def name(self):
            return 'test_collector'

    all_collector_classes = [Collector]

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    # all_collector_classes, gather_subsets, filter_spec can all be none, since we're
    # only testing that 'get_all_facts' works

    # don't use minimal_gather_subset since this test doesn't test for

# Generated at 2022-06-22 22:45:46.506150
# Unit test for function ansible_facts
def test_ansible_facts():
    # create a fake module instance so we can pass it to ansible_facts()
    class FakeModule(object):
        def __init__(self, params=None):
            if params:
                self.params = params
            else:
                self.params = {}

    # test default values
    fake_module = FakeModule()
    expected_subset = ['all']
    expected_timeout = 10
    expected_filter = '*'
    module_facts = ansible_facts(fake_module)
    assert module_facts['gather_subset'] == expected_subset
    assert module_facts['gather_timeout'] == expected_timeout
    assert module_facts['filter'] == expected_filter

    # test overrides for gather_subset, gather_timeout, and filter

# Generated at 2022-06-22 22:45:57.958179
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    unit test for ansible_facts
    '''
    def mock_param(key, default=None):
        '''
        mock get_param for a module instance
        '''
        return {
            'gather_subset': ['all'],
            'gather_timeout': 10,
            'filter': '*'
        }.get(key, default)

    class MockModule:
        '''
        mock module object for unit testing
        '''
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10

        def get_option(self, key):
            '''
            mock get_option for a module instance
            '''

# Generated at 2022-06-22 22:46:04.355908
# Unit test for function ansible_facts
def test_ansible_facts():

    # unit test for a few different filter specs
    filter_specs = ['ansible_mem*', 'ansible_*', 'ansible_mem*',
                    'ansible_mem*', 'ansible_date_time', 'ansible_date_time',
                    'ansible_date_time', 'ansible_date_time', 'ansible_architecture',
                    'ansible_architecture', 'ansible_architecture']

    for filter_spec in filter_specs:
        import ansible.module_utils.facts.ansible_facts as ansible_facts
        import ansible.module_utils.facts.namespace as namespace


# Generated at 2022-06-22 22:46:15.350520
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils._text import to_bytes

    # Additional required module for the test
    import os

    # Use a mock ansible module
    test_module = Facts()
    test_module.params = {'gather_subset': ['all']}

    # Add a test fact
    if os.name != 'nt':
        # Ensure SElinux on this system is in Permissive mode, otherwise facts won't be available
        os.setenvironb(to_bytes('ANSIBLE_SELINUX_FACT', encoding='utf-8'), to_bytes('Permissive', encoding='utf-8'))
        facts_dict = get_all_facts(test_module)
        assert 'ansible_form_factor' in facts_dict

# Generated at 2022-06-22 22:46:16.839791
# Unit test for function get_all_facts

# Generated at 2022-06-22 22:46:20.350206
# Unit test for function get_all_facts
def test_get_all_facts():

    try:
        from ansible.modules.system import setup
    except:
        from ansible.module_utils.facts import ansible_facts
        return ansible_facts(dict())
    return setup.get_all_facts(dict())

# Generated at 2022-06-22 22:46:27.805122
# Unit test for function get_all_facts
def test_get_all_facts():
    # We are using the AnsibleModule class for testing purposes only.
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'gather_subset': ['all']})
    ansible_facts_dict = ansible_facts(module)

    assert isinstance(ansible_facts_dict, dict)
    assert 'distribution' in ansible_facts_dict
    assert 'distribution_release' in ansible_facts_dict

    module = AnsibleModule({'gather_subset': ['min'], 'gather_timeout': 5})
    ansible_facts_dict = ansible_facts(module)

    assert isinstance(ansible_facts_dict, dict)
    assert 'distribution' in ansible_facts_dict
    assert 'distribution_release' not in ansible_facts_dict

# Generated at 2022-06-22 22:46:36.650235
# Unit test for function get_all_facts
def test_get_all_facts():
    import pytest
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts import ansible_collector


# Generated at 2022-06-22 22:46:47.604890
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # mocks
    class MockAnsibleModule():
        def __init__(self, params):
            self.params = params

    class MockFactCollector():
        def __init__(self, facts_dict):
            self.facts_dict = facts_dict

        def collect(self, module):
            return self.facts_dict

    class MockAnsibleCollector():
        def __init__(self, facts_dict):
            self.facts_dict = facts_dict


# Generated at 2022-06-22 22:46:53.253465
# Unit test for function ansible_facts
def test_ansible_facts():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    module = MockModule(params={'gather_subset': ['all']})

    result = ansible_facts(module)
    assert isinstance(result, dict)

# Generated at 2022-06-22 22:47:04.748726
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.collector import Collector

    # Mock up an AnsibleModule
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}

    module = MockAnsibleModule()

    # Mock up a DistributionFactCollector

# Generated at 2022-06-22 22:47:09.967312
# Unit test for function get_all_facts
def test_get_all_facts():
    gather_subset = ['all']
    class AnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': gather_subset}

    module = AnsibleModule()
    ansible_facts(module, gather_subset=gather_subset)

# Generated at 2022-06-22 22:47:17.743690
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts

    We're not testing the internals of the fact gathering code, but that the
    get_all_facts function is a public api for the fact gathering code.
    '''

    from ansible.module_utils.facts import ansible_facts

    module = mock.Mock()
    module.params = dict(gather_subset=['network', 'hardware'])

    facts_dict = get_all_facts(module)
    # facts_dict should be a dict of facts.
    assert isinstance(facts_dict, dict)

    # facts_dict should have a fact named 'default_ipv4'
    assert 'default_ipv4' in facts_dict
    # facts_dict['default_ipv4'] should be a dict.

# Generated at 2022-06-22 22:47:29.028024
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts as fact_collector
    # create a mock AnsibleModule that has no params
    class MockModule(object):
        def __init__(self):
            self.params = {}

    mock_module = MockModule()
    facts = fact_collector(mock_module, load_on_init=False)

    assert isinstance(facts, dict)
    assert 'distribution' in facts
    assert 'distribution_version' in facts
    assert 'distribution_release' in facts
    assert 'ansible_all_ipv4_addresses' in facts
    assert 'ansible_architecture' in facts
    assert 'ansible_bios_date' in facts

# Generated at 2022-06-22 22:47:41.455883
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit test function for function ansible_facts
    '''
    #
    # Create a mock AnsibleModule
    #
    params = dict()
    params['command'] = 'setup'
    params['filter'] = ''
    params['-i'] = 'inventory'
    params['_ansible_version'] = '2.0.0.2'
    params['gather_subset'] = ['all']
    params['gather_timeout'] = 10
    params['_ansible_no_log'] = False
    params['_ansible_debug'] = False
    params['_ansible_verbosity'] = 0
    params['args'] = {'verbosity': 0, 'inventory': '/etc/ansible/hosts', '_ansible_version': '2.0.0.2'}

# Generated at 2022-06-22 22:47:49.778603
# Unit test for function ansible_facts
def test_ansible_facts():

    # create a mock AnsibleModule. AnsibleModule is normally created automatically by Ansible
    # when running a module.
    class AnsibleModuleMock(object):
        def __init__(self, params=None):
            if params is None:
                params = {}
            self.params = params

    module = AnsibleModuleMock({'gather_subset': ['all']})

    facts_dict = ansible_facts(module, module.params['gather_subset'])

    assert facts_dict
    assert 'default_ipv4' in facts_dict

# Generated at 2022-06-22 22:47:58.632110
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible

    # Create a mock ansible module
    class MockAnsibleModule:
        def __init__(self, *args, **kwargs):
            self.params = kwargs

    class MockAnsibleModuleWithGather:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    # Create a dummy fact collector method
    def dummy_collect(self, module=None):
        return {'ansible_dummy_fact': 'dummy_fact_value'}

    # Monkey patch the list of fact collectors.
    default_collectors.collectors = [('dummy', AnsibleCollectorDummy)]

    # Create an AnsibleCollectorDummy object which calls the dummy_collect method

# Generated at 2022-06-22 22:48:11.341344
# Unit test for function ansible_facts
def test_ansible_facts():
    import mock
    import sys

    facts = ansible_facts(gather_subset=['all'])

    assert facts is not None
    assert isinstance(facts, dict)
    assert len(facts) > 0

    assert 'architecture' in facts

    assert 'os_family' in facts
    assert facts['os_family'] in ['RedHat', 'Debian', 'Suse']

    assert 'kernel' in facts
    assert facts['kernel'] in ['Linux', 'SunOS', 'FreeBSD']

    assert 'distribution' in facts
    assert facts['distribution'] in ['CentOS', 'Ubuntu', 'Debian', 'Suse', 'OracleLinux', 'Darwin', 'OpenBSD', 'FreeBSD', 'NetBSD', 'Gentoo', 'Archlinux', 'Alpine', 'MacOSX']



# Generated at 2022-06-22 22:48:21.374508
# Unit test for function get_all_facts
def test_get_all_facts():
    module = DummyAnsibleModule()
    module.params = {
        'gather_subset': ['!all', '!min'],
    }
    facts = get_all_facts(module)
    assert isinstance(facts, dict), 'get_all_facts does not return a dict'
    assert len(facts) > 0, 'get_all_facts returnes an empty dict'
    # Just check for one fact
    assert 'default_ipv4' in facts, 'default_ipv4 fact is not returned by get_all_facts'



# Generated at 2022-06-22 22:48:23.597992
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts as facts
    facts.ansible_facts = ansible_facts
    import ansible.module_u

# Generated at 2022-06-22 22:48:25.072511
# Unit test for function get_all_facts
def test_get_all_facts():
    # TODO: Test get_all_facts.
    # How to mock AnsibleModule class + params?
    pass


# Generated at 2022-06-22 22:48:32.468144
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import ConfigFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.ansible_collector import AnsibleCollector

    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['all'], 'filter': '*'}

    class FakeCollector:
        def __init__(self):
            pass

        def collect(self, module=None):
            return {'fact1': 'value1', 'fact2': 'value2'}

    test_module = FakeModule()
    all = get_all_facts(test_module)
    assert all.get('fact1') == 'value1'

# Generated at 2022-06-22 22:48:39.752860
# Unit test for function get_all_facts
def test_get_all_facts():

    class MockAnsibleModule:
        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)

    module = MockAnsibleModule(gather_subset=['network'])
    facts = get_all_facts(module)
    assert 'network' in facts

    module = MockAnsibleModule(gather_subset=['all'])
    facts = get_all_facts(module)
    assert 'network' in facts
    assert 'virtualization' in facts

# Generated at 2022-06-22 22:48:44.667713
# Unit test for function get_all_facts
def test_get_all_facts():
    module = MockAnsibleModule(gather_subset=['all'])
    facts_dict = get_all_facts(module)
    assert 'default_ipv4' in facts_dict
    assert facts_dict['default_ipv4']['interface'] == 'eth0'


# Generated at 2022-06-22 22:48:47.915667
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
      from ansible.module_utils.facts import ansible_facts
      return True
    except:
      return False


# Generated at 2022-06-22 22:48:58.874850
# Unit test for function get_all_facts
def test_get_all_facts():
    import json
    import sys

    import ansible.module_utils.facts.ansible_facts as ansible_facts_source

    with open('tests/unit/module_utils/ansible_facts_test_cases/get_all_facts_test_case_1.json') as f:
        test_case_1 = json.load(f)

    # mock an AnsibleModule object
    # https://docs.ansible.com/ansible/latest/dev_guide/developing_modules_documenting.html#example-module

# Generated at 2022-06-22 22:49:04.200243
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.facts.system.distribution

    def noop():
        pass

    module_args = dict()
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['!all'], type='list')),
                           supports_check_mode=True)
    module.run_command = noop
    module_facts = ansible_facts(module, gather_subset=['all'])

    assert module_facts == ansible.module_utils.facts.system.distribution.distribution()

# Generated at 2022-06-22 22:49:11.642684
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.urls import open_url
    class MockAnsibleModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

        def fail_json(self, msg):
            pass

        def exit_json(self, **kwargs):
            pass
    m = MockAnsibleModule(['network'])
    r = get_all_facts(m)
    assert r.get('default_ipv4') is not None

# Generated at 2022-06-22 22:49:21.829580
# Unit test for function get_all_facts
def test_get_all_facts():
    module_mock = MockAnsibleModule()
    module_mock.params['gather_subset'] = ['all']
    module_mock.params['gather_timeout'] = 10
    module_mock.params['filter'] = '*'

    fact_collector = MockFactCollector()
    fact_collector.collect = Mock(return_value={'default_ipv4': '10.0.0.1'})

    ansible_collector.get_ansible_collector = Mock(return_value=fact_collector)

    facts_dict = get_all_facts(module=module_mock)

    assert facts_dict['default_ipv4'] == '10.0.0.1'

# Generated at 2022-06-22 22:49:33.896927
# Unit test for function get_all_facts
def test_get_all_facts():
    import collections

    class MockModule(collections.namedtuple('AnsibleModule', ['params'])):
        def __new__(cls, params=None):
            return super(MockModule, cls).__new__(cls, params=params)

    gather_subset = ['all']
    module = MockModule(params={'gather_subset': gather_subset})
    facts = get_all_facts(module)
    assert facts is not None
    assert 'ansible_lsb' in facts
    assert 'lsb' in facts
    assert 'lsb' not in facts['ansible_lsb']
    assert 'lsb' in facts['ansible_local']
    assert 'distribution' in facts['ansible_local']
    assert 'ansible_distribution' not in facts

    gather_sub

# Generated at 2022-06-22 22:49:44.827534
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self):
            self._params = {'gather_subset': 'all'}

        def params(self):
            return self._params

    module = FakeModule()

    gather_subset = module.params['gather_subset']
    gather_timeout = 10
    filter_spec = '*'


# Generated at 2022-06-22 22:49:55.481717
# Unit test for function ansible_facts
def test_ansible_facts():
    '''test function ansible_facts'''

    from ansible.module_utils.facts.collector import FactsCollector

    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    import pytest

    from ansible.module_utils.six.moves import mock

    from ansible.module_utils.basic import AnsibleModule

    facts_collector_classes = [mock.MagicMock(return_value=FactsCollector())]
    mocked_collectors = [collector_class.return_value for collector_class in facts_collector_classes]

    class FakeModule(object):
        def __init__(self, name, params):
            self.name = name
            self.params = params


# Generated at 2022-06-22 22:49:56.237283
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-22 22:50:08.089168
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys

    try:
        import __main__
    except ImportError:
        # ansible 2.7
        __main__ = sys.modules['__main__']
        __builtin__ = None  # pylint: disable=C0103

    # pylint: disable=C0103,W0212
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.facts import default_collectors



# Generated at 2022-06-22 22:50:13.965933
# Unit test for function get_all_facts
def test_get_all_facts():  # pragma: no cover
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list')})
    results = get_all_facts(module)
    assert results



# Generated at 2022-06-22 22:50:23.028067
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    import pytest
    class FakeAnsibleModule():
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    assert ansible_facts(FakeAnsibleModule(gather_subset=None))
    # asserts on gathering facts
    assert ansible_facts(FakeAnsibleModule(gather_subset=['all']))
    assert ansible_facts(FakeAnsibleModule(gather_subset=['min']))
    assert ansible_facts(FakeAnsibleModule(gather_subset=['!min']))

    # invalid value for gather_subset should fail

# Generated at 2022-06-22 22:50:32.619124
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.compat.tests import unittest

    try:
        from test.support import EnvironmentVarGuard
    except ImportError:
        from test.test_support import EnvironmentVarGuard

    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    gather_subset = ['all']
    gather_timeout = 10

# Generated at 2022-06-22 22:50:41.274846
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.ansible_minimal_facts import MinimalAnsibleFactsModule

    module = MinimalAnsibleFactsModule()
    module._ansible_version = (2, 3, 0)
    module.params = dict(gather_subset=['defaults'])

    actual = get_all_facts(module)
    assert actual.get('default_ipv4', {}).get('address') is not None


# Generated at 2022-06-22 22:50:49.215501
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.facts.network as network_facts

    class MockModule(AnsibleModule):
        def __init__(self):
            self.params = dict(
                gather_subset=['!all', 'network'],
                filter='ansible_eth*',
            )
            super(MockModule, self).__init__(argument_spec=dict(), supports_check_mode=True)

    mock_module = MockModule()

    net_facts = network_facts.get_network_facts(mock_module)

    all_facts = get_all_facts(mock_module)

    network_facts = ansible_facts(mock_module)
    # get_network_facts returns facts with the prefix 'ansible_'
    #

# Generated at 2022-06-22 22:51:01.459079
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system

    class FakeFactsModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}
            self.gather_subset = gather_subset

    class FakeOSCategorySystemInfoCommand(ansible.module_utils.facts.system.BaseSystemInfoCommand):
        REQUIRED_PYTHON_PACKAGES = ['ansible-test-fake-package-01', 'ansible-test-fake-package-02']

        def __init__(self, module):
            pass

        def populate(self):
            return {'distribution': {'id': 'distribution_id'}}


# Generated at 2022-06-22 22:51:11.586958
# Unit test for function ansible_facts
def test_ansible_facts():
    """mock the 2.3+ module_utils/facts.collector """
    import ansible.module_utils.facts.collector as mock_collector
    from ansible.module_utils.facts import default_collectors as mock_default_collectors

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    class MockFactsCollector(object):
        def __init__(self, *args, **kwargs):
            self.namespace = kwargs.get('namespace')
            self.gather_subset = kwargs.get('gather_subset')

        def collect(self, module):
            return {'default_ipv4': {'address': '127.0.0.1', 'network': '127.0.0.0'}}

   

# Generated at 2022-06-22 22:51:22.323130
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.ios import NetworkCollector as IOSCollector
    from ansible.module_utils.facts.network.junos import NetworkCollector as JunOSCollector
    from ansible.module_utils.facts.network.eos import NetworkCollector as EOSCollector
    from ansible.module_utils.facts.network.iosxr import NetworkCollector as IOSXRCollector
    from ansible.module_utils.facts.os.ios import IosFacts
    from ansible.module_utils.facts.os.iosxr import IosxrFacts
    from ansible.module_utils.facts.os.junos import JunosF

# Generated at 2022-06-22 22:51:26.460164
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit Test for function ansible_facts.

    Test by running it with no args and make sure we get a dict back.
    '''
    from ansible.module_utils.facts.facts import ansible_facts
    no_op_args = {
        'filter': '*',
        'gather_subset': [],
        'gather_timeout': 10
    }
    test_module = MagicMock(**no_op_args)
    test_facts = ansible_facts(test_module)
    assert test_facts, 'test_facts is none'
    assert isinstance(test_facts, dict), 'test_facts is not a dict'

# Generated at 2022-06-22 22:51:32.960210
# Unit test for function ansible_facts
def test_ansible_facts():

    def mock_module_params(params):
        class MockModule:
            params = params
        return MockModule()

    class MockSubsetModule(object):

        def __init__(self, module):
            self.params = {'gather_subset': module}

    class MockFilterModule(object):

        def __init__(self, module):
            self.params = {'filter': module}

    def run_ansible_facts(module):
        module = mock_module_params(module)
        return ansible_facts(module)

    # Tests for gather_subset
    assert run_ansible_facts(None)
    assert run_ansible_facts(MockSubsetModule(None))
    assert run_ansible_facts(MockSubsetModule('all'))

# Generated at 2022-06-22 22:51:44.316430
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import DEFAULT_GATHER_SUBSET, DEFAULT_GATHER_TIMEOUT
    from ansible.module_utils.facts.normal import normal_collector

    # test with default gather_subsets
    module = AnsibleModule(argument_spec={})
    assert module.params['gather_subset'] == DEFAULT_GATHER_SUBSET
    assert module.params['gather_timeout'] == DEFAULT_GATHER_TIMEOUT

    results = ansible_facts(module)

    # collect returns a dict with namespace_name as the key, and a dict mapping fact_name->value as the value
    assert 'ansible' in results
    assert isinstance(results['ansible'], dict)

    # make sure that some normal facts

# Generated at 2022-06-22 22:51:46.143803
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    ansible_facts()

# Generated at 2022-06-22 22:51:53.759720
# Unit test for function get_all_facts
def test_get_all_facts():
    import mock
    import json
    import sys

    mock_module = mock.MagicMock()
    mock_module.params = {'gather_subset': 'all'}
    mock_module.fail_json.side_effect = SystemExit

    try:
        get_all_facts(mock_module)
    except SystemExit as e:
        if isinstance(e.args[0], dict):
            pass
        else:
            assert False, 'Expected dictionary from get_all_facts, got:' + str(e.args[0])

# Generated at 2022-06-22 22:51:55.366873
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Unit test for function ansible_facts'''
    pass

# Generated at 2022-06-22 22:52:00.859476
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector.test.test_basics import create_module
    # if 'ansible_facts' is not a dict, for example, AttributeError is raised in module code,
    # and causes a failure.
    module = create_module()
    facts = ansible_facts(module)
    assert isinstance(facts, dict)

# Generated at 2022-06-22 22:52:13.381055
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import socket
    import ansible.module_utils.facts.network.base as network_base

    # Mock the module
    import ansible.module_utils.facts.network.LinuxDistribution as LinuxDistribution

    # Mock the get_all_facts() api for ansible 2.2/2.3
    import ansible.module_utils.facts.system.distribution as distribution

    module = MagicMock()
    module.params.get('gather_subset', ['all'])
    module.params.get('gather_timeout', 10)
    module.params.get('filter', '*')
    module.params.get('filter_spec', None)

    # Create a stub object for the LinuxDistribution class

# Generated at 2022-06-22 22:52:19.042632
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.test.test_module_utils_facts import \
        MockAnsibleModule as AnsibleModule

    mock_module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all'])})
    facts = get_all_facts(mock_module)
    assert isinstance(facts['selinux'], bool)


# Generated at 2022-06-22 22:52:24.903344
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.modules.system import setup
    from ansible.module_utils.facts import get_all_facts

    m = setup.AnsibleModule(argument_spec={})
    m.params['gather_subset'] = 'all'

    facts_dict = get_all_facts(module=m)
    assert 'ansible_all_ipv4_addresses' in facts_dict

# Generated at 2022-06-22 22:52:35.172663
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ansible_collector

    import ansible.module_utils.facts.namespace
    ansible.module_utils.facts.namespace.collector_classes = {}

    class DummyModule:
        pass

    def process_common_aliases():
        return {}

    def dummy_collect(self, module):
        return ['a', 'b', 'c']

    class DummyCollector(BaseFactCollector):
        name = 'name'
        _fact_ids = {'a', 'b', 'c'}

        def collect(self, module=None, collected_facts=None):
            return ['a', 'b', 'c']

# Generated at 2022-06-22 22:52:40.776001
# Unit test for function get_all_facts
def test_get_all_facts():
    module = MagicMock()
    module.params = {'gather_subset': ['all']}
    module.run_command.side_effect = ['', '', '', '', '', '', '']

    assert get_all_facts(module) == ansible_facts(module, gather_subset=['all'])



# Generated at 2022-06-22 22:52:52.683281
# Unit test for function get_all_facts
def test_get_all_facts():
    import mock
    import ansible.module_utils.facts as mock_facts

    # TODO: also test __metaclass__ = type functionality
    expected_facts = dict()
    facts_dict = dict(ansible_facts=expected_facts)

    g_mock_ansible_facts = mock.patch.object(mock_facts, 'ansible_facts', return_value=facts_dict)
    g_mock_all_facts = mock.patch.object(mock_facts, 'get_all_facts')

    with g_mock_ansible_facts as mock_ansible_facts, g_mock_all_facts as mock_all_facts:
        mock_ansible_module_instance = mock.Mock()

# Generated at 2022-06-22 22:52:59.643669
# Unit test for function ansible_facts
def test_ansible_facts():
    module = MockModule()

    default_gather_subset = ['all']
    default_filter_spec = '*'

    ignore_gather_subset = None
    ignore_filter_spec = None

    facts = ansible_facts(module=module, gather_subset=default_gather_subset)
    assert facts['test_fact'] == 'test_fact_value'

    facts = ansible_facts(module=module)
    assert facts['test_fact'] == 'test_fact_value'

    facts = ansible_facts(module=module, gather_subset=ignore_gather_subset, filter_spec=ignore_filter_spec)
    assert facts['test_fact'] == 'test_fact_value'

# Mocked class

# Generated at 2022-06-22 22:53:04.268543
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.basic
    module_args = dict()
    module = ansible.module_utils.basic.AnsibleModule(argument_spec=module_args,
                                                      supports_check_mode=False)
    facts = ansible_facts(module=module)
    assert facts


if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-22 22:53:15.177467
# Unit test for function get_all_facts
def test_get_all_facts():
    # param 'gather_subset' not given, so expect use of default 'all'
    module = MockAnsibleModule(params={'gather_timeout': 12})
    facts = get_all_facts(module)
    assert facts.get('version')
    assert facts.get('platform')
    assert facts.get('lsb')

    # param 'gather_subset' includes 'all' so ensure that
    # all expected data gets returned
    module = MockAnsibleModule(params={'gather_subset': ['all']})
    facts = get_all_facts(module)
    assert facts.get('version')
    assert facts.get('platform')
    assert facts.get('lsb')

    # param 'gather_subset' includes platform and lsb, so ensure
    # that only those two fact sets are

# Generated at 2022-06-22 22:53:20.583430
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(required=False, type='list', default=['all'])
        ),
        supports_check_mode = True
    )
    test_module.exit_json(changed=False, ansible_facts=get_all_facts(test_module))
