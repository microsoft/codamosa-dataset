

# Generated at 2022-06-22 22:43:29.048774
# Unit test for function ansible_facts
def test_ansible_facts():
    Dict = dict
    List = list
    import types
    def my_mock_ansible_module(**kwargs):
        mock_module = Dict()
        mock_module.params = kwargs
        mock_module.fail_json = types.MethodType(my_fail_json, mock_module)
        return mock_module

    def my_fail_json(self, *args, **kwargs):
        raise Exception("fail_json called")

    test_module = my_mock_ansible_module(filter='*')
    all_facts = ansible_facts(test_module)

    test_module = my_mock_ansible_module(gather_subset=[])
    no_fact_facts = ansible_facts(test_module)


# Generated at 2022-06-22 22:43:39.585287
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    gather_subset = ['min']
    gather_timeout = 10
    filter_spec = '*'

    prefix = 'ansible_'
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix=prefix)

    all_collector_classes = default_collectors.collectors


# Generated at 2022-06-22 22:43:42.696778
# Unit test for function get_all_facts
def test_get_all_facts():
    with pytest.raises(KeyError):
        get_all_facts()



# Generated at 2022-06-22 22:43:52.809551
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.collector import AnsibleFileCollector
    from ansible.module_utils.facts.system.platform import PlatformLegacyCollector

    from ansible.module_utils.facts.utils import get_collector_name
    import sys

    class FakeModule:
        class FakeParams:
            def get(self, key, default):
                return default

            params = FakeParams()

        module = FakeModule()
        sys.modules['ansible.module_utils.facts'] = module
        import ansible.module_utils.facts.platform

        def __init__(self, gather_subset=['all'], gather_timeout=10):
            self.module = FakeModule.module


# Generated at 2022-06-22 22:43:57.609849
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    module = MockModule(gather_subset=['!all','network','virtual'])
    facts_dict = get_all_facts(module)

    assert isinstance(facts_dict, dict)
    assert facts_dict.keys()



# Generated at 2022-06-22 22:44:09.006716
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import os
    import mock
    import platform

    fake_module = mock.Mock()

    if sys.version_info[0] <= 2:
        import imp
        get_module_path = os.path.dirname(os.path.abspath(__file__))
        # AnsibleModule is in the parent directory, so import it with imp
        module_utils_path = os.path.join(get_module_path, '..')
        f, pathname, desc = imp.find_module('ansible_module_utils', [module_utils_path])
        ansible_module_utils = imp.load_module('ansible_module_utils', f, pathname, desc)
        from ansible_module_utils.facts.utils import get_all_facts

# Generated at 2022-06-22 22:44:19.273684
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Testing ansible_facts with a mocked AnsibleModule'''
    import collections
    class TestFacts(collections.Mapping):
        '''Mock Facts class, to return a dict of fact values'''
        def __init__(self, facts_dict):
            self.facts_dict = facts_dict

        def __getitem__(self, key):
            return self.facts_dict[key]

        def __iter__(self):
            return iter(self.facts_dict)

        def __len__(self):
            return len(self.facts_dict)

    # create a mock AnsibleModule
    class AnsibleModule:
        '''Mock AnsibleModule instance'''

# Generated at 2022-06-22 22:44:30.368860
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import default_collectors

    module = 'fake_module'
    gather_subset = None
    gather_timeout = 10
    filter_spec = '*'

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-22 22:44:34.520187
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit tests for ansible_facts'''

    # mock out an AnsibleModule
    class FakeModule:
        class FakeParams:
            gather_subset = set(['all'])
            gather_timeout = 10
            filter = '*'
        def __init__(module):
            module.params = FakeModule.FakeParams

    fake_module = FakeModule()

    assert ansible_facts(fake_module)

# Generated at 2022-06-22 22:44:38.527716
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.flashbase_util import AnsibleModule
    m = AnsibleModule(argument_spec={})
    facts = get_all_facts(m)
    assert isinstance(facts, dict)
    assert len(facts) > 0
    assert 'default_ipv4' in facts
    assert 'distribution' in facts

# Generated at 2022-06-22 22:44:49.046604
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    import pytest
    from ansible.module_utils.facts.virtual import virtual_collected_facts
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    from ansible.module_utils.facts.processor.base import ProcessorCollector
    from ansible.module_utils.facts.system import default_collectors as system_default_collectors
    from ansible.module_utils.facts.network import default_collectors as network_default_collectors
    from ansible.module_utils.facts.processor import default_collectors as processor_default_collectors



# Generated at 2022-06-22 22:44:59.251627
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import gather

    gather.DEFAULT_GATHER_SUBSET = ['all']
    gather.DEFAULT_GATHER_TIMEOUT = 10

    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['default']}

    module = FakeModule()
    facts = get_all_facts(module=module)
    assert isinstance(facts, dict)
    assert facts.get('system') == 'Linux'
    assert facts.get('python') == '/usr/bin/python'
    assert facts.get('distribution') == 'Fedora'


# Generated at 2022-06-22 22:45:09.639138
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeCollector(BaseFactCollector):
        name = 'fake'

        def collect(self, module=None, collected_facts=None):
            self._collected_facts['fake_fact'] = 'foo'
            return self._collected_facts

    all_collector_classes = default_collectors.collectors
    all_collector_classes.append(FakeCollector)

    # use a mock module to test this
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import iteritems


# Generated at 2022-06-22 22:45:21.717746
# Unit test for function get_all_facts
def test_get_all_facts():

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.legacy

    class AnsibleModule:
        def __init__(self, params):
            self.params = params
            self.fail_json = lambda **kwargs: None
            self.exit_json = lambda **kwargs: None


# Generated at 2022-06-22 22:45:32.392224
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import os
    import stat
    # exercise the ansible_facts function by executing it in a subprocess and
    # compare the output with expected output

    module_path = '/tmp/ansible_facts.py'
    module_content = '''
import os
import sys
# simulate module_utils
import ansible.module_utils.facts as facts
facts_dict = facts.ansible_facts(module=module)
for key in facts_dict:
    print(key + '=' + facts_dict[key])
    '''

    with open(module_path, 'w') as f:
        f.write(module_content)
    st = os.stat(module_path)
    os.chmod(module_path, st.st_mode | stat.S_IEXEC)
    p = subprocess.P

# Generated at 2022-06-22 22:45:43.984594
# Unit test for function ansible_facts

# Generated at 2022-06-22 22:45:53.637228
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts
    import ansible.module_utils.facts.platform.posix as posix_collector
    import ansible.module_utils.facts.hardware.posix as posix_hw_collector
    import ansible.module_utils.facts.system.posix as posix_sys_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.platform.netbsd import NetBSDHardware, NetBSDNetwork
    from ansible.module_utils.facts.platform.freebsd import FreeBSDHardware, FreeBSDNetwork
    from ansible.module_utils.facts.platform.openbsd import OpenBSDHardware, OpenBSDNetwork

    ansible.module_utils.facts.collectors['default'] = []
    ansible.module_

# Generated at 2022-06-22 22:46:01.884719
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.compat.tests import unittest
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestAnsibleModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

    class TestAnsibleCollector(object):
        def __init__(self, all_collector_classes, namespace, filter_spec,
                     gather_subset, gather_timeout, minimal_gather_subset):
            self.all_collector_classes = all_collector_classes
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset
            self.gather_timeout = gather_

# Generated at 2022-06-22 22:46:09.958537
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        from ansible.module_utils.facts import FACT_CACHE
        from ansible.module_utils.facts import AnsibleModule
    except ImportError:
        # Ansible <= 2.3
        from ansible.module_utils.facts import FACT_CACHE
        from ansible.module_utils.basic import AnsibleModule


    FACT_CACHE = {}
    module = AnsibleModule(argument_spec={})
    facts = ansible_facts(module)
    assert facts is not None

# Generated at 2022-06-22 22:46:16.584527
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test ansible_facts function by manually setting gather_subset.
    '''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'gather_subset': {'type': 'list', 'default': ['all']}})
    facts = ansible_facts(module)
    assert('default_ipv4' in facts)
    # FIXME: add more tests

# Generated at 2022-06-22 22:46:25.681180
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.default_collectors
    import ansible.module_utils.facts.ansible_collector

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import RootFactNamespace
    from ansible.module_utils.facts.ansible_collector import AnsibleFactCollector

    # Test that we are getting the current module.
    #
    # NOTE: This isn't a very good test, because the get_all_facts method and the way it is
   

# Generated at 2022-06-22 22:46:34.963754
# Unit test for function get_all_facts
def test_get_all_facts():
    # setup test
    class MockAnsibleModule(object):
        def __init__(self, params):
            self.params = params

    class MockAnsibleModule_no_params(object):
        def __init__(self):
            pass

    class MockAnsibleModule_no_gather_subset(object):
        def __init__(self):
            self.params = dict()

    module = MockAnsibleModule(dict(gather_subset=['all'], gather_timeout=10, filter='*'))
    # first use case, no gather_subset
    facts = get_all_facts(module)
    assert 'system' in facts, \
        "Expected 'system' to exist in facts, but got {!s}".format(facts)

# Generated at 2022-06-22 22:46:44.308282
# Unit test for function get_all_facts
def test_get_all_facts():
    import mock

    with mock.patch('ansible.module_utils.facts.ansible_facts') as m_ansible_facts:
        import ansible.module_utils.facts as facts

        # Test: gather_subset is present in module.params
        module = mock.MagicMock(params={'gather_subset': []})
        facts.get_all_facts(module)
        m_ansible_facts.assert_called_with(module, gather_subset=[])

        # Test: gather_subset is not present in module.params
        module = mock.MagicMock(params={})
        facts.get_all_facts(module)
        m_ansible_facts.assert_called_with(module, gather_subset=None)

# Generated at 2022-06-22 22:46:45.360021
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True


# Generated at 2022-06-22 22:46:51.769697
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_native
    import sys
    import pytest
    from mock import Mock, patch

    if sys.version_info[0] < 3:
        import __builtin__ as builtins  # pylint: disable=import-error,no-name-in-module
    else:
        import builtins  # pylint: disable=import-error

    class AnsibleModule(object):

        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            print('fail_json', kwargs)
           

# Generated at 2022-06-22 22:47:02.410098
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.facts.namespace import RawFactNamespace
    import collections
    import pytest
    import ansible.module_utils

    class MockAnsibleModule(object):
        params = dict(gather_subset=['all'])

    testable_ansible_facts = ansible.module_utils.facts.ansible_facts
    module = MockAnsibleModule()
    test_facts = ansible_facts(module)
    assert isinstance(test_facts, MutableMapping)
    assert test_facts['distribution'] == 'Other'
    assert isinstance(test_facts['python']['executable'], collections.Callable)

# Generated at 2022-06-22 22:47:08.757312
# Unit test for function ansible_facts
def test_ansible_facts():

    import unittest
    import os
    import sys
    import mock
    from ansible.module_utils.facts import collector

    try:
        from ansible.module_utils.facts import ansible_distribution_facts
    except ImportError:
        ansible_distribution_facts = None

    # Mock get_file_content function for ansible_lsb fact to return a
    # fake version number.

# Generated at 2022-06-22 22:47:21.363016
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import unittest
    import ansible.module_utils.facts as facts

    class ModuleMock(object):
        def __init__(self):
            self.params = dict()

        def fail_json(self, *args, **kwargs):
            caller = sys._getframe(1)
            module_name = caller.f_globals['__name__']
            self.fail_json_called = True
            raise Exception('%s:%s failed.  args=%s kwargs=%s' % (module_name, caller.f_code.co_name,
                                                                  args, kwargs))

    class AnsibleModuleMock(ModuleMock):
        def __init__(self):
            super(AnsibleModuleMock, self).__init__()
            self.exit

# Generated at 2022-06-22 22:47:31.498998
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    import sys
    import pytest

    class SimpleModule(Mapping):
        def __init__(self,
                     params,
                     default_gather_subset=None,
                     default_gather_timeout=10,
                     argument_spec=dict(),
                     supports_check_mode=False,
                     bypass_checks=False):
            self.params = params
            self.default_gather_subset = default_gather_subset
            self.default_gather_timeout = default_gather_timeout
            self.argument_spec = argument_spec
            self.checked_args = None


# Generated at 2022-06-22 22:47:35.040871
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule(object):
        '''Fake object to be used as the module object in unit testing.
        '''

        def __init__(self, params=dict()):
            '''FakeModule constructor
            '''
            self.params = params

    fake_module = FakeModule()
    facts_dict = ansible_facts(fake_module)
    # facts_dict should have 'fqdn' in it.
    assert "fqdn" in facts_dict

# Generated at 2022-06-22 22:47:42.036391
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_distribution

    # Test with bare minimum gather_subset
    module = AnsibleModule(argument_spec=dict())
    module.params['gather_subset'] = ['all']
    module.params['gather_timeout'] = 0
    facts_dict = ansible_facts(module)
    assert facts_dict != {}
    assert 'distribution' in facts_dict
    assert facts_dict['distribution'] == get_distribution()



# Generated at 2022-06-22 22:47:44.103015
# Unit test for function get_all_facts
def test_get_all_facts():
    '''dummy function to allow unit testing via pytest'''
    return

# Generated at 2022-06-22 22:47:54.557175
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    class FakeDistributionFactCollector(DistributionFactCollector):
        def __init__(self, *arg, **kwargs):
            super(FakeDistributionFactCollector, self).__init__(*arg, **kwargs)
            # self.os_release_content = "NAME=CentOS\nVERSION=7.12"


# Generated at 2022-06-22 22:48:01.770564
# Unit test for function ansible_facts
def test_ansible_facts():
    import unittest.mock as mock

    # mock out module
    module = mock.MagicMock(spec=['params'])
    module.params = {'gather_subset': ['all', 'min'],
                     'gather_timeout': 10,
                     'filter': '*'}

    # mock out the actual fact collectors to just return static data
    #   we can verify that ansible_facts is kicking off the right subset of collectors, but
    #   we don't need to test that the collectors are actually doing anything.

# Generated at 2022-06-22 22:48:12.433291
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import json
    #import module_utils.facts
    #sys.modules['ansible.module_utils.facts'] = module_utils.facts

    class _AnsibleModule(object):
        def __init__(self, params):
            self.params = params

    params = dict(
        gather_subset=['!all'],
        gather_timeout=10,
        filter='ansible_os_family=Debian',
    )
    module = _AnsibleModule(params)
    my_facts = get_all_facts(module)
    print(json.dumps(my_facts, indent=4, sort_keys=True))

    # Test deprecated API with gather_subset keyword arg
    my_facts = ansible_facts(module, gather_subset=['!all'])

# Generated at 2022-06-22 22:48:25.317358
# Unit test for function get_all_facts
def test_get_all_facts():
    # Unit test for 2.3/2.3 API
    def ansible_module_staff_callable(module_name, module_args=None, check_invalid_arguments=None,
                                      bypass_checks=False,
                                      no_log=False,
                                      define_module=None,
                                      result=None,
                                      **kwargs):
        module_name = module_name or 'test_module'
        # module_args will be a json string.
        # parse the json string, ignore
        module_args = {'gather_subset': module_args.get('gather_subset', '')}
        module_args.update(kwargs)

        class MockModule(object):
            pass

        module = MockModule()
        module.params = module_args
        module.params.update(result)

# Generated at 2022-06-22 22:48:37.820835
# Unit test for function ansible_facts
def test_ansible_facts():
    # import dependencies
    try:
        from ansible.module_utils.facts import default_collectors
        from ansible.module_utils.facts import ansible_collector
        from ansible.module_utils.facts import namespace
        from ansible.module_utils.facts import collector
    except ImportError:
        from module_utils.facts import default_collectors
        from module_utils.facts import ansible_collector
        from module_utils.facts import namespace
        from module_utils.facts import collector

    import sys

    # mock the module class
    class MockAnsibleModule():
        def __init__(self, *args, **kwargs):
            self.params = {
                'gather_subset': ['all'],
                'gather_timeout': 10,
            }


# Generated at 2022-06-22 22:48:45.117916
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={
        'gather_subset': {'default': '!all'},
        'gather_timeout': {'type': 'int', 'default': 10},
        'filter': {'default': '*'},
    })
    facts = ansible_facts(module)
    for fact in facts:
        assert facts[fact] is not None

# Generated at 2022-06-22 22:48:57.286694
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.collectors.disk

    try:
        import ansible.module_utils.facts.collectors.pci
    except ImportError:
        ansible.module_utils.facts.collectors.pci = None

    all_collector_classes = default_collectors.collectors
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    module = ansible.module_utils.facts.DummyModule()


# Generated at 2022-06-22 22:49:03.327229
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.compat.tests.mock import MagicMock
    from ansible.compat.tests.mock import patch

    module = MagicMock()
    gather_subset = 'test'

    ansible_facts(module, gather_subset)

    module.params.get.assert_any_call('gather_subset', ['all'])
    module.params.get.assert_any_call('gather_timeout', 10)
    module.params.get.assert_called_with('filter', '*')

# Generated at 2022-06-22 22:49:08.543532
# Unit test for function ansible_facts
def test_ansible_facts():
    # This is a hard way to get the 'all' subset to test.
    module = {'gather_subset': ['all']}
    module = PrefixFactNamespace(module, '', '')

    facts = ansible_facts(module)
    assert facts is not None
    assert 'fqdn_ip4' in facts



# Generated at 2022-06-22 22:49:14.824370
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Unit test of the get_all_facts function.
    '''
    class FakeModule:
        '''
        Fake of the module class for testing.
        '''
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    module = FakeModule()
    facts = get_all_facts(module)
    assert 'distribution' in facts
    assert facts['distribution'] is not None



# Generated at 2022-06-22 22:49:23.385205
# Unit test for function ansible_facts
def test_ansible_facts():
    # pylint: disable=unused-import,unused-variable
    # pylint doesn't recognize the import being used
    from ansible.module_utils.facts.collector.system import SystemFactCollector

    from ansible.module_utils import basic

    import ansible.module_utils.facts.collector.base
    # pylint: enable=unused-import,unused-variable
    class DummyAnsibleModule(object):
        '''class to fake AnsibleModule for unit tests.

        an instance of DummyAnsibleModule does not have an 'AnsibleModule' ancestor,
        but it has all the attributes and methods of an AnsibleModule instance that
        the AnsibleFactsCollector class expects.
        '''
        def __init__(self, params):
            self.params = params

# Generated at 2022-06-22 22:49:34.264635
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr
    import ansible.module_utils.facts.system.platform as platform

    from ansible.module_utils import facts

    # mock out AnsibleModule()
    class _AnsibleModule(object):
        def __init__(self, gather_subset='all'):
            self.params = {'gather_subset': gather_subset}

    module = _AnsibleModule(gather_subset=['min'])

    all_facts = get_all_facts(module)
    distribution_facts = distribution.facts(module=module)
    pkg_mgr_facts = pkg_mgr.facts(module=module)
    platform_

# Generated at 2022-06-22 22:49:45.138186
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.processor import FactsProcessor
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collectors.extras import Dummy
    from ansible.module_utils.facts.collectors.hardware import Hardware
    from ansible.module_utils.facts.collectors.network import Network
    from ansible.module_utils.facts.collectors.software import Software
    from ansible.module_utils.facts import default_collectors

    class TestModule(object):
        def __init__(self):
            self.params = {}

    module = TestModule()

    source_collectors = [Dummy, Hardware, Network, Software]
    fact_collect

# Generated at 2022-06-22 22:49:55.533590
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    unit test for ansible_facts function
    '''

    try:
        from ansible.module_utils.facts import ansible_facts
    except ImportError:
        # ansible < 2.3 uses get_all_facts
        from ansible.module_utils.facts import get_all_facts as ansible_facts

    class MockModule(object):
        '''mocks an ansible module object'''

        def __init__(self, gather_subset=None):
            self.params = {'gather_subset': gather_subset}

    # check for no gather_subset arg present
    ansible_facts_result = ansible_facts(module=MockModule())

    # check for gather_subset arg present

# Generated at 2022-06-22 22:50:04.295518
# Unit test for function get_all_facts
def test_get_all_facts():
    class DummyModule(object):
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['all'], 'gather_timeout': 10, 'filter': '*'}
    fact_dict = get_all_facts(DummyModule(params))
    assert isinstance(fact_dict, dict)

if __name__ == '__main__':
    test_get_all_facts()

# Generated at 2022-06-22 22:50:10.701735
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'gather_subset': dict(default='all'),
                                          'gather_timeout': dict(default=10, type='int'),
                                          'filter': dict(default='*')})
    # import pdb;pdb.set_trace()
    facts = ansible_facts(module, gather_subset=['network', 'local'])
    assert facts['lsb']['distrib_release'] == '16.04'
    assert facts['lsb']['distrib_security_patch'] == '2016-04-07'
    assert facts['lsb']['major_release'] == '16'
    assert facts['lsb']['distributor_id'] == 'Ubuntu'
    assert facts

# Generated at 2022-06-22 22:50:21.514822
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.group_collection import FactGroups

    fact_groups = FactGroups(
        all_collector_classes=default_collectors.collectors,
        exclude_defaults=False,
        minimal_gather_subset=frozenset(),
        enabled_collectors_only=True,
        filter_spec=None,
        gather_subset=['all'],
    )

    all_fact_names = sorted(fact_groups.names)

    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.service_mgr


# Generated at 2022-06-22 22:50:31.703804
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.cache
    import ansible.module_utils.facts.pristinify
    import ansible.module_utils.facts.gather

    # Reset cache
    ansible.module_utils.facts.cache.FACT_CACHE = dict()

    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network

    class MockModule:
        class params:
            def __init__(self, gather_subset=None, filter='*'):
                self.gather_subset = gather_subset
                self.filter = filter

    ##############################################
    # Test that get_all_facts returns something

    mock_module1 = MockModule(gather_subset="!all,!min")

    ret1 = get_all_facts

# Generated at 2022-06-22 22:50:44.037651
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test function ansible_facts.

    Intended to be run with nosetest.
    '''
    import ansible.module_utils.facts.system.distribution
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.facts import all_collectors

    # 'module' must be an instance of AnsibleModule to test ansible_facts. But we don't
    # have one to work with. So simulate it with a dict.
    class FakeModule:
        params = dict()

    module = FakeModule()

    # Test ansible_facts when gather_subset is not included
    facts_dict = ansible_facts(module)

    # There should be a 'ansible_distribution' fact
    assert facts_dict['ansible_distribution'] == ansible.module

# Generated at 2022-06-22 22:50:56.750310
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import copy
    import inspect
    import json
    import platform
    import os
    sys.path.append(os.path.dirname(__file__))
    import test_utils
    import argparse

# Generated at 2022-06-22 22:51:08.544837
# Unit test for function get_all_facts
def test_get_all_facts():
    class Args(object):
        pass

    class Module(object):
        def __init__(self):
            self.args = Args()
        def get_option(self, param):
            return getattr(self.args, param)
        def fail_json(self, *args, **kwargs):
            self.fail = True
            self.fail_args = args
            self.fail_kwargs = kwargs
            kwargs['msg'] = kwargs.get('msg', '') + ' (This error was intentionally raised from test_get_all_facts)'

    m = Module()
    m.args.gather_subset = ['all']
    facts = get_all_facts(m)
    assert facts['distribution'] == 'unknown', 'facts["distribution"]=' + facts['distribution']

# Generated at 2022-06-22 22:51:19.964250
# Unit test for function ansible_facts
def test_ansible_facts():
    '''This is a basic unit test to make sure the ansible_facts() function works as expected.

    Test the following:
    - If no 'gather_subset' is passed in, the module param 'gather_subset' is used
    - If a 'gather_subset' is passed in, the gather_subset arg is used
    - If neither a 'gather_subset' is passed in, nor is there a module param 'gather_subset', then 'all' is used
    - If the filter is set to '*', then all facts are returned
    - If the filter is set to 'ansible_sysctl*', then only facts matching the filter are returned
    '''

    # This is a fake class that we have to use because the ansible_facts() function
    # expects an instance of an AnsibleModule

# Generated at 2022-06-22 22:51:29.907575
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.virtual.kvm import Virtual

    all_collector_classes = default_collectors.collectors

    class FakeAnsibleModule:
        def __init__(self):
            self.params = dict(gather_subset=['!all', 'network'], gather_timeout='10', filter='*')

    fake_module = FakeAnsibleModule()
    fake_module.facts = dict()
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-22 22:51:34.594996
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.utils import get_file_lines

    class MockModule(AnsibleModule):
        def __init__(self, filter=None, filter_glob=None, gather_subset=None, gather_timeout=1):
            self.filter = filter
            self.filter_glob = filter_glob
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            super(MockModule, self).__init__(argument_spec={})

    mock_module = MockModule(gather_subset=['!all', 'network', 'all'], filter_glob='*ets')

    ansible

# Generated at 2022-06-22 22:51:45.065946
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    import json
    try:
        from ansible.module_utils.facts.collector.ansible_local import FactsCollectorBase
    except ImportError:
        from ansible.module_utils.facts.collector.local import FactsCollectorBase

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, *args, **kwargs):
            raise Exception('Failed formatter')

    all_collectors = default_collectors.collectors[:]
    all_collectors.append(MockModule)

    class MockFactCollector(FactCollectorBase):
        def __init__(self):
            self.mock_fact = 'value'


# Generated at 2022-06-22 22:51:55.624769
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_class
    from ansible.module_utils.facts.utils import get_collector_namespaces

    all_collector_classes = default_collectors.collectors
    collector_namespace = get_collector_namespaces(collector_classes=all_collector_classes)
    collector_classes = get_collector_class(collector_namespaces=collector_namespace,
                                            filter_spec='ansible_date_time')
    # Test to ensure that the function adds the 'ansible_' prefix to the fact name
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='ansible_')
    fact_collector = ansible_collect

# Generated at 2022-06-22 22:52:01.716469
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.realpath(__file__)), '../'))
    from ansible.module_utils.facts import ansible_facts

    class FakeModule(object):
        def __init__(self):
            self.params = {}

    m = FakeModule()

    r = ansible_facts(m)

    assert 'distribution' in r

# Generated at 2022-06-22 22:52:10.395671
# Unit test for function get_all_facts
def test_get_all_facts():

    # test with gather_subset=None
    argspec = dict(  # basic argspec for a module
        gather_subset=dict(type='list', default=['!all']),
        gather_timeout=dict(type='int', default=10),
        filter=dict(type='str', default='*'),
    )

    module = type('AnsibleModule', (), {
        'params': dict(
            gather_subset=None,
        ),
        'argument_spec': argspec,
    })

    facts_dict = get_all_facts(module)

    assert facts_dict is not None
    assert len(facts_dict) > 0
    gathered_fact_names = frozenset(facts_dict.keys())

    assert 'distribution' in gathered_fact_names
    assert 'distribution_release' in gathered

# Generated at 2022-06-22 22:52:20.472397
# Unit test for function get_all_facts
def test_get_all_facts():
    from units.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase

    class TestCase(ModuleTestCase):
        def test_basic(self):
            # test:
            #  - compatibility api

            module = self.mock_module(params=dict(
                gather_subset=['all'],
                gather_timeout=10,
            ))
            get_all_facts(module=module)

            # test:
            #  - gather_subset is optional
            #  - gather_timeout is optional
            #  - should not raise exception

            module = self.mock_module()
            get_all_facts(module=module)

        def test_basic2(self):
            # test:
            #  - compatibility api
            #  - should not raise exception

            module = self.m

# Generated at 2022-06-22 22:52:32.461788
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts as utils_facts
    def my_func(a,b,c):
        return a+b+c

    class FakeModule:
        params = {'a':7,'b':12,'c':'c'}

        def fail_json(*args, **kwargs):
            raise Exception()

        def exit_json(*args, **kwargs):
            pass

    mod = FakeModule()

    assert utils_facts.ansible_facts(mod, ['a','b']) == {'a':7, 'b':12}
    assert utils_facts.ansible_facts(mod, ['a','b'], filter_spec=None) == {'a':7, 'b':12}

# Generated at 2022-06-22 22:52:38.520341
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    # this is needed to pass 2.3 compat tests
    setattr(test_get_all_facts, '__ansible_module__', to_bytes('test_get_all_facts'))
    setattr(test_get_all_facts, '__ansible_arguments__', dict(gather_subset=['all']))
    setattr(test_get_all_facts, '__ansible_version__', '2.2')
    setattr(test_get_all_facts, '__ansible_module_name__', to_bytes('test_get_all_facts'))
    setattr(test_get_all_facts, '__ansible_module_name__', to_bytes('test_get_all_facts'))

# Generated at 2022-06-22 22:52:45.942134
# Unit test for function get_all_facts
def test_get_all_facts():
    import unittest
    import ansible.module_utils.facts.test.test_testmodule as testmodule

    class FakeModule():

        def __init__(self, params=None, fail_json=None):
            self.params = params
            self.fail_json = fail_json

    class TestGetAllFacts(unittest.TestCase):

        def setUp(self):
            self.params = dict(gather_subset=['network', 'virtual'])
            self.module = FakeModule(self.params)


# Generated at 2022-06-22 22:52:56.250519
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_all_subset_facts
    from ansible.module_utils.facts.system import distribution

    class FakeAnsibleModule(object):

        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return 'bin_path'

    fake_subsets = frozenset(['default_ipv4', 'lsb', 'distribution', 'default_interface'])

    def test_subset_provider(subset):
        if subset in fake_subsets:
            return [distribution.DistributionFactCollector()]
        else:
            return None

    # override the all_collectors setter to contain a subset mechanism
    ansible_collector.Ans

# Generated at 2022-06-22 22:52:59.084312
# Unit test for function get_all_facts
def test_get_all_facts():
    module = MockAnsibleModule(None)
    assert get_all_facts(module) == {}



# Generated at 2022-06-22 22:53:07.672709
# Unit test for function get_all_facts
def test_get_all_facts():
    # Make the bare minimum usable 'AnsibleModule' class
    class AnsibleModule(object):
        def __init__(self, module_name, **kwargs):
            self.params = kwargs
            self.module_name = module_name

    # a module that specifies gather_subset information
    module1 = AnsibleModule(module_name='testmodule',
                            gather_subset=['all', 'network', 'virtual'])

    # a module that specifies no gather_subset information
    module2 = AnsibleModule(module_name='testmodule')

    # call the method on both modules without providing the gather_subset param
    facts1_no_gather_subset = get_all_facts(module1)
    facts2_no_gather_subset = get_all_facts(module2)

    #

# Generated at 2022-06-22 22:53:18.511161
# Unit test for function ansible_facts
def test_ansible_facts():
    import os

    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.basic import AnsibleModule

    # Stub out the AnsibleModule.run_command method
    def run_command(self, cmd):
        dirname, filename = os.path.split(os.path.abspath(__file__))
        if cmd == 'uname -a':
            # This answer is from a Debian 9.0 machine.
            return (0, 'Linux ip-172-30-1-239 4.9.0-3-amd64 #1 SMP Debian 4.9.30-2+deb9u1 (2017-06-26) x86_64 GNU/Linux', '')
        elif cmd == 'test -e /etc/debian_version':
            return (0, '', '')
       