

# Generated at 2022-06-22 22:43:26.307343
# Unit test for function ansible_facts
def test_ansible_facts():

    # Lets use the Facter Facts class as a test bed, since it's fairly well behaved
    # it does not have any dependencies on ansible hosts/playbooks, and returns the
    # same data for the same facts
    from ansible.module_utils.facts.facter import FacterFactCollector
    from ansible.module_utils import facts
    from ansible.module_utils.facts import default_collectors
    collectors = default_collectors.collectors
    class FakeModule(object):
        '''A Fake ansible module'''
        params = {'gather_subset': ['all'], 'gather_timeout': 5}


# Generated at 2022-06-22 22:43:37.009171
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Test get_all_facts using a mock AnsibleModule.

    This test imports get_all_facts and checks that it imports without errors.
    It then constructs an instance of AnsibleModule and passes it to get_all_facts.
    No assertions are performed on the returned facts, since that would require actual facts to test against.
    '''

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleFallbackNotFound
    from ansible.module_utils.pycompat24 import get_ex

# Generated at 2022-06-22 22:43:45.507426
# Unit test for function get_all_facts
def test_get_all_facts():
    mock_module = MockModule(
        params={
            'gather_subset': ['all']
        }
    )
    actual = get_all_facts(mock_module)


# Generated at 2022-06-22 22:43:56.640610
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    import sys

    class MyCollectorA(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'myfact_a': 'xxx'}

    class MyCollectorB(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'myfact_b': 'xxx'}

    class MyCollectorC(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'myfact_c': 'xxx'}

    # myfact_c is intentionally not in default_collectors._ALL_COLLECTORS
    # (just like apparmor

# Generated at 2022-06-22 22:44:08.523100
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ansible_collector

    class DummyAnsibleModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, executable, required=False):
            return 'path_to_bin'

        def get_distribution(self):
            return 'dummy_distro'


# Generated at 2022-06-22 22:44:18.989793
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    import unittest
    import ansible.module_utils.facts.test_collector

    class MockAnsibleModule(object):

        def __init__(self):
            self.params = {'gather_subset': ['platform', 'distribution']}

    class TestMockAnsibleFacts(unittest.TestCase):

        def test_get_all_facts(self):
            '''test backwards compat for ansible 2.3/2.4'''

# Generated at 2022-06-22 22:44:26.498222
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.test_module_utils.test_facts.test_test_ansible_facts import MockAnsibleModule

    module = MockAnsibleModule(params={'gather_subset': ['all']})

    facts = get_all_facts(module)

    assert set(facts).isdisjoint(set(['ansible_foo']))
    assert 'foo' in facts
    assert facts['foo'] == 'bar'


# - unit test for function ansible_facts

# Generated at 2022-06-22 22:44:36.788244
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for ansible_facts'''
    import ansible.module_utils.facts as facts_module
    import ansible.module_utils.facts.namespace as namespace_module

    class FakeModule():
        '''fake module class'''
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['!all']
            self.params['filter'] = '*'

        def run_command(self, cmd):
            '''fake run_command method'''
            return cmd

    gather_subset = ['min']
    namespace = namespace_module.DefaultFactNamespace(namespace_name='ansible')
    fact_collector = \
        facts_module.ansible_collector.get_ansible_collector()
    fake_module = FakeModule

# Generated at 2022-06-22 22:44:38.102184
# Unit test for function ansible_facts
def test_ansible_facts():
    pass


# Generated at 2022-06-22 22:44:47.533692
# Unit test for function get_all_facts
def test_get_all_facts():
    # Fixture for AnsibleModule
    # obj.params will be used to access params in the function under test
    class MockAnsibleModule:
        def __init__(self, params):
            self.params = params

    gather_subset = ['!services']
    module = MockAnsibleModule({'gather_subset': gather_subset})

    # run the test
    fact_dict = get_all_facts(module)

    # assert the output
    assert 'dns' in fact_dict
    assert fact_dict['dns']['nameservers'][0] == '8.8.4.4'
    assert 'services' not in fact_dict

# Generated at 2022-06-22 22:44:59.831202
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import facts
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Mock `ansible_collector.get_ansible_collector()` so that the
    # 'ansible' namespace is returned.


# Generated at 2022-06-22 22:45:04.960538
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    # should warn about a missing gather_subset
    facts_dict = ansible_facts(module)

    # should get the default gather_subset
    assert facts_dict['gather_subset'] == ['all']

# Generated at 2022-06-22 22:45:12.604381
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test 2.x/2.3 get_all_facts/ansible_facts method.

    Get a dict of facts with no special args
    Get a dict of facts with gather_subset=['foo', 'bar']
    Get a dict of facts with gather_timeout=30
    Get a dict of facts with filter_spec='ipv4'
    Get a dict of facts with filter_spec='ansible_mounts'
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_collector, default_collectors

    from ansible.module_utils.facts import get_all_facts, ansible_facts


# Generated at 2022-06-22 22:45:24.557074
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Test the ansible_facts() function.

    This is a basic test, which

    * just checks that it doesn't throw an exception,
    * extracts the ansible_default_ipv4 fact, and
    * sanity checks the fact value to make sure it looks like an IP address.
    '''
    import re
    from ansible.module_utils.facts.network.base import NetworkCollector

    ip_address_re = re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}')

    # Simulate the AnsibleModule instance
    class FakeAnsibleModule(object):

        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            import sys

# Generated at 2022-06-22 22:45:33.848175
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.collector.system as system_collector
    import ansible.module_utils.facts.collector.virtual as virtual_collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import LegacyFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    import ansible.module_utils.facts.collector as collector
    import ansible.module_utils.facts as facts
    import collections
    import os

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    local_collector = system_collector.SystemCollector(legacy_collector=None, namespace=LegacyFactNamespace)

# Generated at 2022-06-22 22:45:34.407911
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-22 22:45:45.051375
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.namespace as namespacemodule

    # The 'filter_spec' param is used to filter the facts from fact_collector.collect()
    # This param was added to ansible 2.3.
    # In ansible 2.2 and before, fact_collector.collect() call did not take filter_spec.

    # AnsibleModule.params dict includes params not explicitly passed as args for compat reasons.
    # For compat with 2.2/2.1, ignore 'gather_subset' param in the AnsibleModule.params dict.

    # In ansible 2.1, the gather_subset param of AnsibleModule, was not accepted.
    # In ansible 2.2, the param is accepted, but the value is ignored
    # To mimic this behavior, pass 'gather_subset' param with

# Generated at 2022-06-22 22:45:56.702714
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for get_all_facts method'''
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    # Test that the bare fact name 'lsb' is included in the ansible_facts output.
    # The 'lsb' fact name was chosen because it is present on nearly all distros,
    # and the lsb fact is not present in the minimal_gather_subset.

    # create a mock module with gather_subset=all
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-22 22:46:03.875072
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils
    import ansible.module_utils.facts
    import ansible.module_utils.facts.facts

    import copy
    import os
    import pprint
    import sys

    test_args = {}

    # test setup:
    #   - usr/share/ansible_collections/ansible/netcommon/plugins/module_utils/facts/facts.py
    #   - usr/share/ansible_collections/ansible/netcommon/plugins/module_utils/network/common/utils.py
    #   - usr/share/ansible_collections/ansible/netcommon/plugins/module_utils/network/common/argspec.py
    #   - usr/share/ansible_collections/ansible/netcommon/plugins/module_utils/network/common/config

# Generated at 2022-06-22 22:46:15.341933
# Unit test for function get_all_facts
def test_get_all_facts():
    import tempfile
    import shutil
    import subprocess

    def run_module(gather_timeout=10, gather_subset='all', **module_args):
        module_args.update({
            'gather_timeout': gather_timeout,
            'gather_subset': gather_subset,
        })

        cmd = [
            'facter', '--json'
        ]

        fact_raw = subprocess.check_output(cmd, stderr=subprocess.STDOUT).strip()
        facter_facts = json.loads(to_text(fact_raw, errors='surrogate_then_replace'))

        module_args['ansible_fact_raw'] = fact_raw
        module_args['facter_facts'] = facter_facts


# Generated at 2022-06-22 22:46:24.817788
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit test for ansible_facts function'''

    class FakeModule():
        '''Fake module class used to test gathering of facts'''
        def __init__(self, module_name, module_args):
            self.params = module_args

    class FakeCollector():
        '''Fake Collector class used to test gathering of facts'''
        def collect(self, module):
            return {"fake_fact": "fake_fact_value"}

    class FakeAnsibleTimeoutException(Exception):
        pass

    class FakeAnsibleCollector():
        '''Fake class used to test ansible_collector.get_ansible_collector'''
        def __init__(self, all_collector_classes, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            pass

       

# Generated at 2022-06-22 22:46:34.573362
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule(object):
        def __init__(self):
            self.params = dict(gather_subset=['all'],
                               gather_timeout=10)
            self.run_command = None
        def get_bin_path(self, binary, required=True, opt_dirs=[]):
            return None
        def run_command_environ_update(self, *args, **kwargs):
            return self.run_command(*args, **kwargs)
        def load_file_common_arguments(self):
            return dict(follow=False, check=False)

    import ansible.module_utils.facts
    ansible.module_utils.facts.DEFAULT_GATHER_TIMEOUT = 10

    m = FakeModule()

    # test all subset

# Generated at 2022-06-22 22:46:44.517115
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.core import AnsibleCollector

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    module_params = dict(
        fact_file="/foo/bar",
    )

    # try it with a minimal gather_subset
    module_params['gather_subset'] = ['min']

    module = TestModule(module_params)
    facts_dict = get_all_facts(module)

    # make sure it returned something
    assert facts_dict is not None

    # make sure it's not empty
    assert facts_dict != {}

    # make sure it returns valid data
    assert facts_dict['fqdn'] is not None

    # Test the module_utils.facts

# Generated at 2022-06-22 22:46:56.813766
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test that the get_all_facts function returns the same results as
    ansible_collector.get_collector(all)'''

    # a module that we can pretend to execute so we can grab the params
    # This is how AnsibleModule is used.
    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'all'}

    fake_module = FakeModule()

    # get_all_facts should return a dict with no prefix
    get_all_facts_results = get_all_facts(module=fake_module)
    assert isinstance(get_all_facts_results, dict)
    assert len(get_all_facts_results) > 0
    for key in get_all_facts_results.keys():
        assert not key.startswith

# Generated at 2022-06-22 22:47:08.639419
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_facts

    args_dict = {'gather_subset': ['all']}
    m = AnsibleModule(argument_spec={'fetch_timeout': {'type': 'int', 'default': 10},
                                     'gather_subset': {'type': 'list',
                                                       'default': ['all'],
                                                       'elements': 'str'}},
                      params=args_dict)

    # filter='*' will not trim any facts
    assert ansible_facts(m, gather_subset=['all'])
    assert ansible_facts(m)
    assert not ansible_facts(m, gather_subset=['!all'])

# Generated at 2022-06-22 22:47:21.361424
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.namespace as namespace

    all_fact_classes = namespace.FACT_SUBSETS['all']
    all_fact_names = [fact_class.__name__ for fact_class in all_fact_classes]
    all_fact_names.sort()

    class AnsibleModule(object):

        def __init__(self, params):
            self.params = params

    test_ansible_module = AnsibleModule({'gather_subset': ['all'], 'gather_timeout': 10})

    gaf = get_all_facts(module=test_ansible_module)
    gaf_names = sorted(gaf.keys())

    # gaf = dict('ansible_<fact_name>': <fact_value>, ...)
    # gaf_names = ['ansible

# Generated at 2022-06-22 22:47:31.498836
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import add_namespace

    class DummyCollector(BaseFactCollector):
        name = 'dummy'
        _fact_ids = ['dummy']

        def collect(self, module=None, collected_facts=None):
            collected_facts['dummy'] = 'dummy'
            return collected_facts

    default_collectors.collectors.append(add_namespace(DummyCollector()))

    # create a dummy module object
    import ansible.module_utils.basic
    from ansible.module_utils.common.collections import ImmutableDict


# Generated at 2022-06-22 22:47:42.646069
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts import _get_collector_classes

    '''
    Test function ansible_facts by running fake ansible module (called 'module').
    Test passes if ansible_facts returns the same dict as
    get_all_facts(module=fake_module) does.

    Pytest_mock is used to override the 'import' statement (which normally imports
    the module's 'module_utils.facts' module) and replace it with this module
    (a mock version of 'module_utils.facts' module)

    An 'ImmutableDict' is used to simulate an AnsibleModule 'module' object.
    '''

    from ansible.module_utils.facts import get_all_facts

# Generated at 2022-06-22 22:47:53.810432
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.legacy import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import default_gather_subset
    from ansible.module_utils.facts import default_gather_timeout

    class FakeModule():
        '''Fake AnsibleModule'''
        params = {}
        def __init__(self, params):
            self.params = params

    fake_module = FakeModule({'gather_subset': default_gather_subset,
                              'gather_timeout': default_gather_timeout})

    facts_dict = ansible_facts(fake_module)

    assert(len(facts_dict) > 10)
    # test_facts_dict = facts_dict

# Generated at 2022-06-22 22:47:58.472326
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all']),
                                          'filter': dict(default='*', type='list')})

    assert isinstance(get_all_facts(module), dict)


# Generated at 2022-06-22 22:48:04.217522
# Unit test for function get_all_facts
def test_get_all_facts():

    import sys
    import json

    from ansible.module_utils import basic
    from ansible.module_utils.facts import default_collectors

    # create a mock module object because we don't want to talk to a real
    # ansible module.
    class MockAnsibleModule():
        def __init__(self, params):
            self.params = params

    # Setup module parameters
    test_params = {
        'gather_subset': ['all']
    }

    m = MockAnsibleModule(test_params)

    # Run the method under test
    facts_dict = get_all_facts(m)
    print('facts_dict: ', facts_dict)

    # Figure out the distro and test some facts
    distro = facts_dict['distribution_info']['distribution']

# Generated at 2022-06-22 22:48:13.705328
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import FACT_CACHE
    from ansible.module_utils.facts import FACT_CACHE_TIMEOUT
    from ansible.module_utils.facts import FACT_CACHE_PLUGIN
    from ansible.module_utils.facts import FACT_CACHE_PLUGIN_CONNECTION

    from ansible.module_utils import basic
    import json
    import os

    def setup_module_argspec(spec):
        spec.argument_spec.update({'gather_subset': dict(type='list', default=['all']),
                                   'gather_timeout': dict(type='int', default=10),
                                   'filter': dict(type='str', default='*')})

# Generated at 2022-06-22 22:48:26.078178
# Unit test for function ansible_facts
def test_ansible_facts():
    module = MagicMock()


# Generated at 2022-06-22 22:48:30.037900
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    facts = get_all_facts(module=module)

    assert 'default_ipv4' in facts

# Generated at 2022-06-22 22:48:42.364488
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils._text as text
    import ansible.module_utils.facts.collector as facts_collector

    # remove deprecation warning about version.py imports
    ansible_collector = facts_collector

    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils.facts.utils import get_collector_class

    from ansible.module_utils.facts.network.base import NetworkCollector

    from ansible.module_utils.facts.system.base import SystemCollector

    from ansible.module_utils.facts.system.distribution import DistributionCollector

    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrCollector

    from ansible.module_utils.facts.system.platform import PlatformCollector


# Generated at 2022-06-22 22:48:50.162115
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test for fact module_utils.facts.ansible_facts'''

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    all_collector_classes = default_collectors.collectors

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-22 22:48:52.419504
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    assert callable(get_all_facts)

# Generated at 2022-06-22 22:48:58.289821
# Unit test for function ansible_facts
def test_ansible_facts():
    class module_aom(object):
        def __init__(self):
            self.params = {'gather_subset': ['all'],
                           'gather_timeout': 10,
                           'filter': '*',
                           }

    module_instance = module_aom()
    facts = ansible_facts(module_instance, gather_subset=['all'])
    assert isinstance(facts, dict)

# Generated at 2022-06-22 22:49:04.613095
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', required=True)})
    facts = get_all_facts(module)

    print(facts['virtualization_type'])
    print(facts['ansible_virtualization_type'])

    assert facts['ansible_virtualization_type'] == 'kvm'
    assert facts['virtualization_type'] == 'kvm'


if __name__ == '__main__':
    test_get_all_facts()

# Generated at 2022-06-22 22:49:08.974289
# Unit test for function get_all_facts
def test_get_all_facts():
    mock_module = MockAnsibleModule()
    all_facts = get_all_facts(mock_module)
    assert 'default_ipv4' in all_facts
    assert all_facts['default_ipv4']['interface'] == 'lo'


# Generated at 2022-06-22 22:49:18.969745
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.core import get_platform_facts, get_distribution_facts, get_network_facts
    from ansible.module_utils.facts import ansible_collector

    class TestModule(object):
        def __init__(self):
            self.params = {}

    class TestAnsibleModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            if arg == 'ip':
                return '/bin/ip'

        def get_platform(self):
            return 'linux'


# Generated at 2022-06-22 22:49:24.227287
# Unit test for function get_all_facts
def test_get_all_facts():

    # mock an ansible module
    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = None

    # gather_subset = ['!all']
    f = FakeModule({'gather_subset': ['!all']})
    assert ansible_facts(module=f) == {}

    # gather_subset = ['all']
    f = FakeModule({'gather_subset': ['all']})
    assert ansible_facts(module=f) != {}

# Generated at 2022-06-22 22:49:25.998733
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(gather_subset=None) == {}

# Generated at 2022-06-22 22:49:33.973404
# Unit test for function ansible_facts
def test_ansible_facts():

    class MockModule:
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['!all']}
    mock_module = MockModule(params=params)
    fact_dict = ansible_facts(module=mock_module)
    assert not fact_dict

    params = {'gather_subset': ['all'], 'filter': 'ans*'}
    mock_module = MockModule(params=params)
    fact_dict = ansible_facts(module=mock_module)
    assert 'ansible_architecture' in fact_dict



# Generated at 2022-06-22 22:49:36.024141
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts(module=None) == {'default_ipv4': 'test_default_ipv4'}

# Generated at 2022-06-22 22:49:46.445338
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import os
    import mock
    import ansible.module_utils.facts.network.base as network_module

    sys.path.append(os.path.dirname(__file__))
    from units.mock_module import AnsibleModule, MockNetworkModule
    from units.mock_module import MockNetworkModuleFail
    from ansible.module_utils.facts.facts import ansible_facts
    from ansible.module_utils.facts.network.base import MockNetworkConfig

    def mock_get_file_content(path):
        return path

    def mock_get_file_lines(path):
        return path.split('/')

    module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['all'])))

# Generated at 2022-06-22 22:49:56.680557
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.compat.tests.mock import Mock

    fake_module = Mock()
    fake_module.params = dict(
        gather_subset=[],
        gather_timeout=10,
    )

    # here are the results of ansible_facts on a computer that I own

# Generated at 2022-06-22 22:50:01.205599
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})

    gathered_facts = ansible_facts(module)
    import socket
    import datetime
    assert gathered_facts['fqdn'] == socket.getfqdn()
    assert isinstance(gathered_facts['date_time']['iso8601_micro'], datetime.datetime)

# Generated at 2022-06-22 22:50:09.532154
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils import facts as facts_module_utils

    class FakeAnsibleModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['min']

    class FakeNetworkCollector(NetworkCollector):
        def collect(self, module=None, collected_facts=None):
            return {}

    module = FakeAnsibleModule()
    facts_module_utils.default_collectors.collectors.insert(0, FakeNetworkCollector)
    fact_namespace = get_all_facts(module)
    assert fact_namespace.get('network') is not None
    facts_module_utils.default_collectors.collectors.remove(FakeNetworkCollector)




# Generated at 2022-06-22 22:50:10.180709
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-22 22:50:14.322969
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.compat.tests.mock import MagicMock
    module = MagicMock()
    module.params = {'gather_subset': ['all']}
    get_all_facts(module)

# Generated at 2022-06-22 22:50:23.225065
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import module_utils

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {
                'gather_subset': gather_subset
            }

    class FakeModuleUtils(object):
        def __init__(self):
            self.DEFAULT_GATHER_TIMEOUT = 7

        def get_facts(self, module_params, loader, module_path, timeout):
            return {
                'default_ipv4': '1.1.1.1'
            }


# Generated at 2022-06-22 22:50:32.764418
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for ansible_facts function'''

    # Mock AnsibleModule class
    class AnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     mutual_exclusion=None, required_together=None,
                     required_one_of=None, add_file_common_args=False,
                     supports_check_mode=False):
            self.params = {}
            self.argument_spec = argument_spec

    # Mock argument spec
    argument_spec = {
        'filter': {'default': '*', 'type': 'str'},
        'gather_subset': {'default': ['all'], 'type': 'list'},
        'gather_timeout': {'default': 10, 'type': 'int'},
    }

    #

# Generated at 2022-06-22 22:50:39.760875
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts

    facts = get_all_facts(module=None)
    assert isinstance(facts, dict)
    facts = ansible_facts(module=None)
    assert isinstance(facts, dict)



# Generated at 2022-06-22 22:50:47.285385
# Unit test for function ansible_facts
def test_ansible_facts():
    class AnsibleModule:
        def __init__(self, params):
            self.params = params
    params = dict(gather_subset=['all'], gather_timeout=10)
    ansible_facts_dict = ansible_facts(AnsibleModule(params))
    assert ansible_facts_dict
    assert 'system' in ansible_facts_dict['os_family']
    assert 'ascii' in ansible_facts_dict['ansible_default_ipv4'].keys()


# Generated at 2022-06-22 22:50:55.727060
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.modules.system.setup
    import ansible.utils.module_docs
    import ansible.utils.template

    # Note: unload the module plugin manager, which had been loaded in ansible/modules/system/setup
    ansible.utils.module_docs.MODULE_DOC_FILES = {}
    ansible.utils.template.JINJA2_OVERRIDE = {}

    all_facts = ansible.modules.system.setup.main()
    assert (isinstance(all_facts, dict))



# Generated at 2022-06-22 22:51:07.422173
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts.virtual.base import VirtualCollector

    # Function 'get_all_facts' should return dict with bare fact name as key and fact value as
    # value.

    # Create a fake VirtualCollector class
    class FakeVirtualCollector(VirtualCollector):

        @property
        def priority(self):
            return 1

        def collect(self, module=None, collected_facts=None):
            facts_dict = dict()
            facts_dict['ansible_virtual_abc'] = '123'
            return facts_dict

    # Create a fake AnsibleModule class. 'params' is a dict with keys 'gather_subset'
    class FakeAnsibleModule:
        def __init__(self):
            self.params = dict()

# Generated at 2022-06-22 22:51:15.193861
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts
    '''
    import os
    import sys
    module_path = os.path.realpath(os.path.join(os.path.dirname(__file__), '../../', 'lib/ansible/module_utils/facts/'))
    module_path_ansible = os.path.realpath(os.path.join(os.path.dirname(__file__), '../../', 'lib/ansible/module_utils/'))
    sys.path.insert(0, module_path)
    sys.path.insert(0, module_path_ansible)
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.plugins.base import BaseFactCollector
    import mock

# Generated at 2022-06-22 22:51:25.586401
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class MyFactCollector(BaseFactCollector):
        name = 'my_fact_collector'

        def get_facts(self):
            '''The dict returned by get_facts is treated as the value of ansible_facts directly.'''
            return {
                'a': 'A',
                'b': 'B',
                'c': 'C'
            }

    fake_module = FakeAnsibleModule()

    fake_module.params = {
        'gather_subset': ['all'],
        'gather_timeout': 10,
        'filter': '*'
    }

    expected_ansible_facts = {
        'a': 'A',
        'b': 'B',
        'c': 'C'
    }

# Generated at 2022-06-22 22:51:33.959282
# Unit test for function get_all_facts
def test_get_all_facts():
    from mock import Mock
    from io import StringIO

    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}
        def get_bin_path(self, executable, required=False):
            return "/bin/{0}".format(executable)
        def run_command(self, args):
            return 0, "pathname", ""
        def load_file_common_arguments(self):
            return dict()
    fake_module = FakeModule()

    facts_dict = get_all_facts(fake_module)

    assert isinstance(facts_dict, dict)
    assert type(facts_dict['default_ipv4']) == dict
    assert facts_dict['default_ipv4']['address'] == '10.0.2.15'

# Generated at 2022-06-22 22:51:44.862161
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''
    import mock
    import tempfile

    class module_mock(object):
        def __init__(self, module_args):
            self.params = module_args

    tmpfile = tempfile.NamedTemporaryFile()
    data = {'gather_subset': 'all'}
    module = module_mock(data)
    mdata = {'ansible_all_ipv4_addresses': ['10.0.0.1', '172.16.0.1', '192.168.0.1']}


# Generated at 2022-06-22 22:51:55.532042
# Unit test for function get_all_facts
def test_get_all_facts():

    # GIVEN: a 'module' mock object that provides the gather_subset parameter
    # 'gather_subset' is a string
    gather_subset = '!all'
    class Module:
        def __init__(self):
            self.params = {'gather_subset': gather_subset}
    module = Module()

    # WHEN: I call get_all_facts passing in the above module
    facts = get_all_facts(module)

    # THEN: get_all_facts should call module_utils.facts.ansible_facts with gather_subset == [all]
    assert gather_subset == '!all'
    assert facts
    # and facts should be a dict with at least one key
    assert isinstance(facts, dict)
    assert len(facts) > 0


# Generated at 2022-06-22 22:52:06.145830
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import json
    import sys
    # Let us set ANSIBLE_GATHERING to some invalid option, so that we cover the
    # case when file based facts are not returned.
    os.environ['ANSIBLE_GATHERING'] = 'foobar'
    # Let us set ANSIBLE_CACHE_PLUGIN_CONNECTION to some invalid option, so that
    # we cover the case when cache based facts are not returned.
    os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = 'foobar'
    # Let us set ANSIBLE_CACHE_PLUGIN_PREFIX to some invalid option, so that
    # we cover the case when cache based facts are not returned.

# Generated at 2022-06-22 22:52:16.670753
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for ansible_facts'''
    # temp hack until we can require 2.3/2.3 or later
    try:
        from ansible.module_utils.facts import get_module_facts
    except ImportError:
        from ansible.module_utils.facts import get_ansible_facts as get_module_facts
    try:
        ansible_module_facts = get_module_facts(None, 'linux').get_ansible_facts()
    except AttributeError:
        ansible_module_facts = get_module_facts(None, 'linux')
    assert ansible_module_facts['distribution'] in ['debian', 'redhat', 'gentoo', 'arch']

# Generated at 2022-06-22 22:52:21.096408
# Unit test for function get_all_facts
def test_get_all_facts():

    class FakeModule():
        def __init__(self, params):
            self.params = params

    fake_params = {
        "gather_subset": [],
    }

    fake_module = FakeModule(fake_params)

    facts = get_all_facts(fake_module)

    assert isinstance(facts, dict)



# Generated at 2022-06-22 22:52:33.015385
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    class Module:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}
        def fail_json(self, *args, **kwargs):
            pass
    module = Module(['all'])
    # check that gather_subset is set
    facts_dict = get_all_facts(module)

# Generated at 2022-06-22 22:52:43.813892
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Test that the get_all_facts function works as expected'''
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import mock
    import sys

    # Patch the modules to avoid importing the whole module
    m_ansible = mock.MagicMock()
    m_ansible.module_utils.facts.namespace.PrefixFactNamespace = PrefixFactNamespace
    m_ansible.module_utils.facts.ansible_collector = ansible_collector
    m_ansible.module_utils.facts.default_collectors = default_collectors
    sys.modules['ansible'] = m_ansible

    # Create a mock module to test

# Generated at 2022-06-22 22:52:54.511926
# Unit test for function ansible_facts
def test_ansible_facts():

    filters = [{'filter':'ansible_hostname'}]

    for subset in [{'gather_subset':['!all']}]:
        for timeout in [{'gather_timeout':1}]:
            for filter in filters:
                for param in [subset, timeout, filter]:
                    print(param)
                    try:
                        from ansible.module_utils.facts.utils import AnsibleFailJson
                        from ansible.module_utils.facts.utils import AnsibleModule
                    except ImportError:
                        try:
                            from ansible.module_utils.facts import AnsibleFailJson
                            from ansible.module_utils.facts import AnsibleModule
                        except ImportError:
                            pass

                    module = AnsibleModule(argument_spec=param)

# Generated at 2022-06-22 22:53:02.265897
# Unit test for function get_all_facts
def test_get_all_facts():

    # mock module class
    class AnsibleModule:
        def __init__(self, params):
            self.params = params

    test_params = {
        'gather_subset': ['all'],
        'gather_timeout': 10,
    }

    test_module = AnsibleModule(test_params)

    test_result = get_all_facts(test_module)

    assert 'cmdline' in test_result
    assert 'dns' in test_result



# Generated at 2022-06-22 22:53:13.795485
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.system import distribution

    all_collector_classes = default_collectors.collectors

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    fact_collector = \
        ansible_collector.get_ansible_collector(all_collector_classes=all_collector_classes,
                                                namespace=namespace,
                                                filter_spec='*',
                                                gather_subset='all',
                                                gather_timeout=10,
                                                minimal_gather_subset=frozenset(['ansible_distribution']))

    facts_dict = fact_collector.collect()

    assert 'distribution' in facts_dict['ansible_fact_namespace_blacklist']

# Generated at 2022-06-22 22:53:21.173486
# Unit test for function get_all_facts
def test_get_all_facts():
    # mock of module.params dict
    args = dict(gather_subset = ['all', 'network'])

    # mock of ansible module
    class FakeModule:
        def __init__(self, params):
            self.params = params
    fake_module = FakeModule(args)

    facts = get_all_facts(fake_module)

    # assert facts is a dict
    assert isinstance(facts, dict)

    # assert facts is not empty
    assert facts

    # assert items in facts are not empty
    for name in facts:
        assert facts[name]
