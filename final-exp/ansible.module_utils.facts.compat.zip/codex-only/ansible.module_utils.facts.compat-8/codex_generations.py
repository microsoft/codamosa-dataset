

# Generated at 2022-06-22 22:43:29.536607
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.basic
    from ansible.module_utils.facts import default_collectors
    import ansible.module_utils.facts.network.default
    reload(ansible.module_utils.facts.network.default)

    # Build a dict mapping fact_name -> fact_value for the facts that we expect
    # to be collected by get_all_facts() for the module_setup parameters that we
    # setup below.
    #
    # NOTE: We avoid merging out 'ansible_' prefix and add the prefix here. This
    # avoids a bunch of code and symmetry issues right now. The reason that we
    # use the prefix setup here is that is the prefix used in AnsibleModule.
    # The prefix used in AnsibleModule is the same as used in the ansible_facts()
    # method, so we'll use that

# Generated at 2022-06-22 22:43:35.503809
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule:
        def __init__(self):
            self.params = {
                'gather_subset': ['all'],
                'gather_timeout': 10
            }

    fake_module = FakeModule()

    all_facts = ansible_facts(fake_module)

    assert isinstance(all_facts, dict)
    assert 'lsb' in all_facts



# Generated at 2022-06-22 22:43:44.372017
# Unit test for function ansible_facts
def test_ansible_facts():

    # need a fake ansible module to pass the the ansible_facts function

    class FakeAnsibleModule(object):

        def __init__(self, **kwargs):
            self.params = kwargs

    # FakeAnsibleModule should (by default) return all facts, since no filters
    # were passed.
    allfacts = ansible_facts(FakeAnsibleModule())
    assert len(allfacts) >= 42, 'Expected at least 42 facts to be returned, got %i' % len(allfacts)

    # Now, ask for a subset of facts
    subfacts = ansible_facts(FakeAnsibleModule(gather_subset=['network']))
    assert len(subfacts) > 1, 'Expected at least 1 fact to be returned, got %i' % len(subfacts)

# end unit test

# Generated at 2022-06-22 22:43:52.368588
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    # noinspection PyMissingOrEmptyDocstring
    class FakeModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(FakeModule, self).__init__(*args, **kwargs)
            self.params = {'gather_subset': ['!all']}

    assert len(get_all_facts(FakeModule())) > 0

# Generated at 2022-06-22 22:43:54.467129
# Unit test for function get_all_facts
def test_get_all_facts():
    module = dict(gather_subset = '')
    facts = get_all_facts(module)
    assert len(facts) > 50

# Generated at 2022-06-22 22:44:01.884510
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.network import Network

    original_collectors = collector.network.Network.__dict__['collectors']
    del collector.network.Network.__dict__['collectors'][1:]

    from ansible.compat.tests.mock import patch
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import mock_open
    import ansible.module_utils.facts.collector.network


# Generated at 2022-06-22 22:44:11.846242
# Unit test for function get_all_facts
def test_get_all_facts():

    # The module.params['gather_subset'] is a yaml list, so we can't create a direct dict sub
    mock_module = dict()
    mock_module['ansible_facts'] = dict()
    mock_module['_params'] = dict()
    mock_module['_params']['gather_subset'] = ['all']

    facts = get_all_facts(mock_module)

    assert 'machine' in facts
    assert 'os' in facts
    assert 'distribution' in facts
    assert 'fqdn' in facts
    assert 'hostname' in facts
    assert 'kernel' in facts



# Generated at 2022-06-22 22:44:21.895046
# Unit test for function get_all_facts
def test_get_all_facts():
    # only test the get_all_facts function if ansible <= 2.3 is available
    try:
        from ansible.module_utils.facts.facts import get_all_facts as _get_all_facts
    except ImportError:
        return

    class FakeModule(object):
        def __init__(self, gather_subset=[]):
            self.params = {
                'gather_subset': gather_subset
            }

    module = FakeModule()
    assert get_all_facts(module) == _get_all_facts(module)

    etag = '"aab6d33d6aeafb8e23f09dc644b069c7011f65c8"'
    module = FakeModule(['hardware'])
    assert get_all_facts(module) == _get_all_facts

# Generated at 2022-06-22 22:44:23.506996
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for ansible_facts'''

    # just a stub
    module = None
    assert ansible_facts(module)

# Generated at 2022-06-22 22:44:30.050766
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.__main__ import main
    import argparse
    import sys
    import json

    parser = argparse.ArgumentParser(description='Ansible Module Facts')
    parser.add_argument('--name', required=True, default='joe')
    args = parser.parse_args()
    module = AnsibleModule(argument_spec={}, params=args.__dict__)

    main(module=module)
    # print(json.dumps(facts))



# Generated at 2022-06-22 22:44:39.531338
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    import os
    import sys

    # Build mocks
    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': None,
                           'gather_timeout': 10,
                           'filter': '*',
                           }

    class MockOpen(object):
        def __init__(self, filename):
            self.filename = filename

        def read(self):
            if self.filename == '/proc/sys/kernel/fips_enabled':
                return '1\n'
            raise Exception("This code path shouldn't be hit")

    class MockSSHKey(object):
        def __init__(self, key_data):
            self.key_data = key_data

# Generated at 2022-06-22 22:44:49.566307
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils import basic

    module = ansible_collector.AnsibleModuleStub(argument_spec={'gather_subset': dict(type='str', default='all'),
                                                                'filter': dict(type='str', default='*'),
                                                                'gather_timeout': dict(type='int', default=10),
                                                                'gather_network_resources': dict(type='bool', default='no')
                                                                },
                                                 supports_check_mode=False)
    gather

# Generated at 2022-06-22 22:45:00.858373
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import sys
    import unittest
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes

    # mock ansible module
    class MockAnsibleModule:
        def __init__(self):
            self.params = {
                'gather_subset': ['all'],
                'gather_timeout': 10,
                'filter': '*'
            }

        def get_bin_path(self, exe, required=False, opt_dirs=[]):
            return '/bin/' + exe

# Generated at 2022-06-22 22:45:10.809478
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import sys

    # AnsibleModule is an object from ansible, don't move this import into the function body
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import cached_facts

    # if not cached, the system is calling this module, not our unit tests
    if not cached_facts.FACTS:
        module = AnsibleModule(argument_spec=dict(gather_subset=dict(type='list', default=['!all', '!any']),
                                                  gather_timeout=dict(type='int', default=10),
                                                  filter=dict()))

        # fake that we are on a system with ansible_local factset

# Generated at 2022-06-22 22:45:23.009960
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    import mock

    # Create a mock ansible.module_utils.facts.collector.base.BaseFactCollector._get_collection_methods_from_collector method that
    # returns a list of two collection methods
    base_fact_collector_mock = mock.MagicMock()
    base_fact_collector_mock.configure_mock(**{'_get_collection_methods_from_collector.return_value': [('os_version', lambda: {'os_version': '10'}),
                                                                                                     ('os_family', lambda: {'os_family': 'RHEL'})]})

    # patch the ansible.module_utils.facts.ansible_collector.get_ansible_

# Generated at 2022-06-22 22:45:28.539745
# Unit test for function ansible_facts
def test_ansible_facts():

    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={}, bypass_checks=True)

    # gather_subset should be optional
    facts = ansible_facts(module)

    # gather_subset should be optional
    facts = ansible_facts(module, gather_subset=['all'])

    # filter should be optional
    facts = ansible_facts(module)

# Generated at 2022-06-22 22:45:33.669192
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    dummy module object
    '''
    class DummyModule(object):
        pass

    module = DummyModule()
    module.params = {'gather_subset': ['all']}
    facts = get_all_facts(module)
    dns_fact_found = False
    for fact in facts:
        if 'dns' in fact:
            dns_fact_found = True

    assert dns_fact_found == True


# Generated at 2022-06-22 22:45:44.468730
# Unit test for function get_all_facts
def test_get_all_facts():

    # The results of the get_all_facts call should be returned
    # correctly when a valid module is passed as an argument.
    module = MockAnsibleModule()
    module.params = dict(gather_subset=['all'])
    results = get_all_facts(module)
    assert results['os_family'] == 'RedHat'

    # If a module with a gather_subset parameter that is a list is
    # passed as an argument, the results of the get_all_facts call
    # should be returned correctly.
    module = MockAnsibleModule()
    module.params = dict(gather_subset=[])
    results = get_all_facts(module)
    assert results['os_family'] == 'RedHat'

    # If a module with a gather_subset parameter that is a string is
    #

# Generated at 2022-06-22 22:45:50.588904
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import os

    module_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    if module_path not in sys.path:
        sys.path.append(module_path)
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self):
            self.params = dict()

    class FakeAnsibleModule(AnsibleModule):
        def __init__(self):
            self.params = dict()
            self.module = FakeModule()

    # test 2.3/2.4 API expecting gather_subsets
    fake_ansible_module = FakeAnsibleModule()

# Generated at 2022-06-22 22:45:58.859103
# Unit test for function get_all_facts
def test_get_all_facts():
    module = FakeAnsibleModule()
    # gather_subset not passed, so should default to the DEFAULT_GATHER_SUBSET
    assert get_all_facts(module) == {'hostname': 'hostname'}
    assert get_all_facts(module) == ansible_facts(module, gather_subset=['all'])

    # gather_subset passed, it should be used
    module.params['gather_subset'] = ['min', '!all']
    assert get_all_facts(module) == ansible_facts(module, gather_subset=['!all', 'min'])



# Generated at 2022-06-22 22:46:04.630170
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import tempfile
    import shutil
    import pytest
    import sys

    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

    from test.units.compat import unittest
    from test.units.compat.mock import patch
    from test.units.mock import Mock

    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_version
    from ansible.module_utils.facts.utils import get_all_subclasses

    # create a temp dir to test in
    tmpdir = tempfile.mkdtemp()
    cur

# Generated at 2022-06-22 22:46:16.092967
# Unit test for function ansible_facts
def test_ansible_facts():

    module = MagicMock()
    module.params = {
        'gather_subset': ['min', '!all'],
        'gather_timeout': 5,
        'filter': 'ansible_eth*',
    }

    facts_dict = ansible_facts(module)


# Generated at 2022-06-22 22:46:25.332669
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.network as network_facts

    # In order to test this function, we need to mock an AnsibleModule.
    # We can use the unit test moduleFakeAnsibleModule to do this.
    from ansible.module_utils.facts.test import module_test
    module = module_test()

    # We also need to mock the fact collectors.
    # Since this is a unit test for get_all_facts, we don't need to go
    # through the default collector classes list, we'll just make a list
    # of collectors ourself.
    #
    # The network.py module contains the network collector.
    # The network collector sets the ansible_all_ipv4_addresses fact.
    #
    # So, to verify that get_all_facts has run, we can simply check
   

# Generated at 2022-06-22 22:46:30.640133
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.compat.tests.mock import patch

    module = patch('ansible.module_utils.facts.ansible_collector.AnsibleModule').start()

    module.params = dict(gather_subset='all')

    all_facts = get_all_facts(module)
    assert len(all_facts) > 0, 'failed to collect all facts'



# Generated at 2022-06-22 22:46:38.264156
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts.collector.generic import GenericFactCollector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils import basic
    import sys

    class FakeAnsibleModule(basic.AnsibleModule):
        def __init__(self, opts):
            super(FakeAnsibleModule, self).__init__(opts)


# Generated at 2022-06-22 22:46:47.858778
# Unit test for function ansible_facts
def test_ansible_facts():
    # stub AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    class AnsibleModule:
        def __init__(self, *args, **kwargs):
            self.params = dict(*args, **kwargs)
            self.params['filter'] = '*'
            self.params['gather_timeout'] = 1
            self.params['gather_subset'] = ['all']
    module = AnsibleModule()

    # get the facts for this host
    all_ansible_facts = ansible_facts(module=module)
    # and pick some facts to check
    assert 'system' in all_ansible_facts
    assert 'hostname' in all_ansible_facts
    assert 'ipv4' in all_ansible_facts

# Generated at 2022-06-22 22:46:59.343067
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.module_utils.facts import DEFAULT_GATHER_SUBSET, DEFAULT_GATHER_TIMEOUT
    from ansible.module_utils.facts.module_utils.facts import ansible_facts

    DEFAULT_GATHER_SUBSET_EXPECTED = frozenset(['all', 'min'])

    expected_default_gather_subset = DEFAULT_GATHER_SUBSET
    actual_default_gather_subset = DEFAULT_GATHER_SUBSET_EXPECTED

    assert expected_default_gather_subset == actual_default_gather_subset

    expected_default_gather_timeout = DEFAULT_GATHER_TIMEOUT
    actual_default_gather_timeout = 10

    assert expected_default_gather_timeout == actual_default_

# Generated at 2022-06-22 22:47:10.238313
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.ansible_fact_cache import BaseFactCacheModule
    import time
    import datetime

    class FakeFactCollector(object):
        def __init__(self, fact_cache): 
            self.fact_cache = fact_cache
            self.current_timestamp = time.time()

        def _load_from_file(self, module):
            return "fake_file_fact"

        def _generate_facts_dict(self, module):
            facts_dict = {}
            for key, value in self.fact_cache.items():
                namespace = value.get('namespace')
                fact_name = value.get('fact_name')
                fact_value = value.get('fact_value')

# Generated at 2022-06-22 22:47:21.600411
# Unit test for function get_all_facts
def test_get_all_facts():

    class AnsibleModuleFake(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    module = AnsibleModuleFake(gather_subset=['all'])

    facts = get_all_facts(module)

    assert isinstance(facts, dict)
    assert isinstance(facts['ansible_all_ipv4_addresses'], list)
    assert 'ansible_default_ipv4' in facts
    assert 'ansible_default_ipv6' in facts
    assert 'ansible_swapfree_mb' in facts
    assert 'ansible_distribution_version' in facts
    assert 'ansible_machine' in facts
    assert 'ansible_memory_mb' in facts

# Generated at 2022-06-22 22:47:27.968322
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.modules.network.brocade import bcf_facts

    module = bcf_facts.AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!config'], type='list')
    })

    assert get_all_facts(module) == ansible_facts(module)


if __name__ == '__main__':
    test_get_all_facts()

# Generated at 2022-06-22 22:47:33.801791
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    def test_module(**kwargs):
        argument_spec = dict(gather_subset=dict(type='list', default=['all'], required=False))
        argument_spec.update(kwargs)
        module = AnsibleModule(argument_spec=argument_spec)
        facts = get_all_facts(module)
        return facts

    facts = test_module()
    assert 'default_ipv4' in facts

    facts = test_module(gather_subset=['network', 'virtual'])
    assert 'default_ipv4' in facts

# Generated at 2022-06-22 22:47:43.645584
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.hardware.base import Hardware, HardwareCollector
    from ansible.module_utils.facts.system.base import System, SystemCollector
    from ansible.module_utils.facts.virtual.lxc import Lxc, LxcCollector
    from ansible.module_utils.facts.virtual.lxd import Lxd, LxdCollector
    from ansible.module_utils.facts.virtual.docker import Docker, DockerCollector
    from ansible.module_utils.facts.virtual.ovirt import Ovirt, OvirtCollector
    from ansible.module_utils.facts.virtual.openstack import OpenStack, OpenStackCollector
    from ansible.module_utils.facts.virtual.vmware import VMware, VMwareCollector
    from ansible.module_utils.facts.virtual.vbox import V

# Generated at 2022-06-22 22:47:54.235058
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import BytesIO

    class FakeAnsibleModule(object):
        def __init__(self, params):
            self.params = params

    # Testing case when gather_subset is not present in the params
    fake_module_params = {'filter': 'fake_filter'}
    facts = Facts(FakeAnsibleModule(fake_module_params))
    facts_dict = get_all_facts(facts)
    assert set(facts_dict.keys()) == set(AN_FACTS_DICT.keys())
    assert facts_dict == AN_FACTS_DICT
    facts_json = facts.get_facts(False)

# Generated at 2022-06-22 22:48:06.699033
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.basic
    import ansible.module_utils.facts
    import sys

    class TestModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self):
            super(TestModule, self).__init__(argument_spec={
                'gather_subset': dict(default=['all'], type='list'),
                'gather_timeout': dict(default=10, type='int'),
            })

    m = TestModule()
    gathered_facts = ansible.module_utils.facts.get_all_facts(m)
    assert isinstance(gathered_facts, dict)

# Generated at 2022-06-22 22:48:14.428622
# Unit test for function ansible_facts
def test_ansible_facts():
    """unit test for ansible_facts python function"""

    import sys
    import os
    import pytest
    import tempfile
    # Due to the intricacies of the import system and how ansible modules execute
    # we need to add the src and tests path to sys.path so that we can import
    # the code that is in src.
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../src/'))
    from ansible.module_utils.facts.transform import transform_collected_facts

    from ansible.module_utils.facts.utils import FactsFiles
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts import default

# Generated at 2022-06-22 22:48:26.625018
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Unit test for function ansible_facts '''

    MOCK_MODULE_PARAMS = dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*',
    )
    MOCK_MODULE = Mock()
    MOCK_MODULE.params = MOCK_MODULE_PARAMS

    # catch deprecation warning and reduce noise
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')

        facts = ansible_facts(MOCK_MODULE)

        # no deprication warning
        assert len(w) == 1
        assert issubclass(w[-1].category, DeprecationWarning)

# Generated at 2022-06-22 22:48:33.495312
# Unit test for function ansible_facts

# Generated at 2022-06-22 22:48:44.751026
# Unit test for function ansible_facts
def test_ansible_facts():
    # unit tests require:
    #   1. the test module to be importable
    #   2. the test module can be instantiated as a module object
    #   3. the module object exposes a 'params' dict that looks like it comes from an AnsibleModule
    #   4. the AnsibleModule 'params' has a 'gather_subset' that defaults to ['all']

    # mock out the module object
    module = mock.Mock()
    module.params = dict(gather_subset=['all'])

    # get the facts
    facts = ansible_facts(module)

    # make sure we got something back
    assert facts is not None

    # make sure we got a few basic facts back we would expect
    assert facts.get('fips') is not None

# Generated at 2022-06-22 22:48:48.009629
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    assert isinstance(ansible_facts, object)


# Generated at 2022-06-22 22:48:58.906131
# Unit test for function ansible_facts
def test_ansible_facts():
    def mock_run_command(self, *args, **kwargs):
        raise Exception('run_command should not be called by ansible_facts')

    # monkey patch for unit testing
    ansible_facts.run_command = mock_run_command

    class MockAnsibleModule:
        def __init__(self, *args, **kwargs):
            self.params = kwargs

    # test with all the facts
    mod = MockAnsibleModule(gather_subset=['all'], gather_timeout=10, filter='dummy')
    facts1 = ansible_facts(mod)
    assert len(facts1) > 100

    # test with no facts
    mod = MockAnsibleModule(gather_subset=[], gather_timeout=10, filter='dummy')

# Generated at 2022-06-22 22:49:05.469173
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.common.collections import ImmutableDict

    class FakeAnsibleModule:
        def __init__(self):
            self.params = {}

    module = FakeAnsibleModule()
    gather_subset = ['!all']
    facts_dict = ansible_facts(module, gather_subset)
    assert isinstance(facts_dict, dict)

# Generated at 2022-06-22 22:49:15.904289
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.system.distribution import Distribution
    test_subset = ['network', 'hardware']
    class TestModule(object):
        def __init__(self):
            self.params = dict(gather_subset=test_subset)
    test_module = TestModule()

    # first test with the namespace prefix
    # mocking Distribution.get_distribution method
    # to return fake values
    Distribution.get_distribution = lambda self: {'distribution': 'test', 'major_version': '1', 'minor_version': '0', 'distribution_release': 'test-realease'}
    facts = get_all_facts(test_module)
    assert facts['distribution'] == 'test'
    assert facts['distribution_version'] == '1.0'

# Generated at 2022-06-22 22:49:24.028376
# Unit test for function get_all_facts
def test_get_all_facts():
    from .utils import TestAnsibleModule
    m = TestAnsibleModule()

# Generated at 2022-06-22 22:49:28.074653
# Unit test for function get_all_facts
def test_get_all_facts():
    # set up test data/code
    import os
    import sys
    import json

    # Store current working directory to restore
    # at the end of the test
    cwd_orig = os.getcwd()

    # Change to test directory
    os.chdir(os.path.join(os.path.dirname(__file__)))

    module_name = 'test_module.py'
    module_args = {}
    module_args['gather_subset'] = ['all']
    module_args['gather_timeout'] = 10

    # make a test module to call get_all_facts
    # module code is in test/moduleutils/ansible_test_module.py

# Generated at 2022-06-22 22:49:36.183873
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes
    import pytest

    class MockModule(object):
        params = {}

    mock_module = MockModule()

    # get_all_facts is a compat api. It doesn't exist in Ansible 2.3, but is still available
    # via the default_collectors import.
    # This is the modern way of collecting facts in Ansible 2.3.
    my_facts_dict = get_all_facts(module=mock_module)

    # This is the way you fetched facts in Ansible 2.2
    my_facts_dict2 = ansible_facts(module=mock_module)

    # the output from these two should be the same.
    assert my_facts_dict == my

# Generated at 2022-06-22 22:49:46.591307
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    # test with all gather_subset keys
    for gather_subset in default_collectors.DEFAULT_GATHER_SUBSET:
        module = MockModule(gather_subset=[gather_subset])
        facts_dict = get_all_facts(module)
        assert isinstance(facts_dict, dict)
        assert len(facts_dict) > 0

    # test with an invalid gather_subset parameter
    module = MockModule(gather_subset=['invalid'])
    facts_dict = get_all_facts(module)
    assert isinstance(facts_dict, dict)


# Generated at 2022-06-22 22:49:56.774296
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_text
    from sys import version_info

    if version_info[0] == 2:
        import sys
        import mock
        import __builtin__ as builtins  # pylint: disable=import-error
        import types

        class MockModule(object):
            def __init__(self, params):
                self.params = params

            def fail_json(self, msg, **kwargs):  # pylint: disable=unused-argument
                self.msg = msg

        OPTIONS = ['update_cache', 'reboot', 'reboot_timeout', 'gather_subset',
                   'filter', 'gather_timeout']

        EXTRAS = ['gather_subset']

        load_file

# Generated at 2022-06-22 22:50:00.244923
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic

    class AnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}
    module = AnsibleModule()
    assert get_all_facts(module)


# Generated at 2022-06-22 22:50:08.873870
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    unit test for function get_all_facts
    '''

    from ansible.module_utils.facts import cache
    from ansible.module_utils.six import PY3

    # limit the set of facts collected
    gather_subsets_param = frozenset(['all', 'network'])

    # make a fake 'module' object
    class Module(object):
        def __init__(self, params):
            self.params = params

    module = Module(params={'gather_subset': gather_subsets_param})

    # set cache_dir to None, since this is too difficult to mock
    cache.CACHE_PLUGIN_PATH = None

    # collect facts
    facts_dict = get_all_facts(module=module)

    # make sure we collected some facts
    assert facts_

# Generated at 2022-06-22 22:50:14.477991
# Unit test for function ansible_facts
def test_ansible_facts():

    class MockAnsibleModule(object):
        def __init__(self, params):
            self.params = params

    params = {
        'gather_subset': ['all']
    }
    module = MockAnsibleModule(params)

    facts = ansible_facts(module)
    assert facts

# Generated at 2022-06-22 22:50:23.305190
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    def test_class(module):
        '''passed as the 'module' arg to ansible_facts'''
        pass

    test_class.params = {
        'gather_timeout': 10,
        'gather_subset': ['all'],
        'filter': '*',
    }


# Generated at 2022-06-22 22:50:32.866163
# Unit test for function ansible_facts
def test_ansible_facts():
    '''test function ansible_facts.  We will use a mock AnsibleModule for convenience'''
    from ansible.module_utils.facts import m_ansible_module
    module = m_ansible_module('ansible_facts')
    facts_dict_with_all_defaults = ansible_facts(module=module)
    print(facts_dict_with_all_defaults)
    assert isinstance(facts_dict_with_all_defaults, dict)

    assert 'default_ipv4' in facts_dict_with_all_defaults
    assert 'distribution' in facts_dict_with_all_defaults
    assert 'kernel' in facts_dict_with_all_defaults
    assert 'lsb' in facts_dict_with_all_defaults
    assert 'lsb_distrib_id'

# Generated at 2022-06-22 22:50:44.765621
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    import pytest
    @pytest.fixture
    def real_module():
        from ansible.module_utils.basic import AnsibleModule
        module = AnsibleModule(argument_spec={
            'gather_subset': dict(type='list', default=['all']),
            'gather_timeout': dict(type='int', default=10),
            'filter': dict(default='*'),
        })
        return module

    def test_get_all_facts__all_default(real_module):
        actual = get_all_facts(real_module)
        assert isinstance(actual, dict)
        assert 'localhost' in actual['ansible_hostname']
        assert 'localhost' in actual['ansible_fqdn']


# Generated at 2022-06-22 22:50:54.440449
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.test.test_default_collectors import TestCallbackModule
    import os

    cb = TestCallbackModule()
    module = cb.ansible_module_instance
    os.environ['HOME'] = '/home/mock_default_user'
    facts = ansible_facts(module, gather_subset={'virtual'})
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'kvm'

# Generated at 2022-06-22 22:51:06.193449
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.util import FactsLoader
    import os

    fact_path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

    module_finder = FactsLoader(fact_path)
    all_facts_module = module_finder.find_all_facts_module()
    all_facts = all_facts_module(module_name='all_facts')


# Generated at 2022-06-22 22:51:14.533599
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    module.params = {'gather_subset': ['min']}
    module.run_command = lambda args, check_rc=True: 'Linux x.y.z.f 4.1.2-200.fc22.x86_64 #1 SMP Tue Aug 25 19:56:57 UTC 2015 x86_64 x86_64 x86_64 GNU/Linux'
    all_facts = get_all_facts(module)
    if not isinstance(all_facts, dict):
        raise AssertionError('Expected all_facts to be a dict, got %s' % type(all_facts))

# Generated at 2022-06-22 22:51:24.995038
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    if sys.version_info.major < 3:
        from mock import patch, MagicMock
        from io import BytesIO
    else:
        from unittest.mock import patch, MagicMock
        from io import StringIO

    test_module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(type='list', default='all'),
        gather_timeout=dict(type='int', default=10),
        filter=dict(type='str', default='*')
    ))


# Generated at 2022-06-22 22:51:33.539129
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.hardware.bsd import Hardware
    from ansible.module_utils.facts import namespace

    class FakeModule(object):
        '''Fake module class to use for testing get_all_facts.

        Returns a hard coded value for the gather_subset module param.
        '''

        def __init__(self):
            self.params = {'gather_subset': ['all']}

    bsd_facts = Hardware(FakeModule).populate()
    namespace_facts = namespace.populate(FakeModule)
    linux_facts = ansible_facts(FakeModule)

    # assert that the expected number of facts are present
    assert len(bsd_facts.keys()) == 54
    assert len(linux_facts.keys()) == 60
    assert len(namespace_facts.keys()) == 1

# Generated at 2022-06-22 22:51:44.645660
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.modules.system.setup import main as setup
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_native

    # Test importing AnsibleModule class
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        # Prior to Ansible 2.0
        from ansible.module_utils.basic import *

    result = setup(AnsibleModule(
        argument_spec=dict(
            filter=dict(required=False)
        ),
        bypass_checks=True
    ))

    assert isinstance(result, Mapping)
    assert 'ansible_facts' in result

# Generated at 2022-06-22 22:51:55.398365
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible_collections.notstdlib.moveitallout.tests.units.compat.mock import Mock
    from ansible_collections.notstdlib.moveitallout.plugins.modules import configure_fortigate
    import json

    gather_subset = ['!all', 'min']

    module = configure_fortigate
    module.params = {'gather_subset': gather_subset}
    module.params['gather_timeout'] = 10

    get_all_facts(module)
    assert module._verbosity == 3

    module = configure_fortigate
    module.params = {'gather_subset': gather_subset}
    module.params['gather_timeout'] = 10
    module._verbosity = 0
    module.exit_json = Mock(return_value=True)


# Generated at 2022-06-22 22:52:08.072093
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.utils import ansible_collector

    # Mock class with mock method collect.
    class FakeModule(MutableMapping):
        '''fake module class.  used to test that we can tolerate a 'module' object
        that implements a configurable number of ansible module parameters.  AnsibleModules
        implement at least gather_subset and gather_timeout.'''

# Generated at 2022-06-22 22:52:18.849117
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_facts
    import copy

    module = get_facts(suppress_facts=True)

    # normal gather_subset behavior
    facts_dict = ansible_facts(module)
    assert facts_dict

    # gather_subset can be a string (not list)
    facts_dict = ansible_facts(module, gather_subset='network')
    assert facts_dict

    # gather_subset can be a frozenset
    facts_dict = ansible_facts(module, gather_subset=frozenset(['network']))
    assert facts_dict

    # gather_subset can be a set
    facts_dict = ansible_facts(module, gather_subset=set(['network']))
    assert facts_dict

    # can use 'defaults' gather

# Generated at 2022-06-22 22:52:30.562076
# Unit test for function ansible_facts
def test_ansible_facts():

    import unittest
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule:
        params = dict()

    class FakeCollector(object):
        def __init__(self, gather_subset):
            self.gather_subset = gather_subset

        def collect(self, module):
            return {'gather_subset': self.gather_subset}

    class FakeFactsCollector(object):
        def get_ansible_collector(all_collector_classes=None, namespace=None,
                                  filter_spec=None, gather_subset=None,
                                  gather_timeout=None, minimal_gather_subset=None):
            if gather_subset is None:
                gather_subset = ['all']

# Generated at 2022-06-22 22:52:32.498794
# Unit test for function ansible_facts
def test_ansible_facts():
    pass


# Generated at 2022-06-22 22:52:43.304174
# Unit test for function get_all_facts
def test_get_all_facts():
    # pylint: disable=unused-variable
    from ansible.module_utils.facts import __fact_cache__
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['all'],'filter': '*'}
            self.GATHER_SUBSET = 'all'
            self.GATHER_INTERVAL = 600
            self.GATHER_TIMEOUT = 10
    fake_module = FakeModule()

    filter_spec = fake_module.params.get('filter', '*')


# Generated at 2022-06-22 22:52:53.993943
# Unit test for function get_all_facts
def test_get_all_facts():
    import mock
    import types

    # NOTE: The AnsibleModuleMock is not a mock.Mock object. It is a FakeModule
    # object.
    #
    # FakeModule is a minimal AnsibleModule object that has a 'params' dict
    # attribute and a minimal 'fail_json' method.

    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            pass

    class FakeFactsModule(FakeModule):
        def fail_json(self, **kwargs):
            pass

    source_vars = {'foo': 'bar'}
    subset_vars = {'a': 'b'}
    gather_subset = ['default', 'foo']
    gather_timeout = 1
    filter_spec = '*'


# Generated at 2022-06-22 22:53:04.992075
# Unit test for function get_all_facts
def test_get_all_facts():

    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import cache

    class FakeModule(object):

        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)

        def get_bin_path(self, binary, required=False, opt_dirs=[]):
            return '/bin/' + binary

        def get_module_path(self):
            return '/fake/module/path'

    # for 2.2+ compat, gather_subset is not optional in get_all_facts
    gather_subset = ['min']
    module = FakeModule(gather_subset)

    # clear the cache
    cache.FACT_CACHE = dict()

    all_facts = get

# Generated at 2022-06-22 22:53:15.519077
# Unit test for function ansible_facts
def test_ansible_facts():
    '''test ansible_facts compat api, for ansible 2.0/2.3

    2.3/2.3 expects a gather_subset arg.
    2.0/2.1 does not except a gather_subset arg

    So test ansible_facts with gather_subset as an optional arg, and test both cases.
    '''
    import pytest
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import FactNamespace

   

# Generated at 2022-06-22 22:53:23.684842
# Unit test for function get_all_facts
def test_get_all_facts():

    # compat api for ansible 2.2/2.3 module_utils.facts.get_all_facts method
    class AnsibleModule(object):
        def __init__(self, params):
            self.params = params

    m = AnsibleModule({'gather_subset': ['all']})
    fact_dict = get_all_facts(m)
    assert 'fqdn' in fact_dict
    # check os_family exists
    assert 'os_family' in fact_dict
    # check os_version exists
    assert 'os_version' in fact_dict