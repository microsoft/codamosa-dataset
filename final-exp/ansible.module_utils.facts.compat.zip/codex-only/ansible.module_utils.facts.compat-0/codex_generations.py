

# Generated at 2022-06-22 22:43:21.332873
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):
        params = dict(gather_subset=dict(all=True))

    module = FakeModule()
    get_all_facts(module)

# Generated at 2022-06-22 22:43:31.408439
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.network import NetworkCollector
    import os
    import json
    import unittest

    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, *args, **kwargs):
            raise AssertionError('Module should not fail_json')

    class TestNetworkCollector(NetworkCollector):
        def __init__(self, *args, **kwargs):
            super(TestNetworkCollector, self).__init__(*args, **kwargs)

        def _parse_routes_output(self, output):
            # No route to 'bar' device
            return iter([])


# Generated at 2022-06-22 22:43:41.222697
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts.collector.local import FactsCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector

    from ansible.module_utils.facts.network.base import NetworkCollector

    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    gather_timeout = 10

    class DummyModule(object):
        def __init__(self):
            self.params = dict(gather_timeout=gather_timeout)

    dummy_module = DummyModule()

    fact_collector = FactsCollector()
    fact_collector.collect(module=dummy_module)
    fact_collector.populate()

    minimal_g

# Generated at 2022-06-22 22:43:50.730014
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.system.distribution

    class FakeModule:
        # AnsibleModule is a class, not an instance, so FakeModule mimics the API
        # of AnsibleModule's __init__
        def __init__(self, **kwargs):
            self.params = kwargs

    fake_module = FakeModule(gather_subset=['all'])

    def fake_collect(self, module):
        # Fake the ansible_facts collector
        return {'ansible_lsb': {'distrib_description': 'RancherOS v1.3.1'}}

    old_fake_collect = ansible.module_utils.facts.system.distribution.Distribution.collect
    ansible.module_utils.facts.system.distribution.Distribution.collect = fake_collect
    facts

# Generated at 2022-06-22 22:43:59.434488
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class _noop_module(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['all']

    class _noop_module2(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 5

    m1 = _noop_module()
    m2 = _noop_module2()

    # We test with 2 modules, one with default gather_timeout and one with
    # specified

# Generated at 2022-06-22 22:44:10.832187
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts
    '''

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import cached_facts
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(BaseFactCollector):  # pylint: disable=too-few-public-methods
        '''a collector that returns a specific set of facts, mostly to support testing'''

        def __init__(self, module, namespaces, timeout=10):
            super(TestCollector, self).__init__(module=module, timeout=timeout)
            self.namespaces = namespaces


# Generated at 2022-06-22 22:44:20.005236
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.network.bsd import BSDIfconfigNetwork

    # test for ansible 2.3.1.0 (this function will be called by 2.3.1.0)
    class TestModule2310(object):
        '''Mock ansible module for testing'''

        params = {'gather_subset': ['all'], 'gather_timeout': 10}

    assert 'ansible_distribution' in ansible_facts(TestModule2310())

    # test for ansible 2.0.0.2
    class TestModule2002(object):
        '''Mock ansible module for testing'''

        params = {'gather_subset': ['all']}

    assert 'ansible_distribution' in ansible_facts(TestModule2002())

    # test for ansible 2.

# Generated at 2022-06-22 22:44:26.105643
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    module = FakeModule()
    namespaces = ansible_facts(module)
    assert 'default_ipv4' in namespaces
    assert 'lsb' in namespaces['lsb']
    assert 'build_date' in namespaces['lsb']

# Generated at 2022-06-22 22:44:36.406090
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''
    # pylint: disable=unused-variable
    try:
        from ansible.module_utils.facts import ansible_collector
    except ImportError:
        # Tests are not being run within Ansible, so ansible_collector is not available.
        return

    import ansible.module_utils.facts.default_collectors as default_collectors

    # pylint: disable=protected-access
    # Test getting all facts
    mock_ansible_module = MockAnsibleModule()
    ansible_facts_dict = ansible_facts(mock_ansible_module)
    assert len(ansible_facts_dict) == len(default_collectors.collectors)

    # Test getting a subset of facts via gather_subset
    mock_ansible_

# Generated at 2022-06-22 22:44:47.969305
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test function ansible_facts'''

    # To keep the test simple we will use a mock AnsibleModule, rather than
    # Mock the AnsibleModule class.

    module_args = dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*'
    )

    # this is a mock AnsibleModule
    test_module = mock.MagicMock()
    test_module.params = module_args

    facts_dict = ansible_facts(test_module, gather_subset=module_args['gather_subset'])

    # We don't test the actual facts, that is the job of the facts modules.

    # We do test the structure of the returned dict
    assert isinstance(facts_dict, dict)

    # FIXME: can we check the keys and values of the

# Generated at 2022-06-22 22:44:54.014258
# Unit test for function get_all_facts
def test_get_all_facts():
    import os
    import copy
    import pytest
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.system import kernel
    from ansible.module_utils.facts.system import selinux
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.system import distribution
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.facts.network.base import NetworkCollector

    # Test Case 1: AnsibleModule instance, with gather_subset configured.

# Generated at 2022-06-22 22:44:58.105915
# Unit test for function ansible_facts
def test_ansible_facts():
    # basic unit test, verify we return some facts
    # This test is named 'test_ansible_facts', so it should run in alphabetical order before
    # the more involved tests. See
    # https://docs.python.org/2/library/unittest.html#organizing-test-code
    # for more details.

    import unittest
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}

    class TestCase_test_ansible_facts(unittest.TestCase):
        def test_ansible_facts_no_subset(self):
            test_module = AnsibleModuleMock()

            self.assertTrue

# Generated at 2022-06-22 22:45:09.297952
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Test the get_all_facts function.

    This test tests the no-arg version of ansible_facts, so it tests the optional 'gather_subset'
    arg defaults to None, and then to DEFAULT_GATHER_SUBSET.

    Testing this with a BoolModule, to check that gather_subset=None and gather_subset=[] are
    handled the same.
    '''

    from ansible.module_utils.facts import DEFAULT_GATHER_SUBSET
    from ansible.module_utils.facts.utils import filter_prefix_in_fact_names
    from ansible.module_utils.common.collections import is_sequence

    from ansible.module_utils.basic import BoolModule

    # create a fake module

# Generated at 2022-06-22 22:45:21.669180
# Unit test for function ansible_facts
def test_ansible_facts():

    class FakeModule:
        def __init__(self):
            self.params = {}

    fake_module = FakeModule()

    fake_module.params['filter'] = '*'
    fake_module.params['gather_subset'] = ['all']
    fake_module.params['gather_timeout'] = 10

    fact_dict = ansible_facts(fake_module)

    # some sanity checks
    assert 'default_ipv4' in fact_dict
    assert fact_dict['default_ipv4'] is not None

    assert 'distribution' in fact_dict
    assert fact_dict['distribution']

    # test with a custom gather_subset
    fact_dict2 = ansible_facts(fake_module, gather_subset=['!all', 'min'])
    assert 'default_ipv4'

# Generated at 2022-06-22 22:45:32.301227
# Unit test for function get_all_facts
def test_get_all_facts():
    import unittest
    import mock

    class MockAnsibleModule(object):
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-22 22:45:43.994510
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.test.test_test_ansible_module_utils_facts as test_module
    ansible_module = test_module.TestAnsibleModule()

    # test with gather_subset specified
    gather_subset = ['all']
    test_module.set_module_args({'gather_subset': gather_subset})
    api_return = get_all_facts(ansible_module)
    empty_keys = []
    for key in api_return.keys():
        if not api_return[key]:
            empty_keys.append(key)
    assert empty_keys == []
    assert api_return['distribution'] == 'unknown'

    # test with gather_subset not specified
    test_module.set_module_args({})
    api_return = get_

# Generated at 2022-06-22 22:45:47.785989
# Unit test for function get_all_facts
def test_get_all_facts():

    class Module(object):
        def __init__(self):
            self.params = dict(gather_subset=['all'])

    module = Module()

    facts = get_all_facts(module)

    assert isinstance(facts, dict)



# Generated at 2022-06-22 22:45:58.507177
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import get_install_date
    from ansible.module_utils.facts import get_distribution

    # create a mock AnsibleModule object
    from ansible.module_utils.facts import default_collectors

    class MockModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}
            self.collector = default_collectors.FactsCollector(
                all_collector_classes=default_collectors.collectors,
                namespace=PrefixFactNamespace(namespace_name='', prefix=''))


# Generated at 2022-06-22 22:45:59.619079
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit test for function ansible_facts.
    '''
    pass

# Generated at 2022-06-22 22:46:11.282088
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import get_gather_subset
    from ansible.module_utils.facts import get_gather_timeout
    from ansible.module_utils.facts import get_filter

    class StubModule:
        def __init__(self, params):
            self.params = params

    class StubGatherSubset():
        def __init__(self, options):
            self.options = options

    params = dict(
        gather_subset=['!all','min']
    )
    stub_module = StubModule(params)

    # Unit test for version 2.0/2.1

# Generated at 2022-06-22 22:46:22.139107
# Unit test for function ansible_facts
def test_ansible_facts():
    from collections import namedtuple

    # Mock module class to pass to ansible_facts
    class ModuleMock(object):
        def __init__(self, gather_subset=None, gather_timeout=None, filter=None):
            self.params = dict(
                gather_subset=gather_subset,
                gather_timeout=gather_timeout,
                filter=filter
            )


# Generated at 2022-06-22 22:46:27.934579
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.network.legacy as network_module_utils_network_legacy
    import ansible.module_utils.facts.system.distribution as system_module_utils_distribution

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    # Make sure that existing code using the old get_all_facts function still works.
    # Use current namespace.
    orig = network_module_utils_network_legacy.get_network_module((FakeModule(['!all', 'network'])))
    assert orig == get_all_facts(FakeModule(['!all', 'network']))

    # Also make sure that existing code using the old ansible_facts function still works
    orig = system_module

# Generated at 2022-06-22 22:46:28.959883
# Unit test for function get_all_facts
def test_get_all_facts():
    pass


# Generated at 2022-06-22 22:46:37.370564
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils import basic
    import platform

    class FakeModule(basic.AnsibleModule):
        def __init__(self, module_name='fake_module'):
            super(FakeModule, self).__init__(module_name=module_name, argument_spec={})

        def run_command(self, cmd, check_rc=True):
            if 'hostname' in cmd:
                return 0, 'myhostname', ''
            elif 'uname' in cmd:
                return 0, platform.system(), ''

# Generated at 2022-06-22 22:46:42.305114
# Unit test for function get_all_facts
def test_get_all_facts():
    # test default behaviour which is an all all facts in ansible namespace with
    # no prefix

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.network.default

    import types
    import json

    class DummyModule(types.ModuleType):
        params = dict(gather_subset='all', gather_timeout=10)

    module_args = dict(
        gather_subset=['all'],
        filter='*',
        gather_timeout=10,
    )

    module = DummyModule('ansible.module_utils.facts')

    # stub out the fact collector that we are going to call, so that it
    # doesn't have any dependencies on a real ansible module
    def stub_collector_init(self, *args, **kwargs):
        return None



# Generated at 2022-06-22 22:46:50.134378
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    import sys

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            '''
            Exit with status code 1 and kwargs as JSON message.
            '''
            sys.exit(1)

    module = FakeModule()

    # Test default gather_subset
    module.params = {
        'gather_subset': ['!all']
    }
    assert ansible_facts(module) == {}

    # Test gather_subset when gather_timeout is None
    module.params = {
        'gather_subset': ['!all'],
        'gather_timeout': None
    }
    assert ansible_facts(module) == {}

    #

# Generated at 2022-06-22 22:46:58.631082
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'gather_subset': {'type': 'list', 'default': ['!all'], 'required': False, 'elements': 'str', 'aliases': ['subset'], 'version_added': '2.4'}, 'gather_timeout': {'type': 'int', 'default': 10, 'required': False}})

    fact_dict = get_all_facts(module)

    assert(type(fact_dict)) == dict

# Generated at 2022-06-22 22:47:09.554165
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from collections import namedtuple

    # We will mock the AnsibleModule, but we need the params to be a dict so we can use it to pass args
    # to ansible_facts.  So we create a class that looks enough like an AnsibleModule to pass to ansible_facts.
    class FakeAnsibleModule(object):
        def __init__(self):
            self._params = dict()

        @property
        def params(self):
            return self._params

        def params(self):
            return self._params

    # Fake the get_bin_path function
    def get_bin_path(exe_name, required=False):
        return "/usr/bin/{0}".format(exe_name)


# Generated at 2022-06-22 22:47:16.759617
# Unit test for function ansible_facts
def test_ansible_facts():
    base_module = AnsibleModule(argument_spec={
        'gather_subset': dict(type='list', default=['all']),
        'gather_timeout': dict(type='int', default=10),
        'filter': dict(type='str', default='*')
    })

    result = ansible_facts(base_module)
    assert result['default_ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-22 22:47:28.189258
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ModuleInfo
    from ansible.module_utils.facts import ansible_collector
    try:
        import mock
    except ImportError:
        import unittest.mock as mock
    import importlib

    class FakeModule(object):
        def __init__(self, module_args=None):
            self.params = {'gather_subset': ['all'],
                           'gather_timeout': 10}
            self.params.update(module_args or {})

    class FakeCollector(ansible_collector.BaseFactCollector):
        @classmethod
        def get_required_facts(cls):
            return []


# Generated at 2022-06-22 22:47:38.350520
# Unit test for function get_all_facts
def test_get_all_facts():
    # Final assertion
    def module_exit_json(module, result):
        pass

    # Mock module
    class MockModule():
        def __init__(self):
            self.params = {}

    module = MockModule()
    module.params['gather_subset'] = '!all'

    # Test get_all_facts function
    result = get_all_facts(module)
    assert len(result) > 0

    module.params['gather_subset'] = '!facter'
    result = get_all_facts(module)
    assert len(result) > 0

# Generated at 2022-06-22 22:47:46.915035
# Unit test for function ansible_facts
def test_ansible_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', required=False),
            gather_timeout=dict(type='int', required=False),
            filter=dict(type='str', required=False),
        ),
        supports_check_mode=True
    )
    print(ansible_facts(module))

# AnsibleModule boilerplate to allow unit test to run
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-22 22:47:56.441682
# Unit test for function get_all_facts
def test_get_all_facts():
    '''This function tests function get_all_facts'''
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.test import TestAnsibleModule

    module = TestAnsibleModule()

    # get_all_facts should return a dict with one key 'ansible_facts'
    result_facts = get_all_facts(module=module)
    assert len(result_facts) == 1

    assert 'ansible_facts' in result_facts
    assert isinstance(result_facts['ansible_facts'], dict)

    # get_all_facts should return a dict with one key 'ansible_facts' with value that

# Generated at 2022-06-22 22:48:09.721322
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Test compat get_all_facts method'''

    from ansible.module_utils.facts.utils import get_collector_facts

    class FakeAnsibleModule(object):
        def __init__(self, params):
            self.params = params

    collector_facts = get_collector_facts()

    # get the subset of facts found in the default namespace
    def_namespace_fact_map = {fact['name']: fact['value'] for fact in collector_facts
                              if fact['namespace'] == 'ansible'}

    # get list of unique fact namespaces in all facts
    fact_namespaces = [fact['namespace'] for fact in collector_facts]
    fact_namespaces = set(fact_namespaces)

    # check that when all namespaces are gathered, we get exactly the same
    # facts as

# Generated at 2022-06-22 22:48:14.218008
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule():
        gather_subset = ['all']
        params = {'gather_subset': gather_subset}
        def __init__(self, module_name):
            self.name = module_name

    # Get all facts
    module = MockModule('example_module')
    # Only a few facts are guaranteed to exist.
    # Assert that the module_utils exists is found.
    facts = get_all_facts(module)
    assert facts['module_utils']

# Generated at 2022-06-22 22:48:26.460017
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    This test is only intended to be run by real unittests, not by test cases.
    So it is not named 'test_ansible_facts'

    It is not a test case because test cases are only run with enforced gather_subset,
    which breaks 'all' and 'network' gather_subsets.
    '''

    import sys
    import pytest
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    pytestmark = pytest.mark.unittest

    class Module(object):
        '''
        fakes out the AnsibleModule
        '''

        def __init__(self):
            self.params = {
                'gather_timeout': 1,
            }
            self.fail_

# Generated at 2022-06-22 22:48:33.401731
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import module_proto
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # setup
    all_collector_classes = (default_collectors.NetworkCollector,
                             default_collectors.PlatformCollector)

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    fact_collector = \
        ansible_collector.get_ansible_collector(all_collector_classes=all_collector_classes,
                                                namespace=namespace,
                                                filter_spec='*',
                                                gather_subset=['all'],
                                                gather_timeout=10,
                                                minimal_gather_subset=frozenset())

    # verify the collector was created as expected

# Generated at 2022-06-22 22:48:36.812592
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    facts = get_all_facts(module)
    assert isinstance(facts, dict)


# Generated at 2022-06-22 22:48:39.379358
# Unit test for function ansible_facts
def test_ansible_facts():

    import ansible.module_utils.facts.test_api
    from ansible.module_utils.facts.test_api import TestAnsibleModule

    test_module = TestAnsibleMo

# Generated at 2022-06-22 22:48:44.455721
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.compat import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    module.params['gather_subset'] = ['all']
    facts_dict = get_all_facts(module)
    assert 'default_ipv4' in facts_dict


# Generated at 2022-06-22 22:48:56.644115
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    # Override ansible_collector.get_ansible_collector with a mock version
    orig_get_ansible_collector = ansible_collector.get_ansible_collector

    def wrapped_get_ansible_collector(all_collector_classes, namespace, filter_spec, gather_subset,
                                      gather_timeout, minimal_gather_subset):
        # Call the real get_ansible_collector and then validate the args
        col = orig_get_ansible_collector(all_collector_classes, namespace, filter_spec, gather_subset,
                                         gather_timeout, minimal_gather_subset)


# Generated at 2022-06-22 22:49:04.174785
# Unit test for function get_all_facts
def test_get_all_facts():
    """Unit test for module_utils:facts:get_all_facts

    Test that get_all_facts returns a dictionary of facts
    matching the system.
    """
    try:
        from ansible.module_utils.facts.collector import BaseFactCollector
        from ansible.module_utils.facts import namespace
    except ImportError:
        print("can't import facts modules")
    else:
        # Mock AnsibleModule
        class MockAnsibleModule(object):
            """mock Ansible Module class."""
            def __init__(self, module_name):
                self.module_name = module_name
                self.params = {'gather_subset': ['all']}
                self.facts = {}
                self.tmpdir = "/tmp"

        # Mock fact collector

# Generated at 2022-06-22 22:49:15.056677
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import mock
    import pytest

    GATHERER_SUB_SETS = ('all', 'min', '!networking', 'network')


# Generated at 2022-06-22 22:49:23.544371
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.collector.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.fact_cache import BaseFactCacheModule
    import tempfile
    import os

    def my_collect(module):
        '''override BaseFactCollector.collect'''
        return {}

    def my_get_cache_file_path(self):
        '''override BaseFactCacheModule.get_cache_file_path()'''


# Generated at 2022-06-22 22:49:26.112882
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.ansible_facts
    # ansible_facts.ansible_facts(module, gather_subset=gather_subset)
    module = None
    gather_subset = None
    ansible_facts.ansible_facts(module, gather_subset=gather_subset)

# Generated at 2022-06-22 22:49:29.042137
# Unit test for function get_all_facts
def test_get_all_facts():
    module = None
    gather_subset = ['all']
    assert get_all_facts(module) == ansible_facts(module, gather_subset)



# Generated at 2022-06-22 22:49:36.483347
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test get_all_facts'''
    # the anisble.module_utils.facts.ansible_facts api is tested with test/unit/module_utils/test_facts_utils.py

    # mock an AnsibleModule instance
    class AnsibleModule(object):

        class Params(object):
            def __init__(self, gather_subset):
                self.gather_subset = gather_subset

        def __init__(self, gather_subset):
            self.params = self.Params(gather_subset=gather_subset)

    # gather_subset is ['all']
    module = AnsibleModule(gather_subset=['all'])

    # gather_timeout is 10, the hardcoded default for AnsibleModule

# Generated at 2022-06-22 22:49:44.080721
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Basic unit test for function get_all_facts'''

    from ansible.module_utils.facts import ansible_facts

    class MockModule(object):

        def __init__(self):
            self.params = dict(
                gather_subset=['all'],
                gather_timeout=10,
                filter='*',
                ansible_facts={}
            )

    module = MockModule()

    module.params['ansible_facts'] = ansible_facts(module)

    assert module.params['ansible_facts'] is not None

# Generated at 2022-06-22 22:49:50.560334
# Unit test for function get_all_facts
def test_get_all_facts():

    import ansible.module_utils.facts.platform.linux

    class MockAnsibleModule(object):

        def __init__(self):
            self.params = dict(
                gather_subset=['all'],
                gather_timeout=10,
                filter=None
            )

        def exit_json(self, changed=False, ansible_facts=None):
            self.exit_data = dict(
                changed=changed,
                ansible_facts=ansible_facts
            )

        def fail_json(self, msg, **kwargs):
            self.fail_data = dict(
                msg=msg,
                **kwargs
            )

        def __getattr__(self, attr):
            return self._mocked_ansible_mod[attr]


# Generated at 2022-06-22 22:50:01.293610
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.system import DistributionFactCollector
    from ansible.module_utils.facts import ansible_collector

    class MockModule(object):
        def __init__(self, **kwargs):
            params = {'gather_subset': ['all'], 'gather_timeout': 10}
            params.update(kwargs)
            self.params = params

    class MockFactCollector(DistributionFactCollector):
        def collect(self, module=None, collected_facts=None):
            facts = {'Distribution': 'Debian', 'Distribution Release': '8.6.0'}
            return facts

    # give it a module with a valid gather_subset set to 'all'
    # and a filter set to '

# Generated at 2022-06-22 22:50:09.581226
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import module_lldp
    from ansible.module_utils.facts.system.distribution import Distribution

    import datetime

    class AnsibleModule:

        def __init__(self):
            self.params = {}

    ansible_module = AnsibleModule()

    # Add all the default collectors except lldpd
    # Because we don't have the lldpd package on the test environment
    all_collector_classes = [c for c in default_collectors.collectors
                             if not issubclass(c, module_lldp.LLDP_Collector)]

   

# Generated at 2022-06-22 22:50:20.534067
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts

    test_module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(type='list', required=True),
        gather_timeout=dict(type='int', required=True),
        filter=dict(type='str', required=True),
    ))

    test_module.params.update(dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*'
    ))

    # Test normal run
    facts_result = ansible_facts(module=test_module)
    assert facts_result


if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule

    test_ansible_facts()

# Generated at 2022-06-22 22:50:29.280301
# Unit test for function get_all_facts
def test_get_all_facts():
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all'])})
    module.params['gather_subset'] = ['all']

    facts = get_all_facts(module)

    assert 'ansible_lsb' in facts

    lo_ip_address = facts['ansible_lo'][0]['ipv4']['address']
    assert lo_ip_address == '127.0.0.1'
    assert facts['ansible_lsb']['major_release'] == '7'
    assert facts['ansible_pkg_mgr'] == 'dnf'



# Generated at 2022-06-22 22:50:41.626707
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from test.units.module_utils.arg_validator import arg_validator
    from test.units.compat.mock import MagicMock, patch

    # set up mock module
    mock_module = MagicMock(spec=AnsibleModule)
    mock_module.params = {'gather_subset': ['all']}

    with patch('ansible.module_utils.facts.ansible_collector.get_ansible_collector') as mock_get_ansible_collector:
        mock_get_ansible_collector.return_value = arg_validator.MockCollector()

        facts_dict = ans

# Generated at 2022-06-22 22:50:48.381523
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule:
        params = {}

    fake_module = FakeModule()

    # Gather all facts and check that the number of collected ones is
    # greater or equal to 15 (this is the number of collectors)
    assert len(ansible_facts(fake_module)) >= 15

    # Gather a subset of facts, check that not all of them are collected
    assert len(ansible_facts(fake_module, gather_subset=['!all'])) < 15
    assert len(ansible_facts(fake_module, gather_subset=['!all', 'network'])) < 15
    assert len(ansible_facts(fake_module, gather_subset=['network'])) > 0

# Generated at 2022-06-22 22:50:49.956857
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts

    # import mock so we can mock the module we pass in
    from unittest import mock

    facts = ansible_facts(mock.MagicMock())

    assert isinstance(facts, dict)

# Generated at 2022-06-22 22:50:51.116986
# Unit test for function get_all_facts
def test_get_all_facts():
    '''testing with mock'''
    pass

# Generated at 2022-06-22 22:51:03.126777
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts as old_get_all_facts
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # since we're from __future__.absolute_import, we need to import the loader from future_builtins
    from future_builtins import map

    # mock the ansible_facts function with something that returns a fixed value
    test_data = {'ansible_all_ipv4_addresses': ['1.2.3.4', '1.2.3.5']}

    def mock_ansible_facts(x, gather_subset):
        return test_data

    # mock the AnsibleModule class. We need an instance of it to pass to ansible_collector

# Generated at 2022-06-22 22:51:10.349652
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.six.moves import StringIO
    from ..module_utils.common import AnsibleModule, ExitJson
    from ..module_utils.facts import get_all_facts

    FAKE_STDOUT = StringIO()

    module = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(type='list', default=['all'])
        )
    )
    facts_dict = get_all_facts(module)

    module.exit_json(ansible_facts=facts_dict)

# Generated at 2022-06-22 22:51:16.911321
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class MockAnsibleModule():
        class MockParams():
            pass

        def __init__(self, gather_subset=None, gather_timeout=None, filter=None):
            self.params = self.MockParams()
            self.params.gather_subset = gather_subset
            self.params.gather_timeout = gather_timeout
            self.params.filter = filter

    class MockCollector(BaseFactCollector):
        name = 'mock'

        def collect(self, module=None, collected_facts=None):
            return {'mock_fact': True}

    module = MockAnsibleModule()
    ansible_facts(module)
    assert 'mock_fact' in ansible_facts

# Generated at 2022-06-22 22:51:23.910815
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockAnsibleModule(object):
        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)
            self.params['gather_subset'] = gather_subset

    module = MockAnsibleModule(['all'])

    ansible_facts = get_all_facts(module)

    assert isinstance(ansible_facts, dict)
    assert ansible_facts.get('distribution_release') == 'alpine'

# Generated at 2022-06-22 22:51:29.602238
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Mock AnsibleModule object with gather_subset and gather_timeout as param mapping like dict'''
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all'], 'gather_timeout': 10}

    mock_module = MockAnsibleModule()

    result = get_all_facts(mock_module)

    assert result, "Did not retrieve facts"



# Generated at 2022-06-22 22:51:36.597740
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts

    class AnsibleModule(object):

        def __init__(self, params):
            self.params = params

    class MockAnsibleModule(AnsibleModule):

        def __init__(self, params):
            super(MockAnsibleModule, self).__init__(params)

            self.exit_args = {}

        def exit_json(self, **kwargs):
            self.exit_args.update(kwargs)

    module = MockAnsibleModule({'gather_subset': ['all']})
    ansible_facts(module, gather_subset=['all'])

    # Confirm that all facts have been gathered
    assert len(module.exit_args['ansible_facts']) == len(default_collectors.collectors)

# Generated at 2022-06-22 22:51:48.040668
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts import default_collector_classes

    # reset the global list of collectors to just our mock_collector
    default_collector_classes['all'] = [MockCollector]
    assert not get_collector_classes(subset='all', gather_subset=['min'])

    # mock up a module to pass as a param to get_all_facts
    class MockAnsibleModule(object):

        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/usr/bin/' + executable



# Generated at 2022-06-22 22:51:58.153927
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit test for function ansible_facts.
    '''

    try:
        # This is a hack to make the unit test work,
        # since it relies on a function named 'run_command'
        # which can be found in the 'ansible.module_utils.basic'
        # module. That module is imported at runtime by AnsibleModule,
        # so it's not normally available when 'ansible_facts'
        # is imported into a unit test.
        from ansible.module_utils.basic import AnsibleModule
    except:
        pass

    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # A fake AnsibleModule...
    class FakeModule(object):
        '''
        A fake AnsibleModule.
        '''


# Generated at 2022-06-22 22:52:10.771492
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    def mock_module_params(params):
        class ModuleParams(object):
            def __init__(self, params):
                self.params = params
        module_params = ModuleParams(params)
        return module_params

    test_params = {'gather_subset': 'all'}
    module = mock_module_params(test_params)
    all_facts_dict = get_all_facts(module)

    assert isinstance(all_facts_dict, dict)
    assert 'fips' in all_facts_dict
    assert 'fips' in default_collectors.collectors
    assert 'ansible_fips' in all_facts_dict
   

# Generated at 2022-06-22 22:52:20.740096
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import DEFAULT_GATHER_SUBSET
    # create a stub module with a gather_subset parameter
    class StubModule:
        def __init__(self, params):
            self.params = params

    # gather all facts
    params = {
        'gather_subset': DEFAULT_GATHER_SUBSET,
        'gather_timeout': 10,
    }
    mod = StubModule(params=params)
    all_facts = get_all_facts(mod)
    assert type(all_facts).__name__ == 'dict'
    assert all_facts['ansible_default_ipv4']['address']

    # gather minimal facts

# Generated at 2022-06-22 22:52:30.814016
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.facts.utils import collect_subset

    test_module = TestModule()

    def param_func(*args, **kwargs):
        return None

    with patch.dict(collect_subset.__dict__, {'__get_param_value': param_func}):
        actual_facts = get_all_facts(test_module)

    assert actual_facts['distribution'] == 'Distribution'
    assert actual_facts['distribution_version'] == 'DistributionVersion'
    assert actual_facts['os_family'] == 'OSFamily'



# Generated at 2022-06-22 22:52:42.754481
# Unit test for function ansible_facts
def test_ansible_facts():

    import unittest
    import os
    import shutil
    from ansible.module_utils.facts import ansible_facts

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}
            self.fail_json = None
            self.exit_json = lambda **kwargs: None

    class AnsibleFactsCollectorTestCase(unittest.TestCase):
        def setUp(self):
            os.makedirs('test_facts_collection')
            os.chdir('test_facts_collection')

            self.module = AnsibleModuleMock()
            self.facts = {}
            self.facts['gather_subset'] = ['hardware']
            self.facts['gather_timeout'] = 50


# Generated at 2022-06-22 22:52:53.426316
# Unit test for function get_all_facts
def test_get_all_facts():
    # Tested class
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.facts import get_all_facts

    # Tested function
    from ansible.module_utils.facts.facts import ansible_facts

    # Tested object
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Tested collections
    from ansible.module_utils.facts import default_collectors
    from ansible import module_utils
    from ansible.module_utils.facts import ansible_collector

    # Tested variables
    from ansible.module_utils.facts.facts import DEFAULT_GATHER_TIMEOUT

    # Fake module used for function ansible_facts
    class FakeModule:
        def __init__(self):
            self.params = {}

# Generated at 2022-06-22 22:52:59.084052
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    import mock_ansible_module
    module = mock_ansible_module.MockAnsibleModule()
    module.gather_subset = ['all']
    facts = get_all_facts(module)
    assert 'python' in facts

# Generated at 2022-06-22 22:53:09.950707
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import _get_async_facts_collector, _get_async_multiprocessing_facts_collector  # pylint: disable=import-error
    from ansible.module_utils.facts import _get_async_threading_facts_collector  # pylint: disable=import-error
    from ansible.module_utils.facts.collector import BaseFactCollector  # pylint: disable=import-error
    from ansible.module_utils.facts.fact_cache import FactCache  # pylint: disable=import-error
    import ansible.module_utils.facts.ansible_collector as ac  # pylint: disable=import-error
    import ansible.module_utils.facts.collectors.base as base  # pylint: disable

# Generated at 2022-06-22 22:53:17.933403
# Unit test for function get_all_facts
def test_get_all_facts():
    '''get_all_facts is a compatibility wrapper for the new ansible_facts function. This function is
    here just to support run-time backwards compatibility checks by wrapping ansible_facts in a
    manner that's expected by Ansible 2.2+
    '''
    # Create a mock ansible module object
    class AnsibleModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    module = AnsibleModule()
    facts = get_all_facts(module)

    assert "platform" in facts
    assert facts["distribution"]["name"] == "Fedora"

# Generated at 2022-06-22 22:53:26.722704
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts as module_facts
    import ansible.module_utils.facts.test_module_utils_facts as test_module_utils_facts

    module_mock = test_module_utils_facts.mock_ansible_module()

    module_facts.DEFAULT_GATHER_SUBSET = ['all']
    module_mock.params['gather_subset'] = ['network']

    ansible_facts = module_facts.get_all_facts(module=module_mock)

    assert 'ansible_all_ipv4_addresses' not in ansible_facts
    assert ansible_facts['ansible_nodename'] == 'localhost'