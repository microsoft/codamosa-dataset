

# Generated at 2022-06-22 22:43:25.946323
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test_get_all_facts

    test that get_all_facts() behaves like ansible_facts(), but when gather_subset
    is set to None, that ansible_facts() uses the configured default.
    '''

    from ansible.module_utils.facts.collector import DEFAULT_GATHER_SUBSET

    assert get_all_facts(module=AnsibleModule(argument_spec=dict(gather_subset=dict(type='list')))) == \
           ansible_facts(module=AnsibleModule(argument_spec=dict(gather_subset=dict(type='list')))) == \
           ansible_facts(module=AnsibleModule(argument_spec=dict()), gather_subset=DEFAULT_GATHER_SUBSET)

    # Just test the 1.6 ansible behavior

# Generated at 2022-06-22 22:43:34.111889
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic

    m_params = dict(
        gather_subset='min',
        gather_timeout=0,
        filter='*',
    )
    m_instance = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all', '!min'], elements='str'),
            gather_timeout=dict(type='int', default=10),
            filter=dict(type='str'),
        ),
        supports_check_mode=True
    )

    m_instance.params = m_params

    facts_dict = get_all_facts(m_instance)
    assert isinstance(facts_dict, dict)

# Generated at 2022-06-22 22:43:43.322869
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.legacy.linux import LinuxNetworkCollector
    from ansible.module_utils.facts.network.legacy.freebsd import FreeBSDNetworkCollector
    from ansible.module_utils.facts.network.legacy.netbsd import NetBSDNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkInterfaceFactContext
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.module_utils import basic

    # Test get_all_facts with gather_subset=all

# Generated at 2022-06-22 22:43:52.807993
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.system.distribution
    from ansible.module_utils.facts import caching
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
    import sys
    module = DummyModule()
    facts = get_all_facts(module)

    # Can not validate the contents of the all_collectors because
    # ansible_facts will cache the result and we can not sqeak the cache for testing.
    # Instead we will validate the imports (which is needed for building the cache)
    # and validate the result is a dictionary.
    assert isinstance(facts, dict)

# Generated at 2022-06-22 22:44:00.912790
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes, to_native

    # Minimal test module that provides a gather_subset param.
    class MinimalModule:
        def __init__(self, params):
            self.params = params
    module = MinimalModule({'gather_subset': ['all']})

    # For python 2.7, we need to convert the dict keys to native strings
    # (from unicode) for comparison with ansible <2.4.

# Generated at 2022-06-22 22:44:11.627210
# Unit test for function ansible_facts
def test_ansible_facts():
    # mock module for testing
    from ansible.module_utils._text import to_text

    # import module snippets
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import _get_ansible_facts_modules

    class AnsibleModule(object):
        '''Very simple class to mock AnsibleModule'''
        def __init__(self, **kwargs):
            self.params = kwargs

    # test get_all_facts
    assert to_text('ansible_facts_test') == 'ansible_facts_test'
    # get_all_facts is only used by ansible 2.2/2.3 modules using the old style of
    # facts collection.
    module = AnsibleModule(gather_subset='min')

# Generated at 2022-06-22 22:44:21.726973
# Unit test for function get_all_facts
def test_get_all_facts():

    # test normal case on all of a 2.2/2.3 system
    gather_subset = {'all'}
    result = get_all_facts(mock_module(gather_subset=gather_subset))
    assert len(result) > 0
    assert 'default_ipv4' in result

    # test normal case on subset of a 2.2/2.3 system
    gather_subset = {'interfaces'}
    result = get_all_facts(mock_module(gather_subset=gather_subset))
    assert len(result) > 0
    assert 'default_ipv4' in result

    # test normal case on subset of a 2.2/2.3 system
    gather_subset = {'interfaces'}

# Generated at 2022-06-22 22:44:33.121615
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts.hardware as hardware
    import ansible.module_utils.facts.system as system
    import ansible.module_utils.facts.pkg_mgr as pkg_mgr

    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['!kernel', '!virtual']}

    def test_collect(self, module):
        results = {'ansible_pkg_mgr': 'fake', 'ansible_system': 'fake'}
        return results

    fake_module = FakeModule()

# Generated at 2022-06-22 22:44:37.992788
# Unit test for function ansible_facts
def test_ansible_facts():
    import mock

    mock_AnsibleModule = mock.Mock()
    mock_AnsibleModule.params = {'gather_subset': '!all', 'gather_timeout': 5, 'filter': '*'}

    fact_dict = ansible_facts(mock_AnsibleModule)
    assert fact_dict['command_shell']['executable'] == '/bin/sh'

# Generated at 2022-06-22 22:44:39.785751
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Fake get_all_facts unit test'''
    pass

# Generated at 2022-06-22 22:44:49.740427
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import sys
    class Module:
        def __init__(self, name, params):
            self.name = name
            self.params = params
    class AnsibleModule(Module):
        def __init__(self, name, params):
            self.name = name
            self.params = params
    class MockAllFactCollector:
        def collect(self, module=None):
            return {'fact': 'value'}
    # 2.3/2.4

# Generated at 2022-06-22 22:45:00.677729
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts as facts

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, *args, **kwargs):
            pass

    orig_ansible_facts = facts.ansible_facts
    facts.ansible_facts = lambda module, gather_subset=None: {'greetings': 'hello'}

    try:
        # Test that the get_all_facts method returns the dictionary from ansible_facts.
        mock_module = MockModule({'gather_subset': 'all'})

        assert get_all_facts(mock_module) == {'greetings': 'hello'}
    finally:
        facts.ansible_facts = orig_ansible_facts

# Generated at 2022-06-22 22:45:10.145402
# Unit test for function ansible_facts
def test_ansible_facts():

    class FakeModule:
        def __init__(self, gather_subset, gather_timeout):
            self.params = dict(gather_subset=gather_subset, gather_timeout=gather_timeout)

    fake_module1 = FakeModule(gather_subset=['fact1'], gather_timeout=100)
    ansible_facts1 = ansible_facts(module=fake_module1)
    assert ansible_facts1 == dict(fact1='value1')

    fake_module2 = FakeModule(gather_subset=['all'], gather_timeout=None)
    ansible_facts2 = ansible_facts(module=fake_module2)
    assert ansible_facts2 == dict(fact2='value2')

# Generated at 2022-06-22 22:45:18.903345
# Unit test for function ansible_facts
def test_ansible_facts():
    # Stubbed AnsibleModule and AnsibleModule.params
    module_args = dict(
        gather_timeout=10,
        filter='*',
        gather_subset=['all']
    )

    class TestableAnsibleModule(object):
        def __init__(self, module_args):
            self.params = module_args

    module = TestableAnsibleModule(module_args)

    result = ansible_facts(module)

    assert result is not None
    # Perform basic sanity check that an expected fact is present
    assert 'distribution' in result

# Generated at 2022-06-22 22:45:29.172315
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.platform.linux

    all_collector_classes = {'ansible.module_utils.facts.platform.linux': ansible.module_utils.facts.platform.linux}

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    fact_collector = \
        ansible_collector.get_ansible_collector(all_collector_classes=all_collector_classes,
                                                namespace=namespace,
                                                filter_spec='*',
                                                gather_subset=['all'],
                                                gather_timeout=10,
                                                minimal_gather_subset=None)

    class FakeModule:
        def __init__(self, facts_dict):
            self.facts_dict = facts_dict
           

# Generated at 2022-06-22 22:45:33.339494
# Unit test for function get_all_facts
def test_get_all_facts():
    '''mock up the module arg, collect all facts, then check for a few expected facts'''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import OSTypeLinux


# Generated at 2022-06-22 22:45:44.434591
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts.network.base import NetworkCollector

    from ansible.module_utils.facts.system.base import SysctlCollector

    from ansible.module_utils.facts.parsers import command

    from ansible.module_utils.facts.parsers import file_exists

    from ansible.module_utils.facts.parsers import nmcli

    from ansible.module_utils.facts.parsers import osx_facts

    from ansible.module_utils.facts.parsers import parse_env_var

    from ansible.module_utils.facts.parsers import parse_file

    from ansible.module_utils.facts.parsers import parse_lsb

# Generated at 2022-06-22 22:45:47.404649
# Unit test for function get_all_facts
def test_get_all_facts():
    class Module:
        params = {'gather_subset': ['!all']}

    module = Module()
    facts = get_all_facts(module)
    assert facts == {}



# Generated at 2022-06-22 22:45:56.209161
# Unit test for function get_all_facts
def test_get_all_facts():

    # mock AnsibleModule
    module = MockModule({'gather_timeout': 10, 'filter': '*', 'gather_subset': ['network']})

    # call our function
    all_facts = get_all_facts(module)

    assert(all_facts == {'default_ipv4': {'address': '192.0.2.1', 'alias': 'eth0:0', 'gateway': '192.0.2.254',
                                          'interface': 'eth0', 'macaddress': '00:0c:29:8c:11:b1'}})


# Generated at 2022-06-22 22:46:03.605646
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic
    import json

    # content of module_utils/facts.py
    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'

    module = basic.AnsibleModule(argument_spec={
        'gather_subset': {'required': True, 'type': 'list'},
        'gather_timeout': {'required': True, 'type': 'int'},
        'filter': {'required': True, 'type': 'str'}},
        supports_check_mode=True)

    module.params['gather_subset'] = gather_subset
    module.params['gather_timeout'] = gather_timeout
    module.params['filter'] = filter_spec

    result = get_all_facts(module)

# Generated at 2022-06-22 22:46:09.114025
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.network.base import NetworkCollector
    import mock
    module = mock.MagicMock()
    module.params = {}
    assert ansible_facts(module)['default_ipv4']['interface'] == NetworkCollector().get_default_interface()

# Generated at 2022-06-22 22:46:13.186999
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule():
        def __init__(self):
            self.params = {}

    module = MockModule()
    result = get_all_facts(module)
    assert('default_ipv4' in result)
    assert('hostname_short' in result)


# Generated at 2022-06-22 22:46:23.519340
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    try:
        import ansible
    except ImportError:
        print('Skipping test_ansible_facts: ansible is not installed')
        return

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.facts.collector import AnsibleFactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_content

    from ansible.module_utils.six import PY3

    import os

    # mock module
    module = MockAnsibleModule()

    all_collector_classes = default_collectors.collectors

    # don't

# Generated at 2022-06-22 22:46:33.432751
# Unit test for function ansible_facts
def test_ansible_facts():
    # All we are doing is ensuring that fact collection finished without an exception
    from ansible.module_utils.facts import get_all_facts as get_all_facts_base
    # Using a mock AnsibleModule to call the function.
    class MockAnsibleModule(object):
        def __init__(self, params=dict()):
            self.params = params
    get_all_facts = lambda module: ansible_facts(module)
    params = dict(gather_subset=['network'], gather_timeout=1, filter='*',
                  gather_network_resources=['interfaces', 'interfaces_ipv4'])
    module = MockAnsibleModule(params)
    # ansible_facts is the function being tested.
    facts = get_all_facts(module)

# Generated at 2022-06-22 22:46:43.406468
# Unit test for function ansible_facts
def test_ansible_facts():

    import ansible.module_utils.facts.namespace as namespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ansible_collector

    # To test ansible_facts, create a test_module class which implements
    # the attributes and methods expected by the code.
    class test_module:
        def __init__(self, params=None, gather_subset=None, filter=None):
            self.params = params or {}
            self.params['gather_subset'] = gather_subset
            self.params['filter'] = filter

   

# Generated at 2022-06-22 22:46:48.948882
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
        ),
    )
    ansible_facts = get_all_facts(module)

    assert 'default_ipv4' in ansible_facts
    assert 'fqdn' in ansible_facts
    assert 'hostname' in ansible_facts
    assert 'domain' in ansible_facts

# Generated at 2022-06-22 22:46:57.044676
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors

    class DummyAnsibleModule():
        params = {'gather_subset': ['all']}

    dummy_module = DummyAnsibleModule()

    # Make sure the facts returned are a subset of the facts this
    # collection class can gather
    assert set(ansible_facts(dummy_module).keys()).issubset(set(default_collectors.collectors.keys()))


# Generated at 2022-06-22 22:47:08.903943
# Unit test for function ansible_facts
def test_ansible_facts():
    '''This unit test has some bad assumptions'''
    # assume we're running with an ansible module_utils.basic.AnsibleModule object
    # assume the module has a 'gather_timeout' parameter, with main value of 10.
    # assume the module has a 'gather_subset' parameter, with main value of ['all']

    # define a dummy module_utils.basic._AnsibleModule object


# Generated at 2022-06-22 22:47:15.361739
# Unit test for function get_all_facts
def test_get_all_facts():
    ansible_facts_list = ['distribution', 'distribution_file_parsed', 'distribution_major_version', 'distribution_release', 'distribution_version']
    module = FakeAnsibleModule()
    gaf = get_all_facts(module)
    for fact in ansible_facts_list:
        assert fact in gaf


# Generated at 2022-06-22 22:47:27.265292
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.base import NetworkCollector
    import ansible.module_utils.facts.network.default as network_default

    class NetworkCollectorStub(NetworkCollector):
        @staticmethod
        def test_add_facts(ansible_facts, data, legacy_facts=None):
            ansible_facts['network'] = data

        @staticmethod
        def _get_ipv4_address_data(interface, ipv4addresses=None,
                                   routes=None, network=None):
            return [{'broadcast_address': '192.168.0.255',
                     'cidr': '192.168.0.0/24',
                     'network': '192.168.0.0'}]

   

# Generated at 2022-06-22 22:47:34.452241
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Assert that get_all_facts is a compat wrapper for get_ansible_facts, which is present in
    Ansible 2.0/2.1 and 2.4/devel.'''

    from ansible.module_utils.facts import get_all_facts as get_ansible_facts

    from ansible.module_utils._text import to_text

    from io import StringIO

    orig_stdout = sys.stdout

    class FakeModule(object):
        def __init__(self):
            self.params = dict()

    sys.modules['ansible'] = FakeModule()


# Generated at 2022-06-22 22:47:43.874962
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import ansible_collector
    import six
    import io
    import sys

    my_argv = sys.argv

    # unit test
    sys.argv = [my_argv[0], '--tags', 'default']

    from ansible.module_utils._text import to_bytes, to_text

    class AnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

    class AnsibleModuleMockNoGatherSubset(AnsibleModule):
        def __init__(self):
            self.params

# Generated at 2022-06-22 22:47:54.400514
# Unit test for function get_all_facts
def test_get_all_facts():
    '''unit test for get_all_facts'''

    import ansible.module_utils.basic

    class AnsibleModule(object):
        params = {'gather_subset': ['all']}

    def get_all_facts(self):
        '''dummy get_all_facts function'''
        # pylint: disable=no-self-use
        return {
            'dummy_fact': 'dummy_val',
            'ansible_default_ipv4': {
                'address': '1.1.1.1',
                'interface': 'eth1'
            }
        }

    ansible.module_utils.basic.AnsibleModule.get_all_facts = get_all_facts
    module = AnsibleModule()

    facts_dict = ansible_facts(module)


# Generated at 2022-06-22 22:48:06.933581
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit test for function ansible_facts

    This does not test the full functionality of the
    module_utils.facts.ansible_facts method.
    It only tests the part of that method that is
    particular to this compatibility shim
    '''

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.network
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Because of the generator below, this test will only check the first
    # item returned by the ansible_facts method

    def gen_one():
        yield 'ansible_date_time'

    def gen_all():
        yield 'ansible_bogus_fact'

    import ansible.module_utils.facts.system
    import ansible.module_utils.facts

# Generated at 2022-06-22 22:48:14.519202
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import FactsNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector, BaseFileFactCollector
    from ansible.module_utils.facts import default_collectors

    class TestFactNamespace(FactsNamespace):
        def __init__(self, namespace_name, prefix, **kwargs):
            super(TestFactNamespace, self).__init__(namespace_name, prefix, **kwargs)
            self.namespace['test_fact'] = 'test_fact_value'
            self.namespace['another_fact'] = 'another_fact_value'

    class TestFactCollector(BaseFactCollector):
        name = 'test'
        FIELDS = ['test_fact']


# Generated at 2022-06-22 22:48:26.709969
# Unit test for function get_all_facts
def test_get_all_facts():

    import ansible.module_utils.facts.network as network
    import ansible.module_utils.facts.system as system

    network.get_interfaces = lambda: {}
    system.get_distribution = lambda: None

    try:
        from ansible.module_utils.facts import FACT_SUBSETS
        from ansible.module_utils.facts import cached
    except ImportError:
        # ansible 2.0
        from ansible.module_utils.facts.utils import FACT_SUBSETS
        from ansible.module_utils.facts.utils import cached

    import ansible.module_utils.facts.utils as utils

    utils.get_file_lines = lambda: []

    class FakeAnsibleModule:
        def __init__(self, params):
            self.params = params


    # unit

# Generated at 2022-06-22 22:48:33.559535
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Test the ansible_facts function'''

    mock_module = MagicMock()

    # gather_subset == None
    mock_module.params = {'gather_subset': None, 'gather_timeout': 10, 'filter': '*'}
    result = ansible_facts(module=mock_module)
    assert result['dns']['nameservers'] == ['8.8.8.8']
    assert result['dns']['search'] == ['example.com']

    # gather_subset == empty list
    # This can happen if the user specifies gather_subset=[] on the ansible command line.
    mock_module.params = {'gather_subset': [], 'gather_timeout': 10, 'filter': '*'}

# Generated at 2022-06-22 22:48:36.952493
# Unit test for function ansible_facts
def test_ansible_facts():
    ansible_facts = ansible_facts(None)
    assert ansible_facts is not None
    assert type(ansible_facts) is dict
    assert len(ansible_facts) > 5

# Generated at 2022-06-22 22:48:47.209706
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    # This stub class is used to mock the AnsibleModule class for testing

    class FakeModule:
        class FakeParams:
            def __init__(self):
                self.gather_subset = None

        class FakeFailJson:
            def __init__(self):
                self.msg = None

            def __call__(self, msg):
                self.msg = msg
                return msg

        def __init__(self):
            self.exit_json = FakeFailJson()
            self.fail_json = FakeFailJson()
            self.params = self.FakeParams()

    # Mock the module, which will call the get_all_facts function
    module = FakeModule()

# Generated at 2022-06-22 22:48:51.579156
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    fact_value = get_all_facts(FakeModule())

    assert fact_value



# Generated at 2022-06-22 22:48:55.757174
# Unit test for function get_all_facts
def test_get_all_facts():
    # Test stub AnsibleModule
    class TestModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'all'}

    test_module = TestModule()
    assert 'local' in get_all_facts(test_module)

# Generated at 2022-06-22 22:49:03.680402
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    expected_gather_subset = ['network', 'default']
    expected_gather_timeout = 20
    expected_filter_spec = '^filter_'

    test_module = TestModule(gather_subset=expected_gather_subset,
                             gather_timeout=expected_gather_timeout,
                             filter=expected_filter_spec)

    # Verify default value of gather_subset
    test_module.params.pop('gather_subset')
    results = ansible_facts(test_module)
    assert 'gather_subset' not in test_module.params

# Generated at 2022-06-22 22:49:11.885374
# Unit test for function ansible_facts
def test_ansible_facts():
    """Test the ansible_facts function"""

    import ansible.module_utils.facts.test
    test_collector = ansible.module_utils.facts.test.TestFactCollector()

    test_fact_collector = ansible_collector.AnsibleFactCollector(collector_classes=[test_collector])
    facts_dict = test_fact_collector.collect(module=None)

    assert facts_dict['test_fact_0'] == 'fact_0_value'
    assert facts_dict['test_fact_1'] == 'fact_1_value'



# Generated at 2022-06-22 22:49:21.870385
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit tests for function ansible_facts.

    This function doesn't return anything and so we can't test it directly.
    Instead we test the get_all_facts function which calls ansible_facts and
    passes us the results.
    '''

    from ansible.module_utils.facts import get_all_facts as w_get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    m = MockAnsibleModule()
    m.params = { 'gather_subset': ['all'] }

    # test that namespace is PrefixFactNamespace and prefix is ''
    n = PrefixFactNamespace(namespace_name='ansible', prefix='')
    assert ansible_facts(m, gather_subset=['all']) == w_get_all_facts

# Generated at 2022-06-22 22:49:33.896283
# Unit test for function ansible_facts
def test_ansible_facts():

    import json
    import subprocess
    import os.path

    if os.path.exists('./ansible_facts'):
        process = subprocess.Popen(['/usr/bin/env', 'python', 'ansible_facts'],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()

        if stderr:
            raise Exception('Failed to run ansible_facts:\n{0}'.format(stderr))
        else:
            print('\nansible_facts executed correctly...OK')
    else:
        print('\nansible_facts does not exist.\n')

    print('\nExecuting ansible_facts to gather all facts')

# Generated at 2022-06-22 22:49:39.848147
# Unit test for function get_all_facts
def test_get_all_facts():

    class AnsibleModule:
        def __init__(self):
            self.params = {}

    module = AnsibleModule()
    module.params['gather_subset'] = ['all']

    facts_dict = get_all_facts(module)
    print("get_all_facts:")
    print(facts_dict)


if __name__ == '__main__':
    test_get_all_facts()

# Generated at 2022-06-22 22:49:47.433998
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    import os

    # mock the module
    test_module = AnsibleModule(argument_spec={},
                                supports_check_mode=False)

    # mock environ vars to enable that fact
    os.environ['PATH'] = '/bin:/sbin'

    # run the fact collection
    fact = ansible_facts(test_module)

    # test for a specific value
    assert 'PATH' in fact['env']
    assert '/sbin' in fact['env']['PATH']


__all__ = ['ansible_facts', 'get_all_facts']

# Generated at 2022-06-22 22:49:58.040740
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        from ansible.module_utils.facts import ara_record_facts
        ara_record_facts_available = True
    except ImportError:
        # ara_record_facts only available in 2.3+, but we are testing 2.0 and 2.2 compatible
        #  function, so that's fine
        ara_record_facts_available = False

    class MockModule:
        def __init__(self):
            self.params = {'gather_subset': 'all'}

    class MockAnsibleModule(MockModule):
        def __init__(self):
            super(MockAnsibleModule, self).__init__()

            class MockAnsibleModuleError(Exception):
                def __init__(self):
                    super(MockAnsibleModuleError, self).__init__

# Generated at 2022-06-22 22:50:07.210520
# Unit test for function get_all_facts
def test_get_all_facts():
    my_module = 'my_module'
    my_gather_subset = 'my_gather_subset'

    expected_return_value = 'expected_return_value'
    mock_ansible_facts = 'mock_ansible_facts'

    mock_module = 'mock_module'
    mock_module_class = 'mock_module_class'

    class mock_AnsibleModule(mock_module_class):
        def __init__(self, tmp):
            self.params = dict()
            self.params['gather_subset'] = my_gather_subset

    with patch.multiple(my_module,
                        AnsibleModule=DEFAULT,
                        ansible_facts=DEFAULT) as mocks:
        mocks['ansible_facts'].return_value = expected_return_

# Generated at 2022-06-22 22:50:18.047708
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts

    ansible.module_utils.facts.namespace = mock.MagicMock()
    ansible.module_utils.facts.ansible_collector.get_ansible_collector = mock.MagicMock()

    class StubAnsibleModule(object):
        class AnsibleModule(object):
            params = {'gather_subset': 'should_be_subset'}

    stub_module = StubAnsibleModule
    assert get_all_facts(module=stub_module) == ansible_facts(module=stub_module)

# Generated at 2022-06-22 22:50:27.308135
# Unit test for function get_all_facts
def test_get_all_facts():
    # get_all_facts expects an AnsibleModule instance with a 'gather_subset' param
    class AnsibleModuleInstance:
        params = dict(gather_subset=['all'])

    class MockAnsibleModule:
        def __init__(self, params):
            self.params = params

    old_version_module = MockAnsibleModule(params=dict())
    new_version_module = MockAnsibleModule(params=dict(gather_subset=['all']))

    facts = get_all_facts(module=new_version_module)
    assert 'ssh_pub_keys' in facts
    assert 'env' in facts



# Generated at 2022-06-22 22:50:35.073661
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_text

    # test_module_utils.py's AnsibleModule mock doesn't set params so set it manually
    mock_module = testing_minimal_module.test_module
    mock_module.params = {}
    mock_module.params['gather_subset'] = ['!all', 'min']

    # mock fact ansible_processor_count by adding it to a module namespace
    fact_namespace = FactNamespace('ansible', module=mock_module)
    fact_names

# Generated at 2022-06-22 22:50:36.231701
# Unit test for function ansible_facts
def test_ansible_facts():
    ansible_facts()

# Generated at 2022-06-22 22:50:45.549245
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    class FakeAnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    # Create a fake AnsibleModule, and call get_all_facts()
    fake_module = FakeAnsibleModule()
    all_facts = get_all_facts(fake_module)

    # Verify that all_facts is a dict
    assert isinstance(all_facts, dict)

    # Verify that the dict has a 'ansible_' prefix
    assert all(key.startswith('ansible') for key in all_facts.keys())

    # Verify that the ansible_facts method returns a dict that does not have a 'ans

# Generated at 2022-06-22 22:50:52.227789
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test ansible_facts using the get_all_facts compat api'''

    class TestModule():

        def __init__(self, params):
            self.params = params

    params = dict(filter='dns')
    module = TestModule(params)

    facts = get_all_facts(module)

    assert facts['dns']
    assert not facts['hostvars']



# Generated at 2022-06-22 22:51:04.365226
# Unit test for function ansible_facts
def test_ansible_facts():

    class Result:
        changed = False
        failed = False
        skipped = False
        msg = ""

    class AnsibleModule:
        def __init__(self, params):
            self.params = params
            self.result = Result

    class TestResult:
        def __init__(self, facts):
            self.facts = facts

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors.all as all
    import ansible.module_utils.facts.collectors.local as local

    ansible.module_utils.facts.collector.GATHERED_FACTS = ['fake_fact']
    ansible.module_utils.facts.collectors.all.distribution_facts.GATHERED_FACTS = ['fake_fact']
    ansible.module_utils

# Generated at 2022-06-22 22:51:13.481909
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    ansible_facts = ansible_facts(module, gather_subset=['all'])
    assert type(ansible_facts) is dict
    assert 'ansible_architecture' in ansible_facts
    assert 'ansible_all_ipv4_addresses' in ansible_facts
    assert 'ansible_all_ipv6_addresses' in ansible_facts
    assert 'ansible_apparmor' in ansible_facts
    assert 'ansible_bios_date' in ansible_facts
    assert 'ansible_bios_version' in ansible_facts
    assert 'ansible_cmdline'

# Generated at 2022-06-22 22:51:20.398564
# Unit test for function get_all_facts
def test_get_all_facts():
    import json

    class ModuleFake(object):
        def __init__(self, gather_subset=None):
            self.params = {'gather_subset': gather_subset}
            self.exit_json = lambda **kwargs: json.dumps(kwargs)

    module = ModuleFake(gather_subset=['all'])
    get_all_facts(module)

    module = ModuleFake(gather_subset=['network'])
    get_all_facts(module)

# Generated at 2022-06-22 22:51:30.170009
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit test for function ansible_facts, using an AnsibleModule
    instance that is not actually running in Ansible.'''
    from ansible.module_utils.facts import ansible_facts

    from ansible.module_utils.basic import ModuleSpec, AnsibleModule

    # for the AnsibleModule, use some reasonable args
    ANSIBLE_MODULE_ARGS = {
        'gather_subset': ('all',),
        'gather_timeout': 10,
        'filter': '*',
    }

    module_spec = ModuleSpec(
        argument_spec=ANSIBLE_MODULE_ARGS,
        supports_check_mode=True,
        supports_argument_spec_of_module=True,
    )


# Generated at 2022-06-22 22:51:36.939025
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    class MockFactCollector(BaseFactCollector):
        name = 'mock'
        collected_facts = {'mock_fact': 'mock_value'}
        def fill_facts(self, ansible_facts=None, data=None):
            super(MockFactCollector, self).fill_facts(ansible_facts=ansible_facts, data=data)
    default_collectors.collectors.append(MockFactCollector)
    mock_module = MockAnsibleModule()
    facts = get_all_facts(module=mock_module)
    assert facts == mock_module.fact_cache

# Generated at 2022-06-22 22:51:40.474489
# Unit test for function get_all_facts
def test_get_all_facts():
    module = MockAnsibleModule()
    expected_dict = {'default_ipv4': {},
                     'default_ipv6': {}}
    ret = get_all_facts(module)
    assert ret == expected_dict


# Generated at 2022-06-22 22:51:48.585474
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts

    class MockedModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    module = MockedModule()
    facts = ansible_facts(module, gather_subset=['all'])
    assert facts['system'] == 'Linux'
    assert facts['distribution'] == 'RedHat'
    assert facts['distribution_major_version'] == '7'
# End unit test


# Generated at 2022-06-22 22:51:53.426843
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit test for ansible_facts method'''

    from ansible.module_utils.basic import AnsibleModule
    mock_module = AnsibleModule()

    facts_dict = ansible_facts(mock_module)

    assert isinstance(facts_dict, dict)
    for key, value in facts_dict.items():
        assert isinstance(key, str)
        assert isinstance(value, str)

# Generated at 2022-06-22 22:52:05.815611
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.network

    module = None
    # use the provided gather_subset
    gather_subset = ['all']
    facts = ansible_facts(module, gather_subset=gather_subset)
    assert 'distribution' in facts

    # use default gather_subset = 'all'
    gather_subset = None
    facts = ansible_facts(module, gather_subset=gather_subset)
    assert 'distribution' in facts

    # use a single collector
    gather_subset = ['distribution']
    facts = ansible_facts(module, gather_subset=gather_subset)
    assert 'distribution' in facts
    assert 'network' not in facts

    #

# Generated at 2022-06-22 22:52:17.595068
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys, os
    from ansible.module_utils.facts import ansible_collector, default_collectors, get_all_facts, ansible_facts
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class DummyAnsibleModule(object):
        def __init__(self):
            self.params = {}

    class TestCollector1(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            print("TestCollector1.collect")
            collected_facts = dict()
            collected_facts['fact1'] = 'fact1val'
            return collected_facts


# Generated at 2022-06-22 22:52:27.472517
# Unit test for function get_all_facts
def test_get_all_facts():
    '''make sure get_all_facts is a compat stub for ansible_facts'''

    from ansible.module_utils.facts import get_all_facts

    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    fields = dict(
        gather_subset='all',
        gather_timeout=10,
        filter='*',
    )

    module = AnsibleModule(argument_spec=dict())
    # AnsibleModule will set the argument_spec on the params, using the
    # fields defined above.

    facts = get_all_facts(module)

    module.exit_json(ansible_facts=facts)



# Generated at 2022-06-22 22:52:35.760219
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import os
    import json
    #import pytest

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    from ansible.modules.network.nxos import nxos_facts

    module = nxos_facts.AnsibleModule(argument_spec=nxos_facts.argument_spec)
    facts = ansible_facts(module, gather_subset="min")
    for k, v in facts.items():
        print("%s: %s" % (k, v))
    assert isinstance(json.dumps(facts), str)


if __name__ == "__main__":
    test_ansible_facts()

# Generated at 2022-06-22 22:52:45.153946
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    class MockModule(object):
        def __init__(self, params):
            self.params = params
    params = dict(gather_subset=['all'])
    module = MockModule(params=params)
    all_facts = get_all_facts(module=module)

    assert all_facts['ipv4_default'] == '1.2.3.4'

# Generated at 2022-06-22 22:52:55.694579
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import module_utils
    from ansible.module_utils.facts.virtual.posix import VirtualCollector

    VirtualCollector.collect_virtual_facts = lambda x: {'virtual': 'physical', 'virtual1': 'physical1'}

    # 1. Test with all default values.
    # Test with gather_subset is not passed.
    module = module_utils.build_module_mock()
    module.params = dict(gather_subset='all')
    module.params['gather_subset'] = ['all']
    module.params['gather_timeout'] = 10
    module.params['filter'] = '*'
    facts = ansible_facts(module)
    assert 'ansible_facts' in facts
    assert not facts['ansible_facts']['virtual']


# Generated at 2022-06-22 22:52:56.719740
# Unit test for function ansible_facts
def test_ansible_facts():
    raise NotImplementedError()

# Generated at 2022-06-22 22:52:58.150477
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-22 22:53:00.433267
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': 'all'}

    fact_module = FakeModule()

    facts = get_all_facts(fact_module)

    assert facts['lsb']

# Generated at 2022-06-22 22:53:09.964865
# Unit test for function ansible_facts
def test_ansible_facts():
    # code in this function is test code
    # pylint: disable=missing-docstring

    import os
    import tempfile
    import json
    import sys

    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils.facts import ansible_distribution

    # stub out sys.platform
    saved_platform = sys.platform

    if sys.version_info[0] == 2:
        import mock
        # pylint: disable=redefined-builtin, unused-import
        from mock import patch
    else:
        from unittest import mock
        from unittest.mock import patch

    # create an AnsibleModule stub class
    module = basic.AnsibleModule(argument_spec={'filter': {'type': 'str', 'default': '*'}})

   

# Generated at 2022-06-22 22:53:19.751853
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import gather_subset_definitions
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils._text import to_text

    # Test that limited subsets can be gathered
    for subset in gather_subset_definitions:
        if subset == 'all':
            continue
        # Ensure the test completes in a reasonable amount of time
        if subset == 'network' and sys.version_info[0] > 2:
            continue
        facts = ansible_facts(get_test_module(subset=subset), gather_subset=[subset])
        # Test that the gathered facts are not empty
        assert facts
        # Test that the facts are prefixed
        prefix = PrefixFact