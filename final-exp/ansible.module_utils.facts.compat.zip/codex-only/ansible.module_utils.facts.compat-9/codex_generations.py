

# Generated at 2022-06-22 22:43:26.004425
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes

    # dummyAnsibleModule creates a fake AnsibleModule for us.
    # This allows us to use the same module parameters that a real
    # Ansible module would receive.
    from ansible.module_utils.testing import dummy_AnsibleModule
    # create a fake AnsibleModule
    module = dummy_AnsibleModule()
    # Set defaults
    module.params['gather_subset'] = ['all']
    module.params['filter'] = '*'
    module.params['gather_timeout'] = 10


    facts = ansible_facts(module)

    # facts should be a dict
    assert isinstance(facts, dict)
    # the ansible_system fact should be in the dict

# Generated at 2022-06-22 22:43:35.063393
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # Create a fake AnsibleModule
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all']),
                                          'gather_timeout': dict(type='int', default=10),
                                          'filter': dict(type='str', default='*')},
                           supports_check_mode=True)

    # Run the get_all_facts function as it would be run by an ansible module
    facts_dict = get_all_facts(module=module)

    # Test that the subset of facts gathered was correct
    assert 'lsb' in facts_dict

# Generated at 2022-06-22 22:43:44.068937
# Unit test for function ansible_facts
def test_ansible_facts():

    def get_params(p):
        return dict(name='test',
                    gather_subset=set(p.get('gather_subset', 'all')),
                    gather_timeout=p.get('gather_timeout', 10),
                    filter=p.get('filter', '*'))


# Generated at 2022-06-22 22:43:45.067429
# Unit test for function ansible_facts
def test_ansible_facts():
    pass


# Generated at 2022-06-22 22:43:56.560733
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for the ansible_facts function'''

    from ansible.module_utils import basic
    from ansible.module_utils.facts import default_collectors

    module = basic.AnsibleModule(argument_spec={
        'gather_subset': dict(default=['all'], type='list'),
        'gather_timeout': dict(default=10, type='int'),
        'filter': dict(default='*', type='str'),
        'minimal_gather_subset': dict(default=['all'], type='list')
    })

    facts = ansible_facts(module)

    system_facts = facts['system']

    # check for a few collected system facts that are guaranteed to be present
    assert 'distribution' in system_facts
    assert 'distribution_version' in system_facts


# Generated at 2022-06-22 22:44:08.523246
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = frozenset(['fact_id'])

        def collect(self, module=None, collected_facts=None):
            return {'fact_id': {'key': 'value'}}

    class TestFactCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = frozenset(['fact_id2'])


# Generated at 2022-06-22 22:44:18.990005
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.default_collectors import DefaultCollector
    from ansible.module_utils.facts.platform.default import Default as PlatformDefault
    from ansible.module_utils.facts import default_collectors

    class MockDefaultCollector(DefaultCollector):
        def __init__(self, module):
            self.modules_setup = False
            self.run_once = True
            self.module = module

        def collect(self, module=None, collected_facts=None):
            if not self.modules_setup:
                self.modules_setup = True
                self.module.add_file_common_arguments()
            return dict(fact1='fact1')


# Generated at 2022-06-22 22:44:28.404651
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test with no params. Should return the same facts as get_all_facts.
    # But get_all_facts is not defined in this module, so just verify that
    # we get a complete set of facts.
    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'all'}
    fake_module = FakeModule()

    facts = ansible_facts(fake_module)
    assert facts
    assert 'pkg_mgr' in facts
    assert 'selinux' in facts
    assert 'caps' in facts
    assert 'default_ipv4' in facts
    assert 'python' in facts

# Generated at 2022-06-22 22:44:38.417112
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.system.system_platform_bsd import SystemPlatformBSD

    # this unit test is for issue #34637
    # https://github.com/ansible/ansible/issues/34637
    # it generates a situation where the same fact is collected by multiple collectors
    # because the 'system' collector is deprecated at ansible 2.3, and replaced by 'apparmor' and 'lsb',
    # I will mock 'ansible_system' as defined by the system collector, and 'ansible_lsb' as defined by
    # the lsb collector.  I will also

# Generated at 2022-06-22 22:44:44.676946
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.facts import Facts

    test_class = Facts()
    test_class.add_fact('foo', 'bar')
    test_class.add_fact('bar', 'baz')

    result = test_class.get_ansible_facts()
    assert result['foo'] == 'bar'
    assert result['bar'] == 'baz'

# Generated at 2022-06-22 22:44:50.326928
# Unit test for function get_all_facts
def test_get_all_facts():

    # Fake AnsibleModule instance
    class FakeAnsibleModule(object):
        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)

    am = FakeAnsibleModule(['network'])
    facts = get_all_facts(am)

    assert 'ansible_all_ipv4_addresses' in facts
    assert 'ansible_default_ipv4' in facts

    assert len(facts.keys()) == 96


# Generated at 2022-06-22 22:45:01.267131
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    all_collector_classes = default_collectors.collectors
    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])


# Generated at 2022-06-22 22:45:04.092916
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    # TODO: Write tests
    pass

# Generated at 2022-06-22 22:45:12.037767
# Unit test for function ansible_facts
def test_ansible_facts():
    # pylint: disable=unused-argument
    def fake_module(params):
        return True

    fake_module_params = {
        'gather_subset': ['all'],
        'gather_timeout': 10
    }

    fake_module_instance = fake_module(fake_module_params)

    facts_dict = ansible_facts(fake_module_instance,
                               gather_subset=fake_module_params['gather_subset'])

    assert 'architecture' in facts_dict

# Example of how to call ansible_facts() from a module
# def main():
#     from ansible.module_utils.facts import ansible_facts
#     from ansible.module_utils.basic import AnsibleModule
#     module = AnsibleModule(argument_spec=dict())
#    

# Generated at 2022-06-22 22:45:18.169093
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import BaseFactCollector

    class MockAllFactsCollector(BaseFactCollector):
        name = 'mock_all_facts'
        _fact_ids = set(['a1', 'a2', 'a3', 'a4'])

        def collect(self, module=None, collected_facts=None):
            return {'mock_all_facts': 'mock_all_facts'}

    class MockModule(object):
        def __init__(self, gather_subset=None):
            self.params = {'gather_subset': [] if gather_subset is None else gather_subset}

    assert get_all_facts(MockModule(['all'])) == {'mock_all_facts': 'mock_all_facts'}
    assert get_

# Generated at 2022-06-22 22:45:28.619952
# Unit test for function get_all_facts
def test_get_all_facts():
    action = {}
    ansible_facts = {}
    ansible_facts['ansible_all_ipv4_addresses'] = []
    ansible_facts['ansible_default_ipv4'] = {}
    ansible_facts['ansible_default_ipv4']['address'] = '10.0.0.1'
    ansible_facts['ansible_default_ipv4']['alias'] = 'eth0'
    ansible_facts['ansible_default_ipv4']['broadcast'] = '10.0.0.255'
    ansible_facts['ansible_default_ipv4']['gateway'] = '10.0.0.1'
    ansible_facts['ansible_default_ipv4']['interface'] = 'eth0'
    ansible_facts

# Generated at 2022-06-22 22:45:35.512511
# Unit test for function get_all_facts
def test_get_all_facts():

    import sys
    sys.path.insert(0, '../../lib')

    import json
    import os
    import unittest

    from ansible.module_utils.basic import AnsibleModule

    class TestGetAllFacts(unittest.TestCase):

        def setUp(self):

            self.module = AnsibleModule(
                argument_spec=dict(
                    gather_subset=dict(type='list'),
                )
            )


# Generated at 2022-06-22 22:45:45.501511
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    gather_subset = ['all', 'interfaces', 'foo']
    ansible_facts_path = 'ansible.module_utils.facts.ansible_facts'
    get_all_facts_path = 'ansible.module_utils.facts.ansible_facts.get_all_facts'

    def fake_get_all_facts(module):
        assert module.params.get('gather_subset') == gather_subset
        return {'foo': 'bar'}

    m = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=gather_subset, type='list'),
        )
    )


# Generated at 2022-06-22 22:45:49.207170
# Unit test for function get_all_facts
def test_get_all_facts():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default='all', type='list')})
    assert isinstance(get_all_facts(module), dict)



# Generated at 2022-06-22 22:45:59.482716
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts import default_collectors

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeBaseFactCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return collected_facts

    class FakeNetworkCollector(NetworkCollector):
        def collect(self, module=None, collected_facts=None):
            return {}


# Generated at 2022-06-22 22:46:04.916448
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.__init__ import AnsibleModuleMock
    from ansible.module_utils.facts import _get_all_collector_classes
    # need to make sure that the DEFAULT_GATHER_TIMEOUT is set to a non-zero value
    # so that get_all_facts can accept an empty list of facts to collect
    import ansible.module_utils.facts.default_collectors as default_collectors
    default_collectors.DEFAULT_GATHER_TIMEOUT = 1
    module = AnsibleModuleMock(params={'gather_subset': ['all']})
    all_facts = get_all_facts(module)
    expected_keys = set(_get_all_collector_classes().keys())
    assert set(all_facts.keys()) == expected_keys

# Generated at 2022-06-22 22:46:16.362688
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import DistroCollector

    all_collector_classes = default_collectors.collectors
    collector_class = all_collector_classes[DistroCollector]
    collector_instance = collector_class(namespace=None,
                                         filter_spec=None)

    class FakeModule(object):
        '''Fake ansible module that just holds a gather_subset'''

        def __init__(self, gather_subset):
            self.gather_subset = gather_subset

    fake_module_1 = FakeModule(gather_subset=['all'])
    facts_dict_1 = ansible_facts(fake_module_1)
    assert facts_dict_1 == ansible_facts

# Generated at 2022-06-22 22:46:25.510436
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.fact import BaseFactModule

    class TestModule(AnsibleModule):
        def __init__(self, gather_subset=None, gather_timeout=None):
            super(TestModule, self).__init__(argument_spec=dict(
                gather_subset=dict(type='list', default=gather_subset),
                gather_timeout=dict(default=gather_timeout),
                filter=dict(default="*"),
            ), supports_check_mode=False)

    module = TestModule(gather_subset=['!all'])

    facts_dict = get_all_facts(module)

# Generated at 2022-06-22 22:46:34.848886
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    # gather_subset is '!all'
    module = MockModule({'gather_subset': ['!all']})
    facts = get_all_facts(module)
    assert not facts

    # gather_subset is 'all'
    module = MockModule({'gather_subset': ['all']})
    facts = get_all_facts(module)
    assert 'default_ipv4' in facts

    # gather_subset is ['min']
    module = MockModule({'gather_subset': ['min']})
    facts = get_all_facts(module)
    assert 'default_ipv4' in facts

    # gather_subset is ['network']

# Generated at 2022-06-22 22:46:43.629378
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    module = DictModule()
    facts_dict = get_all_facts(module)

    # check that this is a dict
    assert isinstance(facts_dict, dict)

    # check that fact names have no prefix
    assert all(fact[0].find('ansible_') != 0 for fact in facts_dict.items())

    assert facts_dict['all_ipv4_addresses'] == '10.20.30.40'



# Generated at 2022-06-22 22:46:50.965378
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    test_args = {'gather_subset': 'min'}

    module = MockAnsibleModule(argument_spec=dict(), suppression_warnings=[])
    module.params = test_args

    gather_subset = module.params['gather_subset']
    all_collector_classes = default_collectors.collectors

    namespace = PrefixFactNamespace(namespace_name='ansible')


# Generated at 2022-06-22 22:47:01.840094
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.six import PY3
    if PY3:
        import unittest
        import unittest.mock
    else:
        import mock
        from unittest import TestCase

    class FakeCollector(object):
        def collect(self, module):
            return {'foo': 'bar'}

    class FakeFactModule(AnsibleModule):
        def __init__(self):
            self.params = {'gather_subset': None}


# Generated at 2022-06-22 22:47:08.384098
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    gather_subset = module.params['gather_subset'] = ['all']
    gather_timeout = module.params['gather_timeout'] = 10
    filter_spec = module.params['filter'] = '*'


# Generated at 2022-06-22 22:47:15.791912
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic
    import json

    # Make the module params
    module_args = {
        "gather_subset": ['all'],
    }

    # Make an AnsibleModule from fake module data
    module = basic.AnsibleModule(argument_spec={}, **module_args)

    # get the facts
    facts_dict = ansible_facts(module)

    assert isinstance(facts_dict, dict)
    assert facts_dict.get('fqdn') is not None

    print(json.dumps(facts_dict, indent=4))
    # TODO add unit test for ansible_facts function
    #assert False

# Generated at 2022-06-22 22:47:26.565363
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils import basic

    # Set up test requirements and run function
    # module_init_params is a sentinel value to test the function with
    module = basic.AnsibleModule(argument_spec={'gather_subset': {'type': 'list', 'default': ['all']}})
    test_fact = get_all_facts(module)

    # Test results of function
    # Test that the returned dictionary contains the expected keys
    assert(set(test_fact.keys()).issuperset(set(ansible_facts(module).keys())))
    # Test for the function to return a dictionary
    assert(isinstance(test_fact, dict))

# Generated at 2022-06-22 22:47:34.103333
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
 
    module = AnsibleModule({'gather_subset':{'all'}}, 'ansible')
    all_facts = get_all_facts(module)
    assert all_facts 

    module = AnsibleModule({'gather_subset':{'all'}}, 'ansible')
    all_facts = get_all_facts(module)
    assert all_facts 

    module = AnsibleModule({'gather_subset':{'all'}}, 'ansible')
    all_facts = get_all_facts(module)
    assert all_facts 

    module = AnsibleModule({'gather_subset':{'all'}}, 'ansible')
    all_facts = ansible_facts(module)
    assert all_facts

# Generated at 2022-06-22 22:47:41.537456
# Unit test for function ansible_facts
def test_ansible_facts():

    # TODO: this unit test was done against a real AnsibleModule, moved to a fake object, needs further testing.
    class FakeModule:
        def __init__(self):
            self.params = {}

    module = FakeModule()
    module.params['gather_subset'] = None
    data = ansible_facts(module)

    # make sure at least the kernel fact is present, since we don't know the distribution or kernel
    # this test is going to run on.
    assert 'kernel' in data

# Generated at 2022-06-22 22:47:52.721503
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    sys.modules['ansible'] = None
    import os.path
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils._text import to_bytes

    class AnsibleModuleFake(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, required=False, opt_dirs=None):
            if executable == 'foo':
                return u'/bin/true'
            return None

        def run_command(self, args, check_rc=True):
            argbytes = to_bytes(args)
            if argbytes == b'/bin/true --version':
                return 'bar', '', 0
            else:
                raise Exception('Not implemented')


# Generated at 2022-06-22 22:48:00.523578
# Unit test for function ansible_facts
def test_ansible_facts():

    import exceptions
    import copy
    import collections

    # raise exception if a mutable value is found for a 'ansible_facts' fact.
    # this ensures facts are cached properly
    def is_mutable(obj):
        if isinstance(obj, collections.Mapping):
            return True
        if isinstance(obj, exceptions.Exception):
            return True
        return False

    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    module.params['gather_timeout'] = 0.01

    facts = ansible_facts(module, gather_subset=['all'])
    flat_facts = {k: v for (k, v) in facts.items() if k.startswith('ansible_')}


# Generated at 2022-06-22 22:48:07.023777
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Exercise the ansible_facts method, via a mock.

    Make sure if you add a new fact, you add a new test to ensure it's properly included.
    '''
    import __builtin__
    import mock

    # mock for the module
    my_ansible_module = mock.MagicMock(params=dict(
        gather_subset=['all'],
        filter='*',
    ))
    # mock for the gathering plugin
    my_fact_collector = mock.MagicMock()
    # mock the method that gathers the facts

# Generated at 2022-06-22 22:48:14.576909
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test to verify function interfaces'''
    class Module:
        '''Fake AnsibleModule'''
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 3
        def fail_json(self, **kwargs):
            '''Fake fail_json'''
            raise RuntimeError('Exiting')
        def exit_json(self, **kwargs):
            '''Fake exit_json'''
            raise RuntimeError('Exiting')
    module = Module()
    fact_dict = get_all_facts(module)
    assert 'ansible_default_ipv4' in fact_dict

# Generated at 2022-06-22 22:48:20.410907
# Unit test for function ansible_facts
def test_ansible_facts():
    ansible_mod = default_collectors.AnsibleModule(argument_spec=dict(test_arg='test_value'))
    result = ansible_facts(ansible_mod, gather_subset=['all'])
    assert isinstance(result, dict)
    assert result

# Generated at 2022-06-22 22:48:29.929311
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts

    ansible_facts(module, gather_subset=None)
    '''

    import sys
    import json

    # Mock out everything but 'ansible_facts'
    sys.modules['ansible.module_utils.facts'] = None
    sys.modules['ansible.module_utils.facts.namespace'] = None
    sys.modules['ansible.module_utils.facts.default_collectors'] = None
    sys.modules['ansible.module_utils.facts.ansible_collector'] = None

    sys.modules['ansible_facts'] = None

    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector


# Generated at 2022-06-22 22:48:42.262267
# Unit test for function get_all_facts
def test_get_all_facts():
    import mock
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.facts.ansible_facts

    default_collector_classes = default_collectors.collectors
    for collector_class in default_collector_classes:
        assert(issubclass(collector_class, ansible.module_utils.facts.ansible_facts.BaseFactCollector))

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    old_get_all_facts = ansible.module_utils.facts.ansible_facts.get_all_facts


# Generated at 2022-06-22 22:48:43.643868
# Unit test for function ansible_facts
def test_ansible_facts():
    # TODO: write a unit test for ansible_facts
    pass

# Generated at 2022-06-22 22:48:46.801666
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    module = FakeModule({'gather_subset': ['all']})
    fact_dict = get_all_facts(module)

    assert len(fact_dict) > 100

# Generated at 2022-06-22 22:48:58.156407
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import unittest
    import sys
    import traceback
    from mock import MagicMock

    class TestModule(unittest.TestCase):
        def test_get_all_facts(self):
            '''test compat api for ansible 2.2/2.3 module_utils.facts.get_all_facts method'''
            mock_module = MagicMock()
            mock_module.params = {'gather_subset': ['all']}
            facts = get_all_facts(mock_module)
            self.assertIn('default_ipv4', facts)

    # Keep the test output

# Generated at 2022-06-22 22:49:04.838044
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.__main__ import main as ansible_facts_main
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts import ansible_collector

    module_args = ImmutableDict(
        gather_subset='all',
        gather_timeout=10,
        filter='*'
    )

    module = ansible_facts_main(module_args)
    print(ansible_facts(module))


if __name__ == '__main__':
    test_get_all_facts()

# Generated at 2022-06-22 22:49:13.067514
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.utils import is_ipv4, is_ipv6

    test_module = DummyModule('ansible_default_ipv4', 'ansible_default_ipv6')
    all_facts = get_all_facts(test_module)

    assert 'default_ipv4' in all_facts
    assert 'default_ipv6' in all_facts

    assert is_ipv4(all_facts['default_ipv4']['address'])
    assert is_ipv6(all_facts['default_ipv6']['address'])



# Generated at 2022-06-22 22:49:13.902792
# Unit test for function get_all_facts
def test_get_all_facts():
    pass

# Generated at 2022-06-22 22:49:14.538072
# Unit test for function get_all_facts
def test_get_all_facts():
    pass

# Generated at 2022-06-22 22:49:20.404363
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule(object):
        def __init__(self, params):
            self.params = params
    import sys
    if sys.version_info[0] >= 3:
        module = MockModule({'gather_subset': ['all']})
    else:
        module = MockModule({'gather_subset': 'all'})

    facts = get_all_facts(module)
    assert "subset" not in facts
    assert "gather_subset" not in facts



# Generated at 2022-06-22 22:49:32.797145
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Tests for the ansible compatible facts interface.'''
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector

    class FakeAnsibleModule:
        '''FakeAnsibleModule for testing'''

        class FakeParams:
            '''FakeParams for testing'''

            def __init__(self, gather_subset=None, gather_timeout=None, filter=None):
                self.gather_subset = gather_subset
                self.gather_timeout = gather_timeout
                self.filter = filter


# Generated at 2022-06-22 22:49:43.311256
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.utils import AnsibleFactsModule
    from ansible.module_utils.facts.collector.local import LocalFactCollector

    class MockModule(AnsibleFactsModule):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    class MockLocalFactCollector(LocalFactCollector):
        def __init__(self):
            self.facts = {'default_ipv4': {'address': '10.0.2.15', 'alias': 'eth0', 'scope': 'global', 'family': 'inet'}}

        def collect(self, module, collected_facts=None):
            return self.facts

    actual = get_all_facts(module=MockModule())

# Generated at 2022-06-22 22:49:50.282152
# Unit test for function ansible_facts
def test_ansible_facts():
    import argparse

    # set up a fake module arg spec.
    # AnsibleModule requires a subset of these args, let's just populate them all.
    module_args = dict(gather_subset=dict(type='list', default=['all']),
                       filter=dict(type='dict', default='*'))


# Generated at 2022-06-22 22:49:58.211899
# Unit test for function get_all_facts

# Generated at 2022-06-22 22:50:07.360343
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''
    import os
    import sys
    import ast
    import types
    import unittest
    from ansible.module_utils.facts import ansible_collector

    class AnsibleModuleMock(object):
        '''Mock AnsibleModule object'''
        def __init__(self, params=None):
            if params is None:
                self.params = dict()
            else:
                self.params = params
            self.check_mode = False

        def exit_json(self, *args, **kwargs):
            '''Mock AnsibleModule exit_json method'''
            pass

        def fail_json(self, *args, **kwargs):
            '''Mock AnsibleModule fail_json method'''
            pass


# Generated at 2022-06-22 22:50:18.049379
# Unit test for function get_all_facts
def test_get_all_facts():

    gather_subset = ['all']
    # mock AnsibleModule
    class A:
        class B:
            def __init__(self, params):
                self.params = params

        def __init__(self, params):
            self.params = A.B(params)

    module = A(params=dict(gather_subset=gather_subset))

    facts = get_all_facts(module)

    # verify we get the same results as ansible_facts()
    expected_facts = ansible_facts(module, gather_subset=gather_subset)
    assert expected_facts == facts


# Generated at 2022-06-22 22:50:21.663891
# Unit test for function get_all_facts
def test_get_all_facts():
    import unittest.mock as um
    m = um.MagicMock()
    m.params = dict()
    m.params['gather_subset'] = ['all']
    m.params['gather_timeout'] = 10
    assert isinstance(get_all_facts(m), dict)


# Generated at 2022-06-22 22:50:31.819894
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils import basic
    import sys

    # make a fake 'module' object for testing
    module = basic.AnsibleModule(argument_spec=dict())
    # set up the param for gather_subset
    module.params['gather_subset'] = ['all']

    # make a function call, and capture the stdout/stderr
    # save current stderr and stdout state
    old_stdout = sys.stdout
    old_stderr = sys.stderr

    # capture stdout and stderr
    import StringIO
    sys.stdout = mystdout = StringIO.StringIO()
    sys.stderr = mystderr = StringIO.StringIO()

    all_facts = ansible_

# Generated at 2022-06-22 22:50:44.145674
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.get_all_facts

    import collections

    import unittest
    import unittest.mock

    class AnsibleModuleMock:
        def __init__(self):
            self.params = {'gather_subset': '!all'}

    class CollectionMock:
        def __init__(self):
            pass

        def collect(self, module=None):
            return {'test':'test'}

    ansible.module_utils.facts.collector.get_collector = unittest.mock.MagicMock(return_value=CollectionMock())
    ansible.module_utils.facts.get_all_facts.ansible_facts = un

# Generated at 2022-06-22 22:50:52.709402
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.legacy import get_all_facts
    from ansible.module_utils.facts.legacy import ansible_facts

    def AnsibleModule(**kwargs):
        return type("AnsibleModule", (object,), kwargs)

    module = AnsibleModule(params=dict(gather_subset=['min']))
    assert ansible_facts(module, gather_subset=['min']) == get_all_facts(module)

# Generated at 2022-06-22 22:50:57.967835
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils import basic
    from ansible.module_utils.facts import default_collectors

    module = basic.AnsibleModule(argument_spec={},
                                 supports_check_mode=True)

    facts = ansible_facts(module=module)

    assert isinstance(facts, dict)


# Generated at 2022-06-22 22:51:09.535316
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import ansible_collector

    the_subset = ['all']

    # mock return of the default_collector.collect(module)
    for collector_name, collector_class in ansible_collector.collectors.items():
        mock_collect = lambda module: dict(collector_name=collector_name,
                                           a=1,
                                           b=2)
        collector_class.collect = mock_collect

    mock_module = basic.AnsibleModule(
        argument_spec=dict(gather_subset=dict(required=False, default=the_subset),
                           gather_timeout=dict(required=False, default=10),
                           filter=dict(required=False, default='*'))
    )

# Generated at 2022-06-22 22:51:20.654112
# Unit test for function get_all_facts
def test_get_all_facts():
    import tempfile
    import shutil
    import os


# Generated at 2022-06-22 22:51:30.365052
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts
    import os

    # Create fake modules
    class FakeModule():
        def __init__(self):
            self.params = {}

        def exit_json(self, **kwargs):
            return
        def fail_json(self, **kwargs):
            return

    module = FakeModule()
    module.params['filter'] = '*'
    module.params['gather_subset'] = 'network'
    module.params['gather_timeout'] = 600
    module.params['filter'] = '*'

    # Run module_utils.ansible_facts
    facts_dict = ansible_facts(module)

    # Test existence of a network fact

# Generated at 2022-06-22 22:51:42.762003
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import inspect
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.basic import AnsibleModule

    # ensure we are testing this method
    assert get_all_facts(None) == {}
    assert inspect.getfile(get_all_facts) == '%s/%s' % (sys.path[0], 'ansible_facts.py')

    class MockModule(object):
        def __init__(self, params={}):
            self.params = params

    all_facts = get_all_facts(MockModule())
    assert len(all_facts) == 65
    assert len(all_facts['lsb']) == 5
    assert 'Red Hat' in all_facts['lsb']['description']

    all_facts = get_all_facts

# Generated at 2022-06-22 22:51:49.009442
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for ansible_facts'''

    import ansible.module_utils.facts.timeout
    import ansible.module_utils.facts.default_collectors
    import ansible.module_utils.facts.ansible_collector
    import ansible.module_utils.facts.namespace

    import tempfile
    import json
    import os

    def _module_mock_factory(params):
        '''create a mock module, with mock api'''

        module = types.SimpleNamespace()
        module.fail_json = self.fail_method  # pylint: disable=no-member
        module.exit_json = self.exit_method  # pylint: disable=no-member
        module.params = params
        return module


# Generated at 2022-06-22 22:51:59.442139
# Unit test for function ansible_facts
def test_ansible_facts():

    # Arrange
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.namespace

    class FakeAnsibleModule:
        def __init__(self):
            pass

    class FakeFactsCollector:
        def __init__(self, module, filter_spec, gather_subset=None, gather_timeout=10):
            pass

        def collect(self, module):
            return {'foo': 'bar'}

    class FakeNamespace:
        def __init__(self, namespace_name, prefix):
            pass

        def filter_collection(self, collection_dict):
            return {'foo': 'baz'}

    fake_module = FakeAnsibleModule()
    fake_gather_subset = ['all']
    fake_filter_spec = '*'

# Generated at 2022-06-22 22:52:12.288114
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Test get_all_facts'''
    import sys
    sys.path.append('.')

    import ansible.module_utils.facts.network as ans_network
    import ansible.module_utils.facts.system as ans_system
    import ansible.module_utils.facts.virtual as ans_virtual
    # various collectors
    import ansible.module_utils.facts.distribution as ans_distribution
    import ansible.module_utils.facts.dns as ans_dns
    import ansible.module_utils.facts.kernel as ans_kernel
    import ansible.module_utils.facts.package_manager as ans_pkg_mgr
    import ansible.module_utils.facts.service_mgr as ans_service_mgr
    import ansible.module_utils.facts.system as ans_system


# Generated at 2022-06-22 22:52:21.486500
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.basic import AnsibleModule

    class FakeCollector(BaseFactCollector):
        def collect(self, module):
            return {'test': 1}

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)
            self.params = {'gather_subset': 'all'}
            self.facts = get_all_facts(self)

    m = TestModule()

# Generated at 2022-06-22 22:52:22.821316
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-22 22:52:33.855624
# Unit test for function ansible_facts
def test_ansible_facts():

    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'

    import ansible.module_utils.facts.collector.distro
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockBaseFactCollector(BaseFactCollector):

        name = 'mock_collector'
        _fact_ids = frozenset()

        def collect(self, module=None, collected_facts=None):
            return {'mock_fact': 'dummy_result'}

    all_collector_classes = [ansible.module_utils.facts.collector.distro.Distribution, MockBaseFactCollector]

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    fact_collector = \
        ansible

# Generated at 2022-06-22 22:52:42.260714
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import AnsibleModule
    fake_ansible_module = AnsibleModule(argument_spec={})

    fake_ansible_module.params['gather_subset'] = ['all']
    returned_facts = get_all_facts(fake_ansible_module)

    # Test at least one fact is returned, to confirm that get_all_facts wraps ansible_facts()
    # such that it is calling ansible_facts() with the default (['all']) gather_subset.
    assert 'lsb' in returned_facts


# Generated at 2022-06-22 22:52:52.880345
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    if sys.version_info[0] > 2:
        # py3: mock doesn't work with python 3
        import unittest.mock as mock
    else:
        import mock

    mock_module = mock.Mock(params={'gather_subset': ['all']})

    ansible_facts = get_all_facts(mock_module)

    # make sure a bunch of expected facts are there.
    assert ansible_facts['uptime_seconds'] is not None
    assert ansible_facts['uptime_hours'] is not None
    assert ansible_facts['uptime_days'] is not None
    assert ansible_facts['uptime_seconds'] is not None
    assert ansible_facts['uptime_hours'] is not None

# Generated at 2022-06-22 22:52:59.940030
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import cache
    import sys

    # set up a module to call test_ansible_facts from
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict(gather_subset=['all'])
    module = AnsibleModule(argument_spec=module_args)
    module.exit_json = lambda **x: x

    # clear existing facts
    cache.clear_facts()

    # run the facts
    result = ansible_facts(module)

    # make sure they're not empty
    assert result, result

    # make sure the ansible_facts dict is there
    assert 'ansible_facts' in result, result
    assert result['ansible_facts'], result

    # make sure we got some facts for each known collector

# Generated at 2022-06-22 22:53:00.578633
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-22 22:53:10.094028
# Unit test for function ansible_facts
def test_ansible_facts():

    # Fact collector unit test for ansible.module_utils.facts.ansible_collector
    # ansible_collector.py is a new (2.3) file, not present in 2.2 or 2.0.
    # So in order to unit test this file, ansible_collector.py needs to be installed.  That is
    # done by installing ansible as a python module, then deleting all the modules that would
    # not be installed in a functional install.  This results in a functional ansible.module_utils.facts,
    # but a non-functional ansible installation.

    # set up the test environment (2.2)
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

# Generated at 2022-06-22 22:53:19.831862
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit tests for get_all_facts'''

    # 2.3/2.4 compat shim
    if getattr(get_all_facts, '__module__', None) != 'ansible.module_utils.facts.system.debian':
        return

    from ansible.module_utils.facts import ansible_facts
    from ansible.modules.network.edgeos import edgeos_facts

    from ansible.module_utils.facts.system.debian import os
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.interfaces import InterfacesCollector
    from ansible.module_utils.facts.network.ipv4 import IPv4Collector
    from ansible.module_utils.facts.network.ipv6 import IPv6Collector

   