

# Generated at 2022-06-22 22:43:26.873473
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.ansible_collector as FACTS

    # install and save the old method
    old_collectors = FACTS.collectors
    FACTS.collectors = {('ansible', ''): FACTS.FactCollector}

    # import the unit under test
    from ansible.module_utils.facts import ansible_facts as uut

    # hack in some empty values for testing
    class M(object):
        def __init__(self, gather_subset=None):
            self.params = {'gather_subset': gather_subset}

    # unit under test
    m = M()

    # expected value for all facts
    expected_value = {'facts': {}}

    # test with subset param

# Generated at 2022-06-22 22:43:30.971226
# Unit test for function ansible_facts
def test_ansible_facts():

    def fake_module():
        class fake_AnsibleModule(object):
            def __init__(self):
                self.params = dict(gather_subset=[])

        return fake_AnsibleModule()

    ansible_facts(fake_module())

# Generated at 2022-06-22 22:43:40.853416
# Unit test for function get_all_facts
def test_get_all_facts():

    # Note: this is a barebones test, that does not actually test module_utils/facts.
    # Rather, it tests the compat api module_utils.facts.get_all_facts
    from ansible.module_utils.facts import get_all_facts
    import ansible.module_utils.facts.namespace

    class FakeAnsibleModule:
        def __init__(self):
            self.params = dict(gather_subset=['all'])

    fake_module = FakeAnsibleModule()

    ansible_collector.get_ansible_collector = lambda *args, **kwargs: None

    prefix_fact_namespace = ansible.module_utils.facts.namespace.PrefixFactNamespace

# Generated at 2022-06-22 22:43:50.532473
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.system.sunos import SunOSSystem
    from ansible.module_utils.facts.distribution.sunos import SunOSDistribution
    from ansible.module_utils.facts import default_collectors

    all_collector_classes = \
        [klass() for klass in default_collectors.collectors
         if klass not in [SunOSHardware, SunOSNetwork, SunOSSystem, SunOSDistribution]]

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-22 22:43:56.956686
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import ansible_collector as ac

    class FakeModule(basic.AnsibleModule):
        """FakeModule replaces BasicModule for unit testing."""

        def __init__(self):
            super(FakeModule, self).__init__()
            self.params = dict(
                gather_timeout=10,
                gather_subset=None
            )

    module = FakeModule()
    result = get_all_facts(module)
    assert 'fqdn' in result

# Generated at 2022-06-22 22:44:00.775785
# Unit test for function get_all_facts
def test_get_all_facts():
    ''' unit test for get_all_facts()'''
    from ansible.module_utils.facts.collector.legacy import ansible_facts as get_all_facts
    from ansible.module_utils.facts.collector import ansible_legacy_facts

    # it is a function, not a method, so no self arg
    get_all_facts(ansible_legacy_facts)

# Generated at 2022-06-22 22:44:11.617468
# Unit test for function ansible_facts
def test_ansible_facts():
    gather_subset = ['all']
    # get_all_facts requires this to be a param
    gather_timeout = 10
    # get_all_facts requires this to be a param
    filter_spec = '*'
    # get_all_facts requires this to be a param
    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    all_collector_classes = default_collectors.collectors

# Generated at 2022-06-22 22:44:15.534822
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeAnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    am = FakeAnsibleModule()

    f = get_all_facts(am)

    assert len(f) > 50



# Generated at 2022-06-22 22:44:24.304983
# Unit test for function get_all_facts
def test_get_all_facts():
    import json
    import sys
    import os

    # Dummy module class for testing
    class DummyModule(object):
        def __init__(self, params=None):
            self.params = params
            self.fail_json_called = False
            self.fail_json_msg = None
            self.exit_args = None

        def exit_json(self, **kwargs):
            self.exit_args = kwargs

        def fail_json(self, msg):
            self.fail_json_called = True
            self.fail_json_msg = msg

    def invoke(args):
        meta_args = [
            '__ansible_facts__',
            '-M',
            os.path.dirname(__file__)
        ]

        sys.argv = ['argv0'] + meta_args

# Generated at 2022-06-22 22:44:29.992385
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.ansible_collector
    import ansible.module_utils.facts.default_collectors
    import ansible.module_utils.facts.utilities
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.parser

    class AnsibleModuleStub(object):
        def __init__(self, gather_timeout):
            self.params = dict(gather_timeout=gather_timeout)


# Generated at 2022-06-22 22:44:39.203476
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    import mock

    # create a mock AnsibleModule object that returns the values we want it to return
    # for the params we want to be called
    class MockAnsibleModule(object):
        def __init__(self, *args, **kwargs):
            self.module = mock.Mock()
            self.params = {'key_arg': 'value_arg'}

        def get_bin_path(self, arg, *args, **kwargs):
            return self.params.get(arg, None)

        def fail_json(self, msg, **args):
            raise RuntimeError(msg)

        def get_bin_path(self, arg, *args, **kwargs):
            return self.params.get(arg, None)

    # create a

# Generated at 2022-06-22 22:44:49.471191
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import facts as ansible_facts
    from ansible.module_utils.facts.core import get_all_facts


# Generated at 2022-06-22 22:45:00.789870
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.test.unit.test_ansible_facts import TestAnsibleFacts

    # the testing module in this project does not implement most of the AnsibleModule methods,
    # so for this unit test we need to use the module from the ansible source tree
    from ansible.module_utils.basic import AnsibleModule

    import os

    from ansible.module_utils._text import to_bytes, to_native

    # Need to setup a fake connection for the ansible_facts function
    class FakeConnection(object):
        def __init__(self, *args, **kwargs):
            self.connection = None

        def connect(self, *args, **kwargs):
            self.connection = None
            return self.connection

    # Need to define a fake version to return a reasonable version of the module
   

# Generated at 2022-06-22 22:45:10.767704
# Unit test for function ansible_facts
def test_ansible_facts():

    import sys
    import json
    import unittest
    import unittest.mock as mock
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        '''A really basic implementation of AnsibleModule that only pretends to
        be able to affect the environment by setting env vars.  We won't do
        anything with them, but just access the env vars that are set.'''
        def __init__(self, params):
            self.params = params
            self._environment = {}

        def set_environment(self, data):
            self._environment = data

    module = FakeModule(dict(gather_subset=['min'], gather_timeout=10, filter='*'))


# Generated at 2022-06-22 22:45:14.422982
# Unit test for function get_all_facts
def test_get_all_facts():
    class TestModule(object):
        def __init__(self):
            self.params = dict(gather_subset='!fib')
    module = TestModule()
    ansible_facts(module)

# Generated at 2022-06-22 22:45:25.840950
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import AnsibleModuleMock

    module = AnsibleModuleMock()
    module.params['filter'] = 'ansible_distribution'

    input_subset = ['all']
    input_filter_spec = 'ansible_distribution'
    expected_subset = frozenset(['distribution'])
    expected_facts = {'distribution': {'distribution': 'CentOS',
                                       'distribution_file_variety': 'RedHat',
                                       'distribution_file_version': '7',
                                       'distribution_file_major_version': '7',
                                       'distribution_release': 'Core',
                                       'distribution_major_version': '7',
                                       'distribution_version': '7.3.1611'}}


# Generated at 2022-06-22 22:45:34.698158
# Unit test for function ansible_facts
def test_ansible_facts():

    # Set up a fake AnsibleModule
    class MockAnsibleModule(object):
        def __init__(self, fact_subset, params={}):
            self.params = params

    # Test that we correctly parse gather_subset and gather_timeout param names
    # when they're passed in
    fact_subset = ['!all', 'network']
    gather_timeout = 1
    params = {'gather_subset': fact_subset, 'gather_timeout': gather_timeout}

    mock_module = MockAnsibleModule(fact_subset, params=params)
    # Should've called the ansible_collector with fact_subset and gather_timeout
    # set
    facts_dict = ansible_facts(mock_module)

    # Make sure we get back all the facts in fact_subset, and

# Generated at 2022-06-22 22:45:45.144520
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector.cache.file import Cache
    from ansible.module_utils.facts.collector.network.base import NetworkCollector
    from ansible.module_utils.facts.collector.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.collector.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.collector.system.distribution import LinuxDistributionCollector
    from ansible.module_utils.facts.collector.system.distribution import LinuxGenericDistribution
    from ansible.module_utils.facts.collector.system.distribution import LinuxGenericDistributionCollector
    from ansible.module_utils.facts.collector.system.distribution import WindowsDistribution

# Generated at 2022-06-22 22:45:56.781826
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    This function tests the get_all_facts function
    '''
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_native

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector


# Generated at 2022-06-22 22:46:03.931014
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import json

    module = AnsibleModule({'gather_subset': ['all']}, 'test_get_all_facts')
    gathered_facts = get_all_facts(module)
    assert('distribution' in gathered_facts)
    assert('distribution_release' in gathered_facts)

    module = AnsibleModule({'gather_subset': ['network']}, 'test_get_all_facts')
    gathered_facts = get_all_facts(module)
    assert('default_ipv4' in gathered_facts)


# Generated at 2022-06-22 22:46:15.447322
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import FACT_CACHE
    import mock

    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.called = 'get_all_facts'

    FACT_CACHE = {}
    # test with no gather_subset specified
    params = {}
    module = MockModule(params)

    fact_dict = get_all_facts(module)
    assert fact_dict != None
    assert 'default_ipv4' in fact_dict
    assert 'ansible_facts' not in fact_dict

    # test with specified gather_subset
    params = {'gather_subset': 'network'}
    module = MockModule(params)

    fact_dict = get_all_facts(module)
    assert fact_

# Generated at 2022-06-22 22:46:24.890748
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts import default_collectors

    for collection in default_collectors.collectors:
        try:
            collection.__dict__['__test_ansible_facts']
        except KeyError:
            continue
        if type(collection.__dict__['__test_ansible_facts']) == dict:
            collection.__dict__['__test_ansible_facts']['ansible_collector'] = ansible_collector
            collection.__dict__['__test_ansible_facts']['ansible_local'] = ansible_local
            collection.__dict__['__test_ansible_facts']['default_collectors'] = default_collectors

# Generated at 2022-06-22 22:46:27.406400
# Unit test for function ansible_facts
def test_ansible_facts():

    class Module(object):
        # Params variable
        params = {
            'gather_subset': ['!all', 'network'],
            'filter': 'ansible_eth*'
        }

    module = Module()
    ansible_facts(module)

# Generated at 2022-06-22 22:46:36.349026
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.modules.system.setup import setup
    # Module takes a gather_subset parameter

    # ansible_facts returns a dict mapping the bare fact name ('default_ipv4' with no 'ansible_' namespace) to
    # the fact value.
    try:
        # ansible python 3
        from ansible.module_utils.six import PY3
    except ImportError:
        # ansible python 2
        from ansible.module_utils.six import PY2

    if PY2:
        module = setup(AnsibleModule={})
    else:
        module = setup(AnsibleModule=dict())

    facts = ansible_facts(module, gather_subset=['coffee'])

    assert 'distribution' not in facts
    assert 'distribution_version' not in facts

# Generated at 2022-06-22 22:46:47.171807
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    class MockModule(object):
        def __init__(self, params):
            self.params = params
    module = MockModule(params={'gather_subset': ['all']})
    result = get_all_facts(module)
    assert result.get('distribution') is not None
    assert result.get('domain') is not None
    assert result.get('fqdn') is not None
    assert result.get('hostname') is not None
    assert result.get('interfaces') is not None
    assert result.get('ipv4') is not None

# Generated at 2022-06-22 22:46:58.789748
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts

    since get_all_facts is a thin wrapper around ansible_facts,
    just test that it passes the correct arg, and returns the correct result
    '''
    from ansible.module_utils.facts.ansible_compat import ModuleTestCase

    class ModuleMock():
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    class TestGetAllFacts(ModuleTestCase):

        def test_returns_ansible_facts(self):
            mock_module = ModuleMock(gather_subset=['all'])
            facts_dict = get_all_facts(mock_module)

            self.assertIn('default_ipv4', facts_dict)
            self.assertIn

# Generated at 2022-06-22 22:47:09.742531
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import is_collector_disabled
    from ansible.module_utils._text import to_bytes

    def mock_module(gather_subset, gather_timeout=10):
        if gather_timeout is None:
            gather_timeout = 10
        if isinstance(gather_subset, str):
            gather_subset = [gather_subset]
        return type('MockModule', (object,), {
            'params': {
                'gather_subset': gather_subset,
                'gather_timeout': gather_timeout
            },
            'fail_json': lambda self, **kwargs: None,
            'boolean': lambda x: x
        })()

    fact_collector = ansible_facts(module=mock_module(['network']))

# Generated at 2022-06-22 22:47:21.508524
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector

    # mock a module
    class MockAnsibleModule():

        def __init__(self):
            self.params = {'gather_subset': ['all'],
                           'gather_timeout': 10,
                           # notice gather_subset is not in params
                           }

        def fail_json(self, **kwargs):
            raise RuntimeError("Should not call fail_json")

    module = MockAnsibleModule()

    facts = ansible_facts(module, gather_subset=['hardware', 'virtual'])

    # the fact 'test_fact' is set to the value 134 in
    # ./module_utils/facts/test/test_ansible_collector.py
    assert facts['test_fact'] == 134

# Generated at 2022-06-22 22:47:31.630102
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import os
    import unittest
    import mock
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.system import default_collectors as default_system_collectors
    from ansible.module_utils.facts import ansible_collector

    # Mock some of the imports that can prevent running this code when not in an Ansible environment
    mock_module = mock.MagicMock()
    mock_module.params = {'gather_subset': ['all']}

    mock_import = mock.MagicMock()
    mock_import.return_value = default_system_collectors

# Generated at 2022-06-22 22:47:42.739848
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import module_utils
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeAnsibleModule:

        def __init__(self, params):
            self.params = params
            self.fail_json = None
            self.exit_json = None
            self.warnings = None

        def fail_json(self, msg):
            pass

        def exit_json(self, changed=False, ansible_facts=None):
            pass

    class FakeCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = []

        def collect(self, module, collected_facts):
            return collected_facts

    module_utils.FACT_SUBSETS = {'all': ['fake']}
    module_utils.COLLECTORS

# Generated at 2022-06-22 22:47:53.854348
# Unit test for function ansible_facts
def test_ansible_facts():

    try:
        from ansible.module_utils.facts import ansible_facts
    except ImportError:
        pytest.skip("ansible_facts not available in ansible 2.2")

    class FakeModule:
        def __init__(self, params):
            self.params = params

    os_version = u'10.4.0-<redacted>'


# Generated at 2022-06-22 22:48:06.114363
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.system.distribution as distribution
    from ansible.module_utils.facts import module_proxy

    # Setup the fake module for our test
    module = module_proxy.AnsibleModuleProxy('test_module', {})

    # add some magic to the module
    module.params = {'gather_subset': ['all'],
                     'filter': '*',
                     'gather_timeout': 10}

    module.get_bin_path = lambda exe: exe

    # Draw attention if distribution collector is broken
    assert distribution.DistributionFactCollector.OS_FAMILY == 'RedHat'

    # Get all facts
    ansible_facts = get_all_facts(module)

    # Look at some of the results
    assert 'ansible_distribution' in ansible_facts

# Generated at 2022-06-22 22:48:14.081615
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    import json

    class FakeModule(AnsibleModule):
        def __init__(self):
            super(FakeModule, self).__init__()
            self.params = {
                'gather_subset': ['all'],
                'filter': '*',
                'gather_timeout': 10
            }
            self.exit_json_called = False

        def exit_json(self, **kwargs):
            self.exit_json_called = True

    class FakeCollector(object):
        def __init__(self):
            self.collect_called = False
            self.collect_module = None
            self.collect_fact_dict = {'hostname': 'localhost'}


# Generated at 2022-06-22 22:48:26.335183
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_all_facts
    import sys

    my_namespace = PrefixFactNamespace(namespace_name='ansible', prefix='ansible_')
    my_fact_collector = get_all_facts(sys.modules['ansible.module_utils.basic'], gather_subset=['all'])
    assert my_namespace.namespace_name in my_fact_collector
    assert 'ansible_' in my_fact_collector
    assert 'default_ipv4' in my_fact_collector['ansible']
    assert 'distribution' in my_fact_collector['ansible']
    assert 'default_user' in my_fact_collector['ansible']

# Generated at 2022-06-22 22:48:38.478282
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.ansible_facts import get_all_facts
    from ansible.module_utils.facts.ansible_facts import ansible_facts
    from ansible.module_utils.facts import get_collector_list

    # set up initial class/namespace mapping
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    all_collector_classes = default_collectors.collectors

# Generated at 2022-06-22 22:48:47.461573
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''

    # Create a mock AnsibleModule object, with a gather_subset parameter
    from ansible.module_utils.facts import get_all_facts
    from unittest.mock import MagicMock  # Python 3.3 doesn't have mock module in stdlib

    mock_ansible_module = MagicMock()
    mock_ansible_module.params = {'gather_subset': ['all']}

    facts = get_all_facts(mock_ansible_module)

    assert isinstance(facts, dict)
    assert len(facts) > 0

    # ensure we collect at least one expected fact
    assert 'default_ipv4' in facts

# Generated at 2022-06-22 22:48:57.194204
# Unit test for function ansible_facts
def test_ansible_facts():

    class MockModule(object):
        def __init__(self):
            self.params = {'filter': '*'}

    mock_module = MockModule()

    from ansible.module_utils.facts import fetch_facts as fetch_actual_facts
    actual_facts = fetch_actual_facts('all', mock_module)

    compat_facts = ansible_facts(mock_module, gather_subset=['all'])

    assert cmp(compat_facts, actual_facts) == 0

    compat_facts = ansible_facts(mock_module, gather_subset=['min'])

    assert cmp(compat_facts, actual_facts) != 0

# Generated at 2022-06-22 22:49:04.476329
# Unit test for function get_all_facts
def test_get_all_facts():
    ''' ansible 2.3/2.4 gather_subset parameter is optional, ansible 2.0/2.1 is required
        so test both ways
    '''
    class TestAnsibleModule(object):
        def __init__(self, gather_subset=None):
            self.params = {'gather_subset': gather_subset}

    facts = get_all_facts(TestAnsibleModule(gather_subset=['network']))
    assert isinstance(facts, dict)
    assert 'default_ipv4' in facts
    assert 'default_ipv6' in facts

    facts = get_all_facts(TestAnsibleModule())
    assert isinstance(facts, dict)
    assert 'default_ipv4' in facts
    assert 'default_ipv6' in facts



# Generated at 2022-06-22 22:49:12.777827
# Unit test for function ansible_facts
def test_ansible_facts():

    # This is a fake AnsibleModule object for testing
    class AnsibleModule(object):
        def __init__(self):
            pass
        def params(self, k):
            return {
                'filter': 'ipv4',
                'gather_subset': ['min', 'hardware'],
                'gather_timeout': 1,
            }[k]

    module = AnsibleModule()
    facts = ansible_facts(module)

    assert 'ipv4' in facts
    assert 'default_ipv4' in facts['ipv4']
    assert 'ipv6' not in facts

# Generated at 2022-06-22 22:49:16.675587
# Unit test for function ansible_facts
def test_ansible_facts():
    class module_object():
        params = {'gather_subset': ['!all', '!min']}
        def fail_json(self, msg, **kwargs):
            print(msg)

    module = module_object()
    assert ansible_facts(module)

# Generated at 2022-06-22 22:49:24.500105
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import get_all_facts

    # use a mock for AnsibleModule to use for testing
    mock_module = type('AnsibleModule', (object,), {})

    # make an instance of 'AnsibleModule' with some mock attributes
    fake_module = mock_module()

    # mock a few params
    params = {
        'filter': '*',
        'gather_subset': ['all'],
        'gather_timeout': 1
    }
    fake_module.params = params

    fake_module.run_command = lambda x: (0, to_bytes('example output'), None)

    # run the function we want to test
    facts_dict = get_all_facts(fake_module)

    #

# Generated at 2022-06-22 22:49:28.791218
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    sys.path.append('/usr/lib/python2.7/dist-packages/')
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=None, required=False),
            gather_timeout=dict(default=10, required=False)
        ),
        params = {'gather_subset': ['all']},
        supports_check_mode = True
    )

    facts = get_all_facts(module)

    assert facts is not None

# Generated at 2022-06-22 22:49:31.327774
# Unit test for function ansible_facts
def test_ansible_facts():
    print(ansible_facts(None, gather_subset=['ansible_lsb']))

if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-22 22:49:42.379432
# Unit test for function ansible_facts

# Generated at 2022-06-22 22:49:46.956459
# Unit test for function get_all_facts
def test_get_all_facts():

    # Mockup an ansible module
    m = dict(
        ANSIBLE_MODULE_ARGS = dict (
            gather_subset = ['all']
        )
    )
    module = AnsibleModule(argument_spec=m['ANSIBLE_MODULE_ARGS'])

    # make sure we get back a dict
    assert isinstance(get_all_facts(module), dict)

# Generated at 2022-06-22 22:49:57.398608
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.compat.tests import unittest
    from ansible.module_utils.facts.utils import get_collector_names

    class TestAnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': None}

    module = TestAnsibleModule()

    facts_dict = get_all_facts(module)
    assert isinstance(facts_dict, dict)
    assert facts_dict.get('ansible_facts')
    collector_names = get_collector_names()
    assert set(facts_dict['ansible_facts'].keys()).issuperset(collector_names)

    module.params['gather_subset'] = []
    facts_dict = get_all_facts(module)
    assert isinstance(facts_dict, dict)


# Generated at 2022-06-22 22:50:06.640298
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.collector as collector
    class Module(object):
        def __init__(self, gather_subset=None):
            self.params = {'gather_subset': gather_subset,
                           'gather_timeout': 10}

        def get_bin_path(self, executable, required=False):
            if executable == 'cp':
                return "/bin/cp"

    class Distribution(object):
        @staticmethod
        def linux_distribution(full_distribution_name):
            return ("CentOS", "6", "Final")

    class User(object):
        def __init__(self):
            self.pw_gid = 10
            self.pw_name = "test_user"
            self.pw_dir = "/home/test_user"



# Generated at 2022-06-22 22:50:19.631610
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.other

    # pretend namespace.add_prefix just returns the key
    ansible.module_utils.facts.namespace.add_prefix = lambda namespace_name, key: key
    # pretend hardware collector always return empty dict
    ansible.module_utils.facts.collector.hardware.Hardware = lambda namespace, filter_spec, data=None, gather_subset=None: {}
    # pretend network collector always return empty dict

# Generated at 2022-06-22 22:50:29.801322
# Unit test for function ansible_facts
def test_ansible_facts():
    import unittest
    import unittest.mock as mock

    class MockedAnsibleModule(object):
        def __init__(self, gather_subset=None, gather_timeout=None, filter=None):
            self.params = {}
            if gather_subset is not None:
                self.params['gather_subset'] = gather_subset
            if gather_timeout is not None:
                self.params['gather_timeout'] = gather_timeout
            if filter is not None:
                self.params['filter'] = filter

    class MockedCollector(object):
        collector_classes = [
            'FakeCollector',
        ]
        def __init__(self):
            self.facts = {
                'fake_fact': 'fake_value',
            }


# Generated at 2022-06-22 22:50:42.233556
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for the get_all_facts function'''
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    from ansible.module_utils.facts.cpu.base import CpuCollector
    from ansible.module_utils.facts.memory.base import MemoryCollector
    from ansible.module_utils.facts.distribution.base import DistributionCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.collector import FactsCollector
    import ansible.module_utils.facts.network.default as ansible_default_network_fact_collector
    import ansible.module_utils.facts.system.default as ansible_default_system_

# Generated at 2022-06-22 22:50:49.300565
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit test for function ansible_facts

    static_data_collector_classes is a fact collector
    that has no dependencies, and just returns static test data.

    The static data includes minimal_gather_subset, so those
    facts are returned.

    '''
    from unittest import mock

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import collector

    # mock the static_data collect
    static_data_collector = static_data_collector_class()

# Generated at 2022-06-22 22:51:01.565458
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import FACT_SUBSETS
    from ansible.module_utils.facts.compat import get_all_facts as ansible_get_all_facts

    class MockModule(object):
        def __init__(self):
            self.params = {'gather_timeout': 1}

    m = MockModule()

    # collect everything
    facts_dict = ansible_facts(module=m)
    keys = facts_dict.keys()
    assert len(keys) > 0

    # collect only network facts
    m.params['gather_subset'] = 'network'
    facts_dict = ansible_facts(module=m)
    keys = facts_dict.keys()
    assert len(keys) == 5

    # collect only networking facts, and only IPv4 facts
    m.params

# Generated at 2022-06-22 22:51:11.664135
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.sunos import SunOSIfconfigNetwork
    from ansible.module_utils.facts.network.linux import DebianIfconfigNetwork
    from ansible.module_utils.facts.network.linux import LinuxInterfaceNetwork
    from ansible.module_utils.facts.network.linux import LinuxIpRouteNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetCfgNetwork
    from ansible.module_utils.facts.network.linux import LinuxLsbNetwork
    from ansible.module_utils.facts.network.linux import LinuxSysconfigNetwork

# Generated at 2022-06-22 22:51:19.436103
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeAnsibleModule():
        def __init__(self):
            self.params = dict()
            self.params['filter'] = '*'
            self.params['gather_subset'] = 'all'

    fake_module = FakeAnsibleModule()
    get_all_facts(fake_module)


# Generated at 2022-06-22 22:51:29.471029
# Unit test for function ansible_facts
def test_ansible_facts():
    # ansible_facts needs an AnsibleModule instance to call its 'fail_json' method
    # but it only calls that method in the case of an error.
    # So stub out the fail_json method so we can call ansible_facts without a real
    # AnsibleModule to work with.
    class StubAnsibleModule(object):
        def __init__(self, name, params=None):
            self.name = name
            if params is None:
                params = {}
            self.params = params
            # just a stub, does not have to do anything.
            self.fail_json = lambda msg, **kwargs: None

    stub_module = StubAnsibleModule(name='stub module')
    stub_module.params['gather_subset'] = ['all']


# Generated at 2022-06-22 22:51:34.259422
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.six import PY2
    if PY2:
        import __builtin__ as builtins
    else:
        import builtins

    import ansible.module_utils.facts.system as facts_system
    import ansible.module_utils.facts.virtual as facts_virtual
    import ansible.module_utils.facts.hardware as facts_hardware

    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = fail_json
            self.exit_json = exit_json
            self.params['filter'] = '*'

        def is_failed(self):
            return self._failed

        def fail_json(self, msg):
            self._failed = True


# Generated at 2022-06-22 22:51:44.954673
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_collection_list
    from ansible.module_utils.facts.collector.default import DefaultCollector

    class FakeAnsibleModule:
        def __init__(self):
            self.params = dict()

    module = FakeAnsibleModule()

    # test minimal_gather_subset being used, if passed
    module.params['gather_subset'] = None
    module.params['gather_timeout'] = 2
    module.params['filter'] = '*'
    default_collector_classes = [c for c in get_collection_list() if issubclass(c, DefaultCollector)]
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    fact_collector = \
        ansible_collector.get_ans

# Generated at 2022-06-22 22:51:55.564358
# Unit test for function ansible_facts
def test_ansible_facts():
    # The 'module' object is used to fake calls to the AnsibleModule,
    # to ensure the results of the ansible_facts() function are the same as the
    # ansible 2 module_utils.facts.get_all_facts() function would return.

    class FakeAnsibleModule(object):
        def __init__(self, params={}):
            self.params = params

    # test with ansible 2.3 params
    gather_timeout = 10
    module = FakeAnsibleModule({'gather_subset': ['all'], 'gather_timeout': gather_timeout})
    facts = ansible_facts(module)
    assert facts['python']['version'] == '2.7.15'
    assert facts['ansible_facts'] == {'python': {'version': '2.7.15'}}

   

# Generated at 2022-06-22 22:52:00.251870
# Unit test for function get_all_facts
def test_get_all_facts():
    import types

    get_all_facts_func = get_all_facts
    assert isinstance(get_all_facts_func, types.FunctionType)

    # Nothing to test here since we have already tested the defacto
    # default behaviour of module_utils.facts.get_all_facts()
    return



# Generated at 2022-06-22 22:52:06.438258
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule(object):
        params = {}

    #call ansible_facts with no gather_subset, should contain facts
    facts_dict = ansible_facts(FakeModule())
    assert len(facts_dict) > 0

    #call ansible_facts with gather_subset, should contain facts
    facts_dict = ansible_facts(FakeModule(), gather_subset='all')
    assert len(facts_dict) > 0

# Generated at 2022-06-22 22:52:17.973162
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import ansible.module_utils.facts.facts
    all_collector_classes = default_collectors.collectors
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-22 22:52:29.336215
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils
    from ansible.module_utils.facts import DEFAULT_GATHER_SUBSET

    class FakeModule(object):
        def __init__(self):
            self.params = dict(gather_subset=DEFAULT_GATHER_SUBSET)

        def get_bin_path(self, executable, required=True, opt_dirs=[]):
            return 'bogus_path'

    fake_module = FakeModule()

    # function has no side effects
    facts_dict = ansible_facts(fake_module)

    assert 'default_ipv4' in facts_dict, "default_ipv4 should be in fact dict"

# Generated at 2022-06-22 22:52:37.210094
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Test get_all_facts with various values of gather_subset'''
    class TestModule:
        def __init__(self):
            self.params = {}

    def get_params(gather_subset):
        test_module = TestModule()
        test_module.params['gather_subset'] = gather_subset
        return test_module

    def assert_fact_collecting(facts_returned, message):
        gathered_all = True
        for key in facts_returned:
            if facts_returned[key] is None:
                gathered_all = False
                break
        assert gathered_all, message


# Generated at 2022-06-22 22:52:45.421998
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import module_lldp

    class FakeModule:
        def __init__(self):
            self.params = {}

    assert get_all_facts(FakeModule()) == ansible_facts(FakeModule())

    # Now assume that ansible_facts has been updated to have an optional gather_subset arg
    assert get_all_facts(FakeModule()) == ansible_facts(FakeModule(), gather_subset=None)

    # Now that we have some optional args,

# Generated at 2022-06-22 22:52:55.872222
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import json

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    params = dict(
        filter='*',
        gather_subset='all',
        gather_timeout=10,
    )

    mock_module = MockModule(params)

    facts = ansible_facts(mock_module)

    print("Facts:")
    print(json.dumps(facts, indent=4, sort_keys=True))

    # Some checks on the gathered facts
    if os.name == 'nt':
        assert facts['mounts'] == []
        assert facts['python']['executable'] == '\\windows\\system32\\python.exe'
        assert facts['user'] == ('Administrator', [])

# Generated at 2022-06-22 22:53:05.940423
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.network.distro import DistroNetworkCollector
    from ansible.module_utils.facts.system.distro import DistroCollector
    from ansible.module_utils.facts.system.distribution import DistributionCollector

    test_module = DummyAnsibleModule()

    distro_collector = DistroCollector()
    distro_network_collector = DistroNetworkCollector()
    distribution_collector = DistributionCollector()

    all_collectors = [distro_collector, distro_network_collector, distribution_collector]
    all_collector_classes = [type(c) for c in all_collectors]

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='foo_')

    fact_collector = \
        ansible

# Generated at 2022-06-22 22:53:13.694779
# Unit test for function get_all_facts
def test_get_all_facts():
    test_module = AnsibleModule(argument_spec={'gather_subset': dict(default=['all'])})
    result = get_all_facts(module=test_module)
    assert 'default_ipv4' in result
    assert 'lsb' in result.get('distribution', {})
    assert 'ansible' in result
    assert 'default_ipv4' in result.get('ansible', {})
    assert 'distribution' in result.get('ansible', {})
    assert 'lsb' in result.get('ansible', {}).get('distribution', {})


# Generated at 2022-06-22 22:53:21.495309
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Test the get_all_facts method

    Ensures that the get_all_facts method returns the correct data
    and calls the correct methods in the process.
    '''

    module = MockModule()
    module.params['gather_subset'] = ['all']

    # Mock the default subsets.
    module.params['gather_subset'] = ['all']

    get_all_facts(module)

    # Ensure that the method ran only once.
    assert ansible_facts.call_count == 1
    ansible_facts.assert_called_once_with(module, gather_subset=None)

