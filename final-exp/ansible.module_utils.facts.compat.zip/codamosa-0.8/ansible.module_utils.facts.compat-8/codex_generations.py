

# Generated at 2022-06-11 02:11:49.386531
# Unit test for function ansible_facts
def test_ansible_facts():

    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.service_mgr

    class MockModule(object):

        def __init__(self, params):
            self.params = params

    import collections
    class MockFactCollector(object):
        def __init__(self, namespaces):
            self.namespaces = namespaces

        def collect(self, module):
            return collections.OrderedDict(self.namespaces)

    class MockFactNamespace(object):
        def __init__(self, namespace_name, prefix):
            self.namespace_name = namespace_name
            self.prefix = prefix


# Generated at 2022-06-11 02:11:58.228994
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    print(sys.path)
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.namespace import Namespace
    import os

    class SampleCollector(BaseFactCollector):
        name = 'sample'
        _fact_ids = frozenset([
            'sample_fact',
            'sample_fact2'
        ])

        def collect(self, module=None, collected_facts=None):
            collected_facts['sample_fact'] = '123'


# Generated at 2022-06-11 02:12:04.327212
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.lsb
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.selinux

    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts.utils import get_file_content, get_file_lines, get_python_version

    # Prime the cache so we can use it.

# Generated at 2022-06-11 02:12:13.786720
# Unit test for function ansible_facts
def test_ansible_facts():
    import collections
    import sys
    import tempfile
    import textwrap
    import time
    import unittest
    from unittest.mock import Mock, MagicMock, patch

    sys.path.append(os.getcwd())

    class TestAnsibleModule():
        def __init__(self, *args, **kwargs):
            self.params = kwargs.get('params', dict())

        def fail_json(self, *args, **kwargs):
            pass

    class TestGatherSubsetPlugin():
        distro = 'testdistro'
        def get_facts(self, module, collected_facts, cache):
            collected_facts['gathered_by'] = 'testplugin'
            return collected_facts


# Generated at 2022-06-11 02:12:16.896904
# Unit test for function get_all_facts
def test_get_all_facts():
    ansible_module = mock.Mock()
    ansible_module.params = {'gather_subset': ['all']}

    assert get_all_facts(ansible_module) is not None



# Generated at 2022-06-11 02:12:24.111545
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit test for function ansible_facts'''
    module = mock.MagicMock()

    module.params.get.side_effect = [None, 20, '*']
    gather_subset = None

    ansible_facts(module, gather_subset)

    module.params.get.assert_any_call('gather_subset', ['all'])
    module.params.get.assert_any_call('gather_timeout', 10)
    module.params.get.assert_any_call('filter', '*')

    gather_subset = ['facts']

    ansible_facts(module, gather_subset)

    module.params.get.assert_any_call('gather_subset', ['facts'])
    module.params.get.assert_any_call('gather_timeout', 10)


# Generated at 2022-06-11 02:12:34.555192
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import module_params

    from ansible.module_utils._text import to_text

    from ansible_collections.testns.testcoll.plugins.modules import test_ansible_facts
    module_args = dict(
        gather_subset=['all'],
        filter='*',
        gather_timeout=10,
    )

    module = test_ansible_facts.TestAnsibleFactsModule(
        argument_spec=dict(),
        supports_check_mode=True,
        **module_args
    )

    facts = get_all_facts(module=module)

    assert isinstance(facts, dict)
    assert 'default_ipv4' in facts
    assert isinstance(facts['default_ipv4'], dict)

# Generated at 2022-06-11 02:12:45.804096
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    try:
        from ansible.modules.system.setup import AnsibleModule
        HAS_SETUP_MODULE = True
    except:
        HAS_SETUP_MODULE = False

    if not HAS_SETUP_MODULE:
        import pytest
        pytestmark = pytest.mark.skip("skipping test_ansible_facts, requires module AnsibleModule")

    module = AnsibleModule(argument_spec={})
    fact_collector = ansible_collector.get_ansible_collector(all_collector_classes=default_collectors.collectors)
    facts = fact_collector.collect(module=module).copy()


# Generated at 2022-06-11 02:12:57.265944
# Unit test for function get_all_facts
def test_get_all_facts():
    import fact_collector_base

    # stub class for testing
    class MyFactCollector(fact_collector_base.BaseFactCollector):
        pass

    # Set up the required FactCollectors (with a valid cache)
    class StubAnsibleModule:
        def __init__(self):
            # Set up a fake facts cache
            self._facts_cache = {'dns': {'dns_answer': 'bar'}}
            self.params = {'gather_subset': ['dns']}

    module = StubAnsibleModule()
    all_collector_classes = []

    # Add a known valid fact collector to the list

# Generated at 2022-06-11 02:13:06.854521
# Unit test for function ansible_facts
def test_ansible_facts():
    collect_ipv4_interfaces = ansible_collector.Collector.collect_ipv4_interfaces
    ansible_collector.Collector.collect_ipv4_interfaces = lambda self, module: dict((k, k) for k in ['eth0', 'lo'])

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})

    facts = ansible_facts(module=module)

    assert 'eth0' in facts
    assert 'lo' in facts

    ansible_collector.Collector.collect_ipv4_interfaces = collect_ipv4_interfaces

# Generated at 2022-06-11 02:13:17.957449
# Unit test for function get_all_facts
def test_get_all_facts():
    import unittest
    import ansible.module_utils.facts
    import ansible.module_utils.facts.collector.network

    class ModuleStub(object):
        '''give us enough to test get_all_facts'''
        class AnsibleModule(object):
            '''AnsibleModule stub'''
            def __init__(self, **kwargs):
                for k, v in kwargs.items():
                    setattr(self, k, v)

        @staticmethod
        def params(**kwargs):
            '''stub AnsibleModule params method'''
            return kwargs

        def __init__(self, **kwargs):
            self.params = self.params(**kwargs)


# Generated at 2022-06-11 02:13:29.258330
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeCollector(BaseFactCollector):
        # need an instance of BaseFactCollector that returns a value
        def populate(self):
            self.collect_this('fake_fact', 'fake_value')

    # make a mock ansible module
    module_args = {
        'gather_subset': ['all'],
        'filter': '*',
    }
    fake_module = MagicMock(params=module_args)

    # defined in ansible_facts api
    all_collector_classes = [FakeCollector]
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-11 02:13:38.857638
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'gather_subset': {'type': 'list', 'default': ['all']},
                                          'gather_timeout': {'type': 'int', 'default': 10},
                                          'filter': {'default': '*'}})
    fact_dict = get_all_facts(module)

    assert fact_dict
    # Check that the fact_dict is a dict-like object
    assert 'ansible_pkg_mgr' in fact_dict
    assert 'virtualization_role' in fact_dict
    # Ensure the fact_dict is not a PrefixFactNamespace
    assert 'ansible_virtualization_role' not in fact_dict

# Generated at 2022-06-11 02:13:51.318262
# Unit test for function ansible_facts
def test_ansible_facts():

    import tests.module_utils.facts.facts_module as facts
    import pprint

    # Results of gather_subset=['util']
    expected_util_facts = {
        'ansible_selinux': {
            'getenforce': 'enforcing',
            'policyvers': '31',
            'status': 'enabled'}
    }

    # Expected results of gather_subset=['all']

# Generated at 2022-06-11 02:14:03.028523
# Unit test for function get_all_facts
def test_get_all_facts():
    import unittest
    from ansible.module_utils import basic

    # ansible_facts returns a dict
    def test_returns_a_dict(self):
        test = self.__class__(name='test')
        module = basic.AnsibleModule(argument_spec={})
        module.params['gather_subset'] = ['all']
        module.params['gather_timeout'] = 10

        result = ansible_facts(module)

        test.assertIsInstance(result, dict)

    def test_returns_a_dict_with_several_keys(self):
        test = self.__class__(name='test')
        module = basic.AnsibleModule(argument_spec={})
        module.params['gather_subset'] = ['all']

# Generated at 2022-06-11 02:14:06.875355
# Unit test for function ansible_facts
def test_ansible_facts():

    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['all']

    module = FakeModule()
    assert ansible_facts(module) is not None

# Generated at 2022-06-11 02:14:12.151306
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    fake_module = FakeModule()
    facts_dict = get_all_facts(fake_module)
    assert isinstance(facts_dict, dict)
    assert facts_dict['distribution'] is not None

# Generated at 2022-06-11 02:14:21.867111
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import DEFAULT_GATHER_SUBSET
    import copy
    import unittest

    module = AnsibleModule(argument_spec={})
    assert module.params == dict()

    # calling get_all_facts with no gather_subset, should return all the facts.
    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert len(facts) >= 20

    # calling get_all_facts with a gather_subset, should return only those facts
    module = AnsibleModule(argument_spec={'gather_subset': 'hardware'})
    assert module.params == dict(gather_subset=['hardware'])

    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert len(facts)

# Generated at 2022-06-11 02:14:31.012896
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.ansible_collector import AnsibleFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    class MyAnsibleFactCollector(AnsibleFactCollector):
        def collect(self, module):
            return dict(key1='value1', key2='value2', key3='value3')

    all_collector_classes = default_collectors.collectors
    all_collector_classes['ansible'] = MyAnsibleFactCollector
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-11 02:14:36.264030
# Unit test for function ansible_facts
def test_ansible_facts():

    # Fake AnsibleModule object
    class FakeAnsibleModule:
        def __init__(self, args):
            self.params = args

    test_module = FakeAnsibleModule({'gather_subset': ['all'], 'gather_timeout': 10, 'filter': '*'})
    facts = ansible_facts(test_module)
    assert facts



# Generated at 2022-06-11 02:14:45.124142
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    all_facts = get_all_facts(module)
    assert set(['ansible_python', 'ansible_python_version', 'ansible_python_major_version']) == set(all_facts.keys())


# Generated at 2022-06-11 02:14:52.792368
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    class MockAnsibleModule:
        def __init__(self):
            self.params = {}

    module = MockAnsibleModule()
    facts = ansible_facts(module)

    assert type(facts) == dict
    assert len(facts) > 3
    for key in facts:
        assert type(key) in [str, unicode]
        assert 'ansible_' not in key
        assert type(facts[key]) in [int, str, unicode, list, dict, bool]

# Generated at 2022-06-11 02:15:04.977982
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts import lsb_collector
    import tempfile

    my_tempdir = tempfile.mkdtemp()
    test_file = my_tempdir + "/testfile"

    # Create a collector that just has a single fact called "test_fact"
    class TestFactCollector(BaseFactCollector):
        name = 'testfact'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            fact_value = "Test fact for unittests"

# Generated at 2022-06-11 02:15:06.010428
# Unit test for function ansible_facts
def test_ansible_facts():
    raise NotImplementedError()

# Generated at 2022-06-11 02:15:16.942235
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest
    import ansible.module_utils.facts.collector.network as network
    import ansible.module_utils.facts.collector.platform as platform
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils._text import to_text

    # monkey patch for ansible_collector.get_ansible_collector
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    collector_cache = {}
    all_collectors = [network.NetworkCollector,
                      platform.PlatformCollector]


# Generated at 2022-06-11 02:15:27.050314
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import FactsCollector

    # Make a mock module with a gather_subset param
    class mock_module:
        params = {}

    mod = mock_module()
    mod.params['gather_subset'] = ['all']
    mod.params['gather_timeout'] = 10

    # Create a mock collector plugin, with dummy collect() method
    class mock_collector_plugin:
        def collect(self, module):
            return {'a': 1, 'b': 2}

    # Have that plugin return the mock fact collector

# Generated at 2022-06-11 02:15:31.381523
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    import pytest
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all']),
                                          'gather_timeout': dict(type='int', default=10),
                                          'filter': dict(type='str', default='*')
                                          })
    result = ansible_facts(module)
    print(result)

    assert isinstance(result, dict) == True
    assert isinstance(result['distribution'], dict) == True
    assert isinstance(result['distribution']['distribution'], str) == True
    assert result['distribution']['distribution'] == 'RedHat'

# Generated at 2022-06-11 02:15:36.992856
# Unit test for function ansible_facts
def test_ansible_facts():
    # Mock out an AnsibleModule
    class FakeModule:
        def __init__(self):
            self.params = {}

        def fail_json(self, msg):
            print(msg)
            raise Exception('Module failed')

        def exit_json(self, dict_or_facts, **kwargs):
            print(str(dict_or_facts))

    # Create test module
    fake_module = FakeModule()

    # Get facts
    ansible_facts(fake_module)

# Generated at 2022-06-11 02:15:50.216984
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import collector

    # Mock an ansible module
    class Module(object):
        def __init__(self, gather_subset):
            self.params = dict()
            self.params['gather_subset'] = gather_subset

    # Mock a fact
    class TestFact(collector.BaseFactCollector):
        name = 'test'
        _fact_namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

        def collect(self, module=None, collected_facts=None):
            return dict(test_fact=1234)

    # Install the test fact
    collector.all_collectors += (TestFact,)

    assert get_all_facts(Module(['all'])).get('test_fact') == 1234

# Generated at 2022-06-11 02:15:50.924025
# Unit test for function ansible_facts
def test_ansible_facts():
    # TODO: write unit tests
    pass

# Generated at 2022-06-11 02:16:07.146483
# Unit test for function ansible_facts

# Generated at 2022-06-11 02:16:18.023417
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeAnsibleModule(object):
        class FakeParams(object):
            def get(self, key, default=None):
                if key == 'filter':
                    return 'ansible_os_family'
                return default
        params = FakeParams()

        def __init__(self):
            self.exit_json = lambda **kwargs: None
            self.fail_json = lambda **kwargs: None

    try:
        from ansible.modules.system import setup
    except ImportError:
        # ansible < 2.3
        module = FakeAnsibleModule()
        assert ansible_facts(module, ['network']) == {'os_family': 'RedHat'}
    else:
        # ansible 2.3+
        module = setup.SetupModule()

# Generated at 2022-06-11 02:16:29.201968
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector

    # Fixture
    class NetworkCollector_fixture(NetworkCollector):
        def collect(self, module=None, collected_facts=None):
            pass

    # Setup
    all_collector_classes = {'network': [('NetworkCollector_fixture', NetworkCollector_fixture)]}

    gather_subset = ['network']
    gather_timeout = 10
    filter_spec = '*'

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    # Exercise

# Generated at 2022-06-11 02:16:35.027324
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import TestModule
    # This test is meant to be run with ansible-test which sets up a working
    # Ansible environment.
    module = TestModule(params=dict(
        gather_subset=['all'],
        filter='ansible_default_ipv4',
        gather_timeout=10
    ))
    result = ansible_facts(module)
    assert 'default_ipv4' in result



# Generated at 2022-06-11 02:16:46.366552
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.network as network
    import ansible.module_utils.facts.virtual as virtual
    import ansible.module_utils.facts.system as system
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Mock class for AnsibleModule
    class AnsibleModule(object):
        def __init__(self):
            self.params = {
                'filter': '*',
                'gather_subset': ['all']
            }

    module = AnsibleModule()
    facts = get_all_facts(module)
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-11 02:16:57.492453
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import get_collector_for

    import ansible.module_utils.connection as connection_loader
    import ansible.module_utils.facts.collector.system as system_collector
    import ansible.module_utils.facts.collector.networking as networking_collector
    import ansible.module_utils.facts.collector.pkg_mgr as pkg_mgr_collector

    from ansible.modules.system import setup

    import os
    import datetime
    from time import time
    import subprocess
    from os.path import normpath
    from distutils.version import StrictVersion
    from mock import patch, call, Mock, MagicMock, DEFAULT
    from nose.plugins.skip import SkipTest

   

# Generated at 2022-06-11 02:16:58.606611
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest

    # TODO



# Generated at 2022-06-11 02:17:08.290211
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.basic import AnsibleModule
    import json
    import os

    module_name = os.path.splitext(os.path.basename(__file__))[0]
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['all'])
        ),
        supports_check_mode=True
    )
    ansible_facts_result = ansible_facts(module)
    # Make a Facts() object and collect facts, with the same gather_subset
    # and gather_timeout options

# Generated at 2022-06-11 02:17:17.994614
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for get_all_facts'''

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts.cache as cache

    cache.FACT_CACHE = {}

    class MockAnsibleModule():
        '''Class to represent 2.3/2.4 AnsibleModule

        implements params as a mock param dict'''
        def __init__(self):
            self.params = {}
        def get_option(self, key):
            return self.params.get(key)

    module = MockAnsibleModule()

    module.params['gather_subset'] = None

    fact_dict = get_all_facts(module)

    assert isinstance(fact_dict, dict)

    # verify namespace prefix added to key names
    assert fact

# Generated at 2022-06-11 02:17:29.742367
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class_names
    prev_collect_only = namespace.COLLECT_ONLY
    prev_minimal_gather_subset = namespace.MINIMAL_GATHER_SUBSET
    prev_collector_classes = namespace.ALL_COLLECTOR_CLASSES
    prev_namespace = namespace.NAMESPACES


# Generated at 2022-06-11 02:17:51.093406
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    # so the ansible_facts function doesn't error out
    module.params['gather_subset'] = frozenset(['all'])

    facts_dict = ansible_facts(module)

    assert isinstance(facts_dict, dict)
    assert len(facts_dict.keys()) > 0

# Generated at 2022-06-11 02:18:02.074085
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import MutableMapping
    import os
    import pytest
    import sys
    import types

    class AnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

    module = AnsibleModule(gather_subset=['all'])
    results = ansible_facts(module)


# Generated at 2022-06-11 02:18:05.937394
# Unit test for function ansible_facts
def test_ansible_facts():
    # No AnsibleModule mock object provided
    # Just check that this function can be invoked
    ansible_facts(module=None)


if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-11 02:18:16.264323
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system

    saved_callback_facts = ansible.module_utils.facts.collector.callback_facts

# Generated at 2022-06-11 02:18:27.704502
# Unit test for function get_all_facts
def test_get_all_facts():
    import json
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.facts import AnsibleModule
    class MockModule(MutableMapping):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.__dict__.update(kwargs)

        def __getitem__(self, key):
            return self.params[key]

        def __setitem__(self, key, value):
            self.params[key] = value

        def __delitem__(self, key):
            del self.params[key]

        def __iter__(self):
            return iter(self.params)

        def __len__(self):
            return len(self.params)


# Generated at 2022-06-11 02:18:33.724205
# Unit test for function get_all_facts
def test_get_all_facts():
    module = AnsibleModule(argument_spec={
        'gather_subset': {'type': 'list', 'default': ['all']},
        'gather_timeout': {'type': 'int', 'default': 10},
    })
    all_facts = get_all_facts(module=module)
    facts = ansible_facts(module=module)
    assert all_facts == facts

# Generated at 2022-06-11 02:18:41.773226
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest
    from ansible.modules.system import setup

    module = setup.AnsibleModule(argument_spec=dict(
        ansible_facts=dict(required=True, type='dict'),
        gather_subset=dict(required=False, type='list')
    ))
    module.params = dict(ansible_facts={'a': 'b'}, gather_subset=['node'])

    with pytest.raises(NotImplementedError):
        ansible_facts(module)

# Generated at 2022-06-11 02:18:52.832006
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Function should return a default set of facts named after their bare factname '''
    from ansible.module_utils._text import to_text

    class MyModule(object):
        def __init__(self, gather_subset='all', pk_mgr=None):
            self.params = {'gather_subset': gather_subset, 'filter': '*', 'pkg_mgr': pk_mgr}

    module_all = MyModule()
    module_minimal = MyModule(gather_subset=['min'])
    module_fips = MyModule(gather_subset=['fips'])
    module_min_fips = MyModule(gather_subset=['fips', 'min'])

# Generated at 2022-06-11 02:18:59.489045
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={
            'gather_subset': {'type': 'list', 'default': ['all']}
        })
    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert 'default_ipv4' in facts

# Generated at 2022-06-11 02:19:10.607829
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit test for ansible_facts.
    This unit tests should be run under ansible source code base directory.
    Example:
    $ python -m ansible.module_utils.facts.ansible_facts_unit_test
    '''

    import unittest
    import os
    import sys
    import importlib
    import yaml
    # ansible 2.3 required below
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    class MockAnsibleModule:
        def __init__(self, params=None, check_mode=True):
            self.params = params
            self.check_mode = check_mode

        def fail_json(self, msg):
            self.exit_args = msg
            self.exited

# Generated at 2022-06-11 02:19:45.210214
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule:
        params = {}

    fake_module = FakeModule()

    ansible_facts = ansible_facts(fake_module)
    assert type(ansible_facts) == dict

    assert 'ansible_distribution' in ansible_facts
    assert 'ansible_distribution_version' in ansible_facts
    assert 'ansible_architecture' in ansible_facts

# Generated at 2022-06-11 02:19:58.123970
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    from ansible.module_utils.basic import AnsibleModule

    if sys.version_info[0] >= 3:
        # mock_module is an instance of MagicMock
        # mock_module.params is an instance of MagicMock
        # mock_module.params.get() returns a MagicMock
        # MagicMock's side_effect is a function, not a list.
        mock_module = AnsibleModule(argument_spec={'gather_subset': {'required': False}})
        mock_module.params.get.side_effect = lambda arg, default: arg

# Generated at 2022-06-11 02:20:00.093886
# Unit test for function ansible_facts
def test_ansible_facts():
    module = MockAnsibleModule()
    assert isinstance(ansible_facts(module), dict)


# Generated at 2022-06-11 02:20:05.538276
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import json

    def get_ansible_facts(module):
        facts = ansible_facts(module=module)
        return dict((k, facts[k]) for k in ['os', 'platform'])

    module = AnsibleModule(
        argument_spec=dict(
        ),
    )

    os_facts = get_ansible_facts(module)

    json.dump(sys.stdout, os_facts)

# Generated at 2022-06-11 02:20:15.607347
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys
    import json
    import pytest
    from mock import MagicMock

    with pytest.raises(Exception):
        get_all_facts(None)

    with pytest.raises(Exception) as excinfo:
        class o:
            pass
        module = o()
        get_all_facts(module)
    excinfo.match('module does not have a gather_subset argument')

    class o:
        gather_subset = ['all']
    module = o()

    allfacts = ansible_facts(module)
    assert 'ansible_os_family' in allfacts
    assert allfacts['ansible_os_family'] != ''



# Generated at 2022-06-11 02:20:24.437081
# Unit test for function get_all_facts
def test_get_all_facts():
    from unittest import TestCase
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class Test(TestCase):
        def test_get_all_facts(self):
            import os
            import re
            import sys
            import time
            import pytest

            sys.path.append(os.path.join(os.path.dirname(__file__), os.path.pardir))
            from ansible.module_utils.facts import module

            # ansible < 2.3

# Generated at 2022-06-11 02:20:35.739791
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts.network.base import NetworkCollector

    class BaseNetworkCollector(NetworkCollector):

        def populate(self):
            return {'hello': 'world'}

    class FakeAnsibleModule:
        def __init__(self, params, gather_subset=None):
            self.params = params
            self.gather_subset = gather_subset

    params = {'gather_subset': ['network'],
              'filter': 'ansible_default_ipv4'}

    module = FakeAnsibleModule(params)

    facts = ansible_facts(module)
    assert facts['default_ipv4']['hello'] == 'world'

# Generated at 2022-06-11 02:20:44.795299
# Unit test for function ansible_facts
def test_ansible_facts():

    try:
        from ansible.module_utils.facts import legacy_ansible_facts as legacy_ansible_facts_module
        legacy_ansible_facts = legacy_ansible_facts_module.ansible_facts
    except ImportError:
        legacy_ansible_facts = None

    assert ansible_facts == legacy_ansible_facts

    # In case future versions of module_utils.facts.ansible_facts have extra keyword args,
    # allow for that by accepting **kwargs

    # Assert that ansible_facts accepts **kwargs (partial backwards compat with future versions)
    try:
        ansible_facts(module='unused', foo='bar', baz='qux')
    except TypeError:
        raise

    class MockModule(object):
        '''Fake AnsibleModule Class'''


# Generated at 2022-06-11 02:20:47.178132
# Unit test for function ansible_facts
def test_ansible_facts():

    # stubbed module
    module = type('FakeAnsibleModule', (object,), {'params': {'gather_subset': ['all']}})
    facts_dict = ansible_facts(module)
    assert 'machine_id' in facts_dict

# Generated at 2022-06-11 02:20:51.071918
# Unit test for function ansible_facts
def test_ansible_facts():
    module = {'params': {'filter': '*', 'gather_subset': ['all'], 'gather_timeout': 10}}
    facts = ansible_facts(module)
    assert facts.get('lsb') is not None, \
        "Failed to lookup all facts. Missing 'lsb' fact"