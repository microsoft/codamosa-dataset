

# Generated at 2022-06-11 02:11:40.778949
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_all_facts

    # ensure module_utils.facts.get_all_facts is implemented as function ansible_facts
    assert get_all_facts == ansible_facts

# Generated at 2022-06-11 02:11:42.422223
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts


# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 02:11:49.244707
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    from ansible.module_utils import basic
    from ansible.module_utils.facts.facts import Facts

    module = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all', 'network']),
        ),
    )

    module.ansible_facts = Facts()

    fact_dict = ansible_facts(module=module)

    assert fact_dict is module.ansible_facts.get_all_facts(module=module)

# Generated at 2022-06-11 02:11:53.771284
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import timeout

    start = timeout.monotonic()
    with timeout.timeout(1.0, exception_message='1.0 seconds no more!'):
        ansible_facts({})
    end = timeout.monotonic()
    print(end-start)

# Generated at 2022-06-11 02:12:04.669736
# Unit test for function get_all_facts
def test_get_all_facts():
    # Simple test for get_all_facts
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.utils import get_file_content

    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['all'], type='list')})

    gather_subset = module.params['gather_subset']
    module.warn = lambda *args, **kwargs: None
   

# Generated at 2022-06-11 02:12:09.968600
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    module_args = dict()
    module = AnsibleModule(argument_spec=module_args)

    facts_dict = ansible_facts(module=module)

    assert 'distribution' in facts_dict
    assert 'distribution_version' in facts_dict
    assert 'distribution_major_version' in facts_dict

# Generated at 2022-06-11 02:12:20.142223
# Unit test for function ansible_facts
def test_ansible_facts():

    try:
        from ansible.module_utils.facts import default_collectors
    except ImportError:
        # ansible 2.0
        class SubsetValues(dict):
            def __init__(self, gathered_subset):

                super(SubsetValues, self).__init__()

                self['_ansible_facts_gathered_subset'] = gathered_subset

                self['ansible_facts'] = {}

                self['ansible_facts']['lsb'] = {'codename': 'trusty', 'description': 'Ubuntu 14.04.1 LTS', 'id': 'Ubuntu', 'major_release': '14', 'release': '14.04'}
                self['ansible_facts']['distribution'] = 'Ubuntu'
                self['ansible_facts']['distribution_version']

# Generated at 2022-06-11 02:12:32.074217
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import mocker
    import os
    import tempfile
    import shutil
    import sys

    # we need to mock module interface so that we don't call out to the system
    # to actually gather facts.
    mocker.patch("ansible.module_utils.facts.ansible_collector.AnsibleModule", spec=True)
    mocker.patch("ansible.module_utils.facts.ansible_collector.AnsibleFactCollector", spec=True)

# Generated at 2022-06-11 02:12:43.685215
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    if sys.version_info.major >=3:
        from unittest.mock import patch
    else:
        from mock import patch
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_collector

    # Setup AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Setup mock for ansible_collector.get_ansible_collector
    ax = ansible_collector.AnsibleCollector(gather_subset=['all'],
                                            gather_timeout=10,
                                            namespace=PrefixFactNamespace(namespace_name='ansible', prefix=''),
                                            filter_spec='*')
    mock_ans

# Generated at 2022-06-11 02:12:55.866342
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.facts.ansible_default_collectors as default_collectors

    class MockAnsibleModule():
        params = {'gather_subset': ['all']}

    module = MockAnsibleModule()

    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'


# Generated at 2022-06-11 02:13:08.829688
# Unit test for function ansible_facts
def test_ansible_facts():
    # Note: using MockAnsibleModule requires the collection being tested to be
    # loaded in the import path under the correct collection name
    from ansible.module_utils.facts.mycollection.mymodule import MockAnsibleModule
    from ansible.module_utils.facts.mycollection.mymodule.facts.mycollector import MyCollector

    # Use a filter of '*' to ensure we collect data from all collectors
    module_args = {
        'gather_subset': ['!all', 'mycollector'],
        'gather_timeout': 10,
        'filter': '*',
    }

    module = MockAnsibleModule(**module_args)
    _fact_collector_cls = MyCollector
    # Call ansible_facts API, which by default will collect data from all collectors
    # Note that we

# Generated at 2022-06-11 02:13:18.043056
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.basic import AnsibleModule

    FAKE_MODULE_PATH = 'ansible.module_utils.network.common.network_template'

    class FakeNetworkModule(AnsibleModule):
        def __init__(self):
            super(FakeNetworkModule, self).__init__(argument_spec={},
                                                    supports_check_mode=True,
                                                    add_file_common_args=False)

        def _load_params(self):
            pass

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            pass

        def load_platform_subclass(self, category, attr_class, *args, **kwargs):
            pass


# Generated at 2022-06-11 02:13:27.768040
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    try:
        from ansible.modules.system import setup
    except ImportError:
        from ansible.modules.system import get_distribution as setup

    module = setup.AnsibleModule(argument_spec={})

    facts_dict = ansible_facts(module)

    assert 'ansible_distribution' in facts_dict
    assert isinstance(facts_dict['ansible_distribution'], to_bytes)
    if 'distribution' in facts_dict:
        # make sure they are the same
        assert facts_dict['ansible_distribution'] == facts_dict['distribution']

# Generated at 2022-06-11 02:13:38.506274
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts import ansible_collector

    # A 'mock' AnsibleModule class
    class AnsibleModuleFake:
        def __init__(self, params=None):
            if params is None:
                params = {}
            self.params = params

    # A 'mock' Ansible FactCollector class, only collect_from_* methods mocked.
    # I.E. no corresponding 'real' ansible_collector.Collector class
    class CollectorFake:
        def __init__(self, all_collector_classes, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            pass


# Generated at 2022-06-11 02:13:50.895520
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    class MockAnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

        def fail_json(self, *args, **kwargs):
            raise Exception('module fail_json called')

    class MockDistributionFactCollector(DistributionFactCollector):
        def __init__(self):
            self.collector_name = 'distribution'
            self.distribution = 'osx'
            self.version = '10.11.4'
            self.codename = 'osx_codename'
            self.id = 'osx_id'


# Generated at 2022-06-11 02:14:02.297029
# Unit test for function ansible_facts
def test_ansible_facts():
    def run_module(module):
        module.exit_json = module.run_command
        module.run_command = lambda *args, **kwargs: (0, '', '')
        arguments = module.params
        fact_collector = ansible_facts(module)
        facts_dict = fact_collector.collect(module=module)
        return facts_dict

    class AnsibleModule:
        def __init__(self, params):
            self.params = params
            self.run_command = None
            self.exit_json = None

        def __call__(self, *args, **kwargs):
            # create a dummy module to mock __call__
            return self

    params = {'filter': '*'}
    module = AnsibleModule(params=params)

# Generated at 2022-06-11 02:14:05.621385
# Unit test for function get_all_facts
def test_get_all_facts():
    module = MockModule()
    all_facts = get_all_facts(module)
    facts = all_facts['ansible_facts']()
    assert 'ansible_distribution' in facts


# Generated at 2022-06-11 02:14:16.276938
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import NamespaceCollector

    class fake_collector(NamespaceCollector):
        def __init__(self, namespace=None, filter_spec=None, gather_subset=None, gather_timeout=None, minimal_gather_subset=None):
            self._fake_facts = {}

        def collect(self, module=None):
            return self._fake_facts

    class fake_ansible_module():
        def __init__(self, param_dict=None):
            param_dict = param_dict or {}
            self.params = param_dict

    # no params, everything defaults
    m = fake_ansible_module()
    a = ansible_facts(m)
    assert isinstance(a, dict)

    m = fake_ansible_module()
   

# Generated at 2022-06-11 02:14:24.842408
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    # Test calling ansible_facts with no params
    # The module instance is created with no params, so it will
    # default to module.params = dict()
    # Expects that the gather_subset='all' and gather_timeout=10
    # is set by module_utils.facts

    mock_module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    ansible_facts_dict = ansible_facts(module=mock_module)
    assert ansible_facts_dict
    assert isinstance(ansible_facts_dict, dict)

# Generated at 2022-06-11 02:14:34.048427
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        from ansible.module_utils.facts import ansible_facts
    except Exception:
        # older ansible version compat
        from ansible.module_utils.facts import ansible_collector

    class AnsiModule(object):
        def __init__(self):
            self.params = dict(gather_subset=['min', 'hardware'],
                               gather_timeout=5,
                               filter='ansible_.*')

    ansi_m = AnsiModule()
    ansi_facts_dict = ansible_facts(ansi_m)
    facts_dict_keys = list(ansi_facts_dict.keys())
    facts_dict_keys.sort()
    assert facts_dict_keys == ['distribution',
                               'python'], "ansible_facts did not collect subset"

   

# Generated at 2022-06-11 02:14:42.122687
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    module_args = dict(gather_subset='!non-existent', gather_timeout=1)
    module = AnsibleModule(argument_spec=module_args)
    all_facts = get_all_facts(module)
    assert 'date_time' in all_facts


# Generated at 2022-06-11 02:14:49.267059
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes

    from mock import MagicMock, patch, call
    class MockModule:
        def __init__(self):
            self.params = {'gather_subset': ['all'],
                           'gather_timeout': 10,
                           'filter': '*'
                          }


# Generated at 2022-06-11 02:15:02.138862
# Unit test for function get_all_facts
def test_get_all_facts():
    import os
    import sys
    module_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
    module_path = os.path.join(module_path, 'lib')
    sys.path.append(module_path)

    from ansible.module_utils.facts.plugins.system.distribution import DistributionFactCollector

    module = 'os'
    os = __import__(module)
    os.path = __import__('%s.path' % module)
    module = __import__('%s.path' % module)
    module.path = os.path
    module.path.exists = os.path.exists
    module.path.isdir = os.path.isdir
   

# Generated at 2022-06-11 02:15:10.711828
# Unit test for function ansible_facts
def test_ansible_facts():

    import sys
    import os

    sys.path.append(os.path.join(os.path.dirname(__file__), '../../'))
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors

    class DummyModule(object):
        def __init__(self):
            self.params = {}

    module = DummyModule()

    def test_get_all_facts(module):
        return ansible_facts(module)

    def test_get_distribution_facts(module):
        return ansible_facts(module, gather_subset='distribution')

    def test_get_minimal_facts(module):
        return ansible_facts(module, gather_subset='minimal')


# Generated at 2022-06-11 02:15:20.996806
# Unit test for function get_all_facts
def test_get_all_facts():
    class AnsibleModule(object):
        def __init__(self, gather_subset):
            self.params = {
                'gather_subset': gather_subset,
            }
    all_facts = get_all_facts(AnsibleModule(gather_subset=['all']))
    assert isinstance(all_facts, dict)
    assert len(all_facts) > 0

    all_facts = get_all_facts(AnsibleModule(gather_subset=['!all', 'network']))
    assert isinstance(all_facts, dict)
    assert len(all_facts) > 0

    all_facts = get_all_facts(AnsibleModule(gather_subset=['!all', 'network']))
    assert isinstance(all_facts, dict)

# Generated at 2022-06-11 02:15:32.678600
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import shelve

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ModuleDepFactsCollector
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.facts import default_collectors

    # Patch the shelve.open() call to use in memory db, to avoid leaving behind any artifacts
    # on the filesystem
    original_open = shelve.open

    def in_memory_open(file_name, flag='c', protocol=None, writeback=False):
        return original_open('/dev/null', flag, protocol, writeback)

    shelve.open = in_memory_open

    # Mock the environment, to avoid getting

# Generated at 2022-06-11 02:15:34.648257
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-11 02:15:46.972659
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test ansible_facts function with fake ansible module
    '''

    class FakeAnsibleModule(object):
        '''Fake AnsibleModule class
        '''
        def __init__(self):
            self.params = {'filter':'*',
                           'gather_subset': ['all'],
                           'gather_timeout': 10}

    fake_ansible_module = FakeAnsibleModule()

    facts_dict = ansible_facts(fake_ansible_module)

    # Ansible fact facts_dict always contains 'ansible_facts' key
    assert 'ansible_facts' in facts_dict
    assert isinstance(facts_dict['ansible_facts'], dict)

# Generated at 2022-06-11 02:15:56.236005
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import FACT_CACHE

    FACT_CACHE.clear()
    assert ansible_facts({}) == {}
    assert ansible_facts({}, 'all') == {}
    assert ansible_facts({}, gather_subset=['all']) == {}
    assert ansible_facts({}, gather_timeout=1) == {}
    assert ansible_facts({}, gather_timeout=42) == {}
    assert ansible_facts({}, filter='*') == {}
    assert ansible_facts({}, filter='platform,distribution') == {}
    assert ansible_facts({}) == ansible_facts({})

# Generated at 2022-06-11 02:16:06.042327
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts import callbacks as callback_module
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils.facts.namespace import ExtensionFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import AggregateFactNamespace

    # Mock class for FactCollector
    class MockFactCollector(FactCollector):
        def __init__(self):
            self.collect_called = False

        def collect(self, module):
            self.collect_called = True
            self

# Generated at 2022-06-11 02:16:20.777824
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit test function for function ansible_facts in module_utils/facts.py
    '''

    import datetime
    import shutil
    import tempfile
    import unittest

    class TestAnsibleModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'all', 'filter': '*'}

    class TestFacts(unittest.TestCase):
        def test_ansible_facts(self):
            test_module = TestAnsibleModule()

# Generated at 2022-06-11 02:16:30.574959
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts

    ansible_facts should be usable without instantiating an AnsibleModule.
    Just create a MockModule and pass it in.
    '''

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector.network import NetworkCollector

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.util import get_file_content

    from ansible.module_utils.facts.collector.base import BaseFactCollector

    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.facts.collector.kernel import KernelFactCollector

    # mock the methods we call
    original_get_file_content = get_file_content

# Generated at 2022-06-11 02:16:34.036570
# Unit test for function ansible_facts
def test_ansible_facts():
    module = FakeModule(gather_subset=None, gather_timeout=10)
    facts_dict = ansible_facts(module)

    assert facts_dict["distribution"] == "NoDistro"
    assert facts_dict["distribution_release"] == "NoDistroRelease"

# Generated at 2022-06-11 02:16:45.276111
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import Mock

    mock_module = Mock()
    mock_module.params = {
        'gather_subset': None,
        'gather_timeout': 10,
        'filter': '*'
    }

    mock_all_collector_classes = [Mock(), Mock(), Mock(), Mock(), Mock()]
    mock_all_collector_classes[0].get_mock_name.return_value = 'TestCollector'
    mock_all_collector_classes[0].collect.return_value = {'Test1': 'test1'}

    mock_all_collector_classes[1].get_mock_name.return_value = 'ANOTHERTestCollector'
    mock_all_collector

# Generated at 2022-06-11 02:16:56.523620
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    ansible_collector.get_distribution_version = lambda: '9'  # OS X

    module = ansible.module_utils.facts.collector.AnsibleModule(
        argument_spec=dict(gather_subset=dict(type='list', default=['all'], elements='str')),
        supports_check_mode=False,
    )
    module.exit_json = lambda **kwargs: kwargs


# Generated at 2022-06-11 02:17:06.821045
# Unit test for function ansible_facts
def test_ansible_facts():
    class AnsibleModule:
        def __init__(self, **kwargs):
            self.params = {}
            self.params.update(kwargs)

    # Arrange
    am = AnsibleModule(filter='blah', gather_timeout=10000)
    gather_subset_list = ['all']
    expected_facts = {
        'distribution': 'RedHat',
        'distribution_file_parsers': ['RedHat'],
        'distribution_major_version': '7.2',
        'distribution_release': 'Core',
        'distribution_version': '7.2',
        'system': 'Linux'
    }

    # Act
    facts = ansible_facts(module=am, gather_subset=gather_subset_list)

    # Assert

# Generated at 2022-06-11 02:17:07.343187
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-11 02:17:09.655157
# Unit test for function ansible_facts
def test_ansible_facts():
    module = DummyAnsibleModule()
    subset_and_timeout = ansible_facts(module=module)
    assert subset_and_timeout == DummyAnsibleModule.FACTS



# Generated at 2022-06-11 02:17:11.743490
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    # TODO: Add unit tests for ansible_facts
    pass

# Generated at 2022-06-11 02:17:23.608789
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import ansible_version as facts_ansible_version
    ansible_version = facts_ansible_version()

    def test_module(params):
        class TestModule(object):
            def __init__(self, params):
                self.params = params

            def fail_json(self, msg):
                raise Exception(msg)

        return TestModule(params)

    # call ansible_facts without gather_subset
    test_params = dict(gather_subset=None,
                       gather_timeout=1,
                       filter='ansible_*')

# Generated at 2022-06-11 02:17:48.467871
# Unit test for function ansible_facts
def test_ansible_facts():
    test_module = MockAnsibleModule(params={'filter': '*', 'gather_subset': ['all']})
    facts = ansible_facts(module=test_module)

    # assert that 'ao' namespace gets collected
    assert facts['ao_var'] == 'ao_var_value'

    # assert that 'ansible_' namespace gets collected
    assert facts['ansible_var'] == 'ansible_var_value'

    # assert that 'ansible_' prefix was stripped off
    assert facts['ansible_var'] == 'ansible_var_value'
    assert facts['var'] == 'var_value'

    # assert that 'ansible_local' namespace gets collected
    assert facts['local_var'] == 'local_var'

    # assert that 'ansible_' prefix was stripped off

# Generated at 2022-06-11 02:17:53.998515
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts as facts

    class FakeModule:
        def __init__(self, args):
            self.params = args

    fake_args = dict(
        gather_subset=None,
        gather_timeout=30,
        filter='*',
    )
    module = FakeModule(fake_args)
    facts_dict = ansible_facts(module)
    assert facts_dict.get('python') == facts.python_version()

# Generated at 2022-06-11 02:18:03.819678
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.utils import get_all_facts

# Generated at 2022-06-11 02:18:06.518700
# Unit test for function ansible_facts
def test_ansible_facts():
    # This is here because the test will fail because
    # the import will fail with no test function defined
    # Unused argument here, pylint: disable=unused-argument
    pass

# Generated at 2022-06-11 02:18:10.353326
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):
        def __init__(self):
            pass

    module = FakeModule()
    module.params = {'gather_subset': 'all'}
    fact_dict = get_all_facts(module)
    # Check for truthness
    assert fact_dict

# Generated at 2022-06-11 02:18:21.946839
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.facts import FACT_CACHE_FILE
    from ansible.module_utils.facts.facts import _cache_data_for_platform
    from ansible.module_utils.facts.facts import _cache_data_for_collector
    from ansible.module_utils.facts.facts import _get_platform_cache_data
    from ansible.module_utils.facts.facts import get_file_content
    import ansible.module_utils.facts.network.base as network_base

    import os
    import tempfile
    import stat
    import json

    try:
        os.remove(FACT_CACHE_FILE)
    except OSError:
        pass


# Generated at 2022-06-11 02:18:31.722082
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import pytest
    from unittest.mock import Mock

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'testcollector'

#        test_fact = 'test'
        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test'}

    # Add this to the global namespace for compat reasons
    TestCollector.add_to_class()

    gather_subset = ['testcollector']
    gather_timeout = 10
    filter_spec = '*'

    ansible_module = Mock()
    ansible_module.params = {}

# Generated at 2022-06-11 02:18:42.301985
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils import basic

    class TestModule(basic.AnsibleModule):
        ''' fake AnsibleModule class, holding the module params, hooking up the fact collector'''
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return ''

    module = TestModule()

    gather_subset = module.params['gather_subset']

   

# Generated at 2022-06-11 02:18:53.367833
# Unit test for function ansible_facts
def test_ansible_facts():
    import mock
    test_module = mock.Mock()
    test_module.params = dict(filter='*')
    dict_facts = ansible_facts(module=test_module)

    assert(dict_facts.get('fqdn') is not None)
    assert(dict_facts.get('ansible_fqdn') is not None)
    assert(dict_facts.get('ansible_os_family') is not None)
    assert(dict_facts.get('ansible_pkg_mgr') is not None)
    assert(dict_facts.get('ansible_distribution') is not None)
    assert(dict_facts.get('ansible_distribution_release') is not None)
    assert(dict_facts.get('ansible_distribution_major_version') is not None)

# Generated at 2022-06-11 02:19:06.469256
# Unit test for function ansible_facts
def test_ansible_facts():
    """Tests the ansible_facts function by mock-ing the required methods of
    AnsibleModule, which is the intended behavior.

    """
    from ansible.module_utils.facts import default_collectors

    class TestModule(object):
        params = dict()

        def __init__(self, gather_subset=None, gather_timeout=None, filter=None):
            self.params = dict(gather_subset=gather_subset,
                               gather_timeout=gather_timeout,
                               filter=filter)

        def exit_json(self, ansible_facts_dict=None):
            self.successful_exit = True
            self.facts = ansible_facts_dict
            return

        def fail_json(self, msg=None):
            self.successful_exit = False
            return

    test_

# Generated at 2022-06-11 02:19:48.540548
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.basic
    # test fixture.  This is normally done by ansible.module_utils.facts.ansible_facts
    # which AnsibleModule calls to initialize the facts module.
    ansible.module_utils.facts.system_info = {}

    from ansible.module_utils.facts.collector import get_collector_class

    # Covert the value of ansible.module_utils.facts.default_collectors.collectors
    # to a mapping of {collector_name: CollectorClass}

    collector_classes = {}
    for collector_info in default_collectors.collectors:
        if isinstance(collector_info, (tuple, list)):
            collector_name, collector_class = collector_info
        else:
            collector_name = collector_info.__name__
            collector

# Generated at 2022-06-11 02:20:01.541787
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_file_content
    import os

    class FakeModule(object):
        '''the methods of this class are used by the ansible_facts() function.

        This class is not intended to be instantiated.
        '''

        def __init__(self):
            self.params = {
                'filter': '*',
                'gather_subset': ['all'],
                'gather_timeout': 10
            }

        def get_bin_path(self, executable, required=True, opt_dirs=[]):
            '''stub method for running unit test.

            Return value should be path of executable.
            Raise Exception on error
            '''
            raise Exception("This method is only for unit testing")


# Generated at 2022-06-11 02:20:12.009898
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    sys.modules['ansible'] = mock.Mock()

    # import ansible.module_utils.facts.ansible_collector as collector
    # imp.reload(collector)

    from ansible.module_utils.facts.ansible_collector import BaseFactCollector
    from ansible.module_utils.facts.ansible_collector import AnsibleCollector

    module = mock.Mock()
    module.params = {}

    from ansible.module_utils.facts import ansible_facts

    facts = ansible_facts(module)
    assert set(facts.keys()) == AnsibleCollector.all_collectors
    assert set(facts.keys()).issuperset(BaseFactCollector.required_collectors)


# Generated at 2022-06-11 02:20:20.996164
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={'gather_subset': {'type': 'list', 'default': ['all']},
                                                'gather_timeout': {'type': 'int', 'default': 10},
                                                'filter': {'type': 'str', 'default': '*'}},
                                 check_invalid_arguments=False)
    facts_dict = ansible_facts(module)
    print(facts_dict)


if __name__ == '__main__':
    import unittest
    import sys
    sys.exit(unittest.main())

# Generated at 2022-06-11 02:20:31.341815
# Unit test for function ansible_facts
def test_ansible_facts():
    # import module snippets
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['all'], type='list'),
            filter=dict(default='*', required=False),
        ),
        supports_check_mode=True
    )

    result = ansible_facts(module)
    assert result is not None
    assert 'default_ipv4' in result

    # test gather_subset arg
    result = ansible_facts(module, gather_subset=['!all', 'network'])
    assert result is not None
    assert 'default_ipv4' in result

# Generated at 2022-06-11 02:20:39.641275
# Unit test for function ansible_facts
def test_ansible_facts():
    # make mock AnsibleModule
    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = dict()
        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return None

    am = AnsibleModuleMock()
    am.params['filter'] = 'distribution'
    am.params['gather_subset'] = 'network'

    result = ansible_facts(am)
    assert isinstance(result, dict)
    assert 'distribution' in result
    assert result['distribution'] == 'unknown'


# Generated at 2022-06-11 02:20:45.987667
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.interpreter
    module = ansible.module_utils.facts.interpreter.MyAnsibleModule(
        argument_spec={'gather_subset': {'type': 'list', 'default': ['all'], 'elements': 'str'}},
        bypass_checks=True
    )
    get_all_facts(module)

# Generated at 2022-06-11 02:20:47.147038
# Unit test for function ansible_facts
def test_ansible_facts():
    # TODO !!!
    pass

# Generated at 2022-06-11 02:20:54.724700
# Unit test for function ansible_facts
def test_ansible_facts():
    import tempfile
    import shutil

    import ansible.module_utils.facts.namespace as facts_namespace

    class TestModule(object):
        class Parameters(object):
            def __init__(self, default_file=None, gather_subset=None):
                self.gather_subset = gather_subset
                self.filter = 'ansible_all_ipv4_addresses'

        def __init__(self, params=Parameters()):
            self.params = params

    def test_get_all_facts(module):
        return ansible_facts(module)

    def get_builtin_facts(module):
        return dict(ansible_all_ipv4_addresses=['1.1.1.1', '2.2.2.2'])

    tmp = tempfile.mkd

# Generated at 2022-06-11 02:21:06.239616
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.core import AnsibleModule
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import copy
    import mock

    ansible_module_namespace = 'ansible.module_utils.facts'
    # create a mock module
    module = AnsibleModule(argument_spec={})

    # inject in the module namespace, so the module_util can find the mock module
    with mock.patch(ansible_module_namespace + '.core.AnsibleModule', spec=module, create=True):

        # create a mock module
        module = AnsibleModule(argument_spec={})

        # inject in the module namespace, so the module_util can find the mock module