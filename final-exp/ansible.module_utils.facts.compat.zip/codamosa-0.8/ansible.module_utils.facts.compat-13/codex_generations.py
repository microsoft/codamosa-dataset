

# Generated at 2022-06-11 02:11:50.846078
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import json
    import os
    tmpdir = os.path.join(os.path.dirname(__file__), '../unit/tmp')
    sys.path.append(tmpdir)

    from ansible.module_utils.basic import AnsibleModule

    class MockAnsibleModule(AnsibleModule):
        def __init__(self):
            super(MockAnsibleModule, self).__init__()
            self.params = {
                'gather_subset': ['all'],
                'gather_timeout': 10,
                'filter': '*'
            }

    module = MockAnsibleModule()
    facts = ansible_facts(module)
    assert facts is not None

# Generated at 2022-06-11 02:11:58.753313
# Unit test for function ansible_facts
def test_ansible_facts():
    module = None

    facts = {
        'default_ipv4': dict(address='10.0.0.1'),
        'default_ipv4.address': '10.0.0.1'
    }

    all_collector_classes = default_collectors.collectors
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    fact_collector = \
        ansible_collector.get_ansible_collector(all_collector_classes=all_collector_classes,
                                                namespace=namespace,
                                                filter_spec='*',
                                                gather_subset=['all'],
                                                gather_timeout=0)

    def mock_collect(module=None):
        return facts

    fact_collector.collect = mock_collect



# Generated at 2022-06-11 02:12:06.573203
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.ansible_facts
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector

    # Make sure static method `ansible_facts` works when called on this class
    res = ansible.module_utils.facts.ansible_facts.ansible_facts(None)
    assert isinstance(res, dict)

    # Make sure static method `ansible_facts` works when called on this module
    res = ansible_facts(None)
    assert isinstance(res, dict)

    # Make sure get_all_facts works
    res = ansible.module_utils.facts.ansible_facts.get_all_facts(None)
    assert isinstance(res, dict)

    # Make sure PrefixFactNamespace works
    prefix_

# Generated at 2022-06-11 02:12:16.808559
# Unit test for function ansible_facts

# Generated at 2022-06-11 02:12:24.067348
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from mock import MagicMock

    module = AnsibleModule({})
    mock_collector = MagicMock()
    mock_collector().collect.return_value = {'foo': 'bar'}

    ansible_collector.get_ansible_collector = MagicMock()
    ansible_collector.get_ansible_collector.return_value = mock_collector

    facts = ansible_facts(module)
    assert facts == {'foo': 'bar'}


# Generated at 2022-06-11 02:12:30.166354
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import module_utils
    class DummyModule(object):
        def __init__(self):
            self.params = { 'gather_subset':['all'] }

    module = DummyModule()
    res = module_utils.get_all_facts(module)
    assert isinstance(res, dict)

# Generated at 2022-06-11 02:12:33.357648
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import _cache
    assert get_all_facts(module=None) == _cache.get(timeout=10, gather_subset=['all'], filter_spec='*')


# Generated at 2022-06-11 02:12:45.073506
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.hardware.base
    import ansible.module_utils.facts.network.base

    class FakeHardwareCollector(ansible.module_utils.facts.hardware.base.BaseHardwareCollector):
        '''
        A fake hardware collector class for testing facts.ansible_facts()

        The test_hardware_collector class is defined immediately below
        '''

        NAME = 'hardware'
        PRIORITY = 0

        def __init__(self, *args, **kwargs):
            pass

        def collect(self, module, collected_facts):
            return {}


# Generated at 2022-06-11 02:12:51.999164
# Unit test for function ansible_facts
def test_ansible_facts():
    module = None
    gather_subset = ['all']
    actual_fact_dict = ansible_facts(module, gather_subset)
    assert isinstance(actual_fact_dict, dict)
    assert len(actual_fact_dict) > 0
    assert actual_fact_dict['distribution'] == 'Generic'
    assert actual_fact_dict['distribution_major_version'] == 'Generic'
    assert 'ansible_' not in actual_fact_dict

# Generated at 2022-06-11 02:13:00.882761
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts as facts
    import ansible.module_utils.facts.platform.linux as linux_facts
    import ansible.module_utils.facts.platform.netbsd as netbsd_facts
    import ansible.module_utils.facts.platform.openbsd as openbsd_facts
    import ansible.module_utils.facts.platform.sunos as sunos_facts
    import ansible.module_utils.facts.system.distribution as distribution_facts
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr_facts
    import ansible.module_utils.facts.system.service_mgr as service_mgr_facts
    import ansible.module_utils.facts.system.user as user_facts
    import ansible.module_utils.facts

# Generated at 2022-06-11 02:13:12.468435
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Example module for testing ansible_facts'''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={
            "test_argument": dict(required=False, type='str'),
            "gather_subset": dict(required=False, type='list', default=["!all"]),
        },
        supports_check_mode=True
    )

    gathered_facts = ansible_facts(module)

    # Test that you get a dict back
    assert isinstance(gathered_facts, dict)

    # Test that you get the right number of results
    assert len(gathered_facts) > 7

    # Test some known facts
    assert len(gathered_facts['fqdn_ip4']) > 1

# Generated at 2022-06-11 02:13:24.249083
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.module_utils.facts import get_all_facts_for_platform
    import sys
    import os

    class MockModule:
        def __init__(self, params):
            self.params = params

    module_params = dict(
        gather_timeout=10,
        gather_subset='!all',
        filter='ansible_lsb',
    )
    # test only the subset that can be easily tested with a mock module
    subset = ['all', 'min', '!all', '!min']
    for s in subset:
        module_params['gather_subset'] = s
        module = MockModule(module_params)
        facts = get_all_facts_for_platform(module)
        print(facts)
        assert isinstance(facts, dict)
        assert 'ansible_lsb'

# Generated at 2022-06-11 02:13:28.708371
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule():
        def __init__(self):
            self.params = {'gather_subset': ['all']}
    mock_module = MockModule()

    result = get_all_facts(mock_module)
    assert isinstance(result, dict)



# Generated at 2022-06-11 02:13:34.124709
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    gathered_facts = ansible_facts(module)
    assert isinstance(gathered_facts, dict), type(gathered_facts)

    # should contain ansible_facts_module_name
    assert 'module_name' in gathered_facts, gathered_facts

# Generated at 2022-06-11 02:13:41.139680
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    m, ansible_facts = MagicMock(), {}

    m.params = {'filter': '*', 'gather_subset': '', 'gather_timeout': 10}
    ansible_facts = ansible_facts(module=m)
    assert type(ansible_facts) is dict

    m.params = {'filter': '', 'gather_subset': '', 'gather_timeout': 10}
    ansible_facts = ansible_facts(module=m)
    assert type(ansible_facts) is dict



# Generated at 2022-06-11 02:13:52.508927
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    # create an AnsibleModule helper object
    # Note: because we'll be calling real module_utils, we need to stub out any
    #       params that would cause AnsibleModule to exit immediately
    #       (i.e. missing required params, check_mode=True)
    #       Since the module_utils we will call will use AnsibleModule to
    #       communicate back with the ansible engine, the real AnsibleModule
    #       will be used and we can ignore the stub.
    class FakeAnsibleModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all'],
                           'gather_timeout': 10,
                           'filter': '*'}

    # now create our stub Ansible

# Generated at 2022-06-11 02:14:04.795473
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import cache
    import tempfile

    class DummyModule(object):
        def __init__(self, params):
            self.params = params

    facts_cache = cache.FactCache()
    facts_cache.update(ansible_facts(DummyModule({'gather_subset': ['all'],
                                                  'filter': '*'})))

    expected_facts = get_file_content(os.path.join('unit', 'compat.json'))
    assert facts_cache.gather_subset == 'all'
    assert facts_cache.filter == '*'
    assert expected_facts == facts_cache.get_facts()
    assert 'distribution' in facts_cache.get_facts

# Generated at 2022-06-11 02:14:15.650611
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.network.linux.bond as bond_collector
    import ansible.module_utils.facts.network.linux.file as file_collector
    import ansible.module_utils.facts.network.linux.interfaces as interfaces_collector
    import ansible.module_utils.facts.network.linux.l2_interface as l2_interface_collector
    import ansible.module_utils.facts.network.linux.l3_interface as l3_interface_collector
    import ansible.module_utils.facts.network.linux.ospf_facts as ospf_facts_collector
    import ansible.module_utils.facts.network.linux.vlan as vlan_collector
    import ansible.module_utils.facts.network.linux.iproute2 as iproute2

# Generated at 2022-06-11 02:14:26.419464
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector
    import mock
    import sys

    class Module:
        def __init__(self):
            pass

    module = Module()
    module.params = dict(gather_subset='all')

    # mock network module with fake facts
    # Mock an important method in the NetworkCollector class
    with mock.patch.object(NetworkCollector, '_get_all_interfaces') as mock_get_all_interfaces:
        fake_facts_dict = dict(ansible_interfaces=['lo', 'eth1'],
                               ansible_lo=dict(ipv4=dict(address='127.0.0.1', subnet='8')))

        mock_get_all_interfaces.return_value = fake_facts_dict


# Generated at 2022-06-11 02:14:37.707836
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/facts/system/distribution.py#L31
    os_name = os.name
    if os_name == 'nt':
        os_name = 'Windows'

    # https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/facts/system/distribution.py#L41
    distribution = None
    windows_distribution = None
    if os_name == 'Linux':
        distribution = 'Linux'
    if os_name == 'Windows':
        windows_distribution = 'Windows'

    # https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/facts/system/distribution

# Generated at 2022-06-11 02:14:49.087747
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest
    from ansible.module_utils.six import PY2
    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import BaseFactNamespace

    class NullModule(object):
        class params(object):
            gather_subset = ['all']
            gather_timeout = 10

    class FakeCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {self.namespace.name: {'fake_fact1': 'foo', 'fake_fact2': 'bar'}}

    class FakeNamespace(BaseFactNamespace):
        def _get_collector_classes(self):
            return [FakeCollector]



# Generated at 2022-06-11 02:14:57.020743
# Unit test for function get_all_facts
def test_get_all_facts():
    class Module:
        def __init__(self):
            self.params = {'gather_subset': ['all'],
                           'gather_timeout': 10,
                           'filter': '*'}

    module = Module()
    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    # Smoke test - assert that this key, value pair exists in returned results
    assert 'distribution' in facts
    assert facts['distribution']

# Generated at 2022-06-11 02:15:01.728641
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_classes

    class CustomUserCollector(BaseFactCollector):
        # Mimic UserCollector's collect method.
        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 42}

    class TestCustomUserCollector():
        # Test class to test register method.
        def test_register(self):
            # Add a custom collector to the list of all fact collectors.
            all_collectors = get_collector_classes()

# Generated at 2022-06-11 02:15:10.517238
# Unit test for function ansible_facts
def test_ansible_facts():
    # The two 2.3 unittests import a 2.3 version of the AnsibleModule class.  Since they don't
    # import the 2.0 version of the AnsibleModule class, the unittests in this file are the
    # only place where the 2.0 version of the AnsibleModule class is imported, so import it
    # here to make sure that it still works.
    from ansible.module_utils.facts import AnsibleModule

    import unittest

# Generated at 2022-06-11 02:15:20.857374
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts as facts
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.system as system
    import ansible.module_utils.facts.network as network
    import ansible.module_utils.facts.service as service
    import ansible.module_utils.facts.distribution as distribution
    import ansible.module_utils.facts.hardware as hardware
    import ansible.module_utils.facts.package as package

    class MockModule(object):
        def __init__(self, params=None):
            if params is None:
                params = {}
            self.params = params


# Generated at 2022-06-11 02:15:32.627838
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule(object):

        params = {'gather_subset': ['all'], 'gather_timeout': 10, 'filter': '*'}

        def __init__(self, name):
            self.name = name

    def return_list_of_fake_collectors():
        return [FakeCollector]

    class FakeCollector():
        @staticmethod
        def add_default_facts(module):
            return {'result': 'from fake collector'}

    class FakeFactsModule():
        def __init__(self):
            self.params = {'filter': '*'}

        def fail_json(self, **kwargs):
            pass

    fake_module = FakeModule('fake_ansible_module')
    fake_fact_module = FakeFactsModule()


# Generated at 2022-06-11 02:15:45.769981
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.facts import which_facts
    from ansible.module_utils.facts import default_collectors

    all_collector_classes = default_collectors.collectors
    collector = ansible_collector.get_ansible_collector(all_collector_classes=all_collector_classes,
                                                        namespace=None,
                                                        filter_spec='*',
                                                        gather_subset=[],
                                                        gather_timeout=10,
                                                        minimal_gather_subset=[])

    required_collectors = which_facts(collector.FACT_SUBSETS)

    # all_fact_names = collector.get_fact_names()
    # for fact_name in all_fact_names:
    #    fact_value = collector.collect_fact(fact_

# Generated at 2022-06-11 02:15:50.024435
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.fips
    import ansible.module_utils.facts.system.distribution

    def mock_module(params):
        class FakeModule():
            def __getitem__(self, key):
                return params[key]

        return FakeModule()

    # test with no gather_subset arg
    params = {'gather_subset': ['fips']}
    module = mock_module(params)
    facts = ansible_facts(module)
    assert facts['fips_status'] == 'true'

    # test with gather_subset arg
    params = {'gather_subset': ['distribution']}
    module = mock_module(params)
    facts = ansible_facts(module, gather_subset=params['gather_subset'])

# Generated at 2022-06-11 02:16:00.977246
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.compat.tests import unittest
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.cache import BaseFactCache
    import tempfile

    class TestCollector(BaseFactCollector):

        _fact_ids = frozenset(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return dict(test_fact="test_fact_value")

    class TestFactCache(BaseFactCache):

        def get_facts(self, fact_collector, collected_facts=None):
            return fact_collector.collect()


# Generated at 2022-06-11 02:16:11.224142
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    import copy
    import os

    test_data_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    all_fact_data_file = os.path.join(test_data_dir, 'all_facts')

    # TODO: use mock module to replace AnsibleModule, then can avoid dumping a ton of data into
    #       this test's output.
    # Create a mock AnsibleModule instance
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', elements='str', required=False),
                                          'gather_timeout': dict(type='int', required=False),
                                          'filter': dict(type='str', required=False)})

    # Rather than running

# Generated at 2022-06-11 02:16:29.585907
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector

    class TestAnsibleModule(object):

        def __init__(self, params):
            self.params = params

    _virtual_platform = 'virtual_platform'
    _virtual_uuid = 'virtual_uuid'

    class TestVirtual(Virtual):
        def get_virtual_facts(self):
            return dict(platform=_virtual_platform, uuid=_virtual_uuid)

    class TestVirtualCollector(VirtualCollector):
        def __init__(self, *args, **kwargs):
            super(TestVirtualCollector, self).__init__(*args, **kwargs)
            self.test_virtual = TestVirtual()

    all_collectors = set(default_collectors.collectors)

# Generated at 2022-06-11 02:16:39.685160
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import ansible_collector
    import sys
    import tempfile
    import pytest


# Generated at 2022-06-11 02:16:51.024365
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils

    class AnsibleModuleMock(object):
        def __init__(self, gather_subset, gather_timeout=10, filter="*"):
            self.params = {
                'gather_subset': gather_subset,
                'gather_timeout': gather_timeout,
                'filter': filter,
            }

        def fail_json(self, **kwargs):
            print("module.fail_json called: %s" % kwargs)
            raise Exception('module.fail_json() was called!')

    module = AnsibleModuleMock(['all'])
    facts = ansible_facts(module)
    assert facts['architecture'] == ansible.module_utils.facts.system.distribution.architecture()

# Generated at 2022-06-11 02:16:59.745335
# Unit test for function get_all_facts
def test_get_all_facts():
    import types
    module = types.ModuleType('ansible.module_utils.facts.get_all_facts')

    # gather_subset is a required parameter
    # only test with gather_subset==['all'].
    module.params = {'gather_subset': ['all']}
    facts = get_all_facts(module)

    for default_fact_name in default_collectors.collectors:
        bare_fact_name = ansible_collector.remove_prefix(default_fact_name, 'ansible_')
        assert bare_fact_name in facts


# Generated at 2022-06-11 02:17:08.988969
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import module_facts
    from ansible.module_utils import basic

    module_args = {}

    class Module(object):
        def __init__(self, module_args):
            self.params = module_args

    # This is more or less a unit test for ansible.module_utils.facts.get_all_facts,
    # but we test this function rather then get_all_facts so we don't have to
    # make assumptions about which version of ansible is being tested.

    # For some reason the ansible_facts method doesn't set module.ansible_facts.
    # So we do it here.
    module = Module(module_args)
    module_facts(module)


# Generated at 2022-06-11 02:17:13.158301
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    facts = ansible_facts(module)
    assert type(facts) == dict
    for fact in facts:
        assert type(fact) == str


# Generated at 2022-06-11 02:17:25.293730
# Unit test for function get_all_facts
def test_get_all_facts():
    import os
    import json
    import platform
    import sys

    # assume that this is always absolute path
    test_dir = os.path.dirname(os.path.realpath(__file__))
    ansible_module_utils = os.path.realpath(os.path.join(test_dir, os.pardir, os.pardir, 'module_utils'))
    print('ansible_module_utils: {}'.format(ansible_module_utils))
    sys.path.insert(0, ansible_module_utils)

    from ansible.module_utils.facts import ansible_facts as fact_collector
    from ansible.module_utils.facts import Facts

    #def get_all_facts(module):
    #ansible_facts(module, gather_subset=None):

# Generated at 2022-06-11 02:17:33.353972
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.basic import AnsibleModule

    # Stub out AnsibleModule
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list'),
                                          'gather_timeout': dict(type='int', default=10),
                                          'filter': dict(type='str', default='*')})

    # call module_utils.facts.get_all_facts with same params as get_all_facts
    gather_subset = module.params['gather_subset']

# Generated at 2022-06-11 02:17:44.470055
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.hardware.arm as arm_facts
    import ansible.module_utils.facts.hardware.x86_64 as x86_64_facts

    # basic smoke test
    # check we can get facts when we have cached facts
    module = dict()
    module['ansible_facts'] = dict()
    module['ansible_facts']['cacheable_facts'] = dict()
    module['ansible_facts']['cacheable_facts']['ansible_architecture'] = 'x86_64'
    module['ansible_facts']['failed_conditions'] = []
    module['ansible_facts']['ansible_facts_cacheable'] = True

    x86_64_facts.get_fact(module)
    facts = ansible_facts(module)


# Generated at 2022-06-11 02:17:54.709845
# Unit test for function ansible_facts
def test_ansible_facts():
    '''This function is not a unit test per se.  But it exercises the ansible_facts function,
    and provides a simple entry point to unit test the ansible_facts function in a debugger.

    To run this function under a debugger, run it via:

        python -m pytest -s -v facts/ansible_facts.py

    '''
    from ansible.modules.system import setup
    module = setup.AnsibleModule(argument_spec=dict(
        gather_subset=dict(type='list', default=['all']),
        gather_timeout=dict(type='int', default=10),
        filter=dict(type='str', default='*')
    ))

    ansible_facts(module=module, gather_subset=module.params['gather_subset'])

# Generated at 2022-06-11 02:18:21.399626
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''

    from ansible.module_utils.facts.facts import get_all_facts
    from ansible.module_utils.six import PY3

    class MockModule(object):
        '''Mock class for testing get_all_facts'''

        def __init__(self):
            self.params = {'gather_subset': ['all']}

    class MockPY3Module(object):
        '''Mock class for testing get_all_facts on py3'''

        def __init__(self):
            # gather_subset is a frozen set on py3
            self.params = {'gather_subset': frozenset(['all'])}

    if PY3:
        module = MockPY3Module()
    else:
        module

# Generated at 2022-06-11 02:18:31.390598
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.facts.utils import get_all_collector_classes

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.basic import AnsibleModule

    # build a module for module_utils.facts.ansible_collector.get_ansible_collector to use

# Generated at 2022-06-11 02:18:40.922897
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import get_all_facts

    # This is the minimal set of params required for an AnsibleModule instance.
    # We define it so we can construct a module instance to use as a mock object
    # when calling ansible_facts
    minimal_module_args = dict(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    # Make the call to ansible_facts, passing in a mock 'module'.
    # Verify that the ansible_facts return value is a dict, and all dict
    # values are true (i.e. not None, False, or '')
    module_mock = basic.AnsibleModule(**minimal_module_args)
    facts_dict = ansible_facts(module_mock)

# Generated at 2022-06-11 02:18:46.438249
# Unit test for function ansible_facts
def test_ansible_facts():
    class MockModule:
        def __init__(self):
            self.params = dict(
                gather_subset=['all'],
                gather_timeout=10,
                filter='*',
            )

    fact_dict = ansible_facts(MockModule())
    assert fact_dict.get('default_ipv4')

# Generated at 2022-06-11 02:18:56.782118
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeAnsibleModule():
        def __init__(self, gather_subset=None):
            self.params = {}
            if gather_subset:
                self.params['gather_subset'] = gather_subset
            else:
                self.params['gather_subset'] = ['all']

    class FakeNetworkCollector(NetworkCollector):
        def __init__(self, *args, **kwargs):
            self.modules_to_run = self.get_modules_to_run()
            super(FakeNetworkCollector, self).__init__(*args, **kwargs)


# Generated at 2022-06-11 02:19:09.093239
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    TODO: this is actually a test for get_all_facts, which is a test for ansible_facts, which is
    a test for ansible_collector, which it calls.

    Ideally we'd split this into separate tasks, one for each function tested.
    '''

    import unittest
    import mock

    class TestModule():
        def __init__(self, params):
            self.params = params

    # Test gathering only certain facts
    test_module = TestModule({'gather_subset': ['hardware', 'virtual']})
    facts = get_all_facts(test_module)
    assert 'distribution' not in facts
    assert 'ansible_virtualization_type' in facts
    assert 'ansible_processor_cores' in facts

    # Test gathering all facts

# Generated at 2022-06-11 02:19:20.499098
# Unit test for function ansible_facts
def test_ansible_facts():
    import types
    import sys
    import json
    import pytest

    import ansible
    from ansible.module_utils.basic import AnsibleModule

    # create a fake module to test
    # create an AnsibleModule fake
    fake_module = types.ModuleType('ansible.module_utils.facts.ansible_facts')
    fake_module.AnsibleModule = AnsibleModule
    sys.modules['ansible.module_utils.facts.ansible_facts'] = fake_module

    # create an AnsibleModule fake
    fake_module = types.ModuleType('ansible.module_utils.facts.processors')
    sys.modules['ansible.module_utils.facts.processors'] = fake_module

    # add some fake args to the fake AnsibleModule

# Generated at 2022-06-11 02:19:28.363760
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.utils.display import Display
    from ansible.module_utils.facts import ansible_facts

    display = Display()
    display.verbosity = 5

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    module = FakeModule(dict(gather_subset=['!all']))
    result = ansible_facts(module, gather_subset=['all'])
    assert result
    assert result['distribution']
    assert result['lsb']

# Generated at 2022-06-11 02:19:35.736629
# Unit test for function ansible_facts
def test_ansible_facts():
    import unittest
    import copy
    from ansible.module_utils.facts.utils import get_distribution, get_distribution_version
    from ansible.module_utils.facts import ansible_facts

    class FakeAnsibleModule(object):
        def __init__(self):
            pass

    class MockAnsibleCollector(ansible_collector.BaseAnsibleCollector):
        '''Overload the BaseAnsibleCollector, which does not implement the collect method,
        to return fake facts.'''
        def collect(self, module):
            facts_dict = {}
            facts_dict[self.namespace.prefix + 'distribution'] = 'fake_distribution'
            facts_dict[self.namespace.prefix + 'distribution_version'] = 'fake_version'
            return facts_dict

   

# Generated at 2022-06-11 02:19:47.135817
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr

    module_mock = Mock()
    module_mock.params = dict()
    module_mock.params['gather_subset'] = ['distribution', 'pkg_mgr']

    # AnsibleModule.get_bin_path() needs to be patched to return a real path
    def get_bin_path(name, required=True):
        # return the full path to a bin on the test system
        return {'lsb_release': '/usr/bin/lsb_release'}[name]

    module_mock.get_bin_path = Mock(side_effect=get_bin_path)

    distribution = ansible.module_utils.facts.system.distribution.Distribution

# Generated at 2022-06-11 02:20:25.463900
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import api as fact_api
    fact_api.get_all_facts = get_all_facts
    # load a test module that uses get_all_facts
    import test_module_utils.facts

    # restart ansible default_collector with a new list of just the test collector
    import ansible.module_utils.facts.collector.test_collector
    all_collectors = {'test_collector': ansible.module_utils.facts.collector.test_collector.TestCollector}
    default_collectors.restart_default_collector(all_collectors)

    # call ansible_facts with gather_subset=['test', '!test1']
    module = default_collectors.AnsibleModuleStub()

# Generated at 2022-06-11 02:20:37.922898
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    try:
        from ansible.module_utils import facts
        from ansible.module_utils.facts import default_collectors
        from ansible.module_utils.facts import ansible_collector
        from ansible.module_utils.facts.namespace import PrefixFactNamespace
    except ImportError:
        # ansible 2.2 or 2.3
        from ansible.module_utils.facts import default_collectors
        from ansible.module_utils.facts import ansible_collector
        from ansible.module_utils.facts.namespace import PrefixFactNamespace

    import unittest


# Generated at 2022-06-11 02:20:48.452223
# Unit test for function ansible_facts
def test_ansible_facts():

    try:
        # Python 3.x and 2.x
        import unittest.mock as mock
    except ImportError:
        # Python 2.7
        import mock

    # A fake mock module which we can use to test ansible_facts
    class FakeModule:
        def __init__(self, params):
            self.params = params

    from module_utils.facts import default_collectors
    from module_utils.facts.network.base import NetworkCollector

    class FakeNetworkCollector(NetworkCollector):

        @classmethod
        def is_required(cls, gather_subset=None, filter_spec=None):
            # return true for all network facts.
            return True


# Generated at 2022-06-11 02:20:55.790067
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for get_all_facts function'''

    # Test function with minimal args
    # This test assumes the function is doing the right thing, since it is just a thin wrapper
    # around a 'real' implementation
    try:
        import ansible.module_utils.facts.ansible_facts
        facts_dict = get_all_facts(module=None)
        assert isinstance(facts_dict, dict)
    except Exception as err:
        assert False, "Failed to get facts from get_all_facts function: {0}".format(err)

# Generated at 2022-06-11 02:21:05.550949
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    import ansible.module_utils.facts.platform.linux
    import ansible.module_utils.facts.hardware.linux
    import ansible.module_utils.facts.distribution.linux
    import ansible.module_utils.facts.dns.linux

    mock_module = MockAnsibleModule()
    ansible_facts(module=mock_module)
    actual = len(mock_module.calls)
    # NOTE: update this number for the number of facts that this feature is
    # expected to return
    expected = 9
    assert actual == expected



# Generated at 2022-06-11 02:21:13.764208
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_all_facts

    class AnsibleModule:
        def __init__(self):
            self.params = {}

    am = AnsibleModule()

    assert ansible_facts(am) == get_all_facts(am)

    # Test that we can pass in a gather_subset and we get the same results as
    # ansible 2.3/2.4
    am.params['gather_subset'] = ['!all', 'network']
    assert ansible_facts(am) == get_all_facts(am)

# Generated at 2022-06-11 02:21:23.149683
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    # used by gather_subset/minimal_gather_subset 'python'
    from ansible.module_utils.facts.collector.python import PythonFactCollector
    import skippy.skippy_module as skippy_module
    import pytest
    bare_fixture = ['bare_default_ipv4', 'bare_default_ipv6', 'bare_device',
                    'bare_fips', 'bare_hostname', 'bare_kernel',
                    'bare_lsb', 'bare_machine', 'bare_proc', 'bare_python',
                    'bare_python2', 'bare_python3', 'bare_system',
                    'bare_virtual', 'date_time', 'uptime_seconds']

# Generated at 2022-06-11 02:21:27.553676
# Unit test for function ansible_facts
def test_ansible_facts():
    for module_name in ['setup', 'setup_module']:
        module = AnsibleModule(argument_spec=dict())
        facts = ansible_facts(module=module)
        assert 'ansible_facts' in facts
        assert 'ansible_distribution' in facts['ansible_facts']

# Generated at 2022-06-11 02:21:35.567058
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({
        'gather_subset': ['!all', 'network'],
        'filter': 'ansible_distribution_version',
    })

    facts_dict = ansible_facts(module, gather_subset=['!all', 'network'])

    assert len(facts_dict) == 1
    assert facts_dict['distribution_version'] == to_bytes('2.1')

# Generated at 2022-06-11 02:21:43.735080
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test ansible_facts works without gather_subsets arg, which was added in 2.3'''

    import ansible.module_utils.facts.platform
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.distribution

    # pylint: disable=import-error
    try:
        # works with 2.0/2.1
        from ansible.module_utils.facts import default_collectors
        from ansible.module_utils.facts import ansible_collector
    except ImportError:
        # works with 2.2/2.3
        from ansible.module_utils.facts import collector as default_collectors
        from ansible.module_utils.facts import collector as ansible_collector

    from ansible.module_utils._text import to_text