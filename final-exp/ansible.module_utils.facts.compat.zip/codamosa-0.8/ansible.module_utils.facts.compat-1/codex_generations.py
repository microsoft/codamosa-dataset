

# Generated at 2022-06-11 02:11:49.801898
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.facts.collector.text_file import TextFileCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector
    from ansible.module_utils.facts.collector.pip import PipCollector

    class TestAnsibleModule:
        def __init__(self, params=None, add_file_common_args=None, get_bin_path=None):
            self.params = params
            self.add_file_common_args = add_file_common_args
            self.get_bin_path = get_bin_path


# Generated at 2022-06-11 02:11:58.286128
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.common._collections_compat import MutableMapping

    fake_module = type('AnsibleModule', (), {'params': {'gather_subset': 'all'}})

    expected_facts = {}

    collector = type('FactCollector', (BaseFactCollector,), {'collect': lambda self, module: expected_facts,
                                                             'get_fact_names': lambda self: [],
                                                             'minimal_gather_subset': frozenset()})

    module_utils_facts = type('_AnsibleModuleUtilsFacts', (), {'collectors': [collector]})

    from ansible.module_utils.facts.collector import Facts

# Generated at 2022-06-11 02:12:01.604680
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.modules.system.setup as setup_module
    class FakeModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, opt_dirs=None):
            return arg
    module = FakeModule()
    g_facts = ansible_facts(module)
    s_facts = setup_module.main()
    assert s_facts == g_facts

# Generated at 2022-06-11 02:12:11.674590
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import FACT_CACHE
    from ansible.module_utils._text import to_bytes

    # Test to ensure function returns cached facts when called mulitple times.
    module = MockModule()
    module.params = {'gather_subset': 'all'}
    facts = get_all_facts(module)

    # Get all facts again, this time it should be cached.
    cached_facts = get_all_facts(module)

    # Verify the two facts dicts are equal.
    assert facts == cached_facts

    # Test to ensure function returns cached facts when called multiple times with different
    # gather_subsets.
    module.params = {'gather_subset': 'network'}
    facts = get_all_facts(module)
    cached_facts = get_all_

# Generated at 2022-06-11 02:12:18.870642
# Unit test for function ansible_facts
def test_ansible_facts():
    testargs = ["/usr/bin/ansible", "/tmp"]
    with mock.patch.object(sys, 'argv', testargs):
        from ansible.module_utils.facts import ansible_collector

        class FakeModule(object):
            pass

        fake_module = FakeModule()

        fake_module.params = {'filter': '*', 'facter_task_uuid': None,
                              'gather_subset': None, 'gather_timeout': 10}

        ansible_collector.ansible_facts(fake_module)

# Generated at 2022-06-11 02:12:23.217217
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'filter': dict(default='*')},
                           supports_check_mode=True, bypass_checks=True)

    facts = ansible_facts(module)
    assert type(facts) is dict

# Generated at 2022-06-11 02:12:34.117255
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.local.base import LocalCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    import os

    class TestNetworkCollector(NetworkCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test.network_dummy': 'NetworkDummy'}

    class TestLocalCollector(LocalCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test.local_dummy': 'LocalDummy'}


# Generated at 2022-06-11 02:12:45.693497
# Unit test for function ansible_facts
def test_ansible_facts():
    class Module(object):
        def __init__(self, params):
            self.params = params
            self.exit_json = lambda **kwargs: kwargs

        def fail_json(self, **kwargs):
            self.fail_json_called = True
            pass

    assert ansible_facts(Module({}))
    assert ansible_facts(Module({'gather_subset': '!all'}))
    assert ansible_facts(Module({'gather_timeout': 5}))
    assert ansible_facts(Module({'filter': 'ansible_os_family'}))

    assert ansible_facts(Module({'gather_subset': '!all',
                                 'gather_timeout': 5,
                                 'filter': 'ansible_os_family'}))


# Generated at 2022-06-11 02:12:56.469084
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import pytest
    module_mock = pytest.MagicMock()
    module_mock.params = {'gather_subset': ['all']}
    ansible_dict = ansible_facts(module_mock)
    assert 'distribution' in ansible_dict
    assert 'lsb' in ansible_dict
    # test to make sure that all the namespaces are stripped out
    assert not any([fact.startswith('ansible_') for fact in ansible_dict])

# Generated at 2022-06-11 02:13:07.700539
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test the ansible_facts function.'''
    import sys
    import ansible.module_utils.basic
    import ansible.module_utils.facts.namespace

    class FakeModule(object):
        '''A fake module object.'''

        class ModuleFailException(Exception):
            '''A fake module fail exception.'''

            def __init__(self, *args, **kwargs):
                '''Fake __init__.'''
                Exception.__init__(self, *args, **kwargs)

        def __init__(self, *args, **kwargs):
            '''create a new fake module'''
            for key in kwargs:
                setattr(self, key, kwargs[key])

        def fail_json(self, *args, **kwargs):
            '''Fake fail_json'''

# Generated at 2022-06-11 02:13:18.514334
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test with 2.3 and 2.4 ansible modules (both have gather_subset)
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['!all'])},
                      supports_check_mode=True)
    assert ansible_facts(m, gather_subset=None) == dict()  # No facts to collect

    # Test with 2.0 and 2.1 ansible modules (no gather_subset)
    m = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert ansible_facts(m) == dict()  # No facts to collect

# Generated at 2022-06-11 02:13:29.617868
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.default_collectors
    from ansible.module_utils.facts import module_utils, ansible_collector
    from ansible.module_utils.facts.namespace import PrefixNamespace

    # make a mock ansible_module that has a 'run_command' method
    class AnsibleModuleFake(object):
        def __init__(self):
            self.run_command = lambda x: {'cmd': x, 'rc': 0, 'stdout': '', 'stderr': ''}
            self.params = {'gather_subset': ['foo']} # fake out minimal_gather_subset logic

    class MockCollector(object):
        def __init__(self, namespace, gather_subset=None, gather_timeout=10, filter_spec=None):
            self

# Generated at 2022-06-11 02:13:39.580607
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_collector
    import ansible.module_utils.facts.namespace as ns
    import ansible.module_utils.facts.network as network
    import ansible.module_utils.facts.processor as processor

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    fake_module = FakeModule({'gather_subset': ['network']})
    all_fact_subsets = frozenset([fact_subset for fact_subset, _ in ns.FACT_SUBSETS])
    for fact_subset in ('all', 'network', '!network', 'network,!network', all_fact_subsets):
        facts = get_all_facts(fake_module)
        assert facts == {}

    all_collector

# Generated at 2022-06-11 02:13:51.728415
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for ansible_facts

    fake AnsibleModule params,
    fake results returned by collector classes
    '''

    class FakeModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, binary, required=True):
            return binary

        def get_bin_paths(self, binaries):
            return binaries

        def get_gid(self):
            return 1

        def get_uid(self):
            return 1

        def load_file_common_arguments(self, params):
            return params

        def get_file_content(self, path):
            return path

        def get_file_content_string_from_module_utils(self, path):
            return path

        def get_tmp_path(self):
            return '/tmp'

# Generated at 2022-06-11 02:14:03.807340
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Ansible facts provides a list of all available facts '''

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    params = {'filter': '*', 'gather_subset': ['all']}

    facts = ansible_facts(MockModule(params))
    assert 'ansible_all_ipv4_addresses' in facts
    assert 'ansible_all_ipv6_addresses' in facts
    assert 'ansible_architecture' in facts
    assert 'ansible_bios_date' in facts
    assert 'ansible_bios_version' in facts
    assert 'ansible_cmdline' in facts
    assert 'ansible_date_time' in facts
    assert 'ansible_default_ipv4' in facts

# Generated at 2022-06-11 02:14:08.859207
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    # use AnsibleModule.params so we can set the gather_subset param
    module = AnsibleModule({}, params={'gather_subset': ['all']})
    facts = get_all_facts(module)
    print(facts)
    assert facts['fqdn'] is not None
    assert facts['all_ipv4_addresses'] is not None



# Generated at 2022-06-11 02:14:19.587611
# Unit test for function get_all_facts
def test_get_all_facts():
    with mock.patch('ansible.module_utils.facts.ansible_collector.get_ansible_collector') as mock_get_collector:
        with mock.patch('ansible.module_utils.facts.default_collectors.collectors') as mock_get_default_collectors:
            with mock.patch('ansible.module_utils.facts.ansible_collector.AnsibleCollector.collect', return_value={'a': 'b'}):
                module = mock.MagicMock()
                module.params = {'gather_subset': ['a','b']}
                module.params['gather_timeout'] = '999'
                mock_get_default_collectors.return_value = 'mock_collectors'
                get_all_facts(module)

# Generated at 2022-06-11 02:14:28.136765
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    As long as we're making this a public method, it should have a unit test.
    '''

    import ansible
    import ansible.module_utils.facts.default_collectors.system

    ansible_system_package_facts = ansible.module_utils.facts.default_collectors.system.SystemPackageCollector
    ansible_system_package_facts.collect = lambda self: {'packages': []}

    fake_module = FakeAnsibleModule()

    facts_dict = ansible_facts(fake_module)

    assert facts_dict == fake_module.ansible_facts
    assert facts_dict['packages'] == []



# Generated at 2022-06-11 02:14:36.315557
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        from ansible.module_utils.facts import get_all_facts
    except ImportError:
        return

    class MockModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    mock_module = MockModule(gather_subset=['all'])
    got_facts = get_all_facts(mock_module)

    assert 'ansible_all_ipv4_addresses' in got_facts
    assert 'ansible_lsb' in got_facts
    assert 'ansible_date_time' in got_facts



# Generated at 2022-06-11 02:14:46.433066
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeFactCollector(BaseFactCollector):
        name = 'fake_fact'

        # method required by BaseFactCollector
        def collect(self, module=None, collected_facts=None):
            return {'collector_name': self.name,
                    'fact_name': self.name}

    # replace the FakeFactCollector in place of the real DistributionFactCollector
    # (it is not actually used here, but has a 'name' value of 'distribution')
    fake_collector = FakeFactCollector()
    default_collectors.collectors[fake_collector.name] = fake_collector


# Generated at 2022-06-11 02:15:03.292179
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts as ansible_facts_m_utils
    import ansible.module_utils.facts.collector as ansible_facts_collector

    class TestAnsibleModule():
        def __init__(self):
            self.params = {
                            'gather_subset': 'all',
                            'filter': '*'
                          }

    class TestFactsCollector(ansible_facts_collector.BaseFactCollector):
        def __init__(self, module):
            super(TestFactsCollector, self).__init__(module)

        def collect(self, module=None, collected_facts=None):
            return {'dummy_fact': 'dummy'}


# Generated at 2022-06-11 02:15:07.789443
# Unit test for function get_all_facts
def test_get_all_facts():
    class AnsibleModule():
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    am = AnsibleModule()
    facts = get_all_facts(am)

    assert isinstance(facts, dict)
    assert len(facts) > 5
    assert facts['distribution'] == 'unknown'

# Generated at 2022-06-11 02:15:18.909104
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible import constants as C
    from ansible.compat.tests import unittest

    from ansible.module_utils import basic
    import ansible.module_utils._text as text

    class FakeModule(object):
        def __init__(self, params, **kwargs):
            self.params = params
            self.basic = basic.AnsibleModule(**kwargs)

    # make sure we can get a table of all facts
    module = FakeModule(dict(gather_timeout=C.DEFAULT_GATHER_TIMEOUT, gather_subset=['all']))
    facts = ansible_facts(module)
    assert isinstance(facts, dict)
    assert len(facts) > 0

    # make sure we can get a table of all facts, with the gather_subset param
    # (this is what the

# Generated at 2022-06-11 02:15:29.935834
# Unit test for function ansible_facts
def test_ansible_facts():
    module = AnsibleFakeModule()
    gather_subset = ['hardware', 'virtual']
    gather_timeout = 15
    filter_spec = '*'

    # test default values
    facts_dict = ansible_facts(module=module)
    command_call_history = module._command_history

# Generated at 2022-06-11 02:15:39.070834
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for module_utils.facts.ansible_facts
    '''

    import os
    import imp

    from ansible.module_utils.facts.collector import BaseFactCollector

    # set up a fake module
    module = imp.new_module('test_ansible_facts')
    module.params = {}
    module.params['gather_subset'] = ['foo', 'bar']
    module.params['gather_timeout'] = 10
    module.params['filter'] = '*'
    # set gather_subset to an invalid value, so all collectors are run
    module.params['gather_subset'] = ['foo', 'bar']
    module.params['gather_timeout'] = 10
    module.params['filter'] = '*'

    # run the function
    facts_dict = ansible

# Generated at 2022-06-11 02:15:52.854168
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import gather_subset, get_all_collectors

    # Module is used by AnsibleModule and is a stub for that class
    class Module(object):
        def __init__(self, params=None):
            self.params = params


# Generated at 2022-06-11 02:16:03.380945
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for get_all_facts method'''
    # patch 'ansible.module_utils.facts.ansible_facts' to return a fixed value for the facts
    from mock import Mock
    from mock import MagicMock
    from mock import patch
    mock_ansible_facts = Mock(return_value={'fact1': 'value1'})
    with patch.multiple('ansible.module_utils.facts.collector_compat',
                        ansible_facts=mock_ansible_facts):

        # the base module class needs to be mocked in order to get
        # access to 'ansible_facts' and 'params' properties
        # this is because the base_module class doesn't actually exist and so
        # 'mock' creates a new class
        base_module = MagicMock()
        base_module.ansible

# Generated at 2022-06-11 02:16:15.116367
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes

    class AnsibleModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all'], 'gather_timeout': 10,
                           'filter': '*'}

    am = AnsibleModule()

    facts_dict = ansible_facts(module=am)
    assert isinstance(facts_dict, dict)
    assert to_bytes('ansible_local') in facts_dict
    assert to_bytes('ansible_lsb') in facts_dict
    assert to_bytes('ansible_fips') in facts_dict
    assert to_bytes('ansible_selinux') in facts_dict
    assert to_bytes('ansible_distribution') in facts_dict

# Generated at 2022-06-11 02:16:18.334764
# Unit test for function ansible_facts
def test_ansible_facts():

    # create a fake ansible module
    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    fake_module = FakeModule(params={})
    assert ansible_facts(fake_module) is not None

# Generated at 2022-06-11 02:16:29.436616
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import prefixed_name

    import pytest

    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils.facts.system.date_time import DateTimeFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.lsb import LSBFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector

    class MockAnsibleModule:
        params = dict()


# Generated at 2022-06-11 02:16:48.431211
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic
    import ansible.module_utils.facts as facts_module
    module = basic.AnsibleModule(
        argument_spec={
            'gather_subset': {'type': 'list', 'default': ['all']},
            'gather_timeout': {'type': 'int', 'default': 10},
            'filter': {'type': 'str', 'default': '*'},
        },
        supports_check_mode=True,
    )

    facts_module.ansible_collector = MockAnsibleCollector

    # create a mock ansible_facts() that always returns the same fact value
    facts_module.ansible_facts = MockAnsibleFacts

    # create a mock all_collector_classes that always returns the same fact value
    facts_module.default

# Generated at 2022-06-11 02:16:59.582848
# Unit test for function ansible_facts
def test_ansible_facts():
    import tempfile
    import shutil
    import os
    from ansible.module_utils.facts import default_collectors

    test_facts_path = tempfile.mkdtemp()
    collected_facts = None

# Generated at 2022-06-11 02:17:08.894723
# Unit test for function ansible_facts
def test_ansible_facts():
    """test the ansible_facts function.  Ansible modules will be mocking the module object
    so to do this we need to do the same.

    """

    class FakeModule(object):
        def __init__(self, gather_subset=['all'], gather_timeout=10):
            self.params = {}
            self.params['gather_subset'] = gather_subset
            self.params['gather_timeout'] = gather_timeout
            self.params['filter'] = '*'

    # test with defaults
    module = FakeModule()
    facts = ansible_facts(module)
    assert facts['distribution'] == 'unknown'
    assert facts['distribution_version'] == 'unknown'

    # filter for a subset of the facts
    module = FakeModule(gather_subset=['!network'])
   

# Generated at 2022-06-11 02:17:10.884639
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Unit test for function ansible_facts '''


if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-11 02:17:22.509776
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.runner import get_runner
    from ansible.module_utils.facts.cache import FactsCache


# Generated at 2022-06-11 02:17:31.854801
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test the ansible_facts function.'''
    from ansible.module_utils.facts import ansible_collector

    # Make a 'fake' ansible module.
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(required=False, type='str', default=''),
            gather_timeout=dict(required=False, type='int', default=10),
            filter=dict(required=False, type='str', default='*'),
        )
    )

    # Mock the ansible_facts call.  Basically we want to return
    # a dict containing the 'hostname' AnsibleFact.
    from unittest.mock import Mock
    from ansible.module_utils import facts
    facts.ansible_collect

# Generated at 2022-06-11 02:17:39.665667
# Unit test for function get_all_facts
def test_get_all_facts():
    import unittest
    from ansible.module_utils.facts import AnsibleModuleMock

    # create the mock module object
    mod = AnsibleModuleMock()
    mod.params = {'gather_subset': ['all']}

    # get the facts
    facts = get_all_facts(module=mod)

    # make sure we got some
    assert 'ansible_architecture' in facts
    assert 'ansible_distribution' in facts
    assert 'ansible_distribution_version' in facts
    assert 'ansible_system' in facts



# Generated at 2022-06-11 02:17:48.494069
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.facts.namespace import FactsNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes

    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    # Mock ansible_collector.get_ansible_collector to return a fake that does nothing
    original_get_ansible_collector = ansible_collector.get_ansible_collector


# Generated at 2022-06-11 02:17:56.169844
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr
    from ansible.module_utils.facts.utils.common import FactsCommon

    # simulate an ansible module
    class MockAnsibleModule:
        def __init__(self):
            self.params = {}

        def fail_json(self, msg):
            raise Exception(msg)

    mock_module = MockAnsibleModule()

    # set gather_subset to all, so all facts get collected.
    mock_module.params['gather_subset'] = ['all']

    facts_dict = ansible_facts(mock_module)

    # test the distro specific facts
    distribution_dict = facts_dict['distribution']

    linux_

# Generated at 2022-06-11 02:18:05.549150
# Unit test for function ansible_facts
def test_ansible_facts():
    # we need to mock out the methods on the module.
    # we also need to add the methods required by our fact_collector to the module.
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.bsd import BsdNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic import Network

    from ansible.module_utils.facts.virtual.kvm import KVM
    from ansible.module_utils.facts.virtual.docker import Docker
    from ansible.module_utils.facts.virtual.vbox import VirtualBox

# Generated at 2022-06-11 02:18:30.703799
# Unit test for function ansible_facts
def test_ansible_facts():

    class FakeModule(object):
        def __init__(self, params=None):
            self.params = params or {}

    # default args
    module = FakeModule()

    facts = ansible_facts(module)
    # make sure the ansible namespace was not added
    assert 'ansible' not in facts

    # check for a few bare names
    assert 'default_ipv4' in facts
    assert 'default_ipv4.address' in facts['default_ipv4'], facts['default_ipv4']
    assert 'default_ipv4.gateway' in facts['default_ipv4'], facts['default_ipv4']
    assert 'default_ipv4.interface' in facts['default_ipv4'], facts['default_ipv4']

    # check that all the collectors got run

# Generated at 2022-06-11 02:18:40.731085
# Unit test for function ansible_facts
def test_ansible_facts():
    # 2.2/2.3 style, with gather_subset
    gather_subset = ['!all', 'network', 'virtual']

# Generated at 2022-06-11 02:18:52.184794
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import namespace

    class FakeModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 1
            self.params['filter'] = '*'

        def fail_json(self, **msg):
            pytest.fail('Fail json called with %s' % msg)

    class FakeAnsibleFactCollector(BaseFactCollector):
        def collect(self, module):
            return {'compat_test': 'compat_test'}


# Generated at 2022-06-11 02:19:00.651453
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts import utils
    import json

    # test harness will provide:
    # self.mock_ansible_module.params['gather_subset'] = ['all']
    g_mock_ansible_module = TestModule()

    # get the list of collector classes that should be executed when gather_subset == ['all']
    all_collector_classes = default_collectors.collectors

    # don't add a prefix
    g

# Generated at 2022-06-11 02:19:11.393013
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MyFactCollector(BaseFactCollector):

        def __init__(self, *args, **kwargs):
            super(MyFactCollector, self).__init__(*args, **kwargs)
            self.name = 'my_collector'

        def collect(self, module=None, collected_facts=None):
            # return dummy facts, to prove that my_collector fact collector is called.
            return {'a': 1, 'b': 2}

    class MyModule(object):

        def __init__(self):
            self.params = {'gather_subset': 'all'}

    all_collector_classes = {'my_collector': MyFactCollector}

    my_module = MyModule()

    facts_

# Generated at 2022-06-11 02:19:21.094505
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import get_all_facts

    class FakeModule:
        class FakeModuleParams:
            gather_subset = ['all']

        params = FakeModuleParams()

        def get_bin_path(self, arg, required=True, opt_dirs=[]):
            return ''

    fake_module = FakeModule()

    facts = get_all_facts(fake_module)

    assert 'ansible_python_version' in facts
    assert to_bytes(facts['ansible_python_version'], nonstring='simplerepr') == 3


# Generated at 2022-06-11 02:19:33.050619
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.modules.extras.system.setup as setup

    test_module = setup.AnsibleModule(argument_spec={
        'gather_subset': dict(type='list', elements='str', default=['!all']),
        'gather_timeout': dict(type='int', default=10),
        'filter': dict(type='str', default='*')
    })


# Generated at 2022-06-11 02:19:43.994814
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule(object):

        def __init__(self):
            self.params = {'gather_subset': ['network'], 'gather_timeout': 10, 'filter': '*'}

    class FakeCollector(BaseFactCollector):

        def populate(self):
            self.data['foo'] = 'bar'

    assert ansible_facts(FakeModule(), ['all']) == {}
    assert ansible_facts(FakeModule(), ['network']) == {'foo': 'bar'}

# Generated at 2022-06-11 02:19:51.777258
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.common._collections_compat import MutableMapping
    module = MutableMapping()
    # Note: cannot test the contents of the facts, since some of them may be system-specific.
    # But just make sure that ansible_facts returns a dict.
    assert isinstance(ansible_facts(module), dict)

# Generated at 2022-06-11 02:20:03.118372
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    import mock

    class MockedModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    with mock.patch.object(BaseFactNamespace, 'get_facts') as mocked_get_facts:

        mock_retval = {'foo': 'bar'}
        mocked_get_facts.return_value = mock_retval

        ansible_2_2_module = MockedModule(['all'])
        result = get_all_facts(ansible_2_2_module)
        assert result == mock_retval

        ansible_2_2_module = MockedModule(None)

# Generated at 2022-06-11 02:20:37.519571
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default='all', type='list'),
            gather_timeout=dict(default=10, type='int'),
            filter=dict(default='*')
        )
    )
    assert isinstance(get_all_facts(module), dict)



# Generated at 2022-06-11 02:20:45.852350
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import AnsibleFactCollector
    from ansible.module_utils.facts.system import DistributionFacts
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.utils import FactsDict
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Setup fake module
    module = mock.MagicMock()
    module.params = dict()
    module.params['gather_subset'] = ['all']
    module.params['gather_timeout'] = 10

    # Setup fake AnsibleFactCollector
    all_collector_classes = dict()
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    fact_collector = AnsibleFactCollector

# Generated at 2022-06-11 02:20:50.132815
# Unit test for function get_all_facts
def test_get_all_facts():
    module = MockAnsibleModule()
    result = get_all_facts(module)
    assert result
    assert 'distribution' in result
    assert 'os_family' in result
    assert 'distribution_version' in result
    assert 'distribution_major_version' in result



# Generated at 2022-06-11 02:21:00.298909
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.modules.system import setup
    from ansible.module_utils.facts.collector import GnuDiffFactCollector

    module_name = 'setup'
    module_args = dict(filter='ansible_lsb')

    module = setup.AnsibleModule(argument_spec=setup.argument_spec,
                                 supports_check_mode=setup.supports_check_mode)

    assert isinstance(ansible_facts(module), dict)

    assert isinstance(ansible_facts(module, gather_subset=['all']), dict)

    # gather_subset param not present in module_args, so use default
    assert isinstance(ansible_facts(module), dict)

    # test with filter param
    module_args['filter'] = 'ansible_lsb'
    module = setup.Ansible

# Generated at 2022-06-11 02:21:12.338182
# Unit test for function ansible_facts
def test_ansible_facts():
    import unittest
    import sys
    import os

    # mock AnsibleModule class
    class AnsibleModule(object):
        def __init__(self):
            self.params = dict(
                gather_subset=['all'],
                gather_timeout=10,
                filter='*'
            )

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return executable

    # mock collect_subset_definitions.collectors.all_collector_classes
    # set of collector classes for 2.4

# Generated at 2022-06-11 02:21:12.933016
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-11 02:21:22.295825
# Unit test for function ansible_facts
def test_ansible_facts(): # pylint: disable=redefined-outer-name
    '''this is a unit test of the ansible_facts function.  It is used
    to test the above code functionality independent of Ansible.  It is
    also useful to verify that when converted to a Jinja2 template, the
    above code remains valid.'''

    from ansible.module_utils import basic
    import json
    import tempfile
    import shutil

    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.tmpdir = tempfile.mkdtemp()
            self.exit_args = {}
            self.exit_json_called = False

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/path/to/' + executable


# Generated at 2022-06-11 02:21:33.858119
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors

    def fake_module():
        class FakeModule:
            def __init__(self, params):
                self.params = params

        return FakeModule

    def fake_collect(self, module, collected_facts=None, filter_spec=None, gather_subset=None, intersect=False):
        return {'ansible_facts': {'other_fact': 'other_value'}, 'ansible_fact_gather_time': 0}

    # test default args (gather_subset not given)
    ans_module = fake_module()({'gather_subset': ['all'], 'gather_timeout': 10})
    collector = default_collectors.collectors['ansible_collector']
    old_collect = collector.collect
    collector.collect = fake

# Generated at 2022-06-11 02:21:40.736010
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic

    # Let's override the ansible module
    # AnsibleModule and AnsibleModuleHelper do not take any parameters, so we can't set gather_subset
    # So we create a new AnsibleModule class
    class TestAnsibleModule(basic.AnsibleModule):

        # Let's set the default version of gather_subset to 'all'
        def __init__(self, *args, **kwargs):
            kwargs['params'] = kwargs.get('params', {})
            kwargs['params']['gather_subset'] = kwargs['params'].get('gather_subset', ['all'])
            super(TestAnsibleModule, self).__init__(*args, **kwargs)

    # create a new AnsibleModule instance
    test_