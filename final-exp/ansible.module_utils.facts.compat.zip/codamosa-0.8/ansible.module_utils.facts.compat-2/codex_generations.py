

# Generated at 2022-06-11 02:11:52.268470
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {
                'gather_subset': ['!all', 'min'],
                'gather_timeout': 10,
                'filter': '*'
            }

    # Mock fact collectors
    fact_collectors = [DistributionFactCollector]

    # Mock ansible_facts
    mock_ansible_facts = ansible_facts(module=MockModule(), gather_subset=None)

    # Assert ansible_facts
    # - should be a dict with 'distribution' as key
    assert isinstance(mock_ansible_facts, dict)
    assert 'distribution' in mock_ansible_facts

# Generated at 2022-06-11 02:12:00.374255
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import Facts

    facts_obj = Facts(module=AnsibleModule)
    facts_dict = facts_obj.get_facts(AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all'])}))

    assert isinstance(facts_dict, dict)
    assert len(facts_dict) > 0
    assert 'default_ipv4' in facts_dict.keys()

# Generated at 2022-06-11 02:12:10.709057
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import module_deprecation
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native
    import pytest

    # We need the following ENV variable defined to prevent a warning message
    # emitted by AnsibleModule.
    os.environ['ANSIBLE_CONFIG'] = "/non/existant/path"

    # we need module_deprecation to not raise an exception
    module_deprecation.SUPPORTED_MODULE_API_VERSION = 1.0

    # we need to make sure we're actually using the correct ansible_facts method
    # handle.  This is an easy way to do that
    test_ansible_facts.__globals__['ansible_facts'] = ansible_facts

# Generated at 2022-06-11 02:12:20.792823
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import defaults

    from ansible.module_utils.facts.collector import get_collector_classes

    from ansible.module_utils.facts.virtual.namespace import VirtualNamespace
    from ansible.module_utils.facts.network.namespace import NetworkNamespace
    from ansible.module_utils.facts.system.namespace import SystemFactsNamespace
    from ansible.module_utils.facts.storage.namespace import StorageFactsNamespace
    from ansible.module_utils.facts import namespace

    # this 'DummyAnsibleModule' class is used in the namespaces too, so
    # to make get_all_facts() pass, 'DummyModule' needs to be installed in
    # their module_utils.facts.namespaces package.  So they'll have a
    # '

# Generated at 2022-06-11 02:12:32.619331
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts import module_prefix
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # import mock module
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    # import module_utils module
    try:
        from ansible.module_utils import basic
    except ImportError:
        pass

    # create module
    module = basic.AnsibleModule(
        argument_spec=dict(
            gather_subsets=dict(type='list', require=False, default=[]),
            gather_timeout=dict(type='int', require=False, default=10)
        )
    )

    # set up facts collection
    facts_dict

# Generated at 2022-06-11 02:12:44.345736
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Use a dummy class to ensure that only it is collected.
    class DummyFactCollector(BaseFactCollector):
        name = 'dummy'
        _fact_ids = ['dummy_fact_id']

    # Constructor parameters.
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    filter_spec = '*'
    gather_timeout = 10
    minimal_gather_subset = frozenset(['dummy'])

    # Register DummyFactCollector

# Generated at 2022-06-11 02:12:46.661138
# Unit test for function get_all_facts
def test_get_all_facts():
    before_all_facts = {}
    assert get_all_facts(module=None) == before_all_facts


# Generated at 2022-06-11 02:12:57.914830
# Unit test for function ansible_facts
def test_ansible_facts():
    # Make sure ansible_facts is available in module_utils/facts/ansible_collector.py
    try:
        from ansible.module_utils.facts.ansible_collector import ansible_facts
    except ImportError:
        pass
    else:
        # Test ansible_facts
        from ansible.module_utils.facts.ansible_collector import ansible_facts
        from ansible.module_utils.facts.utils import get_file_content

        facts_dict = ansible_facts()

        # module_utils/facts/ansible_collector.py
        # module_utils/facts/hardware/dmi.py
        assert isinstance(facts_dict['dmi']['bios_date'], str)

        # module_utils/facts/hardware/cpu.py

# Generated at 2022-06-11 02:13:04.881303
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.modules.system.setup
    module_params = {
        'filter': '*',
        'gather_subset': 'all'
    }

    ansible_module = ansible.modules.system.setup.AnsibleModule(argument_spec=module_params)

    facts = ansible_facts(ansible_module)

    assert isinstance(facts, dict)
    assert 'distribution' in facts

# Generated at 2022-06-11 02:13:11.779090
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.test_utils import MockAnsibleModule
    module = MockAnsibleModule()
    fact_names_and_values = ansible_facts(module)
    fact_names = fact_names_and_values.keys()
    assert 'default_ipv4' in fact_names
    assert 'python_version' in fact_names
    assert 'distribution' in fact_names
    assert 'architecture' in fact_names
    assert 'gather_subset' not in fact_names
    assert 'filter' not in fact_names

# Generated at 2022-06-11 02:13:25.160859
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.system.platform

    # the following was copied from facts/__init__.py _ALL_COLLECTORS,
    # except for 'network.facter' and 'network.ohai'

# Generated at 2022-06-11 02:13:26.154525
# Unit test for function ansible_facts
def test_ansible_facts():
    # TODO
    pass

# Generated at 2022-06-11 02:13:37.709665
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self, gather_subset=None, gather_timeout=None):
            self.params = {}
            if gather_subset:
                self.params['gather_subset'] = gather_subset
            if gather_timeout:
                self.params['gather_timeout'] = gather_timeout

    module_inst = FakeModule(gather_subset=['all'], gather_timeout=10)

    facts = get_all_facts(module=module_inst)

    expected_collector_

# Generated at 2022-06-11 02:13:50.009822
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.basic
    import ansible.module_utils.facts.networking


# Generated at 2022-06-11 02:14:00.304290
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        from ansible.module_utils.facts import get_all_facts
    except ImportError: # pragma: no cover
        return

    import ansible.module_utils.facts
    import ansible.module_utils.facts.get_all_facts
    from ansible import context
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.other.dummy import DummyFactCollector
    from ansible.module_utils.facts.network.dummy import DummyNetworkCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

# Generated at 2022-06-11 02:14:10.268979
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test function ansible_facts'''
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network.interfaces import NetworkInterfaces
    from ansible.module_utils.facts.network.ip_addresses import NetworkIPAddresses
    import ansible.module_utils.facts.collector
    # backup the original list of facts
    saved_facts = BaseFactCollector._collectors
    BaseFactCollector._collectors = {'network.interfaces': NetworkInterfaces,
                                     'network.ip_addresses': NetworkIPAddresses}

# Generated at 2022-06-11 02:14:11.473397
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts, 'ansible_facts should be defined'

# Generated at 2022-06-11 02:14:22.103201
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector, DistributionFactCollector2
    from ansible.module_utils.facts.system.distribution import DNFBasedDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import APTBasedDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import YUMBasedDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import ZYPPERBasedDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import OpenBSDDistributionFactCollector

    # In the context of a test,

# Generated at 2022-06-11 02:14:31.166391
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import get_all_facts as setup_module
    from ansible.module_utils.facts import get_all_facts as module_setup

    # Mocks
    class Module(object):
        class params(object):
            @staticmethod
            def get(arg, default=None):
                if arg == 'gather_subset':
                    return ["all"]
                elif arg == 'gather_timeout':
                    return 10
                elif arg == 'filter':
                    return '*'
                else:
                    return default

    module = Module()
    res = ansible_

# Generated at 2022-06-11 02:14:42.501998
# Unit test for function get_all_facts
def test_get_all_facts():

    # Import necessary AnsibleModule class and module_utils.facts.get_all_facts function
    # pylint: disable=redefined-builtin
    from ansible.module_utils.facts.utils import get_all_facts as ansible_get_all_facts

    # Create a mock subclass of AnsibleModule
    class TestAnsibleModule(object):
        '''Mock subclass of AnsibleModule.  Allows us to pretend that the ansible_* facts
        are a param of this module.'''

        def __init__(self, params):
            self.params = params
            self.fail_json = fail_json
            self.exit_json = exit_json

    # A mock implementation of the ansible fail_json method
    def fail_json(self, msg):
        '''mock fail_json'''

        raise Not

# Generated at 2022-06-11 02:14:54.005066
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    all_facts = ansible_facts(module)
    assert all_facts['ansible_distribution'] == 'generic'
    assert all_facts['ansible_distribution_version'] == 'unknown'
    assert all_facts.get('ansible_os_family') == 'Generic'
    assert all_facts.get('ansible_python', {}).get('version') is not None

# Generated at 2022-06-11 02:15:05.821175
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import _get_all_subsets
    gather_subset = 'min,!selinux'
    raise NotImplementedError()
    # the following lines all need to be replaced with mocked versions
    assert _get_all_subsets(gather_subset) == {'min', 'ssh_pub_keys', 'lsb', 'platform', 'caps', 'python', 'service_mgr', 'user', 'env', 'dns'}

# Generated at 2022-06-11 02:15:12.675741
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self._connection = None
            self._socket_path = None

    test_params = {
        'gather_subset': ['!all', 'network'],
        'gather_timeout': 10,
        'filter': '*'
    }
    test_module = FakeModule(params=test_params)
    facts_dict = ansible_facts(module=test_module)
    assert 'network' in facts_dict



# Generated at 2022-06-11 02:15:22.085339
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' unit test for ansible_facts function '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.core import FactCollector

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    test_module = AnsibleModule(argument_spec={'gather_timeout': {'type': 'int', 'default': 1, 'required': True},
                                               'gather_subset': {'type': 'list', 'default': ['all']},
                                               'filter': {'type': 'str', 'default': '*'}})

    # test normal operation
    test_facts_dict = ansible_facts(module=test_module, gather_subset=['network'])
    assert 'distribution' in test_

# Generated at 2022-06-11 02:15:33.616225
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace as factsns
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import default_collectors, ansible_collector
    from ansible.module_utils.facts.collection import Facts

    class TestModule(object):
        def __init__(self, module_name, use_file_globs=True):
            self.params = {
                'gather_subset': ['network', 'virtual'],
                'gather_timeout': 5,
                'filter': '*interface*',
                'use_file_globs': use_file_globs,
                'module_name': module_name,
            }


# Generated at 2022-06-11 02:15:46.921114
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Mock AnsibleModule instance, and test ansible_facts'''

    import sys
    import unittest
    import types

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    class MockModule(object):
        def __init__(self, params=None):
            '''Constructor'''
            self.params = params
            self.exit_json = lambda x: x

        def fail_json(self, msg):
            '''raise exception for given msg'''
            raise Exception(msg)

        def get_bin_path(self, prog, required=False, opt_dirs=[]):
            '''return bin_path for prog, raising exception if required'''
            return prog


# Generated at 2022-06-11 02:15:52.643266
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(gather_subset=dict(type='list', default=['all']),
                                              gather_timeout=dict(type='int', default=10)))
    ansible_facts(module=module)



# Generated at 2022-06-11 02:16:03.269056
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        # This module_utils does not exist in ansible 2.0, so import this import
        # statement will fail
        from ansible.module_utils.facts import ansible_facts
    except ImportError:
        # ansible 2.0
        from unit_tests.module_utils.facts.ansible_facts_2_0 import ansible_facts

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils._text import to_text

    class FakeModule(object):
        def __init__(self, params={}):
            self.params = params


# Generated at 2022-06-11 02:16:15.016851
# Unit test for function ansible_facts
def test_ansible_facts():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=no-name-in-module
    from ansible.module_utils.facts import namespace

    # sample dict for a mocked AnsibleModule instance
    # 'gather_subset' is only included for backwards compat testing purposes
    mock_params_dict = {'gather_subset': '!all,!min',
                        'gather_timeout': 2,
                        'filter': 'ansible_distribution*'}

    class MockModule:

        def __init__(self):
            self.params = mock_params_dict

        def get_bin_path(self, executable):
            return executable

    # the following are needed to fake the import of modules that don't exist on this python controller
    # e

# Generated at 2022-06-11 02:16:26.209578
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils._text import to_text

    from ansible.module_utils.six import PY3

    if PY3:
        from io import StringIO as stringio
    else:
        from io import BytesIO as stringio

    from ansible.module_utils.basic import AnsibleModule

    module = \
        AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all'])},
                      supports_check_mode=True)

    ansible_facts = get_all_facts(module)

    assert type(ansible_facts) == dict

    fact = ansible_facts.get('ansible_python_version')
    assert fact
    assert isinstance(fact, tuple) and len

# Generated at 2022-06-11 02:16:44.958956
# Unit test for function ansible_facts
def test_ansible_facts():
    # Note: these tests use the module_utils.facts/ansible/ansible_facts.py
    # mockup, since we can't load the actual ansible_facts module.
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils import facts

    import types
    import os
    import datetime

    # ansible_facts requires ansible_module, which requires the ansible python API.
    # The ansible API isn't available until you 'import ansible'.  However, we can't
    # import ansible here because we import ansible_facts (which indirectly imports
    # ansible).  So we use a context manager to temporarily add the ansible API to
    # our sys.path while we import ansible_module.
    import sys
    ansible_path = os.path.abspath

# Generated at 2022-06-11 02:16:56.218485
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.network import NetworkFactCollector
    # Mock out ansible_facts.NetworkFactCollector.collect
    # so we don't make network calls in this unit test
    NetworkFactCollector.collect = lambda self, module: {'interfaces': {}}
    from ansible.module_utils.facts.python import PythonFactCollector
    # Stub out time.time, which is used to time gather_subset functions
    PythonFactCollector.start_time = 0
    # Stub out get_file_content, so we don't have to make files for this test
    def stub_get_file_content(filename):
        return filename + ' contents'
    get_file_content = stub_get_file_content
    import ansible

# Generated at 2022-06-11 02:17:06.620370
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.urls import open_url

    import json
    import requests
    from collections import OrderedDict

    try:
        from test.support import EnvironmentVarGuard
    except ImportError:
        from test.test_support import EnvironmentVarGuard

    try:
        if '_ANSIBLE_KEEP_REMOTE_FILES' in os.environ:
            del os.environ['_ANSIBLE_KEEP_REMOTE_FILES']
    except NameError:
        del os.environ['_ANSIBLE_KEEP_REMOTE_FILES']

# Generated at 2022-06-11 02:17:15.658382
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.test.test_ansible_get_all_facts import TestModule

    test_module = TestModule()

# Generated at 2022-06-11 02:17:16.267636
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-11 02:17:28.298592
# Unit test for function ansible_facts
def test_ansible_facts():
    # stub out code the function needs to execute.
    class FakeModule():
        def __init__(self, gather_subset=None):
            self.params = {
                'gather_subset': gather_subset,
                'gather_timeout': 10,
                'filter': '*'
            }
    module = FakeModule(gather_subset=['network'])
    facts_dict = ansible_facts(module)
    assert isinstance(facts_dict, dict)
    assert len(facts_dict) > 0
    assert facts_dict['fqdn_ip4']['interfaces']['lo']['ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-11 02:17:31.536610
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    # Apply the function ansible_facts in order to test it
    try:
        ansible_facts(AnsibleModule, gather_subset=None)
    except TypeError:
        pass
    except Exception as e:
        raise e

# Generated at 2022-06-11 02:17:42.359857
# Unit test for function ansible_facts
def test_ansible_facts():
    module = get_ansible_module_mock()

    # set some expected return values
    module.params = dict(gather_subset=['all', 'network'])
    module.params.get.side_effect = lambda k, d=None: module.params[k]

    # gather_timeout is a float in seconds
    # get_all_facts expects a default timeout value of 10s
    module.params.get.side_effect = lambda k, d=None: module.params.get(k, d)

    # set some expected return values
    # gather_timeout is a float in seconds
    # ansible_facts expects a default timeout value of 10s
    module.params.get.side_effect = lambda k, d=None: module.params.get(k, d)

    # set some expected return values
    # get_

# Generated at 2022-06-11 02:17:52.577879
# Unit test for function ansible_facts
def test_ansible_facts():
    # This module is a stub - testing with a fake AnsibleModule.
    class AnsibleModule(object):

        def __init__(self, **kwargs):
            self.params = kwargs

    fake_module = AnsibleModule(gather_subset=['all'])
    facts = ansible_facts(fake_module)

    # need to make sure that the 'ansible_all_ipv4_addresses' fact is present
    # before we start using it to do more tests
    assert 'ipv4' in facts['all_ipv4_addresses']

    # test that the result is a plain dict with no key prefixes
    assert facts['ipv4']['default_ipv4']['address'] == facts['all_ipv4_addresses']['ipv4'][0]['address']



# Generated at 2022-06-11 02:18:02.808110
# Unit test for function get_all_facts
def test_get_all_facts():
    import mock
    from ansible.module_utils.facts.collector import BaseFactCollector

    module = mock.MagicMock()
    module.params = {'filter': '*', 'gather_subset': ['all']}
    module.get_option.side_effect = ['*', 'all']

    def collect(module=None):
        return {'fact_one': 'fact_one_value', 'fact_two': 'fact_two_value'}

    class Collector(BaseFactCollector):
        name = 'test_collector'
        _fact_class = collect
        _fact_ids = ['fact_one', 'fact_two']


# Generated at 2022-06-11 02:18:25.897680
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit test for ansible_facts, unit test api is different than AnsibleModule api, so we need
    to mock the module'''

    class AnsibleModule(object):

        def __init__(self, *args, **kwargs):
            self.params = {}

    module = AnsibleModule()
    module.params['gather_subset'] = ['all']
    facts = ansible_facts(module)

    assert facts
    assert facts['fqdn'] is not None
    assert facts['fqdn_ip4'] is not None
    assert facts['fqdn_ip6'] is not None

# Generated at 2022-06-11 02:18:33.514723
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import module_facts
    from ansible.compat.tests import unittest

    test_module = module_facts
    test_module.params = dict()

    class TestFactsHelper(unittest.TestCase):
        def test_ansible_facts(self):
            module = test_module
            ansible_facts_dict = ansible_facts(module)

            self.assertIsInstance(ansible_facts_dict, dict, 'ansible_facts should return a dict')
            self.assertGreater(len(ansible_facts_dict), 0, 'ansible_facts dict should not be empty')

    # run the tests
    suite = unittest.TestLoader().loadTestsFromTestCase(TestFactsHelper)
    unittest.TextTestRunner(verbosity=2).run

# Generated at 2022-06-11 02:18:40.356664
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    fake_module = FakeModule({'filter': None, 'gather_subset': ['!all', 'network']})

    facts_dict = ansible_facts(fake_module)

    assert 'network' in facts_dict
    assert len(facts_dict) == 1

# Generated at 2022-06-11 02:18:46.439241
# Unit test for function get_all_facts
def test_get_all_facts():

    import sys

    my_module = sys.modules['ansible.module_utils.facts']
    my_module.params = {'gather_subset': ['all']}

    all_facts = get_all_facts(my_module)

    # a test for the test
    assert 'default_ipv4' in all_facts

# Generated at 2022-06-11 02:18:56.770134
# Unit test for function ansible_facts
def test_ansible_facts():
    test_module = 'tests.unit.module_utils.facts.test_module_utils.TestAnsibleModule'
    test_subset = frozenset(['all', 'min', 'network', 'ohai'])

    # 2.3 has gather_subset on the module
    mock_module = get_mock_module(test_module, gather_subset=test_subset)

    # Get facts with gather_subset arg
    ansible_2_3_facts = ansible_facts(module=mock_module, gather_subset=test_subset)

    # Get facts without gather_subset arg
    ansible_2_2_2_facts = ansible_facts(module=mock_module)

    # Make sure the collect method was called with the module
    mock_module.assert_called_once_

# Generated at 2022-06-11 02:19:09.084140
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    if PY3:
        module = MockModule(gather_subset=['all'], filter='*', gather_timeout=10)
        gathered_facts = ansible_facts(module)
        actual_keys = sorted(list(gathered_facts.keys()))

# Generated at 2022-06-11 02:19:20.499377
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import shutil
    import tempfile
    import sys
    import time
    import unittest

    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, exe, required=False, opt_dirs=[]):
            ''' dummy - always return exe '''
            return exe

    class DummyModule(object):

        def __init__(self):
            self.debug = None
            self.fail_json = None
            self.warn = None

        def set_debug(self, debug):
            self.debug = debug

        def set_fail_json(self, fail_json):
            self.fail_json = fail_json

        def set_warn(self, warn):
            self.warn = warn



# Generated at 2022-06-11 02:19:32.336265
# Unit test for function ansible_facts
def test_ansible_facts():
    import json

    # Construct a mocked AnsibleModule impl
    class mocked_ansible_module(object):
        def __init__(self):
            self.params = dict()

        def set_filter(self, filter_spec):
            self.params['filter'] = filter_spec

        def set_gather_subset(self, gather_subset):
            self.params['gather_subset'] = gather_subset

        def set_gather_timeout(self, gather_timeout):
            self.params['gather_timeout'] = gather_timeout

    module = mocked_ansible_module()

    # Test with no gather_subset, and no filter_spec
    facts_dict = ansible_facts(module)
    print(json.dumps(facts_dict, indent=4))

    # Test with gather_subset

# Generated at 2022-06-11 02:19:42.778120
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit test for function ansible_facts

    Mock out the module object's params method to simulate params
    being passed to the module.

    '''

    # make a dummy module object with a fake params method that returns a mock params
    class FakeModule:
        def __init__(self):
            self.params = lambda: {}
    fake_module = FakeModule()

    # set gather_subset=['all'] and gather_timeout=10
    results = ansible_facts(fake_module)

    # the results should be non empty
    if not results:
        raise AssertionError("results is empty!")

    # TODO: add further assertions

# Generated at 2022-06-11 02:19:49.515033
# Unit test for function get_all_facts
def test_get_all_facts():
    def my_fail_json(msg):
        raise RuntimeError("my_fail_json({0!r}) was called".format(msg))

    class FauxModule(object):
        def __init__(self, params):
            self.params = params
            self.changed = False  # for compat with ansible 2.2/2.3

        def fail_json(self, msg):
            my_fail_json(msg)

    module = FauxModule(params=dict(gather_subset=['all']))
    expected_facts = ansible_facts(module)
    actual_facts = get_all_facts(module)
    assert expected_facts == actual_facts

# Generated at 2022-06-11 02:20:23.330715
# Unit test for function get_all_facts
def test_get_all_facts():

    class FakeModule(object):
        def __init__(self, gather_subset=None, **kwargs):
            self.params = kwargs
            self.params['gather_subset'] = gather_subset

    module = FakeModule(gather_subset=('all'))
    fact_collector = get_all_facts(module)

    assert fact_collector



# Generated at 2022-06-11 02:20:28.670074
# Unit test for function get_all_facts
def test_get_all_facts():

    class MockModule:

        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    module = MockModule(['platform', 'network'])
    facts = get_all_facts(module)

    assert len(facts) > 0



# Generated at 2022-06-11 02:20:36.732953
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import get_all_facts

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': 'all'}
    module = TestModule(params)
    all_facts = get_all_facts(module)
    assert 'ansible_default_ipv4' in all_facts

# Generated at 2022-06-11 02:20:43.099862
# Unit test for function ansible_facts
def test_ansible_facts():
    class MockModule(object):
        pass
    module = MockModule()
    module.params = dict(gather_subset=['all'], gather_timeout=10, filter='*', hosted_by=None,
                         managed_by=None)
    all_facts = ansible_facts(module)
    assert 'lsb' in all_facts
    assert 'default_ipv4' in all_facts
    assert 'default_interface' in all_facts
    assert 'default_ipv4' in all_facts
    assert 'hostname' in all_facts

# Generated at 2022-06-11 02:20:51.071701
# Unit test for function get_all_facts
def test_get_all_facts():
    import gc
    import re
    import time
    import copy

    import unittest

    try: # ansible.module_utils.facts.get_all_facts available >= 2.2
        from ansible.module_utils.facts import get_all_facts
        no_get_all_facts = False
    except ImportError:
        no_get_all_facts = True

    # import module snippets

# Generated at 2022-06-11 02:21:00.855999
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import namespace
    from ansible.module_utils.basic import AnsibleModule

    class AnsibleModuleSubclass(AnsibleModule):
        def __init__(self, *args, **kwargs):
            AnsibleModule.__init__(self, *args, **kwargs)

    # test with no gather_subset
    module_params = {
        'filter': 'ansible_lsb'
    }
    module = AnsibleModuleSubclass(argument_spec=dict(),
                                   supports_check_mode=True,
                                   module_params=module_params)
    facts_dict = module_utils_facts_ansible_facts.ansible_facts(module)
    assert(len(facts_dict) == 1)

# Generated at 2022-06-11 02:21:12.884574
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeCollector(object):
        def __init__(self, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.minimal_gather_subset = minimal_gather_subset

        def collect(self, module):
            return {'foo': 'bar'}

    class FakeCollectorPlugin(object):
        def __init__(self, collectors):
            self.collectors = collectors

        def get_collector_classes(self):
            return self.collectors

# Generated at 2022-06-11 02:21:20.622841
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import module_proto
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    module = module_proto.get_base_protocol()
    module.params['gather_subset'] = 'all'

    # run the function we want to test
    facts = get_all_facts(module)

    # Make sure results look like ansible_facts
    assert list(facts.keys()) == list(ansible_facts(module).keys())


# Generated at 2022-06-11 02:21:32.118921
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.network
    from ansible.module_utils.facts.virtual import BaseVirtual

    # Mock some facts
    class module:
        params = {'gather_subset': ['network']}

    class MockProvider:
        def get_interfaces(self):
            return {'eth0': {'device': 'eth0', 'inet': '192.168.1.1', 'netmask': '255.255.255.0'},
                    'loop0': {'device': 'loop0', 'inet': '127.0.0.1', 'netmask': '255.0.0.0'},
                    'eth1': {'device': 'eth1', 'inet': '100.100.100.100', 'netmask': '255.0.0.0'}}

    ansible.module

# Generated at 2022-06-11 02:21:38.666755
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_text
    from ansible.module_utils import basic

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    module_params = dict(
        _ansible_module=MockModule(params=dict()),
        gather_subset=['all'],
    )
    # minimal facts like 'distribution' don't require any module params
    facts = get_all_facts(MockModule(params=module_params))
    assert 'ansible_distribution' in facts
    assert 'ansible_distribution_version' in facts
    assert 'ansible_distribution_release' in facts

    # more complicated facts like 'ipv4' might