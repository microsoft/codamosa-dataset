

# Generated at 2022-06-11 02:11:52.647865
# Unit test for function ansible_facts
def test_ansible_facts():
    def test_module(module):
        module.params['gather_subset'] = '!all,!min,!not_there'
        return ansible_facts(module)

    result = {'ansible_architecture': 'x64',
              'ansible_distribution': 'Ubuntu',
              'ansible_distribution_release': 'xenial',
              'ansible_distribution_version': '16.04',
              'ansible_os_family': 'Debian',
              'ansible_os_name': 'Ubuntu',
              'ansible_os_version': '16.04'}

    assert result == test_module(AnsibleModule(argument_spec={'gather_subset': {'type': 'list', 'elements': 'str'}}))

# Generated at 2022-06-11 02:12:03.578930
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.common.process import get_bin_path

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    params = dict(gather_subset=['!all', 'aix', '!network', '!cmdline'])
    module = TestModule(params=params)
    facts = get_all_facts(module)

    if get_bin_path('uname') is None:
        # aix fact not available
        assert 'aix' not in facts
    else:
        assert 'aix' in facts

    assert 'ansible_cmdline' not in facts

    # fact disabled by !network
    assert 'ansible_default_ipv4' not in facts



# Generated at 2022-06-11 02:12:09.650031
# Unit test for function ansible_facts
def test_ansible_facts():

    # simple test for function ansible_facts
    MockAnsibleModule = MockAnsibleModuleClass()
    modules_facts = ansible_facts(MockAnsibleModule)
    # check that at least the 'os' fact is returned
    assert 'os' in modules_facts.keys()


# ansible-2.2/2.3 compat shim function, used by ansible-doc:

# Generated at 2022-06-11 02:12:12.910994
# Unit test for function ansible_facts
def test_ansible_facts():
    module = 'dummy_module'
    ansible_facts_result = ansible_facts(module)
    assert 'ansible_default_ipv4' in ansible_facts_result

# Generated at 2022-06-11 02:12:21.891724
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import DEFAULT_GATHER_SUBSET
    from ansible.module_utils.facts import DEFAULT_GATHER_TIMEOUT
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.basic import AnsibleModule, ModuleFailException


# Generated at 2022-06-11 02:12:33.143581
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys

    class FakeModule(object):
        '''Fake module class to use in testing get_all_facts.
        The methods of this class are dynamically generated in the
        AnsibleModule.__init__() method.
        '''

        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']

    fake_module = FakeModule()
    facts_dict = get_all_facts(fake_module)

    assert isinstance(facts_dict, dict)
    assert len(facts_dict) > 0
    assert 'distribution' in facts_dict
    assert facts_dict['distribution'] == 'Unknown'
    assert 'default_ipv4' in facts_dict

# Generated at 2022-06-11 02:12:44.866426
# Unit test for function get_all_facts
def test_get_all_facts():
    # unit test for module ansible.module_utils.facts.get_all_facts
    # NOTE: this test is not checked into git, as we don't want
    # unit tests checked into the module_util directory.
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    # set defaults for module
    module.params['gather_subset'] = frozenset(['all'])
    module.params['gather_timeout'] = 10

    # test that get_all_facts is proxying to ansible_facts with no args
    assert get_all_facts(module=module) == ansible_facts(module=module)


# Generated at 2022-06-11 02:12:53.096878
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Verify that ansible_facts function returns some basic facts.'''

    # Import required modules

    # Create an AnsibleModule mock object
    module = MockAnsibleModule()

    # populate the ansible_facts
    ansible_facts(module)

    # check a few facts
    assert module.ansible_facts['lsb']['id'] == 'CentOS'
    assert module.ansible_facts['lsb']['release'] == '6.9'
    assert module.ansible_facts['lsb']['distro'] == 'CentOS'



# Generated at 2022-06-11 02:13:01.512855
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PackageManagerFactCollector

    # mocking base_class
    class BaseFactCollector(object):
        def __init__(self, *args, **kwargs):
            self.gather_subset = kwargs['gather_subset']
            self.filter_spec = kwargs['filter_spec']
            self.gather_timeout = kwargs['gather_timeout']

        def collect(self):
            pass

    # mocking classes

# Generated at 2022-06-11 02:13:07.369918
# Unit test for function get_all_facts
def test_get_all_facts():

    from ansible.compat.tests.mock import MagicMock
    from module_utils.facts import ansible_facts
    from module_utils.facts import get_all_facts

    module = MagicMock()
    module.params = {"gather_subset": ["all"],
                     "filter": "*"}

    res = get_all_facts(module)

    # get_all_facts should be exactly the same as ansible_facts
    assert res == ansible_facts(module)

# Generated at 2022-06-11 02:13:18.711054
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import NamespaceFactsCollector
    from ansible.module_utils.facts import ansible_collector

    module = FakeModule()
    module.params['gather_subset'] = ['all']

    # Mock the call to get_ansible_collector to return a fake which just returns a pre-determined
    # facts dictionary
    expected_facts = {'fact1': 1, 'fact2': 2}

    def fake_get_ansible_collector(all_collector_classes, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
        return FakeAnsibleFactCollector(expected_facts=expected_facts)

    old_get_ansible_collector = ansible_collector.get_ansible_collector
   

# Generated at 2022-06-11 02:13:23.390355
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    fact_dict = ansible_facts(module)
    assert 'fqdn' in fact_dict

# Generated at 2022-06-11 02:13:29.479409
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import FactsModule
    class MockModule(object):
        def __init__(self, gather_subset=None):
            self.params = {'gather_subset': gather_subset}

    facts = get_all_facts(MockModule())
    assert isinstance(facts, dict)

    facts = get_all_facts(MockModule(gather_subset=['all']))
    assert isinstance(facts, dict)



# Generated at 2022-06-11 02:13:39.493598
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.core import ansible_facts_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'
    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    all_collect

# Generated at 2022-06-11 02:13:50.998839
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    import ansible.module_utils.facts

    # Create a fake AnsibleModule class
    class FakeAnsibleModule:
        params = {
            'gather_subset': ['all'],
            'filter': '*'
        }

    module = FakeAnsibleModule()

    # Test
    actual = ansible_facts(module, gather_subset=['hardware', 'virtual'])

    assert(actual is not None)
    assert(set(actual.keys()).issuperset(set(['virtual', 'default_ipv4'])))
    assert(actual['virtual'] == 'physical')
    assert('ipv4' in actual['default_ipv4'])

# Generated at 2022-06-11 02:14:02.605347
# Unit test for function get_all_facts
def test_get_all_facts():
    module_args = dict(gather_subset=['all'])


# Generated at 2022-06-11 02:14:11.473549
# Unit test for function ansible_facts
def test_ansible_facts():

    class AnsibleModuleFake(object):
        '''Fake enough of AnsibleModule that the ansible_facts function will run,
        and we can check the output

        '''

        def __init__(self):
            self.params = {'gather_subset': ['all'],
                           'filter': '*',
                           'gather_timeout': 10}

        def get_bin_path(self, exe, required=False, opt_dirs=[]):
            # Fake a return value for /bin/sh
            return '/bin/sh'

        def fail_json(self, **kwargs):
            print("FAILED")
            print(kwargs)
            return kwargs

        def exit_json(self, **kwargs):
            print("SUCCEEDED")
            print(kwargs)
            return

# Generated at 2022-06-11 02:14:22.103367
# Unit test for function ansible_facts
def test_ansible_facts():

    class FakeAnsibleModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    # gather all the facts
    facts = ansible_facts(FakeAnsibleModule(gather_subset='all'))

    # test that all facts were gathered.
    assert facts['distribution'] == 'CentOS'
    assert facts['architecture'] == 'x86_64'
    assert isinstance(facts['memory_mb'], int) and facts['memory_mb'] > 0
    assert facts['ipv4']['default_route'] == '172.16.35.254'
    assert facts['ipv6']['default_route'] == 'fe80::30e5:49ff:fedc:e9aa'

# Generated at 2022-06-11 02:14:31.166603
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        from ansible.module_utils.ansible_release import __version__
    except ImportError:
        return
    if __version__[0] >= '2':
        import pytest

        fake_module = FakeModule()
        ansible_facts_returned = ansible_facts(fake_module)

        assert ansible_facts_returned['cmdline'] == {u'nfsroot': u'10.81.0.10:/nfsshare/fake_hostname', u'console': u'console=tty0'}
        # assert ansible_facts_returned['default_ipv4'] == {u'address': u'192.168.1.10', u'alias': u'eth0:0', u'mask': u'255.255.255.0', u'macaddress': u'00:50

# Generated at 2022-06-11 02:14:32.049156
# Unit test for function ansible_facts
def test_ansible_facts():
    # TODO: Add a unit test
    pass

# Generated at 2022-06-11 02:14:47.059758
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system import distribution
    import mock
    import os

    class MockModule():
        def __init__(self):
            self.params = {}

    module = MockModule()
    module.params['gather_subset'] = ['all']
    module.params['filter'] = '*'

    mock_module = mock.MagicMock(name='AnsibleModule')
    mock_module.params = {'gather_subset': ['all'], 'filter': '*'}
    mock_module.check_mode = False

    mock_dist_collector = mock.MagicMock(name='DistributionFactCollector')

# Generated at 2022-06-11 02:14:59.749841
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    assert sys.version_info[0] == 2
    import platform
    import time

    class MockModule(object):
        def __init__(self, params=None):
            self.params = params if params else dict()

    all_params = dict(
        gather_subset='all'
    )

    minimal_params = dict(
        gather_subset='minimal'
    )

    os_min_params = dict(
        gather_subset='!config,!fips'
    )


# Generated at 2022-06-11 02:15:02.192442
# Unit test for function ansible_facts
def test_ansible_facts():
    # This function tests the functionality of ansible_facts()
    # No test case as it is hard to mock the module
    pass

# Generated at 2022-06-11 02:15:06.340925
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        import ansible.module_utils.basic
    except ImportError:
        pass  # don't do test
    else:
        module = ansible.module_utils.basic.AnsibleModule({}, {})
        # test we can load the ansible_facts function
        ansible_facts(module)

# Generated at 2022-06-11 02:15:14.871730
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector

    class TestNetworkCollector(NetworkCollector):
        def collect(self, module=None, collected_facts=None):
            collected_facts = dict()
            collected_facts['foo_fact'] = 'foo value'
            return collected_facts

    collector_class = TestNetworkCollector()

    test_module = MagicMock()
    test_module.params = {
        'gather_subset': ['foo', 'network', 'virtual']
    }

    result = get_all_facts(test_module)
    assert result['foo_fact'] == 'foo value'

# Generated at 2022-06-11 02:15:21.811596
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts

    module_mock = MockAnsibleModule()
    module_mock.get_bin_path.return_value = 'testing'
    module_mock.params = {'filter': '*',
                          'gather_subset': ['!all', 'network'],
                          'gather_timeout': 10}

    result = get_all_facts(module_mock)

    assert result['default_ipv4']['address'] == '10.10.10.10'
    assert result['os_family'] == 'suse'



# Generated at 2022-06-11 02:15:33.392246
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.compat.tests.mock import MagicMock
    from ansible.module_utils.facts import collector
    import collections

    class MockAnsibleModule:
        def __init__(self, params=None, facts=None):
            self.params = params or {}
            self.facts = facts or {}

        def exit_json(self, *args, **kwargs):
            self.exit = kwargs['ansible_facts']

        def fail_json(self, *args, **kwargs):
            pass

    class TestCollector(collector.BaseFactCollector):
        name = 'test'
        _fact_ids = [('test_fact', None)]

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test'}

    # test that

# Generated at 2022-06-11 02:15:40.817799
# Unit test for function ansible_facts
def test_ansible_facts():

    # mock an AnsibleModule
    class FakeAnsibleModule():
        def __init__(self):
            self.params = {
                'gather_subset': ['all'],
                'filter': '*',
            }

    module = FakeAnsibleModule()

    facts_dict = ansible_facts(module)

    assert facts_dict is not None, "Expected non-None facts_dict"

# Generated at 2022-06-11 02:15:47.369950
# Unit test for function ansible_facts
def test_ansible_facts():
    # TODO: use unittest or similar
    print('put unit test here')

    # TODO: The existence of fact collectors should be a sufficient test
    #       need to be able to mock a module param???
    # TODO: The current code exports the fact collectors to a global variable, that should be fixed!

# NOTE: Don't delete this simply for test code, it has production value

# Generated at 2022-06-11 02:15:57.642501
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    unit test for the ansible_facts function.

    Test the function ansible_facts by mocking the ansible.module_utils.facts.collector.BaseFactCollector
    and the main() function of an ansible module
    '''
    import copy
    import unittest
    import logging
    import sys
    import mock
    # Prevent the logger from logging to stderr in the unit test
    logging.getLogger('ansible').addHandler(logging.NullHandler())
    # The mocked logger
    mock_logger = mock.MagicMock()
    mock_logger.name = 'mock_logger'
    # Mock the logging.getLogger function
    get_logger_patcher = mock.patch('ansible.module_utils.facts.collector.getLogger')
    mock_get_

# Generated at 2022-06-11 02:16:18.395109
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors

    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'

    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    all_collector_classes = default_collectors.collectors

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')



# Generated at 2022-06-11 02:16:28.146755
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    import doctest
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['all'])))
    # use the method itself to test it has the right return value
    my_facts = ansible_facts(module=module)
    assert isinstance(my_facts, dict), "ansible_facts must return a dict"
    assert (len(my_facts) > 0), "ansible_facts must return a non-empty dict"
    assert "default_ipv4" in my_facts, "ansible_facts must contain default_ipv4 key"
    doctest.testmod()

# Generated at 2022-06-11 02:16:37.603233
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    import sys

    class MockModule():
        class AnsibleModule(AnsibleModule):
            def __init__(self, *args, **kwargs):
                pass
    mock_module = MockModule()

    class MockAnsibleModule(mock_module.AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.facts = {'some_fact': 'foo'}

    class MockCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-11 02:16:49.035996
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import os
    import sys
    import tempfile
    import subprocess

    # Add the root of the source code to sys.path
    # This allows the tests to locate the ansible module utils code
    ansible_repo_root = subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], universal_newlines=True).rstrip()
    sys.path.insert(0, ansible_repo_root)

    # mock module
    class MockModule:
        def get_option(self, arg):
            return 'all'

        def fail_json(self, msg):
            raise Exception(msg)

        def exit_json(self, **kwargs):
            return kwargs

    mock_module = MockModule()

# Generated at 2022-06-11 02:17:00.248421
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.facts import ansible_facts

    class TestModule(object):
        def __init__(self, params=None, version='2.4'):
            self.params = params
            self.ansible_version = version

    class TestSubsetCollectors(object):
        def __init__(self, params=None, version='2.4'):
            self.params = params
            self.ansible_version = version

        def __iter__(self):
            return iter(self.params)

        def set_subset(self, subset):
            self.subset = subset

    class TestModuleMock(object):
        def __init__(self, module):
            self

# Generated at 2022-06-11 02:17:00.923898
# Unit test for function ansible_facts
def test_ansible_facts():
    pass


# Generated at 2022-06-11 02:17:07.103667
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.basic import AnsibleModule
    import json

    SUCCESS = True
    FAILED = False

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    module = MockModule(gather_subset=[])
    ansible_facts = get_all_facts(module)
    assert SUCCESS



# Generated at 2022-06-11 02:17:15.560993
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    import mock
    import sys

    kwargs = {'params': {'filter': '*'}}
    module = mock.Mock(**kwargs)

    # test the facts
    facts_dict = ansible_facts(module)

    # show the facts
    if sys.version_info.major == 3:
        from pprint import pprint as pp
    else:
        from pprint import pp
    pp(facts_dict)


if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-11 02:17:27.580840
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    test the ansible_facts function returns the expected keys, and that the values
    for the pkg_mgr fact are in the expected format.
    '''
    import ansible.module_utils.facts.ansible_facts as af
    import os
    import tempfile

    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts import default_collectors

    # basic subclass of AnsibleModule with params as used in a typical module.
    class Module(object):
        def __init__(self):
            self.params = {
                'gather_subset': ['all'],
                'gather_timeout': 10,
                'filter': '*'
            }

        def exit_json(self, **kwargs):
            pass


# Generated at 2022-06-11 02:17:34.331202
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.network

    from ansible.module_utils.facts.network.base import NetworkCollector

    def get_module():
        class AnsibleModule(object):
            def __init__(self, *args, **kwargs):
                self.params = {}

        mod = AnsibleModule()
        mod.params = {}
        mod.params['ansible_connection'] = 'test'
        return mod

    module = get_module()

    old_collector_class = ansible.module_utils.facts.network.base.NetworkCollector
    # monkey patch to mock network facts collector
    ansible.module_utils.facts.network.base.NetworkCollector = NetworkCollector


# Generated at 2022-06-11 02:17:59.756561
# Unit test for function get_all_facts
def test_get_all_facts():
    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(type='list', default=['all'])
    ))

    # create a mock find_blockdev to run with
    class MockModule(object):
        def __init__(self, module):
            self.module = module
            self.params = module.params

            self.called_module = None

        def _execute_module(self, *args, **kwargs):
            self.called_module = args[1]

    with mock.patch.object(ansible.module_utils.facts, 'default_collectors') as mock_collectors:
        mock_collectors.collectors = [
            {'name': 'test_collector', 'class_name': 'TestCollector'}
        ]

# Generated at 2022-06-11 02:18:06.517948
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Basic test of get_all_facts'''

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    facts_dict = get_all_facts(MockModule())
    assert 'distribution' in facts_dict
    assert 'distribution' in facts_dict
    assert 'default_ipv4' in facts_dict


# Generated at 2022-06-11 02:18:12.768651
# Unit test for function get_all_facts
def test_get_all_facts():

    print("Testing get_all_facts using mock_ansible_module")

    # setting up a mock ansible module class
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {
                'gather_subset': ['all']
            }

    mm = MockAnsibleModule()

    # calling the method
    ansible_facts = get_all_facts(mm)

    assert ansible_facts is not None, "ansible_facts not populated"

# Generated at 2022-06-11 02:18:15.912987
# Unit test for function ansible_facts
def test_ansible_facts():
    ansible_facts_result = ansible_facts(module=None)

    assert_correct_ansible_facts_result(ansible_facts_result)



# Generated at 2022-06-11 02:18:27.408460
# Unit test for function get_all_facts
def test_get_all_facts():
    """Return all the facts"""
    # Import the module we want to test
    module = __import__('ansible.module_utils.facts')

    # Mock AnsibleModule and instantiate an instance of it
    class module_mock:
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = 'all'
    module = module_mock()

    # Call the function we want to test
    ansible_facts = module.get_all_facts()

    # Assert the results
    assert ansible_facts
    assert type(ansible_facts) == dict
    assert 'ansible_architecture' in ansible_facts
    assert 'ansible_machine' in ansible_facts
    assert 'ansible_distribution' in ansible_facts

# Generated at 2022-06-11 02:18:38.502160
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.network.base as fact_network_base

    class MockAnsibleModule(object):
        def __init__(self, params={}):
            self.params = params
            self.fail_json = lambda xx,yy: None

    module = MockAnsibleModule()
    # test with default gather_subset
    facts = ansible_facts(module)
    assert isinstance(facts, dict)
    assert 'default_ipv4' in facts
    assert isinstance(facts['default_ipv4'], dict)
    assert 'address' in facts['default_ipv4']
    assert 'network' in facts['default_ipv4']
    assert 'netmask' in facts['default_ipv4']
    assert 'prefix' in facts['default_ipv4']

# Generated at 2022-06-11 02:18:39.171781
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-11 02:18:48.586897
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import unittest
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.system import SystemCollector
    from ansible.module_utils.facts.system.distribution import DistributionCollector

    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_native
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    try:
        from unittest import mock
    except ImportError:
        import mock


# Generated at 2022-06-11 02:18:53.688154
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['network', 'hardware', 'virtual'],
                           'gather_timeout': 10,
                           'filter': '*',
                           'verbosity': 3
                           }

    module = FakeModule()

    facts = ansible_facts(module)
    assert facts['virtualization_role'] == 'guest'
    assert facts['distribution'] == 'RedHat'
    assert facts['distribution_major_version'] == '7'
    assert facts['distribution_version'] == '7.2'



# Generated at 2022-06-11 02:19:03.382094
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts

    # Gather all facts
    facts = get_all_facts()
    assert 'ansible_default_ipv4' in facts

    # Gather only default facts
    facts = get_all_facts(gather_subset=['default'])
    assert 'ansible_default_ipv4' in facts

    # Gather only network facts
    facts = get_all_facts(gather_subset=['network'])
    assert 'ansible_default_ipv4' in facts



# Generated at 2022-06-11 02:19:59.540228
# Unit test for function ansible_facts
def test_ansible_facts():
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/facts/__init__.py#L197
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/facts/__init__.py#L890

    import ansible.module_utils.facts
    from ansible.module_utils.facts import default_collectors

    # ansible.module_utils.facts.DEFAULT_GATHER_TIMEOUT = 1234

    def stub_ansible_module():
        '''returns a stub AnsibleModule with parameters for gather_subset=all,
        gather_timeout=1234, filter=*'''


# Generated at 2022-06-11 02:20:08.827505
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils._text import to_native

    # Test imports
    from ansible.module_utils.basic import AnsibleModule
    import json

    def run_module():
        module_args = dict(
            gather_subset='all',
            gather_timeout=10,
        )
        module_args.update(dict())

        tmp_values = dict(
            ANSIBLE_MODULE_ARGS=module_args,
        )

# Generated at 2022-06-11 02:20:12.009981
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    facts = ansible_facts(module, gather_subset=['all'])

    assert 'default_ipv4' in facts

# Generated at 2022-06-11 02:20:22.534989
# Unit test for function ansible_facts
def test_ansible_facts():

    # The AnsibleModule Mock
    class AnsibleModuleMock(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        # Each time get_bin_path is called, return a different path
        def get_bin_path(self, arg, opt_dirs=[]):
            paths = ['/usr/bin', '/usr/sbin', '/bin', '/sbin']
            return paths[self.get_bin_path.callcount % len(paths)]

        get_bin_path.callcount = 0

    # Call ansible_facts with gather_subset
    gather_subset = ['kernel', 'network']
    gather_timeout = 25

# Generated at 2022-06-11 02:20:27.598737
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts

    module = ansible.module_utils.facts.get_ansible_module()
    print(module)

    ansible.module_utils.facts.ansible_facts(module)

if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-11 02:20:39.446651
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.network.default as network_facts
    import ansible.module_utils.facts.system.default as system_facts
    import ansible.module_utils.facts.virtual.default as virtual_facts

    # class AnsibleModule is an abstract class, so hack an instance of it
    # by dynamically inheriting from it, and adding the minimum needed attrs
    # which ansible.module_utils.facts.ansible_collector needs
    class AnsibleModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, app, opt_dirs=[]):
            if app == 'ip':
                # pretend ip is at /bin/ip
                return '/bin/ip'

# Generated at 2022-06-11 02:20:47.083559
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts as facts_mod

    my_module = facts_mod.AnsibleModule()

    def test_module_func(*args, **kwargs):
        return {'ansible_facts': ansible_facts(my_module)}

    my_module.exit_json = test_module_func

    facts_collectors = [
        'all', 'hardware', 'network',
        'virtual', 'facter', 'ohai', 'systemd', 'puppet',
        'augeas', 'setup', 'pkg_mgr', 'service_mgr', 'minimal',
        'command', 'parsers'
    ]


# Generated at 2022-06-11 02:20:51.742613
# Unit test for function ansible_facts
def test_ansible_facts():
    # pylint: disable=redefined-outer-name
    # pylint: disable=too-many-branches,too-many-locals,too-many-statements

    from ansible.module_utils import basic
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    module = basic.AnsibleModule(
        argument_spec={'gather_subset': dict(type='list', default=['all']),
                       'gather_timeout': dict(type='int', default=10),
                       'filter': dict(type='str', default='*')},
        supports_check_mode=True)


# Generated at 2022-06-11 02:21:01.927897
# Unit test for function get_all_facts
def test_get_all_facts():
    import unittest
    import mock
    import json
    import re

    class MockAnsibleModule:
        def __init__(self, params):
            self.params = params

    class TestGetAllFacts(unittest.TestCase):
        def test_get_all_facts_gather_subset_all(self):
            module = MockAnsibleModule({'gather_subset': ['all']})
            facts = get_all_facts(module)

            # We need to use a dict for our comparison because
            # some facts are unpredictable (they contain timestamps or
            # other dynamically generated values)
            # At the same time we don't want to just compare the JSON
            # because that could lead to false negatives if the same
            # data is in a different order in the dict.
            # So we normalize the

# Generated at 2022-06-11 02:21:13.520110
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.basic import AnsibleModule
    import os
    import pytest
    mock_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=None, type='list'),
            gather_timeout=dict(default=10, type='int'),
            filter=dict(default='*', type='str'),
        ),
    )
    mock_module.params['gather_subset'] = ['!all']
    mock_module.params['gather_timeout'] = 10
    mock_module.params['filter'] = '*'