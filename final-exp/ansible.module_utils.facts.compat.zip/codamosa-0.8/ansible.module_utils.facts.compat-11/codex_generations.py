

# Generated at 2022-06-11 02:11:47.780458
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    unit test for get_all_facts.
    '''
    class MockModule():
        def __init__(self, params):
            self.params = params
        def fail_json(self, **kwargs):
            pass

    # params
    params = dict(gather_subset = ['all'])
    # test
    module = MockModule(params)
    ansible_facts = get_all_facts(module)
    assert isinstance(ansible_facts, dict)


# Generated at 2022-06-11 02:11:56.511619
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes

    class FakeFactsModule(object):
        '''fake AnsibleModule

        implements the required params getter, so we can use the real code in ansible_collector
        '''
        def __init__(self, params):
            self._params_dict = params

        def params(self):
            return self._params_dict


    params = {'gather_subset': ['all'],
               'gather_timeout': 10}

    module = FakeFactsModule(params)

    all_collector_classes = default_collectors.collect

# Generated at 2022-06-11 02:12:05.723797
# Unit test for function ansible_facts
def test_ansible_facts():
    import unittest
    import mock

    class FakeModule(object):
        def __init__(self, params=None):
            super(FakeModule, self).__init__()
            self.params = params or {}

        def fail_json(self, **kwargs):
            raise Exception('fail_json called')

    class TestAnsibleFacts(unittest.TestCase):
        def test_get_all_facts_with_no_params_defaults_to_gather_subset_all(self):
            mock_module_instance = FakeModule()
            ansible_facts(mock_module_instance)
            self.assertEqual(mock_module_instance.params['gather_subset'], ['all'])


# Generated at 2022-06-11 02:12:14.329487
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.six import iteritems

    # Test importing ansible_facts() function
    from ansible.module_utils.facts.network.iosxr import ansible_facts

    # Test importing the AnsibleModule mock from module_utils
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 02:12:21.679408
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import shutil
    sys.path.append('/usr/share/ansible')
    from ansible.module_utils._text import to_bytes

    class MockAnsibleModule():
        def __init__(self, gather_subset=None):
            self.params = {}
            if gather_subset:
                self.params['gather_subset'] = gather_subset

            self.tmpdir = None

        def exit_json(self, **kwargs):
            assert isinstance(kwargs['ansible_facts'], dict)
            assert 'lsb' in kwargs['ansible_facts']
            assert 'distribution' in kwargs['ansible_facts']['lsb']
            assert 'id' in kwargs['ansible_facts']['lsb']

# Generated at 2022-06-11 02:12:33.002084
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.ansible_collector import get_all_collector_classes
    from ansible.module_utils.facts import default_collectors

    class DummyModule:
        def __init__(self):
            self.params = dict()
            self._socket_path = None

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/bin/' + arg

        def get_ansible_version(self):
            return (2, 3, 0)

    dummy_module = DummyModule()

    results = ansible_facts(dummy_module)

    # check that all the collectors return a dict.
    # dict value should be a string, but we don't check that.
    #

# Generated at 2022-06-11 02:12:44.742145
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector.linux import DistributionCollector

    assert ansible_facts(AnsibleModule(argument_spec={}))

    mock_module = AnsibleModule(argument_spec={})
    mock_module.params = {
        'gather_subset': ['all'],
        'gather_timeout': 10,
        'filter': '*',
    }

    result = ansible_facts(mock_module)
    assert result
    assert isinstance(result.get('distribution'), DistributionCollector.distribution)


# Generated at 2022-06-11 02:12:56.558024
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import ansible.module_utils.facts.namespace

    class MyFactsCollector(ansible_collector.BaseFactCollector):
        name = 'my_fact_collector'
        mandatory_facts = frozenset()

        def collect(self, module=None, collected_facts=None):
            return {'my_fact': 'value'}

    class MyNamespace(PrefixFactNamespace):
        namespace_name = "ansible"
        prefix = "my_prefix"

    all_collectors = list(default_collectors.collectors)

# Generated at 2022-06-11 02:13:07.780212
# Unit test for function ansible_facts
def test_ansible_facts():
    import re
    import yaml
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.basic import AnsibleModule

    # capture real global env, and restore after test is done
    test_data = {
        'GATHER_SUBSET': None,
        'GATHER_TIMEOUT': None,
        'FILTER': None,
        'DEFAULT_GATHER_TIMEOUT': None,
        'DEFAULT_GATHER_SUBSET': None,
        'DEFAULT_FILTER': None,
    }

    for key in test_data:
        val = globals().get(key, None)
        test_data[key] = val
        globals()[key] = None


# Generated at 2022-06-11 02:13:13.011227
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        from ansible.module_utils.facts import get_all_facts as _get_all_facts
        _get_all_facts
    except ImportError:
        # If _get_all_facts doesn't exist then neither does get_all_facts
        from ansible.module_utils.facts import get_all_facts
        assert get_all_facts is None



# Generated at 2022-06-11 02:13:26.523770
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import sys

    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.basic import AnsibleModule

    import ansible.module_utils.facts.virtual.smartos as virtual_smartos

    class MockModule(object):
        '''mock module object for unit testing facts module

        This is an example, and not exhaustive for all possible facts
        '''
        def __init__(self):
            self.params = {'filter': '*', 'gather_subset': ['all'],
                           'gather_timeout': 10}

    # fact function to return a mocked 'virtual' fact, to test the smartos fact
    # plugin

# Generated at 2022-06-11 02:13:37.889054
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    class FakeAnsibleModule(AnsibleModule):
        def __init__(self):
            # In AnsibleModule, self.params is a dict
            # But in FakeAnsibleModule, self.params is a dict-like object that returns None for missing keys
            self.params = FakeModuleParams()
            self.fail_json = lambda msg: msg

        # fake the exit_json and fail_json methods

    class FakeModuleParams(object):
        def __init__(self):
            # fake the module parameters
            self.ansible_facts_gather_timeout = 10
            self.ansible_facts_gather_subset = ['all']

# Generated at 2022-06-11 02:13:50.318526
# Unit test for function ansible_facts
def test_ansible_facts():
    import collections
    import sys
    from ansible.module_utils import facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.processor.network import _default_ipv4, _default_ipv6
    from ansible.module_utils.facts.system.network import get_default_ipv4, get_default_ipv6

    from ansible.module_utils.facts.system.system import SystemCollector
    from ansible.module_utils.facts.system.distribution import DistributionCollector
    from ansible.module_utils.facts.virtual.hyperv import HypervCollector
    from ansible.module_utils.facts.virtual.lxc import LxC
    from ansible.module_utils.facts.virtual.openvz import OpenVZ

# Generated at 2022-06-11 02:14:01.571737
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    class Module(object):
        def __init__(self, params):
            self.params = params

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    # patch out the ansible_facts function so it returns a default value
    with patch('ansible.module_utils.facts.ansible_collector.get_ansible_collector') as mock_get_ansible_collector:
        with patch('ansible.module_utils.facts.collector.CollectorExecution.collect') as mock_collect:

            mock_ans

# Generated at 2022-06-11 02:14:10.732986
# Unit test for function ansible_facts
def test_ansible_facts():
    # Unit test for function ansible_facts

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils._text import to_bytes

    from mock import Mock
    from ansible.module_utils import basic
    import sys

    class TestAnsibleModule(basic.AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestAnsibleModule, self).__init__(*args, **kwargs)

            self.check_mode = False
            self.no_log = False

    # test the ansible_facts() method of module_utils/facts.py
    # requires a module argument

   

# Generated at 2022-06-11 02:14:19.615550
# Unit test for function ansible_facts
def test_ansible_facts():

    import pytest

    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    test_module = FakeModule()

    # mocked ansible_facts does not require the module passed in to have
    # any of the specific 'gather_subset', 'gather_timeout', or 'filter' params.
    with pytest.raises(SystemExit) as excinfo:
        ansible_facts(test_module)
    assert excinfo.value.code == 0
    facts_dict = ansible_facts(test_module)
    assert isinstance(facts_dict, dict)



# Generated at 2022-06-11 02:14:29.393160
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system import Distribution
    from ansible.module_utils.facts.system import DistributionLegacyArchive
    from ansible.module_utils.facts.system.distribution import RedhatFactCollector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    import os

    # Mock a Distribution() instance and place in the module_utils.facts.system.Distribution module
    # so that when DistributionFactCollector.collect(module) is called, the Distribution object
    # will be available.

# Generated at 2022-06-11 02:14:35.507354
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function "ansible_facts"'''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    ansible_fact_dict = ansible_facts(module)
    assert isinstance(ansible_fact_dict, dict)
    assert 'fqdn' in ansible_fact_dict
    assert 'distribution' in ansible_fact_dict



# Generated at 2022-06-11 02:14:40.266777
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        from ansible.module_utils.facts import get_all
    except ImportError:
        from ansible.module_utils.facts import get_all_facts as get_all

    from ansible.module_utils.facts import ansible_facts

    assert ansible_facts == get_all

# Generated at 2022-06-11 02:14:44.420197
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule(object):
        def __init__(self, gather_subset=['all']):
            self.params = {'gather_subset': gather_subset}

    module = MockModule()
    facts = get_all_facts(module)
    assert 'default_ipv4' in facts

# Generated at 2022-06-11 02:15:00.656060
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.system.os import OsFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.virtual import VirtualFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['all']

    class MockFacts(Facts):
        def __init__(self):
            self.collectors = dict()
            self.collectors['os'] = OsFactCollector(None, None)
            self.collectors['distribution'] = DistributionFactCollector(None, None)
            self.collectors['virtual'] = VirtualFactCollector(None, None)



# Generated at 2022-06-11 02:15:10.190158
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text

    class TestFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['foo', 'os_name'])
        collected_facts = {}

        def collect(self, module=None, collected_facts=None):
            self.collected_facts['foo'] = "bar"
            self.collected_facts['os_name'] = "Linux"
            return self.collected_facts

    test_collector = TestFactCollector()
    ansible_collector._FACT_CACHE = {}
    ansible_collector

# Generated at 2022-06-11 02:15:20.500777
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import get_all_facts
    import mock


# Generated at 2022-06-11 02:15:32.572936
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_facts, get_all_facts
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors
    # empty module
    module = AnsibleModule()
    # empty module, no gather_subset arg
    facts_dict = ansible_facts(module)
    assert bool(facts_dict)
    # empty module, gather_subset=all
    facts_dict = ansible_facts(module, gather_subset=['all'])
    assert bool(facts_dict)
    # empty module, gather_subset=all
    get_all_facts(module)
    assert bool(facts_dict)
    # 2.3/2.4 style module
   

# Generated at 2022-06-11 02:15:45.714780
# Unit test for function get_all_facts
def test_get_all_facts():
    import unittest2 as unittest
    try:
        from ansible.module_utils.facts import get_all_facts
    except:
        from ansible.module_utils.facts import get_all_facts as get_all_facts_without_subset

    # Mock ansible module
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors, ansible_collector
    class MockModule:
        def __init__(self):
            self.params = {'gather_subset':['all']}
    m = MockModule()

    # Gather facts
    facts = get_all_facts_without_subset(m)

    # Make sure distrib_id is set
    assert 'distrib_id' in facts
   

# Generated at 2022-06-11 02:15:56.843685
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test module_utils.facts.ansible_facts method
    # Expected output:
    #   a dict mapping default_ipv4 to a string representing an IP address
    #   a dict mapping distribution to a string representing the os distro
    #   a dict with a value for each item in minimal_subset
    #   no crashes

    module = MockAnsibleModule()
    facts = ansible_facts(module)

    for field in ('default_ipv4', 'distribution'):
        assert field in facts
        assert isinstance(facts[field], str) or isinstance(facts[field], unicode)


# Generated at 2022-06-11 02:16:06.458138
# Unit test for function get_all_facts
def test_get_all_facts():

    # Construct class that implements AnsibleModule interface
    class test():
        def __init__(self, params):
            self.params = params

    # Construct a dict of parameters
    params = {
        'gather_subset': ['all']
    }

    # Test 1
    # Gather everything
    test_module = test(params)
    ansible_facts = get_all_facts(test_module)
    assert 'ansible_architecture' in ansible_facts

    # Test 2
    # Gather some facts
    params['gather_subset'] = ['network', 'hostvars']
    test_module = test(params)
    ansible_facts = get_all_facts(test_module)
    assert 'ansible_hostname' in ansible_facts

# Generated at 2022-06-11 02:16:17.625259
# Unit test for function ansible_facts
def test_ansible_facts():

    # Note that this test will fail if the code uses *any* module_utils.facts.ansible_*
    # method other than module_utils.facts.ansible_facts
    from ansible.module_utils.facts import ansible_collector, ansible_netdev_facts
    # the call to ansible_facts will use the module_utils.facts.ansible_netdev_facts method
    assert ansible_facts.__globals__['ansible_netdev_facts'] == ansible_netdev_facts

    class FakeModule:
        class FakeParams:
            gather_subset = ['all']
            gather_timeout = 10
            filter = '*'

        def __init__(self):
            self.params = self.FakeParams()

    fake_module = FakeModule()


# Generated at 2022-06-11 02:16:28.858487
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_collector_namespaces, \
        get_collector_classes, ansible_collector
    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    nm = FakeModule({"gather_subset": ["all"]})
    facts = ansible_facts(nm)
    assert facts["all_ipv4_addresses"][0] == "127.0.0.1"

    # make sure the namespace is empty
    assert facts.get('ansible') is None

    # ensure that the dictionary returned by ansible_facts matches the dictionary
    # returned by get_all_facts
    single_ip

# Generated at 2022-06-11 02:16:29.863558
# Unit test for function get_all_facts
def test_get_all_facts():
    get_all_facts(2)

# Generated at 2022-06-11 02:16:48.680294
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts import ansible_facts

    # Import AnsibleModule, AnsibleMock, etc ...
    from ansible.module_utils._text import to_bytes, to_text
    import json
    import os
    import shutil

    import sys
    sys.modules['ansible'] = Mock()
    sys.modules['ansible.module_utils.facts'] = Mock()

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors


# Generated at 2022-06-11 02:16:59.850051
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.collector.system
    import ansible.module_utils.facts.collector.file
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.service
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.pip
    import ansible.module_utils.facts.collector.setup


# Generated at 2022-06-11 02:17:07.609760
# Unit test for function ansible_facts
def test_ansible_facts():
    # ansible_facts takes an AnsibleModule as a parameter
    # and returns a dict of all the base facts
    #
    # create a mock AnsibleModule
    from ansible.module_utils import basic

    class MockAnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': 'all', 'gather_timeout': 10}

    mock_module = MockAnsibleModule()

    facts_dict = ansible_facts(mock_module)

    assert isinstance(facts_dict, dict)
    assert 'dns' in facts_dict
    assert 'cpu' in facts_dict


# Generated at 2022-06-11 02:17:14.934468
# Unit test for function ansible_facts
def test_ansible_facts():

    class AnsibleModule:
        def __init__(self, arg_spec, supports_check_mode=False):
            self.params = dict()
            self.check_mode = False

    m = AnsibleModule({}, True)
    facts_dict = ansible_facts(module=m)

    for subset in ['all', 'network']:
        facts_dict = ansible_facts(module=m, gather_subset=subset)

    for subset in ['min']:
        facts_dict = ansible_facts(module=m, gather_subset=subset)


if __name__ == '__main__':
    test_ansible_facts()

# Generated at 2022-06-11 02:17:27.257844
# Unit test for function get_all_facts
def test_get_all_facts():

    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts.ansible_collector

    old_AnsibleFactNamespace = ansible.module_utils.facts.namespace.AnsibleFactNamespace
    old_setup_module_object = ansible.module_utils.facts.collector.setup_module_object
    old_collectors = ansible.module_utils.facts.collectors.collectors
    old_get_ansible_collector = ansible.module_utils.facts.ansible_collector.get_ansible

# Generated at 2022-06-11 02:17:34.201514
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector.default import DefaultFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_network_resources
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic import GenericNetworkCollector
    from ansible.module_utils.facts.network.ios import IosNetwork
    from ansible.module_utils.facts.network.ios import IosNetworkCollector


# Generated at 2022-06-11 02:17:45.096744
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector.ansible_collector import AnsibleFileFactsCollector
    from ansible.module_utils.facts.collector.ansible_collector import AnsibleCommandFactsCollector

    class FakeModule(object):
        def __init__(self, module_name):
            self.module_name = module_name
            self.params = {
                'gather_subset': ['network'],
                'filter': 'ansible_test*'
            }

    fake_module = FakeModule('setup')
    assert 'ansible_test_key' in ansible_facts(fake_module)

    fake_module.params['gather_subset'] = ['min']
    facts_dict = ansible_facts(fake_module)

# Generated at 2022-06-11 02:17:55.100489
# Unit test for function ansible_facts
def test_ansible_facts():
    expected_facts = {'user_dir': '/home/foo',
                      'user_groups': ['wheel', 'staff'],
                      'user_id': '1000',
                      'user_name': 'foo',
                      'user_shell': '/bin/sh'}

    class MockModule():
        class MockParams():
            gather_subset = ['all']

        def __init__(self):
            self.params = self.MockParams()

    class MockTheRest():
        def __init__(self, module):
            self.module = module

        def get_user_facts(self):
            return expected_facts

    module = MockModule()
    tr = MockTheRest(module)
    module.the_rest = tr

    facts = ansible_facts(module)
    assert(facts == expected_facts)

# Generated at 2022-06-11 02:18:03.045988
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={
            'gather_subset': {'type': 'list', 'default': ['!all', 'min']},
        },
    )

    try:
        facts_dict = ansible_facts(module)

        for (k, v) in facts_dict.items():
            module.debug("%s: %s" % (to_native(k), to_native(v)))
    finally:
        module.exit_json()

# Generated at 2022-06-11 02:18:05.088237
# Unit test for function ansible_facts
def test_ansible_facts():
    assert ansible_facts('fake_module') == {}

# Generated at 2022-06-11 02:18:28.940778
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import plugins
    ansible_facts = plugins.__dict__.copy()
    # Remove all classes that start with 'Base'
    for k in list(ansible_facts.keys()):
        if k.startswith('Base'):
            del ansible_facts[k]
    # Remove all functions that start with '_'
    for k in list(ansible_facts.keys()):
        if k.startswith('_'):
            del ansible_facts[k]

    print("ansible_facts: all plugins - %s" % ansible_facts)
    return ansible_facts

# Generated at 2022-06-11 02:18:29.961850
# Unit test for function get_all_facts
def test_get_all_facts():
    assert get_all_facts()

# Generated at 2022-06-11 02:18:34.414658
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'gather_subset': '!all'})
    assert get_all_facts(module) == ansible_facts(module)



# Generated at 2022-06-11 02:18:39.449078
# Unit test for function get_all_facts
def test_get_all_facts():
    class AnsibleModule(object):
        def __init__(self, params):
            self.params = params

    data = get_all_facts(AnsibleModule({'gather_subset': ['all']}))

    assert data is not None


# Generated at 2022-06-11 02:18:48.785560
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import _get_facts
    from ansible.module_utils.facts.virtual.mesos import MesosFactCollector
    from ansible.module_utils.facts.virtual.systemd import SystemdFactCollector
    from ansible.module_utils.facts.virtual.sysv import SysvFactCollector
    import pkg_resources
    import mock


# Generated at 2022-06-11 02:18:54.638215
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    class FakeModule(object):
        '''a fake for the AnsibleModule class'''

        def __init__(self, params=None):
            self.params = params or {}

        def fail_json(self, msg, **kwargs):
            '''fail_json is called when an error occurs, this is a noop stub'''
            pass

    # factor method on FakeModule class to create an instance
    fake_module = FakeModule().__class__

    # test that an empty dict is returned if no collectors run
    fake_module.params = {}
    all_collector_classes = default_collectors.collectors

# Generated at 2022-06-11 02:19:04.048380
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts

    facts = get_all_facts({'gather_subset': ['all']})

    # Check that facts is a dict and that the dict is non-empty
    assert isinstance(facts, dict)
    assert len(facts) > 0

    # Check that all facts in facts have 'ansible_' prefix
    facts_list = list(facts.keys())
    for fact in facts_list:
        assert fact.startswith('ansible_')


# Generated at 2022-06-11 02:19:14.373228
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import NamespaceCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import json

    class MyCollector(NamespaceCollector):
        def _collect(self, module=None):
            self._legacy_facts_dict['dummy'] = 'dummy fact value'
            self._legacy_facts_dict['dummy2'] = 'dummy2 fact value'
            self._legacy_facts_dict['ansible_dummy'] = 'ansible_dummy fact value'


    Collectors = [MyCollector] + default_collectors.collectors
    all_collector_classes = Collect

# Generated at 2022-06-11 02:19:23.869798
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Test for the function get_all_facts
    '''

    from ansible.module_utils.facts.utils import FactsCollector

    import ansible.module_utils.facts.system.distribution

    system_distribution = ansible.module_utils.facts.system.distribution.DistributionFactCollector()
    myfunc = FactsCollector()
    myfunc.collectors.append(system_distribution)

    def module_params(**kwargs):
        '''
        Mock for module.params
        '''
        return kwargs

    def module_exit_json(**kwargs):
        '''
        Mock for module.exit_json
        '''
        return kwargs


# Generated at 2022-06-11 02:19:24.515811
# Unit test for function get_all_facts
def test_get_all_facts():
    pass

# Generated at 2022-06-11 02:20:04.929901
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test: function ansible_facts()

    ansible_facts()
    '''

    # Mock AnsibleModule
    class MockAnsibleModule(object):
        '''Mock Ansible Module Class'''
        def __init__(self):
            '''Mock Ansible Module init method'''
            pass

        @staticmethod
        def params():
            '''Mock Ansible Module params class method'''
            return {
                'gather_subset': None,
                'gather_timeout': 10,
                'filter': '*'
            }

        @staticmethod
        def fail_json(*args, **kwargs):
            '''Mock AnsibleModule fail_json method'''
            print(args, kwargs)
            raise Exception('unexpected call')


# Generated at 2022-06-11 02:20:16.423272
# Unit test for function ansible_facts
def test_ansible_facts():
    import platform
    import datetime
    import sys

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.system import distribution

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    from .mock import Mock, patch
    from .mock import MagicMock

    class FakeAnsibleModule(object):
        def __init__(self):
            self.params = {'gather_subset':['all']}

    class FakeDistributionFactCollector(DistributionFactCollector):
        '''
        Fake DistributionFactCollector which returns a known set of facts
        instead of trying to introspect the system
        '''

        def _get_distribution(self):
            return 'test-distribution'


# Generated at 2022-06-11 02:20:23.259559
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    m = MockModule(params={'gather_subset': ['all'], 'filter': '*', 'gather_timeout': 30})
    results = ansible_facts(m)

    if sys.version_info[0] == 2:
        import platform
        assert results[u'distribution'] == platform.dist()[0].lower()
    else:
        import platform
        assert results['distribution'] == platform.dist()[0].lower()

# Generated at 2022-06-11 02:20:36.023010
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    # we need to import AnsibleModule, but that depends on the version of Ansible being run, so
    # we try a few common locations.
    # if we haven't matched a location yet, it means that the test is to be skipped
    matched_location = False
    for location in ['ansible.module_utils.facts.ansible_module',
                     'ansible.module_utils.basic.AnsibleModule']:
        try:
            from importlib import import_module
            AnsibleModule = import_module(location)
            matched_location = True
            break
        except ImportError:
            pass

    if not matched_location:
        return

    # create a simple module with some params

# Generated at 2022-06-11 02:20:44.645184
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Verify that the compat api for ansible_facts is working'''

    from ansible.module_utils.facts.collector import BaseFactCollector
    # we don't want to actually run any facts when unit testing, just make sure that
    # the code is wired up correctly.

    class FakeCollector(BaseFactCollector):
        '''Dummy class that stands in place of one of the FactCollector classes'''

        name = 'fake_collector'

        def collect(self, module=None, collected_facts=None):
            '''Dummy collect method that just returns the same dict that was passed in.'''

            return collected_facts

    fake_module = FakeAnsibleModule()
    ret = ansible_facts(fake_module)
    assert ret



# Generated at 2022-06-11 02:20:53.585906
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    #simulate the module object
    class AnsibleModule:
        def __init__(self, gather_subset=None, gather_timeout=None, filter=None):
            self.params = {'gather_subset': gather_subset, 'gather_timeout': gather_timeout, 'filter': filter}

    #create a module to simulate the module object
    am = AnsibleModule()

    #get the facts
    facts = get_all_facts(am)

    #try to find some facts to check if it works correctly
    assert "distribution" in facts
    assert facts["distribution"] == "unknown"

# Generated at 2022-06-11 02:21:00.991242
# Unit test for function ansible_facts
def test_ansible_facts():
    # mock up a module
    class AnsibleModule:
        def __init__(self):
            self.params = {}

    module = AnsibleModule()
    module.params['gather_subset'] = ['all']
    module.params['gather_timeout'] = 10
    module.params['filter'] = '*'

    facts_dict = ansible_facts(module=module)
    assert isinstance(facts_dict, dict)
    assert 'fips' in facts_dict
    assert 'distribution' in facts_dict
    assert 'pkg_mgr' in facts_dict

# Generated at 2022-06-11 02:21:12.974561
# Unit test for function get_all_facts
def test_get_all_facts():
    mocked_module = MockAnsibleModule()

    # gather_subset not passed. Should default to ['all']
    facts = get_all_facts(mocked_module)

    assert facts is not None, "Expected 'get_all_facts' to return a dictionary"
    assert isinstance(facts, dict), "Expected return value of 'get_all_facts' to be a dict"
    assert len(facts) > 0, "Expected 'facts' returned by 'get_all_facts' to have at least one entry"

    # gather_subset passed, but empty
    mocked_module.params = {'gather_subset': []}
    facts = get_all_facts(mocked_module)

    assert facts is not None, "Expected 'get_all_facts' to return a dictionary"

# Generated at 2022-06-11 02:21:22.343493
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.basic
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    mock_module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    mock_module.params['filter'] = 'ansible_*'

    fact_collector = ansible_facts(module=mock_module)
    ansible_pkg_mgrs = fact_collector.get_fact('pkg_mgrs')

    assert ansible_pkg_mgrs
    assert 'yum' in ansible_pkg_mgrs


# Generated at 2022-06-11 02:21:33.906327
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts, FACT_CACHE, DONE
    from ansible.module_utils.facts.system import DistributionFactCollector

    # clear out any old cached facts
    DONE = False
    FACT_CACHE = {}

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    gather_timeout = 10
    ansible_facts(module, gather_timeout=gather_timeout)
    assert FACT_CACHE['ansible_lsb']['timeout'] == gather_timeout

    # Check that the default fact collector class for lsb is the DistributionFactCollector
    assert FACT_CACHE['ansible_lsb']['collector'] == DistributionFactCollector

