

# Generated at 2022-06-11 02:11:48.445714
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test to test the functionality of ansible_facts
    '''
    import ansible.module_utils.facts.system.distribution as distro
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr
    from ansible.module_utils.facts import timeout

    module = FakeAnsibleModule()
    fact_collector = ansible_collector.get_ansible_collector({distro.DistributionCollector,
                                                              pkg_mgr.PkgMgrCollector},
                                                             filter_spec='distribution*'
                                                            )
    facts_dict = fact_collector.collect(module=module)
    assert facts_dict['id'] == 'RedHat'

    fact_collector = ansible_collector.get_ansible_

# Generated at 2022-06-11 02:11:55.948071
# Unit test for function ansible_facts

# Generated at 2022-06-11 02:12:05.414352
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'collected'}

    default_collectors.collectors.append(TestCollector)

    # Test that we collect all facts by default
    result = ansible_facts(module={})

# Generated at 2022-06-11 02:12:14.302232
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.lsb import LsbFactCollector
    from ansible.module_utils.facts.network.ipv4 import Ipv4FactCollector
    from ansible.module_utils.facts.network.interfaces import InterfacesFactCollector
    import random
    import time

    random_id = random.randint(1, 1000)
    random_name = "name-%s" % random_id
    random_ansible_interfaces = "ansible_%s" % random_name
    random_ansible_ipv4 = "ansible_%s" % random_name

    class TestAnsibleModule:
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-11 02:12:14.955272
# Unit test for function get_all_facts

# Generated at 2022-06-11 02:12:23.143124
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    all_facts = ansible_facts(module)
    assert 'all' in all_facts

    assert 'default_ipv4' in all_facts['all']
    assert 'default_ipv6' in all_facts['all']
    assert 'fqdn' in all_facts['all']
    assert 'ipv4' in all_facts['all']
    assert 'ipv6' in all_facts['all']
    assert 'macaddress' in all_facts['all']
    assert 'mounts' in all_facts['all']
    assert 'partitions' in all_facts['all']
    assert 'python' in all_facts['all']
    assert 'python3' in all_facts['all']


# Generated at 2022-06-11 02:12:34.060757
# Unit test for function ansible_facts
def test_ansible_facts():
    mock_module = MagicMock()
    mock_module.params = {'gather_subset': ['all'], 'gather_timeout': 10}


# Generated at 2022-06-11 02:12:37.449252
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.test_ansible_facts as test_ansible_facts
    test_ansible_facts.test_ansible_facts()

# Generated at 2022-06-11 02:12:47.527414
# Unit test for function get_all_facts
def test_get_all_facts():
    # set up mock module object
    class MockModule(object):
        def __init__(self):
            self.params = {'filter': '*'}

    # set up mock subprocess object
    class MockPopen():
        def __init__(self, cmd, shell=False, stdout=None, stdin=None, stderr=None, bufsize=1):
            self.stdout = b'{"fact": "value"}'

        def communicate(self, timeout=None):
            pass

        def wait(self, timeout=None):
            return 0

    class MockSubprocess():
        def __init__(self):
            pass

        def Popen(self, *args, **kwargs):
            return MockPopen

    mock_module = MockModule()

# Generated at 2022-06-11 02:12:58.349774
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system import DistributionFactCollector

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    collector_classes = {'distribution': DistributionFactCollector}
    fact_collector = ansible_collector.AnsibleCollector(all_collector_classes=collector_classes,
                                                        namespace=namespace,
                                                        gather_subset=['all'],
                                                        filter_spec='*',
                                                        gather_timeout=10,
                                                        minimal_gather_subset=frozenset())


# Generated at 2022-06-11 02:13:09.612487
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class DummyModule(object):
        # TODO: Add a method get_param so we can test
        # defaults for gather_subset and gather_timeout
        pass

    # params is a dict that should be returned as the result of
    # ansible_facts
    params = {'myparam': 'myparamvalue'}


# Generated at 2022-06-11 02:13:11.877634
# Unit test for function get_all_facts
def test_get_all_facts():
    module = AnsibleModule(argument_spec=dict())
    facts = get_all_facts(module)
    assert isinstance(facts, dict)

# Generated at 2022-06-11 02:13:23.440532
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys

    # ansible modules don't run on Windows, but they can run in Python 2
    if sys.platform != 'win32' and sys.version_info[0] == 2:
        from ansible.module_utils.facts import ansible_facts
        from ansible.module_utils.facts import ansible_facts_2_3

        # Test whether the 2.3 and 2.4 functions return the same values
        #
        # 'module' here is a DummyModule instance - it's not really a 'module' in the sense of
        # a real ansible module
        #
        # test_facts_dict_2_3 is the 'facts' collected by the 2.3 version of ansible_facts,
        # and test_facts_dict_2_4 is the 'facts' collected by the 2.4 version of ansible_facts

# Generated at 2022-06-11 02:13:29.193077
# Unit test for function get_all_facts
def test_get_all_facts():
    test_subset = frozenset(['all', 'network', 'hardware', 'virtual'])

    class TestModule(object):
        def __init__(self):
            self.params = {'gather_subset': list(test_subset)}

    test_module = TestModule()
    test_facts = get_all_facts(test_module)

    assert test_subset == frozenset(test_facts.keys())


# Generated at 2022-06-11 02:13:34.259055
# Unit test for function ansible_facts
def test_ansible_facts():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    module = MockModule({'gather_subset': ('all',), 'filter': '*', 'gather_timeout': 10})
    facts = ansible_facts(module)
    assert 'default_ipv4' in facts

# Generated at 2022-06-11 02:13:36.685636
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Unit test for get_all_facts
    '''
    # TODO: Write unit test
    pass


# Generated at 2022-06-11 02:13:48.765930
# Unit test for function ansible_facts
def test_ansible_facts():
    # create a fake module for testing
    from ansible.module_utils.facts import module_facts

    module_facts()
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_classes

    all_collector_classes = get_collector_classes()
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    filter_spec = '*'
    gather_subset = None
    gather_timeout = 10
    minimal_gather_subset = None


# Generated at 2022-06-11 02:13:56.459722
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for get_all_facts compat api'''

    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    try:
        from ansible.module_utils.facts import ansible_facts
        from ansible.module_utils.facts import ansible_collector
        from ansible.module_utils.facts import default_collectors
    except ImportError:
        # prior to 2.4 this was in a different location
        from ansible.module_utils.facts import ansible_facts
        from ansible.module_utils.facts import ansible_collector
        from ansible.module_utils.facts import default_collectors

    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    #

# Generated at 2022-06-11 02:14:08.254335
# Unit test for function ansible_facts
def test_ansible_facts():

    # mock AnsibleModule
    ansible_module_mock = dict(filter='*', gather_subset=['all'], gather_timeout=10)

    # mock the list of available facts
    # the docker fact is only the name of the fact (a str)
    # the remote_mgmt fact has more data (the dict value)
    mock_facts = [str('docker'), dict(name='remote_mgmt', data={'ipv4': '10.0.0.1'})]

    # mock ansible_facts

# Generated at 2022-06-11 02:14:18.881618
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule

    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'

    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(type='list', default=gather_subset),
            'gather_timeout': dict(type='int', default=gather_timeout),
            'filter': dict(type='str', default=filter_spec),
        }
    )

    facts_dict = ansible_facts(module)

    assert isinstance(facts_dict, dict)

    # test what is returned
    assert to_text(facts_dict['date_time']['date']) != ''

# Generated at 2022-06-11 02:14:30.666592
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import fact_collector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.hardware.base import HardwareCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.hpux import HpuxNetwork
    from ansible.module_utils.facts.network.netbsd import NetBSDNetwork
    from ansible.module_utils.facts.network.aix import AixNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

# Generated at 2022-06-11 02:14:41.776134
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.virtual.docker import DockerFactCollector
    from ansible.module_utils.facts.virtual.kvm import KvmFactCollector
    from ansible.module_utils.facts.virtual.xenapi import XenapiFactCollector
    from ansible.module_utils.facts.virtual.xenserver import XenserverFactCollector
    from ansible.module_utils.facts.processor.arm import ArmFactCollector
    from ansible.module_utils.facts.processor.aarch64 import Aarch64FactCollector
    from ansible.module_utils.facts.processor.ppc64 import Ppc64FactCollector
    from ansible.module_utils.facts.processor.s390x import S390xFactCollector

# Generated at 2022-06-11 02:14:49.134865
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    filter_spec = '*'
    empty_filter_spec = ''
    gather_timeout = 10
    expected_gather_subset = ['all']

# Generated at 2022-06-11 02:15:02.037426
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import os
    import unittest

    # Mock the AnsibleModule class
    class MockAnsibleModule(object):
        def __init__(self, params):
            self.params = params

    # Mock ansible module params
    params = {'gather_subset': ['all']}

    # Run the ansible_facts function and save the results
    test_ansible_facts_results = ansible_facts(MockAnsibleModule(params))

    # Mock ansible module params with user specified subset
    params = {'gather_subset': ['network']}

    # Run the ansible_facts function with user specified subset and save the results
    test_ansible_facts_network_results = ansible_facts(MockAnsibleModule(params))

    # Mock ansible module params with invalid subset


# Generated at 2022-06-11 02:15:10.059316
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils import facts
    from ansible.module_utils.facts import default_collectors

    module = AnsibleModule(argument_spec={})

    with patch.object(facts, 'default_collectors') as mock_default_collectors:
        with patch.object(facts, 'ansible_collector') as mock_ansible_collector:
            with patch.object(facts.module_utils.facts.namespace, 'PrefixFactNamespace') as mock_prefix_fact_namespace:
                with patch.object(mock_default_collectors, 'collectors') as mock_collectors:

                    mock_fact_collector

# Generated at 2022-06-11 02:15:20.465570
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible import constants as C
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({'gather_subset': ['all'], 'gather_timeout': 10})
    module.params.update(ansible_facts(module))

    assert module.params['ansible_all_ipv4_addresses']
    assert module.params['ansible_all_ipv6_addresses']
    assert module.params['ansible_architecture']
    assert module.params['ansible_bios_date']
    assert module.params['ansible_bios_version']
    assert module.params['ansible_cmdline']
    assert module.params['ansible_date_time']
    assert module.params['ansible_default_ipv4']

# Generated at 2022-06-11 02:15:32.572502
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import collector

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all', 'network']),
            filter=dict(default='*', type='str'),
        ),
        # added_argument_spec=dict(),
    )
    gather_subset = module.params['gather_subset']
    filter_spec = module.params.get('filter', '*')
    class FakeCollector(object):

        def __init__(self, *args, **kwargs):
            self.collect_called = False
            self.filter = kwargs.get('filter_spec')
            self.namespace = kwargs.get('namespace')
           

# Generated at 2022-06-11 02:15:45.716508
# Unit test for function ansible_facts
def test_ansible_facts():
    # See comment on ansible_facts method at the top of this file
    #
    # As a temporary measure, run the test with ansible 2.3.1.0
    #
    # TODO: After porting to py3, re-run tests with latest ansible
    from ansible.module_utils.facts import ansible_facts

    # TODO: This test will fail if a new fact is added to the default
    # minimal_gather_subset. We could fix that by fixing the module to
    # actually deal with gather_subset, then removing minimal_gather_subset
    # from the function.

    # TODO: This test is probably broken by the latest Ansible, which
    # probably has added new facts. It should be updated to call get_all_facts,
    # not ansible_facts.
    #
   

# Generated at 2022-06-11 02:15:47.846930
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test'''
    assert ansible_facts({'gather_subset': ['all']})

# Generated at 2022-06-11 02:15:57.843999
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    This is a unit test for the module_utils.facts.ansible_facts function.
    '''

    # pylint: disable=unused-variable
    import unittest
    # pylint: disable=import-error
    from ansible.module_utils.six import PY3
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from mock import patch
    from ansible.module_utils._text import to_text

    class AnsibleModule(object):
        '''
        mock class for AnsibleModule.

        not praticed to use the mock library for this use case, but there it goes.
        '''

# Generated at 2022-06-11 02:16:09.652287
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Unit test for function ansible_facts'''

    class FakeAnsibleModule():
        def __init__(self):
            self.params = dict()

    fake_module = FakeAnsibleModule()

    # all facts
    fake_module.params['gather_subset'] = ['all']
    facts = ansible_facts(fake_module)
    # bare facts
    assert 'fqdn' in facts
    # namespaced facts
    assert 'ansible_fqdn' in facts



# Generated at 2022-06-11 02:16:19.058841
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    import ansible.module_utils.ansible_release
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # seed the namespace with a dummy set of facts for unit test purposes
    dummy_ns = PrefixFactNamespace(namespace_name='ansible', prefix='',
                                   facts_module=ansible.module_utils.ansible_release)
    global_fact_dict = dummy_ns.facts
    global_fact_dict['ansible_facts'] = {'dummy': 'fact'}

    class ModuleMock(object):
        def __init__(self, params=None):
            self.params = params or {'gather_subset': ['all']}

    # This test requires that the get_all_facts

# Generated at 2022-06-11 02:16:27.131170
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({'gather_subset': ['all']})

    if 'ansible_pkg_mgr' in ansible_facts(module):
        assert isinstance(ansible_facts(module)['pkg_mgr'], to_bytes)

if __name__ == '__main__':
    '''Test cases for the module functions'''
    test_ansible_facts()

# Generated at 2022-06-11 02:16:33.922142
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.network.bsd as network_bsd
    import ansible.module_utils.facts.network.linux as network_linux
    import ansible.module_utils.facts as facts
    import ansible.module_utils.facts.hardware.linux as hardware_linux
    import ansible.module_utils.facts.system.linux as system_linux
    import ansible.module_utils.facts.system.bsd as system_bsd
    from ansible.module_utils.facts import default_collectors

    # TODO: this is a workaround for the test for pypy
    # the __file__ variable does not exist in a pypy environment
    # but does exist in a py2/py3 environment
    # for now, we just skip the test in pypy
    import os

# Generated at 2022-06-11 02:16:45.172224
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test get_all_facts method'''
    try:
        # Python2
        import ansible
    except ImportError:
        # Python3
        import ansible.constants as ansible
    import ansible.module_utils.facts.virtual.freebsd as freebsd

    old_uname = freebsd.uname
    old_lsb_release = freebsd.lsb_release
    old_default_interfaces = freebsd.default_interfaces
    old_distribution = freebsd.distribution
    old_platform_distro = freebsd.platform_distro
    old_get_distribution = freebsd.get_distribution


# Generated at 2022-06-11 02:16:56.420035
# Unit test for function get_all_facts
def test_get_all_facts():
    import os
    import socket
    import unittest

    from ansible.module_utils.facts import ansible_collector

    from ..default_collectors import DEFAULT_GATHER_SUBSET

    class AgnosticAnsibleModule(object):
        '''Mock for the AnsibleModule object'''
        def __init__(self, params):
            self.params = params

    if os.name == 'nt':
        import ntpath as os_path
    else:
        import posixpath as os_path

    class MyTestCase(unittest.TestCase):
        def test_get_all_facts(self):
            # just test that we can get all the facts
            module = AgnosticAnsibleModule(params={'gather_subset': ['all']})
            facts_dict = get_all_

# Generated at 2022-06-11 02:17:06.740265
# Unit test for function ansible_facts
def test_ansible_facts():
    import os.path

    from ansible.compat.tests.mock import patch
    from ansible.module_utils.facts import default_collectors

    # make sure that the fact_module is loaded.
    # load 'date_time' and 'fips' in the minimal_gather_subset
    # so that we can assert that they are loaded
    sample_gather_subset = ['date_time', 'fips']
    sample_filter = '*'

    _all_collector_classes = default_collectors.collectors

    _default_filter_spec = default_collectors.DEFAULT_COLLECTOR_JSON_FILTER

    # patch the location of the fact_module.
    #  - this is normally the parent directory of the ansible-base repo.
    #  - but for testing we are in the parent directory

# Generated at 2022-06-11 02:17:15.840607
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.utils as facts_utils

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    m = MockModule({'gather_subset': ['all']})
    d = get_all_facts(m)
    assert isinstance(d, dict)
    assert 'os_family' in d
    assert 'platform' in d
    assert 'distribution' in d

    m = MockModule({'gather_subset': ['all'], 'filter': 'platform'})
    d = get_all_facts(m)
    assert isinstance(d, dict)
    assert 'os_family' in d
    assert 'platform' in d
    assert 'distribution' not in d


# Generated at 2022-06-11 02:17:27.896712
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace
    from ansible.module_utils.facts.facts import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MyCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            collected_facts = collected_facts or {}
            collected_facts['my_key'] = 'my value'
            return collected_facts

    # See: https://github.com/ansible/ansible/issues/37364
    # Until we can safely pass ansible.module_utils.facts.collector.Facts directly to
    # ansible_collector's get_ansible_collector method we need to mock the facts.collector
    # with our test collector.
    import ansible.module_

# Generated at 2022-06-11 02:17:34.449785
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.module_common import AnsibleModule
    from ansible.module_utils.facts.dummy_collector import DummyCollector
    from ansible.module_utils.facts.hardware import HardwareCollector
    module = AnsibleModule(argument_spec={'filter': dict(type='str', default='*'),
                                          'gather_subset': dict(type='list', default=['all']),
                                          'gather_timeout': dict(type='int', default=10)})

    class MyUserCollector(DummyCollector):
        def collect(self, module=None, collected_facts=None):
            return {'name': 'bob'}

    # Test: facts_dict should have 'name' key with value "bob"
    fact_collector = ansible_

# Generated at 2022-06-11 02:17:54.333287
# Unit test for function ansible_facts
def test_ansible_facts():
    import copy
    import pytest
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceCollector
    # load a subset of the namespaces you need for this test
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # make a dummy module subclassing AnsibleModule
    class MyAnsibleModule(object):
        '''AnsibleModule subclass for testing compat_facts'''
        module_args = dict(gather_subset=dict(type='str', required=False, default='all'))
        params = copy.deepcopy(module_args)


# Generated at 2022-06-11 02:18:03.284414
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import shutil
    import tempfile
    from ansible.module_utils.facts import module_facts_cache

    temp_dir = tempfile.mkdtemp()
    cache_dir = os.path.join(temp_dir, 'cache_dir')
    cache_file_path = os.path.join(temp_dir, 'cache_file')
    module_facts_cache.FACTS_CACHE_FILE = cache_file_path

    try:
        os.remove(cache_file_path)
    except OSError:
        pass

    module = None
    ansible_facts(module)
    ansible_facts(module, ['all'])

    shutil.rmtree(temp_dir)

# Generated at 2022-06-11 02:18:11.223973
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.date_time import DateTime
    from ansible.module_utils.facts.system.lsb import Lsb
    from ansible.module_utils.facts.system.platform import Platform

    collect_all_classes = default_collectors.collectors
    minimal_gather_subset = frozenset(['distribution', 'date_time', 'lsb', 'platform'])

    test_module = object()
    test_filter = '*'
    test_gather_subset = ['all']
    test_gather_timeout = 1

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-11 02:18:17.961256
# Unit test for function get_all_facts
def test_get_all_facts():
    import mock

    mocked_module = mock.Mock()
    mocked_module.params = {
        'gather_subset': ['network', 'virtual']}
    results = get_all_facts(mocked_module)

    # test that the returned dict has
    # the expected keys, and that those keys have a value
    assert results.get('fips')
    assert results.get('mounts')



# Generated at 2022-06-11 02:18:28.721134
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class AnsibleModule:
        def __init__(self):
            self.params = {}

    module = AnsibleModule()
    # first test with the default gather_timeout
    facts_dict = ansible_facts(module)
    assert isinstance(facts_dict, dict)

    # now test gather_timeout is properly set to 10
    module.params['gather_timeout'] = 10
    facts_dict = ansible_facts(module)
    assert facts_dict['gather_timeout'] == 10
    # and make sure the default namespace is used
    assert isinstance(facts_dict, dict)


# Unit

# Generated at 2022-06-11 02:18:39.410064
# Unit test for function ansible_facts
def test_ansible_facts():
    import copy
    import json
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class TestAnsibleModule():
        def __init__(self, params):
            self.params = params
            self.fail_json = self.exit_json = self.return_value = self.exit_json = lambda **kwargs: None


# Generated at 2022-06-11 02:18:48.785487
# Unit test for function get_all_facts
def test_get_all_facts():

    class MockAnsibleModule:
        def __init__(self, params=None):
            self.params = params or {}

        def fail_json(self, **kwargs):
            self.exit_json(**kwargs)

        def exit_json(self, **kwargs):
            pass

    # fake the ansible module and gather params
    module = MockAnsibleModule(dict(
        gather_subset=['network'],
        gather_timeout=10,
    ))

    facts = get_all_facts(module)

    # check that network facts are collected
    assert facts['default_ipv4']['interface']

    # check that a subset of facts isn't collected
    assert 'distribution' not in facts
    assert 'distribution_version' not in facts
    assert 'machine' not in facts

# Generated at 2022-06-11 02:18:54.328673
# Unit test for function ansible_facts
def test_ansible_facts():
    class AnsibleModule(object):
        def __init__(self, params):
            self.params = params

    # Test that an empty gather_subset returns an empty facts dict
    assert {} == ansible_facts(AnsibleModule({'gather_subset': ['all']}))

    # Test that ansible_facts() works with gather_subset but not gather_timeout
    assert {} == ansible_facts(AnsibleModule({'gather_subset': ['all']}))

    # Test that ansible_facts() works with both gather_subset and gather_timeout
    assert {} == ansible_facts(AnsibleModule({'gather_subset': ['all'], 'gather_timeout': 1}))

# Generated at 2022-06-11 02:19:07.394560
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.basic
    import ansible.module_utils.facts.default_collectors

    class TestModule(ansible.module_utils.basic.AnsibleModule):
        pass

    test_module = TestModule()
    # Test with gather_subset 'all' and filter '*'
    # Returned dict should contain 'cmdline'
    test_module.params['gather_subset'] = ['all']
    test_module.params['filter'] = '*'
    test_facts = ansible_facts(test_module)
    assert 'cmdline' in test_facts

    # Test with gather_subset 'all' and filter 'cmdline:*'
    # Returned dict should contain 'cmdline'
    test_module.params['gather_subset'] = ['all']
    test_

# Generated at 2022-06-11 02:19:19.008104
# Unit test for function ansible_facts
def test_ansible_facts():  # pragma: no cover
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    from ansible.compat.six import string_types, iteritems


# Generated at 2022-06-11 02:19:48.062973
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector.command import CommandCollector

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.ansible_collector import AnsibleCollector
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.collector.base import BaseFactCollector

    import sys
    import pytest

    class mockAnsibleModule(object):
        class params:
            def __init__(self, _gather_subset, _gather_timeout, _filter):
                self.gather_subset = _gather_subset
                self.gather_timeout = _gather_timeout

# Generated at 2022-06-11 02:19:55.934841
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts

    class AnsibleModule(object):
        def __init__(self, gather_subset=None):
            self.params = {'gather_subset': gather_subset or ['all']}

    facts = ansible_facts(AnsibleModule(gather_subset=['!all', 'min']))
    assert bool(facts)

# Generated at 2022-06-11 02:20:05.604726
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Here we test ansible_facts by collecting facts when no filter is specified.  First we collect
    facts when gather_subset is not specified, then we collect them when gather_subset is specified
    as ['hardware'] and then when gather_subset is specified as ['all']

    This function will be called by test/units/module_utils/facts/__init__.py
    '''

    class FakeModule:
        def __init__(self):
            self.params = {'gather_timeout': 10}

    fake_module = FakeModule()
    facts_no_filter = ansible_facts(fake_module)
    # check that this dict has at least one key

# Generated at 2022-06-11 02:20:17.644998
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import module_utils
    from ansible.module_utils.facts import ansible_facts

    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic import NetworkGenericFactCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    from ansible.module_utils.facts.system.distribution import DistributionCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

    # NOTE: Use a mock module that does not trigger any of the module_utils methods

# Generated at 2022-06-11 02:20:25.365252
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeCollector1(BaseFactCollector):
        NAME = 'faker1'
        _fact_ids = ['the_answer', 'the_thing']
        _platform = 'all'

        def collect(self, module=None, collected_facts=None):
            return {'the_answer': 42, 'the_thing': 'a towel'}

    class FakeCollector2(BaseFactCollector):
        NAME = 'faker2'
        _fact_ids = ['the_answer', 'color']
        _platform = 'all'


# Generated at 2022-06-11 02:20:35.393562
# Unit test for function get_all_facts
def test_get_all_facts():
    class Module:
        def __init__(self, params):
            self.params = params

    modules = [Module({'gather_subset': ['all']}),
               Module({'gather_subset': ['min']}),
               Module({'gather_subset': ['!foo']}),
               Module({}),
               ]

    for module in modules:
        facts = get_all_facts(module)
        assert isinstance(facts, dict)
        assert isinstance(facts['distribution'], str) or facts['distribution'] is None
        assert 'ansible_' not in facts



# Generated at 2022-06-11 02:20:41.052175
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {'gather_subset': None}

    mock = MockAnsibleModule()
    results = get_all_facts(mock)

    assert len(results) > 0, "should have some results"
    assert len(results.keys()) > 0, "should have some keys"
    assert True, "we got here without an exception"

# Generated at 2022-06-11 02:20:42.012149
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-11 02:20:52.084215
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    module = MockModule({'gather_subset': ['all'], 'gather_timeout': 10})

    assert len(ansible_facts(module)) > 0

    minimal_facts = ansible_facts(module, gather_subset=['min'])

    # the minimal set is in 'ansible_' namespace
    namespace_minimal = PrefixFactNamespace(namespace_name='ansible', prefix='ansible_')
    minimal_namespace_facts = namespace_minimal.get_all(minimal_facts)
   

# Generated at 2022-06-11 02:21:01.930226
# Unit test for function get_all_facts
def test_get_all_facts():
    #
    # Unit test for deprecated function get_all_facts
    #
    # Deprecated function get_all_facts() calls ansible_facts(), which requires
    # arg 'module', which needs to be a AnsibleModule instance.
    # This is hard to unit test, so instead use the AnsibleModule mock provided
    # by the 'ansible.module_utils.facts.test_module_utils_facts' module.
    #
    from ansible.module_utils.facts.test_module_utils_facts import MockAnsibleModule

    module = MockAnsibleModule()

    facts_dict = get_all_facts(module)

    assert 'date_time' in facts_dict
    assert facts_dict['date_time']['date'] != ''

