

# Generated at 2022-06-11 02:11:47.240107
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.ansible_collector
    import ansible.module_utils.facts.default_collectors
    import ansible.module_utils.facts.hardware

    mock_module = MockAnsibleModule()
    mock_module.params = {'gather_subset': ['all']}
    ansible.module_utils.facts.ansible_collector.AnsibleCollector.val_from_env_or_params = Mock(return_value=10)


# Generated at 2022-06-11 02:11:56.991436
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.could_not_collect import could_not_collect_all_facts_errors
    from ansible.module_utils._text import to_bytes
    from io import StringIO
    import mock
    import json
    import os

    module = mock.Mock()

    gather_subset = frozenset(['all'])
    gather_timeout = 10

    # Stashing the real stdout and stderr so that test code
    # can still print debugging messages
    real_stdout = sys.stdout
    real_stderr = sys.stderr

    # Capture the output to stdout, so the test code can make
    # assertions about it
    out = StringIO()

# Generated at 2022-06-11 02:12:05.997901
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    assert get_all_facts(TestModule({'gather_subset': 'all'})) == ansible_facts(TestModule({'gather_subset': 'all'}))
    assert get_all_facts(TestModule({'gather_subset': '!all'})) == ansible_facts(TestModule({'gather_subset': '!all'}))
    assert get_all_facts(TestModule({'gather_subset': 4})) == ansible_facts(TestModule({'gather_subset': 4}))

# Generated at 2022-06-11 02:12:14.352462
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.facts import get_all_collector_classes

    class TestModule:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, executable, required=False, opt_dirs=()):
            return '/bin/' + executable

    test_module = TestModule()

    # Test with gather_subset=None
    collected_facts = ansible_facts(test_module)

    assert isinstance(collected_facts, dict)

    all_collector_classes = get_all_collector_classes()

    # Test that all base collectors were run, without having to import them

# Generated at 2022-06-11 02:12:19.526076
# Unit test for function ansible_facts
def test_ansible_facts():
    # fake an AnsibleModule
    class AnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': None}

    am = AnsibleModule()
    am.params = {'gather_subset': None}
    facts = ansible_facts(am)

    assert 'distribution' in facts
    assert 'os_family' in facts
    assert 'default_ipv4' in facts
    assert 'ipv4' in facts



# Generated at 2022-06-11 02:12:31.510749
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import  get_distribution, get_distribution_version, get_distribution_release

    class TestModule:
        def __init__(self, gather_subset=None, gather_timeout=10, filter=None,
                     distribution=None, distribution_version=None, distribution_release=None):
            self.params = {'gather_subset': gather_subset,
                           'gather_timeout': gather_timeout,
                           'filter': filter}

            if distribution is not None:
                self.params['ansible_facts'] = {'distribution': distribution,
                                                'distribution_version': distribution_version,
                                                'distribution_release': distribution_release}


# Generated at 2022-06-11 02:12:32.076226
# Unit test for function ansible_facts
def test_ansible_facts():
    assert True

# Generated at 2022-06-11 02:12:43.684925
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.basic import AnsibleModule

    class StubModule(AnsibleModule):
        def __init__(self, params=None):
            super(StubModule, self).__init__(
                argument_spec={},
                supports_check_mode=False)
            self.params = params

        def get_stub_facts(self):
            return {'foo': 'bar'}

        def run_command(self, command_line, check_rc=True, cwd=None, use_unsafe_shell=False, data=None, binary_data=False,
                        executable=None, umask=None):
            return ('', '')

    module = StubModule({'gather_subset': ['all'], 'gather_timeout': 10})

# Generated at 2022-06-11 02:12:55.866188
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors

    import json

    class FakeModule(object):
        def __init__(self, params, name='fake'):
            self.params = params
            self.name = name

        def fail_json(self, msg):
            raise Exception(msg)

        def exit_json(self, ansible_facts, **kwargs):
            self.facts = ansible_facts
            self.exit_kwargs = kwargs

    params = dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*'
    )

    fake_module = FakeModule(params, name='fake')
    ansible

# Generated at 2022-06-11 02:13:07.114756
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import parse_mount
    from ansible.module_utils.facts.utils import search_file
    from ansible.module_utils.facts.utils import search_file_line_by_line
    from ansible.module_utils.facts.utils import get_file_content_of_module
    from ansible.module_utils.facts.utils import get_file_lines_of_module

# Generated at 2022-06-11 02:13:16.317881
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts.'''
    import mock

    # Create a mock module that can be used to simulate arguments passed to the
    # module, and return values expected from it.
    mock_module = mock.Mock()

    mock_module.params.get.return_value = '*'
    mock_module.params.get.return_value = 10
    mock_module.params.get.return_value = ['all']

    # Call the ansible_facts function
    facts = ansible_facts(mock_module)

    # Assert that the get_all_facts function was called with the proper arguments
    # and that it returned proper facts
    mock_module.params.get.assert_called_with('filter', '*')

# Generated at 2022-06-11 02:13:27.978253
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.facts import ansible_facts
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.the_real_user import TheRealUserFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    module = MockModule({'gather_timeout': 3, 'filter': '*', 'path': '/some/path'})
    collected_facts = ansible_facts(module, gather_subset=['all'])
    assert isinstance(collected_facts['distribution'], DistributionFactCollector)

# Generated at 2022-06-11 02:13:38.652971
# Unit test for function get_all_facts
def test_get_all_facts():

    import sys

    if sys.version_info[0] < 3:
        from mock import MagicMock, call
    else:
        from unittest.mock import MagicMock, call

    test_fact_mock = MagicMock()
    test_fact_mock.__name__ = 'TestFact'

    test_collector_mock = MagicMock()
    test_collector_mock.__name__ = 'TestCollector'
    test_collector_mock.collect = lambda x: {'test_fact': test_fact_mock}

    ansible_collector_mock = MagicMock()
    ansible_collector_mock.get_ansible_collector = lambda *args: test_collector_mock

    facts_mock = MagicMock()
    facts_mock

# Generated at 2022-06-11 02:13:51.086874
# Unit test for function ansible_facts
def test_ansible_facts():
    import json

    # make sure module_utils.facts.ansible_facts is not None
    assert module_utils_facts_ansible_facts is not None

    # gather_subset is supported in Ansible 2.0+
    ANSIBLE_MAJOR_VERSION = 2

    # from the unit test module
    from ansible.modules.system import setup

    # create a mock AnsibleModule
    mock_ansible_module = create_ansible_module(setup)

    # test default gather_subset values

# Generated at 2022-06-11 02:14:02.706653
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.cache

    class ModuleMock(object):
        def __init__(self, gather_subset=None):
            self.params = {'gather_subset': gather_subset}

    PUT_CACHE_RETURN = 'put_cache_return'
    GET_CACHE_RETURN = 'get_cache_return'

    def put_cache_mock(cache_key, cache_value):
        assert cache_key.startswith('ansible_get_all_facts')
        assert isinstance(cache_value, dict)
        return PUT_CACHE_RETURN

    def get_cache_mock(cache_key, cache_default):
        assert cache_key.startswith('ansible_get_all_facts')
        assert cache_default

# Generated at 2022-06-11 02:14:11.553207
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import facts_module
    from ansible.module_utils.facts.facts import Facts

    class MockModule(object):

        def __init__(self, gather_subset=None, gather_timeout=None, filter=None):

            self.params = {'gather_subset': gather_subset,
                           'gather_timeout': gather_timeout,
                           'filter': filter}

    # test with and without gather_subset params
    test_module = MockModule()
    facts = facts_module.get_all_facts(test_module)

    assert isinstance(facts, Facts)
    assert facts['local']['fqdn'] is not None

    test_module = MockModule(gather_subset=['network'])
    facts = facts_module.get_all_

# Generated at 2022-06-11 02:14:17.589848
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(AnsibleModule):

        def __init__(self):
            self.params = {'gather_subset': 'all'}


    mock_module = MockModule()
    all_facts_dict = get_all_facts(mock_module)
    assert isinstance(all_facts_dict, dict)
    assert len(all_facts_dict) > 0

# Generated at 2022-06-11 02:14:27.934219
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.virtual import VirtWhatFactCollector
    from ansible.module_utils.facts import namespace as ns

    # Use a MockAnsibleModule, since we can't get an AnsibleModule w/o executing the actual
    # module code. The only thing we should use the AnsibleModule for is to get the gather_subset
    class MockAnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    # subclass PrefixFactNamespace to grab the generated fact name
    class MockPrefixFactNamespace(ns.PrefixFactNamespace):
        def __init__(self, *args, **kwargs):
            super(MockPrefixFactNamespace, self).__init__(*args, **kwargs)
            self.fact_

# Generated at 2022-06-11 02:14:37.975971
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import pytest
    from ansible.module_utils.facts import Facts
    from ansible.module_utils import basic

    # Helper class to instantiate AnsibleModule
    class TestModule(object):
        def __init__(self, **kwargs):
            # Override module args to be able to supply a mock Facts object
            if 'ansible_facts' in kwargs:
                kwargs['_ansible_facts'] = kwargs.pop('ansible_facts')

# Generated at 2022-06-11 02:14:47.425068
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts
    from ansible.module_utils.facts import _facts_assemble_dict
    # import the modules to stub out and test
    import ansible.module_utils.facts.system.distribution as distribution_collector
    import ansible.module_utils.facts.system.platform as platform_collector

    # Ensure the get_all_facts() method is added to AnsibleModule
    assert ansible.module_utils.facts.get_all_facts

    class FakeModule:
        # define a simple bare-minimum AnsibleModule
        def __init__(self, params):
            self.params = params

    # test with no params
    (distro_collector, platform_collector) = _facts_assemble_dict(FakeModule({}))
    # ensure the ansible namespace prefix is stripped by

# Generated at 2022-06-11 02:15:04.436530
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import MagicMock
    module = MagicMock()

    # Test gather_subset argument passed
    with patch('ansible.module_utils.facts.ansible.ansible_collector.get_ansible_collector') as mock_collector:
        mock_collector.return_value = MagicMock()
        mock_collector.return_value.collect = MagicMock()
        mock_collector.return_value.collect.return_value = MagicMock()
        ansible_facts(module, gather_subset=['all'])

# Generated at 2022-06-11 02:15:14.579486
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_default_collectors
    from ansible.module_utils.facts import get_default_filter_spec

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector

    # mock out AnsibleModule - as its outside of this module, so can't be mock'd out directly
    import sys
    import mock
    # mock out AnsibleModule - as its outside of this module, so can't be mock'd out directly
    sys.modules['ansible.module_utils.basic'] = mock.Mock()

    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(AnsibleModule):
        def __init__(self):
            self.params = dict()

# Generated at 2022-06-11 02:15:22.986345
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Run a unit test on the ansible_facts function.

    '''
    import os
    import shutil

    from ansible import constants as C
    from ansible.plugins.loader import module_utils_loader
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import add_namespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    import pytest

    # Write a fake ansible.cfg, so constants.load_config_file() will run without
    # throwing an exception, see the docs at
    # https://docs.ansible.com/ansible/latest/reference_appendices/config.html#ansible-configuration-settings


# Generated at 2022-06-11 02:15:24.645377
# Unit test for function get_all_facts
def test_get_all_facts():
    assert get_all_facts(module=None)



# Generated at 2022-06-11 02:15:35.647809
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit test function for function ansible_facts'''
    from ansible.compat.tests import mock
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # Using a mock default collector class because the real default collector class is
    # too hard to instantiate.
    # The real default collector class requires too many dependencies to create.
    # (eg. subprocess, platform.linux_distribution, os.walk)
    mock_collector_class = mock.MagicMock()
    mock_collector_class.name = 'mock_collector_class'

    mock_ansible_collector = mock.MagicMock()
    # Want to mock the get_ansible_collector method on the ansible_collector module.
    # However,

# Generated at 2022-06-11 02:15:49.040907
# Unit test for function ansible_facts
def test_ansible_facts():
    """Unit test for ansible_facts function."""
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_native

    import yaml
    import os

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import facts

    import pytest

    # TODO: This test needs cleaning up and moving to unit tests.
    # Test data
    cwd = os.path.dirname(__file__)

# Generated at 2022-06-11 02:15:58.075659
# Unit test for function ansible_facts
def test_ansible_facts():

    # mock the module object and its minimal required attrs
    class MockModule(object):
        def __init__(self, param_dict):
            self.params = param_dict
            self.fail_json = None

    # create and run the fact collection
    fact_dict = ansible_facts(MockModule({}))

    assert isinstance(fact_dict, dict)
    assert 'all_ipv4_addresses' in fact_dict
    assert 'all_ipv6_addresses' in fact_dict
    assert 'ansible_bios_date' in fact_dict
    assert 'ansible_bios_version' in fact_dict
    assert 'ansible_date_time' in fact_dict

# Generated at 2022-06-11 02:16:05.903580
# Unit test for function get_all_facts
def test_get_all_facts():
    import mock
    import json

    # Create a mock instance of the AnsibleModule() class
    mod = mock.Mock()
    mod.params = {
        'gather_subset': ['all'],
    }
    mod.run_command = mock.Mock(side_effect=get_commmand_output)

    # Call it
    facts = get_all_facts(module=mod)

    # assert facts were returned
    assert 'ansible_architecture' in facts
    assert facts['ansible_architecture'] == 'x86_64'


# helper function for test_get_all_facts() unit test

# Generated at 2022-06-11 02:16:17.174385
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    class TestModule:
        params = {
            'gather_subset': ['all']
        }

    class TestFactCollector(BaseFactCollector):
        def __init__(self, namespace=None, *args, **kwargs):
            super(TestFactCollector, self).__init__(*args, **kwargs)
            self.namespace = namespace

        def collect(self, module=None, collected_facts=None):
            if self.namespace:
                if not collected_facts:
                    collected_facts = {}

# Generated at 2022-06-11 02:16:28.464039
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    import pytest

    # basically same test as for ansible_collector.get_ansible_collector
    # but don't want to rely on that code to be working

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    class MockCollector(object):
        def __init__(self, namespace, fact_list):
            self.namespace = namespace
            self.fact_list = fact_list

        def collect(self, module):
            return dict((fact, fact) for fact in self.fact_list)


# Generated at 2022-06-11 02:16:47.979237
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(argument_spec=dict())
    test_module.params['gather_subset'] = ['!all']
    test_module.params['filter'] = '*'

    # Gather facts and populate fact cache
    ansible_facts(module=test_module)
    assert len(cache.FACT_CACHE) > 0

    # Verify all desired facts are present

# Generated at 2022-06-11 02:16:59.115888
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_facts

    # Create a fact in the module which answers the question:
    #   does the fact_collector.collect method find it?

    # Default for filter_spec is '*'.  So fact_76 will not be in the returned facts.
    # But fact_77 should be there, as it matches the default filter_spec.
    #
    # When the filter_spec is overridden with '*77'   then fact_77 will be in the facts.
    # When the filter_spec is overridden with '*76'   then fact_77 will not be in the facts.

# Generated at 2022-06-11 02:17:08.582815
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.collector import BaseFactCollector

    # clear the cache
    cache.FACT_CACHE = {}

    class test_module(object):

        def __init__(self):
            self.params = dict(foo='bar')
            self.ansible_facts = dict()
            self.fail_json = dict()

        def exit_json(self, **kwargs):
            self.ansible_facts = kwargs['ansible_facts']

        def fail_json(self, **kwargs):
            raise ValueError(kwargs['msg'])

    # make sure we get something back
    module = test_module()
    ansible_facts(module)
   

# Generated at 2022-06-11 02:17:18.379560
# Unit test for function ansible_facts
def test_ansible_facts():

    import ansible.module_utils.facts.ansible_facts as ansible_facts
    import ansible.module_utils.facts.default_collectors as default_collectors

    # adding one custom collector to the list of collectors
    collector_class_name = 'my_custom_collector_class_name'
    collector_class = type(collector_class_name, (object,), {})
    collector_class.NAME = collector_class_name
    collector_class.COLLECT_ORDER = 0
    collector_class.minimal_gather_subset = frozenset()
    collector_class.bypass_cache = lambda *args: False
    collector_class.collect = lambda *args: {collector_class_name: 'my_custom_collector_class_result'}
    all_collector_classes = {}


# Generated at 2022-06-11 02:17:30.049617
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts

    ansible_facts is only used in Ansible 2.0 or 2.1, so it's not necessary to mock the module
    instance.

    Test the code path that does not have gather_subset set.
    '''
    import ansible.module_utils.facts.namespace

    fake_facts = {'ansible_distribution': 'red hat'}
    expected_bare_facts = {'distribution': 'red hat'}
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    namespace.add_fact('distribution', 'red hat')

    collector = ansible_collector.AnsibleCollector(namespace)
    facts_dict = collector.collect()
    assert facts_dict == expected_bare_facts

    # Test the code

# Generated at 2022-06-11 02:17:40.269106
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        from ansible.module_utils.facts.network.base import NetworkCollector
        import six
    except ImportError:
        # If Ansible is too old to have NetworkCollector, then just skip this test.
        # This can happen for an Ansible 2.2.2 build using a fact collection from 2.4 .
        # Skipping the test should have no side effects.
        return

    module = MockAnsibleModule()

    # Test basic case
    fact_dict = ansible_facts(module)
    assert 'default_ipv4' in fact_dict

    # Test minimal gather_subset
    fact_dict = ansible_facts(module, gather_subset=['min'])
    assert 'default_ipv4' not in fact_dict

    # Test minimal gather_subset with NetworkFactsCollector


# Generated at 2022-06-11 02:17:48.762998
# Unit test for function ansible_facts
def test_ansible_facts():
    import platform
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.network.interfaces as interfaces
    import ansible.module_utils.facts.network.ipv4 as ipv4
    from ansible.module_utils.facts import _get_file_content as get_file_content
    from ansible.module_utils.facts.virtual.virtualbox import VirtualBox
    from ansible.module_utils.facts.virtual.kvm import KVM
    from ansible.module_utils.facts.virtual.openvz import OpenVZ
    from ansible.module_utils.facts.virtual.vserver import VServer
    from ansible.module_utils.facts.virtual.xen import Xen
    from ansible.module_utils.facts.virtual.vmware import VMware


# Generated at 2022-06-11 02:17:54.743037
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes

    class AnsibleModuleMock(object):

        def __init__(self, gather_subset):
            self.params = dict()
            self.params['gather_subset'] = gather_subset

    module = AnsibleModuleMock(['all'])
    facts = get_all_facts(module)
    assert 'ansible_os_family' in facts
    assert to_bytes(facts['ansible_os_family']) in ['RedHat', 'Debian']


# Generated at 2022-06-11 02:18:03.983918
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import os

    # Make sure we have a clean environment
    original_env = os.environ.copy()

    # Set up a fake AnsibleModule (most of the time!)
    class FakeAnsibleModule:
        def __init__(self, params):
            self.params = params

    module_args = {}
    fm = FakeAnsibleModule(params=module_args)

    # Test when we have a 'cache' arg in module_args
    gathered_facts = ansible_facts(fm)
    assert isinstance(gathered_facts, dict)

    # Test when we have a 'cache' arg in module_args
    module_args = {'cache': {}}
    fm = FakeAnsibleModule(params=module_args)
    gathered_facts = ansible_facts(fm)
   

# Generated at 2022-06-11 02:18:11.266268
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default='all'),
            gather_timeout=dict(type='int', default=10),
            filter=dict(type='str', default='*'),
        ),
        supports_check_mode=True,
    )

    facts_dict = ansible_facts(module)

    assert isinstance(facts_dict, dict)
    assert sorted(facts_dict) == sorted(PrefixFactNamespace(prefix='', namespace_name='ansible').namespace())
    for fact_name in facts_dict:
        assert facts_dict[fact_name] is not None
        assert fact_

# Generated at 2022-06-11 02:18:38.146876
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
    class MockModuleWithGatherSubset(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    module = MockModule()
    with_gather_subset_module = MockModuleWithGatherSubset(gather_subset=['all'])
    assert ansible_facts(module) == ansible_facts(with_gather_subset_module)
    assert not get_all_facts(module) == get_all_facts(with_gather_subset_module)



# Generated at 2022-06-11 02:18:44.717623
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts

    test_module = ansible.module_utils.facts.AnsibleModule(
        argument_spec=dict(gather_subset=dict(type='list', default=['min'])),
        mutually_exclusive=[],
    )

    facts = ansible_facts(test_module)

    assert type(facts) == dict
    assert 'ansible' in facts
    assert not facts['ansible'].get('facts')
    assert facts['ansible'].get('date_time', dict()).get('date')
    assert facts['ansible'].get('local', dict()).get('hostname')

# Generated at 2022-06-11 02:18:52.557725
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test get_all_facts using the localhost_facts.py plugin. we picked this one as it should
    be fairly stable'''

    from ansible.module_utils.facts import localhost_facts

    class DummyAnsibleModule(object):
        params = {
            'filter': '*',
            'gather_subset': ['all'],
            'gather_timeout': 10,
        }

    _facts = get_all_facts(DummyAnsibleModule())

    assert _facts['default_ipv4']['address'] == localhost_facts.get_localhost_facts(DummyAnsibleModule)['ansible_default_ipv4']['address']

# Generated at 2022-06-11 02:19:00.681385
# Unit test for function ansible_facts
def test_ansible_facts():
    '''test ansible_facts function'''
    import json
    import os
    import sys

    # Need to use AnsibleModule(argument_spec) as we need the gather_subset arg
    from ansible.module_utils.basic import AnsibleModule

    ANSIBLE_MODULE_UTILS_PATH = '/tmp/ansible_module_utils'
    if ANSIBLE_MODULE_UTILS_PATH not in sys.path:
        sys.path.append(ANSIBLE_MODULE_UTILS_PATH)
    from module_utils.common.network import add_ansible_module_args

    class AnsibleModuleMock(AnsibleModule):
        '''Override AnsibleModule to mock parameters, facts'''


# Generated at 2022-06-11 02:19:11.424979
# Unit test for function ansible_facts
def test_ansible_facts():

    # We can't directly unit test this, but we can at least make sure it runs.
    # For example, when upgrading the module_utils.facts api, this function
    # will immediately break and stop ansible, preventing a silent downgrade
    # of the facts module_utils.

    # Pretend we're a module and create an instance of an AnsibleModule.
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(required=False, type='list', default=['all']),
        gather_timeout=dict(required=False, type='int', default=10)
    ))

    facts_dict = ansible_facts(module=module)
    assert facts_dict

    # Set to 'custom' and run again

# Generated at 2022-06-11 02:19:18.159790
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import cache
    cache.FACTS_CACHE = {}
    from ansible.module_utils.facts.facts import Facts
    module = Facts()

    fact_names = ansible_facts(module).keys()
    assert fact_names >= {'bin_dir', 'default_ipv4', 'default_ipv6', 'default_module_replacer'}

# Generated at 2022-06-11 02:19:25.592541
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.system import System
    from ansible.module_utils.facts.network import Network
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.core import Core
    from ansible.module_utils.facts.legacy import Legacy
    from ansible.module_utils.facts.collector import get_collector_class
    # Mock a module
    class Mod:
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['all']
            self.params['filter'] = '*'
            self.params['gather_timeout'] = 30
            self.params['gather_network_resources'] = ['network']

    mod = Mod()

    all_collector_classes = get_

# Generated at 2022-06-11 02:19:35.827076
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils import basic

    test_module = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=None, type='list'),
            gather_timeout=dict(default=10, type='int'),
            filter=dict(default='*', type='str'),
        ),
        add_file_common_args=True
    )

    # Replace lsb_release with a custom collector with a dummy fact
    default_collectors.collectors['lsb_release'] = \
        AnsibleDummyLsbReleaseCollector(namespace=None)
    test_facts = ans

# Generated at 2022-06-11 02:19:42.031634
# Unit test for function get_all_facts
def test_get_all_facts():

    # Fake a module
    class FakeModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    fact_dict = get_all_facts(FakeModule(['!foo']))

    assert set(fact_dict.keys()) == {'date_time'}

# Generated at 2022-06-11 02:19:50.009633
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Unit test for function get_all_facts'''

    from mock import Mock, patch
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import OpenBSDDistributionFactCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    from ansible.module_utils.facts.system.pkg_mgr import PackageManagerFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector


# Generated at 2022-06-11 02:20:30.198765
# Unit test for function ansible_facts
def test_ansible_facts():

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            raise AssertionError('module should not call fail_json with args: {}'.format(kwargs))

    module = FakeModule()

    # attempt to collect facts with no gather_subset
    fake_facts = ansible_facts(module=module)
    assert (fake_facts['distribution'] == 'unknown')

# Generated at 2022-06-11 02:20:39.742923
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.dummy import DummyModule
    test_module = DummyModule()
    test_module.params = {'gather_subset': ['all']}
    test_facts = ansible_facts(module=test_module)
    assert test_facts['hostname'] == 'dummy'
    test_facts = ansible_facts(module=test_module, gather_subset=['all'])
    assert test_facts['hostname'] == 'dummy'
    test_facts = ansible_facts(module=test_module, gather_subset=['min'])
    assert 'hostname' not in test_facts



# Generated at 2022-06-11 02:20:51.151452
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import get_file_lines
    all_collectors = PrefixFactNamespace(namespace_name='ansible', prefix='')

    class Module:
        def __init__(self):
            self.params = dict(filter='*')

        def get_bin_path(self, bin_path, required=False, opt_dirs=[]):
            return '/bin/' + bin_path

    # create a module and collectors
    module = Module()
    facts = ansible_facts(module)

    if 'cpu' in facts:
        assert facts['cpu']['count'] > 0
    if 'processor' in facts['system']:
        assert facts['system']['processor']

    assert 'fqdn' in facts['local']

# Generated at 2022-06-11 02:21:00.906475
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        import ansible.module_utils.facts.namespace
        from ansible.module_utils.facts.namespace import PrefixFactNamespace
    except ImportError:
        # We didn't have the right version of ansible installed. Skip.
        return

    # Mock out the ansible.module_utils.facts.ansible_collector.get_ansible_collector method
    # We'll force it to return a mock object.
    mock_collector1 = object()
    def mock_get_collector(all_collector_classes, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
        return mock_collector1
    ansible_collector.get_ansible_collector = mock_get_collector

    # Mock out the collect method of the mock collector, so

# Generated at 2022-06-11 02:21:12.928654
# Unit test for function ansible_facts
def test_ansible_facts():
    # Mock an AnsibleModule, with a gather_subset of 'network'
    module = {}
    module['params'] = {}
    module['params']['gather_subset'] = 'network'

    # Create fake facts
    facts = {}
    facts['interface_ip'] = '1.1.1.1'
    facts['interface_mac'] = '01:23:45:67:89:ab'
    facts['interface_mask'] = '255.255.255.128'
    facts['all_ipv4_addresses'] = ['1.1.1.1', '1.1.1.2']
    facts['default_ipv4'] = facts['all_ipv4_addresses'][0]
    facts['default_ipv4']['alias'] = 'p0p1'

    #

# Generated at 2022-06-11 02:21:22.297828
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.default_collectors

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, required=True, opt_dirs=[]):
            return 'fake_path'

        def run_command(self, cmd, check_rc=True):
            return (0, 'fake_output', '')

        def _load_params(self):
            return

    fake_module = FakeModule({'a': 'b'})
    facts = ansible.module_utils.facts.ansible_facts(fake_module)
    assert facts['a'] == 'b'


# Generated at 2022-06-11 02:21:33.859043
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.basic_gather as basic_gather

    import ansible.module_utils.facts as facts
    facts.DEFAULT_GATHER_SUBSET = ['all']
    facts.DEFAULT_GATHER_TIMEOUT = 10
    facts.GATHER_SUBSET_STRATEGY = 'linear'

    # Fake AnsibleModule instance
    class FakeAnsibleModule():
        def __init__(self):
            self.params = {
                'gather_subset': ['all'],
                'gather_timeout': 10,
                'filter': '*'
            }

    fake_ans_mod = FakeAnsibleModule()

    fact_dict = get_all_facts(fake_ans_mod)
    assert 'default_ipv4' in fact_dict