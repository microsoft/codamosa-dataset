

# Generated at 2022-06-11 02:11:51.440891
# Unit test for function ansible_facts
def test_ansible_facts():

    # py3 compat
    try:
        from unittest.mock import Mock

        HAS_MOCK = True
    except ImportError:
        from mock import Mock

    HAS_MOCK = True

    mock_module = Mock()
    mock_module.params.get.side_effect = {'gather_subset': ['all'],
                                          'gather_timeout': 10,
                                          'filter': '*'}.get

    mock_module.get_bin_path.return_value = '/bin/cat'
    mock_module.run_command.side_effect = [0, 'foo\nbar\nbaz\n', '']

    # namespace_name='ansible', prefix='', include_paths=frozenset(['ansible_local']), exclude_paths=None
    # namespaces={

# Generated at 2022-06-11 02:11:54.694578
# Unit test for function ansible_facts
def test_ansible_facts():
    module = MockAnsibleModule()
    facts_dict = ansible_facts(module)
    assert facts_dict
    # 'all' is a special case, it should return all collectors available
    assert len(facts_dict) == len(default_collectors.collectors)

# Generated at 2022-06-11 02:11:59.972149
# Unit test for function ansible_facts
def test_ansible_facts():
    mock_ansible_module = MagicMock()
    mock_ansible_module.params = {'filter': '*'}

    result = ansible_facts(mock_ansible_module)

    assert 'processor' in result
    assert 'distribution' in result

# Generated at 2022-06-11 02:12:10.517769
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.modules.system import setup
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector

    module = setup.AnsibleModule({})
    all_facts = ansible_facts(module=module, gather_subset=None)
    assert all_facts['distribution'] == 'unknown'
    assert all_facts['distribution_version'] == 'unknown'
    assert all_facts['distribution_major_version'] == 'unknown'

    # don't collect network facts
    module = setup.AnsibleModule({'gather_subset': ['!network']})
    all_facts = ansible_facts(module=module, gather_subset=None)

# Generated at 2022-06-11 02:12:20.606008
# Unit test for function ansible_facts
def test_ansible_facts():
    # mock defaults and module_utils.facts
    try:
        import ansible.module_utils.facts.system.distribution
        import ansible.module_utils.facts.system.pkg_mgr
        import ansible.module_utils.facts.system.platform
        import ansible.module_utils.facts.system.service_mgr
        import ansible.module_utils.facts.system.user
        from ansible.module_utils.facts import ansible_collector
        from ansible.module_utils.facts.collector import BaseFactCollector
        from ansible.module_utils.facts.collector import collect_only_if
    except ImportError:
        raise Exception('Could not import module_utils.facts. Verify you are using ansible 2.0+')

    # set up base mocks
    # mock ansible_collect

# Generated at 2022-06-11 02:12:32.577918
# Unit test for function get_all_facts
def test_get_all_facts():
    ''' Unit test for function get_all_facts
    '''
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import default_collectors
    from ansible.compat.tests.mock import create_autospec
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.network.base import NetworkCollector
    import os

    # create instance of ansible module to pass to the collector, that can be used by the
    # gather_facts method.
    module = create_autospec(ansible_module.AnsibleModule)
    module.params['gather_subset'] = ['all']
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_

# Generated at 2022-06-11 02:12:44.295063
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Test that namespaced facts are returned as plain facts, without the 'ansible_' namespace
    '''
    from ansible.module_utils.facts import FACT_CACHE
    default_collectors.add_negateable_default_collectors()

    class FakeModule(object):
        def __init__(self):
            self.params = {'filter': '*'}

        def get_option(self, option):
            return self.params.get(option)

        def set_fact(self, fact_name, fact_value):
            self.facts[fact_name] = fact_value

    FACT_CACHE.reset()
    fake_module = FakeModule()
    facts_dict = ansible_facts(fake_module, gather_subset=['ansible_system'])

    assert facts

# Generated at 2022-06-11 02:12:56.111532
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test function ansible_facts by calling it as if it were called from library/command/module code.

    Ideally this would be done with py.test, but this allows the test to share code with
    the function being tested.
    '''
    import os

    import unittest

    import ansible.module_utils.facts.legacy
    from ansible.module_utils.facts import collector

    # fake the module for module_utils.facts.get_all_facts
    class FakeAnsibleModule():
        def __init__(self):
            self.params = {}
    fake_module = FakeAnsibleModule()

    # put a test file in the same directory as the test_ansible_facts code
    facts_dir = os.path.dirname(__file__)

# Generated at 2022-06-11 02:13:07.370612
# Unit test for function ansible_facts
def test_ansible_facts():

    import ansible_collections.network.common
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.urls import fetch_url

    module_test_case = ansible_collections.network.common.plugins.module_utils.test.test_module.TestModule()

    cfg = dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*',
        namespace='ansible',
        prefix='',
    )

    module_test_case.params = cfg

    test

# Generated at 2022-06-11 02:13:16.906927
# Unit test for function ansible_facts
def test_ansible_facts():
    # Use the AnsibleModuleMock class to simulate the module object from Ansible
    from ansible.module_utils.facts.utils.collectors import AnsibleModuleMock
    from ansible.module_utils._text import to_bytes

    class AnsibleModuleMock2(AnsibleModuleMock):
        def __init__(self, check_mode):
            super(AnsibleModuleMock2, self).__init__(check_mode)
            self.params = {'gather_subset': ['all'], 'gather_timeout': 10, 'filter': '*'}

    # Create an instance of the mock class
    module = AnsibleModuleMock2(check_mode=False)

    # Call the ansible_facts method
    ansible_facts_dict = ansible_facts(module)

    # Make sure the

# Generated at 2022-06-11 02:13:28.062916
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.network as network_facts

    # set up a fake module.  It has no params, so ansible_facts() will use defaults
    module = MockAnsibleModule()

    assert get_all_facts(module) == ansible_facts(module)

    #  test setting gather_subset.
    gather_subset=frozenset(['network'])
    assert get_all_facts(module) == ansible_facts(module, gather_subset=gather_subset)


# Generated at 2022-06-11 02:13:38.427146
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.distribution

    class FakeModule:
        params = dict(
            filter='*distribution',
            gather_subset=['all'],
            gather_timeout=10,
        )

    fake_module = FakeModule()
    facts = ansible_facts(fake_module)

    # Expect facts to be a dict
    assert isinstance(facts, dict)

    # Expect keys to be strings
    for key in facts:
        assert isinstance(key, str)

    # Expect values to be strings, or lists of strings
    for value in facts.values():
        if isinstance(value, list):
            for val in value:
                assert isinstance(val, str)
        else:
            assert isinstance(value, str)

# Generated at 2022-06-11 02:13:46.594441
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    '''
    Unit test for get_all_facts

    :return:
    '''

    param = {'gather_subset': ['all'] }
    mock_module = type('MockModule', (), {'params': param})
    mock_module = mock_module()

    value = get_all_facts(mock_module)

    assert len(value) > 0



# Generated at 2022-06-11 02:13:55.448636
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import mock

    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    class MockModule(object):
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-11 02:14:07.599579
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys

    class mock_module(object):
        '''fake Module class so we can mock an AnsibleModule object'''
        def __init__(self, **kwargs):
            self.params = kwargs
            self.facts = None

    all_facts = ansible_facts(
        module=mock_module(
            gather_subset=['all'],
            gather_timeout=20,
            filter='ansible_*',
        ),
    )

    # test that non-empty facts are returned
    assert isinstance(all_facts, dict)
    assert len(all_facts) > 0

    # test that all expected module params are present
    assert all_facts['gather_subset'] == ['all']
    assert all_facts['gather_timeout'] == 20

# Generated at 2022-06-11 02:14:12.058521
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit test for module_utils.facts.ansible_facts
    '''

    module = fake_ansible_module()

    facts = ansible_facts(module)
    assert facts['python']['version']['major'] == '2'



# Generated at 2022-06-11 02:14:21.837259
# Unit test for function get_all_facts
def test_get_all_facts():

    # This is a very minimal fake impl of AnsibleModule just enough to make
    # get_all_facts work.
    class FakeModule(object):
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-11 02:14:22.454570
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-11 02:14:31.437730
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.legacy import ansible_compat_fix
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.facts import get_collector_config
    from ansible.module_utils.facts.facts import get_default_config_file

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.legacy import ansible_compat_fix
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

# Generated at 2022-06-11 02:14:32.307639
# Unit test for function ansible_facts
def test_ansible_facts():
    # TODO: mock AnsibleModule
    pass

# Generated at 2022-06-11 02:14:47.235390
# Unit test for function ansible_facts
def test_ansible_facts():
    # This test will pass in local py3.5 env, but fail in py2.7 env.
    import ansible.module_utils.facts.network
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestAnsibleModule:
        params = {'filter': '*'}


# Generated at 2022-06-11 02:15:00.068299
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import os
    import pytest
    from string import ascii_letters

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_class

    here = os.path.abspath(os.path.dirname(__file__))
    test_data_dir = os.path.join(here, 'unit-test-fixtures', 'collection', 'ansible_module_utils')

    test_datafile_name = 'ansible_facts_sample_data.json'

# Generated at 2022-06-11 02:15:05.329530
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.virtual import VirtualCollector

    fact_collector = ansible_facts(None, gather_subset=['network'])
    assert fact_collector['network_interfaces'] == VirtualCollector.interfaces_dict



# Generated at 2022-06-11 02:15:12.180133
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    test_cases = [
        {'gather_subset': None, 'gather_timeout': None, 'expected': ['all']},
        {'gather_subset': ['all'], 'gather_timeout': None, 'expected': ['all']},
        {'gather_subset': ['all', 'foo'], 'gather_timeout': None, 'expected': ['all']},
        {'gather_subset': ['foo', 'bar'], 'gather_timeout': None, 'expected': ['foo', 'bar']},
        {'gather_subset': ['foo', 'bar'], 'gather_timeout': 10, 'expected': ['foo', 'bar']},
    ]


# Generated at 2022-06-11 02:15:21.842217
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit test for function ansible_facts
    '''
    from ansible.module_utils import basic
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Create a fake module
    module = basic.AnsibleModule(
        argument_spec={
            'gather_subset': {'required': False, 'type': 'list', 'default': []},
            'gather_timeout': {'required': False, 'type': 'int', 'default': 10},
            'filter': {'required': False, 'type': 'str', 'default': '*'},
        },
        supports_check_mode=True
    )

    # Expectations for plugin_dirs from the default_collectors.py
    expected

# Generated at 2022-06-11 02:15:33.392396
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.basic import AnsibleModule

    class TestAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestAnsibleModule, self).__init__(*args, **kwargs)
            self.params = {'gather_subset': 'all'}
    test_module = TestAnsibleModule()
    facts_dict = ansible_facts(module=test_module)

    if not isinstance(facts_dict, dict):
        raise AssertionError('ansible_facts return is not a dict, was type: %s'
                             % type(facts_dict))


# Generated at 2022-06-11 02:15:46.616623
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts.collector

    class MyFactCollector(BaseFactCollector):

        NAME = 'my_facts'

        def collect(self, module=None, collected_facts=None):
            return {'key': 'value'}

    namespace = PrefixFactNamespace(namespace_name='ansible')
    ansible.module_utils.facts.collector.collectors.append(MyFactCollector(namespace))

    class DummyModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    module = DummyModule()
    facts_dict = get_

# Generated at 2022-06-11 02:15:57.286877
# Unit test for function ansible_facts
def test_ansible_facts():
    try:
        import ansible.modules.system.setup  # noqa
        has_setup_module = True
    except ImportError:
        # ansible < 2.9 use ansible.module_utils.basic.AnsibleModule
        has_setup_module = False

    # test import of compat api on ansible 2.3 and earlier
    import ansible.module_utils.facts  # noqa

    from ansible.module_utils._text import to_bytes

    # test import of compat api on ansible 2.4 and later
    from ansible.module_utils.facts import ansible_facts, get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors


# Generated at 2022-06-11 02:16:06.698939
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts
    # fake module_utils.facts.AnsibleModule
    fake_module = type('FakeModule', (), {'params': {}})
    fake_module = fake_module()

    # fake module.params['gather_subset']
    fake_gather_subset = ['all']
    fake_module.params['gather_subset'] = fake_gather_subset
    fake_module.params['gather_timeout'] = 10

    # fake module.params['filter']
    fake_filter = 'fact1'
    fake_module.params['filter'] = fake_filter

    # fake default_collectors.collectors
    fake_collectors = []

    # fake ansible_collector.get_collector

# Generated at 2022-06-11 02:16:17.772373
# Unit test for function ansible_facts
def test_ansible_facts():

    import mock
    import ast
    import os

    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts

    # Create a mock module object
    mock_module = mock.MagicMock()
    mock_module.check_mode = False

    # Make it possible to get attrs from that mock_module
    mock_module.configure_mock(**{
        'params.get.return_value': None,
        'fail_json.return_value': False,
    })

    mock_module.params = {
        u'_ansible_verbose_override': True,
        u'gather_subset': [u'!all', u'hardware'],
        u'gather_timeout': 1,
    }

    # Put the mock module into the module utils


# Generated at 2022-06-11 02:16:38.210065
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector

    def main_test():
        ###########################################
        # Test ansible_facts with gather_subset=['all']
        ###########################################

        gather_subset = ['all']
        gather_timeout = 10

        # Verify that if we pass a dictionary of dummy facts, we get the same dictionary back
        # (with any 'ansible_' prefixes removed)
        dummy_facts = {'dummy': 123, 'ansible_dummy': 456}
        dummy_module = DummyModule(params={'gather_subset': gather_subset, 'filter': '*'})
        dummy_module.ansible_facts = dummy_facts
        result_dict = ansible_facts(module=dummy_module)

# Generated at 2022-06-11 02:16:49.654381
# Unit test for function ansible_facts
def test_ansible_facts():
    '''ansible_fact should return a dict with top level keys named ansible_facts'''

    from ansible.module_utils.facts.f5.f5facts import F5Facts
    from ansible.module_utils.facts.asm.asmfacts import AsmFacts
    from ansible.module_utils.facts.network.networkfacts import NetworkFactCollector

    # module is a mock AnsibleModule instance
    module = dict()

    # import the fact_collectors to test
    fact_collectors = [F5Facts, AsmFacts, NetworkFactCollector]

    # override the _load_collectors function on the ansible_collector module
    # to load the test fact collector classes
    ansible_collector._load_collectors = lambda: fact_collectors

    # load the facts
    facts = ansible_

# Generated at 2022-06-11 02:17:00.921037
# Unit test for function get_all_facts
def test_get_all_facts():

    # dummy argparse object that  mimics a real AnsibleModule
    class ModuleArgs(object):
        def __init__(self):
            self.params = {}

    module_args = ModuleArgs()
    module_args.params['gather_subset'] = ['all']
    module_args.params['gather_timeout'] = 0

    class AnsibleModule(object):
        def __init__(self):
            self.params = module_args.params

    ansible_module = AnsibleModule()

    result = get_all_facts(module=ansible_module)
    assert 'default_ipv4' in result.keys()

    # Verify same result if there's no gather_subset arg
    ansible_module.params.pop('gather_subset')

# Generated at 2022-06-11 02:17:07.181456
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import random
    import errno
    import tempfile
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.lsb import LsbFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY3

    plugin_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 02:17:16.448184
# Unit test for function ansible_facts
def test_ansible_facts():
    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.failed = False
            self.fail_json = self.fail
            self.exit_json = self.success
            self.warnings = list()

        def fail(self, msg):
            self.failed = True
            self.msg = msg

        def success(self, msg):
            pass

    class MockCollector(object):
        def __init__(self, facts_dict, module=None):
            self.facts_dict = facts_dict
            self.module = module

        def collect(self, module=None):
            return self.facts_dict

    fact_dict = {'a': 1, 'b': 2}
    gather_subset = ['!all', 'discard_me', '!foo']

# Generated at 2022-06-11 02:17:25.295041
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import _get_all_facts_from_module

    mod = AnsibleModule(argument_spec=dict())
    mod.params = {'gather_subset': ['all']}

    facts = _get_all_facts_from_module(module=mod)
    assert facts['ansible_facts']
    assert mod.params['gather_subset'] == facts['ansible_facts']['gather_subset']



# Generated at 2022-06-11 02:17:33.353921
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts as facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.default import DefaultNetworkCollector
    import ansible.module_utils.facts.test.test_default_collectors as test_default_collectors

    class MockAnsibleModule:
        def __init__(self, params):
            self.params = params

    # test with gather_subset = 'all'
    module = MockAnsibleModule({})

    all_collector_classes = default_collectors.collectors



# Generated at 2022-06-11 02:17:42.027482
# Unit test for function get_all_facts
def test_get_all_facts():
    module = MagicMock()
    module.params = {'gather_subset': ['all']}

    expected_facts_dict = {
        'demo_fact': 'demo_fact_value',
        'demo_fact_2': 'demo_fact_2_value'
    }

    with patch('ansible.module_utils.facts.ansible_collector.get_ansible_collector') as mock:
        mock.return_value = MagicMock(collect=MagicMock(return_value=expected_facts_dict))
        assert get_all_facts(module) == expected_facts_dict

# Generated at 2022-06-11 02:17:49.424560
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.os_facts import OpenBSD
    from ansible.module_utils.facts.system import OpenBSD

    openbsd_os_facts = OpenBSD()
    openbsd_system_facts = OpenBSD()
    openbsd_system_facts.add_os_facts(openbsd_os_facts)


# Generated at 2022-06-11 02:18:01.306704
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.processor

    ansible.module_utils.facts.namespace.BaseFactNamespace
    ansible.module_utils.facts.collectors.BaseFactCollector
    ansible.module_utils.facts.system.DistributionFactCollector
    ansible.module_utils.facts.network.NetworkFactCollector
    ansible.module_utils.facts.virtual.VirtualizationFactCollector
    ansible.module_utils.facts.processor.ProcessorsFactCollector

    # can't run unit test on this file directly,

# Generated at 2022-06-11 02:18:32.027572
# Unit test for function ansible_facts
def test_ansible_facts():
    # following lines needed for importing the module under test
    import sys
    sys.modules['ansible'] = __import__('ansible_fake_module')
    sys.modules['ansible.module_utils'] = __import__('ansible_fake_module')
    import get_all_facts

    # fake ansible module
    class FakeModule(object):
        def __init__(self):
            self.params = dict()

    fm = FakeModule()

    # Gather_subset param not supplied, default to all
    fm.params['gather_timeout'] = 10
    actual_result = get_all_facts.ansible_facts(module=fm)

# Generated at 2022-06-11 02:18:38.271057
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.facts
    mod = ansible.module_utils.facts.facts.get_module_facts(module_args=dict(filter='ip'))
    facts = ansible_facts(mod)
    # Make sure the fact collector didn't return any facts with the 'ansible_' prefix aka 'namespace'
    # the legacy facts module_utils module has no namespaces.
    assert not any(fact.startswith('ansible_') for fact in facts)

# Generated at 2022-06-11 02:18:47.656077
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.distribution

    # Fake up sys.platform, so we can run tests on ths server side
    old_sys_platform = ansible.module_utils.facts.system.distribution.sys.platform

    ansible.module_utils.facts.system.distribution.sys.platform = 'linux2'

    import ansible.module_utils.facts.system.distribution

    # Fake up platform.dist to return void
    old_platform_dist = ansible.module_utils.facts.system.distribution.platform.dist

    ansible.module_utils.facts.system.distribution.platform.dist = lambda *args, **kwargs: None

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector


# Generated at 2022-06-11 02:18:56.509462
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.system.distribution

    # The actual module class doesn't matter, mock the minimal functions to make
    # this code work.
    class FakeModule(object):
        def __init__(self):
            self.params = {}

    fake_module = FakeModule()
    ansible_distribution = ansible.module_utils.facts.system.distribution.Distribution()
    fact_subset_distribution_facts = ansible_distribution.populate()

    all_facts = get_all_facts(fake_module)

    assert 'distribution' in all_facts
    assert all_facts['distribution'] == fact_subset_distribution_facts

# Generated at 2022-06-11 02:19:08.907918
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    module_args = {
        'gather_subset': ['distribution'],
    }
    module = AnsibleModule(argument_spec={}, supports_check_mode=True,
                           bypass_checks=True, module_args=module_args)

    all_collector_classes = default_collectors.collectors
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-11 02:19:12.162836
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.test_module import GetAllFactsTestModule

    result = get_all_facts(GetAllFactsTestModule({'gather_subset': []}))
    assert result == {}

    result = get_all_facts(GetAllFactsTestModule({'gather_subset': ['all']}))
    assert result['default_ipv4']['address'] == '10.10.10.10'

    result = get_all_facts(GetAllFactsTestModule({'gather_subset': ['min']}))
    assert result['default_ipv4']['address'] == '10.10.10.10'


# Generated at 2022-06-11 02:19:22.447624
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import get_distribution
    from ansible.module_utils.facts.collector import BaseFactCollector

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    module = AnsibleModule(argument_spec={})

    def mocked_get_distribution(module):
        return 'RedHat'

    class MockedBaseFactCollector(BaseFactCollector):
        def filter_list(self, _):
            return ['fact1', 'fact2']
        def get_facts(self, module):
            return {'fact1':'value1', 'fact2':'value2'}


# Generated at 2022-06-11 02:19:33.916006
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit test to demonstrate that ansible_facts returns a dict that maps
    fact name to value, with no 'ansible_' prefix.'''

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import GatherSubsetFactCollector

    class MockModule():
        params = {}

    class MockFactCollector(FactCollector):
        NAME = 'ansible'

        def __init__(self):
            super(MockFactCollector, self).__

# Generated at 2022-06-11 02:19:46.725908
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ModuleStub

# Generated at 2022-06-11 02:20:00.046909
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    sys.modules['ansible'] = type('MockObject', (), {})()
    sys.modules['ansible.module_utils.facts'] = type('MockObject', (), {})()
    sys.modules['ansible.module_utils.facts'].default_collectors = type('MockObject', (), {})
    sys.modules['ansible.module_utils.facts.default_collectors'].collectors = \
        {'a': 'value'}
    module = type('MockObject', (), {'params': {}})()
    res = ansible_facts(module)
    assert 'a' in res


# Make the following methods callable by Ansible 2.2/2.3 modules
get_all_facts = get_all_facts
ansible_facts = ansible_facts

# Generated at 2022-06-11 02:20:52.438936
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test function 'ansible_facts'

    def fake_get_section_data(section_name):
        # Fake a section
        # ansible_apparmor facts
        fake_apparmor_facts = dict()
        fake_apparmor_facts['summary'] = 'Disabled'
        fake_apparmor_facts['profile'] = '<no profile>'

        # ansible_architecture facts
        fake_architecture_facts = dict()
        fake_architecture_facts['architecture'] = 'x86_64'
        fake_architecture_facts['hardwaremodel'] = 'x86_64'

        # ansible_distribution facts
        fake_distribution_facts = dict()
        fake_distribution_facts['distribution'] = 'Ubuntu'

# Generated at 2022-06-11 02:21:02.971273
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest
    from ansible.modules.system.setup import main
    from ansible.compat.tests.mock import patch
    import ansible.module_utils.facts.system.distribution
    from ansible.module_utils.facts import namespace

    # if we don't mock this, then fact collection hangs
    ansible.module_utils.facts.system.distribution.Distribution = lambda: None

    # mock out the date/time collector to return trivial data
    datetime_collector_name = 'ansible.module_utils.facts.system.date_time.DateTimeCollector'

# Generated at 2022-06-11 02:21:13.136267
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import FACT_CACHE
    from collections import namedtuple

    if 'local' in FACT_CACHE:
        del FACT_CACHE['local']

    module = namedtuple('module', ['params', 'facts'])
    module.params = {}
    module.params['gather_subset'] = None

    gather_subset = ['local']
    facts_dict = ansible_facts(module, gather_subset=['local'])
    assert 'local' in facts_dict

    gather_subset = ['all']
    facts_dict = ansible_facts(module, gather_subset=['all'])
    assert 'local' in facts_dict

# Generated at 2022-06-11 02:21:20.173593
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    import ansible.module_utils.facts.platform.freebsd

    facts_dict = ansible_facts(module=None)

    assert(facts_dict['distribution'] == 'FreeBSD')

    assert('pkg_mgr' in facts_dict)
    if facts_dict['pkg_mgr'] == 'pkg':
        assert(facts_dict['pkg_mgr_pkg_cache_dir'] == '/var/cache/pkg')
    else:
        assert(facts_dict['pkg_mgr_pkg_cache_dir'] is None)

# Generated at 2022-06-11 02:21:27.885616
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic_module
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    facts_dict = get_all_facts(basic_module.AnsibleModule(argument_spec={'gather_subset': dict(type='list', elements='str', default='all')}))

    # this will fail if any of the facts are not set
    for key in facts_dict.keys():
        assert facts_dict[key] is not None, 'Failed to collect fact %s' % key

# Generated at 2022-06-11 02:21:38.822412
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import dict_filter
    from ansible.module_utils._text import to_bytes, to_text

    import json

    import sys
    import os
    import tempfile
    import subprocess
    import copy

    # compat with python 2.6
    import json
    try:
        from subprocess import check_output
    except ImportError:
        def check_output(cmd_args, **kwargs):
            proc = subprocess.Popen(
                cmd_args, stdout=subprocess.PIPE, **kwargs)
            output, unused_err = proc.communicate()
            retcode = proc.poll()
            if retcode:
                cmd = kwargs.get("args")