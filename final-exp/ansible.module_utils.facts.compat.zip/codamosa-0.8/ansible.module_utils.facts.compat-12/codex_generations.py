

# Generated at 2022-06-11 02:11:44.573273
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import to_text
    from ansible.module_utils.facts import to_nice_string
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeAnsibleModule:
        def __init__(self, gather_subset=None, gather_timeout=None, filter=None):
            self.params = {'gather_subset': gather_subset, 'gather_timeout': gather_timeout, 'filter': filter}

    fake_module = FakeAnsibleModule()

    facts_dict = ansible_facts(fake_module)

    assert isinstance(facts_dict, dict)
    # the to_nice

# Generated at 2022-06-11 02:11:51.350928
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import module_facts
    # TODO:
    # - Mock out module_utils.facts.ansible_collector
    # - mock out module_facts.AnsibleModule so it can be configured to return the expected args
    #   and have them checked by the test
    # - mock out module_utils.facts.namespace.PrefixFactNamespace so it can be checked by the test
    pass

# Generated at 2022-06-11 02:11:59.138057
# Unit test for function ansible_facts

# Generated at 2022-06-11 02:12:03.494957
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockGatherSubsetModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    module = MockGatherSubsetModule()
    facts_dict = get_all_facts(module=module)
    assert 'default_ipv4' in facts_dict

# unit test for function ansible_facts

# Generated at 2022-06-11 02:12:11.195146
# Unit test for function get_all_facts
def test_get_all_facts():
    class Module:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    # 1st test, gather all subset
    module = Module(gather_subset=['all'])
    facts = get_all_facts(module)

    assert facts['distribution'] == 'Unknown'

    # 2nd test, gather some subset, not all
    module = Module(gather_subset=['network', 'hardware'])
    facts = get_all_facts(module)

    assert 'distribution' not in facts

# Generated at 2022-06-11 02:12:21.083924
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    sys.modules['ansible'] = None
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils import facts

    class MockDistributionFactCollector(DistributionFactCollector):
        def collect(self, module, collected_facts):
            return dict(ansible_distribution='asdf')

    original_collector_classes = facts.default_collectors.collectors
    facts.default_collectors.collectors = [
        c for c in facts.default_collectors.collectors
        if c is not DistributionFactCollector
    ]
    facts.default_collectors.collectors.append(MockDistributionFactCollector)

    import unittest


# Generated at 2022-06-11 02:12:32.662416
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec=dict(gather_subset='all',
                                                    gather_timeout='10',
                                                    filter_spec='*'))

    # Patch collector.get_collector_classes to return list of mock collectors
    module_name = u'test_ansible_facts'
    base_class = type(collector.BaseFactCollector)
    class_name = u'AnsibleModule'

# Generated at 2022-06-11 02:12:44.388307
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Basic unit test for module_utils.facts.ansible_facts
    '''

    test_module = FakeAnsibleModule(params={}, msg='', failed=False, changed=False)

    # test when ansible_module provides a gather_subset param
    test_module.params['gather_subset'] = ['min']
    data_in_minimal_gather_subset = ansible_facts(test_module)
    for key in data_in_minimal_gather_subset:
        # check all keys returned are in minimal_gather_subset
        assert key in default_collectors.minimal_gather_subset

    # test when ansible_module does not provide a gather_subset param
    test_module.params = {}

# Generated at 2022-06-11 02:12:56.203333
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test imports
    try:
        from ansible.module_utils.facts import ansible_collector
        from ansible.module_utils.facts import default_collectors
        from ansible.module_utils.facts.namespace import PrefixFactNamespace
    except ImportError:
        # no need to test ansible_facts if we can't import ansible.module_utils.facts
        return

    # We'll use the default_collectors, no need to mock them
    fake_all_collector_classes = default_collectors.collectors

    # Make an AnsibleModule mock
    class FakeModule(object):
        def __init__(self):
            self.called_params = {}
            self.params = {}


# Generated at 2022-06-11 02:13:04.926898
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for the ansible_facts method.
    '''

    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # fake out a module
    class AnsibleModule():

        def __init__(self):
            self.params = {}

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    module = AnsibleModule()

    facts_dict = ansible_facts(module)

    assert facts_dict['lsb']['description'] == 'Ubuntu'

# Generated at 2022-06-11 02:13:10.950511
# Unit test for function get_all_facts
def test_get_all_facts():
    class module(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}
    facts = get_all_facts(module())
    assert len(facts)
    assert 'env' in facts



# Generated at 2022-06-11 02:13:19.072057
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    # Test setting gather_subset
    assert ansible_facts(AnsibleModule(argument_spec={}), gather_subset=['!foo']) == {}
    # Test with an invalid gather_subset
    with pytest.raises(ValueError):
        ansible_facts(AnsibleModule(argument_spec={}), gather_subset=['foo'])
    # Test with an invalid gather_subset
    with pytest.raises(ValueError):
        ansible_facts(AnsibleModule(argument_spec={}), gather_subset=['!skipped'])
    # Test with no gather_subset
    assert ansible_facts(AnsibleModule(argument_spec={})) == {}

# Generated at 2022-06-11 02:13:29.962126
# Unit test for function get_all_facts
def test_get_all_facts():
    # This test will need to be re-written if we add any attributes to AnsibleModule.
    # For now, this will just make sure that it can run without exceptions.
    from ansible.module_utils._text import to_text

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

    # mock module object
    class DummyAnsibleModule():
        def __init__(self):
            self.params = dict()

    module = DummyAnsibleModule()
    module.params['gather_subset'] = ['all']

    all_facts = get_all_facts(module)

    # Just converting it to text to make sure it doesn't throw an exception.

# Generated at 2022-06-11 02:13:37.837940
# Unit test for function get_all_facts
def test_get_all_facts():
    module = MockAnsibleModule(params={'gather_subset': ['network', 'virtual']})
    facts = get_all_facts(module)
    assert facts['distribution'] == 'Mock Linux OS'
    assert facts['fqdn'] == 'test.example.net'
    assert facts['kernel'] == 'Linux'
    assert facts['virtualization_type'] == 'mock_vm'
    assert facts['virtualization_role'] == 'guest'
    assert 'ansible_all_ipv4_addresses' in facts



# Generated at 2022-06-11 02:13:50.221841
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test bare facts are properly namespaced'''

    import pytest
    from ansible.module_utils.facts import collector

    class FakeModule(object):
        class FakeParams(object):
            def __init__(self, gather_subset=None, gather_timeout=10, filter='*'):
                self.gather_subset = gather_subset
                self.gather_timeout = gather_timeout
                self.filter = filter

        def __init__(self, params):
            self.params = params

    class TestSubsetCollector(collector.BaseFactCollector):
        name = 'test_subset'
        _fact_ids = ['test_namespace']

        def collect(self, module=None, collected_facts=None):
            '''makes sure this is properly namespaced'''
            facts_

# Generated at 2022-06-11 02:14:01.362650
# Unit test for function ansible_facts
def test_ansible_facts():

    # create a mock module
    mock_module = MockModuleForAnsibleFacts()
    # mock_module.params is an AttributeDict
    # we want .get() to return None if the param is missing

    class EmptyAttributeDict(object):
        '''Mock a dict-like object that returns None for all attrib lookups.'''
        def __getattr__(self, attrib):
            return None

    mock_module.params = EmptyAttributeDict()

    # test that all is the default gather_subset, and default filter is *
    facts_dict = ansible_facts(mock_module)

    # test that the facts_dict is a dict
    assert isinstance(facts_dict, dict)

    # test that the dict has at least 1 item
    assert len(facts_dict) > 0

    # test

# Generated at 2022-06-11 02:14:10.575356
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit tests for ansible_facts function.
    '''
    from ansible.module_utils.facts import namespace_manager
    namespace_manager.init_namespace_manager()

    # create a simple module to pass to ansible_facts
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    # construct a JSON string version of the params needed for the module.
    # this is what would be passed in from the ansible CLI or the ansible python API
    # when the 'fact' special module is called
    params = {'gather_subset': ['all']}
    json_string_params = json.dumps(params)

    my_module = MockModule(params)

    # assert: running ansible_facts return a non-empty fact dictionary
    #         We can't

# Generated at 2022-06-11 02:14:20.950074
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule()
    ansible_facts = ansible_facts(module=test_module)
    # 'ansible_' facts should not be in the result since it is a 'PrefixFactNamespace'
    assert 'ansible_architecture' not in ansible_facts

    # sanity check - make sure 'ansible_architecture' is present in the Ansible 'ansible_' namespace
    # note we are passing in a 'PrefixFactNamespace'

# Generated at 2022-06-11 02:14:24.521659
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.modules.system import setup

    # Create a 'fake' module for testing
    module = setup.AnsibleModule(argument_spec={})

    facts = ansible_facts(module)

    assert isinstance(facts, dict)

# Generated at 2022-06-11 02:14:27.224903
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import gather_facts
    module = gather_facts.setup_gather_facts()
    get_all_facts(module)

# Generated at 2022-06-11 02:14:36.215512
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.modules.system import setup

    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['/nonexist']}

    fake_module = FakeModule()
    facts = get_all_facts(fake_module)

    assert len(facts) == 0

# Generated at 2022-06-11 02:14:46.361597
# Unit test for function ansible_facts
def test_ansible_facts():
    # I don't know how to get an AnsibleModule instance in a unit test that's not called as an
    # ansible module. So just test with a dummy class instead.
    class FakeAnsibleModule(object):
        def __init__(self, params):
            self.params = params
        def fail_json(self, **kwargs):
            assert False

    gather_subset = ['all']
    params_with_gather_subset = {
        'gather_subset': gather_subset
    }
    facts_dict = ansible_facts(FakeAnsibleModule(params_with_gather_subset))
    assert 'ansible_all_ipv4_addresses' in facts_dict.keys()
    assert facts_dict['ansible_all_ipv4_addresses'] is not None
   

# Generated at 2022-06-11 02:14:58.751877
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys

    # python2.7 compatibility
    if sys.version_info < (3, 0):
        import mock
    else:
        # In python v3, mock is included in unittest.mock
        from unittest import mock

    import module_utils.facts.namespace

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileSnippetCollector

    # create a fake class
    class MockClass(BaseFactCollector):
        # pylint: disable=too-few-public-methods

        name = 'mock'

        def collect(self, module):
            return {'mockfact': 'mockvalue'}

    # create a fake class that looks like a file snippet collector

# Generated at 2022-06-11 02:15:07.747271
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_text

    # fake module instance
    module = type('AnsibleModule', (object,), dict(params=dict(
        gather_subset=set(['all']),
        gather_timeout=10,
        filter='*',
    )))

    facts_dict = ansible_facts(module=module)

    assert 'platform' in facts_dict
    assert 'distribution' in facts_dict
    assert to_text(facts_dict['date_time']['iso8601']) == to_text(ansible_facts.get_date_time_iso8601())

# Generated at 2022-06-11 02:15:18.867671
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Tests the ansible_facts function for ansible v2.4.1'''

    import os
    import sys
    import unittest
    import pprint

    # Ad hoc testing
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system import distribution
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.system import distribution

    # Create a default set all of the default collectors
    collector_classes = default_collectors.collectors

    # Create the collector, passing in the collector classes

# Generated at 2022-06-11 02:15:29.885859
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import get_all_files_of_type
    from ansible.module_utils.facts.utils import ModuleDepFacts
    import os

    # get an ansible module to be used in the call to ansible_facts_module
    test_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    stdlib_dir = os.path.join(test_dir, 'lib', 'ansible', 'modules')
    module_files = ['system', 'pkg_mgr']
    modules = get_all_files_of_type(module_files, stdlib_dir, '.py')

# Generated at 2022-06-11 02:15:39.039424
# Unit test for function ansible_facts
def test_ansible_facts():
    import unittest
    import ansible.module_utils.facts.system.distribution as distribution
    import mock

    MockAnsibleModule = mock.MagicMock()
    mock_ansible_module_instance = MockAnsibleModule.return_value
    mock_ansible_module_instance.params = {}

    with mock.patch.object(distribution, 'Distribution') as mock_distribution:
        mock_distribution.return_value.detect.return_value = None
        ansible_facts(mock_ansible_module_instance)

    # make sure ansible_distribution fact was not collected
    mock_ansible_module_instance.exit_json.assert_called_once_with(
        ansible_facts={}
    )

    distro_instance = mock_distribution.return_value
    dist

# Generated at 2022-06-11 02:15:52.853860
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import get_collector_class

    # stub an ansible module
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    class AnsiFakeModule:
        def __init__(self):
            self.params = dict(
                gather_subset = ['hardware'],
                gather_timeout = 0,
                filter = 'my_fact'
            )

        class FakeAnsibleModule:
            def __init__(self):
                self.params = dict()
            def fail_json(self, msg):
                raise AssertionError(msg)



# Generated at 2022-06-11 02:16:03.381915
# Unit test for function ansible_facts
def test_ansible_facts():
    # Test with gather_subset=['network'] and filter=ansible_eth0
    class AnsibleModuleFake:
        def __init__(self, params):
            self.params = params

    gather_subset = ['network']
    filter_spec = 'ansible_eth0'


# Generated at 2022-06-11 02:16:15.117386
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes

    try:
        from ansible.module_utils.facts import default_collectors
        default_collectors_available = True
    except ImportError:
        default_collectors_available = False

    import ansible.module_utils.facts.system.distribution as distribution_collector
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr_collector
    import ansible.module_utils.facts.system.service_mgr as service_mgr_collector
    import ansible.module_utils.facts.system.user as user_collector
    import ansible.module_utils.facts.system.platform as platform_collector
    import ansible.module_utils

# Generated at 2022-06-11 02:16:31.767768
# Unit test for function ansible_facts
def test_ansible_facts():

    # mock of AnsibleModule object
    class FakeAnsibleModule:

        def __init__(self, **kwargs):
            self.params = kwargs

    # use a fixed subset of facts
    gather_subset = ['!foo', '*']
    params = {
        'gather_subset': gather_subset,
        'filter': '*'
    }

    module = FakeAnsibleModule(**params)
    ansible_facts = ansible_facts(module)

    # should have the correct subset of facts
    expected_facts = frozenset(['ansible_distribution', 'ansible_lsb', 'foo'])
    assert frozenset(ansible_facts) == expected_facts

    # should not have network facts
    assert foo not in ansible_facts

# Generated at 2022-06-11 02:16:42.545760
# Unit test for function get_all_facts
def test_get_all_facts():
    # stubbing
    class GatherSubsetParams:
        def __init__(self):
            self.params = {'gather_subset': ['all']}
        def get(self, key, default=None):
            return self.params.get(key, default)

    class ModuleFake:
        def __init__(self):
            self.params = GatherSubsetParams()
            self.fail_json = None

    module = ModuleFake()
    module.params = {'gather_subset': ['all']}

    # expected result
    result = get_all_facts(module)
    assert result is not None, "The 'facts' should not be empty"
    for key, value in result.items():
        assert key is not None, "key of the 'facts' should not be empty"
        assert value

# Generated at 2022-06-11 02:16:47.374002
# Unit test for function get_all_facts
def test_get_all_facts():
    module_args = { 'gather_subset': ['all'], 'gather_timeout': 60 }
    module = AnsibleModule(argument_spec=module_args)
    #all_facts = get_all_facts(module)
    #assert isinstance(all_facts, dict)

# Generated at 2022-06-11 02:16:52.167525
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.virtual.kvm import KvmFactCollector
    from ansible.module_utils.facts.virtual.vbox import VBoxFactCollector
    from ansible.module_utils.facts.virtual.vmware import VMwareFactCollector
    from ansible.module_utils.facts.virtual.xen import XenFactCollector
    from ansible.module_utils.facts.virtual.bhyve import BhyveFactCollector
    from ansible.module_utils.facts.virtual.virtualbox import VirtualboxFactCollector

# Generated at 2022-06-11 02:17:00.140867
# Unit test for function ansible_facts
def test_ansible_facts():
    # Simulate ansible 2.3/2.4 ansible_facts usage with gather_subset arg
    module = type('AnsibleModule', (object,), dict(params={'gather_subset': ['all']}))()
    facts = ansible_facts(module)
    assert isinstance(facts, dict)

    # Simulate ansible <2.3 ansible_facts usage without gather_subset arg
    module = type('AnsibleModule', (object,), dict(params={}))()
    facts = ansible_facts(module)
    assert isinstance(facts, dict)

# Generated at 2022-06-11 02:17:00.485812
# Unit test for function ansible_facts
def test_ansible_facts():
    pass

# Generated at 2022-06-11 02:17:09.371712
# Unit test for function get_all_facts
def test_get_all_facts():
    import sys

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    if sys.version_info[0] < 3:
        from mock import Mock
    else:
        from unittest.mock import Mock

    def get_all_facts(module):

        # mock parameters
        gather_subset = module.params['gather_subset']

        # create AnsibleModule mock
        mock = Mock(ansible_facts=ansible_facts)
        mock.params = {
            'gather_subset': gather_subset,
            'gather_timeout': 10
        }


# Generated at 2022-06-11 02:17:19.634139
# Unit test for function ansible_facts
def test_ansible_facts():
    # patch sys.platform
    plat_save = __builtin__.__dict__.get('__import__').platform
    __builtin__.__dict__.get('__import__').platform = 'linux'

    # patch moduleutils.facts
    moduleutils_facts_save = __builtin__.__dict__.get('__import__').moduleutils.facts
    # now we can use importlib.import_module to get the moduleutils.facts
    # This avoids the need to have moduleutils.facts.__init__.py in place.
    # moduleutils.facts imports lead to the need to mock a bunch of other things.
    moduleutils_facts = __builtin__.__dict__['__import__'](moduleutils_facts_save.__name__)
    __builtin__.__dict__.get('__import__').moduleutils

# Generated at 2022-06-11 02:17:30.698076
# Unit test for function ansible_facts
def test_ansible_facts():
    # needed to get the 'module' object
    import ansible
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import facts

    class TestModule(AnsibleModule):
        '''AnsibleModule stub for unit testing

        Mimics the API needed to test ansible_facts(module),
        but has a very small subset of the actual AnsibleModule API.
        '''
        def __init__(self, *args, **kwargs):
            self.params = dict()

            # param set to test behavior of gather_subset
            if 'gather_subset' in kwargs:
                self.params['gather_subset'] = kwargs['gather_subset']

            # param set to test filter_spec

# Generated at 2022-06-11 02:17:41.424156
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import module_utils
    # NOTE: requires a linux host to run tests on, but only the 'platform' fact
    # is used in the test.
    module_utils.DEFAULT_GATHER_SUBSET = ['ansible', 'platform']
    # TODO: convert to pytest, which has mock support
    try:
        from unittest.mock import Mock
    except:
        # Backport of Mock is available as 'mock', but must be installed separately
        from mock import Mock
    mock_module = Mock()
    mock_module.params.get.return_value = None
    platform_fact = ansible_facts(mock_module)['platform']
    assert isinstance(platform_fact, dict)
    assert platform_fact['distribution'] == 'Unknown'

# Unit test

# Generated at 2022-06-11 02:18:07.040508
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.system.apparmor
    import ansible.module_utils.facts.system.caps
    import ansible.module_utils.facts.system.cmdline
    import ansible.module_utils.facts.system.date_time
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.dns
    import ansible.module_utils.facts.system.env
    import ansible.module_utils.facts.system.fips
    import ansible.module_utils.facts.system.local
    import ansible.module_utils.facts.system.lsb
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils

# Generated at 2022-06-11 02:18:07.921379
# Unit test for function ansible_facts
def test_ansible_facts():
    print('ansible_facts')


# Generated at 2022-06-11 02:18:18.645176
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''
    class Module:
        def __init__(self, params):
            self.params = params

    # Note: gather_timeout param here is 10s and defaults to 10s in ansible_collector as well
    # so in this case, we expect the gather_timeout to be 10s.
    module = Module(params={'filter': 'ansible_distribution*'})
    result = ansible_facts(module)

    # There are a number of possible ansible_distribution facts on my workstation, but I'm sure there's an
    # ansible_distribution fact that's not empty.
    assert 'distribution' in result
    assert result['distribution'] != ""



# Generated at 2022-06-11 02:18:29.328823
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector

    default_ipv4 = default_collectors.collectors['network'].collect()['ansible_default_ipv4']
    cpu_count = default_collectors.collectors['processor'].collect()['ansible_processor_count']
    distribution = default_collectors.collectors['distribution'].collect()['ansible_distribution']

# Generated at 2022-06-11 02:18:39.801694
# Unit test for function get_all_facts
def test_get_all_facts():

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    # Test with gather_subset = all
    params = {'gather_subset': 'all'}
    tm = TestModule(params)
    facts_dict = get_all_facts(tm)

    # Test with gather_subset = hardware,virtual
    params = {'gather_subset': ['hardware', 'virtual']}
    tm = TestModule(params)
    facts_dict = get_all_facts(tm)

    # Test with gather_subset = hardware,virtual and fact_path = /etc/ansible/facts.d
    params = {'gather_subset': ['hardware', 'virtual'],
              'fact_path': '/etc/ansible/facts.d'}


# Generated at 2022-06-11 02:18:52.094091
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for the ansible_facts function.'''

    # NOTE: this test doesn't exercise the default_collectors or the subprocess_collectors which
    #       is the bulk of ansible_facts

    import ansible.module_utils.facts.processor
    from ansible.module_utils.facts import default_collectors

    # create a mock AnsibleModule object for the call to ansible_facts
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'gather_subset': ['all']})

    # create a mock FactCollector object that can return some facts
    class MockFactCollector(ansible.module_utils.facts.processor.BaseFactCollector):

        def __init__(self, *args, **kwargs):
            super(MockFactCollector, self).__init

# Generated at 2022-06-11 02:19:00.558034
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.interfaces import Interfaces

    # monkeypatch the module_utils.facts.default_collectors
    class TestCollector(NetworkCollector):
        '''A simple test collector for NetworkCollector'''

        name = 'test_collector'
        _fact_class = Interfaces

        def collect(self, module=None, collected_facts=None):
            '''Test collect method'''

            collected_facts[self.name] = {
                'test_key': 'test_value',
            }

            return collected_facts

    default_collectors.collectors = [TestCollector]

    # test param 'gather_subset'

# Generated at 2022-06-11 02:19:11.321065
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class TestModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}
        # TODO: add a module_return_values method.

    gather_subset = ['hardware', 'virtual']
    module = TestModule(gather_subset=gather_subset)
    facts = get

# Generated at 2022-06-11 02:19:20.737869
# Unit test for function get_all_facts
def test_get_all_facts():
    # fake AnsibleModule instance
    module = type('', (), {})()
    module.params = dict(gather_subset=['all'])
    module.params['_ansible_verbosity'] = 1

    # fake facts gathering
    # don't actually do this, fake it!
    import ansible.module_utils.facts.network as facts_network
    def foo(module):
        return {'foo': 'bar'}
    facts_network.get_network_facts = foo

    # run the module code
    facts = get_all_facts(module)

    # assert the results
    assert facts['foo'] == 'bar'

# Generated at 2022-06-11 02:19:29.404346
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # Test that get_all_facts returns dict with bare fact name (default_ipv4) as fact key,
    # and fact value as fact value.
    get_all_facts_dict = get_all_facts()
    for fact_key in get_all_facts_dict.keys():
        assert(fact_key.startswith('ansible_')) is False

# Generated at 2022-06-11 02:20:10.629506
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    import ansible.module_utils.facts.ansible_collector
    import ansible.module_utils.facts.system.distribution

    # Some distributions, eg CentOS 5.x and Windows Server 2012, don't have
    # /etc/os-release
    # So restore os-release state after we're done
    from distutils.version import StrictVersion
    from shutil import copyfile
    import os
    import sys

    os_release_path = '/etc/os-release'

# Generated at 2022-06-11 02:20:21.509115
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.test_utils import Ansible2_2ModuleArgs, Ansible2_3ModuleArgs

    valid_gather_subsets = [None, '!all', 'min', '!min', '!network', '!fips', '!procs', 'network',
                            'network,fips']
    for gather_subset in valid_gather_subsets:
        module_args = Ansible2_3ModuleArgs(gather_subset=gather_subset, filter='*').args()
        module = ansible_2_3_module_mock(module_args)
        facts_dict = get_all_facts(module)
        assert isinstance(facts_dict, dict)

# Generated at 2022-06-11 02:20:34.448107
# Unit test for function get_all_facts
def test_get_all_facts():

    # mock module to pass in
    class MockModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    gather_subset = ['all']

    # setup expected data

# Generated at 2022-06-11 02:20:43.830778
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    def test_module(*args, **kwargs):
        return FakeAnsibleModule(
            params=dict(
                gather_subset='all',
                gather_timeout=10,
                filter='*',
            )
        )

    class FakeAnsibleModule:
        '''Fake AnsibleModule for testing facts'''

        def __init__(self, **kwargs):
            self.params = kwargs['params']

    def fake_collector_class(**kwargs):
        '''Return a class that extends DistributionFactCollector, but overrides collect method to not
        raise NotImplementedError.

        Used to simulate a real distribution fact collector'''


# Generated at 2022-06-11 02:20:53.147128
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import MODULE_CACHE
    from ansible.module_utils.facts.utils import get_file_lines, get_file_content, parse_printenv
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.platform as platform
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr
    import ansible.module_utils.facts.system.service_mgr as service_mgr

    if 'MODULE_CACHE' in globals():
        MODULE_CACHE.clear()
    else:
        MODULE_CACHE = dict()

    MODULE_CACHE['command'] = dict()
    MODULE_CACHE['file'] = dict()
    #MODULE_

# Generated at 2022-06-11 02:20:57.735709
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={'gather_subset': {'default': ['all']}})
    ansible_facts(module)
    module.exit_json(changed=False, ansible_facts=ansible_facts(module))


# Generated at 2022-06-11 02:21:01.804748
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    module = FakeModule()
    facts = get_all_facts(module)

    assert type(facts) == dict


# Generated at 2022-06-11 02:21:11.895304
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'gather_subset': {'type': 'list',
                                                            'default': ['!all', '!min']},
                                           'gather_timeout': {'type': 'int',
                                                              'default': 10}})
    result = ansible_facts(module)
    assert result is not None
    assert type(result) == dict
    for key in result.keys():
        assert len(key) > 0
        assert type(key) == str
        assert type(result[key]) == dict

# Generated at 2022-06-11 02:21:18.880059
# Unit test for function ansible_facts
def test_ansible_facts():
    def test_module():
        return AnsibleModule(argument_spec={'gather_subset': dict(default=['all'])})

    module = test_module()
    facts_dict = ansible_facts(module)
    assert isinstance(facts_dict, dict)

    # the following are the minimal set of facts that are guaranteed to be present.
    # This guarantees we can execute some basic playbooks without any additional plugin code
    #
    # Note that the 'default_os' and 'default_ipv4' facts are marked as 'private'
    # this guarantees that they are not explicitly listed in the list of 'all' facts

# Generated at 2022-06-11 02:21:29.975918
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts

    from collections import namedtuple
    from ansible.module_utils.facts import default_collectors

    # mock out ansible_facts.module
    module = namedtuple('ansible_module', ['params', 'fail_json'])

    # make it behave like a 2.3 module
    module_params = {'gather_subset': ['all'],
                     'gather_timeout': 10,
                     'filter': '*'}
    module = module(params=module_params, fail_json=None)

    # make collector get_facts(module) return a dummy value
    class dummy_collector():
        def collect(self, module):
            return {'fact_name': 'fact_value'}

    mocker = dummy_collector()
    default