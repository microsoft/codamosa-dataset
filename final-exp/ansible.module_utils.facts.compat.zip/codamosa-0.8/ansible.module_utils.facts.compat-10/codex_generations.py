

# Generated at 2022-06-11 02:11:44.589955
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    import json

    module_args = dict(path='/bin:/usr/bin', gather_subset=['all'])

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )

    res_facts = ansible_facts(module)

    print(json.dumps(res_facts, indent=4, sort_keys=True))

# Generated at 2022-06-11 02:11:48.340398
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):
        def __init__(self):
            self.params = dict(gather_subset=['all'])

    module = FakeModule()
    assert(get_all_facts(module) == ansible_facts(module))



# Generated at 2022-06-11 02:11:57.867125
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import get_all_facts
    import ansible.module_utils.facts.network as network_facts_module # pylint: disable=unused-import
    import ansible.module_utils.facts.hardware as hardware_facts_module # pylint: disable=unused-import
    import ansible.module_utils.facts.virtual as virtual_facts_module # pylint: disable=unused-import
    import ansible.module_utils.facts.system as system_facts_module # pylint: disable=unused-import

    # FakeAnsibleModule defines

# Generated at 2022-06-11 02:12:06.436279
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    get_all_facts and ansible_facts are part of the 'ansible.module_utils.facts' api in Ansible,
    and are expected by modules.  But are not currently exported.  So we export them here.

    But that's not the end of the story.  We also want to expose them in the MODULE_UTILS_PATH
    so that module_utils/facts.py is found.  That's done by setting a FACTS_MODULE_UTILS_PATH
    environment variable in ansible/test/units/test_custom_facts.py
    '''
    import ansible.module_utils.facts as facts

    if hasattr(facts, 'get_all_facts'):
        assert facts.get_all_facts is get_all_facts


# Generated at 2022-06-11 02:12:14.417076
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class MockConfig(object):

        def __init__(self, params):
            self.params = params

    def _get_module_mock(params):
        item_config = MockConfig(params=params)
        module_mock = {'config': item_config}
        try:
            module_mock.get_bin_path = lambda x, opt_dirs=[] : ''
        except AttributeError:
            pass
        return module_mock

    module = _get_module_mock({'gather_subset': ['!all', 'network']})

    # test with arg gather_subset=None, should use param gather_subset=['!

# Generated at 2022-06-11 02:12:20.828798
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible.module_utils.facts import ansible_facts

    class MockModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}
            self.path_importer_cache = {}
    facts = ansible_facts(MockModule())
    assert isinstance(facts, dict)


# Generated at 2022-06-11 02:12:32.619054
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=None)})
    ansible_facts = ansible_facts(m, gather_subset=['!all', 'network'])
    assert 'ansible_all_ipv4_addresses' not in ansible_facts
    assert 'ansible_default_ipv4' in ansible_facts

    m = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['!all', 'network'])})
    ansible_facts = ansible_facts(m)
    assert 'ansible_all_ipv4_addresses' not in ansible_facts
    assert 'ansible_default_ipv4' in ansible

# Generated at 2022-06-11 02:12:44.341710
# Unit test for function ansible_facts
def test_ansible_facts():
    # Unit test for function ansible_facts
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    # create a mock class
    class MockModule:
        def __init__(self, gather_subset, gather_timeout, filter, params):
            self.params = params

    # create an instance of the mock class
    gather_subsets = ['all']
    gather_timeout = 10
    filter_spec = '*'
    params = {'gather_subset': gather_subsets, 'gather_timeout': gather_timeout, 'filter': filter_spec}
    module = MockModule(gather_subset=gather_subsets, gather_timeout=gather_timeout, filter=filter_spec, params=params)

    # call the method we are testing
    all_facts_dict = ans

# Generated at 2022-06-11 02:12:48.168087
# Unit test for function ansible_facts
def test_ansible_facts():
    module = FakeAnsibleModule(params={'gather_subset': '!all,!min'})
    facts = ansible_facts(module=module)

    assert isinstance(facts, dict)
    assert 'distribution' in facts



# Generated at 2022-06-11 02:12:50.042817
# Unit test for function ansible_facts
def test_ansible_facts():
    '''compatible api - unit test for ansible_facts function'''

# Generated at 2022-06-11 02:13:00.995686
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.namespace import FactsNamespace

    default_collector_classes = default_collectors.collectors

    fact_namespace = FactsNamespace(name='test')
    gather_timeout = 10
    minimal_gather_subset = frozenset()
    filter_spec = '*'


# Generated at 2022-06-11 02:13:09.741022
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import FacterCollector
    from ansible.module_utils.facts.collector import CmdlineCollector
    from ansible.module_utils.facts.collector import DistributionCollector
    from ansible.module_utils.facts.collector import DnfPackageManager
    from ansible.module_utils.facts.collector import YumPackageManager
    from ansible.module_utils.facts.collector import PkgMgrDpkg
    from ansible.module_utils.facts.collector import PkgMgrRPM
    from ansible.module_utils.facts.collector import ServiceMgrSysV
    from ansible.module_utils.facts.collector import ServiceMgrSystemD
    from ansible.module_utils.facts.collector import SELinuxCollector


# Generated at 2022-06-11 02:13:15.545255
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts

    for ansible_version in ['2.0', '2.1', '2.2', '2.3']:
        class MockModule:
            def __init__(self):
                self.params = {}
                self.ansible_version = ansible_version

        module = MockModule()
        result = ansible_facts(module)
        assert(result['python']['version']['major'] is not None)

# Generated at 2022-06-11 02:13:27.229932
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.legacy import command
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import get_distribution
    from ansible.module_utils.facts import get_distribution_version
    from ansible.module_utils.facts import get_file_systems
    from ansible.module_utils.facts import get_kernel_version
    from ansible.module_utils.facts import get_virtual
    from ansible.module_utils.facts import get_distribution_release

# Generated at 2022-06-11 02:13:38.078943
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.facter import FacterCollector
    from ansible.module_utils.facts.systemd import SystemdCollector
    from ansible.module_utils.facts.zb_snmp import SnmpCollector
    from ansible.module_utils.facts.vmware import VMWareCollector
    from ansible.module_utils.facts.hardware import HardwareCollector
    from ansible.module_utils.facts.network import NetworkCollector
    from ansible.module_utils.facts.virtual import VirtualCollector

    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    from ansible.module_utils.facts import default

# Generated at 2022-06-11 02:13:40.162032
# Unit test for function ansible_facts
def test_ansible_facts():

    fact_collector = ansible_facts()

    assert(len(fact_collector) > 0)


# Generated at 2022-06-11 02:13:52.103011
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockFactCollector(BaseFactCollector):
        """A mock fact collector"""

        name = 'mock'
        _fact_ids = ['foo']
        _platform = ''

        def collect(self, module=None, collected_facts=None):
            """Collect the facts."""
            return dict(foo="bar")

    class TestModule(object):
        def __init__(self, gather_subset):
            self.params = dict(gather_subset=gather_subset)

    module = TestModule(['mock'])

# Generated at 2022-06-11 02:14:04.288321
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import DEFAULT_GATHER_SUBSET
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    gather_subset = ['all', 'network']
    gather_timeout = 10

    all_facts = ansible_facts(module, gather_subset=gather_subset)
    assert 'default_ipv4' in all_facts
    assert 'default_ipv6' in all_facts

    # because module_utils.facts.ansible_facts should accept a backwards compatible
    # arg 'gather_subset', it should be possible to pass the legacy DEFAULT_GATHER_SUBSET
    # list object, for that object to be turned into a frozenset, and for it to work as

# Generated at 2022-06-11 02:14:13.224988
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector

    class AlwaysTrueFactCollector(BaseFactCollector):
        name = 'test.always_true'
        _fact_ids = set(['always_true'])

        def collect(self, module=None, collected_facts=None):
            return {'always_true': True}

    class AlwaysFalseFactCollector(BaseFactCollector):
        name = 'test.always_false'
        _fact_ids = set(['always_false'])

        def collect(self, module=None, collected_facts=None):
            return {'always_false': False}


# Generated at 2022-06-11 02:14:23.454960
# Unit test for function ansible_facts
def test_ansible_facts():
    import datetime
    import os
    import shutil
    import sys
    import tempfile
    import time

    import pytest

    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.facts.virtual import VirtualCollector

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import string_types

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # mock up an AnsibleModule

# Generated at 2022-06-11 02:14:37.824962
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Ansible facts must have exactly the right keys'''

    import os
    import json
    import pytest
    import sys

    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector

    # find the test dir
    current_filename = os.path.abspath(__file__)
    current_dir = os.path.dirname(current_filename)

    # Find the expected generated facts in this directory
    expected_file = os.path.join(current_dir, 'ansible_facts_expected.json')
    with open(expected_file, 'rb') as ff:
        expected = ff.read()


# Generated at 2022-06-11 02:14:47.394022
# Unit test for function ansible_facts
def test_ansible_facts():

    # allow to import
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils import basic

    # Create a 'fake' ansible module, to simulate what the ansible module
    # (i.e. os_facts) would do.
    test_module = basic.AnsibleModule(
        argument_spec={
            'gather_subset': {'default': ['all']},
            'gather_timeout': {'default': 10},
            'filter': {'default': '*'},
        },
        supports_check_mode=True,
    )

    # Run the ansible_facts() function.
    test_fact_dict = get_all_facts(module=test_module)
    assert 'distribution' in test_fact_dict

# Generated at 2022-06-11 02:15:00.119754
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import FactsCollector

    class TestModule():
        def __init__(self, params):
            self.params = params

    class MyFactsCollector(FactsCollector):
        '''A dummy FactsCollector class.
        '''
        def __init__(self, *args, **kwargs):
            super(MyFactsCollector, self).__init__(*args, **kwargs)

        def get_facts(self, module):
            '''Implements the get_facts method.

            Returns a dictionary of facts.
            '''

# Generated at 2022-06-11 02:15:06.931467
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # The default_collectors module does not export the collectors attribute in 2.3, 2.4 or 2.5
    # It does export it in 2.6 and master, so let's test it.
    #
    # Tests for 2.6 and master are very similar, however, the 2.6 implementation will check
    # gather_subset for the collector, and if not set, look for a gather_subset for the collector
    # in the module parameters.  Master does not yet do that.
    #
    # So in 2.6, if a fact collector is configured as a member of gather_subset, and not as part


# Generated at 2022-06-11 02:15:18.037574
# Unit test for function ansible_facts
def test_ansible_facts():
    module = mock.MagicMock()
    module.params = {}

    ansible_facts = ansible_facts(module)

    assert ansible_facts.get('kernel') is not None
    assert ansible_facts.get('distribution') is not None
    assert ansible_facts.get('distribution_version') is not None
    assert ansible_facts.get('distribution_file_parsed') is not None
    assert ansible_facts.get('distribution_major_version') is not None
    assert ansible_facts.get('distribution_release') is not None
    assert ansible_facts.get('os_family') is not None
    assert ansible_facts.get('all_ipv4_addresses') is not None

    assert ansible_facts.get('network_pubkey') is None

# Generated at 2022-06-11 02:15:28.469007
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts

    class AnsibleModule:
        def __init__(self, **kwargs):
            self.params = kwargs

    module = AnsibleModule(gather_subset=['!all', 'network'])
    facts = ansible_facts(module, gather_subset=module.params.get('gather_subset'))
    assert facts['kernel'] == 'Linux'
    assert 'distribution' not in facts
    assert 'dns' not in facts

    module = AnsibleModule(gather_subset=['env'])
    facts = ansible_facts(module, gather_subset=module.params.get('gather_subset'))
    assert 'kernel' not in facts
    assert 'distribution' not in facts
    assert 'dns'

# Generated at 2022-06-11 02:15:38.196903
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test for compat api for ansible 2.0/2.3 module_utils.facts.ansible_facts'''
    from ansible.module_utils._text import to_text

    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.facts import namespace

    import json

    class FakeAnsibleModule:
        def __init__(self, params):
            self.params = params

    module = FakeAnsibleModule({'filter': 'ansible_.*', 'gather_subset': 'all'})

    gather_subset = module.params.get('gather_subset', ['all'])
    gather_timeout = module.params.get('gather_timeout', 10)

# Generated at 2022-06-11 02:15:45.267060
# Unit test for function ansible_facts
def test_ansible_facts():
    import mock
    import json

    module = mock.MagicMock()
    module.params['gather_subset'] = ['all']
    facts_dict = ansible_facts(module)

    assert isinstance(facts_dict, dict)
    json.dumps(facts_dict)  # just make sure it serializes

    return True

# Generated at 2022-06-11 02:15:56.600488
# Unit test for function get_all_facts
def test_get_all_facts():
    import os
    import tempfile
    import unittest

    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.facts.system import distributor


    # Collect required facts
    def_subset = ['all']
    fact_namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    # Minimal subset must be included to have distribution_id, lsbrelease_id and
    # lsbrelease_description facts collected.
    minimal_gather_subset = frozenset(['local', 'lsb'])
    all_collect

# Generated at 2022-06-11 02:16:06.300598
# Unit test for function ansible_facts
def test_ansible_facts():
    # AnsibleModule is not specified as a param to ansible_facts, but it is needed by ansible_collector
    module_mock = Mock()

    # create a mock facts module
    class MockFactsModule(object):
        def __init__(self):
            self._name = 'mock_facts'

        @property
        def name(self):
            return self._name

        def get_fact(self, name, *args, **kwargs):
            self.name = name
            return name

    # collect the facts from the mock facts module
    mock_facts_module = MockFactsModule()

    test_name = 'test_name'
    test_value = 'test_value'
    mock_fact_name = 'test_mock_fact_name'

# Generated at 2022-06-11 02:16:25.588895
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        from ansible.module_utils.facts.namespace import PrefixFactNamespace
        from ansible.module_utils.facts import default_collectors
        from ansible.module_utils.facts import ansible_collector
        from ansible.module_utils.facts.network.base import NetworkCollector
    except ImportError:
        return

    all_collectors = dict((c.name(), c) for c in default_collectors.collectors)

    # Remove the NetworkCollector from all_collectors
    # NetworkCollector requires a module, which we are not passing in
    del all_collectors['Network']

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-11 02:16:31.827131
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.utils import FactsCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFacts
    from ansible.module_utils.facts.system.distribution import OpenBSDFactCollector
    from ansible.module_utils.facts.system.distribution import OpenBSDFacts
    from ansible.compat.tests import mock
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.facts.timeout import FactTimeoutError
    mock_module = mock.MagicMock()


# Generated at 2022-06-11 02:16:42.650443
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace
    ansible.module_utils.facts.namespace.PrefixFactNamespace = PrefixFactNamespace
    import ansible.module_utils.facts.default_collectors
    ansible.module_utils.facts.default_collectors.collectors = default_collectors.collectors
    import ansible.module_utils.facts.ansible_collector
    ansible.module_utils.facts.ansible_collector.get_ansible_collector = \
        ansible_collector.get_ansible_collector
    import ansible.module_utils.facts
    ansible.module_utils.facts.ansible_facts = ansible_facts
    from ansible.module_utils.facts.default_collectors import collect_subset_apparmor, \
        collect_

# Generated at 2022-06-11 02:16:51.719810
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    import ansible.module_utils.facts as facts

    test_module = facts.AnsibleModule(
        argument_spec={},
        mutually_exclusive=[],
        supports_check_mode=False,
        required_together=[]
    )

    # get_all_facts expects the module to have a 'gather_subset' param
    get_all_facts(test_module)
    test_module.params['gather_subset'] = ['all']
    get_all_facts(test_module)


# unit test for function ansible_facts

# Generated at 2022-06-11 02:17:02.975215
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import default_collectors

    class FakeAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = {'gather_subset': kwargs.get('gather_subset', ['all']),
                           'gather_timeout': kwargs.get('gather_timeout', 10),
                           'filter': kwargs.get('filter', '*')}

    # Test with no optional args
    module = FakeAnsibleModule()
    result = ansible_facts(module)
    assert 'ipv4' in result
    assert 'ipv6' in result
    assert 'default_ipv4' in result
    assert 'default_ipv6' in result

    # Test

# Generated at 2022-06-11 02:17:10.310024
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts as facts
    import ansible.module_utils.facts.namespace as namespace

    class DummyModule(object):
        def __init__(self, params=None):
            if params is None:
                params = {}
            self.params = params

    # the following code is borrowed from module_utils.facts.ansible_facts
    gather_subset = ['!all', 'foo', 'bar']
    gather_timeout = 10
    filter_spec = '*'
    module = DummyModule(params={'gather_subset': gather_subset, 'gather_timeout': gather_timeout, 'filter': filter_spec})


# Generated at 2022-06-11 02:17:21.765139
# Unit test for function ansible_facts
def test_ansible_facts():
    # Mock the AnsibleModule
    class AnsibleModule:

        def __init__(self, **kwargs):
            self.params = kwargs

    # default gather_subset
    module = AnsibleModule(gather_subset=None)
    # expect namespaced facts
    ansible_facts = ansible_facts(module, gather_subset=None)
    assert 'ansible_all_ipv4_addresses' in ansible_facts.keys()
    assert 'ansible_lsb' in ansible_facts.keys()
    assert 'ansible_lsb' in ansible_facts.keys()
    assert 'ansible_architecture' in ansible_facts.keys()
    assert 'ansible_local' in ansible_facts.keys()
    assert 'ansible_user_id' in ansible_

# Generated at 2022-06-11 02:17:31.533683
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import os
    import sys

    modules_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'modules')
    sys.path.insert(0, modules_path)

    module = AnsibleModule(argument_spec=dict())

    facts = ansible_facts(module)


# Generated at 2022-06-11 02:17:40.107556
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(required=False, default=['all'], type='list'),
            'gather_timeout': dict(required=False, default=10, type='int'),
            'filter': dict(required=False, default='*', type='str'),
        },
        supports_check_mode=True,
    )

    test_facts = ansible_facts(test_module)
    assert test_facts['environment'] == 'test'
    assert test_facts['distribution'] == 'ubuntu'

# Generated at 2022-06-11 02:17:44.561213
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts

    module = FakeModule()
    facts_dict = ansible_facts(module)
    assert 'default_ipv4' in facts_dict
    assert 'kernel' in facts_dict

# Unit tests for function get_all_facts

# Generated at 2022-06-11 02:18:05.978831
# Unit test for function get_all_facts
def test_get_all_facts():
    factlist = ['default_ipv4', 'default_ipv6']
    # Code under test is in module_utils.facts.get_all_facts
    import ansible.module_utils.facts
    facts = ansible.module_utils.facts.get_all_facts(None, factlist)
    assert len(facts) == 0

# Generated at 2022-06-11 02:18:15.088541
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import Namespace
    # Create a mocked module for testing
    class AnsibleModule(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
    module = AnsibleModule(params={'gather_subset': ['all'], 'gather_timeout': 10})
    # Create the bare namespace
    namespace = Namespace(namespace_name='ansible', prefix='')
    facts = ansible_facts(module, namespace=namespace)
    assert type(facts) == dict


# Generated at 2022-06-11 02:18:26.553820
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import os
    import sys
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    test_data_dir = os.path.normpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../../test/units/module_utils/network/common/test_data'))

    _module = __import__('ansible.module_utils.network.common.facts', fromlist=['AnsibleModule'])
    _module.__dict__['os'] = os
    _module.__dict__['sys'] = sys
    _module.__dict__['json'] = json
    _module.__dict__['tempfile'] = tempfile

    ansible_module = AnsibleModule({'gather_subset': 'all'})

# Generated at 2022-06-11 02:18:38.387500
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.processor.user import UserProcessor
    from ansible.module_utils.facts.processor.user import User
    from ansible.module_utils.facts.processor import network

    # Patch ansible.module_utils.facts.collector.ALL_COLLECTOR_CLASSES to only have
    # UserProcessor-- the only one that does not require root priveledges


# Generated at 2022-06-11 02:18:47.923964
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):
        def __init__(self, params=None):
            self.params = params or {}

    fake_facts = {'fact_a': 'alpha', 'fact_b': 'bravo', 'fact_c': 'charlie'}

    class FakeCollector(object):
        def __init__(self, module):
            self.module = module

        def collect(self):
            return fake_facts

    # patch the ansible_collector.get_ansible_collector function so we can return a mocked
    # collector
    def fake_ansible_collector(module):
        return FakeCollector(module)

    monkeypatch = MonkeyPatch()
    monkeypatch.setattr(ansible_collector, 'get_ansible_collector', fake_ansible_collector)

    # module

# Generated at 2022-06-11 02:18:50.909676
# Unit test for function get_all_facts
def test_get_all_facts():
    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    module = FakeModule(['network'])
    facts = get_all_facts(module)
    assert isinstance(facts, dict)

# Generated at 2022-06-11 02:18:59.754080
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.facts import AnsibleModule
    import sys, os
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # Create a dummy module
    base_module = AnsibleModule
    module_args = {}
    module = base_module(argument_spec=module_args)

    ansible_facts(module, gather_subset=None)
    assert module.params['gather_subset'] == ['all']

    module = base_module(argument_spec=module_args, gather_subset=['all'])
    ansible_facts(module, gather_subset=None)

# Generated at 2022-06-11 02:19:00.871219
# Unit test for function get_all_facts
def test_get_all_facts():
    # Put assertions here
    pass

# Generated at 2022-06-11 02:19:11.524448
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector.default import DefaultFactCollector
    from ansible.module_utils.facts.collector.network import NetworkFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class MockAnsibleModule:
        def __init__(self):
            self.params = dict(gather_subset=['all'])
        def get_bin_path(self, module):
            return module

    # If the 'all' gather subset is passed, we should instantiate a DefaultFactCollector and
    # a NetworkFactCollector. The NetworkFactCollector class only exists in Ansible 2.9+.
    network_fact_collector_names = ['NetworkFactCollector', 'DefaultFactCollector']
    ansible_module = MockAnsibleModule()
   

# Generated at 2022-06-11 02:19:18.160752
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_timeout': 10}
    fm = FakeModule()

    facts_dict = ansible_facts(fm)
    assert 'ansible_devices' in facts_dict
    assert 'ansible_system' in facts_dict

# Generated at 2022-06-11 02:20:03.320017
# Unit test for function get_all_facts
def test_get_all_facts():
    '''test compat shim for ansible 2.3 apis'''
    # ansible 2.3 facts api accepts a gather_subset arg
    # ansible 2.2 facts api does not accept a gather_subset arg.
    # So ensure we can pass/not pass a gather_subset as needed.

    # stub ansible module
    class AnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    module = AnsibleModule()

    # test for gather_subset arg with gather_subset arg
    fact_dict = get_all_facts(module)

    assert isinstance(fact_dict, dict)

    # test for gather_subset arg with no gather_subset arg
    del module.params['gather_subset']

    fact_dict

# Generated at 2022-06-11 02:20:14.562484
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors, ansible_collector
    import mock

    # Make sure ansible_collector is fully initialized by calling it.
    ansible_collector.get_ansible_collector(all_collector_classes=default_collectors.collectors)
    facts = ansible_facts(mock.MagicMock())
    # one of the facts of the system in which this test is run should be 'os_family'
    assert facts['os_family']

    # Test for issue #33812
    def mock_get_file_contents(name):
        if name == 'facter':
            return ('facter: facter 1.7.4\n', None)

# Generated at 2022-06-11 02:20:17.930467
# Unit test for function ansible_facts
def test_ansible_facts():
    fake_module = FakeAnsibleModule()
    result = ansible_facts(fake_module)
    assert result['default_ipv4']['address'] == '10.1.1.1'


# Generated at 2022-06-11 02:20:24.170779
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import module_utils
    import ansible.modules.system.setup
    module = ansible.modules.system.setup.AnsibleModule(argument_spec={'gather_subset': {'type': 'list', 'default': ['min']}})
    # Simplifies the test by forcing all facts to be collected
    module.params['gather_subset'] = ['all']
    default_facts = module_utils.get_all_facts(module)
    assert 'ansible_selinux' in default_facts
    assert 'default_ipv4' in default_facts

# Generated at 2022-06-11 02:20:30.634843
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({'gather_subset': ['all'], 'filter': '*'})
    ansible_facts = ansible_facts(module=module)

    assert isinstance(ansible_facts, dict)
    assert ansible_facts.get('distribution', None) is not None

# Generated at 2022-06-11 02:20:41.525099
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.virtual import VirtualCollector

    class TestModule(basic.AnsibleModule):
        """Comprehensive test of the new fact collector functionality"""

        def __init__(self):
            super(TestModule, self).__init__()
            self.params = {"gather_subset": ["!all", "network"],
                           "gather_timeout": 20,
                           "filter": "ansible_eth*"}

    test_module = TestModule()
    all_collector_classes = default_collectors.collectors

    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

# Generated at 2022-06-11 02:20:48.344595
# Unit test for function get_all_facts
def test_get_all_facts():
    '''
    Ensure ansible_facts is a wrapper around ansible_facts
    '''
    class FakeAnsibleModule():
        '''
        Mimic an ansible module
        '''
        def __init__(self):
            self.params = dict(gather_subset=['all'])

    module = FakeAnsibleModule()

    facts = ansible_facts(module)
    assert facts
    assert facts == get_all_facts(module)



# Generated at 2022-06-11 02:20:55.138482
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    try:
        from ansible.module_utils._text import to_text
    except ImportError:
        from ansible.module_utils.six import text_type as to_text

    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    mock_module = MockAnsibleModule()

    def get_all_facts_api(module):
        return get_all_facts(module)

    ansible.module_utils.facts.get_all_facts = get_all_facts_api

# Generated at 2022-06-11 02:20:57.001769
# Unit test for function ansible_facts
def test_ansible_facts():
    '''
    Unit test for function ansible_facts
    '''
    pass



# Generated at 2022-06-11 02:21:09.158830
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.collector

    try:
        # Importing AnsibleModule for testing
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        raise AssertionError("Unable to import ansible.module_utils.basic.")

    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(type='list', default=['all'])),
        supports_check_mode=True
    )

    facts = ansible_facts(module)

    # checking mandatory facts existence
    assert 'distribution' in facts
    assert 'distribution_release' in facts
    assert 'distribution_version' in facts
    assert 'os_family' in facts
    assert 'kernel' in facts
    assert 'kernel_version' in facts