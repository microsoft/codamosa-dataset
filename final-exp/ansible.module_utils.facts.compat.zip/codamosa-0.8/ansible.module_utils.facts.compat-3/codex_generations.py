

# Generated at 2022-06-11 02:11:44.874261
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.fact_cache import FactCache
    fact_cache = FactCache()
    facts_dict, warnings = fact_cache.get_facts(module=None)
    assert isinstance(facts_dict, dict)
    assert isinstance(warnings, list)

# Generated at 2022-06-11 02:11:55.209417
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    # import is done here to permit testing on the 2.x side and 3.x side of the Ansible API.
    # In 2.x the module_utils are not yet loaded when this snippet is included.
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import TestFactCollector

    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    all_collector_classes = default_collectors.collectors
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    test_fact_collector = TestFactCollector(namespace=namespace)
    all_collector_classes.append(test_fact_collector)


# Generated at 2022-06-11 02:12:05.285204
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import facts

    class FakeAnsibleModule(AnsibleModule):
        _ansible_facts = dict()

        def __init__(self, *args, **kwargs):
            AnsibleModule.__init__(self, *args, **kwargs)

        def exit_json(self, ansible_facts, **kwargs):
            self.ansible_facts = self.params['hostvars']
            self._ansible_facts = ansible_facts

        @property
        def params(self):
            # cache param dict because get_bin_path gets called pretty often
            return self._params


# Generated at 2022-06-11 02:12:09.203907
# Unit test for function get_all_facts
def test_get_all_facts():
    # stub module has a gather_subset param
    module = DummyAnsibleModule()

    s = ansible_facts(module, gather_subset=['all'])
    assert type(s) == dict


# Generated at 2022-06-11 02:12:19.662735
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest
    from mock_module_utils.facts import MockAnsibleModule

    mock_module = MockAnsibleModule()
    ansible_facts_all = ansible_facts(mock_module)

    assert ansible_facts_all.get('default_ipv4') == {u'address': u'192.168.1.1', u'alias': u'p4p1', u'masklen': 24, u'method': u'manual'}
    assert ansible_facts_all.get('default_ipv6') == {'address': 'fe80::250:56ff:fe82:af47', 'alias': 'p4p1', 'masklen': u'64', 'method': 'link-local'}

    # test with subset

# Generated at 2022-06-11 02:12:31.685739
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.fact_cache import FactCache as FactCache
    from ansible.module_utils.facts.collector import CollectedFact
    import tempfile
    import json
    import os

    fact_dict = {'ansible_test_fact': 'test_fact_value'}

    with tempfile.TemporaryDirectory() as tmp_dir:
        cache_dir = os.path.join(tmp_dir, "facts")
        fact_cache = FactCache(file=os.path.join(cache_dir, 'facts_cache.json'),
                               cache_dir=cache_dir, cached_facts=fact_dict)
        fact_cache.set_fact_cache()
        fact_cache.save()


# Generated at 2022-06-11 02:12:39.364164
# Unit test for function ansible_facts
def test_ansible_facts():

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class mock_ansible_module(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    results = ansible_facts(mock_ansible_module())
    assert results is not None
    assert 'apparmor' in results
    assert 'lsb' in results

# Generated at 2022-06-11 02:12:41.409691
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.ansible_collection.test.unit.test_module import AnsibleModuleMock
    module = AnsibleModuleMock()
    facts = ansible_facts(module)
    assert set(facts.keys()) == set(['default_ipv4', 'default_ipv6', 'default_interface'])

# Generated at 2022-06-11 02:12:47.264566
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    from six import iteritems

    module = AnsibleModule(argument_spec={'gather_subset': dict()}, )
    module.params['gather_subset'] = ['all']
    facts = get_all_facts(module)
    assert not facts['ansible_virtualization_role']
    for fact, value in iteritems(facts):
        assert fact in module.params['gather_subset']


# Generated at 2022-06-11 02:12:58.281272
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import ansible.module_utils.basic
    import ansible.module_utils.facts

    sys.modules['ansible'] = ansible
    sys.modules['ansible.module_utils'] = ansible.module_utils
    from ansible.module_utils.facts import ansible_facts

    def module_fail_json(self, msg):
        self.fail_json(msg)

    def module_exit_json(self, **kwargs):
        sys.exit(0)

    def module_from_spec(argument_spec):
        class FakeModule(object):
            def __init__(self, argument_spec):
                self.params = {}
                for key, value in argument_spec.iteritems():
                    self.params[key] = value['default']

            fail_json = module_fail_json


# Generated at 2022-06-11 02:13:09.451418
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys

    # We need to mock an AnsibleModule instance to pass to ansible_facts.
    class AnsibleModule:
        def __init__(self, gather_subset, gather_timeout, facts=None, filter_spec=None):
            self.params = {
                'gather_subset': gather_subset,
                'gather_timeout': gather_timeout
            }
            if facts:
                self.params['facts'] = facts
            if filter_spec:
                self.params['filter'] = filter_spec

    def run_ansible_facts(gather_subset, gather_timeout, facts=None, filter_spec=None):
        print('\n')

# Generated at 2022-06-11 02:13:15.940837
# Unit test for function get_all_facts
def test_get_all_facts():
    try:
        from ansible.module_utils.facts import get_all_facts
    except ImportError:
        get_all_facts = None
    if get_all_facts is None:
        return

    import sys
    mock_module = sys.modules[__name__]

    # ansible 2.0/2.2/2.3 compat test
    mock_module.params = dict(gather_subset=['all'])
    DefaultFacts = get_all_facts(mock_module)

    assert len(DefaultFacts) > 10

# Generated at 2022-06-11 02:13:16.475590
# Unit test for function ansible_facts
def test_ansible_facts():


    pass

# Generated at 2022-06-11 02:13:28.103048
# Unit test for function ansible_facts
def test_ansible_facts():

    import pytest

    import ansible.utils.plugin_docs as plugin_docs
    import ansible.module_utils.facts  # noqa

    # make subclass of AnsibleModule that has a mock gather_subset and gather_timeout
    class MockAnsibleModule(object):
        def __init__(self, gather_subset=None, gather_timeout=None):
            self.params = {}
            if gather_subset is not None:
                self.params['gather_subset'] = gather_subset
            if gather_timeout is not None:
                self.params['gather_timeout'] = gather_timeout

    # get mock instance of MockAnsibleModule
    mock_am = MockAnsibleModule()

    # run test
    test_results = ansible_facts(mock_am)

    # check results


# Generated at 2022-06-11 02:13:38.722889
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.modules.system.setup
    module = ansible.modules.system.setup._setup_arg_spec()
    facts = ansible_facts(module)

# Generated at 2022-06-11 02:13:45.648777
# Unit test for function ansible_facts
def test_ansible_facts():
    '''tests for ansible_facts'''

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    all_collector_classes = ansible_collector.DEFAULT_COLLECTOR_SUBSETS['all']
    assert(DistributionFactCollector in all_collector_classes)

# Generated at 2022-06-11 02:13:50.991018
# Unit test for function ansible_facts
def test_ansible_facts():
    mock_mod = MockFactsModule()

    # Since get_all_facts does not have test coverage, it is not clear that this is actually
    # what ansible_facts does, but it appears to be.
    facts = ansible_facts(module=mock_mod, gather_subset=mock_mod.gather_subset)
    assert facts == {}



# Generated at 2022-06-11 02:13:56.244621
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import ansible_facts

    module = basic.AnsibleModule({'gather_subset': ['all'],
                                  'filter': '*',
                                  'gather_timeout': 10})
    result = ansible_facts(module)
    assert 'os_version' in result
    assert 'kernel' in result
    assert result['kernel'] == 'Linux'

# Generated at 2022-06-11 02:14:08.143370
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--gather_subset', nargs='*', action='store', default=['all'])
    parser.add_argument('--gather_timeout', action='store', default=10, type=int)
    parser.add_argument('--filter', action='store')

    args = parser.parse_args()

    # create a dumb module object
    class MyModule:
        params = {
            'gather_subset': args.gather_subset,
            'gather_timeout': args.gather_timeout,
            'filter': args.filter
        }
    module = MyModule()

    # call ansible_facts
    data = ansible_facts(module)
    print(json.dumps(data))

# Generated at 2022-06-11 02:14:14.813645
# Unit test for function ansible_facts
def test_ansible_facts():
    # arrange
    module = mock.MagicMock()
    module.params = {'gather_subset': 'all', 'gather_timeout': 10, 'filter': '*'}
    # act
    results = ansible_facts(module)

    # assert
    assert results is not None
    assert 'default_ipv4' in results
    assert results['default_ipv4']['address'] is not None
    assert results['default_ipv4']['address'] != ''



# Generated at 2022-06-11 02:14:27.643715
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_virtualization_type
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts import ansible_processor_vcpus
    from ansible.module_utils.facts import local
    from ansible.module_utils.facts import dns
    from ansible.module_utils.facts import ansible_distribution
    from ansible.module_utils.facts import ansible_distribution_version
    from ansible.module_utils.facts import ansible_hostname
    from ansible.module_utils.facts import ansible_env

    module = AnsibleModule(argument_spec=dict(
        gather_subset='all',
    ))

    facts_dict = get_all_facts

# Generated at 2022-06-11 02:14:37.865778
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.system.platform

    all_collectors = default_collectors.collectors

    class FakeModule(object):
        class Params(object):
            gather_subset = None

            def __init__(self, gather_subset):
                self.gather_subset = gather_subset

        def __init__(self, gather_subset):
            self.params = self.Params(gather_subset)

    class FakeCollector(object):
        def __init__(self, name, platform=None):
            self.name = name
            self.platform = platform
            if self.platform == 'linux':
                self._is_content_excluded = ansible.module_utils.facts.system.platform.linux_exclude_content
            else:
                self._is_

# Generated at 2022-06-11 02:14:41.542816
# Unit test for function ansible_facts
def test_ansible_facts():

    class FakeAnsibleModule():
        def __init__():
            self.params = {}

    test_module = FakeAnsibleModule()

    facts = ansible_facts(test_module, gather_subset=['system', 'network'])

    assert isinstance(facts, dict)
    assert len(facts) > 0
    for fact_key in facts:
        assert facts[fact_key] is not None
        assert facts[fact_key] != ""

# Generated at 2022-06-11 02:14:49.039837
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import basic_ansible_module

    class AnsibleModule(object):
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-11 02:15:01.938771
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector

    class DummyModule():
        def __init__(self, gather_subset, gather_timeout):
            self.params = {'gather_subset': gather_subset,
                           'gather_timeout': gather_timeout}

    # test behavior if 'subset' and 'timeout' is set
    gather_subset = ['network']
    gather_timeout = 5
    module = DummyModule(gather_subset, gather_timeout)
    assert ansible_collector.get_ansible_collector.call_count == 0
    assert ansible_facts(module)

# Generated at 2022-06-11 02:15:10.623439
# Unit test for function ansible_facts
def test_ansible_facts():
    from units.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Arrange
    gather_subset = ['all']
    gather_timeout = 10
    filter_spec = '*'

    module = AnsibleModule(argument_spec={})

    minimal_gather_subset = frozenset(['apparmor', 'caps', 'cmdline', 'date_time',
                                       'distribution', 'dns', 'env', 'fips', 'local',
                                       'lsb', 'pkg_mgr', 'platform', 'python', 'selinux',
                                       'service_mgr', 'ssh_pub_keys', 'user'])

    # Assign a dummy function to the method init_collector_facts on BaseFactCollector
    # to ensure method

# Generated at 2022-06-11 02:15:14.484584
# Unit test for function ansible_facts
def test_ansible_facts():

    class AnsibleModule:
        def __init__(self, **params):
            self.params = params

    # Minimal gather_subset, will only collect non-expensive facts
    for gather_subset in [['min'], ['network', 'min']]:
        ansible_facts_dict = ansible_facts(AnsibleModule(gather_subset=gather_subset))

        # check that the list of facts collected is a subset of the minimal gather subset
        assert (frozenset(ansible_facts_dict) <= minimal_gather_subset), "Ansible facts subset is not a subset of the minimal gather subset"

    # Full gather_subset, will collect anything possible
    ansible_facts_dict = ansible_facts(AnsibleModule(gather_subset=['all']))

    # Make sure

# Generated at 2022-06-11 02:15:22.923876
# Unit test for function ansible_facts
def test_ansible_facts():
    # Mock out ansible.modules.basic.AnsibleModule
    class AnsibleModule(object):
        def __init__(self, **args):
            self.params = args
            self.check_mode = False

    mod = AnsibleModule(gather_subset=['all'],
                        gather_timeout=10,
                        filter='*')

    from ansible.module_utils.facts.namespace import AddPrefixFactNamespace

    mock_collectors = []
    class MockCollector(object):
        def __init__(self, name, keys):
            self.name = name
            self.keys = keys
            mock_collectors.append(self)

        def collect(self, module):
            ret = {}
            for key in self.keys:
                ret[key] = "mock-" + key
            return

# Generated at 2022-06-11 02:15:25.430118
# Unit test for function ansible_facts
def test_ansible_facts():
    result = ansible_facts(module=None, gather_subset=['!all'])
    assert result == {}

# Generated at 2022-06-11 02:15:33.481874
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.basic import AnsibleModule, env_fallback

    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(default=['all'], type='list'),
        gather_timeout=dict(default=10, type='int'),
    ), supports_check_mode=True)
    env_fallback(module._name, 'gather_subset')
    env_fallback(module._name, 'gather_timeout')

    actual = get_all_facts(module)

    assert isinstance(actual, dict)



# Generated at 2022-06-11 02:15:50.915313
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils import basic
    # get_all_facts expects a module arg, and will use module.params.get to
    # get gather_subset attribute from module.

    # AnsibleModule base class has a params dict attribute.
    # so we can create a dummy module class w/o needing to create a real
    # Ansible module, which requires a real module_args dict, and some
    # filesystem resources (an argspec, a module).
    class DummyModule(basic.AnsibleModule):
        pass

    # create an instance of the dummy module class, with a 'gather_subset' param.
    dummy_module = DummyModule(argument_spec={'gather_subset': dict(type='list', default=['!all'])})

# Generated at 2022-06-11 02:15:59.250465
# Unit test for function ansible_facts
def test_ansible_facts():
    import unittest
    import sys

    class TestModule(object):
        ''' Test module to mock out an ansible module
        '''

        def __init__(self):
            self.return_value = dict()

        def fail_json(self, msg, **kwargs):
            self.return_value['failed'] = True
            self.return_value['msg'] = msg
            self.return_value['stdout'] = kwargs.get('stdout')
            self.return_value['stderr'] = kwargs.get('stderr')

        def exit_json(self, **kwargs):
            kwargs['changed'] = False
            self.return_value.update(kwargs)


# Generated at 2022-06-11 02:16:07.578692
# Unit test for function ansible_facts
def test_ansible_facts():
    import json
    import os
    import sys

    import ansible.module_utils.facts as a_facts

    class TestAnsibleModule:
        def __init__(self, params):
            self.params = params

        def fail_json(self, **kwargs):
            sys.stderr.write(json.dumps(kwargs) + '\n')
            sys.exit(1)

        def exit_json(self, **kwargs):
            sys.stdout.write(json.dumps(kwargs) + '\n')
            sys.exit(0)

    params = dict()
    am = TestAnsibleModule(params)

    facts = a_facts.ansible_facts(am)
    assert 'default_ipv4' in facts
    assert 'default_ipv6' in facts
   

# Generated at 2022-06-11 02:16:17.133418
# Unit test for function get_all_facts
def test_get_all_facts():
    import inspect
    import sys

    # mock AnsibleModule class
    class AnsibleModule:
        class params:
            gather_subset = ['all']

    # get the module function in scope
    _, module_path, _ = (inspect.getsourcefile(test_get_all_facts), inspect.getfile(test_get_all_facts), [])
    m = sys.modules.get(module_path.replace('.pyc', '').replace('.py', ''))

    # call the function get_all_facts
    facts = get_all_facts(AnsibleModule())

    assert type(facts) == dict

    assert facts['system'] == m.Platform.system()

# Generated at 2022-06-11 02:16:22.607603
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    result = ansible_facts(module=module)
    assert isinstance(result, dict)
    assert result['lsb']['distro'] == 'Ubuntu'



# Generated at 2022-06-11 02:16:31.641951
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_text

    class MockModule(object):
        def __init__(self, gather_subset, gather_timeout, filter, params):
            self.params = params
            self.params['gather_subset'] = gather_subset
            self.params['gather_timeout'] = gather_timeout
            self.params['filter'] = filter

    # The test is run with jinja2 is enabled and disabled
    # When jinja2 is not enabled the test_ansible_collector will fail
    # When jinja2 is enabled the test_ansible_collector will throw an AttributeError
    # This is a catch all decorator and will catch that error

# Generated at 2022-06-11 02:16:42.385045
# Unit test for function get_all_facts
def test_get_all_facts():
    import mock
    mock_module = mock.Mock()
    mock_module.params = {
        'gather_subset': ['all', '!network'],
        'gather_timeout': 10,
        'filter': '*'
    }

    returned_facts_dict = get_all_facts(mock_module)

    assert isinstance(returned_facts_dict, dict)

    # The returned dict should have keys with no 'ansible_' prefix
    assert set(returned_facts_dict.keys()) == set(['default_ipv4', 'fips'])

    # The dict returned from ansible_collector should have keys with no 'ansible_' prefix
    assert 'ansible_' not in returned_facts_dict['default_ipv4']
    assert 'ansible_' not in returned_facts

# Generated at 2022-06-11 02:16:53.849674
# Unit test for function ansible_facts
def test_ansible_facts():
    path_to_fact_module = 'ansible.module_utils.facts.collector'
    path_to_import_collectors = path_to_fact_module + '.collectors'

    # Fact function will use default collectors if we don't patch them
    default_collectors.collectors = []

    # So patch get_collector_classes to return real collector classes
    module = mock.MagicMock()
    module.params = {}
    collectors = find_collector_classes(path_to_import_collectors)

    with patch(path_to_fact_module + '.get_collector_classes', return_value=collectors):
        ansible_facts(module)

        # Should only be called once
        assert module.exit_json.call_count == 1
        args, kwargs = module.exit_json.call_

# Generated at 2022-06-11 02:17:00.087410
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils._text import to_bytes

    # We need to generate a module_utils structure
    #
    # Fake __name__ to prevent module_utils.Facts from erroring out
    __name__ = 'ansible_facts'
    m = {}

# Generated at 2022-06-11 02:17:04.753739
# Unit test for function ansible_facts
def test_ansible_facts():
    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'all'}

    fake_module = FakeModule()
    fact_dict = ansible_facts(fake_module)

    assert fact_dict['lsb']['distrib_release'] == '20.04'

# Generated at 2022-06-11 02:17:25.438785
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_distribution, get_distribution_version
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    import pytest
    import os

    if 'HANDLERS_PATH' in os.environ:
        del os.environ['HANDLERS_PATH']

    fake_module = pytest.Mock()
    fake_module.params = dict()
    fake_module.params['filter'] = '*'
    fake_module.params['gather_subset'] = 'all'

    facts = ansible_facts(fake_module)

    assert facts['distribution'] == get_distribution()

# Generated at 2022-06-11 02:17:33.426898
# Unit test for function ansible_facts
def test_ansible_facts():
    import inspect

    import ansible.module_utils.facts.system.distribution

    # For testing, we will just steal the test_module_utils.py argv handling,
    # and use it to stuff our function arguments in, and then
    # we'll construct an empty ansible module
    import ansible.module_utils.basic
    import ansible.module_utils.facts.collector

    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--gather_subset', action='append', default=None)
    parser.add_argument('--filter', default='*')
    parser.add_argument('--gather_timeout', default=10, type=int)

    args = parser.parse_args(sys.argv[1:])


# Generated at 2022-06-11 02:17:44.563054
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test of legacy ansible_facts function, which is called by the network modules and Ansible 2.0/2.2 code'''

    # git checkout ansible 2.3.1
    # python -m pytest test/units/module_utils/facts/legacy.py -k test_ansible_facts
    from ansible.module_utils.facts.legacy import ansible_facts
    from ansible.module_utils.basic import AnsibleModule

    gather_subset = ['all']
    gather_timeout = 10


# Generated at 2022-06-11 02:17:55.044427
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    # import mock
    import mock

    # ansible_facts(module, gather_subset=None)
    #
    # 'module' should be an instance of an AnsibleModule.

    # returns a dict mapping the bare fact name ('default_ipv4' with no 'ansible_' namespace) to
    # the fact value.

    class MockAnsibleModule(object):
        '''a fake AnsibleModule'''
        def __init__(self, params):
            self.params = params

    module = MockAnsibleModule(params={'gather_subset': ['all'],
                                       'gather_timeout': 10,
                                       'filter': '*'})

    def mock_collect(module=None):
        '''fake collect method'''
       

# Generated at 2022-06-11 02:18:04.167922
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.tests import AnsibleModuleMock

    # create a fake module with gather_subset:
    module = AnsibleModuleMock(params={'gather_subset': ['min']})

    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert 'fips' in facts
    assert isinstance(facts['fips'], bool)
    assert 'selinux' in facts
    assert isinstance(facts['selinux'], dict)
    assert 'selinux' in facts
    assert facts['selinux']['status'] == 'disabled'

    # test the ansible module
    module = AnsibleModuleMock(params={'gather_subset': ['min']})

   

# Generated at 2022-06-11 02:18:09.281464
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Returns a dict mapping the bare fact name ('default_ipv4' with no 'ansible_' namespace) to
    the fact value.
    '''

    from ansible.module_utils.basic import AnsibleModuleBase
    import pytest

    class TestModule(AnsibleModuleBase):

        def __init__(self):
            super(TestModule, self).__init__()

        def execute_module(self):
            return ansible_facts(self)

    module = TestModule()
    ansible_facts_dict = ansible_facts(module)
    assert isinstance(ansible_facts_dict, dict)
    assert 'default_ipv4' in ansible_facts_dict

    ansible_facts_dict = ansible_facts(module, gather_subset='all')

# Generated at 2022-06-11 02:18:20.715759
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # We have to create a fake module with fake facts, to test this method
    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # create a PrefixFactNamespace with a fake fact
    prefix_namespace = PrefixFactNamespace('fancy_prefix', 'ansible_')
    prefix_namespace.add_fact('foo', 'bar')

    module = FakeModule({
        'gather_subset': ['all'],
        'filter': 'bar',
        'fancy_prefix_foo': 'something else',
    })

    # test that our fake

# Generated at 2022-06-11 02:18:30.889431
# Unit test for function ansible_facts
def test_ansible_facts():

    # testing requires access to 'module' which gets passed in as an arg, so this is a nested
    # function that needs to be run as part of the test
    def run_ansible_facts(test_args):

        # this is a mock ansible module, but it contains the args we need to test the ansible_facts
        # function
        class TestModule(object):
            def __init__(self):
                self.params = dict()

            def fail_json(message, **kwargs):
                raise AssertionError(message)

        # test args are provided in the calling context, for ease of testing multiple
        # gather_subset/gather_timeout combos
        gather_subset = test_args.get('gather_subset')
        gather_timeout = test_args.get('gather_timeout')

# Generated at 2022-06-11 02:18:40.130373
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from mock import Mock
    module = Mock()
    module.params = dict()
    module.params['gather_subset'] = None
    module.params['gather_timeout'] = 2
    module.params['filter'] = '*'
    assert ansible_facts(module)['lsb']['codename'] == 'trusty'
    module.params['filter'] = 'ansible_architecture'
    assert ansible_facts(module)['architecture'] == 'x86_64'
    module.params['filter'] = 'kernel'
    assert 'Linux' in ansible_facts(module)['kernel']



# Generated at 2022-06-11 02:18:52.096434
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({
        'gather_subset': ['all'],
        'gather_timeout': 10,
        'filter': '*'
    })

    # expected output, grab this dynamically by running:
    # ./hacking/test-module -m setup | python -m json.tool
    # and copying the output from the 'ansible_facts' field

# Generated at 2022-06-11 02:19:10.428848
# Unit test for function get_all_facts
def test_get_all_facts():
    # we're not going to raise an exception here
    assert(True == True)

# Generated at 2022-06-11 02:19:21.590561
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import get_all_collector_classes
    from ansible.module_utils.facts import NetworkFactCollector
    from ansible.module_utils.facts.dummy import DummyNetworkFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.network.base import BaseNetworkCollector
    from ansible.module_utils.facts.network.ifconfig import IfconfigNetwork
    from ansible.module_utils.facts.network.linux_iproute import LinuxIProute
    from ansible.module_utils.facts.network.bsd_ifconfig import BsdIfconfigNetwork
    from ansible.module_utils.facts.network.bsd_ipconfig import BsdIpconfigNetwork

# Generated at 2022-06-11 02:19:33.156066
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_lines

    facts_dict = ansible_facts(None)
    with open('/etc/ansible/ansible.cfg') as f:
        lines = get_file_lines(f)
    # the function get_file_lines tries to decode the content of /etc/ansible/ansible.cfg 'utf-8'
    # , but the content of this file is 'str' not encoded, so it raises UnicodeDecodeError
    # but the fact 'ansible_config_file' is a list of bytes
    # so if the file can be decoded, we build a list of bytes from lines
    # else we build a list of bytes from the

# Generated at 2022-06-11 02:19:45.861579
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.get_distribution
    # run the function
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import Facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # These are not used by the function code
    class AnsibleModule(object):
        def __init__(self):
            self.params = {}

    module = AnsibleModule()
    # specify a gather_subset
    module.params['gather_subset'] = ['all']

    ##
    ## Test that the function returns an expected dict
    ##
    ansible_facts_dict = ansible_facts(module)

    # test the expected keys are present

# Generated at 2022-06-11 02:19:59.152116
# Unit test for function ansible_facts
def test_ansible_facts():
    # make a mock AnsibleModule
    class MockAnsibleModule:
        pass
    module = MockAnsibleModule()
    module.params = dict()

    # test that gather_subset arg is optional
    facts_dict = ansible_facts(module=module)
    assert isinstance(facts_dict['ansible_system'], str)

    # test that gather_subset defaults to ansible_fact['gather_subset']
    module_gather_subset = ['!foo', 'bar']
    module.params['gather_subset'] = module_gather_subset
    facts_dict = ansible_facts(module=module)
    assert isinstance(facts_dict['ansible_system'], str)
    assert facts_dict['_ansible_gather_subset'] == module_gather_sub

# Generated at 2022-06-11 02:20:07.533905
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    module_name = 'test_ansible_facts'

    class TestModule(object):
        def __init__(self):
            self.params = dict(gather_subset=['!all'])

    class TestFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = ['test1', 'test2']
        def collect(self, module=None, collected_facts=None):
            return dict([(self.name + '_' + fact, fact) for fact in self._fact_ids])

    old_fact_collector = default_collectors.collectors[module_name]
    default_collectors.collectors[module_name] = [TestFactCollector]

# Generated at 2022-06-11 02:20:19.684843
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ansible_collector

    class TestFactCollector(BaseFactCollector):
        """ A simple test fact collector for the unit test"""
        NAME = 'test_fact_collector'

        def collect(self, module=None, collected_facts=None):
            return 42

    assert ansible_facts.__defaults__ == (None,)  # 2.3 doesn't append None to __defaults__
    # if __defaults__ didn't have a value, then assert above will fail
    # so we can be confident there is a __defaults__, and if it's not None,
    # then it must be a tuple.

# Generated at 2022-06-11 02:20:31.736797
# Unit test for function ansible_facts
def test_ansible_facts():
    '''test_ansible_facts'''
    # ensure the ansible_facts() function has the correct signature
    assert ansible_facts.__code__.co_argcount == 2
    assert ansible_facts.__code__.co_varnames == ('module', 'gather_subset')

    # ensure get_all_facts() is calling ansible_facts() with the right args
    def check_args(module, gather_subset=None):
        '''check_args'''
        assert gather_subset == '!all'
        assert module.params.get('filter') == 'fact1:fact2'
        return {'fact1': '1', 'fact2': '2'}

    all_facts_ret = get_all_facts(module=check_args)

# Generated at 2022-06-11 02:20:42.047281
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts, default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector import collect_subset
    from ansible.module_utils.facts.network.linux import _linux_networking_facts
    from ansible.module_utils.facts import ansible_collector
    network_collector = NetworkCollector(namespace=PrefixFactNamespace(namespace_name='ansible', prefix=''))

# Generated at 2022-06-11 02:20:52.091098
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    import tempfile
    import pytest
    import ansible.module_utils.facts.namespace as Namespace
    from ansible.module_utils.facts import ansible_collector

    class EnvVarFact(Namespace.BaseFactNamespace):
        """example of a custom fact namespace"""

        NAME = 'env_var'

        def populate(self, module=None):
            for env_var in module.params['env_var_names']:
                self.data[env_var] = os.environ.get(env_var)

    all_collector_classes = default_collectors.collectors + [EnvVarFact]

    # Test that ansible_collector.get_ansible_collector returns a non-empty result
    filter_spec = '*'
    gather_subset = ['all']

# Generated at 2022-06-11 02:21:32.118371
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import module_utils_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

# Generated at 2022-06-11 02:21:41.264539
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import gather_subset

    class TestModule(AnsibleModule):
        def __init__(self, **kwargs):
            super(TestModule, self).__init__(argument_spec={'gather_subset': dict(type='list', default=['all'])},
                                             **kwargs)

    # Subset of facts we should be able to gather on any system
    minimum_facts = frozenset(["ansible_ssh_host", "ansible_ssh_port"])

    # Our gather_subset argument is a list of fact subsets.  We want to make sure at least one element of that list
    # contains the minimum facts, otherwise we assume the list didn't actually contain any valid fact subsets.
    possible_