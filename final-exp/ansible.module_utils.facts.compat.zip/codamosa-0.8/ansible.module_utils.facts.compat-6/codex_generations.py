

# Generated at 2022-06-11 02:11:45.878022
# Unit test for function get_all_facts
def test_get_all_facts():
    # mock module instance
    module = MockAnsibleModule()
    module.params = dict(gather_subset=['min', 'hardware', 'network'])

    # get all facts, use gather_subset=None to get all facts
    facts = get_all_facts(module)

    assert len(facts) > 0
    assert 'ansible_default_ipv4' in facts



# Generated at 2022-06-11 02:11:56.067572
# Unit test for function ansible_facts
def test_ansible_facts():
    import os
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors, ansible_collector

    class DummyModule(object):
        class DummyParams(object):
            gather_subset = ['all']
            gather_timeout = 5
            filter = '*'
            def as_dict(self):
                return dict(gather_subset=self.gather_subset,
                            gather_timeout=self.gather_timeout,
                            filter=self.filter)

        def __init__(self):
            self.id = '1'
            self.params = self.DummyParams()


# Generated at 2022-06-11 02:12:05.413779
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import os

    # Mock an AnsibleModule
    class AnsibleModule(object):
        pass

    # Add some params that would be added by the 'setup' module
    module = AnsibleModule()
    module.params = {
        'filter': '*',
        'gather_subset': ['all'],
        'gather_timeout': 10,
    }

    ansible_facts = sys.modules['ansible.module_utils.facts.ansible_facts']
    facts_dict = ansible_facts.ansible_facts(module)

    # Make sure that we have at least some facts
    assert len(facts_dict) > 0

    # Check to see if the 'ansible_os_family' fact is present and populated
    assert 'os_family' in facts_dict

    # Check to see if the

# Generated at 2022-06-11 02:12:13.851421
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    import tempfile
    import pytest
    import os
    import json

    class MockModule():
        def __init__(self, params):
            self.params = params

    # create a mock module file
    module_file = tempfile.NamedTemporaryFile(mode="w+t", delete=False, suffix='.py')
    module_file.write('''
''')
    module_file.seek(0)

    # create a mock ansible_facts module file
    facts_file = tempfile.NamedTemporaryFile(mode="w+t", delete=False, suffix='.py')

# Generated at 2022-06-11 02:12:18.298221
# Unit test for function ansible_facts
def test_ansible_facts():

    # Create a mock module
    class ModuleMock():

        def __init__(self):
            self.params = {}

    module = ModuleMock()

    gather_subset = ['min']
    module.params['gather_subset'] = gather_subset

    ansible_facts_dict = ansible_facts(module)
    assert ansible_facts_dict['distribution'] == 'CentOS'

# Generated at 2022-06-11 02:12:30.701751
# Unit test for function ansible_facts
def test_ansible_facts():
    module = object()
    gather_subset=["all"]
    module.params = {'gather_subset': gather_subset,
                     'gather_timeout': 10,
                     'filter': '*',
                     'fact_path': [],
                     'gather_subset': ["all"],
                     'gather_timeout': 10,
                     'filter': '*'}
    facts_dict = ansible_facts(module, gather_subset)


# Generated at 2022-06-11 02:12:41.602327
# Unit test for function ansible_facts
def test_ansible_facts():
    class TestingModule:
        def __init__(self, params):
            self.params = params

    cls_names = {x.__name__ for x in default_collectors.collectors}

    # Note this test is not a full regression test, but it does test
    # the AnsibleModule parameter handling and the main use case for
    # calling ansible_facts.

# Generated at 2022-06-11 02:12:49.833755
# Unit test for function get_all_facts
def test_get_all_facts():

    # Verify that module is not altered when gathering all facts
    test_module = AnsibleModule(argument_spec={'gather_subset': dict(required=False, type='list', default=['all'])})
    assert len(test_module.params) == 1
    get_all_facts(test_module)
    assert len(test_module.params) == 1

    # Verify exclude_facts functionality
    test_module = AnsibleModule(argument_spec={'gather_subset': dict(required=False, type='list', default=['all']), 'exclude_facts': dict(type='list'), 'filter': dict(type='list', required=False)})
    test_module.params['exclude_facts'] = ['first', 'second']
    test_module.params['filter'] = ['second']

# Generated at 2022-06-11 02:12:55.965492
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import module_utils
    ans_mod = module_utils.get_module_utils(output_dir='',
                                            menu_items=[])

    module = ans_mod.AnsibleModule()

    module.params['gather_subset'] = 'all'

    results = get_all_facts(module)

    assert 'default_ipv4' in results


# Generated at 2022-06-11 02:13:07.214876
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.network.bond import BondFactCollector
    from ansible.module_utils.facts.network.base import BaseFactCollector
    from ansible.module_utils.facts.network.linux.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.network.base import BaseFactCollector

    assert BondFactCollector.namespace == 'ansible_bond'
    assert BondFactCollector.platform == 'Linux'

    all_collector_classes = default_collectors.collectors

    # don't add a prefix
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')


# Generated at 2022-06-11 02:13:18.163250
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.compat.tests import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = ['test_fact_1', 'test_fact_2']

        def collect(self, module=None, collected_facts=None):
            facts_dict = dict()
            for fact_id in self._fact_ids:
                facts_dict[fact_id] = None
            return facts_dict

    test_namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    class TestModule:
        params = {'gather_subset': '!all'}

    real_collectors = default_collectors.collectors

    # monkeypatch default_collectors

# Generated at 2022-06-11 02:13:29.395541
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeNetworkCollector(NetworkCollector):
        @property
        def platform(self):
            return 'fake_network'

        def populate(self):
            self.collect_network_resources()

        def collect(self, module=None, collected_facts=None):
            return dict(ansible_eth0=dict(ipv4=dict(address='1.1.1.1')))

    class FakeModule:
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-11 02:13:38.688643
# Unit test for function ansible_facts
def test_ansible_facts():
    # Can't use unittest framework, b/c it does not work with Python 2.6
    # So use a very non-robust but simple test for now.

    #import ansible.module_utils.facts.facts as facts

    from ansible.module_utils.facts.collector import BaseFactCollector, PlatformFactCollector

    import pytest

    class FakeModule:
        params = {}

    def call_ansible_facts(the_fake_module):
        return ansible_facts(the_fake_module)

    fake_module = FakeModule()
    with pytest.raises(PlatformFactCollector.UnsupportedPlatformException):
        call_ansible_facts(fake_module)


# Generated at 2022-06-11 02:13:51.134022
# Unit test for function ansible_facts
def test_ansible_facts():
    class MockAnsibleModule:
        class params(dict):
            gather_subset = None
            gather_timeout = 10
            filter = '*'

        def __init__(self, params):
            self.params = params

    from ansible.module_utils.facts import default_collectors
    all_collector_classes = default_collectors.collectors

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors

# Generated at 2022-06-11 02:14:02.704572
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Test the ansible_facts function'''

    import sys
    sys.modules['_ansible_module_generated_by_test'] = None
    import _ansible_module_generated_by_test
    sys.modules['_ansible_module_generated_by_test'] = _ansible_module_generated_by_test

    # set up test module
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_module
    import ansible.module_utils.facts as facts_module


# Generated at 2022-06-11 02:14:11.554279
# Unit test for function ansible_facts
def test_ansible_facts():
    ''' Unit test for ansible_facts

    ansible_facts collects a bunch of facts, some of which might fail depending
    on the host environment.  There are some basic sanity checks to make
    sure at least a few facts are collected.
    '''

    from ansible.module_utils.facts import ansible_facts
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.module_utils.facts.processors import iteritems
    from ansible.module_utils._text import to_text

    class DummyModule(object):
        ''' Dummy for testing ansible_facts with no actual module '''

        def __init__(self, module_name=None, gather_subset=None):
            self.params = {}
            self.params['gather_subset'] = gather_subset
            self

# Generated at 2022-06-11 02:14:22.155005
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    def mock_collect(collector_self, module=None, collected_facts=None):
        return collected_facts

    class FakeCollector():
        ''' a fake class that supports the minimal require attributes and methods of
        AnsibleCollector'''
        def __init__(self, *args, **kwargs):
            self.namespace = kwargs['namespace']
            self.collect = mock_collect

    original_collector = ansible_collector.AnsibleCollector
    ansible_collector.AnsibleCollector = FakeCollector

# Generated at 2022-06-11 02:14:31.205969
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector.hardware.ceph import CephCollector
    from ansible.module_utils.facts.collector.virtual.ceph import CephVirtualCollector
    from ansible.module_utils.facts.collector.virtual.openstack import OpenStackVirtualCollector

    # Test CephCollector
    ceph_collector = CephCollector()
    facts_dict = ceph_collector.collect(facts=Facts({}, {}, {}, {}, {}), module=MockModule())


# Generated at 2022-06-11 02:14:42.547260
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.ansible_default_collectors as ansible_default_collectors
    import ansible.module_utils.facts.platform.linux as linux
    import ansible.module_utils.facts.system.distribution as distribution_facts
    import ansible.module_utils.facts.system.distro as distro
    import ansible.module_utils.facts.system.platform as platform

    class fake_module:
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['all']

    m = fake_module()
    facts = ansible_facts(m)
    assert 'default_ipv4' not in facts
    assert 'fqdn' in facts
    assert 'machine_id' in facts

# Generated at 2022-06-11 02:14:46.289257
# Unit test for function ansible_facts
def test_ansible_facts():
   from ansible.module_utils.basic import AnsibleModule
   module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['!all'])})
   facts_dict = ansible_facts(module)
   assert(facts_dict['fqdn'] == 'localhost.localdomain')

# Generated at 2022-06-11 02:15:01.485053
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts

    # Simulate running underlying fact collector (returns only local facts)
    def local_facts(module, gather_subset):
        return {'distribution': 'RedHat',
                'distribution_release': '7.0',
                'distribution_version': '7.0.1406'
                }

    # ansible_facts will try to call ansible_collector.get_ansible_collector().collect
    # We want to simulate calling local_facts() instead to get the test data.
    module_mock = Mock(spec=AnsibleModule)

# Generated at 2022-06-11 02:15:10.371234
# Unit test for function get_all_facts
def test_get_all_facts():

    class TestModule(object):
        def __init__(self, gs):
            self.params = {'gather_subset': gs}

    tm = TestModule(['!all'])
    v = get_all_facts(tm)
    assert len(v.keys()) == 0

    tm = TestModule(['all'])
    v = get_all_facts(tm)
    assert len(v.keys()) > 20

    tm = TestModule(['network'])
    v = get_all_facts(tm)
    assert len(v.keys()) > 10

    tm = TestModule(['virtual'])
    v = get_all_facts(tm)
    assert len(v.keys()) > 10

    tm = TestModule(['hardware'])
    v = get_all_facts

# Generated at 2022-06-11 02:15:20.737631
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.ansible_collector
    import ansible.module_utils.facts.collector.base
    import ansible.module_utils.facts.collector.sunos
    import ansible.module_utils.facts.collector.network
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.pkg_mgr
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.service_mgr
    import ansible.module_utils.facts.collector.python
    import ansible.module_utils.facts.collector.virtual
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector

# Generated at 2022-06-11 02:15:27.500851
# Unit test for function ansible_facts
def test_ansible_facts():
    global ansible_facts  # pylint: disable=global-statement
    import sys
    import pytest
    mock_module = pytest.Mock(params={'gather_subset': ['all']})
    if sys.version_info[0] > 2:
        assert isinstance(ansible_facts(mock_module), dict)
    else:
        assert isinstance(ansible_facts(mock_module).keys, list)

# Generated at 2022-06-11 02:15:32.186647
# Unit test for function ansible_facts
def test_ansible_facts():
    import mock
    import logging

    class FakeModule(object):
        class FakeParams(object):
            def __init__(self):
                self.data = {'gather_subset': ['all']}

        def __init__(self):
            self.params = self.FakeParams()

    module = FakeModule()

    # mock out logging
    log_mock = mock.Mock(logging.Logger.debug)

    with mock.patch('ansible.module_utils.facts.ansible_collector.logger', log_mock):
        facts_dict = ansible_facts(module, gather_subset=['all'])

    # Check for the required keys in the returned dictionary
    assert facts_dict

# Generated at 2022-06-11 02:15:40.161900
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    class Base:
        def run(self):
            return True
    class Network(NetworkCollector):
        def get_interfaces(self):
            return True
        def get_all_ipv4_addresses(self):
            return True
        def get_all_ipv6_addresses(self):
            return True
    class Virtual(VirtualCollector):
        def get_virtual_facts(self):
            return True
    class System(SystemCollector):
        def get_platform_facts(self):
            return True

# Generated at 2022-06-11 02:15:41.121454
# Unit test for function get_all_facts
def test_get_all_facts():
    pass

# Generated at 2022-06-11 02:15:53.728947
# Unit test for function ansible_facts
def test_ansible_facts():
    ansible_facts_module = {
        'params': {
            'gather_subset': ['min', '!all'],
            'gather_timeout': 20,
            'filter': 'fact*',
        }
    }

    ansible_facts_result = ansible_facts(ansible_facts_module)

    # the values of the result may change with time, so don't do a complete
    # comparison.
    expected_result_keys = {
        'fact1', 'fact10', 'fact11', 'fact12', 'fact13', 'fact15', 'fact16',
        'fact17', 'fact2', 'fact3', 'fact4', 'fact5', 'fact6', 'fact7', 'fact8',
        'fact9'
    }


# Generated at 2022-06-11 02:16:01.651339
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.basic import AnsibleModule

    def get_param(key):
        return module.params.get(key)

    module = AnsibleModule(
        argument_spec={},
        get_bin_path=dict(),
    )

    ansible_facts(module)

    module.params['gather_subset'] = ['network']
    ansible_facts(module)

    module.params.pop('gather_subset')
    return ansible_facts(module)



# Generated at 2022-06-11 02:16:12.497252
# Unit test for function get_all_facts
def test_get_all_facts():
    # Mock a module
    from ansible.module_utils._text import to_native
    from ansible.module_utils.facts.facts import get_all_facts as facts_get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, msg):
            msg = to_native(msg)
            raise AssertionError(msg)

    # Create a namespace.
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')

    #

# Generated at 2022-06-11 02:16:28.055072
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.platform.base import PlatformFactCollector
    from ansible.module_utils.facts.system.base import SystemFactCollector
    from ansible.module_utils.facts.processor.base import ProcessorFactCollector
    from ansible.module_utils.facts.virtual.base import VirtualFactCollector

    class TestPlatformFactCollector(PlatformFactCollector):
        _fact_ids = frozenset(['test_platform'])

        def populate(self):
            self._populate_platform()

    class TestSystemFactCollector(SystemFactCollector):
        _fact_ids = frozenset(['test_system'])

        def populate(self):
            self._populate_system()


# Generated at 2022-06-11 02:16:37.503879
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts import ansible_collector
    import ansible.module_utils.ansible_release
    import ansible.module_utils.facts.collector.file
    import ansible.module_utils.facts.collector.hardware
    import ansible.module_utils.facts.collector.linux
    import ansible.module_utils.facts.collector.virtual

    # Shorten 'ansible_facts_collector', and make it globally accessible via 'ansible_facts'
    ansible_facts_collector = ansible_collector.AnsibleFactsCollector

    class DummyModule(object):
        def __init__(self, **kwargs):
            self.params = ImmutableDict(kwargs)

# Generated at 2022-06-11 02:16:48.935120
# Unit test for function get_all_facts
def test_get_all_facts():
    import os
    import sys
    import tempfile
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts

    # from ansible import cli
    # from ansible.module_utils.common.process import get_bin_path
    # from ansible.module_utils._text import to_bytes
    #
    # python2 = sys.version_info[0] < 3
    # if python2:
    #     from ansible.module_utils.facts import FactCollector
    # else:
    #     from ansible.module_utils.facts import FactCollector2 as FactCollector
    #
    # class FakeModule(object):
    #     def __init__(self, argv):
    #         self.params = cli.parse(

# Generated at 2022-06-11 02:17:00.138632
# Unit test for function ansible_facts
def test_ansible_facts():
    import unittest
    import os
    import errno

    # Make sure to set AnsibleModule as the import_module in ansible.module_utils.facts
    import ansible.module_utils.facts

    from ansible.compat.tests import unittest
    from ansible.module_utils.basic import AnsibleModule

    class TestAnsibleFacts(unittest.TestCase):

        def setUp(self):
            self.my_environ = os.environ.copy()

        def tearDown(self):
            os.environ = self.my_environ

        def test_ansible_facts(self):
            module = AnsibleModule(argument_spec={}, supports_check_mode=False)

            # Make sure to set AnsibleModule as the import_module in ansible.module_utils.facts
           

# Generated at 2022-06-11 02:17:08.959033
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import ansible_facts
    class AnsibleModule(object):
        class Basic:
            def __init__(self):
                self.params = {'gather_subset': ['all']}
        def __init__(self):
            self.basic = self.Basic()
    m = AnsibleModule()
    # for python 2.6, call get_all_facts directly
    if sys.version_info < (2,7):
        assert isinstance(get_all_facts(m), dict)
    # for python 2.7, get_all_facts is a method of the ansible-facts module_utils
    else:
        assert isinstance(ansible_facts.get_all_facts(m), dict)


# Generated at 2022-06-11 02:17:16.816653
# Unit test for function ansible_facts
def test_ansible_facts():
    # Import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

    # Create an instance of AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default='!configuration'),
            gather_timeout=dict(type='int', default=10),
            filter=dict(type='str', default='*')
        ),
        supports_check_mode=True
    )

    # get fact from function ansible_facts
    result = ansible_facts(module)

    # Check for the result from the function ansible_facts
    assert type(result) == dict

# Generated at 2022-06-11 02:17:28.121156
# Unit test for function get_all_facts
def test_get_all_facts():
    module_name = 'test_get_all_facts'

    class TestModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    expected_facts = {'default_ipv4': {'address': '1.2.3.4', 'interface': 'default_ipv4'}}

    # test
    module = TestModule(['network'])
    result = get_all_facts(module=module)

    # validate
    assert result == expected_facts, \
        "get_all_facts function did not return expected facts. Expected: %s, Actual: %s" % \
        (expected_facts, result)



# Generated at 2022-06-11 02:17:36.789450
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    import inspect
    import types

    # collect_function_args expects
    # (func, arg_names, arg_defaults, ignore_kwarg_names, arg_spec_ignore)
    # the following are just used to satisfy the arg_spec_ignore
    # requirements, so they can be None or empty
    # arg_names = tuple(['module'])
    # arg_defaults = ()
    # ignore_kwarg_names = ()

    # create a

# Generated at 2022-06-11 02:17:47.177445
# Unit test for function get_all_facts
def test_get_all_facts():
    '''Make a fake AnsibleModule, and call get_all_facts to collect all facts'''

    from ansible.module_utils.facts.utils import set_default_facts_collection_when_none
    set_default_facts_collection_when_none()

    import ansible.module_utils.facts.legacy
    from ansible.module_utils.facts.legacy import AnsibleModule
    module = AnsibleModule()

    all_facts = get_all_facts(module)

    # facts collection is slow, so it is not reasonable to use the fully
    # populated fact list to write unit tests

    # Instead, tests should mock up a new module and a minimal subset of the fact
    # collection that was implemented in 2.2.

    # so here, verify that the returned dict is not empty
    assert len(all_facts) > 0

# Generated at 2022-06-11 02:17:48.863107
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''
    pass

# Generated at 2022-06-11 02:18:06.801474
# Unit test for function get_all_facts
def test_get_all_facts():
    # Test that the get_all_facts() function does not return facts if os is not Linux
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import get_distribution
    DistributionFactCollector.distribution = lambda arg: {u'distribution': u'Darwin'}
    assert get_all_facts({}) == {}

    # Test that the get_all_facts() function does not return facts if os is not Linux
    DistributionFactCollector.distribution = lambda arg: {u'distribution': u'Linux'}
    default_collectors.collectors.append(DistributionFactCollector())
    assert get_all_facts({}) != {}

# Generated at 2022-06-11 02:18:11.040583
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list'),
        ),
        supports_check_mode=True
    )

    expected_gather_subset = ['all', 'network']
    m.params['gather_subset'] = expected_gather_subset

    facts = get_all_facts(m)

    expected_keys = frozenset(['ansible_default_ipv4.address'])
    assert facts.keys() == expected_keys

# Generated at 2022-06-11 02:18:23.179297
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.utils import get_file_content
    import json
    import os

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_data = json.loads(get_file_content(test_dir + "/facts.json"))

    # Check that each key in the test_data dictionary is identical to the key
    # in the ansible_facts dictionary. If the value of the key is a dictionary
    # then check each key/value pair in the test_data dictionary is identical
    # to the key/value pair in the ansible_facts dictionary.
    for key in test_data:
        value = test_data[key]

# Generated at 2022-06-11 02:18:32.204150
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_facts

    from ansible.compat.tests import unittest

    class DummyModule(object):
        def __init__(self, params):
            self.params = params

    class GetAllFactsTestCase(unittest.TestCase):
        def setUp(self):
            self.ansible_facts = ansible_facts
            self.mock_ansible = {}

        def test_get_all_facts(self):
            test_params = dict(gather_subset='all',
                               gather_timeout=10,
                               filter='*',
                               ANSIBLE_COLLECTION_PATH=to_bytes(''))
            module = DummyModule(params=test_params)


# Generated at 2022-06-11 02:18:40.978489
# Unit test for function get_all_facts
def test_get_all_facts():
    "Test the get_all_facts function."

    import sys
    import tempfile

    # create a temporary file to use for stdout redirection
    tmp_fd, tmp_name = tempfile.mkstemp(prefix='test_get_all_facts.')
    tmp_file = os.fdopen(tmp_fd, 'w+')

    # save the original stdout and redirect stdout to the temp file
    prev_stdout = sys.stdout
    sys.stdout = tmp_file

    # run the get_all_facts function and write the output to the temp file
    try:
        get_all_facts()
    except SystemExit:
        pass
    finally:
        # close the temp file and restore stdout
        tmp_file.flush()
        sys.stdout = prev_stdout
        tmp_file.close

# Generated at 2022-06-11 02:18:50.045974
# Unit test for function ansible_facts
def test_ansible_facts():

    # mock AnsibleModule
    class ModuleMock(object):
        def __init__(self):
            self.params = dict()

        def show_custom_stats(self, stats):
            pass

        def run_command(self, command):
            pass

        def get_bin_path(self, binary, required=False, opt_dirs=[]):
            pass

        def has_file(self, path):
            pass

        def get_platform(self):
            return 'linux'

        def get_distribution(self):
            return 'Centos'

        def get_all_subclasses(self, class_name):
            pass

        def load_file_common_arguments(self, params):
            return dict()


# Generated at 2022-06-11 02:18:59.320565
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.facts import get_file_content
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(type='list', default=None),
        gather_timeout=dict(type='int', default=None),
        filter=dict(type='str', default=None),
    ))
    module.exit_json = lambda **kwargs: kwargs
    module.fail_json = lambda **kwargs: kwargs
    module.run_command = lambda cmd, check_rc=False: (0, get_file_content(cmd[1]), '')
    module.get_bin_path = lambda binary: 'true'

    module.params['gather_subset'] = ['all']

# Generated at 2022-06-11 02:19:05.006951
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.network.aoscx.facts
    module = ansible.module_utils.facts.network.aoscx.facts.get_module(None)
    result = ansible_facts(module)
    assert type(result) is dict
    assert result['distribution'] == 'AOS-CX'


# Generated at 2022-06-11 02:19:13.565608
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import unittest
    sys.path.append('/home/wma/code/ansible/lib/ansible/module_utils')
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes

    from io import StringIO
    from contextlib import contextmanager
    from ansible.module_utils.basic import AnsibleModule

    def set_module_args(args):
        args = json.dumps({'ANSIBLE_MODULE_ARGS': args})
        basic._ANSIBLE_ARGS = to_bytes(args)

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()


# Generated at 2022-06-11 02:19:21.055044
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector

    module = MockAnsibleModule(params={'gather_subset': ''})
    ansible_collector.get_ansible_collector = Mock(return_value=MockFactCollector())
    facts = ansible_facts(module, gather_subset='')
    assert facts is not None
    module.exit_json.assert_called_with(ansible_facts={'test': 'test', 'test2': 'test2'}, filter='*')



# Generated at 2022-06-11 02:19:48.418118
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.fact_cache import FactCache
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.netlink.linux import LinuxNetlinkNetworkCollector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.hardware.base import HardwareCollector
    from ansible.module_utils.facts.hardware.linux import LinuxHardwareCollector

    class MockAnsibleModule(object):
        '''MockAnsibleModule class'''
        class MockAnsibleModule(object):
            '''MockAnsibleModule class'''


# Generated at 2022-06-11 02:19:57.656104
# Unit test for function ansible_facts
def test_ansible_facts():
    import pytest

    try:
        from unit.mock.module_utils.facts_mock import AnsibleModuleMocked
    except ImportError:
        pytest.skip("ansible-base not installed")

    module = AnsibleModuleMocked()
    facts_dict = ansible_facts(module, gather_subset=['all'])

    # 'ansible_distribution_version' is the last one in most systems
    assert(facts_dict['distribution_version'].startswith('20'))

# Generated at 2022-06-11 02:20:02.998175
# Unit test for function get_all_facts
def test_get_all_facts():
    ''' Test compat api for ansible 2.2/2.3 module_utils.facts.get_all_facts method
    '''

    # test an empty gather_subset
    class MockAnsibleModule:
        params = {
            'gather_subset': [],
        }

    result = get_all_facts(MockAnsibleModule)
    assert result == {}



# Generated at 2022-06-11 02:20:07.049641
# Unit test for function get_all_facts
def test_get_all_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    m = MockModule()
    results = get_all_facts(m)

    assert(results['default_ipv4']['address'])
    assert(results['fips'])


# Generated at 2022-06-11 02:20:12.461090
# Unit test for function ansible_facts
def test_ansible_facts():
    class DummyModule(object):
        pass

    module = DummyModule()
    module.params = {
        'gather_subset': ['all'],
        'gather_timeout': 10,
        'filter': '*'
    }

    facts = ansible_facts(module)
    assert facts.get('lsb')

# Generated at 2022-06-11 02:20:22.830044
# Unit test for function ansible_facts
def test_ansible_facts():

    import logging
    import sys

    logging.basicConfig(stream=sys.stdout)
    logger = logging.getLogger("test_ansible_facts")

    # Mockansible module
    class AnsibleModule():
        def __init__(self, params=None, check_invalid_arguments=None,
                     bypass_checks=None, no_log=None, check_mode=None):
            self.params = {'gather_subset': params,
                           'gather_timeout': 10,
                           'filter': '*'}
            self.check_invalid_arguments = check_invalid_arguments
            self.bypass_checks = bypass_checks
            self.no_log = no_log
            self.check_mode = check_mode

    # 1. When gather_subset is ALL
   

# Generated at 2022-06-11 02:20:29.586564
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={
        'gather_facts': dict(default=True)
    })
    facts = ansible_facts(mod)
    assert 'localhost' in facts['hostname']
    assert 'localhost' in facts['fqdn']
    assert facts['domain'] == 'localdomain'


# Generated at 2022-06-11 02:20:40.711282
# Unit test for function ansible_facts
def test_ansible_facts():
    '''unit test for function ansible_facts'''
    def dummy_module(params):
        class DummyModule:
            pass
        result = DummyModule()
        result.params = params
        return result
    import platform
    import sys

    params = dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*',
    )

    test_module = dummy_module(params)

    ansible_facts = ansible_facts(test_module)

    assert ansible_facts['system'] == platform.system().lower(), ("Unexpected system value %s" % ansible_facts['system'])
    if sys.version_info[0] == 2:
        python_major_version = '2'
    else:
        python_major_version = '3'
    assert ans

# Generated at 2022-06-11 02:20:51.570294
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import gather_subset_definitions
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import get_default_collector_names
    from ansible.module_utils.facts import get_collector_class_names

    import ansible.module_utils.facts.namespace as facts_namespace
    import ansible.module_utils.facts.system.distribution as facts_distribution
    import ansible.module_utils.facts.system.distribution as facts_platform
    import ansible.module_utils.facts.system.pkg_mgr as facts_pkg_mgr
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

   

# Generated at 2022-06-11 02:20:55.721749
# Unit test for function get_all_facts
def test_get_all_facts():
    # Test with gather_subset
    module = MockModule()
    module.params['gather_subset'] = 'all'
    assert ansible_facts(module, gather_subset=['all'])

    # Test with no gather_subset
    module = MockModule()
    assert ansible_facts(module)


# Generated at 2022-06-11 02:21:40.726069
# Unit test for function ansible_facts
def test_ansible_facts():
    def bare_fact_name(key):
        '''strip prefix'''
        if key.startswith('ansible_'):
            return key[8:]
        else:
            return key

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # Create a mock AnsibleModule instance.
    # The mock will mimic the fact that the module has an 'gather_subset' param.
    class MockAnsibleModule:
        params = {'gather_subset': ['all']}

    module = MockAnsibleModule()

    # get facts from AnsibleModule.
    collected_facts = ansible_facts(module, gather_subset=None)