

# Generated at 2022-06-16 23:40:39.926559
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    fake_module = FakeModule(['all'])
    facts = get_all_facts(fake_module)
    assert facts['distribution'] == 'Unknown'


# Generated at 2022-06-16 23:40:50.069763
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # test with gather_subset
    module = FakeModule({'gather_subset': ['all']})
    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert 'default_ipv4' in facts
    assert 'ansible_default_ipv4' not in facts

    # test without gather_subset
    module = FakeModule({})
    facts = get_all_facts(module)
    assert isinstance(facts, dict)

# Generated at 2022-06-16 23:41:02.786647
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

# Generated at 2022-06-16 23:41:16.088791
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

# Generated at 2022-06-16 23:41:27.571896
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import get_collector_classes

    class FakeModule:
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-16 23:41:37.368148
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import TestFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import TestFactNamespace
    from ansible.module_utils.facts.namespace import TestFact
    from ansible.module_utils.facts.namespace import TestFact2
    from ansible.module_utils.facts.namespace import TestFact3
    from ansible.module_utils.facts.namespace import TestFact4
    from ansible.module_utils.facts.namespace import Test

# Generated at 2022-06-16 23:41:47.236283
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFact
    from ansible.module_utils.facts.namespace import NamespaceFactCollection
    from ansible.module_utils.facts.namespace import NamespaceFactSubset
    from ansible.module_utils.facts.namespace import NamespaceFactSubsetCollection
    from ansible.module_utils.facts.namespace import NamespaceFactSubsetItem
    from ansible.module_utils.facts.namespace import NamespaceFactSubsetItemCollection
   

# Generated at 2022-06-16 23:41:54.550350
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector


# Generated at 2022-06-16 23:42:05.078949
# Unit test for function ansible_facts
def test_ansible_facts():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollect

# Generated at 2022-06-16 23:42:14.946598
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtual

# Generated at 2022-06-16 23:42:28.384943
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileSearchFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformFactCollector
    from ansible.module_utils.facts.collector import BaseVirtualizationCollector
    from ansible.module_utils.facts.collector import BaseWindowsFactCollector

# Generated at 2022-06-16 23:42:40.628239
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Test that ansible_facts returns a dict with the expected keys
    # and that the values are of the expected type.
    #
    # This is not a complete test of the facts module.
    # It is just a test of the ansible_facts function.
    #
    # The test is not complete because it does not test the values of the facts.
    # It just tests that the facts are present and that they are of the expected type.
    #
    # The test is not complete because it does not test the values of the facts.
    # It just tests that the facts are present and that they are of the expected type.
   

# Generated at 2022-06-16 23:42:49.909123
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:42:53.801523
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule:
        def __init__(self, params):
            self.params = params

    class FakeCollector:
        def __init__(self, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.minimal_gather_subset = minimal_gather_subset

        def collect(self, module):
            return {'foo': 'bar'}

# Generated at 2022-06-16 23:43:04.122373
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class_for_platform

    class TestFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = ['test_fact']

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    class TestFactCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = ['test_fact2']

        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_fact_value2'}


# Generated at 2022-06-16 23:43:13.219664
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    module = FakeModule({'gather_subset': ['all']})
    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert facts['distribution'] == 'RedHat'

    module = FakeModule({'gather_subset': ['all'], 'filter': 'ansible_distribution'})
    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert facts['distribution'] == 'RedHat'


# Generated at 2022-06-16 23:43:23.115053
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector


# Generated at 2022-06-16 23:43:35.540227
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Test that get_all_facts calls ansible_facts with the correct args
    class MockModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    mock_module = MockModule(['all'])

    ansible_facts_mock = Mock()
    ansible_facts_mock.return_value = {'foo': 'bar'}

# Generated at 2022-06-16 23:43:44.973751
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformFactCollector
    from ansible.module_utils.facts.collector import BaseSELinuxFactCollector

# Generated at 2022-06-16 23:43:52.280831
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import DefaultFactCollector
    from ansible.module_utils.facts.collector import AnsibleFactCollector
    from ansible.module_utils.facts.collector import NetworkFactCollector
    from ansible.module_utils.facts.collector import HardwareFactCollector
    from ansible.module_utils.facts.collector import VirtualFactCollector

# Generated at 2022-06-16 23:44:00.667561
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    class FakeModule:
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['all']}
    module = FakeModule(params)

    # get_all_facts should call ansible_facts with the gather_subset
    # from the module params
    ansible_facts.assert_called_with(module, gather_subset=['all'])
    get_all_facts(module)

    # ans

# Generated at 2022-06-16 23:44:12.801704
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeCollector(object):
        def __init__(self, name, namespace, filter_spec, gather_subset, gather_timeout,
                     minimal_gather_subset):
            self.name = name
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.minimal_gather_subset = minimal_gather_subset


# Generated at 2022-06-16 23:44:25.082430
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:44:33.875042
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import NamespaceCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_fact2': 'test_value2'}

    class TestCollector3(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return

# Generated at 2022-06-16 23:44:47.341354
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        def __init__(self, params):
            self.params = params

    # Test with gather_subset
    params = {'gather_subset': ['all']}
    module = FakeModule(params)
    fact_collector = ansible_facts(module, gather_subset=['all'])
    assert isinstance(fact_collector, PrefixFactNamespace)

    # Test without gather_subset
    params = {'gather_subset': ['all']}

# Generated at 2022-06-16 23:44:57.645861
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.utils import get_distribution
    from ansible.module_utils.facts.utils import get_file_systems
    from ansible.module_utils.facts.utils import get_file_systems_info
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_info

# Generated at 2022-06-16 23:45:09.576672
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = set(['test_fact2'])


# Generated at 2022-06-16 23:45:20.436598
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import PlatformCollector
    from ansible.module_utils.facts.collector import VirtualCollector
    from ansible.module_utils.facts.collector import get_collector_classes

# Generated at 2022-06-16 23:45:33.403562
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.service
    import ansible.module_utils.facts.package
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.user
    import ansible.module_utils.facts.selinux
    import ansible.module_utils.facts.fips
    import ansible.module_utils.facts.cmdline
    import ansible.module_utils.facts.date_time
    import ansible.module_utils.facts.perf
    import ansible.module_

# Generated at 2022-06-16 23:45:46.269673
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_attributes
    from ansible.module_utils.facts.utils import get_file_stat

# Generated at 2022-06-16 23:46:03.873539
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:46:16.051659
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import DefaultFactCollector
    from ansible.module_utils.facts.collector import AnsibleFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import get_ansible_collector
    from ansible.module_utils.facts.collector import get_collector_classes

# Generated at 2022-06-16 23:46:19.276718
# Unit test for function ansible_facts
def test_ansible_facts():
    # TODO: write unit test for ansible_facts
    pass

# Generated at 2022-06-16 23:46:31.382044
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import OpenBSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import FreeBSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import NetBSDDistributionFactCollector

# Generated at 2022-06-16 23:46:40.585882
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsRegistryCollector
    from ansible.module_utils.facts.collector import BaseWindowsWMI
    from ansible.module_utils.facts.collector import BaseWindowsWMICollector
    from ansible.module_utils.facts.collector import BaseWindowsWMIScriptCollector

# Generated at 2022-06-16 23:46:53.325927
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeCollector(object):
        def __init__(self, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.minimal_gather_subset = minimal_gather_sub

# Generated at 2022-06-16 23:47:06.190184
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class TestFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = frozenset(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    class TestCollector(Collector):
        _fact_classes = [TestFactCollector]


# Generated at 2022-06-16 23:47:16.579585
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

# Generated at 2022-06-16 23:47:24.589347
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import DefaultFactCollector
    from ansible.module_utils.facts.collector import AnsibleFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import get_ansible_collector
    from ansible.module_utils.facts.collector import get_collector_classes

# Generated at 2022-06-16 23:47:35.964779
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_class_name_map
    from ansible.module_utils.facts.collector import get_collector_class_name_map

# Generated at 2022-06-16 23:48:02.957949
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import DefaultFactCollector
    from ansible.module_utils.facts.collector import AnsibleFactCollector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-16 23:48:11.929924
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:48:19.959478
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import DefaultGatherSubset
    from ansible.module_utils.facts.collector import DefaultGatherTimeout
    from ansible.module_utils.facts.collector import Minimal

# Generated at 2022-06-16 23:48:32.197595
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file import FileCollector
    from ansible.module_utils.facts.collector.service import ServiceCollector
    from ansible.module_utils.facts.collector.distribution import DistributionCollector
    from ansible.module_utils.facts.collector.local import LocalCollector

# Generated at 2022-06-16 23:48:40.887354
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector

# Generated at 2022-06-16 23:48:53.605665
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    from ansible.module_utils.facts import ansible_facts

    # mock module
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    # mock module instance
    module = MockModule({'gather_subset': ['all']})

    # run ansible_facts
    facts_dict = ansible_facts(module)

    # check for expected keys
    assert 'distribution' in facts_dict
    assert 'distribution_version' in facts_dict
    assert 'distribution_release' in facts_dict
    assert 'distribution_major_version' in facts_dict
    assert 'os_family' in facts_dict
    assert 'python_version' in facts_dict
    assert 'python_executable' in facts

# Generated at 2022-06-16 23:49:04.241230
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # mock module
    class AnsibleModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    module = AnsibleModule()

    # mock collector
    class Collector:
        def __init__(self, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.minimal_gather_subset = minimal

# Generated at 2022-06-16 23:49:15.772091
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['all'], 'gather_timeout': 10}

    fake_module = FakeModule()

    gather_subset = fake_module.params['gather_subset']
    gather_timeout = fake_module.params['gather_timeout']
    filter_spec = '*'


# Generated at 2022-06-16 23:49:27.364195
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    # test that get_all_facts calls ansible_facts with the gather_subset
    # argument
    gather_subset = ['all']
    module = FakeModule(gather_subset)
    ansible_facts_mock = Mock(wraps=ansible_facts)

# Generated at 2022-06-16 23:49:38.754455
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    # test that ansible_facts returns a dict with the expected key/value
    # and that the collector was called with the expected namespace
    namespace = PrefixFactNamespace(namespace_name='ansible', prefix='')
    all_collector_

# Generated at 2022-06-16 23:50:22.500696
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # Test with gather_subset
    module = FakeModule({'gather_subset': ['all']})
    facts = get_all_facts(module)
    assert facts['distribution'] == 'RedHat'

    # Test without gather_subset
    module = FakeModule({})
    facts = get_all_facts(module)
    assert facts['distribution'] == 'RedHat'



# Generated at 2022-06-16 23:50:30.820411
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_subset
    from ansible.module_utils.facts.collector import get_collector_subsets