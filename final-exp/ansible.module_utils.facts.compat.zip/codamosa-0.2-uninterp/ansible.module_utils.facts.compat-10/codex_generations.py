

# Generated at 2022-06-16 23:40:36.753726
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import DefaultGatherSubset
    from ansible.module_utils.facts.collector import DefaultGatherTimeout
    from ansible.module_utils.facts.collector import DefaultFilterSpec
    from ansible.module_utils.facts.collector import DefaultMinimalGatherSubset

# Generated at 2022-06-16 23:40:44.035035
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyFactCollector
    from ansible.module_utils.facts.collector import BaseNetworkFactCollector
    from ansible.module_utils.facts.collector import BaseNetworkLegacyFactCollector
    from ansible.module_utils.facts.collector import BaseNetworkCommandFactCollector
    from ansible.module_utils.facts.collector import BaseNetworkFileGlobFactCollector

# Generated at 2022-06-16 23:40:55.678946
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsRegistryCollector
    from ansible.module_utils.facts.collector import BaseWindowsWMI

# Generated at 2022-06-16 23:41:06.912375
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformFactCollector
    from ansible.module_utils.facts.collector import BaseVirtualizationCollector

# Generated at 2022-06-16 23:41:16.886751
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformFactCollector
    from ansible.module_utils.facts.collector import BaseVirtualizationCollector

# Generated at 2022-06-16 23:41:27.462549
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector

# Generated at 2022-06-16 23:41:37.340549
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class MockModule:
        def __init__(self, params):
            self.params = params

    # Test with no gather_subset
    module = MockModule({'gather_subset': None})
    facts_dict = ansible_facts(module)
    assert facts_dict['distribution'] == 'RedHat'

    # Test with gather_subset
    module = MockModule({'gather_subset': ['all']})
    facts_dict = ansible_facts(module)

# Generated at 2022-06-16 23:41:47.199403
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_all_collector_classes
    from ansible.module_utils.facts.utils import get_collector_classes_for_subset
    from ansible.module_utils.facts.utils import get_collector_classes_for_subset_strict
    from ansible.module_utils.facts.utils import get_collector_classes_for_subset_minimal

    # test that ansible_facts calls get_ansible_collector with the correct args
    # and returns the result

# Generated at 2022-06-16 23:41:54.524474
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_by_name
    from ansible.module_utils.facts.collector import get_collector_names

# Generated at 2022-06-16 23:42:01.358720
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import NamespacePrefixFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import AnsibleCollectorException
    from ansible.module_utils.facts.collector import AnsibleCollectorTimeoutException
    from ansible.module_utils.facts.collector import AnsibleCollectorUnsupportedException

# Generated at 2022-06-16 23:42:12.214496
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = frozenset(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['test']}
    module = TestModule(params)

    # test that the test collector

# Generated at 2022-06-16 23:42:22.092534
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

# Generated at 2022-06-16 23:42:29.879567
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import namespace_manager
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
   

# Generated at 2022-06-16 23:42:40.777652
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['all'], 'gather_timeout': 10, 'filter': '*'}
    module = FakeModule(params)

    gather_subset = module.params['gather_subset']
    gather_timeout = module.params.get('gather_timeout', 10)
    filter_spec = module.params.get('filter', '*')

    minimal_gather_subset = frozens

# Generated at 2022-06-16 23:42:49.995733
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NamespaceCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector

# Generated at 2022-06-16 23:42:57.496344
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_names_from_class
    from ansible.module_utils.facts.collector import get_collector_names_from_classes
    from ansible.module_utils.facts.collector import get_collector_names_from_module
    from ansible.module_utils.facts.collector import get_collector_names_from_modules

# Generated at 2022-06-16 23:43:08.646073
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

# Generated at 2022-06-16 23:43:19.580394
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:43:31.857547
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:43:42.429392
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:43:57.779624
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactsCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_ansible_collector

# Generated at 2022-06-16 23:44:09.969933
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # Test with gather_subset
    module = FakeModule({'gather_subset': ['all']})
    facts_dict = ansible_facts(module)
    assert facts_dict['distribution'] == 'unknown'

    # Test without gather_subset
    module = FakeModule({})
    facts_dict = ansible_facts(module)
    assert facts_dict['distribution'] == 'unknown'

    # Test with gather_

# Generated at 2022-06-16 23:44:16.895241
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

# Generated at 2022-06-16 23:44:27.757592
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    fake_module = FakeModule(['all'])
    facts_dict = get_all_facts(fake_module)
    assert 'default_ipv4' in facts_dict
    assert 'default_ipv6' in facts_dict
    assert 'distribution' in facts_dict
    assert 'distribution_release' in facts_dict
    assert 'distribution_version' in facts_dict

# Generated at 2022-06-16 23:44:34.839790
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # create a mock module
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    # create a mock collector
    class MockCollector(object):
        def __init__(self, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.minimal_gather_subset = minimal_gather_subset

       

# Generated at 2022-06-16 23:44:48.238640
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:44:58.410986
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    fake_module = FakeModule(gather_subset=['all'])

    facts_dict = get_all_facts(fake_module)

    assert facts_dict == ansible_facts(fake_module, gather_subset=['all'])

# Generated at 2022-06-16 23:45:10.099023
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_distribution
    from ansible.module_utils.facts.collector import get

# Generated at 2022-06-16 23:45:20.662173
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    module = FakeModule({'gather_subset': ['all']})
    facts = get_all_facts(module)
    assert facts == ansible_facts(module)

    module = FakeModule({'gather_subset': ['min']})
    facts = get_all_facts(module)
    assert facts == ansible_facts(module)


# Generated at 2022-06-16 23:45:33.632044
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

# Generated at 2022-06-16 23:45:52.167690
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # Mock the module
    class MockModule:
        def __init__(self, params):
            self.params = params

    # Mock the collector
    class MockCollector:
        def __init__(self, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.minimal_gather_

# Generated at 2022-06-16 23:46:02.467992
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyFactCollector
    from ansible.module_utils.facts.collector import BaseDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentDictFactCollector

# Generated at 2022-06-16 23:46:14.738065
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

# Generated at 2022-06-16 23:46:28.672797
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import DefaultCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import HardwareCollector
    from ansible.module_utils.facts.collector import VirtualCollector
    from ansible.module_utils.facts.collector import SystemCollector

# Generated at 2022-06-16 23:46:38.696647
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:46:51.197073
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # Mock module
    class MockModule:
        def __init__(self):
            self.params = {}

    module = MockModule()
    module.params['gather_subset'] = ['all']
    module.params['gather_timeout'] = 10
    module.params['filter'] = '*'


# Generated at 2022-06-16 23:46:59.336335
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:47:11.084817
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import NamespacePrefixFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import AnsibleCollectorException
    from ansible.module_utils.facts.collector import AnsibleFactCollector
    from ansible.module_utils.facts.collector import AnsibleFactCollectorException

# Generated at 2022-06-16 23:47:18.245734
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # test with gather_subset
    params = {'gather_subset': ['all']}
    module = FakeModule(params)
    facts = ansible_facts(module)
    assert 'default_ipv4' in facts

    # test without gather_subset
    params = {}
    module = FakeModule(params)
    facts = ansible_facts(module)
    assert 'default_ipv4' in facts

# Generated at 2022-06-16 23:47:29.748107
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_all_collector_classes
    from ansible.module_utils.facts.utils import get_collector_classes_for_gather_subset
    from ansible.module_utils.facts.utils import get_collector_classes_for_gather_subset_by_name

    class DummyModule(object):
        def __init__(self, gather_subset, gather_timeout):
            self.params = {'gather_subset': gather_subset, 'gather_timeout': gather_timeout}


# Generated at 2022-06-16 23:47:56.215871
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import mock

    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['all'],
                           'gather_timeout': 10,
                           'filter': '*'}

    class FakeCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            pass

        def collect(self, module=None, collected_facts=None):
            return {'fake_fact': 'fake_value'}


# Generated at 2022-06-16 23:48:06.970468
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileSearchFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseNetworkFactCollector
    from ansible.module_utils.facts.collector import BaseHardwareFactCollector
    from ansible.module_utils.facts.collector import BaseVirtualizationFactCollector
    from ansible.module_utils.facts.collector import BaseSystemFactCollector
    from ansible.module_utils.facts.collector import BaseDistributionFactCollector
    from ansible.module_utils.facts.collector import BaseUser

# Generated at 2022-06-16 23:48:14.734101
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import NamespaceCollector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace

    class TestFactCollector(BaseFactCollector):
        '''A test fact collector class'''
        name = 'test'
        _fact_ids = frozenset(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}


# Generated at 2022-06-16 23:48:21.500589
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import NamespacePrefixFactCollector
    from ansible.module_utils.facts.collector import PrefixFactCollector
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import NamespaceFactNamespace
    from ansible.module_utils.facts.namespace import NamespacePrefixFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
   

# Generated at 2022-06-16 23:48:33.808861
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.utils import ansible_facts
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.utils import ansible_facts
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.utils import ansible_facts
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.utils import ansible_

# Generated at 2022-06-16 23:48:41.799162
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # mock module
    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all'], 'gather_timeout': 10}

    # mock collector
    class MockCollector(object):
        def __init__(self, all_collector_classes, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            self.all_collector_classes = all_collector_classes
            self.namespace = namespace
            self.filter

# Generated at 2022-06-16 23:48:54.201152
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    fake_module = FakeModule({'gather_subset': ['all']})
    assert get_all_facts(fake_module) == ansible_facts(fake_module)

    fake_module = FakeModule({'gather_subset': ['all'], 'gather_timeout': 10})
    assert get_all_facts(fake_module) == ansible_

# Generated at 2022-06-16 23:49:02.978652
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    fake_module = FakeModule(['all'])
    facts = get_all_facts(fake_module)
    assert 'default_ipv4' in facts
    assert 'ansible_default_ipv4' not in facts



# Generated at 2022-06-16 23:49:13.774417
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class MockModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    module = MockModule(gather_subset=['all'])
    facts = get_all_facts(module)
    assert facts['lsb']['distrib_id'] == 'CentOS'
    assert facts['lsb']['distrib_release'] == '7.2.1511'
    assert facts['lsb']['distrib_codename'] == 'Core'

# Generated at 2022-06-16 23:49:26.068551
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['all'],
              'gather_timeout': 10,
              'filter': '*'}

    module = FakeModule(params)

    gather_subset = module.params['gather_subset']
    gather_timeout = module.params.get('gather_timeout', 10)
    filter_spec = module.params.get('filter', '*')

    minimal_gather_sub

# Generated at 2022-06-16 23:50:07.994094
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsRegistryCollector

# Generated at 2022-06-16 23:50:15.881831
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:50:27.159908
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsRegistryCollector
    from ansible.module_utils.facts.collector import BaseWindowsWMI
    from ansible.module_utils.facts.collector import BaseWindowsWMICollector
    from ansible.module_utils.facts.collector import BaseWindowsWMICollector