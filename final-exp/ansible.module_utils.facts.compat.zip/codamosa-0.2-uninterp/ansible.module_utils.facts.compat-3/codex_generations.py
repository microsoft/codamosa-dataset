

# Generated at 2022-06-16 23:40:36.094657
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule:
        def __init__(self, params):
            self.params = params

    fake_module = FakeModule(params={'gather_subset': ['all']})
    facts = get_all_facts(fake_module)
    assert facts == ansible_facts(fake_module, gather_subset=['all'])

    fake_module = FakeModule(params={'gather_subset': ['min']})
    facts = get_all_facts(fake_module)
    assert facts == ansible_facts(fake_module, gather_subset=['min'])

    fake_module

# Generated at 2022-06-16 23:40:43.791098
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import RedHatDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DebianDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SuseDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import AlpineDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxMintDistributionFactCollector

# Generated at 2022-06-16 23:40:55.314410
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Create a mock module
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    # Create a mock collector
    class MockCollector(object):
        def __init__(self, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.minimal_gather_subset = minimal_gather_subset

       

# Generated at 2022-06-16 23:41:05.205867
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        def __init__(self, params):
            self.params = params

    # test with no gather_subset
    module = FakeModule({'gather_subset': None,
                         'gather_timeout': 10,
                         'filter': '*'})
    facts_dict = ansible_facts(module)
    assert facts_dict['distribution'] == 'unknown'

    # test with gather_subset

# Generated at 2022-06-16 23:41:16.322901
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-16 23:41:27.847318
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.lsb
    import ansible.module_utils.facts.system.env
    import ansible.module_utils.facts.system.dns
    import ansible.module_utils.facts.system.cmdline
    import ansible.module_utils.facts.system.date_time
    import ansible.module_utils.facts.network.default_ipv4
    import ansible

# Generated at 2022-06-16 23:41:39.759280
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    module = FakeModule({'gather_subset': ['all']})
    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert 'distribution' in facts
    assert 'distribution_version' in facts
    assert 'distribution_release' in facts
    assert 'distribution_major_version' in facts

    module = FakeModule({'gather_subset': ['all', 'network']})
    facts = get_all_facts(module)

# Generated at 2022-06-16 23:41:48.578144
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector

# Generated at 2022-06-16 23:41:59.705911
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import DefaultFactCollector
    from ansible.module_utils.facts.collector import AnsibleFactCollector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_ansible_collector

# Generated at 2022-06-16 23:42:11.290288
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestFactCollector(BaseFactCollector):
        name = 'test_fact_collector'
        _fact_ids = set(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}


# Generated at 2022-06-16 23:42:22.881989
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import NamespaceCollector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespaceDict
    from ansible.module_utils.facts.namespace import NamespaceKeyError
    from ansible.module_utils.facts.namespace import NamespaceKeyError

# Generated at 2022-06-16 23:42:28.775936
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileSearchFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformFactCollector
    from ansible.module_utils.facts.collector import BaseSELinuxFactCollector

# Generated at 2022-06-16 23:42:40.665326
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # test with gather_subset
    module = FakeModule({'gather_subset': ['all']})
    facts = ansible_facts(module)
    assert isinstance(facts, dict)
    assert isinstance(facts['distribution'], dict)
    assert isinstance(facts['distribution']['distribution'], str)

    # test without gather_subset
    module = FakeModule({})
    facts = ansible_

# Generated at 2022-06-16 23:42:49.909053
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def __init__(self, gather_subset=None):
            self.params = {'gather_subset': gather_subset}

    class FakeCollector(object):
        def __init__(self, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather

# Generated at 2022-06-16 23:42:53.801304
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileWriteCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseServiceMgrCollector
    from ansible.module_utils.facts.collector import BaseSystemCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsRegistryCollector
    from ansible.module_utils.facts.collector import BaseWindowsServerCollector

# Generated at 2022-06-16 23:43:01.691001
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    module = FakeModule({'gather_subset': ['all']})
    facts_dict = ansible_facts(module)

    assert isinstance(facts_dict, dict)
    assert isinstance(facts_dict['distribution'], dict)
    assert isinstance(facts_dict['distribution']['name'], str)
    assert isinstance(facts_dict['distribution']['version'], str)
    assert isinstance(facts_dict['distribution']['id'], str)
   

# Generated at 2022-06-16 23:43:11.093845
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    # pylint: disable=import-error
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector

# Generated at 2022-06-16 23:43:22.916298
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # test with gather_subset
    params = {'gather_subset': ['all']}
    module = FakeModule(params)
    facts_dict = ansible_facts(module)
    assert isinstance(facts_dict, dict)
    assert isinstance(facts_dict['ansible_facts'], dict)

    # test without gather_subset
    params = {}
    module = FakeModule(params)
    facts_dict

# Generated at 2022-06-16 23:43:35.274245
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # create a mock module
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    # create a mock ansible module
    class MockAnsibleModule(object):
        def __init__(self, params):
            self.params = params

    # create a mock ansible module
    class MockAnsibleModuleWithGatherSubset(object):
        def __init__(self, params):
            self.params = params

    # create a mock ansible module

# Generated at 2022-06-16 23:43:44.777411
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = frozenset(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    class TestNamespace(PrefixFactNamespace):
        name = 'test'
        prefix = 'test_'

    # test that the test fact collector is used

# Generated at 2022-06-16 23:44:00.290850
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:44:12.407048
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import DefaultFactCollector
    from ansible.module_utils.facts.collector import AnsibleFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import get_ansible_collector
    from ansible.module_utils.facts.collector import get_collector_classes

# Generated at 2022-06-16 23:44:24.891228
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_

# Generated at 2022-06-16 23:44:33.779231
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # test with no gather_subset
    module = FakeModule({'gather_subset': None})
    facts = ansible_facts(module)
    assert isinstance(facts, dict)
    assert 'distribution' in facts
    assert 'distribution_version' in facts

    # test with gather_subset
    module = FakeModule({'gather_subset': ['all']})
    facts = ansible_facts(module)

# Generated at 2022-06-16 23:44:47.299133
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_

# Generated at 2022-06-16 23:44:54.428681
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FacterCollector
    from ansible.module_utils.facts.collector import OhaiCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import VirtualCollector

# Generated at 2022-06-16 23:45:02.521013
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

# Generated at 2022-06-16 23:45:12.168931
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import DefaultFactCollector
    from ansible.module_utils.facts.collector import AnsibleFactCollector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeCollector(BaseFactCollector):
        name = 'fake'
        _fact_ids = ['fake_fact']


# Generated at 2022-06-16 23:45:21.612543
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_ansible_collector
    from ansible.module_utils.facts.collector import get_collector

# Generated at 2022-06-16 23:45:34.241457
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    module = FakeModule(gather_subset=['all'])
    facts_dict = get_all_facts(module)
    assert facts_dict['distribution'] == 'unknown'
    assert facts_dict['distribution_version'] == 'unknown'
    assert facts_dict['distribution_release'] == 'unknown'
    assert facts_dict['distribution_major_version'] == 'unknown'


# Generated at 2022-06-16 23:45:53.572519
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseFileGlobLegacyCollector
    from ansible.module_utils.facts.collector import BaseFileFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector

# Generated at 2022-06-16 23:46:03.825238
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # test with gather_subset
    module = FakeModule(params={'gather_subset': ['all']})
    facts_dict = ansible_facts(module)
    assert isinstance(facts_dict, dict)
    assert 'distribution' in facts_dict
    assert 'distribution_release' in facts_dict
    assert 'distribution_version' in facts_dict
    assert 'distribution_major_version' in facts_dict
    assert 'distribution_file_parsed' in facts

# Generated at 2022-06-16 23:46:16.008729
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:46:29.794664
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(FakeCollector, self).__init__(*args, **kwargs)
            self.collect_called = False

        def collect(self, module=None, collected_facts=None):
            self.collect_called = True

# Generated at 2022-06-16 23:46:39.589584
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = ['test_fact']

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestModule(object):
        def __init__(self, params):
            self.params = params

    # Test that the test collector is called
    params = dict(gather_subset=['all'])
    module = TestModule(params)
    all_collect

# Generated at 2022-06-16 23:46:52.518276
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.utils import ansible_facts
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.utils import ansible_facts
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.utils import ansible_facts
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.utils import ansible_

# Generated at 2022-06-16 23:47:05.265424
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # Test with gather_subset
    module = FakeModule({'gather_subset': ['all']})
    facts_dict = ansible_facts(module)
    assert facts_dict['distribution'] == 'unknown'

    # Test without gather_subset
    module = FakeModule({})
    facts_dict = ansible_facts(module)
    assert facts_dict['distribution'] == 'unknown'

# Generated at 2022-06-16 23:47:15.807455
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # mock module
    class MockModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    # mock collector
    class MockCollector(object):
        def __init__(self, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            self.namespace = namespace
            self.filter_spec = filter_spec
            self

# Generated at 2022-06-16 23:47:26.315054
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_classes
    from ansible.module_utils.facts.utils import get_collector_class_names
    from ansible.module_utils.facts.utils import get_collector_class_names_from_subset
    from ansible.module_utils.facts.utils import get_collector_class_names_from_subset_list
    from ansible.module_utils.facts.utils import get_collector_class_names_from_subset_string
    from ansible.module_utils.facts.utils import get_collector_classes_

# Generated at 2022-06-16 23:47:29.828666
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import NamespaceCollector
    from ansible.module_utils.facts.collector import BaseFileGlobCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseServiceMgrCollector
    from ansible.module_utils.facts.collector import BaseSystemCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector

# Generated at 2022-06-16 23:48:00.630082
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileSearchFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector

# Generated at 2022-06-16 23:48:09.851813
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import DefaultGatherSubsetCollector
    from ansible.module_utils.facts.collector import MinimalGatherSubsetCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector

# Generated at 2022-06-16 23:48:19.013895
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

# Generated at 2022-06-16 23:48:30.905023
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

# Generated at 2022-06-16 23:48:36.858933
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # test with gather_subset=None
    module = FakeModule({'gather_subset': None})
    gather_subset = module.params['gather_subset']
    gather_timeout = module.params.get('gather_timeout', 10)
    filter_spec = module.params.get('filter', '*')


# Generated at 2022-06-16 23:48:43.322886
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    fake_module = FakeModule()

    gather_subset = fake_module.params['gather_subset']
    gather_timeout = fake_module.params.get('gather_timeout', 10)
    filter_spec = fake_module.params.get('filter', '*')


# Generated at 2022-06-16 23:48:55.610213
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    assert get_all_facts(FakeModule(['all'])) == ansible_facts(FakeModule(['all']))
    assert get_all_facts(FakeModule(['min'])) == ansible_facts(FakeModule(['min']))
    assert get_all_facts(FakeModule(['!all'])) == ansible_facts(FakeModule(['!all']))
    assert get_all_facts(FakeModule(['!min'])) == ansible_facts(FakeModule(['!min']))

# Generated at 2022-06-16 23:49:04.485325
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    fake_module = FakeModule({'gather_subset': ['all']})
    facts_dict = get_all_facts(fake_module)
    assert 'default_ipv4' in facts_dict
    assert 'distribution' in facts_dict
    assert facts_dict['distribution'] == 'RedHat'



# Generated at 2022-06-16 23:49:15.997682
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts

    # Test with gather_subset=None
    assert ansible_facts(module=None, gather_subset=None) == {}

    # Test with gather_subset=[]
    assert ansible_facts(module=None, gather_subset=[]) == {}

    # Test with gather_subset=['all']
    assert ansible_facts(module=None, gather_subset=['all']) == {}

    # Test with gather_subset=['!all']
    assert ansible_facts(module=None, gather_subset=['!all']) == {}

    # Test with gather_subset=['*']
    assert ansible_facts(module=None, gather_subset=['*']) == {}

    # Test with gather_subset=['

# Generated at 2022-06-16 23:49:27.545582
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class AnsibleModule(object):
        def __init__(self, params):
            self.params = params

    module = AnsibleModule({'gather_subset': 'all'})
    facts = get_all_facts(module)
    assert facts['distribution'] == 'RedHat'
    assert facts['distribution_version'] == '7.3'
    assert facts['distribution_major_version'] == '7'
    assert facts['distribution_release'] == 'Maipo'
    assert facts['os_family'] == 'RedHat'
    assert facts['kernel'] == 'Linux'

# Generated at 2022-06-16 23:50:16.080531
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.utils import get_collector_classes
    from ansible.module_utils.facts.utils import get_collector_class
    from ansible.module_utils.facts.utils import get_collector_class_by_name
    from ansible.module_utils.facts.utils import get_collector_class_by_key
    from ansible.module_utils.facts.utils import get_collector_class_by_key_value

# Generated at 2022-06-16 23:50:27.275003
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtual