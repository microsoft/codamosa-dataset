

# Generated at 2022-06-16 23:40:36.014576
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

# Generated at 2022-06-16 23:40:43.767253
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsRegistryCollector

# Generated at 2022-06-16 23:40:44.720298
# Unit test for function ansible_facts
def test_ansible_facts():
    # TODO: write unit test
    pass

# Generated at 2022-06-16 23:40:56.669610
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import DefaultCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import HardwareCollector
    from ansible.module_utils.facts.collector import VirtualCollector
    from ansible.module_utils.facts.collector import SystemCollector

# Generated at 2022-06-16 23:41:06.989040
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        def __init__(self, params):
            self.params = params

    module = FakeModule({'gather_subset': ['all']})
    assert get_all_facts(module) == ansible_facts(module)

    module = FakeModule({'gather_subset': ['min']})
    assert get_all_facts(module) == ansible_facts(module)


# Generated at 2022-06-16 23:41:14.488892
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_classes

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeFactCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(FakeFactCollector, self).__init__(*args, **kwargs)
            self.collect_called = False

        def collect(self, module=None, collected_facts=None):
            self.collect_called = True
            return {}


# Generated at 2022-06-16 23:41:24.362094
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:41:30.884968
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector

# Generated at 2022-06-16 23:41:43.391317
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector
    from ansible.module_utils.facts.system.local import LocalFactCollector
    from ansible.module_utils.facts.system.lsb import LsbFactCollector
    from ansible.module_utils.facts.system.date_time import DateTimeFactCollector
    from ansible.module_utils.facts.system.python import PythonFactCollector

# Generated at 2022-06-16 23:41:54.102307
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import BaseFactNamespace

    class TestFactCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    class TestFactNamespace(BaseFactNamespace):
        name = 'test_namespace'

    test_collector = TestFactCollector(namespace=TestFactNamespace())
    test_module = {'params': {'gather_subset': ['all']}}
    test_facts = ansible_facts(module=test_module, gather_subset=['all'])

# Generated at 2022-06-16 23:42:06.426450
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:42:16.638464
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.namespace import BaseFactNamespace
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import namespace_manager
    from ansible.module_utils.facts import utils
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
   

# Generated at 2022-06-16 23:42:28.351207
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_classes

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-16 23:42:40.629865
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_

# Generated at 2022-06-16 23:42:49.878077
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    fake_module = FakeModule(['all'])
    facts_dict = get_all_facts(fake_module)

    assert facts_dict
    assert isinstance(facts_dict, dict)
    assert 'default_ipv4' in facts_dict
    assert 'distribution' in facts_dict
    assert 'distribution_version' in facts_dict
    assert 'distribution_release' in facts_dict

# Generated at 2022-06-16 23:42:54.214435
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_ansible_collector
    from ansible.module_utils.facts.collector import get_collector_classes

# Generated at 2022-06-16 23:43:04.162024
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:43:13.262831
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import FileCacheCollector
    from ansible.module_utils.facts.collector import NamespaceFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import LegacyCollector
    from ansible.module_utils.facts.collector import NamespaceLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector

# Generated at 2022-06-16 23:43:22.902372
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestFactCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(TestFactCollector, self).__init__(*args, **kwargs)
            self.facts_dict = {'test_fact': 'test_fact_value'}

        def collect(self, module=None, collected_facts=None):
            return self.facts_dict


# Generated at 2022-06-16 23:43:35.326940
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # test with gather_subset
    module = FakeModule({'gather_subset': ['all']})
    facts_dict = ansible_facts(module)
    assert isinstance(facts_dict, dict)
    assert facts_dict['distribution'] == 'Unknown'

    # test without gather_subset
    module = FakeModule({})
    facts_dict = ansible_facts(module)

# Generated at 2022-06-16 23:43:50.931367
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector

# Generated at 2022-06-16 23:44:01.291484
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    module = FakeModule({'gather_subset': ['all']})
    facts = get_all_facts(module)
    assert isinstance(facts, dict)
    assert 'ansible_lsb' in facts
    assert 'ansible_distribution' in facts
    assert 'ansible_distribution_version' in facts
    assert 'ansible_distribution_release' in facts
    assert 'ansible_distribution_major_version' in facts

# Generated at 2022-06-16 23:44:13.357348
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    fake_module = FakeModule(['all'])
    facts_dict = get_all_facts(fake_module)
    assert facts_dict['distribution'] == 'unknown'
    assert facts_dict['distribution_release'] == 'unknown'
    assert facts_dict['distribution_version'] == 'unknown'
    assert facts_dict['os_family'] == 'unknown'
    assert facts_dict['python_version'] == 'unknown'

# Generated at 2022-06-16 23:44:25.743403
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector

    class TestFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = frozenset(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    class TestNamespaceFactCollector(NamespaceFactCollector):
        name = 'test'
        _fact_ids = frozenset(['test_fact'])


# Generated at 2022-06-16 23:44:34.272347
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactsCollector
    from ansible.module_utils.facts.collector import DefaultFactCollector
    from ansible.module_utils.facts.collector import AnsibleFactCollector

# Generated at 2022-06-16 23:44:47.700182
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        def __init__(self, params):
            self.params = params

    # Test with no gather_subset
    module = FakeModule({'gather_subset': None, 'gather_timeout': 10, 'filter': '*'})
    facts = ansible_facts(module)
    assert facts['distribution'] == 'unknown'

    # Test with gather_subset
    module = FakeModule({'gather_subset': ['all'], 'gather_timeout': 10, 'filter': '*'})


# Generated at 2022-06-16 23:44:57.952208
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import AnsibleDefaultCollector
    from ansible.module_utils.facts.collector import AnsibleFileGlobCollector
    from ansible.module_utils.facts.collector import AnsibleCommandCollector
    from ansible.module_utils.facts.collector import AnsibleModuleCollector

# Generated at 2022-06-16 23:45:09.661461
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector

# Generated at 2022-06-16 23:45:20.514275
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:45:33.497344
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_classes

    class TestFactCollector(BaseFactCollector):
        '''A test fact collector that returns a fixed set of facts'''

        def __init__(self, *args, **kwargs):
            super(TestFactCollector, self).__init__(*args, **kwargs)
            self.facts = {'test_fact_1': 'test_fact_1_value',
                          'test_fact_2': 'test_fact_2_value'}


# Generated at 2022-06-16 23:45:52.583629
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import DefaultFactCollector
    from ansible.module_utils.facts.collector import AnsibleFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import get_ansible_collector
    from ansible.module_utils.facts.collector import get_collector_classes

# Generated at 2022-06-16 23:46:02.812682
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # Mock out the module
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    # Mock out the ansible_facts function
    def mock_ansible_facts(module, gather_subset=None):
        return {'foo': 'bar'}

    # Mock out the get_ansible_collector function

# Generated at 2022-06-16 23:46:15.124758
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyFactCollector
    from ansible.module_utils.facts.collector import BaseDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentDictFactCollector

# Generated at 2022-06-16 23:46:29.085222
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformFactCollector
    from ansible.module_utils.facts.collector import BaseVirtualizationCollector

# Generated at 2022-06-16 23:46:39.032423
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

# Generated at 2022-06-16 23:46:51.618751
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.ansible_facts as ansible_facts
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.collector as collector
    import ansible.module_utils.facts.default_collectors as default_collectors

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeCollector(collector.BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(FakeCollector, self).__init__(*args, **kwargs)
            self.collected_facts = {'test_fact': 'test_value'}

        def collect(self, module=None, collected_facts=None):
            return self.collected_facts

   

# Generated at 2022-06-16 23:46:59.556858
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceDictCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv4Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceIPv6Collector
    from ansible.module_utils.facts.collector import NetworkInterfaceMACCollector
    from ansible.module_utils.facts.collector import NetworkInterfaceMTUCollector

# Generated at 2022-06-16 23:47:06.541745
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        def __init__(self, params):
            self.params = params

    fake_module = FakeModule({'gather_subset': ['all']})
    assert get_all_facts(fake_module) == ansible_facts(fake_module)

    fake_module = FakeModule({'gather_subset': ['all'], 'gather_timeout': 10})

# Generated at 2022-06-16 23:47:16.864301
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import DefaultCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import HardwareCollector
    from ansible.module_utils.facts.collector import VirtualCollector
    from ansible.module_utils.facts.collector import SystemCollector

# Generated at 2022-06-16 23:47:24.801410
# Unit test for function get_all_facts
def test_get_all_facts():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    # test with a gather_subset of 'all'
    module = FakeModule(gather_subset=['all'])
    facts = get_all_facts(module)
    assert facts['distribution'] == ansible.module_utils.facts.system.distribution
    assert facts['distribution_version'] == ansible.module_utils.facts.system.distribution_version


# Generated at 2022-06-16 23:47:48.202678
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_ansible_collector
    from ansible.module_utils.facts.collector import get_collector

# Generated at 2022-06-16 23:48:00.118057
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:48:09.507697
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        def __init__(self, params):
            self.params = params

    fake_module = FakeModule({'gather_subset': ['all']})
    fake_module.params['gather_timeout'] = 10
    fake_module.params['filter'] = '*'


# Generated at 2022-06-16 23:48:18.820505
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    fake_module = FakeModule(gather_subset=['all'])

    facts = get_all_facts(fake_module)

    assert isinstance(facts, dict)
    assert 'distribution' in facts
    assert 'distribution_release' in facts
    assert 'distribution_version' in facts
    assert 'distribution_major_version' in facts
   

# Generated at 2022-06-16 23:48:30.851417
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformFactCollector
    from ansible.module_utils.facts.collector import BaseVirtualizationCollector
    from ansible.module_utils.facts.collector import BaseWindowsRegistryCollector

# Generated at 2022-06-16 23:48:40.115013
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all'], 'gather_timeout': 10}

    module = MockModule()

    gather_subset = module.params['gather_subset']
    gather_timeout = module.params['gather_timeout']
    filter_spec = '*'


# Generated at 2022-06-16 23:48:52.805235
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.ansible_facts as ansible_facts
    import ansible.module_utils.facts.default_collectors as default_collectors
    import ansible.module_utils.facts.collector.base as base
    import ansible.module_utils.facts.collector.network as network
    import ansible.module_utils.facts.collector.platform as platform
    import ansible.module_utils.facts.collector.pkg_mgr as pkg_mgr
    import ansible.module_utils.facts.collector.service_mgr as service_mgr
    import ansible.module_utils.facts.collector.ssh_pub_keys as ssh_pub_keys
    import ansible.module_utils.facts.collector.user as user
    import ansible.module_utils.facts

# Generated at 2022-06-16 23:49:03.620929
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-16 23:49:15.297919
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    # test with gather_subset=['all']
    module = FakeModule(gather_subset=['all'])
    facts_dict = get_all_facts(module)

    assert facts_dict['distribution'] == 'Ansible'
    assert facts_dict['distribution_version'] == '2.3.0.0'

# Generated at 2022-06-16 23:49:27.147602
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    import os
    import sys
    import tempfile
    import shutil
    import json
    import pytest

    class TestModule:
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-16 23:50:12.005815
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    module = FakeModule(['all'])
    facts = get_all_facts(module)
    assert 'default_ipv4' in facts
    assert 'ansible_default_ipv4' not in facts

    module = FakeModule(['network'])
    facts = get_all_facts(module)
    assert 'default_ipv4' in facts
    assert 'ansible_default_ipv4' not in facts


# Generated at 2022-06-16 23:50:23.227131
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    module = FakeModule({'gather_subset': ['all']})
    facts = get_all_facts(module)
    assert facts['distribution'] == 'unknown'
    assert facts['distribution_version'] == 'unknown'
    assert facts['distribution_release'] == 'unknown'
    assert facts['distribution_major_version'] == 'unknown'

    module = FakeModule({'gather_subset': ['all']})
    facts = get_all_facts(module)