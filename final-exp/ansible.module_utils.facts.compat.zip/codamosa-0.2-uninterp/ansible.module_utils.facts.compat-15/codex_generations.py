

# Generated at 2022-06-16 23:40:37.860412
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import NamespaceCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class

# Generated at 2022-06-16 23:40:48.931949
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # test that ansible_facts returns a dict
    assert isinstance(ansible_facts(module=None), dict)

    # test that ansible_facts returns a dict with a key 'ansible_facts'
    assert 'ansible_facts' in ansible_facts(module=None)

    # test that ansible_facts returns a dict with a key 'ansible_facts'
    # that maps to a dict
    assert isinstance(ansible_facts(module=None)['ansible_facts'], dict)

    # test that ansible_facts returns a dict with a key 'ansible_facts'
    # that maps

# Generated at 2022-06-16 23:41:01.465654
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

# Generated at 2022-06-16 23:41:11.023900
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.utils import ansible_facts
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.utils import ansible_facts
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.utils import ansible_facts
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.utils import ansible_

# Generated at 2022-06-16 23:41:22.224524
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import DictFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.namespace import NamespaceFact
    from ansible.module_utils.facts.namespace import NamespaceKeyError
    from ansible.module_utils.facts.namespace import NamespaceFactKeyError
    from ansible.module_utils.facts.namespace import NamespaceFactKeyNotFound

# Generated at 2022-06-16 23:41:32.956325
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['all'],
              'gather_timeout': 10,
              'filter': '*'}

    module = FakeModule(params)

    # test with no gather_subset arg
    facts_dict = ansible_facts(module)

    # test with gather_subset arg
    facts_dict = ansible_facts(module, gather_subset=['all'])

    # test with gather_

# Generated at 2022-06-16 23:41:45.385895
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector.system import SystemCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.pkg_mgr import PkgMgrCollector
    from ansible.module_utils.facts.collector.file import FileCollector
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.service_mgr import ServiceMgrCollector

# Generated at 2022-06-16 23:41:54.271072
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    fake_module = FakeModule(params={'gather_subset': ['all']})
    facts_dict = ansible_facts(module=fake_module)
    assert isinstance(facts_dict, dict)
    assert 'default_ipv4' in facts_dict
    assert 'ansible_default_ipv4' not in facts_dict


# Generated at 2022-06-16 23:42:01.229806
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector

# Generated at 2022-06-16 23:42:11.758851
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsRegistryCollector
    from ansible.module_utils.facts.collector import BaseWindowsWMI
    from ansible.module_utils.facts.collector import BaseWindowsWMICollector
    from ansible.module_utils.facts.collector import BaseWindowsWMIScriptCollector

# Generated at 2022-06-16 23:42:22.850544
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactsCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import AnsibleCollectorException
    from ansible.module_utils.facts.collector import AnsibleFactCollector
    from ansible.module_utils.facts.collector import AnsibleFactsCollector

# Generated at 2022-06-16 23:42:28.373952
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import DefaultCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import HardwareCollector
    from ansible.module_utils.facts.collector import VirtualCollector
    from ansible.module_utils.facts.collector import SystemCollector

# Generated at 2022-06-16 23:42:40.628151
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeCollector(object):
        def __init__(self, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.minimal_gather_subset = minimal_gather_sub

# Generated at 2022-06-16 23:42:49.879847
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    fake_module = FakeModule()
    facts_dict = get_all_facts(fake_module)

    assert isinstance(facts_dict, dict)
    assert 'default_ipv4' in facts_dict
    assert 'ansible_default_ipv4' not in facts_dict

# Generated at 2022-06-16 23:42:57.437949
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FacterFactCollector
    from ansible.module_utils.facts.collector import NetworkFactCollector
    from ansible.module_utils.facts.collector import PlatformFactCollector
    from ansible.module_utils.facts.collector import Shell

# Generated at 2022-06-16 23:43:07.160600
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_classes

    class TestCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = ['test_fact']

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_fact_value'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = ['test_fact2']


# Generated at 2022-06-16 23:43:19.429789
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.system.base import SystemCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector

    class TestNetworkCollector(NetworkCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_network_fact': 'test_network_fact_value'}

    class TestSystemCollector(SystemCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_system_fact': 'test_system_fact_value'}


# Generated at 2022-06-16 23:43:31.653185
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_attributes
    from ansible.module_utils.facts.utils import get_file_stat

# Generated at 2022-06-16 23:43:42.258108
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseFileContentFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseDictFactCollector

# Generated at 2022-06-16 23:43:50.185524
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFilePersistenceCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePersistenceCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseSELinuxCollector
    from ansible.module_utils.facts.collector import BaseServiceMgrCollector
    from ansible.module_utils.facts.collector import BaseSubsetCollect

# Generated at 2022-06-16 23:44:03.304760
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['all']}
    module = FakeModule(params)

    gather_subset = module.params['gather_subset']
    gather_timeout = module.params.get('gather_timeout', 10)
    filter_spec = module.params.get('filter', '*')


# Generated at 2022-06-16 23:44:13.900877
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import DefaultFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector

    class MockModule(object):
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-16 23:44:26.343200
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyFactCollector
    from ansible.module_utils.facts.collector import BaseNetworkFactCollector
    from ansible.module_utils.facts.collector import BaseNetworkLegacyFactCollector
    from ansible.module_utils.facts.collector import BaseNetworkCommandFactCollector
    from ansible.module_utils.facts.collector import BaseNetworkFileGlobFactCollector

# Generated at 2022-06-16 23:44:34.630528
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.namespace import FactNamespace
    from ansible.module_utils.facts.utils import get_collector_classes
    from ansible.module_utils.facts.utils import get_collector_class
    from ansible.module_utils.facts.utils import get_collector_class_names
    from ansible.module_utils.facts.utils import get_collector_class_name
    from ansible.module_utils.facts.utils import get_collector_class_by_name
    from ansible.module_utils.facts.utils import get_collector_

# Generated at 2022-06-16 23:44:48.045767
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_classes

    class TestFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = frozenset(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestFactCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = frozenset(['test_fact2'])


# Generated at 2022-06-16 23:44:58.243523
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseFileContentFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentGlobFactCollector

# Generated at 2022-06-16 23:45:09.941713
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.user
    import ansible.module_utils.facts.system.lsb
    import ansible.module_utils.facts.network.interfaces
    import ansible.module_utils.facts.network.ipv4
    import ansible.module_utils.facts.network.ipv6
    import ansible.module_utils.facts.network.dns
    import ansible.module_

# Generated at 2022-06-16 23:45:20.661699
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    # Test with gather_subset
    module = FakeModule({'gather_subset': ['all']})
    assert get_all_facts(module) == ansible_facts(module, gather_subset=['all'])

    # Test without gather_subset
    module = FakeModule({})
    assert get_all_facts(module) == ansible_facts

# Generated at 2022-06-16 23:45:33.632777
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

# Generated at 2022-06-16 23:45:46.314176
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class_for_platform

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    class MockFactCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(MockFactCollector, self).__init__(*args, **kwargs)
            self.facts_dict = {'foo': 'bar'}


# Generated at 2022-06-16 23:46:03.823183
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import NamespacePrefixFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import AnsibleCollectorException
    from ansible.module_utils.facts.collector import AnsibleCollectorTimeoutException
    from ansible.module_utils.facts.collector import AnsibleCollectorFilterException

# Generated at 2022-06-16 23:46:16.010730
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

# Generated at 2022-06-16 23:46:29.794874
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

# Generated at 2022-06-16 23:46:37.498481
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:46:50.630881
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsRegistryCollector

# Generated at 2022-06-16 23:46:59.015327
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileLinesFactCollector
    from ansible.module_utils.facts.collector import BaseFileRegexFactCollector
    from ansible.module_utils.facts.collector import BaseFileRegexListFactCollector

# Generated at 2022-06-16 23:47:11.035019
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class MockModule:
        def __init__(self, params):
            self.params = params

    class MockCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(MockCollector, self).__init__(*args, **kwargs)
            self.collect_called = False


# Generated at 2022-06-16 23:47:19.855887
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:47:31.107636
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileSearchFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyFactCollector
    from ansible.module_utils.facts.collector import BaseNetworkFactCollector
    from ansible.module_utils.facts.collector import BasePlatformFactCollector
    from ansible.module_utils.facts.collector import BaseVirtualizationFactCollector

# Generated at 2022-06-16 23:47:42.640768
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    fake_module = FakeModule(['all'])
    facts_dict = get_all_facts(fake_module)

    assert facts_dict == ansible_facts(fake_module, gather_subset=['all'])

    fake_module = FakeModule(['network'])
    facts_dict = get_

# Generated at 2022-06-16 23:48:08.215900
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtual

# Generated at 2022-06-16 23:48:18.011667
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyFactCollector
    from ansible.module_utils.facts.collector import BaseDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentDictFactCollector

# Generated at 2022-06-16 23:48:29.568236
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector

# Generated at 2022-06-16 23:48:39.363403
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector

# Generated at 2022-06-16 23:48:52.364812
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.ansible_facts as ansible_facts
    import ansible.module_utils.facts.collector as collector
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.default_collectors as default_collectors
    import ansible.module_utils.facts.ansible_collector as ansible_collector

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    class MockCollector(collector.BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(MockCollector, self).__init__(*args, **kwargs)


# Generated at 2022-06-16 23:49:03.267397
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:49:14.608865
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentDictFactCollector

# Generated at 2022-06-16 23:49:26.629710
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import DebianDistribution
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import AlpineDistribution

# Generated at 2022-06-16 23:49:33.258982
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class TestFactCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(TestFactCollector, self).__init__(*args, **kwargs)

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}


# Generated at 2022-06-16 23:49:43.546699
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactsCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import AnsibleDefaultCollector
    from ansible.module_utils.facts.collector import AnsibleMinimalFactCollector
    from ansible.module_utils.facts.collector import AnsibleFileGlobFactCollector

# Generated at 2022-06-16 23:50:26.350951
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(FakeCollector, self).__init__(*args, **kwargs)
            self.facts_dict = {'fake_fact': 'fake_value'}

        def collect(self, module=None, collected_facts=None):
            return self.facts_dict

    # Test with no gather_subset

# Generated at 2022-06-16 23:50:34.954490
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_ansible_collector
    from ansible.module_utils.facts.collector import get_collector_for_platform