

# Generated at 2022-06-16 23:40:36.612407
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    # Create a mock module
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    # Create a mock collector
    class MockCollector(object):
        def __init__(self, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.minimal_gather_subset = minimal_gather_subset

       

# Generated at 2022-06-16 23:40:44.035972
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:40:50.940468
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    fake_module = FakeModule(['all'])
    facts_dict = get_all_facts(fake_module)
    assert facts_dict == ansible_facts(fake_module)

    fake_module = FakeModule(['network'])
    facts_dict = get_all_facts(fake_module)


# Generated at 2022-06-16 23:41:03.406200
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import AnsibleDefaultCollector
    from ansible.module_utils.facts.collector import AnsibleMinimalFactCollector
    from ansible.module_utils.facts.collector import AnsibleFileGlobFactCollector
    from ansible.module_utils.facts.collector import AnsibleNetworkFactCollector

# Generated at 2022-06-16 23:41:16.170517
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.ansible_facts as ansible_facts
    import ansible.module_utils.facts.namespace as namespace
    import ansible.module_utils.facts.default_collectors as default_collectors
    import ansible.module_utils.facts.ansible_collector as ansible_collector
    import ansible.module_utils.facts.platform.linux as linux
    import ansible.module_utils.facts.platform.netbsd as netbsd
    import ansible.module_utils.facts.platform.openbsd as openbsd
    import ansible.module_utils.facts.platform.sunos as sunos
    import ansible.module_utils.facts.platform.freebsd as freebsd
    import ansible.module_utils.facts.platform.aix as aix


# Generated at 2022-06-16 23:41:27.715894
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule:
        def __init__(self, params):
            self.params = params

    class FakeCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(FakeCollector, self).__init__(*args, **kwargs)
            self.collect_called = False

        def collect(self, module=None, collected_facts=None):
            self.collect_called = True
            return {'foo': 'bar'}

    fake_module = FakeModule({'gather_subset': ['all']})

# Generated at 2022-06-16 23:41:39.591859
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector

# Generated at 2022-06-16 23:41:48.204671
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # mock module
    class MockModule:
        def __init__(self, params):
            self.params = params

    # mock module params
    params = {
        'gather_subset': ['all']
    }

    # mock module
    module = MockModule(params)

    # get_all_facts
    facts_dict = get_all_facts(module)

    # assert
    assert facts_dict['distribution'] == 'RedHat'


# Generated at 2022-06-16 23:41:59.016855
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    # mock module
    class MockModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    # mock collector
    class MockCollector(object):
        def __init__(self, namespace, filter_spec, gather_subset, gather_timeout, minimal_gather_subset):
            self.namespace = namespace
            self.filter_spec = filter_spec
            self.gather_subset = gather_subset
            self.gather_timeout = gather_timeout
            self.minimal_gather_

# Generated at 2022-06-16 23:42:08.735180
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_ansible_collector
    from ansible.module_utils.facts.collector import get_collector_for
    from ansible.module_utils.facts.collector import get_collector_classes

# Generated at 2022-06-16 23:42:21.346860
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_distribution
    from ansible.module_utils.facts.collector import get_collector_for_platform_by_os_family

# Generated at 2022-06-16 23:42:31.487421
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

    class TestCollector(BaseFactCollector):
        name = 'test'

        def collect(self, module=None, collected_facts=None):
            return {'test': 'test'}

    class TestCollector2(BaseFactCollector):
        name = 'test2'

        def collect(self, module=None, collected_facts=None):
            return {'test2': 'test2'}

    class TestCollector3(BaseFactCollector):
        name = 'test3'


# Generated at 2022-06-16 23:42:43.040597
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(FakeCollector, self).__init__(*args, **kwargs)
            self.facts = {'fake_fact': 'fake_value'}

        def collect(self, module=None):
            return self.facts


# Generated at 2022-06-16 23:42:53.297435
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    fake_module = FakeModule(['all'])
    facts = get_all_facts(fake_module)
    assert facts['distribution'] == 'RedHat'
    assert facts['distribution_version'] == '7.2'
    assert facts['distribution_major_version'] == '7'
    assert facts['distribution_release'] == 'Maipo'


# Generated at 2022-06-16 23:43:04.080239
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_classes

    class TestFactCollector(BaseFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestCollector(Collector):
        def __init__(self, *args, **kwargs):
            super(TestCollector, self).__init__(*args, **kwargs)
            self.fact_classes = get_collector_classes(base_class=TestFactCollector)


# Generated at 2022-06-16 23:43:13.187355
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsRegistryCollector
    from ansible.module_utils.facts.collector import BaseWindowsWMI
    from ansible.module_utils.facts.collector import BaseWindowsWMICollector
    from ansible.module_utils.facts.collector import BaseWindowsWMIScriptCollector

# Generated at 2022-06-16 23:43:22.817538
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_collector_classes

    class TestFactCollector(BaseFactCollector):
        name = 'test'
        _fact_ids = frozenset(['test_fact'])

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': 'test_value'}

    class TestFactCollector2(BaseFactCollector):
        name = 'test2'
        _fact_ids = frozenset(['test_fact2'])


# Generated at 2022-06-16 23:43:35.182205
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector

# Generated at 2022-06-16 23:43:44.712839
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class AnsibleModule(object):
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['all']}
    module = AnsibleModule(params)
    facts = get_all_facts(module)

    assert facts['distribution'] == 'RedHat'
    assert facts['distribution_version'] == '7.4'
    assert facts['distribution_release'] == 'Maipo'
    assert facts['distribution_major_version'] == '7'
    assert facts['os_family'] == 'RedHat'

# Generated at 2022-06-16 23:43:52.097833
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:44:09.694118
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyFactCollector
    from ansible.module_utils.facts.collector import BaseDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentDictFactCollector

# Generated at 2022-06-16 23:44:22.714468
# Unit test for function ansible_facts
def test_ansible_facts():
    import ansible.module_utils.facts.namespace
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.service_mgr
    import ansible.module_utils.facts.pkg_mgr
    import ansible.module_utils.facts.user
    import ansible.module_utils.facts.date_time
    import ansible.module_utils.facts.selinux
    import ansible.module_utils.facts.python
    import ansible.module_utils.facts.cmdline
    import ansible.module_utils.facts.env
    import ans

# Generated at 2022-06-16 23:44:32.123206
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsRegistryCollector
    from ansible.module_utils.facts.collector import BaseWindowsWMI
    from ansible.module_utils.facts.collector import BaseZypperCollector
    from ansible.module_utils.facts.collector import BaseYumCollector

# Generated at 2022-06-16 23:44:46.323804
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    fake_module = FakeModule()
    gather_subset = fake_module.params['gather_subset']
    gather_timeout = fake_module.params.get('gather_timeout', 10)
    filter_spec = fake_module.params.get('filter', '*')


# Generated at 2022-06-16 23:44:56.749955
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import DefaultGatherSubsetCollector
    from ansible.module_utils.facts.collector import MinimalGatherSubsetCollector
    from ansible.module_utils.facts.collector import GatherSubsetCollector
    from ansible.module_utils.facts.collector import AnsibleCollector

    class TestModule(object):
        def __init__(self, params):
            self.params

# Generated at 2022-06-16 23:45:08.607095
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_name_from_class
    from ansible.module_utils.facts.collector import get_collector_name_from_class_name
    from ansible.module_utils.facts.collector import get_collector_name_from_file_name
    from ansible.module_utils.facts.collector import get_collector_name

# Generated at 2022-06-16 23:45:19.688235
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        def __init__(self, params):
            self.params = params

    fake_module = FakeModule({'gather_subset': ['all']})

    assert get_all_facts(fake_module) == ansible_facts(fake_module)
    assert get_all_facts(fake_module) == ansible_facts(fake_module, gather_subset=['all'])


# Generated at 2022-06-16 23:45:32.816829
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFilePersistentCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector

# Generated at 2022-06-16 23:45:39.599744
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class MockModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    module = MockModule(gather_subset=['all'])
    facts = get_all_facts(module)
    assert facts['distribution'] == 'RedHat'
    assert facts['distribution_version'] == '7.2'

    module = MockModule(gather_subset=['network'])
    facts = get_all_facts(module)

# Generated at 2022-06-16 23:45:50.876498
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseFileContentFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector

# Generated at 2022-06-16 23:46:13.081794
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileSearchFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformFactCollector
    from ansible.module_utils.facts.collector import BaseVirtualizationCollector

# Generated at 2022-06-16 23:46:20.259909
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import NamespaceFactsCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import Ansible

# Generated at 2022-06-16 23:46:32.143913
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:46:41.030471
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_attributes
    from ansible.module_utils.facts.utils import get_file_stat

# Generated at 2022-06-16 23:46:53.691861
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

    fake_module = FakeModule()

    gather_subset = fake_module.params['gather_subset']
    gather_timeout = fake_module.params.get('gather_timeout', 10)
    filter_spec = fake_module.params.get('filter', '*')


# Generated at 2022-06-16 23:47:06.256261
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['all'],
              'gather_timeout': 10,
              'filter': '*'}
    module = FakeModule(params)


# Generated at 2022-06-16 23:47:16.664266
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import HardwareCollector
    from ansible.module_utils.facts.collector import VirtualCollector
    from ansible.module_utils.facts.collector import SystemCollector
    from ansible.module_utils.facts.collector import DefaultCollector
    from ansible.module_utils.facts.collector import FileSystemCollector
    from ansible.module_utils.facts.collector import PipCollector
    from ansible.module_utils.facts.collector import PythonCollector
    from ansible.module_utils.facts.collector import RubyCollector

# Generated at 2022-06-16 23:47:27.974015
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFact

# Generated at 2022-06-16 23:47:38.655665
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileSearchFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformFactCollector
    from ansible.module_utils.facts.collector import BaseVirtualizationCollector

# Generated at 2022-06-16 23:47:47.394431
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import DebianDistribution

# Generated at 2022-06-16 23:48:17.471051
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:48:28.936392
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileSearchFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformFactCollector
    from ansible.module_utils.facts.collector import BaseProcessCollector

# Generated at 2022-06-16 23:48:38.814963
# Unit test for function ansible_facts
def test_ansible_facts():
    '''Unit test for function ansible_facts'''

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileGlobFactCollector
    from ansible.module_utils.facts.collector import BaseFileContentFactCollector
    from ansible.module_utils.facts.collector import BaseCommandFactCollector
    from ansible.module_utils.facts.collector import BaseLegacyFactCollector
    from ansible.module_utils.facts.collector import BaseDictFactCollector
    from ansible.module_utils.facts.collector import BaseFileDictFactCollector

    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors

# Generated at 2022-06-16 23:48:52.312837
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector

# Generated at 2022-06-16 23:49:03.265691
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFilePersistenceCollector
    from ansible.module_utils.facts.collector import BaseLegacyCollector
    from ansible.module_utils.facts.collector import BaseNetworkCollector
    from ansible.module_utils.facts.collector import BasePersistenceCollector
    from ansible.module_utils.facts.collector import BasePlatformCollector
    from ansible.module_utils.facts.collector import BaseTimeoutCollector
    from ansible.module_utils.facts.collector import BaseVirtualCollector
    from ansible.module_utils.facts.collector import BaseWindowsCollector

# Generated at 2022-06-16 23:49:14.607932
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.namespace import BaseFactNamespace

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeCollector(BaseFactCollector):
        def __init__(self, *args, **kwargs):
            super(FakeCollector, self).__init__(*args, **kwargs)
            self.collected_facts = {'foo': 'bar'}

        def collect(self, module=None, collected_facts=None):
            return self.collected_facts


# Generated at 2022-06-16 23:49:26.639706
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    params = {'gather_subset': ['all']}
    module = FakeModule(params)
    gather_subset = module.params['gather_subset']
    gather_timeout = module.params.get('gather_timeout', 10)
    filter_spec = module.params.get('filter', '*')


# Generated at 2022-06-16 23:49:37.593105
# Unit test for function get_all_facts
def test_get_all_facts():
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts import ansible_collector

    class FakeModule:
        def __init__(self, gather_subset):
            self.params = {'gather_subset': gather_subset}

    # Test that get_all_facts calls ansible_facts with the same gather_subset
    gather_subset = ['all']
    module = FakeModule(gather_subset)
    ansible_facts_mock = Mock()
    with patch('ansible.module_utils.facts.ansible_facts', ansible_facts_mock):
        get_all_facts

# Generated at 2022-06-16 23:49:47.548777
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_instances

# Generated at 2022-06-16 23:49:55.388830
# Unit test for function ansible_facts
def test_ansible_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.namespace import PrefixFactNamespace
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import NamespaceFactCollector
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import DefaultCollector
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.collector import HardwareCollector
    from ansible.module_utils.facts.collector import VirtualCollector
    from ansible.module_utils.facts.collector import SystemCollector