

# Generated at 2022-06-22 06:50:30.291912
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Add the following line after changing the constructor
    # of class HttpQuietDownloader
    # HttpDownloader.__init__(self, ydl, params)
    dl = HttpQuietDownloader(None, None)
    assert dl


# Generated at 2022-06-22 06:50:31.230398
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # TODO: Rewrite this unit test
    pass

# Generated at 2022-06-22 06:50:36.448030
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io
    buf = io.StringIO()
    out = sys.stdout
    sys.stdout = buf

    fd = FragmentFD()
    fd.to_screen = lambda *args, **kwargs: print(' '.join(args), **kwargs)
    fd.report_skip_fragment(5)

    sys.stdout = out
    assert buf.getvalue().strip() == '[download] Skipping fragment 5...', 'Unexpected output'


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-22 06:50:49.455515
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import tempfile
    filename = tempfile.mkstemp()[1]
    assert '-Frag' not in filename
    assert os.path.isfile(encodeFilename(filename)) is False
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: None
    fd.report_warning = lambda *args, **kargs: None
    ctx = {}
    fd._write_ytdl_file(ctx)
    assert os.path.isfile(encodeFilename('%s.ytdl' % filename))
    os.remove(encodeFilename(filename))
    assert os.path.isfile(encodeFilename('%s.ytdl' % filename))
    fd._read_ytdl_file(ctx)

# Generated at 2022-06-22 06:50:52.358619
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = FileDownloader({})
    dl_quiet = HttpQuietDownloader(dl, {'quiet': True})
    assert dl_quiet.params['quiet']

# Generated at 2022-06-22 06:51:04.014355
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class YDLSimple:
        def to_screen(self, *args, **kargs):
            pass
    dl = HttpDownloader({
        'continuedl': True,
        'quiet': False,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }, YDLSimple())
    assert isinstance(dl, HttpDownloader)
    assert dl.continuedl is True
    assert dl._ydl.params['quiet'] is False
    assert dl._ydl.params['noprogress'] is True
    assert dl._ydl.params['ratelimit'] is None
    assert dl._ydl.params['retries'] == 0
    assert dl._

# Generated at 2022-06-22 06:51:08.016777
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        import YoutubeDL
    except ImportError:
        return
    ydl = YoutubeDL.YoutubeDL()
    hfd = HttpQuietDownloader(ydl, {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'retries': 4,
        'ratelimit': 4321,
        'nopart': False,
    })
    assert hfd.continuedl is True
    assert hfd.quiet is True
    assert hfd.noprogress is True
    assert hfd.retries == 4
    assert hfd.ratelimit == 4321
    assert hfd.nopart is False
    assert not hasattr(hfd, 'test')

# Generated at 2022-06-22 06:51:18.138490
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import io
    import os
    import random
    import string
    import sys

    # Define a helper class to collect the output of FragmentFD
    class CollectOutput(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = io.StringIO()
            return self
        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            sys.stdout = self._stdout

    # Define a simple FragmentFD subclass for testing purposes
    class TestFragmentFD(FragmentFD):
        def __init__(self, ydl):
            super(TestFragmentFD, self).__init__(ydl)
            self.FD_NAME = 'test'

# Generated at 2022-06-22 06:51:30.845282
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from .http import HttpFD

    class YDL(object):
        params = {}

    class FakeInfo(object):
        pass

    extractors = gen_extractors()
    for ie in extractors:
        ie.ydl = YDL()

    def test_url(url):
        ydl = YDL()
        ydl.params['forcejson'] = True
        ydl.params['simulate'] = True
        ydl.params['quiet'] = True
        ydl.params['noprogress'] = True
        ydl.params['logger'] = None
        info = FakeInfo()
        info.extractor_key = 'generic'
        info.url = url
        ydl.process_ie_result(info)


# Generated at 2022-06-22 06:51:41.013725
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_HTTPError
    
    class FakeInfoExtractor(InfoExtractor):
        def _real_initialize(self):
            class FakeFragmentFD(FragmentFD):
                def _start_frag_download(self, ctx):
                    pass
                
                def _finish_frag_download(self, ctx):
                    pass

            return FakeFragmentFD(self.ydl, {'skip_unavailable_fragments': True})

        def _real_extract(self, url):
            assert url == 'http://example.org/frag1'
            class Fragment:
                url = url
                filename = 'frag1'

# Generated at 2022-06-22 06:52:09.489875
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .downloader import Downloader
    from .extractor import gen_extractors
    from .extractor import list_extractors

    class MockFD(FragmentFD):
        def __init__(self, ydl):
            super(MockFD, self).__init__(ydl)

        def to_screen(self, *args, **kargs):
            print('TOSCREEN:', ' '.join(args[0] % args[1:]))

    ydl = Downloader(params={'verbose': True})
    MockFD.add_info_extractor(gen_extractors(ydl, 'mock'))

# Generated at 2022-06-22 06:52:15.422272
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # This test aims to check if HttpQuietDownloader is constructed correctly
    ydl = object()
    params = object()
    dl = HttpQuietDownloader(ydl, params)
    assert dl.ydl == ydl
    assert dl._params == params
    assert dl._progress_hooks == []

# Generated at 2022-06-22 06:52:27.211741
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # pylint: disable=invalid-name
    import sys
    import io
    # pylint: enable=invalid-name

    downloader_params = {'test': True}
    params = {}
    ydl = {'params': params}
    dl = HttpQuietDownloader(ydl, downloader_params)
    out = io.BytesIO()
    dl.to_screen('[download] a message')
    assert out.getvalue() == b''
    dl.to_screen(
        '[download] a message', 'another message', 'third message',
        'fourth message', 'fifth message')
    assert out.getvalue() == b''

    # Should keep quiet when verbose is false
    params['verbose'] = False
    out = io.BytesIO()
    dl = Http

# Generated at 2022-06-22 06:52:37.981916
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    """
    For given error and fragment index, count and retries
    test if the right message is printed to screen.
    """
    import urllib2
    import urllib
    import sys

# Generated at 2022-06-22 06:52:42.399565
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None)
    fd.to_screen = lambda _: _
    assert fd.report_skip_fragment(1) == 'Skipped fragment 1...'
    assert fd.report_skip_fragment(42) == 'Skipped fragment 42...'
    assert fd.report_skip_fragment(0) == 'Skipped fragment 0...'

# Generated at 2022-06-22 06:52:48.807663
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class _FragmentFD(FragmentFD):
        def __init__(self):
            self.screen_data = []

        def to_screen(self, *args, **kargs):
            self.screen_data.append(args)

    ffd = _FragmentFD()
    ffd.report_skip_fragment(23)
    assert ffd.screen_data == [
        ('[download] Skipping fragment 23...',)
    ]

# Generated at 2022-06-22 06:52:53.254374
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_value = None

        def to_screen(self, message, skip_eol=False):
            self.to_screen_value = message

    ffd = TestFragmentFD()
    ffd.report_retry_fragment(Exception('abc'), 23, 2, 10)
    assert ffd.to_screen_value == '[download] Got server HTTP error: abc. Retrying fragment 23 (attempt 2 of 10)...'

# Generated at 2022-06-22 06:53:03.718889
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class SubFragmentFD(FragmentFD):
        def __init__(self):
            FragmentFD.__init__(self)
            self.to_screen_list = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_list.append(message)

    fd = SubFragmentFD()
    fd.report_retry_fragment(OSError('dummy message'), 456, 7, 8)
    assert fd.to_screen_list == [
        '[download] Got server HTTP error: dummy message. Retrying fragment 456 (attempt 7 of 8)...']

# Generated at 2022-06-22 06:53:13.258106
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        @staticmethod
        def _is_test():
            return True

        @staticmethod
        def _prepare_frag_download(ctx):
            pass

        def temp_name(self, filename):
            return '-' if filename == '-' else '/tmp/abc'

        @staticmethod
        def ytdl_filename(filename):
            assert filename != '-'
            return os.path.join(os.path.dirname(filename), 'abc.ytdl')

        def _hook_progress(self, state):
            pass  # pragma: no cover

    tfd = MyFragmentFD({
        'skip_unavailable_fragments': True,
        'fragment_retries': 5,
        'keep_fragments': True,
    })
   

# Generated at 2022-06-22 06:53:24.714148
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import io
    import json

    import youtube_dl.FileDownloader
    import youtube_dl.extractor.common

    class TestExtractor(youtube_dl.extractor.common.InfoExtractor):
        def report_download_webpage(self, *args, **kwargs):
            pass

    class TestFD(youtube_dl.FileDownloader):
        def report_retry_fragment(self, *args):
            pass

        def report_skip_fragment(self, *args):
            pass

        def report_destination(self, *args):
            pass

        def report_progress(self, *args):
            pass

        def to_screen(self, *args, **kwargs):
            pass

        def temp_name(self, *args, **kwargs):
            pass


# Generated at 2022-06-22 06:54:11.564279
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    import sys
    import io

    # We have to pretend we are running in a terminal
    ydl = youtube_dl.YoutubeDL({'logger': sys.stdout, 'forceurl': True})
    ydl.params['noprogress'] = False
    # And also have to pretend we have a real terminal
    ydl.params['progress_with_newline'] = False
    # So that the progress hook can be called
    ydl.progress_hooks.append(ydl.report_progress)

    dl = HttpQuietDownloader(ydl, {'noprogress': True})

    # Create a pretend stream, just to check if we are able to write to it
    stream = io.BytesIO()

# Generated at 2022-06-22 06:54:23.352107
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestLogger(object):
        def __init__(self):
            self.msgs = []
        def info(self, msg):
            self.msgs.append(msg)
        def debug(self, msg):
            self.msgs.append(msg)

    # Test verbosity=0, no messages
    tl = TestLogger()
    hqd = HttpQuietDownloader(None, {'verbose': 0})
    hqd.to_screen = tl.info
    hqd._debug_trace = tl.debug
    hqd.to_screen('foo')
    assert tl.msgs == []

    # Test verbosity=1, only info messages
    tl = TestLogger()

# Generated at 2022-06-22 06:54:28.980408
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .fragment import FragmentFD
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert issubclass(HttpQuietDownloader, FragmentFD)
    assert HttpQuietDownloader(None, {'quiet': True})

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:54:30.653376
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert hasattr(HttpQuietDownloader, 'to_screen')

# Generated at 2022-06-22 06:54:34.746934
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .common import FileDownloader
    from ..extractor import YoutubeIE
    dl = HttpQuietDownloader(YoutubeIE(), dict(continuedl=True))
    assert isinstance(dl, HttpFD)
    assert isinstance(dl, FileDownloader)

# Generated at 2022-06-22 06:54:40.621157
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {'noprogress': True, 'quiet': True})
    fd.to_screen = lambda *a, **k: None
    fd._hooks = {'report_skip_fragment': lambda frag_index: fd.to_screen(frag_index)}
    fd.report_skip_fragment(42)

# Generated at 2022-06-22 06:54:52.654951
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import get_info_extractor
    from ..utils import Location
    from ..compat import compat_urllib_request

    url = sys.argv[1]
    ie = get_info_extractor(url)()
    info = ie.extract(url)
    format = next(f for f in info['formats'] if f.get('format_id', '') == '249')
    filename = encodeFilename('test.webm')
    req = compat_urllib_request.Request(format['url'], headers=format['http_headers'])
    req.add_header('Youtubedl-no-compression', 'True')
    fd = FragmentFD(Location('youtube-dl'), ie, format)

# Generated at 2022-06-22 06:55:03.264440
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractors
    from .utils import FakeYDL

    class FakeInfoDict(object):
        def __init__(self, url, http_headers=None):
            self.url = url
            self.http_headers = http_headers

    class FakeArgs(object):
        passes = 1
        format = None
        playlist_items = None

    class FakeProgressHook(object):
        def __init__(self, fd):
            self._fd = fd

        def __call__(self, d):
            self._fd._hook_progress(d)

    class FakeExtractor(object):
        def __init__(self, fd):
            self._fd = fd

        def _prepare_frag_download(self, context):
            self._fd._prepare_frag

# Generated at 2022-06-22 06:55:12.158999
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_output = ''
        def to_screen(self, out, skip_eol=False):
            self.to_screen_output += out + ('\n' if not skip_eol else '')
    fd = TestFragmentFD()
    try:
        raise Exception('Test Exception')
    except Exception as err:
        pass
    fd.report_retry_fragment(err, 1, 2, 3)
    assert fd.to_screen_output == '[download] Got server HTTP error: Test Exception. Retrying fragment 1 (attempt 2 of 3)...\n'


# Generated at 2022-06-22 06:55:17.463759
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: args
    assert (
        fd.report_retry_fragment(RuntimeError('foo'), 10, 5, 6) ==
        ('[download] Got server HTTP error: foo. Retrying fragment 10 (attempt 5 of 6)...',)
    )

# Generated at 2022-06-22 06:56:34.927118
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_value = None

        def to_screen(self, message, skip_eol=False):
            self.to_screen_value = message

    # NOTE: In the test case we mock error_to_compat_str
    # function since the output of error_to_compat_str
    # is not deterministic.
    def error_to_compat_str_mock(_):
        return 'mocked_error_string'

    # NOTE: In the test case we mock format_retries
    # function since the output of format_retries
    # is not deterministic.
    def format_retries_mock(x):
        return 'mocked_retries_string'

    fragment_fd = TestFragment

# Generated at 2022-06-22 06:56:41.649486
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    assert fd.params == {}
    fd.report_retry_fragment(RuntimeError, 0, 2, 5)
    assert fd.to_screen_calls == [
        '[download] Got server HTTP error: <class \'RuntimeError\'>. '
        'Retrying fragment 0 (attempt 2 of 5)...'
    ]


# Generated at 2022-06-22 06:56:48.703890
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FragmentFDWithStderr(FragmentFD):
        def __init__(self):
            self.stderr = []

        def to_screen(self, message, skip_eol=False):
            self.stderr.append([message, skip_eol])

    fd = FragmentFDWithStderr()
    fd.report_skip_fragment(6)

    assert fd.stderr == [['[download] Skipping fragment 6...', False]]

# Generated at 2022-06-22 06:57:00.471436
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD('youtube', 'youtube-dl', {})
    fd.to_screen = lambda *args, **kargs: None
    # [download] Got server HTTP error: (HTTPError) HTTP Error 403: Forbidden. Retrying fragment 2 (attempt 2 of 10)...
    fd.report_retry_fragment(
        Exception('HTTP Error 403: Forbidden'), 2, 2, 10)
    # [download] Got server HTTP error: Connection was reset. Retrying fragment 2 (attempt 2 of none)...
    fd.report_retry_fragment(
        ConnectionResetError('Connection was reset'), 2, 2, None)
    # [download] Got server HTTP error: (HTTPError) HTTP Error 403: Forbidden. Retrying fragment 0 (attempt 1 of 2)...
    fd.report_retry_fragment

# Generated at 2022-06-22 06:57:08.595780
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import io
    import re

    class FakeYDL():
        def __init__(self):
            self.params = {}
            self.to_screen_strs = []
            self.reported_destination = None

        def warn(self, msg):
            self.to_screen_strs.append(msg)

        def trouble(self, msg, tb=None):
            self.to_screen_strs.append(msg)

        def to_screen(self, msg):
            self.to_screen_strs.append(msg)

        def report_warning(self, msg):
            self.to_screen_strs.append('WARNING: %s' % msg)

        def report_destination(self, filename):
            self.reported_destination = filename

    # Basic constructor test

# Generated at 2022-06-22 06:57:14.766740
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = 'test'

        def report_video_info(self, *args, **kwargs):
            pass

    fd = FragmentFD(TestIE())
    fd.add_info_extractor(TestIE)

# Generated at 2022-06-22 06:57:22.651232
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpQuietDownloader
    from .extractor import YoutubeIE
    from .utils import prepend_extension
    from .compat import compat_str


# Generated at 2022-06-22 06:57:32.740029
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from collections import defaultdict
    # pylint: disable=redefined-outer-name

    # Set up mocked test objects
    class FakeScreenLogger:
        def __init__(self):
            self.msgs = defaultdict(int)
            self.msgs['[download] Skipping fragment 1...'] = 0

        def to_screen(self, msg):
            self.msgs[msg] += 1

    class FakeFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen = FakeScreenLogger().to_screen

    frag_fd = FakeFragmentFD()
    # Exercise the test case
    frag_fd.report_skip_fragment(1)
    # Check the result

# Generated at 2022-06-22 06:57:37.437933
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from ..compat import compat_urllib_request as compat_request
    from ..utils import encode_data_uri
    import io

    # Set up a dummy FileDownloader class
    class DummyFD(FragmentFD):

        def __init__(self, ydl):
            super(DummyFD, self).__init__(ydl)
            self._screen_file = io.BytesIO()

        def to_screen(self, msg, skip_eol=None):
            self._screen_file.write(msg.encode('utf-8'))
            if not skip_eol:
                self._screen_file.write(b'\n')

    ydl = FileDownloader(params={
        'quiet': True,
        'progress_hooks': [],
    })


# Generated at 2022-06-22 06:57:41.430122
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    ffd = FragmentFD('youtube-dl')
    ffd.to_screen = lambda *x, **kx: x
    assert ffd.report_retry_fragment(
        AssertionError('foo'), 1, 3, 5) == (
        '[download] Got server HTTP error: AssertionError: foo. '
        'Retrying fragment 1 (attempt 3 of 5)...',)

# vim: expandtab:sw=4:ts=4