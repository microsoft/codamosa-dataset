

# Generated at 2022-06-22 06:50:31.519188
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import io
    import sys
    saved_stdout = sys.stdout
    try:
        out = io.BytesIO()
        sys.stdout = out
        FragmentFD({}).report_skip_fragment(1)
        out.seek(0)
        assert out.read() == b'[download] Skipping fragment 1...\n'
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-22 06:50:42.716623
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # Create a test object
    class TestFD(FragmentFD):
        FD_NAME = 'Test FD'

    test = TestFD(None)

    # Test all retries are handled properly
    test.report_retry_fragment(None, 1, 1, (5, 10))
    test.report_retry_fragment(None, 3, 1, (5, 10))
    test.report_retry_fragment(None, 4, 2, (5, 10))
    test.report_retry_fragment(None, 5, 3, (5, 10))
    test.report_retry_fragment(None, 5, 4, (5, 10))
    test.report_retry_fragment(None, 5, 5, (5, 10))
    test.report_retry_fr

# Generated at 2022-06-22 06:50:45.875240
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = FileDownloader({})
    dl = HttpQuietDownloader(ydl, {})
    dl.to_screen()

# Generated at 2022-06-22 06:50:57.652976
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..compat import compat_urllib_request
    from ..extractor import gen_extractors

    req = compat_urllib_request.Request('http://127.0.0.1/')

# Generated at 2022-06-22 06:51:05.979438
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dummy_params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }
    from .http import HttpFD
    assert isinstance(HttpQuietDownloader(None, dummy_params), HttpFD)
    assert HttpQuietDownloader(None, dummy_params).params == dummy_params

# Generated at 2022-06-22 06:51:08.822325
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:51:15.867062
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    def fake_screen_print(data):
        fake_screen_print.actual_data.append(data)
    fake_screen_print.actual_data = []

    http_quiet_downloader = HttpQuietDownloader(
        {'to_screen': fake_screen_print},
        {'noprogress': True, 'quiet': True, 'verbose': False}
    )
    http_quiet_downloader.to_screen('foo')
    http_quiet_downloader.to_screen('bar')
    assert ''.join(fake_screen_print.actual_data) == 'foobar'

# Generated at 2022-06-22 06:51:27.892504
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FakeFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_data = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_data.append(message)

    fake = FakeFragmentFD()
    fake.report_retry_fragment(Exception(':('), 42, 12, 300)
    assert fake.to_screen_data == ['[download] Got server HTTP error: Exception(...). Retrying fragment 42 (attempt 12 of 300)...']
    assert fake.format_retries(10) == '10'
    assert fake.format_retries(None) == 'infinite'
    assert fake.format_retries(True) == 'infinite'


# Generated at 2022-06-22 06:51:31.592201
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader({}, {})
    assert dl.params['logger'] is not None
    assert dl.params['progress_hooks'] == []

# Generated at 2022-06-22 06:51:43.090308
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..utils import DateRange
    from .http import HttpFD
    from .rtmp import RtmpFD
    from .hls import HlsFD

    # Testing HttpFD

    frag_fd = FragmentFD(
        HttpFD,
        {
            'format': 'webm',
            'noprogress': True,
        },
        {},
    )

    ctx = {
        'filename': 'video.webm',
        'total_frags': 100,
        'fragment_index': 50,
        'tmpfilename': 'video.part',
    }

    frag_fd._prepare_frag_download(ctx)
    assert ctx['dl']

    frag_fd._start_frag_download(ctx)

# Generated at 2022-06-22 06:52:15.842491
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError

    class FakeFD(FragmentFD):
        def __init__(self, params):
            self.params = params
            self.to_screen_calls = []

        def to_screen(self, message, skip_eol=False):
            # print(message)
            self.to_screen_calls.append(message)

        @staticmethod
        def format_retries(retries):
            # print(retries)
            return '%d' % retries

    class FakeIE(InfoExtractor):
        def __init__(self, params):
            self._downloader = FakeFD(params)

    ie = FakeIE({})
    err = ExtractorError('Test message')


# Generated at 2022-06-22 06:52:17.559939
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FileDownloader, FragmentFD)

# Generated at 2022-06-22 06:52:26.623678
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FakeYDL:
        def to_screen(self, message):
            assert message == '[download] Skipping fragment 0...'

    class DummyFragmentFD(FragmentFD):
        def __init__(self, ydl):
            self.ydl = ydl

    fragfd = DummyFragmentFD(FakeYDL())
    fragfd.report_skip_fragment(0)

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-22 06:52:35.062198
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FragmentFDStub(FragmentFD):
        def format_retries(self, retries):
            return None

    d = FragmentFDStub({}, {'noprogress': True})
    d.to_screen = lambda *a, **kw: a
    def test(expected, frag_index):
        actual = d.report_skip_fragment(frag_index)
        assert expected == actual, (expected, actual)
    test((['[download] Skipping fragment 0...'], {}), 0)
    test((['[download] Skipping fragment 1...'], {}), 1)


# Generated at 2022-06-22 06:52:41.621419
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..compat import compat_urllib_error
    # test FileDownloader constructor for FragmentFD
    fd = FragmentFD(None, {})

    # test report_retry_fragment
    fd.to_screen = lambda *args, **kargs: args[0]
    assert (
        fd.report_retry_fragment(
            compat_urllib_error.URLError('foo'),
            1,
            2,
            3) ==
        'Got server HTTP error: foo. Retrying fragment 1 (attempt 2 of 3)...')

    # test report_skip_fragment
    assert fd.report_skip_fragment(1) == 'Skipping fragment 1...'

# Generated at 2022-06-22 06:52:47.667496
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor.common import InfoExtractor

    # A dummy InfoExtractor
    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        _VALID_URL = r'(?:dummy)'

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            pass

    ie = DummyIE(params={})
    ie.add_info_extractor(DummyIE)
    # Check that the second DummyIE is not added
    ie.add_info_extractor(DummyIE)
    dl = HttpQuietDownloader(ie, {})
    # Test that HttpQuietDownloader has a dummy parameter 'ydl'
    assert hasattr(dl, 'ydl')
    # Test that HttpQuietDownloader has a

# Generated at 2022-06-22 06:53:00.756976
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # This method is going to be tested against two different classes
    # of class FragmentFD, which both inherit on a different class
    # which requires the to_screen method to be different. The first
    # class inherits on FileDownloader, which requires the to_screen
    # method to return None. The second class inherits on HttpQuietDownloader,
    # which requires the to_screen method to return undefined. This
    # is why there is a need for two different test cases.
    #
    # TestCase #1:
    class TestFragmentFD(FragmentFD):
        def to_screen(self, *args, **kargs):
            return None

    test_report_skip_fragment = TestFragmentFD()
    assert test_report_skip_fragment.report_skip_fragment(3) == None



# Generated at 2022-06-22 06:53:07.288950
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FD(FragmentFD):
        def __init__(self):
            self.messages = []
        def to_screen(self, message, skip_eol=False):
            self.messages.append(message)

    fd = FD()
    fd.report_skip_fragment(123)
    assert fd.messages == ['[download] Skipping fragment 123...']


# Generated at 2022-06-22 06:53:17.461670
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io
    import unittest

    class MockYDL:

        def __init__(self):
            pass

        def to_screen(self, *args):
            self.message = args[0]

    class MockFragFD(FragmentFD):

        FD_NAME = 'nop'

        def __init__(self, ydl, params={}):
            super(MockFragFD, self).__init__(ydl, params)
            self.params = params
            self.ydl = ydl

    class TestFragmentFD(unittest.TestCase):
        def setUp(self):
            self.capturedOutput = io.StringIO()
            sys.stdout = self.capturedOutput

        def tearDown(self):
            sys.stdout = sys.__stdout__


# Generated at 2022-06-22 06:53:22.881630
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class YDL(object):
        params = {}

    ydl = YDL()
    hqd = HttpQuietDownloader(ydl, {'continuedl': True})
    assert hqd.params['continuedl']
    assert hqd.params['quiet']


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:53:54.748073
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .fragment import FragmentFD
    assert issubclass(FragmentFD, FileDownloader)
    assert FragmentFD.__name__ == 'FragmentFD'
    FragmentFD(None, None, {'outtmpl': '%(id)s.%(ext)s'})

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:54:06.353496
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import tempfile
    from six import StringIO
    from .utils import FakeYDL

    stream = StringIO()
    ydl = FakeYDL(to_stderr=stream)
    dl = HttpQuietDownloader(ydl)
    dl.report_destination('/tmp/test')
    assert stream.getvalue() == ''
    dl.report_retry('http://localhost/', 'description')
    assert stream.getvalue() == ''
    stream.truncate(0)
    dest_stream = tempfile.TemporaryFile()
    dest_stream.write(b'foo')
    dest_stream.flush()
    dest_stream.seek(0)
    dl.report_progress(50, 100, 0, dest_stream)
    assert stream.getvalue() == ''


# Generated at 2022-06-22 06:54:09.408227
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    downloader = HttpQuietDownloader('youtube-dl', {'channel_title':'abc', 'channel_id':'def'})
    assert downloader.channel_title == 'abc'
    assert downloader.channel_id == 'def'
    assert downloader.params['channel_title'] == 'abc'
    assert downloader.params['channel_id'] == 'def'

# Generated at 2022-06-22 06:54:19.420917
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # Note that this test depends on output of report_retry_fragment,
    # thus if method is changed, this unit test is likely to fail
    class MyFragmentFD(FragmentFD):
        def __init__(self):
            self.called = []
            FragmentFD.__init__(self, None)

        def to_screen(self, message, skip_eol=False):
            self.called.append(message)

    fragment_fd = MyFragmentFD()
    fragment_fd.report_retry_fragment(
        ValueError('error'), frag_index=10, count=6, retries=5)
    assert fragment_fd.called == [
        '[download] Got server HTTP error: error. '
        'Retrying fragment 10 (attempt 6 of 5)...']


# Generated at 2022-06-22 06:54:29.440914
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        def __init__(self, ydl):
            super(TestFD, self).__init__(ydl)

        def real_download(self, filename, info_dict):
            assert info_dict['manifest_type'] == 'test'
            assert os.path.basename(filename) == 'test_filename'
            return True

    def test_hook(d): pass

    res = {}

# Generated at 2022-06-22 06:54:40.217301
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Create an object with expected options (see available options in
    # HttpQuietDownloader docstring)
    dl = HttpQuietDownloader({}, {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': 5,
        'retries': 5,
        'nopart': False,
        'test': True,
    })
    assert dl
    assert dl.params['continuedl']
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert dl.params['ratelimit'] == 5
    assert dl.params['retries'] == 5
    assert not dl.params['nopart']
    assert dl.params['test']



# Generated at 2022-06-22 06:54:50.130640
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """
    Simple unit test for constructor of class HttpQuietDownloader.
    """

    from .downloader import YtdlDownloader
    from .extractor import gen_extractors

    ytdl = YtdlDownloader({'nopart': True, 'quiet': False})
    gen_extractors()
    fd = HttpQuietDownloader(ydl=ytdl, params={'nopart': True, 'quiet': False})
    assert fd.params == {'nopart': True}
    assert fd.ydl == ytdl
    assert not fd.to_screen_allowed()



# Generated at 2022-06-22 06:54:51.366589
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    raise NotImplementedError()

# Generated at 2022-06-22 06:54:57.228992
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .downloader.f4m import F4mFD
    f4mfd = F4mFD(gen_extractors())
    assert isinstance(f4mfd._prepare_frag_download({})['dl'], HttpQuietDownloader)

# Generated at 2022-06-22 06:54:59.447943
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    assert HttpQuietDownloader(None, None).to_screen('to be ignored')


# Generated at 2022-06-22 06:55:36.830360
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import pytest
    from contextlib import contextmanager
    from six import StringIO

    @contextmanager
    def capture():
        old_stdout = FragmentFD._real_stdout
        try:
            FragmentFD._real_stdout = StringIO()
            yield FragmentFD._real_stdout
        finally:
            FragmentFD._real_stdout = old_stdout

    class FDMock(FragmentFD):
        def __init__(self, ydl):
            FragmentFD.__init__(self, ydl)
            self._hooks = {}

        def add_progress_hook(self, hook):
            self._hooks['progress'] = hook

        def to_screen(self, line):
            self._hooks['progress']({'_type': 'result'})
            FragmentFD.to_

# Generated at 2022-06-22 06:55:47.626294
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():

    from .http import HttpFD
    from ..compat import compat_urllib_parse_urlparse
    from ..utils import sanitize_url

    class FakeDownloader(HttpFD):
        def __init__(self, params=None):
            params = params or {}
            HttpFD.__init__(self, None, params)

        def to_screen(self, *args, **kargs):
            pass
        def report_warning(self, *args, **kargs):
            pass
        def report_error(self, *args, **kargs):
            pass
        def download(self, *args, **kargs):
            pass

    url = sanitize_url('http://foo.com/bar')
    d = FakeDownloader()
    d.add_default_extra_info({'url': url})

# Generated at 2022-06-22 06:56:00.170446
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    f = FragmentFD(None, None)
    f.to_screen = lambda *a, **k: a
    assert (f.report_retry_fragment(None, 10, 2, 1) ==
        [('\r[download] Got server HTTP error: None. Retrying fragment 10 (attempt 2 of 1)...',)])
    assert (f.report_retry_fragment(None, 10, 2, 2) ==
        [('\r[download] Got server HTTP error: None. Retrying fragment 10 (attempt 2 of 2)...',)])
    assert (f.report_retry_fragment(None, 10, 2, 3) ==
        [('\r[download] Got server HTTP error: None. Retrying fragment 10 (attempt 2 of 3)...',)])

# Generated at 2022-06-22 06:56:02.119965
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-22 06:56:12.768436
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Note: if you want to check the output of the test, add sys.stdout=sys.stderr
    #       at the beginning of the test
    import sys

    class fake_stderr(object):
        def __init__(self, lst=None):
            if lst is None:
                lst = []
            self.lst = lst

        def write(self, s):
            if s != '\r':
                self.lst.append(s)
    stderr = sys.stderr

# Generated at 2022-06-22 06:56:20.818168
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import youtube_dl
    class MockInfo(object):
        pass
    ydl = youtube_dl.YoutubeDL({})
    info = MockInfo()
    info.filename = 'abc'
    info.total_frags = 3
    info.ad_frags = 1
    frag_fd = FragmentFD(ydl, info)
    assert frag_fd.total_frags == 3
    assert frag_fd.ad_frags == 1



# Generated at 2022-06-22 06:56:28.238261
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: (args, kargs)
    fd.format_retries = lambda x: 'retries'
    assert fd.report_retry_fragment(
        'err', 5, 2, 15) == (([
            '[download] Got server HTTP error: err. Retrying fragment 5 (attempt 2 of retries)...'],
        {}),)


# Generated at 2022-06-22 06:56:36.571374
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import tempfile
    dir = tempfile.mkdtemp()
    fd = FragmentFD({
        'outtmpl': dir + '/%(id)s',
        'noprogress': True,
    })

    # Test if the retry is reported properly to the screen
    fd.to_screen = lambda *args, **kargs: setattr(fd, 'screen_str', args)
    fd.report_retry_fragment('test_err', 2, 3, 10)
    assert fd.screen_str == (
        '[download] Got server HTTP error: test_err. Retrying fragment 2 (attempt 3 of 10)...',)

# Generated at 2022-06-22 06:56:41.286205
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None)
    fd.to_screen = lambda message: message
    assert (
        fd.report_retry_fragment(Exception('stub'), 1, 2, 3) ==
        '[download] Got server HTTP error: stub. Retrying fragment 1 (attempt 2 of 3)...'
    )


# Generated at 2022-06-22 06:56:51.057090
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from io import StringIO
    import sys
    import unittest
    from unittest.mock import MagicMock

    class T(unittest.TestCase):
        def test(self):
            to_screen = sys.stdout.write
            sys.stdout = StringIO()
            FragmentFD._screen_file = sys.stdout
            fd = FragmentFD(MagicMock(), {})
            try:
                fd.report_skip_fragment(42)
                self.assertEqual(sys.stdout.getvalue(), '[download] Skipping fragment 42...\n')
            finally:
                FragmentFD._screen_file = None
                sys.stdout = to_screen

    unittest.main(module=__name__, exit=False, verbosity=2)


# Generated at 2022-06-22 06:57:27.062123
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import StringIO
    fd = HttpQuietDownloader(None, {'noprogress':True})
    fd.to_terminal_size = lambda: (80, 24)
    fd.term_width = lambda *a,**k: 80
    fd.to_stderr = lambda *a,**k: None
    fd.to_stdout = lambda *a,**k: None
    s = lambda x: x.encode('utf-8')
    out = StringIO.StringIO()
    fd.to_screen(s('foo\nbar\nbaz'), file=out)
    assert out.getvalue() == ''
    fd.to_screen(s('foo\rbar\rbaz'), file=out)
    assert out.getvalue() == ''
    fd.to_

# Generated at 2022-06-22 06:57:35.455667
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None)
    fd.to_screen = lambda *args: args

    fd.report_skip_fragment(1)
    assert fd.to_screen.called
    assert fd.to_screen.call_args[0][0] == '[download] Skipping fragment 1...'
    fd.to_screen.reset_mock()

    fd.report_skip_fragment(10)
    assert fd.to_screen.called
    assert fd.to_screen.call_args[0][0] == '[download] Skipping fragment 10...'
    fd.to_screen.reset_mock()

# Generated at 2022-06-22 06:57:42.302625
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    from .extractor.youtube import YoutubeIE
    from ..utils import encode_data_uri

    class MockYoutubeDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen = []

        def to_stdout(self, message):
            self.to_screen.append(message)

    ydl = MockYoutubeDL({
        'outtmpl': '%(id)s.%(ext)s',
        'quiet': True,
        'simulate': True,
    })
    ie = YoutubeIE(ydl)
    hdq = HttpQuietDownloader(ydl, {})

    # 1. Download in quiet mode: no to_screen call
    fragment_data = '\x12\x34\x56\x78'
    url

# Generated at 2022-06-22 06:57:43.477045
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None)
    assert fd.report_skip_fragment(17) == '[download] Skipping fragment 17...'



# Generated at 2022-06-22 06:57:49.277047
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFragFD(FragmentFD):
        def __init__(self):
            FragmentFD.__init__(self, None, None)
            self._screen_file = []

        def to_screen(self, message, skip_eol=False):
            self._screen_file.append(message)

    test_fd = TestFragFD()
    test_fd.set_filename('video.mp4')
    test_fd.report_skip_fragment(0)
    test_fd.report_skip_fragment(3)
    test_fd.report_skip_fragment(8)
    assert test_fd._screen_file == [
        '[download] Skipping fragment 0...',
        '[download] Skipping fragment 3...',
        '[download] Skipping fragment 8...',
    ]

# Generated at 2022-06-22 06:58:00.343833
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        pass

    fd = TestFD()

    assert fd.params.get('fragment_retries') is None
    assert fd.params.get('skip_unavailable_fragments') is False
    assert fd.params.get('keep_fragments') is False

    bfd = TestFD(params={
        'fragment_retries': 100,
        'skip_unavailable_fragments': True,
        'keep_fragments': True,
    })

    assert bfd.params.get('fragment_retries') == 100
    assert bfd.params.get('skip_unavailable_fragments') is True
    assert bfd.params.get('keep_fragments') is True

# Generated at 2022-06-22 06:58:09.050983
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {})
    assert (fd.format_retries(0)) == 'infinite'
    assert (fd.format_retries(1)) == '1'
    assert (fd.format_retries(2)) == '2'
    assert (fd.format_retries(2, True)) == '1'
    assert (fd.report_retry_fragment(Exception('boom'), 0, 0, 1)) == (
        '[download] Got server HTTP error: boom. Retrying fragment 0 (attempt 1 of infinite)...')
    assert (fd.report_retry_fragment(Exception('boom'), 1, 2, 4)) == (
        '[download] Got server HTTP error: boom. Retrying fragment 1 (attempt 3 of 4)...')

# Generated at 2022-06-22 06:58:19.604759
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {}, None)
    fd.to_screen = lambda x: x
    assert (fd.report_retry_fragment('foo', 1, 1, 3) ==
            '[download] Got server HTTP error: foo. Retrying fragment 1 (attempt 1 of 3)...')
    assert (fd.report_retry_fragment('foo', 1, 2, 3) ==
            '[download] Got server HTTP error: foo. Retrying fragment 1 (attempt 2 of 3)...')
    assert (fd.report_retry_fragment('foo', 1, 3, 3) ==
            '[download] Got server HTTP error: foo. Retrying fragment 1 (attempt 3 of 3)...')

# Generated at 2022-06-22 06:58:29.010975
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    from .common import FileDownloader
    from ..compat import compat_print

    class TestFD(FragmentFD):
        def __init__(self, *args, **kargs):
            FragmentFD.__init__(self, *args, **kargs)

        def _prepare_frag_download(self, ctx):
            pass

        def _start_frag_download(self, ctx):
            pass

        def report_destination(self, filename):
            pass

    out = []
    def _print(*args, **kargs):
        out.extend(args)
    compa

# Generated at 2022-06-22 06:58:36.583470
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class FakeYdl(object):
        params = {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': None,
            'retries': 0,
            'nopart': False,
            'test': False,
        }

    ydl = FakeYdl()
    dl = HttpQuietDownloader(ydl, {})
    assert dl
    return dl
