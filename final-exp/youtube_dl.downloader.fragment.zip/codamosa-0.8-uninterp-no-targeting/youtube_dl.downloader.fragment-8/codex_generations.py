

# Generated at 2022-06-22 06:50:31.436326
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        import youtube_dl
    except ImportError:
        raise
    else:
        class MyFragmentFD(FragmentFD):
            def __init__(self, ydl, *args, **kwargs):
                self.__super = super(MyFragmentFD, self)
                self.__super.__init__(ydl, *args, **kwargs)

        MyFragmentFD(youtube_dl.YoutubeDL({}), {})

# Generated at 2022-06-22 06:50:36.580769
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader

    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: None

    fd.report_retry_fragment(Exception('test'), 123, 1, 0)

    fd.params['max_retries'] = 2
    fd.report_retry_fragment(Exception('test'), 123, 1, fd.params['max_retries'])
    fd.report_retry_fragment(Exception('test'), 123, 2, fd.params['max_retries'])

# Generated at 2022-06-22 06:50:41.127972
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class Test:
        def to_screen(self, msg):
            self.result = msg
    t = Test()
    quiet_dl = HttpQuietDownloader(t, {})
    quiet_dl.to_screen('test')
    assert t.result == 'test'

# Generated at 2022-06-22 06:50:53.205947
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io
    import tempfile
    from .common import FileDownloader
    from ..postprocessor import run_postprocessors
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD, FileDownloader):
        def __init__(self, ydl, params={}):
            super(TestFD, self).__init__(ydl, params)

        def real_download(self, filename, info_dict):
            return True

    def _test_skip_fragment(fd, frag_index):
        out = io.BytesIO()
        fd.to_screen = lambda *args: out.write(' '.join(args).encode('utf-8'))
        fd.report_skip_fragment(frag_index)
        return out.getvalue()

    #

# Generated at 2022-06-22 06:51:01.237742
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    error = TypeError()
    fd = FragmentFD(None, None)
    assert 'Got server HTTP error' in fd.report_retry_fragment(
        error, 1, 2, 2)
    assert 'Got server HTTP error' in fd.report_retry_fragment(
        error, 1, 2, 5)
    assert 'Got server HTTP error' in fd.report_retry_fragment(
        error, 1, 10, 5)


# Generated at 2022-06-22 06:51:05.509690
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from ..YoutubeDL import YoutubeDL

    # Simple testcase
    fd = FragmentFD(YoutubeDL(), {}, sys.stdout, sys.stderr, {})


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:51:16.851296
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import get_info_extractor
    from .downloader import gen_extractors
    from .utils import match_filter_func

    gen_extractors()
    ie = get_info_extractor('YoutubeIE')()

    # Downloading a real video

# Generated at 2022-06-22 06:51:26.735811
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import shadow_copy

    def _test_to_screen(info_dict):
        info_dict = shadow_copy(info_dict)

        dl = HttpQuietDownloader({
            'quiet': True,
            'noprogress': True,
            'simulate': True,
            'format': 'best',
            'nooverwrites': True,
            'outtmpl': '-',
            'test': True,
        })

        dl.params['test'] = True

# Generated at 2022-06-22 06:51:27.991490
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:51:40.298713
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {
        'quiet': False,
        'username': 'user',
        'password': 'pass',
        'videopassword': 'vpass',
        'usenetrc': True,
        'noprogress': False,
        'ratelimit': None,
        'retries': 10,
        'continuedl': False,
        'nopart': False,
        'test': False,
    }

    opt = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': '10k',
        'retries': 5,
        'nopart': True,
        'test': True,
    }

    new_ydl = HttpQuietDownloader(ydl, opt).params

    assert new_yd

# Generated at 2022-06-22 06:52:07.799522
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFD(FragmentFD):
        def __init__(self, ydl):
            super(TestFD, self).__init__(ydl)
            self.to_screen_msgs = []

        def to_screen(self, msg, skip_eol=False):
            self.to_screen_msgs.append(msg)

    ydl = {}
    fd = TestFD(ydl)
    ctx = {
        'fragment_index': 0
    }
    fd.report_skip_fragment(ctx['fragment_index'])
    assert fd.to_screen_msgs == ['[download] Skipping fragment 0...']

# Generated at 2022-06-22 06:52:17.531967
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .downloader.external import ExternalFD
    from .compat import compat_urllib_request

    class TestIE(InfoExtractor):
        IE_NAME = 'test'


# Generated at 2022-06-22 06:52:28.827109
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor.common import InfoExtractor
    import sys
    import io
    import mock

    class MockIE(InfoExtractor):
        IE_NAME = 'MockIE'

    ie = MockIE({})
    ie.params = {}
    ie.report_warning = mock.Mock()
    ie.to_screen = mock.Mock()
    ie.to_stdout = mock.Mock()

    ff = FragmentFD(ie, {}, ie.params)
    ff.report_retry_fragment(Exception('Test Exception'), 0, 1, [1, 3, 5])
    ff.to_screen.assert_called_with(
        '[download] Got server HTTP error: Test Exception. Retrying fragment 0 (attempt 1 of 1, 2, 5)...',
        file=io.BytesIO(),
    )

# Generated at 2022-06-22 06:52:37.105543
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    test_err = Exception('Test error')
    frag_index = 4
    retries = (1, 2)
    fd = FragmentFD(None, {'retries': retries})
    fd.to_screen = lambda *args, **kargs: None
    fd.report_retry_fragment(test_err, frag_index, 1, retries)
    fd.report_retry_fragment(test_err, frag_index, 2, retries)
    fd.report_retry_fragment(test_err, frag_index, 3, retries)

# Generated at 2022-06-22 06:52:37.597600
# Unit test for constructor of class FragmentFD

# Generated at 2022-06-22 06:52:39.517764
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    """test_HttpQuietDownloader_to_screen"""
    hqd = HttpQuietDownloader(None, None)
    hqd.to_screen('[download] dl_filename test_filename')

# Generated at 2022-06-22 06:52:46.106523
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)
    fd = FragmentFD({})
    assert repr(fd) == '<FragmentFD(0 total)>'
    fd = FragmentFD({'total_fragments': 1})
    assert repr(fd) == '<FragmentFD(1 total)>'

# Generated at 2022-06-22 06:52:54.959871
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Import here to avoid breaking `youtube-dl --help`
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from .common import FileDownloader
    from .http import HttpFD

    ie = InfoExtractor()
    ie.add_info_extractor(GenericIE())
    FileDownloader(ie)
    HttpFD(ie)
    assert FragmentFD(ie) is not None


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:52:59.865920
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    fd = FragmentFD(None, {}, {'skip_unavailable_fragments': True})
    fd.to_screen = sys.stdout.write
    fd.report_skip_fragment(0)


# Generated at 2022-06-22 06:53:04.232805
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpQuietDownloader
    from ..extractor import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    return HttpQuietDownloader(ydl, {})

# Generated at 2022-06-22 06:53:44.766335
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    class _FakeYoutubeDL(object):
        def __init__(self):
            self.to_screen = []
        def to_screen(self, *args, **kwargs):
            self.to_screen.extend(args)
    fd = FragmentFD(_FakeYoutubeDL())
    fd.to_screen = sys.stdout.write
    fd.report_retry_fragment(Exception('Test exception'), 13, 2, 3)


# Generated at 2022-06-22 06:53:56.073281
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import get_info_extractor
    from .extractor.youtube import YoutubeIE
    from .utils import match_filter_func

    def _test_to_screen(dummy_to_screen):
        hqd = HttpQuietDownloader(None, {
            'format': 'mp4',
            'noprogress': True,
            'outtmpl': '%(id)s',
        })
        hqd.to_screen = dummy_to_screen

        # Test #1
        ie = get_info_extractor('youtube-dl')
        assert ie is YoutubeIE

        hqd._test_ie_result(ie.ie_key(), [
            'https://www.youtube.com/watch?v=BaW_jenozKc'])
        assert dummy_to_screen.method

# Generated at 2022-06-22 06:54:04.898075
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import re
    import tempfile
    ydl = FragmentFD()
    ydl.to_screen = lambda *args, **kargs: sys.stdout.write(args[0]+'\n')
    ydl.report_skip_fragment(1)
    sys.stdout.seek(0)
    out = sys.stdout.read()
    sys.stdout.close()
    sys.stdout = sys.__stdout__
    assert re.match('\[(?:download|fragment)s?\] Skipping fragment 1...', out) is not None

# Generated at 2022-06-22 06:54:16.414929
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor import gen_extractors
    from .downloader.f4m import F4mFD
    from .downloader.dash import DASHFD
    for ie in gen_extractors():
        if ie.IE_NAME == 'youtube':
            continue
        downloader = FragmentFD(None, ie, {}, {})

        downloader.to_screen = lambda *args, **kargs: args[0]
        assert downloader.report_skip_fragment(19) == '[download] Skipping fragment 19...'

        class FakeHttpFD(object):
            def __init__(self):
                pass
            def to_screen(self, *args, **kargs):
                return args[0]

        downloader = FragmentFD(None, ie, {}, {})

# Generated at 2022-06-22 06:54:17.457787
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader({}, {}).ydl is not None

# Generated at 2022-06-22 06:54:23.207747
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_list = []
        def to_screen(self, *args, **kargs):
            self.to_screen_list.append([args, kargs])

    TestFragmentFD().report_skip_fragment(1)
    assert TestFragmentFD().to_screen_list == [[('[download] Skipping fragment 1...',), {}]]

# Generated at 2022-06-22 06:54:30.652571
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    dl = HttpQuietDownloader(
        gen_extractors()['youtube'],
        {
            'usenetrc': False,
            'username': 'user',
            'password': 'none',
            'verbose': True,
            'quiet': True,
            'no_warnings': False,
        })
    assert dl.params['quiet']
# vim:set ts=4 sw=4 sts=4 expandtab:

# Generated at 2022-06-22 06:54:35.488739
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # Test for a fixed frag_index
    fd = FragmentFD()
    frag_index = 11
    fd.to_screen = lambda *x: None
    fd.report_skip_fragment(11)


if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-22 06:54:47.479776
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpQuietDownloader
    from .common import FileDownloader

    class MyFileDownloader(FileDownloader):
        def __init__(self, parameter):
            FileDownloader.__init__(
                self, {
                    'quiet': False,
                    'noprogress': False
                })
            self.my_parameter = parameter

        def to_screen(self, s, skip_eol=False):
            self.output.append((s, skip_eol))

    fd = MyFileDownloader(object())
    hqd = HttpQuietDownloader(fd, None)

    # Check calls to to_screen method from the super class
    a1 = object()
    a2 = object()
    a3 = object()

# Generated at 2022-06-22 06:54:50.025480
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None)
    # Verify that this does not throw an exception
    fd.report_skip_fragment(1)

# Generated at 2022-06-22 06:56:05.263392
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert HttpQuietDownloader is not None
    assert FragmentFD('http://localhost/') is not None

# Generated at 2022-06-22 06:56:14.036372
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import inspect
    import unittest
    import sys

    class MockYDL(object):
        def __init__(self):
            self.params = {}
            self.to_screen_called = False
            self.report_warning_called = False
            self.report_destination_called = False

        def to_screen(self, *args, **kwargs):
            self.to_screen_called = True

        def report_warning(self, *args, **kwargs):
            self.report_warning_called = True

        def report_destination(self, *args, **kwargs):
            self.report_destination_called = True

    class FDUT(unittest.TestCase):
        def setUp(self):
            self.fd = FragmentFD(MockYDL())


# Generated at 2022-06-22 06:56:21.343318
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Creating a simple YoutubeDL object with no parameters
    import sys
    import io
    from collections import OrderedDict
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})

    # Creating a object for recording the 'to_screen' method calls
    class RecordingFD(FileDownloader):
        def __init__(self, ydl, params):
            super(RecordingFD, self).__init__(ydl, params)
            self.method_calls = []
            self.to_screen_buffer = io.StringIO()
            self.to_stderr_buffer = io.StringIO()

        def to_screen(self, message, skip_eol=False, check_quiet=False):
            self.method_calls.append(('to_screen', message))
            self.to_

# Generated at 2022-06-22 06:56:33.284183
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .postprocessor.embedthumbnail import EmbedThumbnailPP


# Generated at 2022-06-22 06:56:37.883661
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    from .fragment import FragmentFD

    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-22 06:56:43.562152
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from collections import namedtuple
    from .http import HttpFD

    opts = namedtuple('FakeOpts', ['verbose'])
    quiet_dler = HttpQuietDownloader(HttpFD(), opts(verbose=False))
    assert not quiet_dler.to_screen(1, 2, 3, 4, 5)

# Generated at 2022-06-22 06:56:49.651805
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    # pylint: disable=unused-variable
    class TestFD(FragmentFD):
        def real_download(self, filename, info_dict):
            pass

    ydl = None # type: ignore
    fd = TestFD(ydl, {'total_frags': 10})
    assert fd.params['fragment_retries'] == 10
    assert fd.params['skip_unavailable_fragments'] is True


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:56:50.313416
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-22 06:57:01.565867
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    import sys
    import io
    from .utils import prepend_extension

    def selftest(testname, params, expected_output, test_methods):
        # Set up
        ie = InfoExtractor()
        ie._downloader = HttpQuietDownloader(ie)
        ie._downloader.params = params

        sys.stdout = io.StringIO()

# Generated at 2022-06-22 06:57:11.746117
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .utils import ExtractorError

    class DummyIE(InfoExtractor):
        IE_NAME = 'DummyIE'
        _VALID_URL = r'.*'

        def _real_extract(self, url):
            return {'url': url}

    ie = gen_extractor(DummyIE)
    dl = lambda ydl, info_dict: HttpQuietDownloader(ydl, info_dict['http_quiet_downloaded_params'])
    ie.add_info_extractor(r'^dummy$', [r'.*'], {'downloader': dl, 'http_quiet_downloaded_params': {'noprogress': 'True', 'quiet': 'True'}})
   