

# Generated at 2022-06-22 06:50:33.204809
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import get_info_extractor
    from .common import InfoExtractor

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        _VALID_URL = r'.*'
        _TEST = {
            'url': 'http://localhost/',
            'info_dict': {
                'id': 'testid',
                'ext': 'mp4',
                'title': 'testtitle',
            },
        }

        def _real_extract(self, url):
            return {'id': 'testid', 'url': url, 'title': 'testtitle'}

    ie = DummyIE(downloader=HttpQuietDownloader(
        get_info_extractor('dummy'), {'quiet': True}))

# Generated at 2022-06-22 06:50:45.697463
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # import in a function so python 2.6 won't complain
    from io import BytesIO
    from six import PY3

    if PY3:
        def u(s):
            return s
    else:
        def u(s):
            return s.decode('unicode-escape')

    class TestFD(HttpQuietDownloader):
        def __init__(self):
            self.out = BytesIO()
            self.to_stderr = self.out.write
            self.to_screen = self.out.write

    fd = TestFD()

    # check if non-ascii message works well
    fd.to_screen(u('\u1234\n'))
    assert fd.out.getvalue() == u('\u1234\n').encode('utf-8')

# Generated at 2022-06-22 06:50:57.154335
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    result = {}
    def to_screen(msg, *args):
        if args:
            msg = msg % args
        result['result'] = msg
    class DummyYDL:
        params = {}
    class DummyFD(FragmentFD):
        def __init__(self, ydl):
            self.ydl = ydl
        def to_screen(self, msg, *args):
            to_screen(msg, *args)

    fd = DummyFD(DummyYDL())
    fd.report_skip_fragment(24)  # noqa: F811
    if result['result'] != '[download] Skipping fragment 24...':
        raise AssertionError('bad report_skip_fragment string: ' + repr(result['result']))

# Generated at 2022-06-22 06:51:09.384957
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    class MockYtdl(object):
        def __init__(self, ydl):
            self.params = {'outtmpl': '%(id)s', 'restrictfilenames': True}
            self.ydl = ydl

    class MockFD(FragmentFD):
        def __init__(self, ydl, params):
            object.__init__(self)
            self.params = params
            self.ydl = MockYtdl(ydl)
            self.to_screen = sys.stdout.write
            self.report_warning = sys.stderr.write
            self.report_destination = sys.stdout.write

    ydl = MockYtdl(object())

# Generated at 2022-06-22 06:51:15.126705
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    """
    This tests the method FragmentFD.report_skip_fragment
    """

    class SimpleFD(FragmentFD):
        def to_screen(self, *args):
            self.screen_text = args

    fd = SimpleFD({})
    fd.report_skip_fragment(5)
    assert fd.screen_text == ('[download] Skipping fragment 5...',)

# Generated at 2022-06-22 06:51:27.233306
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    fd = FragmentFD(None, {
        'skip_fragments': True,
        'fragment_retries': 2,
    })
    assert fd.format_retries(0) == 'infinite'
    assert fd.format_retries(1) == '1'
    assert fd.format_retries(10) == '10'
    assert (fd.report_retry_fragment(None, 0, 1, 0) ==
            '[download] Got server HTTP error: None. Retrying fragment 0 (attempt 1 of infinite)...')
    assert (fd.report_retry_fragment(None, 10, 1, 1) ==
            '[download] Got server HTTP error: None. Retrying fragment 10 (attempt 1 of 1)...')

# Generated at 2022-06-22 06:51:34.860016
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MockFD(FragmentFD):
        def __init__(self):
            self.to_screen_msgs = []

        def to_screen(self, msg):
            self.to_screen_msgs.append(msg)

    fd = MockFD()
    fd.report_skip_fragment(42)
    assert len(fd.to_screen_msgs) == 1
    assert fd.to_screen_msgs[0] == '[download] Skipping fragment 42...'


# Generated at 2022-06-22 06:51:45.881585
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import get_info_extractor
    from .options import OptionParser

    def get_http_quiet_downloader(url, params):
        ydl = OptionParser().parse()[0]
        ie = get_info_extractor(ydl, url)
        ie.set_downloader(HttpQuietDownloader(ydl, params))
        return ie.downloader

    dl = get_http_quiet_downloader('http://localhost:8080/1.ts', {'quiet': True})
    assert dl.params['quiet'] == True
    assert dl.to_screen('foo bar baz', 'qux') == None

    dl = get_http_quiet_downloader('http://localhost:8080/1.ts', {'quiet': False})
    assert dl.params['quiet'] == False

# Generated at 2022-06-22 06:51:50.675298
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():

    class YDL(object):
        def __init__(self):
            self.params = {}

    ydl = YDL()
    hqd = HttpQuietDownloader(ydl, ydl.params)
    hqd.to_screen('message')
    assert ydl.params.get('quiet') is True

# Generated at 2022-06-22 06:51:53.640970
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {'test': True})
    assert fd is not None

# Generated at 2022-06-22 06:52:27.057210
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    from ..utils import parse_filesize
    from .http import HttpFD

    class IE(InfoExtractor):
        def extract_info(self, url, ie_id, download=True):
            data = {
                'id': ie_id,
                'url': url,
                'uploader': 'test',
                'uploader_id': '-1',
                'ext': 'mp4',
            }
            data['title'] = 'test video' if data['id'] == 'test' else 'test-%s' % data['id']

# Generated at 2022-06-22 06:52:34.653183
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class DummyYDL(object):
        params = {
            'nooverwrites': True,
            'continuedl': True,
            'outtmpl': 'test.mp4',
        }

    dl = HttpQuietDownloader(DummyYDL(), {})
    assert dl.ydl is DummyYDL()
    assert dl.params['nooverwrites']
    assert dl.params['continuedl']
    assert dl.params['outtmpl'] == 'test.mp4'

# Generated at 2022-06-22 06:52:42.015239
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import StringIO
    # Create StringIO object
    capturedOutput = StringIO.StringIO()
    # and save the original stdout (sys.stdout)
    sys.stdout = capturedOutput
    try:
        # Initialize object
        fd = FragmentFD(None, None)
        # Call to_screen method
        fd.report_skip_fragment(1)
        # Get value from StringIO object
        output_val = capturedOutput.getvalue().strip()
    finally:
        # Set back the stdout to its original value
        sys.stdout = sys.__stdout__
    # Compare values
    assert output_val == '[download] Skipping fragment 1...'

# Generated at 2022-06-22 06:52:54.331794
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    class opts(object):
        def __init__(self):
            self.verbose = False
            self.quiet = True
            self.simulate = False
            self.format = "best"
            self.forcejson = False
            self.outtmpl = ""
            self.ignoreerrors = False
            self.ratelimit = None
            self.nooverwrites = False
            self.retries = 0
            self.noprogress = True
            self.test = False
            self.nopart = False
            self.updatetime = True
            self.continuedl = True
            self.nooverwrites = False
            self.logger = None

    ydl_opts = opts()
    ydl = YoutubeDL(opts=ydl_opts)
    frag_

# Generated at 2022-06-22 06:53:06.926316
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import YoutubeDL
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func
    from .extractor.generic import GenericIE
    from .compat import compat_urllib_request

    class MockIE(InfoExtractor):
        _WORKING = False
        IE_NAME = 'Mock'
        _VALID_URL = r''

        @staticmethod
        def _real_extract(url):
            return {
                'id': 'mockid',
                'ext': 'mp4',
                'url': 'http://example.com/file.mp4',
                'title': 'mock title',
                'thumbnail': 'http://example.com/thumbnail.jpg',
                'duration': 5,
            }


# Generated at 2022-06-22 06:53:14.648023
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Put the to_screen method in some nested namespace to test if it works
    # properly when the self argument is required for it
    class SomeNamespace(object):
        def __init__(self):
            self.i = 0

        class NestedNamespace(object):
            def to_screen(self_ns, something):
                self_ns.i += 1

        def __call__(self):
            nested = self.NestedNamespace()
            nested.to_screen('increment counter')
            return self.i

    ns = SomeNamespace()
    assert ns() == 1

# Generated at 2022-06-22 06:53:25.766210
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # pylint: disable=no-self-use
    # pylint: disable=no-member
    # pylint: disable=protected-access
    class_ = FragmentFD
    error_message = None
    for method in (
            'warn', 'error', 'to_screen',
            'report_warning', 'report_error'):
        method_mock = getattr(class_, method, None)
        if method_mock:
            setattr(class_, '__%s' % method, method_mock)
        setattr(class_, method, error_message.__ne__)
    actual_message = class_().report_skip_fragment(1)
    assert actual_message is None
    fragment_fd = class_()

# Generated at 2022-06-22 06:53:35.692465
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from io import StringIO
    from .common import FileDownloader
    ydl = FileDownloader(
        {
            'quiet': True,
            'fragment_retries': 2,
        })
    def get_err():
        return ValueError('An error')
    error_to_compat_str_dict = {
        'UnicodeEncodeError': 'character maps to <undefined>',
        'ValueError': 'An error',
        'AttributeError': '',
    }

    # Test 1: unicode
    retries = 2
    frag_index = 0
    out = StringIO()
    ydl.to_screen = out.write
    ydl.report_retry_fragment(get_err(), frag_index, frag_index, retries)

# Generated at 2022-06-22 06:53:42.699079
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import os
    from .common import FileDownloader
    from .http import HttpFD

    tmpfilename = os.path.basename(__file__) + '.tmp'
    fd = FragmentFD(FileDownloader({'outtmpl': tmpfilename}), {'url': __file__, 'noprogress': True})
    assert isinstance(fd.fd, HttpFD)
    assert isinstance(fd, FileDownloader)
    assert not fd.params['noprogress']

# Generated at 2022-06-22 06:53:54.814465
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import shutil
    import tempfile
    from .http import HttpFD
    from ..compat import compat_urllib_parse_unquote_plus

    class MockYDL(object):
        def __init__(self):
            self.params = {
                'continuedl': True,
                'outtmpl': '%(id)s.%(ext)s',
            }
            self.to_screen = self.to_stderr = lambda *a, **k: None
            self.cache = None

    ydl = MockYDL()
    ydl.params.update({
        'fragment_retries': 2,
        'noprogress': True,
    })
    with tempfile.NamedTemporaryFile(delete=False) as f:
        pass

# Generated at 2022-06-22 06:54:18.741528
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD('http://example.com')
    assert fd.params['skip_unavailable_fragments'] is False

# Generated at 2022-06-22 06:54:25.191866
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .downloader.http import HttpFD
    gen_extractors()
    out = HttpQuietDownloader(None, {'format': 'bestvideo+bestaudio/best',
                                     'nooverwrites': True, 'outtmpl': '%(id)s.%(ext)s'})
    assert isinstance(out, HttpFD)

# Generated at 2022-06-22 06:54:34.689813
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import StringIO
    ydl = object()
    out = StringIO.StringIO()
    err = StringIO.StringIO()
    old_stderr = sys.stderr
    old_stdout = sys.stdout
    sys.stderr = err
    sys.stdout = out
    try:
        HttpQuietDownloader(ydl, {'noprogress': True}).to_screen('foo', 'bar')
        assert out.getvalue() == 'foo: bar\n'
        assert err.getvalue() == ''
    finally:
        sys.stderr = old_stderr
        sys.stdout = old_stdout

# Generated at 2022-06-22 06:54:39.772962
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    (fd, inp) = create_fd_and_inp()
    fd.to_screen('[download] Got server HTTP error: foo. Retrying fragment 1 (attempt 2 of 2)...')
    assert inp.__buffer__ == b'[download] Got server HTTP error: foo. Retrying fragment 1 (attempt 2 of 2)...\n'


# Generated at 2022-06-22 06:54:50.777248
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class DummyYoutubeDL(object):
        def __init__(self, params):
            self.params = params
        def to_screen(self, message, skip_eol=False, check_quiet=False):
            self.message = message
            self.skip_eol = skip_eol
            self.check_quiet = check_quiet
    ydl = DummyYoutubeDL({'verbose': False})
    hqd = HttpQuietDownloader(ydl, {'quiet': False, 'verbose': False})
    hqd.to_screen('message')
    assert ydl.message == 'message'
    assert ydl.skip_eol == False
    assert ydl.check_quiet == True

# Generated at 2022-06-22 06:55:01.362013
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import tempfile
    import shutil
    import sys
    import os.path

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 06:55:03.307898
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        _ = FragmentFD(None, [])
    except AssertionError:
        pass

# Generated at 2022-06-22 06:55:12.335149
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from .http import HttpFD

    class HttpQuietFD(HttpFD):
        def to_screen(self, *args, **kargs):
            pass

    fd = HttpQuietFD(FileDownloader({'quiet': True}))
    fd.report_skip_fragment(14)
    fd.to_screen.assert_called_with('[download] Skipping fragment 14...')
    fd.to_screen.reset_mock()
    fd.report_skip_fragment(123)
    fd.to_screen.assert_called_with('[download] Skipping fragment 123...')

# Generated at 2022-06-22 06:55:14.864913
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert isinstance(FragmentFD(None, {}, {'format': 'bestvideo'}), FragmentFD)

# Generated at 2022-06-22 06:55:16.955823
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    return HttpQuietDownloader(None, {'continuedl': True, 'quiet': True}).to_screen('[download] test')

# Generated at 2022-06-22 06:56:13.751858
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import io

    class FakeYDL(object):
        params = {}

        def __init__(self):
            self.to_screen_buffer = io.StringIO()
            self.params['outtmpl'] = '%(id)s'

        def to_screen(self, message, skip_eol=False):
            self.to_screen_buffer.write(message)
            if not skip_eol:
                self.to_screen_buffer.write('\n')

        def to_stderr(self, message):
            sys.stderr.write(message + '\n')

    ydl = FakeYDL()
    try:
        HttpQuietDownloader(ydl, {})
        assert ydl.to_screen_buffer.getvalue() == ''
    except:
        pass

# Generated at 2022-06-22 06:56:19.282697
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {})
    fd.to_screen = lambda *args, **kargs: sys.stdout.write(' '.join(map(str, args)) + '\n')
    fd.report_retry_fragment(KeyboardInterrupt, 2, 3, 4)
    fd.report_retry_fragment(KeyboardInterrupt, 2, 3, 1)
    assert fd.format_retries(4) == '4'
    assert fd.format_retries(1) == '1'

# Generated at 2022-06-22 06:56:22.271354
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .http import HttpFD
    class TestFD(HttpFD, FragmentFD):
        pass
    assert TestFD.__bases__ == (HttpFD, FragmentFD)

# Generated at 2022-06-22 06:56:34.069531
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor.common import YoutubeIE
    from .compat import compat_HTTPError, compat_urllib_error

    class MockFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_calls = []

    fd = MockFragmentFD()

    for i in range(3):
        fd.fragment_retries = i
        fd.report_retry_fragment(compat_HTTPError(None, None, None, None, None), 1, 1, fd.fragment_retries)


# Generated at 2022-06-22 06:56:45.701155
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    import sys

    class TestConstructor(unittest.TestCase):
        def test_success(self):
            FragmentFD(None, {}, None, None, None)
            FragmentFD(None, {'keep_fragments': True}, None, None, None)
        def test_failure(self):
            with self.assertRaises(ValueError):
                FragmentFD(None, {'keep_fragments': 'true'}, None, None, None)
    suite = unittest.TestSuite([
        unittest.TestLoader().loadTestsFromTestCase(TestConstructor),
    ])
    result = unittest.TextTestRunner(stream=sys.stderr, verbosity=2).run(suite)
    return result.wasSuccessful()



# Generated at 2022-06-22 06:56:46.286928
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-22 06:56:58.134636
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD

    try:
        import ssl
    except ImportError:
        ssl = None

    class _FakeYDL:
        def __init__(self):
            self.params = {
                'nocheckcertificate': False,
                'prefer_insecure': False,
            }
            self.to_screen = lambda *args, **kargs: None

        def report_warning(self, message):
            self.warning = message

        def trouble(self, *args, **kargs):
            return self.trouble_fn(*args, **kargs)

    ydl = _FakeYDL()

    # No ssl
    if ssl is None:
        dl = HttpQuietDownloader(ydl, {}).real_download

        # Test no ssl
        ydl

# Generated at 2022-06-22 06:57:05.707977
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import unittest
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_buffer = []
        def to_screen(self, *args, **kargs):
            message = args[0] % args[1:]
            self.to_screen_buffer.append(message)
    class TestError(Exception):
        def __init__(self, code, msg=None):
            self.code = code
            self.msg = msg
        def __str__(self):
            if not self.msg:
                return str(self.code)
            return 'HTTP Error %s: %s' % (self.code, self.msg)
    tfd = TestFragmentFD()

# Generated at 2022-06-22 06:57:17.291588
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class DummyFragmentFD(FragmentFD):
        def to_screen(self, msg, skip_eol=False):
            self._hooked_msg = msg
            self._hooked_eol = not skip_eol

    fd = DummyFragmentFD({})
    # Test capture of HTTP errors with error codes
    fd.report_retry_fragment(
        Exception('HTTP Error 404: Not Found'), frag_index=1, count=3, retries=5)
    assert fd._hooked_msg == (
        '[download] Got server HTTP error: 404 Not Found. '
        'Retrying fragment 1 (attempt 3 of 5)...')
    assert fd._hooked_eol

    # Test capture of HTTP errors with no error code

# Generated at 2022-06-22 06:57:23.341725
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import io
    import sys

    # Test with integer frag_index
    frag_index = 1
    buffer = io.StringIO()
    fd = FragmentFD({}, buffer)
    fd.report_skip_fragment(frag_index)
    assert buffer.getvalue() == '[download] Skipping fragment 1...\n'

    # Test with string frag_index
    frag_index = 'X'
    buffer = io.StringIO()
    fd = FragmentFD({}, buffer)
    fd.report_skip_fragment(frag_index)
    assert buffer.getvalue() == '[download] Skipping fragment X...\n'

# Generated at 2022-06-22 06:59:14.901318
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    stdout = sys.stdout
    sys.stdout = sys.__stdout__

    class MyFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, *args, **kargs):
            self.to_screen_calls.append((args, kargs))

    fragmentfd = MyFragmentFD()
    fragmentfd.report_skip_fragment(2)
    assert fragmentfd.to_screen_calls == [
        (('[download] Skipping fragment 2...',), {})
    ]

    sys.stdout = stdout

# Generated at 2022-06-22 06:59:23.291113
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from sys import stderr as _stderr
    # Create artificial object with output stream
    _fd = FragmentFD(None, {'outtmpl': '-'})
    _fd.to_screen = _to_screen
    _err_message = "oops"
    for frag_index in range(4):
        for attempt_index in range(4):
            _fd.report_retry_fragment(_err_message, frag_index, attempt_index, 4)


# Generated at 2022-06-22 06:59:26.405400
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FD(FragmentFD):
        def __init__(self):
            self.messages = []
        def to_screen(self, *args, **_):
            self.messages.append(args)
    fd = FD()
    fd.report_skip_fragment(4)
    assert fd.messages == [('[download] Skipping fragment 4...',)]

# Generated at 2022-06-22 06:59:28.433249
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    fd.format_retries = lambda n: 'X'
    assert fd.report_retry_fragment('err', 1, 2, 3) is None



# Generated at 2022-06-22 06:59:37.746103
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io
    import unittest
    from .common import FileDownloader

    class FakeLogger(object):
        def debug(self, msg):
            assert False

        def warning(self, msg):
            assert False

        def error(self, msg):
            assert False

    class DummyFragmentFD(FragmentFD):
        FD_NAME = 'dummy'

        def report_progress(self, *args, **kargs):
            raise AssertionError()

        def report_resuming_byte(self, *args, **kargs):
            raise AssertionError()

        def report_retry(self, *args, **kargs):
            raise AssertionError()

        def temp_name(self, *args, **kargs):
            raise AssertionError()


# Generated at 2022-06-22 06:59:44.480066
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def test_options(params):
        fd = FragmentFD(params)
        assert fd.params.get('fragment_retries', 0) == params.get('fragment_retries', 0)
        assert fd.params.get('keep_fragments', False) == params.get('keep_fragments', False)
        assert fd.params.get('skip_unavailable_fragments', False) == params.get('skip_unavailable_fragments', False)
    test_options(dict())
    test_options({'fragment_retries': 10})
    test_options({'keep_fragments': True})
    test_options({'skip_unavailable_fragments': True})

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:59:51.826880
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpFD
    import io
    import sys
    ydl = HttpFD(dict())
    c = io.StringIO()
    ydl.to_screen = c.write

    ydl.to_screen('test')
    assert c.getvalue() == 'test\n'

    ydl.to_screen('test2', 'test3')
    assert c.getvalue() == 'test\ntest2test3\n'

    del sys.stderr
    sys.stderr = c
    ydl.to_screen('test4')
    assert c.getvalue() == 'test4\n'
    c.close()

# Generated at 2022-06-22 06:59:59.246908
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    _, out, _ = get_test_env()
    fd = FragmentFD(MockYDL(), {})
    fd.to_screen = lambda *args, **kargs: out.write(' '.join(args) + '\n')
    expected = '[download] Skipping fragment 1...\n'
    FragmentFD.report_skip_fragment(fd, 1)
    assert expected == out.getvalue()
