

# Generated at 2022-06-22 06:50:29.410413
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io
    fd = FragmentFD(None, {'quiet': False, 'noprogress': True})
    fd.to_screen = lambda *args, **kargs: sys.stdout.write(' '.join(args))
    out = io.StringIO(u'')
    fd.report_skip_fragment(5)
    assert out.getvalue() == '[download] Skipping fragment 5...\n'

# Generated at 2022-06-22 06:50:31.353517
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = FileDownloader({})
    FragmentFD(ydl)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:50:33.874907
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = object()
    params = {'continuedl': True, 'quiet': True, 'noprogress': True}
    assert HttpQuietDownloader(ydl, params).params == params

# Generated at 2022-06-22 06:50:39.567141
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Initialize object
    ydl = None
    params = { 'noprogress': True }
    dl = HttpQuietDownloader(ydl, params)

    # Simulate logging calls
    for i in range(1, 10):
        dl.to_screen(str(i), str(i))

    # Assert that nothing is displayed
    print("test_HttpQuietDownloader_to_screen test passed.")


# Generated at 2022-06-22 06:50:46.576441
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .test_utils import FakeYDL
    ydl = FakeYDL()
    fd = FragmentFD(ydl)
    fd.to_screen = ydl.to_screen
    fd.report_skip_fragment(1)
    assert ydl._screen_file.getvalue() == '[download] Skipping fragment 1...\n'

# Generated at 2022-06-22 06:50:54.438130
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import StringIO
    ydl = object()
    msg = object()
    HttpQuietDownloader(ydl, {}).to_screen(msg)
    old_stderr = sys.stderr
    sys.stderr = StringIO.StringIO()
    HttpQuietDownloader(ydl, {'forcejson': True}).to_screen(msg)
    output = sys.stderr.getvalue().strip()
    assert output == '[debug] %s' % json.dumps(msg)
    sys.stderr = old_stderr

# Generated at 2022-06-22 06:50:57.564323
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():

    ydl = HttpQuietDownloader(None, {'continuedl': True})

    assert ydl.continuedl


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:51:04.014074
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(FileDownloader(), {})
    fd.to_screen = lambda *args: args
    assert (
        fd.report_retry_fragment(RuntimeError('foo'), 10, 4, 12) ==
        ('[download] Got server HTTP error: foo. Retrying fragment 10 (attempt 4 of 12)...',))


# Generated at 2022-06-22 06:51:06.658029
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..utils import urlhandle

    # Instantiate HttpQuietDownloader
    http_quiet_fd = HttpQuietDownloader(None, {})

    # Ensure http_ quiet_fd can be used for downloading
    urlh = urlhandle.UrlHandle()
    res = http_quiet_fd.real_download(urlh, {})
    assert res == True, 'HttpQuietDownloader should not fail on any URL'

# Generated at 2022-06-22 06:51:11.777968
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD('youtube-dl')
    fd.to_screen = lambda x: x
    fd.report_skip_fragment(1)

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-22 06:51:34.980647
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None)
    fd.to_screen = lambda *args, **kargs: args
    assert ('[download] Skipping fragment 10...',) == fd.report_skip_fragment(10)

# Generated at 2022-06-22 06:51:45.988702
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import io
    import logging

    def hook(d):
        if d['status'] == 'finished':
            sys.stdout.write('\n')
        elif d['status'] == 'downloading':
            speed_template = '%(downloaded_bytes)sB %(percent_str)5s%% %(speed)s'
            sys.stdout.write(speed_template % d)
            sys.stdout.write('\r')
            sys.stdout.flush()

    opts = {
        'continuedl': True,
        'quiet': True,
        'noprogress': False,
        'logger': logging.getLogger(u'youtube-dl.test'),
    }


# Generated at 2022-06-22 06:51:51.143984
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(dict(), lambda *a, **k: None)
    fd.to_screen = lambda *a, **k: None
    fd.report_skip_fragment(0)

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-22 06:51:55.238343
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda x: x
    fd.report_skip_fragment(2) == '[download] Skipping fragment 2...'


# Generated at 2022-06-22 06:52:01.960155
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    from .http import HttpFD
    from .fragment import FragmentFD

    dl = HttpQuietDownloader(FileDownloader({}), HttpFD.params)
    assert dl.params['quiet']
    dl = HttpQuietDownloader(FragmentFD({}), HttpFD.params)
    assert dl.params['quiet']

# Generated at 2022-06-22 06:52:15.082884
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..compat import urlopen_err
    from .mock import MockYDL

    ydl = MockYDL()
    fd = FragmentFD(ydl)
    fd.to_screen = lambda _: None
    # Zero-based index
    fd.report_retry_fragment(urlopen_err('HTTP Error 404: Not Found'), 1, 2, 10)
    assert ydl.msgs[0] == (
        '[download] Got server HTTP error: 404 Not Found. '
        'Retrying fragment 1 (attempt 2 of 10)...')
    fd.report_retry_fragment(urlopen_err('HTTP Error 404: Not Found'), 1, 3, 3)

# Generated at 2022-06-22 06:52:15.797461
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    return True

# Generated at 2022-06-22 06:52:25.434279
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    out = os.dup(1)
    devnull = os.dup(2)
    try:
        os.dup2(devnull, 1)
        frag_fd = FragmentFD(None)
        frag_fd.to_screen = None
        frag_fd.report_skip_fragment(2)
    finally:
        os.dup2(out, 1)
        os.close(out)
        os.close(devnull)
test_FragmentFD_report_skip_fragment.test = True
test_FragmentFD_report_skip_fragment.test_msg = "there is no to_screen method but we don't crash"

# Generated at 2022-06-22 06:52:36.825585
# Unit test for constructor of class FragmentFD
def test_FragmentFD():

    print('Testing FragmentFD.__init__...')

    from .common import FileDownloader
    from .http import HttpFD

    assert issubclass(FragmentFD, HttpFD)
    assert issubclass(FragmentFD, FileDownloader)
    assert FragmentFD.FD_NAME == 'fragment'

    ydl = object()
    params = {}
    http_params = {}
    test_input = {
        'ydl': ydl,
        'params': params,
        'http_params': http_params,
    }
    received = FragmentFD(**test_input).__dict__

# Generated at 2022-06-22 06:52:44.576036
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_urllib_request
    urllib_request = compat_urllib_request.Request

    class YDL(object):
        def __init__(self, params):
            self.params = params

    class FD(HttpQuietDownloader):
        def __init__(self, ydl, params):
            super(FD, self).__init__(ydl, params)
            self.final_url = None
            self.content_type = None
            self.downloaded_bytes = 0

        def real_download(self, filename, info_dict):
            url = url_transformer(info_dict['url'])
            if url is None:
                return False
            request = urllib_request(url)
            if self.content_type is not None:
                request.add_header

# Generated at 2022-06-22 06:53:09.791469
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=W0612
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({})
    frag = FragmentFD(ydl, {'continuedl': True, 'quiet': True})
    # pylint: enable=W0612


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:53:12.171695
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fragfd = FragmentFD(None)
    fragfd.report_skip_fragment(1)



# Generated at 2022-06-22 06:53:21.116356
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    fd = FileDownloader({})
    class Mock(FragmentFD):
        def to_screen(self, *args, **kargs):
            self.args = args

    fd = Mock(fd.ydl, fd.params)
    fd.report_retry_fragment(Exception('Foo'), 1, 2, 10)
    assert fd.args[0] == '[download] Got server HTTP error: Foo. Retrying fragment 1 (attempt 2 of 10)...'


# Generated at 2022-06-22 06:53:27.327482
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .extractor import gen_extractor_classes, YoutubeIE
    from .downloader import gen_downloader_classes

    fd_classes = gen_downloader_classes()
    ie_classes = gen_extractor_classes()

    test_ie = ie_classes['youtube']()
    test_fd = fd_classes[test_ie.FD_NAME](YoutubeIE())
    assert test_fd.params.get('noprogress') is True

# Generated at 2022-06-22 06:53:38.236496
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..compat import PY2, unittest

    class MyException(Exception):
        __str__ = None

    class TestFD(FragmentFD):
        def real_download(self, filename, info_dict):
            return False

        def to_screen(self, msg):
            TestFD.screen_msg = msg

    # Python 2
    TestFD.screen_msg = None
    TestFD({
        'outtmpl': '%(id)s-%(playlist_index)s-%(fragment_index)s.%(ext)s',
    }).download(['https://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-22 06:53:43.440221
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=W0212
    # Access to a protected member _ydl of a client class
    assert HttpQuietDownloader(None, None)._ydl == {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }

# Generated at 2022-06-22 06:53:55.499862
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor import get_info_extractor
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_error
    class _FakeDownloader(HttpQuietDownloader):
        def __init__(self, ydl, params, info_dict):
            HttpQuietDownloader.__init__(self, ydl, params)
            self._info_dict = info_dict
        def download(self, filename, info_dict):
            info_dict.update(self._info_dict)
            return False
    class _FakeInfoExtractor(InfoExtractor):
        # XXX: Avoid too much output with real extractor names
        _FEED_NAME = 'Test'
        IE_NAME = 'Test'
        def __init__(self, downloader):
            InfoExtractor.__init

# Generated at 2022-06-22 06:54:06.520278
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import copy
    fd = FragmentFD(dict(params={'keep_fragments': True}))
    assert fd.ytdl_filename(None) == None
    assert fd.ytdl_filename('fname') == 'fname.ytdl'
    assert fd.temp_name(None) == None
    assert fd.temp_name('fname') == 'fname.part'
    assert fd.FD_NAME == 'Fragment'
    fd = FragmentFD(dict(params={}, ytdl_filename=lambda f: '_' + f, temp_name=lambda f: '_' + f))
    assert fd.ytdl_filename(None) == None
    assert fd.ytdl_filename('f') == '_f'
    assert fd.temp_

# Generated at 2022-06-22 06:54:17.369188
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        def __init__(self):
            FileDownloader.__init__(self, {}, {})

    fd = MyFragmentFD()


# Generated at 2022-06-22 06:54:27.614826
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Empty case
    ydl = HttpQuietDownloader(
        {},
        {
            'format': 'bestvideo[height<=?480]+bestaudio/best[height<=?480]',
            'outtmpl': '%(title)s.%(ext)s',
            'ignoreerrors': True,
            'quiet': True,
            'simulate': True,
        }
    )
    ydl.to_screen('')

    # Standard cases

# Generated at 2022-06-22 06:55:17.335311
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io
    import unittest
    import unittest.mock

    class OutStream:
        def __init__(self):
            self.content = io.StringIO()

        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self

        def __exit__(self, *args):
            sys.stdout = self._stdout

        def write(self, message):
            self.content.write(message)

        def getvalue(self):
            return self.content.getvalue()

    class TestFragmentFD(FragmentFD):
        def __init__(self):
            super(TestFragmentFD, self).__init__(None)

        def _prepare_frag_download(self, *args, **kargs):
            pass



# Generated at 2022-06-22 06:55:29.973416
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    import types
    frag_names = [frag.__name__ for frag in FragmentFD.__bases__]
    assert 'FileDownloader' in frag_names
    assert 'HttpFD' in frag_names
    assert hasattr(FragmentFD, 'report_retry_fragment')
    assert hasattr(FragmentFD, 'report_skip_fragment')
    assert hasattr(FragmentFD, '_download_fragment')
    assert hasattr(FragmentFD, '_append_fragment')
    assert hasattr(FragmentFD, '_prepare_frag_download')
    assert hasattr(FragmentFD, '_start_frag_download')
    # Do not test _finish_frag_download() because

# Generated at 2022-06-22 06:55:39.895592
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    h = HttpQuietDownloader(
        None,
        {
            'continuedl': False,
            'quiet': True,
            'noprogress': True,
            'nopart': True,
            'ratelimit': None,
            'retries': 0,
        }
    )
    assert h.params['continuedl'] is False
    assert h.params['quiet'] is True
    assert h.params['noprogress'] is True
    assert h.params['nopart'] is True
    assert h.params['ratelimit'] is None
    assert h.params['retries'] == 0

# Generated at 2022-06-22 06:55:51.153014
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {'noprogress': True})

    # No plural, 1 of 1 fragments
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(RuntimeError, 1, 1, 1) == (
        '[download] Got server HTTP error: RuntimeError. Retrying fragment 1 (attempt 1 of 1)...',)

    # Plural, 2 of 3 fragments
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(RuntimeError, 2, 2, 3) == (
        '[download] Got server HTTP error: RuntimeError. Retrying fragment 2 (attempt 2 of 3)...',)

# Generated at 2022-06-22 06:55:55.166588
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = object()
    params = {'continuedl': True, 'quiet': True, 'noprogress': True}
    dl = HttpQuietDownloader(ydl, params)
    assert dl._ydl is ydl
    assert dl._params == params

# Generated at 2022-06-22 06:56:05.845908
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():

    class MockFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_list = []

        def to_screen(self, *args, **kargs):
            self.to_screen_list.append(args)

    fd = MockFragmentFD()
    fd.report_retry_fragment(
        'Dummy_error', 4, 7, {'maxretries': 21, 'max_frag_retries': 42})
    expected = [('[download] Got server HTTP error: Dummy_error.'
                 ' Retrying fragment 4 (attempt 7 of 42)...',)]
    assert fd.to_screen_list == expected, 'to_screen_list is %s' % fd.to_screen_list


# Generated at 2022-06-22 06:56:11.947861
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({'quiet': True}, {})
    fd.to_screen = lambda *a, **k: a[0] in k.get('noencode', ()) and a[0] or repr(a[0])
    assert fd.report_skip_fragment(42) == '[download] Skipping fragment 42...'
    assert fd.report_skip_fragment(6) == '[download] Skipping fragment 6...'

# Generated at 2022-06-22 06:56:20.068838
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    config = {
        'logger': None,
        'progress_hooks': [],
    }
    fd = FragmentFD(config, {})
    fd.to_screen = lambda *args, **kargs: args[0]
    assert fd.report_retry_fragment(None, 1, 1, (2, 3)) == (
        '[download] Got server HTTP error: None. Retrying fragment 1 (attempt 1 of 2)...')


# Generated at 2022-06-22 06:56:32.026603
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    def t_FragmentFD_report_skip_fragment(destination):
        class MyFragmentFD(FragmentFD):
            def __init__(self, params):
                super(MyFragmentFD, self).__init__(params)
                self._fd = destination

            def to_screen(self, *args, **kargs):
                self._fd.write(' '.join(args) + '\n')

        fd = MyFragmentFD({})
        fd.report_skip_fragment(42)

    class DummyOutput:
        def __init__(self):
            self.val = ''

        def write(self, data):
            self.val += data

    out = DummyOutput()
    t_FragmentFD_report_skip_fragment(out)

# Generated at 2022-06-22 06:56:44.027301
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .file_utils import file_mode_from_env
    from ..utils import std_headers

    fd = FragmentFD('.', {}, {
        'noprogress': True,
        'outtmpl': '%(id)s.f4m',
        'continuedl': True,
        'headers': std_headers,
        'mode': file_mode_from_env(),
    })

    assert fd.downloaded_bytes == 0
    assert fd.total_bytes is None
    assert isinstance(fd.params, dict)
    assert isinstance(fd.info_dict, dict)
    assert isinstance(fd.add_progress_hook, type(lambda : None))
    assert isinstance(fd.to_screen, type(lambda : None))

# Generated at 2022-06-22 06:57:34.817744
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    from .common import FileDownloader

    if '--noprompt' not in sys.argv:
        from .update import get_yt_dl_version
        print('Using %s' % get_yt_dl_version())
        if '--verbose' not in sys.argv:
            print('Re-run with --verbose and --noprompt for a debug log.')
            print('Rerun with just --noprompt to use the latest version.')
            sys.exit(2)

    sys.argv = [sys.argv[0], '--noprompt', '--verbose']
    ydl = FileDownloader()
    fd = FragmentFD(ydl, {})
    fd.to_screen = lambda *args, **kargs: print(args[0])
    fd

# Generated at 2022-06-22 06:57:38.993902
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class HttpQuietDownloader_to_screen(HttpQuietDownloader):
        pass
    ydl = HttpQuietDownloader_to_screen({}, {})
    ydl.to_screen('abc')
    assert ydl.to_screen.called_once



# Generated at 2022-06-22 06:57:48.520361
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from ..utils import unescapeHTML
    from .http import compat_basestring

    class TestFD(HttpQuietDownloader):
        class FakeYDL:
            def __init__(self):
                self.params = {}

            def to_screen(self, *args, **kargs):
                assert len(args) == 1
                assert isinstance(args[0], compat_basestring)
                assert args[0] == unescapeHTML(args[0])

        def __init__(self):
            self.ydl = TestFD.FakeYDL()
            self.params = {}

    TestFD()

# Generated at 2022-06-22 06:58:00.183610
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange

    class TestDateRange(DateRange):
        def __init__(self, ydl):
            super(TestDateRange, self).__init__(ydl)
            self.extract_counter = 0

        def extract(self, info_dict):
            super(TestDateRange, self).extract(info_dict)
            self.extract_counter += 1

    class FakeExtractor(InfoExtractor):
        def __init__(self, ydl):
            super(FakeExtractor, self).__init__(ydl)
            self.date_range = TestDateRange(self.ydl)


# Generated at 2022-06-22 06:58:07.261095
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MyFragmentFD(FragmentFD):
        def __init__(self):
            self._screen_buf = []

        def to_screen(self, s):
            self._screen_buf.append(s)

    fd = MyFragmentFD()
    fd.report_skip_fragment(0)
    # test optional arguments
    fd.report_skip_fragment(100)
    assert fd._screen_buf == [
        '[download] Skipping fragment 0...',
        '[download] Skipping fragment 100...',
    ]


# Generated at 2022-06-22 06:58:17.265655
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .downloader import YoutubeDL
    from .common import FileDownloader

    class TestDownloader(FileDownloader):
        def __init__(self, ydl):
            super(TestDownloader, self).__init__(ydl)

        def real_download(self, filename, info_dict):
            return True

    ydl = YoutubeDL(params={'verbose': True})
    hqd = HttpQuietDownloader(ydl, {'quiet': True})
    td = TestDownloader(ydl)

    hqd.to_screen('hello1')
    td.to_screen('hello2')

    assert hqd.ydl.msgs == []
    assert td.ydl.msgs == ['[download] hello2']

# Generated at 2022-06-22 06:58:25.987079
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    fd = FragmentFD(FileDownloader({}, {}))

    def test_sanitize_open(filename, open_mode):
        return {
            'filename': filename,
            'open_mode': open_mode,
        }, None

    sanitize_open = fd.sanitize_open
    fd.sanitize_open = test_sanitize_open

    fd.report_retry_fragment(Exception('foo'), 1, 3, 2)
    assert fd.sanitize_open.calls[0]['kwargs'] == {'filename': None, 'open_mode': 'w'}

# Generated at 2022-06-22 06:58:27.216560
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'

# Generated at 2022-06-22 06:58:38.391710
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FakeFD(FragmentFD):
        def __init__(self, ydl):
            self.params = {}
            self.to_screen_calls = []
            self.to_screen_strs = []
            FragmentFD.__init__(self, ydl)

        def to_screen(self, msg, **kwargs):
            self.to_screen_calls.append(kwargs)
            self.to_screen_strs.append(msg)

    fd = FakeFD(None)
    err = 'Error Reason'
    frag_index = 5
    retries = 3
    for i in range(0, 2 * retries):
        fd.report_retry_fragment(err, frag_index, i + 1, retries)

# Generated at 2022-06-22 06:58:41.851876
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    hqd = HttpQuietDownloader(object(), {'quiet': True})
    assert issubclass(hqd.__class__, HttpFD)
    assert hqd.params['quiet']

