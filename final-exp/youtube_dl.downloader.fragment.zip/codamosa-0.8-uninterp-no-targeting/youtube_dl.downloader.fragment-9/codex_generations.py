

# Generated at 2022-06-22 06:50:34.920647
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None)
    fd.to_screen = lambda d: d
    assert fd.report_retry_fragment(AttributeError('foo'), 1, 2, (1, 1)) == '\n[download] Got server HTTP error: foo. Retrying fragment 1 (attempt 2 of 1)...'
    assert fd.report_retry_fragment(AttributeError('foo'), 1, 2, (1, 2)) == '\n[download] Got server HTTP error: foo. Retrying fragment 1 (attempt 2 of 2)...'
    assert fd.report_retry_fragment(AttributeError('foo'), 1, 2, (1, 3)) == '\n[download] Got server HTTP error: foo. Retrying fragment 1 (attempt 2 of 1-3)...'
    assert fd.report_ret

# Generated at 2022-06-22 06:50:47.681801
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader

    # pylint: disable=unused-argument
    class MyFragmentFD(FragmentFD):
        FD_NAME = 'myfd'

        def report_warning(self, msg):
            pass

        def temp_name(self, filename):
            return filename + '.part'

        def try_rename(self, old_filename, new_filename):
            pass

        def report_destination(self, filename):
            pass

        def calc_eta(self, start, now, total, completed):
            return None

        def _hook_progress(self, status):
            pass

        def format_retries(self, retries):
            return str(retries)

    MyFD = FileDownloader

# Generated at 2022-06-22 06:50:59.712329
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FragmentFD_4_test(FragmentFD):
        def to_screen(self, msg):
            self.screen_msg.append(msg)
        def format_retries(self, retries):
            return 'retries'
    class Options:
        params = {}
    class YDL:
        def trouble(self, *args, **kargs):
            pass
    ydl = YDL()
    fd = FragmentFD_4_test(ydl, Options())
    fd.screen_msg = []
    fd.report_skip_fragment(10)
    assert fd.screen_msg == ['[download] Skipping fragment 10...']
    fd.screen_msg = []

    # Test that report_skip_fragment() does not throw on fragment_index=None
    fd.report

# Generated at 2022-06-22 06:51:10.152007
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestFD(HttpQuietDownloader):
        def __init__(self):
            self.msgs = []
        def to_screen(self, msg, *args, **kargs):
            self.msgs.append(msg)
    tfd = TestFD()
    # Since HttpQuietDownloader overrides to_screen it does not call
    # FileDownloader.to_screen
    FileDownloader.to_screen(tfd, 'foo', bar='baz')
    assert tfd.msgs == []
    HttpQuietDownloader.to_screen(tfd, 'foo', bar='baz')
    assert tfd.msgs == ['foo']

# Generated at 2022-06-22 06:51:12.562405
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    fd = FragmentFD(FileDownloader())

    try:
        raise OSError(2, 'No such file or directory')
    except OSError as e:
        exc_str = error_to_compat_str(e)
    assert exc_str == '[Errno 2] No such file or directory'
    fd.report_retry_fragment(e, 3, 2, 4)

# Generated at 2022-06-22 06:51:20.163638
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    out = StringIO()
    err = StringIO()
    ydl = YoutubeDL(params={}, auto_init=False)
    ydl.to_screen = lambda s, err=False, title=None: out.write(s + '\n')
    ydl.to_stderr = lambda s: err.write(s + '\n')
    dl = HttpQuietDownloader(ydl, {})
    dl.to_screen(
        'test_msg',
        True)
    assert out.getvalue() == 'test_msg\n'
    assert err.getvalue() == 'ERROR: test_msg\n'

# Generated at 2022-06-22 06:51:33.085455
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .common import FileDownloader
    from .http import HttpFD
    from collections import defaultdict
    import re

    class FakeFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params
            self.to_stderr = defaultdict(list)

        def to_screen(self, s):
            self.to_stderr[s].append(s)

    ydl = FakeFileDownloader({}, {})
    HttpFD(ydl, {}).to_screen('test')
    assert ydl.to_stderr['test'] == ['test']

    ydl = FakeFileDownloader({}, {'quiet': True})
    HttpQuietDownloader(ydl, {}).to_screen('test')
   

# Generated at 2022-06-22 06:51:40.189496
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # HttpQuietDownloader is a subclass of HttpFD
    # It only overrides method to_screen
    assert issubclass(HttpQuietDownloader, HttpFD)
    # Constructor does not throw an exception
    try:
        dl = HttpQuietDownloader(None, {})
        assert isinstance(dl, HttpQuietDownloader)
    except Exception:
        assert False, 'Constructor should not throw an exception'


# Generated at 2022-06-22 06:51:42.970003
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Instantiate a HttpQuietDownloader
    dl = HttpQuietDownloader(None, None)
    # Method to_screen doesn't have any effect
    dl.to_screen('foo', 'bar')

# Generated at 2022-06-22 06:51:45.855585
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {'skip_unavailable_fragments': True})
    fd.report_skip_fragment(5)
    assert fd.to_screen_value() == '[download] Skipping fragment 5...'

# Generated at 2022-06-22 06:52:12.941337
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = object()
    dl = HttpQuietDownloader(ydl, {'noprogress': True})
    dl.to_screen('foo')
    dl.params['noprogress'] = False
    # Non-unicode
    dl.to_screen(b'bar')
# Test for method report_retry_fragment

# Generated at 2022-06-22 06:52:17.829236
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FakeFragmentFD(FragmentFD):
        def to_screen(self, *args):
            pass

    ffd = FakeFragmentFD(None, {})
    ffd.report_skip_fragment(5)

# Generated at 2022-06-22 06:52:29.063659
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpDownloader
    from .utils import match_filter_func

    ie = InfoExtractor()
    ie.set_downloader(HttpQuietDownloader(ie._downloader, {'quiet': True}))

    class FakeDL:
        filters = []

    fdl = FakeDL()
    # test filter type
    filter2 = match_filter_func('youtube')
    fdl.filters.append(filter2)
    # test filter lambda
    filter3 = lambda info_dict: info_dict.get('id') == '123'
    fdl.filters.append(filter3)

    fdl._setup_opener(None)
    fdl._write_info_dict(None)


# Generated at 2022-06-22 06:52:36.583094
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MockFragmentFD(FragmentFD):
        def __init__(self):
            self.messages = []
        def to_screen(self, *args, **kargs):
            self.messages.append(args[0])

    fd = MockFragmentFD()
    frag_index = 0
    fd.report_skip_fragment(frag_index)
    expected_message = '[download] Skipping fragment 0...'.encode('utf-8')
    assert fd.messages[0] == expected_message


# Generated at 2022-06-22 06:52:44.401173
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .utils import UnavailableVideoError

    class FakeInfoExtractor(InfoExtractor):
        _TEST = {
            'url': 'http://example.org/',
            'info_dict': {},
        }

        def _real_extract(self, url):
            raise UnavailableVideoError

    ie = gen_extractor(FakeInfoExtractor)

    fake_to_screen = []

    class FakeFragmentFD(FragmentFD):
        def to_screen(self, message, skip_eol=False):
            fake_to_screen.append(message.strip())

    frag_fd = FakeFragmentFD(ie, {}, False)

    frag_fd.report_skip_fragment(111)

# Generated at 2022-06-22 06:52:52.269253
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self, *args, **kwargs):
            self.out = []
            super(TestFragmentFD, self).__init__(*args, **kwargs)

        def to_screen(self, *args, **kwargs):
            self.out.append(args[0])

    fd = TestFragmentFD({})
    fd.report_skip_fragment(42)
    return fd.out[0] == '[download] Skipping fragment 42...'

# Generated at 2022-06-22 06:53:01.151049
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    ydl = None # pylint: disable=undefined-variable
    fd = FragmentFD(ydl, {})
    fd.to_screen = lambda *args, **kargs: None
    err = 'test error'
    frag_index = 1
    count = 10
    retries = 15
    fd.report_retry_fragment(
        err, frag_index, count, retries)
    assert fd.to_screen.call_count == 1 # pylint: disable=no-member

# Generated at 2022-06-22 06:53:12.354553
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'test', 'title': 'test', 'formats': [{'url':
                'http://test/'}]}

    ie = TestIE()
    url = ie.url_result('test')
    info_dict = url.get_info()
    test_dl = HttpQuietDownloader(ie, {'quiet': True})
    assert isinstance(test_dl.ydl, InfoExtractor)
    test_dl.download('test.ext', info_dict)
    test_dl.report_error('Some error')

if __name__ == '__main__':
    test_HttpQuietDownload

# Generated at 2022-06-22 06:53:18.641890
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd_obj = FragmentFD({})
    fd_obj.to_screen = lambda *args, **kargs: True
    fd_obj.format_retries = lambda retries: '%s' % retries
    fd_obj.report_retry_fragment(None, 1, 2, 3)



# Generated at 2022-06-22 06:53:24.459282
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # stub
    class YDL:
        params = {}
        def to_screen(self, *args, **kargs):
            pass
    ydl = YDL()
    fd = FragmentFD(ydl)
    assert fd.FD_NAME == 'Fragment'
    assert fd.params is fd.ydl.params

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:53:56.830836
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    v = sys.version_info
    if v[0] == 2 and v[1] < 7:
        import unittest2 as unittest  # NOQA
    else:
        import unittest  # NOQA
    class FragmentFDTest(unittest.TestCase):
        def setUp(self):
            self.f = FragmentFD(None, None)
            self.f.to_screen = lambda *x: self.assertEqual(x[0], '[download] Got server HTTP error: client.py line #0 (<urlopen error [Errno 1] _ssl.c:504: error:0D0890A1:asn1 encoding routines:ASN1_verify:unknown message digest algorithm>). Retrying fragment 77 (attempt 7 of 10)...')

# Generated at 2022-06-22 06:54:02.534856
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # mock class and its members

    class MockFragmentFD(FragmentFD):

        def __init__(self):
            self.to_screen_called = False
            self.last_to_screen_arg = None

        def to_screen(self, msg, skip_eol=False):
            self.to_screen_called = True
            self.last_to_screen_arg = msg

    # mock dependencies

    # unit under test
    fragment_fd = MockFragmentFD()

    # test


# Generated at 2022-06-22 06:54:08.259361
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_skip_fragment(0) == (
        '[download] Skipping fragment 0...',)

# Generated at 2022-06-22 06:54:11.248881
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = HttpQuietDownloader()
    ydl.to_screen('foo')



# Generated at 2022-06-22 06:54:17.773311
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import youtube_dl.FileDownloader
    ydl = youtube_dl.FileDownloader(params={})
    ydl.to_screen = lambda *args, **kargs: args
    fd = FragmentFD(ydl, {})
    assert fd.report_skip_fragment(42) == ('[download] Skipping fragment 42...',)

test_FragmentFD_report_skip_fragment.__test__ = False

# Generated at 2022-06-22 06:54:24.593587
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..downloader import YoutubeDL
    assert '_prepare_frag_download' in dir(FragmentFD)
    assert '_start_frag_download' in dir(FragmentFD)
    assert '_finish_frag_download' in dir(FragmentFD)
    assert 'FD_NAME' in dir(FragmentFD)

    ydl = YoutubeDL({})
    fd = FragmentFD(ydl)

# Generated at 2022-06-22 06:54:31.179823
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({})
    for retries in (1, 2, 10):
        for count in (1, 2, retries):
            for frag_index in (0, 1, 2, 10, 100):
                fd.report_retry_fragment(None, frag_index, count, retries)

method_test_funcs = [
    test_FragmentFD_report_retry_fragment,
]

# Generated at 2022-06-22 06:54:37.572054
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    ydl = object()
    x = FragmentFD._bootstrap(ydl)
    x.to_screen = lambda *args, **kargs: ydl.logger.debug('to_screen: %s', args)
    x.report_skip_fragment(10)
    assert ydl.logger.getMessages() == ["to_screen: [(u'[download] Skipping fragment 10...',)]"]
    del ydl.logger.messages[:]

# Generated at 2022-06-22 06:54:47.928150
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io

    from .common import FileDownloader

    class FakeDownloader(FileDownloader):
        def to_screen(self, *args, **kargs):
            sys.stdout.write(' '.join(map(str, args)))
            sys.stdout.write('\n')

    FakeDownloader(None, {}).report_skip_fragment(10)
    sys.stdout.seek(0)
    out = sys.stdout.readline()
    assert out == '[download] Skipping fragment 10...\n'


if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-22 06:54:49.617888
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    assert HttpQuietDownloader({}, {}).to_screen('test') == None

# Generated at 2022-06-22 06:55:17.463071
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {}, None)
    fd.to_screen = lambda *args: None
    fd.report_skip_fragment(frag_index=123)


if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-22 06:55:24.204259
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    fd.to_screen = lambda *args: None

    fd_out = StringIO()
    fd.to_stderr = lambda *args: fd_out.write(args[0] + '\n')

    fd.report_skip_fragment(10)

    assert fd_out.getvalue() == '[download] Skipping fragment 10...\n'

# Generated at 2022-06-22 06:55:31.771940
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {'skip_unavailable_fragments': True}) # Ignore the ydl and params arguments
    fd.to_screen = lambda *x, **y: '' # Mock the to_screen method
    fd.report_skip_fragment(4) # Report that the fourth fragment is being skipped
    # Check that the correct message was outputted
    assert fd.meta['skip_fragment_msg'] == '[download] Skipping fragment 4...'

# Generated at 2022-06-22 06:55:37.284629
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda s: s
    assert (
        fd.report_retry_fragment(
            'fragment not found', 5, 2, 12) ==
        '[download] Got server HTTP error: fragment not found. Retrying fragment 5 (attempt 2 of 12)...'
    )

# Generated at 2022-06-22 06:55:41.947006
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from collections import namedtuple
    opts = namedtuple('Options', ['quiet', 'verbose', 'report_error'])(quiet=True, verbose=False, report_error='stderr')
    HttpQuietDownloader(namedtuple('YoutubeDL', ['params'])(params=opts), {'quiet': False})

# Generated at 2022-06-22 06:55:44.214690
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Tests if nothing happens
    fd = FragmentFD(None, {}, {}, None, None, None)
    assert fd is not None

# Generated at 2022-06-22 06:55:50.628013
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = HttpQuietDownloader.ydl
    ydl.params['verbose'] = True
    ydl.params['dump_intermediate_pages'] = True
    ydl.to_screen('test')
    assert ydl.to_stdout_buffer == []
    assert ydl.to_stderr_buffer == []

# Generated at 2022-06-22 06:55:56.752346
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Create a youtube-dl object, which will be used to create the
    #   HttpQuietDownloader instance
    from ..extractor.common import YoutubeDL
    ydl = YoutubeDL({})

    # Create the HttpQuietDownloader instance
    dl = HttpQuietDownloader(
        ydl,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': 1,
            'retries': 1,
            'nopart': True,
            'test': True,
        }
    )

    # Make sure the HttpQuietDownloader instance has the expected attributes
    assert dl.ydl is ydl
    assert dl.params['quiet']
    assert dl.params['noprogress']


# Unit test

# Generated at 2022-06-22 06:56:00.474776
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from . import YoutubeDL
    ydl = YoutubeDL({})
    hqd = HttpQuietDownloader(ydl, {})
    assert hqd.ydl is ydl



# Generated at 2022-06-22 06:56:11.068841
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    print('Testing FragmentFD.report_skip_fragment')
    class MockFD(FragmentFD):
        def __init__(self, ydl):
            self.messages = []
            super(MockFD, self).__init__(ydl)

        def to_screen(self, *args, **kargs):
            self.messages.append(' '.join(args))

        def get_messages(self):
            return self.messages

    import youtube_dl
    ydl = youtube_dl.YoutubeDL({})
    fd = MockFD(ydl)
    fd.report_skip_fragment(42)
    assert fd.get_messages() == ['[download] Skipping fragment 42...']
    print('Tests succeeded')


# Generated at 2022-06-22 06:56:46.649006
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from sys import stdout
    from io import StringIO
    import time
    test_stdout = StringIO()
    dl = HttpQuietDownloader(None, {})
    dl.to_screen = print
    del dl.to_screen
    dl.params['outtmpl'] = '%(id)s'
    dl.to_stderr = print
    dl.to_screen('abc')
    time.sleep(0.2)
    dl._last_prog_update = time.time()
    dl.to_screen('def')
    assert dl._last_prog_update < time.time()
    dl.to_screen('a\nb\nc')

# Generated at 2022-06-22 06:56:52.334364
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .options import FakeYDL

    ydl = FakeYDL()
    gen_extractors(ydl)
    HttpQuietDownloader(ydl, {})


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:57:02.306440
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.msgs = []
        def to_screen(self, msg):
            self.msgs.append(msg)
    fd = TestFragmentFD()
    fd.report_skip_fragment(0)
    assert fd.msgs == ['[download] Skipping fragment 0...']
    fd.msgs = []
    fd.report_skip_fragment(1)
    assert fd.msgs == ['[download] Skipping fragment 1...']
    fd.msgs = []
    fd.report_skip_fragment(666)
    assert fd.msgs == ['[download] Skipping fragment 666...']

# Generated at 2022-06-22 06:57:03.998405
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    hqd = HttpQuietDownloader(None, {})
    assert hqd.to_screen(u'foo') is None

# Generated at 2022-06-22 06:57:05.717411
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert FragmentFD(None).params.get('noprogress', True)



# Generated at 2022-06-22 06:57:17.290805
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    from ..utils import PreparedRequest
    info_dict = {
        'id': 'abc123',
    }

    # Test simple case
    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = False

    ie = TestIE(downloader=None)
    fd = FragmentFD(ie, info_dict, {}, 'test')
    assert fd.info_dict is info_dict
    assert fd.info_dict['id'] == 'abc123'
    assert isinstance(fd.ydl, FileDownloader)
    assert fd.params == {}

    # Same, but passing explicit downloader instance
    dl_instance = object()

# Generated at 2022-06-22 06:57:17.938486
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-22 06:57:22.156715
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    assert FragmentFD().format_retries(3) == u'3'
    assert FragmentFD().format_retries(10) == u'10'
    assert FragmentFD().format_retries(123) == u'123'
    assert FragmentFD().format_retries(1234) == u'1.2k'
    assert FragmentFD().format_retries(12345) == u'12.3k'



# Generated at 2022-06-22 06:57:25.545917
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpFD
    logger = {}
    FD = HttpQuietDownloader(logger, {})
    FD.to_screen('test')
    assert logger.get('INFO') is None

# Generated at 2022-06-22 06:57:34.240258
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import collections

    def myhook(x):
        states.append(x)

    def test_fail(msg):
        print(msg)
        raise AssertionError(msg)

    states = []
    retries = 1
    ydl = collections.namedtuple('YoutubeDL', ['params', 'to_screen'])
    ydl.params = {'retries': retries}
    ydl.to_screen = lambda x: None
    d = FragmentFD(ydl, {'noprogress': True, 'quiet': True})
    d.add_progress_hook(myhook)
    d._hook_progress = lambda x: None
    d.to_screen = lambda x, *args: None

    # Test URL download
    frag_url = 'http://example.com/video.ts'

# Generated at 2022-06-22 06:58:13.342549
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {}
    opt = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }

    h = HttpQuietDownloader(ydl, opt)
    assert h.opts['continuedl'] and h.opts['quiet'] and h.opts['noprogress']
    assert h.opts['ratelimit'] is None and h.opts['retries'] == 0
    assert not h.opts['nopart'] and not h.opts['test']
    assert h.ydl == ydl
    assert h.params is None

# Generated at 2022-06-22 06:58:19.604207
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from ..utils import PY2

    orig_stderr = sys.stderr
    if PY2:
        sys.stderr = open('/dev/null', 'w')
    else:
        sys.stderr = open('/dev/null', 'w', errors='ignore')
    try:
        hqd = HttpQuietDownloader(None, {})
    finally:
        sys.stderr = orig_stderr

# Generated at 2022-06-22 06:58:21.647004
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-22 06:58:27.697324
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # This test will raise an error if the method does not work properly
    ydl = {
        'params': {},
        'to_screen_nooverwrite': lambda _1, _2: None,
    }
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    dl.to_screen('msg')
    return True

# Generated at 2022-06-22 06:58:33.316270
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    """This tests the constructor of class FragmentFD."""
    fd = FragmentFD(dict(params={}), dict())
    for attr in ('total_frags', 'filename'):
        assert attr in fd.ctx
    assert fd.ctx['total_frags'] == -1
    assert fd.ctx['filename'] is None
    assert 'dl' not in fd.ctx


# Generated at 2022-06-22 06:58:37.514213
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda x: x
    # TODO: more tests
    assert fd.report_skip_fragment(1) == '[download] Skipping fragment 1...'


# Generated at 2022-06-22 06:58:47.773116
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFragmentFD(FragmentFD):
        FD_NAME = 'testfd'
        def __init__(self, ydl, params):
            super(TestFragmentFD, self).__init__(ydl, params)
            self.to_screen = self.report_warning

    td = TestFragmentFD(
        None,
        {
            'noprogress': True,
            'quiet': True,
        },
    )
    td._prepare_and_start_frag_download({
        'filename': 'test.flv',
        'tmpfilename': 'test.flv',
        'total_frags': 2,
    })

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:58:51.981786
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD()
    fd.params = {}
    fd.to_screen = lambda *args: args
    assert fd.format_retries(0) == u'infinite'
    assert fd.format_retries(2) == u'2'
    fd.report_retry_fragment(RuntimeError('test'), 2, 3, 2)
    fd.report_retry_fragment(RuntimeError('test'), 2, 1, -1)
    fd.report_skip_fragment(2)

# Generated at 2022-06-22 06:58:56.350231
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import io
    fd = FragmentFD(None, {}, None)
    fd.to_screen = lambda *args, **kargs: sys.stdout.write(' '.join(args) + '\n')
    old_stdout = sys.stdout
    new_stdout = io.BytesIO()
    sys.stdout = new_stdout
    try:
        fd.report_retry_fragment(KeyError, 'foo', 4, 2)
        assert new_stdout.getvalue() == ('[download] Got server HTTP error: KeyError. '
            'Retrying fragment foo (attempt 4 of 2)...\n')
    finally:
        sys.stdout = old_stdout

# Generated at 2022-06-22 06:58:56.768278
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    pass