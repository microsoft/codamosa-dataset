

# Generated at 2022-06-22 06:50:33.123948
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert hasattr(FragmentFD, 'report_retry_fragment')
    assert hasattr(FragmentFD, 'report_skip_fragment')
    assert hasattr(FragmentFD, '_prepare_and_start_frag_download')
    assert hasattr(FragmentFD, '_download_fragment')
    assert hasattr(FragmentFD, '_append_fragment')
    assert hasattr(FragmentFD, '_prepare_frag_download')
    assert hasattr(FragmentFD, '_start_frag_download')
    assert hasattr(FragmentFD, '_finish_frag_download')

# Generated at 2022-06-22 06:50:38.156723
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """Test the constructor of HttpQuietDownloader"""
    def my_hook(_):
        pass
    ydl = object
    params = {'foo': 'bar', 'some': [1, 2, 3]}
    http_dler = HttpQuietDownloader(ydl, params)
    http_dler.add_progress_hook(my_hook)



# Generated at 2022-06-22 06:50:46.520854
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    fd.to_screen = lambda *args, **kwargs: None

    fd.report_retry_fragment('Test message', 1, 1, 5)
    assert fd.last_reported_retries == '5'

    fd.report_retry_fragment('Test message', 1, 1, 1)
    assert fd.last_reported_retries == '1'

# Generated at 2022-06-22 06:50:58.025970
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor import get_info_extractor

    class FakeYDL:
        params = {}

        def to_screen(self, msg):
            print(msg)

    class FakeFD(FragmentFD):
        def report_destination(self, dest):
            pass

    ie = get_info_extractor('Generic')
    fd = ie.get_info({'_type': 'url', 'url': 'http://foo.bar/baz.ts'}, {}, FakeYDL())
    fd.report_retry_fragment(
        Exception('Fake error'), 10, 2, {'max_retries': 5, 'fragment_retries': 3})
    fd.report_retry_fragment(
        Exception('Fake error'), 10, 2, {'max_retries': 5})
   

# Generated at 2022-06-22 06:51:10.152182
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import tempfile
    fd = HttpQuietDownloader({'logger': sys.stderr}, {'noprogress': True})
    assert fd.ydl is not None
    assert fd.params == {
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'continuedl': True,
        'test': False,
        'quiet': True,
    }
    assert fd._progress_hooks == []
    assert isinstance(fd, HttpQuietDownloader)
    (handle, filename) = tempfile.mkstemp(prefix='ytdl-')
    os.close(handle)
    fd.report_destination(filename)
    os.remove(filename)

# Generated at 2022-06-22 06:51:20.215028
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from StringIO import StringIO


# Generated at 2022-06-22 06:51:26.633668
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class FakeYoutubeDl():
        def __init__(self, params):
            self.params = params
    dl = FragmentFD(FakeYoutubeDl({'test': True, 'quiet': True, 'noprogress': True, 'retries': -1}), {'url': 'http://test.test/test.test'})
    assert dl.url

# Generated at 2022-06-22 06:51:35.285977
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    Ydl = None
    try:
        from youtube_dl.YoutubeDL import YoutubeDL
    except ImportError:
        pass
    else:
        Ydl = YoutubeDL()
    if not Ydl:
        raise Exception('Cannot import youtube_dl')
    dl = HttpQuietDownloader(Ydl, {})
    out, _ = sanitize_open('', 'w')
    dl.to_screen('Hello world', file=out)
    assert out.closed

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-22 06:51:46.138726
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..extractor import get_info_extractor
    from .dash import DASHFD
    from .hls import HLSFD

    ie = get_info_extractor('dash', None)
    dash_fd = DASHFD(ie, None)
    ie = get_info_extractor('hlsnative', None)
    hls_fd = HLSFD(ie, None)

    def _test(fd):
        result = [None]

        def to_screen(message, skip_eol=False):
            result[0] = message

        fd.to_screen = to_screen

        err = IOError(u'Message\u2014')
        fd.report_retry_fragment(err, 1, 1, (5, 5))

# Generated at 2022-06-22 06:51:57.005271
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from . import FakeYDL
    from .extractor.common import InfoExtractor

    retry_frag_report = {
        'count': 0,
        'frag_index': None,
        'retries': None,
        'err_msg': None,
    }
    def _check_retry_fragment_report(add_info=None):
        assert retry_frag_report['count'] != 0
        assert retry_frag_report['frag_index'] is not None
        assert retry_frag_report['retries'] is not None
        assert retry_frag_report['err_msg'] is not None
        retry_frag_report['count'] = 0
        retry_frag_report['frag_index'] = None

# Generated at 2022-06-22 06:52:26.850946
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader

    class MyFragmentFD(FragmentFD):
        def __init__(self, ydl):
            self.screen_output = []
            self.params = {}
            self.ydl = ydl
            self.FD_NAME = 'fragment'

        def to_screen(self, *args, **kargs):
            self.screen_output.append(args[0] % args[1:])

        @staticmethod
        def format_retries(retries):
            return retries

    class MyYDL(object):
        def to_screen(self, *args, **kargs):
            pass

    ydl = MyYDL()
    myfd = MyFragmentFD(ydl)

# Generated at 2022-06-22 06:52:35.667520
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    sys.modules['__main__'].params = {'username': 'test_username', 'password': 'test_password'}
    sys.modules['__main__'].to_screen = lambda *args, **kargs: None
    ydl = sys.modules['__main__']
    FileDownloader('http://test_url', ydl).report_warning('test_warning')
    fd = FragmentFD('http://test_url', ydl)
    fd.report_warning('test_warning')
    sys.modules['__main__'].params = {}
    fd.report_warning('test_warning')

# Generated at 2022-06-22 06:52:37.739704
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class DummyYDL(object):
        params = {}
        def trouble(self, s, tb=None):
            pass
    ydl = DummyYDL()
    dl = HttpQuietDownloader(ydl, {})
    dl.to_screen('test')

# Generated at 2022-06-22 06:52:44.774085
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class StdoutMock(object):
        def __init__(self):
            self.res = ''

        def write(self, data):
            self.res += data

    def run(frag_index, count, retries):
        fd = FragmentFD({}, StdoutMock())
        fd.report_retry_fragment(Exception(), frag_index, count, retries)
        return fd.out

    assert run(0, 1, 5) == '[download] Got server HTTP error: None. Retrying fragment 0 (attempt 1 of 5)...\n'
    assert run(1, 2, 1) == '[download] Got server HTTP error: None. Retrying fragment 1 (attempt 2 of 1)...\n'

# Generated at 2022-06-22 06:52:50.802250
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {'noprogress': True, 'quiet': False})
    result = fd.report_retry_fragment(ValueError('fatal'), 4, 2, (1, 2))
    assert 'Got server HTTP error: ValueError("fatal",)' in result
    assert 'Retrying fragment 4 (attempt 2 of 1-2)...' in result



# Generated at 2022-06-22 06:52:57.189962
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .dashsegments import DASHFragmentsFD
    from .hls import HLSFD
    # DASHFragmentsFD is a subclass of FragmentFD
    assert issubclass(DASHFragmentsFD, FragmentFD)
    # HLSFD is a subclass of FragmentFD
    assert issubclass(HLSFD, FragmentFD)

# Generated at 2022-06-22 06:53:03.774466
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    gen_extractors()
    # This will raise an error if anything is really wrong
    dl = HttpQuietDownloader(None, {'quiet': True, 'noprogress': True})
    assert isinstance(dl, HttpFD)
    dl.to_screen('This should never be printed')

# Generated at 2022-06-22 06:53:15.389544
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .extractor.dash import FDashIE

    HttpQuietDownloader.add_to_screen = staticmethod(FileDownloader.add_to_screen)
    InfoExtractor.add_info_extractor(FDashIE.ie_key(), FDashIE)

    # Test HlsFD
    test_ie = InfoExtractor(params=dict(downloader=HlsFD.FD_NAME))
    test_ie.add_info_extractor(HlsFD.ie_key(), HlsFD)

# Generated at 2022-06-22 06:53:19.841779
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor import gen_extractors
    downloader = FragmentFD({
        'outtmpl': '%(id)s',
        'nooverwrites': True,
    })
    downloader.to_screen = lambda s: s
    downloader.report_skip_fragment(1)

# Generated at 2022-06-22 06:53:31.362071
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {'skip_unavailable_fragments': True})
    fd.params['outtmpl'] = '%(id)s.%(ext)s'
    fd._hooks = []
    fd._progress_hooks = []
    fd.to_screen = lambda *args, **kargs: None
    class DummyFD(object):
        def __init__(self):
            self.total_frags = None
        def report_resume_size(self, total_frags):
            self.total_frags = total_frags
    df = DummyFD()
    fd.add_info_extractor(df)
    fd.add_progress_hook(lambda s: None)
    fd.report_skip_fragment(1)
   

# Generated at 2022-06-22 06:54:12.216979
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Ensure _prepare_frag_download function is called on the construction.
    # This test is based on the assumption that the test filename is not
    # created yet.
    fd = FragmentFD(None, None, {'ffmpegexec': True})
    _, tmpfilename = sanitize_open(fd.temp_name('test'), 'wb')
    tmpfilename = encodeFilename(tmpfilename)
    assert os.path.isfile(tmpfilename)
    os.remove(tmpfilename)

# Generated at 2022-06-22 06:54:24.050132
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    ie = get_info_extractor('YoutubeIE')

    def fake_progress_hook(state):
        pass

    fd = FragmentFD(ie._downloader, {
        'format': 'bestvideo[height<=?720]+bestaudio/best',
        'outtmpl': '%(id)s.f4m',
        'noprogress': True,
        'progress_hooks': [fake_progress_hook],
    })
    assert isinstance(fd, FragmentFD)
    assert isinstance(fd._ydl, FileDownloader)
    assert fd.params['noprogress']
    assert fd._progress_hooks == [fake_progress_hook]


if __name__ == '__main__':
    test_FragmentFD

# Generated at 2022-06-22 06:54:28.320352
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    def test_ydl(params):
        return params
    x = HttpQuietDownloader(test_ydl, {}).ydl
    assert x == {'continuedl': True, 'quiet': True, 'noprogress': True}


# Generated at 2022-06-22 06:54:32.706204
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)
    assert FragmentFD.__name__ == 'FragmentFD'

    fd = FragmentFD()
    assert not hasattr(fd, 'ydl')


# Generated at 2022-06-22 06:54:33.471073
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader({}, {})

# Generated at 2022-06-22 06:54:36.976679
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpQuietDownloader
    from .common import FileDownloader

    hqd = HttpQuietDownloader(FileDownloader())
    hqd.to_screen('%s %s %s', 1, 2, 3)

# Generated at 2022-06-22 06:54:39.705838
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..downloader.http import HttpFD

    dl = HttpQuietDownloader(None, {'noprogress': True})
    assert isinstance(dl, HttpFD)

# Generated at 2022-06-22 06:54:52.002512
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractor
    from .utils import ExtractorError

    class MockYDL():
        def __init__(self):
            self.to_screen_str = ''

        def to_screen(self, s):
            self.to_screen_str = s

    class MockExtractor(gen_extractor()):
        IE_NAME = 'mock'
        IE_DESC = 'mock test'
        _TEST = {
            'url': 'http://mock_url',
            'info_dict': {'id': 'mock_id',
                          'ext': 'mock_ext',
                          'title': 'mock_title'}
        }

        def report_warning(self, msg):
            raise ExtractorError('Mock extractor error: ' + msg)


# Generated at 2022-06-22 06:55:02.425380
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class FakeInfoExtractor(object):
        def __init__(self, downloader, ie_name):
            self._downloader = downloader
            self._type = ie_name
            self._WORKING = True
            self._title = 'video title'

        def _real_initialize(self):
            pass

        @staticmethod
        def suitable(url):
            return True

        @staticmethod
        def _html_search_regex(pat, string, name, fatal=True, flags=0, group=None):
            return FakeInfoExtractor._html_search_meta(name, fatal)

        @staticmethod
        def _html_search_meta(name, fatal=True):
            if name == 'title':
                return 'video title'

# Generated at 2022-06-22 06:55:13.130068
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import re
    from .utils import FakeYDL
    from .postprocessor import FFmpegFixupPP
    from .extractor import YoutubeDLExtractor
    from .__main__ import YoutubeDL
    from .fragment import FragmentFD
    from .http import HttpFD

    ydl = YoutubeDL({'fragment_retries': 5})
    fd = HttpFD(ydl, {})
    ydl.logger.name_to_fd['sync_console'] = fd
    ffd = FragmentFD(ydl, {})
    FFmpegFixupPP._get_fixed_path = lambda self, path: path
    YoutubeDLExtractor.is_logged = lambda self: False

    # Test for a youtubedl error
    class BadException(Exception):
        pass
    frag_err = Bad

# Generated at 2022-06-22 06:56:33.496202
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Setup
    class FakeFD:
        def __init__(self):
            self.toscreen = []

        def to_screen(self, *args, **kargs):
            self.toscreen.append((args, kargs))

    ffd = FakeFD()
    hfd = HttpQuietDownloader(ffd, {})

    # Call
    hfd.to_screen('test', {'end':'\n'})

    # Check
    assert len(ffd.toscreen) == 0

# Generated at 2022-06-22 06:56:45.049274
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import types
    from .http import HttpFD
    from . import FileDownloader
    from ..utils import prepend_extension
    http_downloader = HttpQuietDownloader(FileDownloader({
        'outtmpl': prepend_extension(sys.stdout, '%(format_id)s-%(id)s'),
        'format': 'best',
        'nooverwrites': True,
        'noprogress': True,
        'quiet': True,
    }), {
        'quiet': True,
    })
    assert http_downloader.ydl is not None
    assert isinstance(http_downloader.params, dict)
    assert len(http_downloader.params) == 2
    assert http_downloader.params['quiet'] is True

# Generated at 2022-06-22 06:56:49.824308
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .utils import FakeYDL
    ydl = FakeYDL()
    ffd = FragmentFD(ydl, {})
    ffd.to_screen = ydl.toScreen
    ffd.report_skip_fragment(5)
    assert 'Skipping fragment 5' in ydl.msgs

# Generated at 2022-06-22 06:57:01.173383
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io
    import tempfile
    from collections import namedtuple

    # Set up FD as if it was set up by youtube-dl
    params = IoFD.default_params.copy()

# Generated at 2022-06-22 06:57:07.654680
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .test_utils import TestFD

    class FakeFD(TestFD):
        def __init__(self, ydl):
            TestFD.__init__(self, ydl)
            self.FD_NAME = 'fakefd'

    fd = FakeFD({})
    fd.report_skip_fragment(3)
    assert fd.msgs == [['fakefd: Skipping fragment 3...']]
    fd.msgs = []
    fd.report_skip_fragment(9)
    assert fd.msgs == [['fakefd: Skipping fragment 9...']]

# Generated at 2022-06-22 06:57:15.592944
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Create HttpQuietDownloader object and call to_screen method
    hqd = HttpQuietDownloader(None, {'noprogress': True})
    hqd.to_screen('foo')

    # Create HttpQuietDownloader object in quiet mode
    # and call to_screen method
    hqd = HttpQuietDownloader(None, {'quiet': True})
    hqd.to_screen('foo')


if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-22 06:57:18.627981
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():  # pylint: disable=invalid-name
    import sys
    sys.stdout = open(os.devnull, 'w')

    dl = HttpQuietDownloader(None, None)
    dl.to_screen('test')

# Generated at 2022-06-22 06:57:21.213012
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader(
        {'quiet': True, 'noprogress': True, 'ratelimit': None, 'retries': 0, 'nopart': False, 'test': False}, {})
    assert ydl is not None

# Generated at 2022-06-22 06:57:32.129946
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class FakeInfoDict(dict):
        def __init__(self, http_headers=None):
            self['http_headers'] = dict(http_headers) if http_headers else {}

    # Test with no http_headers
    fd = FragmentFD({}, None)
    assert fd._prepare_url(FakeInfoDict(), 'http://abc.xyz/') == 'http://abc.xyz/'

    # Test with http_headers
    fd = FragmentFD({}, None)
    info = FakeInfoDict(http_headers={'Cookie': 'foo=bar; bar=baz', 'User-Agent': 'Mozilla/1.0'})
    req = fd._prepare_url(info, 'http://abc.xyz/')
    assert isinstance(req, sanitized_Request)

# Generated at 2022-06-22 06:57:45.099575
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({
        'outtmpl': '%(id)s.%(ext)s',
        'format': 'best',
    })
    fd.to_screen_hooks = []

    def dummy_to_screen_hook(message, *args, **kargs):
        fd.to_screen_hooks.append(message)

    fd.to_screen = dummy_to_screen_hook

    fd.report_retry_fragment(u'фейл братишка!', 42, 3, 3)