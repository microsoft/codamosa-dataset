

# Generated at 2022-06-22 06:50:26.907078
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass



# Generated at 2022-06-22 06:50:35.086616
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class MockYDL(object):

        def __init__(self):
            self._progress_hooks = []

        def add_progress_hook(self, callback):
            self._progress_hooks.append(callback)

        def to_screen(self, msg):
            pass

    ydl = MockYDL()
    hqd = HttpQuietDownloader(ydl, {'quiet': True})
    assert len(ydl._progress_hooks) > 0

    class MockInfoDict(object):

        pass

    infodict = MockInfoDict()
    infodict.http_headers = {'Range': 'bytes=0-'}
    assert hqd.get_file(infodict, 'foo') is None

# Generated at 2022-06-22 06:50:38.113233
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fd = HttpQuietDownloader('test', {})
    assert fd.to_screen(1) == None

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:50:51.176014
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .dashsegments import DASHFragmentsFD
    from .hls import HLSFD
    from .m3u8 import M3U8FD
    from .f4m import F4MFD
    from .fragment import FragmentFD

    class TestFD(FragmentFD):
        FD_NAME = 'test'

    assert isinstance(TestFD(), FragmentFD)
    assert TestFD.__bases__ == (FragmentFD,)
    assert TestFD().FD_NAME == 'test'

    assert TestFD()._prepare_url('url', 'test') == 'test'
    assert TestFD()._prepare_url('url', 'test', 'header') == sanitized_Request('test', None, 'header')

    assert isinstance(DASHFragmentsFD(), FragmentFD)

# Generated at 2022-06-22 06:50:52.596325
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # Check normal case
    # TODO: Add this functionality
    pass


# Generated at 2022-06-22 06:50:59.342279
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)
    fd = FragmentFD('http://localhost', {}, 'filename')
    assert fd.ydl is None
    assert fd.params['fragment_retries'] == 10
    assert not fd.params['skip_unavailable_fragments']
    assert not fd.params['keep_fragments']

# Generated at 2022-06-22 06:51:11.386212
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .http import HttpFD
    from ..compat import compat_urllib_error

    def test(fragment_retries, errcode, expected_message):
        fd = FragmentFD(None, {'fragment_retries': fragment_retries})
        fd.report_retry_fragment(
            compat_urllib_error.HTTPError(None, errcode, None, None, None),
            1, 1, fragment_retries)
        assert fd.to_screen_strs == [expected_message]
        fd.to_screen_strs = []

    test(1, 503, '[download] Got server HTTP error: 503 Server Error. Retrying fragment 1 (attempt 1 of 1)...')

# Generated at 2022-06-22 06:51:21.512778
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    from ..utils import compat_urllib_error

    class MockFD(HttpFD):
        def __init__(self):
            super(MockFD, self).__init__(
                {}, {
                    'continuedl': True,
                    'noprogress': True,
                    'retries': 0,
                })
            self.reported = []
        def to_screen(self, *args, **kargs):
            self.reported.append(args[0] % args[1:])

    error = compat_urllib_error.HTTPError('host', 'httperr', 'httpmsg', {}, None)
    fd = MockFD()

# Generated at 2022-06-22 06:51:24.096220
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    hqd = HttpQuietDownloader({}, {'quiet': True})
    assert hqd.to_screen('test') is None

# Generated at 2022-06-22 06:51:36.505769
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    """Test method to_screen of class HttpQuietDownloader"""

    import sys
    import StringIO

    # Suppress display of downloading progress information
    out = StringIO.StringIO()
    old_stdout = sys.stdout
    sys.stdout = out

    ydl = FileDownloader({'quiet': True}, {})
    ydl.add_progress_hook(lambda d: None)
    dl = HttpQuietDownloader(ydl, {'continuedl': False})
    dl.to_screen('Downloading foo')

    # Restore stdout
    sys.stdout = old_stdout

    # Check that no message has been displayed
    assert out.getvalue() == ''

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-22 06:52:01.132422
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    fd.params = {'noprogress': True}
    fd.to_screen = lambda x: 'report_skip_fragment:' + x
    assert fd.report_skip_fragment(6) == 'report_skip_fragment:[download] Skipping fragment 6...'



# Generated at 2022-06-22 06:52:12.125921
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    ie = get_info_extractor('YoutubeIE', 'youtube')
    params = {
        'outtmpl': '%(id)s.%(ext)s',
    }
    from .dash import DASHFD
    from .hls import HLSFD
    from .m3u8 import M3U8FD
    for child_cls in (DASHFD, HLSFD, M3U8FD):
        child = child_cls(ie, params)
        assert issubclass(child.__class__, FragmentFD)
        assert child.ydl is ie.ydl

# Generated at 2022-06-22 06:52:17.204974
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = object.__new__(HttpQuietDownloader)
    ydl.to_screen = ydl.report_warning = ydl.report_error = lambda *args, **kargs: None
    try:
        # test present
        assert hasattr(ydl, 'to_screen')
    except AssertionError:
        raise AssertionError('Method to_screen of class HttpQuietDownloader does not exist')

# Generated at 2022-06-22 06:52:25.907462
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class CountingFragmentFD(FragmentFD):
        def __init__(self):
            self.count = 0
        def to_screen(self, *args, **kargs):
            self.count += 1

    fd = CountingFragmentFD()
    msg = fd.report_retry_fragment(
        err=RuntimeError('test'),
        frag_index=1,
        count=2,
        retries=3,
    )
    assert msg == '[download] Got server HTTP error: test. Retrying fragment 1 (attempt 2 of 3)...'
    assert fd.count == 1



# Generated at 2022-06-22 06:52:37.253866
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {'noprogress': True})
    fd.to_screen = lambda *args, **kargs: args
    fd.report_retry_fragment(
        FileDownloader.make_HTTPDownloadError(
            None, 'http', 'Test HTTP error', None, None, None, None),
        42, 3, 3)
    assert fd.to_screen.call_count == 1
    assert fd.to_screen.call_args[0][0] == (
        '[download] Got server HTTP error: Test HTTP error. Retrying fragment 42 (attempt 3 of 3)...')


# Generated at 2022-06-22 06:52:47.544698
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor import get_info_extractor
    from .downloader.common import FileDownloader
    from .compat import compat_str

    class MockFragmentFD(FragmentFD):
        def __init__(self, ydl, params):
            super(MockFragmentFD, self).__init__(ydl, params)
            self.to_screen_messages = []

        def to_screen(self, *args, **kargs):
            self.to_screen_messages.append(args)

    expected_message = '[download] Skipping fragment 4...'

    params = {
        'skip_unavailable_fragments': True,
        'fragment_retries': 10,
    }
    ydl = FileDownloader(params)

    ies = ['test_fragments']

# Generated at 2022-06-22 06:52:52.483947
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    params = {}
    ydl = FileDownloader(params)
    params = {'quiet': True, 'noprogress': True}
    dl = HttpQuietDownloader(ydl, params)
    assert dl.params['noprogress']

# Generated at 2022-06-22 06:52:54.409127
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    ydl = get_info_extractor('youtube')
    fd = FragmentFD(ydl, {})
    assert fd.params['fragment_retries'] == 10

# Generated at 2022-06-22 06:53:03.376992
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    fd._err_msg_template = '%(index)s -- %(count)s -- %(retries)s -- %(err)s'
    assert fd.format_retries(5) == '5'
    assert fd.format_retries(-1) == 'infinite'
    assert fd.report_retry_fragment(2, 3, 4, 5) == (
        '3 -- 4 -- 5 -- 2'
    )

# Generated at 2022-06-22 06:53:13.099295
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    class Output(object):
        def __init__(self):
            self.out = ''
        def write(self, out):
            self.out += out
        def isatty(self):
            return True
    output = Output()
    fd = FragmentFD(None, {}, None)
    fd.pbar = fd.to_screen = output.write
    fd.to_stderr = lambda x: sys.stderr.write(x.encode(sys.stderr.encoding))
    err = Exception()
    # No retries => no output
    fd.report_retry_fragment(err, 42, 1, 0)
    assert output.out == ''
    # 2 retries => 2 output messages

# Generated at 2022-06-22 06:54:00.164361
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():

    import sys
    from mock import Mock

    def _create_fd(output_stream):
        """
        Creates a FragmentFD instance with mocked 'to_screen' method.
        """
        fd = FragmentFD()
        fd.to_screen = Mock(wraps=output_stream.write)
        return fd

    # Method 'report_retry_fragment' should output the following string:
    # '[download] Got server HTTP error: 502. Retrying fragment 1 (attempt 1 of 2)...'
    output = []
    fd = _create_fd(sys.stdout)
    fd.report_retry_fragment(
        Exception('Got server HTTP error: 502'),
        frag_index=1,
        count=1,
        retries=2)

# Generated at 2022-06-22 06:54:05.362520
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD

    test_dict = {'continuedl': True, 'noprogress': True, 'ratelimit': None}
    res = HttpQuietDownloader(None, test_dict)

    assert isinstance(res, HttpFD)

# Generated at 2022-06-22 06:54:08.692826
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {'noprogress': True})
    fd.report_skip_fragment(52)
    assert fd.report.get_last_line() == '[download] Skipping fragment 52...'

# Generated at 2022-06-22 06:54:12.617017
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    assert fd.report_skip_fragment(3) == '\r[download] Skipping fragment 3...\n'

# Generated at 2022-06-22 06:54:18.340849
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from ..utils import FakeYDL

    fakeYDL = FakeYDL()
    ydl = HttpQuietDownloader(fakeYDL, {})
    ydl.to_screen('This text should not appear')
    assert fakeYDL.msgs == []

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-22 06:54:27.385320
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # This test is actually running the method to_screen with a fake object
    # in order to check that there are no side effects.
    class Fake_YoutubeDL():
        def to_screen(self, message):
            assert False, 'This method should not be called'

    fake_ydl = Fake_YoutubeDL()
    fake_params = {}
    quiet_dl = HttpQuietDownloader(fake_ydl, fake_params)
    quiet_dl.to_screen('fake message')

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-22 06:54:38.268890
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Note: This test uses static methods of HttpQuietDownloader
    # that's why class HttpQuietDownloader is imported above
    from ..extractor import get_info_extractor

    class DummyYDL(object):
        def __init__(self, params):
            self.params = params
            self.info_extractors = []
            self.add_info_extractor(get_info_extractor('youtube'))

        def to_screen(self, msg):
            pass

        def download(self, filenames):
            pass

        def add_info_extractor(self, ie):
            self.info_extractors.append(ie)


# Generated at 2022-06-22 06:54:40.894125
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    assert FragmentFD.report_skip_fragment('dummy', 42) \
        == '[download] Skipping fragment 42...'

# Generated at 2022-06-22 06:54:44.580716
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys

    fd = FragmentFD(None, {}, sys.stdout)
    assert fd is not None
    assert fd.total_frags > 0
    assert fd.params is not None

# Generated at 2022-06-22 06:54:45.693614
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    return FragmentFD({})

# Generated at 2022-06-22 06:56:04.333957
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FlvFD(FragmentFD):
        FD_NAME = 'flv'

    flvfd = FlvFD({'logger': None})
    try:
        err = ValueError('123')
        flvfd.report_retry_fragment(err, 0, 1, (1,))
    finally:
        flvfd.to_screen('')

# Generated at 2022-06-22 06:56:13.725560
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from six.moves import StringIO
    from .extractor.common import InfoExtractor

    ie = InfoExtractor(None)
    ie.to_screen = lambda *args, **kargs: args
    assert ie.to_screen('[download] Skipping fragment %d...' % 1) == (
        '[download] Skipping fragment 1...',)

    # Test that skipped fragments are reported properly
    # when there are multiple downloaders
    out = StringIO()
    fragment_fd_1 = FragmentFD(ie, {'outtmpl': '%(id)s-1.f4m'})
    fragment_fd_1.to_screen = lambda *args, **kargs: print(*args, file=out, **kargs)
    fragment_fd_1.report_skip_fragment(1)
    fragment_fd

# Generated at 2022-06-22 06:56:21.105490
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_cookiejar

    from . import HttpQuietDownloader
    from .common import FileDownloader
    d = HttpQuietDownloader({'noprogress': True}, {'noprogress': True, 'logger': FileDownloader(None, {}).to_screen})

    assert d.params['noprogress']
    assert isinstance(d.ydl, FileDownloader)
    assert d.ydl.params['noprogress']
    assert isinstance(d.ydl.ydl, FileDownloader)
    assert d.ydl.ydl.params['noprogress']
    assert isinstance(d.ydl.ydl.ydl, FileDownloader)
    assert d.ydl.ydl.ydl.params['logger'] == d.to_screen



# Generated at 2022-06-22 06:56:33.073860
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Note: A 'unittest.TestCase' is not used here as it would make this unit test as
    # a non-standalone one (meaning it would not be runnable by itself)
    from .common import FileDownloader

    class DummyYTDL(object):
        def __init__(self):
            self.params = {
                'quiet': False,
                'no_color': False,
            }

    ytdl = DummyYTDL()
    dl = HttpQuietDownloader(ytdl, {'quiet': True})
    dl.to_screen('hello')
    assert not ytdl.params['quiet']

    # Now check if the quiet option is not overwritten
    ytdl.params['quiet'] = True
    dl.to_screen('hello')
    assert ytd

# Generated at 2022-06-22 06:56:38.037175
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import gen_extractors
    class FakeInfoDict(dict):
        pass
    ydl = gen_extractors()[0][1](FakeInfoDict(), {'simulate': True})
    FragmentFD(ydl, ydl.params)

# Generated at 2022-06-22 06:56:48.666169
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class MockFragmentFD(FragmentFD):
        def __init__(self):
            FragmentFD.__init__(self, None, {})
            self.to_screen_calls = []

        def to_screen(self, message, skip_eol=None, override_quiet=False):
            self.to_screen_calls.append((message, skip_eol, override_quiet))

    fragdl = MockFragmentFD()
    fragdl.report_retry_fragment(ValueError('Fake'), 2, 3, (2, 3))
    fragdl.report_retry_fragment(ValueError('Fake'), 2, 3, (2, 0))

    assert 2 == len(fragdl.to_screen_calls)

# Generated at 2022-06-22 06:56:57.624556
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import codecs
    from ..compat import StringIO

    stream = StringIO()
    try:
        from . import FileDownloader
        FragmentFD.to_screen = FileDownloader.to_screen
        FragmentFD.params = {'skip_unavailable_fragments': True}
        FragmentFD.report_skip_fragment(FragmentFD, 2)
        assert stream.getvalue() == '[download] Skipping fragment 2...\n'
    finally:
        sys.stdout = sys.__stdout__
        stream.close()

# Generated at 2022-06-22 06:57:05.480931
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractors
    from .common import get_info_extractor
    import tempfile
    import sys

    def parse(s):
        ie = get_info_extractor(gen_extractors(), 'youtube')
        dl = HttpQuietDownloader(ie, params={'noprogress': True})
        return list(dl.extract_info(s, download=False))

    out = tempfile.NamedTemporaryFile(suffix='out')
    out.close()
    orig_stdout = sys.stdout

# Generated at 2022-06-22 06:57:17.175664
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    ydl = FileDownloader({
        'simulate': True,  # Do not download files
        'nooverwrites': True,  # Do not overwrite files
    })
    gen_extractors(ydl)
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    dl.add_info_extractor(
        type='invalid:no-download', ie_key='TestIE',
        ie=type(b'TestIE', (object,), {'_VALID_URL': r'.*://.+'}))
    assert dl.ies[0].IE_NAME == 'TestIE'
    assert dl.ydl is ydl


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:57:24.041314
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    # pylint: disable=import-error
    import unittest

    class TestFragmentFD(FragmentFD):

        from collections import namedtuple
        FD_NAME = namedtuple('FDName', 'id')(id='test_class_id')

        def __init__(self):
            self.to_screen = lambda *args, **kargs: None
            self.params = {}

    class TestFD(FileDownloader):
        pass

    fd = TestFragmentFD()
    fd.add_info_extractor(TestFD)
    fd.to_screen = TestFD.to_screen
    fd.params = {}

    class TestReportSkipFragment(unittest.TestCase):
        def test_report_skip_fragment(self):
            out