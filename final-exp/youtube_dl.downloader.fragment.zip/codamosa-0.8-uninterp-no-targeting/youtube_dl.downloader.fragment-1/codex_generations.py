

# Generated at 2022-06-22 06:50:31.021274
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    http_quiet_down = HttpQuietDownloader({}, {})
    http_quiet_down.to_screen()
    http_quiet_down.to_screen("Unit test 1")
    http_quiet_down.to_screen("Unit test 2", "Unit test 3")


# Generated at 2022-06-22 06:50:36.527070
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader(
        {
            'quiet': False,
            'continuedl': True,
            'noprogress': True,
            'retries': 0,
            'nopart': False,
            'test': False,
        }
    )
    assert ydl.ydl.params['continuedl'] is True
    assert ydl.ydl.params['noprogress'] is True
    assert ydl.ydl.params['nopart'] is False
    assert ydl.ydl.params['test'] is False
test_HttpQuietDownloader()

# Generated at 2022-06-22 06:50:39.675870
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class X(FragmentFD):
        FD_NAME = 'name'
    x = X(None)
    assert x._ready


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:50:50.974553
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys as _sys
    class _FakeYtdl():
        def to_screen(self, *args, **kargs):
            _sys.stdout.write('[test]: ')
            _sys.stdout.write('%s\n' % (args[0] if len(args) >= 1 else ''))
    class _FakeInfo():
        def __init__(self, test_dict = None):
            self.__dict__.update(test_dict or {})
    _http_quiet_downloader = HttpQuietDownloader(_FakeYtdl(), {'quiet': True})
    _http_quiet_downloader.to_screen('[test]: hello')

# Generated at 2022-06-22 06:51:00.132960
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .helpers import FakeYDL
    from .extractor import get_info_extractor

    ie = get_info_extractor('youtube')
    ydl = FakeYDL()
    fd = FragmentFD(ydl, ie, {'skip_unavailable_fragments': True})
    fd.report_skip_fragment(1)
    fd.report_skip_fragment(3)
    expected_output = (
        '[%s] Skipping fragment 1...\n' % fd.FD_NAME +
        '[%s] Skipping fragment 3...\n' % fd.FD_NAME)
    assert ydl.get_print_msg() == expected_output


# Generated at 2022-06-22 06:51:10.154271
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import DateRange

    class DummyIE(InfoExtractor):
        _VALID_URL = r'.*'
        IE_NAME = 'DummyIE'

    class DummyFD(HttpFD):
        FD_NAME = 'DummyFD'

    ie = DummyIE(FakeYDL())
    dl = DummyFD(ie)
    dl.report_skip_fragment(10)

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-22 06:51:20.017644
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import get_info_extractor
    from .postprocessor.ffmpeg import FFmpegPostProcessor

    class _FakePostProcessor(FFmpegPostProcessor):
        def run(self, info):
            return [], info
    ie = get_info_extractor('generic')
    ie.set_downloader(HttpQuietDownloader(None, {
        'quiet': True,
        'noprogress': True,
    }))
    ie.add_info_extractor(_FakePostProcessor(ie))


# Generated at 2022-06-22 06:51:32.931197
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    ydl = object()
    params = {}
    fd = FragmentFD(ydl, params)
    fd.to_screen = lambda *x: x
    fd.report_retry_fragment(Exception("Test message"), 0, 2, 5)
    assert fd.to_screen.called == 1
    assert fd.to_screen.call_args[0][0].index("Test message") == 0
    assert fd.to_screen.call_args[0][0].index("Retrying fragment") == len("Got server HTTP error: ")
    fd.to_screen = lambda *x: x
    fd.params['retries'] = 2
    fd.report_retry_fragment(Exception("Test message"), 0, 2, 5)

# Generated at 2022-06-22 06:51:43.932587
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class DummyYDL:
        params = {
            'noprogress': True,
        }

    class DummyFD(FragmentFD):
        def __init__(self, ydl):
            self.ydl = ydl

    fd = DummyFD(DummyYDL())

    # Test unicode error
    fd.report_retry_fragment(u'Unicode érror', 2, 1, 2)
    # Test plain string error
    fd.report_retry_fragment('Plain string érror', 2, 1, 2)
    # Test bytes error
    fd.report_retry_fragment(b'Bytes \xc3\xa9rror', 2, 1, 2)



# Generated at 2022-06-22 06:51:50.323825
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class StubYDL(object):
        def __init__(self, params):
            self.params = params
        def to_screen(self, *args, **kargs):
            pass
    quiet_dl = HttpQuietDownloader(StubYDL({'noprogress': True}), {'quiet': True})
    assert not quiet_dl.params.get('quiet', False)
    assert not quiet_dl.params.get('noprogress', False)
    assert quiet_dl.noprogress()

# Generated at 2022-06-22 06:52:18.190456
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        def __init__(self, ydl):
            super(MyFragmentFD, self).__init__(ydl)

        def real_download(self, filename, info_dict):
            self._prepare_and_start_frag_download(self.ctx)
            while self.ctx['fragment_index'] < self.ctx['total_frags']:
                self.ctx['fragment_index'] = self.ctx['fragment_index']
                self._finish_frag_download(self.ctx)
                return True
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'continuedl': True, 'noprogress': True})
    myfd = MyFragmentFD(ydl)

# Generated at 2022-06-22 06:52:29.160522
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor.common import InfoExtractor
    from .utils import Purpose
    from .cache import Cache

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': False,
            }

        def to_screen(self, message, skip_eol=False):
            sys.stdout.write(message + ('\n' if not skip_eol else ''))

    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {
        'quiet': True,
    })
    assert dl.params['noprogress']
    dl.to_screen('test')
    dl.report_progress(1, 5)

    ydl.params['noprogress'] = True
    dl

# Generated at 2022-06-22 06:52:39.550341
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .downloader.external import ExternalFD

    ydl = InfoExtractor()
    ydl.params.update({
        'outtmpl': 'test_%(id)s.%(ext)s',
        'skip_download': True,
    })

    dl = HttpQuietDownloader(ydl, {
        'quiet': True,
        'noprogress': True,
        'ratelimit': '100k',
        'retries': 5,
    })

    _, tmpfilename = sanitize_open(ExternalFD('ffmpeg', ydl).temp_name('test'), 'wb')

    ctx = {
        'filename': tmpfilename,
        'dl': dl,
    }
    FragmentFD._start_frag_download(ctx)

# Generated at 2022-06-22 06:52:48.304368
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestableFragmentFD(FragmentFD):
        def __init__(self):
            self.out = []
        def to_screen(self, message, skip_eol=False):
            self.out.append(message)

    fd = TestableFragmentFD()
    fd.report_retry_fragment(ValueError('test'), 15, 3, 10)
    assert fd.out == [
        '[download] Got server HTTP error: test. Retrying fragment 15 (attempt 3 of 10)...',
    ]

# Generated at 2022-06-22 06:52:54.504170
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {'fragment_retries': 1})
    fd.to_screen = lambda x: x
    fd.report_retry_fragment(
        Exception("Test exception"), 5, 1, fd.params.get('fragment_retries'))


# Generated at 2022-06-22 06:53:07.087473
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import get_info_extractor

    class MockYDL(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s-%(playlist_index)s-%(playlist_title)s'
                           '-%(playlist_uploader)s-%(playlist_id)s-%(playlist)s-%(playlist_duration)s-%(playlist_thumbnails)s',
            }

        def to_screen(self, s):
            print(s)

    fd = FragmentFD(MockYDL(), get_info_extractor('youtube'), 'http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-22 06:53:11.574159
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpFD
    HttpFD.to_screen = HttpQuietDownloader.to_screen
    HttpFD.to_stderr = HttpQuietDownloader.to_stderr
    return HttpFD.test()

# Generated at 2022-06-22 06:53:17.081004
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: args[0]
    assert fd.report_skip_fragment(1) == '\r[download] Skipping fragment 1...\r'

# Generated at 2022-06-22 06:53:26.758210
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)
    fd = FragmentFD('youtube-dl')
    assert fd.params['retries'] == 10
    assert fd.params['fragment_retries'] == 10
    assert fd.params['continuedl']
    assert fd.params['noprogress']
    assert fd.params['ratelimit'] is None
    assert fd.params['nopart']
    assert not fd.params['test']
    assert fd.FD_NAME == 'fragment'
    assert fd.retry_max == 10
    assert fd.skip_unavailable_fragments
    assert fd.postprocessors == []

# Generated at 2022-06-22 06:53:36.603376
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_str
    from ..extractor.common import InfoExtractor
    class MockFileDownloader(object):
        def to_screen(self, *args, **kargs):
            pass
    class MockIE(InfoExtractor):
        IE_NAME = 'mock'

        def report_destination(self, *args, **kargs):
            pass

    fd = HttpQuietDownloader(MockFileDownloader(), {
        'quiet': True,
        'continuedl': True,
        'noprogress': True,
        'test': True,
    })
    assert fd.ydl == MockFileDownloader()
    assert fd.params['quiet'] is True
    assert os.path.basename(fd.params['outtmpl']) == '%(id)s'


# Generated at 2022-06-22 06:54:09.959771
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['noprogress'] = True
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(FragmentFD())

    class FakeDl:
        def report_warning(self, message):
            raise AssertionError('Unexpected call to report_warning(%r)' % message)

    ffd = FragmentFD(ydl, {'noprogress': True})
    ffd.to_screen = lambda *args, **kargs: None
    ffd.report_skip_fragment(42)

# Generated at 2022-06-22 06:54:15.013599
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({}, None)
    fd.to_screen = lambda x: x
    assert fd.report_retry_fragment(None, None, None, 21) == (
        '[download] Got server HTTP error: None. '
        'Retrying fragment None (attempt 21 '
        'of 20)'
    )

# Generated at 2022-06-22 06:54:21.512165
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = None
    params = {'quiet': True, 'noprogress': True}
    hqd = HttpQuietDownloader(ydl, params)
    assert params['continuedl'] is True
    assert hqd.params['continuedl'] is True
    assert hqd.to_screen.__name__ == 'dummy'

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:54:26.430819
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader({
        'quiet': True,
        'continuedl': True,
        'noprogress': True,
        'retries': 2,
        'nopart': True,
        'test': True,
    })
    ydl.to_screen('foo')

# Generated at 2022-06-22 06:54:29.623914
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {}, None)
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment('err', 2, 3, 4) == ((
        '[download] Got server HTTP error: err. '
        'Retrying fragment 2 (attempt 3 of 4)...'),)

# Generated at 2022-06-22 06:54:32.857449
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    assert issubclass(HttpQuietDownloader, FileDownloader)

# Generated at 2022-06-22 06:54:44.354144
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from .utils import prepend_extension

    names = [
        'test-video-dash-fmp4.mkv',
        'test-video-hds.f4v',
        'test-video-hls-variant.m3u8',
        'test-video-hls.m3u8',
    ]

    fmasks = [
        ('%(playlist_title)s-%(playlist_index)s-%(title)s', '.%(ext)s'),
        ('%(playlist_title)s-%(playlist_index)s-%(title)s-%(fragment_number)s.%(ext)s'),
    ]


# Generated at 2022-06-22 06:54:56.163031
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    ie = InfoExtractor({})
    ie.add_info_extractor(_gen_extractor({
        'id': 'foo',
        'extractor': 'dummy',
    }))
    info_dict = {
        'id': 'testid',
        'url': 'http://example.com/test.mp4',
        'extractor': 'foo',
    }
    params = {
        'outtmpl': '%(id)s.mp4',
        'quiet': True,
        'noprogress': True,
        'continuedl': True,
        'nopart': True,
    }
    ie.extract_info(info_dict, downloader=HttpQuietDownloader(ie, params))


# Generated at 2022-06-22 06:55:07.264141
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys

    import mock
    from ..compat import compat_urllib_error

    url = 'http://example.com/manifest.m3u8'
    ydl = mock.MagicMock()
    params ={
        'retries': 3,
        'seek_fragment': 1,
        'fragment_retries': 2,
    }
    FD = FragmentFD(ydl, params)
    args = [
        FD._prepare_url,
        FD._start_frag_download,
        FD._download_fragment,
        FD._append_fragment,
        FD._finish_frag_download,
    ]

    class Manifest(object):
        def __init__(self, urls):
            self.urls = urls


# Generated at 2022-06-22 06:55:17.992686
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from six.moves import StringIO
    from .common import FileDownloader
    from .http import HttpFD

    ctx = {
        'dl': HttpFD(),
        'filename': 'test',
        'tmpfilename': 'test',
        'total_frags': 1,
    }
    ctx['fd'] = FragmentFD(FileDownloader({'outtmpl': ctx['tmpfilename']}, None))
    ctx['fd'].to_screen = lambda *args, **kargs: None

    err = 'error'
    frag_index = 99
    count = 5
    retries = 12

    ctx['fd'].report_retry_fragment(err, frag_index, count, retries)

    # Verify console output
    buf = ctx['dl'].ydl.msgs
   

# Generated at 2022-06-22 06:56:36.843708
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {}, None, {'quiet': True})
    assert fd.format_retries(0) == 'infinite'
    assert fd.format_retries(1) == '1'
    assert fd.format_retries(321) == '321'
    assert fd.format_retries('infinite') == 'infinite'
    assert fd.format_retries('foo') == 'infinite'
    assert fd.format_retries(None) == 'infinite'


if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-22 06:56:44.456033
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # prepare dummy file downloader and dummy hook
    ydl = object()
    params = {}
    report = []

    def hook(msg):
        report.append(msg)

    fd = FragmentFD(ydl, params)
    fd.add_progress_hook(hook)

    # test fragment skipping hook message
    fd.report_skip_fragment(12)
    assert report == ['[download] Skipping fragment 12...']

# Generated at 2022-06-22 06:56:52.464318
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()

    # Check that format string is correct
    def to_screen(self, *msg):
        assert msg == ('[download] Skipping fragment %d...', 7,)

    try:
        fd.to_screen = to_screen
        fd.report_skip_fragment(7)
    finally:
        del fd.to_screen

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-22 06:56:59.124312
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def silent_output(self, *args, **kargs):
        pass

    def dummy_read_fragment_url(*args, **kargs):
        return 'dummy://url'

    class FakeYDL(object):
        params = {
            'verbose': False,
            'quiet': True,
            'noprogress': True,
            'retries': 0,
            'continuedl': True,
        }

        def to_screen(self, *args, **kargs):
            pass

    ydl = FakeYDL()
    FD_ctor = FragmentFD.__init__
    FragmentFD.__init__ = lambda self, *args, **kargs: FD_ctor(self, *((ydl,) + args), **kargs)

# Generated at 2022-06-22 06:57:05.970991
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MyFragmentFD(FragmentFD):
        def __init__(self, ydl):
            self.to_screen_str = ''
            super(MyFragmentFD, self).__init__(ydl)

        def to_screen(self, *args, **kargs):
            self.to_screen_str = encodeFilename(args[0])

    s = FragmentFD(None)
    assert s.report_skip_fragment(23) is None

    m = MyFragmentFD(None)
    assert m.report_skip_fragment(5) is None
    assert m.to_screen_str == '[download] Skipping fragment 5...'


if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-22 06:57:10.805354
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    dl = HttpQuietDownloader({}, {})
    dl.to_screen('test', '', dl)
    dl.to_screen('test', '', dl, dl)

# Generated at 2022-06-22 06:57:19.909769
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    from .common import set_socket_timeout
    from .http import HttpFD
    from .dash import DASHFD

    class FragmentFDforUnittest(FragmentFD):
        ydl = None

        def __self__(self):
            return self.__class__

    class DASHFDforUnittest(DASHFD, FragmentFDforUnittest):
        ydl = None

    info_dict = {
        'url': 'http://test',
        'fragment_index': int
    }

    def progress_hook(d):
        if d.get('status') == 'finished':
            sys.exit(100)

    tmp_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'unittests_temp')
   

# Generated at 2022-06-22 06:57:23.041013
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda x: x
    retries = 2
    assert fd.report_retry_fragment(None, 12, 1, retries) == (
        '[download] Got server HTTP error: None. Retrying fragment 12 (attempt 1 of %d)...' % retries)

# Generated at 2022-06-22 06:57:32.141301
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class StubFD(FragmentFD):
        def __init__(self):
            self.messages = []

        def to_screen(self, *args, **kargs):
            self.messages.append(args)

    err = ValueError()
    fd = StubFD()
    fd.report_retry_fragment(err, 5, 1, 10)
    assert fd.messages[0] == (
        "[download] Got server HTTP error: %s. Retrying fragment 5 (attempt 1 of 10)..." %
        error_to_compat_str(err), )

if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-22 06:57:35.936295
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    ydl = gen_extractors()['youtube']
    fd = FragmentFD(ydl)
    assert fd is not None