

# Generated at 2022-06-22 06:50:32.632499
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.streams = []
            self.to_screen_lock = False

        def to_screen(self, msg):
            assert not self.to_screen_lock
            self.to_screen_lock = True
            self.streams.append(msg)
            self.to_screen_lock = False

    test_downloader = TestFragmentFD()
    test_downloader.report_retry_fragment(Exception('test exception'), 3, 2, (2, 3))
    assert test_downloader.streams[0] == '[download] Got server HTTP error: test exception. Retrying fragment 3 (attempt 2 of 2)...'

# Generated at 2022-06-22 06:50:39.029871
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..compat import compat_urllib_request
    from ..utils import determine_ext

    def test_do_ytdl_file(fd):
        fd.__do_ytdl_file = lambda x: True
        res = fd._do_ytdl_file(
            {'dl': HttpQuietDownloader(fd, None),
             'filename': 'a',
             'live': False,
             'tmpfilename': '-'},
            'b',
            False)
        assert res == 'a'

        fd.__do_ytdl_file = lambda x: False

# Generated at 2022-06-22 06:50:44.478740
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None)
    fd.to_screen = lambda s: s
    assert fd.report_skip_fragment(42) == '[download] Skipping fragment 42...'



# Generated at 2022-06-22 06:50:56.366514
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractors
    from .common import FileDownloader
    from .utils import prepare_filename
    from .extractor.common import InfoExtractor
    for ie in gen_extractors():
        if not ie.suitable(ie.url):
            continue
        if ie.IE_NAME in ['generic', 'googledrive']:
            continue
        ie = ie.ie
        if not ie.working():
            continue
        if issubclass(ie.__class__, InfoExtractor):
            continue
        if issubclass(ie.__class__, FileDownloader):
            continue
        print('Testing to_screen of %s' % ie.IE_NAME)
        ie = ie()
        ie.to_screen('test')
    print('Testing to_screen of HttpFD')
    f

# Generated at 2022-06-22 06:51:08.613003
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from six.moves import cStringIO as StringIO
    from contextlib import closing
    from .common import Parameters
    from .extractor import get_info_extractor

    def _get_stdout_str(extractor, filename, test_url, expected_str):
        params = Parameters()
        params.update(extractor._WORKAROUND)
        with closing(StringIO()) as out:
            with extractor.gen_extractor(test_url, downloader=FragmentFD(params, out, out)) as ie:
                ie.prepare_filename()
                fragment = ie.fragment_list[0]
                fragment['retries'] = 3
                fragment['frag_index'] = fragment['count'] = 1
                fragment['err'] = (0, 'msg')

                # Ensure result is 1 line
                result = extract

# Generated at 2022-06-22 06:51:16.807417
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    h = HttpQuietDownloader(
        None,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'nopart': True,
        }
    )
    assert h.params['continuedl'] is True
    assert h.params['quiet'] is True
    assert h.params['noprogress'] is True
    assert h.params['nopart'] is True
    assert h.params.get('ratelimit') is None
    assert h.params.get('retries') == 0
    assert h.params.get('test') is False

# Generated at 2022-06-22 06:51:19.866339
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, None, None)
    assert fd.params.get('fragment_retries', 0) == 0
    assert not fd.params.get('skip_unavailable_fragments', False)

# Generated at 2022-06-22 06:51:24.330219
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # pylint: disable=W0212
    ctx = {'to_screen': lambda x: print(x)}
    fd = FragmentFD(None, {})
    fd.report_skip_fragment(42, ctx)

# Generated at 2022-06-22 06:51:32.142688
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MockFragmentFD(FragmentFD):
        def __init__(self, msg_list):
            self._msg_list = msg_list

        def to_screen(self, msg, skip_eol=False):
            self._msg_list.append(msg)

    msg_list = []
    fd = MockFragmentFD(msg_list)
    fd.report_skip_fragment(1)
    assert msg_list == ['[download] Skipping fragment 1...']

# Generated at 2022-06-22 06:51:38.814938
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {'format': 'best'})
    got_message = []
    fd.to_screen = lambda message: got_message.append(message)
    fd.report_skip_fragment(2)
    assert got_message == ['[download] Skipping fragment 2...']


if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-22 06:52:03.189380
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .utils import FakeYDL
    from .extractor import get_info_extractor, gen_extractors
    gen_extractors()
    info = get_info_extractor('m3u8')
    instance = info()
    instance.ydl = FakeYDL()
    instance.report_retry_fragment(None, 1, 2, 3)

# Generated at 2022-06-22 06:52:09.937227
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor.common import InfoExtractor
    from ..utils import flush_ssl_errors

    class TestIE(InfoExtractor):
        def report_warning(self, msg):
            assert False, 'Unexpected call to report_warning'
        def report_error(self, msg, tb=None):
            assert False, 'Unexpected call to report_error'
        def to_screen(self, msg):
            assert False, 'Unexpected call to to_screen'

    ie = TestIE()
    flush_ssl_errors(HttpQuietDownloader(ie, ie.params))

# Generated at 2022-06-22 06:52:18.649349
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    def get_FragmentFD():
        return FragmentFD(None, {})

    err = KeyboardInterrupt()
    frag_index = 3
    count = 2
    retries = 6

    f = get_FragmentFD()
    # This test ensures that the output is not changed
    # by the test itself (the print handler)
    def test_log(msg, *args):
        assert args == tuple()
    f.to_screen = test_log

    f.report_retry_fragment(err, frag_index, count, retries)
    # This test ensures that the output is not changed
    # by the test itself (the print handler)

# Generated at 2022-06-22 06:52:25.576694
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..downloader.common import FileDownloader
    class MyFD(FileDownloader):
        def to_screen(self, s):
            print(s)
    params = {'noprogress': True,'quiet': True,'nopart': True}
    ydl = MyFD({}, params)
    HttpQuietDownloader(ydl, params)

# Generated at 2022-06-22 06:52:36.177506
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import youtube_dl.extractor.common
    from youtube_dl.extractor.http import HttpFD
    url = 'http://localhost/video.mp4'
    m = youtube_dl.extractor.common.FragmentFD(HttpFD(), {}, {})
    m.to_screen = lambda *args, **kargs: args
    expected = ('[download] Got server HTTP error: test error. '
                'Retrying fragment 1 (attempt 987 of 4567)...')
    assert m.report_retry_fragment(
        Exception('test error'), 1, 987, 4567) == (expected,)

if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-22 06:52:39.806102
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from . import FakeYDL
    fake_ydl = FakeYDL()
    fragfd = FragmentFD(fake_ydl)
    fragfd.report_skip_fragment(12)
    assert fake_ydl.msgs == ['[download] Skipping fragment 12...']

# Generated at 2022-06-22 06:52:52.211503
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    temp_dir = tempfile.mkdtemp()
    dest_path = os.path.join(temp_dir, 'dest_file')
    try:
        fd = HttpQuietDownloader(
            YoutubeDL({'outtmpl': dest_path}),
            {'continuedl': True, 'quiet': True, 'noprogress': True, 'test': False})

        req = sanitized_Request('http://example.com/')
        fd.download(dest_path, {'url': req.full_url()})

        assert os.path.isfile(encodeFilename(dest_path)), 'Download should create a file'
        assert os.path.getsize(encodeFilename(dest_path)), 'Downloaded file should not be empty'
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-22 06:53:02.918159
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    class FakeYDL(object):
        pass
    from .extractor import gen_extractors
    ie = InfoExtractor()
    ie.add_info_extractor(gen_extractors())
    ydl = FakeYDL()
    ydl.params = {}
    ydl.params['noprogress'] = False
    ydl.params['logger'] = None
    hqd = HttpQuietDownloader(ydl, {'noprogress': True})
    hqd.to_screen('This line should not be printed')

# Generated at 2022-06-22 06:53:12.815869
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {'noprogress': True})
    fd.to_screen = lambda *args, **kargs: args
    retries = 3
    err = 'http error'
    frag_index = 2

    # retry for the first time
    count = 1
    assert fd.report_retry_fragment(err, frag_index, count, retries) == (
        '[download] Got server HTTP error: %s. Retrying fragment %d (attempt %d of %d)...'
        % (err, frag_index, count, retries),
    )
    # retry for the last time
    count = retries

# Generated at 2022-06-22 06:53:23.850549
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor import gen_extractors

    ydl = gen_extractors()
    HttpQuietDownloader(
        ydl, {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': None,
            'retries': 0,
            'nopart': False,
            'test': False,
        }).add_default_info_extractors()
    sys.argv = [sys.argv[0], 'https://example.com/test.html']
    ydl.download(ydl.prepare_filename(ydl.extract_info('https://example.com/test.html', download=False)))

# Generated at 2022-06-22 06:54:09.182810
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys

    class MockStdout(object):
        def __init__(self):
            self.written = ''

        def write(self, s):
            self.written += s

        def flush(self):
            pass

    stdout = sys.stdout
    sys.stdout = MockStdout()
    try:
        downloader = HttpQuietDownloader(None, {
            'noprogress': False,
        })

        # Test this code path
        downloader.to_screen('abc')
        downloader.to_screen('def')
        assert sys.stdout.written == 'def\n'

        # Test this code path
        downloader.to_screen('ghi\n')
        assert sys.stdout.written == 'def\nghi\n'
    finally:
        sys

# Generated at 2022-06-22 06:54:18.544285
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    fd = FragmentFD('dummy')
    assert isinstance(fd, FileDownloader)
    assert fd.params == {
        'buffersize': 1024,
        'continuedl': False,
        'noprogress': False,
        'ratelimit': None,
        'retries': 10,
        'fragment_retries': 10,
        'skip_unavailable_fragments': False,
        'nopart': False,
        'test': False,
    }
    assert fd.to_screen == FileDownloader.to_screen

# Generated at 2022-06-22 06:54:30.432864
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import test_utils

    class DummyHttpQuietDownloader(object):
        def __init__(self, retries):
            self.params = {'retries': retries}

    class DummyLogger(object):
        def __init__(self):
            self.messages = []

        def to_screen(self, msg):
            self.messages.append(msg)

    def test(retries, expected_messages):
        fd = FragmentFD(None, {'retries': retries})
        fd.to_screen = DummyLogger().to_screen

        class DummyExtractor(object):
            def __init__(self, retries):
                self.params = {'retries': retries}

        dl = DummyHttpQuietDownloader(retries)
        retry_

# Generated at 2022-06-22 06:54:37.825139
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFD(FragmentFD):
        def __init__(self, msgdest):
            self.msgdest = msgdest

        def to_screen(self, *args, **kargs):
            self.msgdest.append(' '.join(args))

    dest = []
    fd = TestFD(dest)
    fd.report_skip_fragment(101)
    assert len(dest) == 1
    assert 'Skipping fragment 101' in dest[0]

# Generated at 2022-06-22 06:54:40.946690
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {}, '-', {})
    assert fd
    assert fd.to_screen
    assert fd
    assert fd._hook_progress

# Generated at 2022-06-22 06:54:50.886971
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MockFD(FragmentFD):
        def __init__(self):
            self.to_screen_value = ''

        def to_screen(self, value):
            self.to_screen_value = value

    class MockYDL:
        def __init__(self):
            self.params = {}

    fragfd = MockFD()
    fragfd.ydl = MockYDL()
    fragfd.report_skip_fragment(123)
    assert fragfd.to_screen_value == '[download] Skipping fragment 123...'

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-22 06:54:54.350004
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    dl = HttpQuietDownloader(ydl, {'continuedl': False, 'quiet': True})
    assert dl.to_screen('a', 2) is None

# Generated at 2022-06-22 06:55:06.092205
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None)
    fd.to_screen = lambda *a, **kw: a
    # Dry run
    fd.params['noprogress'] = True
    assert fd.report_retry_fragment(
        ValueError('12345'), 1, 2, 3) == [
            '[download] Got server HTTP error: 12345. Retrying fragment 1 (attempt 2 of 3)...',
    ]
    assert fd.report_retry_fragment(
        ValueError('12345'), 1, 2, 1) == [
            '[download] Got server HTTP error: 12345. Retrying fragment 1 (attempt 2 of 1)...',
    ]
    fd.params['noprogress'] = False

# Generated at 2022-06-22 06:55:16.329914
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # create a FragmentFD object
    fd = FragmentFD(None, None, 'testid')

    def test_report_retry_fragment_cb(msg):
        # if the message contains the correct number of retries, set success to
        # True
        if ('attempt 1 of 2' in msg) or ('Retrying fragment 0 (attempt 1 of 2)' in msg):
            fd.success = True

    # Setup error to report and count of retries, then call the method under
    # test.
    fd.report_retry_fragment('test_error', 0, 1, 2)

    # Set the callback method to the one defined above, then run the
    # report_retry_fragment method again to call this callback
    fd.to_screen = test_report_retry_frag

# Generated at 2022-06-22 06:55:28.955021
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeYDL(object):
        def __init__(self):
            self.output_map = {}

        def to_screen(self, message, component, **kwargs):
            if component not in self.output_map:
                self.output_map[component] = []
            self.output_map[component].append(message)

    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {})
    dl.to_screen("a", "info")
    dl.to_screen("b", "warning")
    dl.to_screen("c", "error")

    assert len(ydl.output_map['http_downloader']) == 3
    assert 'a' in ydl.output_map['http_downloader']
    assert 'b' in ydl.output

# Generated at 2022-06-22 06:56:49.980912
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import StringIO

    fd = FragmentFD({'outtmpl': '-'}, {})

    # Test fragment skipping
    fd.to_screen = lambda *args: sys.stdout.write(' '.join(args) + '\n')
    saved_stdout = sys.stdout
    try:
        out = StringIO.StringIO()
        sys.stdout = out
        fd.report_skip_fragment(5)
        assert u'[download] Skipping fragment 5...\n' == out.getvalue()
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-22 06:57:01.324833
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class YDL(object):
        def __init__(self, to_stderr, force_verbose=False):
            self.to_stderr = to_stderr
            self.force_verbose = force_verbose
            self.params = {}

        def trouble(self, *args, **kargs):
            pass

    ydl = YDL(False)
    qd = HttpQuietDownloader(ydl, {})
    qd.to_screen("a", "b")
    ydl = YDL(True)
    qd = HttpQuietDownloader(ydl, {})
    qd.to_screen("a", "b")
    ydl = YDL(False, True)
    qd = HttpQuietDownloader(ydl, {})
    qd.to_

# Generated at 2022-06-22 06:57:11.412000
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .extractor import gen_extractor
    from ..compat import compat_urllib_error
    from ..extractor import YoutubeIE

    class SuccessFD(FragmentFD):
        def _download_fragment(self, ctx, frag_url, info_dict, headers=None):
            return True, b'a'
        def real_download(self, filename, info_dict):
            return True

    class FailFD(FragmentFD):
        def _download_fragment(self, ctx, frag_url, info_dict, headers=None):
            raise ValueError('This error should not be printed')
        def real_download(self, filename, info_dict):
            return True


# Generated at 2022-06-22 06:57:17.881671
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeYDL(object):
        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, msg):
            self.to_screen_calls.append(msg)

    fake_ydl = FakeYDL()
    qdl = HttpQuietDownloader(fake_ydl, {})
    qdl.to_screen('one')
    qdl.to_screen('two')
    assert [], fake_ydl.to_screen_calls

# Generated at 2022-06-22 06:57:21.354074
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {})
    fd.to_screen = lambda x: x
    assert fd.report_skip_fragment(3) == '[download] Skipping fragment 3...'

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-22 06:57:32.160136
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = FakeYDL()
    downloader = HttpQuietDownloader(ydl, {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': 1,
        'retries': 10,
        'nopart': True,
        'test': True,
    })
    assert downloader.params.get('continuedl', None)
    assert downloader.params.get('quiet', None)
    assert downloader.params.get('noprogress', None)
    assert downloader.params.get('ratelimit', None) == 1
    assert downloader.params.get('retries', None) == 10
    assert downloader.params.get('nopart', None)
    assert downloader.params.get('test', None)

# Generated at 2022-06-22 06:57:38.369094
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    class FakeIE(InfoExtractor):
        IE_NAME = 'fakeie'

    ie = FakeIE(gen_extractor())
    # TODO write unit test for FragmentFD

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:57:42.201723
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = object()
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'nopart': True,
        'test': True,
    }
    hqd = HttpQuietDownloader(ydl, params)
    hqd.to_screen('[download] sample output')
    hqd.to_screen('[download] sample output', skip_eol=True)
    hqd.to_screen('sample output')

# Generated at 2022-06-22 06:57:54.600134
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .common import FileDownloader
    from .postprocessor import gen_pp_db
    from .downloader import gen_downldr_db

    ydl = {
        'noprogress': False,
        'logger': None,
        'progress_hooks': [],
    }
    gen_extractor(ydl)
    gen_pp_db(ydl)
    gen_downldr_db(ydl)

    params = {
        'noprogress': True,
        'quiet': True,
    }
    fd = HttpQuietDownloader(ydl, params)
    assert not fd.params.get('progress_hooks')
    assert fd.params.get('quiet')
    assert FileDownloader._EXTRA_PROGRESS

# Generated at 2022-06-22 06:58:02.762521
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None)
    fd.to_screen = lambda msg: msg
    assert fd.report_skip_fragment(0) == '[download] Skipping fragment 0...'
    assert fd.report_skip_fragment(2) == '[download] Skipping fragment 2...'
    assert fd.report_skip_fragment(int(20e6)) == '[download] Skipping fragment 20000000...'