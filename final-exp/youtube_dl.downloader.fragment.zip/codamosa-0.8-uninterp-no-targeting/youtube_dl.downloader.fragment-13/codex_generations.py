

# Generated at 2022-06-22 06:50:29.451979
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FakeDownloader(object):
        def to_screen(self, *args, **kargs):
            args[0] % args[1:]
    dl = FakeDownloader()
    fd = FragmentFD(dl, None)
    fd.report_retry_fragment(Exception(''), 5, 6, 0)



# Generated at 2022-06-22 06:50:33.431719
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """Test whether HttpQuietDownloader has the required parameters"""
    ydl = object()
    params = {'continuedl': True, 'quiet': True, 'noprogress': True}
    dl = HttpQuietDownloader(ydl, params)
    assert dl.ydl is ydl
    assert dl.params == params

# Generated at 2022-06-22 06:50:36.832810
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .utils import FakeYDL
    ydl = FakeYDL()
    ffd = FragmentFD(ydl, {})
    assert ffd.ydl is ydl
    assert ffd.params is ydl.params

# Generated at 2022-06-22 06:50:49.647794
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    def test(**kwargs):
        old_stdout = sys.stdout
        sys.stdout = StringIO()
        try:
            HttpQuietDownloader(None, kwargs)
            assert False, 'Should raise ValueError'
        except ValueError:
            pass
        try:
            HttpQuietDownloader(None, None)
            assert False, 'Should raise ValueError'
        except ValueError:
            pass
        sys.stdout = old_stdout
    test()
    test(continuedl=True)
    test(quiet=False)
    test(continuedl=False, quiet=False)

# Generated at 2022-06-22 06:50:52.286105
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .utils import FakeYDL
    f = FakeYDL()
    h = HttpQuietDownloader(f)
    assert h.to_screen('test') == None

# Generated at 2022-06-22 06:51:03.960351
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .options import camel_case_to_dash
    from .extractor import gen_extractors, list_extractors
    from .downloader.rtmpdump import RTMPFD
    import tempfile
    import sys

    # Save stdout and stderr
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    stdout = tempfile.TemporaryFile(mode='w+b')
    stderr = tempfile.TemporaryFile(mode='w+b')

    # Make a fake RTMPFD and call report_retry_fragment()
    fd = RTMPFD()
    fd.report_retry_fragment(Exception('foo'), 2, 3, 2)

    # Restore stdout and stderr
    stdout.seek(0)
    st

# Generated at 2022-06-22 06:51:06.095306
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    downloader = HttpQuietDownloader(None, None)
    assert downloader.to_screen() is None

# Generated at 2022-06-22 06:51:15.748336
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import io
    import io
    from collections import namedtuple

    Info = namedtuple('Info', ['url'])
    ydl = namedtuple(
        'YoutubeDL', ['params', 'to_stdout', 'to_stderr', 'process_info'])

    def process_info(info):
        del info['tmpfilename']

    def to_stderr(message, skip_eol=False):
        return

    ydl.params = {}
    ydl.process_info = process_info
    ydl.to_stdout = ydl.to_stderr = to_stderr

    info = Info(url='http://test.test')
    hqd = HttpQuietDownloader(ydl, info)


# Generated at 2022-06-22 06:51:28.148136
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # NOTE: we need to use an actual test instance of the downloader
    # in order to check if the output is suppressed
    ctx = {
        'params': {},
        'info_dict': {},
        'tmpfilename': '',
        'filename': '',
        'info_dict': {},
        'add_progress_hook': lambda *args: None,
        'to_screen': lambda *args, **kargs: None,
    }
    dl = HttpQuietDownloader(ctx, { 'quiet': False })
    dl.to_screen('[download] We should not see this message, the quiet option was set')
    dl = HttpQuietDownloader(ctx, { 'quiet': True })
    dl.to_screen('[download] We should see this message')



# Generated at 2022-06-22 06:51:38.703556
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MyFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_calls = []
        def to_screen(self, *args, **kargs):
            self.to_screen_calls.extend(args)

    fd = MyFragmentFD()
    fd.report_skip_fragment(1)
    assert fd.to_screen_calls == ['[download] Skipping fragment 1...']
    fd.report_skip_fragment(2)
    assert fd.to_screen_calls == ['[download] Skipping fragment 1...',
                                  '[download] Skipping fragment 2...']

# Generated at 2022-06-22 06:52:09.363999
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..downloader.common import DownloadError
    from ..compat import compat_str
    fd = FragmentFD(None, {})
    # Test the string before the attempt number
    fd.to_screen = lambda x: x
    assert 'Retrying fragment 4 (attempt 1 of 3)' == fd.report_retry_fragment(DownloadError('foo'), 4, 1, 10)
    assert 'Retrying fragment 4 (attempt 2 of 3)' == fd.report_retry_fragment(DownloadError('foo'), 4, 2, 10)
    assert 'Retrying fragment 4 (attempt 3 of 3)' == fd.report_retry_fragment(DownloadError('foo'), 4, 3, 10)
    assert 'Retrying fragment 4 (attempt 1 of \'infinite\')' == fd.report_ret

# Generated at 2022-06-22 06:52:17.392904
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    import sys

    class FakeFileDownloader(FileDownloader):
        params = FileDownloader.params.copy()
        params.update(
            {
                'outtmpl': '%(id)s',
                'writedescription': True,
                'writeinfojson': True,
            }
        )

        def _sleep(self, seconds):
            pass

        def report_warning(self, message):
            raise AssertionError('Unexpected call to report_warning: %s' % message)

        def report_error(self, message, tb=None, lang=None):
            raise AssertionError('Unexpected call to report_error: %s' % message)

        def _real_download(self, filename, info_dict):
            return True


# Generated at 2022-06-22 06:52:28.715468
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import unittest
    class TestFragmentFD(unittest.TestCase):

        def setUp(self):
            self.params = {
                'format': 'best',
                'outtmpl': '%(id)s.%(ext)s',
                'restrictfilenames': True,
                'noprogress': True,
                'nooverwrites': False,
                'continuedl': True,
                'logger':  True,
            }

        def test_FragmentFD(self):
            sys.argv = ['youtubedl']
            ydl = YoutubeDL(self.params)
            ffd = FragmentFD(ydl, ydl.params)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestFragmentFD)
    un

# Generated at 2022-06-22 06:52:34.601735
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    hqd = HttpQuietDownloader({})
    assert hqd.to_screen('test') is None
    assert hqd.to_screen('test', 'error') is None
    assert hqd.to_screen('test', 'warn') is None
    assert hqd.to_screen('test', 'info') is None
    assert hqd.to_screen('test', 'debug') is None

# Generated at 2022-06-22 06:52:39.757875
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class DummyYDL(object):
        def to_screen(self, message, skip_eol=False):
            print(message)

    dl = HttpQuietDownloader(DummyYDL())
    dl.to_screen('spam')
    dl.to_screen('eggs')

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-22 06:52:45.947120
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..utils import EstFileDownloader
    ydl = EstFileDownloader({'outtmpl': '%(id)s.%(ext)s'})
    fd = FragmentFD(ydl)
    fd.report_retry_fragment(Exception('foo'), 3, 2, 3)



# Generated at 2022-06-22 06:52:58.851437
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractors
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .post import PostProcessor
    from .downloader import DashSegmentsFD
    class TestFD(HttpQuietDownloader):
        def to_screen(self, *args, **kargs):
            pass

    def my_hook(d):
        if d['status'] == 'finished':
            raise ValueError('quit it')

    gen_extractors()
    ies = list(InfoExtractor._ies)
    ie = ies[0]
    ie.download = lambda *args, **kargs: (args, kargs)
    fd = TestFD(ie, {
        'outtmpl': '%(id)s',
        'quiet': True,
    })
   

# Generated at 2022-06-22 06:53:05.135328
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class DummyYDL:
        def __init__(self):
            self.to_screen = lambda *x: None
    ydl = DummyYDL()
    h = HttpQuietDownloader(ydl, {})
    assert h._ydl is ydl


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:53:12.566275
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    from ..compat import compat_sys_stdout

    out = compat_sys_stdout()
    if sys.version_info > (3, 0):
        out = out.buffer

    dl = HttpQuietDownloader(None, None)

    dl.to_screen('foo')
    assert out.getvalue() == b''

    dl.to_screen('%s', 'bar')
    assert out.getvalue() == b''

    dl.to_screen('%s%s', 'baz', 'bang')
    assert out.getvalue() == b''


# Generated at 2022-06-22 06:53:24.616675
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .utils import TestFD
    from .extractor import get_info_extractor
    from .extractor.common import InfoExtractor

    def report_fragment(ie, fragment_index):
        ie.report_skip_fragment(fragment_index)

    for ie_name in ['dash', 'hlsnative', 'hls', 'm3u8']:
        ie = get_info_extractor(ie_name)
        assert issubclass(ie, InfoExtractor) and issubclass(ie, FragmentFD)
        ie.add_info_extractor(ie_name, [r'.'])
        test_fd = TestFD({'skip_unavailable_fragments': True})
        ie_test = ie(test_fd)
        report_fragment(ie_test, 2)
       

# Generated at 2022-06-22 06:53:57.119164
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():

    class FakeYDL():

        def __init__(self):
            self.to_stderr_value = ''

        def to_stdout(self, *args, **kargs):
            pass

        def to_stderr(self, value):
            self.to_stderr_value = value

    ydl = FakeYDL()
    HttpQuietDownloader(ydl, {'quiet': True, 'verbose': True}).to_screen('test')
    assert ydl.to_stderr_value == 'test'
    ydl.to_stderr_value = ''
    HttpQuietDownloader(ydl, {'quiet': True, 'verbose': False}).to_screen('test')
    assert ydl.to_stderr_value == ''

# Generated at 2022-06-22 06:54:08.121770
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import youtube
    # HttpQuietDownloader was designed to be used in conjunction with FragmentFD
    # (or any other subclass of FileDownloader), so we need to use a dummy
    # subclass of it
    class DummyFD(FileDownloader):
        def report_destination(self, *args, **kwargs):
            pass

    dummyfd = DummyFD()
    # Some dummy data
    info_dict = {'url': 'https://www.youtube.com/watch?v=BaW_jenozKc'}

# Generated at 2022-06-22 06:54:14.837158
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import common

    fd = FragmentFD(common.FileDownloader({'noprogress': True}), {'test': True})
    assert fd
    assert fd.params.get('test', False)
    assert fd.ydl is not None
    return fd

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:54:26.431338
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {'logger': None})
    fd.to_screen = lambda *args, **kargs: fd.retval.append(args)
    fd.retval = []
    err = Exception('ERROR MSG')
    for fragment_index in (1, 10, 100, 1000, 10000):
        for attempt in (1, 10, 100, 1000, 10000):
            fd.report_retry_fragment(err, fragment_index, attempt, (attempt,))
            assert fd.retval[-1] == (
                '[download] Got server HTTP error: ERROR MSG. '
                'Retrying fragment %s (attempt %s of %s)...'
                % (fragment_index, attempt, attempt),)

# Generated at 2022-06-22 06:54:34.637416
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    output = []
    def to_screen(message, skip_eol=False, check_quiet=False):
        output.append(message)
    class Opt:
        params = {}
    ydl = { 'params': Opt() }
    opts = { 'noprogress': True, 'quiet': True }
    h = HttpQuietDownloader(ydl, opts)
    h.to_screen = to_screen
    assert h.params['noprogress']
    assert h.params['quiet']
    assert not output
test_HttpQuietDownloader()

# Generated at 2022-06-22 06:54:39.858194
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import StringIO
    import sys

    f = StringIO.StringIO()
    sys.stdout = f
    try:
        HttpQuietDownloader.to_screen('hello world')
        assert not f.getvalue()
    finally:
        sys.stdout = sys.__stdout__

# Generated at 2022-06-22 06:54:41.266751
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass

# vim: set ts=4 sw=4 tw=0 et :

# Generated at 2022-06-22 06:54:50.253888
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(None, 1, 2, 3) == (
        '[download] Got server HTTP error: None. Retrying fragment 1 (attempt 2 of 3)...',)
    assert fd.report_retry_fragment('test', 2, 4, 6) == (
        '[download] Got server HTTP error: test. Retrying fragment 2 (attempt 4 of 6)...',)
    assert fd.report_retry_fragment(None, None, None, 1) == (
        '[download] Got server HTTP error: None. Retrying fragment None (attempt None of 1)...',)


# Generated at 2022-06-22 06:54:54.651328
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import InfoExtractors

    ie = InfoExtractors.getInstance()
    ie.add_info_extractor(FragmentFD)
    data = ie.extract('https://path/to/url', download=False)
    assert data['extractor'] == FragmentFD.ie_key()

# Generated at 2022-06-22 06:55:01.854977
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestFD(HttpQuietDownloader):
        def __init__(self):
            HttpQuietDownloader.__init__(self, None, {})
            self.messages = []
        def to_screen(self, *args, **kargs):
            self.messages.append(' '.join(args))
    tf = TestFD()
    tf.to_screen('a', 'b', 'c')
    assert tf.messages == []

# Generated at 2022-06-22 06:55:30.249736
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    ie = get_info_extractor('GenericIE', None)
    ie.extract('http://example.org')

# Generated at 2022-06-22 06:55:32.817978
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    fd = HttpQuietDownloader({}, {})
    fd.to_screen('test_HttpQuietDownloader_to_screen')

# Generated at 2022-06-22 06:55:40.818339
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # Test HLS case
    fd = FragmentFD(None)
    exceptions_tries = (
        (Exception(), 0),
        (Exception(), 1),
    )
    fd.to_screen = lambda *args: args
    assert fd.report_retry_fragment(
        Error('E1001', 'Message'), 2, exceptions_tries) == (
            '[download] Got server HTTP error: E1001 Message. '
            'Retrying fragment 2 (attempt 1 of 2)...')


# Generated at 2022-06-22 06:55:52.912235
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD

    class TestFD(HttpFD):
        def to_screen(self, s, skip_eol=False):
            sys.stdout.write(s)
            if not skip_eol:
                sys.stdout.write('\n')
            sys.stdout.flush()

    fd = TestFD({})
    # Ensure HttpQuietDownloader is child of both HttpFD and FileDownloader
    assert isinstance(HttpQuietDownloader(fd, {}), HttpFD)
    assert isinstance(HttpQuietDownloader(fd, {}), FileDownloader)

    # Ensure HttpQuietDownloader has the same constructor as its parent
    assert H

# Generated at 2022-06-22 06:55:57.110865
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractor
    test_ext = gen_extractor()
    ffd = FragmentFD(test_ext, {}, {'test': True})
    assert ffd.params['test']
    assert ffd.FD_NAME == 'generic'

# Generated at 2022-06-22 06:56:01.131964
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    fd = HttpQuietDownloader(None, None)
    fd.to_screen('*' * 79)

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-22 06:56:10.449072
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self, params, ydl):
            super(TestFragmentFD, self).__init__(params, ydl)
            self.to_screen_msgs = []
        def to_screen(self, *args, **kargs):
            self.to_screen_msgs.append(args[0])

    fd = TestFragmentFD({}, None)
    fd.report_retry_fragment(None, 343, 10, 11)
    assert fd.to_screen_msgs[0] == '[download] Got server HTTP error: None. Retrying fragment 343 (attempt 10 of 10)...'



# Generated at 2022-06-22 06:56:11.947666
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader(None, {'logger': object()})



# Generated at 2022-06-22 06:56:24.625985
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .http import HttpFD
    from .options import _fill_output_template
    from .utils import get_cachedir

    options = {
        'format': 'best',
        'verbose': False,
        'quiet': True,
    }
    cachedir = get_cachedir()

    for ee in gen_extractors():
        if not ee.IE_NAME.lower().startswith('http'):
            continue

        ie = ee()

        ie._cache = None
        ie._downloader = HttpQuietDownloader(ie, options)
        ie._sort_formats(ie.formats)
        ie._initialize_geo_bypass()

        info_dict = ie.extract(ie.urls[0])

       

# Generated at 2022-06-22 06:56:29.324007
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=W0212
    from .http import HttpFD
    HttpQuietDownloader(None, {'foo': 10, 'bar': 20}) == HttpFD(None, {'foo': 10, 'bar': 20, 'quiet': True})

# Generated at 2022-06-22 06:57:18.589469
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None)
    fd.to_screen = mock_callback
    fd.report_skip_fragment(0)
    report = global_mock_callbacks['to_screen'][-1]
    assert report == '[download] Skipping fragment 0...'

# Generated at 2022-06-22 06:57:20.865893
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Test the to_screen (not to the stdout)
    dl = HttpQuietDownloader(None, None)
    assert dl.to_screen('hi') is None



# Generated at 2022-06-22 06:57:23.346303
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    def dummy_to_screen(*args, **kargs):
        assert False

    HttpQuietDownloader(None, None).to_screen = dummy_to_screen
    assert True

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-22 06:57:29.553514
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {})
    assert hasattr(fd, 'FD_NAME')
    assert hasattr(fd, '_prepare_frag_download')
    assert hasattr(fd, '_download_fragment')
    assert hasattr(fd, '_append_fragment')
    assert hasattr(fd, '_start_frag_download')
    assert hasattr(fd, '_finish_frag_download')

# Generated at 2022-06-22 06:57:40.926929
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    from .http import HttpFD
    from .fragment import FragmentFD

    # Make sure we have a new class that we can use
    # to test the constructor of HttpQuietDownloader
    FragmentFD.FD_NAME = 'FragmentTestFD'

    class FragmentTestFD(FragmentFD):
        def __init__(self, ydl, params):
            FragmentFD.__init__(self, ydl, params)

            # Make sure the HttpQuietDownloader was properly initialized
            assert isinstance(self.dl, HttpQuietDownloader)
            assert self.dl.parameters['quiet']
            assert self.dl.parameters['noprogress']
            assert self.dl.parameters['continuedl']

# Generated at 2022-06-22 06:57:54.074176
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import io
    import unittest

    # Patch sys.stderr to redirect it to a string buffer
    err_buffer = io.StringIO()
    sys.stderr = err_buffer

    class TestFragmentFD(FragmentFD):
        FD_NAME = 'test_fd'

    fd = TestFragmentFD({}, {'usenetrc': False, 'verbose': False})
    fd.report_retry_fragment(OSError, 0, 0, 1)
    assert err_buffer.getvalue() == (
        '[test_fd] Got server HTTP error: Unknown. Retrying fragment 0 (attempt 0 of 1)...\n')
    err_buffer.truncate(0)
    err_buffer.seek(0)


# Generated at 2022-06-22 06:57:58.176040
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None, None)
    fd.to_screen = lambda x: x
    assert fd.report_skip_fragment(1) == '[download] Skipping fragment 1...'

# Generated at 2022-06-22 06:58:04.786722
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestFD(HttpQuietDownloader):
        def __init__(self):
            self.msgs = []

        def to_screen(self, msg, skip_eol=False):
            self.msgs.append(msg)

    tfd = TestFD()
    tfd.to_screen('foobar\n')
    assert tfd.msgs == []
    tfd.to_screen('foobar')
    assert tfd.msgs == ['foobar']

# Generated at 2022-06-22 06:58:16.206187
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..utils import prepend_extension
    from . import FakeYDL
    from ..extractor import get_info_extractor

    fd_class = FragmentFD
    filename = 'test_video.mp4'
    tmpfilename = fd_class.temp_name(filename)
    ytdl_filename = fd_class.ytdl_filename(filename)

    class TestFD(fd_class):
        def __init__(self):
            super(TestFD, self).__init__(FakeYDL())

        def _prepare_and_start_frag_download(self, ctx):
            # Mock extractor to avoid real download
            ctx['extractor'] = get_info_extractor('test')
            super(TestFD, self)._prepare_and_start_frag_download(ctx)

# Generated at 2022-06-22 06:58:20.002330
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestDownloader(HttpQuietDownloader):
        def report_debug(self, message):
            self.debug_message = message

    downloader = TestDownloader(None, None)
    downloader.to_screen('test')
    assert downloader.debug_message == 'test'