

# Generated at 2022-06-22 06:50:30.330824
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # pylint: disable=W0212
    hqd = HttpQuietDownloader(None, None)

    # if encoding is not set, it should not fail
    hqd._encoding = None
    hqd.to_screen('test')

    # if encoding is set, should not fail
    hqd._encoding = 'ascii'
    hqd.to_screen('test')

# Generated at 2022-06-22 06:50:36.310605
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    """
    Test that method to_screen of class HttpQuietDownloader doesn't print
    anything
    """
    # Set up test
    ydl = None
    ie = None
    params = {'extra_post_data': 'extra_post_data'}
    params.update({
        'prefer_free_formats': True,
        'format': 'best[height<=?1080]',
        'outtmpl': '%(id)s.%(ext)s',
    })

    dl = HttpQuietDownloader(ydl, params)

    # Execution
    dl.to_screen('Test message')

# Generated at 2022-06-22 06:50:48.936614
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import io
    import sys

    hqd = HttpQuietDownloader(None, {})

    # Test writing to custom stream
    custom_stream = io.BytesIO()
    hqd.to_screen('foo', file=custom_stream)
    assert custom_stream.getvalue() == b'foo\n'

    # Test writing to a custom stream does not affect
    # writing to file
    custom_stream = io.BytesIO()
    hqd.to_screen('foo')
    assert sys.stderr.getvalue() == b''

    # Test writing to sys.stderr
    hqd.to_screen('bar', file=sys.stderr)
    assert sys.stderr.getvalue() == b'bar\n'

# Generated at 2022-06-22 06:50:59.977927
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    ydl = object()
    params = object()

    class MockInfoExtractor(object):
        params = params

        def _real_extract(self, *args, **kargs):
            return {
                '_type': 'url',
                'url': 'http://example.com/file.f4m',
                'ie_key': 'F4M',
                'ext': 'f4m',
            }

    ie = MockInfoExtractor()
    ie.ydl = ydl
    get_info_extractor.extractors = [ie]

    fd = FragmentFD(ydl, params)

# Generated at 2022-06-22 06:51:07.933542
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({})
    fd.to_screen = lambda *args, **kargs: print(args, kargs)

    # HTTP 429 is throttling error
    err = Exception('HTTP Error 429: Too Many Requests')
    fd.report_retry_fragment(err, 1, 2, 3)

if __name__ == '__main__':
    import sys
    import doctest

    sys.exit(doctest.testmod().failed)

# Generated at 2022-06-22 06:51:18.874824
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from ..compat import PY2, compat_urllib_request
    from ..utils import wrap_fd
    if PY2:
        import cStringIO as io
    else:
        import io

    out = io.StringIO()

    def report_skip_fragment(self, frag_index):
        out.write('Fragment ' + str(frag_index) + ' skipped')

    # pylint: disable=protected-access
    old_rsf = FragmentFD._report_skip_fragment
    FragmentFD._report_skip_fragment = report_skip_fragment


# Generated at 2022-06-22 06:51:25.578367
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MockFD(FragmentFD):
        def __init__(self):
            self.messages = []
        def to_screen(self, message, skip_eol=False):
            self.messages.append(message)

    frag_fd = MockFD()
    frag_fd.report_skip_fragment(3)
    assert frag_fd.messages == ['[download] Skipping fragment 3...']

# Generated at 2022-06-22 06:51:31.939954
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # Initialize required attributes of FragmentFD class
    out = []
    def to_screen(self, *args, **kargs):
        out.extend(map(encodeFilename, args))
    FragmentFD.to_screen = to_screen
    fragfd = FragmentFD("")
    fragfd.report_skip_fragment(4)
    assert out == [u'Skipping fragment 4...']

# Generated at 2022-06-22 06:51:43.406769
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class MyHttpQuietDownloader(HttpQuietDownloader):
        def __init__(self, ydl):
            super(MyHttpQuietDownloader, self).__init__(ydl, {
                'quiet': True,
            })
            self.to_screen_calls = []

        def to_screen(self, *args, **kargs):
            self.to_screen_calls.append((args, kargs))

    ydl = object()
    dl = MyHttpQuietDownloader(ydl)

    dl.to_screen('something')
    dl.to_screen('something else', 'and a string', 42, key0='str0', key1='str1')

    assert len(dl.to_screen_calls) == 2
    assert dl.to_screen_calls[0]

# Generated at 2022-06-22 06:51:48.337629
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(
        None, {}, {
            'fragment_retries': 10,
            'skip_unavailable_fragments': True,
            'keep_fragments': True,
        })
    assert fd.params['fragment_retries'] == 10
    assert fd.params['skip_unavailable_fragments'] is True
    assert fd.params['keep_fragments'] is True
    assert fd.ytdl_filename('foo') == 'foo.ytdl'

# Generated at 2022-06-22 06:52:17.830304
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor.common import InfoExtractor

    class InfoTestExtractor(InfoExtractor):
        def _real_initialize(self):
            pass

    IE = InfoTestExtractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            # Tests for old buggy downloaders that may raise UnicodeDecodeError
            # when downloading
            if info_dict.get('test_no_unicode_decode_error'):
                # You may want to remove this if statement when porting your
                # extractor to the new API
                import warnings
                warnings.warn(
                    'Your extractor may raise UnicodeDecodeError when downloading, '
                    'you should fix that', stacklevel=2)

# Generated at 2022-06-22 06:52:19.137136
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader({}, {})

# Generated at 2022-06-22 06:52:30.725194
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import StringIO
    downloader = HttpQuietDownloader(
        None, {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': None,
            'retries': 0,
            'nopart': True,
            'test': False,
        }
    )
    empty_stream = StringIO.StringIO()
    sys.stdout = empty_stream
    downloader.to_screen('Test to_screen')
    sys.stdout = sys.__stdout__
    assert empty_stream.getvalue() == '', \
        'to_screen of HttpQuietDownloader class does not work properly'

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-22 06:52:36.481884
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    hqd = HttpQuietDownloader(None, {})
    assert hqd.ydl is None
    assert hqd.params == {}
    hqd = HttpQuietDownloader(None, {'foo': 'bar', 'baz': None})
    assert hqd.ydl is None
    assert hqd.params == {'foo': 'bar', 'baz': None}

# Generated at 2022-06-22 06:52:44.308400
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    def test_format_retries(retries):
        return {
            5: '5',
            0: 'infinite'
        }[retries]

    class MockLogger(object):

        def __init__(self):
            self.message = None

        def to_screen(self, message, skip_eol=False):
            self.message = message

    mocklogger = MockLogger()
    fragfd = FragmentFD(mocklogger)
    fragfd.format_retries = test_format_retries

    fragfd.report_retry_fragment(Exception(), 1, 2, 5)
    assert mocklogger.message == '[download] Got server HTTP error: UNKNOWN. Retrying fragment 1 (attempt 2 of 5)...'


# Generated at 2022-06-22 06:52:44.733492
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    pass

# Generated at 2022-06-22 06:52:47.862480
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self._screen_output = []
        def to_screen(self, *args, **kargs):
            message = args[0] % args[1:]
            self._screen_output.append(message)
    fragment_fd = TestFragmentFD()
    fragment_fd.report_retry_fragment(
        RuntimeError('fake'), 0, 1, 3)
    assert fragment_fd._screen_output == [
        '[download] Got server HTTP error: fake. Retrying fragment 0 (attempt 1 of 3)...']


# Generated at 2022-06-22 06:52:54.039729
# Unit test for constructor of class FragmentFD
def test_FragmentFD():

    # Test __init__
    fd = FragmentFD(None, {'ie_key': None, 'quiet': True, 'skip_unavailable_fragments': True})
    assert fd._ies is None
    assert fd.params['quiet'] is True
    assert fd.params['skip_unavailable_fragments'] is True

# Generated at 2022-06-22 06:52:59.430704
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .post import YoutubeDLHandler
    ie = InfoExtractor(YoutubeIE.ie_key())
    ie.extract('http://youtu.be/BaW_jenozKc')
    assert False

# Generated at 2022-06-22 06:53:04.941579
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import get_info_extractor
    from .common import InfoExtractor
    ie = InfoExtractor()
    ie.add_info_extractor(get_info_extractor('Generic'))
    dl = ie._make_downloader({
        'nocheckcertificate': True,
        'quiet': True,
        'noprogress': True,
    })

    class MockYDL(object):
        params = {
            'nocheckcertificate': True,
        }
        params.update(dl.params)

    mock_ydl = MockYDL()
    assert isinstance(dl, HttpQuietDownloader)
    assert dl.ydl is mock_ydl


# Generated at 2022-06-22 06:53:35.671957
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    from .http import HttpQuietDownloader
    stdout = sys.stdout
    class FakeFD:
        def __init__(self, filename):
            self._filename = filename
            self._file = open(filename, 'w')

        def __del__(self):
            self._file.close()

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def isatty(self):
            return False

    with FakeFD('output.txt') as outfd:
        sys.stdout = outfd
        h = HttpQuietDownloader(None, {})
        h.to_screen('abc')
        h.to_screen('def')
        sys.stdout = stdout
    outfd._file.close()
    assert open

# Generated at 2022-06-22 06:53:45.840611
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import YoutubeIE
    import sys
    import os

    if not os.path.isfile('test'):
        os.mkdir('test')
    sys.stderr = open('test/stderr', 'w')
    sys.stdout = open('test/stdout', 'w')
    ydl = YoutubeIE().download_video(
        'http://www.youtube.com/watch?v=Ik-RsDGPI5Y', 'test', {
            'writedescription': True,
            'writeannotations': True,
            'writeinfojson': True,
            'writeautomaticsub': True,
            'quiet': True,
            'noprogress': True,
        })

# Generated at 2022-06-22 06:53:49.886627
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader({}, {})
    assert ydl.params == {}
    assert ydl.add_info_dict == {}
    assert ydl.to_screen == []


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:53:52.765094
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from f4m_downloader import F4mFD
    FragmentFD(F4mFD(None, ''), {}).report_skip_fragment(1)

# Generated at 2022-06-22 06:54:02.574220
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from io import BytesIO
    from .extractor import get_info_extractor

    def check(ydl):
        buf = BytesIO()
        ydl.params['outtmpl'] = '-'
        ydl.params['logger'] = ydl
        ydl.to_stdout = buf
        ydl.download(['https://www.youtube.com/watch?v=BaW_jenozKc'])
        assert buf.getvalue() == b'[download] Destination: -\n'

    check(FileDownloader())
    check(get_info_extractor('YoutubeIE')(FileDownloader()))

# Generated at 2022-06-22 06:54:09.343198
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():

    # Stub for method 'to_screen'
    def to_screen(self, *args, **kargs):
        assert args == ('[download] Skipping fragment %d...' % 1,)

    fd = FragmentFD({})
    fd.to_screen = to_screen
    fd.report_skip_fragment(1)

# Generated at 2022-06-22 06:54:20.278797
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FakeYDL(object):
        class params(object):
            def get(self, param_name):
                assert param_name == 'retries'
                return 5
        params = params()

    ffd = FragmentFD(FakeYDL(), {})
    ffd.to_screen = lambda *args, **kwargs: print(args[0])
    ffd.report_retry_fragment('sockerr', 101, 1, 5)
    ffd.to_screen.assert_called_with(
        '[download] Got server HTTP error: sockerr. Retrying fragment 101 (attempt 1 of 5)...')


if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-22 06:54:25.952373
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    def my_to_screen(*args, **kwargs):
        assert args[0] == '[download] Skipping fragment %d...' % frag_index
    fd = FragmentFD()
    frag_index = 5
    fd.to_screen = my_to_screen
    fd.report_skip_fragment(frag_index)

# Generated at 2022-06-22 06:54:27.995755
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'


# Generated at 2022-06-22 06:54:35.240072
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    def stdout_getvalue():
        return sys.stdout.getvalue()

    import sys
    import io
    sys.stdout = io.BytesIO()
    fd = FragmentFD()
    fd.to_screen(fd.report_retry_fragment(Exception("http error"), 1, 3, 10))
    assert stdout_getvalue() == b'[download] Got server HTTP error: http error. Retrying fragment 1 (attempt 3 of 10)...\n'
    sys.stdout.close()

# Generated at 2022-06-22 06:55:19.290111
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeYDL(object):
        encoding = None
        def to_screen(self, *a, **k):
            assert a == ('message',)
            assert not k

    quiet_dl = HttpQuietDownloader(FakeYDL(), {})
    quiet_dl.to_screen('message')


if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-22 06:55:31.026130
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():

    # Verify that method report_retry_fragment displays proper message
    # to_screen method should be stubbed to check printed message

    def to_screen_stub(instance, *args, **kwargs):
        instance._to_screen_message = args[0]
        return

    import copy
    fd_instance = FragmentFD(None, copy.deepcopy(dict()))
    fd_instance._to_screen_message = None
    fd_instance.to_screen = to_screen_stub.__get__(fd_instance, FragmentFD)

    fd_instance.report_retry_fragment('error', 1, 3, 4)


# Generated at 2022-06-22 06:55:42.137109
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class MyLogger(object):
        def debug(self, msg):
            pass
    ydl = object.__new__(object)
    setattr(ydl, 'params', {})
    setattr(ydl, 'to_screen', lambda *args, **kargs: None)
    setattr(ydl, 'to_stderr', lambda *args, **kargs: None)
    setattr(ydl, 'to_console_title', lambda *args, **kargs: None)
    setattr(ydl, 'set_console_title', lambda *args, **kargs: None)
    setattr(ydl, 'logger', MyLogger())

    dl = HttpQuietDownloader(ydl, {'test': True})
    assert dl.ydl is ydl
    assert dl.params

# Generated at 2022-06-22 06:55:50.420123
# Unit test for constructor of class FragmentFD
def test_FragmentFD():

    class FakeInfo(object):
        pass

    class FakeYDL(object):
        def __init__(self):
            self.params = {}

    ydl = FakeYDL()
    ydl.params['retries'] = 2
    ydl.params['ratelimit'] = 2000
    ydl.params['nopart'] = False
    ydl.params['test'] = True
    ydl.params['keepfragments'] = True
    ydl.params['fragment_retries'] = 2
    ydl.params['skip_unavailable_fragments'] = True
    info = FakeInfo()
    info.stream_url_hls = "hls"
    info.stream_url_dash = "dash"
    info.frag_index = 0
    info.total_frags = 100

# Generated at 2022-06-22 06:55:54.810679
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    fd.to_screen_noprefix = mock.Mock()
    fd.report_skip_fragment(33)
    fd.to_screen_noprefix.assert_called_with('[download] Skipping fragment 33...')

# Generated at 2022-06-22 06:55:58.502962
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .http import HttpFD
    assert issubclass(FragmentFD, HttpFD)
    fd = FragmentFD()
    assert not fd.ydl
    assert fd.params == {}

# Generated at 2022-06-22 06:56:01.813353
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None)
    fd.to_screen = lambda *args: args
    assert fd.report_skip_fragment(2) == (
        '[download] Skipping fragment 2...',)

# Generated at 2022-06-22 06:56:06.861653
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    d = HttpQuietDownloader({}, {})
    assert d.params.get('continuedl') is True
    assert d.params.get('quiet') is True
    assert d.params.get('noprogress') is True
    assert d.params.get('nopart') is False

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:56:08.742974
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    fd.report_skip_fragment(42)

# Generated at 2022-06-22 06:56:17.079709
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class MyFragmentFD(FragmentFD):
        def __init__(self):
            self.msg = None

        def to_screen(self, msg):
            self.msg = msg

    fragmentFD = MyFragmentFD()
    fragmentFD.report_retry_fragment(
        ValueError('Value is wrong'), 1, 3, 10)
    assert fragmentFD.msg == '[download] Got server HTTP error: Value is wrong. Retrying fragment 1 (attempt 3 of 10)...'



# Generated at 2022-06-22 06:57:47.178884
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    def check_output(args):
        self, err, frag_index, count, retries = args
        self.to_stdout.truncate(0)
        self.to_stdout.seek(0)
        self.report_retry_fragment(err, frag_index, count, retries)
        return self.to_stdout.getvalue()

    class FakeYDL:
        def __init__(self):
            self.params = {}

    class FakeFD(FragmentFD):
        def __init__(self, ydl):
            self.ydl = ydl
            self.to_stdout = io.BytesIO()

    ydl = FakeYDL()
    fd = FakeFD(ydl)


# Generated at 2022-06-22 06:57:52.201363
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # here we can't test anything really, we just make sure that no errors are raised
    import sys
    fd = FragmentFD(None, None, None, {})
    fd.to_screen = sys.stdout.write
    fd.report_skip_fragment(123)

# Generated at 2022-06-22 06:57:57.132930
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = FileDownloader({'noprogress': True}, {'logger': None})
    ydl.to_screen('test')
    ydl = HttpQuietDownloader(ydl, {})
    ydl.to_screen('test')
    ydl.report_warning('test')
    ydl.report_error('test')

# Generated at 2022-06-22 06:57:59.780545
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    dl = HttpQuietDownloader(ydl, {})
    dl._do_download(False)

# Generated at 2022-06-22 06:58:02.435328
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    raise NotImplementedError(
        'Please add unit tests to %s' % __file__)

# Generated at 2022-06-22 06:58:05.430544
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # This unit test is part of the "youtube_dl/extractor/common.py" test file
    # TODO: implement
    pass

# Generated at 2022-06-22 06:58:08.558601
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {})
    assert isinstance(fd, FragmentFD)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:58:15.387901
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    ydl = object()
    fd = FragmentFD(ydl, {'logger': ydl, 'outtmpl': '%(id)s'})
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(None, 2, 1, 2) == (
        '[download] Got server HTTP error. '
        'Retrying fragment 2 (attempt 1 of 2)...', )


# Generated at 2022-06-22 06:58:24.483885
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=W0612
    try:
        from io import BytesIO as StringIO
        # pylint: disable=F0401
        from youtube_dl.compat import urlopen
    except ImportError:
        from StringIO import StringIO
        from urllib2 import urlopen
    # pylint: enable=F0401,W0612
    # pylint: disable=W0212
    from youtube_dl.YoutubeDL import YoutubeDL
    # pylint: enable=W0212
    ydl = YoutubeDL({'noprogress': True, 'quiet': True})
    dl = HttpQuietDownloader(ydl, {'noprogress': True, 'quiet': True})

# Generated at 2022-06-22 06:58:32.665151
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .dash import DASHFD
    from .hls import HLSFD
    from .hlsnative import HLSFD_Native
    from .smoothstreams import SmoothStreamsFD
    from .m3u8 import M3U8FD

    frag_fds = [
        DASHFD,
        HLSFD,
        HLSFD_Native,
        SmoothStreamsFD,
        M3U8FD,
    ]
    for frag_fd in frag_fds:
        assert issubclass(frag_fd, FragmentFD)
        assert isinstance(frag_fd(), FragmentFD)