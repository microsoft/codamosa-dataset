

# Generated at 2022-06-22 06:50:28.530696
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    obj = HttpQuietDownloader(None, None)
    obj.to_screen('foo')
    # no exception

# Generated at 2022-06-22 06:50:29.387047
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass

# Generated at 2022-06-22 06:50:36.740644
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    def my_hook(d):
        # pylint: disable=unused-argument
        my_hook.count += 1
        if my_hook.count >= 2:
            raise ValueError('my hook')

    my_hook.count = 0
    params = {
        'fragment_retries': 1,
        'keep_fragments': True,
        'skip_unavailable_fragments': True,
    }
    hqdl = HttpQuietDownloader(None, {})
    assert hqdl.params == {}
    hqdl = HttpQuietDownloader(None, params)
    assert hqdl.params == params
    assert hqdl.report_error == HttpQuietDownloader.to_screen
    assert not hqdl.to_stderr_fn
    hqdl

# Generated at 2022-06-22 06:50:49.599428
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from io import StringIO
    from ..downloader.common import FileDownloader
    from ..compat import compat_getenv

    class FakeYDL(FileDownloader):
        pass

    fake_ydl = FakeYDL(params={})
    fake_ydl.to_stdout = StringIO()
    fake_ydl.params['outtmpl'] = u'%(title)s-%(id)s.%(ext)s'
    fake_ydl.params['simulate'] = True
    fake_ydl.params['quiet'] = True
    fake_ydl.params['forcetitle'] = True
    fake_ydl.params['format'] = u'flv - 320x240'
    fake_ydl.params['usenetrc'] = False

# Generated at 2022-06-22 06:51:00.132792
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFD(FragmentFD):  # noqa: N801
        def _start_frag_download(self, ctx):
            return ctx

        def report_retry_fragment(self, err, frag_index, count, retries):
            pass

        def report_skip_fragment(self, frag_index):
            pass

    myfd = MyFD({
        'quiet': True,
        'noprogress': True,
        'ratelimit': 1024,
        'retries': 3,
        'nopart': True,
    })
    ctx = myfd._prepare_frag_download({
        'filename': 'test.mp4',
        'total_frags': 10,
    })
    assert ctx['total_frags'] == 10



# Generated at 2022-06-22 06:51:03.148804
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    inst = FragmentFD({})
    assert inst.ydl == None
    assert inst.params == {}

# Generated at 2022-06-22 06:51:06.151572
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = None
    hd = HttpQuietDownloader(ydl, {})
    hd.to_screen(u'string')

# Generated at 2022-06-22 06:51:06.864807
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass

# Generated at 2022-06-22 06:51:11.629621
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.to_screen = lambda *args, **kargs: None
    ydl = FakeYDL()
    hqd = HttpQuietDownloader(ydl, {})
    hqd.to_screen('foo')

# Generated at 2022-06-22 06:51:18.785587
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=protected-access
    assert FragmentFD('dummy1', {}).fragment_retries == 10
    assert FragmentFD('dummy2', {'fragment_retries': 8}).fragment_retries == 8
    assert FragmentFD('dummy3', {'fragment_retries': 0}).fragment_retries == 0
    assert FragmentFD('dummy4', {'fragment_retries': -1}).fragment_retries == 0
    # pylint: enable=protected-access

# Generated at 2022-06-22 06:51:47.109546
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import StringIO

    ydl = None

# Generated at 2022-06-22 06:51:58.231231
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        def __init__(self, *args, **kwargs):
            super(MyFragmentFD, self).__init__(*args, **kwargs)

        def real_download(self, filename, info_dict):
            pass

    fd = MyFragmentFD({})
    assert fd.params['keep_fragments'] is False
    assert fd.params['fragment_retries'] == 10
    assert fd.params['skip_unavailable_fragments'] is False

    fd = MyFragmentFD({'keep_fragments': True, 'fragment_retries': 20})
    assert fd.params['keep_fragments'] is True
    assert fd.params['fragment_retries'] == 20

# Generated at 2022-06-22 06:52:00.502119
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    """Test that the to_screen method of HttpQuietDownloader does not work"""
    downloader = HttpQuietDownloader(None, {})
    assert not downloader.to_screen('Test message')

# Generated at 2022-06-22 06:52:13.225295
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor import get_info_extractor
    from .common import InfoExtractor

    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: (args, kargs)
    fd.format_retries = lambda *args, **kargs: 2

    assert (
        ('[download] Got server HTTP error: dummy. Retrying fragment 3 (attempt 1 of 2)...', {'encode': True}),
        {'encode': True}) == fd.report_retry_fragment(
            'dummy', 3, 1, {'max_retries': 2, 'retries': 0})

# Generated at 2022-06-22 06:52:22.331442
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FakeYDL(object):
        def __init__(self):
            self.to_screen = []
        def to_screen(self, msg):
            self.to_screen.append(msg)

    class FakeFD(FragmentFD):
        def __init__(self, ydl):
            self.ydl = ydl

    ydl = FakeYDL()
    fd = FakeFD(ydl)
    fd.report_skip_fragment(666)
    assert ydl.to_screen == ['[download] Skipping fragment 666...']

# Generated at 2022-06-22 06:52:33.206928
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # pylint: disable=invalid-name
    # Method to be tested
    def report_skip_fragment(self, frag_index):
        return FragmentFD.report_skip_fragment(self, frag_index)

    # Create instance of class TestFD and attach the method to be tested
    testFD = TestFD()
    testFD.report_skip_fragment = report_skip_fragment

    # Test with frag_index = 1
    frag_index = 1
    testFD.to_screen = MagicMock()
    expected = "[download] Skipping fragment 1..."
    report_skip_fragment(testFD, frag_index)
    testFD.to_screen.assert_called_with(expected)


# Generated at 2022-06-22 06:52:41.579165
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({}, {})
    fd.to_screen = lambda *args, **kargs: None
    error = OSError(5, "Input/output error")
    # No retries
    fd.report_retry_fragment(error, 2, 1, 0)
    fd.report_retry_fragment(error, 2, 2, 0)
    # 3 retries
    fd.report_retry_fragment(error, 2, 1, 3)
    fd.report_retry_fragment(error, 2, 2, 3)
    fd.report_retry_fragment(error, 2, 3, 3)
    fd.report_retry_fragment(error, 2, 4, 3)
    # 3 retries max
   

# Generated at 2022-06-22 06:52:52.034490
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # Test with logging disabled
    import logging
    class DummyYoutubeDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen = lambda *args, **kargs: None
        @staticmethod
        def to_stderr(message):
            logging.error(message)
    params = {'logger': logging.getLogger()}
    params['logger'].addHandler(logging.StreamHandler())
    params['logger'].setLevel(logging.ERROR)
    fd = FragmentFD(DummyYoutubeDL(params), params)
    fd.report_skip_fragment(1)
    assert not logging.getLogger().handlers

# Generated at 2022-06-22 06:53:05.597836
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import get_info_extractor

    class MyHttpQuietDownloader(HttpQuietDownloader):
        def report_retry_fragment(self, err, frag_index, count, retries):
            pass

        def report_skip_fragment(self, frag_index):
            pass

    # Test that method to_screen of class HttpQuietDownloader does not output anything
    ydl = get_info_extractor('youtube', None)
    ydl.params['noprogress'] = False
    fragment_downloader = MyHttpQuietDownloader(
        ydl,
        {
            'continuedl': True,
            'noprogress': False,
            'retries': 0,
            'nopart': False,
            'test': False,
        }
    )



# Generated at 2022-06-22 06:53:13.073628
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """
    Test that HTTP-downloader without progress is created properly
    """
    class FakeOptions:
        def __init__(self):
            self.__dict__ = {
                'verbose': False,
                'ratelimit': 30,
                'retries': 0,
                'nopart': False,
                'test': False,
            }
    dl = HttpQuietDownloader(FakeOptions(), {'continuedl': True, 'quiet': True})
    assert dl.params['continuedl'] == True
    assert dl.params['quiet'] == True
    assert dl.params['verbose'] == False

# Generated at 2022-06-22 06:53:57.761834
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD

    DASHFD.report_retry_fragment = HttpFD.report_retry_fragment
    HLSFD.report_retry_fragment = HttpFD.report_retry_fragment

    for fd_cls in (DASHFD, HLSFD):
        fd = fd_cls(HttpFD())
        fd.params['retries'] = 1
        fd.report_retry_fragment(Exception('Foo'), 1, 1, fd.params['retries'])
        fd.params['retries'] = 2

# Generated at 2022-06-22 06:54:08.045149
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    start_time = time.time() - 1.1  # 1.1 second ago
    fd_options = {
        'fragment_retries': 10,
        'skip_unavailable_fragments': True,
    }
    fd_params = {
        'restrictfilenames': True,
        'noprogress': False,
        'continuedl': True,
        'nooverwrites': False,
        'ratelimit': None,
        'retries': 10,
        #'test': True,  # uncomment this to view output in the console
    }
    fd = FragmentFD(
        _FakeYDL({}), {}, fd_params, fd_options,
        start_time=start_time)

    # Case 1. Retries <= max_retries
   

# Generated at 2022-06-22 06:54:18.979125
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class FakeYoutubeDL():
        def download(self, filename, info_dict):
            return False

    class FakeFD(FragmentFD):
        def __init__(self, ydl, params):
            FragmentFD.__init__(self, ydl, params)

        def _prepare_frag_download(self, ctx):
            pass

        def _start_frag_download(self, ctx):
            pass

    ydl = FakeYoutubeDL()
    fd = FakeFD(ydl, {'noprogress': True})
    fd.report_progress = False
    fd._download_fragment({'fragment_index': 2}, 'url', {})

# Generated at 2022-06-22 06:54:30.865631
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    def t(url, *options):
        ydl = FakeYDL()
        fd = HttpQuietDownloader(ydl, {'quiet': True})
        fd.add_info_extractor(FakeIE(url))
        fd._real_download(url, *options)
        return ydl.params

    def t_none(url, *options):
        t(url, *options)

    def t_tuple(url, *options):
        return t(url, *options)

    def t_dict(url, *options):
        return t(url, *options)[0]

    # Test that HttpQuietDownloader accepts all the keyword arguments
    # that FileDownloader accepts
    t_none('url', 'title')
    t_none('url', {'noplaylist': True})
   

# Generated at 2022-06-22 06:54:38.979513
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .downloader.http import HttpDownloader

    def test_downloader(ydl, params=None):
        return HttpDownloader(ydl, params)

    gen_extractors(test_downloader)
    ydl = test_downloader({}, {})
    dl = ydl.get_downloader('http', 'http://example.com/video')
    assert isinstance(dl, HttpQuietDownloader)

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:54:51.312435
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys

    class MyFragmentFD(FragmentFD):
        def format_retries(self, retries):
            return '%d' % (retries + 1)
    # Use a fixed timestamp to force discrepancy between time.time() outputs
    class time_mock:
        @staticmethod
        def time():
            return 123456789.12345
    sys.modules['time'] = time_mock

    ffd = MyFragmentFD(None, {})

    class observer:
        values = []
        def write(self, value):
            self.values.append(value)
    stdout_observer = observer()
    stderr_observer = observer()


# Generated at 2022-06-22 06:55:02.950648
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .http import HttpFD
    fd = FragmentFD(HttpFD(), {})
    fd.params = {'noprogress': True}

    # Test for invalid args
    for args in [
        [],
        ['message', 1],
    ]:
        assert 'Test failed for args %s' % str(args) in fd.report_retry_fragment(*args)

    assert 'message Retrying fragment 1 (attempt 0 of 7)...' in fd.report_retry_fragment('message', 1, 0, 7)
    assert 'message Retrying fragment 2 (attempt 1 of 11)...' in fd.report_retry_fragment('message', 2, 1, 11)
    assert 'message Retrying fragment 3 (attempt 2 of 111)...' in fd.report_retry_

# Generated at 2022-06-22 06:55:05.404678
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader

    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-22 06:55:11.473215
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import StringIO
    f = StringIO.StringIO()
    fd = FragmentFD(None, None)
    fd.to_screen = lambda *args, **kargs: f.write(' '.join([error_to_compat_str(a) for a in args]) + '\n')
    fd.report_skip_fragment(42)
    f.seek(0)
    assert f.read() == '[download] Skipping fragment 42...\n'

# Generated at 2022-06-22 06:55:21.294901
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FakeYDL:
        def __init__(self):
            self.to_screen = []

        def to_screen(self, msg):
            self.to_screen.append(msg)

        def trouble(self, msg, tb=None):
            self.trouble_msg = msg
            self.trouble_tb = tb

    ydl = FakeYDL()
    fd = FragmentFD(ydl, {
    })

    fd.report_skip_fragment(3)
    assert ydl.to_screen == ['[download] Skipping fragment 3...']
    ydl.to_screen = []

# Generated at 2022-06-22 06:56:41.019830
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    fd.retries = 4
    fd.to_screen = lambda s: print(s)
    fd.report_retry_fragment(ValueError('err'), 4, 2, 4)
# End of unit test for method report_retry_fragment of class FragmentFD


# Generated at 2022-06-22 06:56:50.827833
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractor
    from .mtaftpd import test_download
    # suppress warnings
    import warnings; warnings.filterwarnings('ignore')

    class YoutubeDL(object):
        params = {
            'noprogress': True,
        }

    def _print_to_stdout(message, skip_eol=False, check_quiet=False):
        print(message)

    dl = HttpQuietDownloader(YoutubeDL(), {
        'noprogress': True,
        'quiet': True,
    })
    dl.to_screen('test')
    YoutubeDL.params['noprogress'] = False
    dl.to_screen('test')

    # Test HDS download

# Generated at 2022-06-22 06:56:55.923846
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    print('Testing method report_retry_fragment')
    fd = FragmentFD(None)
    fd.to_screen = lambda *args: print(*args)
    fd.report_retry_fragment('err', 1, 2, 100)
    print('PASS')


# Generated at 2022-06-22 06:57:00.203689
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    f = FragmentFD()
    class _ScreenWriter(object):
        def __init__(self):
            self.actual = None
            self.expected = None

        def set_expected(self, expected):
            self.expected = expected

        def assert_output(self):
            assert self.actual == self.expected

        def write(self, msg):
            if self.expected:
                assert msg == self.expected
            self.actual = msg
    sw = _ScreenWriter()
    f.to_screen = sw.write
    sw.set_expected('[download] Skipping fragment 1...')
    f.report_skip_fragment(1)
    sw.assert_output()

# Generated at 2022-06-22 06:57:08.033857
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from tempfile import mkdtemp
    from shutil import rmtree
    from .downloader import sanitize_open

    class YD(object):
        params = {
            'noprogress': True,
        }
        def to_screen(self, *args, **kargs):
            print(args[0] % args[1:])

    tmpdir = mkdtemp()
    ydl = YD()
    fd = HttpQuietDownloader(ydl, {'continuedl': True, 'noprogress': True, 'nopart': True})
    fd.params['outtmpl'] = tmpdir + '/%(title)s-%(id)s.%(ext)s'

    # Test regular print message
    fd.to_screen('hello')
    # Test encoding
   

# Generated at 2022-06-22 06:57:18.736555
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor import gen_extractors
    from .downloader.http import HttpDL
    from .downloader.external import ExternalFD
    from .downloader.fragment import FragmentFD

    class MockYoutubeDL(object):
        params = {}
        _ies = []
        to_screen = sys.stderr.write
        to_stdout = to_screen

        def add_info_extractor(self, ie):
            self._ies.append(ie)

    class MockIE(object):
        IE_NAME = 'MockIE'
        _WORKING = True

        def working(self):
            return self._WORKING

        def _real_initialize(self):
            pass

    ie = MockIE()
    MockYoutubeDL().add_info_extractor(ie)
   

# Generated at 2022-06-22 06:57:26.259484
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Pylint is confused by pyscaffold's structure
    # pylint: disable=no-member
    from youtube_dl.Version import __version__
    from youtube_dl.YoutubeDL import YoutubeDL

    opts = {
        'quiet': False,
        'ratelimit': '12345',
        'retries': 23,
        'nopart': True,
        'test': True,
        'version': __version__,
    }

    # This is pyscaffolds's way to get optparse options
    for opt in YoutubeDL.option_list:
        opts[opt.dest] = opt.default

    ydl = YoutubeDL(opts)
    hqd = HttpQuietDownloader(ydl, {'continuedl': True})

# Generated at 2022-06-22 06:57:29.005610
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = object()
    params = {}
    dl = HttpQuietDownloader(ydl, params)
    dl.to_screen('Test message')

# Generated at 2022-06-22 06:57:36.300147
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FakeFD(FragmentFD):
        def __init__(self):
            self.to_screen_strs = []
        def to_screen(self, *strs):
            self.to_screen_strs.extend(strs)
    fd = FakeFD()
    fd.report_skip_fragment(42)
    assert fd.to_screen_strs == ['[download] Skipping fragment 42...']


# Generated at 2022-06-22 06:57:48.285179
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Catch the output sent to stdout by HttpQuietDownloader.to_screen
    import sys
    output = []
    def fake_print(s, file=None):
        output.append(s)

    # Save stderr
    stderr = sys.stderr
    # Redirect sys.stdout
    sys.stderr = sys.stdout = fake_print

    # Create and test the downloader
    d = HttpQuietDownloader(None, None)
    d.to_screen('hello', 'world')
    d.to_screen('hello %s', 'you!')
    d.to_screen('hello %s', 'you!', 'how', 'are', 1, 2, 'four', 'five')

    assert output == []

    # Restore stdout and stderr
    sys.st