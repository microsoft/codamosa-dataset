

# Generated at 2022-06-22 06:50:34.407421
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .utils import formatted_print
    from .compat import bytes_to_str
    from io import BytesIO
    from sys import version_info as sys_version_info

    # Some python version/configuration doesn't display non-ascii characters,
    # and some python version/configuration doesn't display color chars.
    # We check that both are displayed properly
    def check_output(text):
        return formatted_print(bytes_to_str(text))

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloads=None, params=None):
            self._downloads = downloads
            self._params = params or {}
            super(FakeInfoExtractor, self).__init__()


# Generated at 2022-06-22 06:50:35.746848
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Test no arg constructor
    FragmentFD(None, {})

# Generated at 2022-06-22 06:50:48.666419
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from ..utils import IS_PY2
    # We need to simulate a youtube-dl instance
    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.to_stderr = sys.stderr
        def trouble(self, *args, **kargs):
            pass
        def report_warning(self, *args, **kargs):
            pass
        def report_error(self, *args, **kargs):
            pass
    ydl = FakeYDL()
    fd = FragmentFD(ydl, {})
    assert fd.params == {}
    assert fd.ydl == ydl
    assert fd.to_screen == ydl.to_stderr.write
    assert fd.report_error == ydl.report_

# Generated at 2022-06-22 06:50:59.924844
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.test_ctx = {
                'calls': [],
            }
            self.FD_NAME = 'test'

        def _prepare_frag_download(self, ctx):
            ctx.update(self.test_ctx)
            ctx['fragment_index'] = 1

        def _start_frag_download(self, ctx):
            ctx['fragment_index'] = 2
            return 1.23

        def _finish_frag_download(self, ctx):
            ctx['fragment_index'] = 3


# Generated at 2022-06-22 06:51:06.583133
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    class FakeIE(InfoExtractor):
        IE_NAME = 'fake'
    ydl = FakeIE._create_downloader({})

    # Check class and superclass construction
    assert isinstance(FragmentFD(ydl, {})._downloader, FakeIE)
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-22 06:51:14.883247
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader(
        {
            'continuedl': False,
            'quiet': True,
            'noprogress': True,
            'outtmpl': '%(id)s%(ext)s',
            'test': True,
        }
    )
    assert dl.params.get('continuedl') is False
    assert dl.params.get('quiet') is True
    assert dl.params.get('noprogress') is True
    assert dl.params.get('outtmpl') == '%(id)s%(ext)s'
    assert dl.params.get('test') is True

# Generated at 2022-06-22 06:51:16.622106
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-22 06:51:29.209855
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .downloader import YoutubeDL
    from .extractor import get_info_extractor

    def test_ie_output(ie, ie_result, expected_output_re, expected_retcode):
        ie.extract = lambda *args: ie_result
        fd = FragmentFD(YoutubeDL(), {'simulate': True})
        fd.params['outtmpl'] = '%(id)s'
        assert fd.params['nooverwrites']

        fd.add_info_extractor(ie)
        sim_data = {}
        fd.to_screen = lambda *args, **kargs: sim_data.update({'screen': [args, kargs]})
        fd.report_warning = lambda msg: sim_data.update({'warning': msg})

# Generated at 2022-06-22 06:51:39.304399
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
# pylint: disable=unused-variable
    class FakeInfoDict(object):
        pass
    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s.%(ext)s'
            }
    ydl = FakeYDL()
    info_dict = FakeInfoDict()
    info_dict.upload_date = '20140101'
    info_dict.id = 'test_download'
    info_dict.ext = 'mp4'
    tfd = FragmentFD(ydl, info_dict)
# pylint: enable=unused-variable

# Generated at 2022-06-22 06:51:48.085610
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .helpers import FakeYDL
    from ..extractor.common import InfoExtractor

    class TestIE(InfoExtractor):
        IE_NAME = 'test_ie'
        IE_DESC = 'Dummy IE for testing'
        _VALID_URL = r'/'

        def _real_extract(self, url):
            return {
                'title': 'test video',
                'url': 'http://example.com/video.flv',
            }

    t = TestIE.suitable(TestIE._build_url('/'))
    assert t

    ydl = FakeYDL()
    ie = TestIE(ydl, {})
    fd = FragmentFD(ydl, {})

    # Test not live video
    ie.extract('/')
    fd.params['nopart']

# Generated at 2022-06-22 06:52:17.105116
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractors, get_info_extractor, list_extractors
    from .downloader.external import ExternalFD
    from .downloader.rtmp import RTMPFD
    from .utils import FakeYDL
    fd = HttpFD(FakeYDL(), {})
    # Test behavior of to_screen
    # Test messages to log
    assert fd.to_screen('log message') is None
    assert fd.to_screen('warning', 'log message') is None
    assert fd.to_screen('error', 'log message') is None
    # Test messages to stdout
    assert fd.to_screen('message') == 'message\n'
    assert fd.to_screen('warning', 'message') == 'WARNING: message\n'

# Generated at 2022-06-22 06:52:22.179170
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {})  # Just run the constructor
    fd.params = {'outtmpl': '%(id)s.%(ext)s', 'restrictfilenames': True}
    assert fd.temp_name('abc-def.flv') == 'abc-def.flv.part'

# Generated at 2022-06-22 06:52:22.834198
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-22 06:52:34.550135
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io
    from .common import _make_fake_info_dict

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'skip_fragments': False,
            }

        class FakeOpts(object):
            def __init__(self, params):
                self.params = params

        def params_get(self, key, default=None):
            return self.params[key] if key in self.params else default

        def params_set(self, key, value):
            self.params[key] = value

        def add_info_extractor(self, ie):
            pass

        def add_post_processor(self, pp):
            pass

    ydl = FakeYDL()
    output = io.BytesIO()
    fd = Frag

# Generated at 2022-06-22 06:52:42.719425
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    out = []
    fs = FragmentFD({
        'outtmpl': '-',
        'skip_fragments': True,
        'quiet': True,
    }, {}, {}, None)
    fs.to_screen = lambda *args, **kargs: out.extend(args)
    fs.report_skip_fragment(0)
    fs.report_skip_fragment(1)
    fs.report_skip_fragment(2)
    fs.report_skip_fragment(12)
    fs.report_skip_fragment(1234)
    fs.report_skip_fragment(12345)
    fs.report_skip_fragment(123456)
    fs.report_skip_fragment(1234567)

# Generated at 2022-06-22 06:52:47.756689
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FragmentFD2(FragmentFD):
        def to_screen(self, *args, **kargs):
            FragmentFD2.printed = args
    fd = FragmentFD2()
    fd.report_skip_fragment(2)
    assert FragmentFD2.printed == ('[download] Skipping fragment 2...',)

# Generated at 2022-06-22 06:52:56.226002
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None)
    fd.to_screen = lambda *args, **kargs: args
    fd.format_retries = lambda x: 'formatted:%d' % x
    assert fd.report_retry_fragment(
        err='some error', frag_index=3, count=5, retries=8) == (
            '[download] Got server HTTP error: some error. Retrying fragment 3 (attempt 5 of formatted:8)...',
    )


# Generated at 2022-06-22 06:53:01.412733
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors, list_extractors
    from .postprocessor import gen_pp
    from .downloader.common import FileDownloader

    ydl = FileDownloader()

    # Check extractors
    for ie in gen_extractors():
        ie.ydl = ydl

    # Check postprocessors
    for pp in gen_pp():
        pp.ydl = ydl


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:53:06.286428
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {}
    params = {'continuedl': True, 'noprogress': True, 'quiet': True}
    dl = HttpQuietDownloader(ydl, params)
    assert dl.params == params


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:53:16.401367
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class Parser():
        def __init__(self):
            self.params = {
                'writesubtitles': False,
                'writeautomaticsub': False,
                'writeinfojson': False,
                'writethumbnail': False,
                'skip_download': True,
            }

    class InfoExtractor():
        def __init__(self):
            self._downloader = None

        @property
        def downloader(self):
            if not self._downloader:
                self._downloader = HttpQuietDownloader(Parser(), {})
            return self._downloader

    info_extractor = InfoExtractor()
    # Compat with python 2.6
    if not hasattr(info_extractor.downloader, 'to_screen'):
        return

    info_dict = {}
    # Check

# Generated at 2022-06-22 06:53:54.435094
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: None
    fd.report_retry_fragment(None, 1, 5, 3)



# Generated at 2022-06-22 06:53:59.755776
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    assert (
        fd.report_retry_fragment(Exception('error message'), 1, 1, 2)
        == '[download] Got server HTTP error: error message. Retrying fragment 1 (attempt 1 of 2)...'
    )

# Generated at 2022-06-22 06:54:06.353675
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():

    class MockFD(FragmentFD):
        def __init__(self):
            self.to_screen_msg = None
        def to_screen(self, msg):
            self.to_screen_msg = msg

    frag_fd = MockFD()
    frag_fd.report_skip_fragment(42)
    assert frag_fd.to_screen_msg == '[download] Skipping fragment 42...'

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-22 06:54:07.775701
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    HttpQuietDownloader.to_screen(HttpQuietDownloader, 'starting')

# Generated at 2022-06-22 06:54:16.091315
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None)
    fd.to_screen = lambda x: x
    assert fd.report_skip_fragment(0) == '[download] Skipping fragment 0...'
    assert fd.report_skip_fragment(24) == '[download] Skipping fragment 24...'
    assert fd.report_skip_fragment(42) == '[download] Skipping fragment 42...'
    assert fd.report_skip_fragment('abc') == '[download] Skipping fragment abc...'

# Generated at 2022-06-22 06:54:27.780648
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import YoutubeDL

    def _download_fragment_tester(ctx):
        def _prepare_frag_download(ctx):
            ctx.update({
                'tmpfilename': 'tmpfilename_value',
                'dest_stream': 'dest_stream_value',
                'dl': 'dl_value',
                'started': 'started_value',
            })
        def _finish_frag_download(ctx):
            self.assertEqual(ctx['started'], 'started_value')
            self.assertEqual(ctx['tmpfilename'], 'tmpfilename_value')
            self.assertEqual(ctx['dest_stream'], 'dest_stream_value')
            self.assertEqual(ctx['dl'], 'dl_value')
        ydl = YoutubeDL({})
        ydl.add_

# Generated at 2022-06-22 06:54:31.286183
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # pylint: disable=line-too-long
    from .smoke.test_fragment import test_FragmentFD_report_skip_fragment as smoke_test
    smoke_test(FragmentFD)

# Generated at 2022-06-22 06:54:42.502363
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import io
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    stderr = 'stderr'
    stdout = 'stdout'
    with captured_output() as (out, err):
        HttpQuietDownloader(None, {}).to_screen(stderr, False)
        HttpQuietDownloader(None, {}).to_

# Generated at 2022-06-22 06:54:53.984114
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    if sys.version_info < (3, 0):
        from io import BytesIO as DataIO
    else:
        from io import BytesIO as DataIO
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HlsFD
    from .http import HttpQuietDownloader
    from .fragment import FragmentFD
    # class HttpQuietDownloader(HttpFD):
    #     def to_screen(self, *args, **kargs):
    #         pass
    class InMemFileDownloader(FileDownloader):
        def __init__(self, *args, **kwargs):
            super(InMemFileDownloader, self).__init__(*args, **kwargs)
            self._data = DataIO

# Generated at 2022-06-22 06:55:01.010293
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .common import FileDownloader
    from .http import HttpFD

    class TestFD(FileDownloader):
        def to_screen(self, *args, **kargs):
            self.screen_out = args[0]

    ydl = TestFD({'verbose': False})
    dl = HttpQuietDownloader(ydl, {})
    dl.to_screen('test')
    assert not ydl.screen_out

# Generated at 2022-06-22 06:56:25.333501
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from types import ModuleType
    m = ModuleType('test')
    m.params = {}
    m.params['continuedl'] = False
    m.to_screen = lambda *args, **kargs: None
    m.report_error = m.to_screen
    m.report_warning = m.to_screen
    m.report_destination = m.to_screen
    m.temp_name = lambda *args: None
    m.try_rename = lambda *args: None
    m.add_extra_info = lambda *args: None
    m.calc_eta = lambda *args: None
    m.hook_progress = lambda *args, **kargs: None
    m.ytdl_filename = lambda *args: None

# Generated at 2022-06-22 06:56:32.746200
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class YoutubeDL(object):
        def trouble(self, message, tb=None):
            raise AssertionError(message)

    ydl = YoutubeDL()

    hqd = HttpQuietDownloader(ydl, {})
    assert hqd._opener is not None

    hqd.to_screen('foo')

    hqd._failed_resumption_attempts = 100
    hqd.trouble('trouble')

# Generated at 2022-06-22 06:56:44.075886
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor import get_info_extractor
    from .extractor.common import InfoExtractor
    import sys
    import io
    import tempfile
    import shutil

    IE_NAME = 'test_ie'
    IE_DESC = 'Test IE for FragmentFD'

    old_stdout = sys.stdout
    sys.stdout = io.BytesIO()
    ie = InfoExtractor(IE_NAME, IE_DESC)
    xfd = get_info_extractor(IE_NAME)
    fragmentfd = xfd()

# Generated at 2022-06-22 06:56:55.927127
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import io

    class FragmentFD_stdout_bytes(FragmentFD):
        def __init__(self, ydl):
            FragmentFD.__init__(self, ydl)
            self.to_screen = self._to_stdout_bytes
            self.stdout = io.BytesIO()

        def _to_stdout_bytes(self, out):
            self.stdout.write('%s\n' % (out.encode('utf-8', 'ignore')))

    ydl = lambda: None
    fd = FragmentFD_stdout_bytes(ydl)
    err = TypeError('Something went wrong')
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# Generated at 2022-06-22 06:56:59.460327
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpDownloader
    ydl = HttpDownloader({'noprogress': True})
    test_HttpQuietDownloader.__test__ = False
    assert isinstance(ydl, HttpDownloader)

# Generated at 2022-06-22 06:57:06.245999
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    def dummy_hook(dummy):
        pass
    import youtube_dl
    ydl = youtube_dl.YoutubeDL({})
    dl = HttpQuietDownloader(ydl, ydl.params)
    assert dl.ydl is ydl
    assert dl.params is ydl.params
    assert dl.report_error == ydl.report_error
    assert not dl.to_screen
    assert dl.to_stderr == ydl.to_stderr
    assert dl.sleep_interval == ydl.sleep_interval
    assert dl._hook_progress == dummy_hook
    assert dl._hook_download_rate == dummy_hook
    assert dl._hook_temp_file == dummy_hook
    assert dl._hook_retry == dummy_hook

# Generated at 2022-06-22 06:57:16.897336
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import StringIO
    buf = StringIO.StringIO()
    buf_err = StringIO.StringIO()
    frag_fd = FragmentFD(None, {'outtmpl': ''})
    frag_fd.to_screen = buf.write
    frag_fd.to_stderr = buf_err.write
    frag_fd.report_skip_fragment(42)
    sys.stderr = sys.__stderr__
    out = buf.getvalue()
    err = buf_err.getvalue()
    buf.close()
    buf_err.close()
    assert out == '[download] Skipping fragment 42...\n'
    assert err == ''

# Generated at 2022-06-22 06:57:22.589243
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    ydl = object()
    params = {
        'noprogress': True
    }
    fd = FragmentFD(ydl, params)
    fd.to_screen = lambda *args, **kargs: None
    fd.report_retry_fragment(Exception(), 1, 2, 3)
    fd.report_retry_fragment(Exception(), 30, 40, 50)
    fd.report_retry_fragment(Exception(), 1, 1000, 2000)
    fd.report_retry_fragment(Exception(), 1000000, 1000000, 1000000)

# Generated at 2022-06-22 06:57:24.588189
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None)
    help(fd.report_retry_fragment)

# Generated at 2022-06-22 06:57:29.158800
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # Make sure report_skip_fragment works
    fd = FragmentFD()
    fd.to_screen = lambda *args: args
    assert fd.report_skip_fragment(1) == (
        '[download] Skipping fragment 1...',
    )
