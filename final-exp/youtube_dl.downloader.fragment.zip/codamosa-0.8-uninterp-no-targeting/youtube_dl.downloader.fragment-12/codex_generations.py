

# Generated at 2022-06-22 06:50:35.150222
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {})
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(
        None, 100, 1, {'max_retries': 1}) == (
            "[download] Got server HTTP error: None. Retrying fragment 100 (attempt 1 of 1)...",)
    assert fd.report_retry_fragment(
        'error', 100, 1, {'max_retries': 1}) == (
            "[download] Got server HTTP error: error. Retrying fragment 100 (attempt 1 of 1)...",)

# Generated at 2022-06-22 06:50:42.042059
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {}, None)

    out, err = _capture_output(fd.report_skip_fragment, 42)
    assert out == '[download] Skipping fragment 42 ...\n'
    assert not err

    err = _capture_output(fd.report_skip_fragment, None)[1]
    assert err.startswith('[FragmentFD] Unexpected place')


# Generated at 2022-06-22 06:50:45.810946
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader(None, {})

    # Check format of output of method to_screen
    ydl.to_screen('test')


# Generated at 2022-06-22 06:50:50.556059
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    assert FragmentFD().report_retry_fragment(
        ValueError('error message'), 10, 1, 5) == [
            '[download] Got server HTTP error: error message. '
            'Retrying fragment 10 (attempt 1 of %s)...' % FragmentFD.format_retries(5)]

# Generated at 2022-06-22 06:50:53.577007
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = FileDownloader(params={})
    hqd = HttpQuietDownloader(ydl, {'quiet': True})
    assert hqd.to_screen('test') is None

# Generated at 2022-06-22 06:51:01.560634
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FragmentFD(FragmentFD):
        def __init__(self):
            self.tos = []
        def to_screen(self, msg):
            self.tos.append(msg)

    fd = FragmentFD()
    fd.report_skip_fragment(42)

    assert fd.tos == ['[download] Skipping fragment 42...']


if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-22 06:51:13.421355
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    reload(sys)
    sys.setdefaultencoding('UTF-8')
    def _decode_compat_str(s):
        if isinstance(s, bytes):
            return s.decode('ascii')
        else:
            return s
    dl = HttpQuietDownloader(None, {'quiet': True})
    dl.to_screen('[download] Downloading video %d of %d' % (1, 2))
    assert dl._screen_file.getvalue() == _decode_compat_str('[download] Downloading video %d of %d\n') % (1, 2)
    dl.to_screen('[download] Downloading video %d of %d' % (1, 2), ' ')
    assert dl._screen_file.getvalue()

# Generated at 2022-06-22 06:51:22.739573
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=no-member
    params = dict(
        format='best',
        outtmpl='%(id)s.%(ext)s',
        ratelimit=None,
        retries=None,
        continuedl=True,
        noprogress=True,
        quiet=True,
        no_warnings=True,
        skip_unavailable_fragments=True,
        keep_fragments=True,
        include_ads=True,
    )
    class _InfoExtractor(object):
        downloader = None
        def __init__(self):
            self._available_subtitles = dict()
            self._subtitles_filename = dict()
    ie = _InfoExtractor()
    fd = FragmentFD(ie, params)

# Generated at 2022-06-22 06:51:27.234251
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    fd.to_screen = lambda *args, **kargs: False
    assert fd.report_skip_fragment(0) == None
    assert fd.report_skip_fragment(5) == None

# Generated at 2022-06-22 06:51:31.353381
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # method to_screen of class HttpQuietDownloader just returns None
    hqd = HttpQuietDownloader(None, {'continuedl': True})
    assert hqd.to_screen() is None

# Generated at 2022-06-22 06:52:01.814219
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class YDL(object):
        def to_screen(self, s):
            print(s)

    ydl = YDL()
    hqd = HttpQuietDownloader(ydl, {})
    hqd.to_screen('test')


if __name__ == '__main__':
    import sys
    sys.exit(test_HttpQuietDownloader_to_screen())

# Generated at 2022-06-22 06:52:14.952864
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        FD_NAME = 'testfd'

    fd = TestFD({}, None)
    fd.report_warning = lambda msg: None
    fd.to_screen = lambda msg: None
    fd.report_destination = lambda filename: None

    ctx = {
        'total_frags': 5,
        'filename': 'test.mp4',
        'dl': HttpQuietDownloader(fd, {'continuedl': True, 'quiet': True, 'noprogress': True}),
    }

    _, filename = sanitize_open('test.tmp', 'wb')
    ctx['dl'].download(filename, {})
    open(fd.ytdl_filename('test.mp4'), 'w').close()

# Generated at 2022-06-22 06:52:19.706437
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    ydl = FakeYoutubeDl()
    fd = FragmentFD(ydl)
    fd.to_screen = lambda x: x
    fd.report_skip_fragment(1)
    assert ydl.msgs == ['[download] Skipping fragment 1...']


# Generated at 2022-06-22 06:52:27.893094
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FragmentDummy(FragmentFD):
        def __init__(self):
            self.to_screen_out = []

        def to_screen(self, s):
            self.to_screen_out.append(s)

    fd = FragmentDummy()
    fd.report_retry_fragment(Exception('abc'), 123, 456, [1, 0])
    assert fd.to_screen_out == ['[download] Got server HTTP error: abc. Retrying fragment 123 (attempt 456 of 1)...']

# Generated at 2022-06-22 06:52:38.511808
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from ..extractor import get_info_extractor

    class FakeInfoExtractor(object):
        IE_NAME = 'test'

        def __init__(self, *args, **kargs):
            pass

        def _real_initialize(self):
            pass
    get_info_extractor(FakeInfoExtractor)
# Workaround for https://bugs.python.org/issue9400
# get_info_extractor doesn't work correctly without it
    FakeInfoExtractor.suitable = lambda *x: True

    class FakeYDL(object):
        params = {}

    ydl = FakeYDL()
    ie = FakeInfoExtractor()
    ie.ydl = ydl
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    dl.to_screen('test')

# Generated at 2022-06-22 06:52:40.183071
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-22 06:52:52.280959
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    import io
    import sys

    old_stdout = sys.stdout
    stream = io.StringIO()
    sys.stdout = stream

    class TestIE(InfoExtractor):
        def __init__(self):
            InfoExtractor.__init__(self, {})
        def _real_extract(self, url):
            return {'id': 'video_id', 'ext': 'mp4'}
    extractor = TestIE()

    extractor._print_info_debug('test')
    assert stream.getvalue() == 'test\n'

    extractor._downloader = HttpQuietDownloader(
        extractor,
        {
            'quiet': True,
        },
    )
    extractor._downloader.to_screen('test')


# Generated at 2022-06-22 06:52:57.201093
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    try:
        from io import StringIO
    except ImportError:
        # Python 2.x compatibility
        from cStringIO import StringIO

    output = StringIO()
    downloader = HttpQuietDownloader(None, {'progress_hooks': [], 'outtmpl': '-'})
    downloader.to_stdout = output
    downloader.to_screen('hello', 'world')
    assert output.getvalue() == ''
    downloader.to_screen('hello world')
    assert output.getvalue() == ''
    downloader.to_screen()
    assert output.getvalue() == ''

    # Reset
    output.truncate(0)
    downloader.to_screen(force_print=True)
    assert output.getvalue() == '\n'

    # Reset and test non-string argument

# Generated at 2022-06-22 06:53:01.108634
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader, YoutubeDL
    ydl = YoutubeDL({'noprogress': True, 'logger': FileDownloader()})
    dl = HttpQuietDownloader(ydl, {})
    assert dl.ydl is ydl



# Generated at 2022-06-22 06:53:10.083923
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class HttpQuietDownloaderT(HttpQuietDownloader):
        def __init__(self, *args, **kwargs):
            super(HttpQuietDownloaderT, self).__init__(*args, **kwargs)
            self.__messages = []

        def _write_string(self, s):
            self.__messages.append(s)

    ydl = object()
    dl = HttpQuietDownloaderT(ydl, {})

    dl.to_screen('test message')

    assert len(dl._HttpQuietDownloader__messages) == 0

# Generated at 2022-06-22 06:53:52.118856
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD

    class TestFragmentFD(FragmentFD):
        def __init__(self, ydl, params):
            FileDownloader.__init__(self, ydl, params)
            HttpFD.__init__(self, ydl, params)

    assert issubclass(TestFragmentFD, FragmentFD)
    assert issubclass(TestFragmentFD, FileDownloader)
    assert issubclass(TestFragmentFD, HttpFD)
    assert isinstance(TestFragmentFD(None, None), TestFragmentFD)

# Generated at 2022-06-22 06:54:03.857346
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None, None)
    err = KeyError('foo')
    ret = fd.report_retry_fragment(err, frag_index=0, count=1, retries=5)
    assert ret is None
    assert fd.screen_data() == ''
    fd.to_screen = lambda *args, **kargs: args
    ret = fd.report_retry_fragment(err, frag_index=1, count=3, retries=0)
    assert ret[0] == ('[download] Got server HTTP error: foo. '
                      'Retrying fragment 1 (attempt 3 of infinite)...')
    assert ret[1:] == ()
    assert fd.screen_data() == ''
    fd.to_screen = lambda *args, **kargs: args

# Generated at 2022-06-22 06:54:06.156433
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader is not None

# Generated at 2022-06-22 06:54:16.012975
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class InfoDict(object):
        def __init__(self, d):
            self.__dict__.update(d)
    ydl = None
    params = {
        'quiet': True,
        'noprogress': True,
        'outtmpl': 'filename%(fragment_index)s',
        'nooverwrites': True,
    }
    info_dict = InfoDict({
        'url': '',
    })
    fragment_retries = 0
    fd = FragmentFD(ydl, params, info_dict, fragment_retries)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-22 06:54:20.075518
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = object()
    opts = {'foo': 'bar'}
    dl = HttpQuietDownloader(ydl, opts)
    assert dl.ydl is ydl
    assert dl.params == opts
    assert dl.report_destination is None

# Generated at 2022-06-22 06:54:30.704540
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class _FragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, *args):
            # Make args a single string for easier assertions
            arg = ' '.join(args)
            self.to_screen_calls.append(arg)

    fd = _FragmentFD()
    fd.report_retry_fragment(
        IOError('Connection aborted'), 1, 1, fd.params.get('retries', 0))
    assert fd.to_screen_calls == [
        '[download] Got server HTTP error: Connection aborted. Retrying fragment 1 (attempt 1 of 3)...']



# Generated at 2022-06-22 06:54:32.157028
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass

# Generated at 2022-06-22 06:54:33.797551
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    x = HttpQuietDownloader(FileDownloader())
    assert isinstance(x, HttpFD)

# Generated at 2022-06-22 06:54:35.499845
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloaderTest

    test = FileDownloaderTest()
    test.test_FragmentFD(FragmentFD)

# Generated at 2022-06-22 06:54:39.238371
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD({})
    assert fd.params == {'noprogress': True, 'quiet': True}

# Generated at 2022-06-22 06:55:23.339778
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import StringIO

    class FragmentFDTest(FragmentFD):
        ydl = None
        params = {'skip_download': True}
        params_get = None

        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params
            self.to_screen_buffer = StringIO.StringIO()
            FragmentFD.__init__(self, ydl, params)

        # Don't actually write to sys.stderr
        def to_stderr(self, message):
            pass


# Generated at 2022-06-22 06:55:24.801757
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .options import Option
    fd = FragmentFD(Option({}), None)
    assert fd.FD_NAME is None

# Generated at 2022-06-22 06:55:30.148920
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFD(FragmentFD):
        def to_screen(self, *args, **kargs):
            self.out = args[0]

    tf = TestFD({})
    tf.report_skip_fragment(444)
    return tf.out == '[download] Skipping fragment 444...'

# Generated at 2022-06-22 06:55:37.782807
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpQuietDownloader
    from .extractor import YoutubeIE
    options = {
        'continuedl': True,
        'noprogress': True,
        'nopart': False,
        'retries': 0,
        'test': False,
    }
    ydl = HttpQuietDownloader(YoutubeIE(), options)
    assert ydl.ydl is YoutubeIE()
    assert ydl.params == options

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-22 06:55:43.234974
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFD(FragmentFD):
        def to_screen(self, *args, **kargs):
            self.report_skip_fragment_message = args[0]
    fd = TestFD({}, {}, {})
    fd.report_skip_fragment(42)
    assert fd.report_skip_fragment_message == '[download] Skipping fragment 42...'



# Generated at 2022-06-22 06:55:52.463500
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    def test_screen(msg):
        test_screen.message = msg
    ytdl = FileDownloader(params={
        'username': 'user',
        'password': 'none',
    })
    ytdl.to_screen = test_screen
    h = HttpQuietDownloader(ytdl, {'noprogress': True})
    h.download('test', {'url': 'testurl'})
    assert test_screen.message == (
        '[download] Destination: test\n[download] 100% of 0.00MiB in 00:00')

# Generated at 2022-06-22 06:56:02.901475
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda x: x

    def assertEqualMsg(got, expected):
        if got != expected:
            raise AssertionError('Got:\n  %r\nExpected:\n  %r' % (got, expected))

    assertEqualMsg(fd.report_retry_fragment(None, 1, 1, 10),
        '[download] Got server HTTP error: UNKNOWN. Retrying fragment 1 (attempt 1 of 10)...')
    assertEqualMsg(fd.report_retry_fragment('what an error!', 2, 4, 5),
        '[download] Got server HTTP error: what an error!. Retrying fragment 2 (attempt 4 of 5)...')

# Generated at 2022-06-22 06:56:12.833213
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import tempfile
    from ..compat import compat_getenv
    from ..extractor import get_info_extractor

    def get_testcases():
        # Get a test case from the environment
        tcname = compat_getenv('TEST_CASE')
        if tcname:
            for t in test_cases:
                if tcname == t[0]:
                    return [t]
            else:
                sys.exit('ERROR: cannot find test case %r' % tcname)

        return test_cases

    def get_suite():
        def _make_suite(tc):
            tc_name, ie_name, ie_params, ie_url, expected_title = tc
            def gen_testcase(tc):
                def testcase(self):
                    # Get the extractor object
                    ie = get

# Generated at 2022-06-22 06:56:20.458059
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader


# Generated at 2022-06-22 06:56:26.138218
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    try:
        from io import StringIO
        # Python 2
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    log = StringIO()
    HttpQuietDownloader(None, {
        'outtmpl': '%(id)s'
    }).to_screen('progress bar')
    assert log.getvalue() == ''

# Generated at 2022-06-22 06:57:40.766321
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    ydl = None
    fd = FragmentFD(ydl, {})
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(
        IOError('test'), 1, 3, {'max_retries': 5}) == (
            '[download] Got server HTTP error: test. '
            'Retrying fragment 1 (attempt 3 of 5)...',)
    assert fd.report_retry_fragment(
        IOError('test'), 1, None, {'max_retries': 5}) == (
            '[download] Got server HTTP error: test. '
            'Retrying fragment 1 (attempt 2 of 5)...',)

# Generated at 2022-06-22 06:57:41.488670
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-22 06:57:54.500123
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    test_cases = [
        # description, err, frag_index, count, retries, expected_value
        ('err=None, count=1', None, 1, 1, 5, '[download] Fragment #1 failed, retrying (1 of 5)...'),
        ('err=Exception, count=1', Exception, 1, 1, 5, '[download] Fragment #1 failed, retrying (1 of 5)...'),
        ('err=Exception, count=2', Exception, 1, 2, 5, '[download] Fragment #1 failed, retrying (2 of 5)...'),
        ('err=Exception, count=1, retries=1', Exception, 2, 1, 1, '[download] Fragment #2 failed, retrying (1 of 1)...'),
    ]

# Generated at 2022-06-22 06:58:05.601328
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Default instantiation
    instance = HttpQuietDownloader(
        None,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'retries': 0,
            'nopart': False,
        }
    )
    assert isinstance(instance, HttpQuietDownloader)

    # Custom instantiation
    kwargs = {
        'test': True,
        'ratelimit': 1,
    }
    instance = HttpQuietDownloader(
        None,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'retries': 0,
            'nopart': False,
        }
    )

# Generated at 2022-06-22 06:58:12.664306
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.initialize()
    url = 'http://example.com/video.mp4'
    ie.add_info_extractor(type(ie))
    ie.extract(url)
    ie.report_warning('warning')
    ie.report_error('error')
    ie.raise_ies_exception(ValueError('val_error'))
    ie.to_screen('hello world!')

# Generated at 2022-06-22 06:58:16.366082
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    fd.to_screen = lambda *args, **kargs: args

    assert fd.report_skip_fragment(1) == (
        '[download] Skipping fragment 1...',)
    assert fd.report_skip_fragment(12) == (
        '[download] Skipping fragment 12...',)
    assert fd.report_skip_fragment(123) == (
        '[download] Skipping fragment 123...',)

# Generated at 2022-06-22 06:58:26.690953
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class DummyYDL(object):
        params = {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': None,
            'retries': 0,
            'nopart': False,
            'test': False,
        }

    dl = HttpQuietDownloader(DummyYDL(), {})
    assert dl.params == {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }

# Generated at 2022-06-22 06:58:30.847345
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FragmentFDTest(FragmentFD):
        def to_screen(self, msg):
            self.message = msg
    fft = FragmentFDTest()
    index = 1
    fft.report_skip_fragment(index)
    assert 'Skipping fragment %d...' % index == fft.message

# Generated at 2022-06-22 06:58:33.173869
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..YoutubeDL import YoutubeDL
    # If this does not raise an exception, everything is OK
    HttpQuietDownloader(YoutubeDL(), {})

# Generated at 2022-06-22 06:58:43.874705
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestDownloader(HttpQuietDownloader):
        def __init__(self):
            self.msgs = []
            self.to_stderr_msgs = []
            self.to_screen_msgs = []

        def to_stderr(self, msg):
            self.msgs.append(msg)
            self.to_stderr_msgs.append(msg)

        def to_screen(self, msg):
            self.msgs.append(msg)
            self.to_screen_msgs.append(msg)

    dl = TestDownloader()
    dl.to_screen('text')
    assert dl.msgs == []
    assert dl.to_screen_msgs == []
    assert dl.to_stderr_msgs == []

    dl.params