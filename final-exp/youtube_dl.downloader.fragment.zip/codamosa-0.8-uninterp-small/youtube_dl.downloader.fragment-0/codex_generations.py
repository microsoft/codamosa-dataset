

# Generated at 2022-06-26 11:13:45.975352
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'y+\x06\x0f\x00,p\nI\x0b\x00\x1f2\x15`\x00(^\x1c\x04\x00\x1d2\x15`\x00)^\x1c\x04\x00\x1a2\x15`\x00'
    list_0 = [str_0]
    fragment_fd_0 = FragmentFD(str_0, list_0)
    var_0 = fragment_fd_0.to_screen()

# Generated at 2022-06-26 11:13:51.501494
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'h\x0c|`1UYx^oP'
    list_0 = []
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, list_0)
    return var_0


# Generated at 2022-06-26 11:14:00.453288
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'jf\x12\x17Yi\x0e\\\\6U\x1b\x00\x18\x01\x10\x11\x18\x01\x170\x1b\x00\x1f\n'
    str_1 = ' \x00\x0fYU\x10U\x1b\x00\x18\x01\x10\x11\x18\x01\x17\x1f\x00\x1f\x03\x05'
    str_2 = '\r\r\rRR\r\r\r'
    str_3 = '\r\r\r\r\r\r'

# Generated at 2022-06-26 11:14:07.193708
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'acAnN\x0c|`1UYx^oP'
    dict_0 = {}
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, dict_0)
    str_0 = 'acAnN\x0c|`1UYx^oP'
    http_quiet_downloader_0.to_screen()


# Generated at 2022-06-26 11:14:10.217912
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    int_0 = 0
    # for i in range (int_0, 100000):

    test_case_0()


# Generated at 2022-06-26 11:14:14.983314
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'acAnN\x0c|`1UYx^oP'
    list_0 = []
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, list_0)


# Generated at 2022-06-26 11:14:20.470056
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Global variables (unlikely to be overwritten)
http_quiet_downloader_0 = None

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:14:21.581929
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    obj = FragmentFD()
# Constructor test done


# Generated at 2022-06-26 11:14:30.566996
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'P?\x1aO,\x0f\x01\x1f\x03?|!\x1a\x14\r\r'
    list_0 = []
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, list_0)
    assert 'wsls' == http_quiet_downloader_0.http_class.__name__
    assert 'to_screen' == http_quiet_downloader_0.to_screen.__name__
    assert 'P?\x1aO,\x0f\x01\x1f\x03?|!\x1a\x14\r\r' == http_quiet_downloader_0.ydl



# Generated at 2022-06-26 11:14:31.371565
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:14:54.954951
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd = FragmentFD(None)
    assert isinstance(fragment_fd, FragmentFD)


# Generated at 2022-06-26 11:14:57.556144
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    obj = FragmentFD('youtube-dl', {})
    test_case_0()
    return obj

# Generated at 2022-06-26 11:15:00.215334
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:15:06.794338
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    hfd = FragmentFD('url', 'ydl')
    assert hfd.params['noprogress'] == False
    assert hfd.params['progress_with_newline'] == False
    assert hfd.report_destination == hfd.real_report_destination


# Generated at 2022-06-26 11:15:10.091739
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():

    if (__name__ == "__main__"):
        test_case_0()
    
    # Test case for method HttpQuietDownloader.to_screen
    test_HttpQuietDownloader_to_screen_0()
    

# Generated at 2022-06-26 11:15:11.505901
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    obj_0 = HttpQuietDownloader()

# Generated at 2022-06-26 11:15:24.099152
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Test function int_0 from test_case_0
    int_0 = test_case_0()
    # Test constructor
    obj0 = HttpQuietDownloader(int_0, int_0)
    # Test attribute ydl
    # Test attribute params
    # Test method add_progress_hook
    obj0.add_progress_hook(int_0)
    # Test method to_screen
    obj0.to_screen(int_0, int_0)
    # Test method to_stderr
    obj0.to_stderr(int_0)
    # Test method trouble
    obj0.trouble(int_0, int_0)
    # Test method report_warning
    obj0.report_warning(int_0)
    # Test method report_error

# Generated at 2022-06-26 11:15:31.804706
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    int_0 = 0
    str_1 = 'youtube-dl'
    dict_2 = {'test': True, 'ratelimit': None, 'retries': 0, 'nopart': False, 'continuedl': True, 'quiet': True, 'noprogress': True}
    obj_3 = HttpQuietDownloader(str_1, dict_2)
    obj_4 = obj_3._YDLDownloader__downloader
    obj_5 = obj_3._YDLDownloader__ydl
    int_6 = obj_3._YDLDownloader__process
    int_7 = obj_3._YDLDownloader__params
test_HttpQuietDownloader.test_case_0 = test_case_0
test_HttpQuietDownloader.test_case_1 = test_case_0
test_Http

# Generated at 2022-06-26 11:15:33.718462
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    out_FragmentFD = FragmentFD(ydl=dict(), params=dict())


# Generated at 2022-06-26 11:15:35.270876
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # TODO
    # Setup
    # test_case_0()
    pass


# Generated at 2022-06-26 11:16:08.287188
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

if __name__ == '__main__':
    # test_HttpQuietDownloader()
    # test_FragmentFD()
    pass

# Generated at 2022-06-26 11:16:11.656297
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'Kvx#'
    list_0 = []
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, list_0)
    var_0 = http_quiet_downloader_0.to_screen()



# Generated at 2022-06-26 11:16:13.255234
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:16:17.973732
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'nv`0o\x06v0\x1d\x1fz6'
    dict_0 = {}
    dict_0['fragment_retries'] = 0
    fragment_fd_0 = FragmentFD(str_0, dict_0)
    var_0 = fragment_fd_0.__prepare_frag_download()
    var_1 = fragment_fd_0.__do_ytdl_file()
    var_2 = fragment_fd_0.__do_ytdl_file()
    var_3 = fragment_fd_0.__do_ytdl_file()
    var_4 = fragment_fd_0.__do_ytdl_file()
    var_5 = fragment_fd_0.__do_ytdl_file()
    var_6

# Generated at 2022-06-26 11:16:29.245576
# Unit test for constructor of class FragmentFD

# Generated at 2022-06-26 11:16:34.617972
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'C:E?\x7f-\x1d~\x19\x1e'
    list_0 = [ ]
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, list_0)
    assert_equal(http_quiet_downloader_0.retries, 3)

test_case_0()

# Generated at 2022-06-26 11:16:36.264244
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:16:43.358362
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    #print("Unit test for constructor of class FragmentFD")
    test_case_0()
    #test_case_1()
    #test_case_2()
    #test_case_3()
    #test_case_4()
    #test_case_5()
    #test_case_6()
    #test_case_7()
    #test_case_8()
    #test_case_9()
    #test_case_10()
    #test_case_11()
    #test_case_12()
    #test_case_13()
    #test_case_14()
    #test_case_15()
    #test_case_16()
    #test_case_17()
    #test_case_18()
    #test_case_19()
    #test_case

# Generated at 2022-06-26 11:16:50.552297
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Initialize a dictionary of arguments that can be passed to the constructor:
    test_args_0 = {}

    # Pass the dictionary of arguments to the constructor:
    test_instance_0 = FragmentFD(**test_args_0)
    # Unit test function FragmentFD.test_case_0()
    test_instance_0.test_case_0()


# Generated at 2022-06-26 11:16:53.026687
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD()

if __name__ == "__main__":
   # execute only if run as a script
    test_FragmentFD()

# Generated at 2022-06-26 11:17:41.300499
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = ''
    params = {}
    http_fd_0 = HttpQuietDownloader(ydl, params)
    var_0 = http_fd_0.to_screen()


# Generated at 2022-06-26 11:17:46.043700
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()

# Test case for method report_retry_fragment in class FragmentFD

# Generated at 2022-06-26 11:17:47.758116
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:17:52.376997
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'acAnN\x0c|`1UYx^oP'
    str_1 = 'acAnN\x0c|`1UYx^oP'
    list_0 = []
    fragment_fd_0 = FragmentFD(str_0, str_1, list_0)
    test_case_0()

# Generated at 2022-06-26 11:17:57.267554
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'V\x13\x15\x10\x17\x19'
    list_0 = []
    fragment_fd_0 = FragmentFD(str_0, list_0)
    var_0 = fragment_fd_0.report_skip_fragment()


# Generated at 2022-06-26 11:17:59.963195
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'acAnN\x0c|`1UYx^oP'
    list_0 = []
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, list_0)
    var_0 = http_quiet_downloader_0.to_screen()
    assert False


# Generated at 2022-06-26 11:18:07.115736
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert FragmentFD.__name__ == 'FragmentFD'
    fragment_fd_0 = FragmentFD('youtube-dl', 'None')
    assert (fragment_fd_0.__class__ is FragmentFD)
    assert (fragment_fd_0.FD_NAME == 'youtube-dl')
    assert (fragment_fd_0.params == 'None')
    assert (fragment_fd_0.temp_names_append_extension is False)



# Generated at 2022-06-26 11:18:11.747727
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        assert True
        test_case_0()
        test_case_1()
        test_case_2()
    except:
        print('Test failed')
    else:
        print('Test completed')


# Generated at 2022-06-26 11:18:12.804036
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:18:13.696970
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:19:43.689769
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

test_HttpQuietDownloader()

# Generated at 2022-06-26 11:19:53.095292
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'f"G?6,i\x1aA.oKV7C'
    var_1, var_2 = FragmentFD.__do_ytdl_file(str_0)
    var_3 = FragmentFD.calc_eta(str_0)
    var_4 = FragmentFD.download(str_0)
    var_5 = FragmentFD.format_eta(str_0)
    var_6 = FragmentFD.format_retries(str_0)
    var_7 = FragmentFD.from_screen(str_0)
    var_8 = FragmentFD.get_basename(str_0)
    var_9 = FragmentFD.get_filename(str_0)
    var_10 = FragmentFD.get_infos(str_0)


# Generated at 2022-06-26 11:19:57.119042
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'acAnN\x0c|`1UYx^oP'
    list_0 = []
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, list_0)
    var_0 = http_quiet_downloader_0.to_screen()


# Generated at 2022-06-26 11:20:00.815273
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = '0|0C\x7f\x0fr\x7f\x0f\x7f\x0f'
    list_0 = []
    fragment_fd_0 = FragmentFD(str_0, list_0)
    assert fragment_fd_0._FragmentFD__do_ytdl_file(list_0)

# Generated at 2022-06-26 11:20:03.409313
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        test_case_0()
    except Exception as e:
        print('FAIL: line number: %d, error: %s' % (sys.exc_info()[2].tb_lineno, str(e)))
    else:
        print('PASS')


# Generated at 2022-06-26 11:20:05.753463
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragmentfd_0 = FragmentFD('test')
    fragmentfd_0.sg_config.update(**{'verbosity': 0})
    fragmentfd_0.to_screen = lambda *args, **kargs: None
    test_case_0()


# Generated at 2022-06-26 11:20:11.935319
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'acAnN\x0c|`1UYx^oP'
    list_0 = []
    fragmentfd_0 = FragmentFD(str_0, list_0)
    var_0 = fragmentfd_0.report_skip_fragment()
    var_1 = fragmentfd_0.__do_ytdl_file()
    var_2 = fragmentfd_0._read_ytdl_file()
    var_3 = fragmentfd_0._write_ytdl_file()
    var_4 = fragmentfd_0._download_fragment()
    var_5 = fragmentfd_0._append_fragment()
    var_6 = fragmentfd_0._prepare_frag_download()
    var_7 = fragmentfd_0._start_frag_download()
   

# Generated at 2022-06-26 11:20:21.742896
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'Y|`1UY>^RK&'
    list_0 = []
    fragment_fd_0 = FragmentFD(str_0, list_0)
    # Method call to function _download_fragment() of class FragmentFD
    result = fragment_fd_0._download_fragment(str_0, list_0)
    # Method call to class FragmentFD
    fragment_fd_0.to_screen()
    # Method call to function _start_frag_download() of class FragmentFD
    result = fragment_fd_0._start_frag_download(str_0)
    # Method call to function _finish_frag_download() of class FragmentFD
    result = fragment_fd_0._finish_frag_download(str_0)
    # Method call

# Generated at 2022-06-26 11:20:23.082455
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD()
    assert isinstance(fragment_fd_0, FragmentFD)

# Generated at 2022-06-26 11:20:26.979344
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'lA_\x11'
    list_0 = []
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, list_0)
    var_0 = http_quiet_downloader_0.to_screen()
    return var_0
