

# Generated at 2022-06-26 11:13:40.272140
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert_equals(
        HttpQuietDownloader('', {})._ydl,
        '')


# Generated at 2022-06-26 11:13:47.326013
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    http_quiet_downloader_0 = HttpQuietDownloader('I<\x1e\x1c\x1d\x1a', {'http_header_through_put': '<\x1e\x1c\x1d\x1a'})
    fragment_fd_0 = FragmentFD(http_quiet_downloader_0, 'http://jrjzrpnrjrjrzr.com/')

if __name__ == '__main__':
    try:
        test_case_0()
        test_FragmentFD()
    except Exception:
        pass

# Generated at 2022-06-26 11:13:48.788734
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()



# Generated at 2022-06-26 11:13:56.892095
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'H?&!=\x7fdyd\x03i\x00b'
    dict_0 = {str_0: str_0}
    fragment_fd_0 = FragmentFD(str_0, dict_0)
    str_0 = 'H?&!=\x7fdyd\x03i\x00b'
    dict_0 = {str_0: str_0}
    fragment_fd_1 = FragmentFD(str_0, dict_0)

if __name__ == '__main__':
    test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:14:04.126037
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'R]b\n{'
    dict_0 = {str_0: str_0}
    fragment_fd_0 = FragmentFD(str_0, dict_0)


# Generated at 2022-06-26 11:14:14.442098
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = '\x07\x06\x02\x01\x0b\x03\x00\x07\x04\x07\n\x08\x0b\x07'
    bool_0 = False
    bool_1 = False
    dict_0 = {str_0: bool_0, 'keep_fragments': bool_0, 'test': bool_0, 'skip_unavailable_fragments': bool_1, 'fragment_retries': bool_1}
    fragmentfd_0 = FragmentFD(str_0, dict_0)
    assert str_0 == fragmentfd_0.FD_NAME
    bool_0 = bool_0
    bool_1 = bool_1
    assert bool_0 == bool_1
    str_1 = 'FragmentFD'
    fragment

# Generated at 2022-06-26 11:14:17.723072
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

test_HttpQuietDownloader()

# Generated at 2022-06-26 11:14:19.307470
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:14:20.846136
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:14:28.994141
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD()
    str_0 = 'eb g,[\x0cy)<2aW9G$'
    dict_0 = {str_0: str_0}
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, dict_0)
    fragment_fd_0._prepare_frag_download(http_quiet_downloader_0)
    fragment_fd_0._start_frag_download(http_quiet_downloader_0)
    fragment_fd_0._finish_frag_download(http_quiet_downloader_0)


# Generated at 2022-06-26 11:14:53.954953
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Main entry point of this module
if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:14:59.925530
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    quiet_downloader_0 = HttpQuietDownloader('', {'test': True, 'noprogress': True, 'continuedl': False, 'ratelimit': 18000, 'retries': 1, 'nopart': True})
    print('Quiet Downloader Object: {}'.format(quiet_downloader_0))


# Generated at 2022-06-26 11:15:04.728374
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_1 = '\x05\x1f\x18]\x0e'
    http_quiet_downloader_1 = HttpQuietDownloader(str_1, str_1)

# Generated at 2022-06-26 11:15:07.763277
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'H?&!=\x7fdyd\x03i\x00b'
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, str_0)
    str_1 = http_quiet_downloader_0.config
    assert(str_0 == str_1)


# Generated at 2022-06-26 11:15:11.079830
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'H?&!=\x7fdyd\x03i\x00b'
    http_qu_d_0 = HttpQuietDownloader(str_0, str_0)


# Generated at 2022-06-26 11:15:14.398722
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = '6\x77\x02\x0c\x0c'
    http_quiet_downloader = HttpQuietDownloader(str_0, str_0)


# Generated at 2022-06-26 11:15:19.114554
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'H?&!=\x7fdyd\x03i\x00b'
    http_quiet_d_0 = HttpQuietDownloader(str_0, str_0)


# Generated at 2022-06-26 11:15:20.044431
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # TODO: write unit test
    assert 1


# Generated at 2022-06-26 11:15:23.763207
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_q_d_0 = HttpQuietDownloader(str_0, dict_0)
    var_0 = isinstance(http_q_d_0, HttpQuietDownloader)
    assert var_0


# Generated at 2022-06-26 11:15:31.607610
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    url = 'http://example.com'
    # Invalid values for argv
    try:
        fragment_f_d_0 = FragmentFD(url, 0)
        assert False
    except TypeError:
        pass
    try:
        fragment_f_d_0 = FragmentFD(url, "")
        assert False
    except TypeError:
        pass
    try:
        fragment_f_d_0 = FragmentFD(url, [])
        assert False
    except TypeError:
        pass
    try:
        fragment_f_d_0 = FragmentFD(url, {})
        assert False
    except TypeError:
        pass
    # Valid values for argv
    fragment_f_d_0 = FragmentFD(url, url)

# Generated at 2022-06-26 11:16:16.963717
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'v'
    bytes_0 = None
    tuple_0 = (bytes_0,)
    boolean_0 = FragmentFD.http_error(str_0, tuple_0)
    # assert boolean_0
    print(boolean_0)
    str_1 = 'v'
    bytes_1 = None
    tuple_1 = (bytes_1,)
    FragmentFD.report_critical(str_1, tuple_1)
    print()

if __name__ == "__main__":
    test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:16:17.614514
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:16:18.215084
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:16:23.683681
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    str_0 = 'categories'
    fragment_fd_0 = FragmentFD(tuple_0, str_0)
    assert isinstance(fragment_fd_0, FragmentFD)

if __name__ == "__main__":
    #_test()
    pass

# Generated at 2022-06-26 11:16:34.761111
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    filename = 'test.txt'
    # Call test method
    test_case_0()
    # Test FragmentFD class's constructor

# Generated at 2022-06-26 11:16:35.740794
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:16:37.731176
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    # Test case to execute
    test_FragmentFD()

# Generated at 2022-06-26 11:16:40.811603
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_quiet_downloader_0 = HttpQuietDownloader()
    assert isinstance(http_quiet_downloader_0, HttpQuietDownloader)
    test_case_0()

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:16:41.811440
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:16:42.813691
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # test case 0
    test_case_0()

# Generated at 2022-06-26 11:18:13.685787
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    str_0 = 'categories'
    fragmentFD_0 = FragmentFD(tuple_0, str_0)
    var_0 = fragmentFD_0.to_screen()
    fragmentFD_0.report_retry_fragment('error_0', 1, 1, 1)
    fragmentFD_0.report_skip_fragment(1)
    str_1 = 'url_0'

# Generated at 2022-06-26 11:18:20.212024
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    str_0 = 'categories'
    fragment_fd_0 = FragmentFD(tuple_0, str_0)
    fragment_fd_0.test()
    bytes_0 = None
    tuple_0 = (bytes_0,)
    str_0 = 'categories'
    fragment_fd_0 = FragmentFD(tuple_0, str_0)
    fragment_fd_0.test()

if __name__ == '__main__':
    test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:18:22.084454
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # test constructor
    # first parameter is a tuple, second is a string, then an object is created
    test_case_0()


# Generated at 2022-06-26 11:18:22.870180
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:18:23.713821
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:18:33.781363
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    tuple_0 = (None,)
    str_0 = 'categories'
    fragment_fd_0 = FragmentFD(tuple_0, str_0)
    fragment_fd_1 = FragmentFD(tuple_0, str_0)
    # AssertionError:  != 
    assert fragment_fd_0.YDLSHUTDOWN != fragment_fd_1.YDLSHUTDOWN
    # AssertionError:  != 
    assert fragment_fd_0.FD_NAME != fragment_fd_1.FD_NAME
    # AssertionError:  != 
    assert fragment_fd_0.params != fragment_fd_1.params

# Generated at 2022-06-26 11:18:34.949480
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()



# Generated at 2022-06-26 11:18:39.926507
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    str_0 = 'categories'
    http_quiet_downloader_0 = HttpQuietDownloader(tuple_0, str_0)
    var_1 = http_quiet_downloader_0.to_screen()
    fragment_fd_0 = FragmentFD(tuple_0, str_0)
    assert fragment_fd_0 is not None # created object should not be None

# Generated at 2022-06-26 11:18:40.772945
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:18:51.370841
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'yes'
    str_1 = 'ratelimit'
    str_2 = 'quiet'
    str_3 = 'retries'
    str_4 = 'noprogress'
    str_5 = 'match_filter'
    str_6 = 'username'
    str_7 = 'skip_unavailable_fragments'
    str_8 = 'ratelimit'
    str_9 = 'nopart'
    str_10 = 'test'
    str_11 = 'keep_fragments'
    str_12 = 'use_proxy'
    str_13 = 'fragment_retries'
    str_14 = 'retries'
    str_15 = 'total_frags'
    str_16 = 'fragment_base_url'
    str_17 = 'username'

# Generated at 2022-06-26 11:21:57.296253
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD()
    var_0 = fragment_fd_0.report_retry_fragment()
    var_1 = fragment_fd_0.report_skip_fragment()
    var_2 = fragment_fd_0._prepare_url()
    var_3 = fragment_fd_0._prepare_and_start_frag_download()
    var_4 = fragment_fd_0.__do_ytdl_file()
    var_5 = fragment_fd_0._read_ytdl_file()
    var_6 = fragment_fd_0._write_ytdl_file()
    var_7 = fragment_fd_0._download_fragment()
    var_8 = fragment_fd_0._append_fragment()
    var_9 = fragment_fd

# Generated at 2022-06-26 11:21:58.036961
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:22:00.697020
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Unit Testing
if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:22:05.085926
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = None
    tuple_0 = (bytes_0,)
    str_0 = 'categories'
    fragment_fd_0 = FragmentFD(tuple_0, str_0)
    assert fragment_fd_0


# Generated at 2022-06-26 11:22:05.889819
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()




# Generated at 2022-06-26 11:22:14.625567
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_1 = None
    tuple_1 = (bytes_1,)
    str_1 = 'categories'
    dict_1 = {}
    bool_1 = False
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_

# Generated at 2022-06-26 11:22:15.715987
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:22:22.505770
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    tuple_0 = (None,)
    str_0 = 'categories'
    http_quiet_downloader_0 = HttpQuietDownloader(tuple_0, str_0)
    http_quiet_downloader_1 = HttpQuietDownloader(tuple_0, str_0)
    tuple_1 = (None,)
    str_1 = 'categories'
    http_quiet_downloader_2 = HttpQuietDownloader(tuple_1, str_1)
    http_quiet_downloader_3 = HttpQuietDownloader(tuple_0, str_0)

    # Testing if class `HttpQuietDownloader` contains method `to_screen`
    assert('to_screen' in dir(HttpQuietDownloader))

    # Testing method `to_screen`
    test_case_0

# Generated at 2022-06-26 11:22:24.100526
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

if __name__ == '__main__':
    test_HttpQuietDownloader()
    print('Test has finished...')

# Generated at 2022-06-26 11:22:32.867634
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Instantiate a FragmentFD with _downloader, _sleep_interval, _total_frags, _fragment_retries, _skip_unavailable_fragments, _live, _fragment_index, filename and params
    fragment_fd_0 = FragmentFD(tuple_0, int_0, int_1, int_2, var_0, var_0, int_3, str_1, tuple_1)
    # Assert instance attributes
    assert fragment_fd_0._fd_name == 'fragment'
    assert fragment_fd_0._sleep_interval == int_0
    assert fragment_fd_0._total_frags == int_1
    assert fragment_fd_0._fragment_retries == int_2
    assert fragment_fd_0._skip_unavailable_frag