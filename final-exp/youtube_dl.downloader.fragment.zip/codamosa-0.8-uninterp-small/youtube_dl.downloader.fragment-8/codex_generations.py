

# Generated at 2022-06-26 11:13:40.928134
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD('https://www.youtube.com/watch?v=_H0J23hR2QI', {})
    test_case_0()


# Generated at 2022-06-26 11:13:42.248367
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:13:44.744189
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:13:52.636625
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Initialize a FragmentFD object with fragment_retries, skip_unavailable_fragments, keep_fragments parameters
    fragment_fd_obj_0 = FragmentFD()
    # Assert the initial result of FragmentFD object
    assert fragment_fd_obj_0.params == {'no_overwrites': True, 'quiet': False, 'retries': 10, 'socket_timeout': '10.0'}


# Generated at 2022-06-26 11:13:55.029849
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()



# Generated at 2022-06-26 11:13:56.725888
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:13:58.063564
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:14:00.488376
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD('vkontakte.py')


# Generated at 2022-06-26 11:14:04.206737
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    frag_fd_0 = FragmentFD()


if __name__ == '__main__':
    # debug only
    test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:14:09.262068
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = '\n'
    int_0 = 4596779
    fragment_fd_0 = FragmentFD(str_0, int_0)


if __name__ == '__main__':

    test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:14:31.719131
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    print(">>Testing unit test(s) for constructor of class FragmentFD")
    fragment_f_d_0 = FragmentFD()
    print(">>Passed unit test(s) for constructor of class FragmentFD")
    return True


if __name__ == "__main__":
    test_FragmentFD()

# Generated at 2022-06-26 11:14:33.894117
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d = FragmentFD()



# Generated at 2022-06-26 11:14:47.688437
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import argparse
    if not hasattr(sys, 'argv'):
        sys.argv = ['']
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.PostProcessor import FFmpegMetadataPP

    ydl = YoutubeDL({'quiet': False, 'forcejson': True, 'simulate': True})
    ydl.add_post_processor(FFmpegMetadataPP())

# Generated at 2022-06-26 11:14:54.286327
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    print("Testing constructor of FragmentFD...")
    fragment_f_d_0 = FragmentFD()
    if fragment_f_d_0.__class__ == FragmentFD:
        print("Testcase passed")
    else:
        print("Testcase failed")

# Generated at 2022-06-26 11:15:01.520369
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fragment_f_d_0 = FragmentFD()
    http_quiet_downloader_0 = HttpQuietDownloader(fragment_f_d_0.ydl, {'continuedl': True, 'quiet': True, 'noprogress': True, 'ratelimit': fragment_f_d_0.params.get('ratelimit'), 'retries': fragment_f_d_0.params.get('retries', 0), 'nopart': fragment_f_d_0.params.get('nopart', False), 'test': fragment_f_d_0.params.get('test', False)})
    http_quiet_downloader_0._real_initialize(None)

# Generated at 2022-06-26 11:15:07.606910
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d_0 = FragmentFD(
        {
            'live': False,
            'total_frags': 7,
        },
        '--skip-unavailable-fragments',
        {
            'keep_fragments': False,
        },
        'mp4',
        'video',
        {},
        {
            'ext': 'mp4',
            'n_codec': 'avc1.64001F',
            'vcodec': 'avc1',
            'fps': 24,
            'acodec': 'mp4a',
            'asr': 44100,
            'height': 360,
            'width': 640,
        },
        '2016-03-01T10_59_16.000Z-sunrise-360p24.mp4'
    )


# Generated at 2022-06-26 11:15:08.919698
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Run all unit tests

# Generated at 2022-06-26 11:15:09.885046
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_q_d_0 = HttpQuietDownloader(0,0)


# Generated at 2022-06-26 11:15:10.382878
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d_0 = FragmentFD()

# Generated at 2022-06-26 11:15:11.384114
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():

    HttpQuietDownloader()

# Generated at 2022-06-26 11:15:33.550413
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(1,2)

if __name__ == '__main__':
    test_case_0()
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:15:35.429733
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d_0 = FragmentFD()
    assert fragment_f_d_0 is not None


# Generated at 2022-06-26 11:15:36.289005
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(None,None)

# Generated at 2022-06-26 11:15:37.467717
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fragment_f_d_1 = HttpQuietDownloader({}, None, None)

# Generated at 2022-06-26 11:15:39.607358
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_quiet_downloader_0 = HttpQuietDownloader()

test_case_0()
test_HttpQuietDownloader()


# Indentation check

# Generated at 2022-06-26 11:15:43.953919
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_quiet_dlr = HttpQuietDownloader(
        FileDownloader({'noprogress': True, 'verbose': True}),
        {'continuedl': True, 'quiet': True, 'noprogress': True}
    )
    print(type(http_quiet_dlr))


# Generated at 2022-06-26 11:15:45.295982
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d_0 = FragmentFD()    # call to constructor of class FragmentFD

# Generated at 2022-06-26 11:15:47.752235
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader()


if __name__ == '__main__':
    test_case_0()
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:15:49.648139
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # test_case_0
    HttpQuietDownloader(test_case_0)

# Generated at 2022-06-26 11:15:58.638818
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d = FragmentFD()
    if not isinstance(fragment_f_d, FileDownloader):
        raise AssertionError("FragmentFD should be subclass of FileDownloader")
    from .http import HttpFD
    if not issubclass(FragmentFD, HttpFD):
        raise AssertionError("FragmentFD should be subclass of HttpFD")
    if not isinstance(fragment_f_d, HttpFD):
        raise AssertionError("FragmentFD should be subclass of HttpFD")
    if FragmentFD.__bases__[0] is not HttpFD:
        raise AssertionError("FragmentFD should be subclass of HttpFD")
    from .common import FileDownloader
    if not issubclass(FragmentFD, FileDownloader):
        raise Ass

# Generated at 2022-06-26 11:16:40.872558
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d = FragmentFD()



# Generated at 2022-06-26 11:16:42.584917
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_quiet_downloader = HttpQuietDownloader(0,0)


# Generated at 2022-06-26 11:16:52.369977
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    print('\nUnit test for constructor of class FragmentFD()')
    print('Creating an instance for class FragmentFD(): fragment_f_d_0')
    fragment_f_d_0 = FragmentFD()
    print('\nClass variable is_debug =', fragment_f_d_0.is_debug)
    print('\nCalling method test_case_0()')
    test_case_0()
    print('\n<<< Unit test for constructor of class FragmentFD() passed >>>')
    print('\n')

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:16:53.388744
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Test driver

# Generated at 2022-06-26 11:16:54.759059
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d = FragmentFD()


# Generated at 2022-06-26 11:16:56.728192
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:16:59.677161
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_quiet_downloader_0 = HttpQuietDownloader()

if __name__ == '__main__':
    test_case_0()
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:17:01.002111
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d = FragmentFD()
    return fragment_f_d

# Generated at 2022-06-26 11:17:02.674106
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_quiet_downloader = HttpQuietDownloader(None, None)



# Generated at 2022-06-26 11:17:03.570723
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d = FragmentFD()

# Generated at 2022-06-26 11:18:31.968491
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        FragmentFD()
    except:
        assert False, 'Constructor is not working as expected'


# Generated at 2022-06-26 11:18:33.868982
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d_0 = FragmentFD()


# Generated at 2022-06-26 11:18:34.611824
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert FragmentFD()

# Generated at 2022-06-26 11:18:36.344104
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d_0 = FragmentFD()
    assert fragment_f_d_0 is not None


# Generated at 2022-06-26 11:18:37.245722
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:18:39.677075
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    downloader = HttpQuietDownloader()

if __name__ == '__main__':
    test_case_0()
    # Tests case for HttpQuietDownloader
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:18:42.771172
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # This test case is actually a test case for constructor of class HttpQuietDownloader
    # as constructor of class HttpFD is not called when object of class HttpQuietDownloader
    # is created
    HttpQuietDownloader(None, None)

# Generated at 2022-06-26 11:18:50.581367
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Test sample_info_dict and sample_params
    sample_info_dict = {}
    sample_params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }
    # Test sample_ydl
    sample_ydl = 'youtube-dl'
    # Test HttpQuietDownloader
    HttpQuietDownloader(sample_ydl, sample_params)


# Generated at 2022-06-26 11:18:52.995256
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d_0 = FragmentFD()


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:18:55.783608
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        http_q_d_o = HttpQuietDownloader(False,{})
        print("test_HttpQuietDownloader ok, HttpQuietDownloader created")
    except:
        print("test_HttpQuietDownloader failed, error creating HttpQuietDownloader")



# Generated at 2022-06-26 11:22:20.506819
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fragment_f_d = FragmentFD()
    dl = fragment_f_d.HttpQuietDownloader(
        fragment_f_d.ydl, {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': fragment_f_d.params.get('ratelimit'),
            'retries': fragment_f_d.params.get('retries', 0),
            'nopart': fragment_f_d.params.get('nopart', False),
            'test': fragment_f_d.params.get('test', False),
        }
    )


# Generated at 2022-06-26 11:22:22.386446
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fragment_f_d_0 = HttpQuietDownloader()


# Generated at 2022-06-26 11:22:27.056668
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }
    http_quiet_downloader = HttpQuietDownloader(
        None, params
    )
    assert http_quiet_downloader.params == params



# Generated at 2022-06-26 11:22:28.375548
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:22:29.532506
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    httpQuietDownloader_0 = HttpQuietDownloader()



# Generated at 2022-06-26 11:22:30.822927
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_q_d_0 = HttpQuietDownloader()


# Generated at 2022-06-26 11:22:33.915985
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fragment_f_d_0 = FragmentFD()
    http_quiet_downloader_0 = HttpQuietDownloader(fragment_f_d_0)

# Generated at 2022-06-26 11:22:40.488125
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(
        fragment_f_d_0.ydl,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': fragment_f_d_0.params.get('ratelimit'),
            'retries': fragment_f_d_0.params.get('retries', 0),
            'nopart': fragment_f_d_0.params.get('nopart', False),
            'test': fragment_f_d_0.params.get('test', False)
        }
    )


# Generated at 2022-06-26 11:22:43.746360
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d = FragmentFD()
    if fragment_f_d.FD_NAME:
        print("Constructor of class FragmentFD is ok")
    else:
        print("Constructor of class FragmentFD is not ok")


# Generated at 2022-06-26 11:22:51.243854
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    from .http import HttpFD
    from .dash  import DashSegmentsFD

    http_downloader = HttpFD()
    dash_downloader = DashSegmentsFD()
    dash_downloader = DashSegmentsFD()
    http_downloader = HttpQuietDownloader(
        dash_downloader,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': 3000,
            'retries': 1,
            'nopart': True,
            'test': True,
        }
    )
