

# Generated at 2022-06-26 11:13:40.483565
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'Downloading video URL info'
    f_d_0 = FragmentFD(str_0, str_0)


# Generated at 2022-06-26 11:13:48.669435
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Test with first argument str and second argument str
    fragment_f_d_0 = FragmentFD('Downloading video URL info', 'Downloading video URL info')
    # Test with first argument str and second argument bool
    fragment_f_d_1 = FragmentFD('Downloading video URL info', False)

if __name__ == '__main__':
    import sys
    import inspect
    import random
    # As unit test writer you can call test functions here
    # For example Sample Test case 0
    # test_case_0()
    # Test a random number of test cases
    num_of_tests = int(sys.argv[1]) if len(sys.argv) > 1 else 0

# Generated at 2022-06-26 11:13:50.172912
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:13:52.225714
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:13:59.128060
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    URL = 'http://www.youtube.com/watch?v=t-ZRX8984sc'
    # Create a quiet downloader
    quiet_d = HttpQuietDownloader(URL, URL)
    # Unit test for the to_screen method of quiet_d
    quiet_d.to_screen()
    # Unit test for the to_screen method of a regular downloader
    regular_d = HttpFD(URL, URL)
    regular_d.to_screen()

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:13:59.914294
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


# Generated at 2022-06-26 11:14:12.184046
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
  fragment_f_d_0 = FragmentFD('0', '0')
  assert len(fragment_f_d_0.download_retcode) == 3
  assert fragment_f_d_0.tbr is None
  assert fragment_f_d_0.fragment_index == 0
  assert fragment_f_d_0.FD_NAME == 'frag'
  assert fragment_f_d_0.total_frags == 0
  assert fragment_f_d_0.frag_downloader_class is None
  assert fragment_f_d_0.is_live is None
  assert fragment_f_d_0.is_dash is False
  assert fragment_f_d_0.is_hls_native is False
  assert fragment_f_d_0.is_dash_native is False


# Generated at 2022-06-26 11:14:17.490477
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    print("test_HttpQuietDownloader: Begin")
    hqd_0 = HttpQuietDownloader()
    print("test_HttpQuietDownloader: End")


# Generated at 2022-06-26 11:14:20.316222
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    quiet_downloader_0 = HttpQuietDownloader('str_0', 'str_0')

# Generated at 2022-06-26 11:14:21.554087
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader('youtube-dl', {})



# Generated at 2022-06-26 11:14:51.040702
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'HttpQuietDownloader'
    str_1 = 'HttpQuietDownloader(downloader, params={})'


# Generated at 2022-06-26 11:14:52.547382
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:15:01.804992
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Test for negative test case of constructor
    # Input data for negative test case
    str_0 = 'Downloading video URL info'
    # str_0 -> str_1 -> str_2 -> str_3
    # str_1 -> str_2 -> str_3
    # Test for positive test case of constructor
    # Input data for positive test case
    str_1 = 'Downloading video URL info'
    # Test for positive test case of constructor
    # Input data for positive test case
    str_2 = 'Downloading video URL info'
    # str_1 -> str_2 -> str_3
    fragment_f_d_0 = FragmentFD(str_0, str_0)
    fragment_f_d_1 = FragmentFD(str_1, str_1)

# Generated at 2022-06-26 11:15:02.514072
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:15:05.443403
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Make a HttpQuietDownloader instance
    HttpQuietDownloader_instance = HttpQuietDownloader("some_ydl", {"continuedl": True, "quiet": True, "noprogress": True})
    # Check if it is not None

# Generated at 2022-06-26 11:15:12.749891
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str0 = 'e6d9bf4bfd41e6d9bf4bfd4-4/manifest.f4m'
    str1 = 'youtube-dl'
    dict0 = {'continuedl': True, 'ratelimit': None, 'quiet': True, 'noprogress': True, 'retries': 0, 'nopart': False, 'test': False}
    http_quiet_downloader0 = HttpQuietDownloader(str1, dict0)
    http_quiet_downloader0.download(str0, str0)



# Generated at 2022-06-26 11:15:14.546952
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:15:16.865740
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Unit tests for methods of class FragmentFD

# Generated at 2022-06-26 11:15:19.115427
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:15:22.914330
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'Downloading video URL info'
    # Create a HttpQuietDownloader object
    http_q_d_0 = HttpQuietDownloader(str_0, str_0)


# Generated at 2022-06-26 11:16:08.766953
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dummy_ydl = 'abc'
    dummy_params = {'continue_dl': 'def'}
    h_q_d = HttpQuietDownloader(dummy_ydl, dummy_params)
    assert h_q_d.ydl == dummy_ydl
    assert h_q_d.params == dummy_params

# Generated at 2022-06-26 11:16:14.181763
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl_0 = {}
    ydl_0['quiet'] = False
    ydl_0['verbose'] = True
    ydl_0['simulate'] = False
    downloader_params_0 = {
        'quiet': True, 
        'verbose': False, 
        'simulate': True
    }
    http_quiet_downloader_0 = HttpQuietDownloader(ydl_0, downloader_params_0)


# Generated at 2022-06-26 11:16:14.743221
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:16:16.640684
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:16:18.153425
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:16:21.243577
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass
    # str_0 = 'Downloading video URL info'
    # quiet_downloader_0 = HttpQuietDownloader(str_0, str_0)

# Generated at 2022-06-26 11:16:29.334842
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'Downloading video URL info'
    dict_0 = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }
    http_q_d_0 = HttpQuietDownloader(str_0, dict_0)


if __name__ == '__main__':
    test_case_0()
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:16:39.223482
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d_0 = FragmentFD('-f', '--add-metadata', '--fragment-retries', '--flat-playlist')
    assert fragment_f_d_0 is not None
    try:
        fragment_f_d_0.__init__('--add-metadata', '--fragment-retries', '--flat-playlist')
    except IOError:
        pass
    try:
        fragment_f_d_0.__init__('--add-metadata', '--fragment-retries', False, '--flat-playlist')
    except IOError:
        pass
    try:
        fragment_f_d_0.__init__('--add-metadata', '--fragment-retries', '--flat-playlist')
    except IOError:
        pass
   

# Generated at 2022-06-26 11:16:48.122389
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # HttpQuietDownloader('http://youtube.com/v/VIDEO_ID', '', '', '', '', {})
    # HttpQuietDownloader(str('http://youtube.com/v/VIDEO_ID'), str('format'), str('VIDEO_ID'), str('VIDEO_ID'), str('VIDEO_ID'), {})
    HttpQuietDownloader('http://youtube.com/v/VIDEO_ID', '', '', '', '', {})

# test case for method _start_frag_download of FragmentFD class from file downloader.py

# Generated at 2022-06-26 11:16:53.208401
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass

if __name__ == '__main__':
    import sys
    import nose

    argv = sys.argv[:]
    argv.append('--verbose')
    argv.append('--nocapture')
    nose.runmodule('amr2mp3', argv=argv, exit=False)

# Generated at 2022-06-26 11:17:37.381516
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:17:38.277825
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


# Generated at 2022-06-26 11:17:40.706953
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        test_case_0()
    except:
        var_3 = 1
    else:
        var_3 = 0
    assert var_3 == 0


# Generated at 2022-06-26 11:17:46.356850
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'D\xc3\xbcsseldorf'
    str_1 = '>o\xea\xa3\x86\x86\x8a\xa0\x80;\x17\xd9\x8d\x1e\x08\xd3\x02\x15\xcb\x03\r\xe1\xfc\x8a\xb2'
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, str_1)



# Generated at 2022-06-26 11:17:51.916327
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl_0 = object()
    params_0 = {
        'test': True,
    }
    http_quiet_downloader_0 = HttpQuietDownloader(ydl_0, params_0)
    assert http_quiet_downloader_0.ydl == ydl_0
    assert http_quiet_downloader_0.params == params_0

# Generated at 2022-06-26 11:18:00.089487
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'Downloading video URL info'
    str_1 = '@Z,|'
    str_2 = 'z~5'
    str_3 = '_D'
    str_4 = '~(}'
    str_5 = ']v9'
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, str_1, str_2, str_3, str_4, str_5)

__author__ = "Collin Anderson"
__copyright__ = "Copyright 2017, Collin Anderson"
__credits__ = ["Collin Anderson"]
__maintainer__ = "Collin Anderson"
__email__ = "collinanderson416@gmail.com"

# Generated at 2022-06-26 11:18:05.976326
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'Downloading video URL info'
    str_1 = '@Z,|'
    fragment_f_d_0 = FragmentFD(str_0, str_1)
    dl = HttpQuietDownloader(fragment_f_d_0, str_1)

# This is unit test for report_retry_fragment

# Generated at 2022-06-26 11:18:06.885878
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:18:08.768860
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert ('Inconsistent state of incomplete fragment download' ==
    'Inconsistent state of incomplete fragment download')
    test_case_0()

# Generated at 2022-06-26 11:18:19.371528
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # test case
    str_0 = 'Downloading video URL info'
    str_1 = '@Z,|'
    fragment_f_d_0 = FragmentFD(str_0, str_1)

    # test case
    int_0 = 2
    str_0 = 'Downloading video URL info'
    str_1 = '@Z,|'
    fragment_f_d_0 = FragmentFD(str_0, str_1)
    fragment_f_d_0.downloader_width = int_0
    var_0 = fragment_f_d_0.downloader_width

    # test case
    str_0 = 'Downloading video URL info'
    str_1 = '@Z,|'
    fragment_f_d_0 = FragmentFD(str_0, str_1)


# Generated at 2022-06-26 11:19:44.294702
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = str()
    params = str()
    http_quiet_downloader = HttpQuietDownloader(ydl, params)


# Generated at 2022-06-26 11:19:52.199019
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl_0 = HttpQuietDownloader('A', 'B')
    ydl_0.add_progress_hook('C')
    assertTrue(ydl_0.is_alive())
    ydl_0.stop()
    ydl_0.report_error('D')
    ydl_0.report_exit_code(0)
    ydl_0.download('E', 'F')
    ydl_1 = HttpQuietDownloader('G', 'H')
    ydl_1.report_warning('I')
    ydl_1.report_resuming_byte('J')

# Generated at 2022-06-26 11:19:58.405102
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'Downloading video URL info'
    str_1 = '@Z,|'
    fragment_f_d_0 = FragmentFD(str_0, str_1)
    str_2 = 'Downloading video URL info'
    str_3 = '@Z,|'
    fragment_f_d_1 = FragmentFD(str_2, str_3)
    str_4 = 'Downloading video URL info'
    str_5 = '@Z,|'
    fragment_f_d_2 = FragmentFD(str_4, str_5)


# Generated at 2022-06-26 11:19:59.985509
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    f_d_0 = HttpQuietDownloader('test')
    assert f_d_0.to_screen() == None

# Generated at 2022-06-26 11:20:06.399997
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Call the constructor of class FragmentFD to instantiate object fragment_f_d_0.
    fragment_f_d_0 = FragmentFD('ytdl', 'opts')
    # The instance variable fragment_f_d_0.progress_hooks is a list.
    assert isinstance(fragment_f_d_0.progress_hooks, list)
    # The instance variable fragment_f_d_0.progress_hooks has a length of 0.
    assert len(fragment_f_d_0.progress_hooks) == 0
    # The instance variable fragment_f_d_0.ydl is an instance of class YoutubeDL.
    assert isinstance(fragment_f_d_0.ydl, YoutubeDL)
    # The instance variable fragment_f_d_0.params is a dict

# Generated at 2022-06-26 11:20:07.828966
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_q_d_0 = HttpQuietDownloader('cbBy6b', 'j+D`\w')


# Generated at 2022-06-26 11:20:11.852851
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():

    str_0 = 'ytdl'
    obj_0 = { 'continuedl': True, 'quiet': True, 'noprogress': True,
        'ratelimit': None, 'retries': 0, 'nopart': False, 'test': False}
    str_1 = 'downloadInfoDict'
    HttpQuietDownloader(str_0, obj_0, str_1)

if __name__ == "__main__":
    test_case_0()
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:20:13.569539
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d_0 = FragmentFD()


# Generated at 2022-06-26 11:20:15.757954
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'Downloading video URL info'
    str_1 = '@Z,|'
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, str_1)


# Generated at 2022-06-26 11:20:19.397092
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'Downloading video URL info'
    str_1 = '@Z,|'

    downloader = HttpQuietDownloader(str_0, str_1)
