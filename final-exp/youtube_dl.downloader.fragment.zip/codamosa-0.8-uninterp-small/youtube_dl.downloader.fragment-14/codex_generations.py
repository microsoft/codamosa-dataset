

# Generated at 2022-06-26 11:13:47.615802
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    dict_0 = None
    list_0 = []
    fragment_f_d_0 = FragmentFD(dict_0, list_0)
    fragment_f_d_0.report_retry_fragment(None, 1, 1, None)
    assert fragment_f_d_0.params.get('keep_fragments', False) == False
    fragment_f_d_0.report_skip_fragment(1)
    assert fragment_f_d_0.__do_ytdl_file(None) == False
    fragment_f_d_0._read_ytdl_file(None)
    fragment_f_d_0._write_ytdl_file(None)

# Generated at 2022-06-26 11:13:57.053385
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dict_0 = None
    dict_1 = {'ydl': dict_0, 'params': dict_0, 'info_dict': dict_0}
    http_quiet_downloader_0 = HttpQuietDownloader(
        dict_0, dict_1)
    dict_1 = {'ydl': dict_0, 'params': dict_0, 'info_dict': dict_0}
    http_quiet_downloader_1 = HttpQuietDownloader(
        dict_0, dict_1)
    dict_1 = {'ydl': dict_0, 'params': dict_0, 'info_dict': dict_0}
    http_quiet_downloader_2 = HttpQuietDownloader(
        dict_0, dict_1)

# Generated at 2022-06-26 11:14:04.516752
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    print('Unit testing of class FragmentFD...')
    test_case_0()
    print('Unit test finished.')

# Invoke test_FragmentFD
if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:14:05.888897
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


# Generated at 2022-06-26 11:14:11.592903
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dict_0 = None
    list_0 = []
    http_q_d_0 = HttpQuietDownloader(dict_0, list_0)
    return http_q_d_0

if __name__ == '__main__':
    test_HttpQuietDownloader()
    test_case_0()

# Generated at 2022-06-26 11:14:14.384099
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dict_0 = None
    list_0 = []
    assert HttpQuietDownloader(dict_0, list_0)


# Generated at 2022-06-26 11:14:18.272140
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:14:24.960866
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Testing all possible types of input parameters
    # 1. When input is valid
    ydl = None
    params = None
    http_q_d_0 = HttpQuietDownloader(ydl, params)
    # 2. When input is invalid
    ydl = None
    params = None
    try:
        http_q_d_1 = HttpQuietDownloader(ydl, params)
    except:
        pass


# Generated at 2022-06-26 11:14:28.090841
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_0 = FragmentFD(None, [])
    assert test_0 is not None

test_case_0()
test_FragmentFD()

# Generated at 2022-06-26 11:14:31.015267
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    dict_0 = None
    list_0 = []
    fragment_f_d_0 = FragmentFD(dict_0, list_0)


# Generated at 2022-06-26 11:14:53.900500
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class_var_0 = []
    var_0 = {}
    var_1 = {}
    http_quiet_downloader_0 = HttpQuietDownloader(var_0, var_1)


# Generated at 2022-06-26 11:14:54.767718
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_0 = test_case_0()

# Generated at 2022-06-26 11:14:55.687422
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Test case 0
    test_case_0()

# Generated at 2022-06-26 11:14:58.950841
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Testing 0
    var_0 = []
    fragment_f_d_0 = FragmentFD(var_0, var_0)


# Generated at 2022-06-26 11:15:03.663440
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    urlopen = None
    params = {}
    http_quiet_downloader_0 = HttpQuietDownloader(urlopen, params)
    assert http_quiet_downloader_0 is not None


# Generated at 2022-06-26 11:15:06.213556
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert test_case_0() is None


# Generated at 2022-06-26 11:15:08.652529
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # executed in a separate process (see run_tests.py)
    var_0 = []
    fragment_f_d_0 = FragmentFD(var_0, var_0)

# Generated at 2022-06-26 11:15:10.526694
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    unit_test_http_quiet_downloader_0 = HttpQuietDownloader(None, None)


# Generated at 2022-06-26 11:15:17.890608
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    print('Testing constructor')
    var_0 = []
    var_1 = []
    try:
        fragment_f_d_0 = FragmentFD(var_0, var_1)
        print('PASSED: Constructor tested successfully')
    except AssertionError as err:
        print('FAILED: Constructor test failed')
        print(err)
        exit(1)


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:15:23.762670
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_1 = []
    http_quiet_downloader_0 = HttpQuietDownloader(var_1, var_1)
    http_quiet_downloader_0._opener.open('http://www.youtube.com').read()

# This class represents a simple directory cache with a defined size. It
# implements an LRU policy

# Generated at 2022-06-26 11:15:47.620865
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Test for instance of HttpQuietDownloader
    assert isinstance(HttpQuietDownloader(None, {}), HttpQuietDownloader)

# Generated at 2022-06-26 11:15:49.879811
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:15:54.019379
# Unit test for constructor of class FragmentFD
def test_FragmentFD():

    # Arrange
    params = {
        'fragment_retries': 5
    }

    # Act
    fragment_f_d = FragmentFD(params)

    # Assert
    assert(
        fragment_f_d.params == params and
        fragment_f_d.ydl == None and
        fragment_f_d.FD_NAME == "generic"
    )


# Generated at 2022-06-26 11:15:56.301430
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = HttpQuietDownloader(var_0, var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:15:57.450793
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:15:59.641046
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader(1,2).download == HttpQuietDownloader.download


# Generated at 2022-06-26 11:16:00.977065
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

test_FragmentFD()

# Generated at 2022-06-26 11:16:10.892690
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert type(FragmentFD) is type
    assert FragmentFD.__name__ == 'FragmentFD'
    assert FragmentFD.__doc__ is not None
    assert FragmentFD.__module__ == 'youtube_dl.downloader.fragment'
    assert FragmentFD.__bases__ == (youtube_dl.downloader.FileDownloader,)
    assert hasattr(FragmentFD, 'report_retry_fragment')
    assert hasattr(FragmentFD, 'report_skip_fragment')
    assert hasattr(FragmentFD, '_prepare_url')
    assert hasattr(FragmentFD, '_prepare_and_start_frag_download')
    assert hasattr(FragmentFD, '_download_fragment')

# Generated at 2022-06-26 11:16:20.627351
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Allocate an instance of class FragmentFD without actually calling its
    # constructor.
    fragment_f_d_0 = FragmentFD(0, 0)
    assert isinstance(fragment_f_d_0, FragmentFD)
    assert hasattr(fragment_f_d_0, 'to_screen')
    assert hasattr(fragment_f_d_0, 'report_i_r_f')
    assert hasattr(fragment_f_d_0, 'FD_NAME')
    assert hasattr(fragment_f_d_0, 'retry_fragment')
    assert hasattr(fragment_f_d_0, 'report_skip_fragment')
    assert hasattr(fragment_f_d_0, '_download_fragment')


# Generated at 2022-06-26 11:16:27.587005
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    tmp_arguments = []
    tmp_params = []
    tmp_HttpQuietDownloader = HttpQuietDownloader(tmp_arguments, tmp_params)
    tmp_filename = 'test_filename'
    tmp_info_dict = {}
    tmp_HttpQuietDownloader.download(tmp_filename, tmp_info_dict)
    assert True

if __name__ == '__main__':
    test_case_0()
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:16:54.316698
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {}
    params = {}
    http_quiet_downloader_0 = HttpQuietDownloader(ydl, params)



# Generated at 2022-06-26 11:16:56.043115
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(None, None)


# Generated at 2022-06-26 11:16:57.171042
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


# Generated at 2022-06-26 11:17:06.185672
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_0 = []
    fragment_f_d_0 = FragmentFD(var_0, var_0)
    var_1 = fragment_f_d_0._download_fragment(var_0, var_0, var_0)
    var_2 = fragment_f_d_0.report_skip_fragment(var_0)
    var_3 = fragment_f_d_0.report_retry_fragment(var_0, var_0, var_0, var_0)
    var_4 = fragment_f_d_0._prepare_and_start_frag_download(var_0)
    var_5 = fragment_f_d_0._prepare_url(var_0, var_0)

# Generated at 2022-06-26 11:17:15.600339
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # test case 1
    var_0 = os.path.abspath(__file__)
    var_1 = os.path.abspath(__file__)
    quiet_downloader_0 = HttpQuietDownloader(var_1, var_0)
    # test case 2
    class DummyYDL_0:
        params = {}
    var_0 = DummyYDL_0()
    var_1 = os.path.abspath(__file__)
    quiet_downloader_0 = HttpQuietDownloader(var_0, var_1)
    # test case 3
    class DummyYDL_0:
        params = {'noplaylist': True}
    var_0 = DummyYDL_0()

# Generated at 2022-06-26 11:17:17.889759
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = []
    retval_1 = HttpQuietDownloader(var_0, var_0)
    assert type(retval_1) is HttpQuietDownloader


# Generated at 2022-06-26 11:17:19.815429
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fd = HttpQuietDownloader(None, {}, None)
    assert isinstance(fd, HttpQuietDownloader)


# Generated at 2022-06-26 11:17:21.064894
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:17:25.205413
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_1 = []
    fragment_f_d_1 = FragmentFD(var_1, var_1)

    var_2 = []
    var_3 = {'quiet': True}
    http_quiet_downloader_0 = HttpQuietDownloader(var_2, var_3)

# Generated at 2022-06-26 11:17:27.966825
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        test_case_0()
    except Exception as e:
        print("Exception caught: " + repr(e))

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:18:48.960503
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # tests
    test_case_0()


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:18:49.943539
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert test_case_0() == None


# Generated at 2022-06-26 11:18:51.951411
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    def test_case_0():
        var_0 = []
        HttpQuietDownloader(var_0, var_0)


# Generated at 2022-06-26 11:18:54.465938
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Setup
    var_0 = []
    fragment_f_d_0 = FragmentFD(var_0, var_0)
    assert fragment_f_d_0.params == {}
    # Teardown


# Generated at 2022-06-26 11:18:56.145051
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    res = HttpFD
    assert res == HttpFD

# Generated at 2022-06-26 11:18:57.716776
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(None, None) == HttpQuietDownloader(None, None)


# Generated at 2022-06-26 11:18:59.300542
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

test_FragmentFD()

# Generated at 2022-06-26 11:19:01.057745
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_0 = []
    test_case_0()



# Generated at 2022-06-26 11:19:02.979773
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(None, None)
    assert True


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:19:15.262431
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpQuietDownloader
    from .common import FileDownloader
    from .extractor.youtube import YoutubeIE
    data = dict(params = dict(), url = "https://www.youtube.com/watch?v=OTLOkBNX9pI", extractor = YoutubeIE().ie_key(), ie = YoutubeIE())
    data['params']['usenetrc'] = True
    data['params']['age_limit'] = 18
    data['params']['password'] = "1234567890"
    data['params']['outtmpl'] = "D:\\test.mp4"
    data['params']['max_downloads'] = 1
    data['params']['test'] = True
    data['params']['verbose'] = True

# Generated at 2022-06-26 11:21:07.975902
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass


# Generated at 2022-06-26 11:21:09.560390
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_0 = FragmentFD()

    var_0.test(test_case_0)

# Generated at 2022-06-26 11:21:10.456121
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_0 = FragmentFD()



# Generated at 2022-06-26 11:21:12.433515
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_0 = FragmentFD(0)


# Generated at 2022-06-26 11:21:13.669860
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = HttpQuietDownloader
    var_1 = FileDownloader
    test_case_0()


# Generated at 2022-06-26 11:21:15.062497
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:21:16.039115
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass


# Generated at 2022-06-26 11:21:17.568720
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Test a constructor of FragmentFD without any argument
    FragmentFD()

# Generated at 2022-06-26 11:21:21.018093
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_1 = {}
    var_2 = {}
    assert(isinstance(HttpQuietDownloader(var_1, var_2), HttpQuietDownloader))


# Generated at 2022-06-26 11:21:24.045111
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        FragmentFD(None, {})
    except NameError as var_0:
        print (var_0)

if __name__ == '__main__':
    test_FragmentFD()
    test_case_0()