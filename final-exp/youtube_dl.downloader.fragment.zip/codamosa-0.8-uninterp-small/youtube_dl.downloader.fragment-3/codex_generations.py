

# Generated at 2022-06-26 11:13:40.985443
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = True

# Generated at 2022-06-26 11:13:46.082904
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = True
    dict_0 = {bool_0: bool_0}
    http_quiet_downloader_0 = HttpQuietDownloader(bool_0, dict_0)
    dict_1 =  {'noplaylist': bool_0}
    fragment_fd_0 = FragmentFD(http_quiet_downloader_0, dict_1)


# Generated at 2022-06-26 11:13:48.214903
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = True
    file_downloader = FragmentFD(bool_0)

# Generated at 2022-06-26 11:13:49.672292
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:13:52.446255
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = True
    dict_0 = {bool_0: bool_0}
    fragment_fd_0 = FragmentFD(bool_0, dict_0)


# Generated at 2022-06-26 11:13:56.319260
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert True == True

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:13:57.658073
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:14:02.638469
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = True
    dict_0 = {bool_0: bool_0}
    fragment_fd_0 = FragmentFD(bool_0, dict_0)

if __name__ == '__main__':
    test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:14:08.523141
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    url_0 = 'https://foo.com'
    filename = 'test_filename'
    info_dict = {
        'id': '123',
        'title': 'Test',
    }
    FragmentFD(url_0, filename, info_dict)


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:14:13.615115
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    tmp = FragmentFD(None, {}, None)


# Generated at 2022-06-26 11:14:35.581530
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

if __name__ == "__main__":
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:14:37.475984
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD()


# Generated at 2022-06-26 11:14:39.828367
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    FragmentFD(bool_0, dict_1)



# Generated at 2022-06-26 11:14:47.070521
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bool_0 = True
    dict_0 = {str_0: str_0, str_1: str_1}
    http_quiet_downloader_0 = HttpQuietDownloader(bool_0, dict_0)
    http_quiet_downloader_0.to_screen(**dict_0)
    # var_0 = http_quiet_downloader_0.to_screen(**dict_0)


# Generated at 2022-06-26 11:14:52.321644
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    frag_fd_0 = FragmentFD()



if __name__ == '__main__':
    test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:14:55.315854
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    print("Testing constructor...")
    dict_0 = {}
    dict_1 = {}
    fragment_fd_0 = FragmentFD(dict_0, dict_1)

test_case_0()
test_FragmentFD()

# Generated at 2022-06-26 11:14:56.811518
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:15:07.549094
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bool_0 = True
    dict_0 = {}
    http_quiet_downloader_0 = HttpQuietDownloader(bool_0, dict_0)
    http_quiet_downloader_0.to_screen(**dict_0)
    bool_1 = True
    str_0 = "Xa&]7"
    bool_2 = False
    dict_1 = {str_0: bool_1, bool_2: bool_1}
    var_0 = http_quiet_downloader_0.to_screen(**dict_1)


# Generated at 2022-06-26 11:15:10.090445
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()
    try:
        test_HttpQuietDownloader()
    except:
        return 0

test_HttpQuietDownloader()

# Generated at 2022-06-26 11:15:22.645671
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = "Z2q3"
    bool_0 = True
    dict_0 = {str_0: bool_0}
    fragmentfd_1 = FragmentFD(bool_0, dict_0)
    assert fragmentfd_1 != None
    fragmentfd_3 = FragmentFD(bool_0, dict_0)
    assert fragmentfd_3 != None
    fragmentfd_1 = FragmentFD(bool_0, dict_0)
    assert fragmentfd_1 != None
    fragmentfd_1 = FragmentFD(bool_0, dict_0)
    assert fragmentfd_1 != None
    fragmentfd_1 = FragmentFD(bool_0, dict_0)
    assert fragmentfd_1 != None
    fragmentfd_1 = FragmentFD(bool_0, dict_0)
    assert fragmentfd_1

# Generated at 2022-06-26 11:16:05.270188
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    frag_fd = FragmentFD(None, None)
    assert bool(frag_fd) is True

# Generated at 2022-06-26 11:16:06.443517
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:16:07.836785
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:16:13.252357
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    dict_0 = {}
    dict_1 = {}
    fragment_fd_0 = FragmentFD(dict_0, dict_1)
    dict_0 = {}
    bool_0 = True
    str_0 = "Y0_iR_pcX%c:sGZ7e"
    dict_1 = {str_0: bool_0}
    var_0 = fragment_fd_0._prepare_url(**dict_0, **dict_1)

# Generated at 2022-06-26 11:16:14.182049
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:16:15.171717
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


# Generated at 2022-06-26 11:16:16.280851
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:16:17.519298
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

test_HttpQuietDownloader()

# Generated at 2022-06-26 11:16:23.006671
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = True 
    dict_0 = {'outtmpl': 'test.mp4'}
    file_downloader_0 = FileDownloader(bool_0, dict_0)
    dict_1 = {}
    dict_1 = {}
    frag_fd_0 = FragmentFD(file_downloader_0, dict_1)
    return frag_fd_0


# Generated at 2022-06-26 11:16:31.651554
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_1 = True
    dict_0 = {}
    fragment_fd_0 = FragmentFD(var_1, dict_0)
    assert fragment_fd_0.to_screen("9P*\x0b#\x13wsB?\x1b\x19+@B\x1e\x1e|") == None
    assert fragment_fd_0.params == {}
    assert fragment_fd_0.extractor_downloaders == {}
    assert fragment_fd_0.params == {}
    assert fragment_fd_0.FD_NAME == 'generic'

# Generated at 2022-06-26 11:17:47.568853
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:17:52.246599
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = True
    dict_0 = {'url': 'dummy', 'http_headers': None}
    fragment_fd_0 = FragmentFD(bool_0, dict_0)


if __name__ == '__main__':
    # test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:17:53.926471
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:17:56.495517
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = True
    dict_0 = {}
    fragment_fd_0 = FragmentFD(bool_0, dict_0)


# Generated at 2022-06-26 11:18:00.060149
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    file_downloader_0 = FileDownloader()
    bool_0 = True
    dict_0 = {}
    fragment_fd_0 = FragmentFD(bool_0, dict_0, file_downloader_0)

if __name__ == '__main__':
    test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:18:02.186846
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragmentFD_0 = FragmentFD(True, {}, None)


# Generated at 2022-06-26 11:18:03.034566
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:18:06.846318
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():

    # test case http_quiet_downloader
    bool_0 = bool()
    dict_0 = dict()
    http_quiet_downloader_0 = HttpQuietDownloader(bool_0, dict_0)


# Generated at 2022-06-26 11:18:14.085808
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD(False, 'G{Hx')
    file_downloader_0 = fragment_fd_0.try_rename('r', 'r')
    fragment_fd_0.ytdl_filename('Tc\x7fl')
    fragment_fd_0.test(True)
    file_downloader_0 = fragment_fd_0.download('r', {'http_headers': 'http_headers'})


# Generated at 2022-06-26 11:18:16.695984
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = True
    http_quiet_downloader_0 = HttpQuietDownloader(ydl, {})
    var_0 = http_quiet_downloader_0.to_screen()


# Generated at 2022-06-26 11:20:59.781010
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:21:01.897389
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()
    # raise NotImplementedError


# Generated at 2022-06-26 11:21:02.686105
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    #test_case_0()
    return


# Generated at 2022-06-26 11:21:04.718950
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    file_downloader_0 = FragmentFD(None, None)
    assert file_downloader_0 is not None


# Generated at 2022-06-26 11:21:08.397277
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:21:09.319562
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:21:18.437908
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_2 = "7B'<5"
    str_3 = "6qVA2<\x0cPiX4'z5v"
    dict_2 = {str_2: str_2, str_3: str_3}
    bool_1 = True
    dict_3 = {}
    fragment_fd_0 = FragmentFD(bool_1, dict_3)
    fragment_fd_0.report_destination(**dict_2)
    fragment_fd_0.report_warning(**dict_2)
    fragment_fd_0.calc_eta(**dict_2)
    fragment_fd_0.report_resuming_byte(**dict_2)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:21:21.431309
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()
    return None

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:21:22.283518
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:21:24.045653
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated test cases for method HttpQuietDownloader::_real_download