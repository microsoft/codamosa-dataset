

# Generated at 2022-06-26 11:13:47.643584
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    int_0 = 7
    set_0 = {int_0, int_0, int_0, int_0}
    fragment_f_d_0 = FragmentFD(int_0, set_0)
    assert fragment_f_d_0 is not None

    fragment_f_d_0 = FragmentFD(int_1, set_1)
    assert fragment_f_d_0 is not None

    fragment_f_d_0 = FragmentFD(int_2, set_2)
    assert fragment_f_d_0 is not None

    fragment_f_d_0 = FragmentFD(int_3, set_3)
    assert fragment_f_d_0 is not None

    fragment_f_d_0 = FragmentFD(int_4, set_4)
    assert fragment_f_d

# Generated at 2022-06-26 11:13:53.326369
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    int_0 = -3
    set_0 = {int_0, int_0, int_0, int_0}
    fragment_f_d_0 = FragmentFD(int_0, set_0)
    assert len(fragment_f_d_0.params) == 0
    assert fragment_f_d_0.FD_NAME == 'fragment'

# Generated at 2022-06-26 11:13:56.416386
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    int_0 = -86
    set_0 = {int_0, int_0, int_0, int_0}
    http_quiet_downloader_0 = HttpQuietDownloader(int_0, set_0)

# Generated at 2022-06-26 11:14:00.488009
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        test_case_0()
    except:
        print("Failed test_FragmentFD")
        raise

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:14:06.127427
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl_0 = 'ydl'
    params_0 = {'outtmpl': '%(autonumber)s-%(id)s.%(ext)s'}
    http_quiet_downloader_0 = HttpQuietDownloader(ydl_0, params_0)


# Generated at 2022-06-26 11:14:11.320635
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # making sure that the output is not printed to the console
    HttpFD.to_screen = lambda self,*args,**kargs: None
    HttpQuietDownloader(1, 2)

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:14:15.725067
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = None
    params = {'continuedl': True, 'quiet': True, 'noprogress': True, 'ratelimit': None, 'retries': 0, 'nopart': False, 'test': False}
    http_quiet_downloader_0 = HttpQuietDownloader(ydl, params)


# Generated at 2022-06-26 11:14:18.669964
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

test_FragmentFD()

# Generated at 2022-06-26 11:14:21.469500
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == "__main__":
    test_FragmentFD()

# Generated at 2022-06-26 11:14:23.701918
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # TestCase 0
    assert test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:14:51.790826
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    http_quiet_downloader_0 = HttpQuietDownloader(int_0, int_0)
    fragmentFD_0 = FragmentFD(int_0, http_quiet_downloader_0)



# Generated at 2022-06-26 11:14:54.235944
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

#####
# Function: main
#
# Purpose: Invokes the test routines for the module.
#
#####

# Generated at 2022-06-26 11:14:55.687068
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD(test_case_0)


# Generated at 2022-06-26 11:14:59.538369
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_1 = FragmentFD(None, None)

if __name__ == '__main__':
    test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:15:03.042048
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD(None, None)
    assert type(fragment_fd_0) == FragmentFD

# Generated at 2022-06-26 11:15:04.624879
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:15:06.350877
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # No need to test
    pass


# Generated at 2022-06-26 11:15:08.074688
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_quiet_downloader_0 = HttpQuietDownloader(int_0, int_0)


# Generated at 2022-06-26 11:15:09.186767
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:15:21.730267
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD(7, 7)
    #assert fragment_fd_0.url == 7
    #assert fragment_fd_0.params == 7
    #assert fragment_fd_0.info_dict == 7
    #assert fragment_fd_0.add_extra_info == 7
    #assert fragment_fd_0.progress_hooks == 7
    #assert fragment_fd_0.is_live == 7
    #assert fragment_fd_0.total_frags == 7
    #assert fragment_fd_0.frag_index == 7
    #assert fragment_fd_0.frag_count == 7
    #assert fragment_fd_0.skip_unavailable_fragments == 7
    #assert fragment_fd_0.frag_retries == 7
    #assert fragment_fd_0.

# Generated at 2022-06-26 11:16:06.397482
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    float_0 = -3710.0
    set_0 = set()
    http_quiet_downloader_0 = HttpQuietDownloader(float_0, set_0)


# Generated at 2022-06-26 11:16:08.125372
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:16:09.047245
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()



# Generated at 2022-06-26 11:16:13.129351
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    float_0 = 22.5
    list_0 = []
    fragment_f_d_0 = FragmentFD(float_0, list_0)
    assert fragment_f_d_0 != None

# MAIN ENTRY POINT
if __name__ == '__main__':
    test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:16:14.704811
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:16:21.374536
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    float_0 = -3710.0
    dict_0 = {}
    float_1 = 481.996347
    list_0 = []
    fragment_f_d_0 = FragmentFD(float_1, list_0)
    var_0 = fragment_f_d_0.report_skip_fragment(dict_0)
    set_0 = set()
    http_quiet_downloader_0 = HttpQuietDownloader(float_0, set_0)


# Generated at 2022-06-26 11:16:24.138935
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    print("Test case: test_FragmentFD")
    test_case_0()


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:16:27.859186
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    float_0 = -3710.0
    set_0 = set()
    http_quiet_downloader_0 = HttpQuietDownloader(float_0, set_0)


# Generated at 2022-06-26 11:16:32.288888
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    float_0 = -7463.83957
    list_0 = []
    fragment_f_d_0 = FragmentFD(float_0, list_0)
    if (fragment_f_d_0 != None):
        assert True
    else:
        assert False

# Generated at 2022-06-26 11:16:35.009307
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d_0 = FragmentFD()
    fragment_f_d_1 = FragmentFD(fragment_f_d_0)


# Generated at 2022-06-26 11:18:00.747577
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    global ytdl
    fragment_f_d_0 = FragmentFD(ytdl,downloads)
    global aho
    global bho
    print_case = fragment_f_d_0.download('http://www.autohotkey.com/board/topic/150328-download-youtube-video-and-convert-to-mp3/',{'http_headers':{'Content-Type':'text/html'},'format':'mp3'})

# Generated at 2022-06-26 11:18:02.005639
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


# Generated at 2022-06-26 11:18:03.462888
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:18:06.015741
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:18:07.663787
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:18:08.502592
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()



# Generated at 2022-06-26 11:18:11.931510
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:18:20.551730
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    float_0 = 498.844777
    set_0 = set()
    http_quiet_downloader_0 = HttpQuietDownloader(float_0, set_0)
    float_1 = -4854.0
    list_0 = []
    fragment_f_d_0 = FragmentFD(float_1, list_0)
    dict_0 = {}
    fragment_f_d_0.report_skip_fragment(dict_0)
    var_0 = http_quiet_downloader_0._http_info_dict(dict_0)
    dict_1 = dict_0.copy()
    dict_1['url'] = 'http://i.ytimg.com/vi/IyGDLfnBLsk/hqdefault.jpg'

# Generated at 2022-06-26 11:18:22.220691
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(type(FragmentFD), type(FileDownloader))



# Generated at 2022-06-26 11:18:32.337807
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    float_0 = 904.8744532
    set_0 = set()
    http_quiet_downloader_0 = HttpQuietDownloader(float_0, set_0)
    float_1 = -2886.59
    str_0 = 'kSpJg'
    list_0 = []
    dict_0 = {}
    fragment_f_d_0 = FragmentFD(float_1, list_0)
    fragment_f_d_0._prepare_url(dict_0, str_0)
    float_2 = 380.72
    set_1 = set()
    http_quiet_downloader_1 = HttpQuietDownloader(float_2, set_1)

test_HttpQuietDownloader()
test_case_0()

# Generated at 2022-06-26 11:21:27.935373
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpFD.to_screen = print
    test_case_0()

# Generated at 2022-06-26 11:21:30.126163
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    float_0 = -3710.0
    list_0 = []
    fragment_fd_0 = FragmentFD(float_0, list_0)
    test_case_0()

# Generated at 2022-06-26 11:21:30.690889
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert True

# Generated at 2022-06-26 11:21:35.665292
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    float_0 = -3710.0
    dict_0 = {}
    float_1 = 481.996347
    list_0 = []
    fragment_f_d_0 = FragmentFD(float_1, list_0)
    var_0 = fragment_f_d_0.report_skip_fragment(dict_0)
    set_0 = set()
    http_quiet_downloader_0 = HttpQuietDownloader(float_0, set_0)



# Generated at 2022-06-26 11:21:36.938966
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0() # calling function test_case_0


# Generated at 2022-06-26 11:21:40.350554
# Unit test for constructor of class HttpQuietDownloader

# Generated at 2022-06-26 11:21:46.532703
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    dict_0 = {}
    float_0 = -3710.0
    list_0 = []
    fragment_f_d_0 = FragmentFD(float_0, list_0)
    var_0 = fragment_f_d_0.report_skip_fragment(dict_0)
    set_0 = set()
    http_quiet_downloader_0 = HttpQuietDownloader(float_0, set_0)


# Generated at 2022-06-26 11:21:51.493394
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    float_0 = -19.22044
    list_0 = []
    http_quiet_downloader_0 = HttpQuietDownloader(float_0, list_0)
    float_1 = 81.0
    dict_0 = {
        'floater': float_1,
        'boolean_examiner': False,
        'integer_examiner': 2,
        'list_examiner': list_0,
        'dict_examiner': dict_0,
        'string_examiner': '',
        'null_examiner': None,
    }
    float_2 = 76.78019
    float_3 = -22.756738
    str_0 = 'R'

# Generated at 2022-06-26 11:21:54.558569
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    int_0 = 17
    float_0 = -51.7481679
    dict_0 = {}
    list_0 = []
    fragment_f_d_0 = FragmentFD(float_0, list_0)
    fragment_f_d_0.to_screen(dict_0, int_0)

# Generated at 2022-06-26 11:21:55.363101
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()
