

# Generated at 2022-06-26 11:13:50.102587
# Unit test for constructor of class HttpQuietDownloader

# Generated at 2022-06-26 11:13:51.412868
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


# Generated at 2022-06-26 11:13:52.446726
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass


# Generated at 2022-06-26 11:13:57.210894
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Test with given url
    url = "https://www.youtube.com"
    HttpQuietDownloader1 = HttpQuietDownloader(url)
    assert HttpQuietDownloader1
    
    # Test with empty url
    url = ""
    HttpQuietDownloader2 = HttpQuietDownloader(url)
    assert HttpQuietDownloader2


# Generated at 2022-06-26 11:13:59.271530
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:14:01.444668
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'a|3-L'
    set_0 = {str_0}
    float_0 = 0
    fragment_f_d_0 = FragmentFD(set_0, float_0)


# Generated at 2022-06-26 11:14:05.893331
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {'ydl': 'ydl'}
    params = {'params': 'params'}
    http_quiet_downloader_0 = HttpQuietDownloader(ydl, params)


# Generated at 2022-06-26 11:14:07.833278
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

test_FragmentFD()

# Generated at 2022-06-26 11:14:15.759137
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    dict_0 = dict()
    dict_0 = {'live': True, 'fragment_index': 18, 'filename': 'HD84SD/4.mp4', 'dest_stream': open('5.mp4', 'wb'), 'dl': HttpQuietDownloader({'continuedl': True, 'quiet': True, 'noprogress': True}, {}), 'total_frags': 10, 'started': -1.0, 'complete_frags_downloaded_bytes': 56, 'tmpfilename': 'HD84SD/4.mp4'}
    dict_1 = dict()

# Generated at 2022-06-26 11:14:23.068517
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = '7cqgT,uX'
    str_1 = '7cqgT,uX'
    set_0 = {str_0, str_1}
    float_0 = 3502.56
    fragment_f_d_0 = FragmentFD(set_0, float_0)



# Generated at 2022-06-26 11:14:45.972307
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    set_0 = {str, bool, int}
    float_0 = 627.62
    fragment_f_d_0 = FragmentFD(set_0, float_0)
    assert isinstance(fragment_f_d_0, FragmentFD)

# Generated at 2022-06-26 11:14:57.954931
# Unit test for constructor of class FragmentFD

# Generated at 2022-06-26 11:15:09.912436
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    set_0 = {'4 /', '4 /'}
    float_0 = -5.395949124619721
    http_quiet_downloader_0 = HttpQuietDownloader(set_0, float_0)
    http_quiet_downloader_0.get_filename(None)
    http_quiet_downloader_0.to_screen(None, None, None)
    str_0 = '+3npT'
    str_1 = 'f+E'
    http_quiet_downloader_0.report_warning(str_0, str_0, str_1)
    str_2 = '-'
    http_quiet_downloader_0.real_download(str_2, None)

# Generated at 2022-06-26 11:15:13.646871
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    set_0 = set()
    float_0 = 7461.5
    fragment_f_d_0 = FragmentFD(set_0, float_0)
    assert fragment_f_d_0 is not None


# Generated at 2022-06-26 11:15:25.585345
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bool_0 = True
    bool_1 = True
    dict_0 = {}
    dict_0['continuedl'] = bool_0
    dict_0['quiet'] = bool_1
    dict_0['noprogress'] = bool_1
    dict_0['ratelimit'] = bool_1
    dict_0['retries'] = bool_0
    dict_0['nopart'] = bool_1
    dict_0['test'] = bool_0
    bool_2 = bool_0
    bool_3 = bool_1
    set_0 = {bool_0, bool_1}
    float_0 = -56.47759
    http_quiet_downloader_0 = HttpQuietDownloader(set_0, float_0, dict_0)


# Generated at 2022-06-26 11:15:28.700652
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    set_0 = {'a', 'b', 'c', 'd', 'e'}
    float_0 = 8451.22
    fragment_f_d_0 = FragmentFD(set_0, float_0)
    test_case_0()

test_FragmentFD()

# Generated at 2022-06-26 11:15:30.773749
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_quiet_downloader_0 = HttpQuietDownloader(None, None)
    test_case_0()

test_HttpQuietDownloader()

# Generated at 2022-06-26 11:15:34.545329
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = True
    str_0 = 'k|S3s*^'
    set_0 = {str_0, str_0}
    float_0 = 3502.56
    fragment_f_d_0 = FragmentFD(set_0, float_0)


# Generated at 2022-06-26 11:15:36.055760
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:15:44.683253
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bool_0 = True
    str_0 = '9#^t-#'
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    str_1 = 'b#d,5D'
    set_0 = {str_0, str_0}
    float_0 = 3502.56
    fragment_f_d_0 = FragmentFD(set_0, float_0)
    http_quiet_downloader_0 = HttpQuietDownloader(fragment_f_d_0, float_0, str_1, bytes_0, bool_0)

# Unit test

# Generated at 2022-06-26 11:16:34.007362
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = True
    str_0 = 'Nxgwme7-%K'
    set_0 = {str_0, str_0}
    float_0 = 3387.02
    fragment_f_d_0 = FragmentFD(set_0, float_0)
    var_0 = fragment_f_d_0.report_skip_fragment(bool_0)
    # test the method to_screen()
    bool_0 = True
    str_0 = '-'
    set_0 = {str_0, str_0}
    float_0 = 688.96
    fragment_f_d_0 = FragmentFD(set_0, float_0)
    var_0 = fragment_f_d_0.report_skip_fragment(bool_0)
    # test the

# Generated at 2022-06-26 11:16:42.128694
# Unit test for constructor of class HttpQuietDownloader

# Generated at 2022-06-26 11:16:47.059166
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_1 = None
    float_0 = 63731.6
    fragment_f_d_0 = FragmentFD(test_case_1, float_0)
    return fragment_f_d_0


# Generated at 2022-06-26 11:16:52.893030
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """
    Test of method downloader.HttpQuietDownloader.__init__
    """
    params_0 = {}
    http_quiet_downloader_0 = HttpQuietDownloader(params_0)
    assert http_quiet_downloader_0.params == {'noprogress': True, 'quiet': True}
    assert http_quiet_downloader_0.ydl == params_0


# Generated at 2022-06-26 11:16:53.867205
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass


# Generated at 2022-06-26 11:16:56.371526
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == "__main__":
    # Run the unit test
    test_FragmentFD()

# Generated at 2022-06-26 11:17:00.372899
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
  params = {
      'quiet': True,
  }
  result = HttpQuietDownloader(None, params)
  assert 'resume' in result and 'test' in result

if __name__ == '__main__':
  test_case_0()
  test_HttpQuietDownloader()

# Generated at 2022-06-26 11:17:03.803862
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = False
    # Test case: 0
    try:
        test_case_0()
    except Exception:
        bool_0 = True

    assert (bool_0 == False)

# Generated test cases for report_skip_fragment of class FragmentFD

# Generated at 2022-06-26 11:17:06.642901
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    set_0 = {'', 'X,))^'}
    float_0 = 11.15
    http_quiet_downloader_0 = HttpQuietDownloader(set_0, float_0)


# Generated at 2022-06-26 11:17:07.506075
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:18:37.565965
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    set_0 = {'http', 'http'}
    bool_0 = True
    float_0 = 5.4
    http_quiet_downloader_0 = HttpQuietDownloader(set_0, bool_0, float_0)
    http_quiet_downloader_0.to_screen()

test_case_0()
test_HttpQuietDownloader()

# Generated at 2022-06-26 11:18:48.285043
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bool_0 = True
    set_0 = {'Q', 's', 'G2'}
    float_0 = 801.63

    # Test 1
    http_quiet_downloader_0 = HttpQuietDownloader(set_0, float_0)
    http_quiet_downloader_1 = HttpQuietDownloader(set_0, float_0)
    assert id(http_quiet_downloader_0) != id(http_quiet_downloader_1)

    # Test 2
    http_quiet_downloader_2 = HttpQuietDownloader(set_0, float_0, bool_0)
    http_quiet_downloader_3 = HttpQuietDownloader(set_0, float_0, False)

# Generated at 2022-06-26 11:18:49.988880
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:18:57.109978
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    set_0 = {'wf|b2_7|u;+'}
    float_0 = 5.38
    fragment_f_d_0 = FragmentFD(set_0, float_0)
    float_1 = float(fragment_f_d_0.params.get('retries'))
    float_2 = float(fragment_f_d_0.params.get('max_downloads'))
    float_3 = float(fragment_f_d_0.params.get('min_filesize'))
    float_4 = float(fragment_f_d_0.params.get('max_filesize'))
    bool_0 = bool(fragment_f_d_0.params.get('noprogress'))

# Generated at 2022-06-26 11:19:02.120846
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bool_0 = True
    str_0 = '-h'
    set_0 = {str_0, '2'}
    float_0 = -0.8466043115084359
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, float_0, set_0, bool_0, bool_0)


# Generated at 2022-06-26 11:19:14.345458
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bool_0 = False
    bool_1 = False
    int_0 = 0
    float_0 = 5.0
    set_0 = set()
    str_0 = '^'
    str_1 = '/1Zl9|Ek'
    dict_0 = {}
    list_0 = [int_0, str_0, int_0]
    list_1 = [int_0, str_0]
    http_quiet_downloader_0 = HttpQuietDownloader(bool_0, dict_0)
    http_quiet_downloader_0._do_download(str_1, str_0)
    http_quiet_downloader_0.report_destination(str_1)
    http_quiet_downloader_0.report_error(str_1)
    http_quiet_downloader_

# Generated at 2022-06-26 11:19:22.650856
# Unit test for constructor of class FragmentFD

# Generated at 2022-06-26 11:19:34.118093
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    set_0 = {'f5G?H-', '%'}
    int_0 = 0
    dict_0 = {'lw#%c+': '0J`tb*', '@v)8+': 3, '}C(e': '+'}
    http_quiet_downloader_0 = HttpQuietDownloader(set_0, dict_0)
    dict_1 = {'n8<$': 'n', 'tNvJ': '`*8`', '03_M+': 'Bn(kJ'}
    http_quiet_downloader_1 = HttpQuietDownloader(set_0, dict_1)
    dict_2 = {'kU[d;': int_0, 'jRX': 'r', '}%2': 'H|@5:'}

# Generated at 2022-06-26 11:19:35.019781
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:19:39.860927
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    set_0 = {'p`Y#X"$m'}
    float_0 = float('nan')
    float_1 = float('-inf')
    http_quiet_downloader_0 = HttpQuietDownloader(set_0, float_0, float_1)


if __name__ == '__main__':
    test_case_0()
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:23:04.996100
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    quiet_downloader_0 = HttpQuietDownloader(set(), 450.377)
    bool_0 = True
    str_0 = 'fQ`|}'
    set_0 = {'>qd,;sN', 'Y}RPP*', bool_0}
    float_0 = 903.8
    quiet_downloader_1 = HttpQuietDownloader(set_0, float_0)
    bool_1 = True
    str_1 = 'E2|a-{Y'
    set_1 = {str_0, bool_1, str_1}
    float_1 = 7.66
    quiet_downloader_2 = HttpQuietDownloader(set_1, float_1)
    bool_2 = True
    str_2 = 'K*'

# Generated at 2022-06-26 11:23:15.428172
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    set_0 = {'k|S3s*^', 'k|S3s*^'}
    float_0 = 3502.56
    fragment_f_d_0 = FragmentFD(set_0, float_0)
    fragment_f_d_0.report_retry_fragment('Q:E(s', 0, 0, True)
    fragment_f_d_0.report_skip_fragment(True)
    fragment_f_d_0.report_skip_fragment(True)
    fragment_f_d_0._prepare_url('I1w', 'Q:E(s')
    fragment_f_d_0._prepare_and_start_frag_download('I1w')