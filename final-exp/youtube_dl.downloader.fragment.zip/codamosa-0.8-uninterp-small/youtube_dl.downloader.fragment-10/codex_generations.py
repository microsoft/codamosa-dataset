

# Generated at 2022-06-26 11:13:41.658833
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    int_0 = -3679855
    dict_0 = {int_0: int_0, int_0: int_0}
    http_quiet_downloader_0 = HttpQuietDownloader(int_0, dict_0)

test_case_0()
test_HttpQuietDownloader()

# Generated at 2022-06-26 11:13:43.714526
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:13:48.568507
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import os

    try:
        path = sys.argv[1]
    except IndexError:
        path = ""
        for path in ["/opt/sources/youtube-dl/youtube_dl/downloader/http.py", "downloader/http.py"]:
            if os.path.exists(path):
                break

    if not path or not os.path.exists(path):
        sys.exit(1)

    sys.exit(0)


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:13:50.588209
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()
    # todo: implement test cases


# Generated at 2022-06-26 11:13:51.975394
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:13:54.790782
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_quiet_downloader_0 = HttpQuietDownloader(int, {int: int})
    assert isinstance(http_quiet_downloader_0, HttpQuietDownloader)


# Generated at 2022-06-26 11:13:57.063909
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    file_downloader_0 = FragmentFD('url', '')

# Generated at 2022-06-26 11:14:11.822175
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert (hasattr(HttpQuietDownloader, '__init__')), 'No __init__'
    assert (HttpQuietDownloader.__init__.__doc__), 'No __init__ doc string'
    assert ('object' in str(HttpQuietDownloader.__init__.__annotations__['return'])), 'No __init__ return annotation'
    assert ('True' in str(HttpQuietDownloader.__init__.__annotations__['params'])), 'No __init__ params annotation'
    assert ('__main__' in str(HttpQuietDownloader.__init__.__module__)), 'No __init__ module annotation'
    test_case_0()

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:14:17.723558
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD(int, int)
    # Verify that fragment_fd_0, is an instance of FragmentFD
    assert isinstance(fragment_fd_0, FragmentFD)


# Generated at 2022-06-26 11:14:21.010071
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # NOTE: This test assumes that the target object is already initialized
    #       with non-Python object (e.g. from C)
    # TODO: Implement constructor test for class HttpQuietDownloader
    # test_case_0()
    # test_case_1()
    pass



# Generated at 2022-06-26 11:14:46.013423
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    print('Testing HttpQuietDownloader constructor')
    ydl_opts = {'format': '720p'}
    http_getter = HttpQuietDownloader(ydl_opts, {})
    assert http_getter is not None
    print('Done testing HttpQuietDownloader constructor')


# Generated at 2022-06-26 11:14:52.169304
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_0 = [None]
    bool_0 = False
    fragment_f_d_0 = FragmentFD(var_0, bool_0)

test_case_0()

# Generated at 2022-06-26 11:14:53.955157
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:14:58.749597
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Initialize test variables
    list_0 = []
    bool_0 = False
    fragment_f_d_0 = FragmentFD(list_0, bool_0)

    # Assert fragmentFD_0 has been initialized
    assert (fragment_f_d_0 != None), "FragmentFD_0 was not initialized!"

    # End Unit Test
    return 0


# Generated at 2022-06-26 11:15:10.002835
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    list_0 = []
    bool_0 = False
    str_0 = "progress_hooks"
    str_1 = "\r[download] 100%"
    bool_1 = True
    http_quiet_downloader_0 = HttpQuietDownloader(list_0, bool_0)
    dict_0 = {}
    dict_1 = {}
    dict_1.update(http_quiet_downloader_0.params)
    dict_0.update(dict_1)
    assert dict_0[str_0] == str_1
    assert dict_0['quiet'] == bool_1
    assert dict_0['verbose'] == bool_0
    

# Generated at 2022-06-26 11:15:22.565701
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = '&oH'
    list_0 = []
    bool_0 = False
    fragment_f_d_0 = FragmentFD(list_0, bool_0)
    fragment_f_d_0.report_retry_fragment(str_0, str_0, str_0, str_0)
    fragment_f_d_0.report_skip_fragment(str_0)
    fragment_f_d_0.fragment_retries = str_0
    fragment_f_d_0._prepare_url(str_0, str_0)

# Generated at 2022-06-26 11:15:27.225443
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    list_0 = []
    bool_0 = False
    http_quiet_downloader_0 = HttpQuietDownloader(list_0, bool_0)
    http_quiet_downloader_1 = HttpQuietDownloader(list_0, bool_0)
    http_quiet_downloader_0.report_skip_fragment('#4\n=')


# Generated at 2022-06-26 11:15:29.351979
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # This call is the actual unit test
    test_case_0()

# Unit test execution
if __name__ == "__main__":
   test_HttpQuietDownloader()

# Generated at 2022-06-26 11:15:31.021912
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Test case generator for method FragmentFD.report_skip_fragment()

# Generated at 2022-06-26 11:15:33.549495
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    list_0 = []
    bool_0 = False
    fragment_f_d_0 = FragmentFD(list_0, bool_0)


# Generated at 2022-06-26 11:16:15.089594
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    list_0 = []
    bool_0 = False
    fragment_f_d_0 = FragmentFD(list_0, bool_0)


# Generated at 2022-06-26 11:16:25.767029
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    list_0 = []
    dict_0 = {}
    # pass the following keys in dict_0
    dict_0['continuedl'] = True
    dict_0['quiet'] = True
    dict_0['noprogress'] = True
    dict_0['ratelimit'] = None
    dict_0['retries'] = 0
    dict_0['nopart'] = False
    dict_0['test'] = False
    # pass a list consisting of two elements
    list_0.append(dict_0)
    list_0.append(0)
    # pass the following keys in dict_0
    dict_0['continuedl'] = True
    dict_0['quiet'] = True
    dict_0['noprogress'] = True
    dict_0['ratelimit'] = None

# Generated at 2022-06-26 11:16:31.368784
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    list_0 = []
    bool_0 = False
    fragment_f_d_0 = FragmentFD(list_0, bool_0)
    assert str(fragment_f_d_0.report_skip_fragment(4)) == '[download] Skipping fragment 4...'
    assert fragment_f_d_0.FD_NAME == 'fragment'

# Generated at 2022-06-26 11:16:34.760326
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = '#4\n='
    list_0 = []
    bool_0 = False
    fragment_f_d_0 = FragmentFD(list_0, bool_0)
    test_case_0()


# Generated at 2022-06-26 11:16:36.031136
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Unit tests for methods in class FragmentFD

# Generated at 2022-06-26 11:16:39.348883
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = '#4\n='
    list_0 = []
    bool_0 = False
    fragment_f_d_0 = FragmentFD(list_0, bool_0)


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:16:42.675706
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dict_0 = {'test': False}
    list_0 = []
    bool_0 = False
    http_quiet_downloader_0 = HttpQuietDownloader(list_0, dict_0, bool_0)


# Generated at 2022-06-26 11:16:45.970220
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    self_0 = HttpQuietDownloader(self_0, self_0)


# Generated at 2022-06-26 11:16:47.890453
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:16:50.398670
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:18:16.656733
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    list_1 = [0, 0, 0, 0, 0, 0, 0]
    bool_0 = False
    http_quiet_downloader_0 = HttpQuietDownloader(list_1, bool_0)
    list_2 = [0, 0, 0]
    list_3 = ['v3', 0, -8, '1', 'I', 'o', 0, 0, 0, '\\', 'oZF', -1, -1]
    bool_1 = False
    list_4 = []
    fragment_f_d_0 = FragmentFD(list_4, bool_0)
    list_5 = [0]
    bool_0 = False
    http_quiet_downloader_0 = HttpQuietDownloader(list_5, bool_0)
    # assert http_quiet_downloader_

# Generated at 2022-06-26 11:18:18.943658
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    list_0 = []
    bool_0 = False
    fragment_f_d_0 = FragmentFD(list_0, bool_0)


# Generated at 2022-06-26 11:18:23.914208
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    list_0 = []
    bool_0 = False
    http_quiet_downloader_0 = HttpQuietDownloader(list_0, bool_0)

if __name__ == '__main__':
    import sys
    assert len(sys.argv) >= 2, 'Expected at least 2 arguments, got %d' % len(sys.argv)
    assert sys.argv[1] in ('test_case_0', 'test_HttpQuietDownloader'), 'Expected one of test_case_0, test_HttpQuietDownloader'
    globals()[sys.argv[1]](*sys.argv[2:])

# Generated at 2022-06-26 11:18:27.037105
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = False
    list_0 = []
    fragment_f_d_0 = FragmentFD(list_0, bool_0)

# Generated at 2022-06-26 11:18:37.527154
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class FakeYDL(object):
        def __init__(self):
            self._params = {
                'continuedl': True,
                'quiet': True,
                'noprogress': True,
                'ratelimit': None,
                'retries': None,
                'nopart': False,
                'test': False,
            }
    httpQuietDownloader = HttpQuietDownloader(
        FakeYDL(),
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': None,
            'retries': None,
            'nopart': False,
            'test': False,
        }
    )
    assert httpQuietDownloader.params is not None

# Generated at 2022-06-26 11:18:39.676938
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    list_0 = []
    dict_0 = {}
    http_quiet_downloader_0 = HttpQuietDownloader(list_0, dict_0)


# Generated at 2022-06-26 11:18:50.034270
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Test case 3
    extractor_url = 'http://ur1.ca/jnwxa'
    extractor_info = {'_type': 'url', 'url': 'http://ur1.ca/jnwxa'}
    extractor_params = {}
    params_0 = {'test': True, 'quiet': True}
    params_1 = {'params': params_0}
    downloader_0 = HttpQuietDownloader(params_1, extractor_params)
    downloader_1 = downloader_0.to_screen()

    # Test case 4
    extractor_url = 'http://ur1.ca/jnwxa'
    extractor_info = {'_type': 'url', 'url': 'http://ur1.ca/jnwxa'}
    extractor_params = {}
   

# Generated at 2022-06-26 11:18:53.560008
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    list_0 = []
    bool_0 = False
    fragment_f_d_0 = FragmentFD(list_0, bool_0)
    # assert if the fragment file downloader correctly initialized from the constructor
    assert isinstance(fragment_f_d_0, FragmentFD)


# Generated at 2022-06-26 11:18:56.646941
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    list_0 = []
    bool_0 = False
    http_q_d_0 = HttpQuietDownloader(list_0, bool_0)


# Generated at 2022-06-26 11:18:59.543062
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Test case from class FragmentFD
    list_0 = []
    bool_0 = False
    fragment_f_d_0 = FragmentFD(list_0, bool_0)


# Generated at 2022-06-26 11:21:57.413358
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    print('Testing constructor of class FragmentFD')
    list_0 = []
    bool_0 = False
    fragment_f_d_0 = FragmentFD(list_0, bool_0)
    assert fragment_f_d_0 != None
    assert fragment_f_d_0.FD_NAME == 'fragment'


# Generated at 2022-06-26 11:21:59.134348
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:21:59.689094
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass


# Generated at 2022-06-26 11:22:02.541624
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    list_0 = []
    bool_0 = False
    http_quiet_downloader_0 = HttpQuietDownloader(list_0, bool_0)
    return http_quiet_downloader_0.ydl


# Generated at 2022-06-26 11:22:06.022615
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    list_0 = []
    bool_0 = False
    quiet_downloader_0 = HttpQuietDownloader(list_0, bool_0)


# Generated at 2022-06-26 11:22:08.491480
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Instantiate an object of class HttpQuietDownloader
    a = HttpQuietDownloader(None, None)

    assert a != None
    assert isinstance(a, HttpQuietDownloader)


# Generated at 2022-06-26 11:22:13.701013
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    #TODO: Add your tests here
    print ('No unit tests specified!')
    #logger.debug('Test of constructor of class HttpQuietDownloader with parameters:\n')
    #fragment_f_d_0 = FragmentFD(list_0, bool_0)
    #fragment_f_d_0.report_skip_fragment(str_0)


# Generated at 2022-06-26 11:22:17.181738
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    list_0 = []
    dict_0 = {
        'foo': 'bar',
        'baz': 'qux',
    }
    http_quiet_downloader_0 = HttpQuietDownloader(list_0, dict_0)


# Generated at 2022-06-26 11:22:19.085305
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl_0 = True
    extra_0 = False
    http_quiet_downloader_0 = HttpQuietDownloader(ydl_0, extra_0)


# Generated at 2022-06-26 11:22:20.602719
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    param_0 = ['', True]
    http_quiet_downloader_0 = HttpQuietDownloader(*param_0)
