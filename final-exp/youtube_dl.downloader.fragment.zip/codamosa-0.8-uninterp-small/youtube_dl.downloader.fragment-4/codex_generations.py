

# Generated at 2022-06-26 11:13:40.781197
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Constructor test case

    # Test #0
    str_0 = ''
    fragment_f_d_0 = FragmentFD(str_0, str_0)


# Generated at 2022-06-26 11:13:44.261420
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    fragment_f_d_0 = FragmentFD(str_0, str_0)



# Generated at 2022-06-26 11:13:45.645530
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:13:46.948547
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    h_q_downloader = HttpQuietDownloader(None, None)


# Generated at 2022-06-26 11:13:48.430907
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:14:00.641138
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert 'tmpfilename' not in [encodeFilename("i'%!2\x19"), encodeFilename("oI,G-(X\x1c")]
    assert not (FragmentFD("(:7t\x0b", "7'\x1c\x06") == encodeFilename("^\x1a-\x1e\x01"))
    assert not (FragmentFD(encodeFilename("'\x1c"), encodeFilename("g\x19\x1e\x1a")) == FragmentFD("5\x0f\x05\x02", encodeFilename("\x1f\x14\x1c\x06")))

# Generated at 2022-06-26 11:14:02.991899
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


if __name__ == "__main__":
    test_FragmentFD()

# Generated at 2022-06-26 11:14:05.559666
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d_0 = FragmentFD({}, {}, {}, {})
    return fragment_f_d_0

# Generated at 2022-06-26 11:14:06.970578
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fileDownloader = HttpQuietDownloader("url")


# Generated at 2022-06-26 11:14:15.523246
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = "4+iU4]/iN\t5I'HV4tel"
    str_1 = "https://github.com/ytdl-org/youtube-dl/"
    str_2 = "4+iU4]/iN\t5I'HV4tel"
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, {'noprogress': True, 'quiet': True, 'test': False, 'retries': 0, 'ratelimit': None, 'continuedl': True, 'nopart': False})
    str_3 = "E?_'<M#N\tG\fWGD3xq[s"
    str_4 = "E?_'<M#N\tG\fWGD3xq[s"
   

# Generated at 2022-06-26 11:14:46.611762
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = "FO:)oNc%sW]O(/1F9*i!v'2[#W8C#=NlZN*T\nQ"
    HttpQuietDownloader(str_0, str_0)


# Generated at 2022-06-26 11:14:52.169268
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_tmp = "4+iU4]/iN\t5I'HV4tel"
    FragmentFD(str_tmp, str_tmp)


# Generated at 2022-06-26 11:15:06.120668
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = "4+iU4]/iN\t5I'HV4tel"
    str_1 = "4+iU4]/iN\t5I'HV4tel"
    dict_0 = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }
    http_q_d_0 = HttpQuietDownloader(str_0, dict_0)
    dict_1 = dict_0

# Generated at 2022-06-26 11:15:17.175868
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = "4+iU4]/iN\t5I'HV4tel"
    fragment_f_d_0 = FragmentFD(str_0, str_0)

# Generated at 2022-06-26 11:15:19.021471
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# vim: set ts=4 sw=4 et:

# Generated at 2022-06-26 11:15:21.729629
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    obj_0 = HttpQuietDownloader(str_0, {str_0, str_0})


# Generated at 2022-06-26 11:15:30.244576
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = "4+iU4]/iN\t5I'HV4tel"
    str_1 = "S`z_74R"

# Generated at 2022-06-26 11:15:32.771952
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = "U6g5i*\tUw;G52A]1_5'(&"
    _ = HttpQuietDownloader(str_0, str_0)


# Generated at 2022-06-26 11:15:34.744219
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert True

if __name__ == '__main__':
    test_case_0()
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:15:37.189202
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    h_q_d_0 = HttpQuietDownloader(None, str_0)
# Local Variables:
# compile-command: "python -m pytest -v test_fragment.py"
# End:

# Generated at 2022-06-26 11:16:21.582577
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:16:32.734899
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    float_0 = -394.0
    http_quiet_downloader_0 = HttpQuietDownloader(float_0, float_0)
    assert http_quiet_downloader_0.report_destination('http://www.littlegolem.net/jsp/game/game.jsp?gid=jg_348466') == None
    assert http_quiet_downloader_0._prepare_filename('E7%cA%iM') == 'E7%cA%iM'
    assert http_quiet_downloader_0.trouble('http://www.littlegolem.net/jsp/game/game.jsp?gid=jg_348466') == None

# Generated at 2022-06-26 11:16:35.101495
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """
    Constructor of class HttpQuietDownloader
    """
    test_case_0()

    test_case_1()



# Generated at 2022-06-26 11:16:36.393242
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()
    pass


# Generated at 2022-06-26 11:16:43.424354
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    int_0 = 851
    str_0 = 'R_\x1c]d\t'
    str_1 = 'I\x06'
    int_1 = 35
    float_0 = -13.7
    float_1 = 6.6
    str_2 = 'uc\b_\x15\x0b\x1c\n-\x17'
    float_2 = -89.6
    float_3 = 3.2
    str_3 = '\x1c'
    int_2 = 406
    float_4 = -12.4
    float_5 = -462.9
    float_6 = -3.3
    float_7 = -18.1
    float_8 = 1.5
    list_0 = []
    list_1 = []

# Generated at 2022-06-26 11:16:48.353930
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    float_0 = -967.0
    http_quiet_downloader_0 = HttpQuietDownloader(float_0, float_0)
    http_quiet_downloader_0.to_screen()


# Generated at 2022-06-26 11:16:51.964986
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Test HttpQuietDownloader class constructor
    test_case_0()
    # Skipped:
    # def __init__(self, ydl, params, progress_hooks, downloader_hooks):



# Generated at 2022-06-26 11:16:56.640994
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'f4m'
    float_0 = 14.928
    float_1 = 2.536
    file_downloader_0 = FragmentFD(float_0, float_1)
    file_downloader_0.report_destination(str_0)
    file_downloader_0.to_screen()


# Generated at 2022-06-26 11:17:05.639685
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = '7D`e4Ldb`fcipT'
    str_1 = 'Gu\r'
    list_0 = [str_0, str_0, str_1]
    float_0 = -394.0
    fragment_fd_0 = FragmentFD(float_0, float_0)
    var_0 = fragment_fd_0.report_destination(*list_0)
    str_2 = 'b\rY`H\r'
    str_3 = '\\dvhpfj'
    list_1 = [str_2, str_3]
    float_1 = -7.9444
    var_1 = fragment_fd_0.to_screen(*list_1)
    var_2 = fragment_fd_0.temp_name(str_2)
    str_

# Generated at 2022-06-26 11:17:07.752128
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    float_0 = -394.0
    http_quiet_downloader_0 = HttpQuietDownloader(float_0, float_0)


# Generated at 2022-06-26 11:18:40.530099
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = 0.0
    params = 0.0
    http_quiet_downloader_0 = HttpQuietDownloader(ydl, params)
    assert isinstance(http_quiet_downloader_0, HttpQuietDownloader)


# Generated at 2022-06-26 11:18:43.324852
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_FD_0 = FragmentFD()
    test_case_0()

if __name__ == "__main__":
    test_FragmentFD()

# Generated at 2022-06-26 11:18:53.282265
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    __DUMMY_0 = None
    __DUMMY_1 = 0.0
    __DUMMY_2 = ''
    __DUMMY_3 = {}
    __DUMMY_4 = []
    __DUMMY_5 = ()
    __DUMMY_6 = False
    __DUMMY_7 = None
    float_0 = -0.0
    float_1 = -1.0
    float_2 = -2.0
    float_3 = -3.0
    float_4 = -4.0
    float_5 = -5.0
    float_6 = -6.0
    float_7 = -7.0
    float_8 = -8.0
    float_9 = -9.0
    float_10 = -10.0
    float_11 = -11

# Generated at 2022-06-26 11:18:54.246151
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:18:57.013552
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    filename = encodeFilename('testflie')
    fragmentfd_0 = FragmentFD({'filename': filename})
    del fragmentfd_0

# Generated at 2022-06-26 11:18:58.981712
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:19:01.295955
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    for _ in [0]: print('Unit test for constructor of class FragmentFD')
    test_case_0()



# Generated at 2022-06-26 11:19:02.239557
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:19:07.842586
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = '7D`e4Ldb`fcipT'
    str_1 = 'Gu\r'
    list_0 = [str_0, str_0, str_1]
    float_0 = -394.0
    fragmentfd_0 = FragmentFD(float_0, float_0)
    var_0 = fragmentfd_0.to_screen(*list_0)


# Generated at 2022-06-26 11:19:19.016733
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    float_0 = -394.0
    float_1 = -10.0
    float_2 = -10.0
    float_3 = -10.0
    float_4 = -10.0
    var_0 = FragmentFD.__new__(FragmentFD, float_0, float_1, float_2, float_3)
    assert isinstance(var_0, FragmentFD)
    var_1 = FragmentFD.__init__(var_0, float_0, float_2, float_3)
    assert var_1 is None
    str_0 = '7D`e4Ldb`fcipT'
    str_1 = 'Gu\r'
    list_0 = [str_0, str_0, str_1]

# Generated at 2022-06-26 11:22:44.381432
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragmentfd_0 = FragmentFD(None, None)


# Generated at 2022-06-26 11:22:54.026787
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = '7D`e4Ldb`fcipT'
    list_0 = [str_0, str_0, str_0]
    float_1 = -497.0
    fragment_fd_0 = FragmentFD(float_1, list_0)
    var_0 = fragment_fd_0.to_screen(*list_0)
    var_1 = fragment_fd_0.trouble(float_1, list_0)
    str_1 = '\u000b'
    list_1 = [str_0, str_0, str_1]
    float_3 = -376.0
    var_2 = fragment_fd_0.report_error(*list_1)
    var_3 = fragment_fd_0.report_warning(*list_1)
    var_4 = fragment

# Generated at 2022-06-26 11:23:01.179941
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_quiet_downloader_0 = HttpQuietDownloader(7, -394.0)
    assert isinstance(http_quiet_downloader_0, HttpQuietDownloader)
    assert str(http_quiet_downloader_0) == "<HttpQuietDownloader ydl=7 params={'continuedl': True, 'quiet': True, 'noprogress': True, 'ratelimit': None, 'retries': 0, 'nopart': False, 'test': False}>"
    assert isinstance(http_quiet_downloader_0.to_screen(), None)
    http_quiet_downloader_0.add_progress_hook()
    assert http_quiet_downloader_0.download() == False


# Generated at 2022-06-26 11:23:01.916972
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:23:06.076757
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    float_0 = -11.0
    float_1 = -6.0
    float_2 = 5.0
    fragment_fd_0 = FragmentFD(float_1, float_0, float_2)
    assert fragment_fd_0.FD_NAME == 'fragment'
