

# Generated at 2022-06-26 11:13:41.309280
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


# Generated at 2022-06-26 11:13:47.696811
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bytes_0 = b'\xbb_\x90a\xc8\x7f\t\xe8\n\xfd\xf0'
    tuple_0 = None
    http_quiet_downloader_0 = HttpQuietDownloader(bytes_0, tuple_0)
    assert http_quiet_downloader_0.params == {'quiet': True, 'noprogress': True}
    assert http_quiet_downloader_0.ydl == b'\xbb_\x90a\xc8\x7f\t\xe8\n\xfd\xf0'


# Generated at 2022-06-26 11:13:54.171604
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = b'\xbb_\x90a\xc8\x7f\t\xe8\n\xfd\xf0'
    tuple_0 = None
    http_quiet_downloader_0 = HttpQuietDownloader(bytes_0, tuple_0)
    fragment_fd_0 = FragmentFD(http_quiet_downloader_0)
    assert fragment_fd_0 != None


# Generated at 2022-06-26 11:14:00.217540
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = b'\xbb_\x90a\xc8\x7f\t\xe8\n\xfd\xf0'
    tuple_0 = None
    http_quiet_downloader_0 = HttpQuietDownloader(bytes_0, tuple_0)
    pass

# Generated at 2022-06-26 11:14:01.353603
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()



# Generated at 2022-06-26 11:14:10.784237
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = b'\x03\xe2\x83^\xac\x9b\x8b\x0f\x06b\x82E\xa1'
    tuple_0 = (b'\x00\x06j\x02\x05\xe2\xcc\xc8\x14\xfa\x94\x9br\x8d\xfd\x82\xfd',)
    assert_equals(FragmentFD(bytes_0, tuple_0), None)


# Generated at 2022-06-26 11:14:13.772471
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass
    # TODO: Add test for __init__()


# Generated at 2022-06-26 11:14:21.395335
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bytes_0 = b'\xbb_\x90a\xc8\x7f\t\xe8\n\xfd\xf0'
    tuple_0 = None
    http_quiet_downloader_0 = HttpQuietDownloader(bytes_0, tuple_0)


# Generated at 2022-06-26 11:14:27.262576
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Arrange
    ydl = b'\xbb_\x90a\xc8\x7f\t\xe8\n\xfd\xf0'
    params = None

    # Act
    http_quiet_downloader_0 = HttpQuietDownloader(ydl, params)

    # Assert
    assert http_quiet_downloader_0.YDl != None
    assert http_quiet_downloader_0.Params != None


# Generated at 2022-06-26 11:14:28.555487
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:14:50.669677
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

test_HttpQuietDownloader()

# Generated at 2022-06-26 11:14:52.772082
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # This is a dummy test for the sake of coverage.py
    test_case_0()

# Generated at 2022-06-26 11:15:06.527879
# Unit test for constructor of class FragmentFD

# Generated at 2022-06-26 11:15:07.502367
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()



# Generated at 2022-06-26 11:15:19.116947
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class_0 = FragmentFD(None)
    var_0 = class_0.FD_NAME
    str_0 = '<class \'__main__.FragmentFD\'>'
    method_0 = class_0.__repr__()
    bool_0 = method_0 == str_0
    str_1 = '__main__.FragmentFD'
    method_1 = class_0.__str__()
    bool_1 = method_1 == str_1
    var_1 = class_0.process
    var_2 = class_0.max_retries
    int_0 = class_0.retry_count
    dict_0 = class_0.params
    str_2 = '<!Ep>U6bzcj\'@:lh8>w'
    class_0.to_screen

# Generated at 2022-06-26 11:15:23.928808
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD('url', {'merge_output_format': 'm3u8_native'})
    list_0 = []
    var_0 = fragment_fd_0.to_screen(*list_0)
    str_0 = "http://example.com/video.mp4"
    dict_0 = {'merge_output_format': 'm3u8_native', 'http_headers': {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'}, 'fragment_base_url': 'http://example.com/video_fragments/'}

# Generated at 2022-06-26 11:15:25.167263
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    obj = FragmentFD()
    assert isinstance(obj, FragmentFD)


# Generated at 2022-06-26 11:15:30.708971
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = "{. ?D<4@<cSxU#.^B"
    bytes_0 = b'C[\x0b\xdb\x91K\x0c'
    set_0 = {str_0, bytes_0, str_0}
    fragmentfd_0 = FragmentFD(str_0, set_0)
    list_0 = []
    var_0 = fragmentfd_0.to_screen(*list_0)
    var_1 = fragmentfd_0.to_screen()

# Generated at 2022-06-26 11:15:31.455837
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:15:39.801552
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD()
    tuple_0 = ('',)
    str_0 = 'https://google.com/'
    dict_0 = {str_0: tuple_0}
    list_0 = []
    fragment_fd_0.report_retry_fragment(dict_0, list_0, list_0, list_0)
    fragment_fd_0.report_skip_fragment(list_0)
    fragment_fd_0.download(list_0, dict_0)
    fragment_fd_0.download()
    fragment_fd_0.download(list_0)


# unit tests
if __name__ == '__main__':
    test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:16:26.932748
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class_0 = FragmentFD('S;{ ?D<4@<cSxU#.^B', 'S;{ ?D<4@<cSxU#.^B')
    assert class_0._prepare_url({'http_headers': 'S;{ ?D<4@<cSxU#.^B'}, 'S;{ ?D<4@<cSxU#.^B') == "\'/S;{ ?D<4@<cSxU#.^B\'"

test_case_0()
test_FragmentFD()

# Generated at 2022-06-26 11:16:36.305808
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD(None, None)
    str_0 = "&*Lkxs\\Rr<|rT.T\\}=@"
    list_0 = []
    set_0 = {'l_G', '6C|}\x0bU', '5)`:F', 'fXo"d8'}
    fragment_fd_0.report_retry_fragment(str_0, *list_0)
    fragment_fd_0.report_skip_fragment(*list_0)
    fragment_fd_0._prepare_and_start_frag_download(set_0)
    fragment_fd_0._finish_frag_download(set_0)


# Generated at 2022-06-26 11:16:43.381025
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    FD_NAME_0 = ""
    temp_name_0 = {'nopart': True}
    try_rename_0 = {'nopart': True}
    fragmentfd_0 = FragmentFD(FD_NAME_0, temp_name_0, try_rename_0)
    temp_name_1 = {'nopart': False}
    try_rename_1 = {'nopart': True}
    fragmentfd_1 = FragmentFD(FD_NAME_0, temp_name_1, try_rename_1)
    temp_name_2 = {'nopart': False}
    try_rename_2 = {'nopart': False}
    fragmentfd_2 = FragmentFD(FD_NAME_0, temp_name_2, try_rename_2)



# Generated at 2022-06-26 11:16:55.578562
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    dict_0 = {
        'filetime': 0.0,
        'resume_len': 0,
        'quiet': True,
        'noprogress': True,
        'retries': 0,
        'retry_on_http_error': (),
        'live': False,
    }
    frag_fd_0 = FragmentFD(None, dict_0)
    frag_fd_0.report_warning('LA<SI[\x87\x9e\x8a\xceDT')
    frag_fd_0.calc_eta(0.999274, 0.999274, 143116, 143116)
    frag_fd_0.calc_eta(0.999274, 0.999274, 143116, 143116)

# Generated at 2022-06-26 11:17:04.847525
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Constructor call containing string and set of string, bytes and string
    str_0 = "'S;{ ?D<4@<cSxU#.^B"
    bytes_0 = b'C[\x0b\xdb\x91K\x0c'
    set_0 = {str_0, bytes_0, str_0}
    fragmentfd_0 = FragmentFD(str_0, set_0)
    # Call to 'to_screen' with no arguments
    str_1 = "'S;{ ?D<4@<cSxU#.^B"
    bytes_1 = b'C[\x0b\xdb\x91K\x0c'
    set_1 = {str_1, bytes_1, str_1}
    http_quiet_downloader_0 = H

# Generated at 2022-06-26 11:17:07.618849
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = '`'
    list_0 = []
    set_0 = {str_0}
    print(test_case_0())

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:17:17.020119
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    arg_0 = "'S;{ ?D<4@<cSxU#.^B"

# Generated at 2022-06-26 11:17:22.714997
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = b'\x10\xd7\x11\xdb'
    bytes_0 = b'\x89\x8c\xeb\x18'
    set_0 = {str_0, bytes_0, str_0}
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, set_0)
    list_0 = [b'\x00\x00\x00\x00', b'\x8d\x92\xea\x11']
    var_0 = http_quiet_downloader_0.to_screen(*list_0)
    var_1 = http_quiet_downloader_0.to_screen()


# Generated at 2022-06-26 11:17:23.791874
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_0 = FragmentFD()


# Generated at 2022-06-26 11:17:25.324570
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    root = None
    ut = UnitTest(test_case_0)
    ut.run()

# Generated at 2022-06-26 11:19:04.607629
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = '\x12\xb0\xcd\x06\xda\x96\x12\x94\x18\xac\xbb\x8d\x9f\x0f\x88\x8a\x12\x0b\xc0\x01\x8c\x1d\x1b!a\x7fS\xdaK\n'

# Generated at 2022-06-26 11:19:07.736105
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_quiet_downloader_0 = HttpQuietDownloader()
    assert type(http_quiet_downloader_0) == HttpQuietDownloader

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:19:09.858043
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:19:16.572662
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = "'S;{ ?D<4@<cSxU#.^B"
    bytes_0 = b'C[\x0b\xdb\x91K\x0c'
    set_0 = {str_0, bytes_0, str_0}
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, set_0)
    var_0 = http_quiet_downloader_0.to_screen()

# Generated at 2022-06-26 11:19:24.027788
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = "test_case_0"
    dict_0 = {}
    list_0 = []
    fragment_fd = FragmentFD(dict_0, list_0)
    fragment_fd.to_screen()
    fragment_fd.report_skip_fragment()
    var_0 = fragment_fd.__do_ytdl_file()
    fragment_fd._start_frag_download()
    fragment_fd._read_ytdl_file()
    fragment_fd._write_ytdl_file()
    fragment_fd._download_fragment()
    fragment_fd._append_fragment()
    fragment_fd._prepare_url()
    fragment_fd._prepare_frag_download()
    fragment_fd._prepare_and_start_frag_download()
    fragment_

# Generated at 2022-06-26 11:19:25.530943
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:19:26.449386
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:19:28.858543
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    _ = HttpQuietDownloader("", {})

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:19:35.745228
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = "'S;{ ?D<4@<cSxU#.^B"
    set_0 = {str_0, str_0}
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, set_0)
    assert http_quiet_downloader_0._opts == set_0
    assert http_quiet_downloader_0._ydl == str_0


# Generated at 2022-06-26 11:19:38.881254
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # get the instance of FragmentFD
    fragment_fd = FragmentFD()
    # test the constructor of FragmentFD
    assert isinstance(fragment_fd, FragmentFD)


# Generated at 2022-06-26 11:22:51.973502
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        test_case_0()
    except Exception as e:
        print('Caught exception: ' + str(e))


# Generated at 2022-06-26 11:23:00.395631
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    params_0 = {'proxy': '', 'format': 'lax', 'sleep_interval': -1, 'source_address': '', 'retries': 3, 'skip_unavailable_fragments': True, 'playlistend': -1, 'max_downloads': -1, 'writethumbnail': True, 'writethumbnail': True, 'username': '', 'password': '', 'continuedl': True, 'quiet': True, 'noprogress': True, 'ratelimit': '', 'retries': 0, 'nopart': False, 'test': False}
    ydl_0 = 'C[\x0b\xdb\x91K\x0c'

# Generated at 2022-06-26 11:23:01.917658
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # FragmentFD(self, ydl)
    frag_fd = FragmentFD(None)
    print(frag_fd)


# Generated at 2022-06-26 11:23:03.009673
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass


# Generated at 2022-06-26 11:23:14.195655
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = '\x0c\x03\x1d\x0cq\x1c6\x18\x0c\x07\x14{j'
    dict_0 = {
        '<': True,
        '9\x0e': '\x1f1\x0e\x0e\x06\x06\x0e\x06\x1a\x0f\x04\x1e\x12\x1b\x0f\x07\x0f\x10\x00',
        '=': '\x17\x0c\x1f\x00\x17\x1a\x0f',
        'q': str_0,
    }
    fragment_fd_0 = FragmentFD(str_0, dict_0)
   