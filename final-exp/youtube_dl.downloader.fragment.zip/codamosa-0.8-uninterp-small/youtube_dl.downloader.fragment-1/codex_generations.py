

# Generated at 2022-06-26 11:13:40.523277
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:13:42.038142
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Test case with FD_NAME set to None.
    fragmentFD_0 = FragmentFD(None)

test_case_0()
test_FragmentFD()

# Generated at 2022-06-26 11:13:51.430102
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Test of call to constructor.
    #
    # Test of call to constructor.
    #
    # Test of call to constructor.
    #
    # Test of call to constructor.
    #
    # Test of call to constructor.
    #
    # Test of call to constructor.
    #
    # Test of call to constructor.
    test_case_0()

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:13:53.212904
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:13:55.525367
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    FragmentFD(test_case_0(), test_case_0())

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:13:58.994739
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    list_0 = [0]
    str_0 = 'OwW{O8Pv"hT'
    http_quiet_downloader_0 = HttpQuietDownloader(list_0, str_0)


# Generated at 2022-06-26 11:14:04.222684
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = b'\xc7 \\L\x0ch\xcce\xdd\xb7\xd6\x97\\\xa5\x8f\xaby\x9a\x85'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = "&H'U\\?f.yAQ"
    fragment_fd_1 = FragmentFD(list_0, str_0)

if __name__ == '__main__':
    test_FragmentFD()
    test_case_0()

# Generated at 2022-06-26 11:14:12.494426
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = b'\xc7 \\L\x0ch\xcce\xdd\xb7\xd6\x97\\\xa5\x8f\xaby\x9a\x85'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    file_downloader_0 = FragmentFD(list_0, list_0)
    # Test whether the constructor is working.
    assert file_downloader_0 != None

if __name__ == "__main__":
    test_FragmentFD()
    test_case_0()

# Generated at 2022-06-26 11:14:13.721126
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:14:18.828429
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # int
    assert type(HttpQuietDownloader(int(), int())) is HttpQuietDownloader

    # list -> str
    test_case_0()


# Generated at 2022-06-26 11:14:44.777453
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = None
    var_1 = {
        'continuedl': True,
        'ratelimit': None,
        'retries': None,
        'quiet': True,
        'noprogress': True,
    }
    http_quiet_downloader_0 = HttpQuietDownloader(var_0, var_1)
    # assert http_quiet_downloader_0 is not None


# Generated at 2022-06-26 11:14:53.676796
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_1 = None
    var_2 = {'continuedl': True, 'quiet': True, 
    'noprogress': True,'ratelimit': None,
    'nopart': False, 'retries': 0, 'test': False
    }
    http_quiet_downloader_0 = HttpQuietDownloader(var_1, var_2)



# Generated at 2022-06-26 11:15:02.274086
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = None
    var_1 = None
    var_2 = HttpQuietDownloader(var_0, var_1)
    assert var_2
    assert var_2.ydl
    assert var_2.ydl.params
    assert not var_2.ydl.params.get('verbose')
    assert var_2.ydl.params.get('quiet')
    assert var_2.ydl.params.get('noprogress')
    assert not var_2.ydl.params.get('writethumbnail')
    assert not var_2.ydl.params.get('writeautomaticsub')
    assert var_2.ydl.params.get('continuedl')
    assert var_2.ydl.params.get('nopart')
    assert not var_2.ydl

# Generated at 2022-06-26 11:15:06.572314
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = None
    var_1 = None
    http_q_d_0 = HttpQuietDownloader(var_0,var_1)


# Generated at 2022-06-26 11:15:09.865451
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # check 'HttpQuietDownloader' actually returns a HttpQuietDownloader object
    var_equal = type(HttpQuietDownloader(123, {})) == HttpQuietDownloader
    assert var_equal == True


# Generated at 2022-06-26 11:15:10.899389
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:15:17.071854
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl_0 = None
    http_quiet_down_0 = HttpQuietDownloader(ydl_0, {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False
    })

# Generated at 2022-06-26 11:15:18.590405
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None)
    assert fd is not None


# Generated at 2022-06-26 11:15:24.217983
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = None
    var_1 = {}
    http_quiet_downloader_0 = HttpQuietDownloader(var_0, var_1)
    assert http_quiet_downloader_0._HttpFD__ydl == var_0
    assert http_quiet_downloader_0._HttpFD__params == var_1


# Generated at 2022-06-26 11:15:26.087378
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_0 = None
    fragment_f_d_var_0 = FragmentFD(var_0)

test_case_0()

# Generated at 2022-06-26 11:15:50.371391
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d = FragmentFD()
    assert isinstance(fragment_f_d, FragmentFD)



# Generated at 2022-06-26 11:15:52.746939
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        assert (test_case_0()) is None
        print('Test case passed.')
    except AssertionError as e:
        print('Test case failed: ' + str(e))


# Generated at 2022-06-26 11:15:54.618918
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # test case 0
    var_0 = None
    http_q_d_0 = HttpQuietDownloader(var_0)


# Generated at 2022-06-26 11:15:58.170546
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # _args = [[],]
    # for arg in _args:
    #     HttpQuietDownloader(*arg)
    pass

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:16:00.746024
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = None
    var_1 = {}
    http_quiet_downloader_0 = HttpQuietDownloader(var_0, var_1)

# Generated at 2022-06-26 11:16:02.259200
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    if __name__ == '__main__':
        test_HttpQuietDownloader()


# Generated at 2022-06-26 11:16:05.081281
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# unit tests end here

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:16:08.476434
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = None # type: YoutubeDL
    opts = {} # type: Dict[str, Any]
    a = HttpQuietDownloader(ydl, opts)
    assert a is not None


# Generated at 2022-06-26 11:16:10.397203
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Test case 0
    test_case_0()


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:16:12.118263
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_0 = None
    fragment_f_d_0 = FragmentFD(var_0)


# Generated at 2022-06-26 11:16:38.628514
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    fragment_f_d_0 = FragmentFD(bool_0, set_0)
    assert bool_0 is bool_0
    assert set_0 is set_0
    assert fragment_f_d_0 is fragment_f_d_0
    assert fragment_f_d_0 is not None


# Generated at 2022-06-26 11:16:39.558287
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:16:40.870777
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader()


# Generated at 2022-06-26 11:16:52.841782
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from random import random

    # Create random double between 0 and 1
    rand_double = random()
    # Initialize a set of bool, undefined
    bool_set = {}
    # Create a fragment file downloader
    frag_downloader = FragmentFD(rand_double, bool_set)
    # Create a dictionary of undefined
    dict_undef = {}
    # Create a boolean variable of undefined
    bool_undef = None
    # Create a set of booleans of undefined
    bool_set_undef = None
    # Call method report_skip_fragment
    # test_case_0 = frag_downloader.report_skip_fragment(dict_undef)
    # test_case_1 = frag_downloader.report_skip_fragment(bool_undef)
    # test_case_2 =

# Generated at 2022-06-26 11:17:02.674640
# Unit test for constructor of class FragmentFD

# Generated at 2022-06-26 11:17:03.716114
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:17:06.866469
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dict_var = {}
    bool_var = True
    set_var = {bool_var, bool_var, bool_var, bool_var}
    http_quiet_downloader_var = HttpQuietDownloader(bool_var, set_var)


# Generated at 2022-06-26 11:17:16.277449
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    dict_0 = {}
    dict_1 = {}
    dict_1['dest_stream'] = dict_0
    dict_1['speed'] = dict_0
    dict_1['prev_frag_downloaded_bytes'] = dict_0
    dict_1['dl'] = dict_0
    dict_1['fragment_index'] = dict_0
    dict_1['fragment_filename_sanitized'] = dict_0
    dict_1['complete_frags_downloaded_bytes'] = dict_0
    dict_1['ytdl_corrupt'] = dict_0
    dict_1['started'] = dict_0
    dict_1['tmpfilename'] = dict_0
    dict_1['filename'] = dict_0
    dict_2 = {}
    dict_2['status'] = dict_0

# Generated at 2022-06-26 11:17:17.682788
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader('youtube-dl')
    ydl.to_screen('hello world')

# Generated at 2022-06-26 11:17:22.782547
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    dict_0 = {}
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    fragment_f_d_0 = FragmentFD(bool_0, set_0)
    fragment_f_d_0.__init__(bool_0, set_0)
    fragment_f_d_0.report_skip_fragment(dict_0)



# Generated at 2022-06-26 11:18:18.865296
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    http_quiet_downloader_0 = HttpQuietDownloader(bool_0, set_0)
    http_quiet_downloader_0.to_screen()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 11:18:19.712067
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass


# Generated at 2022-06-26 11:18:23.671512
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    dict_0 = {}
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    fragment_f_d_0 = FragmentFD(bool_0, set_0)
    list_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    fragment_f_d_0.report_destination(list_0)

if __name__ == "__main__":
    test_FragmentFD()

# Generated at 2022-06-26 11:18:29.341380
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = HttpQuietDownloader(test_case_0, test_case_0)
    assert isinstance(var_0, HttpFD)
    var_0.report_warning(test_case_0)

if __name__ == '__main__':
    test_case_0()
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:18:31.929528
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    quiet_downloader = HttpQuietDownloader(False, {'quiet'})
    assert isinstance(quiet_downloader, HttpQuietDownloader)


# Generated at 2022-06-26 11:18:36.886755
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    dict_0 = {}
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    fragment_f_d_0 = FragmentFD(bool_0, set_0)
    assert isinstance(fragment_f_d_0, FragmentFD)


# Generated at 2022-06-26 11:18:40.757032
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    dict_0 = {}
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    fragment_f_d_0 = FragmentFD(bool_0, set_0)
    fragment_f_d_0.report_retry_fragment(dict_0, bool_0, bool_0, bool_0)

# Generated at 2022-06-26 11:18:47.429272
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    fragment_f_d_0 = FragmentFD(bool_0, set_0)
    fragment_f_d_0.report_skip_fragment({})
    fragment_f_d_0.report_skip_fragment({})
    fragment_f_d_0.report_skip_fragment({})

# Generated at 2022-06-26 11:18:51.951041
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    req_0 = sanitized_Request("https://google.com")
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    fragment_f_d_0 = HttpQuietDownloader(bool_0, set_0)
    var_0 = fragment_f_d_0.download(req_0)

# Generated at 2022-06-26 11:18:58.339379
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    fragment_f_d_0 = FragmentFD(bool_0, set_0)
    assert fragment_f_d_0._hooks == {
        'download_end': [],
        'download_start': [],
        'download_progress': []
    }
    assert callable(fragment_f_d_0.add_progress_hook)
    assert callable(fragment_f_d_0.to_screen)
    assert callable(fragment_f_d_0.report_error)
    assert callable(fragment_f_d_0.report_warning)
    assert fragment_f_d_0.to_stderr == sys.stderr

# Generated at 2022-06-26 11:20:47.000611
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    args_0 = None
    args_1 = None
    # Call the constructor of class HttpQuietDownloader
    http_quiet_downloader_0 = HttpQuietDownloader(args_0, args_1)


# Generated at 2022-06-26 11:20:49.376117
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # TypeError: missing 1 required keyword-only argument: 'params'
    # FragmentFD()
    # test_case_0()
    pass


# Generated at 2022-06-26 11:20:53.571553
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dict_0 = {}
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    http_quiet_downloader_0 = HttpQuietDownloader(bool_0, set_0)
    assert http_quiet_downloader_0


# Generated at 2022-06-26 11:20:54.361331
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


# Generated at 2022-06-26 11:20:55.787084
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == "__main__":
    test_FragmentFD()

# Generated at 2022-06-26 11:20:58.924426
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    http_quiet_downloader_0 = HttpQuietDownloader(bool_0, set_0)

if __name__ == '__main__':
    test_case_0()
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:21:00.229287
# Unit test for constructor of class FragmentFD

# Generated at 2022-06-26 11:21:03.142621
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl_0 = True
    params_0 = {}
    http_quiet_downloader_0 = HttpQuietDownloader(ydl_0, params_0)


# Generated at 2022-06-26 11:21:12.727781
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    fragment_f_d_0 = FragmentFD(bool_0, set_0)
    assert fragment_f_d_0.FD_NAME == 'fragment'
    assert fragment_f_d_0.params == {'retries': 10, 'skip_unavailable_fragments': True}
    assert fragment_f_d_0.ydl is bool_0
    assert fragment_f_d_0.preferredcodec is None
    assert fragment_f_d_0.preferredquality is None


# Generated at 2022-06-26 11:21:16.873038
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    dict_0 = {}
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    fragment_f_d_0 = FragmentFD(bool_0, set_0)
    assert isinstance(fragment_f_d_0, FragmentFD)
