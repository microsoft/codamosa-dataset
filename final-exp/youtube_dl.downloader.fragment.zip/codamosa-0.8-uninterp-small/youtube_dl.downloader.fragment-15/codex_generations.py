

# Generated at 2022-06-26 11:13:42.128839
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Usage of class FragmentFD

# Generated at 2022-06-26 11:13:53.174202
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    _O = '\x0b'
    _N = str_0 = 'GI.fIRGQ'
    _O = '\x0b'
    _N = str_0
    _0 = 'GI.fIRGQ'
    _0 = 'ASDmGv'
    _0 = 'GI.fIRGQ\x0bvASDmGv'
    dict_0 = {_N: _O, str_0: str_0, str_1: str_37}
    fragment_f_d_0 = FragmentFD(str_0, dict_0)

# Generated at 2022-06-26 11:14:00.218134
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'GI.fIRGQ\x0bvASDmGv'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    fragment_f_d_0 = FragmentFD(str_0, dict_0)


# Generated at 2022-06-26 11:14:02.992409
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert type(HttpQuietDownloader(None, None)) == HttpQuietDownloader, 'Constructor works'


# Generated at 2022-06-26 11:14:14.056454
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Call to the constructor of the class FragmentFD
    str_0 = 'GI.fIRGQ\x0bvASDmGv'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    fragment_f_d_0 = FragmentFD(str_0, dict_0)

    # Call to the constructor of the class FragmentFD
    str_0 = 'BmKqGwfz'
    dict_0 = {str_0: str_0}
    fragment_f_d_0 = FragmentFD(str_0, dict_0)

    # Call to the constructor of the class FragmentFD
    str_0 = 'BmKqGwfz'
    dict_0 = {str_0: str_0}

# Generated at 2022-06-26 11:14:15.946684
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert test_case_0() == None

# Generated at 2022-06-26 11:14:23.827033
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = '\x96\x0b\xfb\xd1\xc1\xdb\x9e\xab\xb7}'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, dict_0)


# Generated at 2022-06-26 11:14:27.281068
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Test case #0
    print('test_case_0')
    test_case_0()

test_FragmentFD()

# Generated at 2022-06-26 11:14:28.631779
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    raise Exception()


# Generated at 2022-06-26 11:14:30.078131
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:14:54.521151
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_1 = None
    var_1 = HttpQuietDownloader(var_1, None)
    try:
        test_HttpQuietDownloader()
    except Exception as var_0:
        test_case_0()

# Generated at 2022-06-26 11:15:02.594826
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl, _ = sanitize_open('./__test_file__', 'w')
    ydl.write('\n')
    ydl.close()
    _, temp_name_0 = sanitize_open('./__test_file__', 'w')
    temp_name_0.write('\n')
    temp_name_0.close()

    var_0 = {
        'continuedl': None,
        'quiet': None,
        'noprogress': None,
        'ratelimit': None,
        'retries': None,
        'nopart': None,
        'test': None,
    }

# Generated at 2022-06-26 11:15:08.120358
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_0 = FragmentFD(
        # ydl       :
        None,
        # params    :
        {
            'ratelimit': 0,
            'retries': 0,
            'nopart': False,
            'test': False,
        }
    )


# Generated at 2022-06-26 11:15:08.764351
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:15:10.617561
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = 'Exception'
    assert_equals(var_0, 'Exception')


# Generated at 2022-06-26 11:15:14.303361
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    print('Testing for FragmentFD')

    try:
        test_FragmentFD_0()
        test_FragmentFD_1()
    except AssertionError:
        print('AssertionError raised')
        return


# Generated at 2022-06-26 11:15:17.071569
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_1 = HttpQuietDownloader(
        {},
        {}
    )


# Generated at 2022-06-26 11:15:19.390010
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Create an instance of FragmentFD
f = FragmentFD()


# Generated at 2022-06-26 11:15:21.625420
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = HttpQuietDownloader('', {})


# Generated at 2022-06-26 11:15:30.166166
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = {}
    var_6 = {}
    var_7 = {}
    var_8 = {}
    var_9 = {}
    var_10 = {}
    var_12 = set()
    var_13 = set()
    var_14 = set()
    var_15 = set()
    var_16 = set()
    var_17 = set()
    var_18 = set()
    var_19 = set()
    var_20 = set()
    var_21 = set()
    var_22 = set()
    var_23 = set()
    var_24 = set()
    var_25 = set()
    var_26 = set()
    var_27 = set()
   

# Generated at 2022-06-26 11:16:15.829979
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    print('Testing constructor of class FragmentFD')
    assert FragmentFD.__name__ == 'FragmentFD'


# Generated at 2022-06-26 11:16:26.748431
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    case_0_var_0 = 'ytdl.extractor.youtube: YouTube: HTTP Error 429: '
    case_0_var_0 += 'Too Many Requests'
    case_0_var_1 = 'ytdl.extractor.youtube: YouTube: Unknown server response'
    case_0_var_2 = 'ytdl.extractor.youtube: YouTube: HTTP Error 503: '
    case_0_var_2 += 'Service Unavailable'
    case_0_var_3 = 'ytdl.extractor.youtube: YouTube: HTTP Error 524: '
    case_0_var_3 += 'A Timeout Occurred'
    case_0_var_4 = 'ytdl.extractor.youtube: YouTube: HTTP Error 500: '
    case_0_var_4 += 'Internal Server Error'
   

# Generated at 2022-06-26 11:16:31.563148
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
  # Test
  fd = FragmentFD('media', {'params': {'retries': '10', 'fragment_retries': '5'}}, 'options', 'ydl')
  # Verification
  assert fd.params == {'retries': 10, 'fragment_retries': 5}



# Generated at 2022-06-26 11:16:33.213006
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = FragmentFD.__init__()
    if var_0:
        test_case_0()

# Generated at 2022-06-26 11:16:38.848270
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = HttpQuietDownloader(Exception(), Exception())
    var_0.params.update({
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': Exception(),
        'retries': Exception(),
        'nopart': Exception(),
        'test': Exception()
    })
    var_0.to_screen.__defaults__ = (Exception(),)
    var_0.report_error.__defaults__ = (Exception(),)
    var_0.report_warning.__defaults__ = (Exception(),)
    var_0.report_retry.__defaults__ = (Exception(),)
    var_0.to_stdout.__defaults__ = (Exception(),)
    var_0.to_stderr.__defaults

# Generated at 2022-06-26 11:16:40.831215
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    FD = FragmentFD(None, None)


# Generated at 2022-06-26 11:16:48.401909
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Test that non-callable objects as hooks can't be added
    var_0 = [HttpQuietDownloader, 'http://www.example.com/asdf']
    var_1 = var_0[0]
    var_2 = var_1()
    var_3 = var_0[1]
    try:
        var_4 = var_2.add_info_extractor(var_3)
        raise Exception()
    except TypeError:
        pass


# Generated at 2022-06-26 11:16:53.780958
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = Exception()
    var_1 = FileDownloader({'continuedl': True})
    var_2 = {'continuedl': True, 'quiet': True, 'noprogress': True}
    var_3 = test_case_0
    var_3(arg_0=var_0, arg_1=var_1, arg_2=var_2)

# Generated at 2022-06-26 11:16:56.640682
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_0 = FragmentFD(
        var_0,
        {
            'keep_fragments': False,
        },
    )


# Generated at 2022-06-26 11:16:59.314176
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_1 = FragmentFD(None, None)
    # Assignment statement (line 89)
    var_1.add_default_extra_info = lambda : None


# Generated at 2022-06-26 11:18:32.379208
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_0 = FragmentFD(
        ydl,
        {
            'url': 'url',
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': 100000,
            'retries': 5,
            'nopart': False,
            'test': False
        },
        'filename'
    )


# Generated at 2022-06-26 11:18:32.987203
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


# Generated at 2022-06-26 11:18:34.898869
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    var_0 = FragmentFD()
    var_1 = FragmentFD()


# Generated at 2022-06-26 11:18:40.276985
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    res = HttpQuietDownloader(
        [
            chart_mimetype,
            (
                chart_mimetype,
                None,
                {
                    'default_time': 22,
                    'live': True,
                    'entry_protocol': 'chart_mimetype',
                    'noplaylist': False,
                }
            )
        ],
        {
            'segment_filename': 'fhdb',
        }
    )
    assert res is not None


# Generated at 2022-06-26 11:18:44.042422
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    print("Testing constructor of class FragmentFD")

    ydl = object()
    params = object()
    fd = FragmentFD(ydl, params)
    assert fd.FD_NAME == 'fragment'

    print("Class FragmentFD constructor test passed.")


# Generated at 2022-06-26 11:18:53.845858
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_quiet_downloader_0 = HttpQuietDownloader(
        {},
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'retries': 0,
            'nopart': False,
        }
    )
    assert http_quiet_downloader_0._HttpFD__simulate == False
    assert http_quiet_downloader_0._HttpFD__tb_next_step == None
    assert http_quiet_downloader_0._HttpFD__tb_current_key == None
    assert http_quiet_downloader_0.params == {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'retries': 0,
        'nopart': False,
    }

# Generated at 2022-06-26 11:18:55.934958
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Call constructor of HttpQuietDownloader
    pass


# Generated at 2022-06-26 11:19:00.285027
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert isinstance(HttpQuietDownloader(test_case_0(), {'continuedl': True, 'quiet': True, 'noprogress': True, 'test': False, 'ratelimit': None, 'retries': 0, 'nopart': False}), HttpQuietDownloader)


# Generated at 2022-06-26 11:19:01.867544
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    var_0 = HttpQuietDownloader(None, var_0={})


# Generated at 2022-06-26 11:19:13.977712
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import tempfile
    import json
    import inspect

    def check_fragment_state(self, expected):
        with open(self.fragment_state_filename, 'r') as f:
            state_json = json.load(f)
        self.assertEqual(state_json, expected)
        self.assertTrue(state_json is not None)

    def test_case_0(self):
        # Arrange
        expected_result = """{
  "fragment_index": 1,
  "fragment_count": 3
}"""
        # Act
        fd = FragmentFD(None, {})
        # Assert
        assert expected_result == str(fd)


# Generated at 2022-06-26 11:21:12.686400
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    float_0 = 2831.34
    int_0 = -5126
    set_0 = {int_0, int_0, int_0}
    http_quiet_downloader_0 = HttpQuietDownloader(int_0, set_0)
    assert http_quiet_downloader_0._HttpQuietDownloader__do_download() == None


# Generated at 2022-06-26 11:21:15.500865
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert isinstance(FragmentFD(0, {0, 0, 0}), FragmentFD)
    assert callable(FragmentFD(0, {0, 0, 0}).report_skip_fragment)


# Generated at 2022-06-26 11:21:16.793812
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:21:21.470458
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    int_0 = -1355
    set_0 = {int_0, int_0, int_0}
    http_q_d_0 = HttpQuietDownloader(int_0, set_0)
    assert (http_q_d_0 != None)


# Generated at 2022-06-26 11:21:24.451278
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    int_0 = 1
    int_1 = 2
    dict_0 = {'quiet': int_1}
    http_quiet_downloader_0 = HttpQuietDownloader(int_0, dict_0)


# Generated at 2022-06-26 11:21:26.749626
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

test_FragmentFD()

# Generated at 2022-06-26 11:21:29.052569
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    int_0 = 1008
    set_0 = {int_0, int_0, int_0}
    fragment_fd_0 = FragmentFD(int_0, set_0)
    http_quiet_downloader_0 = HttpQuietDownloader(fragment_fd_0, ({'set_0': set_0},))


# Generated at 2022-06-26 11:21:30.821947
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d_0 = FragmentFD(1, {'download_archive', 'verbose', 'cachedir'})


# Generated at 2022-06-26 11:21:37.639515
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    int_0 = -1966
    set_0 = {int_0, int_0, int_0}
    fragment_f_d_0 = FragmentFD(int_0, set_0)
    var_0 = fragment_f_d_0._finish_frag_download()
    var_1 = fragment_f_d_0._prepare_frag_download()
    var_2 = fragment_f_d_0.report_retry_fragment()
    var_3 = fragment_f_d_0.report_skip_fragment()
    var_4 = fragment_f_d_0._start_frag_download()
    var_5 = fragment_f_d_0._write_ytdl_file()
    var_6 = fragment_f_d_0._read_ytdl

# Generated at 2022-06-26 11:21:39.546503
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Test case that just runs the test_FragmentFD() unit test