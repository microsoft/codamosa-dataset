

# Generated at 2022-06-26 11:13:46.728838
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = b'\xe0&S\xcb\xb5\xc7Tw\xe3\xfa\x9f\x0bpq'
    bytes_1 = b'\x88t\xe3\x98\x94\xa5\x85*\x15\x9f\x9e\x00\r\xd8'
    fragment_f_d_0 = FragmentFD(bytes_0, bytes_1)
    assert isinstance(fragment_f_d_0, FragmentFD)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:13:48.787056
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Wrapper function to call the unit test

# Generated at 2022-06-26 11:13:52.873440
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bytes_0 = b'\xe0&S\xcb\xb5\xc7Tw\xe3\xfa\x9f\x0bpq'
    HttpQuietDownloader(bytes_0, bytes_0)


# Generated at 2022-06-26 11:13:54.272868
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fd = HttpQuietDownloader(1,2)
    return fd

# Generated at 2022-06-26 11:13:57.128518
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:14:05.488255
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = b'\xe0&S\xcb\xb5\xc7Tw\xe3\xfa\x9f\x0bpq'
    fragment_f_d_0 = FragmentFD(bytes_0, bytes_0)
    bytes_1 = b'\x7f\x81\xe4\xae\x91\xfb\x1f\x0b\x9b\xee\x83\xf3k\x06\xe1!\x1e\x88\xc2H\x0f'
    fragment_f_d_0.add_info_extractor(bytes_1)

# Generated at 2022-06-26 11:14:14.253824
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # bytes
    bytes_1 = b'\xe0&S\xcb\xb5\xc7Tw\xe3\xfa\x9f\x0bpq'
    bytes_2 = b'\xe0&S\xcb\xb5\xc7Tw\xe3\xfa\x9f\x0bpq'
    fragment_f_d_1 = FragmentFD(bytes_1, bytes_2)
    # params
    params_1 = {'foo': 'bar'}
    params_2 = {'foo': 'bar'}
    fragment_f_d_2 = FragmentFD(params_1, params_2)
    # ydl
    ydl_1 = {'test_case': 0}
    ydl_2 = {'test_case': 0}
    fragment_f_d

# Generated at 2022-06-26 11:14:18.114196
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:14:24.236033
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ins = HttpQuietDownloader('self.to_screen', {'continuedl': True, 'quiet': True, 'noprogress': True})
    assert ins.to_screen == 'self.to_screen'
    assert ins.continuedl == True
    assert ins.quiet == True
    assert ins.noprogress == True


# Generated at 2022-06-26 11:14:26.488450
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(bytes_0, bytes_0)


# Generated at 2022-06-26 11:15:00.724319
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = b'<i\xfc\xf9\xdd9\xad\xd3\x0f#g\xbb\x05\xa3\x92'
    fragment_f_d_0 = FragmentFD(bytes_0, bytes_0)

# Generated at 2022-06-26 11:15:01.520462
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:15:03.858044
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = b'\xe0&S\xcb\xb5\xc7Tw\xe3\xfa\x9f\x0bpq'
    fragment_f_d_0 = FragmentFD(bytes_0, bytes_0)


# Generated at 2022-06-26 11:15:13.506503
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
	bytes_0 = b'\xe0&S\xcb\xb5\xc7Tw\xe3\xfa\x9f\x0bpq'
	dict_0 = {}
	dict_0['ratelimit'] = False
	dict_0['retries'] = 0
	dict_0['nopart'] = False
	dict_0['test'] = False
	dict_0['continuedl'] = True
	dict_0['quiet'] = True
	dict_0['noprogress'] = True

	# Test for constructor
	_HttpQuietDownloader = HttpQuietDownloader(bytes_0, dict_0)
	

# Generated at 2022-06-26 11:15:14.501058
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:15:18.470879
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    print('\n' + 'unit test:  ' + str(FragmentFD))
    test_case_0()
    print('unit test completed:  ' + str(FragmentFD))


# Generated at 2022-06-26 11:15:21.518445
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:15:27.599702
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    with open('test/youtubedl/test_http_quiet_downloader.txt', 'rb') as f:
        input_0 = f.read()
        f.close()
    with open('test/youtubedl/test_http_quiet_downloader_output.txt', 'rb') as o:
        output_0 = o.read()
        o.close()
    a = HttpQuietDownloader(input_0, output_0)
    print("Constructed object of HttpQuietDownloader.")


# Generated at 2022-06-26 11:15:31.344090
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    #http_header_test
    HttpQuietDownloader_test = HttpQuietDownloader(None, {"http-header": "cookie: foo=bar", "http-header": "key: val"})

    assert(HttpQuietDownloader_test.params['http_header'] == [{'cookie': 'foo=bar'}, {'key': 'val'}])


# Generated at 2022-06-26 11:15:31.951876
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass


# Generated at 2022-06-26 11:16:22.069325
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    frag_fd_0 = FragmentFD()
    assert frag_fd_0


# Generated at 2022-06-26 11:16:24.959957
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD('--verbose')

if __name__ == '__main__':
    test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:16:28.185921
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD()
    fragment_fd_0.__init__()
    test_case_0()

test_FragmentFD()

# Generated at 2022-06-26 11:16:29.199744
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:16:30.527686
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:16:34.440860
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bool_0 = False
    bool_1 = True
    http_quiet_downloader_0 = HttpQuietDownloader(bool_0, bool_1)
    assert isinstance(http_quiet_downloader_0, HttpQuietDownloader)



# Generated at 2022-06-26 11:16:35.782546
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    FragmentFD(bool_0, bool_1)


# Generated at 2022-06-26 11:16:36.737954
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:16:38.714051
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()
    print('Pass')

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:16:39.949990
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Test case 0
    test_case_0()

test_FragmentFD()

# Generated at 2022-06-26 11:18:06.055280
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Test parse_codecs method
    bool_0 = False
    bool_1 = True
    fragment_fd_0 = FragmentFD(bool_0, bool_1)


test_case_0()
test_FragmentFD()
print('Success')

# Generated at 2022-06-26 11:18:06.965555
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:18:07.941184
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:18:14.549161
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    int_0 = 2471
    list_0 = [int_0, int_0]
    bool_0 = False
    bool_1 = True
    bool_2 = None
    frag_fd_0 = FragmentFD(bool_0, bool_1, bool_2)
    var_0 = frag_fd_0.report_skip_fragment(*list_0)


# Generated at 2022-06-26 11:18:15.839301
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    frag_fd_0 = FragmentFD(bool(), dict())


# Generated at 2022-06-26 11:18:16.774140
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:18:18.708692
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:18:20.958126
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # AssertionError: expected one of ('downloading', 'finished'), got 'error'
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:18:22.386956
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD(None, False)


# Generated at 2022-06-26 11:18:23.453680
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    file_downloader_0 = FragmentFD()
    test_case_0()

# Generated at 2022-06-26 11:21:29.571586
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class_0 = FragmentFD(False, False)
    return class_0

if __name__ == '__main__':
    print(test_FragmentFD())
    print(test_case_0())

# Generated at 2022-06-26 11:21:30.426440
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()



# Generated at 2022-06-26 11:21:34.476652
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    int_0 = 1593
    list_0 = [int_0, int_0]
    bool_0 = False
    bool_1 = True
    http_quiet_downloader_0 = HttpQuietDownloader(bool_0, bool_1)
    var_0 = http_quiet_downloader_0.to_screen(*list_0)



# Generated at 2022-06-26 11:21:36.393642
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        test_case_0()
    except Exception:
        assert False


# Generated at 2022-06-26 11:21:38.084997
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    __test_case_0()

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:21:39.201041
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:21:41.902412
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    global error_to_compat_str
    output = error_to_compat_str


# Generated at 2022-06-26 11:21:43.352844
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Initialize variables
    # Class: init var
    test_case_0()


test_HttpQuietDownloader()

# Generated at 2022-06-26 11:21:47.074236
# Unit test for constructor of class FragmentFD

# Generated at 2022-06-26 11:21:52.324125
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bool_0 = False
    bool_1 = True
    fragment_fd_0 = FragmentFD(bool_0, bool_1)
    str_0 = fragment_fd_0.ydl_filename('BHdGn2J9Xj0')
    # Assert function returns correct value
    assert str_0 == 'BHdGn2J9Xj0.ytdl', 'FragmentFD constructor failed'