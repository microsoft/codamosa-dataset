

# Generated at 2022-06-26 11:13:41.357792
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_quiet_downloader = HttpQuietDownloader(None, None)
    assert http_quiet_downloader is not None
    assert http_quiet_downloader._TEST_URL == 'http://some.urls.com/long/path.mp4'


# Generated at 2022-06-26 11:13:43.595315
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:13:46.805174
# Unit test for constructor of class FragmentFD

# Generated at 2022-06-26 11:13:51.707433
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = None
    params = None
    http_quiet_downloader = HttpQuietDownloader(ydl, params)

if __name__ == '__main__':
    test_case_0()
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:14:00.577262
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'C\x0e\'\x1a\x1f\x1a7\x0c\x1d'
    fragment_f_d_0 = FragmentFD(str_0, str_0)
    str_1 = '\n\x15`J\x16\x1a'
    assert repr(HttpQuietDownloader(str_1, str_0, {'x': '\x0f\x1d\x1e\x1d\x1d'})) == "<HttpQuietDownloader ydl=\n\x15`J\x16\x1a; params={'x': '\x0f\x1d\x1e\x1d\x1d'}>"

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:14:01.669492
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader


# Generated at 2022-06-26 11:14:07.238048
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bytes_0 = b'GB\xd4\xb35'
    str_0 = '-?FvPyVkN_d%L8/PT3\x0c'
    http_q_d_0 = HttpQuietDownloader(bytes_0, str_0)


# Generated at 2022-06-26 11:14:09.625075
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

# Generated at 2022-06-26 11:14:15.617954
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bytes_0 = b'GB\xd4\xb35'
    str_0 = '-?FvPyVkN_d%L8/PT3\x0c'
    HttpQuietDownloader_0 = HttpQuietDownloader(bytes_0, str_0)

# Descriptor for test_case_1()

# Generated at 2022-06-26 11:14:27.917304
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = b'GB\xd4\xb35'
    str_0 = '-?FvPyVkN_d%L8/PT3\x0c'
    fragment_f_d_0 = FragmentFD(bytes_0, str_0)
    assert not hasattr(fragment_f_d_0, 'ytdl_corrupt')
    assert not hasattr(fragment_f_d_0, 'fragment_index')
    assert not hasattr(fragment_f_d_0, 'fragment_count')
    assert not hasattr(fragment_f_d_0, 'fragment_filetime')
    assert not hasattr(fragment_f_d_0, 'fragment_filename_sanitized')

# Generated at 2022-06-26 11:14:49.129532
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    return FragmentFD


# Generated at 2022-06-26 11:14:52.398176
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_qu_d_0 = HttpQuietDownloader(None, None)


# Generated at 2022-06-26 11:14:59.459367
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = b'\x19\x0b\x18\x03\x0f\x13\x1cF\x16\x04\x0c\x1a\x1f\x18\x1c\x04'
    str_0 = 'XF@\x1dRx\x0f\x11\x15\x01\x13\x00\x1f\x1e\x04'
    fragment_f_d_0 = FragmentFD(bytes_0, str_0)


# Generated at 2022-06-26 11:15:08.873488
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    float_0 = 193.0
    bytes_0 = b'\x0f\x91x\x9b\x1f\x89\x81\x07\xc8\xd7H\xa3'
    str_0 = '\x12>\x16&\x14\x1c1\x17'
    fragment_f_d_0 = FragmentFD(bytes_0, str_0)
    var_0 = fragment_f_d_0.report_retry_fragment(float_0)


# Generated at 2022-06-26 11:15:21.414679
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = 'D0\xa6\xc0\xf3\x841\x9e\xb7K'
    dict_0 = {':%4v': 'sK\'\xe0\x9f\x0e3\x89\xf1\xbf~', 'HkN\xa6_': '\xae\x8f\xf9\x1a\xbd\x8c', '\xa4h\x05\xdb\xb9C9\x91': 'O\xbb\x80\xca', '\xea\x1f\xa6\x9c\x04\x0f\xfb\x9e\xd7\x0c': '\x0e\xce\xeb\xda'}

# Generated at 2022-06-26 11:15:29.995375
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bytes_0 = b'_<I\x0c\x1e"\x18'
    str_0 = '\x12\x15\x7f\x0b\x7f\x15\x11\x7f\x0b\x7f\x0b\x7f\x12\x10\x0e\x7f\x1b\x7f\x18'
    dict_0 = {}
    dict_0['quiet'] = True
    dict_0['retries'] = 0
    dict_0['noprogress'] = False
    dict_0['continuedl'] = True
    dict_0['test'] = True
    dict_0['nopart'] = False
    dict_0['ratelimit'] = True
    http_quiet_downloader_0 = Http

# Generated at 2022-06-26 11:15:33.719016
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = b'GB\xd4\xb35'
    str_0 = '-?FvPyVkN_d%L8/PT3\x0c'
    fragment_f_d_0 = FragmentFD(bytes_0, str_0)
    return fragment_f_d_0



# Generated at 2022-06-26 11:15:39.354988
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bytes_0 = b'&&\xa7 '
    str_0 = '%c\x1f\x1d'
    http_quiet_downloader_0 = HttpQuietDownloader(bytes_0, str_0)
    str_1 = str()
    while False:
        str_1 = '\x0fR \t#' + str_1
        http_quiet_downloader_0.to_screen(str_1)
        str_1 = str_1 + '\x0fR \t#'


# Generated at 2022-06-26 11:15:40.780539
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    __test_cases()



# Generated at 2022-06-26 11:15:42.619897
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()
    print('Test finished!')

# Generated at 2022-06-26 11:16:27.768951
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class_0 = HttpQuietDownloader(None)

if __name__ == '__main__':
    test_case_0()
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:16:37.084103
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():

    # Test case: 1
    # Class HttpQuietDownloader has __init__ function,
    # calling the function without parameters will test the function definition
    # and parameters.
    try:
        HttpQuietDownloader()
        return 1
    except TypeError:
        pass

    # Test case: 2
    # Class HttpQuietDownloader has __init__ function,
    # calling the function with parameters will test the function definition
    # and parameters, if the function can work correctly, return True, else
    # return False.
    http_quiet_downloader = HttpQuietDownloader('--skip-download')
    if http_quiet_downloader == '--skip-download':
        return 1
    else:
        return 0


# Generated at 2022-06-26 11:16:41.324506
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bytes_1 = b'RT\xe37#0-0'
    str_1 = 'Z2}=4&\x0bR7d[Wy&'
    http_quiet_downloader_0 = HttpQuietDownloader(bytes_1, str_1)

if __name__ == '__main__':
    test_HttpQuietDownloader()
    test_case_0()

# Generated at 2022-06-26 11:16:47.376248
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Test case 0 is skipped due to problems with calling __init__ of FragmentFD
    # after its superclass' __init__ as it does
    test_case_0()
    print('test cases for FragmentFD passed successfully')

if __name__ == '__main__':
    # test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:16:54.213442
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    float_0 = 0.0
    str_1 = 'YCe)Y'
    str_2 = 'QM@T1g'
    str_4 = 's~1e$-s{BjX<3'
    str_3 = '\x0c'
    http_quiet_downloader_0 = HttpQuietDownloader(float_0, str_1, str_2, str_3, str_4)
    print(http_quiet_downloader_0)


# Generated at 2022-06-26 11:16:55.534685
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


# Generated at 2022-06-26 11:17:01.468643
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bytes_0 = b'u\x0c\x01\x16\xb8\x0f\x0f\x16'
    dict_0 = {'nopart': False, 'test': False, 'noprogress': True, 'quiet': True, 'continuedl': True, 'retries': 0, 'ratelimit': None}
    http_quiet_downloader_0 = HttpQuietDownloader(bytes_0, dict_0)


# Generated at 2022-06-26 11:17:02.471768
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert False


# Generated at 2022-06-26 11:17:08.716989
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


if __name__ == "__main__":
    import sys
    import inspect

    # For some reason the unittest discovery feature does not work, so
    # we manually visit each function beginning with 'test_' and invoke it.
    for klass_name, obj in inspect.getmembers(sys.modules[__name__]):
        if inspect.isclass(obj):
            for meth_name, _ in inspect.getmembers(obj):
                if meth_name.startswith('test_'):
                    print('Invoking', meth_name)
                    globals()[meth_name]()

# Generated at 2022-06-26 11:17:10.447758
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:18:35.104744
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_f_d_0 = FragmentFD()
    assert type(fragment_f_d_0) is FragmentFD


# Generated at 2022-06-26 11:18:42.228805
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bytes_0 = b'\n\r\r\r\x0c\x1c\x1d\x0c\x17\t\x03\x1d\n\x16\x00\x00\x00\x1d\x1d'
    str_0 = '\x04R\x0f$\x0f9\x0c\x17\x1d\x1c\x19\x0b\x00\x01\x10\x1c\x1d\x1d\x1c\x1b\x0c\x1d\x0c\x1d'
    fragment_f_d_0 = HttpQuietDownloader(bytes_0, str_0)


# Generated at 2022-06-26 11:18:44.084643
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:18:53.860824
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    url = 'https://example.com'
    par = {'fragment_retries': 3}
    fragment_fd = FragmentFD(url, par)
    # assert fragment_fd.params == {'fragment_retries': 3, 'retries': 3}
    assert fragment_fd.params == {'fragment_retries': 3, 'retries': 1}
    assert fragment_fd.to_screen == fragment_fd.ydl.to_screen
    # assert fragment_fd.ydl.params == {'fragment_retries': 3, 'retries': 3, 'username': '', 'password': ''}
    assert fragment_fd.ydl.params == {'fragment_retries': 3, 'retries': 1, 'username': '', 'password': ''}

test_case_0

# Generated at 2022-06-26 11:19:01.335318
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bytes_0 = b'mERv\xb1\x1a\x8e'
    str_1 = ' bytes in '
    str_0 = 'downloader'
    boolean_1 = True
    str_3 = '...'
    str_2 = 'in '
    quiet_downloader_0 = HttpQuietDownloader(bytes_0, str_0, boolean_1)
    int_0 = quiet_downloader_0.report_retry_download(str_1, str_2, str_3)


# Generated at 2022-06-26 11:19:10.251735
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = '-?FvPyVkN_d%L8/PT3\x0c'
    str_1 = 'L7jgop<'
    dict_0 = {'continuedl': True, 'quiet': True, 'noprogress': True}
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, dict_0)
    str_2 = http_quiet_downloader_0.download(str_1)
    assert str_2 == '-?FvPyVkN_d%L8/PT3\x0c'

# Generated at 2022-06-26 11:19:13.224040
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Test cases
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:19:17.126521
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes = b'GB\xd4\xb35'
    str = '-?FvPyVkN_d%L8/PT3\x0c'
    fragment_fd = FragmentFD(bytes, str)
    assert fragment_fd.FD_NAME == 'fragment'


# Generated at 2022-06-26 11:19:22.848155
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    float_0 = 482.0
    bytes_0 = b'GB\xd4\xb35'
    str_0 = '-?FvPyVkN_d%L8/PT3\x0c'
    fragment_f_d_0 = FragmentFD(bytes_0, str_0)
    assert b'GB\xd4\xb35' == fragment_f_d_0.params
    assert '-?FvPyVkN_d%L8/PT3\x0c' == fragment_f_d_0.ydl


# Generated at 2022-06-26 11:19:28.220652
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    tmpfilename = 'LRr5q5q/zBNXpjK8='
    http_quiet_downloader_0 = HttpQuietDownloader(None, {'retries': 1})
    http_quiet_downloader_0.report_error('cannot find update-certs')
    var_0 = http_quiet_downloader_0.report_skip_fragment(tmpfilename)


# Generated at 2022-06-26 11:22:49.562675
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    case_0_res = ()

# Generated at 2022-06-26 11:22:58.021796
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = b'z\xd2\x9c%*\xe3\x10'
    str_0 = '|K\x1c\xa6\xab\x1ci\x1ej2\x84\xea'
    fragment_f_d_0 = FragmentFD(bytes_0, str_0)
    # Test `_download_fragment` method
    bytes_ret = b'\x1a\x9f\xbf\xa5\x07\xea\xa2u\x98\x93\x18\n'
    var_0 = fragment_f_d_0._download_fragment(bytes_0, str_0, bytes_ret)
    # Test `_hook_progress` method
    str_1 = ''
    fragment_f_d_0._

# Generated at 2022-06-26 11:23:02.768209
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    bytes_0 = b'<\x17\xec\xbe\xf1@\x8e'
    str_0 = 'tcgf66'
    fragment_f_d_0 = FragmentFD(bytes_0, str_0)
    assert fragment_f_d_0._prepare_frag_download({
        'tmpfilename': 'tmpfilename',
        'fragment_index': 1,
    }) is None
    test_case_0()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-26 11:23:11.935506
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    bytes_0 = b'<VX\x0c2S'
    str_0 = 'E48lJc%4Y4\t\x1b\n'
    dict_0 = {'noprogress': False, \
              'test': True, \
              'quiet': True, \
              'retries': 7, \
              'continuedl': False, \
              'nopart': True, \
              'ratelimit': ')'}
    _HttpQuietDownloader_0 = HttpQuietDownloader(bytes_0, dict_0)
