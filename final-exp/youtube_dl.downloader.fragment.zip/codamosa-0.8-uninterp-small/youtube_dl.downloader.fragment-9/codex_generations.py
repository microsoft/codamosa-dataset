

# Generated at 2022-06-26 11:13:45.563333
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = '_eX_pbuH1nYd^n@=r'
    tuple_0 = ('a', 'b')
    HttpQuietDownloader(str_0, tuple_0)

if __name__ == '__main__':
    # test_HttpQuietDownloader()
    test_case_0()

# Generated at 2022-06-26 11:13:52.787087
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert 1 == 1
    assert 1 != 0
    assert 1 is not None
    assert 1 is not 0
    assert 1 != None
    assert 1 == True
    assert 1 != False
    assert 1 is not False
    assert 1 is not True
    assert 1 != True
    assert 1 == True
    assert 1 != False
    assert 1 is not False
    assert 1 is not True
    assert 1 != True



# Generated at 2022-06-26 11:13:53.907469
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()



# Generated at 2022-06-26 11:13:56.191598
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()

test_FragmentFD()

# Generated at 2022-06-26 11:13:59.134093
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {}
    params = {}
    http_quiet_downloader_0 = HttpQuietDownloader(ydl, params)


# Generated at 2022-06-26 11:14:03.048647
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl_0 = '<>'
    extra_params_0 = {'retries': 0}
    http_quiet_downloader_0 = HttpQuietDownloader(ydl_0, extra_params_0)


# Generated at 2022-06-26 11:14:04.617574
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()


# Generated at 2022-06-26 11:14:13.961982
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ctx = {
        'ytdl_corrupt': True,
        'fragment_index': 20,
        'tmpfilename': '/tmp/test.mp4',
        'filename': '/data/test.mp4',
    }
    ytdl_filename = encodeFilename(FragmentFD.ytdl_filename(ctx['filename']))

# Generated at 2022-06-26 11:14:18.592393
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ss, tt = '', ()
    qq = HttpQuietDownloader(ss, tt)


# Generated at 2022-06-26 11:14:22.803327
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    h_q_d_0 = HttpQuietDownloader(None, None)
    # This test is not essential since this class is an inner class of FragmentFD and thus it is not used in practice


# Generated at 2022-06-26 11:14:52.295865
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = ','
    str_1 = ']"xaI&_>'
    str_2 = "Za"
    str_3 = ':$`'
    str_4 = "\"6e"
    str_5 = '=1&%u"'
    str_6 = '"\r`>y#H\r&\x7f'
    str_7 = 'J\r(:_:'
    str_8 = '\r6e'
    str_9 = 'zU&%\r"'
    str_10 = '\r`>y#H\r&\x7f'
    str_11 = 'L[+}\r8]'
    str_12 = '"\x7f(dh&'
    str_13 = 'Le'

# Generated at 2022-06-26 11:15:03.196837
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    test_case_0()
    str_0 = "7jU)XyU'7{]1H'^VjbL"
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    fragment_fd_0 = FragmentFD(**dict_0)
    str_1 = "2jTk{WiTfqF,W^d"
    dict_1 = {str_1: str_1, str_1: str_1, str_1: str_1}
    fragment_fd_0.report_skip_fragment(**dict_1)


# Generated at 2022-06-26 11:15:05.133440
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
  pass


# Generated at 2022-06-26 11:15:09.884478
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = "]F&7T_?x/8P7V#=Y0ZB"
    str_1 = "8F)0?_K'&k]x>p7$R0%"
    dict_0 = {str_1: str_1, str_1: str_1, str_1: str_1, str_1: str_1, str_1: str_1}
    dict_1 = dict_0
    dict_1['test'] = False
    fragment_fd_0 = FragmentFD(str_0, dict_1)
    var_0 = fragment_fd_0._hook_progress(**dict_0)


# Generated at 2022-06-26 11:15:22.471577
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    passed = 0
    failed = 0
    for i in range(0, 10):
        try:
            test_case_0()
            passed += 1
        except:
            failed += 1
    print("Test FragmentFD")
    print("Passed:" + str(passed))
    print("Failed:" + str(failed))
    # If failed and passed both are zero that means no test was executed due to some internal error
    if (passed == 0 and failed == 0):
        print("Test Failed")
        return
    # Internal Error
    elif (passed == 0 and failed > 0):
        print("Test Failed")
        return
    # All passed
    elif (passed > 0 and failed == 0):
        print("Test Passed")
        return

    # Some cases passed and some failed

# Generated at 2022-06-26 11:15:25.263177
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    print("Testing constructor HttpQuietDownloader: ", end='')
    test_case_0()
    print("Pass")

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:15:32.546942
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = ""
    dict_0 = {}
    frag_fd_0 = FragmentFD(str_0, dict_0)

    str_1 = "\x1f|\xeb\xfe\xa3"
    dict_1 = {str_1: str_1, str_1: str_1, str_1: str_1}
    frag_fd_0.to_screen(**dict_1)

    str_2 = "Kj\x0f\x08\xf4\x0b"
    dict_2 = {str_2: str_2, str_2: str_2, str_2: str_2}
    frag_fd_0.report_retry_fragment(str_2, str_2, str_2, dict_2)


# Generated at 2022-06-26 11:15:35.230193
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    print("Run unit test for constructor of class HttpQuietDownloader")
    test_case_0()
    print("End")

if __name__ == "__main__":
    test_HttpQuietDownloader()

# Generated at 2022-06-26 11:15:43.916022
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = "*m-#ZF^MPh]3NzV/a"
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    fragment_fd_0 = FragmentFD(str_0, dict_0)
    fragment_fd_0.report_skip_fragment(**dict_0)
    fragment_fd_0.report_retry_fragment(**dict_0)
    fragment_fd_0._start_frag_download(**dict_0)
    fragment_fd_0._prepare_frag_download(**dict_0)
    fragment_fd_0._prepare_and_start_frag_download(**dict_0)

# Generated at 2022-06-26 11:15:45.263307
# Unit test for constructor of class HttpQuietDownloader

# Generated at 2022-06-26 11:16:27.724435
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD('1', '2', {})


# Generated at 2022-06-26 11:16:37.731356
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = "\u0007"
    str_1 = "w"
    str_2 = "J9l"
    str_3 = '\\\xa1'
    str_4 = "b"
    str_5 = "Z"
    str_6 = "Yg"
    str_7 = "5R"
    str_8 = "|P"
    str_9 = "*"
    str_10 = "]"
    str_11 = "r"
    str_12 = "i\u0007"
    str_13 = "C"
    str_14 = "}"
    str_15 = "D"
    str_16 = "-"
    str_17 = "y"
    str_18 = "(("
    str_19 = "|"
    str_20 = "Gb"


# Generated at 2022-06-26 11:16:40.054599
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = "}l"
    dict_0 = {}
    # x = FragmentFD(str_0, dict_0)

# Generated at 2022-06-26 11:16:42.813779
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        test_case_0()
    except ValueError:
        return 'exception'

if __name__ == '__main__':
    print(test_HttpQuietDownloader())

# Generated at 2022-06-26 11:16:43.471426
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass


# Generated at 2022-06-26 11:16:54.286508
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    to_screen_1 = HttpQuietDownloader.to_screen
    to_screen_1(('CG\'w>\tQ\\tT[\\ \'Ra-:', '.\tI$\'r%cH', 'CG\'w>\tQ\\tT[\\ \'Ra-:'), **{'CG\'w>\tQ\\tT[\\ \'Ra-:': 'CG\'w>\tQ\\tT[\\ \'Ra-:', '.\tI$\'r%cH': '.\tI$\'r%cH', 'CG\'w>\tQ\\tT[\\ \'Ra-:': 'CG\'w>\tQ\\tT[\\ \'Ra-:'})


# Generated at 2022-06-26 11:17:02.676081
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl_0 = ''
    params_0 = {}
    try:
        str_0 = "CG'w>\tQ\\tT[\\ 'Ra-:"
        dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
        str_1 = "vW'$-P0'8F)"
        dict_1 = {}
        http_quiet_downloader_0 = HttpQuietDownloader(str_1, dict_1)
        var_0 = http_quiet_downloader_0.to_screen(**dict_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 11:17:03.662670
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()

# Generated at 2022-06-26 11:17:06.829750
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = "f&Y"
    dict_0 = {str_0: str_0}
    fragment_fd_0 = FragmentFD(str_0, dict_0)
    assert fragment_fd_0.FD_NAME == "fragment"


# Generated at 2022-06-26 11:17:07.693006
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:18:36.096231
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = 'lX>|tsl'
    dict_0 = {}
    fragmentfd_0 = FragmentFD(str_0, dict_0)

if __name__ == '__main__':
    test_case_0()
    # test_FragmentFD()

# Generated at 2022-06-26 11:18:36.745410
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()



# Generated at 2022-06-26 11:18:42.648314
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fragment_fd_0 = FragmentFD(None, None, None)
    var_2 = fragment_fd_0.report_skip_fragment(1)
    var_0 = fragment_fd_0.report_retry_fragment(
        ValueError(),
        0,
        int(1),
        {int(0): None}
    )
    var_1 = fragment_fd_0._prepare_and_start_frag_download({str(): None})
    

# Generated at 2022-06-26 11:18:48.359727
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    global http_quiet_downloader_0
    str_0 = http_quiet_downloader_0[str_1]
    http_quiet_downloader_0.to_screen(str_0)
    http_quiet_downloader_0.report_warning('.')
    http_quiet_downloader_0.report_error('8', 'C@')


# Generated at 2022-06-26 11:18:54.162623
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = "r``.^:U**F&m\x0e\x0cX"
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = "s@H0,\x16>W\x0f\\t)"
    dict_1 = {}
    fragment_fd_0 = FragmentFD(str_1, dict_1)
    var_0 = fragment_fd_0._prepare_url(**dict_0)

# Generated at 2022-06-26 11:19:03.622133
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = "CG'w>\tQ\\tT[\\ 'Ra-:"
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = "vW'$-P0'8F)"
    dict_1 = {}
    http_quiet_downloader_0 = HttpQuietDownloader(str_1, dict_1)
    assert f'<{__name__}.HttpQuietDownloader object at 0x{id(http_quiet_downloader_0)}>' == f'<{__name__}.HttpQuietDownloader object at 0x{id(http_quiet_downloader_0)}>'
    assert __name__ == __name__

# Generated at 2022-06-26 11:19:07.431263
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = "9j=Bh<]Q2wVy"
    dict_0 = {}
    http_quiet_downloader_0 = HttpQuietDownloader(str_0, dict_0)


# Generated at 2022-06-26 11:19:16.790176
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = "CG'w>\tQ\\tT[\\ 'Ra-:"
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = "vW'$-P0'8F)"
    dict_1 = {}
    http_quiet_downloader_0 = HttpQuietDownloader(str_1, dict_1)
    var_0 = http_quiet_downloader_0.to_screen(**dict_0)

    print('Unit test of HttpQuietDownloader class')
    return None

# Generated at 2022-06-26 11:19:23.616469
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Create instance of FragmentFD
    fragmentfd_0 = FragmentFD('youtube-dl', 'youtube-dl')
    int_0 = fragmentfd_0.calc_eta('youtube-dl', str(int_0), 'youtube-dl', int_0)
    int_1 = fragmentfd_0.calc_eta('youtube-dl', str(int_0), 'youtube-dl', int_0)
    int_2 = fragmentfd_0.calc_eta('youtube-dl', str(int_0), 'youtube-dl', int_0)
    str_0 = fragmentfd_0.calc_eta('youtube-dl', str(int_0), 'youtube-dl', int_0)


# Generated at 2022-06-26 11:19:34.578174
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_2 = 'B.h#BRH'
    str_3 = 'f'
    dict_2 = {}
    http_quiet_downloader_1 = HttpQuietDownloader(str_3, dict_2)
    fragment_fd_0 = FragmentFD(str_2, http_quiet_downloader_1)
    fragment_fd_0.report_retry_fragment(str_2, 0, 1, 1)
    fragment_fd_0.report_retry_fragment(str_3, 2147483647, 0, 2147483647)
    fragment_fd_0.report_skip_fragment(0)
    fragment_fd_0.report_skip_fragment(2147483647)
    str_4 = "'h-B"

# Generated at 2022-06-26 11:22:57.647519
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_case_0()


# Generated at 2022-06-26 11:23:01.825652
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_4 = "^<1$8*1W)i"
    dict_4 = {str_4: str_4, str_4: str_4, str_4: str_4}
    str_5 = "EF)'E)81e)"
    fragmentfd_0 = FragmentFD(str_5, dict_4)

if __name__ == '__main__':
    test_case_0()
    test_FragmentFD()

# Generated at 2022-06-26 11:23:09.081579
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    str_0 = "l@^/1gDXt"
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = "vW'$-P0'8F)"
    fragment_fd_0 = FragmentFD(str_1, dict_0)


# Generated at 2022-06-26 11:23:15.195757
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    str_0 = "CG'w>\tQ\\tT[\\ 'Ra-:"
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = "vW'$-P0'8F)"
    dict_1 = {}
    http_quiet_downloader_0 = HttpQuietDownloader(str_1, dict_1)
    var_0 = http_quiet_downloader_0.to_screen(**dict_0)

test_HttpQuietDownloader()