

# Generated at 2022-06-24 11:42:25.606530
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from ..extractor import gen_extractors
    gen_extractors()
    import logging
    import StringIO
    out = StringIO.StringIO()
    handler = logging.StreamHandler(out)
    logging.getLogger('youtube_dl.downloader.fragment').addHandler(handler)

    fd = FragmentFD()
    fd.report_skip_fragment(1)
    assert out.getvalue() == '[download] Skipping fragment 1...\n'

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:42:26.242571
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-24 11:42:31.411119
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFD(FragmentFD):
        def __init__(self):
            self.retries = {'max': 5, 'min': 3}
            self.screen_data = []

        def to_screen(self, *args, **kargs):
            self.screen_data.append(args[0] % args[1:])

    fd = TestFD()
    fd.report_retry_fragment("error msg", 10, 5, fd.retries)

    assert fd.screen_data[0] == "[download] Got server HTTP error: error msg. Retrying fragment 10 (attempt 5 of 5)..."


# Generated at 2022-06-24 11:42:37.481641
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {'noprogress': True})
    fd.to_screen = lambda *args, **kargs: print(args[0])
    # Check that method generates correct output, see issue #2538
    fd.report_retry_fragment(
        IOError('unknown url type: https'), 1, 1, {'max_tries': 10})
    fd.report_retry_fragment(
        IOError('unknown url type: https'), 1, 2, {'max_tries': 10})
    fd.report_retry_fragment(
        IOError('unknown url type: https'), 2, 1, {'max_tries': 10})


# Generated at 2022-06-24 11:42:41.448254
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class MyYDL(object):
        def to_screen(self, a):
            assert a == 42
    ydl = MyYDL()
    q = HttpQuietDownloader(ydl, {'quiet': True})
    q.to_screen(42)

# Generated at 2022-06-24 11:42:52.779849
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self, ydl):
            self.to_screen_strs = []
            super(TestFragmentFD, self).__init__(ydl)
        def to_screen(self, s):
            self.to_screen_strs.append(s)

    fd = TestFragmentFD(object())
    for retries in range(0, 5):
        fd.to_screen_strs = []
        for fragment_index in range(0, 5):
            fd.report_retry_fragment(ValueError(), fragment_index, 1, retries)

# Generated at 2022-06-24 11:42:58.746018
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader({}, {'foo': '2', 'bar': '3'})

# Generated at 2022-06-24 11:43:10.897337
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from io import StringIO
    from .fragment import FragmentFD
    from .extractor import get_info_extractor

    for ie_type in ('hls', 'dash'):  # DASH and hlsnative share the same code base for fragment downloading
        fd = FragmentFD(
            get_info_extractor('youtube'),
            {},
            StringIO(),
            StringIO(),
            {'fragment_retries': 5})
        fd.params.update({'continuedl': True, 'noprogress': False})
        assert fd.FD_NAME == ie_type.upper()


# Generated at 2022-06-24 11:43:18.882855
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .common import FileDownloader
    from .http import HttpsFD
    from .fragment import FragmentFD
    from .dash import DASHFD
    from .hls import HLSFD
    from .hlsnative import HLSFD
    from .extractor import YoutubeDL
    ydl_opts = {}
    ydl = YoutubeDL(ydl_opts)
    ydl.add_info_extractor(HttpsFD)
    ydl.add_info_extractor(FragmentFD)
    ydl.add_info_extractor(DASHFD)
    ydl.add_info_extractor(HLSFD)
    ydl.add_info_extractor(HLSFD)
    dest = '/sdcard/test'
    filename = 'test'
    tmpfilename = dest
    fd

# Generated at 2022-06-24 11:43:27.116044
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    frag_fd = FragmentFD(None, None)
    frag_fd.params['fragment_retries'] = -1
    frag_fd.report_retry_fragment(
        Exception('Test exception'), 34, 0, -1)
    frag_fd.report_retry_fragment(
        Exception('Test exception'), 34, 1, -1)
    frag_fd.report_retry_fragment(
        Exception('Test exception'), 34, 2, -1)
    frag_fd.report_retry_fragment(
        Exception('Test exception'), 34, 3, -1)
    frag_fd.report_retry_fragment(
        Exception('Test exception'), 34, 4, -1)

# Generated at 2022-06-24 11:43:31.084041
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFragmentFD(FragmentFD):
        def to_screen(self, msg):
            assert msg == '[download] Skipping fragment 1337...'

    test_fd = TestFragmentFD({})
    test_fd.report_skip_fragment(1337)

    test_fd.to_screen.assert_called_with(
        '[download] Skipping fragment 1337...')


# Generated at 2022-06-24 11:43:34.491942
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    quiet_dl = HttpQuietDownloader(None, {})
    out = 'testing HttpQuietDownloader'
    assert quiet_dl.to_screen(out)

# Generated at 2022-06-24 11:43:40.483994
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FakeYDL(object):
        def __init__(self):
            self.params = {}

    class FakeFD(FragmentFD):
        def __init__(self):
            self.ydl = FakeYDL()

    ffd = FakeFD()
    result = ffd.report_retry_fragment(Exception('Test'), 0, 1, 1)
    assert result is None

if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:43:49.969353
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from ..extractor.common import InfoExtractor
    from ..utils import std_headers
    from .common import FileDownloader
    from .http import HttpFD

    class TestIE(InfoExtractor):
        IE_NAME = 'TestIE'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'formats': [
                    {'url': 'http://example.com/video', 'ext': 'mp4'},
                ],
            }


# Generated at 2022-06-24 11:43:52.987125
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .smoothstreams import SmoothstreamsFD

    class SuperFD(SmoothstreamsFD, FragmentFD):
        FD_NAME = 'super'

    assert type(SuperFD)

# Generated at 2022-06-24 11:43:57.218484
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda msg: msg
    assert fd.report_retry_fragment(ValueError('test'), 0, 1, 10) == '[download] Got server HTTP error: test. Retrying fragment 0 (attempt 1 of 10)...'

# Generated at 2022-06-24 11:44:03.020605
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from ..extractor import get_info_extractor

    class DummyIE(object):
        def __init__(self, ie_name):
            self._type = ie_name

        def ie_key(self):
            return self._type

    extractor = get_info_extractor(DummyIE('somename'))
    quiet_downloader = HttpQuietDownloader(
        extractor, {
            'continuedl': True,
            'noprogress': True,
            'quiet': True,
            'ratelimit': None,
            'nopart': True,
            'retries': 10,
            'test': True,
        })
    assert quiet_downloader.to_screen('message') is None

# Generated at 2022-06-24 11:44:11.626634
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFD(FragmentFD):
        def __init__(self):
            self.to_screen_calls = []
        def to_screen(self, msg, skip_eol=False):
            self.to_screen_calls.append(msg)

    tf = TestFD()
    tf.report_retry_fragment('err', 1, 2, 3)
    assert len(tf.to_screen_calls) == 1
    assert tf.to_screen_calls[0] == \
        '[download] Got server HTTP error: err. Retrying fragment 1 (attempt 2 of 3)...'


# Generated at 2022-06-24 11:44:17.519496
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpQuietDownloader
    from .utils import get_suitable_downloader
    ie = InfoExtractor()
    ie.ydl = object()
    func = get_suitable_downloader({}, ie, 'http').to_screen
    assert issubclass(get_suitable_downloader({}, ie, 'http'), HttpQuietDownloader)
    func('foo')

# Generated at 2022-06-24 11:44:19.176570
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert hasattr(HttpQuietDownloader, 'to_screen')

# Generated at 2022-06-24 11:44:24.843832
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import YoutubeDL
    ydl = YoutubeDL({})
    fd = FragmentFD(ydl, {
        'quiet': True,
        #'skip_unavailable_fragments': True,
    })
    assert fd.params['quiet'] is True

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:44:31.120598
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import io
    buf = io.StringIO()
    d = HttpQuietDownloader(
        {},
        {
            'noprogress': True,
            'progress_hooks': [],
        }
    )
    d.to_screen = lambda msg, skip_eol=False: buf.write(msg.encode())
    d.to_screen('abc')
    d.to_screen('def', skip_eol=True)
    d.to_screen('ghi')
    assert buf.getvalue() == b'abcghi' and buf.getvalue().count(b'\n') == 1
    buf.close()

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:44:32.416788
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..compat import compat_basestring

    assert not issubclass(FragmentFD, compat_basestring)

# Generated at 2022-06-24 11:44:38.142319
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD

    assert issubclass(HttpQuietDownloader, HttpFD)

    hqd = HttpQuietDownloader()

    assert hasattr(hqd, 'to_screen')
    assert callable(hqd.to_screen)


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-24 11:44:44.209360
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
    ydl = FakeYDL()

    dl = HttpQuietDownloader(ydl, {'continuedl': True})

    assert dl.params['continuedl'] is True
    assert dl.ydl is ydl
    assert dl.params is ydl.params
    assert dl.params['continuedl'] is True
    assert dl.params['quiet'] is True
    assert dl.params['noprogress'] is True

# Generated at 2022-06-24 11:44:56.519537
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """
    Testing constructor
    """
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': '4',
        'retries': '5',
        'nopart': True,
        'test': True,
    }
    ydl = None
    test_case = HttpQuietDownloader(ydl, params)
    assert test_case._ydl is None
    assert test_case._params == params
    assert not test_case.downloaded_bytes
    assert not test_case._total_bytes
    assert not test_case._prev_downloaded_bytes
    assert not test_case._prev_elapsed
    assert test_case._filename is None
    assert test_case._status is None

# Generated at 2022-06-24 11:45:01.922811
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp

    dl = HttpQuietDownloader(
        {},
        # General download options:
        {
            'continuedl': True,
            'noprogress': True,
            'quiet': True,
        })
    dl.add_info_extractor(gen_extractors())
    dl.add_post_processor(gen_pp())
    assert dl

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:45:08.131176
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # In python2 we need to cast unicode string to str to prevent TypeError in
    # attempt to write to the stdout (unfortunately, the way of suppressing
    # the cast is language-dependent)
    assert FragmentFD(None, {'skip_fragments': True}).report_skip_fragment(0) == None
    assert FragmentFD(None, {'skip_fragments': False}).report_skip_fragment(0) == '[download] Skipping fragment 0...'

# Generated at 2022-06-24 11:45:10.401202
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    dl = HttpQuietDownloader(None, {'quiet': False})
    dl.to_screen('message')
    dl.params['quiet'] = dl.params['verbose'] = True
    dl.to_screen('message')

# Generated at 2022-06-24 11:45:22.791474
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    from .common import FileDownloader

    class TestFD(FileDownloader):

        def __init__(self, *args, **kargs):
            self.to_screen_strs = []
            super(TestFD, self).__init__(*args, **kargs)

        def to_screen(self, *args, **kargs):
            self.to_screen_strs.append(args[0])

    ydl = TestFD({})
    fd = FragmentFD(ydl, {})
    fd.report_retry_fragment(Exception('Test'), 2, 5, {'maxretries': 2})
    assert ydl.to_screen_strs[0] == '[download] Got server HTTP error: Test. Retrying fragment 2 (attempt 5 of 2)...'

# Generated at 2022-06-24 11:45:32.213861
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class DummyFD(FragmentFD):
        def __init__(self, expected_value):
            super(DummyFD, self).__init__(None, None)
            self.expected_value = expected_value
            self.result = None

        def to_screen(self, *args, **kargs):
            self.result = args[0]

    fd = DummyFD('[download] Skipping fragment 11...')
    fd.report_skip_fragment(11)
    assert fd.result == fd.expected_value

# Generated at 2022-06-24 11:45:36.383060
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import io
    dl = HttpQuietDownloader(None, {'continuedl': True, 'quiet': True, 'noprogress': True, 'ratelimit': None})
    sys.stdout = io.BytesIO()
    dl.to_screen('test')
    assert 'test' != sys.stdout.getvalue()

# Generated at 2022-06-24 11:45:47.500077
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor

    class IE(InfoExtractor):
        IE_NAME = 'Test IE'
        _VALID_URL = r'(?i)^https?://.*'

        def _real_extract(self, url):
            return {
                'id': 'testid',
                'ext': 'mp4',
                'url': url,
                'title': 'test video',
                'upload_date': '20110101',
            }

    class FD(FragmentFD):
        FD_NAME = 'Test FD'
        IE_NAME = IE.IE_NAME

        @staticmethod
        def suitable(query):
            return True

        def real_download(self, filename, info_dict):
            pass

    old

# Generated at 2022-06-24 11:45:57.939608
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpQuietDownloader
    from .compat import bytes, str

    class TestIE(InfoExtractor):
        @staticmethod
        def _build_downloader(params):
            return HttpQuietDownloader(params)

    ie = TestIE({'quiet': True})
    ie._print_message('Error:', 'Test message')
    ie._print_message(bytes('Error:', 'UTF-8'), bytes('Test message', 'UTF-8'))
    ie._print_message(str('Error:'), str('Test message'))


if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:46:06.399029
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self, *args, **kargs):
            self.screen_output = []
            FragmentFD.__init__(self, *args, **kargs)

        def to_screen(self, *args, **kargs):
            self.screen_output.append(args)

    ydl = TestFragmentFD()
    ydl.report_skip_fragment(7)
    assert ydl.screen_output == [('[download] Skipping fragment 7...',)]

# Generated at 2022-06-24 11:46:11.600716
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=W0212
    try:
        fd = FragmentFD()
    except TypeError:
        pass
    else:
        assert False, 'FragmentFD does not require any arguments'
    fd = FragmentFD()
    fd._prepare_frag_download({})
    fd._start_frag_download({})

# Generated at 2022-06-24 11:46:13.731433
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    hqdl = HttpQuietDownloader(None, {})
    assert hqdl.to_screen('testing') is None

# Generated at 2022-06-24 11:46:26.100238
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        def _download_fragment(self, ctx, url, info_dict, headers):
            ctx['fragment_index'] += 1
            return True, 'downloaded fragment data'

        def _start_frag_download(self, ctx):
            ctx.update({
                'total_frags': 5,
                'dl': None,
                'dest_stream': None,
                'tmpfilename': None,
                'complete_frags_downloaded_bytes': 0,
                'started': time.time(),
                'fragment_index': 0,
                'prev_frag_downloaded_bytes': 0,
            })
            return time.time()
    fd = MyFragmentFD(None)
    ctx = dict()
    fd._

# Generated at 2022-06-24 11:46:37.347178
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    class TestFragmentFD_Constructor(unittest.TestCase):

        class YDLogger(object):
            msgs = []
            def debug(self, msg):
                self.msgs.append(msg)

        class YDOhYeah(object):
            def __init__(self, params):
                self.params = params

        def setUp(self):
            self.ydl = self.YDOhYeah({'max_downloads': 1})
            self.ydl.logger = self.YDLogger()
            self.params = {
                'server_http_error_file': '/tmp/foo',
                'fragment_retries': 10,
                'keep_fragments': True,
                'skip_unavailable_fragments': True,
            }


# Generated at 2022-06-24 11:46:41.324416
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import youtube_dl.YoutubeDL as YoutubeDL
    ydl = YoutubeDL({'quiet': True})
    ydl.add_default_info_extractors()
    ydl.download(['http://www.example.com'])
    assert sys.stdout.getvalue() == ''

# Generated at 2022-06-24 11:46:47.657822
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .tests.test_utils import FakeYDL
    ydl = FakeYDL()
    fd = FragmentFD(ydl, {})
    fd.to_screen = lambda *args, **kwargs: args
    assert fd.report_skip_fragment(1) == (
        '[download] Skipping fragment 1...',)


if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:46:54.898843
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    '''
    Unit test for method to_screen of class HttpQuietDownloader
    '''
    class FakeYDL:
        def to_screen(self, *args, **kargs):
            return 'expected result'

    hqd = HttpQuietDownloader(FakeYDL(), {})
    assert hqd.to_screen() == None
    assert hqd.to_screen('some', 'test', 'arguments') == None

# Generated at 2022-06-24 11:47:02.762302
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import unittest

    class FragmentFDTest(unittest.TestCase):
        def setUp(self):
            self._stdout = FragmentFD._stdout
            FragmentFD._stdout = (_ for _ in [1]).next
            self._stderr = FragmentFD._stderr
            FragmentFD._stderr = (_ for _ in [1]).next

        def tearDown(self):
            FragmentFD._stdout = self._stdout
            FragmentFD._stderr = self._stderr

        def test_FragmentFD_report_skip_fragment(self):
            fd = FragmentFD(None)
            out = []
            FragmentFD._stdout = out.append
            fd.report_skip_fragment(2)

# Generated at 2022-06-24 11:47:10.666842
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {'quiet': False})
    fd.to_screen = lambda *args: sys.stderr.write(args[0] + '\n')
    fd.report_retry_fragment(
        IOError('test'),
        frag_index=1,
        count=2,
        retries=5)


if __name__ == '__main__':
    import sys
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:47:21.669429
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from io import StringIO

    class MockFD(FragmentFD):

        def to_screen(self, *args, **kargs):
            self.output = args[0]

    def test(fragment_index, expected_output):
        out = StringIO()
        fd = MockFD({
            'outtmpl': '-',
            'simulate': True,
            'forceurl': True,
            'forcetitle': True,
            'forcefilename': True,
            'forceduration': True,
            'verbose': False,
            'quiet': False,
            'no_warnings': False,
            'logger': FileDownloader.std_logger(out),
        })

# Generated at 2022-06-24 11:47:23.543813
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    hqd = HttpQuietDownloader(None, None)
    assert hqd.to_screen('a', 'b', 'c') is None
    assert hqd.to_screen() is None

# Generated at 2022-06-24 11:47:27.963761
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {})
    fd.to_screen = lambda *args: args
    assert (
        ('[download] Got server HTTP error: Test error. Retrying fragment %d (attempt %d of %s)...' % (
         1, 7, fd.format_retries(40)),)
        == fd.report_retry_fragment('Test error', 1, 7, 40))

# Generated at 2022-06-24 11:47:29.591668
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # TODO
    return True



# Generated at 2022-06-24 11:47:32.087936
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {'nopart': True})
    assert fd.params.get('nopart') is True

# Generated at 2022-06-24 11:47:41.815074
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func
    from .common import FileDownloader
    from .http import HttpFD, HttpQuietDownloader

    video_id = 'dQw4w9WgXcQ'
    url = 'http://www.youtube.com/watch?v=%s' % video_id

    ie = get_info_extractor(url)
    info_dict = ie.extract(url)

    # Input for constructor

# Generated at 2022-06-24 11:47:49.466637
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({})
    fd.to_screen = lambda *x: x

    assert fd.report_retry_fragment(
        'ERROR', 2, 3, (0, 1, 2, 3)) == (
        '[download] Got server HTTP error: ERROR. Retrying fragment 2 (attempt 3 of 4)...',)


if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:47:55.794097
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.generic import GenericIE
    from .. import YoutubeDL
    ydl = YoutubeDL(params={})
    ie = GenericIE(ydl)
    assert issubclass(FragmentFD, FileDownloader)
    assert FragmentFD(ydl, ie, 'dummy')

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:48:03.773140
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys

    class FakeYDL(object):
        def __init__(self):
            self.params = {}

    ydl = FakeYDL()

    # Test if options are copied
    dl = HttpQuietDownloader(ydl, {'param': 'val'})
    assert dl.ydl is ydl
    assert dl.params['param'] == 'val'

    # Test if options are merged with the ydl.params
    ydl.params = {'param': 'param'}
    dl = HttpQuietDownloader(ydl, {'param': 'val'})
    assert dl.ydl is ydl
    assert dl.params['param'] == 'val'

# Generated at 2022-06-24 11:48:13.113500
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({})
    fd._err_restrictive_file_open = True
    fd.to_screen = lambda *args, **kargs: print(args[0])
    fd.report_retry_fragment(
        IOError(2, 'No such file or directory'),
        5, 1, [1, 2, 3])
    fd.report_retry_fragment(
        IOError(3, 'File does not exist'),
        5, 3, [1])


if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:48:16.952699
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestFD(FragmentFD):
        def __init__(self):
            self.to_screen_list = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_list.append(message)

    fd = TestFD()
    dl = HttpQuietDownloader(fd, {})
    dl.to_screen('test message 1')
    dl.to_screen('test message 2', skip_eol=True)
    dl.to_screen('test message 3')
    assert fd.to_screen_list == ['test message 2test message 3']

# Generated at 2022-06-24 11:48:25.654796
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class MyHttpQuietDownloader(HttpQuietDownloader):
        def __init__(self):
            self.str = ''

        def to_screen(self, *args, **kargs):
            self.str += args[0] + '\n'

    hqd = MyHttpQuietDownloader()
    hqd.to_screen('test')
    assert hqd.str == 'test\n'

    # NOTE: HttpQuietDownloader is tested by its client (FragmentFD)

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()
    print('Test passed')

# Generated at 2022-06-24 11:48:36.465370
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import io

    class FDError(Exception):
        pass

    class FD(FragmentFD):
        def to_screen(self, message, skip_eol=False):
            self._screen_file.write(message)

    fd = FD({
        'outtmpl': '-',
    })
    fd.params['retries'] = 0
    fd.params['fragment_retries'] = 2

    with io.BytesIO() as screen_buf:
        fd._screen_file = screen_buf

        fd.report_retry_fragment(
            FDError('err_msg'), 5, 1, fd.params['fragment_retries'])

# Generated at 2022-06-24 11:48:43.383622
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    assert fd.format_retries(42) == '42'
    assert fd.format_retries(1) == '1'
    assert fd.format_retries(0) == 'infinite'
    assert fd.format_retries(None) == 'infinite'
    assert fd.format_retries(-1) == 'infinite'
    assert fd.format_retries(-2) == 'infinite'
    assert fd.format_retries('foo') == 'infinite'
    assert fd.format_retries(object()) == 'infinite'

# Generated at 2022-06-24 11:48:49.898980
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    import copy

    class FakeYDL(object):

        def __init__(self):
            self.params = {}
            self.to_screen = self.to_stdout = self.to_stderr = lambda *args, **kwargs: None
            self.report_warning = lambda *args, **kwargs: None

    class FakeInfoDict(dict):

        def __setitem__(self, *args, **kwargs):
            pass

    class TestFragmentFD(unittest.TestCase):

        def setUp(self):
            self.fake_ydl = FakeYDL()

# Generated at 2022-06-24 11:48:51.854789
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # This is an example of how to use the unit test
    fd = FragmentFD(None, None, None)
    assert fd.report_skip_fragment(0) is None


# Generated at 2022-06-24 11:48:52.882297
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    pass


# Generated at 2022-06-24 11:49:00.302559
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from tests import test_utils
    fd = FragmentFD(test_utils.FileDownloader())
    assert fd.FD_NAME == 'fragment'
    assert fd.ytdl
    assert fd.params
    assert fd.info_dict == {}



# Generated at 2022-06-24 11:49:07.627059
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # Test a regular case
    fd = FragmentFD(None)
    fd.params['fragment_retries'] = 3
    msg = fd.report_retry_fragment(None, 3, 4, 3)
    assert msg == '[download] Got server HTTP error: Unknown. Retrying fragment 3 (attempt 4 of 3)...', 'Got unexpected error message'
    # Test the case when fragment_retries is None
    fd = FragmentFD(None)
    fd.params['fragment_retries'] = None
    msg = fd.report_retry_fragment(None, 3, 4, 3)
    assert msg == '[download] Got server HTTP error: Unknown. Retrying fragment 3 (attempt 4)...', 'Got unexpected error message'
    # Test the case when fragment_retries is 0


# Generated at 2022-06-24 11:49:18.632675
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from .http import HttpFD

    class DummyFD(FragmentFD, HttpFD, FileDownloader):
        FD_NAME = 'dummy'

    test_fd = DummyFD({})
    assert not test_fd.params.get('verbose')
    assert test_fd.to_screen('message') is None

    # verbose
    test_fd.params['verbose'] = True
    assert test_fd.to_screen('message') == 'message'

    # skip_fragments
    test_fd.params['skip_unavailable_fragments'] = True
    assert test_fd.report_skip_fragment(3) is None
    test_fd.params['skip_unavailable_fragments'] = False
    assert test_fd.report_skip_fr

# Generated at 2022-06-24 11:49:27.316496
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = lambda: 0
    ydl.params = {'quiet': True}
    ydl.to_screen = lambda *x, **kargs: 0
    ydl.to_stderr = lambda *x, **kargs: 0
    ydl.to_stdout = lambda *x, **kargs: 0
    h = HttpQuietDownloader(ydl,  {'quiet': True})
    assert h.to_screen('line%s' % os.linesep) is None

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:49:38.249131
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from . import YoutubeDL

    ydl = YoutubeDL()
    dl = HttpQuietDownloader(ydl, {})
    ydl_opts = dl.ydl.params
    assert ydl_opts['logger'].name == 'youtube_dl.downloader.http'
    assert ydl_opts['progress_hooks'] == []
    assert ydl_opts['quiet']
    assert ydl_opts['noprogress']
    assert ydl_opts['forcetitle']
    assert ydl_opts['forceid']
    assert ydl_opts['forcethumbnail']
    assert ydl_opts['forcedescription']
    assert ydl_opts['forceurl']
    assert ydl_opts['forcetags']

# Generated at 2022-06-24 11:49:42.856354
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {'logger': None})
    fd.to_screen = lambda *args, **kargs: args[0]
    assert fd.report_skip_fragment(0) == '[download] Skipping fragment 0...'

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:49:48.713165
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FragmentFD_test(FragmentFD):
        def __init__(self):
            self.to_screen_value = None
        def to_screen(self, value):
            self.to_screen_value = value
    fragmentfd_test  = FragmentFD_test()
    fragmentfd_test.report_retry_fragment(
        'error_message', 1, 2, {'max': 3})
    to_screen_value = fragmentfd_test.to_screen_value
    assert to_screen_value == '[download] Got server HTTP error: error_message. Retrying fragment 1 (attempt 2 of 3)...'

# Generated at 2022-06-24 11:49:57.440394
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    ydl = FileDownloader({})

    class TestFD(FragmentFD):
        def __init__(self):
            self.to_screen_value = None

        def to_screen(self, message):
            self.to_screen_value = message

    fd = TestFD()
    fd.to_screen_value = None
    fd.report_skip_fragment(5)
    assert fd.to_screen_value == '[download] Skipping fragment 5...'

# Generated at 2022-06-24 11:50:05.899273
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .http import YoutubeDLHandler
    from .extractor import gen_extractor_classes

    class TestFD(FragmentFD):
        def __init__(self, params):
            super(TestFD, self).__init__(params, None)
            self._screen_file = io.BytesIO()
        def to_screen(self, s, skip_eol=False, check_quiet=False):
            self._screen_file.write(s.encode('utf-8'))
            if not skip_eol:
                self._screen_file.write(b'\n')
        def get_screen_text(self):
            self._screen_file.seek(0)
            return self._screen_file.read().decode('utf-8')



# Generated at 2022-06-24 11:50:13.556417
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    fd = HttpQuietDownloader(None, {})
    old_stderr = sys.stderr
    sys.stderr = open(os.devnull, 'w')
    try:
        fd.to_screen('foo')
    except IOError:  # sys.stderr was closed
        return
    finally:
        sys.stderr.close()
        sys.stderr = old_stderr
    raise AssertionError('HttpQuietDownloader.to_screen did not suppress output')

# Generated at 2022-06-24 11:50:23.662485
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    """
    Called by:
     * test_parse
     * test_review_fragment_retry
    """
    class FragmentFD_T(FragmentFD):
        @staticmethod
        def format_retries(num):
            assert num == 5
            return '5'
    fd_t = FragmentFD_T()
    msg = 'Got server HTTP error: 500 Internal Server Error. Retrying fragment 10 (attempt 1 of 5)...'
    fd_t.report_retry_fragment(Exception('500 Internal Server Error'), 10, 1, 5)
    assert fd_t.to_stdout == msg
    assert fd_t.to_stderr == ''
    assert fd_t.to_screen_values == (msg,)

# Generated at 2022-06-24 11:50:36.052574
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpQuietDownloader
    from .common import FileDownloader
    from .extractor import gen_extractors
    from .utils import DateRange, match_filter_func
    from .compat import compat_str
    import sys

    old_stderr = sys.stderr
    old_stdout = sys.stdout

    fd = HttpQuietDownloader(
        FileDownloader(params={}),
        {'quiet': True})

    # Test 1: to_screen with value 0
    sys.stderr = sys.stdout = open(os.devnull, 'w')
    fd.to_screen('Testing')
    # Test 2: to_screen with a string
    fd.to_screen(0, 'Testing')
    # Test 3: to_screen with an integer


# Generated at 2022-06-24 11:50:48.937525
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({}, {})
    fd.to_screen = lambda x: False
    fd.format_retries = lambda x: '%d' % (x // 2 + 1)

# Generated at 2022-06-24 11:50:54.830785
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from test import YDL_TEST_FILENAME
    fd = FragmentFD(None, {
        'format': 'bestvideo+bestaudio',
        'noprogress': False,
        'progress_hooks': [],
        'outtmpl': YDL_TEST_FILENAME,
        'nopart': True,
        'retries': 0,
        'continuedl': False,
        'nocheckcertificate': False,
        'noplaylist': False,
    })


# Generated at 2022-06-24 11:51:01.378673
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from io import StringIO
    from .common import FileDownloader
    from urllib.parse import urlparse

    log = StringIO()

    class TestFD(FragmentFD, FileDownloader):
        def __init__(self, ydl, params):
            FileDownloader.__init__(self, ydl, params)

        def to_screen(self, *args, **kargs):
            print(*args, **kargs, file=log)


# Generated at 2022-06-24 11:51:07.482843
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io
    fd_obj = FragmentFD(None)
    fd_obj.to_screen = lambda x: sys.stdout.write(x)

    stdout = sys.stdout
    sys.stdout = io.StringIO()
    fd_obj.report_skip_fragment(5)
    result = sys.stdout.getvalue()
    sys.stdout = stdout
    assert result == '[download] Skipping fragment 5...\n'



# Generated at 2022-06-24 11:51:09.741253
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None)
    assert fd is not None

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:51:12.048920
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..YoutubeDL import YoutubeDL
    HttpQuietDownloader(YoutubeDL(), {'noprogress': False})

# Generated at 2022-06-24 11:51:22.164982
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from collections import OrderedDict
    from ..extractor import gen_extractors
    class FakeInfoDict(OrderedDict):
        pass
    class Options(object):
        params = {}
    info_dict = FakeInfoDict([
        ('id', 'fake_id'),
        ('extractor_key', 'youtube'),
        ('extractor', 'youtube'),
        ('title', 'fake title'),
        ('url', 'http://www.example.com/video-title.mp4'),
        ('http_headers', {'User-Agent': 'DummyDownloader'}),
        ('playlist', None),
        ('playlist_index', None),
        ('extractor_name', 'youtube'),
    ])
    info_dict.add_info_extractor(gen_extractors()[0])

# Generated at 2022-06-24 11:51:28.245044
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import StringIO
    class HttpQuietDownloaderTest(HttpQuietDownloader):
        def __init__(self):
            HttpQuietDownloader.__init__(self, None, {'noprogress': True})
            self.to_stdout = StringIO.StringIO()
            self.to_stderr = StringIO.StringIO()

    h = HttpQuietDownloaderTest()
    assert h.to_stdout.getvalue() == ''
    assert h.to_stderr.getvalue() == ''
    h.to_screen('Hi!')
    assert h.to_stdout.getvalue() == 'Hi!\n'
    assert h.to_stderr.getvalue() == ''
    h.to_screen('This is a warning!', True)
    assert h.to

# Generated at 2022-06-24 11:51:33.262272
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: args[0]
    assert fd.report_skip_fragment(1) == '[download] Skipping fragment 1...'
    fd.to_screen = lambda *args, **kargs: None
    assert fd.report_skip_fragment(1) is None

# Generated at 2022-06-24 11:51:43.443764
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    from ..compat import get_filesystem_encoding

    class FragmentFD(HttpFD, FileDownloader):
        def __init__(self):
            self.ydl = True

    ffd = FragmentFD()
    ffd.to_screen = lambda *args, **kargs: (args, kargs)
    assert ffd._retry_fragment(None, None) is None
    assert (ffd.report_retry_fragment(None, 1, 1, {'max_retries': 3}), {}) == (
        ('[download] Got server HTTP error: None. Retrying fragment 1 (attempt 1 of 3)...',), {})

# Generated at 2022-06-24 11:51:51.985336
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Make sure setting logtostderr=False will not prevent
    # HttpQuietDownloader.to_screen from setting up stdout
    ydl = FileDownloader({'logtostderr': 'false'})
    fd = HttpQuietDownloader(ydl, {'test': 'true'})
    assert fd.ydl is ydl
    assert fd.params.get('test') is True
    assert fd.to_stderr is None
    assert fd.to_screen('test message') is None
    # And that the same is true when logtostderr=True
    ydl = FileDownloader({'logtostderr': 'true'})
    fd = HttpQuietDownloader(ydl, {'test': 'true'})
    assert fd.to_stder

# Generated at 2022-06-24 11:51:57.429715
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import StringIO
    buf = StringIO.StringIO()
    old_stderr = sys.stderr
    sys.stderr = buf
    try:
        d = FragmentFD({})
        d.report_skip_fragment(4)
        assert buf.getvalue() == '[download] Skipping fragment 4...\n'
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-24 11:52:07.007354
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader

    fd = FileDownloader(params={})
    fd.to_screen = lambda *args: (args, [])


# Generated at 2022-06-24 11:52:11.872664
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {})
    assert fd.__check_fragment_index('25', 100) is None
    assert fd.__check_fragment_index('-1', 100) == 0
    assert fd.__check_fragment_index('105', 100) == 100

test_FragmentFD()

# Generated at 2022-06-24 11:52:14.498163
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .options import opts

    fd = FragmentFD(object, opts)
    assert isinstance(fd, FileDownloader)
    assert not hasattr(fd, 'report_warning')


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:52:17.094079
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {'format': 'flv'})
    assert fd.ydl is None
    assert fd.params == {'format': 'flv'}

# Generated at 2022-06-24 11:52:24.415473
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor, gen_extractors
    gen_extractors()

    for ie in get_info_extractor(['generic']):
        fd = ie.get_info_extractor()(ie._downloader, ie.ie_key())
        if isinstance(fd, FragmentFD):
            break
    else:
        raise TypeError('Test failed: could not find any FragmentFD')

    assert FragmentFD.__do_ytdl_file({'filename': 'test.mp4'})
    assert FragmentFD.__do_ytdl_file({'filename': 'test_with_underscores.mp4'})
    assert FragmentFD.__do_ytdl_file({'filename': 'test.'})
    assert FragmentFD.__do_ytdl_