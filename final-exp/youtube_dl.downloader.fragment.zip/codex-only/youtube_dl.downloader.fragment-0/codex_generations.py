

# Generated at 2022-06-24 11:42:22.754553
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {'fragment_retries': 3}, None)

    fd.report_retry_fragment(Exception(), 5, 1, 3)

    # Test for unicode object
    unicode_exc = type('unicode_exc', (Exception,), dict(__str__=lambda s: u'\xe3'))

    fd.report_retry_fragment(unicode_exc(), 5, 1, 3)



# Generated at 2022-06-24 11:42:28.614678
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import io

    stream = io.StringIO()
    sys.stdout = stream
    dl = HttpQuietDownloader(None, {})
    dl.to_screen('abc')
    assert stream.getvalue() == ''
    sys.stdout = sys.__stdout__

# Generated at 2022-06-24 11:42:30.670074
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {}, {'skip_unavailable_fragments': True})
    assert fd

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:42:32.437568
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None, None)
    fd.report_skip_fragment(12)

# Generated at 2022-06-24 11:42:41.957223
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloaderTest
    from .utils import Descriptor
    from .extractor import get_info_extractor
    from .extractor.common import InfoExtractor

    class MockIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'formats': [{
                    'format_id': 'test',
                    'url': 'http://localhost/test',
                    'ext': 'flv',
                    'filesize': 10,
                    'protocol': 'http',
                }]
            }

    def _get_extractor(url):
        ie = get_info_extractor(MockIE.ie_key())
        return ie.suitable(url) and ie or None

    # Check constructor and

# Generated at 2022-06-24 11:42:45.968423
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        def __init__(self, params):
            FileDownloader.__init__(self, params)
            self.FD_NAME = 'testfd'
        def _start_frag_download(self, ctx):
            return ctx['dl'].params['test']
    params = {'test': True}
    testfd = TestFD(params)
    assert testfd, 'Couldn\'t instantiate unit test for class FragmentFD'

# Generated at 2022-06-24 11:42:50.206898
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: fd.screen
    fd.screen = []
    fd.report_skip_fragment(1)
    expected = [u'[download] Skipping fragment 1...']
    assert fd.screen == expected, (fd.screen, expected)


if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:42:55.677244
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class MockFD(FragmentFD):
        def __init__(self):
            pass
    fd = MockFD()
    fd.to_screen = lambda *args, **kargs: args
    err = OSError('some error')
    frag_index = 3
    count = 2
    retries = 5
    assert (
        fd.report_retry_fragment(
            err, frag_index, count, retries)
        == [('[download] Got server HTTP error: %s. '
             'Retrying fragment 3 (attempt 2 of 5)...') % error_to_compat_str(err)]
    )

# Generated at 2022-06-24 11:43:00.886037
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_calls = []
            self.report_warning_calls = []
            super(TestFragmentFD, self).__init__(None)

        def to_screen(self, *args, **kargs):
            self.to_screen_calls.append(args)

        def report_warning(self, msg):
            self.report_warning_calls.append(msg)

    frag_fd = TestFragmentFD()

    # Test download resume
    frag_fd.add_info_dict({
        'fragment_count': 5,
        'filename': 'out.mp4',
        'tmpfilename': 'tmp-out.mp4',
    })
    frag_fd._prepare_frag_download

# Generated at 2022-06-24 11:43:06.286573
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    downloader_params = {
        'continuedl': True,
        'retries': 0,
    }
    downloader = HttpQuietDownloader(
        None,  # ydl
        downloader_params,
    )
    for param, value in downloader_params.items():
        assert downloader.params[param] == value

# Generated at 2022-06-24 11:43:12.460737
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys

    class FakeYDL:
        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_calls.append((message, skip_eol))

    class Test(FragmentFD):
        def __init__(self, ydl):
            self.ydl = ydl

        def to_screen(self, *args, **kargs):
            self.ydl.to_screen(*args, **kargs)

    ydl = FakeYDL()
    dl = Test(ydl)
    dl.to_screen = ydl.to_screen
    dl.report_retry_fragment(
        FakeException('Test'),
        5,
        1,
        3)

# Generated at 2022-06-24 11:43:22.284417
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    sys.stderr = sys.stdout
    try:
        class FakeYDL(object):
            params = {}
            def trouble(self, *args, **kargs):
                pass
            def to_screen(self, *args, **kargs):
                pass

        ydl = FakeYDL()
        _ = HttpQuietDownloader(ydl, {})
        _ = HttpQuietDownloader(ydl, {'continuedl': True})
    finally:
        sys.stderr = sys.__stderr__



# Generated at 2022-06-24 11:43:26.867914
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    ydl = FakeYDL()
    fd = FragmentFD(ydl, {})
    fd.to_screen = lambda *x: None
    fd.report_skip_fragment(123)
    assert ydl.msgs == [
        u'[download] Skipping fragment 123...'
    ]

# Generated at 2022-06-24 11:43:35.341901
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from io import BytesIO
    import sys
    import youtube_dl

    ydl = youtube_dl.YoutubeDL()
    ydl.params['verbose'] = True
    fd = FragmentFD(ydl, {'quiet': True})

    class MyWriter(BytesIO):
        def write(self, b):
            if isinstance(b, bytes):
                b = b.decode('ascii')
            super(MyWriter, self).write(b.replace('\r', '\n').encode('utf-8'))

    writer = MyWriter()
    old_stdout = sys.stdout
    try:
        sys.stdout = writer
        fd.report_retry_fragment(ValueError('test'), 1, 2, (3, 4))
    finally:
        sys.stdout

# Generated at 2022-06-24 11:43:42.704929
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import get_info_extractor

    ie = get_info_extractor(u'generic')

    params = {
        'noprogress': True,
        'quiet': True,
        'retries': 2,
        'continuedl': True,
    }

    with ie.get_downloader(u'http://localhost', params) as d:
        params2 = d.params
        assert params2['noprogress'] == True
        assert params2['quiet'] == True
        assert params2['retries'] == 2
        assert params2['continuedl'] == True

# Generated at 2022-06-24 11:43:48.363203
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD({
        'noprogress': True,
        'nooverwrites': True,
        'continuedl': True,
        'ratelimit': 40000000,
    })
    assert fd.ydl is None
    assert fd.params['noprogress']
    assert fd.params['nooverwrites']
    assert fd.params['continuedl']
    assert fd.params['ratelimit'] == 40000000

# Generated at 2022-06-24 11:43:59.564577
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import unittest
    from ..extractor.common import InfoExtractor
    from ..postprocessor import PostProcessor
    from .common import FileDownloader
    from .http import HttpFD

    class TestInfoExtractor(InfoExtractor):
        IE_NAME = 'Test'

        def _real_extract(self, url):
            return {
                'id': 'TestID',
                'ext': 'TestExt',
                'title': 'Test Title',
            }

    class TestPostProcessor(PostProcessor):
        def run(self, info):
            return [{
                'id': info['id'],
                'ext': 'TestPost',
                'title': info['title'],
            }]

    class TestFD(HttpFD):
        FD_NAME = 'Test'


# Generated at 2022-06-24 11:44:07.336778
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class DummyYDL(object):
        def __init__(self, params):
            self.params = params
    params = {
        'verbose': True,
        'quiet': False,
        'dump_intermediate_pages': False,
    }
    ydl = DummyYDL(params)
    dl = HttpQuietDownloader(ydl, params)
    dl.to_screen('foobar')

# Generated at 2022-06-24 11:44:10.548116
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {'quiet': True})
    fd.to_screen = lambda x: None
    fd.report_skip_fragment(10)

# Generated at 2022-06-24 11:44:19.476159
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import (
        parse_mpd_formats,
        _sort_formats,
        _extract_mpd_formats,
        _extract_m3u8_formats,
        _parse_mpd_formats)
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import (
        parse_mpd_formats,
        _sort_formats,
        _extract_mpd_formats,
        _extract_m3u8_formats,
        _parse_mpd_formats)


# Generated at 2022-06-24 11:44:26.862019
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class FakeYDL:
        params = {}

    class FakeInfoDict:
        pass

    dl = HttpQuietDownloader(FakeYDL(), {'continuedl': True, 'noprogress': True})
    info_dict = FakeInfoDict()
    info_dict.url = 'http://127.0.0.1/video.ts'
    assert dl.real_download(info_dict, None) == (None, info_dict)

# Generated at 2022-06-24 11:44:31.714168
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeYDL(object):
        def __init__(self):
            self.to_screen = lambda *args, **kargs: print(' '.join(map(str, args)))
    ydl = FakeYDL()
    quiet_dl = HttpQuietDownloader(ydl, None)
    quiet_dl.to_screen('Some message')
    quiet_dl.to_screen('Another message')
    print('OK')

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:44:34.128082
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        def __init__(self):
            self.ydl = None
            self.params = {'noprogress': True}

    TestFD()

# Generated at 2022-06-24 11:44:35.452526
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({}, {}, {}, {'to_screen': lambda *args: None})
    fd.report_skip_fragment(100)

# Generated at 2022-06-24 11:44:39.647490
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpDownloader
    from . import YoutubeDL
    ydl = YoutubeDL()
    dl = HttpQuietDownloader(ydl, {'retries': 2})
    assert isinstance(dl, HttpDownloader)
    assert dl.params['retries'] == 2

# Generated at 2022-06-24 11:44:47.422606
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_msgs = []
            self.params = {}

        def to_screen(self, *args, **kargs):
            self.to_screen_msgs.append(args)

        def format_retries(self, retries):
            return '%s (infinite)' % retries if retries is None else str(retries)

    fd = TestFragmentFD()
    # Test with the default value
    err, frag_index, retries, count = ZeroDivisionError, 1, (3, None, None), 1
    fd.report_retry_fragment(err, frag_index, count, retries)

# Generated at 2022-06-24 11:44:58.903363
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .utils import compat_str
    from .compat import mock

    out, err = compat_str(), compat_str()

    class DummyIE(InfoExtractor):
        IE_NAME = 'DummyIE'
        _VALID_URL = r'.*'
        def __init__(self, *args, **kwargs):
            InfoExtractor.__init__(self, *args, **kwargs)

        def _downloader_factory(self, *args, **kwargs):
            return HttpQuietDownloader(self, *args, **kwargs)


# Generated at 2022-06-24 11:45:08.214165
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    class TestFragmentFD(FragmentFD):
        def __init__(self, ydl):
            self.ydl = ydl
    class TestIE(InfoExtractor):
        def __init__(self, ydl):
            self.ydl = ydl
    ie = TestIE(Ydl())
    fd = TestFragmentFD(ie)
    fd.params['verbose'] = True
    fd.to_screen = lambda *args, **kargs: sys.stdout.write(json.dumps(args) + '\n')
    fd.report_skip_fragment(10)
    assert sys.stdout.getvalue() == '["[download] Skipping fragment 10..."]\n'


# Generated at 2022-06-24 11:45:10.717451
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    f = FragmentFD(None, None)
    f.to_screen = lambda *a, **karg: a
    assert f.report_skip_fragment(3) == (
        ['[download]', 'Skipping fragment 3...'], {})

# Generated at 2022-06-24 11:45:18.241951
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .smi import SMI
    from .hls import HLSFD
    from .dash import DASHFD
    from .f4m import F4MFD
    from .fragment import FragmentFD

    assert issubclass(SMI, FragmentFD)
    assert issubclass(HLSFD, FragmentFD)
    assert issubclass(DASHFD, FragmentFD)
    assert issubclass(F4MFD, FragmentFD)

# Generated at 2022-06-24 11:45:24.773668
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    try:
        fd.to_screen = lambda x: x
        assert fd.report_skip_fragment(21) == '[download] Skipping fragment 21...'
        fd._screen_file = None
        assert fd.report_skip_fragment(21) == '[download] Skipping fragment 21...'
    finally:
        fd.to_screen = None

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:45:31.049951
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestHttpQuietDownloader(HttpQuietDownloader):
        def __init__(self):
            self.msgs = []

        def to_screen(self, msg):
            self.msgs.append(msg)

    ydl = TestHttpQuietDownloader()
    ydl.to_screen('test')
    assert ydl.msgs == []

# Generated at 2022-06-24 11:45:35.246825
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    quiet_dl = HttpQuietDownloader({}, {'quiet': True})
    assert not hasattr(quiet_dl, 'to_screen')
    not_quiet_dl = HttpQuietDownloader({}, {'quiet': False})
    assert hasattr(not_quiet_dl, 'to_screen')

# Generated at 2022-06-24 11:45:36.846006
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..youtube_dl.YoutubeDL import YoutubeDL
    FragmentFD(YoutubeDL({}), {})

# Generated at 2022-06-24 11:45:48.125386
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    from io import BytesIO
    from .extractor.common import InfoExtractor

    class FakeFD(FragmentFD):
        def __init__(self, params):
            super(FakeFD, self).__init__(InfoExtractor(), params)
            self.out = BytesIO()
            self._err_buffer = BytesIO()

        def to_screen(self, *args, **kargs):
            kargs['file'] = self.out
            super(FakeFD, self).to_screen(*args, **kargs)

        def trouble(self, *args, **kargs):
            kargs['file'] = self._err_buffer
            super(FakeFD, self).trouble(*args, **kargs)

    fd = FakeFD({})

# Generated at 2022-06-24 11:45:54.255026
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeYoutubeDL:
        @staticmethod
        def to_screen(*args, **kargs):
            pass
    dl = HttpQuietDownloader(FakeYoutubeDL(), {'quiet': True})
    dl.to_screen('sentence')


if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:46:00.377767
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    list(gen_extractors())

    # This is a hack to load HttpQuietDownloader class definition
    ydl = HttpQuietDownloader({'quiet': True}, {})
    assert ydl.params['quiet'] is True
    assert ydl.to_screen == ydl.to_stderr

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:46:08.189010
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    options = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'retries': 0,
        'nopart': False,
        'test': False,
    }
    dl = HttpQuietDownloader(None, options)
    assert dl._opts.get('continuedl') == options['continuedl']
    assert dl._opts.get('quiet') == options['quiet']
    assert dl._opts.get('noprogress') == options['noprogress']
    assert dl._opts.get('retries') == options['retries']
    assert dl._opts.get('nopart') == options['nopart']
    assert dl._opts.get('test') == options['test']



# Generated at 2022-06-24 11:46:09.652986
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    _, _, out, _ = test_FragmentFD_report_skip_fragment()
    return out == '[download] Got server HTTP error: retry. Retrying fragment 2 (attempt 2 of 1)...'


# Generated at 2022-06-24 11:46:16.797231
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    from .extractor.common import InfoExtractor

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = 'Test iedesc'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {'id': 'testid', 'ext': 'mp4'}

    ie = TestIE()
    ie.to_screen(u'abc')
    ie.to_screen(u'abc\u20ac')
    ie.to_screen(u'abc\u20ac', True)

    # Test Fd

# Generated at 2022-06-24 11:46:25.619765
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .shared import FakeYDL
    from .extractor import get_info_extractor
    from .downloader.rtmp import RtmpFD
    from .downloader.fragment import FragmentFD

    fd_inst = FragmentFD(FakeYDL(), {})
    fd_inst.report_retry_fragment(IOError(), 0, 1, 2)
    fd_inst.report_retry_fragment(HttpFD.too_many_requests(''), 0, 1, 2)

    fd_inst = RtmpFD(FakeYDL(), {})
    fd_inst.report_retry_fragment(IOError(), 0, 1, 2)

# Generated at 2022-06-24 11:46:30.752915
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    def to_screen_mock(self, s):
        assert s == '[download] Got server HTTP error: Bad Request. Retrying fragment 1 (attempt 2 of 33)...'
    f = FragmentFD()
    g = FragmentFD()
    g.to_screen = to_screen_mock
    g.report_retry_fragment('Bad Request', 1, 2, 33)

# Generated at 2022-06-24 11:46:41.628313
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class MockFD(FragmentFD):
        def __init__(self):
            self._screen_file = open(os.devnull, 'w')

        def to_screen(self, *args, **kwargs):
            self._screen_file.write(' '.join(args) + '\n')
            self._screen_file.flush()

    fd = MockFD()
    fd.format_retries = lambda r: str(r)

    fd.report_retry_fragment(
        IOError('[Errno socket error] [Errno 1] _ssl.c:504: error:14077438:SSL routines:SSL23_GET_SERVER_HELLO:tlsv1 alert internal error'),
        0, 1, 10)

# Generated at 2022-06-24 11:46:47.921657
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader

    class DummyIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'id',
                'title': 'title',
            }

    class DummyFD(FileDownloader):
        def real_download(self, filename, info_dict):
            return True

    ie = DummyIE(DummyFD(), {})
    fd = FragmentFD(ie, {})
    fd.to_screen = lambda *args: args
    fd.report_skip_fragment(0)
    assert fd.to_screen.call_args == (('[download] Skipping fragment 0...',),)

# Generated at 2022-06-24 11:46:59.237698
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Test that to_screen of class HttpQuietDownloader
    # does not print anything to stdout

    # Create HTTP downloader class
    ydl = YoutubeDL()
    params = {
        'quiet': True,
    }
    test_http_downloader = HttpQuietDownloader(ydl, params)
    # Save stdout to restore original behavior
    save_stdout = sys.stdout
    # Create StringIO object to compare to
    stdout = io.StringIO()
    sys.stdout = stdout
    # Call to_screen
    test_http_downloader.to_screen('test_string')
    # Reset stdout to original
    sys.stdout = save_stdout
    # Check that output of to_screen is empty
    assert stdout.getvalue() == ''

# Generated at 2022-06-24 11:47:03.250890
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .smoke import FD_SmokeTest
    from . import FragmentFD
    test_fd = FragmentFD(FD_SmokeTest.get_test_ydl())
    test_fd.to_screen = lambda *args, **kargs: None
    test_fd.report_skip_fragment(1)



# Generated at 2022-06-24 11:47:10.339465
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    ydl = HttpQuietDownloader(HttpFD(None, {}))
    assert ydl.params == {
        'quiet': True,
        'noprogress': True,
        'continuedl': True,
        'nopart': False,
        'ratelimit': None,
    }


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:47:17.753292
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class _DummyFD(FragmentFD):
        def __init__(self):
            self._screen = []

        def to_screen(self, s):
            self._screen.append(s)

    fd = _DummyFD()
    fd.report_retry_fragment('test_error', 1, 2, {'max_retries': None})
    assert (
        fd._screen == ['[download] Got server HTTP error: test_error. Retrying fragment 1 (attempt 2 of unlimited)...']
    )

# Generated at 2022-06-24 11:47:27.336502
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .test_utils import FakeYDL
    from .extractor import YoutubeIE

    def _test(startswith, *args):
        f = FakeYDL()
        FragmentFD.report_retry_fragment(f, *args)
        assert f.msgs[0].startswith(startswith)

    _test(
        '[download] Got server HTTP error',
        'Some error occurred', 0, 1, 3)

    _test(
        '[download] Got server HTTP error',
        'https://www.youtube.com/watch?v=BaW_jenozKc', 0, 1, 3)

    _test(
        '[youtube] BaW_jenozKc: Downloading webpage',
        YoutubeIE(), 0, 1, 3)


# Generated at 2022-06-24 11:47:39.255879
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .common import FileDownloader
    from .http import HttpQuietDownloader
    from .extractor import YoutubeIE
    from ..utils import std_headers
    from ..compat import compat_urllib_error
    import sys

    class MockYoutubeIE(YoutubeIE):
        def __init__(self, *args, **kwargs):
            YoutubeIE.__init__(self, *args, **kwargs)
            self._downloader = HttpQuietDownloader(self.ydl)
            self._downloader.to_screen = lambda *args: sys.stderr.write(' '.join(args) + '\n')
            self.params['noprogress'] = False

    ie = MockYoutubeIE(params={})

# Generated at 2022-06-24 11:47:46.152853
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .downloader import FakeYDL
    ydl = FakeYDL()
    fd = FragmentFD(ydl, {})
    fd.to_screen = lambda x: x
    fd.report_skip_fragment(5)
    assert ydl.msgs == ['[download] Skipping fragment 5...']


# Utit test for method report_retry_fragment of class FragmentFD

# Generated at 2022-06-24 11:47:49.863467
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD({})
    assert fd.params['fragment_retries'] == 10
    assert fd.params['keep_fragments'] is False
    assert fd.params['skip_unavailable_fragments'] is False

# Generated at 2022-06-24 11:47:58.204843
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class MockFD(FragmentFD):
        def to_screen(self, msg, **kargs):
            self.msg = msg

    fd = MockFD()
    fd.report_retry_fragment('error', 5, 7, 10)
    assert fd.msg == (
        '[download] Got server HTTP error: error. Retrying fragment 5 (attempt 7 of 10)...')
    fd.report_retry_fragment('error', 5, 1, 1)
    assert fd.msg == (
        '[download] Got server HTTP error: error. Retrying fragment 5 (attempt 1 of 1)...')

# Generated at 2022-06-24 11:48:06.453588
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    class TestFD(FragmentFD):
        def to_screen(self, message):
            clean_lines.append(re.sub(r'\[download\].*\r?\n', '', message))
    clean_lines = []
    fd = TestFD(None, {'noprogress': True})
    # Test line with no ANSI color codes
    fd.report_skip_fragment(42)
    assert clean_lines[-1] == '[youtube] Skipping fragment 42...\n'
    # Test line with ANSI color codes
    sys.stderr.write('\033[36mSome ANSI color code\033[0m\n')
    fd.report_skip_fragment(43)

# Generated at 2022-06-24 11:48:19.054953
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    from ..compat import compat_http_server
    from ..extractor import get_info_extractor
    from ..utils import ExtractorError

    class Handler(compat_http_server.BaseHTTPRequestHandler):
        server_version = 'FragmentFDTestServer/1.0'

        def do_GET(self):
            if '?' in self.path:
                args = dict(qc.split('=') for qc in self.path.split('?')[1].split('&'))
            else:
                args = {}
            if 'q' in args:
                if args['q'] == '404':
                    self.send_error(404)
                elif args['q'] == 'ok':
                    self.send_response(200)

# Generated at 2022-06-24 11:48:27.682732
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # This method is expected to not call self.to_screen,
    # so we just check no exception is raised and it returns None
    from .common import FileDownloader
    from .http import HttpFD
    from .fragment import FragmentFD

    dummy_FD_class_bases = (FileDownloader, HttpFD, FragmentFD)
    dummy_FD_class_dict = {'FD_NAME': 'dummyFD'}
    dummy_FD_class = type('dummyFD', dummy_FD_class_bases, dummy_FD_class_dict)
    fd = dummy_FD_class(None, {'continuedl': False, 'quiet': True, 'to_stderr': False}, None)
    assert(fd._downloader.to_screen(dummy='dummy') is None)



# Generated at 2022-06-24 11:48:32.733178
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    assert 'Skipping fragment 0...' == fd.report_skip_fragment(0)
    assert 'Skipping fragment 199...' == fd.report_skip_fragment(199)
    assert 'Skipping fragment 200...' == fd.report_skip_fragment(200)

# Generated at 2022-06-24 11:48:38.878253
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params = {
        'verbose': True,
    }
    ydl = FileDownloader(params)
    hqd = HttpQuietDownloader(ydl, params)
    assert hqd.ydl is ydl
    assert hqd.params == params
    assert hqd.params == ydl.params
    for key in ('verbose', 'quiet'):
        assert params[key] is ydl.params[key]



# Generated at 2022-06-24 11:48:47.320286
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from unittest import TestCase
    import sys

    class FakeYDL:
        def __init__(self):
            self.to_stderr = lambda *args: None
            self.to_screen = lambda *args, **kwargs: None

    class FakeStream:
        def __init__(self):
            self.data = []

        def write(self, data):
            self.data.append(data)

        def read(self):
            return ''.join(self.data)

    class HttpQuietDownloaderTest(TestCase):
        def setUp(self):
            self.old_stderr = sys.stderr
            self.old_stdout = sys.stdout
            sys.stderr = FakeStream()
            sys.stdout = FakeStream()
            self.ydl = FakeY

# Generated at 2022-06-24 11:48:48.841340
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: print(args[0])
    fd.report_skip_fragment(123)



# Generated at 2022-06-24 11:49:00.703081
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import copy
    import urllib2
    from compat import compat_urllib_request as compat_urllib_request

    def new_urlopen(*args, **kwargs):
        return urllib2.urlopen(*args, **kwargs)

    def new_request(*args, **kwargs):
        return compat_urllib_request(*args, **kwargs)

    class NewFD(HttpQuietDownloader):
        def http_scheme(self):
            return 'http'

        def https_scheme(self):
            return 'https'

    patch_urllib2_urlopen = copy.deepcopy(urllib2.urlopen)
    patch_compat_urllib_request = copy.deepcopy(compat_urllib_request.Request)
    is_py2

# Generated at 2022-06-24 11:49:03.018009
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(HttpQuietDownloader(None, {}), {})
    assert fd.ready(None)


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:49:08.902458
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params = {
        'outtmpl': '%(id)s-%(ext)s',
        'verbose': False,
        'nooverwrites': False,
    }

# Generated at 2022-06-24 11:49:14.764912
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {}, None)
    fd.to_screen = lambda *args: args
    assert fd.report_skip_fragment(1) == (
        '[download] Skipping fragment 1...',)

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:49:19.297894
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class DummyYDL(object):
        def __init__(self):
            self.params = {'noprogress': True}

        def to_screen(self, *args, **kargs):
            pass
    ydl = DummyYDL()
    hqd = HttpQuietDownloader(ydl, {})
    assert hqd.params['noprogress']

# Generated at 2022-06-24 11:49:29.856978
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class MyFragmentFD(FragmentFD):
        def to_screen(self, message, skip_eol=False):
            self._results['to_screen'] = message
            self._results['skip_eol'] = skip_eol

    dl = MyFragmentFD(None)
    dl._results = {}
    dl.report_retry_fragment(None, 42, 1, {'max': 3})
    assert (
        dl._results['to_screen'] ==
        '[download] Retrying fragment 42 (attempt 1 of 3)...')
    assert not dl._results['skip_eol']

    dl.report_retry_fragment(None, 23, 3, {'max': 3})

# Generated at 2022-06-24 11:49:38.875095
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from six.moves import io
    import sys
    import types

    fd = FragmentFD()
    fd.to_screen = lambda x: sys.stdout.write(x + '\n')
    err = UnicodeEncodeError('ascii', u'\u3042', 0, 1, 'fake')
    fd.report_retry_fragment(err, 10, 3, 7)
    assert 'error: fake' in sys.stdout.getvalue()
    assert 'fragment 10 (attempt 3' in sys.stdout.getvalue()
    assert '7)' in sys.stdout.getvalue()

# Generated at 2022-06-24 11:49:41.858641
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader('ydl', {'yo': 'waddup'})
    assert ydl.params['yo'] == 'waddup'
    assert ydl.to_screen == FileDownloader.to_screen

# Generated at 2022-06-24 11:49:46.184938
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MockFD(FragmentFD):
        def __init__(self):
            self.messages = []

        def to_screen(self, msg, skip_eol=False):
            self.messages.append(msg)

    fd = MockFD()
    fd.report_skip_fragment(123)
    assert fd.messages[0] == '[download] Skipping fragment 123...'

# Generated at 2022-06-24 11:49:59.200362
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor import YoutubeIE
    from .downloader import YoutubeDL
    from .utils import get_cachedir, list_extractors
    ydl = YoutubeDL()
    ydl.params['simulate'] = True
    ydl.params['geo_bypass'] = True
    ydl.add_default_info_extractors()
    ie = YoutubeIE(ydl)
    url = 'https://www.youtube.com/watch?v=nPt8bK2gbaU'
    info = ie.extract(url)
    fd = FragmentFD(ydl, {'continuedl': True, 'quiet': True, 'noprogress': True, 'ratelimit': None, 'retries': 5, 'nopart': False, 'test': False})
    print(info)
    c

# Generated at 2022-06-24 11:50:11.748271
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .extractor import gen_extractor_classes
    from .extractor import youtube_dl

    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.total_frags = 3
            self.dest_stream = None

        def real_download(self, filename, info_dict):
            assert filename == 'testfilename'
            assert info_dict['title'] == 'test title'

            self.report_destination(filename)

            self.prepare_and_start_frag_download({
                'filename': filename,
                'headers': info_dict.get('http_headers'),
                'fragment_index': 0,
                'total_frags': self.total_frags,
            })

# Generated at 2022-06-24 11:50:20.750291
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from io import StringIO
    from tempfile import TemporaryFile
    from .http import HttpFD
    from .common import FileDownloader
    from .http import HttpQuietDownloader
    from . import YoutubeDL
    from .extractor.common import InfoExtractor
    from .compat import compat_str
    from .utils import sanitize_open
    from .extractor.generic import GenericIE

    class TestInfoExtractor(InfoExtractor):
        IE_DESC = 'Test IE'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?example\.com/video\.mp4'

# Generated at 2022-06-24 11:50:26.017963
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = FileDownloader({})
    dl = HttpQuietDownloader(ydl, {'quiet': True, 'noprogress': True})
    assert dl.ydl == ydl
    assert dl.params['quiet'] is True
    assert dl.params['noprogress'] is True



# Generated at 2022-06-24 11:50:34.394019
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io

    dummy = FragmentFD()
    _stdout = sys.stdout
    try:
        sys.stdout = io.BytesIO()
        dummy.report_skip_fragment(1)
        report = sys.stdout.getvalue()
        if '\r' in report:
            raise AssertionError('Unexpected carriage return in:\n%s' % repr(report))
    finally:
        sys.stdout = _stdout

# Generated at 2022-06-24 11:50:46.018085
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class MockYDL:
        def __init__(self):
            self._screen_file = None
        def set_downloader(self, dl):
            dl.to_screen('hello', 'world', end=None, file=self._screen_file)
        def set_filename(self, filename):
            self._screen_file = filename

    ydl = MockYDL()
    dl = HttpQuietDownloader(ydl, {})
    ydl.set_downloader(dl)
    ydl.set_filename('/dev/null')
    ydl.set_filename('/dev/stdout')
    ydl.set_filename('/dev/stderr')
    ydl.set_filename('/dev/tty')

# Generated at 2022-06-24 11:50:49.172341
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestClass:
        pass
    options = TestClass()
    options.quiet = True

    downloader = HttpQuietDownloader(options, {'verbose': False})

    assert downloader.to_screen() == None

# Generated at 2022-06-24 11:50:59.223188
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestInfoExtractor(get_info_extractor('GenericIE', ['test'])):
        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            pass

    class TestFragmentFD(FragmentFD):
        IE_NAME = 'Test'
        FD_NAME = 'test'

    ie = TestInfoExtractor()
    fd = TestFragmentFD(ie)
    assert fd.IE_NAME == 'Test'
    assert fd.FD_NAME == 'test'
    assert fd._downloader is None


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:51:07.662777
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    # With retries > 0
    fd.params = {'retries': 3}
    # With no error and count = 1
    fd.report_retry_fragment(None, 0, 1, fd.params['retries'])
    # With error and count = 1
    fd.report_retry_fragment('some error', 0, 1, fd.params['retries'])
    # With error and count = retries
    fd.report_retry_fragment('some error', 0, fd.params['retries'], fd.params['retries'])
    # With error and count > retries
    fd.report_retry_fragment('some error', 0, 5, fd.params['retries'])
    # With

# Generated at 2022-06-24 11:51:16.910502
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .common import FileDownloader
    from types import MethodType
    test_dict = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': 2,
        'retries': 2,
        'nopart': True,
        'test': True,
    }
    HttpQuietDownloader(None, test_dict)
    assert test_dict == {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': 2,
        'retries': 2,
        'nopart': True,
        'test': True,
    }, 'Constructor of class HttpQuietDownloader should not change argument'

# Generated at 2022-06-24 11:51:24.359292
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FD(FragmentFD):
        def __init__(self, *args, **kargs):
            FragmentFD.__init__(self, *args, **kargs)
            self.screen_data = []
        def to_screen(self, *args, **kargs):
            self.screen_data.append((args, kargs))
    fd = FD()
    fd.report_skip_fragment(7)
    assert fd.screen_data[0] == ((), {'end': '\n'})
    assert fd.screen_data[1] == (('[download] Skipping fragment 7...',), {})

# Generated at 2022-06-24 11:51:32.576936
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        @staticmethod
        def FD_NAME():
            return 'test'

        def report_destination(self, filename):
            pass

    test_fd = TestFD(None, None, {}, {'noprogress': True})
    assert not test_fd.params.get('keepfragments', False)
    assert not test_fd.params.get('skip_unavailable_fragments', False)
    assert test_fd.params.get('noprogress', False)

# vim: set ts=4 sw=4 tw=0 et:

# Generated at 2022-06-24 11:51:39.179360
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloaderTest

    def reporter(fps):
        assert len(fps) == 1
        assert fps[0] == ' [download] Skipping fragment 1...'
    FileDownloaderTest.check_result(FragmentFD, reporter)({'skip_unavailable_fragments': True})
test_FragmentFD_report_skip_fragment.test = 1
test_FragmentFD_report_skip_fragment.__test__ = False

# Generated at 2022-06-24 11:51:42.508397
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    fd = HttpQuietDownloader(FileDownloader({}), {'continuedl': True})
    assert fd.continuedl

# Generated at 2022-06-24 11:51:46.764591
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # pylint: disable=protected-access
    assert FragmentFD(None, {})._report_retry_fragment(
        None, 1, 1, [1, 1]) == (
        '[download] Got server HTTP error: None. '
        'Retrying fragment 1 (attempt 1 of 1)...')

# Generated at 2022-06-24 11:51:57.299032
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .compat import compat_str
    from .utils import match_filter_func
    from .downloader.common import FileDownloader
    from .postprocessor import run_postprocessors

    class MyInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'foobar',
                'url': url,
            }

    class MyFileDownloader(FileDownloader):
        def report_destination(self, *args):
            pass

        def to_screen(self, *args, **kargs):
            pass

    ies = gen_extractors()
    ies.insert(0, MyInfoExtractor())
    ie = MyInfoExtractor()
   

# Generated at 2022-06-24 11:52:06.236304
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeYoutubeDL():
        def __init__(self, to_screen_str):
            self.to_screen_str = to_screen_str
        def to_screen(self, *args, **kargs):
            self.to_screen_str.append(args[0])

    to_screen_str = []
    ydl = FakeYoutubeDL(to_screen_str)
    dl = HttpQuietDownloader(ydl, {'quiet': False})
    dl.to_screen('foo')
    assert to_screen_str == ['foo']
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    dl.to_screen('foo')
    assert to_screen_str == ['foo']
    dl = HttpQuietDownloader(ydl, {})

# Generated at 2022-06-24 11:52:12.980347
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpQuietDownloader
    from .common import FileDownloader
    from .extractor import gen_extractors

# Generated at 2022-06-24 11:52:22.200099
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import PY2, compat_HTTPError, compat_urllib_request
    if PY2:
        from urllib2 import Request
    else:
        from urllib.request import Request

    from .extractor import gen_extractor
    from .http import HttpDownloader
    hd = HttpDownloader(None, {'noprogress': True})
    extractor = gen_extractor()
    hqd = HttpQuietDownloader(None, {'noprogress': True})

    req = Request('http://localhost:49152/')
    req.headers['Range'] = 'bytes=0-'
    # Download should fail because the local server is not running