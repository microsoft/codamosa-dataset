

# Generated at 2022-06-24 11:42:24.102775
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(
        'err', 2, 3, 5) == (
        '[download] '
        'Got server HTTP error: err. '
        'Retrying fragment 2 (attempt 3 of 5)...',
    )

# Generated at 2022-06-24 11:42:30.689925
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from collections import namedtuple

    opt = namedtuple('opt', ['verbose', 'quiet', 'forceurl'])
    h = HttpQuietDownloader(namedtuple('YDL', [])(), opt(False, False, False))
    assert h.ydl_info_succeeded
    assert h.report_warning.__name__ == 'report_warning'
    assert h.report_error.__name__ == 'report_error'

# Generated at 2022-06-24 11:42:36.879123
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    import sys
    import io

    class FakeYDL(object):
        class FakeParams(object):
            def __init__(self):
                self._params = {
                    'writedescription': False,
                    'nooverwrites': True,
                    'continuedl': True,
                    'noprogress': True,
                    'consoletitle': False,
                    'ratelimit': None,
                    'nopart': False,
                    'test': False,
                    'logger': sys.stdout,
                    'progress_with_newline': False,
                }

            def __getitem__(self, key):
                return self._params[key]

        def __init__(self):
            self.params = self.FakeParams()
        gen_extractor

# Generated at 2022-06-24 11:42:46.988637
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_str
    from .http import HttpFD

# Generated at 2022-06-24 11:42:51.962119
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    downloader = HttpQuietDownloader(
        gen_extractors()[0](downloader=HttpQuietDownloader),
        {'quiet': True})
    assert downloader.ydl.params['quiet']

# Generated at 2022-06-24 11:42:56.555823
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    batch_output = []
    fd = FragmentFD(
        None,
        {
            'outtmpl': '',
            'quiet': True,
        },
        batch=True,
    )
    fd.to_screen = lambda msg: batch_output.append(msg)

    fd.report_skip_fragment(123)
    assert batch_output == ['[download] Skipping fragment 123...']

# Generated at 2022-06-24 11:43:08.997546
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..extractor import get_info_extractor

    class MockYoutubeDL(object):
        def format_retries(self, retries):
            return 'formatted_%s' % retries
    ydl = MockYoutubeDL()
    ie = get_info_extractor('m3u8')
    ie.ydl = ydl
    fd = ie._downloader
    fd.to_screen = lambda *args, **kargs: args[0]
    assert fd.report_retry_fragment(None, 42, 1, 4) == ('[%s] Got server HTTP error: None. Retrying fragment 42 (attempt 1 of formatted_4)...' % ie.IE_NAME)

# Generated at 2022-06-24 11:43:12.179260
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(
        '404 Client Error', 4, 2, {'max_retries': 3}) == (
            '[download] Got server HTTP error: 404 Client Error. Retrying fragment 4 (attempt 2 of 3)...',
    )

# Generated at 2022-06-24 11:43:16.114608
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import pytest
    ydl = pytest.importorskip('youtube_dl')
    hqd = HttpQuietDownloader(ydl)
    assert hqd.to_screen('abc') is None

# Generated at 2022-06-24 11:43:27.770388
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    def do_test(self):
        self.report_skip_fragment(0)
        self.report_skip_fragment(0x7fffffff)
        self.report_skip_fragment(0x80000000)
        self.report_skip_fragment(0xffffffff)
    FragmentFD.to_screen = lambda *args: args
    try:
        do_test(FragmentFD(None, {'playlist_items': []}))
        assert False
    except TypeError as e:
        assert e.args[0] == 'to_screen() takes exactly 3 arguments (2 given)'
    FragmentFD.to_screen = lambda *args: args[1:]
    do_test(FragmentFD(None, {'playlist_items': []}))


# Generated at 2022-06-24 11:43:35.108252
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from sys import stdout
    from ..compat import compat_print
    class DummyFragmentFD(FragmentFD):
        def __init__(self):
            self.out = stdout
    dummy_fd = DummyFragmentFD()
    dummy_fd.to_screen = compat_print
    dummy_fd.report_skip_fragment(10)
    dummy_fd.report_skip_fragment(1)
    dummy_fd.report_skip_fragment(2)


# Generated at 2022-06-24 11:43:42.117725
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpQuietDownloader
    from .extractor import YoutubeIE

    ydl = YoutubeIE()
    ydl.params.update({
        'verbose': True
    })
    dl = HttpQuietDownloader(
        ydl,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': None,
            'retries': 0,
            'nopart': False,
            'test': False,
        }
    )


# Generated at 2022-06-24 11:43:51.049825
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import os

    from .common import FileDownloader

    # Plugins are not loaded by default
    from youtube_dl.extractor import get_info_extractor

    class FakeInfoExtractor(object):
        IE_NAME = 'test'

        def __init__(self, downloader):
            pass

        def _real_extract(self, url):
            return {'url': url, 'http_headers': {'a': 'b'}, 'ie_key': 'Fake'}

    get_info_extractor(FakeInfoExtractor.IE_NAME).cls = FakeInfoExtractor

    class MyFD(FragmentFD, FakeInfoExtractor):
        def __init__(self, downloader=None, params=None):
            FakeInfoExtractor.__init__(self, downloader)
            FragmentFD.__init__

# Generated at 2022-06-24 11:44:01.451111
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import uuid
    from io import StringIO

    # Create a fake youtube-dl object
    ydl = object.__new__(object)
    ydl.to_stderr = lambda s: sys.stderr.write(s + '\n')
    ydl.to_stdout = lambda s: sys.stdout.write(s + '\n')

    # Create a fake params object
    params = {
        'ratelimit': uuid.uuid4(),
        'retries': uuid.uuid4(),
        'nopart': uuid.uuid4(),
        'test': uuid.uuid4(),
    }

    # Create the object under test (OUT)
    OUT = HttpQuietDownloader(ydl, params)

    # Redirect stdout to a buffer
   

# Generated at 2022-06-24 11:44:12.023841
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # test empty params
    try:
        _ = HttpQuietDownloader(None, {})
        raise Exception('HttpQuietDownloader did not raise exception upon receiving None')
    except Exception:
        pass
    try:
        _ = HttpQuietDownloader(None, None)
        raise Exception('HttpQuietDownloader did not raise exception upon receiving None')
    except Exception:
        pass

    # test that HttpQuietDownloader inherits from FileDownloader
    # and HttpDownloader.  Also test that it correctly passes
    # params back to FileDownloader.
    fd = HttpQuietDownloader(None, {'foo': 'bar',
                                    'test': True,
                                    'test2': True,
                                    'noprogress': True})

# Generated at 2022-06-24 11:44:20.559899
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # noinspection PyUnusedLocal
    def test_function(filename, url, info):
        return url
    ydl = HttpQuietDownloader(None, {})
    ydl.to_screen('[foo]')
    ydl.to_screen('[foo]', 'bar')
    ydl.to_screen('[foo] bar', 'baz')
    ydl.to_screen(u'[foo] ßØß')
    ydl.to_screen('[foo] ', 'https://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-24 11:44:29.745252
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys

    def _ret(x):
        return x

    def _id(x):
        return x

    # Should not crash
    fd = FragmentFD(
        None, {
            'outtmpl': '%(id)s',
            'progress_hooks': [],
        }
    )
    fd.to_screen = _id
    fd.report_retry_fragment(
        ValueError('Message'), 2, 3, 'retries')

    # Should print the message
    fd.to_screen = _ret

    old_stderr = sys.stderr

# Generated at 2022-06-24 11:44:33.000601
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment(): # pylint:disable=missing-docstring
    from .common import FileDownloader
    def dummy_to_screen(self, msg):
        pass
    FragmentFD.to_screen = dummy_to_screen
    fd = FragmentFD(FileDownloader({}, {}))
    fd.report_skip_fragment(3)

# Generated at 2022-06-24 11:44:40.893107
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = object()
    quiet_downloader = HttpQuietDownloader(
        ydl, {'quiet': True, 'verbose': True})
    assert quiet_downloader.params['quiet'] is True
    assert quiet_downloader.params['verbose'] is True
    assert not hasattr(ydl, 'to_screen')
    assert not hasattr(ydl, 'to_stderr')

    quiet_downloader.to_screen('to_screen test')
    assert not hasattr(ydl, 'to_screen')
    assert not hasattr(ydl, 'to_stderr')

    quiet_downloader.report_warning('to_stderr test')
    assert not hasattr(ydl, 'to_screen')
    assert not hasattr(ydl, 'to_stderr')

    quiet

# Generated at 2022-06-24 11:44:46.876406
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeYDL:
        def __init__(self):
            self.params = {}
        def trouble(self, msg, tb=None):
            try:
                raise Exception(msg)
            except Exception:
                pass
    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {})
    dl.to_screen('test')
    # Exception is expected because trouble method is called
    assert False

# Generated at 2022-06-24 11:44:57.272736
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({'logger': 'fake'}, {'noprogress': True, 'retries': 0})
    fd.to_screen = lambda x: x

    assert (
        fd.report_retry_fragment(
            Exception('foo'), 42, 1, 1)
        == '[download] Got server HTTP error: foo. Retrying fragment 42 (attempt 1 of 1)...'
    )
    assert (
        fd.report_retry_fragment(
            Exception('foo'), 42, 3, 5)
        == '[download] Got server HTTP error: foo. Retrying fragment 42 (attempt 3 of 5)...'
    )


# Generated at 2022-06-24 11:45:07.060873
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # Test if to_screen method of FragmentFD class
    # is called with correct arguments

    # Mock class for class FragmentFD
    class FragmentFD_mock(FragmentFD):
        def __init__(self):
            self.to_screen_call_count = 0
            self.to_screen_called_with = []

        def to_screen(self, message, skip_eol=False, check_less_args=False):
            self.to_screen_call_count += 1
            self.to_screen_called_with.append((message, skip_eol, check_less_args))

    # create FragmentFD object
    fd = FragmentFD_mock()

    # call report_skip_fragment method of FragmentFD with some arguments

# Generated at 2022-06-24 11:45:09.349838
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fd = HttpQuietDownloader(None, {'quiet': True})
    assert fd.params['quiet']
    assert fd.params['noprogress']

# Generated at 2022-06-24 11:45:12.362766
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {}, None, None)
    fd.to_screen = lambda *args: args
    assert fd.report_skip_fragment(10) == ('[download] Skipping fragment 10...',)

# Make sure that FragmentFD always writes the state to the ytdl file even when
# fragment download is unsuccessful and resume is not attempted.

# Generated at 2022-06-24 11:45:18.713390
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestFD(HttpQuietDownloader):
        def __init__(self):
            HttpQuietDownloader.__init__(self, None, None)
            self._messages = []
        def to_screen(self, msg):
            self._messages.append(msg)

    tfd = TestFD()
    tfd.to_screen('Testing...')
    assert tfd._messages == []

# Generated at 2022-06-24 11:45:27.554911
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class YDL:
        params = {}
        def to_screen(self, *args, **kargs):
            pass

    ydl = YDL()
    fd = HttpQuietDownloader(
        ydl,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': 3,
            'retries': 5,
            'nopart': True,
            'test': True,
        }
    )

    assert fd.ydl.params['continuedl']
    assert fd.ydl.params['quiet']
    assert fd.ydl.params['noprogress']
    assert fd.ydl.params['ratelimit'] == 3
    assert fd.ydl.params['retries'] == 5
   

# Generated at 2022-06-24 11:45:36.681405
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpQuietDownloader
    from mock import MagicMock
    hqd = HttpQuietDownloader(
        ydl=None, params={}
    )
    hqd.to_screen = MagicMock()
    hqd.to_screen('string')
    assert hqd.to_screen.call_count == 1
    hqd.to_screen(('str', 1, [2]))
    assert hqd.to_screen.call_count == 2
    hqd.to_screen(('str', 'str2'))
    assert hqd.to_screen.call_count == 3
    hqd.to_screen()
    assert hqd.to_screen.call_count == 4

# Generated at 2022-06-24 11:45:37.222893
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass

# Generated at 2022-06-24 11:45:42.740158
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = HttpQuietDownloader(None, None)

    # test with unknown status
    ydl.to_screen('[download] Fragment: unknown')
    ydl.to_screen(
        '[download] Fragment: unknown\n[download] Unknown status')
    ydl.to_screen('[download] Unknown status')

# Generated at 2022-06-24 11:45:51.707690
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestIE(get_info_extractor('Test')):
        IE_NAME = 'test'
        IE_DESC = 'This is a test IE'
        _VALID_URL = 'whatever'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'ext': 'mp4',
                'title': 'test video',
                'url': 'https://test.com/video.mp4',
            }

    ie = TestIE({
        'outtmpl': '%(id)s.%(ext)s',
        'noprogress': True,
    })
    # Test outtmpl as unicode

# Generated at 2022-06-24 11:46:01.624550
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from ..extractor import gen_extractors
    from ..compat import compat_urllib_request

    class MyYoutubeDL(object):
        def __init__(self, params):
            self.params = params
            self.extractors = gen_extractors()
            self.ie = None
            self.filename = None
            self.tmpfilename = None

        def to_screen(self, s):
            print(s)

        def trouble(self, s, tb=None):
            pass

        def report_error(self, s, tb=None):
            pass

        def report_warning(self, s, tb=None):
            pass

        def to_stdout(self, s):
            sys.stdout.write(s)
            sys.stdout.flush()

       

# Generated at 2022-06-24 11:46:09.142631
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    def _test(test, err, frag_index, count, retries, expected):
        class TestFD(FragmentFD):
            def __init__(self, ydl):
                super(TestFD, self).__init__(ydl)
                # Test uses .to_screen only, so this property
                # may be used to "simulate" it
                self._screen_file = test
            # So that test doesn't complain about not defined method
            @staticmethod
            def _prepare_frag_download(ctx): pass
            @staticmethod
            def _start_frag_download(ctx): pass
            @staticmethod
            def _finish_frag_download(ctx): pass
            def _hook_progress(self, state): pass


# Generated at 2022-06-24 11:46:12.261590
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FakeFragmentFD(FragmentFD):
        def __init__(self):
            self.last_message = None
        def to_screen(self, message):
            self.last_message = message
    fake_fd = FakeFragmentFD()
    fake_fd.report_skip_fragment(42)
    assert fake_fd.last_message == '[download] Skipping fragment 42...'

# Generated at 2022-06-24 11:46:16.390880
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD({'logger': None})
    assert fd.FD_NAME == 'fragment'
    assert fd.params is not None

# Generated at 2022-06-24 11:46:20.711166
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    """
    Calling to_screen method of HttpQuietDownloader should do nothing
    """
    qd = HttpQuietDownloader(None, None)

    qd.to_screen('Testing to_screen of HttpQuietDownloader')

# Generated at 2022-06-24 11:46:30.752127
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.params = {
        'verbose': True,
    }
    from .http import HTTPError
    e = HTTPError(
        'error_message',
        'error_content',
        'error_headers',
        'error_code',
    )
    fd.report_retry_fragment(
        e,
        frag_index=0,
        count=1,
        retries=6,
    )
    fd.to_screen.assert_called_once_with(
        'ERROR: Got server HTTP error: error_code: error_message. '
        'Retrying fragment 0 (attempt 1 of 6)...')

# Generated at 2022-06-24 11:46:41.280250
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class MyFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_str = ''
            self.to_stderr_str = ''

        def to_screen(self, msg):
            self.to_screen_str += msg

        def to_stderr(self, msg):
            self.to_stderr_str += msg

    fd = MyFragmentFD()
    fd.report_retry_fragment(Exception('Test'), 1, 2, 3)
    assert fd.to_screen_str == ('[download] Got server HTTP error: Test. '
                                'Retrying fragment 1 (attempt 2 of 3)...')
    assert fd.to_stderr_str == ''


# Generated at 2022-06-24 11:46:46.818648
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = YoutubeDL()
    ytdl_downloader = HttpQuietDownloader(
        ydl,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'retries': 1,
            'nopart': False,
            'test': False,
        }
    )
    assert ytdl_downloader

# Generated at 2022-06-24 11:46:50.160434
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = object()
    dl = HttpQuietDownloader(ydl, {})
    dl.to_screen('Hello', prefix='[asd] ')  # Nothing should be outputted

# Generated at 2022-06-24 11:47:00.502359
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """
    Unit test for the constructor of class HttpQuietDownloader.
    """
    # Do not run the unit test if the source code is imported from a different
    # directory than the one from which this file is run.
    if not os.path.exists(os.path.join('.', os.path.split(__file__)[1])):
        return

    # Check that the unit test is run from the root directory.

# Generated at 2022-06-24 11:47:11.919699
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor

    # Preparing test data
    class MockSystem:
        def __init__(self):
            self.stderr = ''
            self.stdout = ''

        def write(self, msg, _type):
            if _type == 'stderr':
                self.stderr += msg
            else:
                self.stdout += msg

    ie = InfoExtractor()
    ie.add_info_extractor(gen_extractors())
    dl = ie._downloader
    ext = ie._ies[0]
    dl.params['logger'] = MockSystem()
    ext.ydl = dl

    # Testing
    assert ext.to_screen() == None

# Generated at 2022-06-24 11:47:18.771874
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    file_downloader = FragmentFD(
        None, {}, 'testout', 'testname', False, False, None)
    assert file_downloader
    assert file_downloader.report_destination('test_1') == None
    assert file_downloader.report_retry_fragment(
        'test_err', 'frag_1', 'count_1', 'retries_1') == None
    assert file_downloader.report_skip_fragment(
        'frag_1') == None

# Generated at 2022-06-24 11:47:23.044026
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class MockYtdl:
        params = {}

    ydl = MockYtdl()
    h = HttpQuietDownloader(ydl, {})
    assert isinstance(h, FileDownloader)

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-24 11:47:27.174655
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    qdl = HttpQuietDownloader(None, {'noprogress': True})
    assert isinstance(qdl, HttpFD)
    assert qdl.params['noprogress']
    assert qdl.params['noprogress'] == qdl.ydl.params['noprogress']

# Generated at 2022-06-24 11:47:39.174832
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # pylint: disable=missing-docstring
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_list = []
            self.params = {'retries': 5, 'fragment_retries': 2}
        def to_screen(self, message, skip_eol=False):
            self.to_screen_list.append(message)
        def format_retries(self, retries):
            return ('%d' % retries) if retries is not None else 'infinite'

    test_object = TestFragmentFD()
    test_object.report_retry_fragment(Exception(), 0, 1, 2)

# Generated at 2022-06-24 11:47:50.328129
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import get_info_extractor
    from .downloader import FD_NAME
    from .downloader import downloader_factory

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.extractor = get_info_extractor(FD_NAME)(params)

    params = {
        'format': '251',
    }
    ydl = FakeYDL(params)
    downloader = downloader_factory(params, ydl)
    assert isinstance(downloader, HttpQuietDownloader)

    # Screen should be empty
    assert downloader.screen == ''
    downloader.to_screen('This message should not appear')
    assert downloader.screen == ''

# Generated at 2022-06-24 11:47:55.967637
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=W0612
    import sys

    class FakeYDL:
        def __init__(self):
            self.params = {}
            self.to_screen = sys.stdout.write

    class FragFD(FragmentFD):
        pass

    ydl = FakeYDL()
    ff = FragFD(ydl)
    assert ff

# Generated at 2022-06-24 11:48:00.066462
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    from .external import ExternalFD
    assert isinstance(HttpQuietDownloader(YoutubeDL(), {'continuedl': True}), ExternalFD)
    assert isinstance(HttpQuietDownloader(YoutubeDL(), {'continuedl': False}), FileDownloader)

# Generated at 2022-06-24 11:48:06.755161
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.test_data = {
                'err': None,
                'frag_index': None,
                'count': None,
                'retries': None,
            }
        def to_screen(self, *args, **kargs):
            msg = args[0]
            self.test_data['err'] = msg[msg.index('HTTP error: ') + len('HTTP error: '):]
            self.test_data['frag_index'] = int(msg[msg.index('fragment ') + len('fragment '):][0])
            self.test_data['count'] = int(msg[msg.index('attempt ') + len('attempt '):][0])

# Generated at 2022-06-24 11:48:11.872828
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    def test_ydl(*args, **kargs):
        from .common import YoutubeDL
        return YoutubeDL(*args, **kargs)
    gen_extractors(test_ydl)
    assert test_ydl(params={'quiet': True}).params['quiet'] is True

# Generated at 2022-06-24 11:48:23.975944
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    from .common import FileDownloader
    from .extractor import get_info_extractor

    FileDownloader.params['noprogress'] = True
    FileDownloader.params['nopart'] = True
    FileDownloader.params['quiet'] = False
    info_dict = {
        'id': 'test',
        'ext': 'mp4',
        'title': 'test video',
        'description': 'test video',
        'thumbnail': 'http://example.com/thumbnail.jpg',
        'uploader': 'test uploader',
        'uploader_id': 'test_uploader',
        'duration': 5,
    }
    class FakeYDL(object):
        def __init__(self):
            self.to_screen = sys.stdout.write

# Generated at 2022-06-24 11:48:28.906577
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    from .http import HttpFD
    from .fragment import FragmentFD

    def test_cls(cls):
        assert issubclass(cls, HttpQuietDownloader), cls
        assert issubclass(cls, FileDownloader), cls
        assert issubclass(cls, HttpFD), cls
        assert issubclass(cls, FragmentFD), cls
        assert not issubclass(cls, object), cls

    test_cls(HttpQuietDownloader)
    test_cls(FragmentFD)

# Generated at 2022-06-24 11:48:35.945662
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http = HttpQuietDownloader({'quiet': True}, {})
    assert http._opts['noprogress'] == True
    assert http._opts['quiet'] == True
    assert http.params['ratelimit'] == None
    assert http.params['retries'] == 0
    assert http.params['nopart'] == False
    assert http.params['test'] == False
    assert http.params['continuedl'] == True
    assert http.to_stderr == None
    assert http.to_screen == None

# Generated at 2022-06-24 11:48:44.346819
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class DummyYDL(object):
        # Dummy class for ydl
        params = {}
        verbose = False

    # Method to_screen should remain silent in all cases
    qdl = HttpQuietDownloader(DummyYDL(), {'noprogress': False})
    qdl.to_screen('a', 'b')
    qdl.to_screen('a', 'b', True)
    qdl.to_screen('a', 'b', False)

    qdl = HttpQuietDownloader(DummyYDL(), {'noprogress': True})
    qdl.to_screen('a', 'b')
    qdl.to_screen('a', 'b', True)
    qdl.to_screen('a', 'b', False)

    class DummyYDL(object):
        params

# Generated at 2022-06-24 11:48:50.466287
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    def todir(dirname, name):
        return os.path.join(dirname, os.path.basename(name))

    import tempfile
    temp_dir = tempfile.mkdtemp()
    try:
        ydl = HttpQuietDownloader(None, {
            'continuedl': True,
            'outtmpl': todir(temp_dir, '%(id)s-%(playlist_id)s-%(format_id)s-%(title)s.%(ext)s'),
        })
        assert type(ydl.down.to_screen('a', 'b', c='c')) == type(HttpQuietDownloader.to_screen(ydl, 'a', 'b', c='c'))

    finally:
        import shutil

# Generated at 2022-06-24 11:48:56.862077
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FragmentFD_test(FragmentFD):
        def to_screen(self, *args, **kwargs):
            to_screen_args.append(args)

    f = FragmentFD_test({})
    to_screen_args = []
    f.report_skip_fragment(42)
    assert to_screen_args == [(
        '[download] Skipping fragment 42...',
        )]

# Generated at 2022-06-24 11:49:05.265834
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .utils import FakeYDL
    ydl = FakeYDL()
    fd = FragmentFD(ydl)
    assert fd.FD_NAME == 'fragment'
    assert ydl.params['noprogress']
    assert ydl.params['nopart']
    assert ydl.params['continuedl']
    assert ydl.params['quiet']
    assert ydl.params['ratelimit'] is None
    assert ydl.params['retries'] == 0
    assert ydl.params['test'] is False
    assert ydl.params['noprogress']
    assert fd.params['skip_unavailable_fragments'] is False
    assert fd.params['keep_fragments'] is False
    assert fd.params['fragment_retries'] == 10
    assert fd

# Generated at 2022-06-24 11:49:17.593037
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .utils import FakeYDL
    from .extractor import gen_extractor_classes
    from .extractor.generic import GenericIE

    class FakeExtractor(GenericIE):
        IE_NAME = 'fake'
        IE_DESC = 'Fake Extractor'
        _VALID_URL = r'(?i)^https?://.*\.fake$'
        _TEST = {
            'url': 'http://www.fake.com/video.fake',
            'md5': 'eb90ae9a83a6a18c4995d7ce842acb0f',
            'info_dict': {
                'id': 'video',
                'ext': 'fake',
                'title': 'video',
            }
        }


# Generated at 2022-06-24 11:49:23.905142
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractors

    def test_to_screen_func(self, message, skip_eol=False, check_quiet=False):
        assert(not check_quiet)
        self.msg_queued = True

    HttpQuietDownloader.to_screen = test_to_screen_func

    dl = HttpQuietDownloader(
        'youtube-dl',
        {
            'continuedl': False,
            'quiet': True,
            'noprogress': True,
            'retries': 0,
            'nopart': True,
            'test': False,
        }
    )

    ie = gen_extractors()[0]()
    info = {'id': 'youtube-dl'}

# Generated at 2022-06-24 11:49:27.867671
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io
    import tempfile
    sys.stderr = io.StringIO()
    sys.stdout = io.StringIO()
    tempfile.mkstemp()
    fd = FragmentFD({}, None)
    fd.report_skip_fragment(23)
    assert sys.stdout.getvalue() == '[download] Skipping fragment 23...\n'

# Generated at 2022-06-24 11:49:38.827914
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        def __init__(self):
            self.ydl = None

        def report_error(self, msg):
            self.ydl.report_error(msg)

        def to_screen(self, msg):
            # pass
            self.ydl.to_screen(msg)

        def report_warning(self, msg):
            self.ydl.report_warning(msg)

        def temp_name(self, filename):
            return self.ydl.temp_name(filename)

        def try_rename(self, old_filename, filename):
            self.ydl.try_rename(old_filename, filename)

        def report_destination(self, filename):
            self.ydl.report_destination(filename)


# Generated at 2022-06-24 11:49:43.205180
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    assert FragmentFD.fragment_retries == 10
    FragmentFD.report_retry_fragment(FragmentFD, None, 1, 2, 3)
    assert FragmentFD.fragment_retries == 1
    FragmentFD.report_retry_fragment(FragmentFD, None, 2, 5, 2)
    assert FragmentFD.fragment_retries == 2

if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:49:47.233965
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # Set up a instance of FragmentFD for testing
    class TestFD(FragmentFD):
        def __init__(self):
            self.ydl = self
            self.params = {}
            self.info_dict = {}
    ydl = TestFD()
    ydl.to_screen = lambda *x: x

    # Test exception name is properly displayed
    assert ydl.report_retry_fragment(Exception('test'), 1, 1, 5) == (
        '[download] Got server HTTP error: test. '
        'Retrying fragment 1 (attempt 1 of 5)...')

# Generated at 2022-06-24 11:49:51.930561
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .utils import ExtractorError
    ydl = InfoExtractor()
    dl = HttpQuietDownloader(ydl, {})
    dl.add_progress_hook(lambda s:None)

# Generated at 2022-06-24 11:50:02.199555
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io
    import unittest
    import youtube_dl.YoutubeDL
    from youtube_dl.downloader.fragment import FragmentFD

    saved_stdout = sys.stdout
    output = io.BytesIO()
    sys.stdout = output

    # Mock ydl as FragmentFD.__init__ needs it to be defined
    youtube_dl.YoutubeDL.YoutubeDL.report_skip_fragment = lambda self, s: None

    ydl = youtube_dl.YoutubeDL.YoutubeDL(params={})
    ydl.params['noprogress'] = True

    ffd = FragmentFD(ydl)
    ffd.report_skip_fragment(1)
    ffd.report_skip_fragment(12)

    sys.stdout = saved

# Generated at 2022-06-24 11:50:07.278306
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """
    Test if HttpQuietDownloader also passes the quiet option to
    FileDownloader.__init__
    """

    class DummyYDL(object):
        params = {}

    dl = HttpQuietDownloader(DummyYDL(), {"quiet": True})
    assert dl.params["quiet"]

# Generated at 2022-06-24 11:50:13.102312
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    class DummyFragmentFD(FragmentFD):
        FD_NAME = 'dummy'

    dummy_ydl = object()
    fd = DummyFragmentFD(dummy_ydl, {'ratelimit': 1048576})
    assert fd.params['ratelimit'] == 1048576
    assert isinstance(fd.FD_NAME, str)
    assert fd.ydl is dummy_ydl

# Generated at 2022-06-24 11:50:13.657224
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-24 11:50:21.168657
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FragmentDownloader(FragmentFD):
        def __init__(self, ydl):
            super(FragmentDownloader, self).__init__(ydl)
            self.to_screen_buffer = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_buffer.append(message)
    ydl = {}
    fd = FragmentDownloader(ydl)
    fd.report_skip_fragment(1)
    assert fd.to_screen_buffer == ['[download] Skipping fragment 1...']

# Generated at 2022-06-24 11:50:29.636626
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader

    class _FragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, *args, **kargs):
            self.to_screen_calls.append(args)

    fd = _FragmentFD()
    fd.report_skip_fragment(0)
    assert fd.to_screen_calls[0] == ('[download] Skipping fragment 0...',)

# Generated at 2022-06-24 11:50:39.100248
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io

    class FragmentTestFD(FragmentFD):
        params = {}

    # A FragmentFD instance to be tested
    ydl = FragmentTestFD(None)

    # The output should be printed to stdout
    ydl.to_screen = sys.stdout.write
    # Save the stdout to restore it later
    orig_stdout = sys.stdout

# Generated at 2022-06-24 11:50:49.919751
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .http import HttpFD
    from .rtmp import RtmpFD
    from .dash import DASHFD
    from .hls import HLSFD
    from .hlsnative import HLSFDs
    from .generic import GenericFD
    from .f4m import F4mFD
    from .safari import SafariFD
    fd_classes = [
        HttpFD,
        RtmpFD,
        DASHFD,
        HLSFD,
        HLSFDs,
        GenericFD,
        F4mFD,
        SafariFD,
    ]
    for fd_class in fd_classes:
        fd = fd_class({})

# Generated at 2022-06-24 11:50:57.236732
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import YoutubeIE
    from .downloader.http import HttpQuietDownloader

    ydl = YoutubeIE()
    ydl.params.update({'logger': ydl})
    ydl.add_info_extractor(YoutubeIE)
    ydl.add_default_info_extractors()
    dl = HttpQuietDownloader(ydl, ydl.params)
    dl.to_screen('foo')

# Generated at 2022-06-24 11:51:09.041320
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD()
    assert fd.FD_NAME is None
    assert fd.__class__.__name__ == 'FragmentFD'
    assert hasattr(fd, 'report_retry_fragment')
    assert hasattr(fd, 'report_skip_fragment')
    assert hasattr(fd, '_prepare_url')
    assert hasattr(fd, '_prepare_and_start_frag_download')
    assert hasattr(fd, '__do_ytdl_file')
    assert hasattr(fd, '_read_ytdl_file')
    assert hasattr(fd, '_write_ytdl_file')
    assert hasattr(fd, '_download_fragment')
    assert hasattr(fd, '_append_fragment')

# Generated at 2022-06-24 11:51:10.446365
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # This is test case
    assert(0==0)


# Generated at 2022-06-24 11:51:13.235431
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(HttpQuietDownloader(None, {}), None, {})
    assert fd.params == {}
    assert fd.FD_NAME == 'fragment'


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:51:22.096242
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import tempfile
    import sys
    import io
    import shutil

    def test(ydl, params, filename, urls, ytdl_filename, live_data=None):
        # TODO: Find better way
        # Prepend file with '-' to test the case when .ytdl file is not used
        filename = '-' + filename
        ytdl_filename = '-' + ytdl_filename
        tmpdir = None
        if filename != '-':
            tmpdir = tempfile.mkdtemp(prefix='ytdl-test_FragmentFD-')
            filename = os.path.join(tmpdir, filename)
        if ytdl_filename != '-':
            tmpdir = tempfile.mkdtemp(prefix='ytdl-test_FragmentFD-')
            ytdl_filename = os

# Generated at 2022-06-24 11:51:30.215588
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class MockFD(FragmentFD):
        def __init__(self):
            self.messages = []
        def to_screen(self, *args, **kwargs):
            self.messages.append(' '.join(args))

    fd = MockFD()
    fd.report_retry_fragment(
        ValueError('abc'), 1, 2, 'infinite')
    assert fd.messages == [
        'Got server HTTP error: abc. Retrying fragment 1 (attempt 2 of infinite)...']

# Generated at 2022-06-24 11:51:37.494730
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        def report_retry_fragment(self, err, frag_index, count, retries):
            self.fragment_retry_logs.append((err, frag_index, count, retries))

        def report_skip_fragment(self, frag_index):
            self.fragment_skip_logs.append(frag_index)

        def report_destination(self, filename):
            self.report_dest_logs.append(filename)

        def report_warning(self, message):
            self.report_warn_logs.append(message)

        def _hook_progress(self, status):
            self.progress_hook_logs.append(status)


# Generated at 2022-06-24 11:51:41.906166
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None, None)
    buf = []
    fd._out_string = buf.append
    fd.report_skip_fragment(2)
    assert buf == ['[download] Skipping fragment 2...']



# Generated at 2022-06-24 11:51:50.891548
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    from ..utils import sanitize_open

    class FakeLogger(object):
        def __init__(self):
            self._messages = []

        def to_screen(self, message, skip_eol=False, check_debug=False):
            self._messages.append(message)

    class TestFragmentFD(FragmentFD):
        def __init__(self, ydl):
            FragmentFD.__init__(self, ydl)
            self.test_logger = FakeLogger()

        def to_screen(self, *args, **kwargs):
            self.test_logger.to_screen(*args, **kwargs)


# Generated at 2022-06-24 11:51:53.723670
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .dashsegments import DASHFragmentsFD
    from .hls import HLSFD

    assert issubclass(DASHFragmentsFD, FragmentFD)
    assert issubclass(HLSFD, FragmentFD)

# Generated at 2022-06-24 11:52:01.002162
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():

    class FakeYDL(object):
        def __init__(self):
            self.to_screen_calls = []
        def to_screen(self, *args, **kargs):
            self.to_screen_calls.append((args, kargs))

    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {})
    dl.to_screen('foo', 'bar')
    assert ydl.to_screen_calls == [
        (('foo', 'bar'), {'level': 0, 'line_end': '\n', 'skip_eol': False}),
    ]

# Generated at 2022-06-24 11:52:09.028577
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        pass

    # Constructor without arguments
    fd = MyFragmentFD({})

    # Constructor with arguments
    ydl = {
        'params': {
            'outtmpl': 'video'
        },
        'to_screen': lambda *args, **kargs: None,
    }
    info_dict = {
        'id': 'video_id',
        'format': 'video_format',
        'ext': 'video_ext',
    }
    fd = MyFragmentFD(ydl, {}, info_dict)

# Generated at 2022-06-24 11:52:18.230368
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {'url': 'https://example.org'})

    assert fd._prepare_url({'http_headers': {'Referer': 'https://example.com'}}, 'foo') == {
        'url': 'foo',
        'headers': {'Referer': 'https://example.com'}}

    assert fd._prepare_url({'http_headers': {'Referer': 'https://example.com'}}, 'https://foo.com') == {
        'url': 'https://foo.com',
        'headers': {'Referer': 'https://example.com'}}

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:52:20.427483
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    """
    The method must be silent on any message
    """
    pass