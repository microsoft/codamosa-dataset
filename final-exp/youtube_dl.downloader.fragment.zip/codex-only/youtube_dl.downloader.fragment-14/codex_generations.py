

# Generated at 2022-06-24 11:42:22.620152
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    f = FragmentFD({})
    f.to_screen = lambda s: s
    assert ('[download] Skipping fragment 1...' ==
            f.report_skip_fragment(1))

# Generated at 2022-06-24 11:42:33.943069
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FD(FragmentFD):
        def __init__(self):
            self.messages = []

        def to_screen(self, *args, **kargs):
            self.messages.append((args, kargs))

    fd = FD()
    err = KeyError('key')
    fd.report_retry_fragment(err, 0, 1, 1)
    assert 1 == len(fd.messages)
    assert '[download] Got server HTTP error: key. Retrying fragment 0 (attempt 1 of 1)...' == fd.messages[0][0][0]

    fd.messages = []
    fd.report_retry_fragment(err, 0, 2, 10)
    assert 1 == len(fd.messages)

# Generated at 2022-06-24 11:42:37.544596
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Test if HttpQuietDownloader does not error out
    from .http import HttpFD
    from .fragment import FragmentFD
    from .dash import DASHFD
    fd = FragmentFD(HttpFD(DASHFD()))

# Generated at 2022-06-24 11:42:48.120901
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .downloader.http import HttpFD
    from .downloader.fragment import FragmentFD
    ie = gen_extractors()['youtube']()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie.ydl, FileDownloader)
    assert isinstance(ie.ydl.ydl, FileDownloader)
    assert isinstance(ie.ydl.ydl.fd, HttpFD)
    assert isinstance(ie.ydl.fd, FragmentFD)
    assert isinstance(ie.ydl.fd.fd, HttpFD)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:42:57.702258
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    f = FragmentFD(None, None)
    f.to_screen = lambda *args, **kargs: args

    retries = 0
    assert f.report_retry_fragment('err', 1, 3, retries) == (
        '[download] Got server HTTP error: err. Retrying fragment 1 (attempt 3 of 0)...',)
    retries = 1
    assert f.report_retry_fragment('err', 1, 3, retries) == (
        '[download] Got server HTTP error: err. Retrying fragment 1 (attempt 3 of 1)...',)
    retries = 2
    assert f.report_retry_fragment('err', 1, 3, retries) == (
        '[download] Got server HTTP error: err. Retrying fragment 1 (attempt 3 of 2)...',)
    ret

# Generated at 2022-06-24 11:43:09.962360
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .options import OptParseError
    from ..compat import compat_opts_to_dict
    from ..extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.add_default_info_extractors()
    # TODO: Write a test for http.py
    # Test for HttpQuietDownloader constructor
    dl = HttpQuietDownloader(
        ie, compat_opts_to_dict({
            'quiet': True,
            'noprogress': False,
            'forcetitle': True,
            'ratelimit': 2000000,
            'retries': 10,
            'continuedl': True,
            'nopart': False,
            'test': False,
        })
    )
    assert dl.params['quiet']

# Generated at 2022-06-24 11:43:12.532918
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fd = HttpQuietDownloader(None, {'a': 1, 'b': '2'})
    assert fd.params['a'] == 1
    assert fd.params['b'] == '2'
    assert fd.params.getdefault('c') == None

# Generated at 2022-06-24 11:43:17.175504
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader

    class MyFragmentFD(FragmentFD):
        FD_NAME = 'myfragmentfd'
        def real_download(self, filename, info_dict):
            try:
                self._prepare_frag_download(info_dict)
                self._start_frag_download(info_dict)
                headers = {'User-Agent': 'test-agent'}
                return self._download_fragment(info_dict, 'http://example.com/video.ts', None, headers)
            finally:
                self._finish_frag_download(info_dict)

    class MyFD(FileDownloader):
        def real_download(self, filename, info_dict):
            self.report_destination(filename)
            return True


# Generated at 2022-06-24 11:43:28.095274
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..compat import compat_urllib_request
    from ..utils import DateRange

    # Remove following after https://github.com/rg3/youtube-dl/issues/12135 is fixed
    from ..extractor import gen_extractors, get_info_extractor
    gen_extractors(['youtube'])
    get_info_extractor('Youtube')

    info_dict = {}

# Generated at 2022-06-24 11:43:35.018399
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():

    # Prepare test
    #
    # Use FragmentFD instance as a mock
    fragment_fd = FragmentFD(None, {'outtmpl': '%(id)s.%(ext)s'})
    fragment_fd.to_screen = lambda *args, **kargs: None

    # Test
    #
    # Test that fragment_fd.report_skip_fragment works
    assert fragment_fd.report_skip_fragment(7) == None

# Generated at 2022-06-24 11:43:42.436656
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self, params):
            self.params = params
            self.to_screen_calls = []
        def to_screen(self, message, skip_eol=False):
            self.to_screen_calls.append(message)

    params = {
        'skip_unavailable_fragments': True,
    }
    test_FD = TestFragmentFD(params)

    test_FD.report_skip_fragment(11)
    assert test_FD.to_screen_calls == ['[download] Skipping fragment 11...']

# Generated at 2022-06-24 11:43:45.391571
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None)  # self.ydl is None
    assert fd.params == {}
    assert fd.tmpfilename == ''
    assert fd.filename == ''
    assert fd.dest_stream is None
    assert fd.dl is None

# Generated at 2022-06-24 11:43:57.991968
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self, params):
            self.params = params
            self.to_screen_called = 0
            self.to_screen_message = None

        def to_screen(self, message, skip_eol=False):
            self.to_screen_called += 1
            self.to_screen_message = message
            assert (skip_eol == False)

        def format_retries(self, retries):
            assert (retries == (0,))
            return 'inf'

    fd = TestFragmentFD({})

    fd.report_skip_fragment(2)
    assert fd.to_screen_called == 1
    assert fd.to_screen_message == '[download] Skipping fragment 2...'


# Generated at 2022-06-24 11:44:04.630437
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    hqd = HttpQuietDownloader(None, {'quiet': True, 'ratelimit': None})
    assert hqd.params['quiet']
    assert hqd.params['noprogress']
    assert not hqd.params['ratelimit']

# Generated at 2022-06-24 11:44:11.257716
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None, None)
    # Given
    retries = 1
    frag_index = 1
    count = 2
    err = IOError('test error')
    # When
    fd.report_retry_fragment(err, frag_index, count, retries)
    # Then
    assert(fd.trouble, 'Retrying fragment 1 (attempt 2 of 1)...')


# Generated at 2022-06-24 11:44:17.809279
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # This test verifies that the string to be displayed is not too long
    fd = FragmentFD(None, {}, None)
    # If the string is too long, the output is written in multiple lines
    fd.to_screen = lambda x: x and sys.stderr.write(x.replace('\n', '\n[...] '))
    # This fragment index is very high but should not cause any problem
    # when displaying the string
    fd.report_skip_fragment(1234)
    fd.to_screen('OK')

# Generated at 2022-06-24 11:44:29.652160
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    from ..compat import compat_urllib_error
    from ..utils import encodeFilename

    retry = 2
    err = compat_urllib_error.HTTPError('http://localhost/', 500, 'Error', {}, None)
    frag_index = 4
    fd = FragmentFD(FileDownloader({}), {'quiet': True})
    fd.to_screen = lambda *args, **kwargs: args[0]
    url = 'http://localhost/'
    dest = encodeFilename('test.mp4')
    headers = None
    fragment_filename = '%s-Frag%d' % (dest, frag_index)
    fragment_info_dict = {
        'url': url,
        'http_headers': headers
    }

# Generated at 2022-06-24 11:44:33.118579
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader

    fd = FragmentFD(FileDownloader({}))
    assert fd.params['fragment_retries'] == 10
    assert fd.params['skip_unavailable_fragments']
    assert not fd.params['keep_fragments']


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:44:36.792856
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl
    ydl = youtube_dl.YoutubeDL({})
    qd = HttpQuietDownloader(ydl, {'noprogress': True})
    assert qd.ydl == ydl

# Generated at 2022-06-24 11:44:45.497172
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from io import StringIO
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'format': 'bestaudio/best', 'quiet': True, 'logger': __name__})
    dl = HttpQuietDownloader(ydl, {'quiet': True, 'noprogress': True})
    out = StringIO()
    dl.to_screen('test')
    assert out.getvalue() == ''
    dl.to_screen('test', skip_eol=True)
    assert out.getvalue() == ''
    dl.to_screen('test', skip_eol=False)
    assert out.getvalue() == ''
    dl.to_stderr('test')
    assert out.getvalue() == ''
    dl.to_console_title('test')


# Generated at 2022-06-24 11:44:47.812224
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(object())
    assert(fd.params == {})

# Generated at 2022-06-24 11:44:49.130102
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    assert FragmentFD({}, {}).report_retry_fragment(
        'error', 1, 2, 3) == None


# Generated at 2022-06-24 11:44:55.418655
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {})
    fd.to_screen = lambda *args, **kargs: args
    expected = (
        '[download] Got server HTTP error: Test error. Retrying fragment 1 (attempt 2 of 3)...',)
    assert fd.report_retry_fragment(IOError('Test error'), 1, 2, 3) == expected


# Generated at 2022-06-24 11:44:58.174689
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD('http://youtube.com/videoplay?docid=12345', {}, {})
    assert fd.params



# Generated at 2022-06-24 11:45:07.666078
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractor

    class DummyYDL(object):
        def __init__(self):
            self._ies = []

        def add_info_extractor(self, ie):
            self._ies.append(gen_extractor(ie))

        def extract_info(self, url, download=True, ie_key=None, extra_info={}):
            name_or_module = ie_key or 'generic'
            ie = self._ies[0] if name_or_module == 'generic' else self._ies[1]
            ie.url = url
            return ie.extract(url)

    fd = FragmentFD(DummyYDL())
    fd.to_screen = _doctest_print

# Generated at 2022-06-24 11:45:08.938319
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader is not None


# Generated at 2022-06-24 11:45:12.769432
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({}, None)
    fd.to_screen = lambda *args, **kargs: None
    fd.report_skip_fragment(42)
    return 'OK'

# Generated at 2022-06-24 11:45:23.785324
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .test import FakeYDL
    from .extractor import gen_extractors
    def my_hook(d):
        pass
    ydl = FakeYDL()
    gen_extractors(ydl)

    assert(not isinstance(ydl.add_default_info_extractors(), type(ydl)))
    assert(ydl.add_default_info_extractors() == ydl)

    f = FragmentFD(ydl, {})

    assert(f.ydl == ydl)

    assert(isinstance(f.params, dict))
    assert(f.params == {})

    assert(isinstance(f._hooks, dict))
    assert(f._hooks == {})

    assert(f.add_progress_hook(my_hook) == f)

# Generated at 2022-06-24 11:45:35.036930
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import YoutubeIE
    # We need a subclass that doesn't mess with
    # fragments on construction
    class FakeYoutubeIE(YoutubeIE):
        def __init__(self, *args, **kwargs):
            pass
    ie = FakeYoutubeIE('test')

    # Test for the `live` flag in __init__
    ff = FragmentFD(ie)
    assert ff.live is False
    ff = FragmentFD(ie, live=False)
    assert ff.live is False
    ff = FragmentFD(ie, live=True)
    assert ff.live is True

    # Test for the `retries` argument in __init__
    ff = FragmentFD(ie)
    assert ff.params.get('retries') is None
    ff = FragmentFD(ie, retries=0)


# Generated at 2022-06-24 11:45:38.603177
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    ydl = None
    fd = FragmentFD(ydl, {}, {})
    fd.to_screen = lambda *args, **kwargs: args
    assert fd.report_retry_fragment(
        'error',
        1,
        2,
        {'max_retries': 5}) == (
        '[download] Got server HTTP error: error. Retrying fragment 1 (attempt 2 of 5)...',)


# Generated at 2022-06-24 11:45:40.295585
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    assert fd.report_skip_fragment(0) is None


# Generated at 2022-06-24 11:45:49.047248
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    hqd = HttpQuietDownloader(
        None, {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
        })
    assert hqd.params['continuedl'] == True
    assert hqd.params['quiet'] == True
    assert hqd.params['noprogress'] == True
    assert hqd.params['ratelimit'] == None
    assert hqd.params['retries'] == 0
    assert hqd.params['nopart'] == False
    assert hqd.params['test'] == False


# Generated at 2022-06-24 11:46:00.208634
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from . import YoutubeDL
    ydl = YoutubeDL(params={
        'noprogress': True,
        'outtmpl': '%(id)s-%(format_id)s.%(ext)s',
    })
    extractors = gen_extractors(ydl)

    fmt = next(e for e in extractors if e.IE_NAME == 'hlsnative')
    fd = FragmentFD(ydl, fmt, {
        'url': 'http://example.com/video.f4m',
        'ext': 'mp4',
        'format_id': '270',
        'format_note': '270p',
        'fps': 30,
    })

# Generated at 2022-06-24 11:46:08.058593
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloaderTest
    from .http import HttpFDTest
    from .youtube_dl.YoutubeDL import YoutubeDL
    file_downloader_test = FileDownloaderTest('.', dict(params=dict(format='best', quiet=True)))
    http_downloader_test = HttpFDTest('.', dict(params=dict(format='best', quiet=True)))
    fd = FragmentFD(YoutubeDL(file_downloader_test.params), file_downloader_test.params)
    http_fd = HttpFD(YoutubeDL(http_downloader_test.params), http_downloader_test.params)
    fd.to_screen = http_fd.to_screen
    fd.report_skip_fragment(1)


# Generated at 2022-06-24 11:46:09.554729
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    hqd = HttpQuietDownloader({}, {'quiet':True})
    assert hqd.params['quiet'] == True

# Generated at 2022-06-24 11:46:12.760820
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    def to_screen(val):
        assert val == '[download] Got server HTTP error: test. Retrying fragment 1 (attempt 2 of 50)...'
    params = {
        'retries': 50,
    }
    fd = FragmentFD(None, params)
    fd.to_screen = to_screen
    fd.report_retry_fragment(Exception('test'), 1, 2, params['retries'])


# Generated at 2022-06-24 11:46:25.296156
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({}, {'noprogress': True})
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(
        RuntimeError('Test'), 123, 456, 789) == (
            'Test', 123, 456, 789)
    assert fd.report_retry_fragment(
        RuntimeError('Test'), 123, 456, 1) == (
            'Test', 123, 456, 1)
    assert fd.report_retry_fragment(
        RuntimeError('Test'), 123, 1, 789) == (
            'Test', 123, 1, 789)

# Generated at 2022-06-24 11:46:29.351120
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class DummyYDL:
        params = {}
    fd = FragmentFD(DummyYDL())
    fd.to_screen = lambda *args, **kargs: True
    fd.report_retry_fragment(Exception('err'), 7, 2, 5)
    assert True

if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:46:37.665662
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    fd.to_screen = lambda *args, **kargs: test_FragmentFD_report_skip_fragment.result.extend(args)
    test_FragmentFD_report_skip_fragment.result = []
    fd.report_skip_fragment(1)
    fd.report_skip_fragment(2)
    assert test_FragmentFD_report_skip_fragment.result == [
        '[download] Skipping fragment 1...',
        '[download] Skipping fragment 2...',
    ]

# Generated at 2022-06-24 11:46:41.236627
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import FileDownloader
    fd = FragmentFD(FileDownloader({}))
    assert hasattr(fd, 'FD_NAME')
    assert hasattr(fd, '_download_fragment')
    assert hasattr(fd, '_append_fragment')

# Generated at 2022-06-24 11:46:42.986197
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    fd = HttpQuietDownloader(None, None)
    assert fd.to_screen() == None

# Generated at 2022-06-24 11:46:54.855593
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .http import FragmentFD
    from .extractor.common import InfoExtractor
    from .utils import TestDownloader
    from .compat import is_py2

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        def _real_extract(self, url):
            return {
                'id': 'test_id',
                'url': url,
                'title': 'test title'
            }

    # Test that it works with py2
    if is_py2:
        TestIE._real_extract = TestIE._real_extract.__func__

    class TestFragmentFD(FragmentFD):
        FD_NAME = 'test'

        def __init__(self, ydl):
            super(TestFragmentFD, self).__init__(ydl)


# Generated at 2022-06-24 11:46:58.177380
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class MockYdl(object):
        def __init__(self):
            self.params = {}

    try:
        HttpQuietDownloader(MockYdl(), {})
    except Exception as e:
        assert False, 'Unexpected exception raised: %r' % e

# Generated at 2022-06-24 11:47:00.280501
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    assert fd.report_retry_fragment(IOError('error'), 1, 1, 10) == None

# Generated at 2022-06-24 11:47:04.577145
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None)
    fd.to_screen = lambda *args, **kargs: args[0]
    assert fd.report_retry_fragment(1, 2, 3, 4) == 'Got server HTTP error: 1. Retrying fragment 2 (attempt 3 of 4)...'



# Generated at 2022-06-24 11:47:08.227531
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = FileDownloader()
    hqd = HttpQuietDownloader(ydl)
    assert hqd.to_screen('test') is None

# Generated at 2022-06-24 11:47:10.336183
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD('/tmp', {}, True)
    assert fd.ydl is not None

# Generated at 2022-06-24 11:47:12.710959
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MockFileDownloader(object):
        def to_screen(self, message):
            self.message = message

    fd = MockFileDownloader()
    fragmentFD_instance = FragmentFD(None, None, None)
    fragmentFD_instance.to_screen = fd.to_screen
    fragmentFD_instance.report_skip_fragment(0)
    assert fd.message == '[download] Skipping fragment 0...'

# Generated at 2022-06-24 11:47:17.943298
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractors, list_extractors
    # Get an HttpQuietDownloader
    ydl = gen_extractors()['youtube']()
    ydl.add_default_info_extractors()
    dl = HttpQuietDownloader(ydl, {'noprogress': False, 'quiet': False})

# Generated at 2022-06-24 11:47:27.721750
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import pytest
    from ytdl.config import (
        YoutubeDL,
        YoutubeDLHandledException,
        DownloadError,
    )
    from ytdl.utils import (
        sanitize_open,
    )
    from ytdl.extractor import get_info_extractor

    class FakeYoutubeDL(YoutubeDL):
        def __init__(self, params, ydl_opts):
            self.params = params
            self.ydl_opts = ydl_opts
        def to_screen(self, *args, **kargs):
            pass

    class FakeIE(object):
        def __init__(self, ie_result):
            self.ie_result = ie_result
        def _real_extract(self, url):
            return self.ie_result

# Generated at 2022-06-24 11:47:30.774560
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = HttpQuietDownloader(object(), dict())
    ydl.to_screen('This is a test')
    assert True

# Generated at 2022-06-24 11:47:41.143700
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TmpHttpQuietDownloader(HttpQuietDownloader):
        def __init__(self, ydl):
            super(TmpHttpQuietDownloader, self).__init__(ydl)
            self.to_screen_messages = []

        def to_screen(self, msg):
            self.to_screen_messages.append(msg)

    ydl = object()
    dl = TmpHttpQuietDownloader(ydl)
    dl.to_screen('Test')
    assert 'Test' not in dl.to_screen_messages
    dl.to_screen('Test', *(None,))
    assert 'Test' not in dl.to_screen_messages
    dl.to_screen('Test', *(None, ), **{'test': None})

# Generated at 2022-06-24 11:47:47.079921
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    try:
        # Remove stdout and stderr
        sys.stdout.close()
        sys.stderr.close()
        del sys.stdout
        del sys.stderr
    except Exception:
        pass
    fd = FragmentFD(None)
    assert fd.fd is None

# Generated at 2022-06-24 11:47:56.762905
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class DummyFD(FragmentFD):
        def __init__(self, ydl):
            super(DummyFD, self).__init__(ydl)
            self._report_skip_fragment_dict = {}

        def to_screen(self, msg):
            frag_index = None
            if 'skipping fragment' in msg.lower():
                frag_index = int(msg.split()[2])
            self._report_skip_fragment_dict[frag_index] = msg

    class DummyYDL(object):
        def __init__(self):
            self.to_screen = lambda *args, **kargs: None

    ydl = DummyYDL()
    fd = DummyFD(ydl)

    fd.report_skip_fragment(1)
    assert fd

# Generated at 2022-06-24 11:48:04.531962
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class FakeInfoDict:
        def __init__(self, d):
            self.__dict__ = d
    class FakeYDL:
        def __init__(self):
            self.params = {}
    info = FakeInfoDict({'url': 'some-url', 'fragment_index': 2})
    fd = FragmentFD(FakeYDL(), info)

    assert fd.ydl is FakeYDL()
    assert fd.info is info
    assert fd.params is FakeYDL().params
    assert fd.url == 'some-url'
    assert fd.fragment_index == 2


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:48:16.263272
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = FakeYoutubeDL({
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'test': True,
    })
    ctx = HttpQuietDownloader(ydl, {}).test(
        'http://127.0.0.1:9127/test.mp4',
        'test.mp4',
        {
            'http_headers': {'Referer': 'http://example.com'},
        }
    )
    assert ctx['info_dict']['url'] == 'http://127.0.0.1:9127/test.mp4'
    assert ctx['info_dict']['http_headers'] == {'Referer': 'http://example.com'}

# Generated at 2022-06-24 11:48:26.872288
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from io import StringIO
    from sys import version_info

    class DummyYDL(object):
        def __init__(self):
            self.to_stdout = StringIO()

    fd = FragmentFD(DummyYDL(), {'noprogress': True})
    fd.to_screen = fd.to_stdout.write

    fd.report_skip_fragment(0)
    assert fd.to_stdout.getvalue() == '[download] Skipping fragment 0...\n'

    fd.report_skip_fragment(255)
    assert fd.to_stdout.getvalue() == '[download] Skipping fragment 0...\n[download] Skipping fragment 255...\n'


# Generated at 2022-06-24 11:48:29.429264
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(object, {'continuedl': True, 'quiet': True})

# Generated at 2022-06-24 11:48:32.971708
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import HEADRequest
    from ..compat import compat_urllib_request

    print(compat_urllib_request.urlopen(
        HEADRequest('http://www.google.com/humans.txt')).headers)

# Generated at 2022-06-24 11:48:42.287413
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
  from youtube_dl.downloader.http import HttpQuietDownloader
  from html.parser import HTMLParser
  from mock import Mock, patch
  from six.moves import StringIO

  html_parser = HTMLParser()
  downloader = HttpQuietDownloader(Mock(), {'geo_verification_proxy':'https://gimmeproxy.com'})
  downloader.to_screen(
      'foo', 'bar', {'end': '[download] foo'},
      html_parser.unescape('\u2026'), {},
      '\u304a\u304a\u304a\u304a\u304a\u304a', '\u2b50\u2b50\u2b50', '\ue000')

  # By checking the output of to_screen using StringIO, we can

# Generated at 2022-06-24 11:48:48.990895
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..YoutubeDL import YoutubeDL
    from .common import FileDownloader
    from .http import HttpFD

    ydl = YoutubeDL()
    fd = FileDownloader(ydl)
    hqd = HttpQuietDownloader(ydl)

    assert isinstance(hqd, HttpFD)
    assert hqd.params == fd.params
    assert hqd.progress_hooks == []

# Generated at 2022-06-24 11:49:00.746724
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .common import FileDownloader
    from .fragment import FragmentFD
    from ..compat import compat_str

    assert issubclass(HttpQuietDownloader, HttpFD)
    assert issubclass(HttpQuietDownloader, FragmentFD)
    assert issubclass(HttpQuietDownloader, FileDownloader)

    assert isinstance(HttpQuietDownloader.to_screen, staticmethod)
    assert isinstance(HttpQuietDownloader.to_stderr, staticmethod)
    assert isinstance(HttpQuietDownloader.to_console_title, staticmethod)

    assert isinstance(HttpQuietDownloader.report_error, staticmethod)
    assert isinstance(HttpQuietDownloader.report_warning, staticmethod)

# Generated at 2022-06-24 11:49:03.702309
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import StringIO
    sys.stdout = StringIO.StringIO()
    ydl = HttpQuietDownloader(None, {})
    assert sys.stdout.getvalue() == ''
    assert not ydl.params.get('progress_hooks')

# Generated at 2022-06-24 11:49:06.648230
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {})
    assert fd.report_skip_fragment('42') is None


# Generated at 2022-06-24 11:49:15.297783
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_calls = []
        def to_screen(self, *args, **kargs):
            self.to_screen_calls.append('[download] Skipping fragment 1...')

    test = TestFragmentFD()
    test.report_skip_fragment(1)
    assert test.to_screen_calls == [
        '[download] Skipping fragment 1...',
    ], test.to_screen_calls

# Generated at 2022-06-24 11:49:18.020513
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    # Assert if "%s" is not in the string
    assert "%s" in fd.report_retry_fragment(None, 1, 2, 3)


# Generated at 2022-06-24 11:49:24.944137
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD

    for FDCls in (FileDownloader, HttpFD, DASHFD, HLSFD):
        fd = FDCls()
        fd.to_screen = lambda *_: None
        fd.add_progress_hook(lambda *_: ())
        fd.report_skip_fragment(0)

# Generated at 2022-06-24 11:49:29.010196
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class Test(HttpQuietDownloader):
        def to_screen(self, data):
            print(str(data))

    # Test if null string is printed
    Test(None, {}).to_screen('')

    # Test if non-null string is printed
    Test(None, {}).to_screen('abc')

# Generated at 2022-06-24 11:49:35.727514
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .options import makeOpts
    from .post import gen_post_processors

    opts = makeOpts()
    ie = gen_extractors()
    pp = gen_post_processors()

    # options, ie, pp can be None
    HttpQuietDownloader(None, None, None, None)

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:49:44.629180
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD
    from .hlsnative import HLSNativeFD
    from ..utils import prepend_extension
    from argparse import Namespace
    class TestFD(DASHFD, HLSFD, HLSNativeFD):
        pass
    TestFD.FD_NAME = 'testfd'
    FD_class = TestFD
    params = {
        'noprogress': True,
        'nopart': True,
        'retries': 10,
        'fragment_retries': 10,
    }
    ydl = Namespace()
    ydl.params = params
    ydl.to_screen = lambda *args: None

# Generated at 2022-06-24 11:49:58.050359
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: args
    assert (
        fd.report_retry_fragment(
            'http error',
            frag_index=7,
            count=123,
            retries=8)
        ==
        ('[download] Got server HTTP error: %r. Retrying fragment 7 (attempt 123 of 8)...'
         % 'http error',))

    assert (
        fd.report_retry_fragment(
            'http error',
            frag_index=7,
            count=1111,
            retries=8)
        ==
        ('[download] Got server HTTP error: %r. Retrying fragment 7 (attempt 1,111 of 8)...'
         % 'http error',))


# Generated at 2022-06-24 11:50:02.847027
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params = {'continuedl': True, 'quiet': True, 'noprogress': True}
    dl = HttpQuietDownloader(
        object(), {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': None,
            'retries': None,
            'nopart': False,
            'test': False,
        }
    )
    assert params == dl.params

# Generated at 2022-06-24 11:50:07.619168
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)
    assert hasattr(FragmentFD, '_start_frag_download')
    assert hasattr(FragmentFD, '_prepare_frag_download')

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:50:11.155709
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({})
    try:
        raise ValueError('test')
    except ValueError as e:
        fd.report_retry_fragment(e, 1, 2, 3)


# Generated at 2022-06-24 11:50:19.721323
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor.common import InfoExtractor

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'ext': 'mp4',
                'title': 'test',
            }

    ie = TestIE()
    ie.add_info_extractor(TestIE())
    options = { 'skip_download': True }
    fd = FragmentFD(ie, ie.suitable_download_extractor(url), 'test', 'test', options)
    class Logger:
        def __init__(self):
            self.buf = ""
        def toScreen(self, msg):
            self.buf += msg + '\n'

    logger = Logger()
    fd.to_screen = logger.toScreen
    err_code

# Generated at 2022-06-24 11:50:23.475242
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD.__new__(FragmentFD)
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_skip_fragment(42) == [
        '[download] Skipping fragment 42...']

# Generated at 2022-06-24 11:50:34.661869
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .downloader.external import ExternalFD
    # Mock up an InfoExtractor
    ie = InfoExtractor(None, {})
    ie._downloader = ExternalFD(ie, {}, False, False)
    ie._downloader.to_screen = lambda *args: args
    # Mock up an HttpQuietDownloader
    dl = HttpQuietDownloader(ie, {})
    # The to_screen method of HttpQuietDownloader should return the same that
    # the to_screen method of its associated InfoExtractor
    assert dl.to_screen('hello', 'world') == ie.to_screen('hello', 'world')

# Generated at 2022-06-24 11:50:41.859062
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    hqd = HttpQuietDownloader.__new__(HttpQuietDownloader)
    hqd.__init__(None, {})
    assert hqd._ydl is None

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:50:45.799660
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None, None)
    fd.to_screen = lambda x: x

    expected_result = '[download] Got server HTTP error: bla. Retrying fragment 2 (attempt 3 of 22)...'
    result = fd.report_retry_fragment(Exception('bla'), 2, 3, 22)
    assert result == expected_result

# Generated at 2022-06-24 11:50:55.120523
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=protected-access
    assert FragmentFD._prepare_destination('foo.avi') == 'foo.avi'
    assert FragmentFD._prepare_destination('-') == '-'
    assert FragmentFD._prepare_destination('-', format_id='mp4') == '-'
    assert FragmentFD._prepare_destination('-', format_id='flv') == '-'
    assert FragmentFD._prepare_destination('-', format_id='flv', forced_format='mp4') == '-%(ext)s'
    assert FragmentFD._prepare_destination('-', format_id='mp4', forced_format='flv') == '-%(ext)s'

# Generated at 2022-06-24 11:51:06.828247
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import unittest

    class _FragmentFD__Mock__FragmentFD(FragmentFD):
        def __init__(self, to_screen):
            FileDownloader.__init__(self)
            self.__to_screen = to_screen

        def to_screen(self, *args, **kargs):
            self.__to_screen(*args, **kargs)

    class _FragmentFD__Test(unittest.TestCase):
        def setUp(self):
            self.__text_chunks = []
            self.__fd = _FragmentFD__Mock__FragmentFD(self.__to_screen)

        def tearDown(self):
            self.__fd = None

        def __to_screen(self, *args, **kargs):
            self.__text_ch

# Generated at 2022-06-24 11:51:13.847742
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor import get_info_extractor

    fd = FragmentFD(get_info_extractor('generic'), {})
    fd_to_screen = fd.to_screen
    def to_screen(message, skip_eol=False):
        assert message == '[download] Skipping fragment 0...'
    fd.to_screen = to_screen
    fd.report_skip_fragment(0)
    fd.to_screen = fd_to_screen
    assert True

# Generated at 2022-06-24 11:51:23.898078
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import io
    import unittest
    from .http import HttpFD

    class NullDevice():
        def write(self, s):
            pass

    def new_stdout():
        return io.StringIO()

    def old_stdout():
        return sys.stdout

    def stdout_as_string(stdout):
        return stdout.getvalue()

    def to_screen(ytdl, msg):
        ytdl.to_screen(msg)

    class TestHttpQuietDownloader(unittest.TestCase):

        def setUp(self):
            self.ytdl = HttpQuietDownloader(None, None)

        def tearDown(self):
            pass

        def test_to_screen(self):
            ytdl = self.ytdl

# Generated at 2022-06-24 11:51:27.441865
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    FileDownloader._safe_print = lambda s: s
    FileDownloader.report_warning = lambda s: s


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:51:32.852382
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    out, err = sys.stdout, sys.stderr
    sys.stdout = sys.stderr = open('/dev/null', 'w')
    try:
        assert HttpQuietDownloader({}, {})
    finally:
        sys.stdout, sys.stderr = out, err

# Generated at 2022-06-24 11:51:35.190172
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader(None, {'continuedl': True})
    assert(ydl.params['continuedl'])

# Generated at 2022-06-24 11:51:41.538742
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeYaDL:
        def __init__(self):
            self.to_screen_list = []

        def to_screen(self, message, skip_eol=False, check_quiet=False):
            self.to_screen_list.append(message)

    ydl = FakeYaDL()
    dl = HttpQuietDownloader(ydl, None)
    dl.to_screen('test message')
    assert len(ydl.to_screen_list) == 0

# Generated at 2022-06-24 11:51:50.700973
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor.youtube import YoutubeIE

    class MockYoutubeIE(YoutubeIE):
        REQUEST_ERRORS = (('failed', "message"),)

    class MockFragmentFD(FragmentFD):
        FD_NAME = 'mock'

    retry_count = 2
    expected_retry_message = '[mock] Got server HTTP error: message. Retrying fragment 1 (attempt %d of %s)...' % (
        retry_count, FragmentFD.format_retries(retry_count))

    mock_fd = MockFragmentFD({}, MockYoutubeIE({}))
    mock_fd._hook_progress = lambda status: None
    mock_fd.report_retry_fragment(('failed', "message"), 1, retry_count, retry_count)

    mock_fd.to_

# Generated at 2022-06-24 11:52:00.018107
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..utils import encodeFilename
    import sys

    # Method for testing
    def test_report_retry_fragment(err, frag_index, count, retries):
        FragmentFD.report_retry_fragment(None, err, frag_index, count, retries)

    # Redirect stdout for testing
    old_stdout = sys.stdout
    sys.stdout = file(encodeFilename('/dev/null'), 'w')

# Generated at 2022-06-24 11:52:11.326452
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            self.to_screen = []
            self.params = params
            self.ydl = ydl

        def to_screen(self, message, skip_eol=False):
            self.to_screen.append(message)

    fd = TestFD(None, {'skip_unavailable_fragments': True})

    fd.report_skip_fragment(1)
    assert fd.to_screen == ['[download] Skipping fragment 1...']
    assert fd.params['skip_unavailable_fragments'] is True

    fd.params['skip_unavailable_fragments'] = False

    fd.report_skip_fragment(3)

# Generated at 2022-06-24 11:52:21.054158
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # pylint: disable=protected-access
    import sys
    import StringIO
    out = StringIO.StringIO()
    err = StringIO.StringIO()
    fd = FragmentFD(
        object(),
        {
            'noprogress': True,
            'outtmpl': '%(id)s',
        },
    )
    fd.to_screen = lambda s, **k: out.write(s + '\n')
    fd.to_stderr = lambda s, **k: err.write(s + '\n')

    # Test for fragment index = 0
    sys.stdout = out = StringIO.StringIO()
    sys.stderr = err = StringIO.StringIO()
    fd.report_skip_fragment(0)
    sys.stdout