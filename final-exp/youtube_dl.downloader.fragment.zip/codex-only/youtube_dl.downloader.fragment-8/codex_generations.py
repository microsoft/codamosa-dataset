

# Generated at 2022-06-24 11:42:19.122431
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    FragmentFD(None, {}, None)


# Generated at 2022-06-24 11:42:28.499678
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class DummyExtractor(FragmentFD):
        def __init__(self, ydl, params):
            # This is a dummy extractor that does nothing useful
            self.ydl = ydl
            self.params = params
            self.fragment_index = params.get('fragment_index', 0)
            self.total_frags = params.get('total_frags', 0)
            self.frag_urls = params.get('frag_urls', [])
            super(DummyExtractor, self).__init__(ydl, params)
            # Normally fragment_count is passed in info dict, hence we can set
            # it here
            self.fragment_count = self.total_frags

        def get_real_downloader(self, filename, info_dict):
            return None



# Generated at 2022-06-24 11:42:35.057637
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader

    class MyFragmentFD(FragmentFD):
        def __init__(self):
            self.out = []
            self.err = []
        def to_screen(self, s):
            self.out.append(s)
        def trouble(self, s):
            self.err.append(s)
        def format_retries(self, retries):
            return '{}-{}'.format(retries, retries * 2)

    fd = MyFragmentFD()
    # fragment_retries is 3
    fd.params = {
        'fragment_retries': 3,
        'skip_unavailable_fragments': False,
        'keep_fragments': False,
    }

    # OK (retry #1)
    fd.report

# Generated at 2022-06-24 11:42:41.458452
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys

    class StringIO(object):
        def __init__(self):
            self.content = ''

        def __call__(self, *args, **kwargs):
            self.content += ' '.join(unicode(arg) for arg in args) + '\n'

    stringio = StringIO()
    sys.stdout = stringio
    dl = HttpQuietDownloader(None, {})
    dl.to_screen('test')
    sys.stdout = sys.__stdout__
    assert stringio.content == ''

# Generated at 2022-06-24 11:42:44.860803
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert 'fragment_retries' in FragmentFD.available_options
    assert 'skip_unavailable_fragments' in FragmentFD.available_options
    assert 'keep_fragments' in FragmentFD.available_options

# Generated at 2022-06-24 11:42:45.541810
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 11:42:52.671097
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    sys.stderr = sys.stdout

    def proc_info(info_dict):
        print('\n%s\n' % info_dict)
    def prog_hook(s):
        print('\r%.02f%% of %.02fMB' % (s['downloaded_bytes'] / 1048576, float(s['total_bytes']) / 1048576))

    ydl = FileDownloader(params={'quiet': True, 'noprogress': False})
    ydl.add_info_extractor(None)
    dl = HttpQuietDownloader(ydl, params={'quiet': True, 'noprogress': True, 'continuedl': True})
    dl.add_progress_hook(prog_hook)

# Generated at 2022-06-24 11:43:04.300013
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class _FakeLogger(object):
        def __init__(self):
            self.messages = []

        def debug(self, message, *args):
            self.messages.append(message % args)

    dl = HttpQuietDownloader(None, {})
    dl.to_screen('a', 'b', kw='c')
    assert dl.to_screen.__name__ == 'to_screen'

    dl.ydl = type('FakeYoutubeDL', (object,), {
        'params': {
            'verbose': True,
        },
        '_screen_file': _FakeLogger(),
        '_err_file': _FakeLogger(),
    })()

    dl.to_screen('a', 'b', kw='c')
    assert dl.to_

# Generated at 2022-06-24 11:43:15.250015
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from io import BytesIO
    from .http import HeadRequest

    fd = FragmentFD()

    assert fd.ydl is None

    assert fd.params['noprogress']
    assert not fd.params['verbose']

    assert fd.max_fragment_retries == 10
    assert not fd.skip_unavailable_fragments
    assert not fd.keep_fragments
    assert not fd.retries

    # _prepare_url
    assert fd._prepare_url({'url': 'abc', 'http_headers': {'a': 'b'}}, 'def') == sanitized_Request('def', None, {'a': 'b'})

# Generated at 2022-06-24 11:43:21.183988
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({})
    hqd = HttpQuietDownloader(ydl, {})
    hqd.download({'url': 'https://github.com/rg3/youtube-dl/archive/master.tar.gz'})

# Generated at 2022-06-24 11:43:30.201362
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from ..utils import match_filter_func

    def check(self, *args, **kwargs):
        assert 'Skipping fragment 1...' in args[0]
        return 0
    class TestFD(FragmentFD):
        def to_screen(self, *args, **kargs):
            return check(self, *args, **kargs)
    fd = TestFD(None, {'extractor_key': 'tt'})
    fd.report_skip_fragment(1)

    class TestFD(FragmentFD):
        def to_screen(self, *args, **kargs):
            pass
    fd = TestFD(None, {'extractor_key': 'tt'})
    assert not match_filter_func(fd, 'report_skip_fragment', 1)()


# Generated at 2022-06-24 11:43:39.576246
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from ..extractor import gen_extractors
    from .http import YoutubeDLHandler
    from .rtmp import RTMPDownloader
    from .external import ExternalFD

    ydl = MockYDL()

    # Some standard downloader that uses to_screen in some way
    fd = YoutubeDLHandler(ydl, {
        'continuedl': True,
        'noprogress': True,
        'quiet': False,
    })
    info_dict = {
        'id': '123',
        'url': 'http://example.org',
        'title': 'title',
        'ext': 'ext',
        'http_headers': {'foo': 'bar'},
    }
    assert fd.to_screen == ydl.to_screen

# Generated at 2022-06-24 11:43:48.612362
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors

    info_dict = {}
    ydl = {}
    params = {
        'fragment_retries': 10,
        'skip_unavailable_fragments': True,
        'keep_fragments': True,
    }
    assert FragmentFD.suitable(info_dict)
    assert FragmentFD(ydl, info_dict, params).params == params
    assert not FragmentFD.suitable(info_dict)

    info_dict = {'protocol': 'http'}
    assert FragmentFD.suitable(info_dict)
    assert FragmentFD(ydl, info_dict, params).params == params
    assert not FragmentFD.suitable(info_dict)

    for ie in gen_extractors():
        ie.ydl = y

# Generated at 2022-06-24 11:43:52.346294
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FileDownloader, object)
    assert issubclass(HttpFD, FileDownloader)

# Generated at 2022-06-24 11:43:59.010809
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class MyFragmentFD(FragmentFD):
        def format_retries(self, retries):
            return retries

    fd = MyFragmentFD(None)
    correct = 'Error description. Retrying fragment 2 (attempt 5 of 42)...'
    assert fd.report_retry_fragment('Error description', 2, 5, 42) == correct

if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:44:11.335530
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'fake'
        IE_DESC = 'Fake extractor'
        _VALID_URL = r'(?i)^https?://.+'

# Generated at 2022-06-24 11:44:13.962823
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader(None, {'continue': True, 'quiet': True, 'noprogress': True})
    assert dl._opts['continue'] == True

# Generated at 2022-06-24 11:44:17.432050
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    warn_func = lambda msg: msg.startswith('WARNING')
    hd = HttpQuietDownloader(warn_func, {'continuedl': False})
    assert hd.params['continuedl'] is False
    assert hd._ydl is warn_func

# Generated at 2022-06-24 11:44:20.448567
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    assert FragmentFD.report_retry_fragment(
        'err', 'frag_index', 'count', 'retries')

# Generated at 2022-06-24 11:44:23.930761
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    ie = InfoExtractor({})
    quiet_dl = HttpQuietDownloader(ie, {})
    assert quiet_dl.ydl is ie

# Generated at 2022-06-24 11:44:30.105613
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import StringIO
    orig_stdout = sys.stdout
    try:
        sys.stdout = StringIO.StringIO()
        fragmentfd = FragmentFD(None, None)
        fragmentfd.report_skip_fragment(1)
        assert sys.stdout.getvalue() == '[download] Skipping fragment 1...\n'
    finally:
        sys.stdout = orig_stdout



# Generated at 2022-06-24 11:44:33.235332
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = FileDownloader({})
    qdl = HttpQuietDownloader(ydl, {})
    # This function uses two print() calls
    qdl.to_screen('foo')
    assert ydl.to_screen_strs == []

# Generated at 2022-06-24 11:44:41.086802
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..utils import DateRange, std_headers

    class TestFD(FragmentFD):
        def report_destination(self, filename):
            pass

        def _hook_progress(self, status):
            pass

        def ydl_is_updateable(self):
            return True

        def temp_name(self, *args, **kwargs):
            return '-'

        def try_utime(self, *args, **kwargs):
            pass

        @staticmethod
        def calc_eta(start, now, total, numbytes):
            return now - start

        @staticmethod
        def try_rename(tmpfilename, filename):
            pass

        @staticmethod
        def format_bytes(bytes):
            return '%d' % bytes


# Generated at 2022-06-24 11:44:50.972694
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    options = {
        'skip_unavailable_fragments': True,
        'fragment_retries': 10,
        'keep_fragments': True,
    }
    class TestFD(FragmentFD):
        FD_NAME = 'testfd'
        def __init__(self, ydl):
            FragmentFD.__init__(self, ydl, options)
    from .YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'noprogress': True})
    ydl.add_info_extractor(TestFD)
    ydl.download(['http://example.org/'])

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:44:55.620771
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    frag_fd = FragmentFD(None, None, {}, {}, {})
    frag_fd.to_screen = lambda *args, **kwargs: None
    frag_fd.report_retry_fragment('error', 3, 4, 5)

# Generated at 2022-06-24 11:45:03.710403
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    fd.to_screen = lambda *args, **kargs: args
    frag_index = 42
    count = 1
    retries = 3
    expected_msg = (
        '[download] Got server HTTP error: HTTP Error 404: Not Found. '
        'Retrying fragment %d (attempt %d of 3)...'
        % (frag_index, count, retries))
    assert fd.report_retry_fragment('HTTP Error 404: Not Found', frag_index, count, retries) == (expected_msg,)


# Generated at 2022-06-24 11:45:05.765705
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = HttpQuietDownloader({}, {})
    output = ydl.to_screen('test', 'output')
    assert output is None

# Generated at 2022-06-24 11:45:16.616225
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor import YoutubeIE
    from .compat import compat_urllib_error

    fd = FragmentFD(YoutubeIE(), None, None)
    fd.to_screen = lambda *a: None

    fd.report_retry_fragment(
        compat_urllib_error.HTTPError(
            'http://localhost/', 500, 'Internal Server Error', {}, None),
        10, 11, 22)
    assert fd.report == (
        '[download] Got server HTTP error: 500 Internal Server Error. '
        'Retrying fragment 10 (attempt 11 of 22)...\n')
    fd.report = ''

    fd.report_retry_fragment(Exception('An exception'), 1, 22, 999)

# Generated at 2022-06-24 11:45:26.648064
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from .options import null_option_parser
    from .extractor import gen_extractors
    from .utils import prepend_extension
    from .downloader import FileDownloader
    from .extractor import gen_extractors
    from .utils import prepend_extension
    ydl = FileDownloader(null_option_parser([]).parse_args())

    # 1. test with no skip_fragment
    fd = FragmentFD(ydl, {})
    assert fd.report_skip_fragment(1) == None, 'report_skip_fragment test 1 failed'

    # 2. test with no skip_fragment
    fd = FragmentFD(ydl, {'skip_unavailable_fragments':False})
    assert fd.report

# Generated at 2022-06-24 11:45:32.292818
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    h = InfoExtractor()
    h.to_screen = None
    h.downloader = HttpQuietDownloader(h, {'quiet': True})
    h.downloader.to_screen('supa')
    assert h.downloader.to_screen('supa') is None

# Generated at 2022-06-24 11:45:38.998188
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys

    class FakeYoutubeDL():
        def __init__(self, params):
            self.params = params
            self.filename = None

        def prepare_filename(self, info_dict):
            self.filename = info_dict['url']

    hd = HttpQuietDownloader(
        FakeYoutubeDL({
            'noprogress': True,
            'ratelimit': '2.0',
            'retries': '5',
        }),
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': '4.0',
            'retries': '10',
            'nopart': True,
            'test': True,
        })


# Generated at 2022-06-24 11:45:42.153064
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    fd = HttpQuietDownloader(None, None)
    assert(None == fd.to_screen('a', 'b', 'c', key='value'))

# Generated at 2022-06-24 11:45:45.472686
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args: args
    fd.report_skip_fragment(1)
    assert fd.to_screen.called

# Generated at 2022-06-24 11:45:52.389140
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    class TestYdl:
        def to_screen_nolock(s, *args, **kargs):
            print('to_screen_nolock', args, kargs)
    h = HttpQuietDownloader(TestYdl())
    h.to_screen('asd')

# Generated at 2022-06-24 11:45:59.082616
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader

    class TestFragmentFD(FragmentFD):

        def __init__(self, ydl):
            super(TestFragmentFD, self).__init__(ydl)

            self.skip_frag_reported = False
            self.skip_frag_reported_value = None

        def to_screen(self, msg):
            if msg.startswith('[download] Skipping fragment '):
                self.skip_frag_reported = True
                self.skip_frag_reported_value = msg[len('[download] Skipping fragment '):-3]

    # No frag_index given
    fd = TestFragmentFD(None)
    fd.report_skip_fragment(None)
    assert fd.skip_frag_reported == False

    # Frag_index

# Generated at 2022-06-24 11:46:07.833287
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    assert (
        fd.report_retry_fragment(
            42, 43, 44, 45)
        == '[download] Got server HTTP error: 42. Retrying fragment 43 (attempt 44 of 45)...'
    )
    assert (
        fd.report_retry_fragment(
            u'error', 43, 44, 45)
        == u'[download] Got server HTTP error: error. Retrying fragment 43 (attempt 44 of 45)...'
    )

# Generated at 2022-06-24 11:46:16.133527
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    import tempfile
    from .extractor import gen_extractors

    global _downloader
    _downloader = None
    def downloader_getter():
        global _downloader
        if _downloader is None:
            _downloader = object.__new__(FragmentFD)
            _downloader.params = {}
            _downloader.ydl = object.__new__(YoutubeDL)
            _downloader.ydl.params = {}
            _downloader.to_screen = lambda *x: None
            _downloader.report_warning = lambda *x: None
        return _downloader

    class _YoutubeDL(object):
        def __init__(self, params):
            self.params = params
            self.cache = {}

# Generated at 2022-06-24 11:46:22.452528
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_urllib_request
    from ..extractor import gen_extractors
    ydl = FileDownloader(params={'noprogress': True})
    ctx = {'ydl': ydl}
    request = compat_urllib_request.Request('http://fakedomain/')
    http_dl = HttpQuietDownloader(ydl, ctx)
    http_dl.add_default_headers(request)
    # Check that add_default_headers added an Accept-Charset header
    assert 'Accept-Charset' in request.headers
    # Check that add_default_headers left the Accept-Charset header unchanged
    assert request.headers['Accept-Charset'] == 'utf-8'
    # Check that add_default_headers added a User-Agent header


# Generated at 2022-06-24 11:46:26.319544
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)



# Generated at 2022-06-24 11:46:37.542519
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD
    from .f4m import F4MFD
    from .hds import HDSFD
    from .hls_legacy import HLSLegacyFD
    tests = [
        (FileDownloader,),
        (HttpFD,),
        (DASHFD,),
        (HLSFD,),
        (F4MFD,),
        (HDSFD,),
        (HLSLegacyFD,),
    ]

    for test in tests:
        fd = test[0]()
        fd.to_screen = lambda a: a
        fd.report_skip_fragment(0)

# vim: expandtab

# Generated at 2022-06-24 11:46:45.850590
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FragmentFD_Mock(FragmentFD):
        def __init__(self):
            self.retry_msg = None
        def to_screen(self, msg):
            self.retry_msg = msg
    ydl = FragmentFD_Mock()
    ydl.report_retry_fragment(
        IOError('Connection failed'), fragment_index=12, count=1, retries=3)
    assert ydl.retry_msg == \
        '[download] Got server HTTP error: Connection failed. Retrying fragment 12 (attempt 1 of 3)...'
    ydl.report_retry_fragment(
        OSError('Unsupported protocol'), fragment_index=17, count=2, retries=5)

# Generated at 2022-06-24 11:46:57.497799
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from ..utils import FakeYDL
    ydl = FakeYDL()
    fd = FragmentFD(ydl, {})
    # Skip an invalid fragment, no error is produced
    fd.report_skip_fragment(frag_index=-1)
    # Skip fragment 0, no error is produced
    fd.report_skip_fragment(frag_index=0)
    # Skip the first fragment
    fd.report_skip_fragment(frag_index=1)
    # Skip the second fragment
    fd.report_skip_fragment(frag_index=2)
    # Skip fragment 99
    fd.report_skip_fragment(frag_index=99)

    # Test idempotency of skipped fragment numbers
    # Skip

# Generated at 2022-06-24 11:47:04.290445
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    import sys
    import io
    from .extractor.http import HttpIE
    from .extractor.common import InfoExtractor

    class DummyFragmentFD(FragmentFD, InfoExtractor):
        def __init__(self, ydl):
            self.ydl = ydl
            self.dict = {
                'id': 'dummy',
                'title': 'dummy',
                'formats': [],
                'is_live': False,
            }

    class DummyFileDownloader(FileDownloader):
        def __init__(self, ydl):
            self.ydl = ydl

    class MyHttpIE(HttpIE):
        def __init__(self):
            pass


# Generated at 2022-06-24 11:47:07.006921
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # TODO: Implement unit test for method to_screen (is this unit test correct?)
    pass

# Generated at 2022-06-24 11:47:12.259219
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    test_out = ['[download] Skipping fragment 5...']
    fd.to_screen = lambda *args, **kargs: test_out.append(args)
    fd.report_skip_fragment(5)
    assert test_out[0] == test_out[1]

# Generated at 2022-06-24 11:47:14.455109
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, None)
    assert fd.FD_NAME == 'Fragment'

# Generated at 2022-06-24 11:47:18.928733
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    dl = HttpQuietDownloader(None, {})
    fake_to_screen = lambda *args, **kargs: None
    args = ('a', 'b')
    kargs = {'c': 'd'}
    dl.to_screen = fake_to_screen
    dl.to_screen(*args, **kargs)

# Generated at 2022-06-24 11:47:26.749467
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class DummyYDL:
        def __init__(self):
            self.params = {
                'noprogress': True,
                'ratelimit': 30,
                'retries': 3,
            }

    dl = HttpQuietDownloader(DummyYDL(), {'test': True})
    assert dl.ydl is not None
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert dl.params['ratelimit'] == 30
    assert dl.params['retries'] == 3
    assert dl.params['test']

# Generated at 2022-06-24 11:47:31.980339
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..downloader.common import FileDownloader
    try:
        FileDownloader(
            'youtube-dl',
            {'params': {'quiet': True, 'noprogress': True}}).to_screen('hey')
        assert False, 'Should raise an error'
    except AssertionError:
        pass

# Generated at 2022-06-24 11:47:41.763086
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .downloader.common import FileDownloader
    from .downloader.http import HttpFD
    from .downloader.http import HttpQuietDownloader

    extractor = gen_extractor()
    params = {
        'quiet': True,
        'verbose': False,
    }

    fd = FileDownloader(extractor, params)
    assert not isinstance(fd, HttpFD)

    params['quiet'] = False
    params['verbose'] = True
    fd = FileDownloader(extractor, params)
    assert not isinstance(fd, HttpFD)

    params['quiet'] = False
    params['verbose'] = False
    fd = FileDownloader(extractor, params)
    assert isinstance(fd, HttpFD)

# Generated at 2022-06-24 11:47:50.902516
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # pylint: disable=protected-access

    # Create a HttpQuietDownloader object
    ydl = HttpQuietDownloader(None, None)
    ydl._screen_file = open(os.devnull, 'wb')
    ydl._err_file = open(os.devnull, 'wb')

    # Test if to_screen works
    ydl.to_screen("some message")
    ydl._screen_file.close()
    ydl._err_file.close()


if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:48:00.110569
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # pylint: disable=protected-access
    import sys
    import StringIO
    buf = StringIO.StringIO()
    sys.stdout = buf

    expected_msg = '[download] Got server HTTP error: foo. Retrying fragment 1 (attempt 2 of 2)...'
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_strs = []
        def to_screen(self, *args, **kargs):
            self.to_screen_strs.append(args)

    fd = TestFragmentFD()
    fd.report_retry_fragment(
        err = 'foo',
        frag_index = 1,
        count = 2,
        retries = 2)

    assert fd.to_screen_strs[0][0]

# Generated at 2022-06-24 11:48:06.781111
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .extractor import gen_extractor_classes
    from .youtube import YoutubeIE
    from .generic import GenericIE

    # Prevent warning for Mercurial URL
    for ie in gen_extractor_classes():
        ie.working = True

    def fd(ie, downloader_options={}):
        options = {
            'usenetrc': True,
            'username': 'test',
            'password': 'test',
        }
        options.update(downloader_options)
        ie.extractor = 'test'
        fd = FragmentFD(YoutubeIE(), options)
        fd.add_info_extractor(ie)
        return fd

    FileDownloader(YoutubeIE(), {'quiet': True}).add_info_extractor(GenericIE())
   

# Generated at 2022-06-24 11:48:19.407848
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor import YoutubeIE
    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    ydl = YoutubeIE().ydl
    fd = FragmentFD(ydl=ydl)
    fd.to_screen = lambda *args, **kargs: ' '.join(args)
    err = 'test_err'
    frag_index = 1
    count = 2
    retries = 5
    assert fd.report_retry_fragment(err, frag_index, count, retries) == (
        '[fragment] Got server HTTP error: test_err. Retrying fragment 1 (attempt 2 of 5)...')

# Generated at 2022-06-24 11:48:24.846907
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .dash import DashFD
    from .hls import HlsFD

    # Test instantiation of FragmentFD with supported downloaders
    assert issubclass(FragmentFD, DashFD)
    assert issubclass(FragmentFD, HlsFD)
    dash_fd = FragmentFD(None, {}, None)
    assert isinstance(dash_fd, FragmentFD)
    hls_fd = FragmentFD(None, {}, None)
    assert isinstance(hls_fd, FragmentFD)

# Generated at 2022-06-24 11:48:35.214098
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class YDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen_arr = list()
        def to_screen(self, *args, **kargs):
            self.to_screen_arr.append(args)
    ydl = YDL({})
    dl = HttpQuietDownloader(ydl, ydl.params)
    assert ydl.to_screen_arr == list()
    dl.to_screen('a')
    assert ydl.to_screen_arr == list()
    dl.to_screen('a', 'b')
    assert ydl.to_screen_arr == list()
    dl.to_screen('a', 'b', c='c')
    assert ydl.to_screen_arr == list()

# Generated at 2022-06-24 11:48:43.956506
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import get_info_extractor
    from .downloader.common import FileDownloader
    from .utils import unescapeHTML, unescapeURL

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test_ie'

        def __init__(self, downloader=None):
            self._ies = []
            if downloader:
                self.downloader = downloader
            self._downloader = None

        @property
        def downloader(self):
            if not self._downloader:
                self._downloader = FileDownloader(
                    {}, FakeInfoExtractor({}))
            return self._downloader

        @downloader.setter
        def downloader(self, value):
            self._downloader = value


# Generated at 2022-06-24 11:48:53.329536
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import tempfile
    from .warnings import YTDLLoggingWarning
    from .common import FileDownloader
    from .http import HttpFD
    import warnings

    class FragmentFD_Mockup(FragmentFD):
        def _prepare_frag_download(self, ctx):
            pass

        def _start_frag_download(self, ctx):
            pass

        def _finish_frag_download(self, ctx):
            pass

    filename = tempfile.mktemp(prefix='ytdltest_', suffix='.mp4')

    class MyFileDownloader(FileDownloader):
        def report_warning(self, message, video_id=None):
            warnings.warn(message, YTDLLoggingWarning)

        def temp_name(self, *args, **kargs):
            return filename

# Generated at 2022-06-24 11:49:05.085680
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from youtube_dl.compat import compat_str

    class YoutubeDL:
        def __init__(self, options):
            self.params = options
            self.to_screen(
                '[debug] Options: %s' % json.dumps(self.params, sort_keys=True, indent=2))

        def to_screen(self, s):
            if 'quiet' not in self.params or not self.params['quiet']:
                sys.stdout.write(compat_str(s) + '\n')


# Generated at 2022-06-24 11:49:13.407544
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    hfd = HttpQuietDownloader(None, {})
    saved_stdout = sys.stdout
    try:
        out = sys.stdout = open(os.devnull, 'w')
        hfd.to_screen('test')
        hfd.to_screen(b'test')
        hfd.to_screen(u'test')
    finally:
        sys.stdout.close()
        sys.stdout = saved_stdout

# Generated at 2022-06-24 11:49:22.305951
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    def test_structure(info_dict):
        assert info_dict['_type'] == 'playlist'
        assert info_dict['id'] == '12345'
        assert info_dict['title'] == 'Test'
        assert 'formats' in info_dict
        assert len(info_dict['entries']) > 0

    # get an IE
    ie = get_info_extractor('youtube')
    # fetch an info dict
    info_dict = ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    assert info_dict['_type'] == 'url'

    test_structure(info_dict)

    # get a definition of an extractor

# Generated at 2022-06-24 11:49:31.525718
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FakeYDL
    from .extractor import YoutubeIE
    from .downloader.http import HttpFD

    class FragmentFDTest(FragmentFD):
        def __init__(self, ydl, params):
            super(FragmentFDTest, self).__init__(ydl, params)
            assert isinstance(self.ydl, FakeYDL)

# Generated at 2022-06-24 11:49:33.428113
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        from youtube_dl.YoutubeDL import YoutubeDL
        ydl = YoutubeDL()
        assert HttpQuietDownloader(ydl, {})
    except ImportError:
        pass

# Generated at 2022-06-24 11:49:43.237702
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    def get_output(f):
        import StringIO
        s = StringIO.StringIO()
        f._do_print = s.write
        return s.getvalue()
    import sys
    from .common import FileDownloader
    test_fd = FileDownloader({}, {
        'noprogress': False,
        'quiet': False,
        'verbose': True,
        'outtmpl': 'test%(ext)s',
    })
    def_s = get_output(test_fd)
    q_s = get_output(HttpQuietDownloader(test_fd, {}))
    assert def_s == 'test\n'
    assert q_s == ''
    reload(sys)
    sys.setdefaultencoding('cp1251')
    def_s = get_output(test_fd)

# Generated at 2022-06-24 11:49:49.943383
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fragment_fd = FragmentFD(None)
    assert fragment_fd.report_retry_fragment(
        None, 1, 1, 1) == '\r[download] Got server HTTP error: None. Retrying fragment 1 (attempt 1 of 1)...'
    assert fragment_fd.report_retry_fragment(
        None, 1, 2, 3) == '\r[download] Got server HTTP error: None. Retrying fragment 1 (attempt 2 of 3)...'
    assert fragment_fd.report_retry_fragment(
        'test_error', 2, 3, 5) == '\r[download] Got server HTTP error: test_error. Retrying fragment 2 (attempt 3 of 5)...'

if __name__ == '__main__':
    test_FragmentFD_report_retry_frag

# Generated at 2022-06-24 11:49:54.326882
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    args = ['test1', 'test2']
    kargs = {'end': ''}
    hqd = HttpQuietDownloader(None, None)
    hqd.to_screen(*args, **kargs)
    return True

# Generated at 2022-06-24 11:50:04.078317
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import StringIO
    import httplib
    import urllib

    class _FragmentFD(FragmentFD):
        def to_screen(self, *args, **kargs):
            # Avoid writing test output to stdout
            pass

        @staticmethod
        def report_warning(msg):
            # Avoid writing test output to stdout
            pass

        def download(self, tmpfilename, info_dict):
            return True

    def my_urlopen(req):
        class _MyHTTPResponse(StringIO.StringIO):
            def close(self):
                pass
        return _MyHTTPResponse()

    # Save the default urlopen method
    default_urlopen = urllib.URLopener.open

    # Replace urlopen with our method
    urllib.URLopener.open

# Generated at 2022-06-24 11:50:06.867881
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys

    fd = FragmentFD({}, {})
    _, out = sys.stdout, sys.stdout = sys.__stdout__, sys.stderr

    fd.to_screen('', end='')
    assert sys.stdout.getvalue() == ''

    fd.report_retry_fragment(None, 1, 1, 3)
    assert 'Got server HTTP error' in sys.stdout.getvalue()

    sys.stdout = out

# Generated at 2022-06-24 11:50:16.421097
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from .utils import FakeYDL
    from .extractor import get_info_extractor
    class MyFragmentFD(FragmentFD):
        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params
            class FakeIE(object):
                def __init__(self):
                    self._type = 'fake'
                IE_NAME = 'fake'
            self.ie = FakeIE()
    ydl = FakeYDL()
    myfd = MyFragmentFD(ydl, {})
    assert ydl.msgs == []
    myfd.report_skip_fragment(1)
    assert ydl.msgs == ['[fake] Skipping fragment 1...']


# Generated at 2022-06-24 11:50:28.504338
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractor
    from .downloader.common import FileDownloader
    from .postprocessor.ffmpeg import FFmpegExtractAudioPP
    from .postprocessor.xattrpp import XAttrMetadataPP
    from .postprocessor.embedthumbnail import EmbedThumbnailPP


# Generated at 2022-06-24 11:50:31.244741
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-24 11:50:39.787384
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import youtube_dl
    ydl = youtube_dl.YoutubeDL()
    hqd = HttpQuietDownloader(ydl, {})
    if hasattr(sys, 'gettrace') and not sys.gettrace():
        assert hqd._ydl is ydl
        assert hqd.params == {}
        assert hqd.to_screen == ydl.to_screen
        assert hqd.to_stderr == ydl.to_stderr
        assert hqd.to_console_title == ydl.to_console_title
        assert hqd.report_error == ydl.report_error
        assert hqd.report_warning == ydl.report_warning
        assert hqd.post_progress == ydl.post_progress



# Generated at 2022-06-24 11:50:50.354587
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class DummyFragmentFD(FragmentFD):
        def to_screen(self, *args, **kargs):
            # pylint: disable=attribute-defined-outside-init
            self._to_screen_args = args
            self._to_screen_kargs = kargs

    err = Exception('foobar')
    frag_index = 239
    count = 3
    retries = 8
    fd = DummyFragmentFD()
    fd.report_retry_fragment(err, frag_index, count, retries)
    assert fd._to_screen_args == ()

# Generated at 2022-06-24 11:50:56.433595
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD('dummy', {}, False)
    fd.report_skip_fragment(17)
    assert fd.subprocess_cmd_string_list == [
        'ffmpeg', '-y', '-i', 'invalidurl', '-loglevel', 'quiet',
        '-c', 'copy', 'test.mp4']


# Generated at 2022-06-24 11:51:04.044371
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FakeFragmentFD(FragmentFD):
        def __init__(self):
            self.msgs = []

        def to_screen(self, msg):
            self.msgs.append(msg)

    ffd = FakeFragmentFD()
    ffd.report_retry_fragment(Exception('e'), 1, 2, (3, 4))
    assert ffd.msgs == [
        '[download] Got server HTTP error: e. Retrying fragment 1 (attempt 2 of 3)...'
    ]

# Generated at 2022-06-24 11:51:10.446373
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl_opts = {'ratelimit': 251658240}
    dl = HttpQuietDownloader({}, ydl_opts)
    print ('[%s] Downloader created. Rate limit: %d bytes/s'
           % (HttpQuietDownloader.FD_NAME, dl._opts['ratelimit']))


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:51:20.093277
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen(): # pylint: disable=W0102
    class TestYDL(object):
        def to_screen(self, *args, **kargs):
            TestYDL.to_screen_args = args
            TestYDL.to_screen_kargs = kargs

    ydl = TestYDL()
    dl = HttpQuietDownloader(ydl, {'quiet': False})
    dl.to_screen('This is an example')
    assert TestYDL.to_screen_args == ('This is an example',)
    assert len(TestYDL.to_screen_kargs) == 0

    dl = HttpQuietDownloader(ydl, {'quiet': True})
    dl.to_screen('This is an example 2')

# Generated at 2022-06-24 11:51:27.371428
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from collections import namedtuple
    from .common import FileDownloader
    from .http import HttpFD
    from ..extractor import YoutubeDL
    class TestFragmentFD(FragmentFD):
        def __init__(self, ydl):
            super(TestFragmentFD, self).__init__(ydl)
            self.skip_fragments = []
        def to_screen(self, msg):
            _, msg = msg.split(': ', 1)
            self.skip_fragments.append(int(msg.rsplit(None, 1)[-1]))
        def mark_skip_fragments(self, entries, url_map):
            self.skip_fragments = []
            super(TestFragmentFD, self).mark_skip_fragments(entries, url_map)
            return

# Generated at 2022-06-24 11:51:30.120860
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None)
    assert (fd.report_retry_fragment(RuntimeError('test'), 3, 2, 3)
            == None)


# Generated at 2022-06-24 11:51:35.062117
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    #Initialization
    ydl = HttpQuietDownloader({})
    #Just call the function
    ydl.to_screen(
        '[download] Skipping fragment %d...' % 1,
        '[download] Got server HTTP error: %s. Retrying fragment %d (attempt %d of %s)...'
        % (error_to_compat_str(1), 1, 1, "3")
    )
    #Doesn't return anything

# Generated at 2022-06-24 11:51:44.447360
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = object

    # Test with a message that fits in one line.
    d = HttpQuietDownloader(ydl, {})
    d.to_screen('A short message')

    # Test with a message that is longer than one line.
    d = HttpQuietDownloader(ydl, {})
    d.to_screen('A message of more than eighty characters that will be printed'
                ' in more than one line. This is a very long message.')

    # Test with a message that is longer than one line and longer than one
    # screen.
    d = HttpQuietDownloader(ydl, {})

# Generated at 2022-06-24 11:51:55.770089
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = HttpQuietDownloader({'simulate': True})
    ydl.to_screen(
        '[download] %s of %s at %s ETA %s' % (
            '100.0KiB', '200.0KiB', '100.0KiB/s', '2:00'))
    ydl.to_screen('[download] Destination: %s' % 'file')
    ydl.to_screen('[download] 100% of 200.0KiB in 00:02')
    ydl.to_screen('[download] Destination: %s' % 'file.part')
    ydl.to_screen(
        '[download] %s of %s in %s' % ('100.0KiB', '200.0KiB', '00:02'))
    y

# Generated at 2022-06-24 11:51:59.697052
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from io import BytesIO
    import sys
    out = BytesIO()
    FragmentFD(None, {'outtmpl': '-'}).to_screen = lambda *args: out.write(' '.join(args) + '\n')
    FragmentFD(None, {'outtmpl': '-'}).report_skip_fragment(5)
    assert out.getvalue() == b'[download] Skipping fragment 5...\n'
    del sys.modules['__main__']



# Generated at 2022-06-24 11:52:05.864651
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class DummyYDL:
        def __init__(self):
            self.params = {}
        def to_screen(self, *args, **kargs):
            self.screen_message = args[0]
    dl = HttpQuietDownloader(DummyYDL())
    dl.to_screen('test')
    assert dl.ydl.screen_message == 'test'

# Generated at 2022-06-24 11:52:16.543900
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpQuietDownloader
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from .extractor import gen_extractors
    from ..compat import compat_os_name
    class MockYDL(object):
        def __init__(self):
            self.params = {}

    class MockInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {}

    ydl = MockYDL()
    vd = MockInfoExtractor(ydl)
    vd.add_default_info_extractors()
    gen_extractors()
    fd = FragmentFD(ydl, {'skip_download':True})
    fd.params['verbose'] = False

# Generated at 2022-06-24 11:52:24.159268
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .converter import Converter
    from .extractor import YoutubeIE
    from .plsplaylist import PLSPlaylistIE
    from .common import FileDownloader
    from .subtitles import SubtitlesInfoExtractor

    assert issubclass(FragmentFD, FileDownloader)
    assert FragmentFD.__name__ == 'FragmentFD'
    assert FragmentFD.FD_NAME == 'fragment'
    assert FragmentFD.lambda_equals('a', 'b') == 'a==b'
    assert FragmentFD.lambda_not_equals('a', 'b') == 'a!=b'
    assert FragmentFD.lambda_gt('a', 'b') == 'a>b'
    assert FragmentFD.lambda_gte('a', 'b') == 'a>=b'
   