

# Generated at 2022-06-24 11:42:24.617631
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .dash import DashFD
    from .hls import HlsFD
    from .hlsnative import HlsFD as HlsnativeFD

    for test_fd_class in (DashFD, HlsFD, HlsnativeFD):
        fd = test_fd_class(None, {}, None)
        assert isinstance(fd, FragmentFD)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:42:30.648222
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import pytest

    from youtube_dl.YoutubeDL import YoutubeDL


    ydl = YoutubeDL({"quiet": True})
    # This should stop the error being printed to stderr
    HttpQuietDownloader(ydl, {})

    ydl = YoutubeDL({"quiet": False})
    with pytest.raises(TypeError):
        HttpQuietDownloader(ydl, {})

# Generated at 2022-06-24 11:42:39.295736
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .test_utils import FakeYDL
    from .options import Options
    from .extractor.common import InfoExtractor
    fydl = FakeYDL()
    ie = InfoExtractor('test', Options())
    ie.add_info_extractor(FragmentFD)
    fydl._ies = [ie]
    fydl.params['skip_unavailable_fragments'] = True
    fydl.params['quiet'] = True
    fydl.params['dumpjson'] = True
    fydl.params['noprogress'] = True
    fydl.params['simulate'] = True
    fydl.add_info_extractor(None)

    # Test if the method report_skip_fragment is called correctly
    # The method checks if the report_skip_fragment is called with

# Generated at 2022-06-24 11:42:43.568802
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    ydl = HttpQuietDownloader({}, {'quiet': True})
    fd = FragmentFD(ydl, {})
    fd.to_screen = lambda *args, **kargs: args
    assert (
        fd.report_retry_fragment(KeyboardInterrupt(), 11, 1, 1) ==
        (('[download] Got server HTTP error: KeyboardInterrupt. '
          'Retrying fragment 11 (attempt 1 of 1)...',), {}))

# Generated at 2022-06-24 11:42:49.474308
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import YoutubeIE
    ydl = YoutubeIE(params={'noplaylist': True})
    ydl.add_info_extractor(YoutubeIE.ie_key())
    dow = HttpQuietDownloader(ydl, {'quiet': True})
    # Avoid terminal dependent output formatting
    dow.to_screen('hello %s', 'downloader') == None

# Generated at 2022-06-24 11:42:56.813529
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .tests.test_file_downloader import FakeYDL
    ydl = FakeYDL()
    fd = FragmentFD(ydl=ydl, params={})
    fd.to_screen = lambda *x, **y: len(x)
    assert 3 == fd.report_retry_fragment(
        err=NotImplementedError('howdy'), frag_index=5, count=1, retries=10)
    ydl.to_stderr.assert_called_with(
        '[download] Got server HTTP error: howdy. Retrying fragment 5 (attempt 1 of 10)...')


# Generated at 2022-06-24 11:43:09.044445
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {'params': {'verbose': False}}
    params = {'continuedl': True,
              'quiet': True,
              'noprogress': True,
              'nopart': True,
              'test': True}
    dl = HttpQuietDownloader(ydl, params)
    assert dl._opener.addheaders == [('User-Agent', 'Mozilla/5.0')]
    assert type(dl.params) == dict
    assert dl.params['continuedl'] == True
    assert dl.params['quiet'] == True
    assert dl.params['verbose'] == False
    assert dl.params['noprogress'] == True
    assert dl.params['retries'] == 10
    assert dl.params['nopart'] == True
   

# Generated at 2022-06-24 11:43:14.865807
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from unittest import mock
    from .common import FileDownloader
    from .http import HttpFD
    from ..utils import compat_urllib_error

    class TestFD(FragmentFD, HttpFD):
        pass

    TestFD.FD_NAME = 'test'

    test_fd = TestFD(mock.MagicMock(), {})
    test_fd.format_retries = FileDownloader.format_retries

    err = compat_urllib_error.URLError(compat_urllib_error.URLError('test'))
    test_fd.report_retry_fragment(err, 0, 1, 99)

# Generated at 2022-06-24 11:43:17.716688
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert hasattr(FragmentFD, 'report_retry_fragment')
    assert hasattr(FragmentFD, 'report_skip_fragment')

# Generated at 2022-06-24 11:43:27.199408
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFD(FragmentFD):
        def __init__(self):
            self.to_screen_arr = []
        def to_screen(self, *args, **kargs):
            self.to_screen_arr.append((args, kargs))
    error = ValueError()
    test_obj = TestFD()
    test_obj.report_retry_fragment(error, 1, 2, 3)
    assert test_obj.to_screen_arr[-1] == (
        ('[download] Got server HTTP error: %s. Retrying fragment 1 (attempt 2 of 3)...' %
            error_to_compat_str(error),), {})

# Generated at 2022-06-24 11:43:29.037379
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = {}
    dl = HttpQuietDownloader(ydl, {})
    assert dl.to_screen('Hello world!') == None

# Generated at 2022-06-24 11:43:33.264935
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpDownloader

    hd = HttpQuietDownloader(None, {'a': 'b'})
    assert isinstance(hd, HttpDownloader)
    assert hd.params == {'a': 'b', 'quiet': True, 'noprogress': True}

# Generated at 2022-06-24 11:43:41.342516
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    assert FragmentFD._report_retry_fragment(
        FragmentFD(),
        None,
        10,
        3,
        5,
    ) == '[download] Got server HTTP error: None. Retrying fragment 10 (attempt 3 of 5)...'
    assert FragmentFD._report_retry_fragment(
        FragmentFD(),
        'test_error',
        20,
        2,
        1,
    ) == '[download] Got server HTTP error: test_error. Retrying fragment 20 (attempt 2 of 1)...'
    assert FragmentFD._report_retry_fragment(
        FragmentFD(),
        'test_error',
        100,
        1,
        0,
    ) == '[download] Got server HTTP error: test_error. Retrying fragment 100...'

# Generated at 2022-06-24 11:43:42.343671
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-24 11:43:51.319469
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .utils import unified_strdate

    class DummyYoutubeIE(YoutubeIE):
        def _real_initialize(self):
            self._downloader.params.update({
                'username': 'test',
                'password': 'testpassword',
            })


# Generated at 2022-06-24 11:43:59.263595
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: [args]
    assert fd.report_retry_fragment(
        'http error', 5, 11, -1) == [
            ('[download] Got server HTTP error: http error. Retrying fragment 5 (attempt 11 of Unlimited)...',)]
    assert fd.report_retry_fragment(
        'http error', 5, 11, 5) == [
            ('[download] Got server HTTP error: http error. Retrying fragment 5 (attempt 11 of 5)...',)]


# Generated at 2022-06-24 11:44:11.406637
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from argparse import ArgumentParser
    from contextlib import closing
    from tempfile import NamedTemporaryFile
    from .options import opts

    parser = ArgumentParser()
    HttpQuietDownloader.add_options(parser)
    opts.add_option(parser)
    opts.read_configuration_file()
    opts.parse_arguments(['--no-cache-dir'])

    with closing(NamedTemporaryFile(mode='w+b')) as t:
        t.write(b'hello')
        t.flush()
        t.seek(0)


# Generated at 2022-06-24 11:44:20.195206
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MockFD(FragmentFD):
        def __init__(self, *args, **kargs):
            super(MockFD, self).__init__(*args, **kargs)
            self.ctx.update({
                'filename': 'filename',
                'total_frags': 1,
            })

    fd = MockFD(None)
    fd._prepare_frag_download(fd.ctx)
    assert fd.ctx['dest_stream'] is not None
    assert fd.ctx['tmpfilename'] == 'filename'
    fd.ctx['dest_stream'].close()
    os.remove('filename')
    os.remove(fd.ytdl_filename(fd.ctx['filename']))


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:44:29.605097
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import io
    ydl = {}
    fd = FragmentFD(ydl, {})
    output = io.BytesIO()
    fd.to_screen = lambda *args, **kargs: output.write(b' '.join(args))
    try:
        fd.report_retry_fragment(123, 1, 4, 5)
        assert output.getvalue() == b'[download] Got server HTTP error: 123. Retrying fragment 1 (attempt 4 of 5)...\n'
    except AssertionError:
        sys.stderr.write(output.getvalue().decode('utf-8', 'ignore'))
        raise

# Generated at 2022-06-24 11:44:30.391030
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass


# Generated at 2022-06-24 11:44:41.890985
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import unittest
    import json
    from copy import copy

    class MockYDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen_calls = []
            self.report_warning_calls = []
            self.report_destination_calls = []

        def to_screen(self, text):
            self.to_screen_calls.append(text)

        def report_warning(self, text):
            self.report_warning_calls.append(text)

        def report_destination(self, filename):
            self.report_destination_calls.append(filename)


# Generated at 2022-06-24 11:44:44.170105
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .tests import ydl

    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    fd = FragmentFD(ydl)

# Generated at 2022-06-24 11:44:56.518810
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    try:
        from unittest import mock
    except ImportError:
        import mock
    from io import StringIO
    from collections import namedtuple

    fixture_err = type('Error', (), {})

    class FragmentFDTest(FragmentFD):
        def format_retries(self, count):
            return '???'

        def to_screen(self, msg, skip_eol=False):
            self.to_screen_output = msg

    FragmentFDTest.to_screen = mock.Mock()

    # Check that method works as expected when called with all expected arguments
    FragmentFDTest.report_retry_fragment(
        FragmentFDTest(), fixture_err, 1, 2, 3)

# Generated at 2022-06-24 11:45:00.067198
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpQuietDownloader
    from .common import FileDownloader
    class TestFD(FileDownloader):
        def to_screen(self, _):
            self.to_screen_count += 1
    ytdl = TestFD(params={})
    ytdl.to_screen_count = 0
    HttpQuietDownloader(ytdl, {}).to_screen('hello')
    assert ytdl.to_screen_count == 0

# Generated at 2022-06-24 11:45:07.023312
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class Dummy(FragmentFD):
        def __init__(self):
            self.screen_file = []
        def to_screen(self, *args, **kargs):
            self.screen_file.append(args[0] % args[1:])
    fd = Dummy()
    fd.report_retry_fragment(Exception('message'), 2, 5, {'maxretries': 10})
    assert fd.screen_file[0] == 'Got server HTTP error: message. Retrying fragment 2 (attempt 5 of 10)...'


# Generated at 2022-06-24 11:45:18.558489
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    assert (
        fd.report_retry_fragment(
            None, 1, 2, (None, None)) ==
        '[download] Got server HTTP error: None. Retrying fragment 1 (attempt 2 of 1)...'
    )
    assert (
        fd.report_retry_fragment(
            None, 1, 1, (10, 10)) ==
        '[download] Got server HTTP error: None. Retrying fragment 1 (attempt 1 of 10)...'
    )
    assert (
        fd.report_retry_fragment(
            None, 1, 10, (10, 10)) ==
        '[download] Got server HTTP error: None. Retrying fragment 1 (attempt 10 of 10)...'
    )

# Generated at 2022-06-24 11:45:27.312035
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class _FragmentFD(FragmentFD):
        def __init__(self):
            self.ydl = None
            self.params = {'format': 'best[height<=?1080][fps<=60][vcodec!=?vp9]/bestvideo[height<=?1080][fps<=60]+bestaudio/best'}

    fragf = _FragmentFD()
    assert fragf
    assert fragf.params == {'format': 'best[height<=?1080][fps<=60][vcodec!=?vp9]/bestvideo[height<=?1080][fps<=60]+bestaudio/best'}
    assert fragf.FD_NAME == 'test_FragmentFD'


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:45:34.362649
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestDownloader(HttpQuietDownloader):
        def __init__(self):
            self.msg = ''
        def to_screen(self, msg):
            self.msg = msg

    downloader = TestDownloader()
    downloader.to_screen('test_msg')
    assert downloader.msg == '', 'HttpQuietDownloader must suppress message to the screen'

# Generated at 2022-06-24 11:45:35.017773
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-24 11:45:46.110563
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import random
    import string
    tmp_dir = u'\u2026'

    def test_dir_fd(fd):
        assert hasattr(fd, '_prepare_frag_download') and hasattr(fd, '_start_frag_download') and hasattr(fd, '_download_fragment') and hasattr(fd, '_append_fragment')
        assert fd.params.get('noprogress', False) == True
        assert fd.params.get('retries', 0) == 10
        assert fd.params.get('nopart', False) == False
        assert fd.params.get('buffersize', None) == None
        assert fd.params.get('ratelimit', None) == None
        assert fd.params.get('test', False) == True
       

# Generated at 2022-06-24 11:45:49.165341
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = HttpQuietDownloader(None, None)
    ydl.to_screen('testing')
    ydl.to_screen('testing %s %d', '(1,2)', {'x': 1})

# Generated at 2022-06-24 11:45:52.389404
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    global fd
    fd = FragmentFD({})

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:46:02.150826
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import io

    class MockYoutubeDL(object):
        def to_screen(self, *args, **kargs):
            print(*args, file=sys.stderr)

    class MockInfoDict(object):
        pass

    quiet_dl = HttpQuietDownloader(
        MockYoutubeDL(),
        {},
    )

    info_dict = MockInfoDict()
    info_dict.url = 'http://example.com/video.mp4'

    orig_stderr = sys.stderr
    try:
        sys.stderr = io.BytesIO()
        quiet_dl.report_destination(info_dict)
        assert False
    except AttributeError:
        pass
    finally:
        sys.stderr = orig_stderr

    tmp_filename

# Generated at 2022-06-24 11:46:05.798889
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FakeYDL:
        def to_screen(self, s):
            assert s == '[download] Skipping fragment 1...'
    class FakeFD:
        ydl = FakeYDL()
    frag = FragmentFD(FakeFD(), {'noprogress': True})
    frag.report_skip_fragment(1)

# Generated at 2022-06-24 11:46:10.383999
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    ydl = MockYDL()
    fd = FragmentFD(ydl, {'skip_unavailable_fragments': True})
    fd.report_skip_fragment(1)
    assert ydl.msgs == ['[download] Skipping fragment 1...']


# Generated at 2022-06-24 11:46:23.130965
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from io import BytesIO
    from functools import partial

    class FragmentFD_test(FragmentFD):
        def __init__(self):
            self.to_screen = BytesIO()
            self.format_retries = partial(FragmentFD.format_retries, self)

    fd = FragmentFD_test()
    fd.report_retry_fragment(
        'HTTP Error 403: Forbidden', 12, 3, {
            2: '2 retries',
            4: '4 retries',
            10: '10 retries',
        })
    assert (
        'Got server HTTP error: HTTP Error 403: Forbidden. '
        'Retrying fragment 12 (attempt 3 of 4 retries)...'
    ) == fd.to_screen.getvalue().decode('utf-8')
   

# Generated at 2022-06-24 11:46:34.372478
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class MyFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_list = []
        def to_screen(self, s):
            self.to_screen_list.append(s)

    fd = MyFragmentFD()
    fd.report_retry_fragment(IOError("error 1"), 2, 3, 4)
    assert len(fd.to_screen_list) == 1
    assert fd.to_screen_list[0] == ("[download] Got server HTTP error: error 1."
                                    " Retrying fragment 2 (attempt 3 of 4)...")

# Generated at 2022-06-24 11:46:41.586476
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # Prepare test environment
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: None    # Intercept to_screen method
    class FakeErr(Exception): pass
    err = FakeErr('Fake error message')
    err.code = 42
    frag_index = 666
    count = 1
    retries = 5

    # Call tested method
    fd.report_retry_fragment(err, frag_index, count, retries)

    # Check result
    assert fd.to_screen.called is False


# Generated at 2022-06-24 11:46:51.725929
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        def __init__(self, ydl):
            super(TestFD, self).__init__(ydl)
            self.FD_NAME = 'test'
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'outtmpl': '-'})
    ydl.add_info_extractor(TestFD(ydl))
    ydl._ies = [TestFD(ydl)]
    ydl._ies_instances = {TestFD(ydl): TestFD(ydl)}
    ydl._ies_instances[TestFD(ydl)] = TestFD(ydl)
    ydl._ies[0] = TestFD(ydl)
    return ydl

# Generated at 2022-06-24 11:46:54.697772
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpFD(None, {'noprogress': True})
    assert dl.params['progress_hooks']

    dl = HttpQuietDownloader(None, {'noprogress': True})
    assert dl.params['progress_hooks'] == []

# Generated at 2022-06-24 11:46:55.591381
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass



# Generated at 2022-06-24 11:46:59.711360
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors, list_extractors
    from ..extractor.common import InfoExtractor

    for ie in gen_extractors():
        if not isinstance(ie, InfoExtractor) or ie.IE_NAME == 'generic':
            continue
        fd = FragmentFD(ie, {})

# Generated at 2022-06-24 11:47:03.065542
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import test_utils
    sys.stderr = test_utils.LoggingIntercept('stderr')
    FragmentFD().report_skip_fragment(3)
    return sys.stderr.got == '[download] Skipping fragment 3...\n'

# Generated at 2022-06-24 11:47:05.973611
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:47:17.515241
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .http import HttpFD

    class FakeFD(FileDownloader, FragmentFD, HttpFD):
        pass

    # it is not easy to expose _screen_file
    # so we just asserts on sys.stdout.write
    import sys
    old = sys.stdout

    class MyStringIO(object):

        def __init__(self):
            self.s = u''

        def write(self, unicode_text):
            self.s += unicode_text

    sys.stdout = MyStringIO()

    fd = FakeFD(dict(params=dict()))
    fd.report_retry_fragment(Exception('my error'), 1, 3, 3)

# Generated at 2022-06-24 11:47:26.599442
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from time import time
    from io import StringIO
    fd = FragmentFD({}, StringIO(), StringIO())
    fd._start_time = start_time = time()
    fd.to_screen = lambda *args, **kargs: None
    fd.report_skip_fragment(1)
    assert fd._total_bytes_estimate is None
    assert fd._start_time == start_time
    assert fd._elapsed() >= 0
    assert fd._hooks == {}
    assert fd._downloaded_bytes == 0
    assert fd._total_bytes == 0
    assert fd._filename == None
    assert fd._status == 'downloading'

# Generated at 2022-06-24 11:47:38.831822
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors

    # The constructor may not raise any exception
    ydl = lambda *args, **kwargs: None
    HttpQuietDownloader(ydl, {'noprogress': True, 'logger': ydl})

    # Create a test extractor for testing downloader options
    class TestIE(object):
        IE_NAME = 'Test'
        def __init__(self, downloader=None):
            self.params = downloader.params if downloader else {}
    gen_extractors({TestIE.IE_NAME: TestIE})

    class FakeYDL:
        def __init__(self, result):
            self.result = result
        def extract_info(self, *args, **kwargs):
            return self.result

    # Test that downloader options are propagated to

# Generated at 2022-06-24 11:47:40.329070
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Should not print anything
    HttpQuietDownloader(None, {}).to_screen('hello world')

# Generated at 2022-06-24 11:47:47.190341
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # disable output
    import sys
    orig_stderr = sys.stderr
    sys.stderr = open(os.devnull, 'w')

    try:
        import youtube_dl
        ydl = youtube_dl.YoutubeDL({})
        assert 'quiet' in HttpQuietDownloader(ydl, {}).params
    finally:
        sys.stderr = orig_stderr

# Generated at 2022-06-24 11:47:50.724810
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class DummyYoutubeDL(object):
        def to_screen(self, *args, **kargs):
            pass
    dl = HttpQuietDownloader(DummyYoutubeDL(), {})
    dl.to_screen('Test')

# Generated at 2022-06-24 11:47:55.967762
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, None, {})
    assert fd.FD_NAME == 'generic'
    assert fd.RETRIES == 3
    assert fd.SKIP_UNKNOWN_FRAGMENTS is False
    assert fd.TEMPLATE_URL == '%s'


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:47:58.583570
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD({})
    assert fd.downloader.params.get('fragment_retries') == 10
    assert fd.downloader.params.get('skip_unavailable_fragments')

# Generated at 2022-06-24 11:48:06.717328
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .downloader.http import HttpQuietDownloader
    from .utils import parse_filesize
    from .compat import bytes_to_str


# Generated at 2022-06-24 11:48:10.989289
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class UnitTestHttpQuietDownloader(HttpQuietDownloader):
        def real_download(self, filename, info_dict):
            return True

    dl = UnitTestHttpQuietDownloader(None, None)
    assert dl.to_screen('test') == None

# Generated at 2022-06-24 11:48:23.039902
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import tempfile
    import shutil
    import random
    import difflib

    def random_string(length):
        return ''.join(random.choice('0123456789AaBbCc') for i in range(length))

    root_dir = tempfile.mkdtemp()
    sys.path.insert(1, root_dir)

# Generated at 2022-06-24 11:48:26.282009
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    hqd = HttpQuietDownloader(None, {'continuedl': True, 'quiet': True, 'noprogress': True})
    assert not hqd.params['quiet']
    assert not hqd.params['noprogress']



# Generated at 2022-06-24 11:48:36.813809
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import get_info_extractor
    class YtdlHttpRequestHandler:
        def __init__(self, params):
            self.params = params
        def add_progress_hook(self, hook):
            pass
        def download(self, filename, info_dict):
            return False

    ydl = get_info_extractor('dummy')
    ydl._params = dict()
    ydl.http_request_handler = YtdlHttpRequestHandler
    dl = HttpQuietDownloader(ydl, dict(noprogress=True))
    assert not dl.params.get('quiet')
    assert not dl.params.get('noprogress')

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:48:47.258867
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        FD_NAME = 'foo'
        def temp_name(self, filename):
            return filename + '.tmp'
        def ytdl_filename(self, filename):
            return filename + '.ytdl'

    # Sanity tests for _read_ytdl_file and _write_ytdl_file
    def read_write_test(ytdl_file_content, expected_fragment_index):
        fd = MyFragmentFD(None)
        ctx = {
            'filename': '__UNIT_TEST_FILE__',
        }

        if ytdl_file_content is not None:
            stream, _ = sanitize_open(fd.ytdl_filename(ctx['filename']), 'w')

# Generated at 2022-06-24 11:48:52.193946
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    h = HttpQuietDownloader(ydl, {'quiet': True})
    assert h is not None
    assert ydl.params['quiet']

# Generated at 2022-06-24 11:49:03.040072
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    def noop(*args, **kargs):
        pass

    # Mock class YDL
    class YDL(object):
        def __init__(self):
            self.params = {}
            self.to_screen = noop

    hqd = HttpQuietDownloader(YDL(), {
        'continuedl': True,
        'quiet': False,
        'noprogress': True,
        'ratelimit': None,
        'nopart': False,
        'test': False,
    })

    assert hqd.params['continuedl']
    assert not hqd.params['quiet']
    assert hqd.params['noprogress']
    assert hqd.params['ratelimit'] is None
    assert not hqd.params['nopart']
    assert not hqd

# Generated at 2022-06-24 11:49:06.695159
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor.common import YoutubeIE
    fd = FragmentFD(YoutubeIE(), {})
    fd.report_retry_fragment(Exception('a'), 5, 3, 10)


# Generated at 2022-06-24 11:49:18.173078
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from ..utils import encode_compat_str, encode_data_uri

    fd = FragmentFD({})

    fd.to_screen = lambda s: test_FragmentFD_report_retry_fragment.output.append(encode_compat_str(s))
    test_FragmentFD_report_retry_fragment.output = []

    fd.report_retry_fragment(RuntimeError('Cannot connect'), 2, 1, 2)

    assert test_FragmentFD_report_retry_fragment.output == [
        encode_data_uri(
            '[download] Got server HTTP error: <urlopen error Cannot connect>. Retrying fragment 2 (attempt 1 of 2)...',
            'ascii')
    ]


# Generated at 2022-06-24 11:49:26.850171
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import StringIO
    fakeout, fakeerr = StringIO.StringIO(), StringIO.StringIO()
    dl = HttpQuietDownloader(None, {})
    dl.to_screen('error', file=fakeerr)
    dl.to_screen('warning', file=fakeerr)
    dl.to_screen('normal', file=fakeout)
    assert fakeerr.getvalue() == ''
    assert fakeout.getvalue().strip() == 'normal'

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:49:30.673403
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    dl = HttpQuietDownloader(None, {})
    class FakeScreen:
        def write(self, s):
            assert False
    dl.to_screen('foo', bar='baz', _screen=FakeScreen())

# Generated at 2022-06-24 11:49:41.312913
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD('', {}, {})
    fd.to_screen = lambda *args, **kwargs: args
    assert fd.report_retry_fragment(Exception('Test error message'), 3, 2, 3) == (
        '[download] Got server HTTP error: Test error message. '
        'Retrying fragment 3 (attempt 2 of 3)...',
    )
    assert fd.report_retry_fragment(Exception('Test error message'), 3, 2, 2) == (
        '[download] Got server HTTP error: Test error message. '
        'Retrying fragment 3 (attempt 2 of 2)...',
    )

# Generated at 2022-06-24 11:49:43.497625
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    return FragmentFD(None, {'logger': None}) \
        .report_retry_fragment(Exception('foo'), 'frag', 'count', 'retries') == None

# Generated at 2022-06-24 11:49:52.177412
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import get_info_extractor
    from .downloader import gen_extractors
    gen_extractors()
    ie = get_info_extractor('generic')
    ydl = ie.get_ydl('http://example.com/video.mp4', 'mp4')
    fd = HttpQuietDownloader(ydl, {'quiet': False, 'noprogress': True})
    fd.to_screen('test')

# Generated at 2022-06-24 11:49:57.334315
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class FakeYDL(object):
        class FakeParams(object):
            pass

        params = FakeParams()

    qd = HttpQuietDownloader(FakeYDL(), {})
    assert qd.ydl is FakeYDL
    assert qd.params == FakeYDL.params



# Generated at 2022-06-24 11:50:04.257872
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import StringIO
    fd = FragmentFD(None, {'params': {}})
    fd.to_screen = sys.stdout.write
    fd.report_skip_fragment(42)
    # Test if the to_screen was called properly
    stdout = sys.stdout.getvalue().strip()
    sys.stdout = StringIO.StringIO()
    assert stdout == '[download] Skipping fragment 42...'
    fd.to_screen = None
    # Test if queue doesn't clog if to_screen is None
    fd.report_skip_fragment(42)
    assert True

# Generated at 2022-06-24 11:50:11.165400
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({
        'format': 'mp4',
        'noprogress': True,
    }, {
        'status': True,
    })
    fd.to_screen = lambda *args, **kargs: print(args)
    fd.report_retry_fragment(ValueError('gotcha'), 3, 5, 10)
    fd.report_retry_fragment(ValueError('gotcha'), 10, 10, 10)
    # TODO: check assertions

# Generated at 2022-06-24 11:50:11.797033
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass

# Generated at 2022-06-24 11:50:20.160061
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys

    fd = FragmentFD()
    fd.to_screen = lambda x: sys.stdout.write(x + '\n')

    fd.report_retry_fragment('somestr', 42, 1, 1)
    fd.report_retry_fragment('somestr', 42, 2, 2)
    fd.report_retry_fragment('somestr', 42, 3, 5)
    fd.report_retry_fragment('somestr', 42, 5, 5)

# Generated at 2022-06-24 11:50:23.902951
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    'Make sure that HttpQuietDownloader sets continuedl and quiet parameters'
    from .http import HttpFD
    dl = HttpQuietDownloader(None, {})
    assert dl.params['continuedl']
    assert dl.params['quiet']
    assert isinstance(dl, HttpFD)

# Generated at 2022-06-24 11:50:28.614724
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None)
    assert fd.params['fragment_retries'] is 10
    assert fd.params['keep_fragments'] is False

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:50:36.945112
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    s = []

    class HttpQuietDownloader(object):
        def to_screen(self, *args, **kargs):
            s.extend(args)

    hqd = HttpQuietDownloader()

    hqd.to_screen('a')
    assert s == []

    hqd.to_screen('b', 'c')
    assert s == []

    hqd.to_screen('d', 'e', 123)
    assert s == []


if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:50:44.588808
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert FileDownloader is not FragmentFD
    assert FileDownloader(None, None).__class__ is FileDownloader
    assert FragmentFD(None, None).__class__ is FragmentFD
    assert FragmentFD is FragmentFD(None, None).__class__
    assert isinstance(FragmentFD(None, None), FileDownloader)


# vim: expandtab sw=4 ts=4

# Generated at 2022-06-24 11:50:48.215436
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    downloader = FragmentFD(None, None)
    downloader.to_screen = lambda x: x
    assert 'Skipping fragment 1...' == downloader.report_skip_fragment(1)



# Generated at 2022-06-24 11:50:56.949663
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    def test_retry_message(num_retries, err):
        fd = FragmentFD()

        fd.to_screen = lambda *args: None
        fd.format_retries = lambda retries: retries
        fd.report_retry_fragment(err, 1, num_retries, retries=3)

        messages = fd.to_screen.calls
        assert len(messages) == 1
        assert messages[0] == ['[download] Got server HTTP error: %s. Retrying fragment 1 (attempt %d of 3)...' % (err, num_retries)]

        fd.to_screen.reset_mock()

    test_retry_message(1, '')
    test_retry_message(2, 'some error')

# Generated at 2022-06-24 11:51:03.750603
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .fakefactory import FakeYDL
    ffd = FragmentFD(FakeYDL())
    retries = (1, 2, 3)
    err = Exception('foo')
    ffd.report_retry_fragment(err, 2, 1, retries)
    assert FakeYDL.msgs == ['[download] Got server HTTP error: foo. Retrying fragment 2 (attempt 1 of 1, 2, 3)...']

# Generated at 2022-06-24 11:51:14.543602
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        FD_NAME = 'testname'

        def __init__(self, ydl):
            FragmentFD.__init__(self, ydl)
            self.retries = 0

        def _make_frag_retry_ctx(self):
            return {
                'frag_index': self._get_frag_index(),
                'count': self.retries,
                'retries': self.retries,
            }

        def format_retries(self, retries):
            return str(retries)

        def _get_frag_index(self):
            return 1

        def report_retry_fragment(self, error, frag_retry_ctx):
            assert frag_retry_ctx['count'] == self.retries
            Fragment

# Generated at 2022-06-24 11:51:15.917041
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    assert FragmentFD(None, {}).report_skip_fragment(0) == None

# Generated at 2022-06-24 11:51:22.439465
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestYDL(object):
        verbose = False
    ydl = TestYDL()
    dl = HttpQuietDownloader(
        ydl,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': None,
            'nopart': False,
            'test': False,
        }
    )
    assert dl.to_screen() is None

# Generated at 2022-06-24 11:51:24.904144
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader(None, {'noprogress': True})


# Generated at 2022-06-24 11:51:34.963832
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import get_info_extractor
    from ..utils import LocationSeparatorDetector

    # To be sure that we don't have any configuration file
    youtube_dl.params.update(dict(
        verbose=True,
        no_config_file=True,
        no_color=True,
        simulated=True,
    ))

    assert youtube_dl.params['skip_download']
    youtube_dl.params['skip_download'] = False

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'

    ie = FakeInfoExtractor()
    ie.extractor = get_info_extractor(ie.IE_NAME)

    url = 'http://example.com'
    ie.extractor._WORKING = True
    loc_sep_det

# Generated at 2022-06-24 11:51:36.567031
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(None, {'test': 1})

# Generated at 2022-06-24 11:51:41.578699
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({})
    err = Exception('Fatal error')
    fd.report_retry_fragment(err, 0, 0, 1)
    return fd.ydl.report_warnings()[0] == 'Got server HTTP error: %s. Retrying fragment 0 (attempt 0 of 1)...' % error_to_compat_str(err)


# Generated at 2022-06-24 11:51:42.343735
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    return FragmentFD('https://youtube.com/videoid')

# Generated at 2022-06-24 11:51:51.208307
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..compat import compat_str
    from ..utils import DateRange

    # Create a dummy FileDownloader object
    downloader = FragmentFD()
    downloader.params = {}
    downloader.ydl = object()
    downloader.to_screen = lambda *x: compat_str(x[0])

    # Test with a custom error message
    assert (downloader.report_retry_fragment(
        'http error 404', 99, 3, 2) ==
        '[download] Got server HTTP error: http error 404. '
        'Retrying fragment 99 (attempt 3 of 2)...')
    # Test with a compat_HTTPError object

# Generated at 2022-06-24 11:51:54.416420
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    fd = FragmentFD({}, {'logger': sys.stdout}, {})
    fd.report_retry_fragment(ValueError('abc'), 23, 3, (1, 2, 3))

# Generated at 2022-06-24 11:51:58.361912
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {'outtmpl': '-'})
    fd.to_screen = lambda *args, **kargs: None
    fd.report_skip_fragment(10)
    fd.report_skip_fragment(1024)


# Generated at 2022-06-24 11:52:03.841075
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import StringIO

    class FakeYDL:
        def trouble(self, msg, tb=None):
            raise RuntimeError(msg)

    out_stream = StringIO.StringIO()
    err_stream = StringIO.StringIO()

# Generated at 2022-06-24 11:52:06.343919
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:52:13.456502
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # These values are arbitrary and only used for testing
    ydl = object()
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': '10K',
        'retries': 5,
        'nopart': False,
        'test': True,
    }
    http_dl = HttpQuietDownloader(ydl, params)

    assert http_dl.ydl is ydl
    assert http_dl.params == params

# Generated at 2022-06-24 11:52:16.868539
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # test that the to_screen of HttpQuietDownloader does not print anything
    httpQuiet = HttpQuietDownloader({}, {})
    httpQuiet.to_screen('[download] %s' % 'test')
    return

# Generated at 2022-06-24 11:52:20.593207
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda x: x
    assert fd.report_skip_fragment(1) == '[download] Skipping fragment 1...'
    assert fd.report_skip_fragment(-1) == '[download] Skipping fragment -1...'