

# Generated at 2022-06-24 11:42:28.271588
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .utils import TestFD
    err = Exception('error message')
    fd = TestFD({'retries': 3})

    fd.report_retry_fragment(err, 1, 1, 3)
    assert fd.msgs == [
        '[download] Got server HTTP error: error message. Retrying fragment 1 (attempt 1 of 3)...'
    ]

    fd.report_retry_fragment(err, 2, 8, 10)
    assert fd.msgs == [
        '[download] Got server HTTP error: error message. Retrying fragment 1 (attempt 1 of 3)...',
        '[download] Got server HTTP error: error message. Retrying fragment 2 (attempt 8 of 10)...'
    ]

# Generated at 2022-06-24 11:42:37.008659
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .utils import ExtractorError

    class MyIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'foo',
                'title': 'bar',
            }

    ie = MyIE(InfoExtractor._downloader)
    ie.ie_key = 'MyIE'
    ie._WORKING = True

    dl = HttpQuietDownloader(ie, {})
    assert dl.to_screen('Hello') is None
    dl.report_warning('Warning!')
    dl.report_error('Error!', True)

# Generated at 2022-06-24 11:42:45.095387
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        import mock
        from ytdl.postprocessor import FFmpegMergerPP
    except ImportError:
        return

    class TestFD(FragmentFD):
        FD_NAME = 'testfd'

    def mock_hook(d):
        pass

    def mock_report_warning(msg):
        pass

    with mock.patch('youtube_dl.YoutubeDL.report_warning', side_effect=mock_report_warning), \
         mock.patch('youtube_dl.postprocessor.ffmpeg.merge_outputs', return_value=True):
        ydl = mock.MagicMock()
        ydl.params = {
            'noprogress': True,
            'logger': mock.MagicMock(),
            'progress_hooks': [mock_hook],
        }

# Generated at 2022-06-24 11:42:46.575950
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from ..utils import CommandLineFD
    d = HttpQuietDownloader(CommandLineFD(), {'quiet': True})
    d.to_screen('foo')

# Generated at 2022-06-24 11:42:49.860153
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .utils import TestFD
    from .extractor import gen_extractors
    extractors = gen_extractors()
    fd = TestFD(extractors)
    fd.report_retry_fragment(
        Exception('Some error'), 3, 2, [1, 2, 3])



# Generated at 2022-06-24 11:42:53.926177
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    sys.stderr.write('Testing FragmentFD class...\n')

    params = {
        'fragment_retries': 10,
        'skip_unavailable_fragments': True,
        'keep_fragments': True,
    }
    fd = FragmentFD({}, params)
    assert fd.params == params
    assert fd.params.get('ratelimit') is None
    assert isinstance(fd.ydl, FileDownloader)
    assert fd.ydl.params == {}
    assert fd.__dict__ == {
        'params': params,
        'ydl': fd.ydl,
    }

    ratelimit = '1k'
    params['ratelimit'] = ratelimit
    fd = FragmentFD({}, params)
    assert fd

# Generated at 2022-06-24 11:43:04.121033
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    class MyOut(object):
        def __init__(self):
            self.str = ''
        def write(self, s):
            self.str += s
    def do_test(expected):
        MyOut.__init__(out)
        fd = FragmentFD(None)
        fd.to_screen = out.write
        fd.report_skip_fragment(42)
        assert out.str == expected
    out = MyOut()
    do_test('[download] Skipping fragment 42...')
    old_stdout = sys.stdout
    try:
        sys.stdout = out
        do_test('[download] Skipping fragment 42...\n')
    finally:
        sys.stdout = old_stdout

# Generated at 2022-06-24 11:43:15.058536
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..compat import compat_urllib_parse_unquote, compat_urllib_parse_urlparse

    def test_url_basename(url, basename):
        url_data = compat_urllib_parse_urlparse(url)
        filename = FragmentFD.url_basename(url_data)
        assert filename == basename, 'Expected: %s Got: %s' % (basename, filename)

    # Tests for url_basename method
    test_url_basename('http://example.org/', 'example.org-download')
    test_url_basename('http://example.org/foo', 'foo')
    test_url_basename('http://example.org/foo.bar', 'foo.bar')

# Generated at 2022-06-24 11:43:26.744157
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from sys import stdout
    fd = FragmentFD(None, {})
    fd.to_screen = lambda x: setattr(stdout, 'buffer', x)

    # Test error code
    fd.report_retry_fragment(
        lambda: 123, 0, 1, {'max_retries': 5})
    assert stdout.buffer == (
        b'[download] got server http error: 123. '
        b'Retrying fragment 0 (attempt 1 of 5)...')
    fd.report_retry_fragment(
        lambda: 123, 0, 1, {'max_retries': 0})
    assert stdout.buffer == (
        b'[download] got server http error: 123. '
        b'Retrying fragment 0...')

    # Test error code - force ASCII
   

# Generated at 2022-06-24 11:43:37.393719
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import get_info_extractor
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .compat import compat_os_name
    from .compat import compat_str

    class DummyIE(InfoExtractor):
        IE_NAME = 'Dummy'
        _VALID_URL = r'(?i)https?://.*'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': 'https://127.0.0.1/test.mp4',
                'title': 'test video',
            }

    class DummyFD(HttpFD):
        @staticmethod
        def _progress_hooks():
            return []

    InfoExtractor.set_downloader(DummyFD)

# Generated at 2022-06-24 11:43:46.821653
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    from .extractor import get_info_extractor

    class TestFragmentFD(unittest.TestCase):
        def setUp(self):
            self.ydl = get_info_extractor('youtube')  # Not used, but required
            # FragmentFD constructor signature:
            # FragmentFD(self, ydl, params, info_dict)
            self.fd = FragmentFD(
                self.ydl,
                {'fragment_retries': 10},
                {'id': 'test video'})

# Generated at 2022-06-24 11:43:52.450979
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from test.helper import ytdl_filename_tst
    fd = FragmentFD(None)
    assert fd.ytdl_filename(ytdl_filename_tst('foo.bar')) == ytdl_filename_tst('.foo.bar.ytdl')



# Generated at 2022-06-24 11:44:01.990120
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Create fake downloader
    class FakeYDL(object):
        def to_screen(self, msg, skip_eol=False):
            fake_ydl.msg_buffer.append(msg)
    class FakeParams(dict):
        def __init__(self, *args, **kwargs):
            super(FakeParams, self).__init__(*args, **kwargs)
            self.setdefault('logger', FakeLogger())
    class FakeLogger(object):
        def debug(self, msg):
            pass
        def warning(self, msg):
            pass
        def error(self, msg):
            pass
    fake_ydl = FakeYDL()
    fake_ydl.params = FakeParams()
    fake_ydl.msg_buffer = []

    # Test
    fd = Http

# Generated at 2022-06-24 11:44:12.278189
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .compat import compat_str

    # Create fake InfoExtractor for passing it to HttpQuietDownloader
    class DummyIE(InfoExtractor):
        def __init__(self, ie_id, ie_id_short):
            self._type = ie_id
            self._type_id = ie_id_short

    # Create fake ydl for passing it to HttpQuietDownloader
    class FakeYdl(object):
        def __init__(self):
            self.params = {}

    def fake_gen_ie_result():
        class _FakeGenIeResult:
            IE_NAME = 'fake'
            IE_DESC = 'Fake Extractor'
            _WORKING = True

# Generated at 2022-06-24 11:44:20.702628
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self, params):
            self.to_screen_result = None
            super(TestFragmentFD, self).__init__()
            self.params = params

        def to_screen(self, *args, **kargs):
            self.to_screen_result = args

    fragment_fd = TestFragmentFD({})

    # Test when retries=None
    fragment_fd.params['retries'] = None
    fragment_fd.report_retry_fragment(42, 137, 1, fragment_fd.params['retries'])
    assert fragment_fd.to_screen_result == (
        '[download] Got server HTTP error: 42. Retrying fragment 137...',)

    # Test when retries=0

# Generated at 2022-06-24 11:44:23.665840
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    fd = HttpQuietDownloader({'noprogress': True}, None)
    assert fd.to_screen(u'hello world') == None


# Generated at 2022-06-24 11:44:29.283486
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    ydl = FakeYDL()
    ffd = FragmentFD(ydl, {}, {'skip_unavailable_fragments': True})
    ffd.to_screen = lambda x: ydl.to_screen(x)
    ffd.report_skip_fragment(5)
    assert ydl.messages == ['[download] Skipping fragment 5...']


# Generated at 2022-06-24 11:44:38.101540
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpFD
    orig_to_screen = HttpFD.to_screen

    def new_to_screen(self, *args, **kargs):
        HttpQuietDownloaderTest.to_screen_args_queue.append((args, kargs))

    HttpFD.to_screen = new_to_screen

    try:
        HttpQuietDownloaderTest.to_screen_args_queue = []
        d = HttpQuietDownloader(None, {'continuedl': False, 'quiet': True})
        d.to_screen('foo', 'bar')
        assert len(HttpQuietDownloaderTest.to_screen_args_queue) == 0
    finally:
        HttpFD.to_screen = orig_to_screen


# Generated at 2022-06-24 11:44:46.356788
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=W0212
    assert_equal = lambda expr1, expr2, msg='': expr1 == expr2 or _raiseAssertionError(expr1, expr2, msg)

    class FakeYDL:
        params = {'ratelimit': 10}

        def to_screen(self, *args, **kargs):
            pass

    class FakeInfoDict:
        pass

    def _create_fd(url, params):
        ydl = FakeYDL()
        ydl.params.update(params)
        info_dict = FakeInfoDict()
        return FragmentFD.__base__(ydl, params, info_dict, url)

    # Constructor test
    base = _create_fd(None, {})
    assert_equal(base.cachedir, None)
    assert_

# Generated at 2022-06-24 11:44:51.542043
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    retries = (None, 0, 1, 2, 3)
    for i in xrange(len(retries)):
        fd.report_retry_fragment(Exception(), 0, i + 1, retries[i])



# Generated at 2022-06-24 11:45:02.779034
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestYDL(object):
        def __init__(self, *args):
            self.to_screen = args

        def to_stderr(self, *args):
            pass

    TestHttpQuietDownloader = HttpQuietDownloader(TestYDL(), {'quiet': True})
    TestHttpQuietDownloader.to_screen(
        'this is a {0} {1}'.format('test', 'message'),
        'second line',
    )
    assert TestYDL.to_screen == ()
    TestHttpQuietDownloader.to_screen(
        'this is a {0} {1}'.format('test', 'message'),
        'second line',
    )
    assert TestYDL.to_screen == ('second line',)

# Generated at 2022-06-24 11:45:13.151007
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from io import StringIO
    from ..utils import prepend_extension

    out = StringIO()

    fd = FragmentFD({'outtmpl': prepend_extension('-', 'mp4')}, {}, out)
    fd.report_skip_fragment(0)
    assert out.getvalue() == '[download] Skipping fragment 0...\n'
    out.seek(0)
    out.truncate(0)

    fd.report_skip_fragment(1)
    assert out.getvalue() == '[download] Skipping fragment 1...\n'
    out.seek(0)
    out.truncate(0)

    fd.report_skip_fragment(999)
    assert out.getvalue() == '[download] Skipping fragment 999...\n'
    out

# Generated at 2022-06-24 11:45:24.044813
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import types

    fd = FragmentFD()

    assert 'fragment_index' in fd.__dict__
    assert 'fragment_count' in fd.__dict__

    assert '_start_frag_download' in fd.__dict__
    assert fd._start_frag_download.__class__ is types.MethodType

    assert '_download_fragments' not in fd.__dict__
    assert '_finish_frag_download' in fd.__dict__
    assert '_prepare_frag_download' in fd.__dict__
    assert '_append_fragment' in fd.__dict__
    assert '_prepare_and_start_frag_download' in fd.__dict__

# Generated at 2022-06-24 11:45:35.037085
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import unittest
    import sys

    class FakeLogger(object):
        def __init__(self):
            self.messages = []

        def debug(self, msg):
            self.messages.append(msg)

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'verbose': True
            }
            self.logger = FakeLogger()

        def report_warning(self, msg):
            self.logger.debug(msg)


# Generated at 2022-06-24 11:45:40.612383
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..compat import StringIO, compat_print

    output_stream = StringIO()
    x = FragmentFD(None, params={}, outtmpl=None)
    x.to_screen = lambda *a, **ka: compat_print(a, file=output_stream, end='')
    x.report_retry_fragment('error', 1, 2, 4)
    assert output_stream.getvalue() == '[download] Got server HTTP error: error. Retrying fragment 1 (attempt 2 of 3)...'
    output_stream.truncate(0)
    x.report_retry_fragment('error', 1, 1, 2)
    assert output_stream.getvalue() == '[download] Got server HTTP error: error. Retrying fragment 1 (attempt 1 of 2)...'
    output_stream.trunc

# Generated at 2022-06-24 11:45:43.076205
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class DummyYDL():
        params = {}

    # Should not fail
    HttpQuietDownloader(DummyYDL(), {})

# Generated at 2022-06-24 11:45:57.940881
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import platform
    assert sys.platform == 'win32' == (platform.system() == 'Windows')
    opts = {
        'usenetrc': False,
        'username': 'u',
        'password': 'p',
        'verbose': True,
        'quiet': True,
    }
    ydl = None  # To suppress "Variable 'ydl' is not used" warning
    dl = HttpQuietDownloader(ydl, opts)

    if sys.platform == 'win32':
        # Test default User-Agent
        assert dl._request_kwargs['headers']['User-Agent'].startswith('Mozilla')
        # Test username and password
        expected_auth = 'Basic dTpw'

# Generated at 2022-06-24 11:46:08.701211
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFD(FragmentFD):
        class DummyYDL(object):
            def __init__(self, *args, **kwargs):
                self.params = kwargs.get('params', {}).copy()
                self.to_screen_str_list = []

            def to_screen(self, message):
                self.to_screen_str_list.append(message)

    ydl = TestFD.DummyYDL()
    fd = TestFD(ydl, {})
    skip_frag_index = 0
    fd.report_skip_fragment(skip_frag_index)
    assert ydl.to_screen_str_list == ['[download] Skipping fragment 0...']

# Generated at 2022-06-24 11:46:12.894740
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .extractor.common import InfoExtractor

    info_dict = {
        'id': '123456',
        'extractor': 'youtube',
        'filename': 'test.mp4',
        'title': 'Test Video'
    }
    ydl = None
    params = {'noprogress': True}
    ie = InfoExtractor({})
    downloader = FragmentFD(ydl, params, info_dict, {})
    assert downloader.info_dict is info_dict
    assert downloader.params is params
    assert downloader.ie is ie

# Generated at 2022-06-24 11:46:21.280522
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD()
    fd.add_default_extra_info({'n_frags': 5})
    assert fd.params == {
        'noprogress': True,
        'quiet': False,
        'nopart': False,
        'updatetime': True,
        'test': False,
        'ratelimit': None,
        'retries': None,
        'n_frags': 5,
    }

# Generated at 2022-06-24 11:46:23.832067
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    assert 'Retrying fragment 1 (attempt 2 of 10)...' == FragmentFD.report_retry_fragment(
        None, '', 1, 2, 10)


# Generated at 2022-06-24 11:46:27.325098
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {'logger': None})
    assert isinstance(fd, FragmentFD)
    assert hasattr(fd, '_download_fragment')


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:46:30.888403
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class FakeYDL(object):
        def __init__(self):
            self.params = {}

    ydl = FakeYDL()
    downloader = HttpQuietDownloader(ydl, ydl.params)
    assert isinstance(downloader, HttpFD)

# Generated at 2022-06-24 11:46:41.750379
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor.common import InfoExtractor

    class MockInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(MockInfoExtractor, self).__init__(*args, **kwargs)
            self._screen_file = open('test_FragmentFD_report_retry_fragment.tmp', 'wb')

        def _print_debug(self, *args, **kwargs):
            self._screen_file.write(repr((args, kwargs)) + '\n')

    downloader = FragmentFD(MockInfoExtractor(), {}, {}, None, None)
    downloader.report_retry_fragment('Test Message', 4, 12, (12, 12))
    downloader._screen_file.close()

# Generated at 2022-06-24 11:46:53.119681
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import collections

    def _progress_hook(status):
        _hook_called = True
        _hook_status = status

    class DummyYDL(object):
        def __init__(self):
            self.params = {}
            self.to_screen = self.report_error = sys.stderr.write
            self.cache = {}

        def hooked(self):
            return collections.defaultdict(lambda: False)

    fd = FragmentFD(DummyYDL())
    _hook_called = False
    _hook_status = None
    fd.add_progress_hook(_progress_hook)
    # Setting a progress hook should result in the hook being called
    fd._hook_progress({'status': 'downloading', 'filename': '-'})
    assert(_hook_called)

# Generated at 2022-06-24 11:47:00.259849
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(
        options={},
        params={},
        ydl=None)
    fd.to_screen = lambda *args, **kargs: print(args[0])
    fd.report_retry_fragment(
        IOError(),
        frag_index=0,
        count=1,
        retries=5)
    fd.report_retry_fragment(
        IOError(),
        frag_index=1,
        count=2,
        retries=5)
    fd.report_retry_fragment(
        IOError(),
        frag_index=2,
        count=3,
        retries=5)



# Generated at 2022-06-24 11:47:11.582275
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import unittest
    import sys

    # Catch all messages written to sys.stderr and return them as string
    # Probably very fragile and not recommended for actual use
    class StdOutCatcher(object):
        def __init__(self, func):
            self.func = func
            self.out = ''

        def __call__(self, *args, **kwargs):
            sys.stderr.flush()
            old_stderr_write = sys.stderr.write
            sys.stderr.write = lambda msg: self.out.append(msg)
            result = self.func(*args, **kwargs)
            sys.stderr.write = old_stderr_write
            return result

        def get_output(self):
            return ''.join(self.out)


# Generated at 2022-06-24 11:47:16.469868
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from ..utils import encode_data_uri

    n = FragmentFD(None, {})

# Generated at 2022-06-24 11:47:17.995265
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert FragmentFD.__name__ == 'FragmentFD'

# Generated at 2022-06-24 11:47:27.752367
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor import gen_extractors
    from .downloader import gen_ytdl_file
    from .postprocessor import gen_pp


# Generated at 2022-06-24 11:47:35.203377
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FakeYDL
    fdl = FragmentFD(FakeYDL(), {'noprogress': True})
    fdl.to_screen = lambda s: s

    assert(fdl.report_skip_fragment(1) ==
           '[download] Skipping fragment 1...')

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:47:40.403687
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {
        'fragment_retries': 'infinite',
        'skip_unavailable_fragments': True,
        'keep_fragments': True,
    })
    assert fd.params['fragment_retries'] == float('inf')
    assert fd.params['skip_unavailable_fragments'] is True
    assert fd.params['keep_fragments'] is True

# Generated at 2022-06-24 11:47:46.805662
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(
        None, {
            'skip_unavailable_fragments': 3,
            'quiet': True,
        }
    )
    fd.to_screen = lambda x: x
    for x in range(4):
        assert fd.report_skip_fragment(x) == '[download] Skipping fragment %d...' % x

# Generated at 2022-06-24 11:47:56.570274
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .test import get_testdata_files_path

# Generated at 2022-06-24 11:48:03.881069
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.messages = []

        def to_screen(self, *args, **kargs):
            self.messages.append(args[0])

    fd = TestFragmentFD()
    fd.report_retry_fragment(
        IOError(1, 'error message'), 1, 2, 10)
    expected_message = (
        '[download] Got server HTTP error: error message. '
        'Retrying fragment 1 (attempt 2 of 10)...')
    assert fd.messages[0] == expected_message



# Generated at 2022-06-24 11:48:14.430545
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FakeYDL():
        def __init__(self):
            self.params = {
                'skip_unavailable_fragments': True,
            }
    class FakeFD(FragmentFD):
        def __init__(self):
            self.params = {}
            self.to_screen = self.to_screen_called = lambda *args: None
    ctx = {}
    fake_fd = FakeFD()
    fake_fd._start_frag_download(ctx)
    fake_fd.report_skip_fragment(0)
    assert ctx['started'] == time.time()
    assert ctx['prev_frag_downloaded_bytes'] == 0
    assert ctx['fragment_index'] == 0

# Generated at 2022-06-24 11:48:25.838479
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import YoutubeDL
    from .extractor import get_info_extractor, gen_extractors_names

    test_ie = get_info_extractor('youtube', YoutubeDL({}))
    assert isinstance(test_ie, FragmentFD)

    for ie_name in gen_extractors_names():
        ie = get_info_extractor(ie_name, YoutubeDL({}))
        if ie is None:
            continue
        if issubclass(ie.__class__, FragmentFD):
            assert hasattr(ie, '_download_fragment'), ie
            assert hasattr(ie, '_prepare_frag_download'), ie
            assert hasattr(ie, '_start_frag_download'), ie
            assert hasattr(ie, '_finish_frag_download'), ie

# Generated at 2022-06-24 11:48:36.762571
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import io

    class _LoggingStdout(object):
        def __init__(self):
            self.content = []

        def write(self, data):
            self.content.append(data)

        def read(self):
            return ''.join(self.content)

    old_stdout = sys.stdout

# Generated at 2022-06-24 11:48:41.537373
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    if not hasattr(FragmentFD, 'FD_NAME'):
        raise Exception('FragmentFD is not a base class')
    return True

# Generated at 2022-06-24 11:48:49.901540
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(ValueError('test'), 0, 1, 1) == (
        '[download] Got server HTTP error: test. Retrying fragment 0 (attempt 1 of 1)...', )
    assert fd.report_retry_fragment(ValueError('test'), 1, 1, 2) == (
        '[download] Got server HTTP error: test. Retrying fragment 1 (attempt 1 of 2)...', )

# Generated at 2022-06-24 11:48:54.811696
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .fragment import DASHFD
    from .youtube import YoutubeFD
    from .m3u8 import M3U8FD
    from .hlsnative import HLSFD
    assert issubclass(DASHFD, FragmentFD)
    assert issubclass(YoutubeFD, FragmentFD)
    assert issubclass(M3U8FD, FragmentFD)
    assert issubclass(HLSFD, FragmentFD)


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:49:04.875564
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractor_classes
    from ..postprocessor import gen_pp_classes
    from ..utils import DateRange


# Generated at 2022-06-24 11:49:17.179261
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloaderTest

    class FragFD(FragmentFD, FileDownloaderTest):
        def __init__(self, ydl):
            FileDownloaderTest.__init__(self, ydl)

    frag_dl = FragFD({})
    tests = [
        (
            'some error',
            42,
            3,
            3,
            b'[download] Got server HTTP error: some error. '
            b'Retrying fragment 42 (attempt 3 of 3)...'
        ),
        (
            'another error',
            13,
            1,
            10,
            b'[download] Got server HTTP error: another error. '
            b'Retrying fragment 13 (attempt 1 of 10)...'
        ),
    ]

# Generated at 2022-06-24 11:49:22.624169
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    dl = HttpQuietDownloader({}, {})
    class TestException(Exception):
        pass
    exc = TestException('msg')
    dl.report_error(exc)  # this should not raise an exception

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:49:27.453200
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    downloader = FragmentFD({})
    downloader._screen_file = lambda: None
    downloader.to_screen = lambda msg: setattr(downloader, 'screen_msg', msg)
    downloader.report_skip_fragment(10)
    assert downloader.screen_msg == '[download] Skipping fragment 10...'

# Generated at 2022-06-24 11:49:38.344391
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
        fd = FragmentFD(
            None, {
                'noprogress': True,
                'quiet': False,
                'format': 'mp4',
            }, None)

        # Retry 2 at attempt 1/3
        fd.to_screen = lambda *args, **kargs: None
        fd.to_screen('[download] Got server HTTP error: HTTP Error 404: Not Found. Retrying fragment 2 (attempt 1 of 3)...')
        fd.report_retry_fragment('HTTP Error 404: Not Found', 2, 1, 3)

        # Retry 5 at attempt 7/15
        fd.to_screen = lambda *args, **kargs: None

# Generated at 2022-06-24 11:49:44.728398
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import io

    # Import here so it won't be loaded when running FragmentFD unit tests
    from .http import HttpFD
    from ..utils import prepend_extension

    # Create a fake stderr
    real_stderr = sys.stderr
    sys.stderr = io.StringIO()

    # Check if report_retry_fragment is called multiple times with different
    # retry numbers and that the retry count is being displayed properly
    frag_down = FragmentFD(HttpFD(), {'retries': 3})

    for i in range(4):
        frag_down.report_retry_fragment(Exception('Could not download'), 0, i + 1, 4)

    output = sys.stderr.getvalue()

# Generated at 2022-06-24 11:49:53.658863
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    class FragmentFDMock(FragmentFD):
        def __init__(self, test):
            FragmentFDMock.test = test
        def to_screen(self, *args, **kargs):
            FragmentFDMock.test.assertEquals(args[0], '[download] Skipping fragment %d...')
    test_frag_fd = FragmentFDMock(sys.modules[__name__])
    test_frag_fd.report_skip_fragment(5)

# Generated at 2022-06-24 11:50:03.320552
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .utils import unescapeHTML
    from .compat import compat_urllib_request

    MSG = 'Downloading webpage'

    # Do nothing
    ctx = {}
    dler = HttpQuietDownloader(
        InfoExtractor(),
        {
            'quiet': True,
            'stdout': ctx,
            'test': True,
        }
    )
    dler.to_screen(MSG)
    assert 'to_screen' not in ctx

    # Print msg to stdout
    ctx = {}
    dler = HttpQuietDownloader(
        InfoExtractor(),
        {
            'quiet': False,
            'stdout': ctx,
            'test': True,
        }
    )
    dler.to_

# Generated at 2022-06-24 11:50:08.818302
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    ytdl = object()
    params = {}
    fd = FragmentFD(ytdl, params)
    fd.to_screen = lambda *args, **kargs: str(args)
    assert fd.report_skip_fragment(2) == "('[download] Skipping fragment 2...',)"


# Generated at 2022-06-24 11:50:15.846097
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.http import HttpIE
    from ..downloader.external import ExternalFD
    from ..compat import compat_str
    try:
        from ..downloader.f4m import F4mFD
    except ImportError:
        F4mFD = None
    try:
        from ..downloader.hls import HlsFD
    except ImportError:
        HlsFD = None
    try:
        from ..downloader.dash import DashSegmentsFD
    except ImportError:
        DashSegmentsFD = None
    try:
        from ..downloader.hlsnative import HlsFD as HlsNativeFD
    except ImportError:
        HlsNativeFD = None

    class TestHttpIE(HttpIE):
        IE_NAME = 'test_http'
        IE_DESC = 'Test HTTP IE'


# Generated at 2022-06-24 11:50:20.786965
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFD(FragmentFD):
        def to_screen(self, message, skip_eol=False, check_quiet=False):
            assert message == '[download] Skipping fragment 0...\r'

    fd = TestFD()
    fd.report_skip_fragment(0)
    fd.params['verbose'] = True
    fd.report_skip_fragment(0)

# Generated at 2022-06-24 11:50:33.835239
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .geturl import GetUrlFD
    fd = FragmentFD(GetUrlFD(), {'retries': 3})
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(None, 1, 2, 3) == (
        "[fragment] Got server HTTP error: None. Retrying fragment 1 (attempt 2 of 3)...",
    )
    assert fd.report_retry_fragment(None, 2, 1, 1) == (
        "[fragment] Got server HTTP error: None. Retrying fragment 2 (attempt 1 of 1)...",
    )

# Generated at 2022-06-24 11:50:38.421488
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import YoutubeDL

    class TestFD(FragmentFD):
        FD_NAME = 'testfd'
        def __init__(self, ydl, params={}):
            self.fd_id = params.get('fd_id')
            super(TestFD, self).__init__(ydl, params)
            if self.params.get('test_fail'):
                raise Exception('Testing failure')
        def real_download(self, filename, info_dict):
            return True
        def ytdl_filename(self, filename):
            return filename + '.ytdl'

    params = {
        'fd_id': 'test',
        'keep_fragments': True,
    }

# Generated at 2022-06-24 11:50:45.296966
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None)
    # Patch to_screen
    orig_to_screen = fd.to_screen
    def to_screen_checker(self, *args, **kargs):
        assert len(args) == 1 and len(args[0]) > 0
    fd.to_screen = to_screen_checker
    # Test
    fd.report_skip_fragment(1)

# Generated at 2022-06-24 11:50:48.040325
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    assert FragmentFD.report_retry_fragment(
        FragmentFD(), 9, 10, 10) == '[download] Got server HTTP error: 9. Retrying fragment 10 (attempt 10 of 10)...'

# Generated at 2022-06-24 11:50:56.823436
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from sys import version_info

    if version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO
    import mock


    fake_ydl = mock.Mock()
    fake_ydl.to_screen = lambda *args, **kargs: None
    fake_ydl.params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }

    fd = HttpQuietDownloader(fake_ydl)
    assert fd.params == fake_ydl.params


# Generated at 2022-06-24 11:51:00.913755
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    output = []
    def to_screen(msg):
        output.append(msg)

    fd = FragmentFD({'toscreen': to_screen})
    fd.report_skip_fragment(1)
    assert output[0] == '[download] Skipping fragment 1...'

# Generated at 2022-06-24 11:51:06.961429
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None, None)
    fd.to_screen = lambda x, **kargs: x
    assert fd.report_skip_fragment(42) == '[download] Skipping fragment 42...'

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:51:11.576821
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=protected-access
    dl = HttpQuietDownloader({}, {})
    assert HttpQuietDownloader._downloader_kwargs(dl) == {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
    }

# Generated at 2022-06-24 11:51:14.126837
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # test to_screen method of class HttpQuietDownloader
    hqd = HttpQuietDownloader(None, {})
    hqd.to_screen('hello world!')

# Generated at 2022-06-24 11:51:19.434488
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from .common import FileDownloader
    gen_extractors()
    fd = FileDownloader({'quiet': True, 'verbose': True})
    hqd = HttpQuietDownloader(fd, {'noprogress': True})
    hqd.to_screen('Test message')

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:51:23.062317
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Ensure that HttpQuietDownloader is imported
    import youtube_dl.downloader.http
    assert hasattr(youtube_dl.downloader.http, 'HttpQuietDownloader')
    assert hasattr(HttpQuietDownloader, 'download')



# Generated at 2022-06-24 11:51:28.528127
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    orig_stderr = sys.stderr
    sys.stderr = dummy_stderr = StringIO.StringIO()
    try:
        HttpQuietDownloader(None, None)
    finally:
        sys.stderr = orig_stderr
    assert not dummy_stderr.getvalue()

# Generated at 2022-06-24 11:51:29.925718
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fd = HttpQuietDownloader({}, {'continuedl': True})
    assert fd is not None

# Generated at 2022-06-24 11:51:35.919537
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    for ie in gen_extractor_classes():
        ie_inst = ie(ydl=None)
        if hasattr(ie_inst, '_downloader'):
            assert isinstance(ie_inst._downloader, HttpQuietDownloader)
            break
    else:
        assert False, 'HttpQuietDownloader not found'

# Generated at 2022-06-24 11:51:36.638166
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass

# Generated at 2022-06-24 11:51:40.684892
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {})
    assert (
        fd.report_retry_fragment(None, 1, 2, 3)
        == fd.to_screen(
            '[download] Got server HTTP error: None. Retrying fragment 1 (attempt 2 of 3)...'))

# Generated at 2022-06-24 11:51:50.097513
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpFD
    from .fragment import FragmentFD
    from ..compat import compat_urllib_error
    from ..utils import FileDownloader
    class TestFD(FileDownloader):
        def report_error(self, *args, **kargs):
            pass
        def to_screen(self, *args, **kargs):
            pass
    test_fd = TestFD(dict())
    fd1 = HttpQuietDownloader(test_fd, dict(quiet=False))
    fd1.to_screen('test1')
    fd2 = HttpQuietDownloader(test_fd, dict(quiet=True))
    fd2.to_screen('test2')
    fd3 = FragmentFD(test_fd, dict())
    fd3.params['quiet']

# Generated at 2022-06-24 11:51:59.098180
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestHttpQuietDownloader(HttpQuietDownloader):
        def __init__(self):
            self._to_screen_buffer = []

        def to_screen(self, message, skip_eol=None, check_quiet=None):
            self._to_screen_buffer.append(message)

    dl = TestHttpQuietDownloader()
    dl.to_screen('abc', skip_eol=True)
    assert dl._to_screen_buffer == ['abc']
    dl.to_screen('def')
    assert dl._to_screen_buffer == ['abc', 'def']
    dl.to_screen(u'\u044f')
    assert dl._to_screen_buffer == ['abc', 'def', u'\u044f']

# Generated at 2022-06-24 11:51:59.713266
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    assert 1 == 1

# Generated at 2022-06-24 11:52:05.645902
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import get_info_extractor

    ie = get_info_extractor('youtube', {})()
    ie.downloader = object()
    fd = ie.FD_NAME(ie, {}, sys.stdout)
    assert fd.ydl is ie.downloader
    assert fd.params is {}
    assert fd.to_screen == sys.stdout.write


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:52:12.102422
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_progress_hook(lambda d: None)
    ydl.params['noprogress'] = True
    hqd = HttpQuietDownloader(ydl, {'quiet': True})
    assert len(hqd.ydl.progress_hooks) == 1
    assert hqd.params['noprogress']
    assert hqd.params['quiet']

# Generated at 2022-06-24 11:52:13.294546
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader(None, None).to_screen == HttpQuietDownloader.to_screen

# Generated at 2022-06-24 11:52:22.352447
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import unittest
    import ydl

    class Params(object):
        def __init__(self):
            self.retries = 30
            self.continuedl = False

    class FakeYDL(ydl.YoutubeDL):
        def __init__(self, *args, **kwargs):
            self.params = Params()
            self.to_stderr = sys.stderr
            self.to_screen = self.to_stdout = sys.stdout

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.ydl = FakeYDL()

        def test_params(self):
            fd = FragmentFD(self.ydl)