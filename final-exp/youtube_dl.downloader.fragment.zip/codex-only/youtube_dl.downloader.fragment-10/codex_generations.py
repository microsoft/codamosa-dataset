

# Generated at 2022-06-24 11:42:20.756707
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-24 11:42:25.365961
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    VideoInfo()['extractor_key'] = 'test_video'
    ctx = {}
    ctx['dl'] = HttpQuietDownloader(None, {'quiet': False})
    ctx['dl'].to_screen(*['teststring1', 'teststring2'])

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:42:31.980559
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    hqd = HttpQuietDownloader(None, {})

    assert hasattr(hqd, 'ydl')
    yield lambda: hqd.ydl is None

    assert hasattr(hqd, 'params')
    yield lambda: isinstance(hqd.params, dict)
    yield lambda: len(hqd.params) == 0


if __name__ == '__main__':
    from . import _test_downloader
    _test_downloader(__name__)

# Generated at 2022-06-24 11:42:37.305938
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MyFragmentFD(FragmentFD):
        def to_screen(self, *args, **kargs):
            self._to_screen_args = args
            self._to_screen_kargs = kargs

    fd = MyFragmentFD()
    fd.report_skip_fragment(1)
    assert fd._to_screen_args[0] == '[download] Skipping fragment 1...'
    assert sorted(fd._to_screen_kargs.keys()) == ['skip_eol']

# Generated at 2022-06-24 11:42:47.608751
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # Test format_retries(retries) method
    fd = FragmentFD(None, {}, {})
    assert fd.format_retries(0) == 'infinite'
    assert fd.format_retries(1) == '1 time'
    assert fd.format_retries(2) == '2 times'
    assert fd.format_retries(3) == '3 times'
    assert fd.format_retries(4) == '4 times'
    assert fd.format_retries(5) == '5 times'
    assert fd.format_retries(6) == '6 times'
    assert fd.format_retries(7) == '7 times'
    assert fd.format_retries(8) == '8 times'
    assert fd.format_retries

# Generated at 2022-06-24 11:42:54.664153
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    import sys
    import types

    class FakeYDL(object):
        params = {}

        def to_screen(self, *args, **kargs):
            pass

    class FakeInfoDict(object):
        pass

    fake_ydl = FakeYDL()

    out = StringIO()

# Generated at 2022-06-24 11:43:01.052360
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import tempfile
    x = FragmentFD(None, {}, None)
    if sys.version_info < (3, 0):
        assert isinstance(x._output_template, unicode), repr(x._output_template)
    else:
        assert isinstance(x._output_template, str), repr(x._output_template)
    tmp_dir = tempfile.mkdtemp()
    try:
        assert x.temp_name('abc.mp3', tmpdir=tmp_dir).startswith(os.path.join(tmp_dir, 'abc.mp3'))
    finally:
        os.rmdir(tmp_dir)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:43:11.360730
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    params = {
        'fragment_base_url': 'http://example.org/f',
        'fragments': [{
            'url': 'f0.ts',
            'duration': 0.1,
            'title': 'Frag 1',
        }, {
            'url': 'f1.ts',
            'duration': 0.1,
            'title': 'Frag 2',
        }, {
            'url': 'f2.ts',
            'duration': 0.1,
            'title': 'Frag 3',
        }],
        'protocol': 'm3u8_native',
    }
    ie = get_info_extractor('test')
    ie.params = {
        'test': True,
    }
    ie.add_info

# Generated at 2022-06-24 11:43:24.519162
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    test_err = "This is a test error"
    test_frag_index = 2
    test_count = 3
    test_retries = 5
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    out = StringIO()
    assert FragmentFD.report_retry_fragment(
        None, out, test_err, test_frag_index, test_count, test_retries)
    assert FragmentFD.report_retry_fragment(
        None, out, test_err, test_frag_index, test_count, test_retries)

# Generated at 2022-06-24 11:43:37.332413
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .fragment import FragmentFD
    from .downloader import YoutubeDL
    from .compat import is_py2
    from ._test_utils import TestLogger, DummyYDL

    class DummyFragmentFD(FragmentFD):
        @staticmethod
        def format_retries(retries):
            return '%d' % retries

    def get_error_code(err):
        if is_py2:
            return err[0]
        else:
            return err.code

    def test_report_retry_fragment_str(err):
        downloader = DummyYDL()
        downloader.to_screen = TestLogger(downloader.to_screen)

# Generated at 2022-06-24 11:43:43.062390
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # Prepare test data
    frag_index = 1
    msg_template = '\r[download] Skipping fragment %d...\n'

    # Test FragmentFD.report_skip_fragment
    fd = FragmentFD('dummyyoutubedl')
    assert fd.report_skip_fragment(frag_index) == None

    # Check that output to screens is correct
    assert fd.msgs == [msg_template % frag_index]

# Generated at 2022-06-24 11:43:51.859550
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import os
    import time
    import json
    import tempfile
    from .common import FileDownloader
    from .http import HttpFD
    from .fragment import FragmentFD
    from .dash import DASHFD
    from .hls import HLSFD

    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(DASHFD, FragmentFD)
    assert issubclass(HLSFD, FragmentFD)
    assert not issubclass(FragmentFD, HttpFD)

    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)
    fd = FragmentFD(object)

# Generated at 2022-06-24 11:44:01.705151
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    class FragmentFDTest(unittest.TestCase):
        def test_Constructor(self):
            from .extractor import gen_extractors, list_extractors
            ydl = gen_extractors()
            from .extractor.common import InfoExtractor
            for ie in list_extractors(ydl):
                if ie.IE_NAME != 'generic':
                    continue
                for url in ie._TEST_CASES:
                    # Skip cases with non-streaming media
                    if any(regex.search(url) for regex in ie._VALID_URL_TEMPLATES):
                        # Skip cases with only one fragment (no progress to report)
                        ie = InfoExtractor()
                        ie.initialize()

# Generated at 2022-06-24 11:44:11.205928
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader(None, {})
    ydl.to_screen = lambda *args, **kargs: None
    ydl.report_destination = lambda *args: None
    assert ydl.ydl is None
    assert ydl.params == {}
    assert not hasattr(ydl, '_err_temp')
    assert not hasattr(ydl, '_progress_hooks')
    assert not hasattr(ydl, '_progress_hooks_refs')
    assert not hasattr(ydl, '_download_retcode')
    assert not hasattr(ydl, '_num_downloads')
    assert not hasattr(ydl, '_screen_file')

# Generated at 2022-06-24 11:44:15.685490
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD

    assert issubclass(FragmentFD, FileDownloader)
    # httpfd is assigned to FileDownloader.FD_NAME
    assert FragmentFD.FD_NAME == HttpFD.FD_NAME
    assert FragmentFD.__name__ == 'FragmentFD'

# Generated at 2022-06-24 11:44:24.737166
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .downloader import FileDownloader
    from .extractor import gen_extractors

    """ This method tests class HttpQuietDownloader on method to_screen """
    gen_extractors()

    def test_pass(msg, expected_value):
        obj = HttpQuietDownloader(FileDownloader({}), {})
        result = obj.to_screen(msg)
        assert result == expected_value

    test_pass('Escape %%-placeholder', None)
    test_pass('Escape %% placeholder', None)
    test_pass('%%end%%', None)
    test_pass('%%end', None)
    test_pass('end%%', None)
    test_pass('end %%', None)
    test_pass('%end%', '%end%')

# Generated at 2022-06-24 11:44:29.813951
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda x: x

    msg = fd.report_retry_fragment('an error', 1, 1, 10)
    assert msg == '[download] Got server HTTP error: an error. Retrying fragment 1 (attempt 1 of 10)...'

    msg = fd.report_retry_fragment('an error', 2, 3, 5)
    assert msg == '[download] Got server HTTP error: an error. Retrying fragment 2 (attempt 3 of 5)...'

# Generated at 2022-06-24 11:44:38.394518
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import unittest

    class FakeYDL(object):
        @staticmethod
        def to_stdout(*args, **kargs):
            assert False

        @staticmethod
        def to_stderr(*args, **kargs):
            assert False

    class TestHttpQuietDownloader(HttpQuietDownloader):
        def __init__(self, ydl):
            super(TestHttpQuietDownloader, self).__init__(ydl, {
                'quiet': False,
            })

    class HttpQuietDownloaderTest(unittest.TestCase):
        def test_to_screen(self):
            dl = TestHttpQuietDownloader(FakeYDL())
            dl.to_screen('test')

    unittest.main()

if __name__ == '__main__':
    test

# Generated at 2022-06-24 11:44:44.131191
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {
        'noprogress': True,
        'format': 'best',
        'skip_unavailable_fragments': False,
        'retries': 10,
    }, {})
    assert fd
    assert fd.params['noprogress']
    assert fd.params['format'] == 'best'
    assert not fd.params['skip_unavailable_fragments']
    assert fd.params['retries'] == 10

# Generated at 2022-06-24 11:44:56.470146
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..downloader import Downloader
    from ..compat import urllib_error
    from .http import HttpFD
    from .file import FileFD
    from .fragment import FragmentFD
    from io import BytesIO
    try:
        from io import StringIO
    except ImportError:
        from io import BytesIO as StringIO
    import os
    import shutil
    import tempfile
    import unittest

    class NullFD(FragmentFD):
        def __init__(self, ydl):
            self.ydl = ydl

        def to_screen(self, msg):
            pass

        def real_download(self, filename, info_dict):
            pass


# Generated at 2022-06-24 11:45:06.424249
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import gc
    from .http import HttpFD
    from .downloader import Downloader
    from ..utils import FakeYDL
    # pylint: disable=too-many-locals
    ydl = FakeYDL()
    ydl.params['noprogress'] = True
    ydl.params['nooverwrites'] = True
    ydl.params['max_downloads'] = 1
    ydl.params['skip_download'] = True
    ydl.prepare_filename = lambda i: i['url']
    w = ydl.add_worker(None, {'url': 'http://localhost:8080/1K'})
    assert isinstance(w, HttpFD)
    assert ydl.download(['http://localhost:8080/0']) == 0
    # Test subclasses construction
   

# Generated at 2022-06-24 11:45:17.820972
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor.common import InfoExtractor
    from .utils import sanitize_open

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            raise IOError(('test reason', 123, None))

        def _download_webpage(self, *args, **kwargs):
            pass

        def _parse_jwplayer_data(self, *args, **kwargs):
            pass

    class FakeFD(FragmentFD):
        def _download_fragment(self, ctx, frag_url, info_dict, headers=None):
            pass

        def _prepare_frag_download(self, ctx):
            pass

        def _start_frag_download(self, ctx):
            pass


# Generated at 2022-06-24 11:45:21.836745
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFD(FragmentFD):
        def to_screen(self, *args, **kwargs):
            self.printed = args[0]
    test = TestFD()
    test.report_retry_fragment('foo', 5, 10, 10)
    assert test.printed == '[download] Got server HTTP error : foo. Retrying fragment 5 (attempt 10 of 10)...'

# Generated at 2022-06-24 11:45:28.989326
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import youtube_dl.extractor.common as common_extractor

    sys.modules['youtube_dl.extractor.common'] = common_extractor
    from youtube_dl.YoutubeDL import YoutubeDL

    raise 'test'
    ydl = YoutubeDL({})
    http_quiet_downloader = HttpQuietDownloader(ydl, {})

# Generated at 2022-06-24 11:45:34.480667
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():

    class DummyFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_value = None

        def to_screen(self, value):
            self.to_screen_value = value

    fd = DummyFragmentFD()
    fd.report_skip_fragment(123)
    assert fd.to_screen_value == '[download] Skipping fragment 123...'

# Generated at 2022-06-24 11:45:38.556420
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        import youtube_dl
    except ImportError:
        return
    ydl = youtube_dl.YoutubeDL({
            'logger': youtube_dl.Logger(),
            'progress_hooks': [lambda d: None],
        })
    fd = FragmentFD(ydl, {}, {})
    assert fd.params.get('progress_hooks')

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:45:49.657823
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class MockLogger(object):
        def __init__(self):
            self.msg = None

        def _print_message(self, msg):
            self.msg = msg

    class MockYDL(object):
        def __init__(self):
            self.logger = MockLogger()

    class MockError(Exception):
        def __init__(self, message):
            self.message = message

    ydl = MockYDL()
    dl = HttpQuietDownloader(ydl, dict())

    # If msg is None, the message is not printed
    dl.to_screen(None)
    assert ydl.logger.msg is None

    # If msg is not None, the message is printed
    dl.to_screen('message')
    assert ydl.logger.msg == 'message'



# Generated at 2022-06-24 11:45:56.246604
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MyFragmentFD(FragmentFD):
        def __init__(self):
            self.string = ''

        def to_screen(self, string):
            self.string += string + '\n'

    fragment_fd = MyFragmentFD()
    fragment_fd.report_skip_fragment(42)

    assert fragment_fd.string.strip() == '[download] Skipping fragment 42...'


# Generated at 2022-06-24 11:46:02.993241
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    from .ytdl import YoutubeDL

    ydl = YoutubeDL()
    fd = FileDownloader(ydl, {})
    assert isinstance(fd, FileDownloader)
    fd = HttpFD(ydl, {})
    assert isinstance(fd, FileDownloader)
    assert isinstance(fd, HttpFD)
    fd = FragmentFD(ydl, {})
    assert isinstance(fd, FileDownloader)
    assert isinstance(fd, HttpFD)

# Generated at 2022-06-24 11:46:13.782845
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # The rule of this test is to check if ytdl_skip is printed correctly
    # when function report_skip_fragment is called
    # It's a basic test so the test downloader only implements the report_skip_fragment
    # method needed to test this.

    class Downloader(FragmentFD):
        def report_skip_fragment(self, frag_index):
            self.to_screen('[download] Skipping fragment %d...' % frag_index)

    # Testing report_skip_fragment
    dl = Downloader(None, {})
    dl.to_screen = lambda x: x
    dl.report_skip_fragment(0)
    assert dl.screen_output == '[download] Skipping fragment 0...'


# Generated at 2022-06-24 11:46:25.121097
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor

# Generated at 2022-06-24 11:46:28.567808
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class MockYDL(object):
        def to_screen(self, msg):
            print('OUTPUT: ' + msg)
    ydl = MockYDL()
    dl = HttpQuietDownloader(ydl, {})
    dl.to_screen('Test message')

# Generated at 2022-06-24 11:46:37.575052
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class MyHttpQuietDownloader(HttpQuietDownloader):
        def __init__(self, *args, **kargs):
            self.output = []
            HttpQuietDownloader.__init__(self, *args, **kargs)

        def to_screen(self, *args, **kargs):
            self.output.append(args)

    my_fd = MyHttpQuietDownloader(None, {'quiet': True})
    my_fd.to_screen('Test')
    assert my_fd.output == [('Test',)]
    assert HttpQuietDownloader(None, {}).to_screen('Test') is None

# Generated at 2022-06-24 11:46:46.534533
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Create a new instance of HttpQuietDownloader for testing
    httpqd_test_instance = HttpQuietDownloader(None, None)
    from ..compat import stdout
    import io
    buf = io.BytesIO()
    sys_stdout = stdout
    stdout = buf
    # Uncomment line below to view test output as bytes
    #print(type(b'[download]\n'))
    try:
        httpqd_test_instance.to_screen(b'[download]')
        httpqd_test_instance.to_screen(b'\n')
        assert buf.getvalue() == b''
        stdout = sys_stdout
        del buf, sys_stdout
    finally:
        stdout = sys_stdout

# Generated at 2022-06-24 11:46:48.865644
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    fd = FragmentFD('youtube-dl')
    assert isinstance(fd, FileDownloader)

# Generated at 2022-06-24 11:46:59.864877
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import tempfile
    from .extractor import get_info_extractor
    from ..compat import compat_urlparse

    class MyFragmentFD(FragmentFD):
        def __init__(self, ydl, params):
            super(MyFragmentFD, self).__init__(ydl, params)

            self._start_frag_download_calls = 0
            self._prepare_frag_download_calls = 0

        def _start_frag_download(self, ctx):
            self._start_frag_download_calls += 1
            return super(MyFragmentFD, self)._start_frag_download(ctx)

        def _prepare_frag_download(self, ctx):
            self._prepare_frag_download_calls += 1
            return super

# Generated at 2022-06-24 11:47:03.089571
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    test_fd = FragmentFD()

    def to_screen(s):
        assert 'Got server HTTP error: error. Retrying fragment 4 (attempt 3 of 8)...' == s
    test_fd.to_screen = to_screen
    test_fd.report_retry_fragment('error', 4, 3, 8)

# Generated at 2022-06-24 11:47:08.341363
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import FileDownloader
    fd = FragmentFD(FileDownloader({}))

    assert fd.params == {'noprogress': True, 'quiet': True}
    assert not fd._do_retry('foo')
    assert fd._make_error({}, 'msg') == 'msg'

# Generated at 2022-06-24 11:47:17.611192
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class MockYDL(object):
        def __init__(self):
            self.params = {'in_error_list': []}
            self._progress_hooks = []

        def to_screen(self, message):
            pass

    ydl = MockYDL()
    fd = HttpQuietDownloader(ydl)

    fd.to_screen('a')
    fd.to_screen('b')
    assert ydl.params['in_error_list'] == []

    fd.report_error('c')
    fd.report_error('d')
    assert ydl.params['in_error_list'] == ['c', 'd']

# Generated at 2022-06-24 11:47:24.608901
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import StringIO
    stdout = sys.stdout
    try:
        output = StringIO.StringIO()
        sys.stdout = output
        FragmentFD({}).report_skip_fragment(23)
        assert output.getvalue() == '[download] Skipping fragment 23...\n'
    finally:
        sys.stdout = stdout
    return True


# Generated at 2022-06-24 11:47:30.362329
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': 1,
        'retries': 2,
        'nopart': True,
        'test': True,
    }
    assert HttpQuietDownloader(InfoExtractor('test', {}), params)

# Generated at 2022-06-24 11:47:40.933376
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class DummyFD(FragmentFD):
        def to_screen(self, s):
            self.screen_content.append(s)

    df = DummyFD(None, {'retries': 1, 'skip_unavailable_fragments': False})
    df.screen_content = []
    df.report_retry_fragment('some error', 2, 1, 0)
    assert df.screen_content == [
        '[download] Got server HTTP error: some error. Retrying fragment 2 (attempt 2 of 3)...']
    df.screen_content = []
    df.report_retry_fragment('some error', 2, 1, 4)
    assert df.screen_content == [
        '[download] Got server HTTP error: some error. Retrying fragment 2 (attempt 2 of 5)...']

# Generated at 2022-06-24 11:47:48.661969
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    save_stdout = sys.stdout

    from io import StringIO
    try:
        out = StringIO()
        sys.stdout = out

        fd = FragmentFD({'logger': sys.stdout}, {})
        fd.params = {}
        fd.report_skip_fragment(42)
        assert out.getvalue() == '[download] Skipping fragment 42...\n'
    finally:
        sys.stdout = save_stdout

# Generated at 2022-06-24 11:47:56.335397
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import tempfile

    dl = FragmentFD({'format': 'bestvideo+bestaudio'}, {}, {'outtmpl': tempfile.mkdtemp()+'/%(id)s.%(ext)s'})
    assert dl.params['noprogress'] is True
    assert dl.params['continuedl'] is True
    assert dl.params['quiet'] is True
    assert dl.params['nopart'] is False
    assert dl.params['test'] is False
    assert dl.params['retries'] == 0
    assert dl.params['ratelimit'] is None
    assert dl.postprocessors == []

# Generated at 2022-06-24 11:48:03.658895
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Test against UnicodeEncodeError: 'ascii' codec can't encode character '\xfc' in position 11: ordinal not in range(128)
    log_message = 'Test message: \xe4\xfc\xf6'
    ydl = object()
    quiet_downloader = HttpQuietDownloader(ydl, {'continuedl': True, 'quiet': True, 'noprogress': True})
    try:
        quiet_downloader.to_screen(log_message)  # should not throw UnicodeEncodeError
    except UnicodeEncodeError:
        raise Exception('to_screen() failed to handle non-ascii characters')

# Generated at 2022-06-24 11:48:06.134378
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    hqd = HttpQuietDownloader(None, None)
    assert hqd.to_screen == HttpFD.to_screen

# Generated at 2022-06-24 11:48:09.157089
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None)
    fd.params['verbose'] = True
    return fd.report_skip_fragment(12)



# Generated at 2022-06-24 11:48:21.418364
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor.common import InfoExtractor
    from .compat import is_py2

    _ = InfoExtractor._download_webpage

    # Suppress printing in stderr
    # Python 2.6 compat: No `capture_output` argument
    try:
        if is_py2:
            import subprocess32 as subprocess
            subprocess.DEVNULL = open(os.devnull, 'wb')
        else:
            import subprocess
            subprocess.DEVNULL = subprocess.DEVNULL
    except NameError:
        import subprocess
        subprocess.DEVNULL = open(os.devnull, 'wb')


# Generated at 2022-06-24 11:48:26.803955
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    fd = FragmentFD(FileDownloader())
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_skip_fragment(1) == ('[download] Skipping fragment 1...',)
    assert fd.report_skip_fragment(11) == ('[download] Skipping fragment 11...',)
    assert fd.report_skip_fragment(10) == ('[download] Skipping fragment 10...',)

# Generated at 2022-06-24 11:48:34.119065
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys

    class A(object):
        pass

    # Make sure to_screen method of super class (HttpFD) is not called
    hqd = HttpQuietDownloader(A(), {})
    old_stdout = sys.stdout
    null_fh = open(os.devnull, 'w')
    sys.stdout = null_fh
    hqd.to_screen('No output should occur')
    sys.stdout = old_stdout
    null_fh.close()

# Generated at 2022-06-24 11:48:43.176597
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestYdl(object):
        def __init__(self):
            self.to_screen_called = 0
            self.to_screen_args = []

        def to_screen(self, msg):
            self.to_screen_called += 1
            self.to_screen_args.append(msg)

        @property
        def params(self):
            return {
                'quiet': False,
            }

    ydl = TestYdl()
    dl = HttpQuietDownloader(ydl, {})

    dl.to_screen('message')
    assert ydl.to_screen_called == 1
    assert ydl.to_screen_args[0] == 'message'

    ydl.params['quiet'] = True
    dl.to_screen('message')
    assert ydl.to_screen

# Generated at 2022-06-24 11:48:46.404308
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import doctest
    sys.exit(doctest.testmod()[0])


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:48:54.685770
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import YoutubeDL
    from .extractor import get_info_extractor

    # Test constructor of class YoutubeDL
    ydl = YoutubeDL()

    # Test update_self()
    ydl2 = ydl.update_self()
    assert ydl2 is ydl

    # Test get_info_extractor()
    ie = get_info_extractor(ydl)
    assert ie is not None
    assert ie.ydl is ydl

    # Test constructor of class InfoExtractor
    ie2 = ie.update_self()
    assert ie2 is ie

    # Test constructor of class FileDownloader
    fd = ie.file_downloader_cls(ydl)
    assert fd is not None

    # Test update_self()
    fd2 = fd.update_self()
    assert fd2

# Generated at 2022-06-24 11:49:02.112456
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_content = ''

        def to_screen(self, message, skip_eol=False, check_quiet=False):
            self.to_screen_content += message

    test_fd = TestFragmentFD()

    frag_index = 1

    test_fd.report_skip_fragment(frag_index)

    assert test_fd.to_screen_content == '[download] Skipping fragment 1...'

# Generated at 2022-06-24 11:49:08.382677
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD

    HttpQuietDownloader(None, {'a': 1})  # 1) just test constructor

    temp_dir = None

# Generated at 2022-06-24 11:49:19.085464
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    dl = HttpQuietDownloader(
        ydl,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'retries': 0,
            'nopart': False,
            'test': False,
        }
    )
    assert dl.ydl is ydl
    assert dl.params.get('continuedl') is True
    assert dl.params.get('quiet') is True
    assert dl.params.get('noprogress') is True
    assert dl.params.get('retries') == 0
    assert dl.params.get('nopart') is False
    assert dl.params.get('test') is False

# Generated at 2022-06-24 11:49:22.839136
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD()

    def to_screen_dummy(msg):
        print('[dummy] ' + msg)

    fd.to_screen = to_screen_dummy

# Generated at 2022-06-24 11:49:30.780480
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_urllib_request
    from ..utils import encode_data_uri

    URL = encode_data_uri(b'content', 'text/plain')

    # A usual request
    req = compat_urllib_request.Request(URL)
    assert req.get_method() == 'GET'

    # An empty POST request
    req = compat_urllib_request.Request('', b'', {})
    assert req.get_method() == 'POST'

    # A nonempty POST request
    req = compat_urllib_request.Request(URL, None, {'Content-Length': '5'})
    assert req.get_method() == 'POST'

    # An empty custom request
    req = compat_urllib_request.Request('', b'', {})
    req.method

# Generated at 2022-06-24 11:49:36.871289
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({}, {})
    fd.to_screen = lambda *args, **kargs: repr((args, kargs))
    assert (
        fd.report_retry_fragment(1, 2, 3, 4)
        ==
        "('[download] Got server HTTP error: 1. Retrying fragment 2 (attempt 3 of 4)...',)",
        {}
    )


# Generated at 2022-06-24 11:49:39.016468
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    x = FragmentFD()
    x.report_retry_fragment(
        IOError('Failed to write data'), 0, 1, {'maxretries': 0})

# Generated at 2022-06-24 11:49:45.367769
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def test_url(url):
        return FragmentFD(None, {}, {'url': url}).url

    assert test_url('foo') == 'foo'
    assert test_url('foo\nbar') == 'foo%0Abar'
    assert test_url('foo\r\nbar') == 'foo%0Abar'
    assert test_url('foo\rbar') == 'foo%0Bar'
    assert test_url('http://a/b/c/d?e=1&f=2#frag') == 'http://a/b/c/d?e=1&f=2#frag'


# Generated at 2022-06-24 11:49:56.981277
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors

    class FakeInfo(object):
        pass

    info = FakeInfo()

    for ie in gen_extractors():
        if ie.IE_NAME == 'Generic':
            continue
        info.name = 'test'
        info.id = 'abc'
        ie.suitable(info)
        ie.extract(info)

        dl = HttpQuietDownloader(ie, {
            'quiet': True,
            'noprogress': True,
        })
        assert dl.ydl is ie
        assert dl.params['quiet'] is True
        assert dl.params['noprogress'] is True

# Generated at 2022-06-24 11:49:59.874932
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        pass

    tfd = TestFD({}, get_info_extractor('youtube'))
    assert tfd.params == {}

# Generated at 2022-06-24 11:50:11.786831
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FakeYDL
    from .extractor import get_info_extractor

    def report_warning(msg):
        warnings.append(msg)

    def hook(d):
        nonlocal hook_count
        hook_count += 1
        if hook_count > 2:
            d['fragment_count'] = 2
            d['fragments'] = [
                {
                    'url': 'f1',
                    'fragment': 1,
                },
                {
                    'url': 'f2',
                    'fragment': 2,
                },
            ]
    warnings = []
    hook_count = 0
    fd = FragmentFD(FakeYDL({}), get_info_extractor('fragments'), {}, {'report_warning': report_warning}, hook)
    fd.to

# Generated at 2022-06-24 11:50:20.157821
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():

    # create a FragmentFD object
    fd = FragmentFD(None)

    # create a error object
    errno = 2
    strerror = 'No such file or directory'
    filename = 'foo'
    winerror = 123
    filename2 = 'bar'

    # This create a error object
    err = OSError(errno, strerror, filename, winerror, filename2)

    # this method only print the information
    # so there is no return value to test.
    fd.report_retry_fragment(err, 1, 2, 3)

# Generated at 2022-06-24 11:50:33.198078
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from six.moves import StringIO
    from collections import namedtuple
    from .common import FileDownloader
    from .http import HttpFD
    from .fragment import FragmentFD


# Generated at 2022-06-24 11:50:45.341470
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpFD
    import copy
    import sys

    class HttpQuietDownloader(HttpFD):
        def to_screen(self, *args, **kargs):
            pass

    params = {
        'continuedl': False,
        'quiet': False,
        'noprogress': False,
        'ratelimit': None,
        'retries': 10,
        'buffersize': None,
        'noresizebuffer': False,
        'test': False,
    }
    fake_ydl = copy.copy(HttpFD(None, params))
    fake_ydl.params = copy.copy(params)

# Generated at 2022-06-24 11:50:48.085506
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = YoutubeDL()
    dl = HttpQuietDownloader(ydl, {'quiet': True})

    assert dl.ydl is ydl
    assert dl.params['quiet']



# Generated at 2022-06-24 11:50:55.509771
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFragmentFD, self).__init__(ydl, params)
            self.to_screen_msgs = []

        def to_screen(self, *args, **kargs):
            self.to_screen_msgs.append((args, kargs))

    tfd = TestFragmentFD({}, {})
    tfd.report_skip_fragment(10)
    assert tfd.to_screen_msgs == [(('[download] Skipping fragment 10...',), {})]


# Generated at 2022-06-24 11:51:07.226106
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    from ..compat import compat_urllib_request

    output = []
    def write_to_output(msg):
        output.append(msg.replace('\r', ''))

    class FakeFD(FileDownloader):
        def to_screen(self, *args, **kargs):
            write_to_output(*args)

    class FakeHttpFD(HttpFD, FakeFD):
        pass

    class FakeDASHFD(DASHFD, FakeHttpFD):
        def __init__(self, ydl, params):
            FakeFD.__init__(self, ydl, params)
            FakeHttpFD.__init__(self, ydl, params)


# Generated at 2022-06-24 11:51:16.063733
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import unittest
    import sys
    import StringIO
    from ..utils import encode_compat_str

    class TestFragmentFD(FragmentFD):
        def __init__(self, *args, **kwargs):
            self._outtest = StringIO.StringIO()
            self._out = sys.stdout
            sys.stdout = self._outtest
            FragmentFD.__init__(self, *args, **kwargs)

        def to_screen(self, *args, **kargs):
            print >>self._outtest, encode_compat_str(args[0] % args[1:], 'utf-8')

        def __del__(self):
            sys.stdout = self._out

        def readtestout(self):
            return self._outtest.getvalue()


# Generated at 2022-06-24 11:51:18.786820
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    hqd = HttpQuietDownloader(None, {'quiet': True})
    assert isinstance(hqd, HttpQuietDownloader)

# Generated at 2022-06-24 11:51:26.692557
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import os
    from .common import FileDownloader
    from .http import HttpFD
    from ..extractor import YoutubeIE
    from ..downloader.external import ExternalFD
    from ..compat import compat_etree_fromstring

    def urlopen(url):
        return open(url[7:], 'rb')

    def get(attr, default=None):
        return lambda: default

    class YDummyYoutubeIE(YoutubeIE):
        IE_NAME = 'youtube'

        @classmethod
        def suitable(cls, url):
            return False


# Generated at 2022-06-24 11:51:34.285326
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class DummyFD(FragmentFD):

        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_calls.append(message)

    fd = DummyFD()
    fd.report_retry_fragment(Exception('Abort'), 123, 2, 5)
    assert (
        fd.to_screen_calls ==
        ['[download] Got server HTTP error: Abort. Retrying fragment 123 (attempt 2 of 5)...'])


# Generated at 2022-06-24 11:51:39.839709
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None, None)
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_skip_fragment(0) == (
        '[download] Skipping fragment 0...',)
    assert fd.report_skip_fragment(9) == (
        '[download] Skipping fragment 9...',)


# Generated at 2022-06-24 11:51:42.808941
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    FragmentFD(InfoExtractor(), {}, {}, {}, {}, {})



# Generated at 2022-06-24 11:51:48.620819
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    def _test_to_screen_write(self, msg):
        # Check the content of msg
        assert msg == 'Hi'

    def _test_to_screen_flush(self):
        pass

    HttpQuietDownloader._write = _test_to_screen_write
    HttpQuietDownloader._flush = _test_to_screen_flush
    dl = HttpQuietDownloader(None, None)
    dl.to_screen('Hi')

# Generated at 2022-06-24 11:51:58.542094
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class _FileDownloader(object):
        to_screen = None
        params = {}
        def __init__(self, params=None):
            if params is not None:
                self.params = params
    class _HttpQuietDownloader(HttpQuietDownloader):
        def __init__(self, fd):
            self.fd = fd
        def to_screen(self, *args, **kargs):
            self.fd.to_screen.to_screen = args
            return HttpQuietDownloader.to_screen(self, *args, **kargs)

    params = {'videopassword': 'test_password'}
    fd = _FileDownloader(params)
    http_dl = _HttpQuietDownloader(fd)

# Generated at 2022-06-24 11:52:04.056596
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = FileDownloader({})
    dl = HttpQuietDownloader(
        ydl,
        {'continuedl': True, 'quiet': True, 'noprogress': True})
    assert dl.continuedl
    assert dl.quiet
    assert dl.noprogress
    assert dl.ydl is ydl



# Generated at 2022-06-24 11:52:14.667026
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..compat import compat_etree_Element
    from .fragment import FragmentFD
    from .test_test import BaseTest

    # FragmentFD uses common.FileDownloader.to_screen so we need to patch
    # it to test report_retry_fragment
    class FragmentTestFD(FragmentFD):
        def __init__(self, ydl):
            FragmentFD.__init__(self, ydl)
            self.to_screen_messages = []

        def to_screen(self, *args):
            self.to_screen_messages.append(args)

    # We need a dummy test case class which should provide a FD
    # So we inherit from BaseTest

# Generated at 2022-06-24 11:52:19.386240
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    frag_fd = FragmentFD(None, {'logger': None})
    frag_fd.to_screen = lambda *args, **kargs: (args, kargs)
    assert frag_fd.report_skip_fragment(42) == (
        ('[download] Skipping fragment 42...',), {'same_line': True})


# Generated at 2022-06-24 11:52:23.137476
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {'prefer_ffmpeg': None})
    fd.to_screen = lambda *x: None
    fd.report_retry_fragment(
        IOError('network error'), 0, 1, [10, 10])


if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()