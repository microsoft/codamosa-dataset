

# Generated at 2022-06-24 11:42:21.988014
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = YoutubeDL()
    ydl.prepare_filename({'id': '123'})
    assert isinstance(ydl, YoutubeDL)

# Generated at 2022-06-24 11:42:28.519482
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = object()
    params = {
        'fragment_retries': 'foo',
        'skip_unavailable_fragments': 'bar',
    }
    fd = FragmentFD(ydl, params)
    assert fd.ydl is ydl
    assert fd.params == params

# Generated at 2022-06-24 11:42:38.132129
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(InfoExtractor):

        _WORKING = True

        def _real_initialize(self):
            self._downloader = FragmentFD(self.ydl, self.params)

    ie = FakeInfoExtractor({})
    ie.params = {
        'format': 'best',
        'noplaylist': True,
        'match_filter': match_filter_func('vod'),
    }
    ie.add_default_info_extractors()

    video_id = 'HL0r_ynLD_Q'
    video_url = 'http://www.youtube.com/watch?v=%s' % video_id
    test_video

# Generated at 2022-06-24 11:42:42.172795
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    sys.argv = [__name__, '-o', 'foo', 'bar']
    dl = HttpQuietDownloader(None)
    assert dl.params['outtmpl'] == 'foo'
    assert dl.params['nooverwrites']
    assert dl.params['quiet']

# Generated at 2022-06-24 11:42:53.261794
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .downloader import Downloader
    from .extractor import get_info_extractor
    from .http import HEADRequest

    class MyFragmentFD(FragmentFD):
        def __init__(self, downloader):
            super(MyFragmentFD, self).__init__(downloader)
            self.fragment_retries = 0

    my_ie = get_info_extractor(MyFragmentFD.FD_NAME)
    downloader = Downloader(params={
        'format': 'best',
        'quiet': True,
        'noprogress': True,
        'simulate': True,
        'nopart': True,
        'retries': 0,
    })
    my_fragmentfd = MyFragmentFD(downloader)

# Generated at 2022-06-24 11:43:04.367238
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys

    class TestDownloader(HttpQuietDownloader):
        def __init__(self):
            self._out = []

        def to_screen(self, msg):
            self._out.append(msg)

    HttpQuietDownloader.urlopen = lambda *args: None  # avoid downloading

    test_ydl = type('', (), {})
    test_ydl.params = {}
    test_ydl.download_retcode = -1
    test_ydl.to_screen = lambda *args: None
    test_ydl.is_alive = lambda: True

    test_fd = TestDownloader()
    test_fd.add_info_extractor(lambda *args: None)
    test_fd.add_info_extractor(lambda *args: None)

# Generated at 2022-06-24 11:43:15.297734
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    # Simulate a running number for retries, so the msg is always the same
    fd.retries = {'max': 3, 'count': 0}
    # Simulate a fragment number, so the mdg is always the same
    frag_index = 5
    # Simulate a retry count, so the msg is always the same
    count = 2
    # Simulate an error, so the msg is always the same
    err = IOError('simulate IOError')
    fd.report_retry_fragment(err, frag_index, count, 3)
    # Simulate an infinite number of retries
    fd.retries['max'] = float('inf')

# Generated at 2022-06-24 11:43:20.821214
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    def report_skip_fragment(frag_index):
        assert frag_index == 1
    fd = FragmentFD({})
    fd.to_screen = report_skip_fragment
    fd.report_skip_fragment(1)

# Generated at 2022-06-24 11:43:25.360275
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    import types
    fd = FragmentFD(FileDownloader({}), {})
    assert type(fd) == FragmentFD
    assert type(fd.report_skip_fragment) == types.MethodType

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:43:33.635205
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .smoothstreams import SmoothStreamsFD
    from .jwplayer import JWPlayerIE
    from .hlsnative import HLSNativeFD
    from .dash import DASHFD
    from .http import HttpFD
    fd_list = [
        FragmentFD,
        SmoothStreamsFD,
        JWPlayerIE,
        HLSNativeFD,
        DASHFD,
        HttpFD,
    ]
    class YDL:
        def __init__(self):
            self.params = {}
            self.cache = None
        def trouble(self, *args, **kargs):
            pass

    ydl = YDL()

# Generated at 2022-06-24 11:43:35.731848
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    downloader = HttpQuietDownloader({}, {'continuedl': True})
    assert downloader.params.get('continuedl') is True

# Generated at 2022-06-24 11:43:45.541709
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .downloader import _match_entry
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import FFmpegMergerPP
    from .utils import unified_strdate

    # This test does not require internet connection

    match = lambda ie, url: _match_entry(gen_extractors(), ie, url)

    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    ie = match(InfoExtractor, url)
    info = ie.extract(url)

    quiet_ie = HttpQuietDownloader(ie, {'quiet': True})
    info['downloader'] = quiet_ie
    quiet_ie.add_info_extractor(ie)

# Generated at 2022-06-24 11:43:46.260253
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen(): assert True

# Generated at 2022-06-24 11:43:55.215754
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys

    class YDL:
        params = {}
        verbose = True
        def __init__(self):
            self.to_screen = sys.stderr.write

    dl = HttpQuietDownloader(YDL(), {'quiet': True})
    assert dl.params['quiet'] is True
    dl.to_screen('test')

    dl = HttpQuietDownloader(YDL(), {'quiet': False})
    assert dl.params['quiet'] is False
    dl.to_screen('test')

# Generated at 2022-06-24 11:44:03.107444
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    from ..postprocessor.ffmpeg import FFmpegMergerPP
    from ..postprocessor.xattrpp import XAttrMetadataPP

    ydl = InfoExtractor({})
    ffmpeg = FFmpegMergerPP(ydl)
    ffmpeg.run = lambda info: info
    xattr = XAttrMetadataPP(ydl)
    xattr.run = lambda info: info

    info = {
        'extractor': 'test',
        'url': 'test_url',
        'title': 'test',
        'ext': 'mp4',
        'http_headers': {
            'Cookie': 'test_cookie',
        },
    }

    dl = FragmentFD(ydl, info, ffmpeg, xattr, test=True)

    assert dl

# Generated at 2022-06-24 11:44:12.970097
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .downloader import YoutubeDL, FileDownloader

    ydl = YoutubeDL({})
    # Test if HttpQuietDownloader behaves as a FileDownloader
    assert issubclass(HttpQuietDownloader, FileDownloader)
    hqd = HttpQuietDownloader(ydl, {'url': 'http://www.example.com'})
    assert hqd != None
    assert isinstance(hqd, FileDownloader)
    assert isinstance(hqd, HttpQuietDownloader)
    # Test if HttpQuietDownloader has been instantiated with correct params
    assert hqd.ydl == ydl
    assert hqd.params == {'url': 'http://www.example.com'}
    assert hqd.report_warning == ydl.report_warning

# Generated at 2022-06-24 11:44:18.547608
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import io
    import sys

    out = io.StringIO()
    # Save original stdout
    savestdout = sys.stdout
    # Set stdout to new StringIO buffer
    sys.stdout = out
    # Print some text
    print('Hello World')
    # Get StringIO buffer text
    contents = out.getvalue()
    # Restore stdout
    sys.stdout = savestdout
    # Print it
    print('Captured:', repr(contents))

# Generated at 2022-06-24 11:44:30.580547
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # Implementation note: This method does not produce any output and
    # is used for unit testing only.
    class MockFragmentFD(FragmentFD):
        def __init__(self, ydl):
            FragmentFD.__init__(self, ydl)
            self.to_screen_output = list()

        def to_screen(self, *args, **kargs):
            self.to_screen_output.append((args, kargs))

    ydl = object()
    mffd = MockFragmentFD(ydl)
    mffd.report_skip_fragment(42)

    assert len(mffd.to_screen_output) == 1
    args, kargs = mffd.to_screen_output[0]
    assert len(args) == 1
    assert args[0].startswith

# Generated at 2022-06-24 11:44:34.292852
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .fragment import FragmentFD
    from .common import FileDownloader

    class TestFD(FileDownloader):
        def to_screen(self, msg):
            self.msg = msg

    fd = TestFD(None, {'skip_unavailable_fragments': True})
    fd.report_skip_fragment(123)
    assert fd.msg == '[download] Skipping fragment 123...'



# Generated at 2022-06-24 11:44:44.130543
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    def _list_false(xs):
        return [x for x in xs if not x]

    from .downloader import VideoFD
    from .extractor import VideoExtractor
    from .http import HttpFD

    class MyVideoFD(VideoFD):
        def __init__(self, ydl, params, info_dict):
            super(MyVideoFD, self).__init__(ydl, params, info_dict)
            self.hooks = []

        def add_progress_hook(self, hook):
            self.hooks.append(hook)

    class TestFD(HttpQuietDownloader):
        def __init__(self, *args, **kwargs):
            super(TestFD, self).__init__(*args, **kwargs)
            self.hooks = []

        # Override to implement hooks support


# Generated at 2022-06-24 11:44:50.345895
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class Test:
        def __init__(self):
            self.value = None

        def screen(self, value):
            self.value = value

    test = Test()
    dl = HttpQuietDownloader(test, {})
    dl.to_screen('value1', 'value2')
    assert test.value == 'value1 value2'

# Generated at 2022-06-24 11:45:01.725374
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor.youtube import YoutubeIE
    from .extractor.common import InfoExtractor
    from .jsinterp import JsInterpreter

    info_dict = {
        'id': '7xU6vK_V7vo',
        'extractor': YoutubeIE.ie_key(),
    }

    def _download_json(ie, url, ie_key, video_id):
        if ie_key == 'Youtube':
            return '{"adaptive_fmts": "foo"}'
        return None
    JsInterpreter.download_json = _download_json

    # Mock FileDownloader.to_screen to capture its output
    output = []
    results = []

    def _mocked_to_screen(self, msg):
        output.append(msg)
        results.append(self)

   

# Generated at 2022-06-24 11:45:03.136795
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    raise NotImplementedError('This test is a stub, please fix it!')

# Generated at 2022-06-24 11:45:13.370093
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    import sys

    class MockYDL(object):
        def __init__(self, params):
            self.params = params

    class TestFragmentFD(FragmentFD):
        @staticmethod
        def temp_name(filename):
            return 'temp'

        @staticmethod
        def ytdl_filename(filename):
            return 'ytdl'

        @staticmethod
        def try_rename(fromname, toname):
            return

        @staticmethod
        def report(*args, **kargs):
            return

        @staticmethod
        def calc_eta(start, now, total, downloaded):
            return 'ETA'

        @staticmethod
        def report_warning(message):
            print >>sys.stderr, message


# Generated at 2022-06-24 11:45:24.183527
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import io
    import sys

    class TestFD(FragmentFD):
        _TEST_FD_NAME = 'TEST'

        def __init__(self, params):
            super(TestFD, self).__init__(None, params)

        @property
        def FD_NAME(self):
            return self._TEST_FD_NAME

    old_stderr = sys.stderr
    old_stdout = sys.stdout
    try:
        sys.stderr = sys.stdout = io.StringIO()
        test_fd = TestFD({})
        test_fd.report_skip_fragment(42)
        assert sys.stderr.getvalue() == '[TEST] Skipping fragment 42...\n'
    finally:
        sys.stderr = old_stderr
       

# Generated at 2022-06-24 11:45:29.869733
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = FileDownloader()
    dl = HttpQuietDownloader(ydl, {'continuedl': True})
    assert dl.params == {'continuedl': True, 'quiet': True, 'noprogress': True}



# Generated at 2022-06-24 11:45:37.985185
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from ..compat import is_py2

    def _test_log(msg):
        sys.stdout.write('[download] %s\n' % msg)

    def _test_err(msg):
        sys.stderr.write('ERROR: %s\n' % msg)

    if is_py2:
        # Python 2.6 doesn't support unittest.mock
        try:
            from mock import Mock
        except ImportError:
            print('unittest.mock not found. Skipping unit test.')
            return
    else:
        # Python 3
        from unittest.mock import Mock

    ydl = Mock()
    fd = FragmentFD(ydl, {}, {})
    fd.to_screen = _test_log
    fd.report_

# Generated at 2022-06-24 11:45:49.475602
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import gc
    fd = FragmentFD()
    fd.params = {}
    fd.ydl = {}
    fd.to_screen = lambda *args, **kargs: None
    fd.report_warning = lambda *args, **kargs: None
    fd.report_error = lambda *args, **kargs: None
    fd.report_destination = lambda *args, **kargs: None
    fd.temp_name = lambda *args, **kargs: None
    fd.try_rename = lambda *args, **kargs: None
    fd.calc_eta = lambda *args, **kargs: None
    fd.ytdl_filename = lambda *args, **kargs: None
    fd.FD_NAME = ''

# Generated at 2022-06-24 11:45:52.391228
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # It should not raise any exception
    HttpQuietDownloader(None, {'quiet': True, 'noprogress': True})

# Generated at 2022-06-24 11:45:53.518821
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    pass


# Generated at 2022-06-24 11:45:56.607088
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # No actual test right now, just don't crash
    fd = FragmentFD(None, {}, None)
    fd.report_retry_fragment(None, 1, 2, 3)

# Generated at 2022-06-24 11:46:01.419411
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    fragfd = FragmentFD(None)
    fragfd.to_screen = sys.stdout.write
    fragfd.report_skip_fragment(1)
    fragfd.report_skip_fragment(13)


if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:46:08.974125
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class MockYDL(object):
        def __init__(self):
            self.params = {}

        def to_screen(self, *args, **kwargs):
            pass

        def temp_name(self, *args, **kwargs):
            return '-1'

        def try_rename(self, *args, **kwargs):
            pass

        def report_warning(self, *args, **kwargs):
            pass

    class TestFragmentFD(unittest.TestCase):
        def setUp(self):
            self.ydl = MockYDL()
            self.fd = FragmentFD(self.ydl)

        def test_prepare_frag_download(self):
            c

# Generated at 2022-06-24 11:46:12.340848
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import tempfile
    import re

    tf = tempfile.NamedTemporaryFile(delete=False)
    hqd = HttpQuietDownloader(None, {'outtmpl': tf.name})
    hqd.to_screen('[download] Total fragments: 11')
    tf.close()
    assert len(open(tf.name, 'r').read()) == 0
    os.unlink(tf.name)

# Generated at 2022-06-24 11:46:24.891202
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import tempfile
    fd = FragmentFD({'outtmpl': '%(id)s-%(format_id)s.%(ext)s', 'nooverwrites': True}, None)
    fd.params.update(forcefilename=True)

    # Assert that on encountering already downloaded file,
    # YoutubeDL produces meaningful error message
    fd.to_screen = sys.stderr.write

    tmp = tempfile.NamedTemporaryFile(delete=False)
    tmp.close()
    try:
        fd.report_destination(tmp.name)
        assert False, 'Expected exception'
    except Exception as e:
        assert 'has already been downloaded' in str(e)
    finally:
        os.remove(tmp.name)

    # Assert that on encountering

# Generated at 2022-06-24 11:46:29.125758
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        #'logger': YoutubeDL.logger.make_dummy_logger(),
    })
    return FragmentFD(ydl, {'format': 'best', 'keep_fragments': True})

# Generated at 2022-06-24 11:46:37.117992
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    try:
        from ..extractor import get_info_extractor
    except ImportError:
        from __main__ import get_info_extractor
    ie = get_info_extractor('test')
    fd = FragmentFD(ie._downloader, {})

# Generated at 2022-06-24 11:46:38.133799
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-24 11:46:44.194219
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import cStringIO

    out = cStringIO.StringIO()
    fd = FragmentFD(None, {'outtmpl': '%(id)s'})
    fd.to_screen = lambda *args, **kargs: out.write(args[0] + '\n')
    fd.report_skip_fragment(1)
    assert out.getvalue() == '[download] Skipping fragment 1...\n'

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:46:49.613955
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    dispatch, url_map = prepare_mock_any_download('f4m')
    fd = FragmentFD({'usenetrc': False, 'username': None,
                     'password': None, 'quiet': True})
    fd.report_skip_fragment(3)
    assert dispatch.call_count == 1
    assert dispatch.call_args[0][0] == (
        u'[%s] Skipping fragment 3...' % (fd.FD_NAME))

# Generated at 2022-06-24 11:47:00.378350
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors

    def p(v):
        return '%r' % v

    def pp(v):
        return '%r' % v.params

    def check_extractor(name, test_url, extractor_cls, expected_output):
        return check_extractor_single(name, extractor_cls, expected_output, test_url=test_url)

    def check_extractor_single(name, extractor_cls, expected_output, test_url=None):
        test_url = test_url or '4:oARsZsBMf_E'

# Generated at 2022-06-24 11:47:07.662127
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader

    ydl = FileDownloader({'quiet': True, 'noprogress': True})
    dl = HttpQuietDownloader(ydl, {'quiet': True, 'noprogress': True})
    assert(dl.params['quiet'] == True)
    assert(dl.params['noprogress'] == True)
    assert(dl.ydl.params['quiet'] == True)
    assert(dl.ydl.params['noprogress'] == True)

# Generated at 2022-06-24 11:47:14.004402
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import io

    save_stdout = sys.stdout

    try:
        sys.stdout = io.StringIO()
        quiet_downloader = HttpQuietDownloader(None, {'quiet': True})
        quiet_downloader.to_screen('foo')
        assert sys.stdout.getvalue() == ''
    finally:
        sys.stdout = save_stdout

# Generated at 2022-06-24 11:47:24.468791
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import io
    import sys
    import types
    from .external import FileDownloader

    class DummyYDL(object):
        params = dict()
        def __init__(self):
            pass

    dummy_ydl = DummyYDL()
    dummy_ydl.params['outtmpl'] = '%(id)s.f4m'
    dummy_ydl.params['retries'] = 2
    info_dict = dict()
    info_dict['id'] = '_test'
    info_dict['title'] = 'test'
    info_dict['ext'] = 'f4m'
    info_dict['url'] = 'http://test_url.org/test.f4m'
    info_dict['player_url'] = 'http://test_player_url.org/player.swf'
   

# Generated at 2022-06-24 11:47:28.273648
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # In python 2.6, we should check if an object is a instance of a subclass
    # by using issubclass(HttpQuietDownloader, FileDownloader)
    assert issubclass(HttpQuietDownloader, FileDownloader)


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:47:39.997868
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # pylint: disable=missing-docstring,attribute-defined-outside-init,protected-access
    import unittest
    from .common import FileDownloaderTestBase
    from .extractor import gen_extractor

    @gen_extractor('foo')
    class FakeInfoExtractor(object):
        IE_NAME = 'foo'
        _VALID_URL = r''
        _TEST = {
            'url': 'http://foo.org/video.mp4',
            'info_dict': {
                'id': 'test_id',
            },
        }

        @staticmethod
        def _real_extract(url):
            return FakeInfoExtractor._TEST


# Generated at 2022-06-24 11:47:52.074647
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeYoutubeDL:
        def __init__(self):
            self.params = {}
            self._err_file = None
            self._err_file_opened = False

        def to_stderr(self, message):
            assert not self._err_file_opened
            self._err_file_opened = True
            self._err_file = open(u'unicode_filename\u00E9', 'w')
            self._err_file.write(message)
            self._err_file.close()
            self._err_file_opened = False

    class FakeInfoDict:
        pass

    info_dict = FakeInfoDict()
    ydl = FakeYoutubeDL()
    dl = HttpQuietDownloader(ydl, {'quiet': True})

# Generated at 2022-06-24 11:47:56.266704
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Arrange
    hq = HttpQuietDownloader(None, None)
    hq.to_stdout = True
    hq.verbose = 4

    # Act
    hq.to_screen("Test message")

    # Assert
    # If it does not fail, the test is successful


# Generated at 2022-06-24 11:47:59.418173
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .common import FileDownloader
    from .http import HttpFD
    from .fragment import FragmentFD

    fd = FragmentFD(FileDownloader({'quiet': True}))
    hqd = HttpQuietDownloader(fd, {})
    assert hqd.to_screen('foo') is None

# Generated at 2022-06-24 11:48:04.269692
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    options = {
        'skip_unavailable_fragments': True,
        'keep_fragments': True,
    }
    fragment_fd = FragmentFD({}, options)

    # Skip unavailable fragmets should be true
    assert fragment_fd.params.get('skip_unavailable_fragments')

    # Keep fragments should be true
    assert fragment_fd.params.get('keep_fragments')

# Generated at 2022-06-24 11:48:09.904419
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    out = []
    def to_screen(msg):
        out.append(msg)

    FD = FragmentFD(None, {'continuedl': True, 'quiet': True})
    FD.to_screen = to_screen
    FD.report_skip_fragment(2)

    assert out == ['[download] Skipping fragment 2...']

# Generated at 2022-06-24 11:48:15.766664
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .test_utils import FakeYDL
    ydl = FakeYDL()
    test_fd = FragmentFD(ydl)
    test_fd.to_screen = lambda *args, **kargs: ydl.reported.append(args)
    test_fd.report_skip_fragment(10)
    assert ydl.reported[0] == ('[download] Skipping fragment 10...', )

# Generated at 2022-06-24 11:48:24.595299
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None, None, None)

    class MyHttpFD(HttpFD):
        def __init__(self):
            self.messages = []
            self._screen_file = None

        def to_screen(self, *args, **kargs):
            self.messages.append(args[0])

    fd.ydl = MyHttpFD()
    fd.report_skip_fragment(4)
    assert fd.ydl.messages[0] == '[download] Skipping fragment 4...'


# Generated at 2022-06-24 11:48:27.309320
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {}, None)
    fd.to_screen = lambda *args, **kwargs: args
    assert fd.report_skip_fragment(5) == ('[download] Skipping fragment 5...',)

# Generated at 2022-06-24 11:48:37.503820
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .utils import FakeYDL
    from .extractor import (
        get_info_extractor,
        gen_extractor_classes,
        ListExtractor,
    )
    from .extractor.common import InfoExtractor
    for ie_name, ie in get_info_extractor(gen_extractor_classes()):
        if not ie.suitable(ie_name) or not issubclass(ie, FragmentFD) \
                or issubclass(ie, ListExtractor) or ie == InfoExtractor:
            continue
        ie = ie(FakeYDL())
        ie.report_skip_fragment(10)
        ie.report_skip_fragment(0)
        ie.report_skip_fragment(9)

# Generated at 2022-06-24 11:48:45.199760
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import tempfile
    import youtube_dl.YoutubeDL
    class FakeYoutubedl(object):
        def __init__(self, params):
            self.params = params
        def to_screen(self, message, skip_eol=False):
            sys.stderr.write(message)
        def to_stdout(self, message):
            sys.stdout.write(message)
        def to_stderr(self, message):
            sys.stderr.write(message)
        def report_warning(self, message):
            sys.stderr.write('warning: ' + message + '\n')

# Generated at 2022-06-24 11:48:49.293428
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FakeYDL:
        def to_screen(self, msg):
            print(msg)

    class FakeFD(FragmentFD):
        FD_NAME = 'FakeFD'

    fd = FakeFD(FakeYDL(), {})
    fd.report_skip_fragment(0)

# Generated at 2022-06-24 11:49:01.020735
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)
    assert FragmentFD.__name__ == 'FragmentFD'
    fd = FragmentFD()
    assert fd.FD_NAME == 'generic'
    assert fd.params == {}
    assert fd.ydl is None
    fd = FragmentFD(params={'quiet': True}, ydl={})
    assert fd.params == {'quiet': True}
    assert fd.ydl == {}
    fd = FragmentFD(params={'quiet': True, 'noprogress': True}, ydl={})
    assert fd.params == {'quiet': True, 'noprogress': True}
    assert fd.ydl == {}


if __name__ == '__main__':
    test

# Generated at 2022-06-24 11:49:03.961390
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD

    assert issubclass(FragmentFD, FileDownloader)
    assert not issubclass(FragmentFD, HttpFD)


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:49:06.976514
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Call the method
    hqd = HttpQuietDownloader(None, None)
    hqd.to_screen('Test')

# Generated at 2022-06-24 11:49:18.059086
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    for ie in gen_extractors():
        if ie.IE_NAME in (
                'generic',  # No format_id, causes an error
                'ToutvIE',  # Doesn't work in travis
        ):
            continue
        for url in ie._TEST_CASES:
            fd = FragmentFD(ie, {
                'noprogress': False,
                'quiet': False,
                'simulate': True,
            })
            try:
                fd.real_download(url, {})
            except NotImplementedError:
                assert not ie.IE_NAME in ('GoProIE',)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:49:28.849857
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import types
    class FauxYDL(object):
        def __init__(self):
            self._fd = None

        def set_dl(self, fd):
            self._fd = fd
    ydl = FauxYDL()
    fd = FragmentFD(ydl, {'skip_unavailable_fragments': True})
    ydl.set_dl(fd)
    test_value = 0
    fragment_index = 1
    old_stderr = sys.stderr

# Generated at 2022-06-24 11:49:34.522877
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    expected_output = (
        '[download] Got server HTTP error: Test error. Retrying fragment 99 (attempt 99 of 99)...'
        '\n')

# Generated at 2022-06-24 11:49:35.232623
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-24 11:49:37.041316
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader.FD_NAME == 'http_quiet'

# Generated at 2022-06-24 11:49:44.303414
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    ydl = object()
    params = {
        'logger': ydl.logger,
        'outtmpl': '%(id)s.%(ext)s',
        'nooverwrites': False,
        'continuedl': False,
    }
    ffd = FragmentFD(ydl, params)
    ffd.to_screen = lambda *args, **kargs: args
    assert ffd.report_skip_fragment(0) == (
        '[download] Skipping fragment 0...',)
    assert ffd.report_skip_fragment(3) == (
        '[download] Skipping fragment 3...',)


# Generated at 2022-06-24 11:49:51.835389
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FakeYDL(object):
        def to_screen(self, msg, *args, **kwargs):
            print(msg, *args, **kwargs)

    ydl = FakeYDL()
    fd = FragmentFD(ydl, {})
    fd.to_screen = FakeYDL.to_screen.im_func
    fd.report_skip_fragment(10)


# Generated at 2022-06-24 11:50:02.169712
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from nose.tools import assert_not_equal

    class MockFD(object):
        def __init__(self):
            self.messages = []
            self.to_screen_messages = []

        def trouble(self, message, tb=None):
            self.messages.append(message)
            self.to_screen_messages.append(message)

        def to_screen(self, *args, **kargs):
            self.to_screen_messages.append(args)

    fd = MockFD()

    quiet_dl = HttpQuietDownloader(fd, {})
    quiet_dl.trouble(u'Message')

    assert_not_equal(fd.messages, fd.to_screen_messages)
    assert fd.to_screen_messages == fd.messages

# Generated at 2022-06-24 11:50:05.628806
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # FragmentFD doesn't actually use the URL, it just needs
    # to be NoneType-free. Hence the URL is arbitrary.
    FragmentFD({}, {})


# Unit tests for methods of class FragmentFD

# Generated at 2022-06-24 11:50:10.445960
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # test if youtube-dl is installed correctly
    from ..downloader.common import YoutubeDL
    ydl = YoutubeDL()
    assert ydl
    # test if HttpQuietDownloader class is in the downloader/common.py file
    from ..downloader.common import HttpQuietDownloader
    assert HttpQuietDownloader

# Generated at 2022-06-24 11:50:13.718726
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({})
    dl = HttpQuietDownloader(ydl, {})
    assert dl.ydl is ydl
    assert dl.params == {}



# Generated at 2022-06-24 11:50:20.853263
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fragmentfd = FragmentFD(None, {}, None)
    err = 'test error'
    frag_index = 42
    count = 4
    retries = -1
    assert (fragmentfd.report_retry_fragment(err, frag_index, count, retries)
            == '[download] Got server HTTP error: %s. Retrying fragment %d (attempt %d of %s)...' % (
                error_to_compat_str(err), frag_index, count, fragmentfd.format_retries(retries)))

# Generated at 2022-06-24 11:50:26.125442
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """
    Test for constructor of class HttpQuietDownloader
    """
    try:
        from ..utils import FileDownloader
    except ImportError:
        return

    s = FileDownloader(params={'quiet': True, 'noprogress': True})
    assert isinstance(s.fd, HttpQuietDownloader)

# Generated at 2022-06-24 11:50:33.734425
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    fd = FragmentFD(FileDownloader())
    for count, s in enumerate([1, 2, 3]):
        fd.report_retry_fragment('HTTP Error 404: Not Found', 1, count + 1, s)
    if count != 2:
        assert False, 'report_retry_fragment: expected 2, got %d' % count

# Generated at 2022-06-24 11:50:46.182938
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from collections import namedtuple
    from .extractor import get_info_extractor
    from .extractor import gen_extractor_classes
    from .compat import urllib_parse_urlparse

    # The test requires youtube-dl and FFmpeg for DASH extraction
    ie = get_info_extractor(urllib_parse_urlparse('https://www.youtube.com/watch?v=BaW_jenozKc').scheme)
    assert ie.ie_key() in gen_extractor_classes()

    fd = FileDownloader({'outtmpl': '-'})
    fragfd = FragmentFD(fd, ie)

    # The test runs only on Python 3.3+

# Generated at 2022-06-24 11:50:55.153000
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ret = {}

    class MyLogger(object):
        def debug(self, *args):
            pass

        def warning(self, *msg):
            ret['warning'] = msg

        def fatal(self, *msg):
            ret['fatal'] = msg

    class MyYDL(object):
        params = {}

        def __init__(self):
            self.logger = MyLogger()

    http = HttpQuietDownloader(MyYDL(), {'continuedl': True})
    http.report_warning('foo')
    http.report_fatal('bar')
    assert 'foo' in ret['warning']
    assert 'bar' in ret['fatal']


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:51:06.827390
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import tempfile
    import unittest

    from youtube_dl.downloader.http import HttpDownloader
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.version import __version__

    class TestYoutubeDL(YoutubeDL):
        def report_warning(self, message, tb=None):
            pass

    dl = TestYoutubeDL()
    dl.params['outtmpl'] = tempfile.mkstemp()[1]
    hd = HttpDownloader(dl, dl.params)
    hqd = HttpQuietDownloader(dl, dl.params)
    # http downloader should log to stdout
    self.assertTrue(hd.to_screen)
    # http quiet downloader should not
    self.assertFalse(hqd.to_screen)

# Generated at 2022-06-24 11:51:13.071596
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFD(FragmentFD):
        def to_screen(self, msg, skip_eol=False):
            self._msg = msg
            self._skip_eol = skip_eol
    fd = TestFD(None, {'noprogress': True})
    fd.report_skip_fragment(42)
    assert fd._msg == '[download] Skipping fragment 42...'


# Generated at 2022-06-24 11:51:17.014616
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from StringIO import StringIO
    from test.test_utils import FakeYDL
    fd = HttpQuietDownloader(FakeYDL(), {})
    out = StringIO()
    fd.to_screen('Downloading', _out=out)
    assert out.getvalue() == ''
    out.close()

# Generated at 2022-06-24 11:51:23.692489
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')

    class FragmentFD_UT(FragmentFD):
        def __init__(self):
            self.to_screen_buffer = []

        def to_screen(self, *args, **kargs):
            self.to_screen_buffer.append(*args)

    fd = FragmentFD_UT()
    fd.report_retry_fragment(
        RuntimeError('test'), 1, 2, 3)
    assert fd.to_screen_buffer == [
        u'Got server HTTP error: test. Retrying fragment 1 (attempt 2 of 3)...']

# Generated at 2022-06-24 11:51:31.546921
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    """
    >>> import sys
    >>> import json
    >>> fd = FragmentFD({})
    >>> retval = fd.__class__.__name__
    >>> sys.stdout = sys.stderr = open('/dev/null', 'w')
    >>> main()
    >>> sys.stdout = sys.__stdout__
    >>> sys.stderr = sys.__stderr__
    >>> retval
    'FragmentFD'
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 11:51:39.711754
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Simulate youtube-dl
    fake_YDL = type('FakeYDL', (object,), {
        'params': {}, '_screen_file': open('/dev/null', 'w')})
    frag_fd = FragmentFD(fake_YDL)

    # Test ytdl_filename
    result_filename = frag_fd.ytdl_filename(
        encodeFilename('<@!@#$>:"\'\\/abc.flv'))
    assert result_filename == (encodeFilename(u'<@!@#$>:"\'\\/abc.flv.ytdl'))

# Generated at 2022-06-24 11:51:46.001470
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *x, **y: None
    fd.to_stderr = lambda *x, **y: None
    fd.to_console_title = lambda *x, **y: None
    fd.report_skip_fragment(10)

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:51:56.020709
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import StringIO

    class FakeYDL(object):
        params = {
            'verbose': True,
        }

        def to_screen(self, s):
            print >> sys.stderr, s

    class MyFragmentFD(FragmentFD):
        FD_NAME = 'testfd'

    fragfd = MyFragmentFD(FakeYDL())
    fragfd.report_retry_fragment(Exception('Some error'), 3, 5, 9)
    ref_output = (
        '[testfd] Got server HTTP error: Some error. '
        'Retrying fragment 3 (attempt 5 of 9)...'
    )
    output = sys.stderr.getvalue()
    assert output == ref_output


# Generated at 2022-06-24 11:52:01.934082
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = None
    params = {
        'noprogress': False,
        'logger': None,
        'progress_hooks': [],
    }
    fd = FragmentFD(ydl, params)
    assert fd.FD_NAME == 'fragment'
    assert fd.params == params
    filename = 'filename.ts'
    assert fd.temp_name(filename) == filename + '.part'
    assert fd.ytdl_filename(filename) == filename + '.ytdl'

# Generated at 2022-06-24 11:52:11.370239
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class DummyFD(FragmentFD):
        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, *args, **kargs):
            self.to_screen_calls.append([args, kargs])

    fd = DummyFD()
    fd.report_retry_fragment(
        IOError('Error message'), 1, 2,
        {'max_attempts': 3})

    assert (
        ['[download] Got server HTTP error: Error message. '
         "Retrying fragment 1 (attempt 2 of 3)...", {}] in
        fd.to_screen_calls
    )



# Generated at 2022-06-24 11:52:16.635182
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self, message):
            self.message = message
        def to_screen(self, message, skip_eol=False):
            assert self.message == message
    fd = TestFragmentFD('[download] Skipping fragment 1...')
    fd.report_skip_fragment(1)

# Generated at 2022-06-24 11:52:24.182687
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class YDL:
        def __init__(self):
            self.to_screen_called = False
        def to_screen(self, *args, **kargs):
            self.to_screen_called = True
    success = True
    hqdl = HttpQuietDownloader(YDL(), {'continuedl':True})
    hqdl.to_screen('foo')
    if hqdl.ydl.to_screen_called:
        success = False