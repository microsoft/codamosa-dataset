

# Generated at 2022-06-24 11:42:25.081350
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    def check(prefix, *args, **kwargs):
        obj = FragmentFD()
        obj.out = lambda *a: a
        assert obj.report_retry_fragment(*args, **kwargs)[-1][0].startswith(prefix)
    check('[download] Got server HTTP error: ', IOError('foo'))
    check('[download] Got server HTTP error: ', IOError('foo'), frag_index=0)
    check('[download] Got server HTTP error: ', IOError('foo'), frag_index=0, count=0)
    check('[download] Got server HTTP error: ', IOError('foo'), frag_index=0, count=0, retries=0)



# Generated at 2022-06-24 11:42:34.830935
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys

    class MockLogger(object):
        def debug(self, *args, **kargs):
            pass

        def warning(self, *args, **kargs):
            pass

        def error(self, *args, **kargs):
            pass

    class MockYDL(object):
        params = {}

        def __init__(self):
            self.logger = MockLogger()
            self.to_screen = MockLogger().debug

    ctx = {
        'filename': 'file',
    }

    fd = FragmentFD(ydl=MockYDL(), params={}, ctx=ctx)
    fd._hook_progress = lambda s: sys.stdout.write(str(s) + '\n')
    ctx['total_frags'] = 3
    ctx['dl']

# Generated at 2022-06-24 11:42:42.125036
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    from .common import FileDownloader
    from ..compat import is_py2
    from .fragment import FragmentFD

    class DummyHttpFD(FragmentFD):
        def __init__(self, ydl):
            super(DummyHttpFD, self).__init__(ydl)
            self.to_screen_calls = []

        def to_screen(self, *args, **kargs):
            self.to_screen_calls.append((args, kargs))

    fd = DummyHttpFD(None)

    fd.report_retry_fragment(
        TypeError('TypeError is a dummy error'),
        1, 2, 3)

# Generated at 2022-06-24 11:42:44.939190
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader({})
    assert not hasattr(ydl, 'report_progress')
    assert hasattr(ydl, 'to_screen')
    assert hasattr(ydl, 'to_stderr')
    assert hasattr(ydl, 'to_console_title')

# Generated at 2022-06-24 11:42:49.594926
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(
        {'ydl': None},
        {
            'fragment_retries': 1,
            'noprogress': True,
            'quiet': True,
        }
    )
    class FakeStdout(object):
        def __init__(self):
            self.value = ''
        def write(self, s):
            self.value += s.replace('\r', '')
    stdout = FakeStdout()
    fd.to_screen = stdout.write
    fd.report_retry_fragment(None, 0, 2, 3)
    assert stdout.value == '[download] Got server HTTP error: None. Retrying fragment 0 (attempt 2 of 3)...\n'

# Generated at 2022-06-24 11:42:50.092841
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    FragmentFD(None, None)

# Generated at 2022-06-24 11:42:56.666445
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestFD(HttpQuietDownloader):
        def __init__(self):
            HttpQuietDownloader.__init__(self, None, None)
            self.messages = []

        def to_stderr(self, message):
            self.messages.append(message)

    fd = TestFD()
    fd.to_screen('xyz')
    assert fd.messages == []
    fd.to_screen('Got server HTTP error: %s' % Exception('oops'))
    assert 'oops' in fd.messages[-1]

# Generated at 2022-06-24 11:43:02.762661
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None)
    # Test formatting of exception name and message
    fd.report_retry_fragment(
        URLError(
            error_to_compat_str(u'[Errno 14] HTTP Error 404: Not Found')),
        1, 2, 10)
    fd.report_retry_fragment(
        IOError('[Errno 2]'),
        1, 2, 10)
    # Test formatting of retries
    fd.report_retry_fragment(
        URLError(
            error_to_compat_str(u'[Errno 14] HTTP Error 404: Not Found')),
        1, 2, 1)

# Generated at 2022-06-24 11:43:09.874425
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys

    out = open(os.devnull, 'w')
    assert(out.fileno() > 2)
    old_stdout = sys.stdout
    sys.stdout = out
    t = HttpQuietDownloader(None, {})
    try:
        t.to_screen('test')
        sys.stdout = old_stdout
        assert(out.getvalue() == '')
        assert(False)
    except IOError:
        sys.stdout = old_stdout
        out.close()
        assert(True)

# Generated at 2022-06-24 11:43:13.050384
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeLogger(object):
        def __init__(self):
            self.msg = None

        def debug(self, msg):
            self.msg = msg

    logger = FakeLogger()
    dl = HttpQuietDownloader(None, {'logger': logger})

    dl.to_screen('foo')
    assert logger.msg == 'foo'

# Generated at 2022-06-24 11:43:17.316390
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader({'quiet': True, 'verbose': True}, {}).params['quiet'] is True
    assert HttpQuietDownloader({'quiet': False, 'verbose': True}, {}).params['quiet'] is True

# Generated at 2022-06-24 11:43:23.812985
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class HttpQuietDownloaderTest(HttpQuietDownloader):
        def __init__(self):
            self.last_message = None
        def to_screen(self, message, skip_eol=False):
            self.last_message = message
    dl = HttpQuietDownloaderTest()
    dl.to_screen('test')
    assert dl.last_message == 'test'

# Generated at 2022-06-24 11:43:31.604525
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import pytest
    from tests.test_utils import FakeYDL
    fakescreen = []
    ydl = FakeYDL({'writedescription': True})
    ydl.params['logger'] = fakescreen
    hqd = HttpQuietDownloader(ydl, {'quiet': True})
    hqd.to_screen('message')
    assert fakescreen[0] == 'message'

    # the no-descriptions case
    fakescreen = []
    ydl = FakeYDL({'writedescription': False})
    ydl.params['logger'] = fakescreen
    hqd = HttpQuietDownloader(ydl, {'quiet': True})
    hqd.to_screen('message')
    assert fakescreen == []

# Generated at 2022-06-24 11:43:37.037446
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    for ie_cls in gen_extractor_classes():
        ie_cls.suitable('https://foo.bar/')
        ie_cls('https://foo.bar/', downloader=HttpQuietDownloader(None, None))
        ie_cls('https://foo.bar/', downloader=HttpFD())

# Generated at 2022-06-24 11:43:46.499640
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys

    fd = FragmentFD({}, {})
    fd.to_screen = lambda *args, **kargs: sys.stderr.write(' '.join(args) + '\n')

    err = URLError('message')
    fd.report_retry_fragment(err, 0, 1, 5)
    fd.report_retry_fragment(err, 1, 2, 5)
    fd.report_retry_fragment(err, 2, 3, 5)
    fd.report_retry_fragment(err, 3, 4, 5)
    fd.report_retry_fragment(err, 4, 5, 5)
    fd.report_retry_fragment(err, 5, 6, 5)


# Generated at 2022-06-24 11:43:58.337733
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    ie = get_info_extractor('YoutubeIE')
    ie._downloader = None  # Hack to be able to instantiate downloader without an IE
    downloader = ie._downloader = FragmentFD(ie._ydl, {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': ie._ydl.params.get('ratelimit'),
        'retries': ie._ydl.params.get('retries', 0),
        'nopart': ie._ydl.params.get('nopart', False),
        'test': ie._ydl.params.get('test', False),
    })


# Generated at 2022-06-24 11:44:10.934088
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..downloader.common import FileDownloader

    class FakeYDL(object):
        params = {
            'ratelimit': '20k',
            'retries': 10,
            'nopart': True,
            'test': True,
        }

        def to_screen(self, msg):
            pass

    fd = FileDownloader(FakeYDL(), {'continuedl': True})
    assert isinstance(HttpQuietDownloader(fd, {}), HttpQuietDownloader)
    assert HttpQuietDownloader(fd, {}).params == {
        'continuedl': True, 'quiet': True, 'noprogress': True, 'ratelimit': '20k',
        'retries': 10, 'nopart': True, 'test': True}

# Generated at 2022-06-24 11:44:19.802237
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor_test import BaseTestCase

    class Test(BaseTestCase):
        def setUp(self):
            self.fd = FragmentFD()

    def test_fragment_retries_fmt_zero_retries():
        Test.fd.params['fragment_retries'] = 0
        Test.fd.report_retry_fragment(Exception('Test error'), 1, 1, 0);
        Test.assertRegexpMatches(
            Test.fd.msgs[-1],
            r'^\[download] Got server HTTP error: Test error\. Retrying fragment 1 '
            r'\(attempt 1 of ?\)\n$')


# Generated at 2022-06-24 11:44:31.033112
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FakeYDL
    from .extractor import get_info_extractor

    ydl = FakeYDL()
    fd = FragmentFD(ydl, {})
    assert fd.to_screen_calls == []

    fd.report_skip_fragment(4)
    fd.report_skip_fragment(9)
    assert fd.to_screen_calls == [
        ' [download] Skipping fragment 4...',
        ' [download] Skipping fragment 9...'
    ]

    fd.report_skip_fragment(12)
    assert fd.to_screen_calls == [
        ' [download] Skipping fragment 4...',
        ' [download] Skipping fragment 9...',
        ' [download] Skipping fragment 12...'
    ]



# Generated at 2022-06-24 11:44:35.563914
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFD(FragmentFD):
        def __init__(self):
            self.to_screen_value = ''
        def to_screen(self, *args, **kargs):
            self.to_screen_value = args[0]

        #
        # Helpers
        #

        # Define a class method to easily unit test its output
        @classmethod
        def test_to_screen(cls, expected_value):
            testfd = cls()
            err = RuntimeError()
            testfd.report_retry_fragment(err, 0, 1, 2)
            assert testfd.to_screen_value == expected_value

# Generated at 2022-06-24 11:44:40.727157
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class _FragmentFD(FragmentFD):
        def __init__(self, ydl):
            FragmentFD.__init__(self, ydl)

        def real_download(self, filename, info_dict):
            raise NotImplementedError('subclasses must implement this')
    _FragmentFD(None)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:44:47.659765
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None)
    assert fd.FD_NAME == 'generic'
    assert fd.params is None
    assert fd.ydl is None
    assert fd.to_screen == fd.report_warning

    class TestYDL:
        def __init__(self):
            self.params = {
                'skip_unavailable_fragments': True,
            }

        def to_screen(self, *args, **kargs):
            pass

    ydl = TestYDL()
    fd = FragmentFD(ydl)
    assert fd.params == ydl.params
    assert fd.ydl == ydl
    assert fd.to_screen == ydl.to_screen

# Generated at 2022-06-24 11:44:59.037926
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from tempfile import mkstemp
    from sys import stderr
    from youtube_dl.downloader.common import FileDownloader
    import youtube_dl.downloader.fragment
    import youtube_dl.utils

    (fd1, tmpfile1) = mkstemp()
    (fd2, tmpfile2) = mkstemp()

    old_stderr = youtube_dl.utils.std_err_enc

# Generated at 2022-06-24 11:45:02.778838
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    assert issubclass(HttpQuietDownloader, FileDownloader)
    assert HttpQuietDownloader(None, {})


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:45:13.151007
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    fd = HttpQuietDownloader()
    fd.to_screen('a')
    fd.to_screen('a', 'b')
    fd.to_screen('a', 'b', 'c')
    fd.to_screen('a', 'b', 'c', 'd')
    fd.to_screen('a', 'b', 'c', 'd', 'e')
    fd.to_screen('a', 'b', 'c', 'd', 'e', 'f')
    fd.to_screen('a', 'b', 'c', 'd', 'e', 'f', 'g')
    fd.to_screen('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h')

# Generated at 2022-06-24 11:45:20.033014
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .compat import compat_kwargs

    ie = InfoExtractor()

    def report(*args, **kargs):
        pass

    ie.report = lambda *args, **kargs: None
    dl = HttpQuietDownloader(ie, compat_kwargs({'quiet': True}))
    dl.report = report
    return dl

# Generated at 2022-06-24 11:45:30.977441
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloaderTest
    from .http import HttpFDTest

    class FakeDownloader(FragmentFD):

        def __init__(self, ydl, params):
            super(FakeDownloader, self).__init__(ydl, params)
            self.test_object = FileDownloaderTest()

        def to_screen(self, *args, **kargs):
            return self.test_object.read_file_and_call(
                'FragmentFD_report_retry_fragment.txt',
                'to_screen', *args, **kargs)

    ydl = FakeDownloader(None, {})
    ydl.report_retry_fragment('', 2, 10, 2)
    assert 'Got server HTTP error' in ydl.test_object.pop_line()

# Generated at 2022-06-24 11:45:39.923220
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor

    class IE(InfoExtractor):
        _VALID_URL = r'.*'

        @staticmethod
        def _extract_info(url):
            return ['id']

    ie = IE(gen_extractors())
    ydl = ie._ydl

    # Test 1: successful download
    url = 'http://example.com/'
    tmpfilename = '-'
    info_dict = {
        'url': url,
        'id': 'id',
        'filename': 'test',
        'http_headers': {'Accept-Encoding': 'compress'},
    }

# Generated at 2022-06-24 11:45:50.217694
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    import tempfile

    temp = tempfile.mktemp(prefix='%s-' % __name__, suffix='.m3u8')
    _, tempfilename = sanitize_open(temp, 'wb')
    tempfilename.close()
    expected_filename = 'test'
    class SilentFD(FragmentFD):
        def __init__(self, ydl, params):
            pass
    extractor = get_info_extractor('FragmentFDUnitTest')
    extractor._downloader = SilentFD

# Generated at 2022-06-24 11:45:56.338437
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class DummyYDL:
        def to_screen(self, message, skip_eol=False):
            print(message)
    dummy_ydl = DummyYDL()
    dummy_fd = HttpQuietDownloader(dummy_ydl, {})
    dummy_fd.to_screen('test')

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:45:57.170848
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-24 11:45:59.637379
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    x = HttpQuietDownloader(None, None)
    x.to_screen("this should not appear")
    assert sys.stdout.getvalue() == ''
    sys.stdout.close()

# Generated at 2022-06-24 11:46:02.371456
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {}, {})
    fd.report_skip_fragment(0)


# Generated at 2022-06-24 11:46:08.188691
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys

    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.to_stdout = []

        def to_screen(self, *args, **kargs):
            self.to_stdout.append(args)

    fd = TestFragmentFD()
    fd.report_skip_fragment(7)
    assert fd.to_stdout == [
        ('[download] Skipping fragment 7...',),
    ]


if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:46:16.158352
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class MyFragmentFD(FragmentFD):
        def format_retries_msg(self, retries):
            return '%d times' % retries

    self = MyFragmentFD(
        ydl=None,
        params={},
        info_dict={},
        filename='',
        status_hook=None)

    # Test printing of message on fragment retry
    with_hook = ''
    without_hook = ''
    stream, _ = sanitize_open('/dev/null', 'wb')

# Generated at 2022-06-24 11:46:26.866124
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpDownloader

    class MockInfoExtractor(InfoExtractor):
        def __init__(self, downloader):
            self._downloader = downloader

        @property
        def downloader(self):
            return self._downloader

    class MockYoutubeDL(object):
        params = {}
        verbose = False

        def __init__(self, params):
            self.params = params


# Generated at 2022-06-24 11:46:36.187106
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class HttpQuietDownloaderTest(HttpQuietDownloader):
        def __init__(self, ydl, params):
            self.messages = []
            super(HttpQuietDownloaderTest, self).__init__(ydl, params)

        def to_screen(self, *args, **kargs):
            self.messages.append(args[0] % args[1:])

    with HttpQuietDownloaderTest(None, {}) as dl:
        dl.report_skip_fragment(1)
        dl.report_retry_fragment('b', 3, 4, 5)
        assert dl.messages == [
            '[download] Skipping fragment 1...',
            '[download] Got server HTTP error: b. Retrying fragment 3 (attempt 4 of 5)...',
        ]

# Generated at 2022-06-24 11:46:40.974843
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    from io import StringIO
    sys.stderr = StringIO()
    fd = FragmentFD(None)
    fd.to_screen = fd.report_skip_fragment
    fd.to_screen(0)
    assert sys.stderr.getvalue() == '[download] Skipping fragment 0...\n'



# Generated at 2022-06-24 11:46:47.209719
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..utils import PreparedFakeYDL
    ydl = PreparedFakeYDL()
    fd = FragmentFD(ydl, {})
    fd.to_screen = ydl.fake_to_screen
    fd.report_retry_fragment(
        OSError('error code 123, message'), 5, 2, [3, 5, 8])
    assert "for 5 (attempt 2 of 3, 5, 8)" in ydl.msgs[-1]

# Generated at 2022-06-24 11:46:55.692183
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    global __testurl
    __testurl = 'http://127.0.0.1:8080/'
    ydl = YoutubeDL()
    dl = HttpQuietDownloader(ydl, {'noprogress': True})
    ydl.add_info_extractor(HttpIE(ydl, 'http', '127.0.0.1:8080'))
    dl.download('http://127.0.0.1:8080/test.html')
    assert dl._ydl.get_downloaded_bytes() == 0

# Generated at 2022-06-24 11:46:58.653803
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {}, None)
    fd.to_screen = lambda *a, **k: a
    assert fd.report_skip_fragment(1) == (['[download] Skipping fragment 1...'], {})

# Generated at 2022-06-24 11:47:02.790496
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Sanity checking
    class FragmentFDTest(FragmentFD):
        ydl = None
        params = {}
        FD_NAME = 'fragment'
    assert FragmentFDTest().pprint() == 'fragment'
    assert FragmentFDTest(params={'noprogress': 't'}).pprint() == 'fragment (no progress)'


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:47:14.790621
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import tempfile
    import shutil
    import sys
    from .youtube_dl.YoutubeDL import YoutubeDL
    dl = YoutubeDL({})
    fd = HttpQuietDownloader(dl, {'continuedl': True})
    out, err = sys.stdout, sys.stderr
    try:
        outdir = tempfile.mkdtemp()
        sys.stdout = open(os.path.join(outdir, 'stdout'), 'w')
        sys.stderr = open(os.path.join(outdir, 'stderr'), 'w')
        fd.to_screen('[youtube] test')
    finally:
        sys.stdout = out
        sys.stderr = err
        shutil.rmtree(outdir)


# Generated at 2022-06-24 11:47:19.382143
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        from pytest import raises
    except ImportError:
        def raises(exc):
            def r(f, *args, **kwargs):
                try:
                    f(*args, **kwargs)
                    return False
                except exc:
                    return True
            return r

    dummy = object()
    assert raises(TypeError)(HttpQuietDownloader, dummy, dummy)
    assert raises(TypeError)(HttpQuietDownloader, dummy, {})
    assert raises(TypeError)(HttpQuietDownloader, dummy, {'quiet': False})
    assert raises(TypeError)(HttpQuietDownloader, dummy, {'quiet': dummy})

# Generated at 2022-06-24 11:47:24.468195
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd._retries = 3
    fd.to_screen = lambda *args: args
    assert fd.report_retry_fragment(Exception(), 42, 1, None) == (
        '[download] Got server HTTP error: Exception. Retrying fragment 42 (attempt 1 of 3)...',
    )

# Generated at 2022-06-24 11:47:36.247975
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import logging
    import io
    import sys
    import unittest

    from .common import FileDownloader
    from ..extractor import gen_extractors

    class MyFD(FragmentFD):
        FD_NAME = 'fragfd'
        def __init__(self, ydl, params):
            FragmentFD.__init__(self, ydl, params)
        def real_download(self, filename, info_dict):
            pass

    class TestFragmentFD(unittest.TestCase):
        def setUp(self):
            self.log = logging.getLogger('youtube_dl.test.FragmentFD')
            gen_extractors()

        def test_sanity(self):
            # Test the basics of report_retry_fragment
            self.log.warning('Test sanity')

           

# Generated at 2022-06-24 11:47:48.500246
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    import tempfile
    import shutil
    import json

    class TestFragmentFD(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tmpdir, 'tmp')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)


# Generated at 2022-06-24 11:47:55.615738
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = object()
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.params['quiet']
    # with quite = True to_screen shouldn't print anything
    dl.to_screen('test')  # shouldn't do anything

    dl = HttpQuietDownloader(ydl, {'quiet': False})
    assert not dl.params['quiet']
    # with quite = False to_screen should print "test"
    dl.to_screen('test')  # should print "test"


# Generated at 2022-06-24 11:47:56.237514
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-24 11:48:01.803507
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)
    fd = FragmentFD()
    assert fd.params is not None
    assert hasattr(fd, '_start_frag_download')
    assert hasattr(fd, '_prepare_frag_download')
    assert hasattr(fd, '_download_fragment')

# Generated at 2022-06-24 11:48:06.094160
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader

    class TestFD(FragmentFD):
        def __init__(self):
            self.to_screen_value = None
            self.params = {}

        def to_screen(self, message, skip_eol=False):
            self.to_screen_value = message

    test_fd = TestFD()
    test_fd.report_skip_fragment(0)
    assert test_fd.to_screen_value == '[download] Skipping fragment 0...'

# Generated at 2022-06-24 11:48:18.801351
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    import os

    class TestFragmentFD(unittest.TestCase):
        def setUp(self):
            self.temp_file = 'test-fragment-fd'

        def tearDown(self):
            try:
                os.remove(encodeFilename(self.temp_file))
            except OSError:
                pass

        def test_constructor(self):
            f = FragmentFD(None, {'noprogress': True, 'logger': None})
            f.report_destination(self.temp_file)

            # The file should not exist
            self.assertFalse(os.path.isfile(self.temp_file))

            # Start downloading

# Generated at 2022-06-24 11:48:22.280397
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..downloader.common import FileDownloader
    fd = FileDownloader({})
    hqd = HttpQuietDownloader(fd, {})
    assert hqd.progress_hooks == []
    assert hqd.params['continuedl'] == True
    assert hqd.params['quiet'] == True
    assert hqd.params['noprogress'] == True

# Generated at 2022-06-24 11:48:26.402008
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .common import FileDownloader
    fd = FileDownloader({}, {})
    fd.add_info_extractor(gen_extractors())
    hd = HttpQuietDownloader(fd, {'noprogress': True})
    assert isinstance(hd, HttpQuietDownloader)

# Generated at 2022-06-24 11:48:37.320835
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    import tempfile
    import shutil
    import sys

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-24 11:48:43.955418
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import youtube
    class DummyYDL(object):
        def __init__(self, params):
            self.params = params
            self.extractor = youtube
        def to_screen(self, *args, **kargs):
            pass
    ydl = DummyYDL({})
    ffd = FragmentFD(ydl, {})
    assert ffd.params == {}
    assert ffd.ydl == ydl
    assert ffd.max_fragment_retries == 10
    assert ffd.retries == 0

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:48:46.436370
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None)
    fd.to_screen = lambda *args, **kwargs: None
    fd.report_skip_fragment(4)



# Generated at 2022-06-24 11:48:49.850255
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import youtube_dl.FileDownloader

    ydl = youtube_dl.FileDownloader({})
    dl = HttpQuietDownloader(ydl, {'quiet': True, 'noprogress': True})
    assert dl.params['logger'] == ydl.logger, 'unexpected logger instance'
    assert dl.params['progress_hooks'] == []

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:48:54.561220
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    d = HttpQuietDownloader(youtube_dl.YoutubeDL({}))
    assert d.params['logger'] is d.ydl


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:48:59.788648
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert issubclass(HttpQuietDownloader, FileDownloader)

# Generated at 2022-06-24 11:49:07.479150
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeYDL:
        def __init__(self, ydl):
            self.fake_ydl = ydl

        def to_screen(self, *args, **kargs):
            self.fake_ydl.report_message(*args, **kargs)

    class FakeYDL2:
        def __init__(self):
            self.messages = []

        def report_message(self, *args, **kargs):
            self.messages.append((args, kargs))

    # Verify that `to_screen` is not called
    ydl = FakeYDL2()
    dl = HttpQuietDownloader(FakeYDL(ydl), {'quiet': False})
    dl.to_screen('test')
    assert len(ydl.messages) == 0

    # Verify that `to_

# Generated at 2022-06-24 11:49:15.452523
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # Mock
    class FragmentFD_Mock(FragmentFD):
        def __init__(self):
            self.messages = []
        def to_screen(self, *args, **kargs):
            self.messages.append(args)

    fragmentfd = FragmentFD_Mock()
    fragmentfd.report_skip_fragment(1)
    assert len(fragmentfd.messages) == 1
    assert 'Skipping fragment 1...' in fragmentfd.messages[0][0]

# Generated at 2022-06-24 11:49:26.850242
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from pytest import raises
    from youtube_dl.compat import compat_HTTPError, compat_str

    # Number of retries is not a number
    with raises(TypeError):
        FragmentFD._report_retry_fragment(None, None, None, None)

    # Number of retries is a number
    error_message = compat_str('Error message')
    error = compat_HTTPError('url', 500, error_message, {'content-type': 'text/html'}, None)
    s = FragmentFD(None, None)
    s.to_screen = lambda *args, **kwargs: args

# Generated at 2022-06-24 11:49:28.851561
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = object()
    hqd = HttpQuietDownloader(ydl, {})
    assert ydl.to_screen('output') == True

# Generated at 2022-06-24 11:49:38.970466
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpQuietDownloader
    from .extractor.common import InfoExtractor
    class FakeYDL(object):
        params = {}
        def __init__(self):
            self.extractor = InfoExtractor()

    FakeYDL.params['verbose'] = False
    FakeYDL.params['quiet'] = True
    FakeYDL.params['retries'] = 42

    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {'prefix': '42'})
    assert dl.params['quiet'] is True
    assert dl.params['retries'] == 42
    assert dl.ydl is ydl
    assert dl.ydl.extractor.IE_NAME == 'generic'

# Generated at 2022-06-24 11:49:45.315065
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # pylint: disable=attribute-defined-outside-init
    class DummyYDL:
        def __init__(self):
            self.to_screen_nums = []

        def to_screen(self, *args, **kargs):
            self.to_screen_nums.append(args[0])

    class DummyFD(HttpQuietDownloader):
        def __init__(self):
            self.ydl = DummyYDL()

    dl = DummyFD()
    dl.to_screen('%d %d' % (1, 2))
    assert not dl.ydl.to_screen_nums
    dl.params['verbose'] = True
    dl.to_screen('%d %d' % (3, 4))
    assert dl.ydl.to_

# Generated at 2022-06-24 11:49:47.419316
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_downloader = HttpQuietDownloader({}, {})

# Generated at 2022-06-24 11:49:58.489882
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    tdata = {'ydl': {'params': {}}, 'filename': 'test'}
    fd = FragmentFD(tdata['ydl'], tdata)
    fd.to_screen = lambda *args: (None, args)
    assert (
        fd.report_retry_fragment(
            'test_err',
            42,
            2,
            'test_max_retries') ==
        None and
        fd.to_screen.call_args[0][0] ==
        '[download] Got server HTTP error: test_err. Retrying fragment 42 (attempt 2 of test_max_retries)...'
    )



# Generated at 2022-06-24 11:50:00.760521
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader(1, 2)

# Generated at 2022-06-24 11:50:05.467971
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    out = sys.stdout
    try:
        sys.stdout = open('/dev/null', 'w')
        HttpQuietDownloader().to_screen('[download] test')
    finally:
        sys.stdout = out

# Generated at 2022-06-24 11:50:12.879579
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..downloader.http import HttpDownloader
    from ..YoutubeDL import YoutubeDL

    youtube_dl = YoutubeDL({})
    dl = HttpQuietDownloader(
        youtube_dl, {
            'continuedl': True,
            'quiet': False,
            'noprogress': False,
            'ratelimit': None,
            'retries': 0,
            'nopart': False,
            'test': False,
        }
    )
    assert dl._opts['quiet'] == True
    assert dl._opts['noprogress'] == True

# Generated at 2022-06-24 11:50:13.498668
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-24 11:50:24.333367
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import six
    import io

    def check_message(msg):
        assert msg in ('[download] Skipping fragment 6...\n',
                       '[download] Skipping fragment 6...\n\n')

    fd = FragmentFD({
        'verbose': True,
        'outtmpl': '%(id)s.%(ext)s',
        'noprogress': True,
        'progress_hooks': [lambda d: check_message(d['_msg'])],
    })
    # Ignore stderr
    saved_stderr = sys.stderr
    sys.stderr = io.open(os.devnull, 'w')
    try:
        fd.report_skip_fragment(6)
    finally:
        sys.stderr = saved_st

# Generated at 2022-06-24 11:50:30.709567
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class YDL:
        def __init__(self):
            self.params = {}
            self.to_screen = lambda *args, **kargs: None
    ydl = YDL()
    fd = HttpQuietDownloader(ydl, {})
    fd.to_screen('one', 'two', 'three')

# Generated at 2022-06-24 11:50:40.826138
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    def test_verbosity(int_opts, msg_expect):
        params = {
            'verbose': int_opts[0],
            'quiet': int_opts[1],
            'no_progress': int_opts[2],
        }
        fder_obj = FragmentFD(
            object(),
            params=params,
        )
        retries = {
            'max': 10,
        }
        fder_obj.report_retry_fragment(
            'error name',
            2,
            7,
            retries,
        )
        assert fder_obj.msgs == msg_expect

    test_verbosity((0, 0, 0), ['[fragment] Got server HTTP error: error name. Retrying fragment 2 (attempt 7 of 10)...'])
   

# Generated at 2022-06-24 11:50:45.596466
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        FD_NAME = 'test'
    test_fd = TestFD()
    assert test_fd.params.get('skip_unavailable_fragments')


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:50:54.929598
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys

    sys.modules['__main__'].__dict__.clear()
    sys.modules['__main__'].Params().parse()

    x = FragmentFD('some-url', {}, {})
    assert x.params.get('fragment_retries') is None
    assert x.params.get('skip_unavailable_fragments') is None
    assert not x.params.get('keep_fragments')
    assert x.ydl is not None
    assert len(x.progress_hooks) == 0
    x.add_progress_hook(lambda d: None)
    assert len(x.progress_hooks) == 1
    x.to_screen('message')


# Generated at 2022-06-24 11:50:57.189178
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-24 11:51:08.994933
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.compat import compat_urllib_request
    from types import SimpleNamespace
    hqd = HttpQuietDownloader(
        SimpleNamespace(params={}),
        SimpleNamespace(youtubeDL=YoutubeDL(YoutubeIE(), {'skip_download': True}),
                        progress_hooks=[],
                        params={'nooverwrites': True}))


# Generated at 2022-06-24 11:51:14.775198
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    fd.params['skip_unavailable_fragments'] = True
    buf = []
    fd.to_screen = lambda s: buf.append(s)
    fd.report_skip_fragment(0)
    assert buf == []
    fd.report_skip_fragment(1)
    assert buf == ['[download] Skipping fragment 1...']



# Generated at 2022-06-24 11:51:20.682568
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=protected-access
    keep_tmpfiles = ['-keep-fragments', '--keep-fragments']
    for keep_tmpfiles_param in keep_tmpfiles:
        params = {'keep_fragments': (keep_tmpfiles_param in keep_tmpfiles)}
        downloader = HttpQuietDownloader(None, params)
        assert downloader._params['keep_fragments'] == (keep_tmpfiles_param in keep_tmpfiles)


# Generated at 2022-06-24 11:51:26.757309
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestFD(HttpQuietDownloader):
        def __init__(self, params):
            self.params = params
            self.to_screen_value = None
            super(TestFD, self).__init__(None, params)

        def to_screen(self, *args, **kargs):
            self.to_screen_value = (args, kargs)

    # Ensure nothing is printed to the screen
    params = {'verbose': False, 'quiet': True, 'no_progress': True}
    fd = TestFD(params)
    download = HttpQuietDownloader.process_info(fd, {}, {'url': 'http://example.org/'})
    assert fd.to_screen_value is None
    download.report_progress(downloaded_bytes=1024, total_bytes=2048)

# Generated at 2022-06-24 11:51:35.881813
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import io
    import unittest
    from ytdl.extractor import YoutubeIE
    from ytdl.downloader.common import FileDownloader
    from .http import HttpFD
    from .common import SameFileError
    from .fragment import FragmentFD

    class DummyFD(HttpFD, FragmentFD):
        FD_NAME = 'dummy'

    file_size = 100 * 1024 * 1024  # 100 megabytes
    url = 'http://localhost:8080/100M'

    class MockServer(object):
        def run(self):
            self.server = HTTPServer(('localhost', 8080), self.Handler)
            self.server.serve_forever()

        class Handler(BaseHTTPRequestHandler):
            def do_HEAD(s):
                s.send_response(200)

# Generated at 2022-06-24 11:51:40.763594
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {})
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(ValueError('test'), 1, 2, (1, 2, 3)) == (
        '[download] Got server HTTP error: test. Retrying fragment 1 (attempt 2 of 3)...',)



# Generated at 2022-06-24 11:51:44.447828
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # FragmentFD is an abstract base class, so we need a derive class
    class TestFD(FragmentFD):
        pass

    fd = TestFD(None, {'foo': 'bar'})
    assert fd.params == {'foo': 'bar'}

# Generated at 2022-06-24 11:51:46.096124
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(None, None)

# Generated at 2022-06-24 11:51:48.682428
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)



# Generated at 2022-06-24 11:51:55.325873
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    original_download_json = gen_extractor.download_json
    def restore_download_json():
        gen_extractor.download_json = original_download_json
    gen_extractor.download_json = lambda self, url: '{}'
    try:
        from ..extractor import YoutubeDL
        assert HttpQuietDownloader(YoutubeDL())
    finally:
        restore_download_json()
test_HttpQuietDownloader()

# Generated at 2022-06-24 11:51:59.893127
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # pylint: disable=protected-access
    ydl = None
    params = None
    frag_fd = FragmentFD(ydl, params)
    for index in (1, 100, 1000):
        frag_fd._report_skip_fragment(index)

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:52:11.184633
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    def test_report_retry_fragment(errno, expected_stderr, fragment_index=12, count=1, retries=10):
        ydl = object()
        frag_fd = FragmentFD(ydl, {
            'fragment_retries': retries,
            'noprogress': True,
            'quiet': True,
        })
        frag_fd.to_stderr = lambda *args, **kargs: None
        frag_fd.report_retry_fragment(errno, fragment_index, count, retries)
        assert frag_fd.to_stderr_str == expected_stderr

    test_report_retry_fragment(None, '')
    test_report_retry_fragment(Exception, '')
    test_report_

# Generated at 2022-06-24 11:52:19.341057
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl
    ydl = youtube_dl.YoutubeDL()
    HttpQuietDownloader(ydl, {'noprogress': True})
    HttpQuietDownloader(ydl, {'noprogress': False})
    HttpQuietDownloader(ydl, {'quiet': True})
    HttpQuietDownloader(ydl, {'quiet': False})
    HttpQuietDownloader(ydl, {})
    try:
        HttpQuietDownloader(ydl, {'quiet': True, 'noprogress': False})
    except SystemExit:
        pass
    else:
        assert False