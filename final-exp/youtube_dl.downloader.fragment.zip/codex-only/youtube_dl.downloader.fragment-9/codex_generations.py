

# Generated at 2022-06-24 11:42:25.164819
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MockYDLSetup(object):
        def __init__(self):
            self.params = {}

        @staticmethod
        def report_error(message, tb):
            pass

        @staticmethod
        def to_screen(message, skip_eol=None):
            pass

        @staticmethod
        def trouble(message, tb=None):
            pass

    class FragmentFDCheck(FragmentFD):
        def __init__(self):
            self.ydl = MockYDLSetup()
            FragmentFD.__init__(self)
            self.to_screen = None

    assert FragmentFDCheck().params['keep_fragments'] is False

# Generated at 2022-06-24 11:42:28.510740
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader(None, {'quiet': True})
    assert dl.params['quiet']
    assert not dl.params['noprogress']


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:42:32.605386
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # pylint: disable=protected-access
    fd = FragmentFD({})
    fd._screen_file = open(os.devnull, 'w')
    fd.to_stderr = fd.to_screen
    for frag_index in range(4, 8):
        fd.report_skip_fragment(frag_index)
    fd._screen_file.close()
    # pylint: enable=protected-access


# Generated at 2022-06-24 11:42:35.057196
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = object()
    params = {
        'noprogress': True,
        'no_color': True,
    }
    dl = HttpQuietDownloader(ydl, params)
    assert dl._write_string('foo') == ''

# Generated at 2022-06-24 11:42:39.866378
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MockFD(FragmentFD):
        def to_screen(self, msg):
            self.msg = msg
    fd = MockFD({'skip_unavailable_fragments': True}, lambda d: True)
    fd.report_skip_fragment(5)
    assert fd.msg == '[download] Skipping fragment 5...'

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:42:45.686968
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {})
    assert fd.format_retries(5) == '5'
    assert fd.format_retries(10) == '10'
    assert fd.format_retries(500) == '500'
    assert fd.format_retries(0) == 'infinite'

if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:42:52.736180
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestHttpQuietDownloader(HttpQuietDownloader):
        def to_screen(self, *args, **kargs):
            TestHttpQuietDownloader.screen_data = args, kargs

    TestHttpQuietDownloader.screen_data = tuple()
    TestHttpQuietDownloader.download(TestHttpQuietDownloader(None, {}), None, None)
    assert TestHttpQuietDownloader.screen_data == tuple()

# Generated at 2022-06-24 11:42:55.260217
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    fd = FragmentFD(None)
    fd.to_screen = sys.stdout.write
    fd.report_retry_fragment(None, 5, 2, (1, 10))

# Generated at 2022-06-24 11:43:00.434412
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import io
    import unittest

    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    class _FragmentFD(FragmentFD):
        params = {
            'skip_unavailable_fragments': False,
            'keep_fragments': True,
        }

        def __init__(self):
            FragmentFD.__init__(self, None)

        def to_screen(self, message, skip_eol=False):
            self.message = message
            self.skip_eol = skip_eol

    old_stderr = sys.stderr
    sys.stderr = sys.stdout = io.BytesIO()

# Generated at 2022-06-24 11:43:10.976970
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Prepare a test downloader and a string stream
    fd = HttpQuietDownloader(None, None)
    output_stream = unicode('')

    # Create a function to capture screen output
    def print_unicode(text):
        global output_stream
        output_stream += text

    # Assign default stream to the downloader
    fd.to_screen = print_unicode

    # Test printing to the screen with default stream
    fd.to_screen()
    assert output_stream == unicode('')
    fd.to_screen(None)
    assert output_stream == unicode('')
    fd.to_screen(unicode(''))
    assert output_stream == unicode('')
    fd.to_screen(unicode('a'))
    assert output_stream == unic

# Generated at 2022-06-24 11:43:15.464631
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    from .fragment import FragmentFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)
    fd = FragmentFD(None, None)
    assert not fd.params.get('extract_flat')
    assert fd.params.get('nooverwrites')

# Generated at 2022-06-24 11:43:26.789928
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # Create mock object for class FileDownloader
    fd = FragmentFD({'verbose': True})
    fd.to_screen = lambda x: x # Redirect print output to variable
    err = (None, '', '')
    # Output should be:
    #   [download] Got server HTTP error: '' (caused by None). Retrying fragment 1 (attempt 1 of 3)...
    assert fd.report_retry_fragment(err, 1, 1, 3) == 'Got server HTTP error: \"\" (caused by None). Retrying fragment 1 (attempt 1 of 3)...'
    # Output should be:
    #   [download] Skipping fragment 1...
    assert fd.report_skip_fragment(1) == 'Skipping fragment 1...'

# Generated at 2022-06-24 11:43:29.772071
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {}, None)
    out = fd.report_skip_fragment(3)
    assert out == None


# Generated at 2022-06-24 11:43:39.304756
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_calls = []
            self.params = {
                'keep_fragments': True
            }
            FileDownloader.__init__(self, {}, {})

        def to_screen(self, message, skip_eol=False, check_quiet=False):
            self.to_screen_calls.append(message)

        def report_destination(self, filename):
            self.to_screen_calls.append('[Destination: ' + filename + ']')

        def report_warning(self, message):
            self.to_screen_calls.append('[warning]' + message)

        def temp_name(self, filename):
            return 'temp_' + filename


# Generated at 2022-06-24 11:43:47.694559
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock
    # Mock some object that implements to_screen method
    mock_to_screen = Mock()
    # Create object of FragmentFD class
    fd = FragmentFD(Mock(), {'retries': 10})
    # redirect to_screen method of FragmentFD class to mock object
    fd.to_screen = mock_to_screen
    # call report_retry_fragment method
    fd.report_retry_fragment(Mock(), 3, 1, 10)
    # check that to_screen method of mock object was called
    mock_to_screen.assert_called_once()

# Generated at 2022-06-24 11:43:54.661607
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import re
    import io
    from .common import FileDownloader
    from .extractor.common import InfoExtractor

    sio = io.BytesIO()
    out_stream = io.TextIOWrapper(sio)

    class MockYDL(object):
        params = {}
        outtmpl = '%(id)s'
        def to_screen(self, message, **_):
            out_stream.write(message + '\n')
            out_stream.flush()

    test_values = (
        (14, '14'),
        (100, '100'),
    )

    class TestFragmentFD(FragmentFD):
        def __init__(self, ydl):
            super(TestFragmentFD, self).__init__(ydl)

# Generated at 2022-06-24 11:43:57.976186
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None)
    assert fd.params == {}


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:44:11.247579
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # pylint: disable=R0904,W0212
    class _FakeInfo(object):
        def __init__(self, params):
            self.params = params

    ydl = object()
    params = {}
    test_fd = FragmentFD(ydl, params)
    test_fd.to_screen = lambda *args, **kargs: (args, kargs)
    # pylint: enable=R0904,W0212
    test_fd.add_info_dict({'id': 'id1'})
    info = test_fd._fake_info_dict({})
    test_fd.add_info_dict({'id': 'id2'})
    info2 = test_fd._fake_info_dict({})

# Generated at 2022-06-24 11:44:16.082212
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader

    fd = FragmentFD(FileDownloader({'skip_download': True, 'quiet': True}), {})
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_skip_fragment(123) == ('[download] Skipping fragment 123...',)



# Generated at 2022-06-24 11:44:26.074225
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    test_class = FragmentFD(None, None)
    test_class.params = {
        'noprogress': True,
        'retries': 4,
    }
    # test zero fragment retries
    test_class.report_retry_fragment(Exception, 0, 1, 0)
    # test all fragment retries used up
    test_class.report_retry_fragment(Exception, 0, 4, 0)
    # test retries left
    test_class.report_retry_fragment(Exception, 0, 3, 0)
    # test fragment index larger than zero
    test_class.report_retry_fragment(Exception, 1, 2, 0)

# Generated at 2022-06-24 11:44:30.943863
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    reporter = FragmentFD(None, {'format': 'mp4'})
    reporter.to_screen = lambda x: x
    assert ('[download] Got server HTTP error: 404. '
            'Retrying fragment 3 (attempt 4 of 10)...') == reporter.report_retry_fragment(
                Exception("404"), 3, 4, 10)

# Generated at 2022-06-24 11:44:36.117945
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {}, None)
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(
        OSError(2, 'No such file or directory'),
        4, 2, 3) == (
        '[download] Got server HTTP error: No such file or directory. '
        'Retrying fragment 4 (attempt 2 of 3)...',)
    fd.to_screen = lambda *args, **kargs: kargs
    assert fd.report_retry_fragment(
        OSError(2, 'No such file or directory'),
        4, 2, 3) == {'same_file': True}

# Generated at 2022-06-24 11:44:39.994335
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from ..utils import FakeLogger
    fd = FragmentFD(FakeLogger())
    fd.to_screen = lambda *args, **kargs: FakeLogger.infos.append(args[0])
    fd.report_skip_fragment(12345)
    assert FakeLogger.infos[-1] == '[download] Skipping fragment 12345...'

# Generated at 2022-06-24 11:44:47.634852
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    d = FragmentFD(None, {'ydl_filename': 'test_filename'})

    # Test _get_info
    assert d._get_info() == {'ydl_filename': 'test_filename'}

    # Test _prepare_and_start_frag_download
    def report_warning(msg):
        assert msg == 'Inconsistent state of incomplete fragment download. Restarting from the beginning...'

    def report_destination(msg):
        assert msg == 'test_filename'

    def temp_name(msg):
        assert msg == 'test_filename'
        return 'temp_filename'

    def report_progress(msg):
        assert msg == {'downloaded_bytes': 0, 'total_bytes': 0, 'filename': 'temp_filename', 'status': 'finished', 'elapsed': 0}



# Generated at 2022-06-24 11:44:55.471732
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class DummyFD(FragmentFD):
        def _start_frag_download(self, ctx):
            pass

    fd = DummyFD({'quiet': True})
    fd.report_retry_fragment(Exception('error'), 2, 3, 3)
    fd.report_retry_fragment(Exception('error'), 2, 3, 0)

if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:45:00.651634
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # Test it without retry count
    out = u'Got server HTTP error: Unsupported protocol "https". Retrying fragment 2...'
    fd = FragmentFD(None, None)
    fd.to_screen = lambda s: s
    assert fd.report_retry_fragment(
            u'Unsupported protocol "https"', 2, None, None) == out

# Generated at 2022-06-24 11:45:01.932152
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader({}, {})

# Generated at 2022-06-24 11:45:05.848385
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def run_test(self):
        if hasattr(FragmentFD, 'do_test'):
            FragmentFD.do_test(self)
        else:
            self.fail('FragmentFD has no do_test()')

    return {'command': '', 'module': '', 'run': run_test}

# Generated at 2022-06-24 11:45:09.805780
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFragmentFD(FragmentFD):
        FD_NAME = 'test'

    tf = TestFragmentFD({})
    assert tf.params == {}
    assert tf.downloaded_bytes == 0
    # TODO: implement proper testing for this class

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:45:20.442137
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor import get_info_extractor
    ie = get_info_extractor('Dummy')
    dl = HttpQuietDownloader(ie._ydl, {'continuedl': True, 'quiet': True, 'noprogress': True, 'retries': 10})
    if not isinstance(dl, HttpQuietDownloader):
        sys.exit(1)
    if dl.params['continuedl'] != True or dl.params['quiet'] != True or dl.params['noprogress'] != True or dl.params['retries'] != 10:
        sys.exit(1)

# Generated at 2022-06-24 11:45:28.935501
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FragmentFDTest(FragmentFD):
        def __init__(self):
            self.to_screen_args = []

        def to_screen(self, *args, **kargs):
            self.to_screen_args.append((args, kargs))

    fd = FragmentFDTest()
    fd.report_skip_fragment(1)
    assert fd.to_screen_args == [(('[download] Skipping fragment 1...',), {})], fd.to_screen_args

# Generated at 2022-06-24 11:45:35.111368
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE

    ie = InfoExtractor(YoutubeIE.ie_key())
    ie._downloader = HttpQuietDownloader(ie._downloader.ydl, ie._downloader._default_params())
    ie._downloader.to_screen('message')


if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:45:42.649914
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    class FakeYDL:
        def __init__(self):
            self.to_screen_called_with = []
        def to_screen(self, *args, **kargs):
            self.to_screen_called_with.extend(list(args))
    ydl = FakeYDL()
    fd = FragmentFD(ydl, {'nooverwrites': True})

    # Check that if retry count is not specified, default
    # value is used
    fd.report_retry_fragment(Exception, 1, 1, None)
    assert ydl.to_screen_called_with == [
        '[download] Got server HTTP error: Exception. Retrying fragment 1 (attempt 1 of 10)...']

    del ydl.to_screen_called_with[:]

    # Check that

# Generated at 2022-06-24 11:45:51.655393
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import io
    import sys
    import time
    from ..extractor import get_info_extractor

    def format_seconds(t):
        return time.strftime('%H:%M:%S', time.gmtime(t))

    class FakeYDL:
        def __init__(self):
            self.tmpfilename = 'tmpfilename'
            self.to_screen_lock = False
            self.params = {}
            self.progress_hooks = []

        def to_screen(self, *args, **kargs):
            pass

        def params(self, *args, **kargs):
            return self.params

        def temp_name(self, *args, **kargs):
            return self.tmpfilename

        def add_progress_hook(self, *args, **kargs):
            self.progress_hook

# Generated at 2022-06-24 11:45:59.545864
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..compat import compat_HTTPError
    from .common import FileDownloader
    err = compat_HTTPError('http://www.youtube.com', 400, 'Bad Request', {}, None)
    ydl = FileDownloader(params={})
    ydl.to_screen = lambda *args, **kargs: args
    ydl.format_retries = lambda a: '5'
    ydl.report_retry_fragment(err, 2, 1, 5) == (
        '[download] Got server HTTP error: 400 Bad Request. Retrying fragment 2 (attempt 1 of 5)...',)

# Generated at 2022-06-24 11:46:11.690845
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import unittest

    class FakeYDL(object):
        def __init__(self):
            self.to_screen_buffer = []

        def to_screen(self, *args):
            self.to_screen_buffer.append(args)

    class TestReportRetryFragment(unittest.TestCase):
        def setUp(self):
            self.fd = FragmentFD(FakeYDL(), {})

        def test_report_retry_fragment_ok(self):
            self.fd.report_retry_fragment(Exception('text'), 42, 1, 4)

# Generated at 2022-06-24 11:46:24.297474
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..compat import compat_HTTPError
    from ..utils import UnavailableVideoError
    import sys

    def to_screen(self, *args, **kargs):
        print(*args)

    def format_retries(self, retries):
        return '2'

    FragmentFD.report_retry_fragment = test_FragmentFD_report_retry_fragment
    FragmentFD.to_screen = to_screen
    FragmentFD.format_retries = format_retries

    # Test basic message
    fragment_fd = FragmentFD(None, None)
    fragment_fd.report_retry_fragment(
        compat_HTTPError('http://example.org', 500, 'Internal Server Error', {}, None),
        2, 1, 2)
    assert sys.stdout.getvalue

# Generated at 2022-06-24 11:46:26.009090
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-24 11:46:29.189847
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .downloader import get_suitable_downloader
    dl = get_suitable_downloader('http://www.example.com')
    assert isinstance(dl, HttpQuietDownloader)

# Generated at 2022-06-24 11:46:37.164120
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import youtube_dl.YoutubeDL
    ydl_opts = {
        'noprogress': True,
        'logger': youtube_dl.YoutubeDL.FileDownloader.std_headers.get('User-Agent'),
        'outtmpl': '%(id)s',
    }
    fd = FragmentFD(ydl_opts, {
        'protocol': 'http',
        'extractor': 'test',
        'fragment_count': 1,
    })
    return fd

# Generated at 2022-06-24 11:46:39.690407
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    downloader = HttpQuietDownloader({'quiet': True})
    assert downloader.QUIET


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:46:46.714035
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()

    fd.to_screen = lambda *args, **kargs: os.write(1, ' '.join(args))
    fd.report_retry_fragment(
        Exception('This is an error'),
        2,
        1,
        {'max_ad': 0, 'max_frag': 15})
    assert os.read(1, 1024) == '\n'.join([
        '[download] Got server HTTP error: This is an error. Retrying fragment 2 (attempt 1 of 15)...'
    ]) + '\n'

# Generated at 2022-06-24 11:46:51.165559
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader({})
    assert ydl.params['continuedl']
    assert ydl.params['quiet']
    assert ydl.params['noprogress']
    assert ydl.params['nopart']

# Generated at 2022-06-24 11:47:00.758863
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD

    class FileDownloaderSubclass(FileDownloader):
        FD_NAME = 'fake'
    dl = FileDownloaderSubclass({})
    for name, fd_class in [('http', HttpFD), ('dash', DASHFD), ('hls', HLSFD)]:
        fd = fd_class({})
        fd.to_screen = dl.to_screen
        assert fd.report_skip_fragment(1) == True
        assert fd.report_skip_fragment(123) == True
        assert fd.report_skip_fragment(0) == True

# Generated at 2022-06-24 11:47:12.312141
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import os
    import tempfile
    from types import MethodType
    from .common import FileDownloader

    class DummyFD(FileDownloader):
        def __init__(self, ydl, params, partial=False):
            super(DummyFD, self).__init__(ydl, params)
            self._screen_file = tempfile.NamedTemporaryFile(delete=False)
            self.to_screen = MethodType(FragmentFD.to_screen.im_func, self)

        def report_destination(self, filename):
            pass

        def _hook_progress(self, status):
            pass

    fd = DummyFD(None, {})
    fd.report_retry_fragment(None, 1, 1, (1, 0, 0))
    fd.report_retry_fr

# Generated at 2022-06-24 11:47:18.589570
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import io
    import mock
    sys.stderr = io.StringIO()
    mock_message = 'Mock error message'

    fd = FragmentFD()
    fd.to_screen = mock.Mock()
    fd.format_retries = mock.Mock(return_value=mock_message)

    err = fd.report_retry_fragment(
        None, 1, 2, {'max_attempts': 3, 'impossible': True})
    assert fd.to_screen.call_count == 1
    assert mock_message in sys.stderr.getvalue()
    assert mock_message in fd.format_retries.call_args[0]
    assert err is False

    fd.format_retries.return_value = mock_message


# Generated at 2022-06-24 11:47:19.669238
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert FragmentFD.__doc__ is not None

# Generated at 2022-06-24 11:47:23.044771
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-24 11:47:30.747195
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from youtube_dl.version import __version__
    from io import BytesIO

    class FakeYDL:
        def __init__(self):
            self.params = {
                'nooverwrites': False,
                'restrictfilenames': False,
                'continuedl': False,
                'noprogress': False,
                'logger': None,
                'quiet': False,
                'no_warnings': False,
                'ignoreerrors': False,
                'forceurl': False,
                'forcetitle': False,
                'forceid': False,
                'forcefilename': False,
                'forceduration': False,
                'forcejson': True,
                'simulate': False,
                'skip_download': False,
            }
            self.to_screen_buffer = BytesIO

# Generated at 2022-06-24 11:47:41.114788
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None)
    class MockOption(object):
        def __init__(self, opt_name, opt_value):
            self.opt_name = opt_name
            self.opt_value = opt_value
    class MockYdl(object):
        def __init__(self, params):
            self.params = {}
            for k in params:
                self.params[k] = MockOption(k, params[k])

    mock_ydl = MockYdl({
        'fragment_retries': 3,
    })

    # Check that TypeError is raised on improper retries value
    try:
        fd.report_retry_fragment(None, 0, None, None)
    except TypeError as e:
        assert str(e).find('fragment_retries')

# Generated at 2022-06-24 11:47:52.871709
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from ..utils import encodeString
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD
    from ..compat import compat_str
    from .fragment import FragmentFD


# Generated at 2022-06-24 11:47:56.055112
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeYoutubeDL(object):
        def to_stdout(self, s):
            pass
    dl = HttpQuietDownloader(FakeYoutubeDL())
    assert dl.to_screen('hello world') == None

# Generated at 2022-06-24 11:48:01.319783
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    class SimpleIE(InfoExtractor):
        def __init__(self, ydl):
            InfoExtractor.__init__(self, ydl)

    ydl = FakeYDL()
    ie = SimpleIE(ydl)
    dl = HttpQuietDownloader(ydl, {'format': 'best'})
    assert dl.ydl is ydl



# Generated at 2022-06-24 11:48:05.400011
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .http import HttpFD
    from .http import HlsFD
    from .dash import DASHFD
    from .wvm import WvmFD

    assert isinstance(HttpFD(), FragmentFD)
    assert isinstance(HlsFD(), FragmentFD)
    assert isinstance(DASHFD(), FragmentFD)
    assert isinstance(WvmFD(), FragmentFD)

# Generated at 2022-06-24 11:48:17.805436
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io

    expected_output = '[download] Skipping fragment 5...\n'
    expected_output = expected_output.encode('ascii', 'ignore')
    output_stream = io.BytesIO()
    # Create a FragmentFD object to test and save its output to output_stream
    my_fragmentFD = FragmentFD({'outtmpl': '-'})
    my_fragmentFD.to_screen = lambda x: output_stream.write(x.encode('utf-8'))
    my_fragmentFD.report_skip_fragment(5)
    actual_output = output_stream.getvalue()
    output_stream.close
    # Check that tested method work as expected

# Generated at 2022-06-24 11:48:25.491716
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .utils import *
    # Silence logging
    logging.getLogger('youtube_dl').setLevel(logging.CRITICAL)

    ie = InfoExtractor()
    ie.add_info_extractor(_test_IE1('--test-id1'))
    ie.add_info_extractor(_test_IE2('--test-id2'))
    ie.add_info_extractor(_test_IE3('--test-id3'))
    ie.add_info_extractor(_test_IE4('--test-id4'))

    ie.download = lambda *args: None

    # Test old-style downloader
    ie.download_with_info_extractor(None, 'abc')  # Should not raise an exception

    # Test new-style downloader

# Generated at 2022-06-24 11:48:29.428396
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fragmentfd = FragmentFD(None, {})
    fragmentfd.to_screen = lambda *args, **kargs: args[0]
    assert fragmentfd.report_skip_fragment(123) == '[download] Skipping fragment 123...'

# Generated at 2022-06-24 11:48:39.590744
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .downloader import Downloader
    from .http import HttpFD
    from .dash import dashseg_exec_external
    from .http import HEADRequest

    class DummyFragmentFD(FragmentFD):
        def _prepare_and_start_frag_download(self, ctx):
            pass

        def _start_frag_download(self, ctx):
            pass

        def _prepare_frag_download(self, ctx):
            pass

    class DummyHttpFD(HttpFD):
        def to_screen(self, *args, **kargs):
            pass

        def report_destination(self, filename):
            pass
    FD_NAME = 'dummy'


# Generated at 2022-06-24 11:48:41.919137
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    dl = FragmentFD(None, None)
    assert dl is not None

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:48:46.636554
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None, None)
    fd.to_screen = lambda *args, **kargs: print(args[0])
    fd.report_skip_fragment(7)



# Generated at 2022-06-24 11:48:51.038193
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({})
    fd.params = {
        'fragment_retries': 10,
    }
    assert (fd.format_retries(10) == '10')
    err = Exception('foo')
    fd.report_retry_fragment(err, 5, 1, 10)

# Generated at 2022-06-24 11:49:01.315114
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor import gen_extractor_classes
    from .common import InfoExtractor
    from .downloader.http import HttpDownloader
    from .downloader import gen_extractor_classes
    callback = {}
    def my_to_screen(s, *args, **kargs):
        callback['s'] = s
    class TestFD(FragmentFD, InfoExtractor):
        def to_screen(self, *args, **kargs):
            my_to_screen(*args, **kargs)
    ie = TestFD(HttpDownloader())
    ie.report_retry_fragment(Exception('BOOM'), 42, 3, 4)
    assert callback['s'] == '[download] Got server HTTP error: BOOM. Retrying fragment 42 (attempt 3 of 4)...'

# Generated at 2022-06-24 11:49:06.466022
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    fd = FragmentFD(FileDownloader({}))
    fd.to_screen = lambda *args, **kargs: args
    # Check all possible ranges of count from 1 to retries
    for retries in range(0, 4):
        fd.report_retry_fragment(Exception('http error'), 1, 1, retries)
        for count in range(2, retries + 2):
            fd.report_retry_fragment(Exception('http error'), 2, count, retries)


# Generated at 2022-06-24 11:49:17.982783
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from io import StringIO
    from .youtube_dl.YoutubeDL import YoutubeDL
    from .postprocessor import FFmpegExtractAudioPP

    stringio = StringIO()
    ydl = YoutubeDL(params={
        'logger': YoutubeDL.logger_class(stringio, 30),
        'outtmpl': '%(id)s.mp4',
        'postprocessors': [FFmpegExtractAudioPP(preferredcodec='mp3')],
    })
    fd = HttpQuietDownloader(ydl=ydl, params={
        'quiet': False,
        'restrictfilenames': True,
        })

    assert stringio.getvalue() == ''
    fd.to_screen('test')
    assert stringio.getvalue() == '[download] test\n'

# Generated at 2022-06-24 11:49:22.781224
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    expected_output = '\r[download] Skipping fragment 42...\n'
    fd = FragmentFD({}, {}, {})
    output = fd.test_output(fd.report_skip_fragment, 42)
    assert expected_output == output, output


# Generated at 2022-06-24 11:49:23.899781
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-24 11:49:27.088197
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD({})
    fd.FD_NAME = 'frag'
    print('FragmentFD test passed')

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:49:38.250056
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from . import options
    from .extractor import get_info_extractor
    from .postprocessor import FFmpegFixupM4aPP

    class DummyIE(get_info_extractor('Foo')):
        def _real_extract(self, url):
            if 'break' in url:
                raise Exception('break')
            if 'skip' in url:
                return {
                    '_type': 'url',
                    'url': 'http://skip.com',
                }
            return {
                '_type': 'url',
                'url': 'http://work.com',
            }

    fd = FragmentFD(DummyIE(), options.YoutubeDL({}), {})
    fd.to_screen = lambda *args, **kwargs: None

# Generated at 2022-06-24 11:49:43.116926
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = FileDownloader({})
    dl = HttpQuietDownloader(ydl, {})
    assert dl.to_screen('hello') == None
    assert dl.to_screen('hello %s', 'world') == None
    assert dl.to_screen('hello %s', ['world']) == None
    assert dl.to_screen(['hello', 'world']) == None
    assert dl.to_screen(['hello', '%s'], 'world') == None
    assert dl.to_screen(['hello', '%s'], ['world']) == None

# Generated at 2022-06-24 11:49:49.241556
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class DummyYoutubeDL():
        def to_stdout(self, s):
            pass

    class DummyParams(object):
        def __init__(self):
            self._params = {}

        def get(self, p):
            return self._params.get(p)

        def set(self, p, v):
            self._params[p] = v

    ydl = DummyYoutubeDL()
    ydl.params = DummyParams()

    # check if to_screen is not printing anything if quiet is True
    ydl.params.set('quiet', True)
    hqd = HttpQuietDownloader(ydl, {'quiet': True})
    hqd.to_screen('test')

    # check if to_screen is printing (if quiet is False)

# Generated at 2022-06-24 11:49:57.127838
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MyFD(FragmentFD):
        def __init__(self):
            self.messages = []
        def to_screen(self, msg, skip_eol=False):
            self.messages.append(msg)
    fd = MyFD()
    fd.report_skip_fragment(1)
    assert fd.messages == ['[download] Skipping fragment 1...']
    del fd


# Generated at 2022-06-24 11:50:04.542075
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .options import opts
    from .extractor import get_info_extractor
    params = {'continuedl': True, 'noprogress': True, 'retries': 10, 'nopart': False, 'test': False}
    ydl = get_info_extractor('youtube')
    q = HttpQuietDownloader(ydl, params)
    assert q.ydl == ydl
    assert q.params == params
    assert q._hooks == {}
    assert q._progress_hooks == []
    assert q._downloaded_bytes == 0
    assert q._total_bytes is None
    assert q._status_string == ''
    assert q._filename is None
    assert q._tmpfilename is None

# Generated at 2022-06-24 11:50:10.261495
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FakeYDL:
        params = {}

    class MockFD(FragmentFD):
        def __init__(self, ydl):
            self.ydl = ydl

    fd = MockFD(FakeYDL())
    fd.report_skip_fragment(1)

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:50:15.530137
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    for extractor in InfoExtractor.__class__.__subclasses__():
        if getattr(extractor, '_TEST') or getattr(extractor, '_TEST_FLASH_VARS') or getattr(extractor, '_TEST_GEO_BYPASS'):
            ie = extractor(downloader=HttpQuietDownloader(None))
            ie._real_initialize()
            ie.to_screen('foo')

# Generated at 2022-06-24 11:50:23.184982
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import YoutubeIE
    from .common import FileDownloader
   
    class FakeInfoExtractor(YoutubeIE):
        IE_NAME = 'test'
   
    ie = FakeInfoExtractor()
    params = {'username': 'test', 'password': 'test'}
   
    def test_download(self, filename, info_dict):
        pass
   
    FileDownloader.__bases__ = (FragmentFD,)
    FileDownloader.download = test_download
    FileDownloader(FakeInfoExtractor(), params)

# Generated at 2022-06-24 11:50:31.085836
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({})
    # Initialization
    dl = HttpQuietDownloader(ydl)
    # Methods
    dl.report_error('error')
    dl.to_screen('message')
    dl.to_console_title('title')

# Generated at 2022-06-24 11:50:39.709672
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    def try_to_screen(self, *args, **kwargs):
        try:
            self.to_screen(*args, **kwargs)
        except Exception:
            pass

    import sys
    from .downloader import SameFileError
    from ..utils import prepend_extension
    from ..extractor import get_info_extractor

    class FD(FragmentFD):
        FD_NAME = 'FragFD'
        IE_NAME = 'FragIE'

        def real_download(self, filename, info_dict):
            ctx = {
                'filename': filename,
                'total_frags': 1,
                'ad_frags': 0,
                'dl': self.ydl,
            }
            url = info_dict['url']
            self._prepare_frag_download(ctx)
            self._

# Generated at 2022-06-24 11:50:48.937392
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestObj(object):
        pass

    test_obj = TestObj()
    quiet_downloader = HttpQuietDownloader(test_obj, None)
    # Test that the method quietly returns
    quiet_downloader.to_screen('testing')

    class MyScreen(object):
        count = 0

    my_screen = MyScreen()

    def to_screen(message, *args):
        my_screen.count = my_screen.count + 1
        assert message == 'testing'

    test_obj.to_screen = to_screen
    quiet_downloader.to_screen('testing')
    assert my_screen.count == 1

# Generated at 2022-06-24 11:50:54.532019
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FragmentFD_report_skip_fragment(FragmentFD):
        def to_screen(*args, **kargs):
            return args[0], args[2]
    fd = FragmentFD_report_skip_fragment()
    assert fd.report_skip_fragment(1) == (fd, 'Skipping fragment 1...')

# Generated at 2022-06-24 11:50:59.810101
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class FragmentFDTest(FragmentFD):
        FD_NAME = 'fragfdtest'

    ydl = object()
    params = {'skip_unavailable_fragments': True}
    fd = FragmentFDTest(ydl, params)

    assert fd.ydl is ydl
    assert fd.params == params



# Generated at 2022-06-24 11:51:03.038496
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = object()
    params = {}
    wget = HttpQuietDownloader(ydl, params)
    assert wget.to_screen('test') == None
    assert wget.to_screen('test\n') == None


# Generated at 2022-06-24 11:51:05.468671
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert FragmentFD(None, None)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:51:09.220863
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None, None)
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_skip_fragment(5) == ('[download] Skipping fragment 5...',)

# Generated at 2022-06-24 11:51:19.010050
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class MyLogger(object):
        def debug(self, msg):
            self.msg = msg

    opts = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }

    ydl = {
        'params': {
            'RateLimitFilter': lambda x, y: x,
            'RetryDownloads': lambda x, y: x,
            'ContinueDownload': lambda x, y: x,
            'FragmentDownloader': lambda x, y: x,
        },
        'logger': MyLogger()
    }

    dl = HttpQuietDownloader(ydl, opts)
    # pyl

# Generated at 2022-06-24 11:51:26.850458
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .dash import FragmentsFD
    fd = FragmentsFD(None, {'quiet': True})
    assert fd.params['quiet'] is True
    assert fd.params['noprogress'] is True
    assert fd.params['ratelimit'] is None
    assert fd.params['retries'] == 0
    fd = FragmentsFD(None, {'quiet': True, 'ratelimit': 1000})
    assert fd.params['ratelimit'] == 1000
    assert fd.params['retries'] == 0
    fd = FragmentsFD(None, {'quiet': True, 'retries': 2})
    assert fd.params['retries'] == 2
    fd = FragmentsFD(None, {'quiet': True, 'noprogress': False})

# Generated at 2022-06-24 11:51:31.771742
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from os.path import isfile

    class FragmentFD(FragmentFD):
        def to_screen(self, msg):
            self.msg = msg

    fd = FragmentFD(None)
    fd.report_skip_fragment(5)
    assert fd.msg == '[download] Skipping fragment 5...'


# Generated at 2022-06-24 11:51:39.360567
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor.common import InfoExtractor
    from .compat import compat_HTTPError

    ie = InfoExtractor()
    ie._downloader = FileDownloader(ie)
    ie.set_downloader(FragmentFD)
    # This is not a complete test for report_skip_fragment method,
    # but it's better than nothing
    retval = ie.report_skip_fragment(1)
    assert isinstance(retval, compat_HTTPError)
    assert retval.code == 101
    assert retval.reason == 'Fragment Skipped'

# Generated at 2022-06-24 11:51:47.118758
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    from .http import HttpFD
    # Create FileDownloader and HttpFD instances
    dummy_ydl = FileDownloader()
    dummy_httpfd = HttpFD(dummy_ydl, {})
    dummy_httpqd = HttpQuietDownloader(dummy_ydl, {'continuedl': False})
    # Check base classes
    assert HttpQuietDownloader.__bases__ == (HttpFD, )

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:51:50.339197
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    assert FragmentFD({}).report_retry_fragment(
        ValueError('oh gosh'), 1, 3, 10) == 3



# Generated at 2022-06-24 11:51:53.906512
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = object()
    opts = {'foo': 'bar'}
    hqd = HttpQuietDownloader(ydl, opts)
    assert hqd.ydl == ydl
    assert hqd._ydl_opts == opts

# Generated at 2022-06-24 11:51:55.636518
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    assert fd.report_skip_fragment(999) == None

# Generated at 2022-06-24 11:51:59.850981
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest

    class TestFragmentFD(unittest.TestCase):
        def test_retries(self):
            fd = FragmentFD([], {'fragment_retries': 'inf'})
            self.assertEqual(fd.params['fragment_retries'], float('inf'))

    unittest.main()

# Generated at 2022-06-24 11:52:02.163799
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    ie = get_info_extractor('generic')
    fd = FragmentFD(ie, {}, ie.download, ie._request_webpage)

# Generated at 2022-06-24 11:52:08.261514
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    d = FragmentFD({})
    msg = (
        '[download] Got server HTTP error: The server has asked for the client to provide a password. Retrying fragment 2 (attempt 1 of 3)...')
    d.to_screen = lambda *args, **kargs: args[0]
    assert d.report_retry_fragment(
        AssertionError('The server has asked for the client to provide a password'),
        2, 1, 3) == msg

# Generated at 2022-06-24 11:52:18.727186
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MockFD(FragmentFD):
        def __init__(self, params, ydl):
            super(MockFD, self).__init__(params, ydl)
            self.to_screen_cnt = 0

        def to_screen(self, *args, **kargs):
            super(MockFD, self).to_screen(*args, **kargs)
            self.to_screen_cnt += 1

    params = {
        'skip_unavailable_fragments': False,
    }
    ydl = MockYDL()
    fd = MockFD(params, ydl)
    assert fd.to_screen_cnt == 0

    fd.report_skip_fragment(666)
    assert fd.to_screen_cnt == 1
