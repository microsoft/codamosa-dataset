

# Generated at 2022-06-24 11:42:25.994201
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import io

    stdout_data = io.BytesIO()
    sys.stdout = stdout_data

    fd = FragmentFD({}, {})

    fd.report_retry_fragment(
        RuntimeError('Some error occurred'),
        1,
        2,
        [6, 5, 4])

    sys.stdout = sys.__stdout__


# Generated at 2022-06-24 11:42:35.464655
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    class MockFragmentFD(FragmentFD):
        def __init__(self, params):
            super(MockFragmentFD, self).__init__(HttpFD(FileDownloader(params)), params)

    mock_params = {'simulate': True, 'noprogress': True}
    fragment_fd = MockFragmentFD(mock_params)

    def to_screen_call(msg, skip_eol=False):
        assert not skip_eol
        to_screen_args.append(msg)

    def format_retries_call(retries):
        format_retries_args.append(retries)
        return '%d' % retries

    fragment_fd.to_screen = to_screen_call
    fragment_fd

# Generated at 2022-06-24 11:42:41.269746
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FakeFragmentFD(FragmentFD):
        def __init__(self):
            self._messages = []
        def to_screen(self, *args, **kargs):
            self._messages.append((args, kargs))

    ffd = FakeFragmentFD()
    ffd.report_retry_fragment('err', 1, 2, (3, 4))
    assert ffd._messages == [(
        (
            '[download] Got server HTTP error: err. '
            'Retrying fragment 1 (attempt 2 of 3)...',
        ),
        {},
    )]

# Generated at 2022-06-24 11:42:51.732563
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFD(FragmentFD):
        def __init__(self, ydl):
            super(TestFD, self).__init__(ydl)
            self._screen_buffer = []

        def to_screen(self, *args, **kargs):
            self._screen_buffer.append(' '.join(args))

    ydl = object()
    fd = TestFD(ydl)
    err = Exception('foo')
    fd.report_retry_fragment(
        err=err, frag_index=12, count=3, retries=10)
    assert fd._screen_buffer == [
        '[download] Got server HTTP error: foo. Retrying fragment 12 (attempt 3 of 10)...',
    ]



# Generated at 2022-06-24 11:42:59.382974
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .f4m import F4mFD
    from .hls import HlsFD
    from .dash import DashSegmentsFD
    from .http import HttpFD
    from .utils import unescapeHTML

    class FakeYtdlFD(F4mFD, HlsFD, DashSegmentsFD, HttpFD):
        pass

    # Create a fake downloader
    ydl = FakeYtdlFD()
    ydl.to_screen = lambda *args, **kargs: unescapeHTML(args[0])
    ydl.params = {
        'keep_fragments': True,
        'skip_unavailable_fragments': True,
    }

    # Create a FakeInfoDict
    ydl.info_dict = {}

    # Initialize the downloader
    ydl.prepare()

    # Call report

# Generated at 2022-06-24 11:43:10.937009
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import io
    import unittest
    testout = io.StringIO()
    saved_stdout = sys.stdout
    try:
        sys.stdout = testout
        hqd = HttpQuietDownloader(None, {'noprogress': False})
        hqd.to_screen('foo')
        hqd.to_screen(u'łąść')
        hqd.to_screen(b'bar')
        hqd.to_screen(b'\xc2\xbb'.decode('utf-8'))
        hqd.to_screen(None)
        sys.stdout = saved_stdout
    except Exception:
        sys.stdout = saved_stdout
        raise
    lines = testout.getvalue().splitlines()


# Generated at 2022-06-24 11:43:17.451844
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class MockYoutubeDL(object):
        def to_screen(self, *args, **kargs):
            pass
    ydl = MockYoutubeDL()
    fd = FragmentFD(ydl, {})
    fd.to_screen = ydl.to_screen
    fd.report_retry_fragment(1, 2, 3, {'max_retries': 10})
    fd.report_retry_fragment(1, 2, 3, {'max_retries': 5})

if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:43:28.331830
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .utils import simple_download
    from .compat import compat_urllib_error
    from .postprocessor import FFmpegMetadataPP
    import os
    import tempfile
    import shutil
    import json
    import sys

    # TODO: add a test for _hooks_progress

    # Check _hooks_progress
    #
    # Test purpose:
    # - check that FileDownloader._hooks_progress is called at the right time
    #   with the right information being passed
    # - check that FileDownloader._hooks_progress is called with the right
    #   information to pass when a post processor is active

    VIDEO_URL = 'http://localhost/video.mp4'
    VIDEO_THUMBNAIL

# Generated at 2022-06-24 11:43:36.542497
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor import get_info_extractor
    from .downloader import YoutubeDL
    fd = FragmentFD(YoutubeDL({}), get_info_extractor('test'), 'dest.mp4')
    class FakeErr(Exception):
        pass
    fd.to_screen = lambda *args, **kargs: print(args, kargs)
    fd.report_retry_fragment(FakeErr, 1, 2, (1, 100))

if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:43:37.131319
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass

# Generated at 2022-06-24 11:43:40.596250
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: args
    assert ('[download] Got server HTTP error: Some error. '
        'Retrying fragment 1 (attempt 7 of 10)...') == fd.report_retry_fragment(
        'Some error', 1, 7, 10)


# Generated at 2022-06-24 11:43:50.045923
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..downloader import HttpFD
    from ..post import get_filesize

    # test code
    def get_info(url, download=False, filename=None, info_dict=None):
        fp = HttpQuietDownloader.head_video_file(url)
        size = get_filesize(fp)
        fp.close()
        info = {'_filename': filename or os.path.basename(url),
                'url': url,
                'filesize': size,
                'format_id': 'test'}
        if download:
            tmpfilename = tempfile.mkstemp(prefix='ytdltest_')[1]

# Generated at 2022-06-24 11:44:00.849086
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    from tempfile import mkstemp
    from contextlib import contextmanager

    @contextmanager
    def capture_output(fd):
        old = os.dup(1)
        os.dup2(fd, 1)
        try:
            yield
        finally:
            os.dup2(old, 1)
            os.close(old)

    (fd, temp_path) = mkstemp(suffix='.txt')
    os.close(fd)

    with capture_output(fd):
        ydl = FileDownloader(params={})
        ydl.add_info_extractor(HttpFD())
        ydl.add_info_extractor(FragmentFD())
        ydl.report_skip_fragment(42)
   

# Generated at 2022-06-24 11:44:11.778683
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    # NoopFileDownloader is a simple downloader with noop .download() and .real_download() methods
    # and real .to_screen() and .report_destination() methods
    class NoopFileDownloader(FileDownloader):
        def __init__(self, *args, **kwargs):
            super(NoopFileDownloader, self).__init__(*args, **kwargs)
            self.nop = True

        def download(self, *args, **kwargs):
            return self.nop

        def real_download(self, *args, **kwargs):
            return self.nop


# Generated at 2022-06-24 11:44:20.413078
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        def _start_frag_download(self, ctx):
            ctx['total_frags'] = 1
            ctx['ad_frags'] = 0
            ctx['tmpfilename'] = 'my_file'
            ctx['filename'] = 'my_file'
            ctx['frag_index'] = 0
            return super(MyFragmentFD, self)._start_frag_download(ctx)

        def _download_fragment(self, *args, **kwargs):
            return True, 'test content'

        def _append_fragment(self, *args, **kwargs):
            pass

        def _finish_frag_download(self, *args, **kwargs):
            pass

    fd = MyFragmentFD(None)


# Generated at 2022-06-24 11:44:31.334447
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import youtube_dl.YoutubeDL
    # Required:
    # - no tests for live fragments
    # - fragments should be retriable (HTTP server error)
    # - fragments should be skippable (HTTP server error 404)
    ydl = youtube_dl.YoutubeDL({
        'quiet': True,
        'skip_download': True,
        'simulate': True,
    })
    fd = FragmentFD(ydl, {
        'fragment_retries': 2,
        'skip_unavailable_fragments': True,
        'keep_fragments': True,
    })
    fd.to_screen = sys.stdout.write
    fd.report_warning = sys.stderr.write
    fd.report_error = sys.stderr.write
   

# Generated at 2022-06-24 11:44:35.372696
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = object()
    params = object()
    expected_params = {'continuedl': True, 'quiet': True,
                       'noprogress': True, 'nopart': False}

    d = HttpQuietDownloader(ydl, params)

    assert d.ydl is ydl
    assert d.params == expected_params

# Generated at 2022-06-24 11:44:42.703537
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from collections import namedtuple
    from .test_extractor import fake_upper_downloader
    from .common import FileDownloader
    from .http import HttpFD
    from ..compat import str

    retries = 1
    err = 'error'
    frag_index = 1
    destination = 'destination'

    test_class = FragmentFD()
    test_class.to_screen = lambda *args, **kargs: None
    test_class.params = {'retries': retries}
    test_class.info = namedtuple('Info', 'name')(name='test_class')

    class TestFD(FileDownloader, HttpFD):
        pass

    TestFD.report_retry_fragment(
        test_class, err, frag_index, 1, retries, destination)
    TestFD

# Generated at 2022-06-24 11:44:45.137798
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader(
        {},
        {
            'noprogress': False,
            'logger': 'fake',
            'progress_hooks': [],
        }
    )
    assert dl._opts['quiet']
    assert dl._opts['noprogress']

# Generated at 2022-06-24 11:44:53.013812
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import StringIO
    sys.stderr = StringIO.StringIO()
    test_obj = FragmentFD(None, {}, None)
    test_obj.to_screen = lambda *args, **kargs: None
    test_obj.report_skip_fragment(2)
    output = sys.stderr.getvalue()
    sys.stderr.close()
    assert output == '[download] Skipping fragment 2...\n'

# Generated at 2022-06-24 11:45:04.053064
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():

    class HttpQuietDownloaderTest(HttpQuietDownloader):
        def __init__(self, *args):
            self.to_screen_args = []
            HttpQuietDownloader.__init__(self, *args)

        def to_screen(self, *args):
            self.to_screen_args.append(args)

    class YoutubeDL:
        params = {}

    ytdl_object_test = YoutubeDL()

    http_downloader_test = HttpQuietDownloaderTest()
    http_downloader_test.ydl = ytdl_object_test

    http_downloader_test.to_screen('test string')
    assert len(http_downloader_test.to_screen_args) == 0

    ytdl_object_test.params.update({'verbose': True})

# Generated at 2022-06-24 11:45:14.550651
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    from ..compat import compat_HTTPError

    class FakeFD(FileDownloader, FragmentFD):
        def __init__(self, ydl):
            FileDownloader.__init__(self, ydl)
            FragmentFD.__init__(self, ydl)
            self.to_screen_calls = []

        def to_screen(self, *args, **kargs):
            self.to_screen_calls.append((args, kargs))

    def detect_to_screen_call(
            log_type, log_message,
            expected_log_type=None, expected_log_message=None):

        if expected_log_type is None:
            expected_log_type = log_type


# Generated at 2022-06-24 11:45:18.142963
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {'logger': None})
    assert fd.FD_NAME == 'fragment'
    assert fd.params == {}
    fd.report_skip_fragment(0)
    fd.to_screen('hello')
    assert fd.params == {}



# Generated at 2022-06-24 11:45:22.664967
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    fd = HttpQuietDownloader(None, {'noprogress': True, 'quiet': True})
    assert isinstance(fd, HttpFD)
    assert fd.params['noprogress']
    assert fd.params['quiet']



# Generated at 2022-06-24 11:45:26.283320
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    httpqd = HttpQuietDownloader({}, {})
    assert(httpqd)



# Generated at 2022-06-24 11:45:31.631089
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl
    import tempfile

    with tempfile.TemporaryFile() as f:
        ydl = youtube_dl.YoutubeDL(f)
        qdl = HttpQuietDownloader(ydl, {})

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:45:37.386856
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import os
    import tempfile
    assert __name__ == '__main__'
    fd = FragmentFD({
        'outtmpl': '%(id)s.%(ext)s',
    })
    sys.stdout = os.fdopen(sys.stdout.fileno(), 'w')
    fd.to_screen('Hello world!')
    sys.stdout = tempfile.TemporaryFile()

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:45:45.241715
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def run_FragmentFD(name):
        fd = FragmentFD(None, {'noprogress': True})
        fd.FD_NAME = name
        return fd

    assert (run_FragmentFD('fd').__class__.__name__ == 'FragmentFD')
    assert (run_FragmentFD('dash').__class__.__name__ == 'FragmentFD')
    assert (run_FragmentFD('hlsnative').__class__.__name__ == 'FragmentFD')

# Generated at 2022-06-24 11:45:56.742961
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FragmentFD_retry(FragmentFD):
        def __init__(self):
            self.to_screen_list = []
            self.retries = 4
        def to_screen(self, *msg):
            self.to_screen_list.extend(msg)
        def format_retries(self, retries):
            return '%d' % retries

    fd = FragmentFD_retry()
    fd.report_retry_fragment('ERROR', 2, 3, fd.retries)
    assert 'Got server HTTP error: ERROR. Retrying fragment 2 (attempt 3 of 4)' in fd.to_screen_list

# Generated at 2022-06-24 11:46:07.878353
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    data = {
        'fragment_retries': 1,
        'skip_unavailable_fragments': False,
        'keep_fragments': False,
        'ratelimit': None,
        'noprogress': False,
        'retries': 0,
        'nopart': False,
        'test': False,
    }

    fd = FragmentFD('youtube-dl', data)
    fd.to_screen = lambda *args, **kargs: args

    args = fd.report_retry_fragment(
        IOError('Connection broken: IncompleteRead(0 bytes read)'),
        0, 1, fd.params['fragment_retries'] + 1)

# Generated at 2022-06-24 11:46:13.982344
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpFD

    def to_screen(self, *args, **kargs):
        self.to_screen_args = args
        self.to_screen_kargs = kargs

    HttpFD.to_screen = to_screen

    ydl = HttpQuietDownloader({}, {})
    ydl.to_screen('foo')

    assert not hasattr(ydl, 'to_screen_args')
    assert not hasattr(ydl, 'to_screen_kargs')

# Generated at 2022-06-24 11:46:21.916542
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {'format': 'dash'})
    fd.to_screen = lambda *x, **y: x
    out = fd.report_retry_fragment(Exception('foo'), 26, 3, 10)
    assert out == (
        "[download] Got server HTTP error: foo. Retrying fragment 26 (attempt 3 "
        "of 10)...",
    )

# Generated at 2022-06-24 11:46:25.512562
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class A(object):
        pass
    a = A()
    a.to_screen = lambda *args, **kargs: args
    s = HttpQuietDownloader(a, {})
    res = s.to_screen('a', 'bc')
    assert res is None

# Generated at 2022-06-24 11:46:36.828548
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import unittest
    import StringIO

    class TestLogger(unittest.TestCase):
        def setUp(self):
            self.saved_stdout = sys.stdout
            self.log = StringIO.StringIO()
            sys.stdout = self.log

        def tearDown(self):
            self.log.close()
            sys.stdout = self.saved_stdout

        def testString(self):
            self.assertEqual(self.log.getvalue(), '')
            HttpQuietDownloader(None).to_screen('Hello world!')
            self.assertEqual(self.log.getvalue(), 'Hello world!\n')

        def testUnicode(self):
            self.assertEqual(self.log.getvalue(), '')
            HttpQuietDownloader

# Generated at 2022-06-24 11:46:43.735464
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {'skip_unavailable_fragments': True}, None)
    fd.to_screen = lambda *args, **kargs: None

    fd.report_skip_fragment(0)
    fd.report_skip_fragment(1)
    fd.report_skip_fragment(10)
    fd.report_skip_fragment(100)
    fd.report_skip_fragment(1000)


if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:46:46.712973
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .downloader import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)
    assert FragmentFD.__name__ == 'FragmentFD'

# Generated at 2022-06-24 11:46:58.160267
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from mock import Mock
    from ..utils import _unquote_url

# Generated at 2022-06-24 11:46:59.050028
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    return FragmentFD(None, None)

# Generated at 2022-06-24 11:47:06.585007
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class AssertionFD(FragmentFD):
        def __init__(self):
            self.assert_equal = lambda x, y: x

    fd = AssertionFD()
    fd.to_screen = lambda *x: None
    err, frag_index = RuntimeError('test'), 1
    count = 3
    retries = 5
    fd.format_retries = lambda x: x

    fd.assert_equal(
        fd.report_retry_fragment(err, frag_index, count, retries),
        False
    )

# Generated at 2022-06-24 11:47:15.059569
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..downloader import YoutubeDL
    from ..compat import compat_urllib_request

    url = 'https://github.com/rg3/youtube-dl/blob/master/README.md#readme'
    ie = get_info_extractor(url)()
    ydl = YoutubeDL()
    fd = ie.get_info_extractor()(ydl, ie.url)
    req = compat_urllib_request.Request(url)
    fd.download(req, ie)

# Generated at 2022-06-24 11:47:25.495982
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor.common import InfoExtractor

    # Create an InfoExtractor object with a valid youtube url
    IE = InfoExtractor()
    IE.extract('http://www.youtube.com/watch?v=BaW_jenozKc')

    FD = HttpQuietDownloader(IE, {
        'progress_hooks': [lambda d: sys.stdout.write(
            'Downloaded %f bytes\n' % d['downloaded_bytes'])],
    })
    # Check whether download works
    FD.download('http://www.youtube.com/watch?v=BaW_jenozKc', {
        'continuedl': False,
        'quiet': False
    })        

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:47:30.697777
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestFD(FileDownloader):
        pass
    TestFD.params = {}
    TestFD.to_screen = lambda *args, **kargs: None
    dl = HttpQuietDownloader(TestFD(), {})
    msg = 'Just a message'
    dl.to_screen(msg)

# Generated at 2022-06-24 11:47:36.140484
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FakeYDL

    ydl = FakeYDL()

    fd = FragmentFD(ydl=ydl, params={})
    fd.report_skip_fragment(3)

    assert ydl.msgs == ['[download] Skipping fragment 3...']



# Generated at 2022-06-24 11:47:42.663441
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import io
    import sys
    # Ensure python 3.x compatibility to run on python 2.x virtual environments
    out = io.BytesIO() if sys.version_info[0] == 2 else io.StringIO()
    old_sys_stdout = sys.stdout
    old_sys_stderr = sys.stderr
    try:
        sys.stdout = sys.stderr = out
        downloader = HttpQuietDownloader(None, None)
        assert downloader.to_screen('to screen') is None
        assert out.getvalue() == ''
    finally:
        sys.stdout = old_sys_stdout
        sys.stderr = old_sys_stderr

# Generated at 2022-06-24 11:47:50.373545
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    gen_extractor_classes()

    ydl = lambda: None
    ydl.params = {}
    ydl.add_info_extractor = lambda i: None
    ydl.to_screen = lambda s, skip_eol=False: None

    hqd = HttpQuietDownloader(ydl, {})
    assert hqd.params['logger'] is None
    assert hqd.params['progress_with_newline'] is False

# Generated at 2022-06-24 11:47:59.374890
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class DummyYDL:
        params = {'skip_unavailable_fragments': True}
        params.update(FragmentFD.params)

# Generated at 2022-06-24 11:48:04.272167
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestHttpQuietDownloader(HttpQuietDownloader):
        def __init__(self, ydl):
            super(TestHttpQuietDownloader, self).__init__(ydl, {})
            self.msgs = []

        def to_screen(self, msg):
            self.msgs.append(msg)

    c = TestHttpQuietDownloader(None)
    c.to_screen('Test 1')
    c.to_screen('Test 2')

    assert c.msgs == []

# Generated at 2022-06-24 11:48:15.919800
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # Testing different locales
    old_lc_ctype = None

# Generated at 2022-06-24 11:48:21.703423
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    dummy_downloader = object()
    dummy_params = {}
    fd = FragmentFD(dummy_downloader, dummy_params)

    assert fd.FD_NAME == 'fragment'
    assert fd.ydl is dummy_downloader
    assert fd.params is dummy_params

# Generated at 2022-06-24 11:48:24.916984
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_skip_fragment(3) == ('[download] Skipping fragment 3...',)



# Generated at 2022-06-24 11:48:30.154828
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .common import FileDownloader
    from .common import YoutubeDL
    def test(*args):
        for ie in gen_extractors():
            if ie.ie_key() == 'HttpQuietDownloader':
                return True
        return False
    ydl = YoutubeDL()
    assert test(ydl)

# Generated at 2022-06-24 11:48:40.266247
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def test_body(cls, filename_d, filename_e, dest_stream_b, dest_stream_c):
        ctx = {
            'dest_stream': dest_stream_b,
            'filename': filename_d,
            'tmpfilename': filename_e,
            'downloader': {
                'current_fragment': {
                    'index': 0,
                },
                'fragment_count': 5,
            },
        }
        if cls.__do_ytdl_file(ctx):
            ctx['dl']._write_ytdl_file(ctx)
        ctx['dest_stream'] = dest_stream_c
        cls.__read_ytdl_file(ctx)
        cls.__write_ytdl_file(ctx)
        assert ctx

# Generated at 2022-06-24 11:48:52.246484
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor import get_info_extractor
    class MockYoutubeDL(object):
        def __init__(self, *args, **kargs):
            self._ies = []
            self._downloader = None
        def add_info_extractor(self, ie):
            self._ies.append(ie)
        def set_downloader(self, dl):
            self._downloader = dl
    ydl = MockYoutubeDL()
    HttpQuietDownloader(ydl, {})
    assert len(ydl._ies) == 0
    assert isinstance(ydl._downloader, HttpQuietDownloader)
    assert ydl._downloader.ydl is ydl
    # Test that HttpQuietDownloader overwrites default downloader

# Generated at 2022-06-24 11:49:03.080815
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FragmentFD_test(FragmentFD):
        def __init__(self, retries=None, frag_retries=None):
            self.to_screen_value = None
            self.params = {
                'retries': retries,
                'fragment_retries': frag_retries,
            }

        def to_screen(self, *msg):
            self.to_screen_value = msg

    fd = FragmentFD_test(frag_retries=0)
    fd.report_retry_fragment(Exception('test'), 1, 1, None)
    assert fd.to_screen_value == (
        '[download] Got server HTTP error: test. Retrying fragment 1 (attempt 1 of 1)...',)


# Generated at 2022-06-24 11:49:04.277962
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    assert not HttpQuietDownloader(None, {}).to_screen('message')

# Generated at 2022-06-24 11:49:16.828999
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    out = sys.stdout
    sys.stdout = open('/dev/null', 'w')

# Generated at 2022-06-24 11:49:23.951259
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fake_logger = {}
    def fake_log(msg):
        fake_logger['msg'] = msg
    class FakeFragmentFD(FragmentFD):
        def to_screen(self, msg):
            fake_log(msg)
    ffd = FakeFragmentFD({'logger': fake_log})
    ffd.report_skip_fragment(42)
    assert fake_logger['msg'] == '[download] Skipping fragment 42...'

# Generated at 2022-06-24 11:49:32.512520
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import unittest

    from ..compat import compat_http_client, compat_urllib_error
    from ..utils import prepend_extension

    class MockFragmentFD(FragmentFD):
        def __init__(self):
            self.buf = []

            class MockYDL:
                def __init__(self):
                    self.params = {}
                    self.to_screen = self.to_stdout
                def to_stdout(self, message, skip_eol=False):
                    self.buf.append(message + u'\n' if not skip_eol else message)

            self.ydl = MockYDL()

            self.params = {
                'fragment_retries': 3,
            }


# Generated at 2022-06-24 11:49:34.023607
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # assert(isinstance(FragmentFD(None, None), object))
    pass

# Generated at 2022-06-24 11:49:40.213011
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args: fd._called_with_args.append(args)
    fd._called_with_args = []

    fd.report_skip_fragment(10)

    assert len(fd._called_with_args) == 1
    assert fd._called_with_args[0] == (
        '[download] Skipping fragment 10...',)

# Generated at 2022-06-24 11:49:47.971036
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'test:.*'

    ie = TestIE()

    # Setup to_screen if not available
    if not hasattr(HttpQuietDownloader, 'to_screen'):
        HttpQuietDownloader.to_screen = YoutubeIE.to_screen

    # Test to_screen method
    qdl = HttpQuietDownloader(ie, {'quiet' : True})
    qdl.to_screen('test msg')

    qdl = HttpQuietDownloader(ie, {'quiet' : False})
    qdl.to_screen('test msg')

    # Test

# Generated at 2022-06-24 11:49:58.581519
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .downloader import Downloader
    from ..extractor import get_info_extractor
    class FakeInfoExtractor(object):
        IE_NAME = 'test'
    class FakeFDClass(FragmentFD):
        FD_NAME = 'test'
    info_extractor = FakeInfoExtractor()
    downloader = Downloader(info_extractors=[info_extractor])
    ie = get_info_extractor(info_extractor.IE_NAME)
    ie.set_downloader(downloader)
    assert isinstance(ie.fd, FakeFDClass)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:50:11.478271
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    from .fragment import FragmentFD
    for ie in gen_extractors():
        if 'youtube' in ie.IE_NAME or 'generic' in ie.IE_NAME:
            continue
        if not ie.working():
            continue
        ie = ie()
        break
    info_dict = {}
    ie.extract(info_dict)
    ydl = FileDownloader(info_dict)
    HttpFD(ydl, {})
    DASHFD(ydl, {})
    FragmentFD(ydl, {})
    info_dict.update(ydl.add_default_extra_info(info_dict))

# Generated at 2022-06-24 11:50:22.619580
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    _stderr = sys.stderr
    try:
        fd = FragmentFD(None, {})
        fd.to_screen = lambda *args, **kargs: None
        sys.stderr = open('/dev/null', 'w')
        fd.report_retry_fragment(
            'test error 3', 3, 1, [1, 2, 42])
        sys.stderr.seek(0, 0)
        err_msg = sys.stderr.read()
        assert err_msg == (
            '[download] Got server HTTP error: test error 3. '
            'Retrying fragment 3 (attempt 1 of [1, 2, 42])...\n')
    finally:
        sys.stderr = _stderr


# Generated at 2022-06-24 11:50:35.314058
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():

    class DummyYdl(object):
        def __init__(self):
            self.to_screen_files = []
            self.to_screen_strings = []

        def to_screen(self, s, f=None):
            self.to_screen_files.append(f)
            self.to_screen_strings.append(s)

    dummy_ydl = DummyYdl()
    qd = HttpQuietDownloader(dummy_ydl, {'continuedl': True})
    qd.to_screen('foo')
    assert dummy_ydl.to_screen_files == [None]
    assert dummy_ydl.to_screen_strings == ['foo']

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:50:41.089244
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = FileDownloader({}, {'continuedl': True, 'quiet': False})
    assert ydl.to_screen('foo') == None
    ydl = FileDownloader({}, {'continuedl': True, 'quiet': True})
    assert ydl.to_screen('foo') == None
    return True

# Generated at 2022-06-24 11:50:51.035391
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params

        def add_info_extractor(self, ie):
            pass


# Generated at 2022-06-24 11:50:57.424554
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    fd.to_screen = lambda x: x
    fd.report_skip_fragment(1)

    fd.to_screen = lambda x: None
    fd.report_skip_fragment(1)


if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:50:59.671106
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TempFD(FragmentFD):
        FD_NAME = 'test'

    assert TempFD({}).FD_NAME == 'test'

# Generated at 2022-06-24 11:51:06.064823
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FakeYDL:
        params = {}

    class FakeFD(FragmentFD):
        def to_screen(self, *args, **kargs):
            self.result = args

    fd = FakeFD(FakeYDL())
    fd.report_skip_fragment(1)
    assert fd.result == ('[download] Skipping fragment 1...',)


# Generated at 2022-06-24 11:51:08.664671
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = HttpQuietDownloader({}, {})
    ydl.to_screen('foo') # should not raise an exception

# Generated at 2022-06-24 11:51:18.469531
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FakeYDL(object):
        def __init__(self):
            self.params = {}
    ydl = FakeYDL()
    fd = FragmentFD(ydl, {})
    assert fd.report_retry_fragment(
        TypeError(u'x'), 2, 1, 2) == u'[download] Got server HTTP error: x. Retrying fragment 2 (attempt 1 of 2)...'
    ydl.params['fragment_retries'] = 2
    assert fd.report_retry_fragment(
        TypeError(u'x'), 2, 1, 2) == u'[download] Got server HTTP error: x. Retrying fragment 2 (attempt 1 of 2)...'

# Generated at 2022-06-24 11:51:21.867120
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    class DummyFragmentFD(FragmentFD, FileDownloader):
        pass
    out = DummyFragmentFD.report_skip_fragment(DummyFragmentFD(), 5)
    assert(out is None)

# Generated at 2022-06-24 11:51:29.845559
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = object()
    params = {
        'keep_fragments': True,
        'retries': 5,
    }
    from .dash import DASHFD
    from .hls import HLSFD
    for fd in (DASHFD(ydl, params), HLSFD(ydl, params)):
        assert fd._frag_retries == 5
        assert fd._frag_skip_unavailable
        assert fd._frag_keep_fragments

# Generated at 2022-06-24 11:51:37.307305
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .options import (
        OptionParser,
        YoutubeDLOptions,
    )
    op = OptionParser(YoutubeDLOptions())
    op.add_option('-r', '--rate-limit', dest='ratelimit')
    op.add_option('-R', '--retries', dest='retries')
    op.add_option('-t', '--test', dest='test')
    opts, _ = op.parse_args([
        '--retries', '0',
        '-r', '100',
        '-t',
        '--get-title',
        '--write-auto-sub',
        '--write-all-thumbnails',
    ])
    fd = FragmentFD(opts)
    assert fd.params['retries'] == 0
    assert fd.params['ratelimit']

# Generated at 2022-06-24 11:51:41.856723
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None)
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_skip_fragment(42) == (['[download] Skipping fragment 42...'], {})


# Generated at 2022-06-24 11:51:48.022508
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from . import YoutubeDL
    from .extractor.common import InfoExtractor
    ydl = YoutubeDL({'quiet': True})
    class DummyIE(InfoExtractor):
        def _get_info(self, url):
            self.report_skip_fragment(45)
    ie = DummyIE(ydl, {'url': 'http://example.com', 'ie_key': 'Dummy'})
    ie._get_info('http://example.com')


# Generated at 2022-06-24 11:51:51.587490
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    dl = HttpQuietDownloader({}, {})
    try:
        dl.to_screen('test')
    except:
        # This test is expected to fail if the to_screen method is invoked
        return False
    return True

# Generated at 2022-06-24 11:51:55.192436
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .http import HttpFD
    fd = FragmentFD(HttpFD.params)

# Generated at 2022-06-24 11:51:56.981391
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors

    gen_extractors()
    # TODO: Create a real unit test

# Generated at 2022-06-24 11:52:00.962571
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(dict(), dict())
    assert fd.params.get('fragment_retries', 0) == 0
    assert not fd.params.get('keep_fragments', False)
    assert not fd.params.get('skip_unavailable_fragments', False)



# Generated at 2022-06-24 11:52:11.552743
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import is_py2

    if is_py2:  # Python 2.6+ required
        from .http import HttpFD
        # http_chunk_size = param = w get() = 1
        http_quiet_downloader = HttpQuietDownloader(
            {}, {'continuedl': False, 'quiet': True, 'noprogress': True})
        assert isinstance(http_quiet_downloader, HttpFD)
        # http_chunk_size = param = get() = None
        http_quiet_downloader = HttpQuietDownloader(
            {}, {'continuedl': False, 'quiet': True, 'noprogress': True, 'ratelimit': None})
        assert isinstance(http_quiet_downloader, HttpFD)
        # http_chunk_size

# Generated at 2022-06-24 11:52:13.922896
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    hqd = HttpQuietDownloader(ydl, {'quiet': True, 'noprogress': True})
    assert isinstance(hqd, FileDownloader)

# Generated at 2022-06-24 11:52:18.003498
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # HttpQuietDownloader.to_screen should do nothing
    test_dummy = HttpQuietDownloader(None, None)
    test_dummy.to_screen('[download] foo bar')

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:52:22.417206
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    fd = HttpQuietDownloader(None, {'continuedl': False})
    old_stderr = sys.stderr
    sys.stderr = sys.__stderr__ = open('NUL', 'w')
    fd.to_screen('test')
    sys.stderr.close()
    sys.stderr = old_stderr