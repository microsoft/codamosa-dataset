

# Generated at 2022-06-24 11:42:26.208720
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from unittest import TestCase
    from .common import TestDownloader

    def test(self):
        self.to_screen_calls = 0

        def to_screen(self2, *args, **kargs):
            self.to_screen_calls += 1
            self.assertEqual(self2, self.FD)
            self.assertEqual(args, (
                '[download] Got server HTTP error: test error. Retrying fragment 1 (attempt 3 of 10)...',))
            self.assertEqual(kargs, {})

        fd = FragmentFD(TestDownloader())
        fd.to_screen = lambda *args, **kargs: to_screen(fd, *args, **kargs)
        fd.report_retry_fragment(Exception('test error'), 1, 3, 10)


# Generated at 2022-06-24 11:42:32.364960
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class FakeFD:
        def __init__(self, params):
            self.params = params

        def add_progress_hook(self, cb):
            pass

        def report_warning(self, msg):
            pass

        def download(self, filename, info_dict):
            return info_dict['url'] == 'foo'

        def temp_name(self, *args, **kwargs):
            return 'tempn'

        def try_rename(self, *args, **kwargs):
            pass

    params = {
        'fragment_retries': 'infinite',
        'keep_fragments': True,
        'sleep_interval': 0,
    }
    frag_count = 5
    ydl = FakeFD(params)
    dl = FragmentFD(ydl, params)
   

# Generated at 2022-06-24 11:42:33.264618
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass


# Generated at 2022-06-24 11:42:46.322772
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    """
    Test to confirm that to_screen of HttpQuietDownloader doesn't print anything to the stdout of the terminal.
    """
    import sys
    # Backup the stdout of the terminal
    stdout_backup = sys.stdout
    # Dummy class without init
    class Dummy:
        pass
    # Dummy options for youtube-dl
    opts = Dummy()
    opts.simulate = True
    opts.quiet = True
    opts.no_warnings = False
    opts.verbose = True
    opts.dumpjson = False
    opts.no_color = True
    opts.ignoreerrors = True
    opts.forceurl = True
    opts.forcetitle = True
    opts.forcethumbnail = True
    opts.forcedescription = True

# Generated at 2022-06-24 11:42:49.827441
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # Create a FragmentFD object, call repport_skip_fragment and check
    # that the output is as expected
    fd = FragmentFD({})
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_skip_fragment(1) == ('[download] Skipping fragment 1...',)


# Generated at 2022-06-24 11:42:56.391161
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import get_info_extractor
    fd = FragmentFD(get_info_extractor("youtube"), {}, None)
    assert fd.params == {}
    fd = FragmentFD(get_info_extractor("youtube"), {'retries': 5}, None)
    assert fd.params == {'retries': 5}
    fd = FragmentFD(get_info_extractor("youtube"), None, None)
    assert fd.params == {}
    class FakeInfoExtractor:
        IE_NAME = 'Fake'
        def __init__(self):
            self._ies = []
        def _call_ies(self, method, *args, **kwargs):
            for ie in self._ies:
                result = getattr(ie, method)(*args, **kwargs)

# Generated at 2022-06-24 11:43:03.619191
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader(None, {'quiet': True, 'noprogress': True, 'retries': 10})
    assert dl.params['retries'] == 10
    dl = HttpQuietDownloader(None, {'q': True, 'n': True})
    assert dl.params['retries'] == 0

# Generated at 2022-06-24 11:43:10.657012
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor

    class QuietIE(InfoExtractor):
        IE_NAME = 'quiet'

        def _real_extract(self, url):
            q = HttpQuietDownloader(self._ytdl)
            q.to_screen('Test')

    gen_extractors()
    ie = QuietIE(None)
    ie.extract('http://quiet.test')

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:43:23.668105
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .utils import write_string
    from .compat import compat_urllib_parse_urlparse

    class FakeFD(FileDownloader):
        def __init__(self, params):
            self.params = params

        def report_warning(self, msg):
            self.to_screen('WARNING: ' + msg)

        def _do_download(self, *args, **kwargs):
            return

        def temp_name(self, *args, **kwargs):
            return

        def try_rename(self, *args, **kwargs):
            return

        def mkdir(self, *args, **kwargs):
            return

        def _hook_progress(self, *args, **kwargs):
            return


# Generated at 2022-06-24 11:43:30.223533
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    try:
        fd = FragmentFD({'tmpdir': tmpdir})
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-24 11:43:33.668748
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from ..utils import flvlib_utils

    fd = FragmentFD(None, {})
    fd.to_screen = flvlib_utils.flvlib_decorator
    fd.report_skip_fragment(5)

# Generated at 2022-06-24 11:43:36.006141
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None) # pylint: disable=abstract-class-instantiated
    captured = []
    def my_to_screen(msg, skip_eol=False):
        captured.append(msg)
    fd.to_screen = my_to_screen
    fd.report_skip_fragment(3)
    assert captured == ['[download] Skipping fragment 3...']

# Generated at 2022-06-24 11:43:40.230576
# Unit test for method to_screen of class HttpQuietDownloader

# Generated at 2022-06-24 11:43:49.737088
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    from ..utils import unified_strdate

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test1',
                'title': 'test',
                'upload_date': unified_strdate('20130101'),
                'formats': [{'url': 'http://example.com/video0.ts'}],
            }

    ie = TestIE()
    result = ie.extract('http://example.com')
    assert result['id'] == 'test1'
    assert result['title'] == 'test'
    assert result['upload_date'] == '20130101'
    assert len(result['formats']) == 1

# Generated at 2022-06-24 11:43:58.513349
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = FileDownloader({
        'progress_hooks': [lambda d: None],
        'nocheckcertificate': True,
    })
    return isinstance(HttpQuietDownloader(
        ydl, {'continuedl': True, 'quiet': True, 'noprogress': True}), HttpFD)

# Generated at 2022-06-24 11:44:11.290951
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    import traceback
    import mock

    error = ValueError('test')
    error.errno = 42

    # FragmentFD.report_retry_fragment calls FileDownloader.to_screen
    # with pre-formatted message
    with mock.patch('youtube_dl.downloader.FileDownloader.to_screen') as to_screen:
        FragmentFD({}, {}, {}, {}).report_retry_fragment(error, 1, 1, 2)
        to_screen.assert_called_once_with(
            '[download] Got server HTTP error: test (caused by ValueError('
            '"test",), errno=42). Retrying fragment 1 (attempt 1 of 2)...')

    # Make sure the method does not raise any exceptions

# Generated at 2022-06-24 11:44:17.296467
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from ..utils import compat_str
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: compat_str(args)
    fd.format_retries = lambda r: '%d' % r
    assert fd.report_retry_fragment(
        Exception(), 10, 7, 8), (
        '[download] Got server HTTP error: ' +
        'Exception(). Retrying fragment 10 (attempt 7 of 8)...')

if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:44:22.689453
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class MockYoutubeDL(object):
        def to_screen(self, *args, **kargs):
            pass

    ydl = MockYoutubeDL()
    dl = HttpQuietDownloader(ydl)
    dl.to_screen('some_text')



# Generated at 2022-06-24 11:44:32.712638
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=protected-access
    # TODO: test _start_frag_download
    # TODO: test _finish_frag_download
    # TODO: test _prepare_frag_download
    # TODO: test _prepare_and_start_frag_download
    # TODO: test _download_fragment
    # TODO: test _append_fragment
    # TODO: test _read_ytdl_file
    # TODO: test _write_ytdl_file
    # TODO: test __do_ytdl_file
    # TODO: test report_skip_fragment
    # TODO: test report_retry_fragment
    # TODO: test __init__
    pass

# Generated at 2022-06-24 11:44:33.331545
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    pass

# Generated at 2022-06-24 11:44:43.350491
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        FD_NAME = 'testfd'
        def temp_name(self, filename):
            return '%s.tmp.testfd' % filename
        def ytdl_filename(self, filename):
            return '%s.tmp.ytdl' % filename

    ydl = BaseYoutubeDL()
    ydl.params['noprogress'] = True
    testfd = TestFD(ydl)
    assert testfd.params['noprogress'] == True
    assert testfd.params['retries'] == 0
    assert testfd.params['keep_fragments'] == False

    ydl.params['retries'] = 5
    ydl.params['keep_fragments'] = True
    testfd = TestFD(ydl)

# Generated at 2022-06-24 11:44:55.672794
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TFD(FragmentFD):
        def __init__(self, toscreen=lambda *args, **kargs: None):
            self.toscreen = toscreen

    fd = TFD()

    def test(args, exc, retries):
        frag_index, count, retries = args
        error_message = str(exc)
        expected_message = 'Got server HTTP error: %s. Retrying fragment %d (attempt %d of %s)...' % (
            error_message, frag_index, count, fd.format_retries(retries))
        fd.report_retry_fragment(exc, frag_index, count, retries)
        assert fd.screen_data == [(expected_message,)]
    test((1, 2, 3), Exception('hello'), 3)

# Generated at 2022-06-24 11:45:04.095009
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    ydl = object()
    params = {
        'noprogress': False,
        'ratelimit': None,
        'retries': 3,
        'fragment_retries': 0,
    }
    err = TypeError('error message')
    fd = FragmentFD(ydl, params)
    fd.to_screen = lambda *args: args
    assert fd.report_retry_fragment(err, 4, 5, 4) == ('[download]',
            ('Got server HTTP error: TypeError("\'error message\'",).',
             'Retrying fragment 4 (attempt 5 of 4)...'))


# Generated at 2022-06-24 11:45:04.958186
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    FragmentFD(object())

# Generated at 2022-06-24 11:45:11.951326
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..compat import compat_urllib_request
    extractors = gen_extractors()
    for name, ie in extractors.items():
        try:
            compat_urllib_request.urlopen(ie.IE_NAME)
        except compat_urllib_request.URLError:
            continue
        req = compat_urllib_request.Request(ie.IE_NAME)
        req.add_header('Ytdl-request-test', 'True')
        try:
            compat_urllib_request.urlopen(req)
        except compat_urllib_request.URLError:
            continue

# Generated at 2022-06-24 11:45:23.064350
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class DummyFragmentFD(FragmentFD):
        def __init__(self):
            super(DummyFragmentFD, self).__init__(None)
            self.to_screen_calls = []

        def to_screen(self, *args, **kargs):
            self.to_screen_calls.append((args, kargs))

    fd = DummyFragmentFD()
    fd.report_retry_fragment(
        Exception('test err'),
        frag_index=2,
        count=3,
        retries=1)
    assert fd.to_screen_calls[0][0] == (
        '[download] Got server HTTP error: test err. Retrying fragment 2 (attempt 3 of 1)...',)


# Generated at 2022-06-24 11:45:31.337628
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(False)
    assert fd.report_skip_fragment(-2) == None
    assert fd.report_skip_fragment(-1) == None
    assert fd.report_skip_fragment(0)  == None
    assert fd.report_skip_fragment(1)  == None
    assert fd.report_skip_fragment(2)  == None

# Generated at 2022-06-24 11:45:36.886213
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FragmentFDTest(FragmentFD):
        def report_skip_fragment(self, frag_index):
            self.frag_index = frag_index
    ffd = FragmentFDTest(None, {'skip_unavailable_fragments': True})
    ffd.frag_index = None
    ffd.report_skip_fragment(3)
    assert ffd.frag_index == 3

# Generated at 2022-06-24 11:45:48.220436
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    import io

    class NoSkipFD(FragmentFD):
        SKIP_UNAVAILABLE_FRAGMENTS = False

        def __init__(self, ydl):
            FragmentFD.__init__(self, ydl)
            self.to_screen = self.report_skip_fragment = self.report_error = self._hook_progress = lambda *x: None

    class FakeYDL:
        params = {}

    class FakeFD(HttpFD, FileDownloader):
        def __init__(self, ydl, params):
            FileDownloader.__init__(self, ydl)
            HttpFD.__init__(self, ydl, params)
            self.sim

# Generated at 2022-06-24 11:45:55.650646
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class DummyYDL(object):
        params = {}
        verbose = False
        def to_screen(self, *args, **kwargs):
            to_screen.args = args
            to_screen.kwargs = kwargs

    ydl = DummyYDL()
    qdl = HttpQuietDownloader(ydl, {})
    qdl.to_screen('test')
    assert to_screen.args == ()
    assert to_screen.kwargs == {}

# Generated at 2022-06-24 11:46:07.346787
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    # Test all known IE
    for ie_name in get_info_extractor(None)._ies:
        ie = get_info_extractor(ie_name)
        if not hasattr(ie, '_WORKING'):
            continue
        if ie.IE_NAME == 'Generic':
            continue
        if ie.IE_NAME == 'ARVE':
            continue
        if ie.IE_NAME == 'Youtube':
            continue
        if ie.IE_NAME == 'Soundcloud':
            continue
        if ie.IE_NAME == 'Vimeo':
            continue
        if ie.IE_NAME == 'Vidme':
            continue
        if ie.IE_NAME == 'Vevo':
            continue

# Generated at 2022-06-24 11:46:15.891970
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # Case 1: skip_unavailable_fragments is False
    class MockFragmentFD(FragmentFD):

        def __init__(self, params):
            self.params = params
            self.to_screen_buffer = ''

        def to_screen(self, message):
            self.to_screen_buffer = message

    class MockYDL:

        def __init__(self):
            self.params = {}

    frag_fd = MockFragmentFD({'skip_unavailable_fragments': False})
    frag_fd.ydl = MockYDL()

    frag_fd.report_skip_fragment(5)
    assert frag_fd.to_screen_buffer == '[download] Skipping fragment 5...'

    frag_fd.to_screen_buffer = ''

# Generated at 2022-06-24 11:46:19.323946
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = {
        'params': {}
    }
    qd = HttpQuietDownloader(ydl, ydl['params'])
    qd.to_screen('foo')

# Generated at 2022-06-24 11:46:26.620865
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({})
    err = KeyError('test', 'test', 1)
    assert fd.report_retry_fragment(err, 1, 1, 3) == (
        '[download] Got server HTTP error: test. Retrying fragment 1 '
        '(attempt 1 of 3)...'
    )
    assert fd.report_retry_fragment(err, 1, 3, 3) == (
        '[download] Got server HTTP error: test. Retrying fragment 1 '
        '(attempt 3 of 3)...'
    )


# Generated at 2022-06-24 11:46:37.763662
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    from .common import FileDownloader

    def test(_):
        pass

    # hooked version of report_skip_fragment
    def report_skip_fragment(self, fragment_index):
        self.report_skip_fragment_called = True
        test(self.to_screen_value.replace('%d', '1'))

    fd = FileDownloader({})
    # captured to_screen_value
    to_screen_value = None

    def to_screen(message, skip_eol=False):
        nonlocal to_screen_value
        to_screen_value = message
        sys.stdout.write(message + ('\n' if not skip_eol else ''))
        sys.stdout.flush()
    fd.to_screen = to_screen

# Generated at 2022-06-24 11:46:45.487494
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import InfoExtractor
    from .extractor import gen_extractors

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        IE_DESC = 'Dummy IE for youtube-dl unit tests'
        _TESTS = [{
            'note': 'Dummy test',
        }]

        def _real_extract(self, url):
            return []
    for ie in list(gen_extractors()) + [DummyIE()]:
        ie.add_info_extractor(DummyIE)
    ie = gen_extractors()[0]

    fd = ie._download_webpage('https://youtube.com', 'youtube')
    assert fd.ydl is ie

# Generated at 2022-06-24 11:46:54.351790
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io

    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_buffer = io.StringIO()

        def to_screen(self, *args, **kargs):
            print(*args, file=self.to_screen_buffer)

    f = TestFragmentFD()
    f.params['noprogress'] = True
    f.report_skip_fragment(1)
    assert f.to_screen_buffer.getvalue() == '[download] Skipping fragment 1...\n'

# Generated at 2022-06-24 11:47:02.282538
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from ..extractor import get_info_extractor
    from .common import FakeYDL

    def local_report_skip_fragment(self, frag_index):
        print('Skipping fragment %d' % frag_index)

    class TestFragmentFD(FragmentFD):
        def report_skip_fragment(self, frag_index):
            local_report_skip_fragment(self, frag_index)

    test_ie = get_info_extractor('test_fragments')
    test_ie.fragment_index = 0

    ydl = FakeYDL()
    ffd = TestFragmentFD(ydl, {'skip_unavailable_fragments': True})
    ffd.add_info_extractor(test_ie)


# Generated at 2022-06-24 11:47:14.408317
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import unittest

    class FragmentFDTest(unittest.TestCase):
        def _test_construction(self, args):
            from ..downloader.common import FileDownloader
            from ..downloader import Downloader, HttpQuietDownloader
            from ..utils import FileDownloader as UFD
            from .fragment import FragmentFD
            from .dash import DASHFD
            from .m3u8 import M3U8FD
            from .hls import HLSFD
            from .hlsnative import HLSNativeFD
            from .http import HttpFD
            from .f4m import F4MFD
            from .fragment import FragmentFD
            downloader = Downloader(FileDownloader())
            downloader.params.update(args)

# Generated at 2022-06-24 11:47:24.839681
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    progress_hooks = []
    postproc_hooks = []
    def my_hook(d):
        progress_hooks.append(d)
    def my_postproc_hook(d):
        postproc_hooks.append(d)
    class DummyYtdl(object):
        def __init__(self, params):
            self.params = params
            self.to_screen_lock = 0
    class DummyInfo(object):
        pass
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
    }
    ydl = DummyYtdl(params)
    info_dict = DummyInfo()
    info_dict.filename = 'filename'
    dl = HttpQuietDownloader(ydl, params)
   

# Generated at 2022-06-24 11:47:35.256244
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class FakeYtdl():
        def __init__(self):
            self.params = {}

    ydl = FakeYtdl()
    opts = {
        'continuedl': True,
        'logger': None,
        'nopart': False,
        'quiet': True,
        'noprogress': True,
        'retries': 0,
        'test': False,
        'ratelimit': None,
    }

    dl = HttpQuietDownloader(ydl, opts)
    dl.report_retry_fragment('error', 0, 3, 3)
    assert dl.opts == opts

# Generated at 2022-06-24 11:47:36.342636
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass # Currently no unit test for this class

# Generated at 2022-06-24 11:47:40.061551
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader

    params = {'continuedl': True, 'quiet': True, 'noprogress': True}
    fd = FileDownloader({}, params)
    assert isinstance(fd, HttpQuietDownloader)

# Generated at 2022-06-24 11:47:52.074210
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': '1.0',
        'retries': 10,
        'nopart': False,
        'test': True,
    }
    ydl = object()
    dl = HttpQuietDownloader(ydl, params)

# Generated at 2022-06-24 11:47:54.164855
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    hqd = HttpQuietDownloader(None, {'noprogress': False})
    hqd.to_screen('test')

# Generated at 2022-06-24 11:48:01.151196
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FragmentFD(object):
        def report_retry_fragment(self, err, frag_index, count, retries):
            assert err == 'err'
            assert frag_index == 1
            assert count == 2
            assert retries == (3, 4)
    FragmentFD().report_retry_fragment('err', 1, 2, 3)
    FragmentFD().report_retry_fragment('err', 1, 2, -3)
    FragmentFD().report_retry_fragment('err', 1, 2, (3, 4))


# Generated at 2022-06-24 11:48:08.120595
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .common import FileDownloader
    extractor_classes = gen_extractor_classes()

    class MyFakeYDL(object):
        def __init__(self, params):
            self.params = params
    test_params = {
        'ratelimit': '1',
        'retries': '3',
        'nopart': True,
        'test': True,
    }
    ydl = MyFakeYDL(test_params)
    test_FD = FileDownloader(ydl, {})
    http_dl = HttpQuietDownloader(test_FD, extractor_classes)

    test_params['continuedl'] = True
    test_params['quiet'] = True
    test_params['noprogress'] = True


# Generated at 2022-06-24 11:48:12.907675
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    assert FragmentFD().format_retries(3) == '3'
    assert FragmentFD().format_retries('infinite') == 'infinite'
    assert FragmentFD().format_retries(0) == '0'
    assert FragmentFD().format_retries(-1) == '0'

# Generated at 2022-06-24 11:48:24.677786
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from argparse import Namespace
    from .compat import compat_urllib_request
    from ..extractor import VideoExtractor

    from collections import defaultdict

    class MockInfoExtractor(VideoExtractor):
        def __init__(self):
            self.name = 'i'

    class MockYDL(object):
        def __init__(self):
            self.params = defaultdict(lambda: None, {
                'outtmpl': 'f',
                'continuedl': True,
                'test': True,
            })
            self.info_extractors = []

        def add_info_extractor(self, ie):
            self.info_extractors.append(ie)

        def to_screen(self, *args, **kargs):
            pass


# Generated at 2022-06-24 11:48:30.102249
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = FileDownloader(params={'logger': DummyLogger()})
    fd = FragmentFD(ydl, params={'skip_unavailable_fragments': True})
    assert isinstance(fd, FragmentFD)
    assert fd.params['skip_unavailable_fragments']


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:48:40.237533
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func
    # An info extractor that returns a test downloader
    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'is_live': False,
                'title': 'test',
                'formats': [],
            }
    # A test downloader
    class TestDownloader(HttpQuietDownloader):
        FD_NAME = 'test'
        def real_download(self, filename, info_dict):
            assert self.ydl.params['outtmpl'] == '%(id)s'
            assert info_dict['id'] == 'test'
            assert self.params['nopart']

# Generated at 2022-06-24 11:48:47.835266
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import get_info_extractor

    class DummyYDL(object):
        def __init__(self, params):
            self.params = params
            self.ie = get_info_extractor('youtube', downloader=self)

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

    dl = HttpQuietDownloader(DummyYDL({
        'quiet': True,
        'noprogress': True,
        'retries': 0,
    }), {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'retries': 0,
    })

    # get with retries

# Generated at 2022-06-24 11:48:56.064048
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader(100)
    assert ydl._opts['continuedl']
    assert ydl._opts['quiet']
    assert ydl._opts['noprogress']
    assert ydl._opts['ratelimit'] == 100
    assert ydl._opts['retries'] == 0
    assert ydl._opts['nopart'] is False
    assert ydl._opts['test'] is False

# Generated at 2022-06-24 11:49:05.311239
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from .extractor import gen_extractors
    gen_extractors()

    downloader = FileDownloader({})

    fd = FragmentFD(downloader, {
        'total_frags': 7,
    })

    # Fragment index 5 should be printed as it is nonzero
    fd.report_skip_fragment(5)
    # Fragment index 0 should be printed too
    fd.report_skip_fragment(0)

    # Same fragments but keeping fragments on disk should not print anything
    fd = FragmentFD(downloader, {
        'total_frags': 7,
        'keep_fragments': True,
    })

    fd.report_skip_fragment(5)

# Generated at 2022-06-24 11:49:13.298814
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    fd.to_screen = lambda *x: x
    assert fd.report_retry_fragment(
        IOError('foo'), 1, 2, 3) == [
            'WARNING: [download] Got server HTTP error: foo. Retrying fragment 1 (attempt 2 of 3)...']

if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-24 11:49:20.199781
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = object()
    dl = HttpQuietDownloader(ydl, {'continuedl': True, 'quiet': True, 'noprogress': True, 'ratelimit': None, 'retries': 0})
    class MyFileDownloader(FragmentFD):
        def __init__(self, params):
            FragmentFD.__init__(self, ydl, params)
    ydl = MyFileDownloader({'skip_unavailable_fragments': False})
    ydl.to_screen = dl.to_screen
    ydl.report_retry_fragment(None, 2, 3, 4)

# Generated at 2022-06-24 11:49:26.905320
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class YDL(object):
        params = {}

    ydl = YDL()

    ydl.params.update({'quiet': True})
    dl = HttpQuietDownloader(ydl, {})

    ydl.params.update({'quiet': False})
    dl = HttpQuietDownloader(ydl, {})

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:49:38.197661
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import all_extractors_cls
    from ..postprocessor import FFmpegMetadataPP

    init_kwargs = {
        'params': {
            'noprogress': True,
        },
    }
    h = HttpQuietDownloader(None, init_kwargs)

    assert 'http' in h._ydl.params
    assert 'https' in h._ydl.params

    # HttpQuietDownloader must support all extractors
    for ie_cls in all_extractors_cls:
        name = ie_cls.IE_NAME.lower()
        assert name in h._ydl._ies
        assert h._ydl._ies[name] is ie_cls

    # HttpQuietDownloader must support all postprocessors

# Generated at 2022-06-24 11:49:39.343892
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .common import FileDownloader
    test = FileDownloader(None)
    test.to_screen('hello')

# Generated at 2022-06-24 11:49:43.162579
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpDownloader
    ie = InfoExtractor()
    ie._downloader = HttpDownloader(ie, ie.params)
    hqd = HttpQuietDownloader(ie, ie.params)
    hqd.to_screen('A message')
    assert True

# Generated at 2022-06-24 11:49:47.750974
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestYdl:
        def __init__(self):
            self.params = dict()
            self.to_screen = ""
        def to_screen(self, message):
            self.to_screen = message
    stdout = 'test'
    testYdl = TestYdl()
    quietDownloader = HttpQuietDownloader(testYdl, testYdl.params)
    quietDownloader.to_screen(stdout)
    assert testYdl.to_screen == ""

# Generated at 2022-06-24 11:49:50.709833
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    downloader = HttpQuietDownloader(None, {'quiet':True})
    assert (downloader.to_screen('foo') is None)

# Generated at 2022-06-24 11:50:01.807173
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeFileDownloader(object):
        def __init__(self, ydl):
            self.params = {'noprogress': False}
            self.to_screen_allowed = True
            self.ydl = ydl
    ydl = FakeYDL()
    fd = HttpQuietDownloader(ydl, {'noprogress': True})
    assert fd.to_screen_allowed is False

    fd = HttpQuietDownloader(ydl, {'noprogress': False})
    assert fd.to_screen_allowed is True

    fd = HttpQuietDownloader(ydl, {})
    assert fd.to_screen_allowed is False


# Generated at 2022-06-24 11:50:11.298231
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class YDL:
        def __init__(self):
            self.params = {}

    ydl = YDL()
    dl = HttpQuietDownloader(ydl, {
        'quiet': True,
        'noprogress': True,
        'ratelimit': '4000k',
        'retries': 5,
        'nopart': False,
    })
    assert dl.params['noprogress'] is True
    assert dl.params['ratelimit'] == '4000k'
    assert dl.params['retries'] == 5
    assert dl.params['nopart'] is False
    assert dl.ydl is ydl

# Generated at 2022-06-24 11:50:19.866130
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import random
    import tempfile
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSApplicationFD
    from ..utils import OnDemandPagedList

    def build_fd(fd_cls, params=None, info_dict=None, ydl=None):
        params = params or {}
        return fd_cls(
            ydl or {
                'params': params,
                'progress_hooks': [],
            },
            info_dict or {},
        )

    # FragmentFD itself should fail without .download() implementation
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-24 11:50:27.124729
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .http import HttpFD
    from .rtmp import RtmpFD
    from .hls import HlsFD

    from ..extractor.common import InfoExtractor
    from ..compat import compat_str
    from ..utils import encodeFilename, sanitize_open

    class MockYDL(object):
        def __init__(self):
            self.params = {
                'continuedl': True,
                'quiet': True,
                'noprogress': True,
                'ratelimit': None,
                'retries': 0,
                'nopart': False,
                'test': False,
            }

    class IE(InfoExtractor):
        pass

    # Constructor test. Check that correct FileDownloader is created based on url
    # fragment markers (itd, itm or its)
    ie = IE

# Generated at 2022-06-24 11:50:33.978199
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dummy_ydl = object()
    dummy_params = {'quiet': True}
    dl = HttpQuietDownloader(dummy_ydl, dummy_params)
    assert dl.ydl is dummy_ydl
    assert dl._params == dummy_params


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 11:50:35.607524
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD({}, {}, None, None, None)
    assert isinstance(fd.params, dict)

# Generated at 2022-06-24 11:50:48.558226
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_info_dict = {
        'url': 'http://example.com',
        'http_headers': {'key': 'value'},
    }
    dl = HttpQuietDownloader(
        None, {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': '512k',
            'nopart': True,
        }
    )
    success = dl.download(None, test_info_dict)
    assert success == True
    assert dl.ydl == None
    assert dl.params == {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': '512k',
        'nopart': True,
    }

# Generated at 2022-06-24 11:50:50.046343
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # This test is currently empty, but it should be present
    # in order to ensure that the method to_screen of class
    # HttpQuietDownloader is tested.
    pass

# Generated at 2022-06-24 11:50:54.238648
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader(None, {'noprogress': True})
    assert dl._opts['noprogress']
    assert dl._progress_hooks == []

# Generated at 2022-06-24 11:50:58.304451
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    yd = HttpQuietDownloader(None, {'quiet': False})
    yd.to_screen('This should not be displayed')
    yd = HttpQuietDownloader(None, {'quiet': True})
    yd.to_screen('This should be displayed')

# Generated at 2022-06-24 11:51:02.271621
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from ..utils import FakeYDL
    fd = FragmentFD(FakeYDL(), {}, None)
    fd.to_screen = lambda s: s
    assert fd.report_skip_fragment(1) == '[download] Skipping fragment 1...'

# Generated at 2022-06-24 11:51:04.198736
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-24 11:51:15.005907
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import io
    # Create a fake stdout to verify the output of to_screen
    fake_stdout = io.BytesIO()
    orig_stdout = sys.stdout
    sys.stdout = fake_stdout
    message = b'This is a fake HttpQuietDownloader message'

# Generated at 2022-06-24 11:51:23.299261
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..utils import FileDownloader
    from collections import namedtuple
    from .http import HttpFD
    test_obj = namedtuple('TestObj', 'ydl')
    ydl = test_obj(ydl=test_obj(params={}))
    assert isinstance(FragmentFD(ydl, 'http://example.com'), FileDownloader)
    assert isinstance(FragmentFD(ydl, 'http://example.com', {'ratelimit': 10}), FragmentFD)
    assert isinstance(FragmentFD(ydl, 'http://example.com', {'retries': 10}), HttpFD)
    assert isinstance(FragmentFD(ydl, 'http://example.com', {'nopart': True}), HttpFD)

# Generated at 2022-06-24 11:51:33.625971
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = object()
    dl = HttpQuietDownloader(ydl, {'quiet': False})
    assert dl.to_screen.func_closure[0].cell_contents == ydl
    assert dl.to_screen.func_closure[1].cell_contents == ''
    assert dl.to_screen.func_closure[2].cell_contents is None
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.to_screen.func_closure[0].cell_contents == ydl
    assert dl.to_screen.func_closure[1].cell_contents == ' '
    assert dl.to_screen.func_closure[2].cell_contents is None


if __name__ == '__main__':
    test_

# Generated at 2022-06-24 11:51:39.406167
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kwargs: args
    fd.format_retries = lambda x: '{}'.format(x)
    assert (
        fd.report_retry_fragment(None, 17, 3, 3) ==
        ('[download] Got server HTTP error: None. Retrying fragment 17 (attempt 3 of 3)...',))

# Generated at 2022-06-24 11:51:44.270770
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # It is important to test that the constructor doesn't throw exceptions
    try:
        FragmentFD(object(), object())
    except Exception as err:
        pytest.fail('Unexpected error obtained: %r' % err)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:51:52.764795
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Stub class to return the output of HttpQuietDownloader.to_screen
    class TestHttpQuietDownloader(HttpQuietDownloader):
        def to_screen(self, *args, **kargs):
            TestHttpQuietDownloader.to_screen_output = super(TestHttpQuietDownloader, self).to_screen(*args, **kargs)
    dl = TestHttpQuietDownloader({}, {})
    dl.to_screen('[download] %s of %s at %s ETA %s' %
        ('100K', '200K', '201K/s', '1:40:00'))
    assert TestHttpQuietDownloader.to_screen_output is None

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:51:57.112314
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys

    fd = FragmentFD(None, {}, None)
    sysout = sys.stdout
    try:
        sys.stdout = sys.stderr = open(os.devnull, 'w')
        fd.report_skip_fragment(42)
    finally:
        sys.stdout = sysout

# Generated at 2022-06-24 11:52:02.464654
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import StringIO
    output = StringIO.StringIO()

    dl = HttpQuietDownloader(
        None,
        {},
    )
    dl.to_screen = lambda *args, **kargs: output.write(' '.join(map(str, args)) + os.linesep)
    dl.to_screen('a', 'b', 'c')
    assert output.getvalue() == ''
    dl.to_screen('a', 'b', 'c', {'end': ' '}, 'd', 'e', 'f')
    assert output.getvalue() == 'a b c d e f' + os.linesep

if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:52:08.214465
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .extractor import gen_extractor_classes
    for ie in gen_extractor_classes():
        if ie.IE_NAME == 'generic':
            continue
        ie = ie()
        if ie.suitable(None):
            ie.download(None)
            break
    else:
        assert False, 'No extractor is suitable'

    # This should not raise anything
    ie.report_error(None, None)

# Generated at 2022-06-24 11:52:18.683416
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        def _prepare_frag_download(self, ctx):
            pass

    from ..extractor import YoutubeIE
    from ..utils import FakeYDL
    fd = TestFD(FakeYDL(), {'fragment_retries': 3, 'skip_unavailable_fragments': True})
    assert isinstance(fd, TestFD)
    assert fd.params == {
        'keep_fragments': False,
        'fragment_retries': 3,
        'skip_unavailable_fragments': True,
    }
    # Note that the class must be instantiated with a custom _prepare_frag_download() method