

# Generated at 2022-06-24 11:42:28.015195
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD
    from .hlsnative import HLSFD_Native
    from .fragment import FragmentFD
    downloader = HttpFD(None)
    downloader.to_screen = lambda *args: args
    assert downloader.report_retry_fragment(ValueError('test'), 1, 2, 3) == (
        '[download] Exception: test. Retrying fragment 1 (attempt 2 of 3)...',)
    assert downloader.report_retry_fragment(ValueError('test'), 1, 2, 1) == (
        '[download] Exception: test. Retrying fragment 1 (attempt 2 of 1)...',)
    downloader = HLSFD(None)
    download

# Generated at 2022-06-24 11:42:36.885771
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

    ie = get_info_extractor('test_fragments')
    fd = TestFD(ie.ydl, ie.params)
    assert fd.params.get('fragment_retries') == 10
    assert fd.params.get('skip_unavailable_fragments') is False
    assert fd.params.get('keep_fragments') is False

    ie = get_info_extractor('test_fragments_custom_options')
    fd = TestFD(ie.ydl, ie.params)
    assert fd.params.get('fragment_retries') == 2
    assert fd.params.get('skip_unavailable_fragments')

# Generated at 2022-06-24 11:42:43.990739
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .options import opts
    from .extractor import get_info_extractor
    from .extractor.http import HttpIE

    class MockInfoExtractor(HttpIE):
        IE_NAME = 'mock'

        def _real_extract(self, url):
            return self.url_result(url, 'dummy')

    ie = get_info_extractor(MockInfoExtractor.IE_NAME)
    ie.add_info_extractor(MockInfoExtractor)

    def _get_info(url, options=None):
        downloader = FragmentFD(opts)
        return downloader.extract_info(ie.suitable(url), download=False, ie=ie, force_generic_extractor=True)


# Generated at 2022-06-24 11:42:54.894152
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import re
    import sys
    import io
    import unittest

    class MockFragFD(FragmentFD):
        def __init__(self):
            class _DummyYDL:
                def __init__(self):
                    self.params = {
                        'skip_download': True,
                    }
            FragmentFD.__init__(self, _DummyYDL(), {'test': True})

    class ToScreenTester(unittest.TestCase):
        def setUp(self):
            # Capture stdout
            self._real_stdout = sys.stdout
            sys.stdout = self._stringio = io.StringIO()

        def tearDown(self):
            sys.stdout = self._real_stdout

        def test(self):
            frag_fd = MockFragFD()
            frag_

# Generated at 2022-06-24 11:42:57.733526
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({})
    fd = FragmentFD(ydl, {'progress_hooks': []})
    assert fd.FD_NAME == 'fragment'



# Generated at 2022-06-24 11:43:10.002938
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class MockFD(FragmentFD):
        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_calls.append(message)

    fd = MockFD()

    fd.report_retry_fragment(None, 0, 5, 3)
    assert (
        fd.to_screen_calls[0]
        == '[download] Got server HTTP error: None. Retrying fragment 0 (attempt 5 of 3)...')

    fd.report_retry_fragment(Exception('test error'), 1, 6, 3)

# Generated at 2022-06-24 11:43:17.565214
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeYDL(object):
        def __init__(self):
            self.to_screen_count = 0
            self.to_screen_msg = None

        def to_screen(self, *args, **kargs):
            self.to_screen_count += 1
            self.to_screen_msg = args

    class FakeFD(object):
        def __init__(self, ydl):
            self.ydl = ydl

    y = FakeYDL()
    f = FakeFD(y)
    h = HttpQuietDownloader(f, {})
    h.to_screen('test')
    assert y.to_screen_count == 0
    assert y.to_screen_msg is None


if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:43:28.408519
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self, ydl):
            super(TestFragmentFD, self).__init__(ydl)
            self._msgs = []

        def to_screen(self, s):
            self._msgs.append(s)

    info_dict = {}
    ydl = {
        'params': {},
    }
    fd = TestFragmentFD(ydl)
    ctx = {
        'filename': 'foo.mp4',
        'total_frags': 3,
    }
    err = Exception()
    fd._prepare_frag_download(ctx)

    fd.report_retry_fragment(err, 1, 1, 3)

# Generated at 2022-06-24 11:43:38.447014
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import copy
    import tempfile
    import sys
    from ..extractor import get_info_extractor

    # Hack: disable stderr when importing youtube_dl
    orig_stderr = sys.stderr
    sys.stderr = tempfile.TemporaryFile()

    test_fragment_fd = None

# Generated at 2022-06-24 11:43:44.606317
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({})
    def to_screen(line):
        assert line == '[download] Got server HTTP error: Test error. Retrying fragment 1 (attempt 2 of 5)...'
    fd.to_screen = to_screen
    fd.report_retry_fragment('Test error', 1, 2, 5)



# Generated at 2022-06-24 11:43:57.946767
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = {}
    params = {'skip_unavailable_fragments': False, 'verbose': True, 'progress_hooks': []}
    params['fragment_retries'] = 0
    fd = FragmentFD(ydl, params)
    assert fd.params['fragment_retries'] == 0
    assert fd.params['skip_unavailable_fragments'] == False
    assert fd.params['verbose'] == True
    assert fd.params['progress_hooks'] == []

    # Test with a valid value
    params['fragment_retries'] = 20
    fd = FragmentFD(ydl, params)
    assert fd.params['fragment_retries'] == 20

    # Test with an invalid value

# Generated at 2022-06-24 11:44:04.630023
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpQuietDownloader
    output = []
    def _print(msg):
        output.append(msg)
    HttpQuietDownloader({'logger': {'_print': _print}}, {}).to_screen('hello')
    assert not output

# Generated at 2022-06-24 11:44:09.975542
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class DummyYDL(object):
        def __init__(self):
            self.to_screen = lambda *args: args
    ydl = DummyYDL()
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    args = ('msg', 'more', 'args')
    assert dl.to_screen(*args) is None

# Generated at 2022-06-24 11:44:18.468740
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    fd = HttpQuietDownloader({}, {})
    fd.to_screen = lambda *args, **kargs: args
    assert fd.to_screen('foo', 'bar') == ('foo', 'bar')
    assert fd.to_screen('foo', 'bar', end='\r') == ('foo', 'bar', '\r')
    assert fd.to_screen('foo', 'bar', now='error') == ('foo', 'bar', 'error')
    assert fd.to_screen('foo', 'bar', now='error', end='\r') == ('foo', 'bar', 'error', '\r')


if __name__ == '__main__':
    test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:44:30.488420
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import io

    class MyHttpQuietDownloader(HttpQuietDownloader):
        def __init__(self, ydl, params):
            super(type(self), self).__init__(ydl, params)
            self.my_out_stream = io.StringIO()
            self.__out_stream = sys.stdout

        def to_screen(self, *args, **kargs):
            sys.stdout = self.my_out_stream
            super(type(self), self).to_screen(*args, **kargs)
            sys.stdout = self.__out_stream

    hqd = MyHttpQuietDownloader(None, {})
    hqd.to_screen('test')
    assert hqd.my_out_stream.getvalue() == ''


# Generated at 2022-06-24 11:44:33.964693
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest

    class FragmentFDTests(unittest.TestCase):
        def setUp(self):
            self.fd = FragmentFD(None)

    unittest.main()


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:44:36.132854
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None)
    fd.to_screen = lambda *args: None
    fd.report_skip_fragment(42)


# Generated at 2022-06-24 11:44:45.065390
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():

    class TestFD(FragmentFD):
        class YDL(object):
            def __init__(self):
                self.params = {}

        def __init__(self, ydl):
            self.to_screen = self.screen
            self.ydl = ydl

        def format_retries(self, retries):
            return '%d' % retries

        def screen(self, *args, **kargs):
            self.messages.append(args[0])

    fd = TestFD(TestFD.YDL())
    fd.messages = []
    fd.report_retry_fragment(None, 10, 1, 3)
    assert (fd.messages[0] ==
        '[download] Got server HTTP error: . Retrying fragment 10 (attempt 1 of 3)...')
    fd

# Generated at 2022-06-24 11:44:56.105190
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class MyLogger(object):
        def debug(self, *args):
            pass
    ydl = {
        'params': {
            'verbose': False
        },
        'logger': MyLogger()
    }
    hqd = HttpQuietDownloader(ydl, {'continuedl': True})
    assert hqd.params['continuedl']
    assert hqd.params['quiet']
    assert hqd.params['noprogress']
    assert hqd.params['logger'] == MyLogger()
    assert hqd.params['verbose'] is False
    assert hasattr(hqd, 'to_stderr')

# Generated at 2022-06-24 11:45:06.160570
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import tempfile
    outf = tempfile.TemporaryFile()
    class Opts(object):
        def __init__(self):
            self.noprogress = True
            self.verbose = True
            self.ratelimit = 1
            self.retries = 1
    class YDL(object):
        def to_screen(self, msg, **kwargs):
            outf.write(msg + '\n')
        def to_stdout(self, msg):
            outf.write(msg + '\n')
        def to_stderr(self, msg):
            outf.write(msg + '\n')
        def report_warning(self):
            pass
        def report_error(self):
            pass
    ydl = YDL()
    opts = Opts()


# Generated at 2022-06-24 11:45:17.155051
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import sizeof_fmt
    from .f4m import F4mFD
    from .m3u8 import M3u8FD

    class DummyYDL(object):
        def __init__(self, params):
            self.params = params
        def to_screen(self, s):
            print(s)

    def download(fd_name, params):
        ydl = DummyYDL(params)
        params.update({
            'logger': ydl.to_screen,
            'progress_hooks': [],
        })
        extractor = gen_extractors()[fd_name]()
        fd = extractor._get_info_extractor()(params)

# Generated at 2022-06-24 11:45:24.740675
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class MockYDL():
        def __init__(self, out):
            self.logger = {'out': out, 'realout': out}
            self.params = {'ignoreerrors': False}

    h = HttpQuietDownloader(MockYDL('stdout'), {})
    h.to_screen(u'Test')
    assert h.ydl.logger['realout'] == 'stdout'

    h = HttpQuietDownloader(MockYDL(None), {})
    h.to_screen(u'Test')
    assert h.ydl.logger['realout'] is None

# Generated at 2022-06-24 11:45:32.332750
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # pylint: disable=protected-access
    class TestFD(FragmentFD):
        def __init__(self):
            self.to_screen_list = []
        def to_screen(self, *args, **kargs):
            self.to_screen_list.append((args, kargs))
    fd = TestFD()
    fd._report_skip_fragment(1)
    assert (('[download] Skipping fragment 1...',), {}) in fd.to_screen_list

# Generated at 2022-06-24 11:45:34.428477
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import YoutubeDL
    ydl = YoutubeDL({'outtmpl': '%(id)s', 'continuedl': True})
    FragmentFD(ydl, {})

# Generated at 2022-06-24 11:45:38.641550
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    httpQuietDownloader = HttpQuietDownloader(
        None,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'retries': 0,
            'nopart': False,
            'test': False,
        }
    )
    assert httpQuietDownloader.to_screen('test') is None

# Generated at 2022-06-24 11:45:46.279857
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor import get_info_extractor
    fd = FragmentFD({})
    fd._screen_file = open('test_fd', 'wb')
    ie = get_info_extractor('fragment:skip:0')
    fd.add_info_extractor(ie)
    res = fd.real_download('fragment:skip:0')
    assert res['status'] == 'finished'
    os.unlink('test_fd')


# Generated at 2022-06-24 11:45:50.184233
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Testing constructor of FragmentFD
    ydl = object()
    params = {}
    info_dict = {}
    fd = FragmentFD(ydl, params, info_dict)
    assert fd.ydl is ydl
    assert fd.params is params
    assert fd.info_dict is info_dict

# Generated at 2022-06-24 11:46:00.880638
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import tempfile
    import types
    from ..utils import SilentPopen

    # sys.stderr = open(os.devnull, 'w')
    sys.stderr = tempfile.TemporaryFile()
    # sys.stderr = sys.stdout

    class TestYoutubeDL(object):
        def __init__(self, params):
            self.params = dict(params)
            self._screen_file = sys.stderr

        def params_get(self, option, default=None):
            return self.params.get(option, default)

        def trouble(self, *args, **kargs):
            self.to_screen(*args, **kargs)

        def report_warning(self, *args, **kargs):
            self.to_screen(*args, **kargs)



# Generated at 2022-06-24 11:46:02.428484
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'


# Generated at 2022-06-24 11:46:13.674070
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class YDL(object):
        def __init__(self):
            self.params = {}
            self.json_output = False

    def write_string_to_file(filename, output):
        with open(filename, 'w') as f:
            f.write(output)

    ydl = YDL()
    hqd = HttpQuietDownloader(
        ydl,
        {
            'quiet': False,
            'noprogress': False,
        }
    )
    hqd.to_screen('test string')
    assert os.path.isfile('screen.log')
    out = open('screen.log', 'r').readlines()
    assert out[0] == 'test string\n'
    write_string_to_file('screen.log', '')

# Generated at 2022-06-24 11:46:22.792876
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    """
    Test that report_skip_fragment is called with an index
    """
    from .test_HttpFD import MockYTDLSubclass
    fd = MockYTDLSubclass(FragmentFD)
    fd.to_screen = lambda *args, **kargs: args[0]
    frag_index = 4
    assert fd.report_skip_fragment(frag_index) == '[download] Skipping fragment %d...' % frag_index



# Generated at 2022-06-24 11:46:29.912422
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def my_hook(_):
        1 + 1
    ydl = {}
    params = {
        'fragment_retries': 5,
        'keep_fragments': True,
        'skip_unavailable_fragments': True,
        'no_warnings': True,
    }
    fd = FragmentFD(ydl, params)
    assert fd.params == params
    assert fd.ydl is ydl
    assert fd.report_warning != fd.fixup_url != fd._start_frag_download
    fd._prepare_frag_download({
        'filename': 'a' * 2,
        'total_frags': 1,
    })
    assert fd.report_warning != fd.fixup_url != fd._start_frag_download



# Generated at 2022-06-24 11:46:35.975504
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    def to_screen(self, message, skip_eol=False):
        assert message == '[download] Skipping fragment 0...'
    FragmentFD.to_screen = to_screen
    FragmentFD({}).report_skip_fragment(0)

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:46:44.862748
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpQuietDownloader
    from .extractor import YoutubeIE

    def test_equals(ydl, func):
        ret = ydl.extract_info(
            'https://www.youtube.com/watch?v=BaW_jenozKc',
            download=False
        )
        assert ret['title'] == func()

    ydl = YoutubeIE().ydl
    test_equals(ydl, lambda: 'Hitch Hiker\'s Guide to the Galaxy')
    test_equals(ydl, lambda: 'Hitch Hiker\'s Guide to the Galaxy')

    ydl.params['quiet'] = False
    test_equals(ydl, lambda: '[youtube] BaW_jenozKc: Downloading webpage ...')

# Generated at 2022-06-24 11:46:52.521903
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # check error message for retrying fragment
    class TestException(Exception):
        pass
    error = TestException
    from unittest.mock import MagicMock
    to_screen = MagicMock()
    class MockFragmentFD(FragmentFD):
        def to_screen(self, *args, **kargs):
            to_screen(args, kargs)
    mock_fd = MockFragmentFD()
    mock_fd.report_retry_fragment(error, 1, 1, 5)
    assert to_screen.call_count == 1
    call_args = to_screen.call_args[0]
    message = call_args[0]
    assert message.startswith('[download] Got server HTTP error:')
    assert message.endswith('Retrying fragment 1 (attempt 1 of 5)...')

# Generated at 2022-06-24 11:46:57.289348
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_str = ''

        def to_screen(self, message, skip_eol=False):
            self.to_screen_str += message

    frag_fd = TestFragmentFD()
    frag_fd.report_skip_fragment(10)
    assert frag_fd.to_screen_str == '[download] Skipping fragment 10...'

# Generated at 2022-06-24 11:47:04.148953
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from ..compat import compat_str
    from ..utils import CaptureStdout

    class FakeFDClass(FileDownloader):
        def __init__(self, ydl):
            FileDownloader.__init__(self, ydl)

        def to_screen(self, *args, **kargs):
            self.screen_file.write(' '.join(args))
            self.screen_file.write('\n')

    ydl = FakeFDClass({})
    with CaptureStdout(ydl):
        ydl.report_retry_fragment(
            RuntimeError('HTTP Error 404: Not Found'), 3, 7,
            {'max_attempts': 10})
    assert ydl.screen_file.getvalue() == 'ERROR: HTTP Error 404: Not Found\n'

# Generated at 2022-06-24 11:47:12.312238
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({'quiet': True, 'skip_unavailable_fragments': True})
    class MockFragmentFD(FragmentFD):
        """
        A mock class for FragmentFD, for testing.
        """

        def to_screen(self, msg):
            assert msg == "[download] Skipping fragment 1000..."

    fragfd = MockFragmentFD({'quiet': True, 'skip_unavailable_fragments': True})
    fragfd.report_skip_fragment(1000)

# Generated at 2022-06-24 11:47:23.133442
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor.common import InfoExtractor
    from .utils import FakeYDL
    from .compat import compat_HTTPError

    class FakeIE(InfoExtractor):
        def _real_extract(self, url):
            return {'fragment_count': 0, 'num_fragments_downloaded': 0}

    ie = FakeIE(FakeYDL())
    ffd = FragmentFD(ie)
    ffd._start_frag_download = lambda x: 0
    ffd._download_fragment = lambda a, b, c, d: (False, None)
    ffd._finish_frag_download = lambda x: None
    ffd._prepare_frag_download = lambda x: None
    ffd.to_screen = lambda *a, **k: None
    ffd.report

# Generated at 2022-06-24 11:47:30.817866
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor import gen_extractor

    class MockYoutubeDL(object):
        def __init__(self):
            self.to_screen = []

        def to_stdout(self, s):
            self.to_screen.append(s)

    class MockExtractor(gen_extractor()):
        IE_NAME = 'MockExtractor'

        def __init__(self, ydl):
            gen_extractor.__init__(self, ydl, {'name': 'MockExtractor'})
            self.extractor_type = 'fragment'
            self.progress_hooks = []

        def _real_extract(self, url):
            return {'name': 'test_FragmentFD_report_skip_fragment'}


# Generated at 2022-06-24 11:47:34.791580
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    ydl = sys.modules['__main__']
    fd = FragmentFD(ydl, {})
    fd.params['noprogress'] = True
    fd.to_screen = lambda *args, **kargs: setattr(ydl, 'to_screen_str', args[0])
    fd.report_skip_fragment(17)
    assert ydl.to_screen_str == '[download] Skipping fragment 17...'

# Generated at 2022-06-24 11:47:39.805311
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    fd = FileDownloader(HttpFD({}), {})
    message = ''
    def to_screen(msg):
        nonlocal message
        message = msg
    fd.to_screen = to_screen
    FragmentFD._report_skip_fragment(fd, 42)
    assert message == '[download] Skipping fragment 42...'

# Generated at 2022-06-24 11:47:42.407949
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    assert FragmentFD({}).report_retry_fragment(None, 0, 1, 2) == None


# Generated at 2022-06-24 11:47:51.046962
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor.common import InfoExtractor

    class DummyIE(InfoExtractor):
        def _real_extract(self, url):
            pass

    fd = FragmentFD(DummyIE(), {})
    fd.to_screen = lambda *args, **kargs: None
    assert fd.report_skip_fragment(9) is None
    assert fd.report_skip_fragment('abc') is None

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:47:56.011147
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    fd.to_screen = lambda *a, **ka: a
    assert fd.report_retry_fragment(
        'HTTP Error 404', 10, 1, 5) == (
        '[download] Got server HTTP error: HTTP Error 404. '
        'Retrying fragment 10 (attempt 1 of 5)...',)

# Generated at 2022-06-24 11:48:03.659191
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class Stub:
        def __init__(self):
            self.to_screen_str = ""

        def to_screen(self, *args, **kargs):
            self.to_screen_str = " ".join(args[0])

    fd = FragmentFD(Stub(), {}, None, None)

    stub = Stub()
    fd.to_screen = stub.to_screen

    fd.report_retry_fragment(Exception("HTTP error"), 1, 3, 10)

    assert stub.to_screen_str == '[download] Got server HTTP error: HTTP error. Retrying fragment 1 (attempt 3 of 10)...'


# Generated at 2022-06-24 11:48:12.957491
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from StringIO import StringIO
    from collections import namedtuple
    from .http import HttpQuietDownloader

    Params = namedtuple('Params', ['verbose'])
    out = StringIO()
    dl = HttpQuietDownloader(None, Params(verbose=True))
    dl.to_screen('test', file=out)
    assert out.getvalue() == 'test\n'
    dl = HttpQuietDownloader(None, Params(verbose=False))
    dl.to_screen('test', file=out)
    assert out.getvalue() == '\ntest\n'

# Generated at 2022-06-24 11:48:22.918803
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class MyHttpQuietDownloader(HttpQuietDownloader):
        def real_download(self, *args, **kargs):
            return {'tmpfilename': '', 'filename': '', 'status': True}

    ydl = {
        'params': {
            'noprogress': True,
            'retries': 0,
        }
    }

    dl = MyHttpQuietDownloader(ydl, {'test': False})
    assert dl.test == False
    assert dl.params['noprogress'] == True
    assert dl.params['retries'] == 0
    assert dl._ydl is ydl

# Generated at 2022-06-24 11:48:28.367085
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from . import YoutubeDL
    ydl_opts = {
        'quiet': True,
        'outtmpl': '%(id)s',
        'writethumbnail': True,
    }
    retcode = YoutubeDL(ydl_opts).download([
        'http://www.dailymotion.com/video/x5hsfak',
        'https://www.youtube.com/watch?v=BaW_jenozKc']
    )
    assert retcode == 0

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:48:30.998170
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert HttpQuietDownloader is not HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-24 11:48:40.861136
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .http import HttpFD
    # Create objects required for the test
    fd = FileDownloader({})
    fd.to_screen = lambda *args, **kargs: args
    http_fd = HttpFD(fd, None, None)
    http_fd.report_retry_fragment = FragmentFD.report_retry_fragment.__get__(http_fd, HttpFD)
    # Actual tests
    assert http_fd.report_retry_fragment(
        ConnectionError(), # err
        1, # frag_index
        1, # count
        10, # retries
    ) == (
        "[download] Got server HTTP error: ConnectionError('',). Retrying fragment 1 (attempt 1 of 10)...",
    )



# Generated at 2022-06-24 11:48:46.416805
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFD(FragmentFD):
        def __init__(self):
            self._screen_str = ''

        def to_screen(self, *args, **kargs):
            self._screen_str = args[0]

        def get_screen_str(self):
            return self._screen_str

    frag_fd = TestFD()
    frag_fd.report_skip_fragment(3)
    assert frag_fd.get_screen_str() == '[download] Skipping fragment 3...'


# Generated at 2022-06-24 11:48:52.245142
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import youtube_dl.FileDownloader
    import nturl2path
    fd = youtube_dl.FileDownloader({})
    fd.to_screen = lambda s: s
    err = IOError()
    frag_index = 10
    count = 1
    retries = 99
    eq_(
        # Just check that the call doesn't fail
        fd.report_retry_fragment(
            err, frag_index, count, retries),
        None)

# Generated at 2022-06-24 11:48:56.821383
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class MockYDL(object):
        def __init__(self, outtmpl=False):
            self.params = {}
            self.outtmpl = outtmpl
    ydl = MockYDL()
    ydl_quiet = HttpQuietDownloader(ydl, {})

    assert ydl_quiet.to_screen(None, b'line1', b'line2') == None

    ydl.params['verbose'] = True
    assert ydl_quiet.to_screen(None, b'line1', b'line2') == None

    ydl.params['verbose'] = False
    assert ydl_quiet.to_screen(None, b'line1', b'line2') == None

# Generated at 2022-06-24 11:49:05.055619
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import copy
    from .common import FileDownloader
    from .http import HttpFD

    params = {
        'username': 'user',
        'password': 'pass',
        'usenetrc': False,
        'quiet': False,
        'ratelimit': None,
        'retries': 10,
        'continuedl': True,
        'noprogress': False,
        'nopart': False,
        'test': False,
    }
    ydl = FileDownloader({}, params)
    qdl = HttpQuietDownloader(ydl, params)


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:49:17.400129
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Test without arguments
    dl = HttpQuietDownloader(None, None)
    assert dl.to_screen() is None
    # Test with arguments
    args = (
        '[download] Destination: /Users/paul/video.mp4',
        {
            'eta': '1:07:51',
            'speed': '2.4KiB/s',
            'filename': '/Users/paul/video.mp4',
            '_percent_str': '6.78%',
            'downloaded_bytes': '71.4MiB',
            'total_bytes': '1.1GiB',
            'total_bytes_estimate': '1.1GiB',
            'elapsed': 549.9,
        },
    )
    assert dl.to_screen(*args) is None

# Generated at 2022-06-24 11:49:18.574361
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    print('TODO')

# Generated at 2022-06-24 11:49:22.251967
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda x: x
    assert fd.report_skip_fragment(0) == '[download] Skipping fragment 0...'

# Generated at 2022-06-24 11:49:31.494167
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractor_classes
    from ..compat import compat_urllib_request

    urlopen = compat_urllib_request.urlopen
    compat_urllib_request.urlopen = lambda req: urlopen(req)

    class MyFD(FragmentFD):
        pass

    class MyIE(gen_extractor_classes()[0]):
        info_dict = {
            'id': 'testid',
            'title': 'testtitle'
        }

    assert issubclass(MyFD, FileDownloader)

    fd = MyFD('MyFD', MyIE())
    fd.params.update({
        'quiet': True,
    })

    with open(os.devnull, 'w') as devnull:
        fd.to_stdout = devnull

# Generated at 2022-06-24 11:49:37.401609
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    # Dummy IO
    io = DummyIO()
    params = {
        'outtmpl': 'outtmpl',
        'quiet': True,
    }
    ydl = YoutubeDL(params)
    ydl.set_downloader(FragmentFD(ydl, params))
    fd = ydl.downloader

    # Register dummy IO
    fd.to_screen = io.to_screen
    frag_index = 10
    retries = 5
    err = 'http error'
    for count in range(1, retries + 2):
        fd.report_retry_fragment(err, frag_index, count, retries)
    # Check if all the lines are there.

# Generated at 2022-06-24 11:49:45.544896
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from ..utils import std_headers

    class MockFD(FileDownloader):
        def __init__(self):
            FileDownloader.__init__(
                self, {'outtmpl': '%(id)s.f4m'}, {}, {'noprogress': True})

    dl = FragmentFD(MockFD(), {}, {}, {})
    dl.report_skip_fragment(5)

    # Now with a custom FD class
    class CustomFD(FileDownloader):
        def __init__(self):
            FileDownloader.__init__(
                self, {'outtmpl': '%(id)s.f4m'}, {}, {'noprogress': True})

# Generated at 2022-06-24 11:49:58.760696
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {'noprogress': True})
    assert (fd.report_retry_fragment(
        Exception('Test Exception'), 10, 3, 5) ==
        '[download] Got server HTTP error: Test Exception. Retrying fragment 10 (attempt 3 of 5)...')
    # Test unicode exception
    assert (fd.report_retry_fragment(
        Exception('\u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0430'),
        10, 3, 5) ==
        '[download] Got server HTTP error: \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0430. Retrying fragment 10 (attempt 3 of 5)...')
    #

# Generated at 2022-06-24 11:50:08.260416
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    def report_skip_fragment(self, frag_index):
        assert frag_index == 4
        self.reported_fragments.append(frag_index)
    FragmentFD.report_skip_fragment = report_skip_fragment
    fd = FragmentFD(None, {}, None)
    fd.reported_fragments = []
    fd.report_skip_fragment(4)
    assert fd.reported_fragments == [4]

# Generated at 2022-06-24 11:50:15.537466
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractors
    from .downloader import gen_downloaders
    gen_extractors()
    gen_downloaders()

    from .common import FileDownloader
    from .http import HttpFD
    from . import YoutubeDL
    params = {
        'quiet': True,
        'noprogress': True,
        }
    ydl = YoutubeDL(params)
    file_downloader = FileDownloader(ydl, params)
    http_downloader = HttpFD(ydl, params)
    http_quiet_downloader = HttpQuietDownloader(ydl, params)

    # We cannot test that the messages are not printed since FileDownloader
    # will print them before we have a chance to change the to_screen method.
    # We check that they are not printed twice.
   

# Generated at 2022-06-24 11:50:19.473302
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .output import TestOut
    out = TestOut()
    out.stdout = TestOut()
    fd = FragmentFD(lambda: out)
    fd.report_skip_fragment(42)
    out.stdout.assertContainsRe(r'\[download\] Skipping fragment 42\.\.\.')


# Generated at 2022-06-24 11:50:26.287530
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {}
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'retries': 0,
        'nopart': False,
        'test': False,
    }
    hqd = HttpQuietDownloader(ydl, params)
    for k, v in params.items():
        assert hqd.params[k] == v
    assert hqd.ydl is ydl

# Generated at 2022-06-24 11:50:37.719020
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .common import FileDownloader
    from .http import HttpFD
    from io import StringIO
    with_screen = StringIO()
    FileDownloader(
        params = {
            'outtmpl': '%(id)s.%(ext)s',
        },
        pgroups = {},
        ydl = object(),
    ).to_screen('\n%s\n' % ('a' * 79), file=with_screen)
    assert (
        with_screen.getvalue() ==
        '\n' + ('a' * 79) + '\n')

# Generated at 2022-06-24 11:50:49.346807
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Standard text

    test_message = 'youtube-dl test message'
    check_message = None

    def check_message_filter(message):
        assert message == test_message
        check_message = message
        return message

    ydl = HttpQuietDownloader(
        None,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'prefer_insecure': True,
            'verbose': True,
        }
    )
    ydl.to_screen = check_message_filter
    ydl.to_screen(test_message)
    assert check_message == test_message

    # Emojis

    test_emoji = 'youtube-dl 😄 test'
    check_emoji = None


# Generated at 2022-06-24 11:50:51.419608
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    HttpQuietDownloader(youtube_dl.YoutubeDL({}), {'continuedl': True})

# Generated at 2022-06-24 11:51:00.597895
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class DummyFragmentFD(FragmentFD):
        def __init__(self):
            self.to_screen_buffer = ''
        def to_screen(self, *args, **kargs):
            self.to_screen_buffer = args[0] % args[1:]

    fd = DummyFragmentFD()
    fd.report_retry_fragment('err', 42, 3, 5)
    assert fd.to_screen_buffer == (
        '[download] Got server HTTP error: err. '
        'Retrying fragment 42 (attempt 3 of 5)...'
    )

# Generated at 2022-06-24 11:51:12.610641
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor.youtube import YoutubeIE

    # Create a FragmentFD object
    fd = FragmentFD({}, YoutubeIE(YoutubeIE.ie_key()), {}, None)

    # Since we don't test stdout redirection, output is suppressed for now
    fd.to_screen = lambda *args, **kargs: None


# Generated at 2022-06-24 11:51:21.657907
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    params = {
        'fragment_retries': '10',
        'skip_unavailable_fragments': 'no',
        'keep_fragments': 'yes',
        'ratelimit': '5M',
        'retries': '1',
        'nopart': 'yes',
        'test': 'no',
        'updatetime': 'yes',
    }
    assert FragmentFD._prepare_params(params) == {
        'fragment_retries': 10,
        'skip_unavailable_fragments': False,
        'keep_fragments': True,
        'ratelimit': 5000000.0,
        'retries': 1,
        'nopart': True,
        'test': False,
        'updatetime': True,
    }

# Unit test

# Generated at 2022-06-24 11:51:26.526896
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({'outtmpl': '%(id)s'}, {}, None)
    fd.to_screen = lambda *args: None
    fd.report_skip_fragment(42)


# Generated at 2022-06-24 11:51:30.725740
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Create a new HttpQuietDownloader instance
    http_quiet_dl = HttpQuietDownloader(None, {'quiet': True})

    # Call to_screen with a message - it should not print anything
    http_quiet_dl.to_screen("Testing")

# Generated at 2022-06-24 11:51:32.444555
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    fd = HttpQuietDownloader({},{})
    fd.to_screen('test')

# Generated at 2022-06-24 11:51:34.395201
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    fd = HttpQuietDownloader(None, None)
    assert fd.to_screen('test') == None

# Generated at 2022-06-24 11:51:38.859897
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {'noprogress': True}, {'skip_unavailable_fragments': True})
    fd.to_screen = lambda *args: args
    assert fd.report_skip_fragment(42) == ('[download] Skipping fragment 42...',)

# Generated at 2022-06-24 11:51:48.986969
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from io import StringIO
    from .http import HttpFD
    from . import YoutubeDL

    # Test normal instance
    ydl = YoutubeDL()
    d = HttpQuietDownloader(ydl, {})
    d.to_screen('hello')

    # Test quiet instance
    ydl = YoutubeDL({'quiet': True})
    d = HttpQuietDownloader(ydl, {})
    d.to_screen('hello')

    # Test quiet instance with outtmpl
    ydl = YoutubeDL({'quiet': True, 'outtmpl': '%(stitle)s'})
    d = HttpQuietDownloader(ydl, {})
    d.to_screen('hello')

    # Test instance with outtmpl and nopart

# Generated at 2022-06-24 11:51:57.067580
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestHttpQuietDownloader(HttpQuietDownloader):
        def to_screen_str(self):
            return self.to_screen_str_value

    test_cases = [
        ('some text to screen', 'some text to screen'),
        ('text with\nnewline', 'text with\nnewline'),
    ]
    dl = TestHttpQuietDownloader(None, {})
    for message, expected_result in test_cases:
        dl.to_screen_str_value = ''
        dl.to_screen(message)
        assert dl.to_screen_str_value == expected_result

# Generated at 2022-06-24 11:52:06.057465
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from ..compat import compat_urllib_request
    class DummyYDL:
        params = {
            'username': 'dummy',
            'password': 'dummy',
        }
        def __init__(self):
            self.extractor_names = []
            self.preferredcodec = None
            self.preferredquality = None
        def to_screen(self, message):
            pass
        def trouble(self, message, tb=None):
            pass
        def report_warning(self, message, tb=None):
            pass
        def report_error(self, message, tb=None):
            pass
        def to_stderr(self, message):
            pass
        def to_stdout(self, message):
            pass
   

# Generated at 2022-06-24 11:52:13.977235
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import pytest

    class TD(FragmentFD):
        def __init__(self):
            self.to_screen_value = ''

        def to_screen(self, message, skip_eol=False):
            self.to_screen_value = message

    td = TD()
    td.report_skip_fragment(10)

    assert td.to_screen_value == '[download] Skipping fragment 10...', \
        'Expected [download] Skipping fragment 10..., Got %s' % td.to_screen_value


# Generated at 2022-06-24 11:52:19.648330
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor

    class FragmentOnlyIE(InfoExtractor):

        def extract(self):
            self._downloader.report_skip_fragment(1)

    ie = gen_extractor(FragmentOnlyIE)
    ie.suitable('http://localhost:8080')

    class NullFD(object):
        def to_screen(self, *args, **kargs):
            pass

    dl = NullFD()
    dl.to_screen = lambda *args, **kargs: None
    ie._downloader = dl

    ie._real_extract()

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()