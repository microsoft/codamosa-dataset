

# Generated at 2022-06-24 11:42:27.070429
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, None)
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(
        'err', 1, 1, {'max_attempts': 5}) == (
        '[download] Got server HTTP error: err. Retrying fragment 1 (attempt 1 of 5)...',)
    assert fd.report_retry_fragment(
        'err', 1, 1, {'max_attempts': 0}) == (
        '[download] Got server HTTP error: err. Retrying fragment 1...',)


# Generated at 2022-06-24 11:42:36.062448
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..compat import compat_urlopen
    from ..extractor.common import InfoExtractor

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            info_dict = {
                'id': 'test',
                'ext': 'mp4',
                'title': 'test',
                'formats': [{
                    'url': 'http://example.com/videos.ts',
                }],
            }
            return [info_dict]

    ie = TestIE()
    info_dict = ie.extract('http://example.com')[0]
    info_dict['http_headers'] = {'Youtubedl-no-compression': 'True'}
    fd = FragmentFD(ie._ydl, ie.params, info_dict)
    fd.prep

# Generated at 2022-06-24 11:42:43.364057
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Check an instance initialization
    fd = FragmentFD(None)
    check_ok(fd, FragmentFD)
    check_true(fd._ready)
    check_eq(fd.total_frags, -1)

    # Check if _ready attribute is changed when total_frags is set to 0
    fd.total_frags = 0
    check_true(fd._ready)

    # Check if _ready attribute is changed when total_frags is set to a value
    # greater than 0
    fd = FragmentFD(None)
    fd.total_frags = 1
    check_false(fd._ready)

    # Check is_done when total_frags is set to a value greater than 0
    # and there are incomplete fragments
    fd.total_frags = 3
    fd.frag

# Generated at 2022-06-24 11:42:54.308994
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor import get_info_extractor
    from .downloader import _replace_extension
    from ..compat import compat_urllib_error

    error_message = 'f4m4u_downloader_fatal_error_occurred'
    error_message_str = error_to_compat_str(error_message)

    class TestFragmentFD(FragmentFD):
        def __init__(self, ydl, params=None):
            super(TestFragmentFD, self).__init__(ydl, params)
            self._screen_message_stack = []

        @staticmethod
        def urlhandle_detect_ext(url_handle):
            return 'mpd'

        # Override superclass method. We call it directly with index only

# Generated at 2022-06-24 11:42:59.421733
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fragfd = FragmentFD(None, None)
    assert fragfd.report_skip_fragment(1) is None

test_FragmentFD_report_skip_fragment()

# Generated at 2022-06-24 11:43:02.833351
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    from .common import FileDownloader

    class FakeYDL(object):
        params = {
            'outtmpl': '%(id)s',
            'quiet': False,
        }
        def to_screen(self, *args, **kargs):
            print(*args, file=sys.stderr)

    fd = FragmentFD(FakeYDL())
    fd.report_skip_fragment(1)

# Generated at 2022-06-24 11:43:08.774389
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import io
    import sys
    from .extractor.common import InfoExtractor
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashFD
    from .downloader.http import HttpFD
    from .postprocessor.ffmpeg import FFmpegPostProcessor
    from .postprocessor.metadatafromtitle import MetadataFromTitlePP

    from .utils import prepend_extension

    class DummyYDL(object):
        def __init__(self, params):
            self.params = params
            self.cache = None
            self.to_screen = sys.stdout.write

        def prepare_filename(self, info_dict):
            return info_dict['id']


# Generated at 2022-06-24 11:43:11.553968
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class DummyYDL(object):
        def to_screen(self, *args, **kwargs):
            self.message = args[0]

    dl = HttpQuietDownloader(DummyYDL(), None)
    dl.to_screen('foo')
    assert dl.ydl.message == 'foo'

# Generated at 2022-06-24 11:43:18.204561
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=W0212
    # Access to a protected member of a client class
    dl = HttpQuietDownloader({}, {'quiet': True})
    assert dl.params['quiet']
    assert dl.params['progress_with_newline']
    assert dl.report_m3u8_warnings is False

# Generated at 2022-06-24 11:43:24.053995
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .utils import FakeYDL
    ydl = FakeYDL()
    ffd = FragmentFD(ydl, {})
    ffd.report_skip_fragment(42)
    ffd.to_screen.assert_called_once_with('[download] Skipping fragment 42...')
    ydl.to_stderr.assert_not_called()


# Generated at 2022-06-24 11:43:28.926233
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    fd = FragmentFD(FileDownloader({}))
    fd.report_retry_fragment(Exception('test'), 1, 1, 0)
    fd.report_retry_fragment(Exception('test'), 1, 2, 1)
    fd.report_retry_fragment(Exception('test'), 1, 3, 2)

# Generated at 2022-06-24 11:43:38.773113
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import FileDownloader
    from .http import HttpFD

    fd = FragmentFD(FileDownloader({
        'proxy': '127.0.0.1:8080',
        'quiet': True,
        'outtmpl': '%(id)s.%(ext)s',
        'retries': '0',
        'noprogress': True,
        'nopart': True,
        'fragment_retries': '5',
    }))

    # Pass
    msg = fd.report_retry_fragment(Exception('foo'), 1, 5, 5)
    assert msg == '[download] Got server HTTP error: foo. Retrying fragment 1 (attempt 5 of 5)...'

# Generated at 2022-06-24 11:43:45.932043
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {'noprogress': True})
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(None, 3, 5, 10) == (
        '[download] Got server HTTP error: None. Retrying fragment 3 (attempt 5 of 10)',
    )


if __name__ == '__main__':
    import sys
    sys.exit(test_FragmentFD_report_retry_fragment())

# Generated at 2022-06-24 11:43:53.265264
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import io
    from .common import FileDownloader
    from .http import HttpQuietDownloader

    def test_HttpQuietDownloader_to_screen():
        ydl = FileDownloader()
        ydl.params['outtmpl'] = '-'
        qdl = HttpQuietDownloader(ydl, {})

        # Save stdout and stderr
        saved_stdout = sys.stdout
        saved_stderr = sys.stderr

        # Create a buffer to store stdout and stderr
        stdout_buffer = io.BytesIO()
        stderr_buffer = io.BytesIO()

        # Make stdout and stderr point to this buffer
        sys.stdout = stdout_buffer
        sys.stderr = stderr_buffer

        # Test if

# Generated at 2022-06-24 11:43:57.436077
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FakeYDL

    ydl = FakeYDL()
    ffd = FragmentFD(ydl)
    ffd.add_info_extractor(lambda: None)
    assert ffd.ydl is ydl
    assert ffd.IE_NAME == 'generic'

# Generated at 2022-06-24 11:44:03.473576
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    import sys
    import os.path
    import json
    import shutil
    import tempfile
    import filecmp

    class TestDownloader(unittest.TestCase):
        tmp_subdir = 'ytdl-test'
        tmp_subdir = os.path.join(tempfile.gettempdir(), tmp_subdir)

        def setUp(self):
            if os.path.isdir(self.tmp_subdir):
                shutil.rmtree(self.tmp_subdir)
            os.mkdir(self.tmp_subdir)
            self.tmp_file = os.path.join(self.tmp_subdir, 'ytdl-test-file')

# Generated at 2022-06-24 11:44:13.277352
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import YoutubeIE
    from ..extractor import gen_extractors

    def extractor_for_url(url):
        for ie in gen_extractors():
            if ie.suitable(url) and ie is not YoutubeIE:
                return ie
        return None

    def test_init(url):
        extractor = extractor_for_url(url)
        if not extractor:
            return
        dir, name = os.path.split(__file__)
        outtmpl = os.path.join(dir, 'test_output', '%s.%%(ext)s' % name)
        ydl = lambda **kargs: None
        ydl.params = {
            'outtmpl': outtmpl,
        }
        extractor(ydl, url)()


# Generated at 2022-06-24 11:44:16.126696
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..utils import FakeYDL
    ydl = FakeYDL()
    fd = FragmentFD(ydl)
    assert fd.ydl is ydl
    assert fd.params == {}

# Generated at 2022-06-24 11:44:18.588306
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .common import FileDownloader
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert issubclass(HttpQuietDownloader, FileDownloader)

# Generated at 2022-06-24 11:44:27.413466
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    x = gen_extractor('http://www.youtube.com/watch?v=BaW_jenozKc')

    HttpQuietDownloader(
        None,
        {
            'continuedl': False,
            'quiet': False,
            'noprogress': False,
            'ratelimit': None,
            'retries': 2,
            'buffersize': 16777216,
            'noresizebuffer': False,
            'test': False,
        }
    )

# Generated at 2022-06-24 11:44:41.763365
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .extractor.youtube import YoutubeIE
    from .utils import match_filter_func
    from ..compat import compat_str
    fragment_retries = 3
    fd = FragmentFD(YoutubeIE(), {
        'fragment_retries': fragment_retries,
        'prefer_free_formats': True,
        'format': 'bestvideo/best+bestaudio/best',
        'noprogress': True,
    })
    assert fragment_retries == fd.params['fragment_retries']
    assert fd.params['prefer_free_formats']
    assert fd.params['format'] == 'bestvideo+bestaudio'
    assert fd.params['noprogress']
    assert match_filter_func(fd.format_limit) is None
    youtube_ie

# Generated at 2022-06-24 11:44:48.971425
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from io import StringIO
    from sys import stdout
    from .extractor import get_info_extractor
    original_stdout = stdout
    stdout = StringIO()
    profile = [{
        'outtmpl': '%(id)s%(ext)s',
        'noprogress': True,
        'format': '137+140/bestvideo+bestaudio',
        'keep_fragments': True,
    }]
    fd = FileDownloader(ydl=None, params=profile[0], info_dict=None)
    ie = get_info_extractor('youtube')()
    ie._real_extract(
        fd,
        'https://www.youtube.com/watch?v=65a57Rk0xV8')
   

# Generated at 2022-06-24 11:45:00.334283
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestHttpQuietDownloader(HttpQuietDownloader):
        def __init__(self, *args, **kwargs):
            HttpQuietDownloader.__init__(self, *args, **kwargs)
            self.to_screen_buf = []

        def to_screen(self, *args, **kargs):
            self.to_screen_buf.append(args)

    ytdl = TestHttpQuietDownloader({})
    assert ytdl.to_screen_buf == []

    ytdl.to_screen('message 1')
    assert ytdl.to_screen_buf == []

    ytdl.to_screen('message 2', 'message 3')
    assert ytdl.to_screen_buf == []


# Generated at 2022-06-24 11:45:09.050740
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .dash import _parse_fragment_base_url
    from ..utils import prepend_extension
    from ..compat import compat_urllib_error
    from ..extractor import get_info_extractor

    def test_method(self, message, skip_eol=False, check_error=False):
        nonlocal to_screen_data
        to_screen_data.append(message)

    def test_report_error(self, message, exc_info=None):
        nonlocal error_data
        error_data.append(message)

    def test_download(self, filename_or_obj, info_dict, *args, **kwargs):
        nonlocal info_dicts
        info_dicts.append(info_dict)
        return True


# Generated at 2022-06-24 11:45:11.251833
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from ..YoutubeDL import YoutubeDL
    assert HttpQuietDownloader(YoutubeDL(), {}).to_stderr is sys.stderr


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:45:18.507464
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    ydl = object()
    fd = FragmentFD(ydl, {'noprogress': True})
    fd.to_screen = lambda *args, **kargs: args
    assert (
        'Got server HTTP error: test error. Retrying fragment 10 (attempt 1 of 3)...'
        == fd.report_retry_fragment(Exception('test error'), 10, 1, {'max_retries': 2}))

# Generated at 2022-06-24 11:45:20.888148
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-24 11:45:24.546690
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors

    _, ie = gen_extractors(
        ['http://github.com/rg3/youtube-dl/issues/1'])[0]
    assert isinstance(ie._real_initialize(), HttpQuietDownloader)

# Generated at 2022-06-24 11:45:30.687487
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    assert sys.stdout.getvalue() == ''
    ydl = object()
    params = {'noprogress': True}
    dl = HttpQuietDownloader(ydl, params)
    dl.to_screen('Foo bar')
    assert sys.stdout.getvalue() == ''



# Generated at 2022-06-24 11:45:38.371364
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from . import std_headers

    # Create test environment

# Generated at 2022-06-24 11:45:47.802658
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import io
    # Create fake output stream
    output = io.BytesIO()
    sys.stdout = output

    # Create HttpQuietDownloader instance
    from .http import HttpFD
    from .common import FileDownloader
    ydl = FileDownloader({}, {'quiet': True})
    hqd = HttpQuietDownloader(ydl, {})

    # Write something to screen
    hqd.to_screen('Some text')

    # Reset output stream
    sys.stdout = sys.__stdout__

    assert output.getvalue() == b''

# Generated at 2022-06-24 11:45:55.320893
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class testFragmentFD(FragmentFD):
        def __init__(self):
            self.expect_retries = ['FragmentFD', 0, 1, 1]
    tfd = testFragmentFD()
    tfd.report_retry_fragment(None, 0, 1, 1)
    if tfd.expect_retries:
        raise ValueError("Unexpected to_screen value: %r" % tfd.expect_retries)

# Generated at 2022-06-24 11:45:56.976843
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD()
    fd.to_screen = lambda *args, **kargs: None
    fd.report_skip_fragment(3)
    assert fd.to_screen.called


# Generated at 2022-06-24 11:46:07.477354
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    # Sanity test for FragmentFD.report_retry_fragment with silent=False
    fd.params['simulate'] = False
    fd._downloader.to_screen = lambda *args, **kargs: args
    assert fd.report_retry_fragment(0, 1, 2, 3) == (
            '[download] Got server HTTP error: 0. '
            'Retrying fragment 1 (attempt 2 of 3)...',)
    # Test for FragmentFD.report_retry_fragment with silent=True
    fd.params['simulate'] = True
    assert fd.report_retry_fragment(0, 1, 2, 3) == ()

# Generated at 2022-06-24 11:46:15.975238
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    """
    Method to_screen of class HttpQuietDownloader must not print any output.
    """
    import sys
    from io import StringIO
    import os

    test_string = "Test string"

    # Collect output
    saved_stdout = sys.stdout

# Generated at 2022-06-24 11:46:26.768031
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .http import HttpFD
    from six import StringIO
    from ..utils import std_headers
    from ..compat import str_to_compat_str

    s = StringIO()
    ydl = HttpFD()
    ydl.to_screen = lambda *args, **kargs: s.write(str_to_compat_str(args[0]))
    ydl.report_destination = lambda *args, **kargs: None


# Generated at 2022-06-24 11:46:34.345952
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from . import FakeYDL
    from .extractor import get_info_extractor
    from .downloader.http import HttpFD
    from ytdl.utils import RetryDownload

    fd = FragmentFD(FakeYDL(), get_info_extractor('youtube'), {'noprogress': True})
    fd._hooks = HttpFD._hooks
    fd.to_screen = lambda *args, **kargs: None
    fd.report_retry_fragment(
        RetryDownload(0, 2, 3), 2, 3, 2) == 'Retry failed fragment 2 (attempt 3 of 2).'

# Generated at 2022-06-24 11:46:38.540878
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..utils import DateRange
    fd = FragmentFD({'logger': None})
    frag_index = 5
    retries = 7
    count = 2
    err = 'test'
    fd.report_retry_fragment(err, frag_index, count, retries)

# Generated at 2022-06-24 11:46:43.310562
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class MockFD(FragmentFD):
        def __init__(self):
            self.reported_lines = []

        def to_screen(self, *args, **kargs):
            self.reported_lines.append(args)

    fd = MockFD()
    fd.report_skip_fragment(12)
    assert fd.reported_lines == [('[download] Skipping fragment 12...',)]

# Generated at 2022-06-24 11:46:55.199443
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .extractor import gen_extractor
    from .downloader import gen_downloader
    from .utils import ExtractorError
    from .compat import str

    class ConsumingFD(FragmentFD):
        def __init__(self, params):
            self._params = params
            self._to_screen_text = []

        @property
        def params(self):
            return self._params

        def to_screen(self, *args, **kargs):
            self._to_screen_text.append(' '.join([str(arg) for arg in args]))

    params = {
        'verbose': True,
        'logger': 'test',
    }

    dl = ConsumingFD(params)

# Generated at 2022-06-24 11:47:02.982118
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .extractor import YoutubeIE
    from .extractor.common import InfoExtractor
    class TestInfoExtractor(InfoExtractor):
        IE_DESC = 'Test IE'
        def _real_extract(self, url):
            return {
                'id': 'testid',
                'title': 'testtitle',
                'url': url,
                'ext': 'mp4',
                'http_headers': {},
                'fragment_base_url': url,
                'fragments': ['1/1']
            }
    ie = TestInfoExtractor()
    YoutubeIE.ie_keywords.append(ie.ie_key())
    ie.ydl = YoutubeIE()

    import sys


# Generated at 2022-06-24 11:47:12.259244
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    try:
        FragmentFD.report_retry_fragment(None, None, 0, 0)
    except SystemExit as e:
        assert e.code == 1
    else:
        assert False
    sys.stderr = open('test.log', 'w')
    FragmentFD.report_retry_fragment(None, None, 1, 2)
    FragmentFD.report_retry_fragment(None, 'err', 3, 10)
    sys.stderr.close()
    sys.stderr = sys.__stderr__


# Generated at 2022-06-24 11:47:12.695856
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass

# Generated at 2022-06-24 11:47:16.825915
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .downloader import FileDownloader
    opts = {
        'sleep': 1,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
    }
    ydl = FileDownloader(opts)
    dl = HttpQuietDownloader(ydl, opts)
    assert dl.params == opts
    assert dl.ydl == ydl

# Generated at 2022-06-24 11:47:26.436728
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor.common import InfoExtractor
    from .http import HttpFD
    from .dash import DashFD
    class TestIE(InfoExtractor):
        IE_NAME = 'TestIE'
        def __init__(self):
            InfoExtractor.__init__(self)

        def _real_extract(self, url):
            # this is normally done in __init__
            self._setup_opener()

            dl = DashFD(self, {'continuedl': True, 'quiet': True})

    ie = TestIE()
    # raise, if you don't get an instance of HttpQuietDownloader,
    # since that should be what we need
    assert(isinstance(ie._opener, HttpQuietDownloader))

# Generated at 2022-06-24 11:47:38.750929
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = {
        'params': {
            'verbose': False,
        },
    }
    quiet_dl = HttpQuietDownloader(ydl, {'quiet': False})
    quiet_dl.to_screen(
        'First message',
        'Second message',
        'Third message')
    assert ydl['to_stderr'] == []

    quiet_dl = HttpQuietDownloader(ydl, {'quiet': True})
    quiet_dl.to_screen(
        'First message',
        'Second message',
        'Third message')
    assert ydl['to_stderr'] == []

    ydl = {
        'params': {
            'verbose': True,
        },
    }


# Generated at 2022-06-24 11:47:44.070419
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ...compat import compat_HTTPError

    fd = FragmentFD({})
    err = compat_HTTPError('http://host', 504, 'Gateway timeout', {}, None)
    fd.report_retry_fragment(err, 10, 5, 10)



# Generated at 2022-06-24 11:47:53.339760
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params = {
        'outtmpl': '%(id)s.%(ext)s',
        'quiet': True,
        'continuedl': True,
        'noprogress': True,
        'nopart': False,
        'ratelimit': 0,
        'retries': 0,
        'test': False,
    }
    from .extractor import gen_extractors
    gen_extractors()
    from .YoutubeDL import YoutubeDL
    ytdl = YoutubeDL(params)
    http_fd = HttpQuietDownloader(ytdl, params)
    assert http_fd.params == params
    return http_fd

# Generated at 2022-06-24 11:48:01.756564
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFragmentFD(FragmentFD):
        def __init__(self):
            FragmentFD.__init__(
                self,
                {
                    'noprogress': True,
                    'quiet': True,
                },
            )
            self.expected_msg = None

        def to_screen(self, msg):
            assert msg == self.expected_msg

    def _test_report_retry_fragment(error_msg, frag_index, retry_count, retries, expected_msg):
        fd = TestFragmentFD()
        fd.expected_msg = expected_msg
        fd.report_retry_fragment(error_msg, frag_index, retry_count, retries)


# Generated at 2022-06-24 11:48:07.275140
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    frag_fd = FragmentFD(None, {'noprogress': True})
    log = open('test_skip_fragment.txt', 'wt')
    frag_fd.to_screen = log.write
    frag_fd.report_skip_fragment(5)
    log.close()
    assert open('test_skip_fragment.txt').read() == '[download] Skipping fragment 5...\n'

if __name__ == '__main__':
    test_FragmentFD_report_skip_fragment()
    os.remove('test_skip_fragment.txt')

# Generated at 2022-06-24 11:48:10.328455
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    FD = FragmentFD(None, {}, None)
    print (FD.report_retry_fragment(None, 1, 2, 3))


# Generated at 2022-06-24 11:48:22.080866
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # pylint: disable=unused-argument
    class FragmentFDMock(FragmentFD):
        def __init__(self, ydl):
            pass
        to_screen_messages = []
        def to_screen(self, message):
            self.to_screen_messages.append(message)

    ffdm = FragmentFDMock('ydl')
    ffdm.report_skip_fragment(0)
    assert ffdm.to_screen_messages == ['[download] Skipping fragment 0...']
    del ffdm.to_screen_messages[:]
    ffdm.report_skip_fragment(1)
    assert ffdm.to_screen_messages == ['[download] Skipping fragment 1...']

# Generated at 2022-06-24 11:48:22.691021
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-24 11:48:29.707005
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .options import Options
    from ..utils import FakeYDL

    ydl = FakeYDL()
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'retries': 10,
        'nopart': True,
        'test': False,
    }
    frag_fd = FragmentFD(ydl, params)
    assert frag_fd.params == params
    assert frag_fd.ydl is ydl

    no_params = {}
    frag_fd = FragmentFD(ydl, no_params)
    assert frag_fd.params == params
    assert frag_fd.ydl is ydl

    frag_fd = FragmentFD(ydl, {'outtmpl': 'out%(ext)s'})
    assert frag_fd

# Generated at 2022-06-24 11:48:36.037326
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=W0612
    from .extractor import gen_extractors, list_extractors
    global_opts = {
        'quiet': True,
        'logtostderr': True,
        'nocheckcertificate': True,
    }
    extractors = gen_extractors(global_opts)
    assert HttpQuietDownloader
    assert extractors
    assert list_extractors(extractors)

# Generated at 2022-06-24 11:48:44.195753
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Create object
    dl = HttpQuietDownloader(
        None,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'retries': 5,
            'nopart': False,
            'test': False,
        }
    )

    assert dl._opts['continuedl'] is True
    assert dl._opts['quiet'] is True
    assert dl._opts['noprogress'] is True
    assert dl._opts['ratelimit'] is None
    assert dl._opts['retries'] == 5
    assert dl._opts['nopart'] is False
    assert dl._opts['test'] is False



# Generated at 2022-06-24 11:48:53.481595
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from ..compat import compat_str

    for ie in gen_extractor_classes():
        name = ie.IE_NAME
        if name == 'generic':
            continue
        ie = ie()
        if ie.suitable(name):
            ie.url = name
            res = ie._real_initialize()
            if not res:
                continue
            ie.report_warning = lambda *args, **kwargs: args
            info = ie.extract(ie.url)
            assert isinstance(info, dict)
            formats = info.get('formats', [])

# Generated at 2022-06-24 11:49:00.377238
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD({}, None)
    expected = '[download] Got server HTTP error: 403 Forbidden. Retrying fragment 3 (attempt 4 of 6)...\n'
    assert fd.report_retry_fragment(403, 3, 4, 6) == expected


# Generated at 2022-06-24 11:49:07.259219
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import get_info_extractor
    from ..downloader import YoutubeDL
    from .http import HttpFD

    ie = get_info_extractor('youtube', 'YoutubeIE')

    def _dummy_hook(_):
        pass

    with YoutubeDL(params={'quiet': True, 'noprogress': True}) as ydl:
        params = {'quiet': True, 'noprogress': True}
        dl = HttpQuietDownloader(ydl, params)
        assert isinstance(dl, HttpFD)
        assert dl.params == params

        dl.add_progress_hook(lambda _: _dummy_hook)
        dl.report_destination('.')
        dl.to_screen('.')
        dl.to_stdout('.')
       

# Generated at 2022-06-24 11:49:18.462742
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class FragmentFDStub(FragmentFD):
        ydl = None
        params = None
        FD_NAME = 'FragmentFDStub'

        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params

        @classmethod
        def ytdl_filename(cls, name):
            return name + '.ytdl'

        def temp_name(self, name):
            return name + '.part'

        def report_destination(self, name):
            pass

        def _hook_progress(self, status):
            pass

        def try_rename(self, old_name, new_name):
            pass

        def calc_eta(self, start, now, total, completed):
            return 123


# Generated at 2022-06-24 11:49:26.757403
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys

    fd = FragmentFD({ 'outtmpl': '%(id)s.%(ext)s' })
    fd.to_screen = sys.stdout.write

    fd.report_retry_fragment(
        Exception('HTTP 403 Client Error: Forbidden'), 0, 2, 3)

    fd.report_retry_fragment(
        Exception('HTTP 403 Client Error: Forbidden'), 0, 3, 3)

if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:49:32.382950
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFragmentFD(FragmentFD):
        def format_retries(self, retries):
            return '%d (formatted)' % retries

        def to_screen(self, *args, **kargs):
            self.result = args[0] % args[1:]
    fragment_fd = TestFragmentFD()
    fragment_fd.report_retry_fragment(None, 1, 2, 3)
    assert fragment_fd.result == '[download] Got server HTTP error: . Retrying fragment 1 (attempt 2 of 3 (formatted))...'

# Generated at 2022-06-24 11:49:36.220591
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {}, None)
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_skip_fragment(1) == (['[download] Skipping fragment 1...'],)

# Generated at 2022-06-24 11:49:39.437240
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FileDownloaderSubclass(FragmentFD):
        def to_screen(self, s):
            print(s)
    FileDownloaderSubclass().report_skip_fragment(123)

# Generated at 2022-06-24 11:49:45.689672
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import io
    import sys
    from collections import OrderedDict

    from .http import HttpFD
    from ..downloader.common import FileDownloader

    od = OrderedDict

    class FakeYDL(object):
        params = od([('noprogress', False)])

    class HttpDummyFD(HttpFD):
        def real_download(self, *args, **kargs):
            return

    class TestFD(FileDownloader):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.to_screen_buffer = io.StringIO()
            self.to_stderr_buffer = io.StringIO()
            self.http_fd = HttpDummyFD(ydl, params)


# Generated at 2022-06-24 11:49:58.581398
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def check_compat_str(e):
        return isinstance(error_to_compat_str(e), compat_str)

    assert check_compat_str(ValueError())
    assert check_compat_str(compat_HTTPError(''))
    assert check_compat_str(compat_socket_error(''))
    assert check_compat_str(compat_urlerror(''))
    assert check_compat_str(compat_socket_timeout(''))
    assert check_compat_str(compat_certificate_error('', ''))
    assert check_compat_str(compat_SSLError('', ''))
    assert check_compat_str(compat_urllib_error(''))

# Generated at 2022-06-24 11:50:04.055105
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .common import FileDownloader
    from .http import HttpFD
    fd = HttpFD(FileDownloader())
    return fd.to_screen('test message')


# Generated at 2022-06-24 11:50:13.530072
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor import gen_extractor_classes
    from .worker import LazyFD

    def test_func(ydl, *args, **kargs):
        # Do nothing
        pass

    info_dict = {}
    lazy_func = LazyFD(info_dict, test_func)

# Generated at 2022-06-24 11:50:21.816052
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    # Empty logger, don't print anything
    logger = lambda *args, **kargs: None
    ydl = {
        'params': {
            'verbose': True,
            'dump_intermediate_pages': False,
        },
        'to_screen': logger,
        'to_stderr': logger,
    }
    d = HttpQuietDownloader(ydl, {})
    # The following calls should not print anything
    d.to_screen('test', {}, True)
    d.to_screen('test', {'test': 'test'})
    d.to_screen('[download] test', {'test': 'test'})
    d.to_screen('[dump] test', {'test': 'test'})
    d.to_screen('test')

# Generated at 2022-06-24 11:50:22.680503
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-24 11:50:24.474574
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    x = HttpQuietDownloader('ytdl', {})



# Generated at 2022-06-24 11:50:33.415696
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {
        'fragment_retries': 2,
    })
    fd.to_screen = lambda *args: args
    assert fd.report_retry_fragment(Exception('foo'), 0, 2, 2) == (
        '[download] Got server HTTP error: foo. Retrying fragment 0 (attempt 2 of 2)...',
    )

if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:50:43.359321
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from ..utils import FakeYDL
    d = FragmentFD(FakeYDL(), {
        'continuedl': False,
        'format': 'best',
        'logger': FakeYDL().logger,
        'nooverwrites': False,
        'outtmpl': u'%(id)s',
        'ratelimit': None,
        'retries': 10,
        'test': False,
    })
    d.to_screen = lambda x, **k: None
    d.report_skip_fragment(0)
    d.report_skip_fragment(1)

# Generated at 2022-06-24 11:50:48.580609
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .youtube_dl import YoutubeDL
    ydl = YoutubeDL()
    params = {
        'continuedl': True,
        'noprogress': True,
        'retries': 5,
        'nopart': True,
        'test': True,
    }
    dl = HttpQuietDownloader(ydl, params)
    assert dl.params == params
    assert dl._ydl is ydl

# Generated at 2022-06-24 11:50:54.645747
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import StringIO
    from .common import FileDownloader

    # sys.stdout and sys.stderr will be overwritten
    stdout = sys.stdout
    stderr = sys.stderr
    out = StringIO.StringIO()
    err = StringIO.StringIO()
    sys.stdout = out
    sys.stderr = err

    # Suppress logging from the http downloader
    class MyFileDownloader(FileDownloader):
        def to_screen(self, *args, **kargs):
            pass

    ydl = MyFileDownloader(dict())
    dl = HttpQuietDownloader(ydl, dict())
    # to_screen should be suppressed
    dl.to_screen('foo')
    sys.stdout = stdout

# Generated at 2022-06-24 11:51:03.750425
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = object()
    params = {'continuedl': True, 'quiet': True, 'noprogress': True}
    hqdl = HttpQuietDownloader(ydl, params)
    assert hqdl._ydl is ydl
    assert hqdl.params == params
    assert hqdl.quiet == True
    assert 'continuedl' in hqdl.params
    assert 'quiet' in hqdl.params
    assert 'noprogress' in hqdl.params


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:51:08.280036
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from . import YoutubeDL
    ydl = YoutubeDL({})
    dl = HttpQuietDownloader(ydl, {})
    dl.to_screen('test')
    assert dl.ydl is ydl

# Unit tests for FragmentFD

# Generated at 2022-06-24 11:51:14.450029
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader('youtube-dl')

    opts = dl.params
    assert opts['continuedl']
    assert opts['quiet']
    assert not opts['verbose']
    assert opts['noprogress']
    assert opts['nopart'] == False
    assert opts['retries'] == 0
    assert opts['test'] == False
    assert not 'ratelimit' in opts


# Generated at 2022-06-24 11:51:22.899029
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .options import opts
    from .extractor import gen_extractors

    # TODO Test handling of keep_fragments and quiet options which are handled
    # differently in the base downloader class. Test other options as well.

    # Test for file time
    opts.updatetime = True
    opts.quiet = True
    opts.fragment_retries = 2
    opts.skip_unavailable_fragments = True
    opts.keep_fragments = True
    for ie in gen_extractors():
        assert isinstance(ie, FragmentFD)
        if ie.IE_NAME in ('hlsnative', 'dash', 'ism'):
            assert ie._retry_fragments == 2
            assert ie._skip_unavailable_fragments
            assert ie._

# Generated at 2022-06-24 11:51:30.400087
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class TestFD(FragmentFD):
        def __init__(self):
            self.output = []

        def to_screen(self, *args):
            self.output.append(' '.join(args))

    fd = TestFD()
    fd.report_retry_fragment(Exception('abc'), 2, 3, 2)
    assert fd.output == [
        '[download] Got server HTTP error: abc. Retrying fragment 2 (attempt 3 of 2)...',
    ]



# Generated at 2022-06-24 11:51:33.819039
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFragmentFD(FragmentFD):
        def to_screen(self, *args, **kargs):
            return args
    assert TestFragmentFD().report_skip_fragment(1) == (('[download] Skipping fragment 1...',), {})


# Generated at 2022-06-24 11:51:42.945337
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    from .http import HttpFD
    from .f4m import F4mFD
    from .hls import HlsFD
    from .dash import DashFD
    from .merge import MergeFD

    assert isinstance(HttpQuietDownloader(None, None), FileDownloader)
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert not issubclass(HttpQuietDownloader, F4mFD)
    assert not issubclass(HttpQuietDownloader, HlsFD)
    assert not issubclass(HttpQuietDownloader, DashFD)
    assert not issubclass(HttpQuietDownloader, MergeFD)


# Generated at 2022-06-24 11:51:48.410436
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    options = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': '10',
        'retries': 3,
        'nopart': True,
        'test': True,
    }
    dl = HttpQuietDownloader(None, options)
    for k, v in options.iteritems():
        assert dl.params[k] == v

# Generated at 2022-06-24 11:51:54.276157
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.http import HttpFD

    ydl = YoutubeDL()
    HttpQuietDownloader(ydl, {'quiet': True, 'noprogress': True})
    assert isinstance(ydl.downloader, HttpFD)
    assert ydl.downloader.params['quiet']
    assert ydl.downloader.params['noprogress']

# Generated at 2022-06-24 11:52:00.177024
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys

    class FakeYDL:
        def __init__(self, params):
            self.params = params

        def to_screen(self, *args, **kargs):
            print(*args, file=sys.stderr)

        def to_stderr(self, *args, **kargs):
            print(*args, file=sys.stderr)

    ydl = FakeYDL({
        'skip_unavailable_fragments': False,
        'keep_fragments': True,
        'rm_tmp_files_enabled': False,
    })

    class FakeFragmentFD(FragmentFD):
        def __init__(self, ydl):
            super(FakeFragmentFD, self).__init__(ydl)


# Generated at 2022-06-24 11:52:11.461474
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import pytest

    class TestFragmentFD(FragmentFD):
        FD_NAME = 'testfd'

        def __init__(self, params):
            self.params = params
            self.to_screen_calls = []

        def to_screen(self, *args, **kargs):
            self.to_screen_calls.append((args, kargs))

    fd = TestFragmentFD({'max_retries': 1})
    fd.report_retry_fragment(
        Exception('Ex'), 4, 3,
        {'max_retries': 3, 'fragment_retry': (1, 1)})

    assert len(fd.to_screen_calls) == 1
    msg = 'Got server HTTP error: Ex. Retrying fragment 4 (attempt 3 of 3)...'
   

# Generated at 2022-06-24 11:52:19.971838
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import IS_PY2
    from ..extractor.common import InfoExtractor

    class IE(InfoExtractor):
        IE_NAME = 'ie'
        IE_DESC = 'Some desc'

    ie = IE({})
    dl = HttpQuietDownloader(ie, {})
    assert dl.ydl is ie
    assert dl.params == {}
    assert dl.to_screen is (None if IS_PY2 else IE.to_screen)
    assert dl.report_error is (None if IS_PY2 else IE.report_error)


if __name__ == '__main__':
    test_HttpQuietDownloader()