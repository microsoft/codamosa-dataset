

# Generated at 2022-06-24 11:42:23.582797
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .extractor import gen_extractors

    # First we need to register all supported extractors
    gen_extractors()

    # Creating an instance of class FragmentFD
    fd = FragmentFD({
        'noprogress': True,
        'outtmpl': '%(id)s-%(format_id)s.%(ext)s',
        'quiet': True,
    }, FileDownloader)
    assert fd.params['noprogress'] is True

# Generated at 2022-06-24 11:42:29.122861
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None, {}, None)
    err = RuntimeError('Any message')
    frag_index = 3
    count = 2
    retries = 5
    ret = fd.report_retry_fragment(err, frag_index, count, retries)
    assert ret is None


# Generated at 2022-06-24 11:42:30.407831
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    d = HttpQuietDownloader(None, {})
    d.to_screen('foo')

# Generated at 2022-06-24 11:42:36.867975
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD({}, [])
    assert isinstance(fd, FragmentFD)
    assert isinstance(fd, FileDownloader)
    assert not hasattr(fd, 'params')
    assert not hasattr(fd, 'ydl')
    assert not hasattr(fd, 'info_dict')
    assert not hasattr(fd, 'filename')

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:42:45.549084
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class Progress(object):
        def __init__(self):
            self.to_screen = []

        def to_screen(self, msg):
            self.to_screen.append(msg)

    class FragmentFD(FragmentFD):
        def to_screen(self, *args, **kwargs):
            self._progress.to_screen(*args, **kwargs)

    fd = FragmentFD(Progress(), {})
    fd.report_retry_fragment(None, 'foo', 'bar', 'baz')
    assert fd._progress.to_screen == ['[download] Got server HTTP error: None. Retrying fragment foo (attempt bar of baz)...']

# Generated at 2022-06-24 11:42:56.182008
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..compat import compat_urlparse
    from ..extractor import get_info_extractor
    info_dict = {
        'id': '4Y4Syqod_X4',
        'url': 'http://www.youtube.com/watch?v=4Y4Syqod_X4',
        'ext': 'mp4',
        'title': 'test video',
        'thumbnail': 'http://test.com/thumbnail',
        'fragment_base_url': 'http://test.com/',
        'manifest_base_url': 'http://test.com/',
    }
    ie = get_info_extractor('youtube')

# Generated at 2022-06-24 11:43:02.163366
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    assert FragmentFD._FragmentFD__test_report_skip_fragment_impl(
        FragmentFD,
        '\r[download] Skipping fragment 12345...\n',
        '\r[download] Skipping fragment 12345...\r\n') == 0


# Generated at 2022-06-24 11:43:09.390289
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = FakeYDL()

    dl = HttpQuietDownloader(
        ydl,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'retries': 15,
        }
    )
    assert isinstance(dl, HttpQuietDownloader)
    assert dl.params['continuedl']
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert dl.params['retries'] == 15



# Generated at 2022-06-24 11:43:16.162217
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import YoutubeDL

    # Instantiate downloader
    downloader = YoutubeDL(
        {
            'outtmpl': '%(id)s.f4m',
            'quiet': True,
        }
    )
    # Run extractor
    test_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    test_info = downloader.extract_info(
        test_url,
        download=False)
    # Instantiate downloader
    f4m_fd = FragmentFD(
        downloader,
        test_info,
        {}
    )
    assert f4m_fd.params['noprogress']

    # Run extractor
    test_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
   

# Generated at 2022-06-24 11:43:27.813196
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    def test_constructor(self, ie, *args, **kwargs):
        info = get_info_extractor(ie)(*args, **kwargs)
        instance = self.FD_CLASS(info)

        assert instance.ydl is not None
        assert instance.params is not None
        assert instance.info is not None
        assert instance.info == ie_info
        assert instance.ie_key == ie
        assert instance.num == 0
        assert instance.retries == 0

    ie_info = 'http://example.org/video.mp4'
    # Unit test: test constructor of class FragmentFD
    # Test case 1: with valid extractor info
    test_constructor(FragmentFD, 'test_ie', ie_info)
    # Test case 2: with

# Generated at 2022-06-24 11:43:29.442515
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Just run it
    HttpQuietDownloader(None, dict())

# Generated at 2022-06-24 11:43:38.258882
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor

    class TestHttpQuietDownloader(HttpQuietDownloader):
        def __init__(self, ie):
            HttpQuietDownloader.__init__(self, ie, {})

        def to_screen(self, *args, **kargs):
            return args, kargs
    ie = InfoExtractor()
    hqd = TestHttpQuietDownloader(ie)
    assert hqd.to_screen('test string') == (('test string',), {})
    assert hqd.to_screen('%(test)s', {'test': 'test string'}) == (('%(test)s',), {'test': 'test string'})

# Generated at 2022-06-24 11:43:48.494030
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import sys
    class TestFD(FragmentFD):
        def to_screen(self, *args, **kargs):
            print(args)

    fd = TestFD({
        'retries': 3,
        'fragment_retries': 4,
    })

    # Test with fragment_retries specified
    fd.report_retry_fragment(
        Exception('Server HTTP error'), 101, 2, 4)
    assert sys.stdout.getvalue() == (
        "[('[download] Got server HTTP error: Server HTTP error. ', "
        "'Retrying fragment 101 (attempt 2 of 4)...')]\n")

    # Test with fragment_retries not specified
    fd.to_screen = lambda *args, **kargs: None

# Generated at 2022-06-24 11:43:52.646449
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    dl = FragmentFD(None, {'quiet': True})
    dl.to_screen = lambda *args, **kargs: True
    dl.report_skip_fragment(0)



# Generated at 2022-06-24 11:43:58.297950
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from . import YoutubeDL
    ydl = YoutubeDL(params={'noprogress': True, 'logger': sys.stdout})
    assert ydl.params['logger'] is sys.stdout
    dl = HttpQuietDownloader(ydl, {})
    assert dl.ydl is ydl
    assert ydl.params['logger'] is dl

# Generated at 2022-06-24 11:44:07.939557
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .common import FileDownloader
    from .http import HttpFD

    class TestHttpQuietDownloader(HttpQuietDownloader):
        def to_screen(self, *args, **kargs):
            self.screen_string = args + (kargs,)

    ydl = FileDownloader(params={})
    ydl.add_info_extractor(TestIE())
    test_http_quiet_downloader = TestHttpQuietDownloader(ydl, {'continuedl': True})

    test_http_quiet_downloader.to_screen('a')
    assert test_http_quiet_downloader.screen_string == (('a',), {})

    test_http_quiet_downloader.to_screen('b', {'a': 1})

# Generated at 2022-06-24 11:44:17.971968
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    import io
    import unittest

    class StubYDL(object):
        def to_screen(self, *args, **kargs):
            pass

    class TestClass(unittest.TestCase):
        def test(self):
            frag_index = 5
            orig_stdout = sys.stdout
            sys.stdout = io.BytesIO()
            fd = FragmentFD(StubYDL(), {'quiet': True})
            fd.report_skip_fragment(frag_index)
            sys.stdout.seek(0)
            message = sys.stdout.read()
            sys.stdout = orig_stdout
            self.assertEqual(message, '[download] Skipping fragment 5...\n'.encode('ascii'))
    unittest.main()

# Generated at 2022-06-24 11:44:29.963361
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import copy

    import nose.tools
    import mock

    dl = FragmentFD()

    nose.tools.assert_true(hasattr(dl, 'report_retry_fragment'))
    nose.tools.assert_true(hasattr(dl, 'report_skip_fragment'))
    nose.tools.assert_true(hasattr(dl, '_prepare_url'))
    nose.tools.assert_true(hasattr(dl, '_prepare_and_start_frag_download'))
    nose.tools.assert_true(hasattr(dl, '__do_ytdl_file'))
    nose.tools.assert_true(hasattr(dl, '_read_ytdl_file'))

# Generated at 2022-06-24 11:44:33.838416
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from ..compat import compat_basestring
    dl = FragmentFD(None, {})
    result = dl.report_skip_fragment(5)
    assert isinstance(result, compat_basestring)
    assert result.startswith('[download] Skipping fragment 5...')


# Generated at 2022-06-24 11:44:39.002343
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    sys.stdout = open('log.txt', 'w')
    ff = FragmentFD(None)
    ff.report_skip_fragment(1)
    sys.stdout.close()
    sys.stdout = sys.__stdout__
    expected = '...\n[download] Skipping fragment 1...\n'
    with open('log.txt', 'r') as f:
        actual = f.read()
    os.remove('log.txt')
    assert actual == expected

# Generated at 2022-06-24 11:44:45.322610
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..compat import compat_urlparse
    from ..compat import compat_urllib_request

    url = 'https://www.youtube.com/watch?v=EbKLBPmH7Ow'
    ie = get_info_extractor(url)
    info = ie.extract(url)
    # fd = FragmentFD(lambda url: url,
    #                 info['url'],
    #                 {'http_headers': info['http_headers'],
    #                  'total_frags': info.get('fragment_count') or 1,
    #                  'fragment_base_url': info.get('fragment_base_url'),
    #                  'skip_unavailable_fragments': True},
    #                 True

# Generated at 2022-06-24 11:44:50.136458
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {})
    assert 'Skipping fragment 0...' == fd.report_skip_fragment(0)
    assert 'Skipping fragment 1...' == fd.report_skip_fragment(1)

# Generated at 2022-06-24 11:44:52.567508
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class O(object):
        pass
    O.params = {}
    o = O()
    assert isinstance(FragmentFD(o).params, dict)

# Generated at 2022-06-24 11:45:03.668567
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD(None)
    fd.to_screen = lambda *args, **kargs: args
    assert (
        fd.report_retry_fragment(
            SystemExit, 2, 3, (1, 2)) ==
        ('[download] Got server HTTP error: SystemExit. Retrying fragment 2 (attempt 3 of 2)...',))
    assert (
        fd.report_retry_fragment(
            ValueError, 2, 3, (1, 2)) ==
        ('[download] Got server HTTP error: ValueError. Retrying fragment 2 (attempt 3 of 2)...',))

# Generated at 2022-06-24 11:45:05.152357
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        FD_NAME = 'test'

    TestFD(None, {})

# Generated at 2022-06-24 11:45:05.898489
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    pass

# Generated at 2022-06-24 11:45:08.854896
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    fd = FragmentFD(None)
    out = sys.stdout
    sys.stdout = sys.stderr
    fd.report_skip_fragment(5)
    sys.stdout = out

# Generated at 2022-06-24 11:45:14.482320
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params = {
        'continue_dl': 0,
        'quiet': False,
        'ratelimit': 0,
        'retries': 0,
        'noprogress': False,
        'test': False,
    }
    hqd = HttpQuietDownloader(None, params)
    assert hqd.params == params

# Generated at 2022-06-24 11:45:22.368770
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {
        'continuedl': True,
        'retries': 10,
        'noprogress': True,
        'ratelimit': 200000,
    })
    assert not fd.params.get('continuedl', True)
    assert fd._retries == 10
    assert fd._sleep_interval == 3
    assert fd.params['noprogress']
    assert fd.params['continuedl']
    assert fd.params['ratelimit'] == 200000

# Generated at 2022-06-24 11:45:29.489500
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .dash import DASHFD
    from .hls import HLSFD
    from .http import HttpFD
    assert issubclass(DASHFD, FragmentFD)
    assert issubclass(HLSFD, FragmentFD)
    assert not issubclass(HttpFD, FragmentFD)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:45:32.708772
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader({})
    assert ydl

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-24 11:45:34.345799
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader

    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-24 11:45:36.299085
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    obj = HttpQuietDownloader(None, None)
    assert obj.to_screen('hello', end=None) is None

# Generated at 2022-06-24 11:45:39.957341
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class TestFD(FragmentFD):
        def to_screen(self, *args, **kargs):
            TestFD.last_args = args

    fd = TestFD(None)
    fd.report_skip_fragment(42)
    assert TestFD.last_args[0] == '[download] Skipping fragment 42...'

# Generated at 2022-06-24 11:45:42.501999
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    FD = FragmentFD()
    FD.to_screen = lambda *x: None
    FD.report_skip_fragment(4)

# Generated at 2022-06-24 11:45:48.265137
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    import six
    fd = FragmentFD(None, {})
    fd.to_screen = six.StringIO()
    fd.report_retry_fragment(Exception('foo'), 7, 1, 10)
    assert fd.to_screen.getvalue() == (
        '[download] Got server HTTP error: foo. Retrying fragment 7 (attempt 1 of 10)...\n')

# Generated at 2022-06-24 11:45:59.544757
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .common import FileDownloader
    from .http import HttpFD
    from .extractor import gen_extractors
    from ..compat import parse_qs

    ydl = FileDownloader({})
    ydl.add_info_extractor(gen_extractors())

    class TestFD(HttpFD):
        def real_download(self, filename, info_dict):
            self.to_screen('message1')
            self.to_screen('message2')
            return True

    info_dict = ydl.extract_info(
        'http://localhost:8080/echo',
        download=False,
        process=False,
        extra_info={'noplaylist': False, 'http_headers': {'Cookie': 'foo=bar; bar=baz'}})

# Generated at 2022-06-24 11:46:05.937307
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_skip_fragment(36) == (
        "[download] Skipping fragment 36...",)
    assert fd.report_skip_fragment(-1) == (
        "[download] Skipping fragment -1...",)

# Generated at 2022-06-24 11:46:15.063760
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class FakeFD(FragmentFD):
        def __init__(self):
            self.to_screen_calls = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_calls.append(message)

    fragment_fd = FakeFD()
    err = ValueError('test error')
    retries = 5

    # retries is a finite number
    fragment_fd.format_retries = lambda x: '%d' % x
    for count in range(1, retries + 1):
        fragment_fd.report_retry_fragment(err, 1, count, retries)
    assert 'Got server HTTP error: test error. Retrying fragment 1 (attempt 1 of %d)...' % retries in fragment_fd.to_screen_calls[0]
   

# Generated at 2022-06-24 11:46:19.720709
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD({})
    fd.to_screen = lambda s: s
    fd.report_skip_fragment(13) == '[download] Skipping fragment 13...'

# Generated at 2022-06-24 11:46:26.505309
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # This is just a dummy class to test method report_skip_fragment of class FragmentFD
    class DummyFD(FragmentFD):
        def __init__(self):
            pass

    fd = DummyFD()
    out = u''
    fd.to_screen = lambda *args, **kargs: out.__iadd__(args[0] + u'\n')
    fd.report_skip_fragment(2)
    assert out == u'[download] Skipping fragment 2...\n'


# Generated at 2022-06-24 11:46:34.045498
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    fd = FragmentFD()
    assert fd.format_retries(None) == 'infinite'
    assert fd.format_retries(0) == 'no'
    assert fd.format_retries(1) == '1'
    assert fd.format_retries(2) == '2'
    assert fd.format_retries(5) == '5'


if __name__ == '__main__':
    test_FragmentFD_report_retry_fragment()

# Generated at 2022-06-24 11:46:43.521055
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    from .common import FileDownloader
    from .extractor import gen_extractors, list_extractors
    # TODO: Figure out how to test quiet mode functionality

    # Create test downloader
    class TestDownloader(FileDownloader):
        def to_screen(self, *a, **ka):
            self._screen_str = a[0] % a[1:]
    fd = TestDownloader(gen_extractors())

    # Define test case
    test_cases = [
        {
            'test_fragment_index': 2
        },
    ]

    # Execute test case
    for case in test_cases:
        fd.report_skip_fragment(case['test_fragment_index'])

# Generated at 2022-06-24 11:46:55.608974
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .downloader import FakeYDL
    from .extractor.common import InfoExtractor
    from .postprocessor import FFmpegMetadataPP
    from .compat import urlopen

    def test_report_retry_fragment(fd):
        # This test is needed for coverage
        try:
            urlopen('http://127.0.0.1:1')
        except Exception:
            fd.report_retry_fragment(
                Exception(), 0, 1, fd.params.get('fragment_retries'))

    # Create a fake InfoExtractor with a FakeYDL instance
    fake_ie = type('FakeIE', (InfoExtractor,), {
        '_WORKING': True,
        '_downloader': None,
        '_NAME': 'FakeIE',
    })(FakeYDL())

# Generated at 2022-06-24 11:46:57.793215
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params = {'quiet': True, 'noprogress': True}
    assert HttpQuietDownloader({}, params).params == params

# Generated at 2022-06-24 11:47:01.595578
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class TestQuietDownloader(HttpQuietDownloader):
        def __init__(self):
            self.screen_str = ''

        def to_screen(self, str):
            self.screen_str += str

    test_ytdl = TestQuietDownloader()
    test_ytdl.to_screen('abc')
    assert test_ytdl.screen_str == ''

# Generated at 2022-06-24 11:47:13.656364
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor.common import InfoExtractor
    import sys

    class MockHttpQuietDownloader_to_screen(HttpQuietDownloader):

        def _real_download(self, *args, **kwargs):
            return None

    ie = InfoExtractor()
    ie.add_info_extractor(_TEST_INSTANCE(ie))
    dl = MockHttpQuietDownloader_to_screen(ie)
    # redirect stderr to a file
    filename_temp_file = os.path.join(os.path.dirname(__file__), u'temp_file')
    sys.stderr = open(filename_temp_file, 'w')
    # check the message is not printed on stderr
    dl.to_screen(u'A message')
    sys.stderr.close()


# Generated at 2022-06-24 11:47:17.370741
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, {})
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_skip_fragment(1) == ([], {
        'skip_unavailable_fragments': True
    })

# Generated at 2022-06-24 11:47:22.427181
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    # pylint: disable=protected-access
    f = FragmentFD()
    f._print_fn = lambda x: x
    def test(expected, **kwargs):
        assert f.report_skip_fragment(**kwargs) == expected
    test('[download] Skipping fragment 3...', frag_index=3)


# Generated at 2022-06-24 11:47:26.448702
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    from contextlib import contextmanager
    from io import StringIO

    @contextmanager
    def override_stdout():
        stdout = sys.stdout
        sys.stdout = StringIO()
        try:
            yield
        finally:
            sys.stdout = stdout

    with override_stdout():
        test_downloader = HttpQuietDownloader(None, None)
        test_downloader.to_screen('test')
        assert sys.stdout.getvalue() == ''

# Generated at 2022-06-24 11:47:32.955589
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    """Test that HttpQuietDownloader.to_screen() is silent"""
    h = HttpQuietDownloader(None, {})
    try:
        h.to_screen('x')
    except SystemExit:
        assert False, 'HtppQuietDownloader.to_screen() raised SystemExit'
test_HttpQuietDownloader_to_screen()

# Generated at 2022-06-24 11:47:42.168380
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    class MockFD(FragmentFD):
        def __init__(self):
            self.to_screen_buffer = []

        def to_screen(self, *args, **kargs):
            self.to_screen_buffer.append((args, kargs))

    fragment_fd = MockFD()
    fragment_fd.report_retry_fragment(
        IOError('BOOM'), fragment_index=1, count=2, retries=3)
    assert fragment_fd.to_screen_buffer == [
        (('[download] Got server HTTP error: BOOM. Retrying fragment 1 (attempt 2 of 3)...',), {})]
    fragment_fd.to_screen_buffer[:] = []


# Generated at 2022-06-24 11:47:52.669676
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import io
    import unittest
    class HttpQuietDownloaderTest(unittest.TestCase):
        def test_quiet(self):
            old_stderr = sys.stderr
            sys.stderr = io.StringIO()
            try:
                dl = HttpQuietDownloader(None, {"quiet":True})
                self.assertEqual(len(sys.stderr.getvalue()), 0)
                dl.to_screen('abc')
                self.assertEqual(len(sys.stderr.getvalue()), 0)
            finally:
                sys.stderr = old_stderr

    unittest.main()

# Generated at 2022-06-24 11:47:56.226570
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    sys.stdout.seek(0)
    sys.stdout.truncate()
    d = HttpQuietDownloader(None, {})
    d.to_screen('Message')
    assert sys.stdout.getvalue() == ''

# Generated at 2022-06-24 11:47:59.131159
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    fd = FragmentFD(None, None, None)
    fd.to_screen = lambda *args, **kargs: args
    assert fd.report_skip_fragment(10) == ('[download] Skipping fragment 10...',)

# Generated at 2022-06-24 11:48:07.087264
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import io
    import sys
    from .common import FileDownloader

    class MockYdl:
        def __init__(self, ydl):
            self.params = ydl.params

        def to_screen(self, msg, **kwargs):
            print(msg)

    from .http import HttpFD

    old_stderr = sys.stderr
    sys.stderr = io.BytesIO()  # Make sure nothing is written to stderr
    fd = FileDownloader({'verbose': False, 'outtmpl': '%(id)s'})
    try:
        fd = HttpQuietDownloader(MockYdl(fd), fd.params)
        assert sys.stderr.getvalue() == b''
    finally:
        sys.stderr.close()
       

# Generated at 2022-06-24 11:48:18.954117
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    # class HttpQuietDownloader(HttpFD):
    #    def to_screen(self, *args, **kargs):
    #        pass
    # see HttpQuietDownloader.to_screen
    hqd = HttpQuietDownloader({}, {
        # after HttpDownloader.__init__(self, ydl, params)
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False})
    hqd.to_screen('to_screen: Test message')
    assert not sys.stderr.getvalue()


# Generated at 2022-06-24 11:48:22.314637
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    ie = get_info_extractor('test_ie')
    assert ie.__class__.__name__ == 'test_IE'
    assert FragmentFD.__name__ == 'FragmentFD'

# Generated at 2022-06-24 11:48:29.475519
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import gen_extractors
    from .extractor.generic import GenericIE
    from .extractor.common import InfoExtractor
    IE_DESC = {
        'ie_key': 'Test',
        'extractor': 'Test',
        'name': 'Test',
        'description': 'Test',
    }

    class TestIE(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(TestIE, self).__init__(*args, **kwargs)
            self.to_screen_result = None

        def to_screen(self, *args, **kwargs):
            self.to_screen_result = (args, kwargs)

    ie = TestIE(IE_DESC)
    gen_extractors(ie)

# Generated at 2022-06-24 11:48:39.633290
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from .common import HEADRequest
    from ..compat import urlopen
    from .http import HttpFD
    from .fragment import FragmentFD

    def run(s):
        fd = FragmentFD()
        fd.to_screen = lambda *args, **kargs: s.append(args)
        fd.report_retry_fragment(Exception('foo'), 1, 2, 3)
        fd.report_retry_fragment(Exception(Exception('foo')), 10, 20, 30)
        return s

    def request_factory(*args, **kargs):
        return HEADRequest(*args, **kargs)

    def urlopen_factory(*args, **kargs):
        return urlopen(*args, **kargs)

    HttpFD._request = request_factory
    Http

# Generated at 2022-06-24 11:48:48.809810
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    options = {
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }
    ydl = {
        'params': {
            'socket_timeout': None,
        },
    }
    dl = HttpQuietDownloader(ydl, options)
    assert dl.ydl is ydl
    assert dl.params == options
    assert dl._socket_timeout == ydl['params']['socket_timeout']



# Generated at 2022-06-24 11:48:55.957534
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor.common import InfoExtractor
    ie = InfoExtractor({})
    ydl = ie.ydl
    ydl.params['external_downloader'] = 'wget'
    ydl.params['external_downloader_args'] = []
    ydl.download(['http://example.com'], {
        'quiet': True,
        'continuedl': True,
    })

# Generated at 2022-06-24 11:48:57.772622
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    fd = FragmentFD('test', {}, FileDownloader)
    assert fd

# Generated at 2022-06-24 11:49:05.200310
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    import sys
    from .report import MockYDL
    from .common import FileDownloader
    from .extractor.common import InfoExtractor
    from ..compat import is_py2
    from ..utils import FakeDict

    i = InfoExtractor()
    i.set_downloader(FileDownloader(MockYDL()))
    i.report_skip_fragment(2)

    if is_py2:
        assert sys.stdout.getvalue() == '[generic] Skipping fragment 2...\n'
    else:
        assert sys.stdout.getvalue() == '[generic] Skipping fragment 2...\n'

# Generated at 2022-06-24 11:49:13.573364
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=W0212
    import io
    import sys

    saved_stderr = sys.stderr
    try:
        sys.stderr = io.BytesIO()
        HttpQuietDownloader(
            {'params': {'noprogress': True}},
            {'quiet': True}
        )
        assert sys.stderr.getvalue() == b''
    finally:
        sys.stderr = saved_stderr

# Generated at 2022-06-24 11:49:22.727414
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class FakeYdl:
        def __init__(self):
            self.to_screen_calls = []
        def to_screen(self, *args, **kargs):
            self.to_screen_calls.append((args, kargs))
    dl = HttpQuietDownloader(FakeYdl(), {'noprogress': True})
    dl.to_screen('test')
    assert not dl.ydl.to_screen_calls, 'to_screen was called with noprogress'
    dl = HttpQuietDownloader(FakeYdl(), {'noprogress': False})
    dl.to_screen('test')

# Generated at 2022-06-24 11:49:24.678732
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'



# Generated at 2022-06-24 11:49:28.125604
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from ..extractor import gen_extractors
    ydl = FileDownloader({})
    gen_extractors(ydl)
    dl = FragmentFD(ydl, {})

# Generated at 2022-06-24 11:49:29.830299
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = YoutubeDL({})
    fd = FragmentFD(ydl)
    assert fd.params == {}

# Generated at 2022-06-24 11:49:38.045197
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys

    if sys.version_info < (2, 6):
        ydl = None
    else:
        from .extractor import gen_extractors
        from .postprocessor import gen_pp

        ydl = FileDownloader({
            'outtmpl': '%(id)s',
            'quiet': True,
            'simulate': True,
            'format': 'best',
            'extractors': gen_extractors(),
            'postprocessors': gen_pp(),
        })
    assert HttpQuietDownloader(ydl, {}) is not None

# Generated at 2022-06-24 11:49:41.194464
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {}
    assert not 'info_dict' in HttpQuietDownloader(ydl, {}).params
    assert HttpQuietDownloader(ydl, {'info_dict': True}).params['info_dict'] == ydl

# Generated at 2022-06-24 11:49:48.676614
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .fragment import FragmentFD
    desc = {
        'id': 'test_id',
        'title': 'test_title',
        'ext': 'test_ext',
        'filesize': 100,
    }
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': 'test_ratelimit',
        'retries': 'test_retries',
        'nopart': 'test_nopart',
        'test': 'test_test',
    }
    fd = FragmentFD(None, desc, params)
    dl = fd._downloader
    assert isinstance(dl, HttpQuietDownloader)
    assert dl.ydl.params['continuedl']

# Generated at 2022-06-24 11:49:56.522790
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    import sys
    import StringIO
    HttpQuietDownloader(None, None).to_screen('This won\'t be printed')
    out = StringIO.StringIO()
    try:
        sys.stdout = out
        HttpQuietDownloader(None, None).to_screen('This will be printed')
        assert out.getvalue() == 'This will be printed\n'
    finally:
        sys.stdout = sys.__stdout__

# Generated at 2022-06-24 11:50:05.293091
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .tests.test_extractor import FakeYDL
    class FakeFD(FragmentFD):
        def __init__(self):
            super(FakeFD, self).__init__(FakeYDL(), {})

    ydl = FakeYDL()
    fd = FakeFD()
    fd.to_screen = ydl.to_screen
    fd.report_warning = ydl.report_warning
    fd.report_error = ydl.report_error

    # Test invalid ctx dict
    ctx = {'tmpfilename': 'tmp', 'filename': 'filename'}
    try:
        fd._prepare_frag_download(ctx)
        assert False
    except AssertionError:
        pass

    # Test ctx dict with valid values

# Generated at 2022-06-24 11:50:14.165138
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--test-http-quiet-downloader')
    args = parser.parse_args()

    if args.test_http_quiet_downloader:
        dl = HttpQuietDownloader(None, {'restrictfilenames': True})

# Generated at 2022-06-24 11:50:19.809302
# Unit test for method report_skip_fragment of class FragmentFD
def test_FragmentFD_report_skip_fragment():
    class FragmentFD_report_skip_fragment(FragmentFD):
        def to_screen(self, *args, **kargs):
            self._screen_str = args[0]

    frag_fd = FragmentFD_report_skip_fragment()
    frag_fd.report_skip_fragment(123)
    assert frag_fd._screen_str == '[download] Skipping fragment 123...'

# Generated at 2022-06-24 11:50:24.409555
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ..extractor.common import FileDownloader
    from .http import HttpFD

    fd = FragmentFD(FileDownloader({}), {})
    fd.to_screen = lambda *args, **kargs: None
    fd.report_retry_fragment(Exception('xxx'), 0, 1, (3, 1))



# Generated at 2022-06-24 11:50:36.524112
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from types import MethodType

    class MockYDL():
        def __init__(self):
            self.params = {
                'continuedl': True,
                'quiet': True,
                'noprogress': True,
                'ratelimit': None,
                'retries': 0,
                'nopart': False,
                'test': False,
            }
            self.cache = {}
            self.to_screen = lambda s: print(s)

    ydl = MockYDL()
    ffd = FragmentFD(ydl, ydl.params)
    assert ffd._start_frag_download.__func__ == FragmentFD._start_frag_download.__func__

# Generated at 2022-06-24 11:50:44.004527
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from .extractor import get_info_extractor

    ie = get_info_extractor('http://www.youtube.com/watch?v=BaW_jenozKc')
    ie._downloader = HttpQuietDownloader({}, ie)
    ie.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-24 11:50:53.485028
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_http_server
    from ..compat import compat_urllib_parse_urlparse
    from urllib.parse import parse_qs
    from .http import HttpFD

    class TestServer(compat_http_server.HTTPServer):
        def handle_error(self, request, client_address):
            pass

    def test_handler(httpd):
        def do_HEAD(handler):
            handler.send_response(200)
            handler.send_header('Content-length', 0)
            handler.end_headers()

        def do_GET(handler):
            qs = compat_urllib_parse_urlparse(handler.path).query
            req = parse_qs(qs)

# Generated at 2022-06-24 11:50:57.098756
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    ydl = object()
    params = dict()
    qDwl = HttpQuietDownloader(ydl, params)
    x = qDwl.to_screen('hello world')
    assert x is None, 'HttpQuietDownloader does not work'

# Generated at 2022-06-24 11:51:00.459968
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    test_ie = InfoExtractor()
    test_ie.params = {}
    test_ie._setup_opener()
    assert isinstance(test_ie._opener, HttpQuietDownloader)

# Generated at 2022-06-24 11:51:06.113140
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ctx = {}
    fd = FragmentFD(ctx)
    assert fd.params == {'nopart': False, 'noprogress': True, 'nooverwrites': False, 'retries': 0, 'ignoreerrors': False, 'quiet': True, 'continuedl': True}

# Generated at 2022-06-24 11:51:16.406663
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..utils import DateRange

    FD = FragmentFD({}, {})

    start_time = time.time()
    time.sleep(1)
    end_time = time.time()

    assert FD.calc_eta(start_time, end_time) == 1
    assert FD.calc_eta(start_time, end_time + 1, 100) == 1
    assert FD.calc_eta(start_time, end_time + 1, 50, 50) == 1
    assert FD.calc_eta(start_time, end_time, 50, 50) == 0

    def test_hook(_):
        pass


# Generated at 2022-06-24 11:51:22.082997
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    class Test:
        def __init__(self):
            self.message = ''
        def to_screen(self, message, skip_eol=False, check_quiet=False):
            self.message = message

    ydl = Test()
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    dl.to_screen('test_message')
    assert ydl.message == ''

# Generated at 2022-06-24 11:51:33.429510
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class FragmentTestFD(FragmentFD):
        def __init__(self):
            self.to_screen_calls = []
            self.report_warning_calls = []
            self.report_destination_calls = []
            self.params = {}
            self.calc_eta_calls = []

        def to_screen(self, message, skip_eol=False):
            self.to_screen_calls.append(message)

        def report_warning(self, message):
            self.report_warning_calls.append(message)

        def report_destination(self, filename):
            self.report_destination_calls.append(filename)


# Generated at 2022-06-24 11:51:43.567258
# Unit test for method report_retry_fragment of class FragmentFD
def test_FragmentFD_report_retry_fragment():
    from ssl import SSLError
    from urllib2 import URLError
    from youtube_dl.utils import DownloadError, UnsupportedError

    class FakeYDL:
        def __init__(self, params):
            self.params = params
    fdy = FakeYDL({})
    fdf = FragmentFD(fdy, fdy.params)
    assert fdf.format_retries(0) == 'infinite'
    assert fdf.format_retries(1) == '1'
    assert fdf.format_retries(2) == '2'

    with open(os.devnull, 'w') as devnull:
        fdf.to_screen = lambda *args, **kargs: print(*args, **kargs)
        fdf.to_screen('test', file=devnull)



# Generated at 2022-06-24 11:51:49.908807
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert isinstance(FragmentFD(None, {}), FragmentFD)
    assert isinstance(FragmentFD(None, {}, {'fragment_retries': 5}), FragmentFD)
    assert isinstance(FragmentFD(
        None, {}, {'skip_unavailable_fragments': True}), FragmentFD)
    assert isinstance(FragmentFD(
        None, {}, {'keep_fragments': True}), FragmentFD)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-24 11:51:56.840473
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from ..extractor import gen_extractors
    gen_extractors()
    from ..downloader.http import HttpFD

    ydl = HttpFD()

    # Add a mock object instead of a stream
    ydl.to_screen = lambda x, y, z: True
    test_string = 'test for HttpQuietDownloader.to_screen()'
    ydl.to_screen(test_string)

    # if the method calls HttpFD.to_screen()
    # the value of test_string will be returned
    assert test_string



# Generated at 2022-06-24 11:51:58.268280
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    assert FragmentFD(gen_extractors()).__class__ is FragmentFD

# Generated at 2022-06-24 11:52:01.639432
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    from ..compat import compat_str
    from io import StringIO
    out = StringIO()
    dl = HttpQuietDownloader(None, {'outtmpl': '-'})
    dl.to_screen = lambda *args, **kargs: print(args[0], file=out)
    dl.to_screen(u'foo', True)
    assert compat_str(out.getvalue()) == u'foo\n'

# Generated at 2022-06-24 11:52:08.007706
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    param = {
        'noprogress': True,
        'quiet': False,
        'nopart': False,
        'ratelimit': None,
        'retries': 0,
        'continuedl': True,
        'nocheckcertificate': False,
        'test': False
    }
    testDownloader = HttpQuietDownloader('', param)
    testDownloader.to_screen('test')
    assert 1 == 1

# Generated at 2022-06-24 11:52:17.367696
# Unit test for method to_screen of class HttpQuietDownloader
def test_HttpQuietDownloader_to_screen():
    out_fd = open('/dev/null', 'w')
    try:
        old_stderr = os.dup(2)
        os.dup2(out_fd.fileno(), 2)
        hqd = HttpQuietDownloader(None, {})
        hqd.to_screen('test1')
        hqd.to_screen('test2', 'test3')
        hqd.to_screen('test4', 'test5', 'test6')
        hqd.to_screen('test7', 'test8', 'test9', 'test10')
    finally:
        os.dup2(old_stderr, 2)
        out_fd.close()