

# Generated at 2022-06-12 16:49:15.769067
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import tempfile
    import shutil

    class MockYDL(object):
        def __init__(self):
            self.params = {
                'outtmpl': tempfile.mkdtemp(prefix='youtube-dl-test-'),
            }

    fd = FragmentFD(MockYDL())
    shutil.rmtree(fd.ydl.params['outtmpl'])

# Generated at 2022-06-12 16:49:30.137733
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    opt = {
        'usenetrc': False,
        'username': None,
        'password': None,
        'videopassword': None,
        'quiet': True,
    }
    ydl = gen_extractors(opt)['generic']

    class DummyFD(FragmentFD):
        @staticmethod
        def report_destination(filename):
            print('[Destination] %s' % filename)

        def _prepare_frag_download(self, ctx):
            ctx.update({
                'ad_frags': 3,
                'total_frags': 23,
                'filename': u'file_\u0439.txt',
            })
            FragmentFD._prepare_frag_download(self, ctx)

# Generated at 2022-06-12 16:49:42.715926
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import YoutubeIE

    ytdl = YoutubeIE()
    ytdl.params['quiet'] = True
    ytdl.params['test'] = True

    url = 'http://localhost:8080/test.mp4?start=1.0&end=3.0'
    info_dict = {}
    info_dict['http_headers'] = {
        'Range': 'bytes=%d-%d' % (1000, 3000)
    }

    dl = HttpQuietDownloader(ytdl, {})

    req = dl._prepare_url(info_dict, url)
    assert req.url == url
    assert req.headers == info_dict['http_headers']


# Generated at 2022-06-12 16:49:46.304737
# Unit test for constructor of class FragmentFD
def test_FragmentFD():

    class TestFD(FragmentFD):
        FD_NAME = 'test'

    tfd = TestFD({})

    assert tfd.FD_NAME == 'test'

# Generated at 2022-06-12 16:49:50.342691
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    hqd = HttpQuietDownloader(HttpFD(), {'quiet': True})
    assert 'toscreen' not in hqd
    assert hqd._opts['quiet'] is True

# Generated at 2022-06-12 16:49:51.915139
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)


# Generated at 2022-06-12 16:50:01.481911
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        def __init__(self, ydl):
            super(MyFragmentFD, self).__init__(ydl)

    class DummyYDL(object):
        def __init__(self):
            self.params = {}

    fd = MyFragmentFD(DummyYDL())
    assert fd.params == {
        'noprogress': True,
        'retries': 0,
    }

# Generated at 2022-06-12 16:50:08.708580
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .downloader import gen_extractor_classes

    for ie in gen_extractor_classes():
        if ie.IE_NAME != 'generic':
            continue
        for url in ie.working_urls():
            ie = gen_extractor(ie.ie_key(), url)
            print(ie.__class__.__name__ + ': ' + url)
            params = {
                'noprogress': True,
                'forcetitle': True,
                'forcethumbnail': True,
                'forceid': True,
                'simulate': True,
                'format': 'best',
            }

# Generated at 2022-06-12 16:50:10.525190
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Test parameter check
    try:
        HttpQuietDownloader(None, None)
        assert False
    except TypeError:
        pass

# Generated at 2022-06-12 16:50:13.898527
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    def download(self, url_or_request, filename, info_dict):
        return True
    hd = HttpQuietDownloader(None, {})
    hd.to_screen = lambda *args: None
    hd._do_download = download
    hd.download(None, 'test_filename', None)

# Generated at 2022-06-12 16:50:36.051183
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..utils import FakeYDL
    fd = FragmentFD(FakeYDL())
    assert fd.FROM_MANIFEST == 0

# Generated at 2022-06-12 16:50:45.112133
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_error

    class FakeInfoExtractor(InfoExtractor):
        def _real_initialize(self):
            return

    class FakeFragmentFD(FragmentFD):
        def real_download(self, filename, info_dict):
            return True

    frfd = FakeFragmentFD(FakeInfoExtractor(), {})
    # Test for Live streams
    ctx = {}
    frfd._prepare_frag_download(ctx)
    assert frfd._start_frag_download(ctx)

# Generated at 2022-06-12 16:50:50.944853
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..utils import FakeYDL

    params = {
        'fragment_retries': 10,
        'skip_unavailable_fragments': True,
        'keep_fragments': False,
    }

    ydl = FakeYDL()
    ffd = FragmentFD(ydl, params)

    assert ffd._params == params
    assert ffd._ydl is ydl
    assert ffd.FD_NAME == 'fragment'

# Generated at 2022-06-12 16:51:00.787244
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class DummyExtractor(FragmentFD):
        def real_initialize(self):
            pass

        def real_extract(self, url):
            pass

    frag_dl = DummyExtractor()
    assert frag_dl.params['retries'] == 10
    assert frag_dl.params['continuedl'] is True
    assert frag_dl.params['quiet'] is True
    assert frag_dl.params['noprogress'] is True
    assert frag_dl.params['ratelimit'] is None
    assert frag_dl.params['nopart'] is False

# Generated at 2022-06-12 16:51:09.573557
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    MockIE = type(str('MockIE'), (InfoExtractor,), {})
    url = 'http://www.example.org/v.mp4'
    ydl = {}
    fd = FragmentFD(ydl, {'format': 'm4a'}, MockIE(ydl, {}), url)
    assert fd.params == {
        'continuedl': True,
        'format': 'm4a',
        'quiet': True,
        'noprogress': True,
        'retries': 0,
    }
    assert fd.extractor.__class__ == MockIE
    assert fd.ie.__class__ == MockIE
    assert fd.url == url

# Generated at 2022-06-12 16:51:20.155377
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .downloader import Downloader
    from .http import HttpFD

    class DummyYDL(object):
        def __init__(self, params):
            self.params = params

    ydl = DummyYDL({'noprogress': True})
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert isinstance(dl, Downloader)
    assert isinstance(dl, HttpFD)
    assert dl.ydl == ydl
    assert dl.params['quiet'] is True
    assert dl.params['noprogress'] is True

# Generated at 2022-06-12 16:51:32.126816
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        from io import BytesIO
    except ImportError:
        from StringIO import StringIO as BytesIO

    class YDL(object):
        def __init__(self):
            self._progress_hooks = []

        def add_progress_hook(self, hook):
            self._progress_hooks.append(hook)

        def _run_progress_hooks(self, status):
            for ph in self._progress_hooks:
                ph(status)

    class DummyHttpFD(object):
        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params

# Generated at 2022-06-12 16:51:34.453368
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor.common import InfoExtractor
    assert InfoExtractor()._request_webpage(
        'http://www.youtube.com',
        downloader=HttpQuietDownloader)

# Generated at 2022-06-12 16:51:37.693741
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    ie = InfoExtractor()
    # Just smoke test
    HttpQuietDownloader(ie, {})

# Generated at 2022-06-12 16:51:42.861264
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {}
    params = {'quiet': True, 'noprogress': True}
    dl = HttpQuietDownloader(ydl, params)

    assert dl._ydl is ydl
    assert dl._params == params

# Generated at 2022-06-12 16:52:13.605659
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def assert_ctx(ctx, expected_keys):
        assert isinstance(ctx, dict)
        assert set(expected_keys) == set(ctx.keys())

    def assert_hook(ctx, hook_name, hook_func):
        hook_func_name = hook_name + '_hook'
        hook_data = hook_name + '_data'
        hook_func(ctx[hook_data])
        assert hook_func_name in ctx
        assert ctx[hook_func_name] == hook_func

    def test_hook(ctx, hook_name, hook_func, hook_data):
        hook_func_name = hook_name + '_hook'
        hook_func(ctx[hook_data])
        assert hook_func_name in ctx
        assert ctx[hook_func_name] == hook_

# Generated at 2022-06-12 16:52:18.452554
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=W0212
    fd = FragmentFD(
        None,
        # Dummy params
        {
            'itag': None,
        })
    del fd

# Generated at 2022-06-12 16:52:19.778962
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader(None, {'quiet': True})

# Generated at 2022-06-12 16:52:21.858345
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD({})
    assert isinstance(fd, FragmentFD)
    assert isinstance(fd, FileDownloader)

# Generated at 2022-06-12 16:52:28.425279
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=W0212
    from .http import HttpDownloader

    dl = HttpQuietDownloader(
        None, {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'nopart': True,
            'test': True,
        }
    )
    assert dl.__class__ == HttpDownloader

# Generated at 2022-06-12 16:52:31.245078
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader(None, None).to_screen.__name__ == 'to_screen'


# Generated at 2022-06-12 16:52:38.280557
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.add_info_extractor(lambda *args, **kwargs: None)
    ie._call_downloader = lambda *args, **kwargs: None
    ie._downloader = HttpQuietDownloader(ie, {'quiet': False})
    ie._downloader.to_screen(
        "[youtube] Setting language", {
            'codes': ["en", "en_US"]
        })

# Generated at 2022-06-12 16:52:48.609616
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from random import randint

    from .utils import IsolatedFD

    class FragmentFDTest(FragmentFD, IsolatedFD):
        pass

    fd = FragmentFDTest()
    assert fd.FD_NAME == 'Unknown'
    fd.report_skip_fragment(randint(0, 100)) == None
    fd.report_retry_fragment(Exception('test exception'), randint(0, 100), randint(0, 100), randint(0, 100)) == None

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:52:50.906137
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        from ..extractor.common import InfoExtractor
    except ImportError:
        return
    class FakeIE(InfoExtractor):
        @property
        def params(self):
            return {'test': True}
    FakeIE._downloader = FragmentFD(FakeIE(), {})
    assert FakeIE._downloader.params['test'] == True

# Generated at 2022-06-12 16:53:00.193173
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import common
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'fake'
        def _real_extract(self, url):
            return {
                'id': 'foo',
                'ext': 'ts',
                'title': 'foo',
                'formats': [{
                    'url': url,
                    'ext': 'ts',
                    'format_id': 'foo',
                }],
            }

    class FakeFD(FragmentFD):
        FD_NAME = 'fake'

    fake_ie = FakeInfoExtractor()
    fake_ie.add_info_extractor(FakeInfoExtractor)
    ydl = common.Ytdl({'noplaylist': True})
   

# Generated at 2022-06-12 16:53:47.025827
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import youtube_dl.YoutubeDL
    sys.argv = [sys.argv[0]]
    sys.argv += ['-q', '--no-warnings', '--max-filesize', '1']
    try:
        main(youtube_dl.YoutubeDL)
    except DownloadError:
        pass
    else:
        assert False, 'DownloadError not raised'

# Generated at 2022-06-12 16:53:56.761770
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD

    class DummyIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'dummyid',
                'ext': 'mp4',
                'title': 'dummy',
                'url': url,
            }
    ie = DummyIE(params={
        'skip_download': True,
        'noplaylist': True,
        'quiet': True,
    })

# Generated at 2022-06-12 16:54:09.457722
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        from . import YoutubeDL
    except ImportError:
        from __main__ import YoutubeDL
    from .downloader.http import HttpFD
    from .downloader.common import FileDownloader
    from .downloader.external import ExternalFD
    ydl = YoutubeDL()
    dl = HttpQuietDownloader(ydl, {})
    assert dl.params == {'continuedl': True, 'noprogress': True, 'quiet': True}
    assert isinstance(dl.ydl, YoutubeDL)

    dl = HttpQuietDownloader(ydl, {'continuedl': False, 'noprogress': False, 'quiet': False})
    assert dl.params == {'continuedl': False, 'noprogress': False, 'quiet': False}

    assert issubclass

# Generated at 2022-06-12 16:54:17.443622
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD()
    assert fd.params['fragment_retries'] == 10
    assert fd.params['skip_unavailable_fragments']

    fd = FragmentFD(params={'test': True})
    assert fd.params['test']
    assert fd.params['noprogress']

    # Test that fragment_retries cannot be negative
    class MyFD(FragmentFD):
        def _prepare_frag_download(self, ctx):
            pass

        def _start_frag_download(self, ctx):
            pass

    fd = MyFD(params={'fragment_retries': -1})
    assert fd.params['fragment_retries'] == 0

if __name__ == '__main__':
    test_FragmentFD

# Generated at 2022-06-12 16:54:23.107299
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint:disable=W0212
    from .dash import DASHFD
    from .hls import HLSFD
    from .hlsnative import HLSNativeFD

    assert issubclass(DASHFD, FragmentFD)
    assert issubclass(HLSFD, FragmentFD)
    assert issubclass(HLSNativeFD, FragmentFD)

# Generated at 2022-06-12 16:54:28.822839
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    from .rtmp import RtmpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)
    assert issubclass(FragmentFD, RtmpFD)
    assert FragmentFD.__name__ == 'FragmentFD'
    assert FragmentFD.__module__ == __name__

# Generated at 2022-06-12 16:54:34.041562
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class _Fake:
        def __init__(self):
            self.params = {}

        def to_screen(self, *args, **kargs):
            pass

    f = _Fake()
    hqd = HttpQuietDownloader(f, {})
    assert hqd._opener.params == {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
    }

# Generated at 2022-06-12 16:54:37.076728
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .downloader import youtube_dl
    test_ctx = {'dl': youtube_dl}
    assert type(HttpQuietDownloader(test_ctx, {})) is HttpQuietDownloader
    assert test_ctx['dl'] is youtube_dl

# Generated at 2022-06-12 16:54:47.103733
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from test import ytdl_mock as mock
    from test import support
    from test import fake_system

    with fake_system.FakeOsModule('posix'):
        with support.temp_dir('FragmentFD') as tdir:
            with support.captured_output('stderr') as stderr:
                ctx = {
                    'filename': os.path.join(tdir, 'filename'),
                    'tmpfilename': os.path.join(tdir, 'tmp-filename'),
                    'ytdl_filename': os.path.join(tdir, 'filename.ytdl'),
                    'total_frags': 10,
                    'dl': mock.FakeYDL(),
                    'params': {},
                }
                fragment_fd = FragmentFD(mock.FakeYDL())

# Generated at 2022-06-12 16:54:52.964489
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': True,
        'retries': 0,
        'nopart': False,
        'test': False,
    }
    ydl = None
    dl = HttpQuietDownloader(ydl, params)

    for k, v in params.items():
        assert dl._params[k] == v

# Generated at 2022-06-12 16:56:12.184849
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    FragmentFD(FileDownloader())

# Generated at 2022-06-12 16:56:20.801468
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        def _prepare_and_start_frag_download(self, ctx):
            super(TestFD, self)._prepare_and_start_frag_download(ctx)
            self._finish_frag_download(ctx)

    fd = TestFD({})
    fd.params['skip_unavailable_fragments'] = True
    fd.params['fragment_retries'] = 0
    fd.params['keep_fragments'] = True
    fd.add_info_extractor(lambda x: x)
    fd._download_frag_list(
        [
            {
                'duration': 3,
                'url': 'url',
            }
        ],
        'test-filename',
        {}
    )

# Generated at 2022-06-12 16:56:30.639975
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD

    qdl = HttpQuietDownloader(1,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': False,
            'ratelimit': 1,
            'retries': 0,
            'nopart': False,
            'test': False,
        }
    )
    assert isinstance(qdl, HttpFD)
    assert qdl.continuedl is True
    assert qdl.quiet is True
    assert qdl.noprogress is False
    assert qdl.ratelimit == 1
    assert qdl.retries == 0
    assert qdl.nopart is False
    assert qdl.test is False

# Generated at 2022-06-12 16:56:40.317898
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors


# Generated at 2022-06-12 16:56:50.958058
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .http import HttpFD
    from .fragment import FragmentFD
    from .dash import DASHDownloader
    from .hls import HLSDownloader
    from .hlsnative import HLSNativeDownloader
    from .m3u8 import M3U8FD
    for fd_cls in [FragmentFD, DASHDownloader, HLSDownloader, HLSNativeDownloader, M3U8FD]:
        assert isinstance(fd_cls.__bases__[0], FragmentFD)
    assert isinstance(FragmentFD.__bases__[0], HttpFD)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:56:52.394428
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-12 16:56:54.932502
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # the ydl object is presumably an instance of YoutubeDL
    ydl = None
    fd = FragmentFD(ydl, {})


# Generated at 2022-06-12 16:57:03.809490
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import YoutubeDL
    class TestFD(FragmentFD):
        FD_NAME = 'test'

    ydl = YoutubeDL({})
    fd = TestFD(ydl)
    assert fd.params.get('keep_fragments') is False
    assert fd.params.get('nopart') is False
    assert fd.params.get('continuedl') is True
    assert fd.params.get('retries') == 0

    fd = TestFD(ydl, {'keep_fragments': True, 'nopart': True})
    assert fd.params.get('keep_fragments') is True
    assert fd.params.get('nopart') is True
    assert fd.params.get('continuedl') is True

# Generated at 2022-06-12 16:57:07.197752
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, None)
    assert fd.params == {
        'fragment_retries': 10,
        'keep_fragments': False,
        'skip_unavailable_fragments': True,
    }

# Generated at 2022-06-12 16:57:08.996579
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    FragmentFD(None, None)

