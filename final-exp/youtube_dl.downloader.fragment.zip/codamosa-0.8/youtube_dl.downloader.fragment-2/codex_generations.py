

# Generated at 2022-06-12 16:49:21.586699
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(
        {},
        {'outtmpl': '-', 'noprogress': True, 'quiet': True, 'ratelimit': 1048576},
        {}
    )
    assert fd

    fd = FragmentFD(
        {},
        {'outtmpl': 'foo.%(ext)s', 'noprogress': True, 'quiet': True, 'ratelimit': 1048576},
        {}
    )
    assert fd


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:49:29.487114
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import InfoExtractor
    from . import YoutubeIE
    from .extractor.youtube import YoutubeIE as NewYoutubeIE

    def _test_consistency(ie, url, filename=None):
        if filename is None:
            filename = 'test_%s' % ie.ie_key()
        url = '%s?nofragments' % url
        info_dict = ie._real_extract(url)
        # Make sure we can download fragmnets
        info_dict['fragment_retries'] = 0
        FD = FragmentFD.create_fd(
            ie, ie._downloader, filename, info_dict, {})
        FD.download()
        # And download the whole file
        info_dict['nofragments'] = True

# Generated at 2022-06-12 16:49:34.016400
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl_opts = {
        'fragment_retries': 1,
    }
    ffd = FragmentFD(FileDownloader(ydl=None, params={}), ydl_opts)
    assert ffd.params['fragment_retries'] == 1

# Generated at 2022-06-12 16:49:47.101349
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        def fragments_are_available(self, info_dict):
            return range(5)

        def _get_fragment_url(self, frag_index, info_dict):
            return 'http://example.org/%d' % frag_index

    import sys
    ydl = object.__new__(object)
    ydl.params = {}
    ydl.to_screen = lambda *args, **kargs: sys.stderr.write(
        ' '.join(map(str, args)) + '\n')
    fd = MyFragmentFD(ydl)
    info_dict = {}
    fd._do_download(info_dict, 'test.mp4')

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:49:50.234521
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """Make sure HttpQuietDownloader class could be instantiated."""
    hqd = HttpQuietDownloader(None, {})
    assert hqd is not None

# Generated at 2022-06-12 16:49:55.198981
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def assert_initial_state(self):
        assert self.params == {}
        assert self.ydl is not None
        assert self.FD_NAME is not None

    class DummyFragmentFD(FragmentFD):
        FD_NAME = 'Dummy'

    dummy_fd = DummyFragmentFD(None, {}, None)
    assert_initial_state(dummy_fd)

# Generated at 2022-06-12 16:50:03.618110
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FakeYDL
    from collections import namedtuple
    from ..extractor import get_info_extractor

    # Taken from m3u8_segment_test.py
    segment_url = 'http://example.org/seg-1.ts'
    expected_fragment_base_url = 'http://example.org/'
    m3u8_template = '''\
#EXTM3U
#EXT-X-TARGETDURATION:10
#EXT-X-MEDIA-SEQUENCE:0
#EXTINF:10, no desc
%s
#EXT-X-ENDLIST
'''
    m3u8_content = m3u8_template % segment_url

# Generated at 2022-06-12 16:50:04.825631
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader


# Generated at 2022-06-12 16:50:13.387850
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {
        'noprogress': True,
        'retries': 10,
        'nopart': True,
        'test': True,
        'continuedl': True,
        'quiet': True,
    })
    assert fd.params == {
        'noprogress': True,
        'retries': 10,
        'nopart': True,
        'test': True,
        'continuedl': True,
        'quiet': True,
    }
    assert fd.ydl is None

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:50:23.174151
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .smuggle import smuggle_url, smuggle_add_extra_info
    from .common import FileDownloader
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    class MyFD(FragmentFD):
        def fragment_retries(self):
            return self._opts.get('fragment_retries', 10)

        def skip_unavailable_fragments(self):
            return self._opts.get('skip_unavailable_fragments', False)


# Generated at 2022-06-12 16:50:43.364924
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-12 16:50:46.813779
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = FakeYDL()
    params = {'noprogress': True, 'quiet': True}
    hqd = HttpQuietDownloader(ydl, params)
    assert hqd.report_warning == ydl.report_warning
    assert hqd.report_error == ydl.report_error
    assert hqd.to_screen == ydl.to_screen


# Generated at 2022-06-12 16:50:59.530674
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MockInfoDict(dict):
        def __init__(self, extra_info, return_true=False):
            dict.__init__(self, extra_info)
            self.return_true = return_true
        def __getitem__(self, key):
            if key == 'playlist_index':
                return 10
            return dict.__getitem__(self, key)
        def __contains__(self, key):
            if key == 'playlist_index':
                return True
            return dict.__contains__(self, key)
        def __setitem__(self, key, value):
            dict.__setitem__(self, key, value)
            if key == 'title' and self.return_true:
                raise KeyError()

# Generated at 2022-06-12 16:51:09.216398
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {
        'continuedl': False,
        'quiet': False,
        'noprogress': False,
        'ratelimit': None,
        'retries': None,
        'nopart': False,
        'test': False
    }
    HttpQuietDownloader(ydl, {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': 1,
        'retries': 2,
        'nopart': True,
        'test': True})

# Generated at 2022-06-12 16:51:22.687775
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpDownloader
    from .utils import prepend_extension

    class IE(InfoExtractor):
        def __init__(self, ydl):
            self.ydl = ydl

        def _real_extract(self, url):
            return {
                'id': 'foo',
                'title': 'title',
                'url': url,
                'ext': 'mp4',
            }

    ie = IE('None')
    info_dict = ie._real_extract('http://example.com/video.mp4')
    dl = HttpQuietDownloader(ie.ydl, {
        'noprogress': True,
    })
    dl.add_info_extractor(ie)
    tmp_filename

# Generated at 2022-06-12 16:51:31.129572
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class YDL:
        params = dict(noprogress=False)

    ydl = YDL()
    dl = HttpQuietDownloader(ydl, {'noprogress': False})
    assert not dl.params['noprogress']
    dl = HttpQuietDownloader(ydl, {'noprogress': True})
    assert dl.params['noprogress']
    dl = HttpQuietDownloader(ydl, {})
    assert dl.params['noprogress']

# Generated at 2022-06-12 16:51:38.206435
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    params = {'noprogress': True, 'format': 'bestvideo'}
    for url in [
        # Youtube video
        'https://youtu.be/BaW_jenozKc',
        # Youtube video with encrypted signature
        'https://youtu.be/Ik-RsDGPI5Y',
        # Soundcloud track
        'https://soundcloud.com/clicksandwhistles/clicks-whistles-tonk',
        # Vimeo video
        'https://vimeo.com/204384333',
        # Streamable video
        'https://streamable.com/bhzp',
    ]:
        ie = get_info_extractor(url)
        fd = ie.get_downloader(params)

# Generated at 2022-06-12 16:51:39.365158
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    return isinstance(FragmentFD(), FileDownloader)

# Generated at 2022-06-12 16:51:49.859385
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class MockYtdl(object):
        def __init__(self):
            self.params = {}

    class MockFD(object):
        def __init__(self):
            self.params = {}
            self.to_screen = lambda *args, **kargs: None

    ydl = MockYtdl()
    fd = MockFD()
    dl = HttpQuietDownloader(ydl, fd.params)
    assert dl.params['continuedl'] is True
    assert dl.params['quiet'] is True
    assert dl.params['noprogress'] is True
    assert dl.fd == fd

# Generated at 2022-06-12 16:51:52.349565
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-12 16:52:36.998299
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .http import HttpFD
    from .rtmp import RtmpFD
    from .hls import HlsFD
    from .dash import DashFD
    from .generic import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(HttpFD, FragmentFD)
    assert issubclass(RtmpFD, FragmentFD)
    assert issubclass(HlsFD, FragmentFD)
    assert issubclass(DashFD, FragmentFD)

# Generated at 2022-06-12 16:52:40.898647
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Pylint bug: https://bitbucket.org/logilab/pylint/issue/491/false-positive-when-protocol-is-an-abc
    # pylint: disable=abstract-class-little-used
    assert issubclass(FragmentFD, FileDownloader)



# Generated at 2022-06-12 16:52:52.091127
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    fd = FragmentFD(
        InfoExtractor(
            {'username': 'test_user', 'password': 'test_password'}
        ),
        {
            'downloader': {
                'fragment_retries': 3,
                'skip_unavailable_fragments': True,
                'keep_fragments': True,
            }
        })
    assert fd.retries == 3
    assert fd.skip_unavailable_fragments
    assert fd.keep_fragments

# Generated at 2022-06-12 16:52:53.823753
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader(None, {'verbose': False})
    assert ydl.params['verbose'] is False

# Generated at 2022-06-12 16:53:05.694145
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors


# Generated at 2022-06-12 16:53:10.867598
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor.common import InfoExtractor
    ie = InfoExtractor({'outtmpl': '%(id)s%(ext)s'})
    # This will raise an exception if constructor fails
    result = HttpQuietDownloader(ie, {'continuedl': True})
    assert(result.continuedl == True)

# Generated at 2022-06-12 16:53:14.050946
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    fd = FragmentFD(YoutubeDL())
    assert fd.params is not None
    assert not fd.params.get('quiet')


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:53:24.098447
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..utils import setup_cli_args
    assert issubclass(HttpQuietDownloader, FileDownloader)
    ydl_opts_dict = {
        'quiet': False,
        'verbose': True,
    }
    ydl_opts = setup_cli_args(ydl_opts_dict)
    dl = HttpQuietDownloader(
        {'params': ydl_opts})
    assert dl.params['quiet']
    assert not dl.params['verbose']
    assert dl.ydl is not None

# Generated at 2022-06-12 16:53:35.203045
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import json
    fd = FragmentFD('config', {
        'param1': 'value1',
        'param2': 'value2',
    })
    assert ('param1' in fd.params and fd.params['param1'] == 'value1')
    assert ('param2' in fd.params and fd.params['param2'] == 'value2')
    fd.to_screen('test message')
    fd.report_warning('test warning')
    fd.report_destination('test destination')
    assert (fd.FD_NAME == 'test')
    assert (fd.temp_name('test_filename') == 'test_filename.test')
    assert (fd.ytdl_filename('test_filename') == 'test_filename.test.ytdl')
    # TODO: test _prep

# Generated at 2022-06-12 16:53:39.877446
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class MyLogger:
        def to_screen(self, message, skip_eol=False):
            pass

    ydl = MyLogger()
    opts = {}
    hqd = HttpQuietDownloader(ydl, opts)
    assert hqd.ydl == ydl
    assert hqd.params == opts

# Generated at 2022-06-12 16:55:04.249635
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    url_info = {
        'url': 'rtmp://test',
    }

    res = FragmentFD(None, url_info)  # pylint: disable=W0612
    assert res is not None

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:55:05.515100
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fd = HttpQuietDownloader(None, {})
    assert fd is not None

# Generated at 2022-06-12 16:55:17.322826
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor

    class FakeInfoExtractor(InfoExtractor):

        def _real_extract(self, url):
            return {
                'id': 'id',
                'title': 'title',
                'ext': 'mp4',
                'thumbnail': 'thumbnail',
                'description': 'description',
                'uploader': 'uploader',
            }

    FD_NAME = 'fake'
    ie = FakeInfoExtractor()
    ie.ie_key = 'Fake'
    ie.ie_key; ie.ie_key; ie.ie_key; ie.ie_key; ie.ie_key
    ie.ie_key = 'Fake'
    ie.ie_key; ie.ie_key; ie.ie_key; ie.ie_key; ie.ie_key


# Generated at 2022-06-12 16:55:21.305213
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader({})
    assert isinstance(ydl, HttpFD)
    assert ydl.ydl is not None
    assert ydl.report_warning is None
    assert ydl._hook_progress is None
    assert ydl.to_screen is None
    assert ydl.params is not None

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:55:28.237647
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractor
    class TestExtractor(gen_extractor()):
        def __init__(self):
            gen_extractor.__init__(
                self,
                'test_FragmentFD',
                gir_url='',
            )
        def _real_extract(self, url):
            return FragmentFD(self, {
                'url': '',
                'playlist': [],
                'playlist_id': '',
                'playlist_title': '',
                'playlist_uploader': '',
                'playlist_index': 0,
            })
    extractor = TestExtractor()
    assert isinstance(extractor, FragmentFD)

# Generated at 2022-06-12 16:55:33.718288
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class DummyDl(object):
        @staticmethod
        def report_warning(msg):
            pass

        @staticmethod
        def trouble(msg, tb=None):
            pass

    dl = HttpQuietDownloader(DummyDl(), {})
    assert dl.ydl is DummyDl



# Generated at 2022-06-12 16:55:43.851985
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl
    import sys
    import os

    class MyLogger(object):
        def debug(self, msg):
            pass

        def warning(self, msg):
            pass

        def error(self, msg):
            pass

    ydl = youtube_dl.YoutubeDL({})

    # Test if no outtmpl
    info = {
        'id': 'test',
        'url': 'http://127.0.0.1:9300/manifest.f4m',
        'title': 'test',
        'ext': 'f4m',
        'format': 'test',
    }
    ydl.params['outtmpl'] = None
    dl = HttpQuietDownloader(ydl, {'continuedl': True})
    dl.report_destination(None)

   

# Generated at 2022-06-12 16:55:49.703604
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        fd = FragmentFD(None)
        assert fd._downloader is None
        assert fd.params == {}
    except:
        raise AssertionError('Failed to initialize FragmentFD with None')

    fd = FragmentFD(None, {'test': True})
    assert fd.params['test']
# Unit test: _download_fragment

# Generated at 2022-06-12 16:55:52.034544
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({})
    HttpQuietDownloader(ydl, {})

# Generated at 2022-06-12 16:56:01.399343
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    info_extractor = get_info_extractor('Generic')()
    info_extractor.suitable = lambda _: True
    info_extractor.add_info_extractor(_gen_ie())
    url_result = info_extractor._real_extract('url')
    filename = 'file name'
    params = {}
    ydl = type('YoutubeDL', (object,), {
        'params': params,
        'to_screen': lambda *_: None,
        'temp_name': lambda _: '',
        'try_rename': lambda _1, _2: True,
        'report_warning': lambda *_: None,
        'report_destination': lambda *_: None,
    })()