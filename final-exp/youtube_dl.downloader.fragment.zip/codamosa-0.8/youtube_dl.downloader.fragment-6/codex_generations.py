

# Generated at 2022-06-12 16:49:23.709823
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from ..utils import get_elapsed_time

    assert issubclass(FragmentFD, FileDownloader)

    # Test initialization of attributes
    fd = FragmentFD(object(), {'params': {}, 'info_dict': {}})
    assert fd.params == {}
    assert fd.info_dict == {}

    # Test calc_eta()
    assert get_elapsed_time(0) == '00:00:00'
    assert get_elapsed_time(10) == '00:00:10'
    assert get_elapsed_time(60) == '00:01:00'
    assert get_elapsed_time(3600) == '01:00:00'
    assert get_elapsed_time(36000) == '10:00:00'
   

# Generated at 2022-06-12 16:49:32.115688
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(
        object(), {}, {'url': 'http://example.com/video.mp4', 'outtmpl': 'video.%(ext)s'})
    assert fd.ydl is not None
    assert fd.params is not None
    assert fd.info is not None
    assert not fd.finished


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:49:37.151077
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    for ie in gen_extractors():
        ie_result = ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
        fd = ie_result['formats'][0]['url']
        assert fd.startswith('http')

# Generated at 2022-06-12 16:49:47.156788
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # No downloader options in constructor
    dl = HttpQuietDownloader(None, {})
    assert dl.params == {'continuedl': True, 'noprogress': True, 'quiet': True}
    assert dl.ydl is None
    # Constructor with downloader options
    dl = HttpQuietDownloader(None, {'test': True})
    assert dl.params == {'test': True, 'continuedl': True, 'noprogress': True, 'quiet': True}
    assert dl.ydl is None

# Generated at 2022-06-12 16:49:52.419879
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=W0612
    class DummyYoutubeDL(object):
        def __init__(self):
            self.params = {}
    a = DummyYoutubeDL()
    b = FragmentFD(a)
    assert b

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:50:05.017827
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import unittest

    import test_utils

    class FragmentFDTest(test_utils.YoutubeDLUnitTest):
        def __init__(self, *args, **kwargs):
            super(FragmentFDTest, self).__init__(*args, **kwargs)
            self.fd = FragmentFD(None, {'quiet': False})

        def test_constructor(self):
            self.fd = FragmentFD(None, {'quiet': True})

        def test_report_skip_fragment(self):
            self.fd.report_skip_fragment(1)

        def test_report_retry_fragment(self):
            self.fd.report_retry_fragment(ValueError('abc'), 1, 2, 3)


# Generated at 2022-06-12 16:50:09.381852
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .downloader import get_suitable_downloader
    from .http import HttpFD
    assert get_suitable_downloader('https://example.com/') == HttpFD
    assert get_suitable_downloader('http://example.com/') == HttpFD
    return 'ok'

# Generated at 2022-06-12 16:50:20.810916
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..utils import match_filter_func
    params = {'quiet': True}
    mf = match_filter_func({'match_filter': lambda info_dict: True})
    ydl = HttpQuietDownloader(
        {
            'mock_dl': True,
            'params': params,
            'match_filter': mf,
        },
        params)

    # test simple download
    res = ydl.download(('http://www.example.com',))
    assert res == (True, {
        'url': 'http://www.example.com',
    })

    # test redirect
    res = ydl.download(('http://goo.gl/N8Wer3',))

# Generated at 2022-06-12 16:50:33.796292
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .opener import OpenerDirector
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import PostProcessor
    from .downloader.rtmp import RTMPFD

    class MockYDL(object):
        def __init__(self):
            self.params = {}
            self.info_extractors = gen_extractors()
            self.postprocessors = []

        def add_info_extractor(self, ie):
            self.info_extractors.append(ie)

    class MockIE(InfoExtractor):
        IE_NAME = 'mock'

    class MockPP(PostProcessor):
        def run(self, *args, **kargs):
            pass

    ydl = MockYDL()
    opener = OpenerDirector()



# Generated at 2022-06-12 16:50:37.085719
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-12 16:51:04.099858
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .http import HttpFD

    # Check that FragmentFD has all methods and attributes of HttpFD
    assert all(hasattr(FragmentFD, a) for a in dir(HttpFD) if not a.startswith('_'))

    # Check that FragmentFD has all methods and attributes of FileDownloader
    from .common import FileDownloader
    assert all(hasattr(FragmentFD, a) for a in dir(FileDownloader) if not a.startswith('_'))

# Generated at 2022-06-12 16:51:16.674594
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .options import opts
    from .extractor import gen_extractors
    info_dict = {
        'id': '8W7_nKvIO1Q',
        'formats': [{'format_id': 'mp4-hd'}],
    }
    ie = gen_extractors(info_dict)['youtube'](info_dict)
    url = None
    for f in ie._get_formats(url):
        if f.get('format_id') == 'mp4-hd':
            url = f['url']
            break
    assert url
    req = sanitized_Request(url)
    req.add_header('Cookie', 'name=value')
    info_dict['http_headers'] = {'Cookie': 'name=value'}

# Generated at 2022-06-12 16:51:29.956562
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    for iecls in gen_extractor_classes():
        ydl = iecls.ydl_cls(params={})
        ie = iecls(ydl, iecls.ie_key())
        fd = ie.get_info_extractor(iecls.ie_key())
        fd.to_screen('Message to screen')
        fd.report_warning('Warning message')
        hqd = HttpQuietDownloader(ydl, {})
        hqd.to_screen('Another message to screen')
        hqd.report_warning('Another warning message')
        assert not (ydl._screen_file and ydl._err_file)
        assert not (hqd._screen_file and hqd._err_file)

# Generated at 2022-06-12 16:51:32.034542
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader(None, {'foo': 'bar'})
    assert dl.params['foo'] == 'bar'

# Generated at 2022-06-12 16:51:34.379766
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {})
    assert fd is not None

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:51:45.691187
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes

    data = {'extractor_key': 'youtube', 'some_key': 'value'}
    # The test requires the existence of https://www.youtube.com/user/ytdl and
    # https://www.youtube.com/watch?v=BaW_jenozKc
    extractors = gen_extractor_classes()
    info_dict = extractors['youtube']()._real_extract(data)
    assert u'fragment_count' in info_dict
    assert info_dict['fragment_count'] == 7

# Generated at 2022-06-12 16:51:47.434610
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass

# Generated at 2022-06-12 16:51:53.562887
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from types import MethodType
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)
    assert hasattr(FragmentFD, 'report_skip_fragment')
    assert hasattr(FragmentFD, 'report_retry_fragment')
    assert isinstance(FragmentFD.report_skip_fragment, MethodType)
    assert isinstance(FragmentFD.report_retry_fragment, MethodType)

# Generated at 2022-06-12 16:52:05.916001
# Unit test for constructor of class FragmentFD
def test_FragmentFD():

    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.to_screen = ydl.to_screen
            self.report_warning = ydl.report_warning
            self.report_destination = ydl.report_destination
            self.params = params
            self.ydl = ydl

    fd = TestFD(None, {
        'keep_fragments': True,
        'noprogress': True
    })

    # Test that we start downloading from zero if there's no ytdl file

# Generated at 2022-06-12 16:52:07.216751
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        HttpQuietDownloader(None, None)
        assert False
    except TypeError:
        assert True

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:52:41.857578
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .youtube import YoutubeFD

    assert isinstance(HttpQuietDownloader.__bases__[0], HttpFD)


# Generated at 2022-06-12 16:52:47.582709
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class DummyYDL:
        params = {}

    assert HttpQuietDownloader is type(FragmentFD(DummyYDL()).dl)


# The following code is for testing purpose only
if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:52:51.690600
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    class IE(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = 'Dummy IE'
        def __init__(self):
            super(IE, self).__init__()
    ydl = object.__new__(InfoExtractor)
    setattr(ydl, 'params', {})
    ydl.add_default_info_extractors()
    ie = IE()
    ydl.add_info_extractor(ie)
    ie.set_downloader(HttpQuietDownloader(ydl))

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:52:56.752055
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    hqd = HttpQuietDownloader(None, {'continuedl': True})
    assert hqd.params.get('continuedl') is True
    hqd = HttpQuietDownloader(None, {})
    assert hqd.params.get('continuedl') is False


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:53:05.042327
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .extractor.generic import GenericIE
    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'(?:http|ftp)://.*'
        _TEST = {
            'url': 'http://example.com',
        }
    ie = TestIE()
    http_downloader = HttpQuietDownloader(ie, {'cachedir': None})
    assert isinstance(http_downloader.ydl, GenericIE)

# Generated at 2022-06-12 16:53:14.250856
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class DummyInfoDict(dict):
        pass

    class DummyYDL(object):
        def __init__(self, params=None):
            self.params = params or {}

        def report_warning(self, msg):
            print('WARNING: %s' % msg)

        def to_screen(self, msg):
            print(msg)

    def error_to_compat_str(err):
        return str(err)

    fd = FragmentFD(DummyYDL(), DummyInfoDict(), None, None, None)
    fd.error_to_compat_str = error_to_compat_str
    fd.report_warning('test_warning')
    fd.report_error('test_error')

# Generated at 2022-06-12 16:53:15.546184
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD()
    assert fd.FD_NAME == 'fragment'

# Generated at 2022-06-12 16:53:27.447124
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    downloader = HttpQuietDownloader({'noprogress': True}, {})

    class FakeYdl:
        def to_screen(self, *args, **kargs):
            sys.stdout.write(str(args) + str(kargs) + '\n')

    downloader.ydl = FakeYdl()

    # Test to_screen with message
    downloader.to_screen('Test message')
    # Test to_screen with message and skip_eol
    downloader.to_screen('Test message', skip_eol=True)
    # Test to_screen without message
    downloader.to_screen()
    # Test to_screen with message and same_line
    downloader.to_screen('Test message', same_line=True)

# Generated at 2022-06-12 16:53:32.712813
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .options import Options
    fd = FragmentFD(Options({
        'skip_unavailable_fragments': True,
        'keep_fragments': True,
        }))

    assert fd.params.get('fragment_retries') is 3
    assert fd.params.get('skip_unavailable_fragments') is True
    assert fd.params.get('keep_fragments') is True

# Generated at 2022-06-12 16:53:33.327149
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass

# Generated at 2022-06-12 16:54:23.458959
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .dash import DASHFD
    from .hls import HLSFD
    from .smoothstreams import SmoothStreamsFD

    assert issubclass(DASHFD, FragmentFD)
    assert issubclass(HLSFD, FragmentFD)
    assert issubclass(SmoothStreamsFD, FragmentFD)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:54:33.029826
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        import __main__
        __main__.params = dict()
        __main__.ydl = dict()
    except ImportError:
        import sys
        sys.modules['__main__'] = sys.modules[__name__]
    finally:
        # Define the HttpQuietDownloader constructor
        globals()['HttpQuietDownloader'] = HttpQuietDownloader

    # Setup
    from ..compat import quote, unittest
    from .common import FileDownloader, SameFileError

    class DummyYDL(object):
        def __init__(self):
            self.params = dict()

        def trouble(self, *args, **kargs):
            raise SameFileError

        def toScreen(self, *args, **kargs):
            pass


# Generated at 2022-06-12 16:54:37.708822
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({})
    ydl.add_default_info_extractors()
    hqd = HttpQuietDownloader(ydl, {'quiet': True})
    assert hqd == hqd.ydl
    assert not hqd.params['quiet']

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:54:40.253828
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:54:43.071847
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    fd = FragmentFD(
        {
            'noprogress': True,
            'logger': sys.stdout,
        },
        {},
        {}
    )

    assert fd

# Generated at 2022-06-12 16:54:50.784289
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    def _get_ydl(params):
        from ..YoutubeDL import YoutubeDL
        return YoutubeDL(params)

    # Create a quiet http downloader
    params = {'noprogress': True, 'logger': True, 'progress_hooks': []}
    ydl = _get_ydl(params)
    quiet_http_dl = HttpQuietDownloader(ydl, params)
    assert quiet_http_dl

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:54:53.138492
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """Just init and test if attributes are created"""
    # pylint: disable=W0612
    dl = HttpQuietDownloader([], {})
    dl.to_screen('test')

# Generated at 2022-06-12 16:54:57.525380
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.add_info_extractor(_FragmentFDTestIE())
    info_dict = {'id': 'test_video_id'}
    ie.extract(info_dict)



# Generated at 2022-06-12 16:54:58.620175
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader


# Generated at 2022-06-12 16:55:06.208926
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    dl = HttpQuietDownloader(
            HttpFD(None, {}, lambda *a, **kwargs: None),
            {
                'quiet': True,
                'noprogress': True,
                'retries': 0,
                'nopart': True,
                'test': False,
            }
        )
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert dl.params['retries'] == 0
    assert dl.params['nopart']
    assert dl.params['test'] == False


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:56:40.841128
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    def my_hook(d):
        if d['status'] == 'finished':
            raise ValueError('Everythig is broken, go away')

    ydl_opts = {
        'quiet': True,
        'noprogress': False,
        'logger': object(),
        'progress_hooks': [my_hook],
    }
    ydl = object()
    dl = HttpQuietDownloader(ydl, ydl_opts)
    assert dl.params['noprogress']



# Generated at 2022-06-12 16:56:49.428721
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    ie = get_info_extractor('GenericIE')()
    try:
        FragmentFD(ie, {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': 1,
            'retries': 0,
            'fragment_retries': 0,
            'nopart': True,
            'test': False,
        })
        assert False, 'Constructor must fail due to fragment_retries less than fragment_retry_timeout'
    except ValueError:
        pass

# Generated at 2022-06-12 16:57:00.693547
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import gen_extractor
    class DummyYDL(object):
        def __init__(self, params):
            self.params = params
            self.cache = None
            self.extractor_desc = {}
            self.extractor_locks = {}
            # NOTE: This is stub value, ideally it should be mocked
            self.default_extractor = gen_extractor(self, [
                'youtube.com',
                'vimeo.com',
            ])

        def extract_info(self, url, download=False):
            info = self.default_extractor.extract(url)
            if download:
                info.update({
                    '_type': 'url',
                    'url': 'http://example.com/video_frag',
                })
            return info


# Generated at 2022-06-12 16:57:07.758251
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import io

    class TestDownloader(FragmentFD):
        def __init__(self, ydl):
            FragmentFD.__init__(self, ydl)
            self.to_screen = io.StringIO()

    from .extractor import YoutubeIE
    import youtube_dl

    ydl = youtube_dl.YoutubeDL(YoutubeIE._build_config())
    dl = TestDownloader(ydl)

    def get_items():
        return [{'fragments': ['1', '2']}]

    dl._prepare_and_start_frag_download({
        'filename': 'abc',
        'total_frags': 2,
    })

    assert dl.params.get('keep_fragments') is False

# Generated at 2022-06-12 16:57:13.395193
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)
    ydl = FakeYDL()
    test_FragmentFD = FragmentFD(ydl)
    assert test_FragmentFD.ydl is ydl
    assert test_FragmentFD.FD_NAME == 'fragment'
    assert test_FragmentFD.params == {}

# Generated at 2022-06-12 16:57:16.939137
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    assert issubclass(
        get_info_extractor('fragment', {}).get_info_extractor(), FragmentFD)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:57:23.561262
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .test import TestFalseFD
    fd = TestFalseFD(
        {
            'frag_index': 0,
            'fragments': [
                {'url': 'url1', 'duration': 2.025},
                {'url': 'url2', 'duration': 2.025},
                {'url': 'url3', 'duration': 2.025},
            ],
            'title': 'Media title',
        },
        {
            'format': '251',
            'noprogress': True,
            'outtmpl': '%(id)s-fragments.mkv',
        },
    )
    assert fd.params['noprogress'] is True
    assert fd.params['outtmpl'] == '%(id)s-fragments.mkv'
    assert fd

# Generated at 2022-06-12 16:57:29.340496
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    import sys
    import tempfile
    from ..utils import FakeYDL

    class TestFragmentFD(unittest.TestCase, FragmentFD):
        def __init__(self, *args, **kwargs):
            self.params = {
                'keep_fragments': True
            }
            FragmentFD.__init__(self, FakeYDL(), self.params)

        def report_warning(self, msg):
            print('WARNING:', msg, file=sys.stderr)

        def report_destination(self, filename):
            print('Dest:', filename)

        def try_rename(self, from_, to):
            print('Renaming %s -> %s' % (from_, to))
            os.rename(from_, to)


# Generated at 2022-06-12 16:57:38.828220
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    sys.path.append('..')
    from yt_dl.extractor import get_info_extractor
    from yt_dl.YoutubeDL import YoutubeDL
    from yt_dl.downloader.http import HttpDownloader as HttpDownloaderBase
    HttpDownloader = HttpQuietDownloader.factory()
    def get_test_ie():
        ie = get_info_extractor('Youtube')
        ie.downloader = HttpDownloader(YoutubeDL({}), {})
        ie.downloader.http_wd = getattr(ie.downloader, 'http_wd', ie.downloader)
        return ie
    test_ie = get_test_ie()
    test_ie.url = 'http://example.com/'

# Generated at 2022-06-12 16:57:45.589740
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

    ydl = object()
    params = {'continuedl': True, 'quiet': True, 'noprogress': True}
    dl = HttpQuietDownloader(ydl, params)

    assert dl.ydl is ydl
    assert dl.params == params
    assert dl._progress_hooks == []