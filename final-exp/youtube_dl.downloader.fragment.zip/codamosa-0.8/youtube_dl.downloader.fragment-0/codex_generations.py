

# Generated at 2022-06-12 16:49:24.987054
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .extractor import (
        gen_extractors,
        get_info_extractor,
        ListExtractor,
    )
    from ..compat import compat_HTTPError

    gen_extractors()
    class TestListExtractor(ListExtractor):
        _WORKING = True
        IE_DESC = 'rtsp://'
        IE_NAME = 'test'


# Generated at 2022-06-12 16:49:27.611735
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-12 16:49:36.862000
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Enforce initialization of aggregate_fn_map , _is_ini_value_true,
    # and _is_ini_value_false
    import youtube_dl.YoutubeDL
    assert FragmentFD.__name__ == 'FragmentFD'
    assert FragmentFD.FD_NAME == 'fragment'
    assert FragmentFD.PROTOCOL == 'fragment'
    assert FragmentFD.MAX_FRAGMENT_RETRIES == 10
    assert hasattr(FragmentFD, 'report_skip_fragment')
    assert hasattr(FragmentFD, 'report_retry_fragment')

# Generated at 2022-06-12 16:49:43.625907
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        FD_NAME = 'testfd'

        def __init__(self, ydl):
            FragmentFD.__init__(self, ydl)

    from youtube_dl.YoutubeDL import YoutubeDL
    dl = TestFD(YoutubeDL({}))
    assert dl.FD_NAME == 'testfd'

# Generated at 2022-06-12 16:49:50.830741
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class FakeYDL:
        params = {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': None,
            'retries': 0,
            'nopart': False,
            'test': False,
        }
    dl = HttpQuietDownloader(FakeYDL(), {})
    assert dl.params == FakeYDL.params

# Generated at 2022-06-12 16:49:58.032388
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD

    ydl = HttpFD({}, {'noprogress': True}, None)

    try:
        ydl.to_screen('A')
    except Exception:
        pass
    else:
        raise Exception('to_screen should not be overridden')

    ydl = HttpQuietDownloader({}, {'noprogress': True}, None)

    try:
        ydl.to_screen('A')
    except Exception:
        raise Exception('to_screen should not be overridden')
    else:
        pass

# Generated at 2022-06-12 16:50:04.090827
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import __main__
    params = {
        'outtmpl': 'test-outtmpl',
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': 23,
        'retries': 3,
        'nopart': True,
        'test': True,
    }
    ydl = __main__.YoutubeDL(params)
    dl = HttpQuietDownloader(ydl, params)
    assert dl.params == params

# Generated at 2022-06-12 16:50:16.667143
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import json
    import tempfile
    from .extractor import get_info_extractor, gen_extractor_classes

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp(prefix='youtube-dl-FragmentFD-')

    # Manually create a dummy, non-working InfoExtractor class
    def _workaround_initialization(self, *args, **kwargs):
        pass
    InfoExtractor = gen_extractor_classes()[0]
    InfoExtractor.__init__ = _workaround_initialization

    # Create a fake FragmentFD instance
    class FakeFD(FragmentFD):
        outtmpl = tmpdir
        params = {}

        @staticmethod
        def format_retries(retries):
            return 'INF'

        def report_error(self, msg):
            raise Exception

# Generated at 2022-06-12 16:50:18.760660
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = lambda: None
    ydl.params = lambda: None
    ydl.params.get = lambda k: None
    res = HttpQuietDownloader(ydl, {})
    assert res

# Generated at 2022-06-12 16:50:23.344542
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import YoutubeDL
    assert isinstance(HttpQuietDownloader.ydl, YoutubeDL)
    # Test that the constructor of FileDownloader was not called...
    assert not hasattr(HttpQuietDownloader, 'params')


# vim: expandtab:sw=4:ts=4

# Generated at 2022-06-12 16:50:49.601240
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        from collections import OrderedDict as OD
    except Exception as e:
        from ordereddict import OrderedDict as OD
    from .extractor import gen_extractors
    from .downloader import gen_extractor_classes
    from .downloader.http import HttpFD
    import six
    import sys

    # Downloaders that are not quiet (i.e. are used in tests)
    undownloaders = {'http', 'smuggle'}
    undownloaders_list = list(undownloaders)

    downloaders = set()
    downloaders_list = []

    extractors = gen_extractors()
    for ie in extractors:
        info_dict = ie.IE_NAME, ie.extractor_key(), ie.SUFFIX, ie._WORKING

# Generated at 2022-06-12 16:50:51.895773
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(None, {'quiet': True})
    HttpQuietDownloader(None, {})  # default value for quiet is True

# Generated at 2022-06-12 16:51:03.517656
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader(
        None,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': 'NONE',
            'retries': 0,
            'nopart': False,
            'test': False,
        }
    )
    assert dl._opts['continuedl']
    assert dl._opts['quiet']
    assert dl._opts['noprogress']
    assert dl._opts['ratelimit'] == 'NONE'
    assert dl._opts['retries'] == 0
    assert not dl._opts['nopart']
    assert not dl._opts['test']

# Generated at 2022-06-12 16:51:10.748245
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .http import HttpFD

    # Test default constructor
    fd = FragmentFD()
    assert fd.name() == 'Fragment'
    assert fd.FD_NAME == 'Fragment'

    # Test inheritance
    assert issubclass(FragmentFD, HttpFD)

    # Test initialization
    fd = FragmentFD(params={})

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:51:24.013526
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .extractor.common import InfoExtractor
    from .compat import compat_etree_fromstring
    from .downloader.external import ExternalFD

    def fail(self, *args, **kwargs):
        """Make sure download() fails"""
        raise Exception('This download was expected to fail.')

    class FailFD(ExternalFD):
        def real_download(self, *args, **kwargs):
            self.to_screen('[download] The download was expected to fail. Exit code: 0')
            return True

    class P(InfoExtractor):
        IE_NAME = 'P'
        IE_DESC = False
        _VALID_URL = r'(?i)https?://.+'

        def _real_extract(self, url):
            return

# Generated at 2022-06-12 16:51:34.865900
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {
        'fragment_retries': 2,
        'skip_unavailable_fragments': False,
        'keep_fragments': False,
    })
    assert fd.params['fragment_retries'] == 2
    assert fd.params['skip_unavailable_fragments'] is False
    assert fd.params['keep_fragments'] is False

    assert fd.FD_NAME == 'generic'

    # Test params types
    fd.params['fragment_retries'] = '2'
    fd.params['skip_unavailable_fragments'] = 'False'
    fd.params['keep_fragments'] = 'False'
    assert fd._prepare_format(None) is None

# Generated at 2022-06-12 16:51:47.016860
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class MyYDL(object):
        def __init__(self):
            self.params = {'ratelimit': 5}

    ydl = MyYDL()
    dl = HttpQuietDownloader(
        ydl,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': ydl.params.get('ratelimit'),
        }
    )
    assert dl.params.get('quiet') is True
    assert dl.params.get('noprogress') is True
    assert dl.params.get('continuedl') is True
    assert dl.params.get('ratelimit') == 5

# Generated at 2022-06-12 16:51:54.876926
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .test import get_test_file_content
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urlparse

    class FakeInfoExtractor(InfoExtractor):
        @staticmethod
        def suitable(url):
            return True

        def extract(self, url):
            ie = self
            id = compat_urlparse.parse_qs(compat_urlparse.urlparse(url).query)['id'][0]
            return {
                '_type': 'url',
                'id': id,
                'url': 'http://example.org/%s.mp4' % id,
                'title': id,
                'ext': 'mp4',
            }

    ydl = YoutubeDL({
        'logger': lambda *x: None,
    })
    ydl.add_

# Generated at 2022-06-12 16:52:06.838736
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD
    from .fragment import (
        FragmentFD, FragmentFDException, _FragmentFDContext,
        _download_fragments, _prepare_and_start_frag_download,
    )

    class FakeInfoDict(object):
        pass

    info_dict = FakeInfoDict()
    info_dict.http_headers = [('Foo', 'Bar')]

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params

    def assertIsInstance(obj, cls):
        if not isinstance(obj, cls):
            raise AssertionError('Not an instance of %r' % cls.__name__)


# Generated at 2022-06-12 16:52:18.718925
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    ydl = sys.modules['__main__'].YoutubeDL()
    ydl.params['nooverwrites'] = True
    fd = FragmentFD(ydl, {'noprogress': True, 'logger': ydl})
    assert fd.params['retries'] == 0
    fd = FragmentFD(ydl, {'noprogress': True, 'logger': ydl, 'fragment_retries': 10})
    assert fd.params['retries'] == 10
    fd = FragmentFD(ydl, {'noprogress': True, 'logger': ydl, 'fragment_retries': '10'})
    assert fd.params['retries'] == 10

# Generated at 2022-06-12 16:53:09.989211
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import io
    import mock
    from .utils import FakeYDL
    from ..extractor import get_info_extractor

    # test normal constructor
    class TestFD(FragmentFD):
        def _prepare_frag_download(self, ctx):
            return

        def _start_frag_download(self, ctx):
            return

    fd = TestFD()
    assert fd.params is not None

    # test other methods
    class TestFD(FragmentFD):
        def __init__(self):
            self.report_warning = mock.Mock()
            self.report_destination = mock.Mock()
            self.report_progress = mock.Mock()
            self.to_screen = mock.Mock()


# Generated at 2022-06-12 16:53:22.252059
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from tests.test_downloader import FakeYDL
    from tests.test_downloader import MockHttpServerRule
    from .http import HttpFD
    from .fragment import FragmentFD

    with MockHttpServerRule() as rule:
        rule.server.add_handler('/manifest.mpd', lambda r: r.protocol_version)
        rule.server.add_handler('/fragment1.ts', lambda r: r.protocol_version)
        rule.server.add_handler('/fragment2.ts', lambda r: r.protocol_version)
        expected_version = rule.server.server_version

        ydl = FakeYDL()
        fd = FragmentFD(ydl, {'fragment_retries': 0})

# Generated at 2022-06-12 16:53:33.369297
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys

    fd = FragmentFD(None)
    assert fd.FD_NAME == 'test'
    assert fd.params == {
        'keep_fragments': False,
        'quiet': False,
    }
    assert fd.ydl is None

    fd = FragmentFD(None, {'opt1': 'val1', 'opt2': 'val2'})
    assert fd.FD_NAME == 'test'
    assert fd.params == {
        'keep_fragments': False,
        'quiet': False,
        'opt1': 'val1',
        'opt2': 'val2',
    }
    assert fd.ydl is None

    ydl = lambda: 0
    fd = FragmentFD(ydl)

# Generated at 2022-06-12 16:53:33.984046
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass

# Generated at 2022-06-12 16:53:37.267217
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader

    fd = FragmentFD({
        'ydl': FileDownloader({}),
        'params': {},
    })

    assert fd.FD_NAME == 'fragment'
    assert len(fd._hooks) == len(FileDownloader._hooks)

# Generated at 2022-06-12 16:53:48.477220
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class FakeInfoDict(object):
        pass

    assert issubclass(FragmentFD, FileDownloader)

    info_dict = FakeInfoDict()
    assert isinstance(FragmentFD(None, info_dict), FileDownloader)

    # default params
    assert FragmentFD._default_params == {
        'keep_fragments': False,
        'fragment_retries': 10,
        'skip_unavailable_fragments': False,
    }

    # available options
    assert FragmentFD._available_options == set((
        'keep_fragments',
        'fragment_retries',
        'skip_unavailable_fragments',
    ))

# Generated at 2022-06-12 16:53:52.137919
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD

    dl = FragmentFD('http://example.com/file.mp4', {})

    assert isinstance(dl, FileDownloader)

    assert isinstance(dl, HttpFD)

# Generated at 2022-06-12 16:53:53.546996
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD()
    assert fd is not None

# Generated at 2022-06-12 16:53:59.255805
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    ydl = gen_extractor({
        'outtmpl': '%(id)s',
    })
    # Check if instance has all required methods
    assert hasattr(HttpQuietDownloader(ydl, {}), 'to_screen')
    assert hasattr(HttpQuietDownloader(ydl, {}), 'download')
    assert hasattr(HttpQuietDownloader(ydl, {}), 'retry')

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:54:12.140977
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func, std_headers

    # Init m_ep
    for ie in gen_extractors():
        if ie.IE_NAME.lower() == 'mms':
            m_ep = ie
    m_ep.suitable(m_ep._request_webpage('http://10.6.3.82:8080/media', None, std_headers))

    fd = FragmentFD(m_ep)
    assert not fd.params.get('test', False)
    assert fd.params['retries'] == 0

    fd = FragmentFD(m_ep, {'test': True})
    assert fd.params.get('test', False)
    assert fd.params['retries'] == 0

    fd = Frag

# Generated at 2022-06-12 16:54:59.534152
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..utils import get_suitable_downloader

    o = get_suitable_downloader({'quiet': True}, 'http://localhost/')
    assert isinstance(o, HttpQuietDownloader)



# Generated at 2022-06-12 16:55:07.313364
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import xml.etree.ElementTree as ET

    class MockYDL(object):
        def __init__(self):
            self.params = {}

    class MockPostProcessor(object):
        def __init__(self):
            self.queue = []

    ydl = MockYDL()
    pp = MockPostProcessor()
    ydl.postprocessor = pp

    ffi = FragmentFD(ydl, {
        'noprogress': True,
        'continuedl': False,
        'ratelimit': None,
        'retries': 3,
        'keepfragments': False,
        'nopart': False,
        'updatetime': True,
        'test': False,
        'outtmpl': '%(id)s.%(ext)s',
    })

    assert f

# Generated at 2022-06-12 16:55:18.437868
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=redefined-variable-type
    fd = FragmentFD(None, {'id': 'test1'})
    import types
    assert isinstance(fd, FragmentFD)
    assert isinstance(fd._prepare_url, types.MethodType)
    assert isinstance(fd._download_fragment, types.MethodType)
    assert isinstance(fd._append_fragment, types.MethodType)
    assert isinstance(fd._prepare_and_start_frag_download, types.MethodType)
    import re
    assert isinstance(fd.FD_NAME, str)
    assert re.match(r'(rtmp|hls|f4f|f4m|m3u8|mpd|ism)', fd.FD_NAME)

# Generated at 2022-06-12 16:55:21.506360
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import common
    # Make sure that __init__() of FragmentFD doesn't crash and
    # provides expected defaults.
    FragmentFD(common.FileDownloader())

# Generated at 2022-06-12 16:55:25.048645
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        import youtube_dl
    except ImportError:
        raise
    ydl = youtube_dl.YoutubeDL()
    return HttpQuietDownloader(ydl, {
        'quiet': True,
        'noprogress': True,
    })

# Generated at 2022-06-12 16:55:27.710293
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)



# Generated at 2022-06-12 16:55:33.717735
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        import __main__
        __main__.params = {}
        __main__.ydl = None
        __main__.to_screen = lambda *args, **kargs: None
        HttpQuietDownloader(__main__, {'quiet': True})
    finally:
        del __main__.params
        del __main__.ydl

# Generated at 2022-06-12 16:55:40.565989
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    fields = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': 10,
        'retries': 3,
        'nopart': True,
        'test': True,
    }
    assert HttpQuietDownloader(None, fields)
    assert HttpQuietDownloader(None, fields) == HttpFD(None, fields)

# Generated at 2022-06-12 16:55:42.206967
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-12 16:55:49.215683
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = {}
    params = {}
    info_dict = {}
    inst = FragmentFD(ydl, params, info_dict)
    assert inst.total_frags == 0
    assert inst.complete_frags == 0
    assert inst.resume_len == 0
    assert inst.fragment_index == 0
    assert inst.fragment_urls is None
    assert inst.FD_NAME == 'generic'

# Generated at 2022-06-12 16:57:30.991535
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import unittest
    import inspect

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.to_screen = sys.stdout.write

    # pylint: disable=protected-access
    class TestFragmentFD(FragmentFD):
        def _get_total_frags(self, info_dict):
            return info_dict.get('total_frags', 0)

        def _prepare_and_start_frag_download(self, ctx):
            self._prepare_frag_download(ctx)
            self._start_frag_download(ctx)


# Generated at 2022-06-12 16:57:41.270791
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def on_progress(state):
        print('state: %s' % state)

    ydl = FakeYDL()
    ydl.params = {}
    fd = FragmentFD(ydl)
    # Run _prepare_frag_download
    fd.add_progress_hook(on_progress)
    fd._prepare_frag_download({
        'filename': 'test.mp4',
        'total_frags': 4,
    })
    # Run _start_frag_download
    start = fd._start_frag_download({
        'filename': 'test.mp4',
        'total_frags': 4,
    })
    time.sleep(1)
    # Run _finish_frag_download

# Generated at 2022-06-12 16:57:49.315077
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """
    Create HttpQuietDownloader instance and verify that it doesn't write to sys.stdout.
    """

    from .common import YoutubeDL
    from .extractor import all_extractors

    ydl = YoutubeDL({'quiet': True})
    hqd = HttpQuietDownloader(ydl, {})
    for ie in all_extractors:
        if ie.IE_NAME not in ['generic', 'googledrive']:
            continue
        ie = ie()
        for url in ie.working_urls():
            hqd.download('/tmp/nonexisting_file', {
                'url': url,
                'ie_key': ie.ie_key(),
            })


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:57:59.742322
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """ youtube-dl unit test for class HttpQuietDownloader """
    # pylint: disable=protected-access
    opts = {
        'quiet': False,
        'verbose': True,
    }
    ydl = object()
    obj = HttpQuietDownloader(ydl, opts)
    assert obj._ydl is ydl
    assert obj._opts == {
        'quiet': True,
        'verbose': False,
        'noprogress': True,
    }
    assert obj._progress_hooks == []


# Generated at 2022-06-12 16:58:10.588532
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from unittest import TestCase
    from .http import HttpFD
    from .common import FileDownloader
    from .extractor import get_info_extractor
    from ..utils import compat_urllib_request, compat_urllib_error
    import sys

    class MockYDL(object):
        def __init__(self):
            self.params = {'verbose': False}

        def to_screen(self, message, skip_eol=False, check_quiet=False):
            sys.stderr.write(message)

        def trouble(self, message, tb=None):
            raise Exception(message)

        def add_info_extractor(self, ie):
            self.ie = ie


# Generated at 2022-06-12 16:58:14.270531
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ctx = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'retries': 2,
        'nopart': True,
        'test': True,
    }
    hqd = HttpQuietDownloader(object, ctx)
    # This will raise an exception if any attribute is not set properly
    hqd.report_destination('filename')

# Generated at 2022-06-12 16:58:15.538859
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)
    # TODO: write real test

# Generated at 2022-06-12 16:58:26.690761
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import warnings
    from .extractor.youtube import YoutubeIE
    from .downloader.common import FileDownloader
    from .utils import DateRange
    from .compat import compat_setenv, compat_urlretrieve

    compat_setenv('YOUTUBE_DL_NO_WARN_ENV', '1')
    class DummyYoutubeDL(object):
        params = {}

        def __init__(self):
            self.to_screen = self._to_screen
            self._ies = [YoutubeIE()]
            self.cache = None
            self.warned = set()

        def _to_screen(self, *args, **ka):
            pass

        def trouble(self, *args, **kargs):
            pass


# Generated at 2022-06-12 16:58:37.752281
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import io
    # Preamble
    def log(text):
        return None
    def report_error(text):
        raise Exception(text)
    class InfoDict(dict):
        def __missing__(self, _):
            return None
    class DummyYDL(object):
        def __init__(self):
            self.params = {}
            self.extractors = []
        def to_screen(self, *args, **kargs):
            log(str(args) + str(kargs))
        def report_error(self, *args, **kargs):
            report_error(str(args) + str(kargs))
        def add_info_extractor(self, *args, **kargs):
            pass
    ydl = DummyYDL()
    ydl.params['retries']

# Generated at 2022-06-12 16:58:45.680922
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class MyYtdl(object):
        params = {}

    class MyDl(HttpQuietDownloader):
        params = {}
    MyDl.add_default_info_extractors()

    MyDl._login()
    MyDl._real_initialize()
    MyDl.add_info_extractor(MyDl.ie_key_map['youtube'])
    MyDl.add_info_extractor(MyDl.ie_key_map['youtube:playlist'])
    MyDl.add_info_extractor(MyDl.ie_key_map['youtube:search'])
    MyDl.add_info_extractor(MyDl.ie_key_map['youtube:user'])