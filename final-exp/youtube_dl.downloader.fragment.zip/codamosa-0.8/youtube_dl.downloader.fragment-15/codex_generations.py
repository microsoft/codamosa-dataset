

# Generated at 2022-06-12 16:49:23.770592
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.hlsnative import HlsFD as HlsNativeFD
    from .downloader.dash import DashFD

    install_opener(build_opener())

    ie = InfoExtractor('GummyMaker')
    ie.add_info_extractor(gen_extractors())
    ie.add_info_extractor(gen_extractors(ie, [r'https?://.*[.](f4m)$']))
    ie.add_info_extractor(gen_extractors(ie, [r'https?://.*[.](m3u8)$']))

# Generated at 2022-06-12 16:49:31.304287
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from ..extractor.common import InfoExtractor
    hd = HttpQuietDownloader({'outtmpl': '-'}, InfoExtractor())
    assert isinstance(hd, HttpFD)
    assert hd.params['noprogress'] is True
    assert hd.params['quiet'] is True


# Generated at 2022-06-12 16:49:37.214789
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {}
    params = {
        'continuedl': True, 'quiet': True, 'noprogress': True,
        'ratelimit': None, 'retries': 0, 'nopart': False, 'test': False,
    }
    dl = HttpQuietDownloader(ydl, params)
    assert dl.ydl == ydl
    assert dl.params == params

# Generated at 2022-06-12 16:49:39.960393
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(dict(), dict())
    assert type(fd) == FragmentFD

# Generated at 2022-06-12 16:49:51.213746
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor.ffmpeg import FFmpegPostProcessor
    for ie in gen_extractors():
        for pp in ie.get_postprocessors():
            if not isinstance(pp, FFmpegPostProcessor):
                continue
            break
        else:
            continue
        dl = HttpQuietDownloader(None, ie._ydl_opts)
        dl.add_info_extractor(ie)
        return dl
    raise ValueError('Could not find a suitable extractor to test with')

if __name__ == '__main__':
    # Run unit test for the module
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 16:50:00.662907
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .downloader import Downloader
    from .extractor import YoutubeIE
    from .extractor.common import InfoExtractor

    class TestIE(InfoExtractor):
        IE_NAME = 'test_ie'
        _VALID_URL = 'https://example.org/'
        _TESTS = [{
            'url': _VALID_URL,
            'info_dict': {
                'id': 'test_id',
                'title': 'test_title'
            }
        }]

        def _real_extract(self, url):
            return {
                'id': self._match_id(url),
                'title': 'test_title'
            }

    class TestFD(FragmentFD):
        FD_NAME = 'test_fd'
        IE_NAME = 'test_ie'


# Generated at 2022-06-12 16:50:08.307983
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import testserver

    url = testserver.server() + '/quiet_download'

    dl = HttpQuietDownloader({}, {'continuedl': True})

    filename = 'dummy.tmp'
    info_dict = {
        'url': url,
        'fragment_index': 1
    }

    dl._prepare_url(info_dict, info_dict['url'])

    dl.download(filename, info_dict)

# Generated at 2022-06-12 16:50:19.840318
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..utils import prepare_filename

    ydl_opts = {
        'quiet': True,
        'noprogress': True,
        'logger': None,
    }
    dl = FileDownloader({
        'params': {},
        'ydl_opts': ydl_opts,
        'progress_hooks': [],
    })
    http_dl = HttpQuietDownloader({}, dl)

    assert 'http_headers' not in http_dl.params
    assert 'outtmpl' in http_dl.params
    assert http_dl.params['outtmpl'] == prepare_filename('-', None)

    assert http_dl.params['quiet'] is True
    assert http_dl.params['noprogress'] is True

# Generated at 2022-06-12 16:50:20.496395
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass

# Generated at 2022-06-12 16:50:31.295812
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=C0111
    # pylint: disable=W0212
    class DummyFD(FragmentFD):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
    dfd = DummyFD(params={
        'filename': 'video.mp4',
        'total_frags': 3,
    })

    assert dfd.params == {
        'filename': 'video.mp4',
        'total_frags': 3,
        'keep_fragments': False,
        'fragment_retries': 10,
        'skip_unavailable_fragments': False,
    }

# Generated at 2022-06-12 16:51:02.213037
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from . import YoutubeDL
    from .extractor import gen_extractors

    def gen_httpfd_up() -> HttpFD:
        ydl = YoutubeDL({
            'quiet': False,
            'simulate': True,
            'format': 'best',
            'outtmpl': '%(id)s',
            'continuedl': False,
            'noprogress': False,
            'logtostderr': False,
            'writeinfojson': False,
            'writesubtitles': False,
            'writeautomaticsub': False,
            'subtitlesformat': 'best',
            'allsubtitles': False,
            'listsubtitles': False,
        })
        gen_extractors(ydl)
        return HttpFD

# Generated at 2022-06-12 16:51:15.042374
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import copy
    import youtube_dl.YoutubeDL
    from .extractor.common import InfoExtractor

    class InfoExtractorMock(InfoExtractor):

        class FragmentsFD(FragmentFD):
            pass

        def __init__(self, *args, **kwargs):
            InfoExtractor.__init__(self, *args, **kwargs)
            self.results = []
            self.args = []

        def _download_webpage(self, *args, **kwargs):
            self.args.append(('_download_webpage', args, kwargs))
            return 'webpage'

        def _real_extract(self, *args, **kwargs):
            self.args.append(('_real_extract', args, kwargs))

# Generated at 2022-06-12 16:51:28.734788
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from ..utils import FakeYDL
    from ..compat import compat_urllib_request

    fd = FragmentFD(FakeYDL(), {
        'quiet': True,
        'fragment_retries': 3,
        'skip_unavailable_fragments': True,
        'keep_fragments': True,
    })

    def report_test_message(*args, **_):
        assert args == ('Test message',)
        sys.stderr.write('Test message\n')

    def report_error_test_message(*args, **_):
        assert args == ('Error test message',)
        sys.stderr.write('Error test message\n')


# Generated at 2022-06-12 16:51:36.680793
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .tests import FakeYDL

    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params

    ydl = FakeYDL()
    ydl.params = {
        'retries': 10,
        'fragment_retries': 2,
        'keep_fragments': True,
        'skip_unavailable_fragments': True,
        'noprogress': True,
    }
    fd = TestFD(ydl, ydl.params)
    assert fd.params.get('retries') == 10
    assert fd.params.get('fragment_retries') == 2
    assert fd.params.get('keep_fragments') is True

# Generated at 2022-06-12 16:51:39.955807
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    hq = HttpQuietDownloader({}, {})
    # this is an ugly hack to check if the output is redirected
    assert hq.to_screen('') is None

# Generated at 2022-06-12 16:51:52.212692
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from ..compat import compat_urllib_request
    from ..utils import unescapeHTML

    if sys.version_info[:2] < (2, 7):
        raise TypeError('Test requires Python 2.7 or higher.')

    class MockYoutubeDl(object):
        def __init__(self, expected_url, result_filename, result_status, result_headers):
            self.expected_url = expected_url
            self.result_filename = result_filename
            self.result_status = result_status
            self.result_headers = result_headers
            self.params = {}

        def trouble(self, *args, **kwargs):
            pass

        def to_screen(self, *args, **kargs):
            pass


# Generated at 2022-06-12 16:52:03.953881
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import get_info_extractor

    def _fake_download(self, filename, info_dict):
        return True

    def _fake_to_screen(self, *args):
        pass

    extractor = get_info_extractor('youtube')
    extractor._download = _fake_download
    extractor.to_screen = _fake_to_screen
    if not hasattr(extractor, '_downloader'):
        extractor._downloader = HttpQuietDownloader(extractor._ydl, extractor._ydl_opts)

    # test if HttpQuietDownloader object is created exactly
    assert(isinstance(extractor._downloader, HttpQuietDownloader))

# Generated at 2022-06-12 16:52:13.909631
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import tempfile
    d = FragmentFD(None, {
        'nooverwrites': True,
        'continuedl': False,
        'quiet': True,
        'noprogress': True,
        'retries': 10,
        'ratelimit': 200000,
    })
    assert d.params['ratelimit'] == 200000
    d.report_warning('this is a test for warnings')
    d.report_error('this is a test for errors')
    try:
        d.to_screen('this is a test for to_screen')
    except UnboundLocalError:
        pass
    else:
        print('Expected UnboundLocalError')
        sys.exit(1)
    fd, fname = tempfile.mkstemp(prefix='ytdltest-')
   

# Generated at 2022-06-12 16:52:19.472897
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    'Make sure the constructor of HttpQuietDownloader works'
    ydl = object()
    params = object()
    dl = HttpQuietDownloader(ydl, params)
    assert dl._ydl is ydl
    assert dl._params is params

# Generated at 2022-06-12 16:52:21.146248
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = FileDownloader({})
    assert isinstance(HttpQuietDownloader(ydl, {}), HttpFD)

# Generated at 2022-06-12 16:53:09.861394
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from .fragment import FragmentFD

    ydl = {
        'params': {
            'usenetrc': False,
            'username': None,
            'password': None,
            'twofactor': None,
            'videopassword': None,
        },
        'progress_hooks': [],
    }

    def my_hook(d):
        """A hook function that prints its argument."""
        print(d)

    ydl['progress_hooks'].append(my_hook)

    match_filter = match_filter_func(
        ydl, ydl['params'].get('match_filter'), ydl['params'].get('limit_filter'))


# Generated at 2022-06-12 16:53:14.449681
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import types
    from .http import HttpFD
    qdl = HttpQuietDownloader(None, {'quiet': True})
    assert isinstance(qdl, HttpFD)
    assert isinstance(qdl.to_screen, types.MethodType)


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:53:27.145907
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """Constructor of class HttpQuietDownloader"""
    import sys
    obj = HttpQuietDownloader(
        'my_ydl',
        {
            'continuedl': 'my_continuedl',
            'noprogress': 'my_noprogress',
            'ratelimit': 'my_ratelimit',
            'retries': 'my_retries',
            'nopart': 'my_nopart',
            'test': 'my_test',
        }
    )
    assert obj.ydl == 'my_ydl'

# Generated at 2022-06-12 16:53:31.545963
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import unittest

    class Test(unittest.TestCase):
        def test_Downloader(self):
            d = HttpQuietDownloader({}, {})
            self.assertEqual(d.params['quiet'], True)
            self.assertEqual(d.params['noprogress'], True)
    unittest.main()

# Generated at 2022-06-12 16:53:34.807302
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader(None, None).preferredencoding == 'utf-8'
    assert HttpQuietDownloader(None, {'prefer_insecure': True}).preferredencoding == 'utf-8'



# Generated at 2022-06-12 16:53:35.679325
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # TODO
    pass


# Generated at 2022-06-12 16:53:48.295463
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {
        'noprogress': True,
        'ratelimit': '10k',
        'retries': 42,
        'nopart': True,
        'test': True,
        'expected_frags': 5,
    })
    assert fd.ydl.params['noprogress'] is True
    assert fd.ydl.params['nopart'] is True
    assert fd.ydl.params['test'] is True
    assert fd.params['noprogress'] is True
    assert fd.params['nopart'] is True
    assert fd.params['test'] is True
    assert fd.params['expected_frags'] == 5

    dl = fd.ydl
    assert dl.params['noprogress'] is True

# Generated at 2022-06-12 16:53:49.616289
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert isinstance(HttpQuietDownloader(None, None), HttpFD)

# Generated at 2022-06-12 16:53:58.741441
# Unit test for constructor of class FragmentFD
def test_FragmentFD():

    def run_test(test_num, params, expected_result):
        test_name = '%s_%d' % (test_func.func_name, test_num)
        result = FragmentFD(None, params)
        assert result == expected_result, '%s failed' % test_name

    def prepare_params(
            fragment_retries=None, skip_unavailable_fragments=None, keep_fragments=None):
        return {
            'fragment_retries': fragment_retries,
            'skip_unavailable_fragments': skip_unavailable_fragments,
            'keep_fragments': keep_fragments,
        }


# Generated at 2022-06-12 16:54:11.501105
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    sys.modules['__main__'].params = {
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False
    }
    sys.modules['__main__'].params['outtmpl'] = '-a'
    sys.modules['__main__'].temp_name = lambda s: '-'
    sys.modules['__main__'].report_warning = lambda s: None
    sys.modules['__main__'].to_screen = lambda *args, **kargs: None
    sys.modules['__main__'].report_destination = lambda s: None
    sys.modules['__main__'].try_rename = lambda s, t: None

# Generated at 2022-06-12 16:55:40.695220
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor.common import InfoExtractor

    def _set_ytplayer_config(ie):
        ie._set_config({
            '_type': 'playlist',
            'ie_key': 'YoutubePlaylist',
        })

    ie = InfoExtractor()
    ie.set_downloader(FragmentFD(lambda *args, **kargs: ie))
    ie.add_default_info_extractors()
    ie.http_header('User-Agent', 'DummyUserAgent')
    ie.set_info_extractors([(
        re.compile(r'https?://(?:example\.)?com/'),
        lambda *args, **kargs: _set_ytplayer_config(ie))])
    sys.modules['youtube_dl.extractor.youtube'] = ie
   

# Generated at 2022-06-12 16:55:48.020214
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from .common import FileDownloader
    from .http import HttpFD

    class DummyFD(FragmentFD):
        def __init__(self, ydl, params):
            super(DummyFD, self).__init__(ydl, params)
            self.to_screen('subclass __init__ is called')

        def real_download(self, filename, info_dict):
            self.to_screen('subclass real_download is called')
            return super(DummyFD, self).real_download(filename, info_dict)

        def _start_frag_download(self, ctx):
            self.to_screen('subclass _start_frag_download is called')


# Generated at 2022-06-12 16:55:51.300717
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..downloader.common import FileDownloader
    assert issubclass(HttpQuietDownloader, FileDownloader)
    downloader = HttpQuietDownloader(None, {'quiet': True})
    assert isinstance(downloader, FileDownloader)

# Generated at 2022-06-12 16:56:00.593575
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = FakeYoutubeDl()
    dl = HttpQuietDownloader(
        ydl, {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'retries': 0,
            'nopart': False,
            'test': False,
        })

    assert dl.ydl is ydl
    assert dl.report_hooks == []
    assert dl.params['continuedl']
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert dl.params['retries'] == 0
    assert not dl.params['nopart']
    assert not dl.params['test']


# Fake class that represents an instance of YoutubeDL

# Generated at 2022-06-12 16:56:11.337751
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor

    class TestInfoExtractor(object):
        IE_NAME = 'test_ie'

        def __init__(self, ie_urls):
            self._ies = [gen_extractor(ie) for ie in ie_urls]

        def suitable(self, url):
            return any(ie.suitable(url) for ie in self._ies)

        def __getattr__(self, aname):
            if aname in ('_WORKING', '_downloader'):
                raise AttributeError(aname)
            return getattr(self._ies[0], aname)

    class TestYDL(object):
        params = {}
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-12 16:56:20.343710
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    extractors = gen_extractors()
    for ie_name in extractors.keys():
        if 'test' in extractors[ie_name].ie_keywords:
            continue
        extractor = extractors[ie_name]
        urls = [
            'http://example.com',
            'http://example.com/v/123',
            'http://example.com/a/b/c/d',
        ]
        for url in urls:
            try:
                result = extractor.suitable(url)
            except Exception:
                raise
            if result:
                print('Checking %s from %s' % (url, ie_name))
                ie = extractor(FragmentFD(), {}, {'noprogress': True})

# Generated at 2022-06-12 16:56:25.325154
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from . import YoutubeDL

    class MyYoutubeDL(YoutubeDL):
        def process_info(self, info_dict):
            # Should not print anything
            return info_dict

    ydl = MyYoutubeDL()
    dl = HttpQuietDownloader(ydl, {})
    assert isinstance(dl, HttpQuietDownloader)

# Generated at 2022-06-12 16:56:31.378487
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)
    x = FragmentFD('dummyydl', {})
    assert not hasattr(x, '_TEST_ATTR')
    x._TEST_ATTR = True
    assert x._TEST_ATTR
    del x._TEST_ATTR

# Generated at 2022-06-12 16:56:33.076035
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    def nop(*args, **kargs):
        pass
    assert HttpQuietDownloader(nop, {}).to_screen('') is None

# Generated at 2022-06-12 16:56:35.385490
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({'quiet': True})
    dl = HttpQuietDownloader(ydl, {})
    return dl.ydl.params['quiet']