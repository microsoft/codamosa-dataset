

# Generated at 2022-06-12 16:49:17.711935
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import unittest

    if not sys.platform.startswith('linux'):
        return

    from ..utils import format_bytes
    from .external import ExternalFD

    class FakeInfoDict(object):
        def __init__(self):
            self.title = 'title'

    class TestFragmentFD(unittest.TestCase):
        def setUp(self):
            self.ydl = None


# Generated at 2022-06-12 16:49:31.793658
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """this function tests whether the HttpQuietDownloader class works as expected"""
    from ..compat import StringIO
    options = {
        'noprogress': True,
        'quiet': True,
        'format': 'bestaudio/best'
    }

    try:
        from ..extractor import gen_extractors
    except ImportError:
        return False

    ydl = gen_extractors()[0]()
    ydl.params = options
    ydl.add_default_info_extractors()

    #since HttpQuietDownloader(...) as an input, uses the constructor of the FileDownloader class,
    #we test whether the FileDownloader constructor works as expected
    fd = HttpQuietDownloader(ydl, options)
    assert fd.params == options

# Generated at 2022-06-12 16:49:44.344877
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    if sys.version_info < (3, 0):
        import codecs
        sys.stdout = codecs.getwriter('utf-8')(sys.stdout)


# Generated at 2022-06-12 16:49:46.855268
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {})
    assert fd.FD_NAME == 'Fragment downloader'

# Generated at 2022-06-12 16:49:49.965710
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = object()
    params = {}
    fd = FragmentFD(ydl, params)
    assert fd.ydl is ydl
    assert fd.params == params

# Generated at 2022-06-12 16:49:59.737868
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    for ie in gen_extractors():
        ie_result = ie.suitable(ie.ie_key())
        if ie_result is not True:
            continue
        ydl = type('DummyYDL', (object,), {'params': {'quiet': True, 'forceurl': True, 'forcetitle': True}})()
        ydl.add_default_info_extractors()
        ie = ie.__class__(ydl)
        # Just use the first info dict
        try:
            info_dict = next(ie.extract(ie.ie_key()))
        except StopIteration:
            continue
        if not info_dict.get('url'):
            continue
        if info_dict.get('files'):
            continue
        f

# Generated at 2022-06-12 16:50:00.240435
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass

# Generated at 2022-06-12 16:50:03.800716
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.downloader.http
    assert issubclass(HttpQuietDownloader, youtube_dl.downloader.http.HttpFD)

# Generated at 2022-06-12 16:50:06.157711
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    assert FragmentFD(ydl)

# Generated at 2022-06-12 16:50:15.070907
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import YoutubeIE

    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    ydl = YoutubeIE()
    ydl.add_info_extractor(YoutubeIE())

    fd = FragmentFD(ydl, {'continue_dl': True, 'quiet': True})
    fd.add_info_extractor(YoutubeIE())
    fd.download([url])

    assert not os.path.exists(encodeFilename('.%s.ytdl' % url))

# Generated at 2022-06-12 16:50:43.904686
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import tempfile
    import shutil

    # Create new directory
    tmpdir = tempfile.mkdtemp()
    # Change working directory
    os.chdir(tmpdir)

# Generated at 2022-06-12 16:50:46.540564
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import get_info_extractor
    ydl = get_info_extractor('generic')
    HttpQuietDownloader(ydl, {'quiet': True, 'noprogress': True})


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:50:59.425179
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import tempfile
    import shutil
    import youtube_dl
    import youtube_dl.downloader.fragment
    import youtube_dl.downloader.http
    class TestYDL(youtube_dl.YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(TestYDL, self).__init__(*args, **kwargs)
            self.downloader = youtube_dl.downloader.fragment.FragmentFD(self)
            self.downloader.ydl = self

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-12 16:51:08.422753
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    content = '<title>Downloading video info webpage</title>'
    upload_date = '20120101'
    url = 'http://www.youtube.com/get_video_info?video_id=videoid'
    d = HttpQuietDownloader(
        None, {'test': True, 'quiet': True, 'test_result': content})
    t = d.test(url, {})
    assert t == {
        'filename': 'youtube-videoid.info.json',
        'info_dict': {
            'id': 'videoid',
            'ext': 'info',
            'protocol': 'http',
            'upload_date': upload_date,
            'title': 'Downloading video info webpage'
        }
    }

# Generated at 2022-06-12 16:51:16.394312
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .common import FileDownloader
    dl = HttpQuietDownloader(None, {})
    assert dl.ydl is None
    assert dl.params == {}
    assert dl.params.get('logger') is None
    assert dl.url == ''
    assert dl.info_dict == {}
    assert isinstance(dl, HttpFD)
    assert isinstance(dl, FileDownloader)

# Generated at 2022-06-12 16:51:26.717009
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class _YoutubeDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
            }
        def to_screen(self, *args, **kargs):
            pass
    _YoutubeDL().to_screen('[download] blah-blah')

    ydl = _YoutubeDL()
    hqdl = HttpQuietDownloader(ydl, {'quiet': True})
    assert hqdl.ydl is ydl
    assert hqdl.params == {'continuedl': True, 'noprogress': True, 'quiet': True}

# Generated at 2022-06-12 16:51:32.929144
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """
    Check if HttpQuietDownloader initializes correctly.
    """
    from .http import HttpFD
    from ..YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    fd = HttpQuietDownloader(ydl, {'quiet': False})

    assert fd.params['quiet'] == False

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:51:34.033678
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert isinstance(FragmentFD(None), FragmentFD)


# Generated at 2022-06-12 16:51:39.251703
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ctx = {'params': {}}
    fd = FragmentFD({}, ctx)
    assert fd.params == {}
    assert fd.ydl is None
    assert fd.FD_NAME == 'fragment'



# Generated at 2022-06-12 16:51:51.706472
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # We have to use YoutubeDL class since it is a base for
    # YouTubeDl. Also we cannot call constructor of FragmentFD
    # directly because it is abstract. Moreover we cannot use
    # unit test method test_FileDownloader since it requires
    # test_download method which requires the same YoutubeDL class
    # as the constructor does. So the only way is to create another
    # FileDownloader class and test its constructor.
    class FragmentFDTest(FragmentFD):
        # Needed by constructor of FragmentFD
        FD_NAME = 'fragment'
        # Needed by constructor of FileDownloader
        params = {
            'noprogress': True,
            'continuedl': True,
        }

        @staticmethod
        def calc_eta(start, now, total, completed):
            return 0


# Generated at 2022-06-12 16:52:34.054217
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Test constructor
    from .http import HttpQuietDownloader
    from ..downloader import BaseDownloader
    from ..utils import FakeYDL
    assert issubclass(HttpQuietDownloader, BaseDownloader)
    assert HttpQuietDownloader.ydl is BaseDownloader.ydl
    hy = HttpQuietDownloader(FakeYDL())
    assert hy.ydl is FakeYDL()



# Generated at 2022-06-12 16:52:37.212808
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    return HttpQuietDownloader(ydl, {'quiet': True})

# Generated at 2022-06-12 16:52:44.703863
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ytdl_core.YoutubeDL import YoutubeDL
    from ytdl_core.extractor.common import InfoExtractor
    import sys
    logger = sys.stdout

    params = {
        'nooverwrites': True,
        'forcetitle': True,
        'quiet': True,
        'continuedl': True,
        'noprogress': True,
        'retries': 2,
        'nopart': True,
        'ratelimit': 222222,
        'test': True,
    }

    ydl = YoutubeDL(params)
    oIE = InfoExtractor(ydl)

    qdl = HttpQuietDownloader(ydl, params, oIE)
    assert oIE != qdl.ie
    assert qdl.params == params
    assert qdl == q

# Generated at 2022-06-12 16:52:56.714966
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FakeYDL
    from .http import HttpFD
    from .dash import DashFD

    class TestFragmentFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFragmentFD, self).__init__(ydl, params)
            self.downloaded_bytes = 0

        def _start_frag_download(self, ctx):
            self.downloaded_bytes = ctx['complete_frags_downloaded_bytes']
            return super(TestFragmentFD, self)._start_frag_download(ctx)

        def static_get_frag_count(self):
            return 4

        def static_test_fragment_urls(self):
            frag_count = self.static_get_frag_count()

# Generated at 2022-06-12 16:53:08.966709
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys

    def on_progress(state):
        self.downloaded = state.get('downloaded_bytes')
        sys.stderr.write('downloaded %d\n' % self.downloaded)

    ffd = FragmentFD({})
    ffd.add_progress_hook(on_progress)

    # ftmp will be closed by destructor of class FragmentFD
    ftmp = ffd.temp_name('video.mp4')

    ctx = {
        'dl': None,
        'tmpfilename': ftmp,
        'fragment_index': 0,
        'complete_frags_downloaded_bytes': 0,
        'total_frags': 3,
        'filename': 'video.mp4',
        'dest_stream': open(ftmp, 'wb'),
    }


# Generated at 2022-06-12 16:53:16.683110
# Unit test for constructor of class FragmentFD
def test_FragmentFD():  # pylint: disable=too-many-locals
    from . import YoutubeDL # pylint: disable=redefined-outer-name
    dummy_ydl = YoutubeDL({})
    dummy_ydl.add_info_extractor(object())

    tmpfilename = dummy_ydl.prepare_filename('video')
    tmpfilename = dummy_ydl.temp_name(tmpfilename)

    # Constructor
    ffd = FragmentFD(dummy_ydl, {
        'fragment_retries': 'inf'
    })

    # Prepare
    ctx = {
        'filename': 'video',
        'total_frags': 1001,
        'fragment_index': 0,
        'complete_frags_downloaded_bytes': 0,
    }

    ffd._prepare_frag

# Generated at 2022-06-12 16:53:28.806094
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import get_info_extractor

    class MyInfoExtractor(get_info_extractor('GenericIE', {})):
        IE_DESC = 'Test IE'
        IE_NAME = 'test'
        _VALID_URL = r'https?://(?:www\.)?test\.com/'

# Generated at 2022-06-12 16:53:36.017065
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.http_QD = HttpQuietDownloader(ie, {'noprogress': True, 'quiet': True})
    ie.http_QD.toScreen = False
    ie.http_QD.params = {'outtmpl': '%(id)s.%(ext)s'}
    ie.http_QD.download('foo', {'id': 'bar', 'url': 'http://localhost:9/'})
    assert 'bar.mp3' in os.listdir('.')
    os.remove('bar.mp3')

# Generated at 2022-06-12 16:53:41.692631
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..utils import FakeYDL

    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {})
    assert dl.ydl is ydl
    assert dl.params == {}


if __name__ == '__main__':
    import sys

    test_HttpQuietDownloader()
    sys.exit(0)

# Generated at 2022-06-12 16:53:53.540706
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    test_cases = [(
        'https://upload.wikimedia.org/wikipedia/commons/7/77/Test.jpg',
        500 * 1024,
    ), (
        'https://upload.wikimedia.org/wikipedia/commons/7/77/Test.jpg',
        0,
    )]
    for url, expected_size in test_cases:
        class TestFD(FragmentFD):
            def report_retry_fragment(self_, *args, **kwargs):
                pass
            def report_skip_fragment(self_, *args, **kwargs):
                pass
        ydl = {'params': {}}
        test_fields = ['params', 'to_screen', 'report_warning', 'report_destination']

# Generated at 2022-06-12 16:55:26.025287
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class FakeInfo(dict):
        def __init__(self):
            super(FakeInfo, self).__init__(
                {
                    'url': 'http://www.example.com',
                    'http_headers': {
                        'Range': 'bytes=0-4',
                    },
                }
            )


    class FakeYDL(object):
        def __init__(self):
            self.params = {}


    class FakeFD(FragmentFD):
        def __init__(self):
            super(FakeFD, self).__init__(FakeYDL())

        def _prepare_and_start_frag_download(self, ctx):
            pass


    fd = FakeFD()
    # Test preparation of request with http_headers
    info = FakeInfo()

# Generated at 2022-06-12 16:55:34.521631
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpQuietDownloader, HttpFD
    arg1 = 'a'
    arg2 = {'b': 'c'}
    dl = HttpQuietDownloader(arg1, arg2)
    assert dl.ydl is arg1
    assert dl.params is arg2
    assert isinstance(dl, HttpFD)
    assert dl.to_screen == HttpFD._print_debug_info  # pylint: disable=protected-access



# Generated at 2022-06-12 16:55:36.755829
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpDownloader
    assert isinstance(HttpQuietDownloader(None, None), HttpDownloader)

# Generated at 2022-06-12 16:55:45.579344
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import youtube
    from ..utils import get_cachedir

    class MockYoutubeDL(object):
        params = {}

        def __init__(self, params):
            self.params = params

        def to_screen(self, *args, **kwargs):
            pass

        def report_warning(self, *args, **kwargs):
            pass

    ydl = MockYoutubeDL({})
    ydl2 = MockYoutubeDL({'noprogress': True})
    HttpQuietDownloader(ydl, {}).to_screen('foo')
    HttpQuietDownloader(ydl2, {}).to_screen('bar')

    # Test http proxies
    class MockInfoDict(dict):
        pass
    info = MockInfoDict()

# Generated at 2022-06-12 16:55:55.721516
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .downloader.http import HttpQuietDownloader

    from .utils import prepare_filename
    from .compat import compat_urllib_parse_urlencode


# Generated at 2022-06-12 16:56:06.420861
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """
    Unit-test for constructor of class HttpQuietDownloader.
    See http://docs.python.org/library/unittest.html
    """
    import unittest
    import sys
    import os

    class TestHttpQuietDownloader(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            sys.path.insert(0, os.path.abspath('..'))

        def setUp(self):
            # Setup
            self.ydl = None

        def tearDown(self):
            # Cleanup
            pass

        def test_new_HttpQuietDownloader(self):
            # Test new HttpQuietDownloader(self.ydl)
            from .http import HttpFD
            from youtube_dl.YoutubeDL import YoutubeDL

            self

# Generated at 2022-06-12 16:56:11.566542
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    ydl = gen_extractors()[0].ydl
    opts = dict(continuedl=True, noprogress=True, ratelimit=None, retries=0, nopart=False, test=False)
    assert isinstance(HttpQuietDownloader(ydl, opts), HttpFD)

# Generated at 2022-06-12 16:56:17.770083
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params, info_dict = {}, {
        'id': 'test_id',
        'title': 'test_title',
        'ext': 'test_ext',
        'format': 'test_format',
        'url': 'test_url',
    }
    ydl = {
        'params': params,
        'info_dict': info_dict,
        'to_screen': lambda *args: None
    }
    HttpQuietDownloader(ydl, {})

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:56:20.498197
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        def real_download(self, *args, **kargs):
            pass

    fd = TestFD(None, {'retries': 8})
    assert fd.params['fragment_retries'] == 8

# Generated at 2022-06-12 16:56:26.695971
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=W0212
    import sys
    sys.modules['__main__'].params = {'quiet': True}
    try:
        fragment_fd = FragmentFD({})
        assert fragment_fd.params == {'quiet': 'quiet', 'verbose': False, 'dump_intermediate_pages': False, 'skip_download': False}
    finally:
        del sys.modules['__main__'].params