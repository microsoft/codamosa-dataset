

# Generated at 2022-06-12 16:49:17.366168
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_urllib_request
    from .http import HttpFD

    class fake_ydl(object):
        def __init__(self):
            self.params = {
                'noprogress': False,
            }
        def to_screen(self, *args, **kargs):
            pass
        def trouble(self, *args, **kargs):
            pass

    qdl = HttpQuietDownloader(fake_ydl(), {})
    assert isinstance(qdl.ydl, fake_ydl)
    assert qdl.params == {}
    assert qdl.report_destination == HttpFD.report_destination
    assert isinstance(qdl.urlopen, compat_urllib_request.urlopen)

# Generated at 2022-06-12 16:49:25.995823
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import youtube_dl

    ydl = youtube_dl.YoutubeDL()
    dl = FragmentFD(ydl, {'test': True, 'quiet': True})

    sys.stdout = dl.stdout = open(os.devnull, 'w')
    sys.stderr = dl.stderr = open(os.devnull, 'w')

    dl.report_warning('warning')
    dl.report_error('error')

# Generated at 2022-06-12 16:49:38.602928
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import YoutubeDL

    downloader = YoutubeDL({
        'noplaylist': True,
        'skip_download': True,
    })

    # 1. Basic test
    fd = FragmentFD(downloader)

    # 2. Check methods
    for _, method in [
        ('_prepare_frag_download', 1),
        ('_start_frag_download', 1),
        ('_download_fragment', 1),
        ('_append_fragment', 1),
        ('_finish_frag_download', 1),
    ]:
        assert hasattr(fd, method), "Missing method %s" % method

    # 3. Check attributes
    assert hasattr(fd, 'FD_NAME'), "Missing attribute FD_NAME"

    # 4. Check constructor input

# Generated at 2022-06-12 16:49:45.584366
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {}
    try:
        HttpQuietDownloader(ydl, None)
    except Exception as err:
        assert False, 'unexpected error %r' % err
    assert HttpQuietDownloader.ydl == ydl, 'wrong ydl'
    assert HttpQuietDownloader.params == {}, 'wrong params'


# Generated at 2022-06-12 16:49:49.637464
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():

    # The class is not intended to be used directly, so we just check that
    # it can be constructed without error
    HttpQuietDownloader(
        {
            'ydl': None,
            'params': {},
        }, {}
    )

# Generated at 2022-06-12 16:49:59.485330
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class DummyYoutubeDL():
        def __init__(self):
            self.params = {
                'continuedl': True,
                'quiet': True,
                'noprogress': True,
                'ratelimit': None,
                'retries': 0,
                'nopart': False,
                'test': False,
            }

    ydl = DummyYoutubeDL()

# Generated at 2022-06-12 16:50:05.863026
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def pr(**kwargs):
        print(kwargs)
    params = {
        'ratelimit': '1k',
        'retries': 5,
        'test': False,
    }
    fd = FragmentFD('testid', 'testname', pr, params)
    assert fd.params == {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'nopart': False,
        'ratelimit': 1024,
        'retries': 5,
        'test': False,
    }

# Generated at 2022-06-12 16:50:08.809341
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = FileDownloader({})
    fd = FragmentFD(ydl)

    assert_equal(fd.params['noprogress'], False)

# Generated at 2022-06-12 16:50:11.238034
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # This test only verifies that HttpQuietDownloader constructor doesn't break
    HttpQuietDownloader(None, {})

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:50:18.088593
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .http import HttpFD
    from .generic import Downloader

    class MyFD(FragmentFD):
        pass

    myfd = MyFD('youtube-dl', {})
    assert isinstance(myfd, FileDownloader)
    assert isinstance(myfd, Downloader)
    assert isinstance(myfd, HttpFD)

# Generated at 2022-06-12 16:50:40.036755
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    ydl = InfoExtractor()
    quiet_dl = HttpQuietDownloader(ydl, {'continuedl': True})
    assert quiet_dl

# Generated at 2022-06-12 16:50:40.995374
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass # Constructor does not need to be tested

# Generated at 2022-06-12 16:50:43.291536
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)
    assert FragmentFD.__doc__


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:50:44.612509
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-12 16:50:46.059229
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader(None, None)


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:50:48.002079
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {})
    assert fd.FD_NAME == 'fragment'

# Generated at 2022-06-12 16:51:00.740624
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .options import Options
    from .utils import DateRange


# Generated at 2022-06-12 16:51:10.104319
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HEADRequest
    from .fragment import FragmentFD
    from .dash import DASHFD
    from ..extractor.generic import YoutubeIE
    from ..utils import compat_urllib_parse
    # Create an instance of DASHFD
    fd = DASHFD('http://some-url/video.mpd', {})
    assert isinstance(fd, FragmentFD)
    assert hasattr(fd, '_prepare_frag_download')
    assert hasattr(fd, '_download_fragment')

    # Create an instance of HttpQuietDownloader
    req = HEADRequest('http://some-url/video.mpd')

# Generated at 2022-06-12 16:51:20.165607
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def value_err(**kwargs):
        try:
            FragmentFD(None, None, **kwargs)
        except ValueError:
            return True
        return False

    assert value_err(test=True, retries=2)
    assert value_err(test=True, nopart=True)
    assert not value_err(test=True, retries=None)
    assert not value_err(test=True, nopart=False)
    assert not value_err(test=True, retries=0)
    assert not value_err()

# Generated at 2022-06-12 16:51:23.810068
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = FileDownloader({})
    dl = HttpQuietDownloader(ydl, {})
    assert dl


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:51:52.975887
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import pytest
    sys.stdout = open('/dev/null', 'w')
    sys.stderr = open('/dev/null', 'w')
    try:
        from ydl.YoutubeDL import YoutubeDL
        from ydl.extractor import get_info_extractor
    except ImportError:
        pytest.skip('youtube-dl library not available.')
    else:
        dl = HttpQuietDownloader(
            YoutubeDL({'logger': YoutubeDL.create_std_logger('warning')}), {})
        dl.add_info_extractor(get_info_extractor('GenericIE'))
        assert dl.download('http://example.com/')

# Generated at 2022-06-12 16:52:02.038019
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpDownloader

    class DummyIE(InfoExtractor):
        def __init__(self, downloader=None):
            InfoExtractor.__init__(self, downloader)

    dl = HttpQuietDownloader(DummyIE())
    assert dl.params['quiet']


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:52:12.270154
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..utils import fake_http_server, FakeYDL
    from ..extractor import gen_extractors

    info_dict = {
        'id': 'testing-id',
        'title': 'testing-title',
        'extractor': 'testing-extractor',
        'url': 'http://127.0.0.1:0/',
    }

    with fake_http_server() as httpd:
        info_dict['url'] = httpd.url('/testing-file')
        httpd.serve_content('testing-file')
        gen_extractors(info_dict)
        FakeYDL().download([info_dict['url']])


# Generated at 2022-06-12 16:52:21.361697
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import time
    from .common import FileDownloader
    fd = FragmentFD({
        'outtmpl': '%(id)s.%(ext)s',
        'noprogress': True,
    }, {
        'id': 'video_id',
        'ext': 'mp4',
    })
    assert isinstance(fd, FileDownloader)
    assert fd.params['outtmpl'] == '%(id)s.%(ext)s'
    assert not fd.params['progress_hooks']


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:52:23.920803
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        hqd = HttpQuietDownloader(None, {'noprogress': True})
    except:
        raise AssertionError('HttpQuietDownloader constructor does not work')

# Generated at 2022-06-12 16:52:26.082304
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(dict(noprogress=True))
    assert isinstance(fd.fd, HttpQuietDownloader)
    assert fd.fd.params['noprogress'] is True

# Generated at 2022-06-12 16:52:38.171805
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    global HttpQuietDownloader
    global FileDownloader
    if HttpQuietDownloader is None or FileDownloader is None:
        return

    class FakeYDL(object):
        def __init__(self):
            self.params = {}

    import tempfile

    t_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 16:52:45.175335
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import subprocess

    fd = FragmentFD({'outtmpl': '%(id)s.%(ext)s', 'format': 'best', 'noprogress': True}, None)
    if sys.version_info < (3, 0):
        assert isinstance(fd, object)
    else:
        assert isinstance(fd, object)

    # Test if constructor raises proper errors

    # Missing outtmpl
    try:
        FragmentFD({'format': 'best', 'noprogress': True}, None)
        raise AssertionError('FragmentFD constructor didn\'t raise TypeError')
    except TypeError:
        pass
    except Exception:
        raise AssertionError('FragmentFD constructor raised wrong exception')

    # Missing format

# Generated at 2022-06-12 16:52:46.358664
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # TODO
    pass

# Generated at 2022-06-12 16:52:50.501667
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-12 16:53:31.058859
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)



# Generated at 2022-06-12 16:53:32.756515
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    isinstance(FragmentFD(FileDownloader({})), FragmentFD)

# Generated at 2022-06-12 16:53:33.788649
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-12 16:53:37.087811
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, None)
    fd.to_screen = lambda *a, **k: None
    fd.report_warning = lambda msg: None
    fd.report_error = lambda msg: None
    fd.report_destination = lambda *a: None
    fd._hook_progress = lambda *a: None
    fd.temp_name = lambda *a: '-'

# Generated at 2022-06-12 16:53:49.433595
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import tempfile

    class FakeYDL:
        def __init__(self):
            self.to_screen_value = ''

        def to_screen(self, *args, **kargs):
            self.to_screen_value = args[0]

    def temp_name(name):
        return name

    ydl = FakeYDL()
    class FakeFragFD(FragmentFD):
        FD_NAME = 'fake'
        ydl = ydl
        params = {}
        temp_name = temp_name

    # output_template is required to specify output file
    ctx = {'output_template': '%(id)s'}
    ff = FakeFragFD(ctx, None)
    assert isinstance(ff, FragmentFD)
    assert ff.params == {}
    assert ff.ctx == c

# Generated at 2022-06-12 16:53:58.559034
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import YoutubeIE
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD
    from ..downloader.dash import DashFD

    assert issubclass(FragmentFD, FileDownloader)

    assert issubclass(F4mFD, FragmentFD)
    assert issubclass(HlsFD, FragmentFD)
    assert F4mFD.FD_NAME == 'f4m'
    assert HlsFD.FD_NAME == 'hlsnative'
    assert DashFD.FD_NAME == 'dash'

    assert issubclass(
        YoutubeIE.fragment_retries_ies['f4m'], F4mFD)
    assert issubclass(
        YoutubeIE.fragment_retries_ies['hls'], HlsFD)

# Generated at 2022-06-12 16:54:03.321267
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fd = HttpQuietDownloader(None, {'quiet': True})
    assert not hasattr(fd, 'to_screen')


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:54:05.443973
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None)
    assert fd.params == {}
    assert fd.ydl is None

# Generated at 2022-06-12 16:54:15.535994
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import tempfile
    class MyFragmentFD(FragmentFD):
        def __init__(self, ydl):
            super(MyFragmentFD, self).__init__(ydl)
        def real_download(self, *args, **kwargs):
            pass
    ydl = {
        'outtmpl': 'foo', # required by real_downloader
        '_err_temp_file_name': tempfile.mkstemp()[1],
        'progress_hooks': [],
        'params': {},
    }
    fd = MyFragmentFD(ydl)

# Generated at 2022-06-12 16:54:18.079941
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from . import YoutubeDL
    ydl = YoutubeDL({'quiet': True})  # it's quiet!
    dl = HttpQuietDownloader(ydl, {'quiet': False})  # it's not quiet!
    assert not dl.params['quiet']  # but actually it is!

# Generated at 2022-06-12 16:55:47.326170
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:55:49.466712
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=star-args
    assert isinstance(FragmentFD(*(None,) * 9), FragmentFD)

# Generated at 2022-06-12 16:55:50.928471
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader(options={'quiet':True})
    dl.to_screen('Hello there!')

# Generated at 2022-06-12 16:55:58.077342
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    f = FragmentFD(None)
    assert f.params['retries'] == 10
    f = FragmentFD(None, {'retries': 3})
    assert f.params['retries'] == 3
    from ..YoutubeDL import YoutubeDL
    # Check that http downloader is properly initialized
    # by setting ratelimit
    y = YoutubeDL({'noprogress': True, 'ratelimit': '500k'})
    f = FragmentFD(y)
    assert f.ydl._downloader.params['ratelimit'] == '500k'


# Generated at 2022-06-12 16:56:02.954670
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFD(FragmentFD):
        def __init__(self, ydl, params=None):
            super(MyFD, self).__init__(ydl, params)
    ydl = {}
    fd = MyFD(ydl)
    assert fd.ydl is ydl
    assert fd.params is fd.ydl._default_params
    assert fd.FD_NAME is None

# Utility

# Generated at 2022-06-12 16:56:07.329239
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # FragmentFD needs to subclass FileDownloader
    class DummyFragmentFD(FragmentFD):
        pass

    fd = DummyFragmentFD({})
    assert isinstance(fd, FileDownloader)


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:56:16.795149
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DashSegmentsFD
    from .hls import HLSFD
    fd = FileDownloader({})
    http = HttpFD(fd, {})
    dash = DashSegmentsFD(fd, http, {})
    assert issubclass(FileDownloader, FragmentFD)
    assert issubclass(HttpFD, FragmentFD)
    assert issubclass(DashSegmentsFD, FragmentFD)
    assert not issubclass(FragmentFD, DashSegmentsFD)
    assert not issubclass(FragmentFD, HttpFD)
    assert not issubclass(FragmentFD, FileDownloader)
    assert isinstance(http, FragmentFD)
    assert isinstance(dash, FragmentFD)

# Generated at 2022-06-12 16:56:21.222618
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD({}, {'noprogress': True}, 'test')
    assert fd.params == {'noprogress': True}
    assert fd.ydl == {}
    assert fd.FD_NAME == 'test'
    assert fd.to_screen_bool() is False
    assert fd.params == {'noprogress': True}
    assert fd.params == {'noprogress': True}

# Generated at 2022-06-12 16:56:23.927209
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, None)
    assert fd


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:56:27.609341
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader(None, {})
    assert dl.opts['quiet']
    assert dl.opts['noprogress']
    assert not dl.opts['verbose']