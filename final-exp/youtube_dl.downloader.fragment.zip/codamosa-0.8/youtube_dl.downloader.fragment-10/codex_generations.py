

# Generated at 2022-06-12 16:49:17.151142
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import get_ytdl_file
    from .compat import compat_str
    from .downloader.external import ExternalFD

    # Prepare
    extractors = gen_extractors()
    ytdl_file = get_ytdl_file()

    # Manual tests
    class _TestIE(InfoExtractor):
        IE_NAME = 'Test IE'

        def __init__(self, ie_urls):
            super(_TestIE, self).__init__()
            self._ies = ie_urls

        def _real_extract(self, url):
            url = compat_str(url)
            ie = self._ies.get(url)
            if ie is None:
                raise ValueError


# Generated at 2022-06-12 16:49:26.434802
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import get_info_extractor

    ie = get_info_extractor('Youtube')
    dl = HttpQuietDownloader(ie, {'continuedl': True, 'noprogress': True})
    assert dl.params['continuedl'] is True and dl.params['noprogress'] is True
    assert dl.report_warning == ie.report_warning


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:49:34.864313
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .dashsegments import DashSegmentsFD
    from .hlsnative import HLSFD
    from .http import HttpFD

    def is_subclass(sub, cls):
        return issubclass(sub, cls) and sub is not cls

    assert is_subclass(FragmentFD, FileDownloader)
    assert not is_subclass(FragmentFD, HttpFD)
    assert is_subclass(DashSegmentsFD, FragmentFD)
    assert is_subclass(HLSFD, FragmentFD)
    assert not is_subclass(HttpFD, FragmentFD)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:49:38.272245
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD()
    assert fd.params == {
        'keep_fragments': False,
        'ratelimit': None,
        'retries': 10,
        'skip_unavailable_fragments': False,
        'fragment_retries': 10,
        'test': False,
        'nopart': False,
        'updatetime': True,
    }

# Generated at 2022-06-12 16:49:39.850843
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader({}, {})

# Generated at 2022-06-12 16:49:48.691254
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = type('DummyYDL', (object,), {})()
    params = {
        'nopart': True,
        'noprogress': True,
        'retries': 0,
    }
    fragment_fd = FragmentFD(ydl, params)

    assert fragment_fd.params is params
    assert fragment_fd.tmpfilename is None
    assert fragment_fd.last_fragment_index is None
    assert fragment_fd.FD_NAME is None
    assert fragment_fd.progress_hooks == []

# Generated at 2022-06-12 16:49:53.667620
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params

    ydl = object()
    params = {}
    fd = TestFD(ydl, params)
    assert fd.ydl is ydl
    assert fd.params is params

# Generated at 2022-06-12 16:49:58.450065
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    global params
    params = {
        'noprogress': True,
        'nopart': True,
        'updatetime': True,
        'test': True,
        'socket_timeout': 300,
        'continuedl': True,
        'nocheckcertificate': True,
    }
    HttpQuietDownloader({}, params)

# Generated at 2022-06-12 16:50:02.407477
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    hqd = HttpQuietDownloader(
        FileDownloader(params={}),
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
        })
    return True


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:50:04.829611
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    instance = HttpQuietDownloader(None, None)
    assert isinstance(instance, HttpFD)

# Generated at 2022-06-12 16:50:38.551207
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        from StringIO import StringIO
        from urllib2 import build_opener, HTTPHandler, HTTPError
        from urllib import addinfourl
        from types import ClassType
    except ImportError:
        return True
    opener = build_opener(
        HTTPHandler(debuglevel=0),
    )
    urlopen = opener.open

    def _test_dlinstance(dlinstance, filename, info_dict):
        try:
            dlinstance.report_warning('Should be printed')
            return False
        except AttributeError:
            pass


# Generated at 2022-06-12 16:50:43.867550
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }
    ydl = object()
    dl = HttpQuietDownloader(ydl, params)

    assert dl.ydl is ydl
    assert dl.params == params

# Generated at 2022-06-12 16:50:45.030213
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {}, None)
    assert 'FragmentFD' == fd.FD_NAME

# Generated at 2022-06-12 16:50:49.733500
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import YoutubeIE
    ydl = YoutubeIE()
    x = FragmentFD(ydl, {'format': 'bestvideo+bestaudio'})
    x.to_screen = lambda *args, **kargs: None
    assert x.params['fragment_retries'] == 10
    assert x.params['skip_unavailable_fragments']

# Generated at 2022-06-12 16:50:52.119113
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from ..downloader.http import HttpDownloader
    assert issubclass(HttpQuietDownloader, HttpDownloader)

# Generated at 2022-06-12 16:51:04.484916
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from .common import FileDownloader


# Generated at 2022-06-12 16:51:15.151440
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD({})
    assert fd.params == {
        'fragment_retries': 10,
        'keep_fragments': False,
        'skip_unavailable_fragments': False,
    }

    fd = FragmentFD({
        'fragment_retries': 42,
        'keep_fragments': True,
        'skip_unavailable_fragments': True,
    })
    assert fd.params == {
        'fragment_retries': 42,
        'skip_unavailable_fragments': True,
        'keep_fragments': True,
    }

    assert fd.FAILED_ON_PERCENTAGE == 0

# Generated at 2022-06-12 16:51:15.881725
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass

# Generated at 2022-06-12 16:51:26.280627
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.params = {'cachedir': False}
    ie.add_info_extractor(lambda ie: None)
    ie.to_screen = lambda *x: None
    ie.report_warning = lambda msg: None
    ie.report_error = lambda msg: None
    ie.expected_warnings = 0
    FD = HttpQuietDownloader(ie, params={'quiet': False})
    assert not FD.params.get('quiet', True)


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:51:30.768154
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        def _real_extract(self, url):
            return None
    f = TestFD(dict())
    f.to_screen = lambda *args, **kargs: None
    return f

# Generated at 2022-06-12 16:52:05.915819
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from ..compat import compat_urllib_request

    _old_HTTPDownloadHandler = HttpFD._HTTPDownloadHandler

    def _new_HTTPDownloadHandler(self, *args, **kwargs):
        return _old_HTTPDownloadHandler(*args, **kwargs)

    ydl = HttpQuietDownloader({'quiet': True})
    assert ydl.params['quiet'] is True
    assert ydl._progress_hooks == []
    assert ydl._progress_hook_downloaded_bytes == 0
    assert isinstance(
        ydl.http_req, compat_urllib_request.Request)

    HttpFD._HTTPDownloadHandler = _new_HTTPDownloadHandler


# Generated at 2022-06-12 16:52:16.975731
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class MockYtDL(object):
        def __init__(self, params):
            self.params = params

    hqd = HttpQuietDownloader(
        MockYtDL({'continuedl': False, 'noprogress': False, 'progress_with_newline': False}),
        {'continuedl': True, 'quiet': True, 'noprogress': True})
    assert hqd._ydl.params['continuedl']
    assert not hqd._ydl.params['noprogress']
    assert not hqd._ydl.params['progress_with_newline']
    assert hqd.params['continuedl']
    assert hqd.params['quiet']
    assert hqd.params['noprogress']

    hqd = HttpQuietDownload

# Generated at 2022-06-12 16:52:22.832056
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }
    ydl = youtube_dl.YoutubeDL(params)
    assert HttpQuietDownloader(ydl, params).params == params

# Generated at 2022-06-12 16:52:26.944569
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl
    ydl = youtube_dl.YoutubeDL()
    ydl.params['verbose'] = False
    ydl.params['dump_intermediate_pages'] = False
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    info = ydl.extract_info(url, False)
    assert info['_type'] == 'url'
    assert info['url'] == url
    assert info['ie_key'] == 'Youtube'
    assert info['ext'] == 'flv'
    assert info['title'] == 'youtube-dl test video "\'/\\ä↭𝕐"'
    assert 'http://r12---sn-p5qlsu7r.googlevideo.com/' in info['url']

# Generated at 2022-06-12 16:52:38.988741
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class FakeInfoDict(dict):
        def __init__(self):
            self['url'] = None
            self['playlist'] = None
            self['playlist_index'] = None
            self['title'] = None
            self['id'] = None
            self['formats'] = None
            self['extractor'] = 'dummy'

    class FakeYdl(object):

        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s',
                'restrictfilenames': True,
                'nooverwrites': False,
            }

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass


# Generated at 2022-06-12 16:52:45.613975
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = None  # Dummy
    params = {
        'noprogress': True,
        'quiet': True,
    }
    h = HttpQuietDownloader(ydl, params)

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:52:57.385083
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class FakeYoutubeDL():
        params = {
            'outtmpl': '%%(id)%%',
        }

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def to_stderr(self, *args, **kargs):
            pass

        def temp_name(self, name):
            return name + '-Tmp'

    class FakeFD():
        params = {}

        def report_progress(self, *args, **kargs):
            pass

        def to_screen(self, *args, **kargs):
            pass

    expected_params

# Generated at 2022-06-12 16:53:09.280987
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def ydl_filename(name):
        return name + '.ytdl'

    fd = FragmentFD(ydl=None, params={})
    fd.to_screen = lambda *args: None
    fd.report_warning = lambda *args: None
    fd.calc_eta = lambda *args: None
    fd.report_progress = lambda *args: None
    fd.report_destination = lambda *args: None
    fd.try_rename = lambda *args: None
    fd.temp_name = lambda name: name
    fd.ytdl_filename = ydl_filename
    ok = False
    try:
        fd._read_ytdl_file({'filename': 'test'})
        ok = True
    except Exception:
        pass
    assert ok
   

# Generated at 2022-06-12 16:53:10.242566
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass


# Generated at 2022-06-12 16:53:13.241336
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    dl = HttpQuietDownloader(youtube_dl.YoutubeDL({}), {})
    assert dl.ydl is not None
    assert dl.params == {}

# Generated at 2022-06-12 16:54:11.105051
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors

    info_dict = {
        'id': 'OjyKGb7c0RQ',
        'ext': 'mp4',
        'title': 'Re: zero kara hajimeru isekai seikatsu opening full',
        'upload_date': '20160623',
        'uploader': 'AniMeMa',
        'uploader_id': 'AniMeMa',
    }

    class TestFD(HttpQuietDownloader):
        def __init__(self_, ydl, params):
            self_.ydl = ydl
            self_.params = params
            self_.to_screen('This is a test')


# Generated at 2022-06-12 16:54:16.809604
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        import __main__
        __main__.params = {
            'download_archive': 'archive',
            'ratelimit': 55029,
            'retries': 0,
            'nopart': False,
            'test': False,
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
        }
        dl = HttpQuietDownloader(__main__, __main__.params)
        assert dl
    except Exception:
        assert False, 'failed to instantiate HttpQuietDownloader'

# Generated at 2022-06-12 16:54:20.150215
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractor_classes
    # Number of extractors that inherit FragmentFD
    assert len(gen_extractor_classes()) - 37 == 0

# Generated at 2022-06-12 16:54:26.770175
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    gen_extractors()
    from .http import HttpFD
    from .dash import DashFD
    from .hls import HlsFD
    from .hlsnative import HlsFD as HlsNativeFD
    from .m3u8 import M3u8FD

    for fd in (HttpFD, DashFD, HlsFD, HlsNativeFD, M3u8FD):
        assert issubclass(fd, FragmentFD)

# Generated at 2022-06-12 16:54:29.626974
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-12 16:54:38.448841
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    import test

    def to_screen(msg):
        assert 'foo' in msg
    def download(filename, desc):
        assert 'foo' in desc['url']
        return True
    ydl = youtube_dl.YoutubeDL({})
    ydl.to_screen = to_screen
    ydl.download = download
    hqd = HttpQuietDownloader(ydl, {'continuedl': True})
    hqd.report_retry('foo', 1, 1)
    hqd.report_skip_fragment('foo')
    try:
        hqd.report_destination('foo')
    except test.TestError:
        pass
    else:
        raise test.TestError('Unexpected success')

# Generated at 2022-06-12 16:54:48.895567
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .http import HttpFD

    class FakeYoutubeDL(object):
        params = {'verbose': True}

        def to_screen(self, message, skip_eol=None, check_quiet=None):
            pass

    class FakeFD(HttpFD):
        def __init__(self, ydl, params):
            pass

    class FakeInfoDict(object):
        pass

    class FakeEntry(object):
        def __init__(self, name, id):
            self.name = name
            self.id = id

    fake_infodict = FakeInfoDict()
    fake_infodict.filename = 'TestFile.mp4'
    fake_infodict.title = 'TestTitle'
    fake_infodict.id = '123456789'
    fake_inf

# Generated at 2022-06-12 16:54:56.081949
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import urlopen
    from ..utils import dl
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..postprocessor.common import PostProcessor
    from .f4m import F4mFD
    from .hlsnative import HlsFD
    from .dash import (
        DashSegmentsFD,
        DASH_MANIFEST_RE,
        DASH_ADAPTATION_TYPE_TO_NAME,
    )

    class _FakeYoutubeDL(object):
        params = {
            'simulate': True,
        }

        def to_stdout(self, message):
            print(message)

        def to_screen(self, message):
            print(message)


# Generated at 2022-06-12 16:55:03.195389
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    opts = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }
    dl = HttpQuietDownloader(object(), opts)
    assert dl._opts == opts
    dl.to_screen('Testing')

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:55:07.448295
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = MockYoutubeDl()
    http_downloader = HttpQuietDownloader(ydl, {})
    assert http_downloader.ydl is ydl
    assert http_downloader.params is {}



# Generated at 2022-06-12 16:56:46.728050
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.params = {}
    ie.add_default_info_extractors()
    dl = HttpQuietDownloader(ie, {'continuedl': True})
    assert dl.params['continuedl'] == True

# Generated at 2022-06-12 16:56:58.796227
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys

    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': 1,
        'retries': 1,
    }
    hqd = HttpQuietDownloader({'params': params}, {'quiet': True})
    assert isinstance(hqd, HttpFD)
    # Test for 'quiet' flag passed to the constructor of FileDownloader
    assert 'quiet' in hqd.ydl.params

    # Test for 'quiet' flag passed to the constructor of HttpFD
    gen = hqd._do_download(None, {'url': 'https'})
    next(gen) # start downloading
    gen.send(None) # progress hook

# Generated at 2022-06-12 16:57:06.511807
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl
    import sys

    def write_to_fd(fd, data):
        if sys.version_info < (3, 0):
            import codecs
            fd.write(codecs.BOM_UTF8)
        fd.write(data)

    write_to_fd(sys.stderr, 'test stderr')
    assert sys.stderr.getvalue() == 'test stderr'

    ydl = youtube_dl.YoutubeDL(
        {'verbose': True, 'quiet': True, 'simulate': True, 'logger': youtube_dl.logger.Logger()})

    write_to_fd(sys.stderr, 'test stderr')
    assert sys.stderr.getvalue() == 'test stderr'

    HttpQuiet

# Generated at 2022-06-12 16:57:08.909396
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(None, {'quiet': True})

# Generated at 2022-06-12 16:57:15.855195
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    info_dict = {
        'id': 'test',
        'protocol': 'http',
        'ext': 'mp4',
        'url': 'http://test.test',
    }
    params = {'quiet': True}
    ydl = object()
    downloader = HttpQuietDownloader(ydl, params)
    assert downloader.ydl is ydl
    assert downloader.params == params


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:57:22.677099
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import DateRange
    from ..downloader import gen_fd_classes
    for ie in gen_extractors():
        if ie.IE_NAME == 'youtube':
            break
    ie.url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    video = ie.extract(ie.url)
    for fd_cls in gen_fd_classes():
        if fd_cls.FD_NAME == 'hlsnative':
            break
    fd = fd_cls(ie.ydl, ie, DateRange('1d'), False, False)

# Generated at 2022-06-12 16:57:28.006693
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    youtube_dl = gen_extractor()
    downloader = HttpQuietDownloader(
        youtube_dl,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'retries': 0,
            'nopart': False,
            'test': False,
        }
    )
    assert downloader.params['continuedl'] == True
    assert downloader.params['quiet'] == True
    assert downloader.params['noprogress'] == True
    assert downloader.params['nopart'] == False
    assert downloader.params['test'] == False
    assert downloader.params['retries'] == 0
    assert downloader.ydl is youtube_dl

# Generated at 2022-06-12 16:57:36.247060
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import io
    from .common import FileDownloader
    from .http import HttpFD

    my_stdout = io.StringIO()

    class MyFD(HttpFD, FileDownloader):
        def report_progress(self, *args):
            pass

    MyFD({}, {}, {'outtmpl': '-'}).to_screen('hello')

    sys.stdout = my_stdout
    MyFD({}, {}, {'outtmpl': '-'}).to_screen('hello')
    assert my_stdout.getvalue() == ''
    sys.stdout = sys.__stdout__

# Generated at 2022-06-12 16:57:42.675375
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = object()
    params = {'noprogress': True, 'param': 'value'}
    dl = HttpQuietDownloader(ydl, params)
    assert dl.ydl == ydl
    assert dl.params['noprogress'] is False
    assert dl.params['param'] == 'value'

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:57:50.024127
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        import youtube_dl.extractor.generic
        import youtube_dl.postprocessor.ffmpeg
        import youtube_dl.YoutubeDL
    except ImportError:
        return 'skip'

    def my_hook(d):
        pass
