

# Generated at 2022-06-12 16:49:16.902384
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import io
    from .http import HttpFD

    ydl = HttpQuietDownloader(HttpFD(), {'noprogress': True})

    # Emulate stdout
    out = io.StringIO()
    sys.stdout = out

    ydl.to_screen('Testing for HttpQuietDownloader')

    # reset stdout
    sys.stdout = sys.__stdout__

    assert out.getvalue() == ''

    # test that opts passed to HttpQuietDownloader are passed to HttpFD
    # (test for regression - see https://github.com/rg3/youtube-dl/pull/12091)
    assert ydl.ydl.params['noprogress'] is True

# Generated at 2022-06-12 16:49:31.198341
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import YoutubeIE

    YoutubeIE._WORKING = False

    ydl = HttpQuietDownloader(
        {
            'username': 'faketestuser',
            'password': 'faketestpass',
        },
        {
            'continuedl': False,
            'quiet': True,
            'noprogress': True,
            'ratelimit': None,
            'retries': 10,
            'nopart': False,
            'test': True,
        }
    )

    assert ydl._opener.auth_manager.passwd == {'http://www.youtube.com': ('faketestuser', 'faketestpass'), 'https://www.youtube.com': ('faketestuser', 'faketestpass')}

# Generated at 2022-06-12 16:49:43.571688
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import random

    fd = FragmentFD({}, sys.stdout)
    assert fd.FD_NAME == 'fragment'
    assert fd.progress_hooks == []

    fd.add_progress_hook(lambda x: None)
    assert len(fd.progress_hooks) == 1
    fd.add_progress_hook(lambda x: None)
    assert len(fd.progress_hooks) == 2

    hooks = [lambda x: None, lambda x: None]
    fd.add_progress_hook(hooks)
    assert len(fd.progress_hooks) == 4
    fd.remove_progress_hook(hooks[0])
    assert len(fd.progress_hooks) == 3

    hooks = [lambda x: None, lambda x: None]
   

# Generated at 2022-06-12 16:49:55.113630
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .extractor.common import InfoExtractor
    from .utils import DateRange
    class FakeIE(InfoExtractor):
        IE_NAME = 'test_ie'
        def _real_extract(self, url):
            return {
                '_type': 'url',
                'url': url,
                'ie_key': 'Fake',
                'id': 'TESTID',
            }
    int_fallback_daterange = DateRange(29990101)
    assert FragmentFD(
        FakeIE(),
        {},
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': None,
            'retries': 0,
            'nopart': False,
            'test': False,
        },
        {})

# Generated at 2022-06-12 16:50:01.605311
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert FragmentFD.__name__ == 'FragmentFD'

    fd = FragmentFD(None, {
        'fragment_retries': 10,
        'keep_fragments': True,
        'skip_unavailable_fragments': False,
    })
    assert fd.params['fragment_retries'] == 10
    assert fd.params['keep_fragments'] is True
    assert fd.params['skip_unavailable_fragments'] is False

    assert 'fragment_retries' in fd._default_options

# Generated at 2022-06-12 16:50:09.181349
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=W0212
    test_filename = 'test_filename'
    fd = FragmentFD(None, {'nooverwrites': True, 'continuedl': True})
    assert fd.params['continuedl'] is True
    assert fd._prepare_and_start_frag_download({'filename': test_filename})
    # TODO: test _finish_frag_download
    assert fd.ytdl_filename(test_filename) == test_filename + '.ytdl'

# Generated at 2022-06-12 16:50:20.665102
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader

# Generated at 2022-06-12 16:50:33.665797
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_pp_classes
    from .postprocessor.common import PostProcessor
    class TestIE(InfoExtractor):
        IE_NAME = 'test'
    class TestPP(PostProcessor):
        def run(self, info):
            pass

    ie = TestIE(None)
    pp = TestPP(ie)
    dl = HttpQuietDownloader(None, {})

    assert isinstance(dl, FileDownloader)
    assert isinstance(dl.params, dict)
    assert dl.ydl is None

    dl = HttpQuietDownloader(ie, {'noprogress': True, 'logger': pp})

# Generated at 2022-06-12 16:50:40.664456
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class YDL(object):
        params = {}

    ydl = YDL()
    ctx = {
        'continuedl': True,
        'noprogress': True,
        'quiet': True,
    }
    hd = HttpQuietDownloader(ydl, ctx)
    assert hd.params == ctx
    assert hd.ydl == ydl
    assert hd.fd.params == ctx
    assert hd.fd.ydl == ydl

# Generated at 2022-06-12 16:50:44.167084
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class FakeYdl(object):
        params = {}
    ydl = FakeYdl()

    quiet_dl = HttpQuietDownloader(ydl, {'noprogress': True})
    assert quiet_dl.params['noprogress'] is True
    assert quiet_dl.params['quiet'] is True

# Generated at 2022-06-12 16:51:05.956931
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpDL
    assert isinstance(HttpQuietDownloader(None, {}), HttpDL)

# Generated at 2022-06-12 16:51:07.162619
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(None, {'noprogress': True})

# Generated at 2022-06-12 16:51:20.279853
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .common import FileDownloader
    from .extractor import YoutubeIE
    from .downloader.common import which

    # Assert inheritance path
    assert issubclass(HttpQuietDownloader, HttpFD), 'HttpQuietDownloader not subclass of HttpFD'
    assert issubclass(HttpFD, FileDownloader), 'HttpFD not subclass of FileDownloader'

    # Test that HttpQuietDownloader.to_screen is always None
    d = HttpQuietDownloader(YoutubeIE(), {'quiet': True, 'noprogress': True})
    assert d.to_screen is None, 'Unexpected value for HttpQuietDownloader.to_screen'

    # Test that HttpQuietDownloader.report_destination works the same as HttpFD.report_destination

# Generated at 2022-06-12 16:51:32.267034
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .common import FileDownloader
    from .extractor import gen_extractors

    class MyInfoExtractor(object):
        IE_NAME = 'myie'
        IE_DESC = False

        def __init__(self, downloader=None, download_warning=None,
                     ie_key='', params={}):
            pass

    gen_extractors()
    FileDownloader. Extractor = MyInfoExtractor
    ydl = FileDownloader(params={'verbose': False}, handlers={},
                         download_warning=sys.stderr.write)
    fd = FragmentFD(ydl, {})
    fd.report_retry_fragment(Exception('Test error'), 0, 1, 1)
    fd.report_skip_fragment(0)

# Generated at 2022-06-12 16:51:36.123423
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func
    ie = InfoExtractor()
    ie.params = {'noprogress': True}
    ie._match_filter = match_filter_func(['youtube'])(lambda ie, ie_info: ie)
    dl = HttpQuietDownloader(ie, {})
    assert dl.params == ie.params

# Generated at 2022-06-12 16:51:42.043673
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class DerivedHttpQuietDownloader(HttpQuietDownloader):
        def report_error(self, errmsg):
            pass

    fd = DerivedHttpQuietDownloader(None, {'continuedl': True})
    assert fd.continuedl

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:51:44.340955
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert isinstance(HttpQuietDownloader(None, {}), HttpQuietDownloader)

# Generated at 2022-06-12 16:51:54.042748
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .tests import get_testdata_video_url

    fd = FragmentFD(None, {'quiet': True})

    # test simple download
    ctx = {
        'filename': 'test.mp4',
        'tmpfilename': 'test.mp4.tmp',
        'total_frags': 1,
    }
    frag_url = get_testdata_video_url('test.mp4')
    fd._prepare_frag_download(ctx)
    fd._download_fragment(ctx, frag_url, {'http_headers': {}})
    fd._append_fragment(ctx, ctx.pop('fragment_content'))
    fd._finish_frag_download(ctx)

    # test simple download with resume

# Generated at 2022-06-12 16:51:58.488487
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Downloader can be initialized without any problem
    d = HttpQuietDownloader(None, {})
    # It doesn't display anything to the screen
    d.to_screen('foo')
    # Downloading is not possible
    assert d.download() is False

# Generated at 2022-06-12 16:52:09.438148
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from collections import defaultdict
    from operator import xor
    from .http import HttpFD
    from .common import FileDownloader

    # Test for inner workings of HttpQuietDownloader and its parent classes
    # HttpFD and FileDownloader.
    http_quiet_downloader = HttpQuietDownloader(
        defaultdict(lambda: None),
        {}
    )
    assert isinstance(http_quiet_downloader, HttpFD)
    assert isinstance(http_quiet_downloader, FileDownloader)

    # Test if values in given dict are copied to the new dict.
    dict_to_be_copied = {'debug': True}
    http_quiet_downloader = HttpQuietDownloader(
        defaultdict(lambda: None),
        dict_to_be_copied
    )

# Generated at 2022-06-12 16:52:48.305559
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=W0612
    import sys
    import youtube_dl.FileDownloader
    sys.modules['FileDownloader'] = youtube_dl.FileDownloader

# Generated at 2022-06-12 16:52:52.555352
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert FragmentFD({}, {}, None).params == {'retries': 0}
    assert FragmentFD({'noplaylist': True}, {}, None).params == {'noplaylist': True, 'retries': 0}

# Generated at 2022-06-12 16:53:01.062820
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import gen_extractors
    sys.modules['__main__'].params = {'quiet': True}

# Generated at 2022-06-12 16:53:07.375618
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from collections import namedtuple
    from tempfile import NamedTemporaryFile

    ydl = namedtuple('YoutubeDL', ['params'])({'logger': {}, 'temp_name': NamedTemporaryFile().name})
    assert FragmentFD(ydl, {}).__class__ == FragmentFD


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:53:19.197372
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import os
    import tempfile
    # Create a directory
    tmp_dir = tempfile.mkdtemp()
    os.chdir(tmp_dir)
    filename = 'test.ts'
    fd = FragmentFD(None, {'outtmpl': filename})
    assert fd._prepare_and_start_frag_download({
        'filename': filename,
        'tmpfilename': filename + '.part',
        'total_frags': 10,
    })
    assert os.path.isfile(filename + '.part')
    # Test it twice
    assert fd._prepare_and_start_frag_download({
        'filename': filename,
        'tmpfilename': filename + '.part',
        'total_frags': 10,
    })

# Generated at 2022-06-12 16:53:30.413595
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .extractor import gen_extractors

    def frag_progress_hook(status):
        if status['status'] == 'finished':
            print('downloaded %d bytes' % status['downloaded_bytes'])

    class FakeInfoDict(dict):
        pass

    info_dict = FakeInfoDict()
    info_dict['url'] = 'http://www.youtube.com/watch?v=BaW_jenozKc'

    ydl = gen_extractors()[0].ydl
    ydl.add_progress_hook(frag_progress_hook)

    fd = ydl.get_media_fd(info_dict)
    fd.download('./BaW_jenozKc.f4m')
    ydl.remove_progress_hook(frag_progress_hook)




# Generated at 2022-06-12 16:53:35.058590
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None)
    assert fd._prepare_url(None, 'foo') == 'foo'
    assert fd._prepare_url({'http_headers': {'Foo': 'bar'}}, 'foo') == {
        'url': 'foo',
        'http_headers': {'Foo': 'bar'},
    }

# Generated at 2022-06-12 16:53:47.228378
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..compat import compat_cookiejar
    from ..extractor import common

    class FakeFD(FragmentFD):
        FD_NAME = 'fake'

        def real_download(self, filename, info_dict):
            return True

        def _prepare_frag_download(self, ctx):
            self.report_destination(ctx['filename'])
            dest_stream, tmpfilename = sanitize_open(
                self.temp_name(ctx['filename']), 'wb')
            ctx.update({
                'dest_stream': dest_stream,
                'tmpfilename': tmpfilename,
                'fragment_index': 0,
                'complete_frags_downloaded_bytes': 0,
            })

        def _start_frag_download(self, ctx):
            pass


# Generated at 2022-06-12 16:53:51.374645
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params = {'ratelimit': 10, 'retries': 5, 'nopart': True, 'test': True}
    ydl = object()
    fd = HttpQuietDownloader(ydl, params)
    assert fd.params == params
    assert fd.ydl == ydl

# Generated at 2022-06-12 16:53:52.689726
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    _ = HttpQuietDownloader(None, {})

# Generated at 2022-06-12 16:55:12.279576
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-12 16:55:15.308477
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FakeYDL

    fd = FragmentFD(FakeYDL(), {})
    assert fd
    assert isinstance(fd, FileDownloader)

# Generated at 2022-06-12 16:55:18.241188
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({})
    hqd = HttpQuietDownloader(ydl, {})
    assert hqd.to_screen == hqd.ydl.to_screen

# Generated at 2022-06-12 16:55:21.773610
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    for ie in gen_extractors():
        if ie.IE_NAME != 'generic':
            continue
        if not ie.is_suitable(ie.url_result('fake')):
            continue
        fd = FragmentFD(ie, {}, ie.url_result('fake'))
        assert fd is not None

# Generated at 2022-06-12 16:55:27.160328
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .http import HttpFD
    from ..utils import SameFileError, SameFileWarning
    from .common import FileDownloader
    from .fragment import FragmentFD

    class SameFileFD(HttpFD, FragmentFD):
        FD_NAME = 'samefile'

    global samefile_warning
    samefile_warning = False
    def _samefile_warning(obj, msg):
        global samefile_warning
        samefile_warning = True

    fd = SameFileFD({})
    fd.report_warning = _samefile_warning

# Generated at 2022-06-12 16:55:29.838104
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .rtmp import RtmpFD

    assert issubclass(RtmpFD, FragmentFD)

# Generated at 2022-06-12 16:55:41.001691
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import io
    import sys
    from .extractor import get_info_extractor

    def get_test_ie():
        return get_info_extractor('test')

    filename = 'test'
    ydl = get_test_ie().ydl
    params = {
        'noprogress': True,
        'logger': ydl,
        'hls_prefer_native': True,
        'test': True
    }

    ctx = {
        'ie': get_test_ie(),
        'filename': filename,
        'info_dict': {},
    }
    ffd = FragmentFD(ydl, params)
    ffd.to_stdout = True
    # Make file like object to make sure it's not closed when download finishes
    ffd.out_fd = io.StringIO()

# Generated at 2022-06-12 16:55:46.605953
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class Downloader(HttpQuietDownloader):
        pass
    state = Downloader(None, {})._prepare_kwargs({})
    assert state.get('quiet'), 'Need to be quiet'
    assert state.get('noprogress'), 'Need to have noprogress'

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:55:52.322125
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_str
    from .http import HttpFD
    from ..utils import std_headers

    class FakeYoutubeDL:
        def __init__(self):
            self.params = {
                'noprogress': True,
            }
            self.to_screen = to_screen
            self.report_warning = report_warning
            self.report_error = report_error

    class FakeInfoDict:
        pass

    info_dict = FakeInfoDict()

    def to_screen(msg):
        assert msg == 'Iron Man 3 Official Trailer #2 (2013) - Robert Downey Jr. Movie HD'

    def report_warning(msg):
        assert msg == 'You are using an old version (2013.01.27) of youtube-dl.'

    def report_error(msg):
        assert msg

# Generated at 2022-06-12 16:56:01.599363
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import pytest
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['quiet'] = True
    ydl.add_default_info_extractors()
    hqd = HttpQuietDownloader(
        ydl=ydl, params={
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': None,
            'nopart': True,
            'retries': 0
        })
    hqd.to_screen = sys.stdout.write