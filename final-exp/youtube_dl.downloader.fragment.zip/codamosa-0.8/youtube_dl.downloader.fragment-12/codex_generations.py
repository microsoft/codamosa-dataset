

# Generated at 2022-06-12 16:49:09.916083
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert isinstance(FragmentFD(), FileDownloader)


# Test that FragmentFD is a subclass of FileDownloader

# Generated at 2022-06-12 16:49:16.925660
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import mock
    HttpQuietDownloader(
        mock.Mock(params={'retries': 2}),
        {
            'noprogress': True,
            'ratelimit': 50000,
            'quiet': True,
            'retries': 5,
            'continuedl': True,
            'nopart': False,
        }
    )

# Generated at 2022-06-12 16:49:17.818574
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD()
    assert fd.params is None

# Generated at 2022-06-12 16:49:23.652943
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    quietdl = HttpQuietDownloader(ydl, {})
    quietdl.download('http://example.com')
    assert quietdl.ydl is ydl


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:49:28.487585
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, FileDownloader)
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-12 16:49:41.224770
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def test_const(**kwargs):
        fd = FragmentFD(
            None,
            {
                'outtmpl': '%(id)s.f4m',
                'skip_unavailable_fragments': True,
            },
            **kwargs)
        return (fd.YD_DATA['retries'],
                fd.params.get('skip_unavailable_fragments'))

    assert (5, True) == test_const(format='hls', retries=5)
    assert (5, True) == test_const(format='hlsnative')
    assert (5, True) == test_const(format='dash', retries=5)
    assert (5, True) == test_const(format='dash-flv', retries=5)
    assert (5, True) == test

# Generated at 2022-06-12 16:49:43.285531
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    return len(HttpQuietDownloader.__dict__) - len(HttpFD.__dict__) == 1

# Generated at 2022-06-12 16:49:48.582276
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import mock
    import youtube_dl
    ydl = mock.MagicMock()
    params = {'quiet': True}
    http_quiet_downloader = HttpQuietDownloader(ydl, params)
    assert isinstance(http_quiet_downloader, youtube_dl.downloader.http.HttpFD)

# Generated at 2022-06-12 16:49:50.775116
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # No-op: it should be enough that the constructor doesn't crash
    HttpQuietDownloader(None, None)

# Generated at 2022-06-12 16:49:54.578175
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)
    ydl = lambda: None
    fd = FragmentFD(ydl)
    assert fd.FD_NAME == 'fragment'


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:50:25.308833
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .utils import read_batch_urls

    test_cases = read_batch_urls(
        os.path.join(os.path.dirname(__file__),
            'test', 'testcases', 'http_batch'))

    def retval_processor(retval):
        if retval is None:
            return None
        elif 'status' not in retval:  # return video info
            del retval['extractor']
            return retval
        elif 'error' in retval:
            return retval['error']
        return None

    info_extractor = InfoExtractor()
    options = {
        'quiet': True,
        'noprogress': True,
        'skip_download': True,
    }
    dl = Http

# Generated at 2022-06-12 16:50:37.413013
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import io
    import shutil
    import tempfile
    from contextlib import contextmanager
    from .http import HttpFD

    @contextmanager
    def _stream_and_capture_sys_stdout():
        old_stdout = sys.stdout
        try:
            sys.stdout = io.BytesIO()
            yield sys.stdout
        finally:
            sys.stdout = old_stdout

    tempdir = tempfile.mkdtemp()


# Generated at 2022-06-12 16:50:42.961056
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    video_id = 'OQSNhk5ICTI'
    video_url = 'http://www.youtube.com/watch?v=OQSNhk5ICTI'

    def test_url(url):
        dl = HttpQuietDownloader(None, {'noprogress': True})
        dl.download(None, {'url': url})

    test_url(video_url)
    test_url(video_id)

# Generated at 2022-06-12 16:50:45.586622
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params = {
        'continuedl': True,
        'noprogress': True,
        'quiet': True,
        'ratelimit': '42',
        'test': False,
        'nopart': True,
        'retries': '3',
    }
    assert HttpQuietDownloader(None, params).params == params

# Generated at 2022-06-12 16:50:47.254136
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None)
    assert fd.file_desc() == 'fragmented media'

# Generated at 2022-06-12 16:50:51.273634
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(object())
    assert fd.params == {
        'retries': 0,
        'noprogress': True,
        'nopart': False,
        'test': False,
        'keepfragments': False,
    }

# Generated at 2022-06-12 16:50:56.220530
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:51:07.180466
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=W0612
    import sys
    ydl = {
        'params': {
            'buffersize': '16k',
            'noresizebuffer': True,
            'noprogress': True,
        },
        'quiet': True,
        'to_screen': lambda *args, **kargs: sys.stdout.write('%s\n' % (args[0] % args[1:])),
        'to_stderr': lambda *args, **kargs: sys.stderr.write('%s\n' % (args[0] % args[1:])),
    }
    info_dict = {'url': 'http://127.0.0.1:23490/Techslides.mp4'}

# Generated at 2022-06-12 16:51:20.278283
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """Make sure HttpQuietDownloader constructor works as expected"""
    from ..compat import compat_cookiejar
    from .http import HttpFD
    from .fragment import FragmentFD

    class DummyYDL(object):
        def __init__(self):
            self._cookiejar = compat_cookiejar()

        def to_screen(self, s):
            pass

    class DummyFD(FragmentFD):
        def __init__(self, ydl, params):
            super(DummyFD, self).__init__(ydl, params)

        @staticmethod
        def report_warning(msg):
            pass

        @staticmethod
        def calc_eta(start, now, total, downloaded):
            return None

    ydl = DummyYDL()
    params = {}
    dummyfd = DummyFD

# Generated at 2022-06-12 16:51:22.648787
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class FakeYDL:
        def __init__(self):
            self.params = {}
        def to_screen(self, msg):
            pass

    HttpQuietDownloader(FakeYDL(), {})

# Generated at 2022-06-12 16:51:45.300872
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fd = HttpQuietDownloader.factory()
    assert type(fd) == HttpQuietDownloader

# Generated at 2022-06-12 16:51:50.651265
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    fd = HttpQuietDownloader(None,
                             {'continuedl': True, 'quiet': True, 'noprogress': True})
    assert fd.ydl is None
    assert fd.params['continuedl'] is True
    assert fd.params['quiet'] is True
    assert fd.params['noprogress'] is True

# Generated at 2022-06-12 16:51:53.356750
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    assert issubclass(HttpQuietDownloader, FileDownloader)
    dl = HttpQuietDownloader(None, {})
    assert dl.ydl is None


# Generated at 2022-06-12 16:52:05.916632
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import sys
    IS_PY2 = sys.version_info.major == 2

    class HttpQuietDownloaderTest(unittest.TestCase):
        def test_constructor(self):
            ydl = None
            params = {
                'continuedl': True,
                'quiet': True,
                'noprogress': True,
                'ratelimit': 1,
                'retries': 2,
                'nopart': False,
                'test': False,
            }
            dl = HttpQuietDownloader(ydl, params)
            self.assertTrue(dl._ydl is ydl)
            self.assertTrue(dl._params is not params)
            self.assertE

# Generated at 2022-06-12 16:52:11.187207
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    from .http import HttpFD

    class MockYDL(object):
        def __init__(self, params):
            self.params = params

    ydl = MockYDL({'continuedl': True, 'quiet': True, 'noprogress': True})
    dl = HttpQuietDownloader(ydl, {'continuedl': True, 'quiet': True, 'noprogress': True})
    assert isinstance(dl, HttpFD)
    assert isinstance(dl, FileDownloader)
    assert ydl.params == {'continuedl': True, 'quiet': True, 'noprogress': True}
    assert dl.params == {'continuedl': True, 'quiet': True, 'noprogress': True}

# Generated at 2022-06-12 16:52:15.307477
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        def _prepare_frag_download(self, ctx):
            self.assertIn('tmpfilename', ctx)
            self.assertIn('total_frags', ctx)
            self.assertIn('filename', ctx)
            self.assertIn('fragments', ctx)
            self.assertIn('dl', ctx)
            self.assertIn('dest_stream', ctx)
            self.assertIn('fragment_count', ctx)
            self.assertIsInstance(ctx['dl'], HttpFD)
            self.assertEqual(ctx['total_frags'], len(ctx['fragments']))

        def _start_frag_download(self, ctx):
            self.assertIn('started', ctx)
            self.assertGreater

# Generated at 2022-06-12 16:52:25.646565
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def get_empty_dict():
        return {}

    def get_file_size(filename):
        return os.path.getsize(encodeFilename(filename))

    class FileDownloaderTest(FragmentFD):
        def __init__(self, ydl, temp_name_func, report_func):
            FragmentFD.__init__(
                self, ydl,
                {
                    'quiet': True,
                    'continuedl': True,
                    'fragment_retries': 0,
                    'skip_unavailable_fragments': False,
                    'keep_fragments': False,
                    'updatetime': False,
                })
            self.temp_name = temp_name_func
            self.report_destination = report_func


# Generated at 2022-06-12 16:52:33.501642
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import youtube

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.to_screen = lambda *_, **__: None
        error = lambda *_, **__: None

    fd = FragmentFD(FakeYDL(), youtube.YoutubeIE)
    assert fd.FD_NAME == youtube.YoutubeIE.IE_NAME
    assert fd.params == {}
    assert isinstance(fd.dl, HttpQuietDownloader)

# Generated at 2022-06-12 16:52:40.718140
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD

    # FileDownloader is an abstract class
    # No error is expected
    FileDownloader(None)

    # No error is expected
    FragmentFD(None)

    # Instantiation of HttpFD is illegal for FragmentFD
    # since it's an abstract child of HttpFD
    try:
        HttpFD(None)
    except TypeError:
        pass
    else:
        assert False, 'Instantiation of HttpFD should be illegal'

test_FragmentFD()

# Generated at 2022-06-12 16:52:52.374352
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def test(cls):
        fd = cls(None, {
            'fragment_retries': 10,
            'skip_unavailable_fragments': True,
            'keep_fragments': True,
            'noprogress': True,
            'quiet': True,
            'outtmpl': '-',
        })
        assert fd._retry_fragment_count == 10
        assert fd._skip_unavailable_fragments is True
        assert fd._keep_fragments is True
        assert fd._progress_hooks == []
    test(FragmentFD)

# Generated at 2022-06-12 16:53:27.491350
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from ..utils import DateRange
    from ..extractor import get_info_extractor

    ie = get_info_extractor('youtube')
    info_dict = ie.extract('2g811Eo7K8U')
    from .fragment import YoutubeFD
    from .http import HttpFD
    from .wget import WgetFD
    from .wrappers import YoutubeDLCookiesFD, YoutubeDLHTTPHeadersFD
    from .external import ExternalFD
    from .ffmpeg import FFmpegFD
    from .dash import DASHFD
    from .hls import HlsFD
    from .http import HttpFD
    from .f4m import F4mFD
    from .concat import ConcatFD

    class FakeYDL:
        def __init__(self, params):
            self.params

# Generated at 2022-06-12 16:53:34.109433
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from ..extractor.common import InfoExtractor

    class MyInfoExtractor(InfoExtractor):
        def report_warning(self, msg):
            sys.stderr.write('WARNING: ' + msg + '\n')

        def report_error(self, msg):
            sys.stderr.write('ERROR: ' + msg + '\n')

    ydl = MyInfoExtractor({})
    HttpQuietDownloader(ydl, {})

# Generated at 2022-06-12 16:53:45.109220
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        FD_NAME = 'test'

    # empty
    o = TestFD({})
    assert o.params == {
        'noprogress': True,
        'nopart': False,
        'retries': 0,
        'ratelimit': None,
        'test': False,
    }

    # non-standard
    o = TestFD({'params': {'foo': 'bar', 'baz': 'qux'}})
    assert o.params == {
        'foo': 'bar',
        'baz': 'qux',
        'noprogress': True,
        'nopart': False,
        'retries': 0,
        'ratelimit': None,
        'test': False,
    }

# Generated at 2022-06-12 16:53:55.097315
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert hasattr(FragmentFD, '__init__')
    assert hasattr(FragmentFD, 'report_progress')
    assert hasattr(FragmentFD, 'report_retry_fragment')
    assert hasattr(FragmentFD, 'report_skip_fragment')
    assert hasattr(FragmentFD, '_append_fragment')
    assert hasattr(FragmentFD, '_download_fragment')
    assert hasattr(FragmentFD, '_finish_frag_download')
    assert hasattr(FragmentFD, '_prepare_frag_download')
    assert hasattr(FragmentFD, '_start_frag_download')

    import youtube_dl
    ydl = youtube_dl.YoutubeDL({})
    frag_dl = FragmentFD(ydl, {})


# Generated at 2022-06-12 16:54:07.530078
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import get_info_extractor
    sys.argv = ['yt', '--simulate', 'http://a']
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL(
        {
            # Set output template to none to avoid downloading
            'outtmpl': 'none'
        }
    )
    ie = get_info_extractor('GenericIE', ydl)
    frag_fd = FragmentFD(ydl, ie)

    opts = {
        'fragment_retries': 3,
        'skip_unavailable_fragments': True,
        'keep_fragments': True,
    }
    opt_diff = frag_fd.params.copy()
    frag_fd.params.update(opts)
    assert frag_fd.params == opt

# Generated at 2022-06-12 16:54:10.477394
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None)
    assert not fd.params.get('continuedl')
    assert fd.params.get('noprogress')

# Generated at 2022-06-12 16:54:11.314890
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass

# Generated at 2022-06-12 16:54:20.414908
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader

    fd = FragmentFD()

    assert fd.params is None
    assert fd.ydl is None
    assert fd.name is None
    assert fd.outtmpl is None
    assert fd.progress_hooks == []
    assert fd.finished_hooks == []

    # This is how constructor of FileDownloader works in real life
    # (as of 2011-01-28)
    fd = FragmentFD.__new__(FragmentFD)
    FileDownloader.__init__(fd)
    assert isinstance(fd, FileDownloader)
    assert isinstance(fd, FragmentFD)

# Generated at 2022-06-12 16:54:22.628443
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=protected-access
    assert HttpQuietDownloader._opener.is_authenticated() == True

# Generated at 2022-06-12 16:54:26.491582
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class DummyFragmentFD(FragmentFD):
        def __init__(self):
            self.ydl = None
            self.params = {}
            FragmentFD.__init__(self)
    DummyFragmentFD()

# Generated at 2022-06-12 16:55:25.682172
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class MockYTDLSetup:
        params = {}
        to_screen = lambda x, msg: None
    ydl = MockYTDLSetup()
    dl = HttpQuietDownloader(
        ydl,
        {
            'noprogress': True,
            'quiet': True
        }
    )
    assert dl.params == {
        'format': 'best',
        'continuedl': True,
        'noprogress': True,
        'quiet': True,
        'nopart': True
    }

# Generated at 2022-06-12 16:55:33.060528
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)
    assert not issubclass(FragmentFD, DASHFD)
    assert not issubclass(FragmentFD, HLSFD)

# Generated at 2022-06-12 16:55:43.390428
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': '2M',
        'retries': 3,
        'nopart': True,
        'test': True,
    }

# Generated at 2022-06-12 16:55:54.281440
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import common
    from ..compat import compat_urllib_error
    from .http import HttpFD
    from .http import FragmentFD as HttpFragmentFD
    from .rtmp import FragmentFD as RtmpFragmentFD

    class DummyYoutubeDL(object):
        def __init__(self, params):
            assert isinstance(self, HttpFragmentFD)
            assert params['continuedl']
            assert params['noprogress']
            assert params['quiet']
            assert params['retries'] == 0
            assert params['nopart']
            assert params['test']
            assert not self.params
            self.params = params

        def download(self, filename, info_dict):
            return True

        def to_screen(self, *args, **kargs):
            pass

# Generated at 2022-06-12 16:56:01.260056
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .dash import DASHFD
    FileDownloader.params = {
        'noprogress': True,
        'quiet': True,
    }
    dashfd = DASHFD(FileDownloader())
    assert isinstance(dashfd.dl, HttpQuietDownloader)
    dashfd.to_screen('foo')
    assert dashfd.dl.ydl is FileDownloader()
    assert dashfd.dl.params['noprogress']
    assert dashfd.dl.params['quiet']
    assert not dashfd.dl.params['progress_with_newline']

# Generated at 2022-06-12 16:56:09.983660
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD({})
    fd.add_info_extractor('http')
    fd.params['writedescription'] = True
    fd.params['writeannotations'] = True
    fd.params['writethumbnail'] = True
    fd.params['writeinfojson'] = True
    fd.params['writesubtitles'] = True
    fd.params['writeautomaticsub'] = True
    fd.params['subtitleslangs'] = ['en']
    fd.params['nooverwrites'] = True
    fd.params['prefer_free_formats'] = True

# Generated at 2022-06-12 16:56:18.472956
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Check that HttpQuietDownloader doesn't print anything
    class FakeYDL(object):
        def __init__(self, *args, **kwargs):
            pass

        def to_screen(self, *args, **kargs):
            raise AssertionError('to_screen shouldn\'t be called.')

        def to_stderr(self, *args, **kargs):
            raise AssertionError('to_stderr shouldn\'t be called.')

        def to_console_title(self, *args, **kargs):
            raise AssertionError('to_console_title shouldn\'t be called.')

    ydl = FakeYDL()

# Generated at 2022-06-12 16:56:24.234919
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .common import YoutubeDL

    class FakeInfoDict(dict):
        pass
    class FakeExtractor(object):
        IE_NAME = 'test_extractor'

    ydl = YoutubeDL({'quiet': True, 'simulate': True, 'noprogress': True})
    dl = HttpQuietDownloader(ydl, {'quiet': True, 'noprogress': True})

    info_dict = FakeInfoDict({'url': 'http://example.com/'})
    fake_IE = gen_extractor(FakeExtractor())
    info_dict['extractor'] = fake_IE

    test_url = 'http://example.com/test_file'
    request = dl._prepare_request(test_url, info_dict)

# Generated at 2022-06-12 16:56:31.571112
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader(None, {}).to_screen == HttpFD.to_screen    # By default to_screen is not overriden
    assert HttpQuietDownloader(None, {'quiet': False}).to_screen != HttpFD.to_screen
    assert HttpQuietDownloader(None, {'noprogress': False}).to_screen != HttpFD.to_screen
    assert HttpQuietDownloader(None, {'noprogress': True}).to_screen == HttpFD.to_screen

# Generated at 2022-06-12 16:56:33.334228
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    d = HttpQuietDownloader(object(), {'quiet': True})

# Generated at 2022-06-12 16:58:45.930903
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL

    options = {
        'quiet': True,
        'noprogress': True,
        'continuedl': True,
        'retries': 10,
    }

    ydl = youtube_dl.YoutubeDL(options)
    url = 'http://example.com/file_5M'
    http_quiet_downloader = HttpQuietDownloader(ydl, options)
    tmpfilename = http_quiet_downloader.temp_name(url)
    open_mode = 'wb'
    if os.path.isfile(tmpfilename):
        open_mode = 'ab'
    stream, tmpfilename = sanitize_open(tmpfilename, open_mode)
    http_quiet_downloader.report_destination(url)