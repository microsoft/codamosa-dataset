

# Generated at 2022-06-12 16:49:22.963224
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    import tempfile
    import shutil
    import os.path

    from ..extractor import gen_extractors

    # Base class for all fragment downloaders tests
    class FragTest(unittest.TestCase):
        def setUp(self):
            # Standard dummy values for all tests
            self.FD_NAME = 'test-fd'
            self.ydl = gen_extractors()[self.FD_NAME](dict())
            self.ydl.params['noprogress'] = True
            self.ydl.to_screen = lambda *x: self.fail('Unexpected call to to_screen(): %r' % x)
            self.ydl.report_warning = lambda msg: self.fail('Unexpected call to report_warning: %r' % msg)
            self.temp_dir = temp

# Generated at 2022-06-12 16:49:36.448762
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def _run_test(url, expected_count):
        downloader = FragmentFD(None, {})
        parts = list(downloader._calc_frag_count(url))
        assert len(parts) == expected_count, 'Expected %d parts, got %d' % (expected_count, len(parts))
        for index, part in enumerate(parts):
            assert part['index'] == index


# Generated at 2022-06-12 16:49:49.800602
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Arguments passed to constructor
    self = object()
    ie_kwargs = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': 'ratelimit',
        'retries': 'retries',
        'nopart': 'nopart',
        'test': 'test'
    }

    # Expected values in instance
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': 'ratelimit',
        'retries': 'retries',
        'nopart': 'nopart',
        'test': 'test'
    }
    ydl = self

    # Call constructor

# Generated at 2022-06-12 16:49:57.214895
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from . import YoutubeDL
    from .extractor.youtube import YoutubeIE
    ydl = YoutubeDL({'quiet': True})
    ies = ydl.get_info_extractors()
    for ie in ies:
        for ie_name in ie.ie_keywords:
            if ie_name == 'youtube':
                assert isinstance(ie, HttpQuietDownloader)
                assert isinstance(ie, YoutubeIE)
            else:
                assert not isinstance(ie, HttpQuietDownloader)
                assert not isinstance(ie, YoutubeIE)

# Generated at 2022-06-12 16:50:04.358207
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import youtube_dl.FileDownloader
    import youtube_dl.extractor.common
    ydl = youtube_dl.FileDownloader.FileDownloader()
    info_dict = {'url': 'http://www.example.com', 'title': 'TestTitle'}
    ydl.add_info_extractor(youtube_dl.extractor.common.InfoExtractor('test_ie', 'TestIE', {}))
    ydl.params['noprogress'] = True
    ie = ydl._ies[0]
    fd = FragmentFD(ydl, ie, info_dict)
    assert fd.FD_NAME == 'TestIE'
    assert fd.ytdl_filename('a') == 'a.ytdl'

# Generated at 2022-06-12 16:50:05.635617
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    h = HttpQuietDownloader(None, {})
    assert h


# Generated at 2022-06-12 16:50:12.111431
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..postprocessor import run_postprocessors
    from ..compat import compat_kwargs
    # Constructor of class FileDownloader should not raise any exception
    # (avoid crashes on unknown info extractors)
    FragmentFD(
        get_info_extractor('no-such-extractor'),
        {},
        match_filter_func('abc'),
        run_postprocessors,
        compat_kwargs({}))

# Generated at 2022-06-12 16:50:20.444554
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader(
        None,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'nopart': True,
            'test': True,
        }
    ).params == {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'retries': 0,
        'nopart': True,
        'test': True,
    }

# Generated at 2022-06-12 16:50:29.339975
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MockYDL():
        def __init__(self):
            self.params = {}

    ydl = MockYDL()
    fd = FragmentFD(ydl, {})
    assert fd.params['retries'] == 0
    assert fd.params['keep_fragments'] is False
    assert fd.FD_NAME == 'fragment'
    assert not fd.__do_ytdl_file({})
    assert fd.__do_ytdl_file({'tmpfilename': '-'})

# Generated at 2022-06-12 16:50:34.110584
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    fd = HttpQuietDownloader(ydl, {'continuedl': True})
    assert isinstance(fd, HttpFD)
    assert fd.params['continuedl'] is True

# Generated at 2022-06-12 16:51:00.452209
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = MockYoutubeDl()
    hqd = HttpQuietDownloader(
        ydl, {'continuedl': True, 'noprogress': True, 'quiet': True})
    assert hqd.ydl == ydl
    assert isinstance(hqd.params, dict)
    assert hqd.params == {
        'continuedl': True, 'noprogress': True, 'quiet': True}

# Generated at 2022-06-12 16:51:09.907398
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = object()
    params = {
        'continuedl' : True,
        'quiet' : True,
        'noprogress' : True,
        'ratelimit' : 'ratelimit',
        'retries' : 'retries',
        'nopart' : 'nopart',
        'test' : 'test'
    }
    result = HttpQuietDownloader(ydl, params)
    assert result.ydl == ydl
    assert result.params['continuedl'] == params['continuedl']
    assert result.params['noprogress'] == params['noprogress']
    assert result.params['quiet'] == params['quiet']
    assert result.params['ratelimit'] == params['ratelimit']
    assert result.params['retries'] == params['retries']
   

# Generated at 2022-06-12 16:51:11.760590
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # TODO: test constructor of class HttpQuietDownloader
    pass

# Generated at 2022-06-12 16:51:24.947245
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from .common import FileDownloader
    class DummyFD(FileDownloader):
        def __init__(self, ydl, params):
            super(DummyFD, self).__init__(ydl, params)
            self.to_screen = lambda *args, **kargs: None

    params = {
        'username': 'user',
        'password': 'pass',
    }

    fd = get_info_extractor('FragmentFD')(DummyFD(None, params), params)
    assert fd.params.get('username') == 'user'
    assert fd.params.get('password') is None
    assert fd.params.get('usenetrc') is True


# Generated at 2022-06-12 16:51:35.439261
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from ..extractor import get_info_extractor
    ydl = get_info_extractor('YoutubeIE')
    dl = HttpQuietDownloader(
        ydl,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': ydl.params.get('ratelimit'),
            'retries': ydl.params.get('retries', 0),
            'nopart': ydl.params.get('nopart', False),
            'test': ydl.params.get('test', False),
            'outtmpl': '%(id)s.%(ext)s',
        }
    )
    dl.download(sys.stdout, {'url': 'http://example.org'})

# Generated at 2022-06-12 16:51:37.891431
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader(None, None)

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:51:39.899131
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, object)



# Generated at 2022-06-12 16:51:40.699370
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass

# Generated at 2022-06-12 16:51:49.630280
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    # test invalid parameter
    try:
        fd = FragmentFD(get_info_extractor('youtube'), {'invalid_param': 42})
        assert False, 'Instantiating FragmentFD with invalid parameter did not fail!'
    except TypeError:
        pass

    # test valid parameter
    fd = FragmentFD(get_info_extractor('youtube'), {'keep_fragments': True})
    assert fd.params['keep_fragments'] is True

# Generated at 2022-06-12 16:51:55.062834
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .extractor import gen_extractors

    assert FragmentFD.__name__ == 'FragmentFD'
    # Check that FragmentFD is not in the list of known extractors
    assert FragmentFD not in gen_extractors()

    assert not hasattr(FragmentFD, '_download_fragment')
    assert not hasattr(FragmentFD, '_append_fragment')
    assert not hasattr(FragmentFD, '_start_frag_download')
    assert not hasattr(FragmentFD, '_finish_frag_download')

# Generated at 2022-06-12 16:52:32.870212
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import unittest
    class Test(unittest.TestCase):
        def setUp(self):
            self.downloader = HttpQuietDownloader(None)

    unittest.main(argv=['', 'Test'])

# Generated at 2022-06-12 16:52:37.821049
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import tempfile
    import json

    ydl = DummyYDL()
    params = {
        'continuedl': True,
        'quiet': True,
        'ratelimit': '1M',
        'noprogress': True,
        'retries': 0,
        'nopart': False,
        'proxy': None,
        'socket_timeout': None,
        'test': False,
        'prefer_insecure': False,
        'force_generic_extractor': False
    }
    dl = HttpQuietDownloader(ydl, params)

    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.write(b'1')
    test_file.close()

    info = {'url': 'http://localhost:9999/'}

   

# Generated at 2022-06-12 16:52:39.308056
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {})
    assert fd is not None

# Generated at 2022-06-12 16:52:45.506167
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ytdl.YoutubeDL import YoutubeDL
    YoutubeDL({
        'proxy': '127.0.0.1:8118',
        'fragment_retries': 5,
        'skip_unavailable_fragments': False,
    })

# Generated at 2022-06-12 16:52:49.692371
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-12 16:52:59.707889
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    from .http import HttpFD
    import urlparse


# Generated at 2022-06-12 16:53:03.339366
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-12 16:53:13.520050
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert FragmentFD.__bases__ == (FileDownloader,)

    # pylint: disable=W0212
    fd = FragmentFD({
        'params': {
            'ratelimit': 1048576,
            'retries': 10,
            'nopart': True,
            'keep_fragments': False,
            'test': False,
            'noprogress': False,
        },
    })
    assert fd.ratelimit == 1048576
    assert fd.retries == 10
    assert fd.nopart is True
    assert fd.keep_fragments is False
    assert fd.test is False
    assert fd.noprogress is False

# Generated at 2022-06-12 16:53:18.354455
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .http import HttpDownloader

    ydl = gen_extractors()
    h = HttpQuietDownloader(ydl, {})
    assert isinstance(h, HttpDownloader)

# Generated at 2022-06-12 16:53:24.695285
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = {}
    params = {
        'buffer_size': 8192,  # bytes
    }
    fd = FragmentFD(ydl, params)
    assert(isinstance(fd, FragmentFD))
    assert(fd.buffer_size == 8192)
    assert(fd.ydl is not None)
    assert(fd.params is not None)

# Generated at 2022-06-12 16:54:46.190925
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {}, None)  # FileDownloader object is not used here
    assert isinstance(fd, FragmentFD)

# Generated at 2022-06-12 16:54:54.942382
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from ..utils import match_filter_func

    class FakeFD(FragmentFD):
        FD_NAME = 'fake'

    fd = FakeFD(None, {
        'format': 'bestvideo[height<=1080]+bestaudio/best',
        'outtmpl': '%(id)s.%(ext)s',
        'writedescription': True,
        })
    assert fd.params['simulate'] is False
    assert fd.params['format'] == 'bestvideo[height<=1080]+bestaudio/best'
    assert fd.params['outtmpl'] == '%(id)s.%(ext)s'
    assert fd.params['writedescription'] is True
    assert fd.params['ignoreerrors'] is False

# Generated at 2022-06-12 16:55:04.775323
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange

    class FragmentFDTest(unittest.TestCase):
        def setUp(self):
            self.dummy_ydl = YoutubeDL({
                'writedescription': False,
                'writeinfojson': False,
                'writesubtitles': False,
                'writeautomaticsub': False,
                'skip_download': True,
                'quiet': True,
            })
            self.fd = FragmentFD(self.dummy_ydl)

        def tearDown(self):
            self.fd = None


# Generated at 2022-06-12 16:55:16.833017
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..utils import DateRange
    from .dash import DASHFD
    from .hls import HLSFD
    from .fragment import FragmentFD

    params = {
        'format': '137+140/bestaudio/best',
        'fragment_retries': 15,
        'skip_unavailable_fragments': True,
    }


# Generated at 2022-06-12 16:55:21.680742
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.extractor.http
    # HttpQuietDownloader should be a subclass of
    # youtube_dl.downloader.http.HttpDownloader
    assert issubclass(HttpQuietDownloader, youtube_dl.downloader.http.HttpDownloader)
    # Check if to_screen is overridden
    http_quiet_downloader = HttpQuietDownloader({}, {})
    assert http_quiet_downloader.to_screen != youtube_dl.downloader.http.HttpDownloader.to_screen

# Generated at 2022-06-12 16:55:26.219520
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import unittest

    class TestHttpQuietDownloader(unittest.TestCase):
        def setUp(self):
            self.ydl = object()
            self.params = {
                'continuedl': True,
                'quiet': True,
                'noprogress': True,
                'ratelimit': None,
                'nopart': False,
                'test': False,
                'retries': 0,
            }

        def test_constructor(self):
            dl = HttpQuietDownloader(self.ydl, self.params)
            self.assertTrue(dl)

    unittest.main()

# Generated at 2022-06-12 16:55:35.693976
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class TestYDL(object):
        def add_info_extractor(self, ie):
            pass
    ydl = TestYDL()
    params = {
        'quiet': True,
    }
    dl = HttpQuietDownloader(ydl, params)
    assert dl.ydl == ydl
    assert dl.params == params
    assert dl._ydl_is_old_style
    assert dl._outtmpl == '-'
    assert dl._trouble is None


# Tests for the FileDownloader class

# Generated at 2022-06-12 16:55:37.713533
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-12 16:55:40.016075
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from . import YoutubeDL
    HttpQuietDownloader(YoutubeDL(), {'noprogress': True, 'progress_with_newline': True})

# Generated at 2022-06-12 16:55:41.609809
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Must not raise an exception:
    HttpQuietDownloader(None, {})