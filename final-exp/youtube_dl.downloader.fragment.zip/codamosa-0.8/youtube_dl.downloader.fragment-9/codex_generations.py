

# Generated at 2022-06-12 16:49:18.034753
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def _dummy_download(filename, info):
        return True

    from .options import Options
    from .extractor import gen_extractors

    gen_extractors()
    ydl = FileDownloader(Options({}))
    ydl.add_info_extractor(type('DummyIE', (object,), {
        '_VALID_URL': r'.*',
        '_WORKING': True,
        '_download_webpage': lambda self, url, *args, **kargs: 'webpage',
        '_real_extract': lambda self, url: {
            'id': 'id',
        },
    })())
    fd = FragmentFD(ydl, {
        'filename': 'filename',
        'fragment_count': 3,
    })
    fd.to_screen

# Generated at 2022-06-12 16:49:25.257481
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader

    # pylint: disable=protected-access
    assert not FileDownloader._is_fragment_retry(23)

    # pylint: disable=protected-access
    assert FileDownloader._is_fragment_retry(23, fragment_index=2)

    # pylint: disable=protected-access
    assert not FileDownloader._is_fragment_retry(23, fragment_index=23)

    # pylint: disable=protected-access
    assert not FileDownloader._is_fragment_retry(23, fragment_index=24)

# Generated at 2022-06-12 16:49:29.483748
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert HttpQuietDownloader.__init__ is not HttpFD.__init__

# Generated at 2022-06-12 16:49:33.538700
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)
    fd = FragmentFD('a', {}, {})
    assert fd.fd is None
    assert fd.param

# Generated at 2022-06-12 16:49:37.729491
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params

    ydl = FakeYDL({'quiet': False})
    params = {'quiet': True}
    dl = HttpQuietDownloader(ydl, params)
    assert dl.params == params
    assert dl.ydl == ydl
    assert sys.getrefcount(ydl) == 3
    dl = None
    assert sys.getrefcount(ydl) == 2

# Generated at 2022-06-12 16:49:48.365804
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from collections import namedtuple
    FakeInfoDict = namedtuple('FakeInfoDict', ['url', 'http_headers'])

    url = 'http://example.com/1'
    info_dict = FakeInfoDict(url, None)
    x = HttpQuietDownloader(None, {})
    x._prepare_url(info_dict, url)

    headers = {'referer': 'http://example.com'}
    info_dict = FakeInfoDict(url, headers)
    x = HttpQuietDownloader(None, {})
    x._prepare_url(info_dict, url)

# Generated at 2022-06-12 16:49:56.104522
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = None
    params = {
        'retries': 3,
        'nopart': False,
        'test': True,
        'keep_fragments': False,
        'updatetime': True,
    }
    fd = FragmentFD(ydl, params)
    assert fd.params['retries'] == 3
    assert fd.params['nopart'] == False
    assert fd.params['test'] == True
    assert fd.params['keep_fragments'] == False
    assert fd.params['updatetime'] == True

# Generated at 2022-06-12 16:50:01.327488
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {}
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 20,
        'nopart': False,
        'test': False,
    }
    dl = HttpQuietDownloader(ydl, params)
    assert dl._params == params

# Generated at 2022-06-12 16:50:03.523479
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    ie = InfoExtractor()
    fd = FragmentFD(ie, {}, None, None, None)
    assert fd.FD_NAME == 'fragment'

# Generated at 2022-06-12 16:50:06.580948
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import io
    from .http import HttpFD

    io.StringIO = io.BytesIO
    d = HttpQuietDownloader(None, {})
    assert isinstance(d, HttpFD)

# Generated at 2022-06-12 16:50:38.323675
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import YoutubeDL

    ydl = YoutubeDL({'noprogress': True})
    ydl.add_info_extractor(FragmentFD(ydl, {'noprogress': True}))
    d = ydl.prepare_filename('foo')
    assert d['status'] == 'error'
    assert d['exc_info'][0] == AssertionError

    class MyFragmentFD(FragmentFD):
        def __init__(self, ydl, params):
            super(MyFragmentFD, self).__init__(ydl, params)
            FragmentFD.__init__(self, ydl, params)

        def real_download(self, filename, info_dict):
            info_dict['tmpfilename'] = filename
            info_dict['filename'] = 'bar'
            info_dict

# Generated at 2022-06-12 16:50:46.444723
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from ..compat import compat_urllib_request

    url = 'http://127.0.0.1:443/'
    dest = '-'
    params = {'continuedl': True, 'noprogress': True, 'retries': 0}
    headers = {'User-Agent': 'Test'}

    http_dl = HttpQuietDownloader(
        gen_extractors(), params)
    req = http_dl._prepare_request(url, headers=headers)

    assert req.full_url == url
    assert req.headers['User-Agent'] == 'Test'
    assert req.get_method() == 'GET'

    data = compat_urllib_request.urlopen(req)
    assert data.info().get('X-Test')

# Generated at 2022-06-12 16:50:59.424254
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import youtube_dl

    def error_fatal_debug(self, msg):
        self.to_stderr(msg)

    class DummyYDL(youtube_dl.YoutubeDL):
        def __init__(self, *args, **kwargs):
            youtube_dl.YoutubeDL.__init__(self, *args, **kwargs)
            self.params['format'] = '0'

    ydl = DummyYDL({'noprogress': True})
    fd = FragmentFD(ydl, {'retries': 0})
    sys.modules['__main__'].error_fatal_debug = error_fatal_debug
    fd.report = lambda *args, **kwargs: None
    fd.report_destination = lambda *args, **kwargs: None


# Generated at 2022-06-12 16:51:02.953798
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'
    assert HttpQuietDownloader.__module__ == 'youtube_dl.downloader.http'
    assert hasattr(HttpQuietDownloader, 'to_screen')
test_HttpQuietDownloader()

# Generated at 2022-06-12 16:51:05.139689
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader({}, {})

# Generated at 2022-06-12 16:51:11.453857
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class FakeYDL(object):
        def __init__(self):
            self.params = {}

        def to_screen(self, *args, **kargs):
            pass

    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {'continuedl': True, 'quiet': True})
    assert dl.ydl is ydl
    assert dl.params == ydl.params

# Generated at 2022-06-12 16:51:24.757858
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # The code of this test is based on the code of
    # YoutubeDLHandler.test_partial_download()
    #
    # NOTE: in order to run this test all the condition inside
    # YoutubeDLHandler.test_partial_download() should be true

    import BaseHTTPServer
    import socket
    from .common import FileDownloader

    from ..utils import (
        encodeFilename,
    )
    from ..extractor import gen_extractors

    from .http import HttpQuietDownloader

    class PartialHTTPRequestHandler(BaseHTTPServer.BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'

        def do_HEAD(self):
            self.send_response(200)
            self.send_header('Content-Type', 'video/webm')

# Generated at 2022-06-12 16:51:35.300244
# Unit test for constructor of class FragmentFD

# Generated at 2022-06-12 16:51:40.165296
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    r = sanitized_Request('http://example.org/')
    dl = HttpQuietDownloader(youtube_dl.YoutubeDL({}), {})
    resp = dl.urlopen(r)
    assert resp.code == 200

# Generated at 2022-06-12 16:51:44.743721
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = None
    options = {'continuedl': True}
    HttpQuietDownloader(ydl, options)

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:52:09.759902
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def fd_constructor(self, *args, **kwargs):
        FileDownloader.__init__(self, *args, **kwargs)

    fragmentfd_instance = FragmentFD()
    assert isinstance(fragmentfd_instance, FileDownloader)

# Generated at 2022-06-12 16:52:21.645369
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    class FragmentFDTestIE(InfoExtractor):
        IE_NAME = 'FragmentFDTest'
        def report_warning(self, message):
            pass
        def _download_webpage(self, url, *args, **kargs):
            return {'id': '1234567890', 'title': 'Test Video'}, url
        def _real_extract(self, url):
            info = {'id': '1234567890', 'extractor': 'FragmentFDTest', 'title': 'Test Video'}
            return [{'url': url, 'ie_key': 'FragmentFDTest', 'info_dict': info}]
    ydl = {'params': {}}
    ie = FragmentFDTestIE(ydl)
    res = ie._real_ext

# Generated at 2022-06-12 16:52:28.335008
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .downloader import gen_extractor_downloaded, get_suitable_downloader
    from .common import FileDownloader
    from .http import HttpFD
    you_get_classes = gen_extractor_classes()
    you_get_downloaded = gen_extractor_downloaded(you_get_classes)
    suitable_downloader = get_suitable_downloader(you_get_downloaded, you_get_classes)
    you_get_classes['YouTubePlaylistIE'] = [suitable_downloader['youtube']]
    you_get_classes['YouTubePlaylistBaseInfoExtractor'] = [suitable_downloader['youtube']]
    you_get_classes['GenericIE'] = [suitable_downloader['http']]

# Generated at 2022-06-12 16:52:39.830025
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import TestFD
    fd = FragmentFD(TestFD())
    assert fd.params == {}
    assert fd.keep_fragments is False
    assert fd.skip_unavailable_fragments is False
    assert fd.retries == 0

    fd = FragmentFD(TestFD(), {
        'keep_fragments': True,
        'skip_unavailable_fragments': True,
        'retries': 1,
    })
    assert fd.params == {
        'keep_fragments': True,
        'skip_unavailable_fragments': True,
        'retries': 1,
    }
    assert fd.keep_fragments is True
    assert fd.skip_unavailable_fragments is True

# Generated at 2022-06-12 16:52:54.639756
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import (
        gen_extractors,
        mk_extractors_info_dict
    )
    def create_download_context(live=False):
        return {
            'extractor':
                mk_extractors_info_dict(
                    gen_extractors()).get('FragmentFD', {}),
            'filename': 'file.mp4',
            'url': 'url',
            'total_frags': 4,
            'ad_frags': 2,
            'frag_index': 3,
            'live': live
        }

    downloader = FragmentFD(
        None,
        create_download_context(),
        { 'retries': 42 }
    )
    assert downloader.params.get('retries') == 42

    # Check for normal behavior of constructor
    download

# Generated at 2022-06-12 16:53:07.373419
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    import tempfile
    import os
    import shutil
    import json

    fd = FragmentFD()

    url = 'https://www.youtube.com/watch?v=_HSylqgVYQI'
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 16:53:15.853523
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def hook(d):
        if d['status'] == 'finished':
            raise KeyboardInterrupt()
    params = {
        'format': '135',
        'progress_hooks': [hook],
    }
    ydl = FakeYDL()
    frag_fd = FragmentFD(ydl, params)

# Generated at 2022-06-12 16:53:28.047433
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .downloader import FileDownloader
    import sys
    import os

    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    out = StringIO()
    ydl = FileDownloader({'outtmpl': '-'}, params={}, auto_init=False)
    ydl.add_default_info_extractors()
    ydl._setup_opener()

    def report_hook(d):
        if d['status'] == 'finished':
            print('Done downloading, now converting ...')

    # go to test dir

    MY_PATH = os.path.abspath(os.path.dirname(__file__))
    os.chdir(os.path.join(MY_PATH, 'fragment_test'))

    return

# Generated at 2022-06-12 16:53:36.797527
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # Constructor of class FragmentFD is not used so far.
    # In order to test this class we need to create its instance.
    # Tested code calls self.to_screen method, so we need to
    # set it to something callable
    class FakeYDL:
        def to_screen(self, *args, **kwargs):
            pass
    assert 'skip_unavailable_fragments' not in FragmentFD.params
    assert 'fragment_retries' not in FragmentFD.params
    assert 'keep_fragments' not in FragmentFD.params
    fd = FragmentFD(FakeYDL()).__class__()
    fd.params['fragment_retries'] = 10
    assert fd.params['fragment_retries'] == 10

# Generated at 2022-06-12 16:53:49.347042
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from types import MethodType
    import sys

    class FakeYDL(object):
        pass

    FakeYDL.params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'version': False,
        'nooverwrites': False,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
        'outtmpl': u'%(id)s'
    }

    FakeYDL.to_screen = MethodType(lambda ydl, *args, **kargs: sys.stdout.write('FakeYDL.to_screen was called\n'), FakeYDL)

    HttpQuietDownloader(FakeYDL)


# Generated at 2022-06-12 16:54:17.235010
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    sys.modules['__main__'].params = {}
    inst = HttpQuietDownloader(None, {'continuedl': True})
    assert 'continuedl' in inst.params


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:54:24.937205
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        def _real_extract(self, url):
            return {'id': 'test', 'url': url}
    ie = TestIE(downloader=HttpQuietDownloader(
        TestIE(None), {'quiet': True, 'noprogress': True}))
    ie.download('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-12 16:54:34.319112
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import DateRange
    extractors = gen_extractors()
    fd = FragmentFD(
        extractors['youtube'], {}, 'f4m', 'test', {
            'noprogress': True, 'quiet': True, 'ratelimit': 1024,
            'retries': 10, 'player_params': {'hls_prefer_native': True}})
    assert fd.FD_NAME == 'f4m'
    assert fd.params['noprogress'] is True
    assert fd.params['quiet'] is True
    assert fd.params['ratelimit'] == 1024
    assert fd.params['retries'] == 10
    assert fd.params['player_params']['hls_prefer_native'] is True
   

# Generated at 2022-06-12 16:54:40.433673
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=W0212
    assert len(HttpQuietDownloader._print_info_dict.__defaults__) == 2
    dl = HttpQuietDownloader(None, {})
    assert len(dl._print_info_dict.__defaults__) == 2
    dl = HttpQuietDownloader(None, {'quiet': True})
    assert len(dl._print_info_dict.__defaults__) == 2
    dl = HttpQuietDownloader(None, {'verbose': True})
    assert len(dl._print_info_dict.__defaults__) == 2
    dl = HttpQuietDownloader(None, {'quiet': True, 'verbose': True})
    assert len(dl._print_info_dict.__defaults__) == 2


# Generated at 2022-06-12 16:54:50.999097
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import io

    class TDownloader(object):
        pass

    class TYDL(object):
        downloader = TDownloader()

    t_ydl = TYDL()
    t_ydl.downloader.report_destination = lambda *x: sys.stdout.write('report_destination: ' + repr(x) + '\n')
    t_ydl.downloader.to_screen = lambda *x: sys.stdout.write('to_screen: ' + repr(x) + '\n')
    t_ydl.downloader.report_warning = lambda *x: sys.stdout.write('report_warning: ' + repr(x) + '\n')

# Generated at 2022-06-12 16:55:01.609356
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class FakeYDL(object):
        def __init__(self):
            self.params = {}

    class FakeInfoDict(object):
        def __init__(self):
            self.http_headers = {'test': 'yes'}

    fake_ydl = FakeYDL()
    fake_info_dict = FakeInfoDict()
    loader = HttpQuietDownloader(
        fake_ydl,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'retries': 1,
            'prefer_insecure': True,
            'socket_timeout': 5,
            'test': True,
            'nocheckcertificate': True,
        }
    )
    loader.test(False, fake_info_dict)

# Generated at 2022-06-12 16:55:03.524279
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(object, dict(params=dict(noprogress=True, format='m3u8_native')))
    assert fd

# Generated at 2022-06-12 16:55:04.796363
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader('youtube-dl', {})

# Generated at 2022-06-12 16:55:14.411010
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(object(), dict(noprogress=True))
    assert fd.params['noprogress'] is True
    assert fd.params.get('continuedl', False) is True
    assert fd.params.get('quiet', False) is True
    assert fd.params.get('nopart', False) is True
    assert fd.params.get('test', False) is True
    assert fd.params.get('retries', 0) == 0

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:55:22.202772
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """Make sure that HttpQuietDownloader is really quiet"""
    from io import StringIO
    from .common import FileDownloader

    class MyLogger:
        @staticmethod
        def debug(msg):
            pass

        @staticmethod
        def warning(msg):
            pass

        @staticmethod
        def error(msg):
            pass

        @staticmethod
        def to_screen(msg, skip_eol=False):
            pass

    class MyFD(FileDownloader):
        def to_screen(self, *args, **kargs):
            pass

        def report_progress(self, *args, **kargs):
            pass

    out = StringIO()

    dl = HttpQuietDownloader(MyFD({'logger': MyLogger()}), {'outtmpl': out})
    dl

# Generated at 2022-06-12 16:56:13.211462
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import get_info_extractor

    def download(ie, url):
        ie = get_info_extractor(ie)()

        dl = HttpQuietDownloader(None, {'continuedl': True, 'quiet': True, 'noprogress': True})
        return dl.download(ie, {'url': url})

    assert download('GenericIE', 'https://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-12 16:56:15.048567
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        def report_progress(self):
            pass
    TestFD({})

# Generated at 2022-06-12 16:56:17.864379
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.params = {}
    fd = FragmentFD(ie, None, 'test-frag.f4m', {})
    assert fd.FD_NAME == 'test-frag.frag'

# Generated at 2022-06-12 16:56:20.056451
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({'quiet': True})
    HttpQuietDownloader(ydl, {})

# Generated at 2022-06-12 16:56:28.149740
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_quiet_downloader = HttpQuietDownloader({})
    assert http_quiet_downloader.ydl is not None
    assert http_quiet_downloader.params is not None
    assert http_quiet_downloader.params['quiet'] is True
    assert http_quiet_downloader.params['continuedl'] is True
    assert http_quiet_downloader.params['noprogress'] is True
    assert http_quiet_downloader.params['nopart'] is False
    assert http_quiet_downloader.params['test'] is False


# Generated at 2022-06-12 16:56:32.059942
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from . import YoutubeDL
    ydl = YoutubeDL()
    fd = HttpQuietDownloader(ydl, {'continuedl': True})
    assert fd.params['continuedl'] == True


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:56:37.233422
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor.common import InfoExtractor
    try:
        ies = InfoExtractor.get_info_extractors()
    except TypeError:
        # python < 2.7.5
        ies = InfoExtractor.ies
    ie = ies[0]()
    dl = HttpQuietDownloader(ie, {'verbose': False})
    assert dl.ydl.parameters['verbose'] == False
    dl = HttpQuietDownloader(ie, {'verbose': True})
    assert dl.ydl.parameters['verbose'] == True


# Generated at 2022-06-12 16:56:39.604182
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        from collections import namedtuple
    except ImportError:
        return

    Ydl = namedtuple('Ydl', ('params',))
    ydl = Ydl({})
    hqd = HttpQuietDownloader(ydl, {})
    assert hqd.parameters['quiet']

# Generated at 2022-06-12 16:56:42.028390
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD({}, {})
    assert 'fragment' in fd.ie_key()
    assert 'id' in fd.ie_key()

# Generated at 2022-06-12 16:56:54.715537
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    gen_extractors()  # Load all extractors
    ydl = {}
    params = {
        'cachedir': False,
        'noprogress': True,
        'nooverwrites': True,
        'quiet': True,
        'simulate': True,
        'forcetitle': True,
        'forceurl': True,
        'forcethumbnail': True,
        'forcedescription': True,
        'forcefilename': True,
        'forcejson': True,
        'dump_single_json': True,
        'outtmpl': '%(id)s',
    }
    # Here we test the constructor of HttpQuietDownloader class
    dl = HttpQuietDownloader(ydl, params)
    assert dl

# Generated at 2022-06-12 16:58:11.993615
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    from .http import HttpFD
    import pprint
    pp = pprint.PrettyPrinter(indent=4)
    FileDownloader.params = {}
    fd = HttpQuietDownloader({'format': 'best'}, {'continuedl': True})
    pp.pprint(fd.__dict__)
    pp.pprint(fd.params.__dict__)
    pp.pprint(HttpFD.__dict__)
# End of unit test

# Generated at 2022-06-12 16:58:19.922111
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import unittest
    import sys

    sys.modules['__main__'].params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'retries': 0,
        'nopart': False,
        'test': False,
    }
    sys.modules['__main__'].to_screen = lambda *args, **kargs: 0

    # test verbose flag
    class options: verbose = True
    http_dl = HttpQuietDownloader(options)
    assert http_dl.params['noprogress'] == False

    # test retries
    class options:
        verbose = False
        retries = 3
    http_dl = HttpQuietDownloader(options)
    assert http_dl.params['retries'] == 3

# Generated at 2022-06-12 16:58:22.288543
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    hqd = HttpQuietDownloader(None, {})
    assert hqd.params['quiet']

# Generated at 2022-06-12 16:58:33.786241
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import io
    import sys
    from ..utils import std_headers

    class params:
        proxy = None
        noprogress = True
        quiet = True
        retries = 0
        ratelimit = None
        test = None
    class ydl:
        params = params

    class Hook:
        def __init__(self, code, content):
            self.code = code
            self.content = content
        def __call__(self, *args, **kargs):
            return {'status': self.code, 'downloaded_bytes': self.content}

    def my_urlopen(*args, **kargs):
        class Out:
            def __init__(self, content):
                self.content = content
            def read(self):
                return self.content
            def close(self):
                pass
        code

# Generated at 2022-06-12 16:58:41.219448
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys

# Generated at 2022-06-12 16:58:47.369240
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    import tempfile
    import shutil

    class ConstructorTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.test_dir)

        def test_ytdl_file_is_created(self):
            from .fragment import FragmentFD

            class TestFD(FragmentFD):
                @staticmethod
                def ytdl_filename(name):
                    return name + '.ytdl'

            test_fd = TestFD({}, None)
            tmpfilename = os.path.join(self.test_dir, 'test-file')
            ctx = {
                'filename': tmpfilename,
            }
            test_fd._prepare_frag