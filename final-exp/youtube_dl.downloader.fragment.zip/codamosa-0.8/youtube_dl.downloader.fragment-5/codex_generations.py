

# Generated at 2022-06-12 16:49:26.516619
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():

    filename = 'test'
    ext = 'mp4'
    title = 'test video'
    ydl = mock.Mock()
    ydl.params = {}
    ydl.prepare_filename.return_value = filename

    info_dict = {
        'id': 'test',
        'ext': ext,
        'title': title,
        'url': 'https://www.test.com/test.mp4',
    }
    http_dl = HttpQuietDownloader(ydl, info_dict)

    assert http_dl.ydl == ydl
    assert http_dl.params == ydl.params
    assert http_dl.info_dict == info_dict

# Generated at 2022-06-12 16:49:38.970702
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class TestYDL(object):
        def __init__(self, dictionaries):
            self.dictionaries = dictionaries

        def add_info_extractor(self, ie, *args):
            pass


# Generated at 2022-06-12 16:49:51.814363
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    class MockIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'mockid',
                'title': 'mocktitle',
                'ext': 'mockext',
                'url': url,
                'extractor': 'mockextractor',
                'thumbnail': 'mockthumbnail',
                'description': 'mockdescription',
                'upload_date': '20130101',
                'uploader': 'mockuploader',
                'uploader_id': 'mockuploaderid',
                'age_limit': 0,
                'subtitles': None,
                'formats': [],
            }
    ie = MockIE()
    ydl = FileDownloader({}, ie)


# Generated at 2022-06-12 16:49:53.619377
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """Verify whether HttpQuietDownloader class construction works"""
    HttpQuietDownloader(None, None)

# Generated at 2022-06-12 16:50:00.716973
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def test(retries, expected_retries):
        params = {'retries': retries}
        ydl = FakeYDL({'retries': retries})
        fd = FragmentFD(ydl, {'url': 'x'}, params)
        assert fd.params['retries'] == expected_retries
    for retries in [0, 1, 2, 5, None]:
        test(retries, retries)
    for inv_retries in [-1, -20, 'a', '3.14', '0', False, True]:
        test(inv_retries, 0)

# Generated at 2022-06-12 16:50:04.148198
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        FragmentFD(None, None)
    except Exception as err:
        assert False, 'Failed to construct: %s' % str(err)

# Generated at 2022-06-12 16:50:09.179957
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.prepare_filename('http://www.example.com/video.mp4')
    assert ydl.params.get('quiet')


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:50:18.043228
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=protected-access
    assert FragmentFD._match_entry(None) is False
    assert FragmentFD._match_entry(lambda _: None) is False
    assert FragmentFD._match_entry(lambda _: ['None']) is False
    assert FragmentFD._match_entry(lambda _: ['foo', 'bar']) is True
    fd = FragmentFD(None)
    assert fd.FD_NAME == 'fragment'


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:50:19.302158
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None)
    assert fd

# Generated at 2022-06-12 16:50:22.124364
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = type('FakeYDL', (object,), {})
    info_dict = {}
    fd = FragmentFD(ydl, info_dict)
    assert fd

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:50:49.455819
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    # pylint: disable=protected-access
    fragfd_ctor = FragmentFD._ctor
    assert fragfd_ctor.__code__.co_varnames == (
        'self', 'ydl', 'params', 'info_dict')
    assert fragfd_ctor.__code__.co_argcount == 4
    assert (
        'fragment_retries' in fragfd_ctor.__defaults__
        and isinstance(fragfd_ctor.__defaults__[-1], int))
    assert (
        'skip_unavailable_fragments' in fragfd_ctor.__defaults__
        and isinstance(fragfd_ctor.__defaults__[-2], bool))

# Generated at 2022-06-12 16:51:01.965991
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import tempfile
    import sys
    import os.path
    import shutil
    path = tempfile.mkdtemp()

    class MyFD(FragmentFD):
        def __init__(self, ydl, params, filename, info_dict):
            self.ydl = ydl
            self.params = params
            self._filename = filename
            self._info_dict = info_dict

        @staticmethod
        def _make_minimal_ydl(*args, **kargs):
            return None

        def temp_name(self, *args, **kargs):
            return None

        def try_rename(self, *args, **kargs):
            pass

        @staticmethod
        def calc_eta(start, now, total_bytes, downloaded_bytes):
            return None


# Generated at 2022-06-12 16:51:10.829776
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .utils import _yt_filter_url_result

    # Without info dict
    fd = FragmentFD(None, {
        'fragment_retries': 10,
        'skip_unavailable_fragments': True,
    })
    assert fd.params['fragment_retries'] == 10
    assert fd.params['skip_unavailable_fragments'] == True
    assert fd.params['keep_fragments'] == False

    # With info dict
    info_dict = {
        'http_headers': {'Referer': 'http://a.bc/d'},
        'url': 'http://e.fg/h',
    }

# Generated at 2022-06-12 16:51:24.066691
# Unit test for constructor of class FragmentFD

# Generated at 2022-06-12 16:51:26.179368
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, None, None)
    assert isinstance(fd, FragmentFD)

# Generated at 2022-06-12 16:51:30.673579
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import get_info_extractor
    extractor = get_info_extractor('BaseIE')()
    return HttpQuietDownloader(extractor, {'quiet': True, 'noprogress': True})

# Generated at 2022-06-12 16:51:37.913653
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..utils import prepend_extension

    class ConcatFD(FragmentFD):
        FD_NAME = 'concat'

        def __init__(self, ydl, dest_filename, fragments):
            super(ConcatFD, self).__init__(ydl, {
                'fragments': fragments,
                'filename': prepend_extension(dest_filename, 'test'),
                'total_frags': len(fragments),
            })

        def real_download(self, *args, **kwargs):
            return True

    class MockedYDL(object):
        def add_progress_hook(self, hook):
            pass

        def to_screen(self, msg):
            print(msg.encode('utf-8'))


# Generated at 2022-06-12 16:51:46.965111
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .test import get_testcases
    for (message, kargs) in get_testcases(FragmentFD, {}, {'outtmpl': '%(id)s'}):
        # use dummy FileDownloader because it has params attribute
        fd = FileDownloader({}, {}, {})
        try:
            fd = FragmentFD(fd, **kargs)
        except Exception as err:
            print('%s: %s' % (message, error_to_compat_str(err)))

# Generated at 2022-06-12 16:51:51.758392
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .downloader import _parseOpts
    ydl = HttpQuietDownloader(_parseOpts(['--test']))
    # It does not need the parameter 'params'
    assert ydl.params == {'test': True}


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:51:55.197764
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    gen_extractors()
    HttpQuietDownloader(None, None)

# Generated at 2022-06-12 16:52:42.418224
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    try:
        # This can be instantiated
        FragmentFD(
            None,
            {
                'fragment_retries': 1,
                'skip_unavailable_fragments': True,
                'keep_fragments': True,
            }
        )
    except Exception:
        raise AssertionError('You should not be here!')

    # Test proper options validation
    assert FragmentFD(None, {'fragment_retries': '1'}) is None
    assert FragmentFD(None, {'fragment_retries': -1}) is None
    assert FragmentFD(None, {'fragment_retries': 0}) is None

    # -1 can be passed to specify an infinite retry count
    assert FragmentFD(None, {'fragment_retries': -1})

# Generated at 2022-06-12 16:52:45.148835
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..compat import compat_urllib_request
    from .socks import SocksFD

    req = compat_urllib_request.Request('http://example.com')
    c = FragmentFD(SocksFD(), {'noprogress': True}, req)
    assert c.params['noprogress'] is True

# Generated at 2022-06-12 16:52:53.139060
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from test import ytdl_mocks
    ydl = ytdl_mocks.YtdlMock()
    qdl = HttpQuietDownloader(ydl, {})
    assert qdl.ydl is ydl
    assert qdl.params == {}
    assert qdl._opener == ydl.build_opener()
    qdl._sleep(0.01)


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:53:04.766495
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from collections import namedtuple

    Params = namedtuple('Params', 'continuedl quiet noprogress ratelimit retries nopart test')
    params = Params(continuedl=1, quiet=1, noprogress=1, ratelimit='ratelimit', retries='retries', nopart='nopart', test='test')
    ydl = namedtuple('YDL', 'params')
    ydl.params = params

    hqd = HttpQuietDownloader(ydl, {})
    assert hqd.ydl_opts.continuedl == params.continuedl
    assert hqd.ydl_opts.quiet == params.quiet
    assert hqd.ydl_opts.noprogress == params.noprogress
    assert hqd.ydl

# Generated at 2022-06-12 16:53:09.685680
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpQuietDownloader
    from .extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.to_screen = lambda s: s

    # Just check that is doesn't raise any exceptions
    HttpQuietDownloader(ie, {'quiet': True})

# Generated at 2022-06-12 16:53:10.610374
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    return HttpQuietDownloader.__init__

# Generated at 2022-06-12 16:53:11.490648
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # TODO: Add tests
    pass

# Generated at 2022-06-12 16:53:13.402146
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    fd = FragmentFD(None, {}, None)
    assert isinstance(fd, FileDownloader)

# Generated at 2022-06-12 16:53:17.571257
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)
    assert FragmentFD.__bases__ == (FileDownloader,)
    fd = FragmentFD.__new__(FragmentFD)
    assert isinstance(fd, FragmentFD)
    assert isinstance(fd, FileDownloader)
    assert fd.FD_NAME == ''
    assert not fd.params
    assert not fd._hooks


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:53:29.242988
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # TODO: review this test
    import unittest
    import tempfile
    import shutil
    import json
    import os.path
    import sys
    from ..utils import (
        encodeFilename,
        encodeArgument,
        open_workdir
    )
    from ..extractor import gen_extractors

    class FragmentFDTest(unittest.TestCase):
        def setUp(self):
            self.__tempdir = tempfile.mkdtemp()

# Generated at 2022-06-12 16:54:55.080123
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import json
    import types
    import warnings
    from .http import HttpQuietDownloader

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        import argparse

    class FakeYDL(object):

        def __init__(self):
            self.params = {}
            self.add_progress_hook = lambda x: None

    ydl = FakeYDL()
    fd = HttpQuietDownloader(ydl, {'noprogress': False, 'logger': sys.stdout})
    assert isinstance(fd, FileDownloader)
    assert isinstance(fd.ydl, FakeYDL)
    logger = fd.params.pop('logger')
    assert isinstance(json.loads(json.dumps(fd.__dict__)), dict)

# Generated at 2022-06-12 16:54:59.705176
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({})
    http_quiet_downloader = HttpQuietDownloader(ydl, {'continuedl': False})
    assert http_quiet_downloader.params['continuedl'] == False
    assert http_quiet_downloader.ydl == ydl

# Generated at 2022-06-12 16:55:04.488344
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors, ListExtractor

    class FragmentExtractor(FragmentFD, ListExtractor):
        def __init__(self, *args, **kargs):
            ListExtractor.__init__(self, 'FragmentExtractor', *args, **kargs)

    gen_extractors()
    FragmentExtractor(None)

# Generated at 2022-06-12 16:55:12.022209
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    class X(object):
        params = {'noprogress': True, 'ratelimit': 1, 'nopart': False, 'test': False, 'retries': 0}
        ydl = InfoExtractor()
    h = HttpQuietDownloader(X(), {'continuedl': True, 'quiet': True})
    assert h.to_screen.__name__ == 'to_screen'

# Generated at 2022-06-12 16:55:15.177877
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpQuietDownloader
    dl = HttpQuietDownloader(None, {'continuedl': True})
    dl.params = {}
    return dl

# Generated at 2022-06-12 16:55:22.750778
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .test import get_testcases
    from ..postprocessor import FFmpegFixupM3u8PP
    info_dict = {
        'id': 'myid',
        'ext': 'mp4',
        'title': 'mytitle',
        'duration': 10,
        'formats': [{
            'format_id': 'format0',
            'url': 'http://example.org/kajhdfkjashdf',
        }, {
            'format_id': 'format1',
            'url': 'http://example.org/fjkhafjkahf',
        }],
        'fragment_count': 20,
    }

# Generated at 2022-06-12 16:55:24.959926
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = FakeYDL()
    fd = FragmentFD.FragmentFD(ydl)
    assert fd.FD_NAME == 'fragment'

# Generated at 2022-06-12 16:55:27.546829
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    HttpQuietDownloader(HttpFD(), {})



# Generated at 2022-06-12 16:55:31.505240
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = None
    params = {}
    dler = HttpQuietDownloader(ydl, params)

    assert dler.ydl is ydl
    assert dler.params is params

# Generated at 2022-06-12 16:55:37.661637
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(FileDownloader({}))
    assert fd._hook_progress == FileDownloader.hook_progress
    assert fd.params == {}
    assert not fd.progress_hooks
    assert fd.ydl is None
    assert fd.params.get('retries') is None


if __name__ == '__main__':
    test_FragmentFD()