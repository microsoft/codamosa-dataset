

# Generated at 2022-06-12 16:49:08.991695
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert FragmentFD(None, {}) is not None

# Generated at 2022-06-12 16:49:23.142954
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import YoutubeDL
    from ..extractor import get_info_extractor

    ydl = YoutubeDL({
        'outtmpl': '%(id)s%(ext)s',
        'writedescription': True,
        'writeinfojson': True,
        'writethumbnail': True,
        'write_all_thumbnails': True,
        'writesubtitles': True,
        'writedescription': True,
        'writeannotations': True,
        'writeautomaticsub': True,
        'simulate': True,
        'quiet': True,
        'skip_download': True,
    })
    ie = get_info_extractor('youtube')
    ie.extract('http://youtube.com/watch?v=BaW_jenozKc')
    ydl.process_ie_result

# Generated at 2022-06-12 16:49:26.435769
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    hqd = HttpQuietDownloader(None, {'quiet': True})
    assert hqd.quiet == True

# Generated at 2022-06-12 16:49:28.194606
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    f = FragmentFD(None)
    assert isinstance(f, FileDownloader)

# Generated at 2022-06-12 16:49:30.827740
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    fd = FragmentFD(YoutubeDL())

# Generated at 2022-06-12 16:49:40.843543
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=protected-access
    assert FragmentFD()._prepare_url(None, 'http://example.com') == 'http://example.com'
    assert FragmentFD()._prepare_url({'http_headers': {'Foo': 'Bar'}}, 'http://example.com') == sanitized_Request('http://example.com', None, {'Foo': 'Bar'})
    assert FragmentFD()._prepare_url({'http_headers': []}, 'http://example.com') == 'http://example.com'

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:49:42.034088
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(None, {})

# Generated at 2022-06-12 16:49:53.947438
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=W0212
    assert isinstance(FragmentFD._prepare_url(None, 'url'), str)
    ctx = {
        'tmpfilename': 'file',
        'fragment_index': 3,
    }
    assert FragmentFD._prepare_frag_download(None, ctx) is None
    assert ctx['fragment_index'] == 3
    dl = object()
    ctx.update({
        'dl': dl,
        'dest_stream': object(),
    })
    assert FragmentFD._start_frag_download(None, ctx) is None
    ctx['dl'] = None
    ctx['dest_stream'] = None
    FragmentFD._finish_frag_download(None, ctx)

# Generated at 2022-06-12 16:50:04.056454
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import unittest

    from .downloader import HttpFD

    class TestDownloader(unittest.TestCase):
        def setUp(self):
            self.params = {
                'continuedl': True,
                'quiet': True,
                'noprogress': True,
                'ratelimit': 100000,
                'retries': 5,
                'nopart': True,
                'test': True,
            }

    TestDownloader.test_HttpQuietDownloader = lambda self: self.assertIsInstance(
        HttpQuietDownloader(None, self.params), HttpFD)

    return unittest.TestLoader().loadTestsFromTestCase(TestDownloader)

# Generated at 2022-06-12 16:50:09.804094
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class _DummyYDL():
        params = {}
        def dash_el_start(self, *args, **kargs):
            pass
        def dash_el_end(self, *args, **kargs):
            pass
    d = HttpQuietDownloader(_DummyYDL(), {'param': 'value'})
    assert d.params['param'] == 'value'


# Generated at 2022-06-12 16:50:33.710863
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)
    fd = FragmentFD({}, {})
    assert isinstance(fd, FileDownloader)
    assert repr(fd)

# Generated at 2022-06-12 16:50:35.146143
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader(None, {})
    dl.to_screen = lambda x: x

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:50:36.443267
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    pass # TODO: implement

# Generated at 2022-06-12 16:50:41.385878
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpDownloader
    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'testid', 'title': 'testttile'}
    t = TestIE(HttpDownloader())
    t.extract('http://test')

# Generated at 2022-06-12 16:50:46.184157
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Test inheritance
    http_fd = HttpQuietDownloader(None, None)
    assert isinstance(http_fd, FileDownloader)
    assert http_fd.params == {}

    # Test download method
    http_fd = HttpQuietDownloader(None, {'noprogress': True})
    assert http_fd.download("whatever", {}) is False
    assert http_fd.params == {'noprogress': True}
    assert http_fd.ydl is None

# Generated at 2022-06-12 16:50:59.031485
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from test import re

    # Use HLS test video
    ie = get_info_extractor('http://youtu.be/WYo_9GM21ls')
    info = ie.extract('WYo_9GM21ls')
    fd = FragmentFD(None, None)
    info_dict = info['formats'][info['format_id']]['fragment_base_url']
    url = fd._prepare_url(info_dict, info_dict['fragments'][0])

# Generated at 2022-06-12 16:51:03.374683
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class YDL(object):
        def __init__(self, params):
            self.params = params

    params = {'quiet': True}
    ydl = YDL(params)
    dl = HttpQuietDownloader(ydl, params)
    assert not dl._opener.addheaders

# Generated at 2022-06-12 16:51:06.649450
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    sys.argv = ['youtube-dl']
    ydl = FragmentFD(dict(params={}))
    assert ydl

# Generated at 2022-06-12 16:51:19.612161
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.extractor
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD
    from .hlsnative import HLSNativeFD
    from .fragment import DASHFragmentsFD
    from .fragment import HLSFragmentsFD
    from .fragment import HLSNativeFragmentsFD
    ydl = youtube_dl.YoutubeDL({})
    hqd = HttpQuietDownloader(
        ydl,
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'nopart': False,
            'test': False,
        }
    )
    assert isinstance(hqd, HttpFD)

# Generated at 2022-06-12 16:51:23.751390
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)
    fd = FragmentFD(dict())
    assert isinstance(fd, FileDownloader)


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:51:54.484898
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import doctest
    if False:
        def to_screen(*args, **kargs):
            pass
        ydl = type('DummyYDL', (object,), {'to_screen': to_screen})()
        hqd = HttpQuietDownloader(ydl)
        sys.stderr.write('\n')
        sys.stderr.write('Testing for correct progress reporting for HttpQuietDownloader\n')
        sys.stderr.write('  (please wait, this may take a while)\n')
        sys.stderr.write('\n')
        doctest.testmod(hqd)
        sys.stderr.write('\n')
        sys.stderr.write('HttpQuietDownloader: OK\n')


# Generated at 2022-06-12 16:51:59.178766
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    for ie in gen_extractors():
        if 'FragmentFD' in ie.__class__.__name__:
            ie.suitable(None) and ie.__class__(None) and ie.report_warning('')

# Generated at 2022-06-12 16:52:09.842725
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    import sys
    sys.stderr = sys.stdout
    ydl = FileDownloader({})
    fd = FragmentFD(ydl, {})
    assert fd.params['retries'] == 0
    assert fd.params['continuedl']
    assert fd.params['noprogress']
    assert fd.params['nopart'] is False
    assert fd.params['test'] is False
    assert fd.params['ratelimit'] is None
    assert fd.params['keep_fragments'] is False
    assert fd.params['skip_unavailable_fragments'] is False
    assert fd.params['fragment_retries'] == 10

# Generated at 2022-06-12 16:52:21.811427
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import unittest
    # Python 2 and Python 3 compatible mock object
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock
    from collections import namedtuple
    from ytdl.extractor.common import InfoExtractor

    dummy_params = {
        'continuedl': True,
        'ratelimit': None,
        'retries': 0,
        'noprogress': True,
        'quiet': True,
        'nopart': False,
        'test': False
    }
    mock_ydl = MagicMock()
    mock_ydl.params = dummy_params
    test_obj = HttpQuietDownloader(mock_ydl, {'verbose': False})
    test_obj.to_screen

# Generated at 2022-06-12 16:52:28.404886
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Test that HttpQuietDownloader with no arguments creates a default
    # FileDownloader object
    fd_default = HttpQuietDownloader()
    assert fd_default.opts == {}
    assert fd_default.params == {}
    assert fd_default.ydl == None

    # Test that HttpQuietDownloader with arguments creates a FileDownloader
    # object with particular options and params
    fd_args = HttpQuietDownloader(
            {'noprogress': True, 'retries': 1},
            {'ratelimit': 100500, 'retries': 2},
            'ytdl')
    assert fd_args.opts == {'noprogress': True, 'retries': 1}

# Generated at 2022-06-12 16:52:39.912687
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .utils import SearchInfoExtractor
    from .compat import compat_str
    from .downloader.external import ExternalFD
    from .downloader.f4m import F4mFD
    from .downloader.fragment import FragmentFD
    from .downloader.hls import HlsFD
    from .downloader.http import HttpFD
    from .downloader.rtmp import RtmpFD
    from .downloader.srt import SrtFD

    def test_constructor(downloader):
        assert isinstance(downloader.ydl, InfoExtractor)
        assert isinstance(downloader.params, dict)
        assert 'continuedl' in downloader.params
        assert 'quiet' in downloader.params

# Generated at 2022-06-12 16:52:52.028253
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def _fake_download(filename, info_dict):
        return True

    def _fake_hook(status):
        pass

    class FakeYDL(object):
        params = {}
        to_screen = _fake_hook
        to_stderr = _fake_hook
        add_progress_hook = _fake_hook
        temp_name = lambda self, f: f + '.part'
        try_rename = _fake_hook

    # No exception expected
    fd = FragmentFD(FakeYDL(), {'noprogress': True})
    assert fd.params == {'noprogress': True}

# Generated at 2022-06-12 16:53:03.239468
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor.youtube import YoutubeIE
    from .downloader.http import HttpFD
    from .postprocessor import FFmpegMergerPP

    class MockYDL(object):
        def __init__(self):
            self.ies = []
            self.params = {
                'nooverwrites': True,
                'forcefilename': True,
            }

        def add_info_extractor(self, ie):
            self.ies.append(ie)

        def to_screen(self, s):
            print(s)

        def to_stdout(self, s):
            print(s)

        def trouble(self, s, tb=None):
            raise Exception(s)

        def report_error(self, s, tb=None):
            raise Exception(s)


# Generated at 2022-06-12 16:53:07.172490
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    GetInfoExtractor = get_info_extractor('GenericIE')
    ie = GetInfoExtractor()
    fd = FragmentFD(ie)
    assert fd.downloader

# Generated at 2022-06-12 16:53:15.016080
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Instance creation
    d = HttpQuietDownloader({}, {
        'continuedl': False,
        'quiet': True,
        'noprogress': True,
        'hls_use_mpegts': True,
        'preferredcodec': 'mp3',
    })

    # Test all options set by constructor
    assert d.params['continuedl'] is True
    assert d.params['quiet'] is True
    assert d.params['noprogress'] is True
    assert d.params['http_chunk_size'] == None
    assert d.params['hls_use_mpegts'] is True
    assert d.params['preferredcodec'] == 'mp3'

# Generated at 2022-06-12 16:53:57.120032
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=C0111
    fd = FragmentFD(None, {'name': 'FragmentFD'})
    fd.to_screen('Testing FragmentFD...')

# Generated at 2022-06-12 16:54:09.925934
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..extractor.common import InfoExtractor
    from ..utils import extract_attributes

    # Extractors are registered in the order they are defined.  Make sure
    # our FragmentFD works by registering an InfoExtractor and change the
    # downloader class it uses to FragmentFD.
    class TempInfoExtractor(InfoExtractor):
        IE_NAME = 'fragmentfd'
        IE_DESC = False  # Do not list

    ie = TempInfoExtractor(gen_extractors())
    ie._downloader = FragmentFD
    assert ie.IE_NAME == 'fragmentfd'
    # Make sure the _real_initialize() method was called
    assert ie._downloader.FD_NAME == 'fragmentfd'
    assert ie._downloader.params

# Generated at 2022-06-12 16:54:20.828813
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import youtube_dl.downloader.http as http_module
    import youtube_dl.downloader.external as external_module
    import youtube_dl.downloader.f4m as f4m_module
    from youtube_dl.downloader import common
    from youtube_dl.extractor import youtube
    from youtube_dl.utils import match_filter_func
    from youtube_dl.jsinterp import JSInterpreter
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.postprocessor.execafterdownload import ExecAfterDownloadPP
    common.FragmentFD.__bases__ = (http_module.HttpFD, external_module.ExternalFD, f4m_module.F4mFD)
    FFmpegPostProcessor.__bases__ = (ExecAfterDownloadPP,)

# Generated at 2022-06-12 16:54:23.692862
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .downloader import YoutubeDL
    ydl = YoutubeDL()
    h = HttpQuietDownloader(ydl, {})
    assert h.ydl == ydl

# Generated at 2022-06-12 16:54:29.530716
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .youtube_dl.extractor.common import InfoExtractor

    class FakeIE(InfoExtractor):
        IE_NAME = 'test_ie'

    for ie in [FakeIE('http://example.com')]:
        fd = FragmentFD(ie, {})
        assert fd.FD_NAME == 'test_ie'
        assert fd.ydl is ie

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:54:38.373349
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import tempfile
    from io import BytesIO, open

    if sys.version_info[:2] >= (3, 0):
        basestring = str

    def test_download(self, filename, info_dict):
        if info_dict.get('protocol') == 'file':
            return True, info_dict
        if isinstance(filename, basestring):
            return True, info_dict
        test_stream = BytesIO()
        info_dict['size'] = len(test_stream.getvalue())
        return True, info_dict

    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)

        FD_NAME = 'test'


# Generated at 2022-06-12 16:54:44.507072
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .dashsegments import (  # NOQA
        DASHFragmentsFD,
    )
    from .hls import (  # NOQA
        HLSFD,
    )
    from .m3u8 import (  # NOQA
        M3U8FD,
    )
    from .f4m import (  # NOQA
        F4MFD,
    )
    from .fragment import (  # NOQA
        FragmentFD,
    )

# Generated at 2022-06-12 16:54:46.898595
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = HttpQuietDownloader(None, {'quiet': True, 'noprogress': True})
    ydl.report_warning('warning')

# Generated at 2022-06-12 16:54:50.685034
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = None
    try:
        ydl = HttpQuietDownloader(None, {'quiet': True})
        assert ydl is not None
    finally:
        if ydl is not None:
            del ydl

# Generated at 2022-06-12 16:55:00.376678
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .__main__ import parseOpts

    def test_sanity():
        classes = gen_extractor_classes()
        opts, args = parseOpts(['--extractor-descriptions'])
        dl = FileDownloader(opts)

        for ie in classes:
            dl.add_info_extractor(ie)

        def test_sanity(ie):
            if ie.IE_NAME in ('generic', 'googledrive'):
                return
            print('testing ' + ie.IE_NAME + ' ' + '.' * 40)
            tests = ie._TEST
            for t in tests:
                m = t[0] if isinstance(t[0], compat_str) else t[1]
                print(m)

# Generated at 2022-06-12 16:56:19.853481
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = {}
    params = {}
    return FragmentFD(ydl, params)

# Generated at 2022-06-12 16:56:28.945543
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    import youtube_dl.downloader.common
    assert not hasattr(youtube_dl.downloader.common.FileDownloader, 'ytlogger')
    ydl = youtube_dl.YoutubeDL({})
    HttpQuietDownloader(ydl, {})
    assert hasattr(youtube_dl.downloader.common.FileDownloader, 'ytlogger')
    ydl.params.update({'logger': None})
    HttpQuietDownloader(ydl, {})
    assert not hasattr(youtube_dl.downloader.common.FileDownloader, 'ytlogger')

# Generated at 2022-06-12 16:56:33.896757
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import common
    ydl = common.FakeYDL()
    ydl.params['noprogress'] = False
    fd = FragmentFD(ydl, {'url': 'http://dummy/manifest.f4m', 'fragment_base_url': 'http://dummy/'})
    assert not fd._do_ytdl_file('-')
    assert fd._do_ytdl_file('manifest.mp4')

# Generated at 2022-06-12 16:56:40.510029
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class FakeInfoDict(object):
        def __init__(self):
            self.preference = 0
            self.https_is_default = False
            self.http_headers = {}
    info_dict = FakeInfoDict()
    dl = FragmentFD(object(), info_dict)
    assert info_dict.preference == 0
    assert not info_dict.https_is_default
    assert info_dict.http_headers == {}

# Used by _download_fragments_chunk to override FileDownloader._do_download

# Generated at 2022-06-12 16:56:52.791757
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..compat import parse_qs
    from ..page import Page
    c = FragmentFD()

# Generated at 2022-06-12 16:56:56.595569
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    fd = FragmentFD(ydl, {'format': 'best'})

# Generated at 2022-06-12 16:56:59.033033
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD()
    assert fd.params.get('fragment_retries', None) is None
    assert not fd.params.get('keep_fragments')

# Generated at 2022-06-12 16:57:06.712800
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..utils import DateRange
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD
    from .f4m import F4MFD
    from .smoothstreams import SmoothStreamsFD

    def get_fd_class(name):
        return {
            'http': HttpFD,
            'dash': DASHFD,
            'hls': HLSFD,
            'f4m': F4MFD,
            'smoothstreams': SmoothStreamsFD,
        }[name]

    def get_fd_instance(name, ydl, params, info_dict):
        return get_fd_class(name)(ydl, params, info_dict)


# Generated at 2022-06-12 16:57:11.258328
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    # Test 1: Test the constructor
    x = HttpQuietDownloader(FileDownloader({}), {'quiet': True})
    # Test 2: Test that to_screen() does not print anything
    x.to_screen('[debug] Test message')

# Generated at 2022-06-12 16:57:21.046148
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import youtube_dl
    from .downloader.http import HttpQuietDownloader
    ydl = youtube_dl(params={'ignoreerrors': True, 'quiet': True})
    dl = HttpQuietDownloader(
        ydl,
        {'continuedl': True, 'noprogress': True, 'ratelimit': '50k'}
    )
    assert dl.params['noprogress']
    assert dl.params['continuedl']
    assert dl.params['ratelimit'] == '50k'
    assert dl.params['quiet']
    try:
        dl.params['noprogress'] = False
    except KeyError:
        pass
    else:
        assert False, 'Should not be able to change read-only param "noprogress"'