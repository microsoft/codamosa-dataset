

# Generated at 2022-06-12 16:49:16.137439
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    for ie_name in gen_extractors():
        ie = gen_extractors()[ie_name]()
        downloader = HttpQuietDownloader(ie, {'quiet': True})
        assert downloader.params['quiet'] is True
        assert ie == downloader.ydl

# Generated at 2022-06-12 16:49:30.767592
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    ydl = None
    params = {}
    tmp_filename = '-test_video.mp4'
    filename = 'test_video.mp4'
    fragment_index = 0
    fragment_count = 1
    tmp_filename_sanitized = encodeFilename(tmp_filename)
    complete_frags_downloaded_bytes = 0
    prev_frag_downloaded_bytes = 0
    started = time.time()

    fd = FragmentFD(ydl, params)
    assert isinstance(fd.params, dict)
    assert isinstance(fd.ydl, object)
    assert isinstance(fd._prepare_url({}, 'http://example.org'), sanitized_Request)
    assert fd.FD_NAME == 'fragment'


# Generated at 2022-06-12 16:49:43.115948
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import prepend_extractor

    def assert_download_result(info, expected):
        downloader = HttpQuietDownloader(None, info)
        assert expected == downloader.result

    prepend_extractor(gen_extractors())

    info = {
        'continuedl': False,
        'quiet': False,
        'noprogress': False,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }

# Generated at 2022-06-12 16:49:54.802176
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def progress_hook(status):
        pass

    class DummyYdl:

        def __init__(self, progress_hooks):
            self.progress_hooks = progress_hooks

    url = 'http://example.com/video.mp4'
    frag_count = 10
    ydl = DummyYdl([])
    fd = FragmentFD(ydl, {
        'fragment_count': frag_count,
        'fragment_index': frag_count - 1,
    }, progress_hook)
    assert fd.total_frags == frag_count
    assert fd.frag_index == frag_count - 1
    assert fd.ydl is ydl
    assert fd.params == {}
    assert len(fd.ydl.progress_hooks) == 1
    assert f

# Generated at 2022-06-12 16:49:57.303383
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest

    class TestFragmentFD(unittest.TestCase):
        pass

    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    suite.addTests(loader.loadTestsFromTestCase(TestFragmentFD))
    return unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful()


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:50:03.424294
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def fail(msg):
        raise AssertionError(msg)

    params = {
        'quiet': True,
    }
    fd = FragmentFD({}, None, params)

    # Check default values of parameters
    assert 'fragment_retries' not in params
    assert 'skip_unavailable_fragments' not in params
    assert 'keep_fragments' not in params

    # Check that http_chunk_size is overriden
    assert params.get('http_chunk_size') is None


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:50:06.809445
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    fd = FragmentFD(DummyYDL(), {})
    assert fd.params == {'logger': sys.stderr}
    assert fd.ydl is DummyYDL()



# Generated at 2022-06-12 16:50:18.883940
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .extractor import GenericIE
    from ..extractor.common import InfoExtractor
    from ..utils import parse_duration
    youtube_ie = InfoExtractor.gen_extractor(r'https?://(?:www\.)?youtube\.com/watch\?v=[A-Za-z0-9-_]{11}')
    ie_result = youtube_ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    assert isinstance(ie_result, dict)
    assert 'id' in ie_result
    assert ie_result['id'] == 'BaW_jenozKc'
    assert 'duration' in ie_result
    assert parse_duration(ie_result['duration']) > 0

    class FakeYdl:

        def __init__(self):
            self

# Generated at 2022-06-12 16:50:31.389864
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor import GenFileInfoExtractor
    from .utils import std_headers
    from .compat import compat_urllib_request

    def _test(*args, **kargs):
        class MockYoutubeDL():
            def __init__(self):
                self.params = {}
                self.result = []
            def report_warning(self, msg):
                self.result.append('WARNING: ' + msg)
            def to_screen(self, msg):
                self.result.append(msg)
            def download(self, *args, **kargs):
                return True
            def problem(self, msg):
                self.result.append('PROBLEM: ' + msg)
        ydl = MockYoutubeDL()

# Generated at 2022-06-12 16:50:34.698828
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    HttpQuietDownloader(None, {'http_chunk_size': 10})

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:50:58.002462
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    http_dl = HttpQuietDownloader(None, None)
    assert isinstance(http_dl, HttpFD)
    assert not hasattr(http_dl, 'to_screen')


if __name__ == "__main__":
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:51:06.298300
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL
    import youtube_dl.downloader.http
    ydl = youtube_dl.YoutubeDL({})
    hqd = youtube_dl.downloader.http.HttpQuietDownloader(ydl)
    assert hqd.ydl is ydl
    assert hqd.params['quiet']
    assert hqd.params['noprogress']
    assert not hqd.params['verbose']
    assert hqd.params['simulate'] == ydl.params['simulate']
    assert hqd.params['skip_download'] == ydl.params['skip_download']

# Generated at 2022-06-12 16:51:10.292792
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    from .hls import HlsFD
    from .dash import DashFD
    isinstance(FragmentFD(), FileDownloader)
    isinstance(FragmentFD(), HttpFD)
    isinstance(FragmentFD(), HlsFD)
    isinstance(FragmentFD(), DashFD)

# Generated at 2022-06-12 16:51:23.537857
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor

    # Create a dummy InfoExtractor and a HttpQuietDownloader
    ie = InfoExtractor(gen_extractors())
    ie.params = {}
    ie.initialize()
    hqd = HttpQuietDownloader(ie, {})

    # Download a mp4 video
    hqd.download('test.mp4', { 'url': 'http://techslides.com/demos/sample-videos/small.mp4' })

    # Download a webm video
    hqd.download('test.webm', { 'url': 'https://ia600502.us.archive.org/9/items/WebmVp8Vorbis/webmvp8.ogg' })

# Generated at 2022-06-12 16:51:33.932958
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # We don't have an actual extractor to test with but we still need
    # to have some basic tests to make sure that the constructor works properly
    tfd = FragmentFD({'_type': 'fragment_downloader'})
    assert not tfd.params.get('verbose')
    assert tfd.params.get('skip_unavailable_fragments')
    assert not tfd.params.get('keep_fragments')
    assert tfd.FD_NAME == 'fragment'
    assert tfd.progress_hooks == []  # Don't check the contents of progress_hooks as we don't have an actual extractor

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:51:39.969090
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    dl = HttpQuietDownloader(
        gen_extractors(),
        {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': None,
            'retries': 1,
            'nopart': True,
            'test': True,
        }
    )
    dl.to_screen = None
    assert dl.params['continuedl']
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert dl.params['ratelimit'] is None
    assert dl.params['retries'] == 1
    assert dl.params['nopart']
    assert dl.params['test']

# Generated at 2022-06-12 16:51:48.057506
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..YoutubeDL import YoutubeDL
    from .http import HttpFD
    from .common import FileDownloader
    ydl = YoutubeDL({})
    ydl.params['logtostderr'] = False
    ydl.add_default_info_extractors()
    fd = HttpQuietDownloader(ydl, {})
    assert issubclass(fd.__class__, HttpFD)
    assert issubclass(fd.__class__, FileDownloader)

# Generated at 2022-06-12 16:51:52.390125
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class SimYDL(object):
        def __init__(self):
            self.params = {}

    h = HttpQuietDownloader(SimYDL(), {'continuedl': True, 'quiet': True})
    assert h.params['continuedl']
    assert h.params['quiet']

# Generated at 2022-06-12 16:51:55.687694
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader(None, {})
    assert dl.params['quiet']
    assert not dl.params['noprogress']

# Generated at 2022-06-12 16:52:07.654164
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .downloader import ExternalFD

# Generated at 2022-06-12 16:52:44.564752
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert hasattr(FragmentFD, 'report_retry_fragment')

# Generated at 2022-06-12 16:52:49.573160
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    try:
        # Create a HttpQuietDownloader object
        HttpQuietDownloader(None, {'retries': 1})
    except Exception as err:
        # Assert that no exception was thrown
        assert False, 'Unexpected exception thrown: ' + repr(err)

# Generated at 2022-06-12 16:52:59.659358
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_urllib_request
    from ..utils import compat_str

    res = compat_urllib_request.urlopen('http://www.example.com/')
    assert res.headers['Content-Type'] == 'text/html'
    res_content = compat_str(res.read())
    assert res_content.find('Example Domain') >= 0

    req = sanitized_Request('http://www.example.com/')
    dl = HttpQuietDownloader(
        None,
        {
            'continuedl': False,
            'noprogress': True,
            'quiet': True,
        }
    )
    res = dl.urlopen(req)
    assert res.headers['Content-Type'] == 'text/html'

# Generated at 2022-06-12 16:53:04.482590
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    url = 'http://127.0.0.1/'
    dl = HttpQuietDownloader(None, {'quiet': True, 'noprogress': True})
    ctx = {'url': url}
    dl._do_download(ctx)
    assert ctx['status'] == 'finished'

# Generated at 2022-06-12 16:53:10.455577
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = object()
    params = object()
    hqd = HttpQuietDownloader(ydl, params)
    assert hqd.ydl is ydl
    assert hqd.params is params
    assert hqd.stderr == []
    assert hqd._progress_hooks == []
    assert hqd.to_screen == hqd.to_stderr

# Generated at 2022-06-12 16:53:11.777611
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'

# Generated at 2022-06-12 16:53:12.660444
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-12 16:53:18.712078
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .utils import FakeYDL
    from .extractor.common import InfoExtractor

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'

        def _real_extract(self, url):
            url_info = {
                'url': url,
                'playlist': 'url',
                'playlist_id': 'id',
                'playlist_title': 'title',
            }
            return [url_info]

    ie = DummyIE(FakeYDL({}))
    fragment_urls = ['A', 'B', 'C', 'D']

# Generated at 2022-06-12 16:53:29.992649
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import tempfile
    import shutil
    import json

# Generated at 2022-06-12 16:53:33.797144
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def ytdl_filename(filename):
        return filename + '_ytdl'
    fd = FragmentFD(None, {}, {'filename': 'fname', 'ytdl_filename': ytdl_filename})
    assert fd.filename == 'fname', 'Invalid constructor for FragmentFD'

# Generated at 2022-06-12 16:54:59.251214
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import InfoExtractor
    from ..compat import compat_urllib_request
    downloader = InfoExtractor().downloader
    downloader.params['outtmpl'] = '%(id)s'
    downloader.params['writethumbnail'] = True
    handler = compat_urllib_request.HTTPHandler(debuglevel=0)
    opener = compat_urllib_request.build_opener(handler)
    compat_urllib_request.install_opener(opener)

# Generated at 2022-06-12 16:55:07.196736
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    import sys
    import tempfile
    import os.path

    class FragmentFDTest(unittest.TestCase):
        def setUp(self, *args, **kargs):
            self.tmp_dir = tempfile.mkdtemp(prefix='ytdl_test_')
            self.filename = os.path.join(self.tmp_dir, 'filename')
            self.fd = FragmentFD(None, {
                'quiet': True,
                'continuedl': True,
                'noprogress': True,
            }, self.filename, None)

        def tearDown(self, *args, **kargs):
            import shutil
            shutil.rmtree(self.tmp_dir)


# Generated at 2022-06-12 16:55:18.401869
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        def __init__(self, ydl, params):
            super(MyFragmentFD, self).__init__(ydl, params)
    params = {
        'format': 'bestvideo+bestaudio',
        'download_archive': os.path.join(os.getcwd(), 'archive'),
        'skip_download': True,
        'noplaylist': False,
        'simulate': True,
        'keep_fragments': True,
    }
    ydl = MockYDL()
    fd = MyFragmentFD(ydl, params)
    assert fd.params == params
    assert fd.FD_NAME == 'mockfd'
    assert fd.ytdl == ydl
    assert fd.params['keep_fragments']

# Generated at 2022-06-12 16:55:27.518036
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .common import FileDownloader
    from .http import HttpFD
    from .fragment import FragmentFD
    import sys

    def get_FD_for_type(info_dict):
        if info_dict['protocol'] == 'file':
            return FileDownloader(ydl, params)
        elif info_dict['protocol'] in ('http', 'https'):
            return FragmentFD(ydl, params)
        else:
            raise ValueError('Unsupported protocol')


# Generated at 2022-06-12 16:55:32.807777
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.set_downloader(HttpQuietDownloader())
    assert ie.params.get('quiet') is True
    assert ie.params.get('noprogress') is True
    assert ie.params.get('verbose') is False

# Generated at 2022-06-12 16:55:43.196891
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    ydl = object()
    params = {
        'continuedl': True,
        'noprogress': True,
        'ratelimit': 1048576,
        'retries': 10,
        'prefer_ffmpeg': True,
        'ffmpeg_location': 'ffmpeg',
        'hls_prefer_native': True,
        'hls_use_mpegts': True,
        'external_downloader': 'avconv',
        'hls_prefer_ffmpeg': True,
        'hds_prefer_ffmpeg': True,
    }
    assert isinstance(HttpQuietDownloader(ydl, params), HttpFD)


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:55:54.199741
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from ..compat import compat_str
    from ..downloader.external import ExternalFD
    from ..downloader.http import HttpFD

    class FakeHttpQuietDownloader(HttpQuietDownloader):
        def __init__(self, ydl, params):
            super(FakeHttpQuietDownloader, self).__init__(ydl, params)
            self.passed_ydl = ydl
            self.passed_params = params

    class FakeYtdl(object):
        class FakeIE(InfoExtractor):
            def __init__(self, ydl):
                self.ydl = ydl

        def add_info_extractor(self, ie):
            pass


# Generated at 2022-06-12 16:55:54.760467
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass

# Generated at 2022-06-12 16:56:00.422703
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=protected-access
    hd = HttpQuietDownloader(None, {'continuedl': False})
    assert hd.continuedl is False
    hd = HttpQuietDownloader(None, {'continuedl': True})
    assert hd.continuedl is True
    hd = HttpQuietDownloader(None, {})
    assert hd.continuedl is True

# Generated at 2022-06-12 16:56:11.190567
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=W0612
    class testFD(FragmentFD):
        def __init__(self, ydl):
            self.param = {}
            FragmentFD.__init__(self, ydl)

        def report_warning(self, msg):
            pass

        def report_destination(self, filename):
            pass

        def calc_eta(self, start_time, end_time, total_bytes, downloaded_bytes):
            pass

        def to_screen(self, s, skip_eol=False):
            pass

        def temp_name(self, filename):
            return '%s.part' % filename

        def ytdl_filename(self, filename):
            return '%s.ytdl' % filename
