

# Generated at 2022-06-12 16:49:17.633424
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpDownloader
    from ..compat import compat_http_server
    import tempfile

    data = b'content of test file'
    with tempfile.NamedTemporaryFile(suffix='.mp4') as f:
        f.write(data)
        f.flush()
        d = HttpDownloader({'quiet': False})

# Generated at 2022-06-12 16:49:24.012432
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .downloader import _assert_downloader_works

    class DummyFragmentFD(FragmentFD):
        def real_download(self, filename, info_dict):
            self.filename = filename
            self.info_dict = info_dict
            return True

    _assert_downloader_works(DummyFragmentFD(), 'http://example.org/')

# Generated at 2022-06-12 16:49:31.095312
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_urllib_request
    dl = HttpQuietDownloader(None, {})
    assert dl.ydl is None
    assert dl.params == {}
    assert dl.certifi_handles_url is None
    assert dl.urlopen is compat_urllib_request.urlopen

# Generated at 2022-06-12 16:49:43.456843
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import get_info_extractor
    from .common import InfoExtractor
    from .http import HttpDownloader
    from .options import OptParseError

    # Mock InfoExtractor
    class MockIE(InfoExtractor):
        IE_NAME = 'IE_NAME'
        _VALID_URL = r'^.*?$'

    ie = MockIE()

    # Mock HttpDownloader
    class MockHttpDownloader(HttpDownloader):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

    ie._downloader = MockHttpDownloader

    # Test constructor
    ie.params = {'continuedl': False, 'format': 'mp4'}
    ie.download('url')
    assert ie._downloader.params['continuedl']

    ie

# Generated at 2022-06-12 16:49:49.916330
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .common import FileDownloader
    dl = HttpQuietDownloader(None, {'continuedl': True})
    assert dl
    assert dl.params['continuedl']
    assert isinstance(dl, HttpFD)
    assert isinstance(dl, FileDownloader)
    assert dl.to_screen() == None

# Generated at 2022-06-12 16:49:59.695740
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.options
    params = {
        'forceurl': True,
        'forcethumbnail': True,
        'forcetitle': True,
        'forcedescription': True,
        'forcefilename': True,
        'forcejson': True,
        'simulate': True,
        'skip_download': True,
        'geturl': True,
        'gettitle': True,
        'getthumbnail': True,
        'getdescription': True,
        'getfilename': True,
        'get_format_id': True,
        'nofail': True,
    }
    opts = youtube_dl.options.parseOpts(params)
    downloader = HttpQuietDownloader({'logger': None}, opts)
    assert downloader.params == {}


# Generated at 2022-06-12 16:50:04.311694
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.extractor.common
    import youtube_dl.YoutubeDL
    import types

    params1 = {'continuedl': True, 'quiet': True, 'noprogress': True,
               'ratelimit': None, 'retries': -1, 'nopart': True, 'test': True}

    assert HttpQuietDownloader.params == params1

# Generated at 2022-06-12 16:50:16.667674
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class FakeYDL:
        def __init__(self, params):
            self.params = params
            self.cache = None

        def add_info_extractor(self, ie):
            self.ie = ie

        def add_post_processor(self, pp):
            pass

        def to_screen(self, *args, **kargs):
            pass

    ydl = FakeYDL({
        'fragment_retries': 10,
        'skip_unavailable_fragments': True,
        'keep_fragments': True,
    })
    f4m_ie = get_info_extractor('f4m')
    f4m_ie.ydl = ydl
    ydl.ie = f4m_ie
    f4m_

# Generated at 2022-06-12 16:50:27.634719
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import io
    import sys
    import tempfile
    from .http import HttpFD

    ydl = object()
    params = object()
    downloader = HttpQuietDownloader(ydl, params)
    assert downloader.ydl is ydl
    assert downloader.params is params
    assert downloader.to_stderr is None
    assert downloader.stdout is sys.stdout

    downloader = HttpQuietDownloader(ydl, params, sys.stdout)
    assert downloader.to_stderr is None
    assert downloader.stdout is sys.stdout

    downloader = HttpQuietDownloader(ydl, params, to_stderr=True)
    assert downloader.to_stderr is sys.stderr
    assert downloader.stdout is sys.st

# Generated at 2022-06-12 16:50:34.285585
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # pylint: disable=protected-access
    hqd = HttpQuietDownloader({}, {})
    assert hqd._opts == {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }

# Generated at 2022-06-12 16:50:56.842370
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    pass  # Just make sure the class can be instantiated

# Generated at 2022-06-12 16:51:00.929533
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    params = {
        'quiet': True,
        'skip_unavailable_fragments': True,
        'fragment_retries': 10,
        'keep_fragments': True,
        'updatetime': True,
        'retries': 10,
        'ratelimit': '5M',
    }
    ydl = {}
    fd = FragmentFD(ydl, params)

    assert fd.params.get('keep_fragments') == params['keep_fragments']
    assert fd.params.get('quiet') == params['quiet']
    assert fd.params.get('skip_unavailable_fragments') == params['skip_unavailable_fragments']
    assert fd.params.get('fragment_retries') == params['fragment_retries']


# Generated at 2022-06-12 16:51:06.478029
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpQuietDownloader
    from .common import FileDownloader
    from ..utils import FakeYDL
    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {})
    assert dl.params == {'noprogress': True, 'quiet': True}
    assert dl.ydl is ydl
    assert isinstance(dl, FileDownloader)

# Generated at 2022-06-12 16:51:08.194255
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert HttpQuietDownloader(None, {'noprogress': True, 'quiet': True})

# Generated at 2022-06-12 16:51:10.530433
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    dl = HttpQuietDownloader({}, None)
    assert dl.params['noprogress'] is True

# Generated at 2022-06-12 16:51:23.810028
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .null import NullFD
    from ..compat import compat_urllib_request
    from ..extractor import get_info_extractor
    from ..utils import format_bytes

    class FakeYDL:
        def __init__(self):
            self.params = {
                'outtmpl': encodeFilename('%(id)s.%(ext)s'),
                'restrictfilenames': True,
            }

    ydl = FakeYDL()
    info_dict = {
        'format': '500',
        'id': 'fakeid1',
        'ext': 'mp4',
        'title': 'faketitle',
        'http_headers': {'Range': 'bytes=0-16/17', 'Accept-Encoding': 'identity'},
        'filesize': 17,
    }


# Generated at 2022-06-12 16:51:28.992231
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class MyHttpQuietDownloader(HttpQuietDownloader):
        def _real_initialize(self):
            return None

    my_http_quiet_downloader = MyHttpQuietDownloader(None, {})
    assert my_http_quiet_downloader.ydl is None

# Generated at 2022-06-12 16:51:31.009415
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    # Currently a stub
    pass


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:51:37.669279
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    """
    Constructor of youtube_dl.downloader.common.HttpQuietDownloader class
    """
    import types

    ydl = object
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': None,
        'nopart': False,
        'test': False,
    }
    hqd = HttpQuietDownloader(ydl, params)
    assert hqd.ydl is ydl
    assert hqd.params is params
    assert hqd._progress_hooks is None
    assert isinstance(hqd.to_screen, types.MethodType)



# Generated at 2022-06-12 16:51:40.233338
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from . import YoutubeDL
    dler = HttpQuietDownloader(YoutubeDL())
    assert dler is not None

# Generated at 2022-06-12 16:52:07.519344
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': 192000,
        'retries': 5,
        'nopart': True,
        'test': True,
    }
    ydl = object()
    dl = HttpQuietDownloader(ydl, params)
    assert dl.ydl is ydl
    assert dl.params == params

# Generated at 2022-06-12 16:52:12.959141
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD({'quiet': True})
    assert fd.params['continuedl']
    assert fd.params['quiet']
    assert fd.params['noprogress']
    assert fd.params['ratelimit'] is None
    assert fd.params['retries'] == 0
    assert fd.params['nopart'] is False
    assert fd.params['test'] is False

# Generated at 2022-06-12 16:52:24.035256
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .urltransformer import UrlTransformer
    from .verbosedownloader import VerboseFD
    from .fragment import FragmentFD
    from ..extractor import youtube_dl

    http_c = HttpQuietDownloader.__mro__[1].__init__
    ytdl = youtube_dl(params={'noprogress': False, 'verbose': True}, auto_init=True)
    ytdl.add_info_extractor(UrlTransformer.IE_NAME)
    ytdl.add_info_extractor(VerboseFD.IE_NAME)
    ytdl.add_info_extractor(FragmentFD.IE_NAME)

    # Test that verbose is updated to True

# Generated at 2022-06-12 16:52:36.595247
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import fake_info_dict
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD
    from .hlsnative import HLSFD as HLSNATIVEFD
    from .http import HttpQuietDownloader
    from .external import ExternalFD

    # FragmentFD is an abstract class, it shouldn't be instantiated
    try:
        FragmentFD(None, None, None)
    except TypeError:
        pass
    else:
        assert False, 'Expected exception was not raised'

    # http and dash
    info_dict = fake_info_dict(
        'http_test_url', [{'url': 'http://example.com/video.mp4'}],
        http_headers={'User-Agent': 'FooAgent'})
   

# Generated at 2022-06-12 16:52:44.461659
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class MyFragmentFD(FragmentFD):
        def __init__(self, ydl):
            super(MyFragmentFD, self).__init__(ydl)
            self.tmpfilename = 'tmp'
            self.filename = 'fn'
            self.dest_stream = open(self.tmpfilename, 'wb')
            self.complete_frags_downloaded_bytes = 0
            self.fragment_index = 0
            self.prev_frag_downloaded_bytes = 0
            self.speed = '100'
            self.started = time.time()
            self.live = False
            self.params = {'keep_fragments': True}

# Generated at 2022-06-12 16:52:56.547687
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor.common import InfoExtractor
    from .postprocessor.ffmpeg import FFmpegPostProcessor
    from .utils import DateRange

    # Extractor instance
    ie = InfoExtractor()

    # Postprocessor instance
    pp = FFmpegPostProcessor()

    # File downloader instance

# Generated at 2022-06-12 16:53:08.828233
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def report_progress(state):
        return True

    def report_warning(message):
        return True

    def report_error(message):
        return True

    from .extractor.common import InfoExtractor
    class InfoExtractorMock(InfoExtractor):
        _FAKE_INFO = {
            'url': '',
            'id': '1234',
            'ext': '',
            'title': 'foo',
        }
        def __init__(self):
            InfoExtractor.__init__(self, {})
        def _real_extract(self, url):
            return self._FAKE_INFO


# Generated at 2022-06-12 16:53:20.941796
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    def test_v(v):
        assert(v == 'a')
    a = FragmentFD(None)
    a._prepare_and_start_frag_download({'filename': 'a', 'total_frags': 3})
    a._prepare_and_start_frag_download({'filename': 'a', 'total_frags': 3})
    a._prepare_and_start_frag_download({'filename': 'b', 'total_frags': 2})
    a._finish_frag_download({'filename': 'a'})
    a._finish_frag_download({'filename': 'b'})
    a._hooks = {'test': test_v}
    a._hook_progress({'status': 'test', 'filename': 'a'})


# Generated at 2022-06-12 16:53:24.695254
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    fd = FragmentFD(InfoExtractor({}), {})
    assert fd.params is not None
    assert fd.ydl is not None


# Generated at 2022-06-12 16:53:28.783549
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    hd = HttpQuietDownloader({}, {'quiet': True})
    assert isinstance(hd, HttpFD)

# Generated at 2022-06-12 16:54:16.799424
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import youtube_dl.YoutubeDL

    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': '500k',
        'retries': 10,
        'nopart': False,
        'test': True,
    }
    hqd = HttpQuietDownloader(
        YoutubeDL({}),
        params
    )
    for (key, ref_value) in params.items():
        assert getattr(hqd, key) == ref_value

# Generated at 2022-06-12 16:54:24.937032
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import StringIO
    out = StringIO.StringIO()
    sys.stdout = out
    out.truncate(0)
    HttpQuietDownloader({}, {'quiet': True}).to_screen('Hello!')
    assert out.getvalue() == '', out.getvalue()
    HttpQuietDownloader({}, {'quiet': False}).to_screen('Hello!')
    assert out.getvalue() == 'Hello!\n', out.getvalue()
    sys.stdout = sys.__stdout__

# Generated at 2022-06-12 16:54:26.722825
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..downloader.common import FileDownloader
    assert issubclass(HttpQuietDownloader, FileDownloader)

# Generated at 2022-06-12 16:54:29.888555
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    fd = HttpQuietDownloader(ydl, {'q': True, 'noprogress': True})
    assert fd.params['noprogress']

# Generated at 2022-06-12 16:54:33.766445
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class FakeYDL():
        def __init__(self):
            self.params = {}

    fake_ydl = FakeYDL()
    http_dl = HttpQuietDownloader(fake_ydl, {'noprogress': True})
    assert http_dl.params["verbose"] == False

# Generated at 2022-06-12 16:54:42.551036
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    import tempfile
    import atexit

    from xml.etree import ElementTree
    from xml.dom.minidom import parseString

    headers = [
        ('Content-type', 'application/xml'),
    ]

    def _make_http_server():
        """
        Start an HTTP server serving an XML file
        """
        fd, xml_filename = tempfile.mkstemp(suffix='.xml')
        os.close(fd)
        atexit.register(os.remove, xml_filename)
        root = ElementTree.Element('root')
        for h, v in headers:
            child = ElementTree.Element('header', name=h)
            child.text = v
            root.append(child)
        ElementTree.ElementTree(root).write(xml_filename)

# Generated at 2022-06-12 16:54:50.206327
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_urllib_request
    from ..downloader.common import FileDownloader

    url = 'http://127.0.0.1:0/' + 'a' * 2000
    dl = HttpQuietDownloader(FileDownloader({}), {})
    try:
        dl._do_download(compat_urllib_request.Request(url), {}, {})
    except compat_urllib_request.HTTPError as err:
        assert err.getcode() == 414



# Generated at 2022-06-12 16:54:56.567142
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class DummyYoutubeDL(object):
        pass

    ydl = DummyYoutubeDL()
    params = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': '1k',
        'retries': 5,
        'nopart': True,
        'test': True,
    }
    dl = HttpQuietDownloader(ydl, params)
    assert dl.ydl is ydl
    assert dl.params == params

# Generated at 2022-06-12 16:54:58.395295
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    assert isinstance(HttpQuietDownloader({'noprogress': True}, {}), HttpQuietDownloader)

# Generated at 2022-06-12 16:55:00.759607
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    # compilation test
    x = FragmentFD(ydl, {})
    assert x is not None

# Generated at 2022-06-12 16:56:31.454694
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = FileDownloader({'quiet': True})
    assert isinstance(ydl.params['progress_hooks'], list)
    ydl = FileDownloader({'verbose': True})
    assert ydl.params['progress_hooks'] is None
    ydl = HttpQuietDownloader(ydl, {'continuedl': True})
    assert ydl.params['progress_hooks'] is None

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:56:33.228165
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    assert issubclass(FragmentFD, FileDownloader)



# Generated at 2022-06-12 16:56:37.968806
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    }
    hd = HttpQuietDownloader({'to_stderr': None}, ydl)
    assert hd.params == ydl

# Generated at 2022-06-12 16:56:41.020003
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    d = HttpQuietDownloader({}, {})
    d.to_screen('foo') # Shouldn't raise exception


if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-12 16:56:43.634005
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    fd1 = HttpFD()
    fd2 = HttpQuietDownloader()
    assert isinstance(fd2, HttpFD)

# Generated at 2022-06-12 16:56:53.105076
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class A:
        params = {}
        to_screen = lambda x, *a, **k: None
        report_warning = lambda x, *a: None
    class B(A):
        temp_name = lambda x, fn: fn
        calc_eta = lambda x, *a: None
        ydl = A()
        try_rename = lambda x, f1, f2: None
    frag = FragmentFD(B())
    frag.report_destination('file.mp4')


if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-12 16:56:55.696644
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import YoutubeIE
    FragmentFD(YoutubeIE(), {}, {'fragment_retries': 5})

# Generated at 2022-06-12 16:57:00.884702
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    ydl = sys.modules['__main__']
    ydl.params['noprogress'] = ydl.params['nopart'] = True
    d = FragmentFD(ydl, {'continuedl': True})
    assert d.params['noprogress']
    assert d.params['nopart']
    assert d.params['continuedl']
    assert d.ydl is ydl

# Generated at 2022-06-12 16:57:07.904863
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import unittest
    import tempfile
    import shutil
    import sys
    import json

    # TODO: remove this
    class MockYDL(object):
        params = {}

        def to_screen(self, msg):
            sys.stderr.write(msg + '\n')

        def report_warning(self, msg):
            self.to_screen(msg)

        def report_error(self, msg):
            raise Exception(msg)

        def trouble(self, msg, tb=None):
            raise Exception(msg)

        def report_destination(self, filename):
            self.to_screen('[Destination: %s]' % filename)

    ydl = MockYDL()

    class TestFragmentFD(unittest.TestCase):
        def setUp(self):
            self.test

# Generated at 2022-06-12 16:57:15.507020
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from collections import namedtuple

    YDL = namedtuple('YDL', ['params'])

    fd = FragmentFD(YDL({'params1': 'val1'}))
    assert fd.params == {'params1': 'val1'}

    fd = FragmentFD(YDL({'params1': 'val1'}), {'params2': 'val2'})
    assert fd.params == {'params1': 'val1', 'params2': 'val2'}