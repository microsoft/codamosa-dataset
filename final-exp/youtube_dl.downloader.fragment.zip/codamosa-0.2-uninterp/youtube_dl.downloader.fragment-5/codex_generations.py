

# Generated at 2022-06-18 13:20:06.874694
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'simulate': True,
                'skip_download': True,
                'format': 'best',
            }
            self.cache = None
            self.progress_hooks = []

        def add_progress_hook(self, hook):
            self.progress_hooks.append(hook)

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:20:11.863698
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = False  # Do not list
        _TESTS = [{
            'url': 'http://example.com/video.mp4',
            'info_dict': {
                'id': 'video',
                'ext': 'mp4',
                'title': 'video',
            },
        }]

        def _real_extract(self, url):
            return {
                'id': 'video',
                'title': 'video',
                'url': url,
            }

    ie = TestIE()
    ie.add

# Generated at 2022-06-18 13:20:17.879511
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test')
    ie.set_downloader(TestFD(ie))
    ie.download('http://localhost/')

# Generated at 2022-06-18 13:20:25.138208
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'
        _VALID_URL = r'https?://.+'

        def __init__(self, downloader=None):
            pass

        def _real_initialize(self):
            pass

        @classmethod
        def suitable(cls, url):
            return True

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'formats': [
                    {'format_id': 'test', 'url': 'http://test/test.mp4'},
                ],
            }


# Generated at 2022-06-18 13:20:37.166709
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func


# Generated at 2022-06-18 13:20:45.471786
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'
        _VALID_URL = r'(?x)https?://.+'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, url):
            return True

        def _real_initialize(self):
            pass


# Generated at 2022-06-18 13:20:54.790960
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.common import FileDownloader
    from .compat import compat_str

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

        def warning(self, msg):
            pass

        def error(self, msg):
            pass

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = 'test'

        def _real_extract(self, url):
            pass

   

# Generated at 2022-06-18 13:21:00.354205
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test_ie')
    ie.add_info_extractor(TestFD)
    ie.extract('test')

# Generated at 2022-06-18 13:21:13.640856
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.ydl = ydl
            self.params = params

        def real_download(self, filename, info_dict):
            self.filename = filename
            self.info_dict = info_dict
            return True

    class TestIE(object):
        def __init__(self, ydl):
            self.ydl = ydl


# Generated at 2022-06-18 13:21:15.214126
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    ydl = gen_extractors()[0]
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.params['quiet']

# Generated at 2022-06-18 13:21:43.420236
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params
            self.to_screen = lambda *args, **kargs: None
            self.report_warning = lambda *args, **kargs: None
            self.report_destination = lambda *args, **kargs: None
            self.temp_name = lambda *args, **kargs: None
            self.try_rename = lambda *args, **kargs: None
            self.calc_eta = lambda *args, **kargs: None
            self.ytdl_filename = lambda *args, **kargs: None
            self.FD_NAME = 'test'
            self._hooks = {
                'progress': [],
            }


# Generated at 2022-06-18 13:21:51.929629
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def _test_frag_download(ie, url, expected_frag_count, expected_frag_retries, expected_frag_skip):
        ie = get_info_extractor(ie)()
        ie.params = {}
        ie.add_info_extractor(get_info_extractor('GenericIE'))
        ie.add_info_extractor(get_info_extractor('YoutubeIE'))
        ie.add_info_extractor(get_info_extractor('YoutubePlaylistIE'))
        ie.add_info_extractor(get_info_extractor('YoutubeChannelIE'))
        ie.add_info_extractor(get_info_extractor('YoutubeSearchIE'))

# Generated at 2022-06-18 13:22:01.134748
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..compat import compat_urllib_request

    ydl = gen_extractors()['youtube']
    req = compat_urllib_request.Request('http://www.youtube.com/')
    dl = HttpQuietDownloader(ydl, {'continuedl': True, 'quiet': True})
    dl.to_screen('test')
    dl.to_stderr('test')
    dl.report_warning('test')
    dl.report_error('test')
    dl.report_file_already_downloaded('test')
    dl.report_destination('test')
    dl.download(req, {'test': True})
    dl.download(req, {'test': True})
    dl

# Generated at 2022-06-18 13:22:11.188961
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(ie_key):
        return match_filter_func(ie_key, ['youtube', 'generic'])

    gen_extractors(test_filter)

    # Test for youtube
    fd = FragmentFD(
        {
            'ydl': {
                'quiet': True,
                'skip_download': True,
            },
            'params': {
                'skip_unavailable_fragments': True,
            },
        },
        {
            'id': 'test_id',
            'extractor': 'youtube',
            'url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
        }
    )
    fd._prepare_frag

# Generated at 2022-06-18 13:22:24.576368
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(extractor_class, ie_name):
        if not issubclass(extractor_class, FragmentFD):
            return
        if ie_name == 'generic':
            return
        ie = extractor_class(FragmentFD.ydl)
        if ie.IE_NAME != ie_name:
            return
        if ie.params.get('skip_download'):
            return
        if not ie.working():
            return
        if not ie.suitable(ie.url):
            return
        if not match_filter_func(ie.url, ie.params.get('playlistend', -1)):
            return
        return ie

    for ie in gen_extractors():
        ie = test

# Generated at 2022-06-18 13:22:35.425285
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class FakeYDL:
        def __init__(self):
            self.params = {}
            self.cache = None
            self.progress_hooks = []

        def add_progress_hook(self, hook):
            self.progress_hooks.append(hook)

        def to_screen(self, *args, **kargs):
            pass

    class FakeIE(get_info_extractor('Generic')):
        IE_NAME = 'Fake'
        IE_DESC = False
        _VALID_URL = r'https?://.+'


# Generated at 2022-06-18 13:22:47.785521
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def test_filter(ie, ie_name, ie_info):
        return ie_name == 'Youtube'

    ie = get_info_extractor(match_filter_func(test_filter))
    fd = FragmentFD(ie, {'noprogress': True, 'quiet': True})
    assert fd.params['noprogress']
    assert fd.params['quiet']
    assert fd.params['retries'] == 0
    assert fd.params['nopart'] is False
    assert fd.params['test'] is False
    assert fd.params['continuedl'] is True
    assert fd.params['ratelimit'] is None

# Generated at 2022-06-18 13:22:59.734862
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'fake'

        def _real_extract(self, url):
            return {
                'id': 'fake',
                'url': url,
                'title': 'fake video',
                'ext': 'mp4',
            }

    ie = FakeInfoExtractor()
    gen_extractors()
    ie.add_info_extractor(FakeInfoExtractor)


# Generated at 2022-06-18 13:23:08.992778
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .downloader.http import HttpFD
    from .downloader.rtmp import RtmpFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.hls import HlsFD
    from .downloader.hls import HlsNativeFD
    from .downloader.external import ExternalFD
    from .downloader.fragment import FragmentFD
    from .downloader.f4m import F4mFD
    from .downloader.ism import IsmFD
    from .downloader.m3u8 import M3u8FD
    from .downloader.common import FileDownloader
    from .downloader.http import HttpQuietDownloader
    from .downloader.http import HttpFD
    from .downloader.http import HttpFDHeadRequest

# Generated at 2022-06-18 13:23:21.396995
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .common import InfoExtractor
    from .downloader.http import HttpDownloader
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.fragment import FragmentFD

    def test_class(cls):
        assert issubclass(cls, FragmentFD)
        assert cls.FD_NAME
        assert cls.__name__ == cls.FD_NAME + 'FD'
        assert cls.FD_NAME in HttpQuietDownloader.handlers
        assert HttpQuietDownloader.handlers[cls.FD_NAME] is cls

    test_class(F4mFD)
    test_

# Generated at 2022-06-18 13:24:04.735095
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    # Test constructor of FragmentFD
    ie = get_info_extractor('youtube', {})
    fd = FragmentFD(ie, {}, None)
    assert fd.params == {}
    assert fd.ydl is ie.ydl
    assert fd.FD_NAME == 'generic'

    # Test constructor of FragmentFD with params
    fd = FragmentFD(ie, {'params': {'test': True}}, None)
    assert fd.params == {'test': True}
    assert fd.ydl is ie.ydl
    assert fd.FD_NAME == 'generic'

    # Test constructor of FragmentFD with name
    fd = FragmentFD(ie, {'name': 'test'}, None)

# Generated at 2022-06-18 13:24:13.886390
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class MockInfoExtractor(object):
        IE_NAME = 'mock'
        IE_DESC = 'Mock info extractor'
        _VALID_URL = r'(?:mock)'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, url):
            return re.match(cls._VALID_URL, url) is not None


# Generated at 2022-06-18 13:24:22.131168
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(HttpQuietDownloader())
    ie.extract('http://example.com/')

    ie = TestIE(HttpQuietDownloader(gen_extractors(), gen_postprocessors(), match_filter_func()))

# Generated at 2022-06-18 13:24:32.361801
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_frag_downloader(info_dict):
        ydl = FileDownloader({
            'outtmpl': '%(id)s',
            'match_filter': match_filter_func(info_dict),
            'quiet': True,
        })
        ydl.add_info_extractor(gen_extractors()[info_dict['extractor']])
        ydl.download([info_dict['url']])


# Generated at 2022-06-18 13:24:36.016232
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .common import FileDownloader
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert issubclass(HttpQuietDownloader, FileDownloader)

# Generated at 2022-06-18 13:24:48.419313
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .downloader.http import HttpQuietDownloader
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'(?i)^https?://.*'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(HttpQuietDownloader())
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')

    ie = Test

# Generated at 2022-06-18 13:24:58.939473
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def test_fragment_download(url, ie_key, expected_frag_count, expected_frag_retries, expected_frag_skip):
        ie = get_info_extractor(ie_key)
        info = ie.extract(url)
        fd = FragmentFD(ie, {}, info)
        assert fd.params['fragment_retries'] == expected_frag_retries
        assert fd.params['skip_unavailable_fragments'] == expected_frag_skip
        assert fd.params['keep_fragments'] == False
        assert fd.params['nopart'] == False
        assert fd.params['noprogress'] == False
        assert f

# Generated at 2022-06-18 13:25:01.453280
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:25:11.708384
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'

        def __init__(self, downloader=None):
            self._downloader = downloader

        def _real_initialize(self):
            pass


# Generated at 2022-06-18 13:25:14.584098
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:26:39.161339
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    ydl = gen_extractors()['youtube']()
    HttpQuietDownloader(ydl, {'quiet': True})

# Generated at 2022-06-18 13:26:46.512769
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import ExtractorError

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'fakeid',
                'title': 'faketitle',
                'formats': [{
                    'url': 'http://example.com/video.mp4',
                    'format_id': 'mp4',
                }],
            }


# Generated at 2022-06-18 13:26:53.884098
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_str

    def test_extractor(ie):
        if ie.IE_NAME == 'generic':
            return

# Generated at 2022-06-18 13:27:00.553126
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'quiet': True,
        'noprogress': True,
        'nopart': True,
        'continuedl': True,
        'dump_intermediate_pages': True,
        'skip_download': True,
    })
    ydl.add_info_extractor(gen_extractors())
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(match_filter_func(lambda x: True))
    ydl.params['test'] = True
    ydl.params['noplaylist'] = True
    ydl.params['forcetitle'] = True

# Generated at 2022-06-18 13:27:06.734411
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .utils import DateRange

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'https?://.+'
        _TEST = {
            'url': 'http://example.com',
            'file': 'test.mp4',
            'info_dict': {
                'id': 'test',
                'ext': 'mp4',
                'title': 'test',
            },
        }

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': 'http://example.com/test.mp4',
                'title': 'test',
            }

    ie = TestIE()

# Generated at 2022-06-18 13:27:17.113978
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_downloader(downloader, url, expected_extractor_key):
        info_dict = downloader.extract(url)
        assert info_dict['extractor_key'] == expected_extractor_key
        downloader.process_info(info_dict)

    def _test_fragment_downloader(downloader, url, expected_extractor_key):
        info_dict = downloader.extract(url)
        assert info_dict['extractor_key'] == expected_extractor_key
        downloader.process_info(info_dict)
        assert downloader.params['noprogress'] is False
        assert downloader.params['quiet'] is False

    extractors = gen_extractors()


# Generated at 2022-06-18 13:27:26.699714
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class MockInfoExtractor(object):
        IE_NAME = 'mock'
        _WORKING = True

        def __init__(self, downloader=None, ie_key=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, url):
            return True


# Generated at 2022-06-18 13:27:36.330352
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.common import FileDownloader
    from .downloader.http import HttpFD
    from .compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'ratelimit': None,
                'retries': 0,
                'nopart': False,
                'test': False,
            }

# Generated at 2022-06-18 13:27:43.398032
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*'
        _TEST = {
            'url': 'http://example.com/',
            'info_dict': {
                'id': 'test',
            },
        }

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
            }

    ie = TestIE()
    ie.add_info_extractor(gen_extractors())
    ie.add_default_info_extractors

# Generated at 2022-06-18 13:27:47.452067
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test')
    ie.add_info_extractor(TestFD)
    ie.extract('http://localhost/')