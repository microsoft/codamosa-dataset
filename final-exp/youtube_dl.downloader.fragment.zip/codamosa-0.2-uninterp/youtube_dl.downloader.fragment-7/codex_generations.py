

# Generated at 2022-06-18 13:20:11.528780
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .common import InfoExtractor
    from .downloader.http import HttpFD
    from .compat import compat_urllib_request

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?example\.com/video\.mp4'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': 'http://example.com/video.mp4',
                'title': 'Test video',
            }

    gen_extractor_classes(TestIE)


# Generated at 2022-06-18 13:20:22.023534
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }
            self.extractors = gen_extractors()
            self.postprocessors = gen_postprocessors()

    class FakeLogger(object):
        def debug(self, msg):
            pass

        def warning(self, msg):
            pass

        def error(self, msg):
            pass

    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {})
    assert dl.ydl is ydl

# Generated at 2022-06-18 13:20:27.315002
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def test_download(url, ie_key, expected_filename, expected_status,
                      expected_total_frags, expected_frag_retries,
                      expected_skip_unavailable_frags,
                      expected_keep_fragments,
                      expected_fragment_base_url,
                      expected_fragment_base_headers,
                      expected_fragment_params):
        ie = get_info_extractor(ie_key)
        ie.extract(url)
        assert ie.working == True
        assert ie.fragment_base_url == expected_fragment_base_url
        assert ie.fragment_base_headers == expected_fragment_base_headers
        assert ie.fr

# Generated at 2022-06-18 13:20:38.962994
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_urlparse

    # Test for DASH
    ie = get_info_extractor('youtube')
    info = ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    assert 'formats' in info
    formats = info['formats']
    assert len(formats) > 0
    f = formats[0]
    assert 'url' in f
    url = f['url']
    assert url is not None
    assert url.startswith('http')
    assert '?' in url
    url, query = url.split('?', 1)
    assert url.endswith('.mp4')
    assert query.startswith('signature')

# Generated at 2022-06-18 13:20:49.679331
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie):
        if ie.IE_NAME == 'generic':
            return
        if ie.IE_NAME in ('youtube:playlist', 'youtube:search', 'youtube:channel', 'youtube:user', 'youtube:watchlater', 'youtube:recommended'):
            return
        if ie.IE_NAME in ('crunchyroll:playlist', 'crunchyroll:show'):
            return
        if ie.IE_NAME in ('metacafe', 'vimeo', 'soundcloud', 'mixcloud'):
            return
        if ie.IE_NAME in ('bandcamp:album', 'bandcamp:track'):
            return

# Generated at 2022-06-18 13:20:52.452833
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:20:57.932516
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .common import FileDownloader
    from ..utils import get_suitable_downloader

    assert issubclass(HttpQuietDownloader, HttpFD)
    assert issubclass(HttpQuietDownloader, FileDownloader)
    assert get_suitable_downloader(None, {'url': 'http://example.com'}) is HttpQuietDownloader

# Generated at 2022-06-18 13:21:10.646550
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.http import HttpFD

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': self,
            }
            self.cache = None
            self.progress_hooks = []

        def to_screen(self, *args, **kargs):
            pass

        def to_stdout(self, *args, **kargs):
            pass

        def to_stderr(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:21:23.629488
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.cache = None
            self.download_retcode = None
            self.to_screen = lambda *args, **kargs: None

        def add_info_extractor(self, ie):
            self.ie = ie

        def add_default_info_extractors(self):
            pass

        def process_ie_result(self, *args, **kargs):
            return args[0]

        def to_stdout(self, s):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

       

# Generated at 2022-06-18 13:21:35.565715
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_FragmentFD(info_dict):
        if info_dict.get('protocol') != 'm3u8_native':
            return
        if info_dict.get('extractor_key') != 'Youtube':
            return
        if info_dict.get('playlist_id') != 'PLwP_SiAcdui0KVebT0mU9Apz359a4ubsC':
            return
        if info_dict.get('playlist_title') != 'Youtube':
            return
        if info_dict.get('playlist_uploader') != 'Youtube':
            return

# Generated at 2022-06-18 13:22:09.288805
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .downloader.http import HttpFD
    from .utils import get_cachedir

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?example\.com/video\.mp4'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
            }

    ie = TestIE()
    ie.add_info_extractor(YoutubeIE.ie_key())
    ie.add_info_extractor(TestIE.ie_key())

# Generated at 2022-06-18 13:22:12.854944
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:22:26.070485
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .compat import compat_urllib_request

    class DummyIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test video',
                'ext': 'mp4',
            }

    ie = DummyIE(downloader=HttpQuietDownloader())
    ie.add_info_extractor(DummyIE.ie_key())
    ie.params['quiet'] = True
    ie.params['noprogress'] = True
    ie.params['continuedl'] = True
    ie.params['nopart'] = True
    ie.params['test'] = True
    ie.params

# Generated at 2022-06-18 13:22:34.296624
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ydl = get_info_extractor('youtube', {})
    fd = TestFD(ydl, {})
    assert fd.params == {}
    assert fd.ydl is ydl
    assert fd.FD_NAME == 'test'

# Generated at 2022-06-18 13:22:46.190021
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.get = self.__getitem__

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': None,
            }
            self.extractors = gen_extractors()
            self.extractors_by_id = dict((e.IE_NAME, e) for e in self.extractors)
            self.params = {}

        def to_screen(self, *args, **kargs):
            pass



# Generated at 2022-06-18 13:22:58.201569
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestIE(object):
        IE_NAME = 'test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'(?:https?://)?(?:\w+\.)?test\.com/'

        @staticmethod
        def suitable(url):
            return True

        @staticmethod
        def extract(url):
            return {
                'id': 'testid',
                'title': 'test title',
                'formats': [
                    {'url': 'http://test.com/video.mp4', 'format_id': 'mp4'},
                    {'url': 'http://test.com/video.flv', 'format_id': 'flv'},
                ],
            }


# Generated at 2022-06-18 13:23:07.847762
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import get_info_extractor

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.cache = {}

        def add_info_extractor(self, ie):
            self.ie = ie

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def download(self, *args, **kargs):
            return True

        def temp_name(self, *args, **kargs):
            return '-'


# Generated at 2022-06-18 13:23:20.721932
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'(?i)https?://.*'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE)


# Generated at 2022-06-18 13:23:30.976094
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp


# Generated at 2022-06-18 13:23:43.287876
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError

    class FakeIE(InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'(?i)^https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'fakeid',
                'title': 'faketitle',
                'formats': [
                    {'format_id': 'fakeformat', 'url': 'http://example.com/fake.mp4'},
                ],
            }

    class FakeFD(FragmentFD):
        FD_NAME = 'fake'

        def real_download(self, filename, info_dict):
            return True

    ie = FakeIE(FakeFD())
    ie.params['test'] = True
    ie

# Generated at 2022-06-18 13:24:44.749406
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    # Test that HttpQuietDownloader is initialized with the same params as
    # FileDownloader

# Generated at 2022-06-18 13:24:50.209911
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..downloader.http import HttpFD

    ydl = FileDownloader({})
    gen_extractors(ydl)
    assert isinstance(ydl.get_info_extractor('http://www.youtube.com/watch?v=BaW_jenozKc'), HttpFD)

# Generated at 2022-06-18 13:25:02.583635
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestIE(get_info_extractor('Test')):
        IE_NAME = 'Test'
        _VALID_URL = r'https?://(?:www\.)?test\.com/video\.html'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'formats': [
                    {'url': 'http://example.com/video.mp4'},
                ],
            }

    ie = TestIE()
    info = ie.extract('http://www.test.com/video.html')
    fd = FragmentFD(ie._ydl, ie.params)
    fd.add_info_extractor(ie)
    fd.download(info)

# Generated at 2022-06-18 13:25:12.516490
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    gen_extractors()
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE()
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE)

# Generated at 2022-06-18 13:25:24.021432
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_frag_downloader(info_dict):
        if info_dict.get('protocol') != 'm3u8_native':
            return
        fd = FragmentFD(
            {
                'noprogress': True,
                'quiet': True,
                'format': 'best',
                'outtmpl': '%(id)s.%(ext)s',
            },
            gen_extractors(),
            match_filter_func('best'))
        fd.add_info_extractor(info_dict)
        fd.download(info_dict['id'])


# Generated at 2022-06-18 13:25:36.331676
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.external import ExternalFD
    from .downloader.rtmp import RTMPDownloader
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD

    # Test that HttpQuietDownloader is used by all downloaders and postprocessors
    # that use HttpFD
    for ie in gen_extractors():
        if not ie.IE_NAME.startswith('generic') and ie.IE_NAME != 'googledrive':
            ie = ie()
            if ie.params.get('http_chunk_size') is None:
                ie

# Generated at 2022-06-18 13:25:39.452362
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:25:50.018320
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie):
        if ie.IE_NAME == 'generic':
            return
        if ie.IE_NAME in ('youtube:playlist', 'youtube:search', 'youtube:channel', 'youtube:user', 'youtube:watchlater', 'youtube:recommended', 'youtube:top_rated', 'youtube:trending'):
            return
        if ie.IE_NAME in ('crunchyroll:show', 'crunchyroll:collection', 'crunchyroll:media'):
            return

# Generated at 2022-06-18 13:25:55.854011
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    ydl = gen_extractors()['youtube']()
    dl = HttpQuietDownloader(ydl, {})
    assert dl.ydl is ydl
    assert dl.params == {}

# Generated at 2022-06-18 13:26:04.336222
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_FragmentFD(name, url, expected_extractor_class):
        for ie in gen_extractors():
            if match_filter_func(ie.IE_NAME)(name):
                assert isinstance(ie, expected_extractor_class)
                return ie.suitable(url)
        assert False

    assert _test_FragmentFD('youtube:playlist', 'PLwP_SiAcdui0KVebT0mU9Apz359a4ubsC', FragmentFD)
    assert _test_FragmentFD('youtube:user_uploads', 'UCkUq-s6z57uJFUFBvZIVTyg', FragmentFD)

# Generated at 2022-06-18 13:27:49.856573
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    gen_extractors()
    from ..extractor import get_info_extractor
    ie = get_info_extractor('Youtube')
    ie.params['quiet'] = True
    ie.params['noprogress'] = True
    ie.params['noplaylist'] = True
    ie.params['forcetitle'] = True
    ie.params['forceid'] = True
    ie.params['forcethumbnail'] = True
    ie.params['forceurl'] = True
    ie.params['forcedescription'] = True
    ie.params['forcefilename'] = True
    ie.params['forcejson'] = True
    ie.params['simulate'] = True
    ie.params['skip_download'] = True
    ie.params['format'] = 'bestvideo'

# Generated at 2022-06-18 13:27:59.193141
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestIE(object):
        IE_NAME = 'test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'(?:https?://)?(?:\w+\.)?example\.com/'

# Generated at 2022-06-18 13:28:01.361532
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-18 13:28:14.171246
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?test\.com/video\.mp4'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': 'http://test.com/video.mp4',
                'title': 'test',
            }

    ie = TestIE(HttpQuietDownloader(None, {'quiet': True}))
    ie.extract('http://test.com/video.mp4')

    gen_extractors()
    gen_postprocessors()

# Generated at 2022-06-18 13:28:23.762863
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeYDL:
        def __init__(self):
            self.params = {}

        def add_info_extractor(self, ie):
            self.ie = ie

        def add_post_processor(self, pp):
            self.pp = pp

        def to_screen(self, *args, **kargs):
            pass

    ydl = FakeYDL()
    ie = get_info_extractor('youtube')
    ie.ydl = ydl
    ie.params = {}
    ie.add_default_info_extractors()
    ie.add_default_downloader()
    ie.add_default_processors()
    ie.add_default_post_processors()
    ie.extract

# Generated at 2022-06-18 13:28:36.858829
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL:
        def __init__(self):
            self.params = {}
            self.extractors = gen_extractors()
            self.extractor_descriptions = {}
            for ie in self.extractors:
                self.extractor_descriptions[ie.IE_NAME] = ie.IE_DESC

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:28:47.211768
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_extract(self, url):
            ie = get_info_extractor(url)
            return ie.extract(url)

    test_fd = TestFD(None)
    test_fd.params['skip_unavailable_fragments'] = True
    test_fd.params['fragment_retries'] = 1
    test_fd.params['keep_fragments'] = True
    test_fd.params['noprogress'] = True
    test_fd.params['quiet'] = True
    test_fd.params['nopart'] = True
    test_fd.params['test'] = True

# Generated at 2022-06-18 13:28:57.093691
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
            }
            self.params.update(gen_extractors())
            self.params.update(gen_extractor_classes())

        def add_info_extractor(self, ie):
            self.params['extractors'].append(ie)

        def add_default_info_extractors(self):
            for ie in gen_extractor_classes().values():
                self.add_info_extractor(ie)


# Generated at 2022-06-18 13:29:07.561272
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return match_filter_func(info_dict, ['http://www.youtube.com/watch?v=BaW_jenozKc'])

    def test_download(ydl, info_dict):
        ydl.process_ie_result(info_dict)

    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'matchfilter': test_filter,
        'test': True,
    })
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.add_post_processor(test_download)

# Generated at 2022-06-18 13:29:16.804250
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
