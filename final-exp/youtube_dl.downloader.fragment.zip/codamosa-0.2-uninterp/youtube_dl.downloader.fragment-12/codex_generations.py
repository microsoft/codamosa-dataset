

# Generated at 2022-06-18 13:20:05.239997
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = 'test'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
            }

    ie = FakeInfoExtractor()

# Generated at 2022-06-18 13:20:09.786963
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    ydl = gen_extractors()[0](params={})
    dl = HttpQuietDownloader(ydl, {})
    assert dl.ydl is ydl
    assert dl.params == {}

# Generated at 2022-06-18 13:20:20.950286
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
                'simulate': True,
                'format': 'best',
            }
            self.extractors = gen_extractors()
            self.params['extractors'] = self.extractors
            self.params['extractor_descriptions'] = get_descriptions(self.extractors)
            self.params['extractor_keys'] = list(self.extractors.keys())
            self.params['forced_extractors'] = []

# Generated at 2022-06-18 13:20:34.038994
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import ExtractorError

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'(?:http://)?(?P<host>test\.com)/(?P<id>[0-9]+)'

# Generated at 2022-06-18 13:20:43.731321
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..postprocessor import gen_pp


# Generated at 2022-06-18 13:20:45.575918
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)
    assert FragmentFD.__name__ == 'FragmentFD'
    assert FragmentFD.__doc__ is not None

# Generated at 2022-06-18 13:20:54.539794
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def test_frag_download(ie, url, expected_frag_count, expected_frag_retries, expected_frag_skip):
        ie = get_info_extractor(ie)()
        ie.params.update({
            'fragment_retries': expected_frag_retries,
            'skip_unavailable_fragments': expected_frag_skip,
        })
        ie.add_info_extractor(ie)
        ie.extract(url)
        assert ie.fragment_count == expected_frag_count

    test_frag_download('generic', 'http://example.com/', 0, 0, False)

# Generated at 2022-06-18 13:20:57.933258
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:21:10.638459
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..downloader.external import ExternalFD
    from ..postprocessor import gen_pp


# Generated at 2022-06-18 13:21:15.126805
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpDownloader
    class DummyIE(InfoExtractor):
        def __init__(self, downloader=None):
            self._downloader = downloader
        def _real_initialize(self):
            pass
        def _real_extract(self, url):
            return {'id': 'test'}
    class DummyFD(HttpDownloader):
        def __init__(self, ydl, params):
            super(DummyFD, self).__init__(ydl, params)
            self.ie = DummyIE(downloader=self)
    dl = DummyFD({}, {})
    assert isinstance(dl.ydl, DummyFD)
    assert isinstance(dl.ie, DummyIE)

# Generated at 2022-06-18 13:21:43.460914
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return info_dict['id'] == 'test_id'

    def test_hook(d):
        pass

    fd = FragmentFD(
        gen_extractors(),
        {
            'format': 'best',
            'outtmpl': '%(id)s',
            'match_filter': match_filter_func(test_filter),
            'progress_hooks': [test_hook],
        },
    )
    assert fd.params['outtmpl'] == '%(id)s'
    assert fd.params['match_filter'] == test_filter
    assert fd.params['progress_hooks'] == [test_hook]

# Generated at 2022-06-18 13:21:51.978930
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from .common import FileDownloader

    # Create a FileDownloader object
    ydl = FileDownloader({})
    ydl.add_info_extractor(gen_extractors())
    ydl.params['noprogress'] = True
    ydl.params['logger'] = ydl

    # Create a FragmentFD object
    ffd = FragmentFD(ydl, {'noprogress': True})

    # Test the constructor
    assert ffd.ydl is ydl
    assert ffd.params == {'noprogress': True}

    # Test the _match_entry() method

# Generated at 2022-06-18 13:22:01.135327
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func


# Generated at 2022-06-18 13:22:11.062906
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }
            self.cache = None

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def download(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:22:24.423825
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.setdefault('extractor_key', 'test')

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': None,
                'progress_hooks': [],
                'extractors': gen_extractors(),
                'match_filter': match_filter_func('all'),
            }

    ydl = FakeYDL()
    info_dict = FakeInfoDict()

# Generated at 2022-06-18 13:22:35.304374
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_urlparse

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.cache = None

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def report_destination(self, *args, **kargs):
            pass

        def temp_name(self, *args, **kargs):
            return 'TEMP'


# Generated at 2022-06-18 13:22:43.004485
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return match_filter_func(info_dict, {'protocol': 'http'})

    for ie in gen_extractors():
        if ie.suitable(test_filter) and ie.IE_NAME != 'generic':
            ie.extract_info(ie.suitable(test_filter)[0], download=False)

# Generated at 2022-06-18 13:22:55.217393
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestIE(get_info_extractor('Test')):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'ext': 'mp4',
                'title': 'test',
                'formats': [{
                    'url': 'http://example.com/test.mp4',
                    'format_id': 'test',
                }],
            }

    ie = TestIE()
    fd = FragmentFD(ie, {}, ie.suitable(None), None)
    fd.add_info_extractor(ie)
    fd.params['skip_download'] = True
    fd.params['noprogress'] = True

# Generated at 2022-06-18 13:23:05.531269
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_downloader(downloader):
        if downloader.params.get('test', False):
            return False
        if downloader.params.get('noplaylist', False):
            return False
        if downloader.params.get('nocheckcertificate', False):
            return False
        if downloader.params.get('age_limit', 0) > 0:
            return False
        return True

    extractors = [x for x in gen_extractors() if _test_downloader(x)]

# Generated at 2022-06-18 13:23:16.744671
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp

    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'quiet': True,
        'noprogress': True,
        'nooverwrites': True,
        'format': 'best',
        'extractors': gen_extractors(),
        'postprocessors': gen_pp(),
    })
    dl = HttpQuietDownloader(ydl, {'continuedl': True})
    assert dl.params['noprogress'] is True
    assert dl.params['quiet'] is True
    assert dl.params['continuedl'] is True

# Generated at 2022-06-18 13:24:00.248355
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def test_downloader(ydl, params, info_dict):
        dl = HttpQuietDownloader(ydl, params)
        dl.add_info_extractor(gen_extractors(ydl, match_filter_func('http://www.youtube.com/watch?v=BaW_jenozKc')))
        dl.download(info_dict['id'], info_dict)

    def test_http_downloader(ydl, params, info_dict):
        dl = HttpFD(ydl, params)

# Generated at 2022-06-18 13:24:08.939499
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    ie = get_info_extractor('youtube')
    fd = FragmentFD(ie, {}, ie.ydl)
    assert fd.FD_NAME == 'fragment'
    assert fd.params == {}
    assert fd.ydl is ie.ydl
    assert fd.ie is ie
    assert fd.params == {}
    assert fd.to_screen == ie.to_screen
    assert fd.report_warning == ie.report_warning
    assert fd.report_error == ie.report_error
    assert fd.troubleshoot == ie.troubleshoot
    assert fd.report_destination == ie.report_destination

# Generated at 2022-06-18 13:24:17.070787
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_FragmentFD(extractor_name, url):
        extractor = gen_extractors()[extractor_name]
        info_dict = extractor._real_extract(url)
        fd = FragmentFD(None, info_dict, {'skip_download': True})
        return fd

    # Test for DASH
    fd = _test_FragmentFD('YoutubeIE', 'http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-18 13:24:25.965927
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_downloader(info_dict):
        return FragmentFD(
            gen_extractors(),
            match_filter_func(info_dict),
            {
                'quiet': True,
                'noprogress': True,
                'nopart': True,
                'retries': 0,
            })

    # Test for DASH

# Generated at 2022-06-18 13:24:33.476031
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(ie_key):
        return match_filter_func(ie_key, ['youtube'])(ie_key)

    for ie in gen_extractors():
        if test_filter(ie.IE_NAME):
            dl = HttpQuietDownloader(None, {'quiet': True})
            dl.add_info_extractor(ie)
            break
    else:
        assert False, 'No suitable extractor found'

    return dl

# Generated at 2022-06-18 13:24:39.673018
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test_ie')
    ie.add_info_extractor(TestFD.ie_key())
    ie.extract('test')

# Generated at 2022-06-18 13:24:51.252525
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_frag_downloader(ydl, info_dict):
        class TestFD(FragmentFD):
            FD_NAME = 'test'

            def real_download(self, filename, info_dict):
                return True

        return TestFD(ydl).download(info_dict)

    def test_frag_extractor(ydl, info_dict):
        class TestIE(object):
            IE_NAME = 'test'
            IE_DESC = 'Test IE'
            _VALID_URL = r'(?i)^https?://.*'

            def __init__(self, ie_url, ie_name, ie_desc):
                self._url = ie_url
                self.IE_NAME = ie_

# Generated at 2022-06-18 13:25:03.705240
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.extractors = gen_extractors()
            self.IE_NAME = 'test'

        def add_info_extractor(self, ie):
            self.extractors.append(ie)

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:25:08.391412
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'
    assert HttpQuietDownloader.__module__ == 'youtube_dl.downloader.fragment'

# Generated at 2022-06-18 13:25:11.964287
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'
    assert HttpQuietDownloader.__module__ == 'youtube_dl.downloader.fragment'

# Generated at 2022-06-18 13:26:30.380030
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:26:39.122729
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import get_info_extractor

    class FakeYDL:
        params = {}
        def __init__(self):
            self.cache = {}
        def add_info_extractor(self, ie):
            self.cache[ie.ie_key()] = ie
        def extract_info(self, url, download=False, ie_key=None, extra_info={}):
            if ie_key is None:
                ie = get_info_extractor(url)
            else:
                ie = self.cache[ie_key]
            return ie.extract(url)

    ydl = FakeYDL()
    ydl.add_info_extractor(get_info_extractor('Generic'))

# Generated at 2022-06-18 13:26:46.483508
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
                'nopart': True,
                'ratelimit': '1k',
                'retries': 10,
                'test': True,
            }
            self.params.update(gen_extractors())
            self.params.update(match_filter_func())

        def to_screen(self, *args, **kargs):
            pass

    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, ydl.params)
    assert dl.ydl

# Generated at 2022-06-18 13:26:49.386528
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    ydl = gen_extractors()[0]
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.params['quiet']
    assert dl.to_screen == dl._write_string

# Generated at 2022-06-18 13:26:56.853753
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return match_filter_func(info_dict, {'protocol': 'http'})

    extractors = gen_extractors()
    extractors = [e for e in extractors if test_filter(e.IE_NAME)]
    for ie in extractors:
        ie = ie(downloader=None)
        if ie.IE_NAME in ('YoutubeLive', 'YoutubeLiveDASH'):
            continue
        if ie.IE_NAME in ('Youtube', 'YoutubePlaylist'):
            continue
        if ie.IE_NAME in ('YoutubeSearch', 'YoutubeSearchDate'):
            continue

# Generated at 2022-06-18 13:27:02.047170
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return info_dict['id'] == 'test_id'

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ydl = gen_extractors()
    ydl.add_info_extractor(TestFD(ydl, {'test': True}))
    ydl.params['match_filter'] = match_filter_func(test_filter)
    ydl.download(['test_id'])

# Generated at 2022-06-18 13:27:08.347283
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    dl = HttpQuietDownloader(ie, {'quiet': True})
    dl.to_screen('test')
    assert dl.params['quiet']

    dl = HttpQuietDownloader(ie, {'quiet': False})
    dl.to_screen('test')
   

# Generated at 2022-06-18 13:27:14.323563
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test')
    ie.add_info_extractor(TestFD)
    ie.extract('http://localhost/')

# Generated at 2022-06-18 13:27:24.029770
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.ydl = ydl
            self.params = params
            self.to_screen = ydl.to_screen
            self.report_warning = ydl.report_warning
            self.report_error = ydl.report_error
            self.report_destination = ydl.report_destination
            self.temp_name = ydl.temp_name
            self.try_rename = ydl.try_rename
            self.calc_eta = ydl.calc_eta
            self.format_bytes = ydl.format_bytes

# Generated at 2022-06-18 13:27:29.245465
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test')
    ie.add_info_extractor(TestFD)
    ie.extract('test')