

# Generated at 2022-06-18 13:20:02.021433
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-18 13:20:14.259693
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.ie = get_info_extractor('youtube')

        def add_info_extractor(self, ie):
            self.ie = ie

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def report_file_already_downloaded(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:20:23.436858
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func


# Generated at 2022-06-18 13:20:28.216429
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import get_info_extractor

    class FakeYDL:
        params = {}
        def __init__(self):
            self.to_screen = sys.stdout.write
            self.to_stderr = sys.stderr.write

    ydl = FakeYDL()
    ie = get_info_extractor('generic')
    ie.ydl = ydl

    fd = FragmentFD(ydl, ie, {'url': 'http://example.com'})
    assert fd.params == {
        'fragment_retries': 10,
        'keep_fragments': False,
        'skip_unavailable_fragments': False,
    }

# Generated at 2022-06-18 13:20:39.786035
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import get_cachedir

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {'id': 'test', 'title': 'test'}

    ie = FakeInfoExtractor()
    ie.add_info_extractor(ie)
    ie.add_info_extractor(ie)
    ie.add_info_extractor(ie)
    ie.add_info_extractor(ie)
    ie.add_info_extractor(ie)
    ie.add_info_extractor(ie)

# Generated at 2022-06-18 13:20:50.368573
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..utils import prepend_extension
    from .common import FakeYDL

    ydl = FakeYDL()
    ydl.params['noprogress'] = False
    ydl.params['logger'] = ydl
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.add_post_processor(gen_pp()[0])
    ydl.add_post_processor(gen_pp()[1])

# Generated at 2022-06-18 13:21:00.620666
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.external import ExternalFD

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        _VALID_URL = r'(?i)^https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    class DummyPP(object):
        def __init__(self, downloader=None):
            pass

        def run(self, information):
            return information

    gen_extractors()
    gen_postprocessors()

# Generated at 2022-06-18 13:21:14.073437
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

    class FakeInfoDict(object):
        def __init__(self):
            self.url = 'http://example.com'
            self.http_headers = {'User-Agent': 'FakeUA'}

    class FakeRequest(object):
        def __init__(self, url, data, headers):
            self.url = url
            self.data = data
            self.headers = headers

   

# Generated at 2022-06-18 13:21:26.837616
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'
        _VALID_URL = r'(?i)^https?://.*\.test(?:/|$)'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, url):
            return re.match(cls._VALID_URL, url) is not None

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            pass

    ie = FakeInfoExtractor()
    ie.add_info_extractor(get_info_extractor('youtube'))
   

# Generated at 2022-06-18 13:21:37.718501
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_downloader(info_dict):
        downloader = FragmentFD(gen_extractors(), {})
        downloader.add_info_extractor(info_dict)
        downloader.params.update({
            'noprogress': True,
            'quiet': True,
            'skip_download': True,
        })
        return downloader

    def _test_download(downloader, url):
        info_dict = downloader.extract_info(url, download=False)
        return downloader.process_ie_result(info_dict, download=True)


# Generated at 2022-06-18 13:22:15.290290
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_frag_downloader(info_dict):
        def _test_frag_downloader(self, *args, **kwargs):
            return FragmentFD(self, *args, **kwargs)
        return _test_frag_downloader

    for ie in gen_extractors():
        if ie.IE_NAME == 'generic':
            continue
        if not hasattr(ie, '_WORKING'):
            continue
        if not ie._WORKING:
            continue
        if not ie.suitable(ie.url_result('http://example.com/')):
            continue
        if not ie.is_fragmented():
            continue

# Generated at 2022-06-18 13:22:27.277053
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            self._prepare_and_start_frag_download({
                'filename': filename,
                'total_frags': 2,
            })
            self._finish_frag_download({
                'filename': filename,
                'tmpfilename': '-',
                'complete_frags_downloaded_bytes': 10,
                'started': time.time(),
            })
            return True

    ie = get_info_extractor('test')
    ie.add_info_extractor(TestFD)
    ie.extract('test')

# Generated at 2022-06-18 13:22:36.875082
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test')

# Generated at 2022-06-18 13:22:49.119574
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

        def warning(self, msg):
            pass

        def error(self, msg):
            pass

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        _VALID_URL = r'(?i)^https?://.+'

        def __init__(self):
            self._downloader = None


# Generated at 2022-06-18 13:23:01.008775
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.external import ExternalFD
    from .downloader.rtmp import RTMPFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.http import HttpFD
    from .downloader.fragment import FragmentFD
    from .downloader.ism import IsmFD
    from .downloader.m3u8 import M3u8FD
    from .downloader.dash import DashFD
    from .downloader.hls import HlsFD
    from .downloader.http import HttpFD

# Generated at 2022-06-18 13:23:09.773955
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .compat import compat_urllib_request

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractor({'test': TestIE}))
    ie.add_info_extractor(TestIE)
    ie.extract('http://example.com/')

    # Test that HttpQuietDownloader is used by default

# Generated at 2022-06-18 13:23:22.489898
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader.external import ExternalFD
    from ..downloader.http import HttpFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hls import HlsFD
    from ..downloader.hls import HlsNativeFD
    from ..downloader.ism import IsmFD
    from ..downloader.f4m import F4mFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpQuietDownloader

    # Test that HttpQuietDownloader is a subclass of HttpFD


# Generated at 2022-06-18 13:23:32.144019
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .utils import ExtractorError

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'Fake'
        _VALID_URL = r'(?i)^https?://.+'
        _TEST = {
            'url': 'http://fake.com/video.mp4',
            'file': 'video.mp4',
            'info_dict': {
                'id': 'fake',
                'ext': 'mp4',
                'title': 'fake video',
            },
        }

        def _real_extract(self, url):
            raise ExtractorError('test', expected=True)

    gen_extractor.add_ie(FakeInfoExtractor)


# Generated at 2022-06-18 13:23:45.016907
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_fragment_downloader(ydl, info_dict):
        def _test_fragment_downloader(ydl, info_dict):
            info_dict['url'] = info_dict['fragment_base_url']
            info_dict['fragments'] = [
                {
                    'url': '%s-Frag1' % info_dict['fragment_base_url'],
                    'duration': 1,
                },
                {
                    'url': '%s-Frag2' % info_dict['fragment_base_url'],
                    'duration': 1,
                },
            ]
            info_dict['skip_unavailable_fragments'] = True

# Generated at 2022-06-18 13:23:55.349426
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test_fragments')
    ie.add_info_extractor(TestFD)

    def test_download(url, params, expected_frag_count):
        params = dict(params)
        params['format'] = 'test'
        params['noplaylist'] = True
        params['nocheckcertificate'] = True
        params['quiet'] = True
        params['skip_download'] = True
        params['match_filter'] = match_filter_func(params.get('match_filter'))

# Generated at 2022-06-18 13:24:54.102963
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
                'format': 'best',
                'outtmpl': '%(id)s',
                'ignoreerrors': False,
                'ratelimit': None,
                'retries': 10,
                'continuedl': True,
                'nopart': False,
                'logger': None,
                'test': False,
            }
            self.cache = None
            self.server = None
            self.extractor_descs = gen_extractors()

# Generated at 2022-06-18 13:25:06.596403
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    gen_extractors()
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .compat import compat_str

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE()
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE)


# Generated at 2022-06-18 13:25:15.107003
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request

    class TestIE(object):
        IE_NAME = 'test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, url):
            return re.match(cls._VALID_URL, url) is not None


# Generated at 2022-06-18 13:25:21.883722
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class DummyYDL(object):
        params = {}
        def __init__(self):
            self.to_screen = lambda *args, **kargs: None
    ydl = DummyYDL()
    hqd = HttpQuietDownloader(ydl, {'continuedl': True})
    assert hqd.params['continuedl'] is True
    assert hqd.ydl is ydl
    assert hqd.to_screen is ydl.to_screen

# Generated at 2022-06-18 13:25:34.959853
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..downloader.external import ExternalFD
    from ..downloader.http import HttpFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hls import HlsFD
    from ..downloader.hls import HlsNativeFD
    from ..downloader.f4m import F4mFD
    from ..downloader.ism import IsmFD
    from ..downloader.fragment import FragmentFD

    # Test that HttpQuietDownloader is used by all downloaders
    # that use HttpFD
    for ie in gen_extractors():
        if ie.ie_key() in ['generic', 'playlist']:
            continue

# Generated at 2022-06-18 13:25:46.183843
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.common import FileDownloader
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    # Create a dummy InfoExtractor
    class DummyIE(InfoExtractor):
        IE_NAME = 'Dummy'
        _VALID_URL = r'(?i)^https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test video',
                'url': url,
                'ext': 'mp4',
                'format': 'mp4',
            }

    ie = DummyIE(FileDownloader({}))
   

# Generated at 2022-06-18 13:25:54.117583
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp

    ydl = FileDownloader({
        'quiet': True,
        'noprogress': True,
        'logger': None,
        'progress_hooks': [],
        'extractor_key': 'Youtube',
        'extractors': gen_extractors(),
        'postprocessors': gen_pp(),
        'params': {},
        'prefer_insecure': False,
    })
    dl = HttpQuietDownloader(ydl, {'quiet': True, 'noprogress': True})
    assert dl.params['quiet']
    assert dl.params['noprogress']

# Generated at 2022-06-18 13:25:59.682293
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def test_frag_download(ie, url, expected_frag_count, expected_frag_retries, expected_frag_skip):
        ie = get_info_extractor(ie)
        ie.params = {
            'fragment_retries': expected_frag_retries,
            'skip_unavailable_fragments': expected_frag_skip,
        }
        ie.add_info_extractor(FragmentFD)
        info = ie.extract(url)
        assert info['fragment_count'] == expected_frag_count
        assert info['fragment_retries'] == expected_frag_retries
        assert info['fragment_skip'] == expected_frag

# Generated at 2022-06-18 13:26:06.584376
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader.external import ExternalFD
    from ..downloader.http import HttpFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hds import HdsFD
    from ..downloader.ism import IsmFD
    from ..downloader.m3u8 import M3U8FD
    from ..downloader.common import FileDownloader

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-18 13:26:15.430388
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_frag_downloader(info_dict):
        if info_dict.get('protocol') != 'm3u8_native':
            return None
        return FragmentFD(
            {
                'format': 'best',
                'noprogress': True,
                'quiet': True,
                'nopart': True,
                'retries': 10,
                'fragment_retries': 10,
                'skip_unavailable_fragments': True,
                'keep_fragments': True,
            },
            None,
            gen_extractors(),
            match_filter_func('best'))

    def _test_download(url):
        from ..extractor import gen_extractor

# Generated at 2022-06-18 13:28:07.840834
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    dl = HttpQuietDownloader(ie, {'quiet': True})
    assert dl.params['quiet'] is True
    assert dl.params['noprogress'] is True
    assert dl.params['progress_with_newline'] is False

# Generated at 2022-06-18 13:28:11.217386
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:28:21.561802
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {'id': 'test_id'}

    ie = TestIE(gen_extractors())
    ie.add_info_extractor(TestIE.ie_key())
    ie.add_default_info_extractors()

    def test_hook(d):
        if d['status'] == 'finished':
            assert d['filename'] == 'test_id.mp4'
            assert d['elapsed'] > 0
            assert d['total_bytes'] > 0
            assert d['downloaded_bytes'] > 0
            assert d['speed'] > 0

# Generated at 2022-06-18 13:28:27.627739
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)
    assert FragmentFD.__name__ == 'FragmentFD'
    assert FragmentFD.__module__ == 'youtube_dl.downloader.fragment'
    assert FragmentFD.FD_NAME == 'fragment'
    assert FragmentFD.RETRY_MAX == 10
    assert FragmentFD.RETRY_SLEEP == 5

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-18 13:28:39.080391
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

    class FakeIE(object):
        def __init__(self):
            self.ydl = FakeYDL()
            self.params = {}

    class FakeInfoDict(dict):
        def __init__(self):
            super(FakeInfoDict, self).__init__()

# Generated at 2022-06-18 13:28:49.871411
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.http import HttpFD
    from .downloader.rtmp import RtmpFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.external import ExternalFD
    from .downloader.fragment import FragmentFD

    # Test that all downloader classes are instantiated correctly
    downloader_classes = [
        HttpFD,
        RtmpFD,
        F4mFD,
        HlsFD,
        DashSegmentsFD,
        ExternalFD,
        FragmentFD,
    ]

# Generated at 2022-06-18 13:28:58.985011
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'Test',
            }

    ie = TestIE(HttpQuietDownloader())
    ie.extract('http://example.com/')

    ie = TestIE(HttpFD())
    ie.extract('http://example.com/')

    ie = TestIE(HttpQuietDownloader())

# Generated at 2022-06-18 13:29:09.481994
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func


# Generated at 2022-06-18 13:29:20.854676
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie, url):
        ie = gen_extractors(ie)
        ie = match_filter_func(ie)(url)
        return ie

    def test_downloader(ie, url):
        ie = test_extractor(ie, url)
        ie.download(url)

    test_downloader('dash', 'http://dash.edgesuite.net/envivio/EnvivioDash3/manifest.mpd')
    test_downloader('hlsnative', 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8')

# Generated at 2022-06-18 13:29:28.850141
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func
