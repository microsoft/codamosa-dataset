

# Generated at 2022-06-18 13:20:10.732489
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': self,
            }
            self.cache = None
            self.extractor_desc = {}
            self.extractors = gen_extractors()
            self.IE_NAME = 'fake'
            self.ie = InfoExtractor(self, 'fake')

        def to_screen(self, message, skip_eol=False):
            sys.stderr.write(message + ('\n' if not skip_eol else ''))

        def trouble(self, message, tb=None):
            raise Exception(message)


# Generated at 2022-06-18 13:20:21.569161
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp


# Generated at 2022-06-18 13:20:34.650505
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import get_info_extractor

    class FakeYDL:
        params = {}
        def __init__(self):
            self._ies = []
            self.cache = None
        def add_info_extractor(self, ie):
            self._ies.append(ie)
        def extract_info(self, url, download=False):
            for ie in self._ies:
                if ie.suitable(url):
                    return ie.extract(url)
            else:
                raise Exception('no suitable IE found')

    ydl = FakeYDL()
    ie = get_info_extractor(ydl, 'GenericIE')

# Generated at 2022-06-18 13:20:43.005393
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    # Test for constructor of class FragmentFD
    class TestFD(FragmentFD):
        FD_NAME = 'test'
        def real_download(self, filename, info_dict):
            return True

    ydl = TestFD({
        'outtmpl': '%(id)s',
        'matchfilter': lambda info: match_filter_func('all', info),
        'skip_download': True,
    })
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.download(['http://example.com/'])

# Generated at 2022-06-18 13:20:53.426789
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_downloader(ydl, info_dict):
        dl = HttpQuietDownloader(ydl, info_dict)
        assert dl.ydl is ydl
        assert dl.params == info_dict
        assert dl.params.get('quiet') is True
        assert dl.params.get('noprogress') is True
        assert dl.params.get('continuedl') is True
        assert dl.params.get('nopart') is True
        assert dl.params.get('test') is True
        assert dl.params.get('retries') == 0
        assert dl.params.get('ratelimit') == 'nolimit'

    # Test with default params


# Generated at 2022-06-18 13:21:04.946450
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.extractors = gen_extractors()
            self.IE_NAME = 'test'
            self.IE_DESC = 'test'

        def add_info_extractor(self, ie):
            self.extractors.append(ie)

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:21:18.404037
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'quiet': True,
                'noprogress': True,
                'ratelimit': None,
                'retries': 0,
                'nopart': False,
                'test': False,
            }
            self.extractor_descriptions = gen_extractors()
            self.params['match_filter'] = match_filter_func(self.extractor_descriptions)

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:21:31.249254
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    gen_extractors()
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE()
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE)
   

# Generated at 2022-06-18 13:21:35.662428
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.params = {}
    ie.add_default_info_extractors()
    dl = HttpQuietDownloader(ie, {})
    assert dl.ydl is ie
    assert dl.params == {}

# Generated at 2022-06-18 13:21:45.455748
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'quiet': True,
        'noprogress': True,
        'nooverwrites': True,
        'format': 'best',
        'logger': None,
        'progress_hooks': [],
    })
    ydl.add_info_extractor(gen_extractors())
    ydl.add_default_info_extractors()
    ydl.params['match_filter'] = match_filter_func()
    ydl.add_progress_hook(lambda d: None)
    ydl.add_progress_hook(lambda d: None)


# Generated at 2022-06-18 13:22:23.485247
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'(?i)^https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'url': url,
            }

    ie = TestIE(gen_extractors())

# Generated at 2022-06-18 13:22:34.603638
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_constructor(name, url, expected_result):
        for ie in gen_extractors():
            if match_filter_func(ie.IE_NAME)(name):
                ie = ie()
                ie.add_default_info_extractors()
                ie.extract(url)
                assert isinstance(ie._downloader, expected_result)
                return
        assert False, 'Extractor for %r not found' % name

    test_constructor('youtube:playlist', 'PLwP_SiAcdui0KVebT0mU9Apz359a4ubsC', FragmentFD)

# Generated at 2022-06-18 13:22:40.524884
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test')
    ie.add_info_extractor(TestFD)
    ie.extract('http://localhost/')

# Generated at 2022-06-18 13:22:52.538156
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
            }
            self.params.update(HttpFD.params)
            self.params['outtmpl'] = '%(id)s'

    ydl = FakeYDL()
    ie = InfoExtractor()
    ie.add_info_extractor(gen_extractors())
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-18 13:23:01.496342
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test_fragments')
    test_fd = TestFD(ie._downloader, ie)
    test_fd.params.update({
        'noprogress': True,
        'quiet': True,
    })
    test_fd.add_info_extractor(ie)
    test_fd.download(['http://localhost/test'])

# Generated at 2022-06-18 13:23:10.705667
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from ..utils import match_filter_func
    from ..compat import compat_str

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'writedescription': True,
        'writeinfojson': True,
        'writethumbnail': True,
        'writesubtitles': True,
        'writeautomaticsub': True,
        'subtitleslangs': ['en'],
        'skip_download': True,
        'matchtitle': 'test',
        'matchfilter': lambda info: True,
    })
    test_fd = TestFD(ydl)

# Generated at 2022-06-18 13:23:23.500595
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    dl = HttpQuietDownloader(ie, {'quiet': True})
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert dl.params['nopart']
    assert dl.params['retries'] == 0

# Generated at 2022-06-18 13:23:32.741880
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_frag_downloader(fd_name, fd_class):
        fd = fd_class(None, {
            'quiet': True,
            'noprogress': True,
            'retries': 0,
            'nopart': True,
            'test': True,
        })
        assert fd.FD_NAME == fd_name
        assert isinstance(fd, FragmentFD)

    for ie in gen_extractors():
        if not ie.is_suitable(None) or not ie.IE_NAME:
            continue
        if match_filter_func(ie.IE_NAME):
            continue

# Generated at 2022-06-18 13:23:36.727277
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .common import FileDownloader
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert issubclass(HttpQuietDownloader, FileDownloader)

# Generated at 2022-06-18 13:23:47.856612
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        _VALID_URL = r'(?i)^https?://.+'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, url):
            return re.match(cls._VALID_URL, url) is not None


# Generated at 2022-06-18 13:24:52.125893
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_fragment_fd(fd_name, url, expected_filenames):
        fd = gen_extractors(fd_name)({})
        fd.params['outtmpl'] = '%(id)s.%(ext)s'
        fd.params['writedescription'] = True
        fd.params['writeinfojson'] = True
        fd.params['writethumbnail'] = True
        fd.params['writesubtitles'] = True
        fd.params['writeautomaticsub'] = True
        fd.params['writeannotations'] = True
        fd.params['write_all_thumbnails'] = True
        fd.params['write_all_subtitles']

# Generated at 2022-06-18 13:25:04.307393
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_frag_downloader(fd_name, url, expected_frag_count):
        fd = FragmentFD(gen_extractors(), {'fragment_retries': 0})
        info_dict = {
            'url': url,
        }
        fd.add_info_extractor(match_filter_func(lambda x: x == fd_name), lambda *args: None)
        fd.prepare_filename(info_dict)
        fd.process_info(info_dict)
        assert fd.total_frags == expected_frag_count


# Generated at 2022-06-18 13:25:06.658519
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:25:11.633625
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..utils import FakeYDL
    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {'continuedl': True, 'quiet': True, 'noprogress': True})
    assert dl.params['continuedl']
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert not dl.params['progress_with_newline']
    assert dl.ydl is ydl

# Generated at 2022-06-18 13:25:22.833098
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    ie = get_info_extractor('youtube')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')


# Generated at 2022-06-18 13:25:33.049425
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ydl = gen_extractors()
    ydl.add_info_extractor(TestFD())
    ydl.params['noprogress'] = True
    ydl.params['logger'] = None
    ydl.params['progress_hooks'] = []
    ydl.params['match_filter'] = match_filter_func('test')
    ydl.download(['test'])

# Generated at 2022-06-18 13:25:44.609198
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import get_cachedir

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': None,
                'progress_hooks': [],
            }
            self.cache = get_cachedir('test')
            self.extractors = gen_extractors()
            self.ie_key_map = {}
            self.ie_keys = []
            for ie in self.extractors:
                self.ie_key_map[ie.ie_key()] = ie
                self.ie_keys.append(ie.ie_key())


# Generated at 2022-06-18 13:25:53.784044
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_pp
    from .utils import DateRange

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.+'


# Generated at 2022-06-18 13:25:58.789914
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': None,
                'progress_hooks': [],
            }

    ydl = FakeYDL()
    ie = InfoExtractor()
    ie.add_info_extractor(gen_extractors())
    ie.set_downloader(HttpQuietDownloader(ydl, {}))
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    ie.set_downloader(HttpQuietDownloader(ydl, {'quiet': False}))
    ie.extract

# Generated at 2022-06-18 13:26:06.092426
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.http import HttpFD
    from .downloader.rtmp import RtmpFD
    from .downloader.external import ExternalFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.dash import DashManifestFD
    from .downloader.ism import IsmFD
    from .downloader.fragment import FragmentFD
    from .downloader.hls import HlsFD
    from .downloader.hls import HlsNativeFD
    from .downloader.hls import HlsFD

# Generated at 2022-06-18 13:27:53.763004
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test')
    ie.add_info_extractor(TestFD)
    ie.extract('http://localhost/')

# Generated at 2022-06-18 13:28:06.464986
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func


# Generated at 2022-06-18 13:28:18.059538
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_downloader(ydl, params):
        return HttpQuietDownloader(ydl, params)

    def test_extractor(ydl, ie_name, ie):
        return ie

    def test_hook(d):
        pass


# Generated at 2022-06-18 13:28:25.448436
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class MockInfoExtractor(object):
        IE_NAME = 'mock'
        IE_DESC = 'Mock info extractor'
        _VALID_URL = r'(?:mock)'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, url):
            return re.match(cls._VALID_URL, url) is not None

        def _real_extract(self, url):
            return {
                'id': 'mock',
                'title': 'mock',
                'formats': [
                    {'format_id': 'mock', 'url': 'mock://mock/mock.mock'},
                ],
            }

    ie

# Generated at 2022-06-18 13:28:38.650654
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class MockInfoExtractor(object):
        IE_NAME = 'mock'
        IE_DESC = 'Mock Info Extractor'
        _VALID_URL = r'(?:mock)'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, url):
            return re.match(cls._VALID_URL, url) is not None


# Generated at 2022-06-18 13:28:44.552808
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp
    from ..downloader import gen_downloader
    from ..utils import prepend_extension

    def test_downloader(ydl, params):
        return HttpQuietDownloader(ydl, params)

    gen_downloader(test_downloader)
    gen_extractors()
    gen_pp(prepend_extension)

# Generated at 2022-06-18 13:28:55.156715
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import DateRange

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test')
    ie.set_downloader(TestFD(ie._downloader))
    ie.extract('http://localhost/')

    ie = get_info_extractor('test')
    ie.set_downloader(TestFD(ie._downloader))
    ie.extract('http://localhost/', download=False)

    ie = get_info_extractor('test')
    ie.set_downloader(TestFD(ie._downloader))
    ie.extract('http://localhost/', download=True)

    ie = get_info

# Generated at 2022-06-18 13:29:05.408316
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_frag_downloader(fd):
        assert isinstance(fd, FragmentFD)
        assert fd.params is not None
        assert fd.params.get('fragment_retries') == 10
        assert fd.params.get('skip_unavailable_fragments') is True
        assert fd.params.get('keep_fragments') is False

    # Test for DASH
    fd = FragmentFD(None, {
        'fragment_retries': 10,
        'skip_unavailable_fragments': True,
    })
    _test_frag_downloader(fd)

    # Test for HLS

# Generated at 2022-06-18 13:29:14.713085
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?example\.com/video\.mp4'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': 'http://example.com/video.mp4',
                'title': 'Test video',
                'ext': 'mp4',
            }

    ie = TestIE()
    ie.extractor = gen_extractors()[ie.IE_NAME]()

# Generated at 2022-06-18 13:29:25.836745
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import DateRange

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        _VALID_URL = r'(?:$)'

        def __init__(self, ydl):
            self.ydl = ydl

        def _real_initialize(self):
            self._downloader = FragmentFD(self.ydl)

        def _real_extract(self, url):
            self._downloader.download(['http://example.com/video.mp4'])

    ie = get_info_extractor(FakeInfoExtractor.IE_NAME)
    ie.ydl = FakeYDL()