

# Generated at 2022-06-18 13:19:56.680403
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:20:08.526954
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)
    assert FragmentFD.__name__ == 'FragmentFD'
    assert FragmentFD.__module__ == 'youtube_dl.downloader.fragment'
    assert FragmentFD.FD_NAME == 'fragment'
    assert FragmentFD.RETRY_MAX == 10
    assert FragmentFD.RETRY_SLEEP == 5
    assert FragmentFD.RETRY_CODES == [500, 502, 503, 504]
    assert FragmentFD.RETRY_ON_ERRORS == True
    assert FragmentFD.RETRY_ON_HTTP_ERROR == True
    assert FragmentFD.RETRY_ON_NET

# Generated at 2022-06-18 13:20:20.043520
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def _test_frag_downloader(ie, url, expected_frag_count, expected_filename):
        info = ie.extract(url)
        assert info['_type'] == 'fragment'
        assert info['ie_key'] == ie.ie_key()
        assert info['id'] == ie._match_id(url)
        assert info['title'] == ie._og_search_title(info['webpage'])
        assert info['ext'] == 'mp4'
        assert info['fragment_count'] == expected_frag_count
        assert info['filename'] == expected_filename

    def _test_frag_downloader_live(ie, url, expected_filename):
        info = ie.ext

# Generated at 2022-06-18 13:20:32.624860
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .compat import compat_urllib_request

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?example\.com/video\.mp4'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'Test video',
                'ext': 'mp4',
            }

    class TestFD(HttpFD):
        FD_NAME = 'Test'

    ie = TestIE(gen_extractors())
    dl

# Generated at 2022-06-18 13:20:43.082389
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_frag_downloader(ydl, info_dict):
        class TestFD(FragmentFD):
            def __init__(self, ydl, info_dict):
                self.ydl = ydl
                self.info_dict = info_dict
                self.params = ydl.params
                self.add_default_info_extractors()
                self.ie = self._real_initialize()

            def _real_initialize(self):
                ie = self._ies[0](self.ydl, self.info_dict)
                ie.set_downloader(self)
                return ie

            def report_warning(self, msg):
                pass

            def report_error(self, msg):
                pass



# Generated at 2022-06-18 13:20:48.778240
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    ydl = gen_extractors()['youtube']
    dl = HttpQuietDownloader(ydl, {'noprogress': True})
    assert dl.params['noprogress'] is True
    assert dl.params['quiet'] is True
    assert dl.params['continuedl'] is True

# Generated at 2022-06-18 13:20:56.527114
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_HttpQuietDownloader(ydl, info_dict):
        dl = HttpQuietDownloader(ydl, info_dict)
        assert dl.ydl is ydl
        assert dl.params == info_dict
        return dl


# Generated at 2022-06-18 13:21:09.096798
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(ie_key):
        return match_filter_func(ie_key, ['youtube'])(ie_key)

    for ie in gen_extractors():
        if test_filter(ie.IE_NAME):
            dl = HttpQuietDownloader(None, {'quiet': True})
            dl.add_info_extractor(ie)
            break
    else:
        assert False, 'No suitable extractor found'

    dl.params['noprogress'] = True
    dl.params['nopart'] = True
    dl.params['retries'] = 0
    dl.params['continuedl'] = True
    dl.params['test'] = True

# Generated at 2022-06-18 13:21:22.217698
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.extractors = gen_extractors()
            self.extractors_by_id = {}
            for ie in self.extractors:
                self.extractors_by_id[ie.ie_key()] = ie

        def to_screen(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:21:29.013817
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            raise ExtractorError('test', expected=True)

    ie = FakeInfoExtractor({})
    dl = HttpQuietDownloader(ie, {'quiet': True})
    dl.report_error('test')

# Generated at 2022-06-18 13:21:56.084848
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    gen_extractors()
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

        def warning(self, msg):
            pass

        def error(self, msg):
            pass

    class FakeIE(InfoExtractor):
        IE_NAME = 'Fake'
        IE_DESC = False  # Do not list
        _VALID_URL = r'(?i)^https?://.+'


# Generated at 2022-06-18 13:22:05.929379
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie):
        if ie.IE_NAME == 'generic':
            return
        if ie.IE_NAME in ('youtube:playlist', 'youtube:search', 'youtube:channel', 'youtube:user', 'youtube:subscriptions', 'youtube:watchlater', 'youtube:recommended', 'youtube:favorites'):
            return
        if ie.IE_NAME in ('crunchyroll', 'crunchyroll:base', 'crunchyroll:media'):
            return
        if ie.IE_NAME in ('vimeo:likes', 'vimeo:album', 'vimeo:channel', 'vimeo:groups', 'vimeo:ondemand', 'vimeo:watchlater'):
            return

# Generated at 2022-06-18 13:22:17.621268
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    dl = HttpQuietDownloader(ie, {'quiet': True})
    dl.add_info_extractor(ie)
    dl.add_default_info_extractors()
    dl.add_info_extractor(TestIE)
    dl.add_default_info

# Generated at 2022-06-18 13:22:24.257502
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test')
    ie.add_info_extractor(TestFD)
    ie.extract('http://localhost/')

# Generated at 2022-06-18 13:22:32.301787
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return match_filter_func(info_dict, {'protocol': 'http'})

    extractors = gen_extractors(test_filter)
    assert len(extractors) > 0
    for ie in extractors:
        if ie.IE_NAME == 'generic':
            continue
        fd = FragmentFD(ie, {}, None)
        assert fd.FD_NAME == ie.IE_NAME

# Generated at 2022-06-18 13:22:39.211809
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

        def warning(self, msg):
            pass

        def error(self, msg):
            pass

    class FakeFD(FragmentFD):
        FD_NAME = 'fake'


# Generated at 2022-06-18 13:22:51.279133
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
                'format': 'best',
                'outtmpl': '%(id)s',
                'ignoreerrors': True,
                'forceurl': True,
                'forcetitle': True,
                'simulate': True,
                'format_limit': 1,
                'match_filter': match_filter_func('all'),
            }
            self.extractors = gen_extractors()
            self.extractor_descrs = InfoExtractor.descriptions


# Generated at 2022-06-18 13:23:01.154341
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(ie_key):
        return match_filter_func(ie_key, ['youtube'])(ie_key)

    extractors = gen_extractors(test_filter)
    assert len(extractors) == 1
    assert extractors[0].IE_NAME == 'Youtube'

    fd = FragmentFD(None, {}, extractors[0])
    assert fd.FD_NAME == 'Youtube'
    assert fd.params == {}
    assert fd.ydl is None
    assert fd.ie is extractors[0]

# Generated at 2022-06-18 13:23:09.973495
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_frag_downloader(info_dict):
        assert info_dict['protocol'] in ('m3u8_native', 'f4m')
        assert info_dict['extractor'] in ('m3u8', 'f4m')
        assert info_dict['fragment_base_url']
        assert info_dict['fragments']
        assert info_dict['fragment_index'] == 0
        assert info_dict['fragment_count'] == len(info_dict['fragments'])
        assert info_dict['url'] == info_dict['fragment_base_url']
        assert info_dict['http_headers']


# Generated at 2022-06-18 13:23:22.637684
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .compat import compat_urllib_request

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
            }

    gen_extractor.register(TestIE)

    class TestFD(HttpFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    gen_extractor.register

# Generated at 2022-06-18 13:24:13.143543
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..downloader.external import ExternalFD
    from ..downloader.http import HttpFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hls import HlsFD
    from ..downloader.hds import HdsFD
    from ..downloader.ism import IsmFD
    from ..downloader.f4m import F4mFD
    from ..downloader.common import FileDownloader
    from ..downloader.fragment import FragmentFD
    from ..downloader.external import ExternalFD
    from ..downloader.f4m import F4mFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.hds import HdsFD

# Generated at 2022-06-18 13:24:16.544274
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'
    assert HttpQuietDownloader.__module__ == 'youtube_dl.downloader.fragment'

# Generated at 2022-06-18 13:24:20.229384
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    ydl = gen_extractors()['youtube']
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert dl.params['logger'] == ydl.logger

# Generated at 2022-06-18 13:24:29.971235
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD
    from .hlsnative import HLSFD as HLSNativeFD

    def _test_constructor(ie, ie_key, fd_class):
        info_dict = {
            'id': 'test',
            'extractor': ie.IE_NAME,
            'extractor_key': ie_key,
            'url': 'http://localhost/',
        }
        params = {
            'nopart': True,
            'test': True,
        }
        ydl = FileDownloader(params)
        ydl.add_info_extractor(ie)


# Generated at 2022-06-18 13:24:41.718792
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..downloader.external import ExternalFD
    from ..downloader.http import HttpFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hls import HlsFD
    from ..downloader.hls import HlsNativeFD
    from ..downloader.ism import IsmFD
    from ..downloader.f4m import F4mFD

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

    ydl = FakeYDL()

# Generated at 2022-06-18 13:24:52.779694
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie):
        if ie.IE_NAME == 'generic':
            return

# Generated at 2022-06-18 13:25:05.380558
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    gen_extractors()
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'fake'
        IE_DESC = 'Fake extractor'

        def _real_extract(self, url):
            return {
                'id': 'fake_id',
                'url': url,
                'title': 'fake_title',
                'ext': 'mp4',
                'format': 'fake_format',
                'duration': 10,
                'thumbnail': 'fake_thumbnail',
            }

    ie = FakeInfoExtractor()
    ie.add_info_extractor(FakeInfoExtractor)

# Generated at 2022-06-18 13:25:13.979370
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from .common import FileDownloader

    class FakeYDL(object):
        params = {
            'nooverwrites': True,
            'continuedl': False,
            'noprogress': True,
            'logger': None,
            'quiet': True,
            'skip_download': True,
        }

        def __init__(self):
            self.cache = None
            self.to_screen = lambda *args, **kargs: None

        def to_stdout(self, message):
            pass

        def trouble(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:25:26.014313
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'(?i)^https?://.*'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(HttpQuietDownloader())
    ie.extract('http://localhost/')

    ie = TestIE(HttpFD())
    ie.extract('http://localhost/')

    gen_extractors()
    ie = Info

# Generated at 2022-06-18 13:25:36.422915
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_func(ie, ie_result):
        assert ie_result == 'test_passed'

    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'match_filter': match_filter_func(['youtube']),
        'test': True,
    })
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.add_post_process(test_func)
    ydl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-18 13:27:25.333625
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    dl = HttpQuietDownloader(ie, {'quiet': True})
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert dl.params['nopart']
    assert dl.params['continuedl']
   

# Generated at 2022-06-18 13:27:35.438888
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_FragmentFD(extractor_class):
        if not issubclass(extractor_class, FragmentFD):
            return
        if not hasattr(extractor_class, '_TEST'):
            return
        if not hasattr(extractor_class, 'IE_NAME'):
            return
        if not hasattr(extractor_class, '_VALID_URL'):
            return
        if not hasattr(extractor_class, '_TESTS'):
            return
        if not hasattr(extractor_class, '_TEST'):
            return
        if not hasattr(extractor_class, '_TEST_ENTRIES'):
            return

# Generated at 2022-06-18 13:27:42.831871
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_frag_downloader(fd, info_dict):
        assert isinstance(fd, FragmentFD)
        assert fd.ydl is not None
        assert fd.params is not None
        assert fd.info_dict is not None
        assert fd.info_dict is info_dict
        assert fd.params['outtmpl'] == '%(id)s'
        assert fd.params['noprogress'] is True
        assert fd.params['quiet'] is True
        assert fd.params['nopart'] is True
        assert fd.params['test'] is True
        assert fd.params['retries'] == 10
        assert fd.params['fragment_retries']

# Generated at 2022-06-18 13:27:50.204334
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': None,
                'progress_hooks': [],
            }

    ydl = FakeYDL()
    ie = InfoExtractor()
    ie.add_info_extractor(gen_extractors())
    ie.set_downloader(HttpQuietDownloader(ydl, {}))
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')



# Generated at 2022-06-18 13:27:59.738190
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.ydl = ydl
            self.params = params
            self.total_frags = 10
            self.frag_index = 0

        def real_download(self, filename, info_dict):
            self.frag_index += 1
            return True

    ydl = get_info_extractor('youtube')
    fd = TestFD(ydl, {'noprogress': True})
    assert fd.params['noprogress']
    fd.download('test.mp4', {'url': 'http://test.com/test.mp4'})
    assert f

# Generated at 2022-06-18 13:28:12.939776
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test desc'
        _VALID_URL = r'(?:foo)'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, url):
            return re.match(cls._VALID_URL, url) is not None

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            pass

    class FakeYDL(object):
        params = {}

        def __init__(self):
            self.extractor = FakeInfoExtractor(self)

    ydl = FakeYDL()

# Generated at 2022-06-18 13:28:22.710124
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .utils import ExtractorError

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        _TEST = {
            'url': 'http://localhost/',
            'info_dict': {
                'id': 'test',
                'ext': 'mp4',
                'title': 'test',
            },
        }

        def _real_extract(self, url):
            raise ExtractorError('test', expected=True)

    gen_extractor_classes(TestIE)

    ydl = YoutubeIE()
    ydl.add_info_extractor(TestIE)

# Generated at 2022-06-18 13:28:35.426216
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_frag_downloader(ydl, info_dict):
        class TestFD(FragmentFD):
            def __init__(self, ydl, info_dict):
                super(TestFD, self).__init__(ydl, info_dict)
                self.params['noprogress'] = True
                self.params['quiet'] = True
                self.params['nopart'] = True
                self.params['retries'] = 0
                self.params['test'] = True
                self.params['keep_fragments'] = True


# Generated at 2022-06-18 13:28:46.074557
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test_fragments')
    ie.extract('test_fragments')
    ie.extract('test_fragments_live')
    ie.extract('test_fragments_ad')
    ie.extract('test_fragments_ad_live')
    ie.extract('test_fragments_ad_live_skip')
    ie.extract('test_fragments_ad_live_skip_retry')
    ie.extract('test_fragments_ad_live_skip_retry_keep')

# Generated at 2022-06-18 13:28:56.243824
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie):
        if ie.IE_NAME == 'generic':
            return
        if ie.IE_NAME in ('youtube:playlist', 'youtube:search', 'youtube:channel', 'youtube:user'):
            return
        if ie.IE_NAME.startswith('soundcloud:'):
            return
        if ie.IE_NAME.startswith('bandcamp:'):
            return
        if ie.IE_NAME.startswith('mixcloud:'):
            return
        if ie.IE_NAME.startswith('ted:'):
            return
        if ie.IE_NAME.startswith('cspan:'):
            return
        if ie.IE_NAME.startswith('imgur:'):
            return