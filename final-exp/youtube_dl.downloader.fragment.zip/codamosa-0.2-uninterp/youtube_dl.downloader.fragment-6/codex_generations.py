

# Generated at 2022-06-18 13:20:07.306327
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        IE_DESC = 'Dummy IE'
        _VALID_URL = r'https?://.+'


# Generated at 2022-06-18 13:20:19.187192
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func


# Generated at 2022-06-18 13:20:29.740294
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .extractor.common import InfoExtractor
    from .utils import ExtractorError

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def _real_extract(self, url):
            raise ExtractorError('test error', expected=True)

    gen_extractor_classes(TestIE)

    ydl = FileDownloader({'quiet': True})
    ydl.add_info_extractor(TestIE)
    ydl.download(['http://example.test/'])

# Generated at 2022-06-18 13:20:40.858924
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(extractor_class):
        if not issubclass(extractor_class, FragmentFD):
            return
        if extractor_class.IE_NAME == 'generic':
            return
        if extractor_class.IE_NAME in ('googledrive', 'googleshortener'):
            return
        if extractor_class.IE_NAME in ('crunchyroll', 'crunchyrolles'):
            return
        if extractor_class.IE_NAME in ('vk', 'vkontakte'):
            return
        if extractor_class.IE_NAME in ('vimeo', 'vimeopro'):
            return

# Generated at 2022-06-18 13:20:50.007872
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie_name):
        ie = gen_extractors()[ie_name]()
        if not ie.suitable(ie.url):
            return
        info_dict = ie.extract(ie.url)
        if not info_dict:
            return
        fd = FragmentFD(ie, info_dict, {'format': 'best'})
        fd.download()

    for ie_name in gen_extractors():
        if match_filter_func(ie_name, ['youtube', 'generic']):
            test_extractor(ie_name)

# Generated at 2022-06-18 13:21:00.136605
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'Fake'
        _VALID_URL = r'(?i)^https?://.*\.fake'

    ie = FakeInfoExtractor()
    ie.add_info_extractor(gen_extractors())
    ie.add_default_info_extractors()

    # Test that HttpQuietDownloader is created with the same options
    # as the parent InfoExtractor

# Generated at 2022-06-18 13:21:13.357264
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp
    from ..utils import DateRange


# Generated at 2022-06-18 13:21:18.664633
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'
    assert HttpQuietDownloader.__module__ == 'youtube_dl.downloader.fragment'

# Generated at 2022-06-18 13:21:23.080176
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    ydl = gen_extractors()['youtube']
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.params['quiet']

# Generated at 2022-06-18 13:21:27.495130
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    ydl = gen_extractors()['youtube']
    dl = HttpQuietDownloader(ydl, {})
    assert dl.ydl is ydl
    assert dl.params == {}

# Generated at 2022-06-18 13:21:54.604745
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..downloader.external import ExternalFD
    from ..downloader.http import HttpFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hls import HlsFD
    from ..downloader.hlsnative import HlsFD as HlsNativeFD
    from ..downloader.f4m import F4mFD
    from ..downloader.ism import IsmFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hls import HlsFD
    from ..downloader.hlsnative import HlsFD as HlsNativeFD
    from ..downloader.f4m import F4mFD

# Generated at 2022-06-18 13:22:03.944273
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
            }
            self.cache = None
            self.server = None
            self.extractor_desc = []
            self.extractors = gen_extractors()
            self.IE_NAME = 'test'
            self.IE_DESC = 'test'
            self.ie = InfoExtractor(self.IE_NAME, self.IE_DESC)
            self.ie.extractor_key = self.IE_NAME

        def add_info_extractor(self, ie):
            self.extract

# Generated at 2022-06-18 13:22:15.499538
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeYDL:
        def __init__(self):
            self.params = {}
            self.cache = None
            self.to_screen = lambda *args, **kargs: None
            self.to_stderr = lambda *args, **kargs: None
            self.to_console_title = lambda *args, **kargs: None
            self.set_progress_hook = lambda *args, **kargs: None
            self.report_warning = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None
            self.report_file_already_downloaded = lambda *args, **kargs: None

# Generated at 2022-06-18 13:22:17.620977
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-18 13:22:30.478657
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'ratelimit': None,
                'retries': 0,
                'nopart': False,
                'test': False,
            }
            self.extractor_descriptions = []
            for ie in gen_extractors():
                self.extractor_descriptions.append(ie.IE_DESC)

# Generated at 2022-06-18 13:22:33.249357
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'
    assert HttpQuietDownloader.__module__ == 'youtube_dl.downloader.fragment'

# Generated at 2022-06-18 13:22:44.494562
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestIE(get_info_extractor('Test')):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'ext': 'mp4',
                'title': 'test video',
                'formats': [{
                    'url': 'http://example.com/video.mp4',
                    'ext': 'mp4',
                    'format_id': 'test',
                    'filesize': 1024,
                }],
            }

    ie = TestIE()
    fd = FragmentFD(ie, {'outtmpl': '%(id)s-%(format_id)s.%(ext)s'})
    info = ie._real_extract('http://example.com/video.mp4')


# Generated at 2022-06-18 13:22:56.637228
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_frag_downloader(fd_name, info_dict):
        fd = gen_extractors(info_dict['extractor'])[0](
            {
                'quiet': True,
                'simulate': True,
                'skip_download': True,
                'format': 'best',
            },
            match_filter_func('best')
        )
        assert isinstance(fd, FragmentFD)
        assert fd.FD_NAME == fd_name

    _test_frag_downloader('dash', {
        'extractor': 'dash',
        'url': 'http://example.com',
    })

# Generated at 2022-06-18 13:23:06.617920
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.cache = {}

        def add_info_extractor(self, ie):
            self.cache[ie.ie_key()] = ie

        def extract_info(self, url, download=True, ie_key=None, extra_info={}):
            if ie_key is None:
                ie = get_info_extractor(url)
            else:
                ie = self.cache[ie_key]
            return ie.extract(url)

        def to_screen(self, *args, **kargs):
            pass

        def to_stdout(self, message):
            pass


# Generated at 2022-06-18 13:23:12.936902
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .downloader.rtmp import RTMPFD
    from .downloader.external import ExternalFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.ism import IsmFD
    from .downloader.fragment import FragmentFD
    from .downloader.http import HttpQuietDownloader

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        IE_DESC = 'Test IE'

# Generated at 2022-06-18 13:23:56.536114
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie):
        if ie.IE_NAME == 'generic':
            return
        if ie.IE_NAME in ('youtube:playlist', 'youtube:search'):
            return
        if ie.IE_NAME in ('crunchyroll:playlist', 'crunchyroll:show'):
            return
        if ie.IE_NAME in ('vimeo:album', 'vimeo:channel', 'vimeo:group', 'vimeo:likes', 'vimeo:ondemand', 'vimeo:reviews', 'vimeo:watchlater', 'vimeo:channels'):
            return

# Generated at 2022-06-18 13:24:04.045737
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'(?i)^https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'formats': [{
                    'format_id': 'test',
                    'url': 'http://localhost/test.mp4',
                }],
            }

    ie = FakeInfoExtractor()
    ie.add_info_extractor(ie)
    ie.add_post_processor(None)
    ie.add_progress_hook(None)

    y

# Generated at 2022-06-18 13:24:13.180621
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    from ..utils import parse_duration

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, downloader=None):
            super(FakeInfoExtractor, self).__init__(downloader)

        def _real_extract(self, url):
            return {
                'id': 'fakeid',
                'title': 'faketitle',
                'ext': 'mp4',
                'duration': parse_duration('PT1M'),
                'formats': [{
                    'url': 'http://example.com/video.mp4',
                    'format_id': 'mp4',
                    'ext': 'mp4',
                    'filesize': 1000000,
                }],
            }

    class FakeFD(FragmentFD):
        FD_NAME

# Generated at 2022-06-18 13:24:21.346217
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.common import FileDownloader

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'fake'
        IE_DESC = 'fake extractor'

        def _real_extract(self, url):
            return {
                'id': 'fake',
                'title': 'fake video',
                'formats': [{
                    'format_id': 'fake',
                    'url': 'http://example.com/fake.mp4',
                }],
            }


# Generated at 2022-06-18 13:24:28.763031
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _match_filter(info_dict):
        return match_filter_func(info_dict, {'protocol': 'http'})

    extractors = gen_extractors()
    extractors = [e for e in extractors if _match_filter(e.IE_NAME)]
    for ie in extractors:
        ie = ie(HttpQuietDownloader(None, {'quiet': True}), {})
        ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-18 13:24:40.501345
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .post import PostProcessor
    from .downloader.external import ExternalFD
    from .downloader.rtmp import RTMPFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.http import HttpFD
    from .downloader.fragment import FragmentFD

    assert issubclass(HttpQuietDownloader, HttpFD)
    assert not issubclass(HttpQuietDownloader, (
        InfoExtractor, PostProcessor, ExternalFD, RTMPFD, F4mFD, HlsFD,
        DashSegmentsFD, FragmentFD))

    # Test that Http

# Generated at 2022-06-18 13:24:51.874535
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_urllib_request
    from ..utils import sanitize_open
    from .http import HttpFD

    class MockYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': MockLogger(),
            }

    class MockLogger(object):
        def debug(self, msg):
            pass

    class MockInfoDict(dict):
        pass

    class MockFD(HttpFD):
        def __init__(self, ydl, params):
            super(MockFD, self).__init__(ydl, params)
            self.to_screen_calls = []


# Generated at 2022-06-18 13:25:04.095486
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*'

    ie = TestIE(gen_extractors())
    dl = HttpQuietDownloader(ie, {
        'continuedl': True,
        'quiet': True,
        'noprogress': True,
        'ratelimit': None,
        'retries': 0,
        'nopart': False,
        'test': False,
    })
    assert dl.params['continuedl'] is True
    assert dl.params['quiet'] is True

# Generated at 2022-06-18 13:25:13.393376
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func
    from .compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
                'nopart': True,
                'continuedl': True,
                'ratelimit': None,
                'retries': 0,
                'test': False,
            }

# Generated at 2022-06-18 13:25:25.158824
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    import tempfile
    from .extractor import get_info_extractor

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen = sys.stderr.write
            self.temp_name = tempfile.mkstemp
            self.try_rename = os.rename
            self.report_error = sys.stderr.write
            self.report_warning = sys.stderr.write
            self.report_destination = sys.stderr.write
            self.calc_eta = lambda *_: None

    class FakeInfoDict(object):
        def __init__(self, url, http_headers):
            self.url = url
            self.http_headers = http_headers


# Generated at 2022-06-18 13:27:00.287735
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..compat import compat_urllib_request

    def _test_downloader(ydl, url, expected_filename, expected_status,
                         expected_content):
        info = {'url': url}
        dl = HttpQuietDownloader(ydl, {'continuedl': False})
        filename = dl.download(expected_filename, info)
        assert filename == expected_filename
        assert info['status'] == expected_status
        with open(encodeFilename(filename), 'rb') as f:
            content = f.read()
        assert content == expected_content

    def _test_downloader_with_error(ydl, url, expected_filename, expected_status,
                                    expected_exc_msg):
        info = {'url': url}


# Generated at 2022-06-18 13:27:06.499921
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie):
        if ie.IE_NAME == 'generic':
            return
        if ie.IE_NAME in ('youtube', 'googledrive', 'googleshortener'):
            return
        if ie.IE_NAME in ('crunchyroll', 'crunchyrolles'):
            return
        if ie.IE_NAME in ('vimeo', 'vimeo:album', 'vimeo:channel', 'vimeo:group', 'vimeo:ondemand', 'vimeo:review'):
            return
        if ie.IE_NAME in ('dailymotion', 'dailymotion:playlist'):
            return

# Generated at 2022-06-18 13:27:13.454870
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    # Test for DASH
    ie = get_info_extractor('dash')
    fd = ie._downloader
    assert isinstance(fd, FragmentFD)

    # Test for HLS
    ie = get_info_extractor('hls')
    fd = ie._downloader
    assert isinstance(fd, FragmentFD)

    # Test for HLS native
    ie = get_info_extractor('hlsnative')
    fd = ie._downloader
    assert isinstance(fd, FragmentFD)

# Generated at 2022-06-18 13:27:17.428256
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    ydl = gen_extractors()['youtube']
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.params['quiet']

# Generated at 2022-06-18 13:27:27.147059
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestIE(object):
        IE_NAME = 'test'
        _VALID_URL = r'(?:$)'

        def __init__(self, downloader=None):
            self._downloader = downloader

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'formats': [
                    {'url': 'http://example.com/1', 'format_id': '1'},
                    {'url': 'http://example.com/2', 'format_id': '2'},
                ],
            }

    ie = TestIE()
    ie.add_info_extractor(ie)

# Generated at 2022-06-18 13:27:36.589581
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .compat import compat_urllib_request

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        _VALID_URL = r'https?://.+'
        _TEST = {
            'url': 'http://example.com/',
            'file': 'test.mp4',
            'info_dict': {
                'id': 'test',
                'ext': 'mp4',
            },
        }

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'ext': 'mp4',
            }

    gen_extractor.register

# Generated at 2022-06-18 13:27:43.936005
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'nooverwrites': True,
        'quiet': True,
        'simulate': True,
        'format': 'best',
    })
    ydl.add_info_extractor(gen_extractors())
    ydl.add_default_info_extractors()
    ydl.params['match_filter'] = match_filter_func('is_live:true')
    ydl.process_ie_result(ydl.extract_info('http://www.youtube.com/watch?v=BaW_jenozKc', download=False))
    assert ydl.params['test'] is True
    assert ydl

# Generated at 2022-06-18 13:27:45.294645
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-18 13:27:47.380612
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    fd = FragmentFD(None, {'noprogress': True})
    assert fd.params['noprogress']

# Generated at 2022-06-18 13:27:49.991864
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .common import FileDownloader
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert issubclass(HttpQuietDownloader, FileDownloader)