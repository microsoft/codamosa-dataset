

# Generated at 2022-06-18 13:20:05.517417
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeYDL:
        def __init__(self):
            self.params = {}

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def report_destination(self, *args, **kargs):
            pass

        def temp_name(self, *args, **kargs):
            return 'temp'

        def try_rename(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:20:17.717588
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
                'nopart': True,
                'continuedl': True,
            }

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = 'test'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    def fake_urlopen(request):
        return compat

# Generated at 2022-06-18 13:20:20.832072
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'
    assert HttpQuietDownloader.__module__ == 'youtube_dl.downloader.fragment'

# Generated at 2022-06-18 13:20:33.927630
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    ie.add_info_extractor(TestIE)

    def test_hook(d):
        if d['status'] == 'finished':
            raise Exception('finished')


# Generated at 2022-06-18 13:20:41.813827
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return match_filter_func(info_dict, {'protocol': 'http'})

    for ie in gen_extractors():
        if test_filter(ie.IE_NAME):
            ie.suitable(ie.url_result('http://www.youtube.com/watch?v=BaW_jenozKc'))
            ie.download(ie.url_result('http://www.youtube.com/watch?v=BaW_jenozKc'))
            break

# Generated at 2022-06-18 13:20:52.324929
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class MockYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
            }

    ydl = MockYDL()
    ie = InfoExtractor()
    ie.ydl = ydl
    ie._downloader = HttpQuietDownloader(ydl, ie.params)
    assert ie._downloader.params['noprogress']
    assert ie._downloader.params['quiet']

    # Test that HttpQuietDownloader is used for all extractors
    for ie in gen_extractors():
        if not ie.IE_NAME:
            continue

# Generated at 2022-06-18 13:20:58.360628
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .compat import compat_urllib_request

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        IE_DESC = 'Dummy IE'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    class DummyFD(HttpFD):
        FD_NAME = 'dummy'

        def real_download(self, filename, info_dict):
            return True

    ie = DummyIE(DummyFD())
    ie.add_info

# Generated at 2022-06-18 13:21:11.501046
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return info_dict.get('protocol') == 'm3u8'

    extractors = gen_extractors()
    extractors = match_filter_func(extractors, test_filter)
    for ie in extractors:
        ie.ydl = None
        ie.params = {}
        ie.report_warning = lambda msg: None
        ie.report_error = lambda msg: None
        ie.report_destination = lambda filename: None
        ie.to_screen = lambda *args, **kargs: None
        ie.temp_name = lambda filename: filename
        ie.try_rename = lambda old_filename, new_filename: None
        ie.add_default_extra

# Generated at 2022-06-18 13:21:24.117285
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .common import InfoExtractor
    from .downloader.http import HttpFD
    from .downloader.http import HttpQuietDownloader

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'Fake'
        IE_DESC = 'Fake IE'

        def _real_extract(self, url):
            pass

    FakeIE = gen_extractor_classes(FakeInfoExtractor)

    ydl = FakeYDL({})
    ie = FakeIE(ydl)

# Generated at 2022-06-18 13:21:35.960758
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class FakeYDL:
        def __init__(self):
            self.params = {}

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def to_stdout(self, *args, **kargs):
            pass

        def to_stderr(self, *args, **kargs):
            pass

        def temp_name(self, *args, **kargs):
            return '-'

        def try_rename(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:22:02.464941
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test_fragments')
    ie.add_info_extractor(TestFD)
    ie.extract('test_fragments')

# Generated at 2022-06-18 13:22:05.410604
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:22:17.117093
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    gen_extractors()
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import get_cachedir

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?example\.com/video\.mp4'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
            }

    ie = TestIE()
    ie.extract('http://example.com/video.mp4')
    ie

# Generated at 2022-06-18 13:22:30.068212
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.rtmp import RtmpFD
    from .downloader.external import ExternalFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.http import HttpFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.dash import DashFD
    from .downloader.ism import IsmFD
    from .downloader.fragment import FragmentFD
    from .downloader.hls import HlsFD
    from .downloader.hls import HlsNativeFD
    from .downloader.http import HttpQuietDownloader

    # Test that HttpQu

# Generated at 2022-06-18 13:22:38.279903
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, *args):
            return True


# Generated at 2022-06-18 13:22:46.354370
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'https?://.+'

    ie = TestIE(gen_extractor())
    dl = HttpQuietDownloader(ie, {'quiet': True})
    assert dl.params['quiet'] is True

# Generated at 2022-06-18 13:22:58.352217
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_downloader(ydl, url, expected_filename, expected_status,
                        expected_total_bytes, expected_downloaded_bytes,
                        expected_elapsed):
        class TestFD(FragmentFD):
            def __init__(self, ydl, params):
                super(TestFD, self).__init__(ydl, params)
                self.downloaded_bytes = 0
                self.total_bytes = 0
                self.elapsed = 0
                self.status = None
                self.filename = None

            def to_screen(self, *args, **kargs):
                pass

            def report_warning(self, *args, **kargs):
                pass


# Generated at 2022-06-18 13:23:07.973919
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def _test_downloader(url, expected_filename, expected_status, expected_total_frags):
        ydl = FileDownloader({
            'outtmpl': '%(id)s',
            'quiet': True,
            'noprogress': True,
            'nooverwrites': True,
            'matchfilter': match_filter_func(expected_filename),
            'test': True,
        })
        ydl.add_info_extractor(gen_extractors()[0])
        ydl.add_info_extractor(gen_extractors()[1])

# Generated at 2022-06-18 13:23:20.776481
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestIE(object):
        IE_NAME = 'test'
        _VALID_URL = r'(?:$)'
        IE_DESC = 'Test IE'

        def __init__(self, downloader=None):
            self._downloader = downloader

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': 'http://example.com/test',
                'title': 'test video',
                'ext': 'mp4',
                'http_headers': {
                    'Range': 'bytes=0-10',
                },
            }

    ie = TestIE()
    ie.add_ie = lambda i: None
    ie.add_

# Generated at 2022-06-18 13:23:23.162637
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:24:12.674469
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .downloader.http import HttpFD
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import get_cachedir

    class TestFD(HttpQuietDownloader):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.to_screen_called = False

        def to_screen(self, *args, **kargs):
            self.to_screen_called = True

    ydl = gen_extractor_classes()
    ydl.params['cachedir'] = get_cachedir()
    ydl.params['noprogress'] = True
    ydl.params['logger'] = File

# Generated at 2022-06-18 13:24:14.059594
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-18 13:24:22.335243
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def _test_frag_downloader(ie, url, expected_frag_count, expected_filename, expected_ext, expected_frag_retries):
        ie = get_info_extractor(ie)
        info = ie.extract(url)
        assert info['_type'] == 'fragment'
        assert info['url'] == url
        assert info['ie_key'] == ie.ie_key()
        assert info['ext'] == expected_ext
        assert info['fragment_count'] == expected_frag_count
        assert info['fragment_retries'] == expected_frag_retries
        assert match_filter_func(info['title'], expected_filename, expected_ext)

    _

# Generated at 2022-06-18 13:24:32.600880
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.common import FileDownloader

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }
            self.cache = None
            self.postprocessors = gen_postprocessors()
            self.extractors = gen_extractors()

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:24:44.706132
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(ie_key, ie):
        return ie_key == 'youtube'

    extractors = gen_extractors()
    extractors = list(filter(lambda ie: match_filter_func(ie.IE_NAME, test_filter), extractors))
    assert len(extractors) == 1
    youtube_ie = extractors[0]

    ydl = youtube_ie(params={})
    ydl.add_info_extractor(youtube_ie)
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    ydl.params['noplaylist'] = True

# Generated at 2022-06-18 13:24:54.384077
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.http import HttpFD
    from .downloader.rtmp import RtmpFD
    from .downloader.external import ExternalFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashFD
    from .downloader.hds import HdsFD
    from .downloader.ism import IsmFD
    from .downloader.fragment import FragmentFD
    from .downloader.common import FileDownloader
    from .compat import compat_str

    # Test that HttpQuietDownloader is a subclass of HttpFD

# Generated at 2022-06-18 13:25:06.853849
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import prepend_extractor
    from .http import HttpFD
    from .fragment import FragmentFD

    class TestFD(FragmentFD):
        FD_NAME = 'test'

    test_fd = TestFD(None)
    test_fd.params['noprogress'] = False
    test_fd.params['quiet'] = True
    test_fd.params['nopart'] = True
    test_fd.params['retries'] = 1
    test_fd.params['test'] = True
    test_fd.params['continuedl'] = True
    test_fd.params['ratelimit'] = '1k'


# Generated at 2022-06-18 13:25:15.367390
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def test_downloader(ydl, params, info_dict):
        dl = HttpQuietDownloader(ydl, params)
        dl.add_info_extractor(gen_extractors(ydl, match_filter_func(info_dict['url']))[0])
        dl.download(info_dict)

    def test_http_downloader(ydl, params, info_dict):
        dl = HttpFD(ydl, params)
        dl.add_info_extractor(gen_extractors(ydl, match_filter_func(info_dict['url']))[0])
        dl.download(info_dict)

# Generated at 2022-06-18 13:25:27.921075
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        _VALID_URL = r'(?i)^https?://.+'
        _TEST = {
            'url': 'http://example.com/',
            'file': 'test.mp4',
            'info_dict': {
                'id': 'test',
                'ext': 'mp4',
            },
        }

    gen_extractors()
    ie = DummyIE({})
    dl = HttpQuietDownloader(ie, {'quiet': True})
    assert dl.params['quiet']
    assert dl.ydl is ie

# Generated at 2022-06-18 13:25:39.691822
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .downloader.http import HttpFD
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
            }

    class FakeInfoDict(object):
        def __init__(self):
            self.url = 'http://example.com/video.mp4'

    fake_ydl = FakeYDL()
    fake_info_dict = FakeInfoDict()
    http_quiet_downloader = HttpQuietDownloader(fake_ydl, {'continuedl': True})

# Generated at 2022-06-18 13:27:23.993250
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    ie = get_info_extractor('youtube')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')


# Generated at 2022-06-18 13:27:34.415015
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl_info
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'quiet': True,
        'simulate': True,
        'format': 'best',
        'nooverwrites': True,
        'noplaylist': True,
        'logger': None,
        'progress_hooks': [],
        'extractors': gen_extractors(),
        'downloader_hooks': [],
    })

    info = gen_ydl_info(ydl, 'http://www.youtube.com/watch?v=BaW_jenozKc')
    info

# Generated at 2022-06-18 13:27:42.024401
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.external import ExternalFD
    from .downloader.rtmp import RTMPFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashFD
    from .downloader.http import HttpFD
    from .downloader.fragment import FragmentFD
    from .downloader.common import FileDownloader
    from .downloader.external import ExternalFD
    from .downloader.rtmp import RTMPFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashFD

# Generated at 2022-06-18 13:27:50.153249
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_error

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
            }
            self.extractors = gen_extractors()
            self.params = {}
            self.to_screen = lambda *x: x
            self.to_stderr = lambda *x: x
            self.to_console_title = lambda *x: x
            self.urlopen = compat_urllib_error.URLError('foo')
            self.report_warning = lambda *x: x
            self.report_error = lambda *x: x
            self.add_

# Generated at 2022-06-18 13:27:59.640277
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_str

    def test_frag_downloader(url, expected_frag_count, expected_frag_retries, expected_skip_unavailable_fragments):
        class FakeYDL(object):
            def __init__(self):
                self.params = {}

        ydl = FakeYDL()
        for ie in gen_extractors():
            if not ie.suitable(url) or not ie.IE_NAME in ('hlsnative', 'dash'):
                continue
            ie = ie.ie
            break
        else:
            raise ValueError('Unsupported URL: ' + url)
        ie = ie(ydl=ydl, downloader=None, params={})

# Generated at 2022-06-18 13:28:03.584557
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:28:15.946312
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.extractors = gen_extractors()
            self.extractors_by_id = dict((e.IE_NAME, e) for e in self.extractors)
            self.params['match_filter'] = match_filter_func(self.params)

        def to_screen(self, *args, **kargs):
            pass

    ydl = FakeYDL()
   

# Generated at 2022-06-18 13:28:25.136869
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    gen_extractors()
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.+'
        _TEST = {
            'url': 'http://example.com',
            'info_dict': {
                'id': 'test',
            },
        }

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
            }

    ie = TestIE(downloader=FragmentFD())
    info = ie.extract('http://example.com')
    assert info['id'] == 'test'

# Generated at 2022-06-18 13:28:31.304965
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test_fragments')
    test_fd = TestFD(ie._downloader, ie)
    test_fd.params.update({
        'fragment_retries': 10,
        'skip_unavailable_fragments': True,
        'keep_fragments': True,
    })

# Generated at 2022-06-18 13:28:33.460520
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)