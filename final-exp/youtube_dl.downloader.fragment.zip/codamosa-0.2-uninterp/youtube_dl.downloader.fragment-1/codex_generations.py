

# Generated at 2022-06-18 13:20:10.565791
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    ie = get_info_extractor('youtube')
    dl = HttpQuietDownloader(ie, {'quiet': True})
    assert dl.params['quiet']
    assert dl.params['noprogress']

    dl = HttpQuietDownloader(ie, {'noprogress': True})
    assert dl.params['quiet']
    assert dl.params['noprogress']

    dl = HttpQuietDownloader(ie, {})
    assert not dl.params['quiet']
    assert not dl.params['noprogress']

    dl = HttpQuietDownloader(ie, {'quiet': False})
    assert not dl.params['quiet']
   

# Generated at 2022-06-18 13:20:15.336589
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    ydl = object()
    params = {'continuedl': True, 'quiet': True, 'noprogress': True}
    dl = HttpQuietDownloader(ydl, params)
    assert dl.ydl is ydl
    assert dl.params == params

# Generated at 2022-06-18 13:20:20.653145
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test_fragments')
    ie.add_info_extractor(TestFD)
    ie.extract('http://localhost/test_fragments')

# Generated at 2022-06-18 13:20:33.462707
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_FragmentFD(info_dict):
        fd = FragmentFD(gen_extractors(), {}, info_dict)
        fd.report_destination = lambda x: None
        fd.to_screen = lambda *x, **kx: None
        fd.report_progress = lambda x: None
        fd.report_warning = lambda x: None
        fd.report_error = lambda x: None
        fd.params['noprogress'] = True
        fd.params['quiet'] = True
        fd.params['nopart'] = True
        fd.params['retries'] = 0
        fd.params['test'] = True

# Generated at 2022-06-18 13:20:39.969273
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    # Test for DASH
    ie = get_info_extractor('dash')
    assert isinstance(ie, FragmentFD)

    # Test for HLS
    ie = get_info_extractor('hls')
    assert isinstance(ie, FragmentFD)

    # Test for HLS native
    ie = get_info_extractor('hlsnative')
    assert isinstance(ie, FragmentFD)

# Generated at 2022-06-18 13:20:50.648632
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp

    ydl = FileDownloader({
        'noprogress': True,
        'quiet': True,
        'simulate': True,
        'format': 'best',
        'outtmpl': '%(id)s',
        'ignoreerrors': True,
        'logger': None,
        'progress_hooks': [],
        'extractors': gen_extractors(),
        'postprocessors': gen_pp(),
        'params': {},
    })
    dl = HttpQuietDownloader(ydl, {})
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert dl.params['retries'] == 0

# Generated at 2022-06-18 13:20:53.650835
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    ydl = gen_extractors()['youtube']
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.params['quiet'] is True

# Generated at 2022-06-18 13:20:59.040234
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeYDL:
        def __init__(self):
            self.params = {}

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def report_destination(self, *args, **kargs):
            pass

        def temp_name(self, *args, **kargs):
            return 'temp_name'

        def try_rename(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:21:12.244921
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class MyInfoDict(dict):
        pass

    class MyFD(FragmentFD):
        def __init__(self, ydl, params):
            super(MyFD, self).__init__(ydl, params)
            self.total_frags = 0
            self.frag_index = 0
            self.frag_retries = params.get('fragment_retries', 0)
            self.skip_unavailable_fragments = params.get('skip_unavailable_fragments', False)
            self.keep_fragments = params.get('keep_fragments', False)


# Generated at 2022-06-18 13:21:24.831060
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from .common import FileDownloader
    from .http import HttpFD

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            self.to_screen('%s: real_download called' % self.FD_NAME)
            return True

        def _prepare_frag_download(self, ctx):
            self.to_screen('%s: _prepare_frag_download called' % self.FD_NAME)
            ctx.update({
                'tmpfilename': 'tmpfile',
                'filename': 'file',
                'total_frags': 3,
            })


# Generated at 2022-06-18 13:21:52.487036
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .utils import DateRange

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'ratelimit': None,
                'retries': 0,
                'nopart': False,
                'test': False,
            }
            self.extractors = gen_extractors()
            self.postprocessors = gen_postprocessors()
            self.params = {}
            self.cache = None
            self.progress_hooks = []
            self.IE_NAME = 'test'
            self.server_api_support = False
            self.server_api_version = None


# Generated at 2022-06-18 13:22:01.522537
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    ie = get_info_extractor('youtube')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')

    fd = FragmentFD(ie, {
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        'outtmpl': '%(id)s.%(ext)s',
        'noprogress': True,
        'quiet': True,
        'skip_download': True,
    })
    fd.add_info_extractor(ie)
    fd.add_default_info_extractors()

    info_dict = fd.ie_result

# Generated at 2022-06-18 13:22:11.562649
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_urllib_request
    from ..extractor import gen_extractors
    from ..utils import get_cachedir

    gen_extractors()
    compat_urllib_request.install_opener(compat_urllib_request.build_opener())
    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'quiet': True,
        'cachedir': get_cachedir(),
    })
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    dl.add_info_extractor(None)
    dl.add_default_info_extractors()
    dl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-18 13:22:24.913313
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..downloader.external import ExternalFD

    class TestFD(FragmentFD):
        FD_NAME = 'test'

    class TestIE(object):
        IE_NAME = 'test'
        IE_DESC = 'Test IE'

        def __init__(self, downloader=None):
            self._downloader = downloader

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': 'http://example.com/test',
                'title': 'test video',
                'ext': 'mp4',
            }

    ie = TestIE()
    gen_extractors()
    ie.add_info_extractor(TestIE)

# Generated at 2022-06-18 13:22:35.620925
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .post import PostProcessor
    from .downloader.external import ExternalFD
    from .downloader.rtmp import RTMPFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.http import HttpFD
    from .downloader.dash import DashFD
    from .downloader.hds import HdsFD
    from .downloader.ism import IsmFD
    from .downloader.fragment import FragmentFD

    # Check that all downloader classes are covered

# Generated at 2022-06-18 13:22:48.002412
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_download_fragment(self, frag_url, info_dict, headers=None):
        return True, 'test'

    def test_append_fragment(self, frag_content):
        pass

    def test_prepare_frag_download(self):
        pass

    def test_start_frag_download(self):
        return time.time()

    def test_finish_frag_download(self):
        pass

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self._download_fragment = test_download_frag

# Generated at 2022-06-18 13:22:53.327338
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'
    assert HttpQuietDownloader.__module__ == 'youtube_dl.downloader.fragment'

# Generated at 2022-06-18 13:23:04.081157
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import get_info_extractor

    class FakeYDL:
        params = {}
        def __init__(self):
            self.extractor = get_info_extractor('generic')

        def to_screen(self, *args, **kargs):
            print(*args, file=sys.stderr)

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

    ydl = FakeYDL()
    fd = FragmentFD(ydl, {'noprogress': True})
    assert fd.params['noprogress'] is True
    assert fd.params['quiet'] is True
    assert f

# Generated at 2022-06-18 13:23:11.436348
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def _test_frag_downloader(ie, url, expected_filename, expected_frag_count):
        ydl = FakeYDL()
        ie.ydl = ydl
        ie.params = {
            'noprogress': True,
            'nopart': True,
            'quiet': True,
        }
        ie.add_default_info_extractors()
        ie.extract_info(url, download=False)
        assert ydl.downloaded_info_dicts[0]['_type'] == 'fragment'
        assert ydl.downloaded_info_dicts[0]['filename'] == expected_filename

# Generated at 2022-06-18 13:23:23.929794
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestIE(get_info_extractor('Test')):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'ext': 'mp4',
                'url': url,
                'http_headers': {
                    'Range': 'bytes=0-10',
                },
            }

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def _get_fragment_retries(self, fragment_index):
            return self.params.get('fragment_retries', 0)

        def _get_fragment_url(self, fragment_index):
            return 'http://localhost/%d' % fragment_index


# Generated at 2022-06-18 13:24:10.236646
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)
    assert FragmentFD.__bases__ == (FileDownloader, HttpFD)

# Generated at 2022-06-18 13:24:18.474058
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def _test_downloader(ydl, ie, url, expected_filename, expected_status,
                         expected_total_frags, expected_frag_retries,
                         expected_skip_unavailable_fragments,
                         expected_keep_fragments,
                         expected_fragment_base_url=None,
                         expected_fragment_base_headers=None):
        info = get_info_extractor(ydl, ie)(url)
        filename = info['id'] + '.' + info['ext']
        if expected_filename is not None:
            assert filename == expected_filename

# Generated at 2022-06-18 13:24:27.543265
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from .http import HttpFD


# Generated at 2022-06-18 13:24:39.122455
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.common import FileDownloader
    from .downloader.http import HttpFD
    from .compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'ratelimit': None,
                'retries': 0,
                'nopart': False,
                'test': False,
            }
            self.cache = None
            self.params = {}
            self.to_screen = lambda *x: x
            self.to_stderr = lambda *x: x

# Generated at 2022-06-18 13:24:50.814729
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test_ie')
    ie.add_info_extractor(TestIE(ie.name, ie.ie_key()))
    ie.add_info_extractor(TestIE(ie.name, ie.ie_key()))
    ie.add_info_extractor(TestIE(ie.name, ie.ie_key()))
    ie.add_info_extractor(TestIE(ie.name, ie.ie_key()))
    ie.add_info_extractor(TestIE(ie.name, ie.ie_key()))
    ie.add_info_ext

# Generated at 2022-06-18 13:24:58.676541
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.params = {
        'noprogress': True,
        'quiet': True,
        'continuedl': True,
        'nopart': False,
        'ratelimit': None,
        'retries': 0,
        'test': False,
    }
    dl = HttpQuietDownloader(ie, ie.params)
    assert dl.params == ie.params

# Generated at 2022-06-18 13:25:09.961935
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .post import PostProcessor
    from .downloader.http import HttpFD
    from .utils import DateRange

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        _VALID_URL = r'(?i)^https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test video',
                'formats': [
                    {'url': 'http://example.org/video.mp4'},
                ],
            }

    class DummyPP(PostProcessor):
        def run(self, info):
            return [info]


# Generated at 2022-06-18 13:25:18.166802
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'Fake'
        IE_DESC = 'Fake IE'

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            pass

    ie = FakeInfoExtractor()
    ie.ydl = FakeYDL()
    ie.params = {}
    ie.add_

# Generated at 2022-06-18 13:25:31.050224
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_frag_downloader(ydl, info_dict):
        class TestFD(FragmentFD):
            def __init__(self, ydl, info_dict):
                super(TestFD, self).__init__(ydl, info_dict)
                self.fragment_retries = 1
                self.skip_unavailable_fragments = True
                self.keep_fragments = True

            def real_download(self, filename, info_dict):
                self.to_screen('[%s] Downloading %s' % (self.FD_NAME, filename))
                self.report_destination(filename)
                return True


# Generated at 2022-06-18 13:25:42.890102
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .extractor.common import InfoExtractor
    from .utils import ExtractorError

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        _VALID_URL = r'(?i)^https?://.+'
        _TEST = {
            'url': 'http://example.com/',
            'info_dict': {
                'id': 'dummy',
                'ext': 'mp4',
                'title': 'dummy',
            },
        }

        def _real_extract(self, url):
            raise ExtractorError('This is a test', expected=True)

    gen_extractor_classes(DummyIE)
    dl = HttpQuietDownloader(None, {'quiet': True})


# Generated at 2022-06-18 13:27:27.994503
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:27:37.025425
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .post import PostProcessor
    from .downloader.external import ExternalFD
    from .downloader.rtmp import RtmpFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.http import HttpFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.dash import DashFD
    from .downloader.ism import IsmFD
    from .downloader.fragment import FragmentFD

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?test\.com/'


# Generated at 2022-06-18 13:27:44.532182
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.http import HttpFD
    from .downloader.rtmp import RtmpFD
    from .downloader.external import ExternalFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashFD
    from .downloader.hds import HdsFD
    from .downloader.ism import IsmFD
    from .downloader.fragment import FragmentFD
    from .downloader.rtmpdump import RtmpdumpFD
    from .downloader.external import ExternalFD
    from .downloader.f4m import F4mFD

# Generated at 2022-06-18 13:27:53.304748
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @staticmethod
        def suitable(url):
            return True

        def _real_extract(self, url):
            return {
                'id': 'test',
                'extractor': self.IE_NAME,
                'extractor_key': self.IE_NAME,
                'title': 'test',
                'url': url,
                'formats': [
                    {'format_id': 'test', 'url': url, 'ext': 'mp4'},
                ],
            }

    class FakeYDL(object):
        params = {}

       

# Generated at 2022-06-18 13:27:58.659985
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test')
    ie.add_info_extractor(TestFD)
    ie.extract('test')

# Generated at 2022-06-18 13:28:11.416142
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    ydl = FileDownloader({
        'noprogress': True,
        'quiet': True,
        'simulate': True,
        'format': 'best',
    })
    ydl.add_info_extractor(gen_extractors())
    ydl.add_default_info_extractors()
    ydl.params['match_filter'] = match_filter_func('best')
    ydl.params['outtmpl'] = '%(id)s'
    ydl.params['writedescription'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writeannotations'] = True
    ydl.params['writesubtitles'] = True
    ydl.params

# Generated at 2022-06-18 13:28:21.631955
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func


# Generated at 2022-06-18 13:28:29.003551
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp


# Generated at 2022-06-18 13:28:34.429631
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.external import ExternalFD
    from .downloader.rtmp import RTMPDownloader
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.http import HttpFD
    from .downloader.fragment import FragmentFD
    from .downloader.http.http_req_compat import compat_urllib_request
    from .downloader.http.http_req_compat import compat_urllib_error
    from .downloader.http.http_req_compat import compat_urllib_parse
   

# Generated at 2022-06-18 13:28:44.841255
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_downloader(ydl, info_dict):
        dl = HttpQuietDownloader(ydl, info_dict)
        assert dl.ydl is ydl
        assert dl.params == info_dict
        assert dl.params.get('continuedl')
        assert dl.params.get('quiet')
        assert dl.params.get('noprogress')
        assert dl.params.get('ratelimit') == ydl.params.get('ratelimit')
        assert dl.params.get('retries') == ydl.params.get('retries')
        assert dl.params.get('nopart') == ydl.params.get('nopart')
        assert dl