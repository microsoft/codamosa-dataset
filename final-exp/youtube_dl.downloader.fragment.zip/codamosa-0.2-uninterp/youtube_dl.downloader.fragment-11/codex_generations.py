

# Generated at 2022-06-18 13:20:09.126489
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test_fragments')
    ie.add_info_extractor(TestFD)
    ie.extract('test_fragments:%s' % TestFD.FD_NAME)

    ie = get_info_extractor('test_fragments_with_filter')
    ie.add_info_extractor(TestFD)
    ie.extract('test_fragments_with_filter:%s' % TestFD.FD_NAME)


# Generated at 2022-06-18 13:20:14.699231
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    ydl = gen_extractors()['youtube']
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert dl.params['logger'] == ydl.logger

# Generated at 2022-06-18 13:20:16.928678
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:20:26.223865
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def test_download(url, ie_key, expected_filenames, expected_total_frags,
                      expected_frag_retries, expected_frag_skip,
                      expected_frag_count, expected_frag_duration,
                      expected_frag_urls, expected_frag_content,
                      expected_frag_content_length):
        ie = get_info_extractor(ie_key)
        info = ie.extract(url)

# Generated at 2022-06-18 13:20:38.132072
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.ydl = ydl
            self.params = params
            self.FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ydl = get_info_extractor('youtube', {})
    fd = TestFD(ydl, {})
    assert fd.params.get('keep_fragments', False) is False
    assert fd.params.get('fragment_retries', 0) == 0
    assert fd.params.get('skip_unavailable_fragments', False) is False

# Generated at 2022-06-18 13:20:49.634526
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'
        _VALID_URL = r'(?:$)'
        _TEST = {
            'url': 'http://localhost/',
            'file': 'test.mp4',
            'info_dict': {
                'id': 'test',
                'ext': 'mp4',
                'title': 'test',
            },
        }

        def __init__(self, ydl, **kwargs):
            self.ydl = ydl


# Generated at 2022-06-18 13:20:56.961478
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import DateRange


# Generated at 2022-06-18 13:21:00.354222
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:21:13.577565
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..postprocessor import gen_pp_funcs


# Generated at 2022-06-18 13:21:26.522329
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp

    ydl = FileDownloader({
        'noprogress': True,
        'quiet': True,
        'format': 'best',
        'outtmpl': '%(id)s',
        'nooverwrites': True,
        'forceurl': True,
        'forcetitle': True,
        'forceduration': True,
        'forcefilename': True,
        'simulate': True,
        'skip_download': True,
    })
    ydl.add_info_extractor(gen_extractors())
    ydl.add_post_processor(gen_pp())
    ydl.params['test'] = True


# Generated at 2022-06-18 13:21:54.349881
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import DateRange
    from .compat import compat_urllib_request

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?example\.com/video\.mp4'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
            }

    ie = TestIE()
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE)
   

# Generated at 2022-06-18 13:22:03.735108
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def test_frag_download(ie, url, expected_frag_count, expected_frag_retries, expected_frag_skip):
        ie = get_info_extractor(ie)()
        ie.params = {
            'fragment_retries': expected_frag_retries,
            'skip_unavailable_fragments': expected_frag_skip,
        }
        info = ie.extract(url)
        assert info['_type'] == 'fragment'
        assert info['fragment_count'] == expected_frag_count
        assert info['fragment_retries'] == expected_frag_retries
        assert info['skip_unavailable_fragments'] == expected

# Generated at 2022-06-18 13:22:15.224386
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    ydl = FileDownloader({
        'quiet': True,
        'noprogress': True,
        'simulate': True,
        'format': 'best',
        'outtmpl': '%(id)s',
        'match_filter': match_filter_func('is_live:true'),
    })
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.add_info_extractor(gen_extractors()[1])
    ydl.add_info_extractor(gen_extractors()[2])
    ydl.add_info_extractor(gen_extractors()[3])

# Generated at 2022-06-18 13:22:28.125710
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func
    from .compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'Fake'
        IE_DESC = 'Fake extractor'
        _VALID_URL = r'(?i)^https?://.*'


# Generated at 2022-06-18 13:22:37.328639
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.external import ExternalFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.http import HttpFD
    from .downloader.rtmp import RtmpFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.dash import DashManifestFD
    from .downloader.hls import HlsNativeFD
    from .downloader.ism import IsmFD
    from .downloader.fragment import FragmentFD
    from .downloader.dash import DashNativeFD
    from .downloader.hds import HdsFD

# Generated at 2022-06-18 13:22:48.590991
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .downloader import gen_downloader_classes

    extractor_classes = gen_extractor_classes()
    downloader_classes = gen_downloader_classes()

    for ie in extractor_classes:
        ie.ydl = None
        ie.params = {}

    for de in downloader_classes:
        de.ydl = None
        de.params = {}

    for ie in extractor_classes:
        for de in downloader_classes:
            if de.is_suitable(ie.IE_NAME):
                de(ie.ydl, ie.params)
                break
        else:
            assert False, 'No downloader found for %s' % ie.IE_NAME

# Generated at 2022-06-18 13:23:00.516749
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

        def warning(self, msg):
            pass

        def error(self, msg):
            pass

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def __init__(self):
            self._downloader = FakeYDL()

        @staticmethod
        def suitable(url):
            return True

       

# Generated at 2022-06-18 13:23:06.442829
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
            }

    ie = TestIE(gen_extractors())
    dl = HttpQuietDownloader(ie, {'quiet': True})
    dl.to_screen('test')

# Generated at 2022-06-18 13:23:10.754833
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'
    assert HttpQuietDownloader.__module__ == __name__

# Generated at 2022-06-18 13:23:23.500242
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    dl = HttpQuietDownloader(ie, {'quiet': True})
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert dl.params['logger'] == ie.logger

# Generated at 2022-06-18 13:24:13.488781
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_fragment_fd(extractor_class, url):
        extractor = extractor_class()
        info_dict = extractor.extract(url)
        assert info_dict is not None
        assert info_dict.get('_type', 'video') == 'video'
        assert info_dict.get('id') is not None
        assert info_dict.get('title') is not None
        assert info_dict.get('url') is not None
        assert info_dict.get('ext') is not None
        assert info_dict.get('format') is not None
        assert info_dict.get('format_id') is not None
        assert info_dict.get('protocol') is not None
        assert info_dict

# Generated at 2022-06-18 13:24:21.697589
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = 'test'

        def report_warning(self, message):
            sys.stderr.write('WARNING: ' + message + '\n')

        def report_error(self, message, tb=None):
            sys.stderr.write('ERROR: ' + message + '\n')

    ie = FakeInfoExtractor()
    ie.add_info_extractor(gen_extractors())
    ie.add_default_info_extractors()

    fd = FragmentFD(ie, {'noprogress': True})

    # Test _prep

# Generated at 2022-06-18 13:24:31.806748
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..downloader.external import ExternalFD
    from ..downloader.http import HttpFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.dash import DashFD
    from ..downloader.hls import HlsFD
    from ..downloader.hlsnative import HlsFD as HlsNativeFD
    from ..downloader.f4m import F4mFD
    from ..downloader.ism import IsmFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.external import ExternalFD
    from ..downloader.ffmpeg import FFmpegFD
    from ..downloader.merge import merge_fd_outputs
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpQuietDownloader


# Generated at 2022-06-18 13:24:43.676008
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    # Test that all extractors that support fragments have a corresponding
    # FragmentFD class
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME in ('generic', 'googledrive'):
            continue
        if ie.IE_NAME == 'youtube':
            # YouTubeIE is a special case, it has a separate downloader for
            # DASH manifests
            continue
        if ie.IE_NAME == 'jwplatform':
            # JWPlatformIE is a special case, it has a separate downloader for
            # HLS manifests
            continue

# Generated at 2022-06-18 13:24:53.877551
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s.%(ext)s',
                'nooverwrites': True,
                'continuedl': False,
                'quiet': True,
                'noprogress': True,
                'ratelimit': None,
                'retries': 0,
                'nopart': False,
                'test': False,
            }

# Generated at 2022-06-18 13:25:06.245686
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        _VALID_URL = r'(?i)^https?://.+'
        _TEST = {
            'url': 'http://example.com/',
            'info_dict': {
                'id': 'dummy',
                'ext': 'mp4',
                'title': 'dummy',
            },
        }

        def _real_extract(self, url):
            return {
                'id': 'dummy',
                'ext': 'mp4',
                'title': 'dummy',
            }

    gen_extractor_classes([DummyIE])



# Generated at 2022-06-18 13:25:14.637576
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_frag_downloader(info_dict):
        fd = FragmentFD(
            gen_extractors(),
            {
                'format': 'best',
                'outtmpl': '%(id)s.%(ext)s',
                'quiet': True,
                'noprogress': True,
                'retries': 0,
                'nopart': True,
                'test': True,
            },
            match_filter_func('best'),
            info_dict,
        )
        fd.download()


# Generated at 2022-06-18 13:25:26.988677
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .downloader.http import HttpQuietDownloader

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?example\.com/video\.mp4'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    ie.add_info_extractor(TestIE)


# Generated at 2022-06-18 13:25:35.920726
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_constructor(extractor_class):
        if not issubclass(extractor_class, FragmentFD):
            return
        ie = extractor_class(
            {
                'params': {
                    'skip_download': True,
                },
            },
            match_filter_func('https://example.com/'))
        assert isinstance(ie, FragmentFD)

    for ie in gen_extractors():
        test_constructor(ie)

# Generated at 2022-06-18 13:25:46.922162
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .postprocessor import FFmpegMergerPP
    from .downloader.external import ExternalFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.http import HttpFD
    from .downloader.rtmp import RtmpFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.ism import IsmFD
    from .downloader.fragment import FragmentFD
    from .downloader.dash import DashFD
    from .downloader.hls import HlsNativeFD

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = False  # Do not list
        _VALID

# Generated at 2022-06-18 13:27:35.905849
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .post import PostProcessor
    from .downloader.http import HttpFD
    from .utils import DateRange

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    class TestPP(PostProcessor):
        def run(self, info):
            return [info]

    ie = TestIE(HttpQuietDownloader())
    ie.extract('http://example.test')


# Generated at 2022-06-18 13:27:38.279761
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .common import FileDownloader
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert issubclass(HttpQuietDownloader, FileDownloader)

# Generated at 2022-06-18 13:27:45.480062
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_frag_downloader(fd_name, url, expected_frag_count, expected_frag_retries, expected_frag_skip):
        fd = gen_extractors(match_filter_func(url))[0](
            {
                'fragment_retries': expected_frag_retries,
                'skip_unavailable_fragments': expected_frag_skip,
            }
        )
        assert isinstance(fd, FragmentFD)
        assert fd.FD_NAME == fd_name
        assert fd.params['fragment_retries'] == expected_frag_retries
        assert fd.params['skip_unavailable_fragments'] == expected_

# Generated at 2022-06-18 13:27:51.664202
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    gen_extractors()
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(downloader=FragmentFD())
    ie.extract('http://localhost/')

# Generated at 2022-06-18 13:28:02.851953
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func


# Generated at 2022-06-18 13:28:15.108767
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return match_filter_func(info_dict, {'protocol': 'http'})

    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'generic':
            continue
        ie = ie(FragmentFD(dict()))
        if not ie.suitable(test_filter):
            continue
        if not ie.working():
            continue
        if not ie.IE_NAME in ('youtube', 'twitch', 'crunchyroll', 'vk'):
            continue
        if ie.IE_NAME == 'youtube' and ie._WORKING is False:
            continue

# Generated at 2022-06-18 13:28:24.495386
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class FakeYDL:
        def __init__(self, params):
            self.params = params

    class FakeIE(get_info_extractor('generic')):
        def __init__(self, downloader):
            self.downloader = downloader

    ie = FakeIE(FakeYDL({}))
    fd = FragmentFD(ie)
    assert fd.params == {
        'fragment_retries': 10,
        'keep_fragments': False,
        'skip_unavailable_fragments': False,
    }

# Generated at 2022-06-18 13:28:26.812301
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:28:39.001247
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie, url):
        ie.extract(url)
        assert ie.suitable(url)
        assert ie.url_result(url)

    for ie in gen_extractors():
        if ie.IE_NAME == 'generic':
            continue
        if ie.IE_NAME in ('YoutubePlaylist', 'YoutubeSearch'):
            continue
        if ie.IE_NAME in ('BandcampWeekly', 'SoundcloudSet'):
            continue
        if ie.IE_NAME in ('Crackle', 'Videa'):
            continue

# Generated at 2022-06-18 13:28:42.578839
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    ydl = gen_extractors()['youtube']
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.params['quiet']