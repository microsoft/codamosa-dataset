

# Generated at 2022-06-18 13:20:00.907563
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'
    assert HttpQuietDownloader.__module__ == 'youtube_dl.downloader.fragment'

# Generated at 2022-06-18 13:20:13.064863
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.external import ExternalFD
    from .downloader.rtmp import RTMPFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD

    ydl = FileDownloader({})
    ydl.add_info_extractor(gen_extractors())
    ydl.add_post_processor(gen_postprocessors())
    ydl.add_default_info_extractors()

    # Test that HttpQuietDownloader is used for external downloads
    fd = HttpQuietDownloader(ydl, {'quiet': True})
   

# Generated at 2022-06-18 13:20:22.725723
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .downloader import gen_extractor_downloader_classes
    from .common import FileDownloader
    from .http import HttpFD

    # Test that HttpQuietDownloader is a subclass of HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

    # Test that HttpQuietDownloader is a subclass of FileDownloader
    assert issubclass(HttpQuietDownloader, FileDownloader)

    # Test that HttpQuietDownloader is in gen_extractor_downloader_classes
    assert HttpQuietDownloader in gen_extractor_downloader_classes()

    # Test that HttpQuietDownloader is not in gen_extractor_classes
    assert HttpQuietDownloader not in gen_extractor_classes()

# Generated at 2022-06-18 13:20:36.008833
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def report_destination(self, *args, **kargs):
            pass

    class FakeLogger(object):
        def debug(self, *args):
            pass


# Generated at 2022-06-18 13:20:44.829207
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_constructor(fd_name, url, expected_result):
        for ie in gen_extractors():
            if match_filter_func(ie.IE_NAME)(fd_name):
                ie.suitable(url)  # This will raise ExtractorError if not suitable
                break
        else:
            assert False, 'Extractor for %r not found' % fd_name

        ydl = FakeYDL()
        fd = FragmentFD(ydl, {'outtmpl': '%(id)s'})
        fd.add_info_extractor(ie)
        fd.params['usenetrc'] = False
        fd.params['username'] = None
        fd.params['password']

# Generated at 2022-06-18 13:20:54.477469
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE()
    ie.add_info_extractor(gen_extractor(TestIE))
    ie.add_info_extractor(gen_extractor(TestIE, ie_key='Test2'))
    ie.add_info_extractor(gen_extractor(TestIE, ie_key='Test3'))



# Generated at 2022-06-18 13:21:06.232133
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    ie.add_info_extractor(TestIE)
    ie.add_default_info_extractors()
    ie.extract('http://example.com/')
    ie.extract('http://example.com/', download=False)


# Generated at 2022-06-18 13:21:14.885336
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    # Test that all extractors that support fragmented media have
    # FragmentFD as their downloader class
    for ie in gen_extractors():
        if match_filter_func(ie.IE_NAME, ['fragments']):
            assert ie.ie_key() in globals()
            assert issubclass(globals()[ie.ie_key()], FragmentFD)

# Generated at 2022-06-18 13:21:27.727107
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _TEST = {
            'url': 'http://example.com/video.mp4',
            'info_dict': {
                'id': 'video',
                'ext': 'mp4',
                'title': 'video',
            },
        }

        def _real_extract(self, url):
            return {
                'id': 'video',
                'ext': 'mp4',
                'title': 'video',
            }

    ie = TestIE(gen_extractors())
    dl = HttpQuietDownloader(ie, {'quiet': True})

# Generated at 2022-06-18 13:21:34.801407
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    gen_extractors()
    from ..extractor import get_info_extractor
    ie = get_info_extractor('Youtube')
    ydl = ie._ydl
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.ydl is ydl
    assert dl.params['quiet'] is True
    assert dl.params['noprogress'] is True

# Generated at 2022-06-18 13:22:06.531436
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors

    class TestInfoDict(dict):
        pass

    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            assert 'fragment_index' in info_dict
            assert 'fragment_count' in info_dict
            assert 'total_frags' in info_dict
            assert 'live' in info_dict
            assert 'tmpfilename' in info_dict
            assert 'filename' in info_dict
            assert 'url' in info_dict
            assert 'http_headers' in info_dict
            assert 'ad_frags' in info_dict

# Generated at 2022-06-18 13:22:18.824142
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        _VALID_URL = r'(?i)^https?://.+'
        IE_NAME = 'Test'
        IE_DESC = 'Test IE'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE)

# Generated at 2022-06-18 13:22:31.221999
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class MockInfoExtractor(object):
        IE_NAME = 'mock'
        IE_DESC = 'Mock info extractor'
        _VALID_URL = r'(?:mock)'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, url):
            return re.match(cls._VALID_URL, url) is not None

        def _real_extract(self, url):
            return {
                'id': 'mock',
                'title': 'mock',
                'formats': [
                    {'format_id': 'mock', 'url': 'mock://mock/mock.mock'},
                ],
            }

    ie

# Generated at 2022-06-18 13:22:41.164545
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @staticmethod
        def suitable(url):
            return True


# Generated at 2022-06-18 13:22:51.168203
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .extractor.common import InfoExtractor
    from .utils import ExtractorError

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            raise ExtractorError('test', expected=True)

    FakeIE = gen_extractor_classes(FakeInfoExtractor)
    ie = FakeIE(params={})
    dl = HttpQuietDownloader(ie, {'quiet': True})
    dl.download('test', {'url': 'http://localhost/'})

# Generated at 2022-06-18 13:22:53.690024
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:23:04.346467
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request


# Generated at 2022-06-18 13:23:05.600729
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:23:18.067031
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class MockYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
            }
            self.cache = None
            self.progress_hooks = []

        def add_progress_hook(self, hook):
            self.progress_hooks.append(hook)

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:23:28.861745
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie):
        if ie.IE_NAME in ('generic', 'googledrive', 'googlesearch'):
            return
        if ie.IE_NAME.startswith(('test_', 'test:')):
            return
        if ie.IE_NAME in ('youtube:playlist', 'youtube:search', 'youtube:search_url', 'youtube:channel', 'youtube:user', 'youtube:uservideo'):
            return
        if ie.IE_NAME in ('crunchyroll:playlist', 'crunchyroll:show'):
            return

# Generated at 2022-06-18 13:24:17.670654
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:24:19.146280
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:24:28.381548
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .utils import match_filter_func

    class MyInfoExtractor(InfoExtractor):
        IE_NAME = 'MyInfoExtractor'
        _VALID_URL = r'(?i)^https?://.*'
        _TEST = {
            'url': 'http://example.com',
            'file': 'test.mp4',
            'info_dict': {
                'id': 'test',
                'ext': 'mp4',
                'title': 'test video',
                'duration': 10,
            },
        }


# Generated at 2022-06-18 13:24:34.052575
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    ydl = gen_extractors()['youtube']
    hqd = HttpQuietDownloader(ydl, {'continuedl': True, 'quiet': True, 'noprogress': True})
    assert hqd.params['continuedl']
    assert hqd.params['quiet']
    assert hqd.params['noprogress']

# Generated at 2022-06-18 13:24:46.539006
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .extractor.common import InfoExtractor
    from .utils import ExtractorError

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

        def warning(self, msg):
            pass

        def error(self, msg):
            pass

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'Fake'
        IE_DESC = 'Fake extractor'

        def _real_extract(self, url):
            raise ExtractorError('Useful error message', expected=True)

    ie = FakeInfoExtractor()
   

# Generated at 2022-06-18 13:24:49.993020
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:25:02.273007
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeYDL:
        def __init__(self, params):
            self.params = params

        def to_screen(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def report_destination(self, *args, **kargs):
            pass

        def temp_name(self, *args, **kargs):
            return 'tmp'

        def try_rename(self, *args, **kargs):
            pass

        def calc_eta(self, *args, **kargs):
            return 'ETA'


# Generated at 2022-06-18 13:25:12.301603
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    gen_extractors()
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader.http import HttpFD
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.external import ExternalFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.http import HttpFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import Hls

# Generated at 2022-06-18 13:25:21.053985
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .common import FileDownloader
    from ..utils import FakeYDL

    class TestFD(FragmentFD):
        FD_NAME = 'test'

    ydl = FakeYDL()
    fd = TestFD(ydl)
    assert isinstance(fd, FileDownloader)
    assert fd.ydl is ydl
    assert fd.params == {}
    assert fd.to_screen == sys.stdout.write
    assert fd.to_stderr == sys.stderr.write
    assert fd.report_warning == ydl.report_warning
    assert fd.report_error == ydl.report_error

# Generated at 2022-06-18 13:25:34.359883
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func


# Generated at 2022-06-18 13:27:22.057206
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(ie_key):
        return match_filter_func(ie_key, ['youtube'])(ie_key)

    gen_extractors(test_filter)

    ydl = HttpQuietDownloader(
        {
            'quiet': True,
            'noprogress': True,
            'nopart': True,
            'retries': 0,
            'test': True,
        },
        {
            'extractor_key': 'Youtube',
            'url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
        }
    )

# Generated at 2022-06-18 13:27:32.251161
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie):
        if ie.IE_NAME == 'generic':
            return False
        if ie.IE_NAME in ('YoutubeLiveStream', 'YoutubeLiveIE'):
            return False
        if ie.IE_NAME in ('AparatIE', 'VidziIE', 'VidziEmbedIE', 'VidziApiIE'):
            return False
        if ie.IE_NAME in ('VimeoIE', 'VimeoChannelIE', 'VimeoAlbumIE', 'VimeoUserIE'):
            return False
        if ie.IE_NAME in ('SoundcloudIE', 'SoundcloudSetIE', 'SoundcloudUserIE', 'SoundcloudPlaylistIE'):
            return False

# Generated at 2022-06-18 13:27:33.934747
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:27:41.688904
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        pass

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.extractors = gen_extractors()
            self.extractors_by_id = {}
            for ie in self.extractors:
                self.extractors_by_id[ie.ie_key()] = ie

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:27:49.885060
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .compat import compat_urllib_request

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    class TestFD(HttpFD):
        def to_screen(self, *args, **kargs):
            pass

    ie = TestIE(gen_extractor({'IE_NAME': 'test'}))
    dl = TestFD(ie, {'quiet': True})
    dl.report_destination('test')
    assert dl.params['quiet']

# Generated at 2022-06-18 13:27:53.761972
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test')
    ie.set_downloader(TestFD(ie))
    ie.download('testid')

# Generated at 2022-06-18 13:28:06.464989
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return info_dict['id'] == 'test_id'

    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'match_filter': match_filter_func(test_filter),
        'quiet': True,
    })
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.add_info_extractor(gen_extractors()[1])
    ydl.add_info_extractor(gen_extractors()[2])
    ydl.add_info_extractor(gen_extractors()[3])

# Generated at 2022-06-18 13:28:18.046634
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func
    from .compat import compat_urllib_request

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(TestIE.ie_key())


# Generated at 2022-06-18 13:28:26.713865
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_func(info_dict):
        return info_dict['extractor'] == 'youtube'

    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'quiet': True,
        'noprogress': True,
        'matchfilter': match_filter_func(test_func),
        'writedescription': True,
    })
    ydl.add_info_extractor(gen_extractors())
    ydl.add_info_extractor(gen_extractors(u'generic'))
    ydl.add_info_extractor(gen_extractors(u'*'))

# Generated at 2022-06-18 13:28:39.009620
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

        def to_screen(self, *args, **kargs):
            pass

    class FakeLogger(object):
        def debug(self, *args):
            pass

    class FakeInfoDict(dict):
        def __init__(self):
            super(FakeInfoDict, self).__init__()
            self['extractor'] = 'youtube'
            self['url'] = 'http://www.youtube.com/watch?v=BaW_jenozKc'
