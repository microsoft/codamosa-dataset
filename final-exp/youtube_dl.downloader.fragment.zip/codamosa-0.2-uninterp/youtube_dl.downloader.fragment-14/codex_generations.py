

# Generated at 2022-06-18 13:20:06.850836
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.external import ExternalFD
    from .downloader.rtmp import RTMPFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.http import HttpFD
    from .downloader.fragment import FragmentFD
    from .downloader.common import FileDownloader
    from .downloader.external import ExternalFD
    from .downloader.rtmp import RTMPFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD

# Generated at 2022-06-18 13:20:18.824613
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp


# Generated at 2022-06-18 13:20:30.963183
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params

        def add_info_extractor(self, ie):
            self.ie = ie

        def add_default_info_extractors(self):
            pass

        def add_post_processor(self, pp):
            pass

        def add_progress_hook(self, ph):
            pass

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

# Generated at 2022-06-18 13:20:41.945522
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.extractor_descriptions = {}
            self.extractors = gen_extractors()
            self.extractors_by_id = {}
            for ie in self.extractors:
                self.extractors_by_id[ie.IE_NAME] = ie
                self.extractor_descriptions[ie.IE_NAME] = ie.IE_DESC

       

# Generated at 2022-06-18 13:20:52.494861
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.ydl = ydl
            self.params = params
            self.ie = get_info_extractor(ydl, 'test')
            self.ie.params = params

        def real_download(self, filename, info_dict):
            return self.ie._real_extract(info_dict)


# Generated at 2022-06-18 13:21:03.638723
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..downloader.external import ExternalFD
    from ..downloader.rtmp import RTMPFD
    from ..downloader.http import HttpFD
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hlsnative import HlsFD as HlsNativeFD
    from ..downloader.dashnative import DashSegmentsFD as DashNativeFD

    def test_constructor(downloader_class):
        ydl = {}
        params = {}
        info_dict = {}
        downloader = downloader_class(ydl, params)
        assert downloader.ydl is ydl
        assert downloader.params is params
        assert downloader.info_

# Generated at 2022-06-18 13:21:15.846108
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def test_filter(ie_key):
        return ie_key == 'youtube'

    ydl = get_info_extractor(
        'youtube',
        downloader_kwargs={
            'test': True,
            'quiet': True,
            'match_filter': match_filter_func(test_filter),
        }
    )
    fd = FragmentFD(ydl, {'test': True, 'quiet': True})
    assert fd.params['test'] is True
    assert fd.params['quiet'] is True
    assert fd.ydl is ydl
    assert fd.FD_NAME == 'fragment'

# Generated at 2022-06-18 13:21:28.842153
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'
        _VALID_URL = r'(?:$)'

        def __init__(self, downloader=None):
            self._downloader = downloader

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            pass

    ie = get_info_extractor(FakeInfoExtractor.IE_NAME)
    assert ie is None

    ie = FakeInfoExtractor()
    ie.add_info_extractor(FakeInfoExtractor)
    ie = get_info_extractor(FakeInfoExtractor.IE_NAME)
    assert ie is not None

    ydl = FakeYDL()

# Generated at 2022-06-18 13:21:38.684872
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    gen_extractors()
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'formats': [{
                    'format_id': 'test',
                    'url': url,
                }],
            }

    ie = TestIE(downloader=FragmentFD())
    ie.extract('http://example.com/')

# Generated at 2022-06-18 13:21:48.260859
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.http import HttpFD

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*'

    ie = TestIE(HttpQuietDownloader(
        {
            'outtmpl': '%(id)s',
            'quiet': True,
            'noprogress': True,
            'nopart': True,
            'continuedl': True,
            'logger': None,
            'extractors': gen_extractors(),
            'postprocessors': gen_postprocessors(),
            'progress_hooks': [],
        }))

# Generated at 2022-06-18 13:22:24.368776
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request
    from ..utils import sanitize_open

    url = 'http://example.com/video.mp4'

# Generated at 2022-06-18 13:22:29.587561
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    ie = get_info_extractor('youtube')
    fd = FragmentFD(ie, {}, ie.ydl)
    assert fd.params == {
        'noprogress': False,
        'progress_with_newline': True,
    }

# Generated at 2022-06-18 13:22:38.047847
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .post import PostProcessor
    from .downloader.http import HttpFD
    from .downloader.rtmp import RtmpFD
    from .downloader.external import ExternalFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.dash import DashManifestFD
    from .downloader.ism import IsmFD
    from .downloader.fragment import FragmentFD
    from .utils import DateRange


# Generated at 2022-06-18 13:22:50.269856
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'skip_download': True,
                'noprogress': True,
                'simulate': True,
            }
            self.to_screen = lambda *args, **kargs: None
            self.report_warning = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None

# Generated at 2022-06-18 13:23:01.955335
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return info_dict['id'] == 'test'

    ydl = FileDownloader(params={
        'noprogress': True,
        'quiet': True,
        'format': 'best',
        'outtmpl': '%(id)s',
        'matchfilter': match_filter_func(test_filter),
    })
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.add_info_extractor(gen_extractors()[1])
    ydl.add_info_extractor(gen_extractors()[2])
    ydl.add_info_extractor(gen_extractors()[3])

# Generated at 2022-06-18 13:23:10.289697
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }
            self.cache = None
            self.extractor_descriptions = {}
            self.extractors = gen_extractors()
            self.IE_NAME = 'test'


# Generated at 2022-06-18 13:23:23.161645
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'skip_download': True,
                'quiet': True,
                'simulate': True,
                'noprogress': True,
                'noplaylist': True,
                'match_filter': match_filter_func('all'),
            }
            self.cache = None
            self.extractor_descriptions = gen_extractors()

    ydl = FakeYDL()


# Generated at 2022-06-18 13:23:32.500965
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class MockInfoExtractor(object):
        IE_NAME = 'mock'
        IE_DESC = 'Mock Info Extractor'
        _VALID_URL = r'(?:mock)'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, url):
            return re.match(cls._VALID_URL, url) is not None

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            pass

    class MockYDL(object):
        params = {
            'noprogress': False,
            'progress_hooks': [],
        }


# Generated at 2022-06-18 13:23:41.680391
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_FragmentFD(extractor_class):
        if not issubclass(extractor_class, FragmentFD):
            return
        if not match_filter_func(extractor_class.IE_NAME):
            return
        extractor = extractor_class()
        assert isinstance(extractor, FragmentFD)

    for ie in gen_extractors():
        _test_FragmentFD(ie)

# Generated at 2022-06-18 13:23:50.122848
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import get_cachedir

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': None,
                'progress_hooks': [],
                'cachedir': get_cachedir(),
            }
            self.extractors = gen_extractors()
            self.IE_NAME = 'test'
            self.ie = InfoExtractor(self, 'test')

    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.ydl is ydl

# Generated at 2022-06-18 13:24:47.872817
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_downloader(downloader, url, expected_filename, expected_status):
        info_dict = {
            'id': 'test',
            'url': url,
            'extractor': 'test',
            'extractor_key': 'test',
        }
        params = {
            'noprogress': True,
            'format': 'test',
            'outtmpl': '%(id)s.%(ext)s',
        }
        downloader.download(info_dict)
        assert os.path.isfile(expected_filename)
        assert downloader._hook_progress.call_args[0][0]['status'] == expected_status
        os.remove(expected_filename)


# Generated at 2022-06-18 13:24:57.737769
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    def _test_frag_downloader(ie, url, expected_frag_count):
        ydl = FakeYDL()
        ie = get_info_extractor(ie)
        ie.ydl = ydl
        ie.params = {}
        info = ie._real_extract(url)
        assert isinstance(info['fragment_downloader'], FragmentFD)
        assert info['fragment_count'] == expected_frag_count
        return info

    # Test DASH
    info = _test_frag_downloader('YoutubeIE', 'http://www.youtube.com/watch?v=Xn599R0ZBwg', 2)

# Generated at 2022-06-18 13:25:01.613867
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:25:11.853288
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .post import PostProcessor
    from .downloader.external import ExternalFD
    from .downloader.http import HttpFD
    from .downloader.rtmp import RtmpFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.dash import DashFD
    from .downloader.ism import IsmFD
    from .downloader.fragment import FragmentFD
    from .downloader.http import HttpQuietDownloader
    from .downloader.http import HttpFD
    from .downloader.http import HttpFD
    from .downloader.http import HttpFD
   

# Generated at 2022-06-18 13:25:13.527486
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:25:25.383601
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(object):
        def __init__(self, ie_name):
            self._ie_name = ie_name

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            pass

        @property
        def IE_NAME(self):
            return self._ie_name

        @property
        def ie_key(self):
            return self.IE_NAME

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.cache = None
            self.to_screen = lambda *args, **kargs: None

        def add_info_extractor(self, ie):
            self.ie = ie

# Generated at 2022-06-18 13:25:37.458376
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    def test_downloader(ydl, info_dict):
        return TestFD(ydl, info_dict)

    gen_extractors(test_downloader)

    ydl = FakeYDL()
    ydl.params['skip_download'] = True
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    ydl.params['simulate'] = True
    ydl.params['match_filter'] = match_filter_func('test')
    ydl.params['outtmpl'] = '%(id)s'

# Generated at 2022-06-18 13:25:48.318658
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*'

        def _real_extract(self, url):
            return {'id': 'test', 'title': 'test', 'url': url}

    ie = TestIE()
    ie.add_info_extractor(TestIE)
    ie.add_info_extractor(gen_extractors())
    ie.add_default_info_extractors()
    ie.extract('http://example.com/')
    ie.extract('http://example.com/')

# Generated at 2022-06-18 13:25:56.389045
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    ie = get_info_extractor('youtube')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    assert ie.result['id'] == 'BaW_jenozKc'
    assert ie.result['title'] == 'youtube-dl test video "\'/\\ä↭𝕐'

    ie = get_info_extractor('youtube')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    assert ie.result['id'] == 'BaW_jenozKc'
    assert ie.result['title'] == 'youtube-dl test video "\'/\\ä↭𝕐'

    ie = get_

# Generated at 2022-06-18 13:26:04.692804
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_str

    def test_extractor(ie):
        if ie.IE_NAME == 'generic':
            return
        if ie.IE_NAME in ('youtube', 'youtube:playlist', 'youtube:search', 'youtube:channel', 'youtube:user', 'youtube:uservideo', 'youtube:uservideos', 'youtube:show', 'youtube:movie'):
            return
        if ie.IE_NAME in ('soundcloud', 'soundcloud:set', 'soundcloud:user', 'soundcloud:favorites', 'soundcloud:playlist'):
            return
        if ie.IE_NAME in ('bandcamp', 'bandcamp:album', 'bandcamp:track'):
            return

# Generated at 2022-06-18 13:27:54.367795
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.get = self.__getitem__

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': None,
            }
            self.extractors = gen_extractors()
            self.extractor_descriptions = {}
            for ie in self.extractors:
                self.extractor_descriptions[ie.IE_NAME] = ie.IE_DESC


# Generated at 2022-06-18 13:28:06.791304
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_FragmentFD(fd_name, url, expected_result):
        for ie in gen_extractors():
            if match_filter_func(ie.IE_NAME)(fd_name):
                fd = ie.ie_key_map[fd_name](None, {})
                result = fd.suitable(url)
                assert result == expected_result, (
                    '%s: %r != %r for url=%r' % (fd_name, result, expected_result, url))
                return
        assert False, 'Extractor for %r not found' % fd_name

    _test_FragmentFD('hlsnative', 'http://example.com/manifest.m3u8', True)


# Generated at 2022-06-18 13:28:18.320205
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .utils import DateRange


# Generated at 2022-06-18 13:28:26.911953
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_str

    class FakeYDL:
        def __init__(self):
            self.params = {}
            self.cache = None
            self.to_screen = lambda *args, **kargs: None
            self.to_stdout = lambda *args, **kargs: None
            self.to_stderr = lambda *args, **kargs: None
            self.set_filename = lambda *args, **kargs: None
            self.report_warning = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None
            self.report_file_already_downloaded = lambda *args, **kargs: None

# Generated at 2022-06-18 13:28:39.001311
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.get = self.__getitem__

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': None,
            }
            self.cache = None

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:28:45.430924
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(ie_key):
        return match_filter_func(ie_key, ['youtube'])(ie_key)

    extractors = gen_extractors(test_filter)
    assert len(extractors) == 1
    assert extractors[0].IE_NAME == 'Youtube'
    assert isinstance(extractors[0](), FragmentFD)

# Generated at 2022-06-18 13:28:50.839498
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test')
    ie.set_downloader(TestFD(ie))
    ie.download('http://localhost/')

# Generated at 2022-06-18 13:28:59.605625
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    ydl = FileDownloader({})
    ydl.add_info_extractor(gen_extractors())
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    ydl.params['format'] = 'bestvideo'
    ydl.params['outtmpl'] = '%(id)s'
    ydl.params['matchtitle'] = 'test'
    ydl.params['nooverwrites'] = True
    ydl.add_default_info_extractors()
    ydl.add_progress_hook(match_filter_func('test'))

# Generated at 2022-06-18 13:29:09.957419
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': None,
            }

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'Fake'
        IE_DESC = False  # Do not list
        _VALID_URL = r'(?i)^https?://.*\.fake'

    ie = FakeInfoExtractor()
    ie.ydl = FakeYDL()
    ie._downloader = HttpQuietDownloader(ie.ydl, ie.params)
    assert ie._downloader.params['noprogress']

    ie = FakeInfoExtractor

# Generated at 2022-06-18 13:29:16.319108
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    # Test that all extractors that support fragmented media are derived from
    # FragmentFD
    extractors = gen_extractors()
    for ie in extractors:
        if match_filter_func(ie.IE_NAME, ['fragments']):
            assert issubclass(ie.__class__, FragmentFD), (
                '%s is not derived from FragmentFD' % ie.IE_NAME)