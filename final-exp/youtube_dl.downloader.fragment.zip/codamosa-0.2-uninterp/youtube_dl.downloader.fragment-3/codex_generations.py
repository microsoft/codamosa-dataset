

# Generated at 2022-06-18 13:20:09.082968
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_urlparse

    class MockYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'simulate': True,
                'skip_download': True,
                'quiet': True,
            }
            self.cache = None
            self.to_screen = lambda *args, **kargs: None

        def add_info_extractor(self, ie):
            self.ie = ie

        def add_default_info_extractors(self):
            pass

        def process_ie_result(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:20:14.204387
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'
    assert HttpQuietDownloader.__module__ == 'youtube_dl.downloader.fragment'

# Generated at 2022-06-18 13:20:23.384831
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..downloader.http.http_req_test import FakeYDL
    from ..downloader.http.http_req_test import FakeHttpResponse
    from ..downloader.http.http_req_test import FakeUrlOpen
    from ..downloader.http.http_req_test import FakeSocket
    from ..downloader.http.http_req_test import FakeHeadRequest
    from ..downloader.http.http_req_test import FakeGetRequest
    from ..downloader.http.http_req_test import FakePostRequest

# Generated at 2022-06-18 13:20:36.714869
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..downloader.http import HttpFD
    from ..utils import match_filter_func

    def test_func(info_dict):
        return True

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'match_filter': match_filter_func(test_func),
                'outtmpl': '%(id)s',
                'nooverwrites': True,
                'continuedl': True,
                'noprogress': True,
                'quiet': True,
                'ratelimit': None,
                'retries': 0,
                'nopart': False,
                'test': False,
            }
            self.extractors = gen_extractors()

    ydl = FakeYDL

# Generated at 2022-06-18 13:20:45.240562
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(object):
        IE_NAME = 'test'

    ie = FakeInfoExtractor()
    ie.extractor = get_info_extractor(ie.IE_NAME)
    ie.params = {}
    ie.add_info_extractor(ie.extractor)
    ie.add_default_info_extractors()

    fd = FragmentFD(ie, {}, match_filter_func('test'))
    assert fd.FD_NAME == 'test'
    assert fd.params == {}
    assert fd.ydl is ie
    assert fd.match_filter_func('test') is True
    assert fd.match_filter_func('test2') is False

# Generated at 2022-06-18 13:20:54.668269
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'formats': [
                    {'url': 'http://test/test.f4m', 'format_id': 'f4m'},
                    {'url': 'http://test/test.m3u8', 'format_id': 'hls'},
                ],
            }

    ie = TestIE()

# Generated at 2022-06-18 13:21:06.330497
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        _VALID_URL = r'(?i)^https?://.+'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, url):
            return re.match(cls._VALID_URL, url) is not None

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'formats': [
                    {'format_id': 'test', 'url': url},
                ],
            }


# Generated at 2022-06-18 13:21:20.223683
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie):
        if ie.IE_NAME in ('generic', 'googledrive', 'googlesearch'):
            return
        if ie.IE_NAME.startswith(('test_', 'Youtube')):
            return
        if ie.IE_NAME in ('crunchyroll', 'crunchyrolles'):
            return
        if ie.IE_NAME in ('vk', 'vimeo', 'vine', 'soundcloud', 'mixcloud'):
            return
        if ie.IE_NAME in ('xhamster', 'xhamster_thumbs'):
            return
        if ie.IE_NAME in ('extremetube', 'extremetube_tags'):
            return

# Generated at 2022-06-18 13:21:32.660020
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    gen_extractors()
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader.http import HttpFD
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD
    from ..downloader.dash import DashSegmentsFD

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'url': url,
            }


# Generated at 2022-06-18 13:21:41.297082
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.http import HttpFD
    from .downloader.rtmp import RTMPFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.external import ExternalFD
    from .downloader.fragment import FragmentFD
    from .downloader.ism import IsmFD
    from .downloader.m3u8 import M3u8FD
    from .downloader.dash import DashFD

    def test_downloader(downloader_cls):
        assert issubclass(downloader_cls, FileDownloader)
       

# Generated at 2022-06-18 13:22:15.879190
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import get_info_extractor

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.cache = {}

        def add_info_extractor(self, ie):
            self.cache[ie.ie_key()] = ie


# Generated at 2022-06-18 13:22:24.737154
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    # Test that all extractors that support fragmented media have
    # FragmentFD as their downloader
    for ie in gen_extractors():
        if match_filter_func(ie.IE_NAME, ie.ie_keywords, ['fragmented']):
            assert issubclass(ie.FD_CLASS, FragmentFD), (
                '%s.FD_CLASS is not a subclass of FragmentFD' % ie.IE_NAME)

# Generated at 2022-06-18 13:22:35.542987
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'simulate': True,
                'quiet': True,
                'format': 'best',
                'outtmpl': '%(id)s.%(ext)s',
                'ignoreerrors': False,
                'logger': None,
                'progress_hooks': [],
            }
            self.cache = None
            self.server = None
            self.extractor_desc = []
            self.ie_key_map = {}
            self.ie_map = {}
            self.download_retcode = None


# Generated at 2022-06-18 13:22:37.873519
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    assert issubclass(FragmentFD, FileDownloader)

# Generated at 2022-06-18 13:22:48.591306
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_func(ie, ie_result):
        if ie.IE_NAME == 'generic':
            return False
        if ie.IE_NAME == 'youtube':
            return ie_result['id'].startswith(('gvsearch', 'ytsearch'))
        return True

    ie = gen_extractors(match_filter_func=match_filter_func(test_func))
    for i in ie:
        if i.IE_NAME == 'youtube':
            continue
        dl = HttpQuietDownloader(i, {'quiet': True})
        assert dl.params['quiet']

# Generated at 2022-06-18 13:23:00.516931
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.ie = get_info_extractor('youtube')

        def add_info_extractor(self, ie):
            self.ie = ie

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def report_file_already_downloaded(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:23:08.337923
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    class TestYDL(object):
        def __init__(self):
            self.params = {}
            self.to_screen = lambda *x: None
    ydl = TestYDL()
    dl = HttpQuietDownloader(ydl, {'continuedl': True, 'quiet': True})
    assert dl.params['continuedl']
    assert dl.params['quiet']
    assert not dl.params['noprogress']
    assert not dl.params['ratelimit']
    assert dl.params['retries'] == 0
    assert not dl.params['nopart']
    assert not dl.params['test']

# Generated at 2022-06-18 13:23:20.825794
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        _VALID_URL = r'(?i)^https?://.+'
        _TEST = {
            'url': 'http://example.com/',
            'info_dict': {
                'id': 'dummy',
                'ext': 'mp4',
                'title': 'dummy',
            },
        }

        def _real_extract(self, url):
            return {
                'id': 'dummy',
                'ext': 'mp4',
                'title': 'dummy',
            }

    ie = DummyIE(gen_extractors())


# Generated at 2022-06-18 13:23:31.058875
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_fragment_downloader(ydl, info_dict):
        class TestFD(FragmentFD):
            def __init__(self, ydl, info_dict):
                FragmentFD.__init__(self, ydl, info_dict)
                self.to_screen = ydl.to_screen
                self.report_warning = ydl.report_warning
                self.report_error = ydl.report_error
                self.params = ydl.params
                self.temp_name = ydl.prepare_filename
                self.try_rename = ydl.try_rename
                self.report_destination = ydl.report_destination
                self.calc_eta = ydl.calc

# Generated at 2022-06-18 13:23:43.400099
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_ydl(ydl, url, expected_filename):
        ydl.params.update({
            'outtmpl': '%(id)s',
            'writedescription': True,
            'writeinfojson': True,
            'writeannotations': True,
            'writethumbnail': True,
            'writesubtitles': True,
            'writeautomaticsub': True,
            'allsubtitles': True,
            'write_all_thumbnails': True,
            'skip_download': True,
        })
        info = ydl.extract_info(url, download=False)
        assert info['id'] == expected_filename


# Generated at 2022-06-18 13:24:37.982119
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return match_filter_func(info_dict, {'protocol': 'http'})

    extractors = gen_extractors(test_filter)
    extractor = extractors[0]
    fd = FragmentFD(extractor._ydl, extractor._downloader, {}, {}, {}, {})
    assert fd.FD_NAME == extractor.IE_NAME

# Generated at 2022-06-18 13:24:49.987885
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func
    from .compat import compat_urllib_request

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    ie.add_info_extractor(TestIE)
    ie.add_default_info_extractors()


# Generated at 2022-06-18 13:25:02.338818
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    ydl = FileDownloader({
        'noprogress': True,
        'quiet': True,
        'format': 'best',
        'outtmpl': '%(id)s.%(ext)s',
    })

    # Test that all extractors are supported
    for ie in gen_extractors():
        if ie.IE_NAME == 'generic':
            continue
        if ie.IE_NAME in ('youtube:playlist', 'youtube:search', 'youtube:channel', 'youtube:user', 'youtube:watchlater', 'youtube:recommended', 'youtube:top_rated', 'youtube:trending'):
            continue

# Generated at 2022-06-18 13:25:12.337459
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class FakeInfoExtractor(object):
        IE_NAME = 'test'

    class FakeYDL(object):
        params = {}
        def __init__(self):
            self.extractor = FakeInfoExtractor()

    ydl = FakeYDL()
    fd = FragmentFD(ydl, {'noprogress': True, 'quiet': True})
    assert fd.params == {'noprogress': True, 'quiet': True}
    assert fd.ydl is ydl
    assert fd.IE_NAME == 'test'
    assert fd.FD_NAME == 'test'
    assert fd.progress_hooks == []
    assert fd.report_warning == ydl.report_warning
    assert fd.report_error == y

# Generated at 2022-06-18 13:25:23.798099
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.extractors = gen_extractors()
            self.extractors_by_id = dict((e.IE_NAME, e) for e in self.extractors)
            self.params['extractors'] = self.extractors_by_id.keys()
            self.params['extractor_filter'] = match_filter_func(self.params['extractors'])



# Generated at 2022-06-18 13:25:36.129654
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    # Test that HttpQuietDownloader is initialized with the same parameters as
    # the parent class
    def test_HttpQuietDownloader_init(self):
        assert self.ydl is not None
        assert self.params == {
            'continuedl': True,
            'quiet': True,
            'noprogress': True,
            'ratelimit': None,
            'retries': 0,
            'nopart': False,
            'test': False,
        }

    def test_HttpQuietDownloader_to_screen(self, *args, **kargs):
        pass

    HttpQuietDownloader.__init__ = test_HttpQuiet

# Generated at 2022-06-18 13:25:44.465981
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test_fragments')
    ie.extract('test_fragments')
    ie.extract('test_fragments_live')

    fd = TestFD(ie._downloader, ie.result)
    fd.download('test_fragments')
    fd.download('test_fragments_live')

# Generated at 2022-06-18 13:25:53.605298
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'ratelimit': None,
                'retries': 0,
                'nopart': False,
                'test': False,
            }
            self.cache = None
            self.to_screen = lambda *args, **kargs: None

# Generated at 2022-06-18 13:26:03.069277
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_downloader(downloader):
        assert isinstance(downloader, HttpQuietDownloader)
        assert downloader.params['quiet']
        assert downloader.params['noprogress']
        assert downloader.params['continuedl']

    def _test_extractor(extractor):
        assert isinstance(extractor, type)
        assert issubclass(extractor, FragmentFD)
        assert hasattr(extractor, '_download_fragment')
        assert hasattr(extractor, '_prepare_frag_download')
        assert hasattr(extractor, '_start_frag_download')
        assert hasattr(extractor, '_finish_frag_download')
        assert has

# Generated at 2022-06-18 13:26:11.745206
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_downloader(ydl, url, expected_filename, expected_status, expected_total_bytes, expected_downloaded_bytes, expected_fragment_index, expected_fragment_count):
        class TestFD(FragmentFD):
            def __init__(self, ydl, params):
                super(TestFD, self).__init__(ydl, params)
                self.expected_filename = expected_filename
                self.expected_status = expected_status
                self.expected_total_bytes = expected_total_bytes
                self.expected_downloaded_bytes = expected_downloaded_bytes
                self.expected_fragment_index = expected_fragment_index

# Generated at 2022-06-18 13:27:53.152804
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:27:59.691362
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_func(info_dict):
        return info_dict['extractor'] == 'youtube'

    ydl = HttpQuietDownloader(gen_extractors(), {
        'match_filter': match_filter_func(test_func),
    })
    assert isinstance(ydl, HttpFD)

# Generated at 2022-06-18 13:28:04.057557
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    ydl = gen_extractors()[0]
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.params['quiet']

# Generated at 2022-06-18 13:28:08.277812
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:28:19.249430
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class DummyIE(object):
        def __init__(self, downloader, ie_name):
            self.downloader = downloader
            self.ie_name = ie_name

    class DummyYDL(object):
        def __init__(self):
            self.params = {}

    ie = DummyIE(DummyYDL(), 'dummy')
    fd = FragmentFD(ie, {'url': 'http://example.com/video.f4m'}, 'video.f4m')
    assert fd.FD_NAME == 'dummy'
    assert fd.ydl is ie.downloader
    assert fd.params is ie.downloader.params
    assert fd.url == 'http://example.com/video.f4m'


# Generated at 2022-06-18 13:28:30.074700
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urlparse

    def test_fragment_downloader(url, expected_frag_count):
        def test_hook(status):
            if status['status'] == 'finished':
                assert status['fragment_count'] == expected_frag_count
        ydl = FileDownloader({
            'noprogress': True,
            'logger': FakeLogger(),
            'progress_hooks': [test_hook],
        })
        match_filter = match_filter_func(ydl.params)
        for ie in gen_extractors():
            if not ie.suitable(url) or not ie.IE_NAME in match_filter:
                continue
            ie = ie.ie


# Generated at 2022-06-18 13:28:38.692872
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    # Test that all extractors that support fragmented media are subclasses of
    # FragmentFD
    for ie in gen_extractors():
        if ie.IE_NAME == 'generic':
            continue
        if not match_filter_func(ie.IE_NAME)(ie):
            continue
        if ie.is_suitable(ie.url_result('http://example.com')):
            assert issubclass(ie.__class__, FragmentFD), (
                '%s is not a subclass of FragmentFD' % ie.IE_NAME)

# Generated at 2022-06-18 13:28:49.376777
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    import sys
    from .extractor import gen_extractors
    from .downloader.http import HttpFD
    from .downloader.rtmp import RtmpFD
    from .downloader.dash import DashFD
    from .downloader.hls import HlsFD
    from .downloader.hls import HlsNativeFD
    from .downloader.external import ExternalFD
    from .downloader.f4m import F4mFD
    from .downloader.ism import IsmFD
    from .downloader.fragment import FragmentFD
    from .downloader.http import HttpQuietDownloader
    from .downloader.rtmp import RtmpQuietDownloader
    from .downloader.dash import DashQuietDownloader
    from .downloader.hls import HlsQuietDownloader

# Generated at 2022-06-18 13:28:53.107151
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    ydl = gen_extractors()['youtube']
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.params['quiet']

# Generated at 2022-06-18 13:28:59.390158
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .downloader import gen_downloader_classes
    from .common import FileDownloader
    from .http import HttpFD

    # Generate all extractor and downloader classes
    gen_extractor_classes()
    gen_downloader_classes()

    # Test if HttpQuietDownloader is a subclass of HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

    # Test if HttpQuietDownloader is a subclass of FileDownloader
    assert issubclass(HttpQuietDownloader, FileDownloader)