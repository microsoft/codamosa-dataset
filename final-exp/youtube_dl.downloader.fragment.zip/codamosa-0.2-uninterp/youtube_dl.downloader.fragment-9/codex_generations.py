

# Generated at 2022-06-18 13:20:06.813673
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_str

    gen_extractors()
    ydl = FileDownloader({
        'quiet': True,
        'noprogress': True,
        'matchfilter': match_filter_func('all'),
    })
    dl = HttpQuietDownloader(ydl, {})
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert dl.params['matchfilter'].name == 'all'
    assert dl.ydl is ydl
    assert dl.to_screen('test') is None
    assert dl.to_stderr('test') is None
    assert dl.to_console_title('test') is None
   

# Generated at 2022-06-18 13:20:18.824934
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

        def _prepare_frag_download(self, ctx):
            ctx.update({
                'total_frags': 10,
                'ad_frags': 2,
                'live': False,
            })
            FragmentFD._prepare_frag_download(self, ctx)

        def _start_frag_download(self, ctx):
            return FragmentFD._start_frag_download(self, ctx)

        def _finish_frag_download(self, ctx):
            FragmentFD._finish_frag_download

# Generated at 2022-06-18 13:20:30.963110
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp


# Generated at 2022-06-18 13:20:41.946406
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    ydl = FileDownloader({})
    ydl.add_info_extractor(gen_extractors())
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    ydl.params['forcejson'] = True
    ydl.params['simulate'] = True
    ydl.params['match_filter'] = match_filter_func('is_live:true')
    ydl.params['outtmpl'] = '%(id)s'
    ydl.params['writesubtitles'] = True
    ydl.params['writeautomaticsub'] = True
    ydl.params['allsubtitles'] = True
    ydl.params['subtitleslangs']

# Generated at 2022-06-18 13:20:47.841214
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)
    assert FragmentFD.__name__ == 'FragmentFD'
    assert FragmentFD.__module__ == 'youtube_dl.downloader.fragment'
    assert FragmentFD.FD_NAME == 'fragment'

# Generated at 2022-06-18 13:20:50.960088
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..utils import FakeYDL
    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {})
    assert dl.ydl is ydl
    assert dl.params == {}

# Generated at 2022-06-18 13:21:01.647679
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'formats': [{
                    'url': 'http://example.com/',
                    'format_id': 'test',
                }],
            }

    ie = TestIE(gen_extractor({'outtmpl': '%(id)s%(ext)s'}))
    ie.add_info_extractor(TestIE)
    ie.extract('http://example.com/')

# Generated at 2022-06-18 13:21:15.084901
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..downloader.external import ExternalFD
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }
            self.cache = None
            self.extractor_desc = {}
            self.extractors = gen_extractors()
            self.postprocessors = []
            self.progress_hooks = []

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:21:26.466358
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    ydl = FileDownloader({
        'noprogress': True,
        'quiet': True,
        'format': 'best',
        'outtmpl': '%(id)s.%(ext)s',
        'ignoreerrors': True,
        'matchfilter': match_filter_func('all'),
        'test': True,
    })
    ydl.add_info_extractor(gen_extractors())
    ydl.add_default_info_extractors()
    ydl.download(['http://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-18 13:21:37.422886
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'fake',
                'title': 'fake',
                'formats': [{
                    'url': 'http://example.com/video.mp4',
                    'format_id': 'mp4',
                }],
            }

    ie = FakeInfoExtractor()
    gen_extractors()
    ie.add_info_extractor(FakeInfoExtractor)

    def test_filter(ie_name, ie):
        return ie_name

# Generated at 2022-06-18 13:22:10.697285
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import get_info_extractor

    class FakeYDL:
        params = {}

        def __init__(self):
            self.to_screen = sys.stdout.write
            self.to_stderr = sys.stderr.write

        def report_warning(self, msg):
            self.to_stderr('WARNING: ' + msg + '\n')

        def report_error(self, msg, tb=None):
            self.to_stderr('ERROR: ' + msg + '\n')

        def trouble(self, msg, tb=None):
            self.report_error(msg, tb)
            sys.exit(1)

    class FakeIE(object):
        def __init__(self, ydl, ie_name):
            self.yd

# Generated at 2022-06-18 13:22:24.045267
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.common import FileDownloader
    from .utils import get_cachedir

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?example\.com/video\.mp4'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    class TestPP(object):
        def __init__(self, downloader=None):
            pass

        def run(self, info):
            return [info]

    gen_extractors

# Generated at 2022-06-18 13:22:35.018858
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_urllib_request
    from ..extractor import get_info_extractor

    def _test_downloader(ie, downloader, expected_result):
        info = {
            'id': 'test',
            'extractor': ie.IE_NAME,
            'title': 'test',
            'url': 'http://localhost/',
        }
        result = downloader.suitable(info)
        assert result == expected_result, '%s != %s: %s' % (result, expected_result, info)

    def _test_http_downloader(ie, downloader, expected_result):
        _test_downloader(ie, downloader, expected_result)
        if expected_result:
            assert isinstance(downloader, HttpQuietDownloader)


# Generated at 2022-06-18 13:22:47.221354
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .post import PostProcessor
    from .downloader.external import ExternalFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.http import HttpFD
    from .downloader.rtmp import RtmpFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.dash import DashManifestFD
    from .downloader.dash import DashFD
    from .downloader.ism import IsmFD
    from .downloader.fragment import FragmentFD
    from .downloader.common import FileDownloader
    from .downloader.http import HttpQuietDownloader


# Generated at 2022-06-18 13:22:59.208761
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test')
    ie.extract = lambda url: {
        '_type': 'url',
        'url': url,
        'ie_key': 'Test',
        'title': 'test',
        'id': 'test',
        'formats': [{
            'format_id': 'test',
            'url': url,
        }],
    }


# Generated at 2022-06-18 13:23:08.606378
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    import sys
    import tempfile

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        IE_DESC = 'Dummy IE'
        _VALID_URL = r'(?:foo)'

        def _real_extract(self, url):
            return {
                'id': 'dummy',
                'url': 'http://example.com/dummy.mp4',
                'title': 'Dummy',
            }

    def _run_test(params, expected_result):
        ie = DummyIE(DummyIE.create_ie())
        tmp_filename = tempfile.mktemp()

# Generated at 2022-06-18 13:23:21.014790
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(object):
        def __init__(self, url):
            self.url = url


# Generated at 2022-06-18 13:23:31.226181
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    ie.add_info_extractor(TestIE)
    ie.add_default_info_extractors()

    def test_downloader(ydl, params):
        return HttpQuietDownloader(ydl, params)


# Generated at 2022-06-18 13:23:43.663267
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_constructor(extractor_class):
        if not issubclass(extractor_class, FragmentFD):
            return
        if extractor_class is FragmentFD:
            return
        if extractor_class.__name__ in ('M3U8FD', 'F4MFD'):
            return
        if extractor_class.IE_NAME == 'generic':
            return
        if extractor_class.IE_NAME == 'googledrive':
            return
        if extractor_class.IE_NAME == 'googlesearch':
            return
        if extractor_class.IE_NAME == 'crunchyroll':
            return
        if extractor_class.IE_NAME == 'vk':
            return

# Generated at 2022-06-18 13:23:48.244971
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return info_dict.get('extractor_key') == 'HttpQuietDownloader'

    gen_extractors(test_filter)
    assert match_filter_func(test_filter)({'extractor_key': 'HttpQuietDownloader'})

# Generated at 2022-06-18 13:24:47.277252
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
                'simulate': True,
                'format': 'best',
            }
            self.cache = None
            self.extractor_desc = []
            self.extractors = gen_extractors()
            self.IE_NAME = 'youtube'
            self.IE_DESC = 'Test IE'
            self.add_info_extractor(self.IE_NAME, self.IE_DESC)
            self.add_default_info_extractors

# Generated at 2022-06-18 13:24:56.785490
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..downloader.external import ExternalFD
    from ..downloader.http import HttpFD
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hlsnative import HlsFD as HlsNativeFD
    from ..downloader.dashnative import DashSegmentsFD as DashNativeFD

    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(ExternalFD, FragmentFD)
    assert issubclass(HttpFD, FragmentFD)
    assert issubclass(F4mFD, FragmentFD)
    assert issubclass(HlsFD, FragmentFD)

# Generated at 2022-06-18 13:25:08.527172
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_urllib_request
    from ..utils import encode_data_uri

    class MockYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': MockLogger(),
            }

    class MockLogger(object):
        def debug(self, msg):
            pass

    ydl = MockYDL()
    dl = HttpQuietDownloader(ydl, {'quiet': True})
    assert dl.ydl is ydl
    assert dl.params['quiet']
    assert dl.params['noprogress']
    assert dl.params['logger'] is ydl.params['logger']


# Generated at 2022-06-18 13:25:16.953612
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
            }
            self.extractor_desc = []
            self.info_extractors = gen_extractors()
            self.params['extractors'] = match_filter_func(self.info_extractors)
            self.params['extractor_descriptions'] = self.extractor_desc

    class FakeIE(InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'(?i)^https?://.*\.fake'

# Generated at 2022-06-18 13:25:29.618951
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?example\.com/video\.mp4'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test video',
                'ext': 'mp4',
            }

    ie = TestIE(gen_extractors())
    ie.add_info_extractor(TestIE)

    dl = HttpQuietDownloader(ie, {'quiet': True})
    dl.download('http://example.com/video.mp4')

# Generated at 2022-06-18 13:25:41.619698
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_downloader(info_dict):
        downloader = FragmentFD(gen_extractors(), {}, match_filter_func())
        downloader.report_warning = lambda msg: None
        downloader.report_destination = lambda filename: None
        downloader.to_screen = lambda msg: None
        downloader.download(info_dict)


# Generated at 2022-06-18 13:25:51.431013
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor
    from .extractor.common import InfoExtractor
    from .utils import ExtractorError

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'fake',
                'title': 'fake',
                'formats': [{
                    'url': 'http://example.com/video.mp4',
                    'format_id': 'mp4',
                }],
            }

    gen_extractor.register(FakeInfoExtractor)


# Generated at 2022-06-18 13:26:01.618898
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader
    from ..utils import match_filter_func

    def test_filter(ie, downloader, info_dict):
        return ie.IE_NAME == 'generic'

    extractors = gen_extractors()
    extractors.sort(key=lambda ie: ie.IE_NAME.lower())
    for ie in extractors:
        if not ie.working():
            continue
        if not ie.SUFFIX:
            continue
        if not match_filter_func(ie.IE_NAME, test_filter):
            continue
        fd = FileDownloader({
            'outtmpl': '%(id)s.%(ext)s',
            'quiet': True,
        }, ie, downloader=FragmentFD)
        f

# Generated at 2022-06-18 13:26:10.133736
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    def _test_frag_downloader(fd_name, ie_name, url, expected_frag_count):
        ie = get_info_extractor(ie_name)
        ie.extract(url)
        assert ie.get_info(url)['extractor'] == ie_name
        fd = FragmentFD(ie, {}, {'noprogress': True})
        assert fd.FD_NAME == fd_name
        ctx = {
            'filename': 'test.mp4',
            'total_frags': expected_frag_count,
        }
        fd._prepare_frag_download(ctx)
        fd._start_frag_download(ctx)

# Generated at 2022-06-18 13:26:15.147245
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .common import FileDownloader
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert issubclass(HttpQuietDownloader, FileDownloader)
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'
    assert HttpQuietDownloader.__module__ == __name__

if __name__ == '__main__':
    test_HttpQuietDownloader()

# Generated at 2022-06-18 13:28:08.821635
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            self.to_screen('This is a test downloader')
            return True

    ie = get_info_extractor('test_fragments')
    ie.add_info_extractor(TestFD)

    def test_download(url, params):
        ie = get_info_extractor(url)
        info = ie.extract(url)
        ie.download(info['entries'][0])

    test_download('test_fragments', {'format': 'test'})

# Generated at 2022-06-18 13:28:19.627211
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie):
        if ie.IE_NAME == 'generic':
            return
        if ie.IE_NAME in ('youtube', 'youtube:playlist', 'youtube:search', 'youtube:channel', 'youtube:user', 'youtube:uservideo'):
            return
        if ie.IE_NAME in ('crunchyroll', 'crunchyroll:base'):
            return
        if ie.IE_NAME in ('soundcloud', 'soundcloud:set', 'soundcloud:user', 'soundcloud:favorites', 'soundcloud:search'):
            return
        if ie.IE_NAME in ('bandcamp', 'bandcamp:album', 'bandcamp:track'):
            return

# Generated at 2022-06-18 13:28:30.678460
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, *args):
            return True

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            pass

    ie = FakeInfoExtractor(None)
    ie.add_info_extractor(FakeInfoExtractor)
    ie.add_info_extractor(FakeInfoExtractor)
    ie.add_info_extractor(FakeInfoExtractor)
    ie.add_info_extractor(FakeInfoExtractor)
    ie.add_info_extractor

# Generated at 2022-06-18 13:28:40.906481
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader.http import HttpFD

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

    class FakeInfoDict(object):
        pass

    def test_http_downloader(url, params):
        ydl = FakeYDL()
        ydl.params.update(params)
        info_dict = FakeInfoDict()

# Generated at 2022-06-18 13:28:43.077087
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:28:53.867736
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .postprocessor.common import PostProcessor
    from .downloader.http import HttpFD
    from .downloader.rtmp import RtmpFD
    from .downloader.external import ExternalFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.fragment import FragmentFD

    ydl = object()

# Generated at 2022-06-18 13:29:01.144389
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        _VALID_URL = r'(?i)^https?://.+'
        _TEST = {
            'url': 'http://example.com/',
            'info_dict': {
                'id': 'dummy',
                'ext': 'mp4',
                'title': 'dummy',
            },
        }

    ie = DummyIE(DummyIE._downloader)
    ie.add_info_extractor(DummyIE)
    ie.add_info_extractor(DummyIE)
    ie.add_info_extractor(DummyIE)
   

# Generated at 2022-06-18 13:29:07.653068
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.extractor = get_info_extractor('TestIE', ydl)

    fd = TestFD(None, {})
    assert fd.FD_NAME == 'test'
    assert fd.extractor.IE_NAME == 'TestIE'

# Generated at 2022-06-18 13:29:17.668147
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    gen_extractors()
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'formats': [{
                    'url': 'http://example.com/test.mp4',
                    'format_id': 'test',
                    'ext': 'mp4',
                }],
            }

    ie = TestIE(downloader=FragmentFD())

# Generated at 2022-06-18 13:29:27.358410
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_downloader(ydl, info_dict):
        fd = FragmentFD(ydl, info_dict)
        assert fd.params['retries'] == 0
        assert fd.params['nopart'] is False
        assert fd.params['test'] is False
        assert fd.params['keep_fragments'] is False
        assert fd.params['skip_unavailable_fragments'] is False
        assert fd.params['ratelimit'] is None
