

# Generated at 2022-06-18 13:20:03.740267
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from . import YoutubeDL
    ydl = YoutubeDL()
    fd = FragmentFD(ydl)
    assert fd.params == {
        'continuedl': True,
        'noprogress': True,
        'quiet': True,
        'nopart': False,
        'test': False,
    }
    assert fd.ydl is ydl

# Generated at 2022-06-18 13:20:16.002007
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .extractor.common import InfoExtractor

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params

    class FakeExtractor(InfoExtractor):
        IE_NAME = 'Fake'
        IE_DESC = 'Fake Extractor'
        _VALID_URL = r'(?i)^https?://.*\.fake$'

        def _real_extract(self, url):
            return {
                'id': 'fakeid',
                'title': 'faketitle',
                'ext': 'fakeext',
                'url': url,
                'http_headers': {'Fake-Header': 'fake-header-value'},
            }

    gen_extractor_classes(FakeExtractor)
    y

# Generated at 2022-06-18 13:20:24.198136
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .compat import compat_urllib_request
    from .utils import sanitize_open

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'title': 'test',
                'formats': [{
                    'url': 'http://127.0.0.1:8080/manifest.mpd',
                    'format_id': 'test',
                }],
            }


# Generated at 2022-06-18 13:20:37.069250
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader.http import HttpFD
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.ism import IsmFD

    # Test that FragmentFD is a base class for all fragment downloaders
    assert issubclass(F4mFD, FragmentFD)
    assert issubclass(HlsFD, FragmentFD)
    assert issubclass(DashSegmentsFD, FragmentFD)
    assert issubclass(IsmFD, FragmentFD)

    # Test that FragmentFD is not a base class for HttpFD


# Generated at 2022-06-18 13:20:45.420281
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_downloader(ydl, info_dict):
        dl = HttpQuietDownloader(ydl, info_dict)
        assert dl.ydl is ydl
        assert dl.params == info_dict
        assert dl.to_screen == ydl.to_screen
        assert dl.to_stderr == ydl.to_stderr
        assert dl.report_warning == ydl.report_warning
        assert dl.report_error == ydl.report_error
        assert dl.report_info == ydl.report_info

    ydl = gen_extractors(match_filter_func('youtube'))[0]().ydl

# Generated at 2022-06-18 13:20:54.762065
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class MockInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            pass

    ie = MockInfoExtractor({})
    ie.add_info_extractor(MockInfoExtractor.ie_key())
    ie.add_info_extractor(MockInfoExtractor.ie_key())
    ie.add_info_extractor(MockInfoExtractor.ie_key())
    ie.add_info_extractor(MockInfoExtractor.ie_key())
    ie.add_info_extractor(MockInfoExtractor.ie_key())
    ie.add_info_extractor(MockInfoExtractor.ie_key())


# Generated at 2022-06-18 13:21:06.434240
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from .common import FileDownloader
    from .http import HttpFD
    from .dash import DASHFD
    from .hls import HLSFD
    from .hlsnative import HLSFD as HLSNativeFD
    from .fragment import FragmentFD

    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)
    assert not issubclass(FragmentFD, DASHFD)
    assert not issubclass(FragmentFD, HLSFD)
    assert not issubclass(FragmentFD, HLSNativeFD)

    assert FragmentFD.__name__ == 'FragmentFD'
    assert FragmentFD.__doc__ == FragmentFD.__init

# Generated at 2022-06-18 13:21:20.222942
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

    ie = get_info_extractor('test')
    ie.add_info_extractor(
        'test',
        [
            {
                'url': 'http://localhost/',
                'playlist': [
                    'http://localhost/1',
                    'http://localhost/2',
                ],
                'playlist_count': 2,
            },
        ],
        ie_key='test')

# Generated at 2022-06-18 13:21:32.661894
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'(?i)^https?://.*\.fake'

        def _real_extract(self, url):
            return {
                'id': 'fakeid',
                'title': 'faketitle',
                'ext': 'fakeext',
                'url': url,
                'upload_date': '20120101',
                'uploader': 'fakeuploader',
                'uploader_id': 'fakeuploaderid',
                'age_limit': 0,
            }

    ie = FakeInfoExtractor()

# Generated at 2022-06-18 13:21:41.129218
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    # Test that HttpQuietDownloader doesn't print anything
    # when downloading a file
    def test_filter(ie, name):
        return ie.IE_NAME == 'generic' and name == 'http'

    def test_hook(d):
        if d['status'] == 'finished':
            raise Exception('HttpQuietDownloader printed something')

    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'quiet': True,
        'format': 'best',
        'logger': FileDownloader.std_logger,
        'progress_hooks': [test_hook],
    })
    ydl.add_info_ext

# Generated at 2022-06-18 13:22:22.707871
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class MockInfoExtractor(object):
        IE_NAME = 'Mock'
        IE_DESC = 'Mock IE'
        _VALID_URL = r'(?:mock)?(?P<url>.*)'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, url):
            return True


# Generated at 2022-06-18 13:22:28.892783
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test_ie')
    ie.add_info_extractor(TestFD)
    ie.extract('test_url')

# Generated at 2022-06-18 13:22:37.692324
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(object):
        IE_NAME = 'test_ie'
        IE_DESC = 'Test IE'
        _VALID_URL = r'(?:foo)'

        def __init__(self, downloader=None):
            self._downloader = downloader

        def _real_initialize(self):
            pass


# Generated at 2022-06-18 13:22:49.725292
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    ie = get_info_extractor('youtube')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc', download=False)
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc', download=True)
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc', download=True,
               force_generic_extractor=True)

# Generated at 2022-06-18 13:23:01.677199
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL:
        params = {}

        def __init__(self):
            self.extractors = gen_extractors()
            self.params = {}

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def report_destination(self, *args, **kargs):
            pass

        def temp_name(self, *args, **kargs):
            return '-'


# Generated at 2022-06-18 13:23:08.841768
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _get_extractor(url):
        for ie in gen_extractors():
            if match_filter_func(ie)(url):
                return ie
        return None

    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    ie = _get_extractor(url)
    info = ie.extract(url)
    dl = HttpQuietDownloader(ie, {'quiet': True, 'noprogress': True})
    dl.download(info['id'], info)

# Generated at 2022-06-18 13:23:21.288683
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_frag_downloader(fd_name, url, expected_extractor_name):
        extractors = gen_extractors()
        extractor = match_filter_func(extractors, lambda e: e.IE_NAME == fd_name)
        assert extractor is not None
        info_dict = extractor()._real_extract(url)
        assert info_dict['extractor'] == expected_extractor_name
        fd = FragmentFD(None, {}, info_dict)
        assert fd.FD_NAME == fd_name

    _test_frag_downloader('hlsnative', 'http://example.com/hls.m3u8', 'hlsnative')
    _test

# Generated at 2022-06-18 13:23:23.639980
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:23:32.837179
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import prepend_extractor
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

    class FakeInfoDict(object):
        pass

    class FakeExtractor(object):
        IE_NAME = 'Fake'

        def __init__(self):
            self._downloader = None

        @staticmethod
        def suitable(url):
            return True


# Generated at 2022-06-18 13:23:45.685317
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def _test_frag_downloader(ie, url, expected_frag_count, expected_ad_frag_count):
        ydl = FakeYDL()
        ie = get_info_extractor(ie)
        ie.extract(ydl, url)
        assert ydl.downloaded_info_dicts[0]['fragment_count'] == expected_frag_count
        assert ydl.downloaded_info_dicts[0]['ad_frag_count'] == expected_ad_frag_count

    # Test DASH

# Generated at 2022-06-18 13:24:29.223621
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.cache = None
            self.progress_hooks = []

        def add_progress_hook(self, hook):
            self.progress_hooks.append(hook)

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def report_destination(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:24:35.012595
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test_ie')
    ie.add_info_extractor(TestFD)
    ie.extract('test')

# Generated at 2022-06-18 13:24:47.224450
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }
            self.cache = None

        def to_screen(self, *args, **kargs):
            pass

    class FakeLogger(object):
        def debug(self, *args):
            pass


# Generated at 2022-06-18 13:24:55.334990
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    # pylint: disable=W0212
    fd = FragmentFD(None, {'noprogress': True})
    assert fd._prepare_url({'http_headers': {'foo': 'bar'}}, 'http://example.com/') == sanitized_Request('http://example.com/', None, {'foo': 'bar'})
    assert fd._prepare_url({}, 'http://example.com/') == 'http://example.com/'
    assert fd._prepare_url({'http_headers': {}}, 'http://example.com/') == 'http://example.com/'
    assert fd._prepare_url({'http_headers': None}, 'http://example.com/') == 'http://example.com/'

# Generated at 2022-06-18 13:25:07.590105
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    import sys
    from .extractor import gen_extractors
    from .utils import DateRange

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': self,
            }
            self.cache = None
            self.extractors = gen_extractors()
            self.extractor_descriptions = {}
            for ie in self.extractors:
                self.extractor_descriptions[ie.IE_NAME] = ie.IE_DESC


# Generated at 2022-06-18 13:25:08.994442
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:25:17.362433
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return match_filter_func(info_dict, {'protocol': 'http'})

    extractors = gen_extractors()
    extractors = [e for e in extractors if test_filter(e.IE_NAME)]
    for e in extractors:
        if e.IE_NAME == 'generic':
            continue
        if e.IE_NAME in ('youtube:playlist', 'youtube:search', 'youtube:channel', 'youtube:user'):
            continue
        if e.IE_NAME in ('soundcloud:set', 'soundcloud:user', 'soundcloud:search'):
            continue

# Generated at 2022-06-18 13:25:30.052856
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @classmethod
        def suitable(cls, url):
            return True

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'formats': [
                    {'format_id': 'test', 'url': url},
                ],
            }

    class FakeYDL(object):
        params = {}
        params['writedescription'] = False
        params['writeinfojson'] = False
       

# Generated at 2022-06-18 13:25:38.954482
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..utils import FakeYDL
    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {'continuedl': True})
    assert dl.ydl is ydl
    assert dl.params['continuedl'] is True
    assert dl.params['quiet'] is True
    assert dl.params['noprogress'] is True
    assert dl.params['ratelimit'] is None
    assert dl.params['retries'] == 0
    assert dl.params['nopart'] is False
    assert dl.params['test'] is False

# Generated at 2022-06-18 13:25:49.753568
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_frag_downloader(info_dict):
        class TestFD(FragmentFD):
            FD_NAME = info_dict['extractor_key']
            def real_download(self, filename, info_dict):
                return True
        return TestFD(gen_extractors(), {'outtmpl': '%(id)s.%(ext)s'})

    for ie in gen_extractors():
        if ie.IE_NAME in ('generic', 'googledrive'):
            continue
        if not match_filter_func(ie.IE_NAME)({'extractor': ie.IE_NAME}):
            continue

# Generated at 2022-06-18 13:26:50.332303
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return info_dict['id'] == 'test'

    class TestFD(FragmentFD):
        FD_NAME = 'test'
        def real_download(self, filename, info_dict):
            return True

    fd = TestFD(gen_extractors(), {'match_filter': match_filter_func(test_filter)})
    assert fd.params['match_filter'] == test_filter

# Generated at 2022-06-18 13:26:53.600369
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'
    assert HttpQuietDownloader.__module__ == 'youtube_dl.downloader.fragment'

# Generated at 2022-06-18 13:26:58.652448
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor.common import InfoExtractor
    from .utils import DateRange
    from .compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'Fake'
        IE_DESC = False  # Do not list
        _VALID_URL = r'(?i)^https?://.*\.f4m$'


# Generated at 2022-06-18 13:27:05.041655
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    gen_extractors()
    from ..extractor import list_extractors
    from ..downloader.external import ExternalFD

    def test_downloader(ydl, params):
        return HttpQuietDownloader(ydl, params)

    def test_external_downloader(ydl, params):
        return ExternalFD(ydl, params)

    for ie in list_extractors():
        if ie.IE_NAME == 'generic':
            continue
        if ie.IE_NAME in ('googledrive', 'googlesheets'):
            continue
        if ie.IE_NAME in ('youtube:playlist', 'youtube:channel', 'youtube:user', 'youtube:search'):
            continue

# Generated at 2022-06-18 13:27:13.673702
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_func(info_dict):
        return info_dict['extractor'] == 'youtube'

    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'match_filter': match_filter_func(test_func),
    })
    ydl.add_info_extractor(gen_extractors())
    ydl.add_info_extractor(gen_extractors(u'youtube:generic'))
    ydl.add_info_extractor(gen_extractors(u'youtube:playlist'))
    ydl.add_info_extractor(gen_extractors(u'youtube:search'))

# Generated at 2022-06-18 13:27:16.120836
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:27:21.713551
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_filter(info_dict):
        return match_filter_func(info_dict, {'protocol': 'http'})

    def test_downloader(info_dict):
        return FragmentFD(gen_extractors(), test_filter, {}, info_dict)

    from .test_downloader import test_downloader
    test_downloader(test_downloader)

# Generated at 2022-06-18 13:27:23.397299
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:27:28.097690
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert HttpQuietDownloader.__name__ == 'HttpQuietDownloader'
    assert HttpQuietDownloader.__module__ == 'youtube_dl.downloader.fragment'

# Generated at 2022-06-18 13:27:37.147597
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .compat import compat_str

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': FakeLogger(),
            }

    class FakeLogger(object):
        def debug(self, msg):
            pass

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'fake'
        IE_DESC = 'fake ie'


# Generated at 2022-06-18 13:28:58.311315
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def test_downloader(ydl, url, expected_filename, expected_status, expected_count):
        class MyHttpQuietDownloader(HttpQuietDownloader):
            def __init__(self, ydl, params):
                super(MyHttpQuietDownloader, self).__init__(ydl, params)
                self.count = 0

            def to_screen(self, *args, **kargs):
                self.count += 1

        dl = MyHttpQuietDownloader(ydl, {'quiet': True})
        info = {'url': url}
        dl.download(expected_filename, info)
        assert info['status'] == expected_status


# Generated at 2022-06-18 13:29:08.818080
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
                'simulate': True,
            }
            self.extractor_descriptions = gen_extractors()
            self.params['extractors'] = match_filter_func(self.extractor_descriptions)

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:29:15.856025
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp

    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'noprogress': True,
        'quiet': True,
        'logger': False,
        'progress_hooks': [],
        'extractors': gen_extractors(),
        'postprocessors': gen_pp(),
    })
    dl = HttpQuietDownloader(ydl, {'continuedl': True})
    assert dl.params['continuedl']

# Generated at 2022-06-18 13:29:26.383289
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def test_frag_download(ie, url, expected_frag_count, expected_frag_retries, expected_frag_skip):
        ie = get_info_extractor(ie)()
        ie.params = {
            'fragment_retries': expected_frag_retries,
            'skip_unavailable_fragments': expected_frag_skip,
        }
        info = ie.extract(url)
        assert info['_type'] == 'fragment'
        assert info['fragment_count'] == expected_frag_count
        assert info['fragment_retries'] == expected_frag_retries
        assert info['fragment_skip'] == expected_frag

# Generated at 2022-06-18 13:29:33.508191
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.ie = get_info_extractor(ydl, 'test')
            self.ie.params = params

        def real_download(self, filename, info_dict):
            self.ie.download(info_dict)
            return True


# Generated at 2022-06-18 13:29:40.108192
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from .http import HttpFD
    from .fragment import FragmentFD

    class TestFD(FragmentFD):
        FD_NAME = 'test'

    ydl = {}
    ydl.update(gen_extractors())