

# Generated at 2022-06-18 13:20:08.329374
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'(?i)^https?://.*\.test$'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(gen_extractors())
    dl = HttpQuietDownloader(ie, {'quiet': True})
    dl.add_info_extractor(ie)
    dl.add_default_info_extractors()
    dl.add_info_extractor(TestIE)


# Generated at 2022-06-18 13:20:11.857600
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)

# Generated at 2022-06-18 13:20:22.214648
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

    ie = get_info_extractor('test')
    ie.add_info_extractor(
        'test', [{
            'url': 'http://example.com/video.mp4',
            'fragment_base_url': 'http://example.com/video-fragment-%d.ts',
            'fragments': [1, 2, 3],
        }], ie_key='test')

    fd = TestFD(ie)
    fd.params['noprogress'] = True
    fd.params['outtmpl'] = '%(id)s'
    fd.params['quiet'] = True
    fd.params['nopart'] = True

# Generated at 2022-06-18 13:20:35.415710
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_frag_downloader(ydl, info_dict):
        fd = FragmentFD(ydl, info_dict)
        assert fd.params.get('fragment_retries', 0) == 0
        assert fd.params.get('skip_unavailable_fragments', False) is False
        assert fd.params.get('keep_fragments', False) is False

    def test_frag_downloader_with_params(ydl, info_dict):
        fd = FragmentFD(ydl, info_dict, {
            'fragment_retries': 10,
            'skip_unavailable_fragments': True,
            'keep_fragments': True,
        })

# Generated at 2022-06-18 13:20:44.275327
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_fragment_fd(url, expected_extractor_key):
        extractors = gen_extractors()
        for ie in extractors:
            if match_filter_func(ie)(url):
                assert ie.IE_NAME == expected_extractor_key
                return
        assert False, 'Extractor not found'

    test_fragment_fd('http://example.com/video.f4m', 'generic_f4m')
    test_fragment_fd('http://example.com/video.m3u8', 'hlsnative')
    test_fragment_fd('http://example.com/video.mpd', 'dash')

# Generated at 2022-06-18 13:20:53.188777
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractor_classes
    from .common import InfoExtractor

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?example\.com/video\.mp4'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'Test video',
            }

    ie = TestIE()
    ie.add_info_extractor(gen_extractor_classes())
    ie.extract('http://example.com/video.mp4')

# Generated at 2022-06-18 13:21:04.615821
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_frag_downloader(extractor_name, url, expected_filename, expected_info_dict):
        extractors = gen_extractors()
        extractor = next(e for e in extractors if e.IE_NAME == extractor_name)
        info_dict = extractor._real_extract(url)
        assert info_dict['id'] == expected_info_dict['id']
        assert info_dict['title'] == expected_info_dict['title']
        assert info_dict['ext'] == expected_info_dict['ext']
        assert info_dict['format'] == expected_info_dict['format']
        assert info_dict['duration'] == expected_info_dict['duration']

# Generated at 2022-06-18 13:21:18.108004
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = 'test'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'formats': [
                    {'format_id': 'f1', 'url': 'http://f1/f1.ts'},
                    {'format_id': 'f2', 'url': 'http://f2/f2.ts'},
                ],
            }


# Generated at 2022-06-18 13:21:30.956590
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp

    class FakeInfoDict(dict):
        def __init__(self):
            super(FakeInfoDict, self).__init__()
            self['extractor'] = 'fake'
            self['url'] = 'http://fakeurl/video.mp4'
            self['http_headers'] = {'User-Agent': 'FakeUserAgent'}
            self['fragment_base_url'] = 'http://fakeurl/'
            self['fragments'] = ['frag1.ts', 'frag2.ts']
            self['fragment_index'] = 0


# Generated at 2022-06-18 13:21:40.378716
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_func(info_dict):
        return info_dict['extractor_key'] == 'Youtube'

    ydl = FileDownloader({
        'outtmpl': '%(id)s',
        'quiet': True,
        'match_filter': match_filter_func(test_func),
    })
    ydl.add_info_extractor(gen_extractors())
    ydl.add_info_extractor(gen_extractors(u'generic'))
    ydl.add_info_extractor(gen_extractors(u'playlist'))
    ydl.add_info_extractor(gen_extractors(u'subtitles'))

    dl = HttpQuiet

# Generated at 2022-06-18 13:22:13.278747
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_downloader(ydl, info_dict):
        fd = FragmentFD(ydl, info_dict)
        assert fd.params.get('fragment_retries') == 10
        assert fd.params.get('skip_unavailable_fragments') is True
        assert fd.params.get('keep_fragments') is False

    for ie in gen_extractors():
        if match_filter_func(ie.IE_NAME, ['dash', 'hlsnative']):
            test_downloader(None, {'extractor': ie.IE_NAME})

# Generated at 2022-06-18 13:22:26.506165
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(object):
        def __init__(self, url):
            self.url = url

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'ratelimit': None,
                'retries': 0,
                'nopart': False,
                'test': False,
            }
            self.extractor_descriptions = gen_extractors()
            self.extractors = [
                x for x in self.extractor_descriptions
                if match_filter_func(x['ie_key'], ['generic'])(x)]


# Generated at 2022-06-18 13:22:32.449214
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from .common import FileDownloader
    from .http import HttpFD
    assert issubclass(FragmentFD, FileDownloader)
    assert issubclass(FragmentFD, HttpFD)
    assert FragmentFD.__name__ == 'FragmentFD'
    assert FragmentFD.__module__ == __name__

if __name__ == '__main__':
    test_FragmentFD()

# Generated at 2022-06-18 13:22:43.552705
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.extractor_desc = []
            self.extractors = gen_extractors()
            self.extractors_by_name = {}
            for ie in self.extractors:
                self.extractors_by_name[ie.IE_NAME] = ie
                self.extractor_desc.append((ie.IE_NAME, ie.IE_DESC))


# Generated at 2022-06-18 13:22:55.764931
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..compat import compat_urllib_request
    from ..utils import sanitize_open

    url = 'http://example.com/'
    req = compat_urllib_request.Request(url)
    req.add_header('Range', 'bytes=0-10')
    req.add_header('Accept-Encoding', 'gzip')
    req.add_header('User-Agent', 'Mozilla/5.0')
    req.add_header('Cookie', 'foo=bar')
    req.add_header('X-Forwarded-For', '127.0.0.1')
    req.add_header('Referer', 'http://example.com/referer')

# Generated at 2022-06-18 13:23:05.974968
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class TestFD(FragmentFD):
        def __init__(self, ydl, params):
            super(TestFD, self).__init__(ydl, params)
            self.ydl = ydl
            self.params = params

        def real_download(self, filename, info_dict):
            self.to_screen('[test] Downloading %s' % filename)
            return True

    ydl = get_info_extractor('youtube', {})
    ydl.add_info_extractor(get_info_extractor('youtube:playlist', ydl))
    ydl.add_info_extractor(get_info_extractor('youtube:channel', ydl))
    ydl.add_info_extractor

# Generated at 2022-06-18 13:23:12.064423
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        IE_DESC = 'Test IE'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?test\.com/video\.mp4'

        def _real_extract(self, url):
            raise ExtractorError('This is just a test', expected=True)

    ie = TestIE()
    ie.add_info_extractor(TestIE)

    fd = FragmentFD(ie, {'noprogress': True})
    fd.download({'url': 'http://test.com/video.mp4'})

# Generated at 2022-06-18 13:23:24.209541
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_fragment_fd(info_dict):
        fd = FragmentFD(
            {
                'noprogress': True,
                'quiet': True,
                'skip_download': True,
            },
            info_dict)
        fd.report_destination = lambda filename: None
        fd.to_screen = lambda *args, **kargs: None
        fd.download()

    for ie in gen_extractors():
        if not ie.is_suitable(None):
            continue
        if not ie.IE_NAME in ('dash', 'hlsnative'):
            continue

# Generated at 2022-06-18 13:23:33.216683
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    gen_extractors()
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .utils import match_filter_func

    class TestIE(InfoExtractor):
        IE_NAME = 'Test'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
            }

    ie = TestIE(HttpQuietDownloader())
    info = ie.extract('http://example.com/')
    assert info['url'] == 'http://example.com/'
    assert info['title'] == 'test'

    ie = TestIE(HttpFD())


# Generated at 2022-06-18 13:23:42.694036
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    class TestFD(FragmentFD):
        FD_NAME = 'test'

        def real_download(self, filename, info_dict):
            return True

    ie = get_info_extractor('test_fragments')
    info_dict = ie.extract('test_fragments')
    fd = TestFD(ie._downloader, ie.ydl, ie.params)
    fd.download(info_dict['url'], info_dict)

# Generated at 2022-06-18 13:24:31.649900
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    assert issubclass(HttpQuietDownloader, HttpFD)

# Generated at 2022-06-18 13:24:43.511946
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeYDL:
        def __init__(self):
            self.params = {}
            self.cache = None
            self.to_screen = lambda *args, **kargs: None

        def add_info_extractor(self, ie):
            self.ie = ie

        def add_default_info_extractors(self):
            pass

        def process_ie_result(self, *args, **kargs):
            return args[0]

        def to_screen(self, *args, **kargs):
            pass

    ydl = FakeYDL()
    ie = get_info_extractor('youtube')
    ydl.add_info_extractor(ie)

# Generated at 2022-06-18 13:24:49.666147
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..utils import FakeYDL
    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {'continuedl': True})
    assert dl.ydl is ydl
    assert dl.params['continuedl'] is True
    assert dl.params['quiet'] is True
    assert dl.params['noprogress'] is True

# Generated at 2022-06-18 13:25:01.669133
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import YoutubeIE
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader.http import HttpFD
    from ..downloader.common import FileDownloader

    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    ydl = YoutubeIE()
    ydl.add_info_extractor(YoutubeIE.ie_key())
    ydl.params['noplaylist'] = True
    ydl.params['quiet'] = True
    ydl.params['format'] = 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'

# Generated at 2022-06-18 13:25:11.896239
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie, url):
        ie = gen_extractors()[ie]()
        ie.extract(url)
        return ie

    def test_frag_download(ie, url, params):
        ie = test_extractor(ie, url)
        params = params.copy()
        params['quiet'] = True
        params['noprogress'] = True
        params['nopart'] = True
        params['retries'] = 0
        params['test'] = True
        params['outtmpl'] = '%(id)s.%(ext)s'
        params['writedescription'] = True
        params['writeinfojson'] = True
        params['writesubtitles'] = True


# Generated at 2022-06-18 13:25:23.532707
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_extractor(ie):
        if ie.IE_NAME == 'generic':
            return

# Generated at 2022-06-18 13:25:28.468764
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..utils import FakeYDL
    ydl = FakeYDL()
    dl = HttpQuietDownloader(ydl, {'continuedl': True})
    assert dl.params['continuedl']
    assert dl.params['quiet']
    assert dl.params['noprogress']

# Generated at 2022-06-18 13:25:40.516496
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from ..extractor import gen_extractors
    from ..postprocessor import gen_pp


# Generated at 2022-06-18 13:25:50.668069
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .utils import DateRange

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'logger': None,
            }
            self.extractors = gen_extractors()
            self.IE_NAME = 'youtube'
            self.IE_DESC = 'Test IE'
            self.ie = InfoExtractor(self.IE_NAME, self.IE_DESC)
            self.ie.extractor_key = 'Youtube'

    ydl = FakeYDL()
    hqd = HttpQuietDownloader(ydl, {'continuedl': True})
    assert hqd.params['continuedl']

# Generated at 2022-06-18 13:26:01.535809
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor

    def _test_FragmentFD(ie, url):
        ydl = FakeYDL()
        ydl.add_info_extractor(ie)
        ydl.params['noprogress'] = True
        ydl.params['quiet'] = True
        ydl.params['skip_download'] = True
        ydl.params['noplaylist'] = True
        ydl.params['format'] = 'best'
        ydl.params['outtmpl'] = '%(id)s'
        ydl.params['writedescription'] = True
        ydl.params['writeinfojson'] = True
        ydl.params['writethumbnail'] = True
        ydl.params['writeannotations'] = True

# Generated at 2022-06-18 13:27:47.093637
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL:
        params = {}

        def __init__(self):
            self.extractor = get_info_extractor('youtube')
            self.params = {}

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

        def report_destination(self, *args, **kargs):
            pass

        def temp_name(self, *args, **kargs):
            return '-'


# Generated at 2022-06-18 13:27:55.296320
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.cache = None
            self.to_screen = lambda *args, **kargs: None
            self.to_stderr = lambda *args, **kargs: None
            self.report_warning = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None
            self.report_file_already_downloaded = lambda *args, **kargs: None
            self.add_progress_hook = lambda *args, **kargs: None

        def download(self, *args, **kargs):
            return True

# Generated at 2022-06-18 13:28:08.006345
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import DateRange

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        _VALID_URL = r'(?:$)'
        _TESTS = []

        def __init__(self, downloader=None):
            self._downloader = downloader

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            pass

    ie = FakeInfoExtractor(downloader=FragmentFD())
    ie.add_info_extractor(get_info_extractor('youtube'))
    ie.add_info_extractor(get_info_extractor('generic'))
    ie.add_info_extractor(get_info_extractor('googledrive'))
    ie

# Generated at 2022-06-18 13:28:19.046427
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_postprocessors
    from .downloader.http import HttpFD
    from .downloader.rtmp import RtmpFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.dash import DashSegmentsFD
    from .downloader.external import ExternalFD
    from .downloader.fragment import FragmentFD

    # Test the constructor of HttpQuietDownloader
    # This test is not complete, but it is enough to detect some errors
    # in the constructor of HttpQuietDownloader
    ydl = object()

# Generated at 2022-06-18 13:28:29.708346
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            self.cache = None
            self.to_screen = lambda *args, **kargs: None

        def add_info_extractor(self, ie):
            self.ie = ie

        def add_default_info_extractors(self):
            pass

        def process_ie_result(self, *args, **kargs):
            return args[0]

        def to_stdout(self, s):
            pass

        def trouble(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:28:33.079860
# Unit test for constructor of class HttpQuietDownloader
def test_HttpQuietDownloader():
    from .http import HttpFD
    from .common import FileDownloader
    assert issubclass(HttpQuietDownloader, HttpFD)
    assert issubclass(HttpQuietDownloader, FileDownloader)

# Generated at 2022-06-18 13:28:43.370347
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'outtmpl': '%(id)s.%(ext)s',
                'nooverwrites': True,
                'continuedl': False,
                'quiet': False,
                'noprogress': False,
                'ratelimit': None,
                'retries': 10,
                'nopart': False,
                'test': False,
            }

# Generated at 2022-06-18 13:28:54.164109
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    def _test_frag_downloader(ie, url, expected_filenames, expected_frag_count,
                              expected_ad_frag_count, expected_total_frag_count,
                              expected_frag_retries, expected_skip_unavailable_fragments,
                              expected_keep_fragments):
        ie = get_info_extractor(ie)
        ie.extract(url)
        assert ie.get_info(url)['_type'] == 'fragment'
        assert ie.get_info(url)['extractor'] == ie.IE_NAME
        assert ie.get_info(url)['url'] == url

# Generated at 2022-06-18 13:29:01.285370
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @staticmethod
        def suitable(url):
            return True


# Generated at 2022-06-18 13:29:11.216681
# Unit test for constructor of class FragmentFD
def test_FragmentFD():
    from ..extractor import get_info_extractor
    from ..utils import match_filter_func

    class FakeInfoExtractor(object):
        IE_NAME = 'test'
        IE_DESC = 'test'

        def __init__(self, downloader=None):
            self._downloader = downloader

        @staticmethod
        def suitable(url):
            return True

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'formats': [{
                    'format_id': 'test',
                    'url': url,
                    'ext': 'mp4',
                }],
            }

    class FakeYDL(object):
        params = {}
        params['writedescription'] = False
        params