

# Generated at 2022-06-18 08:12:10.130151
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
                                      'error: failed to push some refs to \'https://github.com/user/repo.git\'\n'
                                      'hint: Updates were rejected because the tip of your current branch is behind\n'
                                      'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                      'hint: \'git pull ...\') before pushing again.\n'
                                      'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:12:19.187780
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To https://github.com/user/repo.git\n ! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/user/repo.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-18 08:12:28.607294
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/nvbn/thefuck\n ! [rejected] '
                         'master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'https://github.com/nvbn/thefuck\'\n'
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))

# Generated at 2022-06-18 08:12:38.917973
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] master -> master (non-fast-forward)\n'
                                               'error: failed to push some refs to \'https://github.com/user/repo.git\'\n'
                                               'hint: Updates were rejected because the tip of your current branch is behind\n'
                                               'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                               'hint: \'git pull ...\') before pushing again.\n'
                                               'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) == 'git pull && git push'

# Generated at 2022-06-18 08:12:48.643143
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To https://github.com/nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:12:58.520291
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:dsp9107/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))

# Generated at 2022-06-18 08:13:07.762651
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:mislav/dotfiles.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))

# Generated at 2022-06-18 08:13:17.179410
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:dummy/dummy.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))

# Generated at 2022-06-18 08:13:18.759086
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '')) == 'git pull origin master'

# Generated at 2022-06-18 08:13:27.399511
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:dspinellis/git-issue.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:13:39.333841
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/user/repo.git\n ! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/user/repo.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-18 08:13:48.040075
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To git@github.com:nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:13:57.242952
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to \'git@github.com:fuck.git\'',
                         'hint: Updates were rejected because the tip of your current branch is behind',
                         'hint: its remote counterpart. Integrate the remote changes (e.g.',
                         'hint: \'git pull ...\') before pushing again.',
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:14:07.623999
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:aiyanbo/test.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))

# Generated at 2022-06-18 08:14:09.366916
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '', 0)) == 'git pull'

# Generated at 2022-06-18 08:14:11.427848
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '', '', '', '')) == 'git pull'

# Generated at 2022-06-18 08:14:20.963771
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:Sylhare/configs.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))

# Generated at 2022-06-18 08:14:30.101193
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To git@github.com:nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:14:39.913944
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:dsp9107/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))

# Generated at 2022-06-18 08:14:49.982367
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected] master -> master (non-fast-forward)\n'
                                     'error: failed to push some refs to \'https://github.com/user/repo.git\'\n'
                                     'hint: Updates were rejected because the tip of your current branch is behind\n'
                                     'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                     'hint: \'git pull ...\') before pushing again.\n'
                                     'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:15:03.099096
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:aiyanbo/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:15:12.595340
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To git@github.com:nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:15:22.862479
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:dsp9107/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-18 08:15:31.624133
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/user/repo.git\n ! [rejected] '
                         'master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'https://github.com/user/repo.git\'\n'
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))

# Generated at 2022-06-18 08:15:40.644654
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:fuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-18 08:15:43.152702
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '', 1)) == 'git pull'

# Generated at 2022-06-18 08:15:45.272938
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-18 08:15:54.309877
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/user/repo.git\n ! [rejected] '
                         'master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'https://github.com/user/repo.git\'\n'
                         'hint: Updates were rejected because the tip of '
                         'your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\nhint: \'git pull ...\') before '
                         'pushing again.\nhint: See the \'Note about '
                         'fast-forwards\' in \'git push --help\' for details.',
                         '', 1))

# Generated at 2022-06-18 08:16:04.366101
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To https://github.com/nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:16:13.747894
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:fuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))

# Generated at 2022-06-18 08:16:26.946246
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:16:35.976704
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/nvbn/thefuck\n ! [rejected]      master -> master (fetch first)\nerror: failed to push some refs to \'https://github.com/nvbn/thefuck\'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:16:44.620317
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To git@github.com:nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:16:51.001928
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n  (use "git pull" to update your local branch)')) == 'git pull && git push'
    assert get_new_command(Command('git push', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the remote contains work that you do\n  (use "git pull" to update your local branch)')) == 'git pull && git push'

# Generated at 2022-06-18 08:16:59.063576
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/user/repo.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/user/repo.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:17:08.294520
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:dspinellis/git-issue.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))

# Generated at 2022-06-18 08:17:16.590824
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))

# Generated at 2022-06-18 08:17:23.809785
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:fuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:17:32.808617
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/user/repo.git\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/user/repo.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:17:41.257882
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '', '', '', '')) == 'git pull'
    assert get_new_command(Command('git push origin master', '', '', '', '', '')) == 'git pull origin master'
    assert get_new_command(Command('git push origin master:master', '', '', '', '', '')) == 'git pull origin master:master'
    assert get_new_command(Command('git push origin master:master --force', '', '', '', '', '')) == 'git pull origin master:master --force'
    assert get_new_command(Command('git push origin master:master --force --tags', '', '', '', '', '')) == 'git pull origin master:master --force --tags'

# Generated at 2022-06-18 08:17:52.425116
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:dsp9107/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))

# Generated at 2022-06-18 08:17:53.759393
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '', 1)) == 'git pull'

# Generated at 2022-06-18 08:18:04.736427
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:dummy/dummy.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:18:13.632477
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/user/repo.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:18:22.714231
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To git@github.com:nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:18:31.288712
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:user/repo.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-18 08:18:38.725135
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:mislav/dotfiles.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:18:40.128429
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '')) == 'git pull origin master'

# Generated at 2022-06-18 08:18:41.923719
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '', 1)) == 'git pull && git push'

# Generated at 2022-06-18 08:18:50.098615
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:aiyanbo/test.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))

# Generated at 2022-06-18 08:18:58.449106
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nits remote counterpart. Integrate the remote changes (e.g.\n\'git pull ...\') before pushing again.\nSee the \'Note about fast-forwards\' section of \'git push --help\' for details.')) == 'git pull && git push'

# Generated at 2022-06-18 08:18:59.567594
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '')) == 'git pull'

# Generated at 2022-06-18 08:19:00.704547
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '', 1)) == 'git pull'

# Generated at 2022-06-18 08:19:08.790278
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/user/repo.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-18 08:19:13.403527
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nits remote counterpart. Integrate the remote changes (e.g.\n\'git pull ...\') before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.')) == 'git pull && git push'

# Generated at 2022-06-18 08:19:21.314300
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:...\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:19:29.768139
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:fuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))

# Generated at 2022-06-18 08:19:38.720377
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:xxxx/xxxx.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:19:46.768454
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:agermanidis/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:19:48.627618
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'Updates were rejected because the tip of your current branch is behind')) == 'git pull && git push'

# Generated at 2022-06-18 08:20:02.441404
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '''To https://github.com/nvbn/thefuck.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-18 08:20:07.884376
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'Updates were rejected because the tip of your current branch is behind')) == 'git pull && git push'
    assert get_new_command(Command('git push', 'Updates were rejected because the remote contains work that you do')) == 'git pull && git push'
    assert get_new_command(Command('git push', 'Updates were rejected because the remote contains work that you do not have locally')) == 'git pull && git push'

# Generated at 2022-06-18 08:20:08.815046
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '', 1)) == 'git pull && git push origin master'

# Generated at 2022-06-18 08:20:12.613711
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n')) == 'git pull && git push'
    assert get_new_command(Command('git push', '', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the remote contains work that you do\n')) == 'git pull && git push'

# Generated at 2022-06-18 08:20:14.006791
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '', '', '', '')) == 'git pull'

# Generated at 2022-06-18 08:20:23.292862
# Unit test for function get_new_command

# Generated at 2022-06-18 08:20:31.759310
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
                                     'error: failed to push some refs to \'https://github.com/user/repo.git\'\n'
                                     'hint: Updates were rejected because the tip of your current branch is behind\n'
                                     'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                     'hint: \'git pull ...\') before pushing again.\n'
                                     'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:20:34.342767
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n')) == 'git pull && git push'

# Generated at 2022-06-18 08:20:35.857935
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '')) == 'git pull origin master'

# Generated at 2022-06-18 08:20:40.692056
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', '! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nits remote counterpart. Integrate the remote changes (e.g.\n\'git pull ...\') before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-18 08:20:53.053852
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nits remote counterpart. Integrate the remote changes (e.g.\n\'git pull ...\') before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.')) == 'git pull && git push'

# Generated at 2022-06-18 08:21:00.764296
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:xxx/xxx.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:21:09.330250
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To git@github.com:nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:21:18.388850
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:dogr/test.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))

# Generated at 2022-06-18 08:21:26.953247
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To git@github.com:nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-18 08:21:28.421839
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '', '', '', '')) == 'git pull'

# Generated at 2022-06-18 08:21:35.578782
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:aiyanbo/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))


# Generated at 2022-06-18 08:21:45.154747
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] master -> master (non-fast-forward)\n'
                                              'error: failed to push some refs to \'https://github.com/user/repo.git\'\n'
                                              'hint: Updates were rejected because the tip of your current branch is behind\n'
                                              'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                              'hint: \'git pull ...\') before pushing again.\n'
                                              'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')) == 'git pull && git push'

# Generated at 2022-06-18 08:21:51.346618
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   '! [rejected]        master -> master (non-fast-forward)\n'
                                   'error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n'
                                   'hint: Updates were rejected because the tip of your current branch is behind\n'
                                   'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                   'hint: \'git pull ...\') before pushing again.\n'
                                   'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-18 08:21:53.183944
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '', 1)) == 'git pull'