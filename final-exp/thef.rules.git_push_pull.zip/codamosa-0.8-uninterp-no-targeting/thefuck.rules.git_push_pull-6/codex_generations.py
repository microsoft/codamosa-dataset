

# Generated at 2022-06-22 01:44:45.172830
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '''Updating b6ed8f6..c7d1549
error: failed to push some refs to 'https://github.com/agnoster/git-fork-rebase-demo.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''')).script == 'git pull'


# Generated at 2022-06-22 01:44:54.053353
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
                                   '! [rejected]        master -> master (non-fast-forward)\n'
                                   'error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n'
                                   'hint: Updates were rejected because the tip of your current branch is behind\n'
                                   'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                   'hint: \'git pull ...\') before pushing again.')) == 'git pull && git push'

# Generated at 2022-06-22 01:44:56.574721
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == 'git pull --rebase origin master && git push origin master'

# Generated at 2022-06-22 01:45:06.432565
# Unit test for function match
def test_match():
    assert not match(Command(script = 'git push'))
    assert match(Command(script = 'git push',
                         output = '! [rejected]        master -> master (non-fast-forward)'))
    assert not match(Command(script = 'git push',
                             output = 'To https://gitlab.com/user/repo.git'))

# Generated at 2022-06-22 01:45:10.422653
# Unit test for function match
def test_match():
	assert match(Command('git push', "To https://github.com/... ! [rejected]\nUpdates were rejected because the tip of your current branch is behind"))


# Generated at 2022-06-22 01:45:15.296855
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin/master', '', stderr='Updates were rejected because the remote contains work that you do not have locally.  This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g.,', script='git push origin/master')) == 'git pull && git push origin/master'

# Generated at 2022-06-22 01:45:18.393601
# Unit test for function get_new_command
def test_get_new_command():
    f = get_new_command
    assert f(
        Command(script='git push', output='Updates were rejected because')) == \
        'git pull && git push'

# Generated at 2022-06-22 01:45:25.332915
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push origin master',
                                   output=' ! [rejected]  master -> master (non-fast-forward)\n')) == 'git pull'
    assert get_new_command(Command(script='git push origin master',
                                   output='This command automatically merges remote changes into your current branch, but will not make it active.\n! [rejected]  master -> master (non-fast-forward)\n')) == 'git pull'

# Generated at 2022-06-22 01:45:36.080294
# Unit test for function match
def test_match():
    assert match(Command('git push',
    '''To git@github.com:xxx/xxx.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:xxx/xxx.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''))


# Generated at 2022-06-22 01:45:38.193569
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push")
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-22 01:45:43.606099
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('git fetch') ==
            shell.and_('git pull', 'git fetch'))



# Generated at 2022-06-22 01:45:54.853216
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
                                   '! [rejected]        master -> master (non-fast-forward)\n'
                                   'error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n'
                                   'hint: Updates were rejected because the tip of your current branch is behind\n'
                                   'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                   'hint: \'git pull ...\') before pushing again.\n'
                                   'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                                   None)) == 'git fetch && git pull && git push'


# Generated at 2022-06-22 01:46:01.288243
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push heroku master',
                                   '''To git@heroku.com:app.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@heroku.com:app.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.''',
                                   '', None)) == 'git pull heroku master & git push heroku master'



# Generated at 2022-06-22 01:46:03.808398
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(Command('git push origin master')) == 'git pull && git push origin master'


enabled_by_default = True

# Generated at 2022-06-22 01:46:09.661787
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', "", "", "", "", ""))
    assert match(Command('git push origin master', "", "", "", "", ""))
    assert not match(Command('git push origin master', "", "", "", "", ""))
    assert not match(Command('git push origin master', "", "", "", "", ""))


# Generated at 2022-06-22 01:46:17.665590
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '''
! [rejected]
error: failed to push some refs to 'https://github.com/apple/swift.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''')) == ('git pull origin master && git push origin master')

# Generated at 2022-06-22 01:46:21.120653
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', 'Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.')
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-22 01:46:30.164175
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)')).script == 'git push'
    assert match(Command('git push', 'To https://github.com/nvbn/thefuck.git')).script is None
    assert match(Command('git push', 'Updates were rejected because the tip of your current branch is behind')).script == 'git push'
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do')).script == 'git push'


# Generated at 2022-06-22 01:46:39.964414
# Unit test for function get_new_command
def test_get_new_command():
    script = "git push origin master"
    output = "! [rejected]        master -> master (non-fast-forward)\n\
    error: failed to push some refs to 'https://github.com/KrisYu/thefuck.git'\n\
    hint: Updates were rejected because the tip of your current branch is behind\n\
    hint: its remote counterpart. Integrate the remote changes (e.g.\n\
    hint: 'git pull ...') before pushing again.\n\
    hint: See the 'Note about fast-forwards' in 'git push --help' for details."
    assert get_new_command(Command(script=script, output=output)) == "git pull origin master && git push origin master"

# Generated at 2022-06-22 01:46:51.172759
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         stderr='! [rejected] master -> master (fetch first)\n'
                                'error: failed to push some refs to \'git@heroku.com:xxx.git\'\n'
                                'hint: Updates were rejected because the remote contains work that you do\n'
                                'hint: not have locally. This is usually caused by another repository pushing\n'
                                'hint: to the same ref. You may want to first integrate the remote changes\n'
                                'hint: (e.g., \'git pull ...\') before pushing again.\n'
                                'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) is True


# Generated at 2022-06-22 01:46:56.005228
# Unit test for function get_new_command
def test_get_new_command():
    command = get_new_command('git push origin master')
    assert 'git pull origin master' in command

# Generated at 2022-06-22 01:47:07.095148
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', 'error: failed to push some refs to')
    assert get_new_command(command) == 'git pull && git push'
    command = Command('git push', 'error: failed to push some refs to')
    assert get_new_command(command) == 'git pull && git push'
    command = Command('git push origin master', 'error: failed to push some refs to and more')
    assert get_new_command(command) == 'git pull && git push'
    command = Command('git push origin master', 'error: failed to push some refs to\n Updating the remote repository')
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-22 01:47:17.862828
# Unit test for function match

# Generated at 2022-06-22 01:47:27.858969
# Unit test for function match
def test_match():
    assert match(Command(script='git push',
                         stderr='''
To https://github.com/chibisov/dotfiles.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/chibisov/dotfiles.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''')) == True


# Generated at 2022-06-22 01:47:30.642713
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'
    assert get_new_command('git push origin master').script == 'git pull && git push origin master'


# Generated at 2022-06-22 01:47:32.899558
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('git push', 'Updates were rejected because the tip of your current branch is behind')) == 'git pull && git push'

# Generated at 2022-06-22 01:47:37.299372
# Unit test for function get_new_command

# Generated at 2022-06-22 01:47:47.927045
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                     '''To https://github.com/rkp0001/Artificial-Intelligence-for-Robotics-Python-Projects.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/rkp0001/Artificial-Intelligence-for-Robotics-Python-Projects.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))


# Generated at 2022-06-22 01:47:52.955442
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '', '! [rejected] - no matching remote head\n'
                     'error: failed to push some refs to \'git@git.dv.com:bonus_system/bonus_system.git\'')
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-22 01:48:00.751158
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
                                   '! [rejected]        master -> master (non-fast-forward)\n'
                                   'error: failed to push some refs to\''
                                   'https://github.com/user/repo.git\'\n'
                                   'Updates were rejected because the tip of your'
                                   ' current branch is behind')) == shell.and_('git pull',
                                                                   'git push')

# Generated at 2022-06-22 01:48:16.444730
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
       ' ! [rejected]        master -> master (non-fast-forward)\n'
       'error: failed to push some refs to \'git@github.com:aiwithab/Git-Cheat-Sheet.git\'\n'
       'hint: Updates were rejected because the tip of your current branch is behind\n'
       'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
       'hint: \'git pull ...\') before pushing again.\n'
       'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-22 01:48:25.686385
# Unit test for function get_new_command
def test_get_new_command():
    output = '''
remote: You are not currently on a branch.
To push the history leading to the current (detached HEAD)
state now, use

    git push origin HEAD:<name-of-remote-branch>

Updates were rejected because the tip of your current branch is behind
its remote counterpart. Integrate the remote changes (e.g.
'git pull ...') before pushing again.
See the 'Note about fast-forwards' in 'git push --help' for details.
'''
    command = Command('git push origin master', output)
    assert get_new_command(command) == "git pull origin master && git push origin master"

# Generated at 2022-06-22 01:48:36.444241
# Unit test for function match
def test_match():
    assert match(Command("git push origin master",
                         "! [rejected]        master -> master (non-fast-forward)\n"
                         "error: failed to push some refs to"
                         " 'git@github.com:Bachelor-Project-SS16/neelix.git'\n"
                         "hint: Updates were rejected because the tip of your "
                         "current branch is behind\n"
                         "hint: its remote counterpart. Integrate the remote "
                         "changes\n"
                         "hint: (e.g. 'git pull ...') before pushing again."
                         "hint: See the 'Note about fast-forwards' in "
                         "'git push --help' for details.")) == True

# Generated at 2022-06-22 01:48:48.290510
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/MorteNoir1/Zork.git\n'
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'https://github.com/MorteNoir1/Zork.git\'\n'
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))

# Generated at 2022-06-22 01:48:58.792977
# Unit test for function match
def test_match():
    m_match = match(Command('git push'))
    assert m_match == False

    m_match = match(Command('git pull'))
    assert m_match == False

    m_match = match(Command('git push origin master'))
    assert m_match == False


# Generated at 2022-06-22 01:49:01.781450
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', '', '', 0)) == 
        'git pull && git push')


# Generated at 2022-06-22 01:49:11.992858
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '', '! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\n\'git pull ...\') before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert get_new_command(command) == 'git pull && git push'


# Generated at 2022-06-22 01:49:23.017370
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected] ... (non-fast-forward)'
                         '\nUpdates were rejected because the tip of your'
                         ' current branch is behind'
                         '\nfatal: The remote end hung up unexpectedly'))
    assert match(Command('git push', '! [rejected] ... (non-fast-forward)'
                         '\nUpdates were rejected because the remote '
                         'contains work that you do'
                         '\nfatal: The remote end hung up unexpectedly'))
    assert not match(Command('git push', '! [rejected] ... (non-fast-forward)'
                              '\n'
                              '\nfatal: The remote end hung up unexpectedly'))


# Generated at 2022-06-22 01:49:31.565098
# Unit test for function match

# Generated at 2022-06-22 01:49:42.261306
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/user/repo.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n', ''))

# Generated at 2022-06-22 01:49:58.081692
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
                                             'Updates were rejected because the tip of your current branch is behind')).script == 'git pull && git push'
    assert get_new_command(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
                                             'Updates were rejected because the remote contains work that you do')).script == 'git pull && git push'

# Generated at 2022-06-22 01:50:09.736436
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push',
                      '! [rejected]        master -> master (fetch first)\n'
                      'error: failed to push some refs to '
                      '\'ssh://git@git.server.com/project.git\'\n'
                      'hint: Updates were rejected because the remote '
                      'contains work that you do\n'
                      'hint: not have locally. This is usually caused by '
                      'another repository pushing\n'
                      'hint: to the same ref. You may want to first integrate\n'
                      'hint: the remote changes (e.g., \'git pull ...\') '
                      'before pushing again.\n'
                      'hint: See the \'Note about fast-forwards\' in '
                      '\'git push --help\' for details.\n')
    assert get

# Generated at 2022-06-22 01:50:15.087330
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] master -> master (fetch first)\nUpdates were rejected because the remote contains work that you do\nnation', '', '')) == 'git pull && git push'


enabled_by_default = True

# Generated at 2022-06-22 01:50:16.804519
# Unit test for function match
def test_match():
    assert match(Command('push', ''))
    assert not match(Command('push', '', ''))


# Generated at 2022-06-22 01:50:22.641531
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push",
    "Updates were rejected because the remote contains work that you do\nnot have locally. This is usually caused by another repository pushing\n"
    "to the same ref. You may want to first integrate the remote changes\n(e.g., 'git pull ...') before pushing again."
    "\n", "~/projects/dev_env")
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-22 01:50:32.515345
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To https://github.com/user/repo\n ! [rejected] \
master -> master (non-fast-forward)', '', 1))

# Generated at 2022-06-22 01:50:34.935372
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git push", "git push", "")) == "git pull"

# Generated at 2022-06-22 01:50:38.812968
# Unit test for function get_new_command
def test_get_new_command():
    command = "git push"
    git_fail = "hint: Updates were rejected because the remote contains work that you do"
    assert get_new_command(MagicMock(script=command, output=git_fail)) == "git pull"

# Generated at 2022-06-22 01:50:49.376293
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '! [rejected] master -> master'
                         '(non-fast-forward)\n'
                         'error: failed to push some refs to'
                         ' \'git@gitlab.com:someuser/somerepository.git\''
                         '\nUpdates were rejected because the remote contains'
                         ' work that you do\n'
                         'To prevent you from losing history, non-fast-forward'
                         ' updates were rejected\nMerge the remote changes'
                         ' \'git pull\' before pushing again.\n'
                         'See the \'non-fast-forward\' section of \'git push'
                         ' --help\' for details.\n'))

# Generated at 2022-06-22 01:50:50.951461
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = 'git push origin master')) == 'git pull && git push origin master'

# Generated at 2022-06-22 01:51:18.911021
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:aiyanbo/dotfiles.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         None))



# Generated at 2022-06-22 01:51:29.256235
# Unit test for function get_new_command
def test_get_new_command():
    script = "git push origin master"
    output = "! [rejected]        master -> master (non-fast-forward)\n" \
             "error: failed to push some refs to 'git@github.com:ronnnguyen/coconut.git'\n" \
             "hint: Updates were rejected because the tip of your current branch is behind\n" \
             "hint: its remote counterpart. Integrate the remote changes (e.g.\n" \
             "hint: 'git pull ...') before pushing again.\n" \
             "hint: See the 'Note about fast-forwards' in 'git push --help' for details."
    assert get_new_command(Command(script, output)) == "git pull origin master && git push origin master"

# Generated at 2022-06-22 01:51:32.226724
# Unit test for function match
def test_match():
    assert match(Command('git push origin master'))
    assert match(Command('')) == False

# Generated at 2022-06-22 01:51:34.265595
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(shell.and_('git pull', 'git push')) == shell.and_('git pull', 'git pull'))

# Generated at 2022-06-22 01:51:38.013832
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do'))
    assert not match(Command('git push', 'Everything up-to-date'))

# Generated at 2022-06-22 01:51:49.945504
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         "Updates were rejected because the tip of your " +
                         "current branch is behind"))
    assert match(Command('git push origin master',
                         "Updates were rejected because the remote " +
                         "contains work that you do"))
    assert match(Command('git push origin master',
                         "! [rejected]        master -> master " +
                         "(non-fast-forward)"))

# Generated at 2022-06-22 01:51:58.896163
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to \'git@example.com:repo_name.git\'\n'
                         'hint: Updates were rejected because the remote contains work that you do\n'
                         'hint: not have locally. This is usually caused by another repository pushing\n'
                         'hint: to the same ref. You may want to first integrate the remote changes\n'
                         'hint: (e.g., \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'
                         ))

# Generated at 2022-06-22 01:52:03.744376
# Unit test for function match
def test_match():
    assert match(Command("git push origin master", "", "")) == True
    assert match(Command("git push origin master", "To /home/user/ed", "")) == True
    assert match(Command("git push origin master", "! [rejected]  master -> master (fetch first)\n\
error: failed to push some refs to '" + "ssh://user@123.45.67.89/home/user/ed" + "'", "")) == True
    assert match(Command("git push origin master", "'''", "")) == False


# Generated at 2022-06-22 01:52:15.301179
# Unit test for function match
def test_match():
    assert match(Command('git push --force', 'Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.hint: ''git pull ...) before pushing again.\n', '', 0))
    assert match(Command('git push --force', 'Updates were rejected because the remote contains work that you do hint: not have locally. This is usually caused by another repository pushing hint: to the same ref. You may want to first integrate the remote changes hint: (e.g., ''git pull ...) before pushing again.\n', '', 0))
    assert match(Command('git pull', 'From https://github.com/nvbn/thefuck\n * branch            master     -> FETCH_HEAD\nAlready up-to-date.\n', '', 0))

# Generated at 2022-06-22 01:52:17.409378
# Unit test for function get_new_command
def test_get_new_command():
	command= Command("git push")
	assert get_new_command(command) == shell.and_("git pull", "git push")

# Generated at 2022-06-22 01:53:05.441369
# Unit test for function match
def test_match():

    # Test 1
    test = '''
        bash-3.2$ git push origin master
        To ../../repo.git ! [rejected] master -> master (non-fast-forward)
        error: failed to push some refs to '../../repo.git'
        To prevent you from losing history, non-fast-forward updates were rejected
        Merge the remote changes (e.g. 'git pull') before pushing again.  See the
        'Note about fast-forwards' section of 'git push --help' for details.
        bash-3.2$
    '''

    command = Command(script=test, output=test)
    ret = match(command)
    assert ret is True

    # Test 2

# Generated at 2022-06-22 01:53:15.826237
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         " ! [rejected]        master -> master (non-fast-forward)\n"
                         "error: failed to push some refs to"
                         "'git@example.com:mmornati/mytest.git'\n"
                         "hint: Updates were rejected because the tip of"
                         " your current branch is behind\n"
                         "hint: its remote counterpart. Integrate the remote"
                         " changes (e.g.\n"
                         "hint: 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in"
                         " 'git push --help' for details.\n",
                         '', 256))

# Generated at 2022-06-22 01:53:25.974610
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         "! [rejected]        master -> master (non-fast-forward)\n"
                         "error: failed to push some refs to 'git@github.com:123/456.git'\n"
                         "hint: Updates were rejected because the tip of your current branch is behind\n"
                         "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                         "hint: 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in 'git push --help' for details.",
                         'git'))

# Generated at 2022-06-22 01:53:36.450255
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/modocache/django-wiki.git\n! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/modocache/django-wiki.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-22 01:53:44.044699
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin work-in-progress',
        '! [rejected]        work-in-progress -> work-in-progress (non-fast-forward)\n'
        'Updates were rejected because the tip of your current branch is behind\n'
        'its remote counterpart. Merge the remote changes (e.g. \'git pull\')\n'
        'before pushing again.\n'
        'See the \'Note about fast-forwards\' section of \'git push --help\' for details.',
        '', None)) == ' && git pull'


# Generated at 2022-06-22 01:53:53.608900
# Unit test for function get_new_command
def test_get_new_command():
    # Setup
    class TestCommand:
        def __init__(self, script, output):
            self.script = script
            self.output = output
    test_git1 = 'git push'
    test_git2 = 'git push --force'
    test_git3 = 'git push origin master'
    test_git4 = 'git push origin master:feature2'

    test_output = ("Updates were rejected because the tip of "
                   "your current branch is behind its remote counterpart. "
                   "Integrate the remote changes (e.g.\n"
                   "\ngit pull ...\n"
                   "\n) before pushing again.\n"
                   "See the 'Note about fast-forwards' in 'git push --help' "
                   "for details.")

# Generated at 2022-06-22 01:53:59.605752
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git pull && git push' == get_new_command(
        'git push').script
    assert 'git push' == get_new_command(
        'git push').script
    assert 'git push' == get_new_command(
        'git push').script
    assert 'git pull' == get_new_command(
        'git push').script
    assert 'git pull' == get_new_command(
        'git push').script

# Generated at 2022-06-22 01:54:01.688740
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', 'Updates were rejected because the tip of your current branch is behind')
    assert get_new_command(command) == 'git pull'

# Generated at 2022-06-22 01:54:08.050582
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected'
                                    ' because the remote contains work that '
                                    'you do'))
    assert match(Command('git push', 'Updates were rejected'
                                    ' because the tip of your '
                                    'current branch is behind'))
    assert not match(Command('git push', ''))
    assert not match(Command('git push', 'Updates were rejected'))
    assert not match(Command('ls', 'total 0'))


# Generated at 2022-06-22 01:54:16.564644
# Unit test for function match
def test_match():
    assert match(Command('git push',
                'To https://github.com/nvbn/thefuck.git\n ! [rejected]        '
                'gh-pages -> gh-pages (fetch first)\n'
                'error: failed to push some refs to '
                '\'https://github.com/nvbn/thefuck.git\'\n'
                'hint: Updates were rejected because the tip of your '
                'current branch is behind\n'
                'hint: its remote counterpart. Integrate the remote changes '
                '(e.g.\n'
                'hint: \'git pull ...\') before pushing again.\n'
                'hint: See the \'Note about fast-forwards\' in '
                '\'git push --help\' for details.'))
