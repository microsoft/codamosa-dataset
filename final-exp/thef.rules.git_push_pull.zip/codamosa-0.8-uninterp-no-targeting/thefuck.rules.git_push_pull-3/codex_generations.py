

# Generated at 2022-06-22 01:44:45.597938
# Unit test for function match
def test_match():
	fail_output = '''
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'ssh://gitolite3@example.com:22222/testing.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''
	assert match(Command('git push origin master', fail_output))
	command = 'git add README.md git_status.sh && git commit -m "Fix typo" & git push origin master'
	assert match(Command(command, fail_output))


# Generated at 2022-06-22 01:44:46.964801
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'

# Generated at 2022-06-22 01:44:54.781793
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master',
                      '! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/ZhongyanZhang/test\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    new_command = get_new_command(command)
    assert command.script == 'git push origin master'
    assert new_command == 'git pull origin master && git push origin master'


# Generated at 2022-06-22 01:45:05.523308
# Unit test for function match
def test_match():
    # Tests to see if match works correctly
    # Test 1: Test to see if match correctly determines correctly
    # when ! [rejected] is not in output
    command = Command('git push origin master', ' ! [rejected] error')
    assert (match(command) is False)

    # Test 2: test to see if match correctly determines correctly
    # when ! [rejected] is in output along with failed to push
    # some refs to
    command = Command('git push origin master', ' ! [rejected] error failed to push some refs to')
    assert (match(command) is False)

    # Test 3: test to see if match correctly determines correctly
    # when ! [rejected] is in output along with failed to push
    # some refs to and whether updates were rejected because the
    # tip of your current branch is behind
    command

# Generated at 2022-06-22 01:45:17.446485
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         "To git@github.com:nvbn/thefuck.git\n ! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to 'git@github.com:nvbn/thefuck.git'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.")) == True

# Generated at 2022-06-22 01:45:28.993663
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/user/repo\n ! [rejected]      master -> master (fetch first)\n error: failed to push some refs to \'https://github.com/user/repo\'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))
    assert not match(Command('git branch', ''))

# Generated at 2022-06-22 01:45:30.771884
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(make_command('git push origin master')) == 'git pull && git push origin master'

# Generated at 2022-06-22 01:45:40.141225
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to '
                         '\'git@github.com:ralphbean/vagrant-dev-box\''))
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
                         'Updates were rejected because the tip of your '
                         'current branch is behind'))
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
                         'Updates were rejected because the remote '
                         'contains work that you do'))


# Generated at 2022-06-22 01:45:42.742856
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push --force origin master') == 'git pull && git push --force origin master'

# Generated at 2022-06-22 01:45:45.332855
# Unit test for function match
def test_match():
    assert match(Command('git push origin master'))
    assert match(Command('git push'))
    assert not match(Command('git add'))


# Generated at 2022-06-22 01:45:59.240366
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "MSG"', ''))
    assert match(Command('git commit -m "MSG"', 'To git@github.com:USER/REPO.git\n ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:USER/REPO.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-22 01:46:00.912753
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command([u'git push origin master']) == \
           u'git pull && git push origin master'

# Generated at 2022-06-22 01:46:07.723035
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command("git push", "Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.hint: 'git pull ...') before pushing again.\nSee the 'Note about fast-forwards' in 'git push --help' for details.")

# Generated at 2022-06-22 01:46:12.009802
# Unit test for function get_new_command
def test_get_new_command():
    assert ('git pull && git push origin master' ==
            get_new_command(Command('git push origin master',
                                    '! [rejected] '
                                    'Updates were rejected because the tip of '
                                    'your current branch is behind')))

# Generated at 2022-06-22 01:46:14.350401
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull && git push origin master'

# Generated at 2022-06-22 01:46:16.049976
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '', '')) == 'git pull'

# Generated at 2022-06-22 01:46:21.662281
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == 'git pull origin master'
    assert get_new_command(Command('git push', '')) == 'git pull'
    assert get_new_command(Command('git push origin branch1 branch2 branch3', '')) == 'git pull origin branch1 branch2 branch3'
    assert get_new_command(Command('git push origin branch1', '')) == 'git pull origin branch1'

# Generated at 2022-06-22 01:46:32.407866
# Unit test for function match
def test_match():
    assert match(Command('git push', '', 'fatal: The current branch master has no upstream branch.\nTo push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n', ''))
    assert match(Command('git push', '', 'Everything up-to-date\n', ''))
    assert match(Command('git push origin', '', 'fatal: The current branch master has no upstream branch.\nTo push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n', ''))
    assert not match(Command('git log', '', '', ''))


# Generated at 2022-06-22 01:46:43.415375
# Unit test for function get_new_command
def test_get_new_command():
    _get_new_command = git_support(get_new_command)

# Generated at 2022-06-22 01:46:55.823049
# Unit test for function match
def test_match():
    assert match(Command(script = 'git push',
                         output = ' ! [rejected]          master -> master (non-fast-forward)\n'
                                  'error: failed to push some refs to \'git@github.com:jameskolce/dotfiles.git\'\n'
                                  'To prevent you from losing history, non-fast-forward updates were rejected\n'
                                  'Merge the remote changes (e.g. \'git pull\') before pushing again.  See the\n'
                                  '\'Note about fast-forwards\' section of \'git push --help\' for details.\n'))

# Generated at 2022-06-22 01:47:11.498599
# Unit test for function match

# Generated at 2022-06-22 01:47:22.501556
# Unit test for function get_new_command

# Generated at 2022-06-22 01:47:24.225132
# Unit test for function get_new_command
def test_get_new_command():
	result = get_new_command('git push origin')
	assert result == 'git pull origin'

# Generated at 2022-06-22 01:47:34.926918
# Unit test for function match

# Generated at 2022-06-22 01:47:42.015060
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git push origin master',
                                          '! [rejected] master -> master (non-fast-forward)\n'
                                          'error: failed to push some refs to \'https://github.com/paulodiovani/dotfiles.git\'',
                                          '', 1))
    assert str(new_command) == 'git pull;git push origin master'

# Generated at 2022-06-22 01:47:45.199303
# Unit test for function match
def test_match():
    assert((match('git push origin test:dev') ==
        'git push origin test:dev'))
    assert((match('git push') == 'git push') == False)
    assert((match('') == '') == False)


# Generated at 2022-06-22 01:47:47.804229
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin feature') == 'git pull'
    assert get_new_command('git push master') == 'git pull'
    assert get_new_command('git push') == 'git pull'

# Generated at 2022-06-22 01:48:00.016713
# Unit test for function match
def test_match():
    script1 = 'git push'
    script2 = 'git push origin master'
    script3 = 'git commit -m "test"'

    output1 = '''
 ! [rejected]        master -> master (fetch first)
 error: failed to push some refs to 
 'git@gitlab.com:dangkhoasdc/git-thefuck.git'
 hint: Updates were rejected because the tip of your current branch is 
 behind
 hint: its remote counterpart. Integrate the remote changes (e.g.
 hint: 'git pull ...') before pushing again.
 hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''


# Generated at 2022-06-22 01:48:02.617556
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   '! [rejected] master -> master (non-fast-forward)','')) == 'git pull && git push origin master'

# Generated at 2022-06-22 01:48:14.793016
# Unit test for function match

# Generated at 2022-06-22 01:48:34.168228
# Unit test for function match
def test_match():
    """
    Check if match method works correctly.
    """

    assert match(Command('git push origin master', '', '', 1))

    # Should not match
    assert not match(Command('ls', '', '', 1))
    assert not match(Command('git branch', '', '', 1))
    assert not match(Command('git commit -m "testing"', '', '', 1))

    # Check if the correct error types are matched

# Generated at 2022-06-22 01:48:45.109372
# Unit test for function match
def test_match():
    # Should be considered as valid command
    command1 = Command('git push origin master',
                      ' ! [rejected]        master -> master ')
    assert match(command1)
    # Should not be considered as valid command
    command2 = Command('git push',
                     ' ! [rejected]        master -> master ')
    assert not match(command2)
    # Should be considered as valid command
    command3 = Command('git push origin master',
                     ' ! [rejected]        master -> master ')
    assert match(command3)
    # Should not be considered as valid command
    command4 = Command('git push origin master',
                     ' ! [rejected]        master -> master ')
    assert not match(command4)
    # Should be considered as valid command

# Generated at 2022-06-22 01:48:56.333691
# Unit test for function match
def test_match():
    assert match(Command(script="git push origin master", output="Updates were \
rejected because the tip of your current branch is behind its remote counterpart. \
Integrate the remote changes (e.g. 'git pull ...') before pushing again. \
See the 'Note about fast-forwards' section of 'git push --help' for details."))
    assert match(Command(script="git push origin master", output="Updates were \
rejected because the remote contains work that you do not have locally. This is \
usually caused by another repository pushing to the same ref. You may want to \
first integrate the remote changes before pushing again. See the 'Note about \
fast-forwards' section of 'git push --help' for details."))


# Generated at 2022-06-22 01:49:07.451020
# Unit test for function match
def test_match():
    assert match(Command('git push -u origin master',
                         '! [rejected] master -> master (fetch first)\n'
                         'error: failed to push some refs to \'git@github.com:<user>/<repo>.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-22 01:49:19.063536
# Unit test for function match
def test_match():
    # Normal case
    def match_normal(c):
        return {'script': c,
                'output': ''' ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@git.epitech.eu:/login/2013/login'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Merge the remote changes (e.g. 'git pull')
hint: before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.''',
                'side_effect': ''}
    assert match(match_normal('git push origin master'))

    # Not from remote

# Generated at 2022-06-22 01:49:22.860876
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push something').script == 'git pull ; git push something'
    assert get_new_command('git push something something').script == 'git pull ; git push something something'
    assert get_new_command('git push').script == 'git pull ; git push'

# Generated at 2022-06-22 01:49:31.488428
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', "Updates were rejected \
            because the tip of your current branch is behind its remote \
            counterpart. Integrate the remote changes (e.g. 'git pull ...') \
            before pushing again. See the 'Note about fast-forwards' in 'git \
            push --help' for details.", '', 1))
    assert match(Command('git push origin master', "Updates were rejected \
            because the remote contains work that you do not have locally. \
            This is usually caused by another repository pushing \
            to the same ref. You may want to first integrate the remote \
            changes (e.g., 'git pull ...') before pushing again. \
            See the 'Note about fast-forwards' in 'git push --help' for details.", '', 1))

# Generated at 2022-06-22 01:49:37.474627
# Unit test for function match
def test_match():
    assert match('git push')
    assert match('git push origin master')
    assert match('git push heroku master')
    assert match('git push --force origin master')
    assert match('git push heroku master')
    assert match('git push --force-with-lease origin master')
    assert not match('git push origin master --force-with-lease')


# Generated at 2022-06-22 01:49:39.070635
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('git push origin master').script ==
            'git pull && git push origin master')

# Generated at 2022-06-22 01:49:50.014004
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', ''))
    assert not match(Command('git push origin master', '', 'fatal: not a git repository (or any of the parent directories): .git'))
    assert match(Command('git push origin master', '', 'To ssh://server:~/path/to/file.git ! [rejected]        master -> master (non-fast-forward) error: failed to push some refs to \'ssh://server:~/path/to/file.git\' hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes (e.g. hint: \'git pull ...\') before pushing again. hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-22 01:50:17.657987
# Unit test for function match
def test_match():
    
    command = Command('git push', '! [rejected]\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\n\'git pull ...\') before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.\n')
    assert match(command)
    
    command = Command('git push', '! [rejected]\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\n\'git pull ...\') before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.\n')
    assert not match(command)


# Generated at 2022-06-22 01:50:27.396389
# Unit test for function match

# Generated at 2022-06-22 01:50:29.564650
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command="git push origin master") == 'git pull origin master'


# Generated at 2022-06-22 01:50:40.861707
# Unit test for function match

# Generated at 2022-06-22 01:50:48.879962
# Unit test for function get_new_command
def test_get_new_command():
    import mock
    import sys
    sys.modules['git'] = sys.modules['thefuck.specific.git']
    with mock.patch('thefuck.specific.git.shell') as shell:
        shell.and_ = lambda *args: ' and '.join(args)
        assert get_new_command(mock.Mock(
            script='git push',
            output=('To http://github.com/nvbn/git-recall\n! [rejected]      '
                    'master -> master (non-fast-forward)')
            )) == u'git fetch origin && git pull && git push'

# Generated at 2022-06-22 01:50:55.895069
# Unit test for function match
def test_match():

    # Test with a git command error
    # Test wrong argument for command push
    result = match(Command('git push origin master:master',
                           "fatal: 'origin' does not appear to be a git repository",
                           stderr=True,
                           script='git push origin master:master'))
    assert result is False

    # Test with a real git error

# Generated at 2022-06-22 01:51:07.862038
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'ERROR: Permission to blah blah ... ! [rejected]\n'
                         'Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'failed to push some refs to...'))
    assert match(Command('git push',
                         'ERROR: Permission to blah blah ... ! [rejected]\n'
                         'Updates were rejected because the remote '
                         'contains work that you do\n'
                         'failed to push some refs to...'))
    assert not match(Command('git push', 'Everything up-to-date\n'
                                          'failed to push some refs to...'))

# Generated at 2022-06-22 01:51:13.410843
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git push origin master') == 'git pull origin master && git push origin master')
    assert(get_new_command('git push') == 'git pull && git push')
    assert(get_new_command('git push --force') == 'git pull && git push --force')
    assert(get_new_command('git push --force origin master') == 'git pull origin master && git push --force origin master')

# Generated at 2022-06-22 01:51:16.124814
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == 'git pull && git push origin master'

# Generated at 2022-06-22 01:51:26.789697
# Unit test for function match
def test_match():
    assert not match(Command('git push', '', 'error: src refspec master does not match any.'))
    assert not match(Command('git add', '', 'error: src refspec master does not match any.'))

# Generated at 2022-06-22 01:52:12.168836
# Unit test for function match
def test_match():
    assert match(Command('git push origin master'))
    assert not match(Command('git push origin master',
                             'Everything up-to-date'))
    assert not match(Command('git push origin master',
                             'Updates were rejected because the '
                             'remote contains work that you do'))
    assert not match(Command('git push origin master',
                             'To prevent you from losing history, '
                             'non-fast-forward updates were rejected'))
    assert not match(Command('git push origin master',
                             'To prevent you from losing history, '
                             'non-fast-forward updates were rejected'))
    assert not match(Command('git push --force o',
                             'Everything up-to-date'))

# Generated at 2022-06-22 01:52:14.180578
# Unit test for function match
def test_match():
    command = mock.Mock(script = 'git push')
    command.output = 'Failed to push some refs to \'https://github.com/user/repository.git'
    assert not match(command)
    command.output = 'Updates were rejected because the tip of your current branch is behind'
    assert match(command)
    command.output = 'Updates were rejected because the remote contains work that you do'
    assert match(command)


# Generated at 2022-06-22 01:52:23.553893
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                            'To https://github.com/user/repo.git\n ! [rejected]      master -> master (fetch first)\n error: failed to push some refs to \'https://github.com/user/repo.git\'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) is True

# Generated at 2022-06-22 01:52:30.076338
# Unit test for function match
def test_match():
    assert match(
        Command('git push origin master', 'fatal: The current branch master has no upstream branch.\nTo push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n\n', ''))
    # Another message when using same command with different arguments
    assert not match(
        Command('git push origin master', 'Everything up-to-date', ''))

# Generated at 2022-06-22 01:52:33.251074
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git push origin master', '', 0))
    assert new_command == shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-22 01:52:43.540729
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push", "! [rejected]        master -> master (non-fast-forward)\n\
error: failed to push some refs to 'git@github.com:Sara-Lautman/pyshroom.git'\n\
hint: Updates were rejected because the tip of your current branch is behind\n\
hint: its remote counterpart. Integrate the remote changes (e.g.\n\
hint: 'git pull ...') before pushing again.\n\
hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n", "", 1, "")

    new_command = get_new_command(command)
    assert isinstance(new_command, Command)
    assert new_command.script == "git pull && git push"

# Generated at 2022-06-22 01:52:47.447460
# Unit test for function match
def test_match():
   assert match(Command('git push origin master', '! [rejected]        master -> master (fetch first)',
      'error: failed to push some refs to \'git@github.com:Luke-zhang-04/test-repo\'')) == True

# Generated at 2022-06-22 01:52:56.088886
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', 'Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.hint: \'git pull ...\') before pushing again.')
    assert get_new_command(command) == 'git pull origin master && git push origin master'
    command = Command('git push origin master', 'Updates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g. hint: \'git pull ...\') before pushing again.')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-22 01:53:03.498772
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (fetch first)'))
    assert match(Command('git push origin master',
                         'Updates were rejected because the tip of your'
                         ' current branch is behind its remote'
                         ' counterpart. Integrate the remote changes'
                         ' (e.g.hint: \'git pull ...\') before'))
    assert not match(Command('git push origin master', 'Everything up-to-date'))



# Generated at 2022-06-22 01:53:04.632166
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push master', '')) == 'git pull master'

# Generated at 2022-06-22 01:53:45.377341
# Unit test for function get_new_command
def test_get_new_command():
    assert ('git pull') == get_new_command(Command("git push origin master", "", ""))



# Generated at 2022-06-22 01:53:50.629492
# Unit test for function match
def test_match():
    assert match(Command('git push', 'warning: Upd',
                         'warning: Updates were rejected because the tip '
                         'of your current branch is behind its remote'))
    assert match(Command('git push', 'warning: Upd',
                         'warning: Updates were rejected because the remote '
                         'contains work that you do'))
    assert not match(Command('git push', 'warning: Upd',
                             'warning: Updates were rejected because'))

# Generated at 2022-06-22 01:53:51.724823
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'

# Generated at 2022-06-22 01:54:01.976130
# Unit test for function match
def test_match():
    assert (match(Command('git push',
                         (' ! [rejected]        master -> master (fetch first)\n'
                          'error: failed to push some refs to '
                          '\'git@github.com:nvbn/thefuck.git\'\n'
                          'hint: Updates were rejected because the tip of your '
                          'current branch is behind\n'
                          'hint: its remote counterpart. Integrate the remote '
                          'changes (e.g\n'
                          'hint: \'git pull ...\') before pushing again.\n'
                          'hint: See the \'Note about fast-forwards\' in '
                          '\'git push --help\' for details.\n'))), True)

# Generated at 2022-06-22 01:54:10.471979
# Unit test for function match
def test_match():
    assert match(Command("git push origin master",
                         "! [rejected]        master -> master (non-fast-forward)\n"
                         "error: failed to push some refs to 'git@github.com:<user>/<repo>.git'\n"
                         "hint: Updates were rejected because the tip of your current branch is behind\n"
                         "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                         "hint: 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n",
                         "git",
                         "https://github.com/nvbn/thefuck"))



# Generated at 2022-06-22 01:54:15.537965
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', 'Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g. git pull ...) before pushing again.\ngit push origin master ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:geofft/thefuck.git ')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-22 01:54:24.467984
# Unit test for function match
def test_match():
    assert match(Command(
        script = 'git push',
        output = '! [rejected] master -> master (non-fast-forward) error: fai'\
    		'led to push some refs to \'https://github.com/abhinavnagar31/'\
    		'vagrant-tutorial.git\' hint: Updates were rejected because the '\
    		'tip of your current branch is behind its remote counterpart. '\
    		'Integrate the remote changes (e.g. hint: \'git pull ...\') '\
    		'before pushing again. hint: See the \'Note about fast-forwar'\
    		'ds\' in \'git push --help\' for details.'))

# Generated at 2022-06-22 01:54:30.268541
# Unit test for function match
def test_match():
    assert match(Command('git push', u'''
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/jianqingwang/coursera-data-sci.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-22 01:54:39.593933
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         " ! [rejected]        master -> master (non-fast-forward)\n"
                         "error: failed to push some refs to 'git@github.com:jpmarco/dot-files.git'\n"
                         "hint: Updates were rejected because the tip of your current branch is behind\n"
                         "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                         "hint: 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n"))