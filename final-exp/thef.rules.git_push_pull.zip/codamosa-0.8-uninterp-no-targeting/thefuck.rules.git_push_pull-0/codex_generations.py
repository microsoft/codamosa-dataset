

# Generated at 2022-06-22 01:44:42.008810
# Unit test for function match
def test_match():
    assert match(Command('git push origin branch-a',
    '''
    To https://github.com/nvbn/thefuck.git
     ! [rejected]        branch-a -> branch-a (fetch first)
     error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'
    hint: Updates were rejected because the tip of your current branch is behind
    hint: its remote counterpart. Integrate the remote changes (e.g.
    hint: 'git pull ...') before pushing again.
    hint: See the 'Note about fast-forwards' in 'git push --help' for details.
    '''))


# Generated at 2022-06-22 01:44:52.072823
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         "remote: Permission to cplusplus/thefuck.git denied to lastLeaf.\nfatal: unable to access 'https://github.com/cplusplus/thefuck.git/': The requested URL returned error: 403"))
    assert match(Command('git push origin master',
                         '''To https://github.com/cplusplus/thefuck.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/cplusplus/thefuck.git'''))

# Generated at 2022-06-22 01:44:56.857370
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git push origin master') == 'git pull origin master && git push origin master')
    assert(get_new_command('git push') == 'git pull && git push')
    assert(get_new_command('git push origin') == 'git pull origin && git push origin')

# Generated at 2022-06-22 01:45:06.568236
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
    'To https://github.com/.../...\n ! [rejected]        master -> master (fetch first)\n'
    'error: failed to push some refs to \'https://github.com/.../...\'\n'
    'hint: Updates were rejected because the remote contains work that you do\n'
    'hint: not have locally. This is usually caused by another repository pushing\n'
    'hint: to the same ref. You may want to first integrate the remote changes\n'
    'hint: (e.g., \'git pull ...\') before pushing again.\n'
    'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')) == True


# Generated at 2022-06-22 01:45:09.295966
# Unit test for function match
def test_match():
    assert match(Command("git push origin/master", "[rejected]"))


# Generated at 2022-06-22 01:45:11.055863
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '', '')
    assert get_new_command(command) == 'git pull'

# Generated at 2022-06-22 01:45:15.887275
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', 1))
    assert match(Command('git push origin master', '', 1))
    assert not match(Command('git push origin master', '', 1))
    assert not match(Command('git push origin master', '', 1))
    assert not match(Command('git push origin master', '', 1))


# Generated at 2022-06-22 01:45:25.381179
# Unit test for function match
def test_match():
  assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
    'error: failed to push some refs to \'https://github.com/taq123/dubhe-cli.git\'\n'
    'hint: Updates were rejected because the tip of your current branch is behind\n'
    'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
    'hint: \'git pull ...\') before pushing again.\n'
    'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-22 01:45:36.128100
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', ''))
    assert match(Command('git push origin master', '',
                         'To https://github.com/nvbn/thefuck.git'
                         '\n ! [rejected]        master -> master(fetch first)'
                         '\n error: failed to push some refs to'
                         ' \'https://github.com/nvbn/thefuck.git\''
                         '\n hint: Updates were rejected because the tip of'
                         ' your current branch is behind'
                         '\n hint: its remote counterpart. Integrate the remote'
                         ' changes (e.g.'
                         '\n hint:  \'git pull ...\') before pushing again.'
                         '\n hint: See the \'Note about fast-forwards\' in'
                         ' \'git push --help\' for details.'))

# Generated at 2022-06-22 01:45:40.446350
# Unit test for function match
def test_match():
    command = Command('git push -u origin master', '')
    assert match(command)
    command = Command('git push -u origin master',
                      'Updates were rejected because the tip of your '
                      'current branch is behind its remote counterpart. '
                      'Integrate the remote changes (e.g.hint: \'git pull ...\' '
                      'before pushing again.hint: See the \'Note about '
                      'fast-forwards\' in \'git push --help\' for details.')
    assert match(command)
    command = Command('git push -u origin master',
                      'Updates were rejected because the remote '
                      'contains work that you do not have locally. '
                      'This is usually caused by another repository pushing '
                      'to the same ref. You may want to first integrate the '
                      'remote changes before pushing again.')

# Generated at 2022-06-22 01:45:55.301763
# Unit test for function match
def test_match():
    assert match(Command('git push not-a-branch',
                         'error: failed to push some refs to ...\n'
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes\n'
                         'hint: (e.g. hint: \'git pull ...\') before pushing '
                         'again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.\n'))

# Generated at 2022-06-22 01:45:58.993407
# Unit test for function get_new_command
def test_get_new_command():
    assert ((get_new_command(Command('git push', 'git pull')) == 'git pull')
            and (get_new_command(Command('git push origin master',
                                         'git pull origin master')) ==
                 'git pull origin master'))

# Generated at 2022-06-22 01:46:00.685796
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git push') == shell.and_('git pull', 'git push'))

# Generated at 2022-06-22 01:46:12.475087
# Unit test for function match
def test_match():
    command = Command('git push origin master',
        '''To https://github.com/xxx/xxx
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/xxx/xxx'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''')
    assert match(command)

# Generated at 2022-06-22 01:46:23.205302
# Unit test for function match
def test_match():
    #simple condition test
    result = git.match(Command('git push', '', 'Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.hint: \'git pull ...\') before pushing again.\n'))
    assert result
    #simple condition test
    result = git.match(Command('git push', '', 'Updates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g.hint: \'git pull ...\') before pushing again.\n'))
    assert result
    #simple condition test
    result = git.match(Command('git pull', '', 'Already up-to-date.\nCounting objects: 5, done.\n'))


# Generated at 2022-06-22 01:46:27.066100
# Unit test for function match
def test_match():
    assert match(Command(script='git push', output='! [rejected]        master -> master (fetch first)\n'
        'error: failed to push some refs to \'git@github.com:ryanb58/py4eng.git\'\n'
        'hint: Updates were rejected because the remote contains work that you do\n'
        'hint: not have locally. This is usually caused by another repository pushing\n'
        'hint: to the same ref. You may want to first integrate the remote changes\n'
        'hint: (e.g., \'git pull ...\') before pushing again.\n'
        'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-22 01:46:31.812747
# Unit test for function match
def test_match():
    # Test case: git push command returns error
    assert match(Command('git push origin master',
            'To git@github.com:user/repo.git\n ! [rejected] master -> master (non-fast-forward)\nerror: failed to push some refs to..\nUpdates were rejected because the tip of your current branch is behind its remote\ncounterpart. Integrate the remote changes (e.g.\n`git pull ...`) before pushing again.\nSee the \'Note about fast-forwards\' section of \'git push --help\' for details.\n'))
    # Test case: non-git push command
    assert not match(Command('ls', ''))

# Generated at 2022-06-22 01:46:34.880690
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master && git push origin master'
    assert get_new_command('git push -u origin master') == 'git pull -u origin master && git push -u origin master'

# Generated at 2022-06-22 01:46:36.587945
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master')) == 'git pull origin master; git push origin master'

# Generated at 2022-06-22 01:46:46.846569
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '', 1))
    assert not match(Command('git pull', '', '', 1))
    assert not match(Command('git push', '', '! [rejected]', 1))
    assert not match(Command('git push', '', '! [rejected]'
                             'failed to push some refs to', 1))
    assert not match(Command('git push', '', 'Updates were rejected because'
                             'the tip of your current branch is behind', 1))
    assert not match(Command('git push', '', 'Updates were rejected because'
                             'the remote contains work that you do', 1))


# Generated at 2022-06-22 01:47:01.879034
# Unit test for function match

# Generated at 2022-06-22 01:47:02.474106
# Unit test for function match
def test_match():
    asser

# Generated at 2022-06-22 01:47:04.488163
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', 'failed to push some refs')) == ["git pull"]

# Generated at 2022-06-22 01:47:12.355997
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == 'git pull origin master && git push origin master'
    assert get_new_command(Command('git push origin master', 'Updates were rejected because the remote contains work that you do\n')) == 'git pull origin master && git push origin master'
    assert get_new_command(Command('git push origin master', 'Updates were rejected because the tip of your current branch is behind\n')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-22 01:47:23.163768
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
        "! [rejected]        master -> master (non-fast-forward)\n"
        "error: failed to push some refs to 'git@gitlab.com:dogwood008/feeds-widget.git'\n"
        "hint: Updates were rejected because the tip of your current branch is behind\n"
        "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
        "hint: 'git pull ...') before pushing again.\n"
        "hint: See the 'Note about fast-forwards' in 'git push --help' for details.")) == \
        shell.and_('git pull', 'git push')

# Generated at 2022-06-22 01:47:24.857756
# Unit test for function match

# Generated at 2022-06-22 01:47:29.341262
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] master -> master (fetch first)')) == 'git pull && git push'
    assert get_new_command(Command('git push', '! [rejected] master -> master')) == 'git pull && git push'

# Generated at 2022-06-22 01:47:32.704283
# Unit test for function match
def test_match():
    assert match(Command("git push origin master",
                         "! [rejected] master -> master (non-fast-forward)\n"
                         "error: failed to push some refs to"
                         "'git@github.com:..."))


# Generated at 2022-06-22 01:47:34.832914
# Unit test for function get_new_command
def test_get_new_command():
    command = ('git push origin master', '', 'Updates were rejected')
    assert get_new_command(command) == 'git pull origin master'

# Generated at 2022-06-22 01:47:38.520141
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit file1 file2', '', '')
    assert get_new_command(command) == 'git pull && git commit file1 file2'


enabled_by_default = True

# Generated at 2022-06-22 01:47:56.792637
# Unit test for function match

# Generated at 2022-06-22 01:48:04.563046
# Unit test for function match
def test_match():
    command = Command(script='git push', stderr=' ! [rejected]        master -> master (non-fast-forward)')
    assert match(command)
    command = Command(script='git push', stderr=' ! [rejected]        master -> master (fetch first)')
    assert match(command)
    command = Command(script='git push', stderr=' ! [rejected]        mastern -> mastern (non-fast-forward)')
    assert not match(command)
    command = Command(script='git push', stderr=' ! [rejected]        mastern -> mastern (fetch first)')
    assert not match(command)


# Generated at 2022-06-22 01:48:16.253495
# Unit test for function get_new_command
def test_get_new_command():
    def test_input(output):
        command = Command('git push',output)
        new_command = get_new_command(command)
        assert new_command == 'git push && git pull'
    test_input(('Everything up-to-date', '', 0))
    test_input(('Updates were rejected because the remote contains work that '
                ' you do\n'
                'not have locally. This is usually caused by another '
                'repository pushing\n'
                'to the same ref. You may want to first integrate the remote '
                'changes\n'
                ' (e.g., \'git pull ...\') before pushing again.\n'
                'See the \'Note about fast-forwards\' in \'git push '
                '--help\' for details.', '', 128))

# Generated at 2022-06-22 01:48:19.729778
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push origin master") == "git pull origin master && git push origin master"
    assert get_new_command("git push -u origin master") == "git pull -u origin master && git push -u origin master"

# Generated at 2022-06-22 01:48:24.505635
# Unit test for function match
def test_match():
    command = Command('git push', '! [rejected] master -> master \
(non-fast-forward) \
error: failed to push some refs to \'git@github.com:avelino/vim-bootstrap.git\'')

    assert match(command)



# Generated at 2022-06-22 01:48:34.586417
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected] master -> master (non-fast-forward)',
                         'error: failed to push some refs to '
                         "'git@gitlab.com:daniel/test.git'",
                         'hint: Updates were rejected because the tip of '
                         'your current branch is behind'))
    assert match(Command('git push origin master',
                         ' ! [rejected] master -> master (non-fast-forward)',
                         'error: failed to push some refs to '
                         "'git@gitlab.com:daniel/test.git'",
                         'hint: Updates were rejected because the remote '
                         'contains work that you do'))


# Generated at 2022-06-22 01:48:46.199725
# Unit test for function match

# Generated at 2022-06-22 01:48:48.843159
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push") == "git pull && git push"
    assert get_new_command("git push origin master") == "git pull origin master && git push origin master"

# Generated at 2022-06-22 01:48:59.345901
# Unit test for function match
def test_match():
    # 1st case test
    assert match(Command('git push origin master', 'To git@github.com:nvbn/thefuck.git\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))
    # 2nd case test

# Generated at 2022-06-22 01:49:10.420980
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:Carol-Wu/thefuck.git\'\n'
                         'To prevent you from losing history, non-fast-forward updates were rejected\n'
                         'Merge the remote changes (e.g. \'git pull\') before pushing again.  See the\n'
                         '\'Note about fast-forwards\' section of \'git push --help\' for details.\n',
                         ''))

# Generated at 2022-06-22 01:49:27.949256
# Unit test for function match
def test_match():
    assert not match({'stderr': '',
                      'script': 'mkdir test'})
    
    assert match({'stderr': 'Updates were rejected because the tip of your \
            current branch is behind',
            'script': 'git push'})
            

# Generated at 2022-06-22 01:49:38.478505
# Unit test for function match
def test_match():
    assert match(Command('git p',
                "fatal: The current branch feature/cool has no upstream branch."))
    assert match(Command('git push',
                "error: failed to push some refs to 'git@somerepo.com:coolrepo.git'"
                "\n! [rejected]        master -> master (non-fast-forward)"
                "\nUpdates were rejected because the tip of your current branch is behind its remote"
                "\ncounterpart. Integrate the remote changes (e.g.\n"
                "\n'git pull ...') before pushing again.\n"
                "\nderr: failed to push some refs to 'git@somerepo.com:coolrepo.git'"))


# Generated at 2022-06-22 01:49:40.728017
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '')) == \
        ' &&  '.join(['git pull origin master', 'git push origin master'])

# Generated at 2022-06-22 01:49:42.501509
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git push')) == 'git pull'

# Generated at 2022-06-22 01:49:54.508299
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]\n'))
    assert match(Command('git push', '!\n[rejected]'))
    assert not match(Command('git push', ''))
    assert not match(Command('git push', '! [rejected]\n' '! [rejected]'))
    assert match(Command('git push', '! [rejected]\n' 'Updates were rejected'
                         ' because the tip of your current branch is behind'))
    assert match(Command('git push', '! [rejected]\n' 'Updates were rejected'
                         ' because the remote contains work that you do'
                         ' not have locally.'))

# Generated at 2022-06-22 01:49:55.424185
# Unit test for function get_new_command

# Generated at 2022-06-22 01:49:57.320195
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-22 01:49:59.420686
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull'

# Generated at 2022-06-22 01:50:09.928854
# Unit test for function match
def test_match():
    assert match(Command('git push origin master:master', stderr=(
        'To git@github.com:nvbn/thefuck.git\n'
        '! [rejected]        master -> master (non-fast-forward)\n'
        'error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n'
        'hint: Updates were rejected because the tip of your current branch is behind\n'
        'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
        'hint: \'git pull ...\') before pushing again.\n'
        'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')))



# Generated at 2022-06-22 01:50:20.174380
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))
    assert not match(Command('git push', 'Everything up-to-date'))


# Generated at 2022-06-22 01:50:40.908293
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = 'git push origin master',
                      stdout= ' ! [rejected]        master -> master (non-fast-forward)\n Updating 2ed8b59..89d0a6e\n error: failed to push some refs to ')
    new_command = get_new_command(command)
    assert new_command == "git pull && git push origin master"


enabled_by_default = True
priority = -1  # Pull before push
requires_output = True

# Generated at 2022-06-22 01:50:42.416409
# Unit test for function get_new_command

# Generated at 2022-06-22 01:50:52.245708
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (fetch first)',
                         'error: failed to push some refs to \'git@github.com:JJ/angular-seed.git\'',
                         'hint: Updates were rejected because the tip of your current branch is behind',
                         'hint: its remote counterpart. Integrate the remote changes (e.g.',
                         'hint: \'git pull ...\') before pushing again.',
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-22 01:50:55.340539
# Unit test for function match
def test_match():
    command = Command('git push', '! [rejected]\n'
                                  'error: failed to push some refs to\n'
                                  'Updates were rejected because the tip of your\n'
                                  'current branch is behind')
    # check if match succeed
    assert match(command)



# Generated at 2022-06-22 01:51:07.504002
# Unit test for function get_new_command
def test_get_new_command():
    assert ('git pull && git push',
            get_new_command(Command(script='git push',
                                    output='! [rejected]        master -> master (non-fast-forward)\n'
                                           'error: failed to push some refs to \'git@github.com:user/test.git\'\n'
                                           'hint: Updates were rejected because the tip of your current branch is behind\n'
                                           'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                           'hint: \'git pull ...\') before pushing again.\n'
                                           'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')))

# Generated at 2022-06-22 01:51:18.337475
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:shitpile/test.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-22 01:51:20.710784
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '')) == 'git pull && git push'

# Generated at 2022-06-22 01:51:23.069041
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '! [rejected]        master -> master (non-fast-forward)', '', 1, ''))


# Generated at 2022-06-22 01:51:33.021516
# Unit test for function match
def test_match():
    command = Command('git push', 'remote: Resolving deltas: 100% (90/90), completed with 22 local objects.\
            ! [rejected]        master -> master (fetch first)\
            error: failed to push some refs to \'https://github.com/user/repo.git\'\
            hint: Updates were rejected because the tip of your current branch is behind\
            hint: its remote counterpart. Integrate the remote changes (e.g.\
            hint: \'git pull ...\') before pushing again.\
            hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert match(command)



# Generated at 2022-06-22 01:51:43.016443
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', stderr='git push: fatal: The current branch master has no upstream branch.\nTo push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n\n')) == False
    assert match(Command('git push origin master', stderr='git push: fatal: The current branch master has no upstream branch.\nTo push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n\n')) == False
    assert match(Command('git push origin master', stderr='Updates were rejected because the tip of your current branch is behind\nUpdates were rejected because the tip of your current branch is behind')) == True


# Generated at 2022-06-22 01:52:19.348219
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push test', '! [rejected]        master -> master (fetch first)\n'
                                 'error: failed to push some refs to \'test\'')) == 'git pull && git push test'

# Generated at 2022-06-22 01:52:26.368093
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'',
                         'hint: Updates were rejected because the tip of your current branch is behind',
                         'hint: its remote counterpart. Integrate the remote changes (e.g.',
                         'hint: \'git pull ...\') before pushing again.',
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-22 01:52:37.831747
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected] master -> master (non-fast-forward)\n'\
                         'error: failed to push some refs to'\
                         ' "https://github.com/user/hello-world.git"\n'\
                         'hint: Updates were rejected because the tip of your'\
                         ' current branch is behind\n'\
                         'hint: its remote counterpart. Integrate the remote changes'\
                         ' (e.g.\n'\
                         'hint: "git pull ...") before pushing again.\n'\
                         'hint: See the "Note about fast-forwards" in '\
                         '"git push --help" for details.'))

# Generated at 2022-06-22 01:52:48.577584
# Unit test for function match
def test_match():
    
    assert match(Command('git push origin master',
        '''! [rejected]        master -> master (non-fast-forward)
To git@github.com:mohitraj/git-manual.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'git@github.com:mohitraj/git-manual.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''))


# Generated at 2022-06-22 01:52:59.563663
# Unit test for function match
def test_match():
    # STDERR message
    assert match(Command('git push', output='To https://github.com/...\n\
    ! [rejected]        master -> master (non-fast-forward)\n\
    error: failed to push some refs to \'https://github.com/...\'\n\
    hint: Updates were rejected because the tip of your current branch is behind\n\
    hint: its remote counterpart. Integrate the remote changes (e.g.\n\
    hint: \'git pull ...\') before pushing again.\n\
    hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))
    # STDOUT message

# Generated at 2022-06-22 01:53:05.562843
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '', '! [rejected]        master -> master (non-fast-forward)\n'))
    assert match(Command('git push', '', '', '! [rejected]        master -> master (fetch first)\n'))
    assert match(Command('git push', '', '', 'Updates were rejected because the tip of your current branch is behind'))
    assert not match(Command('git push', '', '', ''))


# Generated at 2022-06-22 01:53:07.996815
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'


# Generated at 2022-06-22 01:53:18.204665
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'remote: error: denying non-fast forward refs/heads/master '
                         '! [rejected]        master -> master (non-fast forward)\n'
                         'error: failed to push some refs to '
                         '\'https://github.com/dmitrykopytko/thefuck\'\n'
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))

# Generated at 2022-06-22 01:53:28.170296
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', "! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n  its remote counterpart. Integrate the remote changes (e.g.\n  'git pull ...') before pushing again.\n  See the 'Note about fast-forwards' in 'git push --help' for details."))

# Generated at 2022-06-22 01:53:38.417421
# Unit test for function match
def test_match():
    assert match(Command('git push', stderr='! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/xxx/xxx.git\'\n'
                         'To prevent you from losing history, non-fast-forward updates were rejected\n'
                         'Merge the remote changes (e.g. \'git pull\') before pushing again.\n'
                         'See the \'Note about fast-forwards\' section of \'git push --help\' for details.'))
