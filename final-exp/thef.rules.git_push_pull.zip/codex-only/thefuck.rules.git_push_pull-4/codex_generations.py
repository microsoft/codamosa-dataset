

# Generated at 2022-06-24 06:35:35.773454
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push origin test") == "git pull && git push origin test"
    assert get_new_command("git push origin test develop") == "git pull && git push origin test develop"

# Generated at 2022-06-24 06:35:37.465318
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin feature')) == 'git pull && git push origin feature'

# Generated at 2022-06-24 06:35:48.715281
# Unit test for function match
def test_match():    
    from thefuck.rules.git_pull_before_push import match
    supported_shells = shell.all_shells


# Generated at 2022-06-24 06:35:56.484863
# Unit test for function match
def test_match():
    # test case 1:
    command = Command('git push origin master', '', '', '', '')
    assert match(command) == None
    # test case 2:
    command = Command('git push origin master', '', '', '',
                      '''To https://github.com/denisidoro/dotfiles.git
 ! [rejected]        master -> master (non-fast-forward)
 error: failed to push some refs to 'https://github.com/denisidoro/dotfiles.git'
 hint: Updates were rejected because the tip of your current branch is behind
 hint: its remote counterpart. Integrate the remote changes (e.g.
 hint: 'git pull ...') before pushing again.
 hint: See the 'Note about fast-forwards' in 'git push --help' for details.''')

# Generated at 2022-06-24 06:36:00.755098
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'fatal: failed to push some refs to')) == 'git pull && git push'

# Generated at 2022-06-24 06:36:06.868551
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'Updates were rejected because the tip of your current branch is behind',
                         'failed to push some refs to'))
    assert match(Command('git push',
                         'Updates were rejected because the remote contains work that you do',
                         'failed to push some refs to'))



# Generated at 2022-06-24 06:36:18.953122
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    from tests.utils import CommandStub
    assert git_support(Command('git push origin master', ''))
    command = CommandStub(script='git push origin master',
                          output=''' ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:XXX/git-test.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''')
    assert match(command)

# Generated at 2022-06-24 06:36:29.991118
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 'error: failed to push some refs to \'git@example.com:my_user/my_repo.git\'\n'
                                                  'hint: Updates were rejected because the tip of your current branch is behind\n'
                                                  'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                                  'hint: \'git pull ...\') before pushing again.\n'
                                                  'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         'git push origin master'))

# Generated at 2022-06-24 06:36:41.111709
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (fetch first)',
                         'error: failed to push some refs to \'git@github.com:SnorreNorresletten/thefuck.git\'',
                         'hint: Updates were rejected because the tip of your current branch is behind',
                         'hint: its remote counterpart. Integrate the remote changes (e.g.',
                         'hint: \'git pull ...\') before pushing again.',
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-24 06:36:49.458343
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '! [rejected] master -> master (fetch first)\n'
                                                  'error: failed to push some refs to \'cm@cm-master.d.cmteam.com:ss\'\n'
                                                  'hint: Updates were rejected because the remote contains work that you do\n'
                                                  'hint: not have locally. This is usually caused by another repository pushing\n'
                                                  'hint: to the same ref. You may want to first integrate the remote changes\n'
                                                  'hint: (e.g., \'git pull ...\') before pushing again.\n'
                                            'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-24 06:36:52.390757
# Unit test for function get_new_command

# Generated at 2022-06-24 06:36:59.857732
# Unit test for function match
def test_match():
    # Test with every case you can think of. In other words, test as much as
    # possible.
    assert (not match(Command('git push origin master', '')))
    assert (match(Command('git push origin master',
                          '! [rejected]\nUpdates were rejected because the tip'
                          ' of your\ncurrent branch is behind its remote '
                          'counterpart. Integrate the remote changes (e.g.'
                          '\n  git pull ... ) before pushing again.\n'
                          'See the \'Note about fast-forwards\' in \'git push'
                          ' --help\' for details.')))

# Generated at 2022-06-24 06:37:01.996083
# Unit test for function match
def test_match():
    assert match(command=Command('git push origin master'),
            )
    assert not match(command=Command('git push origin master'),
            )


# Generated at 2022-06-24 06:37:12.720765
# Unit test for function match
def test_match():
    assert match(Command(script='git push origin master',
                         stderr='! [rejected]        ff -> fff (non-fast-forward)',
                         output='To git@github.com:myorg/myrepo.git'))
    assert match(Command(script='git push origin master',
                         stderr='! [rejected]        ff -> fff (non-fast-forward)',
                         output='To git@github.com:myorg/myrepo.git'))
    assert match(Command(script='git push origin master',
                         stderr='! [rejected]        ff -> fff (non-fast-forward)',
                         output='To git@github.com:myorg/myrepo.git'))

# Generated at 2022-06-24 06:37:18.576618
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', 'Updates were rejected because the remote contains work that you do')
    assert get_new_command(command) == ['git pull', 'git push']

# Generated at 2022-06-24 06:37:28.546094
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To https://github.com/user/repo.git\n ! [rejected] \
                         master -> master (non-fast-forward)\n error: \
                         failed to push some refs to \'https://github.com/user/repo.git\'\n\
                         hint: Updates were rejected because the tip of your current branch is behind\n\
                         hint: its remote counterpart. Integrate the remote changes (e.g.\n\
                         hint: \'git pull ...\') before pushing again.\n\
                         hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:37:37.562201
# Unit test for function match
def test_match():
	message1 = '''
	    ! [rejected]        master -> master (non-fast-forward)
	     error: failed to push some refs to 'git@github.com:pwlmaciejewski/psu-cs350.git'
	     hint: Updates were rejected because the tip of your current branch is behind
	     hint: its remote counterpart. Integrate the remote changes (e.g.
	     hint: 'git pull ...') before pushing again.
	     hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''.strip().replace('\t', '')

# Generated at 2022-06-24 06:37:46.352056
# Unit test for function get_new_command
def test_get_new_command():
	command = r'git push'
	command = Command(command, r'''
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@heroku.com:yojimbo.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''')
	assert get_new_command(command) == shell.and_('git pull', 'git push')

# Generated at 2022-06-24 06:37:56.952059
# Unit test for function match
def test_match():
    command = Command('git push',
                      '! [rejected]        master -> master (non-fast-forward)\n'
                      'error: failed to push some refs to message')
    assert match(command)

    command = Command('git push',
                      '! [rejected]        master -> master (non-fast-forward)\n'
                      'error: failed to push some refs to message\n'
                      'Updates were rejected because the tip of your current branch is behind\n'
                      'Tois it, run \'git pull --rebase\'')
    assert match(command)


# Generated at 2022-06-24 06:38:07.129755
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/user/repo.git\n ! [rejected] '
                         'master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'https://github.com/user/repo.git\'\n'
                         'hint: Updates were rejected because the tip of '
                         'your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\n'
                         "hint: 'git pull ...') before pushing again.\n"
                         'hint: See the '
                         '\'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))

# Generated at 2022-06-24 06:38:11.117413
# Unit test for function match
def test_match():
    assert match(Command('git push', 'To https://github.com/user/repo.git\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/user/repo.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:38:13.375570
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master')
    assert get_new_command(command) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:38:19.076307
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master',
                      'Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\n      git pull ...) before pushing again.\n      See the \'Note about fast-forwards\' section of \'git push --help\' for details.')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:38:20.302852
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 
        output='Updates were rejected because the tip of your current branch is behind')) == shell.and_('git pull', 'git push')

# Generated at 2022-06-24 06:38:30.587843
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push','''
To https://github.com/user/repo.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/user/repo.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
    ''')) == shell.and_('git pull', 'git push')


# Generated at 2022-06-24 06:38:37.766095
# Unit test for function match
def test_match():
    assert match(Command('git push origin new_branch',
                         ' ! [rejected]    new_branch -> new_branch (non-fast-forward) \n'
                         'error: failed to push some refs to \'git@github.com:repo.git\'\n'
                         'Updates were rejected because the tip of your current branch is behind\n'
                         'its remote counterpart. Merge the remote changes (e.g. \'git pull\')\n'
                         'before pushing again.\n'
                         'See the \'Note about fast-forwards\' section of \'git push --help\' for details.',
                         '', 5))


# Generated at 2022-06-24 06:38:48.128045
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:xxxx/xxx.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')) is True


# Generated at 2022-06-24 06:38:50.515336
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('git push origin master') == 'git pull && git push origin master'

# Generated at 2022-06-24 06:38:52.493048
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == \
        'git pull && git push origin master'



# Generated at 2022-06-24 06:39:01.856942
# Unit test for function match

# Generated at 2022-06-24 06:39:11.082776
# Unit test for function match
def test_match():
    assert match(Command('git push',
        'To https://github.com/nvie/gitflow.git\n ! [rejected]        '
        'develop -> develop (non-fast-forward)\nerror: failed to push '
        'some refs to \'https://github.com/nvie/gitflow.git\'\n'
        'To prevent you from losing history, non-fast-forward '
        'updates were rejected\nMerge the remote changes (e.g. '
        '\'git pull\') before pushing again.  See the \'Note about '
        'fast-forwards\' section of \'git push --help\' for details.'))
    assert not match(Command('git push'))

# Generated at 2022-06-24 06:39:21.616497
# Unit test for function match
def test_match():
    command1 = Command(script='git push',
                      output=' ! [rejected] \
                          master -> master (non-fast-forward) \
                          error: failed to push some refs to \'git@github.com:...\' \
                          hint: Updates were rejected because the tip of your current branch is behind \
                          hint: its remote counterpart. Integrate the remote changes (e.g. \
                          hint: \'git pull ...\') before pushing again. \
                          hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')

# Generated at 2022-06-24 06:39:25.151861
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull && git push'
    assert get_new_command('git-push') == 'git-pull && git-push'
    assert get_new_command('push') == 'pull && push'

# Generated at 2022-06-24 06:39:27.450804
# Unit test for function get_new_command
def test_get_new_command():
    commands = ['git push']
    new_commands = get_new_command(commands)
    assert new_commands == 'git push && git pull'

# Generated at 2022-06-24 06:39:35.584450
# Unit test for function match
def test_match():
    assert match(Command(script = 'git push',
                         output = ' ! [rejected]        master -> master (non-fast-forward)\n'
                                  'error: failed to push some refs to \'git@github.com:Psycojoker/thefuck.git\'\n'
                                  'hint: Updates were rejected because the tip of your current branch is behind\n'
                                  'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                  'hint: \'git pull ...\') before pushing again.\n'
                                  'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')) == True

# Generated at 2022-06-24 06:39:38.960777
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', ''))
    assert match(Command('git push upstream master', '', ''))
    assert match(Command('git push', '', ''))
    assert not match(Command('git push origin master', '', '', '', 1))
    assert not match(Command('git commit', '', ''))

# Generated at 2022-06-24 06:39:49.710147
# Unit test for function match
def test_match():
    assert (match(Command('cd abc; git push origin master',
                '! [rejected] master -> master (non-fast-forward)\n'
                'error: failed to push some refs to\n'
                'hint: Updates were rejected because the tip of your '
                'current branch is behind\n'
                'hint: its remote counterpart. Integrate the remote changes'
                ' (e.g.\n'
                'hint: \'git pull ...\') before pushing again.\n'
                'hint: See the \'Note about fast-forwards\' in '
                '\'git push --help\' for details.\n',
                '')))

# Generated at 2022-06-24 06:39:59.899780
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (fetch first)'
                         '\nerror: failed to push some refs to...'
                         '\n\nUpdates were rejected because the tip of your '
                         'current branch is behind'))

# Generated at 2022-06-24 06:40:03.172202
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', 'git pull')).script == 'git pull'


# Generated at 2022-06-24 06:40:10.727434
# Unit test for function match
def test_match():
    new_command = "git push"
    command = Command(new_command, "! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to 'git@github.com:saadq/dotfiles.git'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\nhint: 'git pull ...') before pushing again.\n hint: See the 'Note about fast-forwards' in 'git push --help' for details.", "")
    assert match(command)



# Generated at 2022-06-24 06:40:17.631893
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected] master -> master (fetch first)\n\
        error: failed to push some refs to \'git@github.com:evilhackerdude/MARP.git\'\n\
        hint: Updates were rejected because the remote contains work that you do\n\
        hint: not have locally. This is usually caused by another repository pushing\n\
        hint: to the same ref. You may want to first integrate the remote changes\n\
        hint: (e.g., \'git pull ...\') before pushing again.\n\
        hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

	

# Generated at 2022-06-24 06:40:21.247254
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin hello', '')) == 'git pull && git push origin hello'
    assert get_new_command(Command('git push origin hello --force', '')) == 'git pull && git push origin hello --force'

# Generated at 2022-06-24 06:40:30.913973
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   '! [rejected] master -> master (non-fast-forward)\n'
                                   'Updates were rejected because the tip of your '
                                   'current branch is behind its remote\n'
                                   'counterpart. Integrate the remote changes (e.g.\n'
                                   '\'git pull ...\') before pushing again.\n'
                                   'See the \'Note about fast-forwards\' in '
                                   '\'git push --help\' for details.')) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:40:41.139116
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '''
To ssh://git@git.websudos.net/git/coffeebot.git
   1c81d4c..4b4a4f4  master -> master
To ssh://git@git.websudos.net/git/coffeebot.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'ssh://git@git.websudos.net/git/coffeebot.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
    '''))

# Generated at 2022-06-24 06:40:50.618274
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to \'git@github.com:**********.git\'',
                         'To prevent you from losing history, non-fast-forward updates were rejected',
                         'Merge the remote changes (e.g. \'git pull\') before pushing again.',
                         'See the \'Note about fast-forwards\' section of \'git push --help\' for details.'))


# Generated at 2022-06-24 06:41:01.108232
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@server:fuck.git\'\n'
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes '
                         '(e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for '
                         'details.',
                         ''))

# Generated at 2022-06-24 06:41:08.449084
# Unit test for function get_new_command

# Generated at 2022-06-24 06:41:20.843864
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to...',
                         ''))
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to...',
                         ''))
    assert not match(Command('git push origin master',
                             'Everything up-to-date',
                             ''))
    assert match(Command('git push origin master',
                         'To git@not.real:user/repo.git\n ! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to ...',
                         ''))

# Generated at 2022-06-24 06:41:24.374173
# Unit test for function match
def test_match():
    assert match(Command('git push orign master',
                         'Username for \''
                         'https://github.com\': yao1352', "",
                         "ERROR: Permission to xxx.git denied to yao1352."))



# Generated at 2022-06-24 06:41:32.988502
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push origin master") == "git pull && git push origin master"
    assert get_new_command("git push origin") == "git pull && git push origin"
    assert get_new_command("git push") == "git pull && git push"
    assert get_new_command("git push origin github") == "git pull && git push origin github"
    assert get_new_command("git push origin") == "git pull && git push origin"
    assert get_new_command("git push origin github") == "git pull && git push origin github"
    assert get_new_command("git push origin") == "git pull && git push origin"


# Generated at 2022-06-24 06:41:41.957332
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   'fatal: You are not currently on a branch.'
                                   '\nTo push the history leading to the current'
                                   ' (detached HEAD) state now, use\n'
                                   '\tgit push origin HEAD:master'
                                   '\nTo push to the branch of the same name, use\n'
                                   '\tgit push origin master'
                                   '\n')) == \
           'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:41:49.358035
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]\n'
                         'Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'failed to push some refs to ...'))
    assert not match(Command('git push origin master', ''))
    assert not match(Command('git push origin master',
                         '! [rejected]\n'
                         'Updates were rejected because the remote '
                         'contains work that you do\n'
                         'failed to push some refs to ...'))


# Generated at 2022-06-24 06:41:54.826568
# Unit test for function match
def test_match():
	command = Command("git push origin master", "! [rejected]        master -> master (fetch first)\n\
error: failed to push some refs to 'git@github.com:user/repo.git'\n\
hint: Updates were rejected because the remote contains work that you do\n\
hint: not have locally. This is usually caused by another repository pushing\n\
hint: to the same ref. You may want to first integrate the remote changes\n\
hint: (e.g., 'git pull ...') before pushing again.\n\
hint: See the 'Note about fast-forwards' in 'git push --help' for details.")
	assert(match(command))


# Generated at 2022-06-24 06:41:58.179471
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('push origin master', '! [rejected] master -> master (fetch first)\nfatal: The remote end hung up unexpectedly', '', 1)) == 'git pull && git push origin master')

# Generated at 2022-06-24 06:42:09.093099
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         stderr='! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:...\''))
    assert match(Command('git push origin master',
                         stderr='! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:...\'\n'
                         'Updates were rejected because the tip of your'
                         ' current branch is behind'))

# Generated at 2022-06-24 06:42:15.474963
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push',
        stdout='! [rejected]        master -> master (non-fast-forward)\n'
        'error: failed to push some refs to \'ssh://git@bitbucket.org/jack/dummy.git\'\n'
        'To prevent you from losing history, non-fast-forward updates were rejected\n'
        'Merge the remote changes (e.g. \'git pull\') before pushing again.  See the \'Note about\n'
        'fast-forwards\' section of \'git push --help\' for details.')) == 'git pull && git push'

# Generated at 2022-06-24 06:42:20.624137
# Unit test for function match
def test_match():
    assert match(Command('git push', ''))
    assert not match(Command('push', ''))
    assert not match(Command('git push', 'failed to push some refs to '))
    assert not match(Command('git push', '! [rejected] '))
    assert not match(Command('git push', 'Updates were rejected because the tip'
                                        ' of your current branch is behind'))
    assert not match(Command('git push', 'Updates were rejected because the remote'
                                        ' contains work that you do'))


# Generated at 2022-06-24 06:42:28.451500
# Unit test for function match
def test_match():
    assert (match(Command('git push', ' ! [rejected] master -> master (non-fast-forward) error: failed to push some refs to \'https://github.com/uranusjr/thefuck\' hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes hint: (e.g. hint: \'git pull ...\') before pushing again. hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')))


# Generated at 2022-06-24 06:42:39.350392
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push', output="""
To https://github.com/nvbn/thefuck.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.

""", env={'GIT_TRACE': '1'})) == 'git pull'

# Generated at 2022-06-24 06:42:50.542542
# Unit test for function match
def test_match():
    assert (match(Command('git push origin master',
                          'To git@heroku.com:xxxxx.git\n! [rejected] master -> master (non-fast-forward)\nerror: failed to push some refs to \'git@heroku.com:xxxxx.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                          '', '', 1)) == True)


# Generated at 2022-06-24 06:42:58.321608
# Unit test for function match
def test_match():
    assert match(Command('git push',
        """To http://github.com/nvie/gitflow
   0d1d7fc..127e0c8  master -> master
 ! [rejected]        develop -> develop (non-fast-forward)
error: failed to push some refs to 'git@github.com:nvie/gitflow.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.""",
        ''))

# Generated at 2022-06-24 06:43:01.656884
# Unit test for function get_new_command
def test_get_new_command():
    command_base = Command('git push', '', None)
    assert get_new_command(command_base) == 'git pull && git push'

    command_base = Command('git push origin sintact:assistant', '', None)

# Generated at 2022-06-24 06:43:03.890238
# Unit test for function get_new_command
def test_get_new_command():
    """Check that get_new_command changes the command correctly
    """
    command = Command('git push')
    assert get_new_command(command) == 'git pull'

# Generated at 2022-06-24 06:43:05.992858
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master')
    assert get_new_command(command) == 'git pull origin master && git push origin master'


# Generated at 2022-06-24 06:43:10.636299
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'
    assert get_new_command('git push origin master').script == 'git pull && git push origin master'
    assert get_new_command('git remote add origin git@github.com:nvbn/thefuck.git && git push').script == 'git pull && git remote add origin git@github.com:nvbn/thefuck.git && git push'

# Generated at 2022-06-24 06:43:19.791541
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/nvbn/thefuck.git\n ! [rejected] '
                         'master -> master (non-fast-forward)\n error: failed '
                         'to push some refs to \'https://github.com/nvbn/thefuck.git\'.'
                         '\n hint: Updates were rejected because the tip of your '
                         'current branch is behind\n hint: its remote counterpart.'
                         ' Integrate the remote changes (e.g.\n hint: \'git pull . '
                         'master\') before pushing again.\n hint: See the '
                         '\'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-24 06:43:21.215544
# Unit test for function get_new_command
def test_get_new_command():
    assert "git pull" == get_new_command("git push")

# Generated at 2022-06-24 06:43:31.783907
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '''
    Everything up-to-date
    ! [rejected]        master -> master (fetch first)
    error: failed to push some refs to 'git@github.com:TylerGubala/hough_lines.git'
    hint: Updates were rejected because the remote contains work that you do
    hint: not have locally. This is usually caused by another repository pushing
    hint: to the same ref. You may want to first integrate the remote changes
    hint: (e.g., 'git pull ...') before pushing again.
    hint: See the 'Note about fast-forwards' in 'git push --help' for details.
    Completed with errors, see above.
    ''')
    new_command = get_new_command(command)

# Generated at 2022-06-24 06:43:40.425156
# Unit test for function get_new_command
def test_get_new_command():
    assert git.get_new_command("git push origin master") == "git pull origin master && git push origin master"
    assert git.get_new_command("git push origin master:master") == "git pull origin master:master && git push origin master:master"
    assert git.get_new_command("git push origin master:master --force") == "git pull origin master:master --force && git push origin master:master --force"
    assert git.get_new_command("git push origin master:master --force --set-upstream") == "git pull origin master:master --force --set-upstream && git push origin master:master --force --set-upstream"

# Generated at 2022-06-24 06:43:47.331892
# Unit test for function match

# Generated at 2022-06-24 06:43:49.514241
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git push origin master') == 'git pull origin master')

# Generated at 2022-06-24 06:43:52.381728
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == shell.and_('git pull origin master', 'git push origin master')
    assert get_new_command('git push') == shell.and_('git pull', 'git push')
	

# Generated at 2022-06-24 06:43:55.632614
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == \
           shell.and_('git pull origin master', 'git push origin master')


enabled_by_default = True

# Generated at 2022-06-24 06:44:02.342567
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
                                   'error: failed to push some refs to \'ssh://example.com/git/repo.git/\'\n'
                                   'hint: Updates were rejected because the tip of your current branch is behind\n'
                                   'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                   'hint: \'git pull ...\') before pushing again.')) == shell.and_('git pull', 'git push')

# Generated at 2022-06-24 06:44:10.929732
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push origin master',
                                    '! [rejected] master -> master (fetch first)',
                                    'Updates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes before  pushing again.')) ==
            'git pull origin master && git push origin master')

# Generated at 2022-06-24 06:44:21.282982
# Unit test for function match
def test_match():
    # Test 1
    str_output = '''
    ! [rejected]        refs/remotes/origin/master -> master (non-fast-forward)
    error: failed to push some refs to 'https://github.com/neovim/neovim.git'
    hint: Updates were rejected because the tip of your current branch is behind
    hint: its remote counterpart. Integrate the remote changes (e.g.
    hint: 'git pull ...') before pushing again.
    hint: See the 'Note about fast-forwards' in 'git push --help' for details.
    '''

    command = Command('git push', str_output)
    assert match(command) == True

    # Test 2

# Generated at 2022-06-24 06:44:31.762515
# Unit test for function match
def test_match():
    # tests the original case
    assert match(Command(script="git push origin master", output="! [rejected]        master -> master (non-fast-forward)\n\
error: failed to push some refs to 'git@github.com:<username>/<repository>.git'\n\
hint: Updates were rejected because the tip of your current branch is behind\n\
hint: its remote counterpart. Integrate the remote changes (e.g.\n\
hint: 'git pull ...') before pushing again.\n\
hint: See the 'Note about fast-forwards' in 'git push --help' for details."))
    # tests the case where the local branch is behind the remote branch

# Generated at 2022-06-24 06:44:35.124535
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 'Failed'))
    assert match(Command('git push origin master', 'rejected'))
    assert not match(Command('git pull origin master', 'Failed'))
    assert not match(Command('git clone git@github.com:nvbn/thefuck.git', 'Failed'))

# Generated at 2022-06-24 06:44:36.989695
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command("git push", "Updates were rejected because the tip of your current branch is behind"))
    assert "git pull && git push" == new_command

# Generated at 2022-06-24 06:44:42.505390
# Unit test for function match
def test_match():
    assert match(Command('git remote -v',
                         '''advice: Updates were rejected because the tip of
             your current branch is behind its remote
             counterpart. Integrate the remote changes (e.g.
             'git pull ...') before pushing again.
             See the 'Note about fast-forwards' in 'git push --help' for details.
                         '''))

    assert match(Command('git remote -v',
                         '''advice: Updates were rejected because the remote
             contains work that you do
             not have locally. This is usually caused by another
             repository pushing
             to the same ref. You may want to first integrate the
             remote changes
             (e.g., 'git pull ...') before pushing again.
             See the 'Note about fast-forwards' in 'git push --help' for details.
                         '''))

# Generated at 2022-06-24 06:44:51.190266
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Shell

    assert get_new_command(Shell('git push origin master:foo',
                                 ' ! [rejected]        master -> foo '
                                 '(non-fast-forward)',
                                 'Updates were rejected because the tip of '
                                 'your current branch is behind',
                                 'error: failed to push some refs to '
                                 '\'git@github.com:nvie/gitflow.git\'')) == \
               'git pull && git push origin master:foo'


# Generated at 2022-06-24 06:44:54.214015
# Unit test for function match
def test_match():
    assert match(Command('git push', 'fatal: The current branch master has no upstream branch. To push the current branch and set the remote as upstream, use git push --set-upstream origin master'))
    assert not match(Command('git push', 'error no such file or directory'))


# Generated at 2022-06-24 06:44:56.019087
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git push'
    command = Command(script, '')
    assert get_new_command(command) == 'git pull && git push'


enabled_by_default = True

# Generated at 2022-06-24 06:44:59.117603
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull && git push origin master'
    assert get_new_command('git push') == 'git pull && git push'

# Generated at 2022-06-24 06:45:04.497001
# Unit test for function match
def test_match():
    assert match(Command(
        script='git push',
        output='Updates were rejected because the tip of your current branch is behind'))
    assert match(Command(
        script='git push',
        output='Updates were rejected because the remote contains work that you do'))
    assert not match(Command(
        script='git add file1 file2',
        output='fatal: pathspec \'/file3/\' did not match any files'))



# Generated at 2022-06-24 06:45:05.754233
# Unit test for function get_new_command
def test_get_new_command():
    assert isinstance(get_new_command(Command('git push origin master')),
                      And)

# Generated at 2022-06-24 06:45:11.781163
# Unit test for function match
def test_match():
    assert match(Command('git push',
                     '''To https://github.com/wzpan/thefuck
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/wzpan/thefuck'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.'''))

# Generated at 2022-06-24 06:45:16.045204
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git push'
    head = 'Your branch is up-to-date with '
    tail = '.\nnothing to commit, working directory clean'
    output = head + "''" + tail
    assert (get_new_command(Command(script=command, output=output))
            == 'git pull; git push')

# Generated at 2022-06-24 06:45:24.077902
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:RichardLitt/python-docs-theme.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:45:33.097332
# Unit test for function match
def test_match():
    # When the match function returns True
    assert(match(Command(
        '', '', 'Error: failed to push some refs to '
        '\'https://github.com/FuckTheFuck/FuckTheFuck.git\''
        '\n'
        'hint: Updates were rejected because the tip of your '
        'current branch is behind'
        '\n'
        'hint: its remote counterpart. Integrate the remote changes'
        ' (e.g.'
        '\n'
        'hint: \'git pull ...\') before pushing again.'
        '\n'
        'hint: See the \'Note about fast-forwards\' in \'git push '
        '--help\' for details.',
        '', 0, 'git push')))

    # When the match function returns False