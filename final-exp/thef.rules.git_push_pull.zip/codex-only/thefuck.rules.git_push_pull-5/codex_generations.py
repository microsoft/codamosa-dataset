

# Generated at 2022-06-24 06:35:47.143383
# Unit test for function match
def test_match():
    assert match(Command('git push',
        '''! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/omkarjc27/thefuck.git''',
        ''))

# Generated at 2022-06-24 06:35:51.678217
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'Updates were rejected because the tip of your current branch is behind\nUpdates were rejected because the remote contains work that you do\n\n	(use "git pull" to update your local branch)')) == shell.and_('git pull', 'git push')

# Generated at 2022-06-24 06:35:56.291375
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master && git push origin master'
    assert get_new_command('git push') == 'git pull && git push'
    assert get_new_command('git push --repo=foo') == 'git pull --repo=foo && git push --repo=foo'

# Generated at 2022-06-24 06:36:00.675100
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', ''))
    assert not match(Command('git vsd vds', '', ''))

# Generated at 2022-06-24 06:36:11.083247
# Unit test for function match
def test_match():
    command_push = Command('git push origin master',
                           '================================================================================\n'
                           '== [rejected]        master -> master (non-fast-forward)\n'
                           '================================================================================\n'
                           'Updates were rejected because the tip of your current branch is behind\n'
                           'its remote counterpart. Integrate the remote changes (e.g.\n'
                           '\'git pull ...\') before pushing again.\n'
                           'You may also want to try the \'--rebase\' option.\n'
                           '================================================================================\n'
                           '', 'git')
    assert match(command_push)

# Generated at 2022-06-24 06:36:22.157854
# Unit test for function match
def test_match():
    assert match(Command(script='git push',
                         output='To https://github.com/github/VisualStudio.git'
                         ' ! [rejected]        master -> master '
                         '(non-fast-forward) error: failed to push '
                         'some refs to '
                         '\'https://github.com/github/VisualStudio.git\''
                         ' Updates were rejected because the tip of your'
                         ' current branch is behind its remote counterpart.'
                         ' Integrate the remote changes (e.g.'
                         'git pull ...) before pushing again.'
                         ' See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))

# Generated at 2022-06-24 06:36:23.512618
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git push origin feature", "")) == "git pull origin feature && git push origin feature"

# Generated at 2022-06-24 06:36:25.197374
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push", "", "")
    assert get_new_command(command) == "git pull;git push"

enabled_by_default = True

# Generated at 2022-06-24 06:36:33.012703
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git adit push', " ! [rejected]\n"
                                      "failed to push some refs to 'https://bitbucket.org/walaa/git-cheatsheet.git'\n"
                                      "hint: Updates were rejected because the tip of your current branch is behind\n"
                                      "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                                      "hint: 'git pull ...') before pushing again.\n"
                                      "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n")
    print(get_new_command(command))
    assert(get_new_command(command) == 'git adit pull')

# Generated at 2022-06-24 06:36:38.368288
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', 'Updates were rejected because the remote contains work that you do not have locally.  This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g., \'git pull ...\') before pushing again.')
    assert get_new_command(command) == "git pull && git push"

# Generated at 2022-06-24 06:36:47.703976
# Unit test for function match
def test_match():
    # test command that match the criteria
    assert match(Command("git push origin master", "! [rejected] master -> master (fetch first)\nerror: failed to push some refs to 'git@gitorious.org:test/test.git'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first merge the remote changes (e.g.,\nhint: 'git pull') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.\n", "", 0)) == True

    # test commands that don't match the criteria

# Generated at 2022-06-24 06:36:50.055621
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == shell.and_('git pull origin master', 'git push origin master')


# Generated at 2022-06-24 06:36:58.823252
# Unit test for function match
def test_match():
    command = Command('git push origin master', '', '', 1, None)
    assert match(command)

    command = Command('git push origin master', '', 'Updates were rejected '
                      'because the tip of your current branch is behind', 1, None)
    assert match(command)

    command = Command('git push origin master', '', 'Updates were rejected '
                      'because the remote contains work that you do', 1, None)
    assert match(command)

    command = Command('git push origin master', '', '', 1, None)
    assert not match(command)

    command = Command('git push origin master', '', 'Updates were rejected '
                      'because the tip of your current branch is behind', 1, None)
    assert match(command)


# Generated at 2022-06-24 06:37:00.991777
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '-bash'))==shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-24 06:37:04.699181
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"',
                         '',
                         '',
                         1))
    
    assert not match(Command('git commit -m "test"',
                             '',
                             '',
                             0))
    

# Generated at 2022-06-24 06:37:15.557501
# Unit test for function match
def test_match():
    assert match(Command('git push', 'fatal: The current branch master has no upstream branch.\nTo push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n\n! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'git@github.com:vicoxu/fucker.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:37:18.721643
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('git push origin master', '')
    assert get_new_command(command1) == 'git pull origin master && git push origin master'
    command2 = Command('git push', '')
    assert get_new_command(command2) == 'git pull && git push'

# Generated at 2022-06-24 06:37:28.666660
# Unit test for function match

# Generated at 2022-06-24 06:37:32.180417
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', '', 1))
    assert not match(Command('git push origin master', '', '', ''))
    assert not match(Command('git commit', '', '', ''))

# Generated at 2022-06-24 06:37:39.658933
# Unit test for function match
def test_match():

    # [rejected]
    assert match(Command('git push origin master',
                         "To https://github.com/user/repo.git\n ! [rejected] master -> master (fetch first)\nerror: failed to push some refs to 'https://github.com/user/repo.git'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.")) == True

# Generated at 2022-06-24 06:37:48.327804
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '',
                         'To https://github.com/.../...\n ! [rejected]      master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/.../...\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:37:56.212645
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         "! [rejected]        master -> master (non-fast-forward)\n"
                         "error: failed to push some refs to 'origin'\n"
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         "hint: its remote counterpart. Integrate the remote changes "
                         "(e.g.\nhint: 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in 'git push "
                         "--help' for details.\n"))


# Generated at 2022-06-24 06:37:58.707083
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '', 0, None)) == "git pull && git push origin master"

# Generated at 2022-06-24 06:38:06.836624
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To https://github.com/myuser/my_repo.git\n ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/myuser/my_repo.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-24 06:38:13.293510
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   '! [rejected]        master -> master (non-fast-forward)\r\n'
                                   'Updates were rejected because the tip of your '
                                   'current branch is behind\r\n'
                                   'its remote counterpart. Integrate the remote changes '
                                   '(e.g.\r\n'
                                   'git pull ...)\r\n'
                                   'before pushing again.\r\n'
                                   'See the \'Note about fast-forwards\' in '
                                   '\'git push --help\' for details.')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:38:24.412574
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         stderr='''To https://github.com/<USER>/hellogitworld.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/<USER>/hellogitworld.git'
hint: Updates were rejected because the remote contains work that you do
hint: no nt have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''))

# Generated at 2022-06-24 06:38:33.375403
# Unit test for function match
def test_match():
    assert match(Command('git push -u origin master',
                         ' ! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/sadikovi/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:38:42.953600
# Unit test for function match

# Generated at 2022-06-24 06:38:51.027847
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push origin master', 
output='failed to push some refs to \nUpdates were rejected because the tip of your current branch is behind')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:38:56.875990
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '''To git@github.com:np1/vim.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:np1/vim.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-24 06:39:06.399238
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes before pushing again.'))
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward) error: failed to push some refs to \'git@gitlab.com:german.alvarez/gitlab.git\' hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes (e.g. hint: \'git pull ...\') before pushing again. hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))
    assert not match(Command('git push', 'Everything up-to-date'))
    assert not match

# Generated at 2022-06-24 06:39:15.804879
# Unit test for function match
def test_match():
    assert match(Command(script = "git push",
                         output = "To https://github.com/ChrisTitusTech/thefuck.git\n ! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to 'https://github.com/ChrisTitusTech/thefuck.git'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details."
                         )) == True


# Generated at 2022-06-24 06:39:25.899108
# Unit test for function match
def test_match():
    command1 = Command('git push', '! [rejected] branch -> branch (non-fast-forward)\n'
                       'error: failed to push some refs to \'https://github.com/gleitz/howdoi.git\'\n'
                       'hint: Updates were rejected because the tip of your current branch is behind\n'
                       'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                       'hint: \'git pull ...\') before pushing again.\n'
                       'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                       'git')

# Generated at 2022-06-24 06:39:34.517256
# Unit test for function match
def test_match():
    assert match(Command('git push', '', ''))
    assert match(Command('git push origin', '', ''))
    assert match(Command('git push origin master', '', ''))
    assert not match(Command('git push origin master', '', '', '', 1))

# Generated at 2022-06-24 06:39:36.995009
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push remote master:master', "! [rejected], failed to push some refs to ..")
    assert('git pull remote master:master && git push remote master:master' == get_new_command(command))

# Generated at 2022-06-24 06:39:39.095956
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command("git push origin master")) == \
           shell.and_("git pull origin master", "git push origin master")

# Generated at 2022-06-24 06:39:41.310235
# Unit test for function get_new_command
def test_get_new_command():
    assert "git pull" in get_new_command('git push')

# Generated at 2022-06-24 06:39:43.763688
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '! [rejected]        master -> master (non-fast-forward)')
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-24 06:39:52.213832
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 1, 0))

# Generated at 2022-06-24 06:39:54.732703
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert (get_new_command(Command('git push'))
            == 'git pull && git push')


# Generated at 2022-06-24 06:39:56.995680
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'git push', 'git pull')) == 'git pull'

# Generated at 2022-06-24 06:40:10.060836
# Unit test for function get_new_command
def test_get_new_command():
    script = "git push origin master"
    output1 = "! [rejected]        master -> master (fetch first)\n\
        error: failed to push some refs to 'git@github.com:rugbyprof/543test.git'\n\
        hint: Updates were rejected because the remote contains work that you do\n\
        hint: not have locally. This is usually caused by another repository pushing\n\
        hint: to the same ref. You may want to first integrate the remote changes\n\
        hint: (e.g., 'git pull ...') before pushing again."


# Generated at 2022-06-24 06:40:15.869918
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '''\
To https://github.com/nvbn/thefuck.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.''', '', 1))


# Generated at 2022-06-24 06:40:24.160894
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('git push origin master') == 'git pull origin master'
	assert get_new_command('git push http://asdasdasd/asdasdas/asdasd.git master') == 'git pull http://asdasdasd/asdasdas/asdasd.git master'
	assert get_new_command('git push origin http://asdasdasd/asdasdas/asdasd.git master') == 'git pull origin http://asdasdasd/asdasdas/asdasd.git master'


# Generated at 2022-06-24 06:40:27.451191
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == shell.and_('git pull', 'git push')
    assert get_new_command('git push') == shell.and_('git pull', 'git push')
    assert get_new_command('git push') == shell.and_('git pull', 'git push')

# Generated at 2022-06-24 06:40:31.088319
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push origin master",
                      "error: failed to push some refs to",
                      "Updates were rejected because the tip of your current \
                      branch is behind",
                      "Updates were rejected because the remote \
                      contains work that you do")
    assert get_new_command(command) == 'git pull;git push'

# Generated at 2022-06-24 06:40:41.284434
# Unit test for function match
def test_match():
    assert match(Command('git push',
        "To https://github.com/ssssssssssss.git\n ! [rejected]        \
        master -> master (fetch first)\nerror: failed to push some refs to \
        'https://github.com/ssssssssssss.git'\nhint: Updates were rejected \
        because the tip of your current branch is behind\nhint: its remote \
        counterpart. Integrate the remote changes (e.g.\nhint: 'git \
        pull ...') before pushing again.\nhint: See \
        the 'Note about fast-forwards' in 'git push --help' for details.\n"
    )) == True

# Generated at 2022-06-24 06:40:50.734414
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git push'
    command = Command(script, 'Failed to push some refs to \'https://github.com/kirienko/fastr\'\n'
                              'hint: Updates were rejected because the tip of your current branch is behind\n'
                              'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                              'hint: \'git pull ...\') before pushing again.\n'
                              'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert get_new_command(command) == shell.and_('git pull', script)
    script = 'git push'

# Generated at 2022-06-24 06:40:53.068822
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master')) == 'git pull'

# Generated at 2022-06-24 06:41:02.864616
# Unit test for function match

# Generated at 2022-06-24 06:41:05.781834
# Unit test for function match
def test_match():
    command = Command('git push origin master', '! [rejected]', '')
    assert match(command)

    command = Command('', '', '')
    assert not match(command)

# Generated at 2022-06-24 06:41:07.549750
# Unit test for function match
def test_match():
    assert match(command=Command('git push'))
    assert not match(command=Command('echo'))


# Generated at 2022-06-24 06:41:10.579747
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
                                   '! [rejected] master -> master (fetch first)',
                                   'error: failed to push some refs to...'
                                   'Updates were rejected because the tip of '
                                   'your current branch is behind',
                                   '')) == shell.and_('git pull', 'git push')

# Generated at 2022-06-24 06:41:18.213579
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '', '! [rejected] master -> master (fetch first)', '', ''))
    assert match(Command('git push', '', '', 'Updates were rejected because the tip of your current branch is behind', '', ''))
    assert match(Command('git push', '', '', 'Updates were rejected because the remote contains work that you do', '', ''))
    assert not match(Command('git push', '', '', '! [rejected] master -> master', '', ''))
    assert not match(Command('git pull', '', '', '! [rejected] master -> master', '', ''))



# Generated at 2022-06-24 06:41:20.964812
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '')) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:41:22.819035
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '','')) == 'git pull && git push'



# Generated at 2022-06-24 06:41:33.078205
# Unit test for function match

# Generated at 2022-06-24 06:41:43.279328
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command(script='git push master',
                                       stderr='! [rejected]        master -> master (non-fast-forward)\n\
                                               error: failed to push some refs to \'../../\'\n\
                                               hint: Updates were rejected because the tip of your current branch is behind\n\
                                               hint: its remote counterpart. Integrate the remote changes (e.g.\n\
                                               hint: \'git pull ...\') before pushing again.\n\
                                               hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))
    assert shell.and_('git pull master', 'git push master') == new_command


enabled_by_default = True

# Generated at 2022-06-24 06:41:48.690865
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the tip of your current branch is behind'))
    assert not match(Command('git push', 'to prevent you from losing history.'))
    assert match(Command('git push origin master', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push origin master', 'Updates were rejected because the remote contains work that you do'))

# Generated at 2022-06-24 06:41:55.011817
# Unit test for function match
def test_match():
    assert match(Command('git push',
        '! [rejected]        master -> master (non-fast-forward)\n'
        'error: failed to push some refs to \'ssh://git@github.com/\''))
    assert match(Command('git push',
        '! [rejected]        master -> master (non-fast-forward)\n'
        'error: failed to push some refs to \'https://github.com/\''))
    assert match(Command('git push',
        '! [rejected]        master -> master (fetch first)\n'
        'error: failed to push some refs to \'ssh://git@github.com/\''))

# Generated at 2022-06-24 06:42:04.520322
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master',
                      '''To https://github.com/user/repo.git
                         ! [rejected]        master -> master (non-fast-forward)
                         error: failed to push some refs to 'https://github.com/user/repo.git'
                         hint: Updates were rejected because the tip of your current branch is behind
                         hint: its remote counterpart. Integrate the remote changes (e.g.
                         hint: 'git pull ...') before pushing again.
                         hint: See the 'Note about fast-forwards' in 'git push --help' for details.
                         ''')
    assert get_new_command(command) == 'git pull && git push origin master'


# Generated at 2022-06-24 06:42:10.060330
# Unit test for function match
def test_match():
    assert match(Command('git push', '', ''))
    assert match(Command('git push', '', 'Updates were rejected because the remote contains work that you do\n'))
    assert match(Command('git push', '', 'Updates were rejected because the tip of your current branch is behind\n'))
    assert not match(Command('git add', '', ''))


# Generated at 2022-06-24 06:42:11.818695
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:42:20.990630
# Unit test for function get_new_command

# Generated at 2022-06-24 06:42:31.768081
# Unit test for function match
def test_match():
    assert match(Command('git push origin test',
        "To https://github.com/User/Test\n ! [rejected]        test -> "
        "test (non-fast-forward)\n error: failed to push some refs to "
        "'https://github.com/User/Test'\n hint: Updates were rejected "
        "because the tip of your current branch is behind\n hint: its "
        "remote counterpart. Integrate the remote changes (e.g.\n hint: 'git "
        "pull ...') before pushing again.\n hint: See the 'Note about "
        "fast-forwards' in 'git push --help' for details.\n",
        'git push origin test'))

# Generated at 2022-06-24 06:42:40.055183
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 0, None))
    assert match(Command('git push origin master', '', '', 0, None))
    assert not match(Command('git push', '', '', 0, None))
    assert not match(Command('', '', '', 0, None))


# Generated at 2022-06-24 06:42:51.311491
# Unit test for function match
def test_match():
	assert match(Command('git push origin master',
						 ' ! [rejected]        master -> master (non-fast-forward)',
						 'error: failed to push some refs to \'origin\'',
						 'To prevent you from losing history, non-fast-forward updates were rejected',
						 'Merge the remote changes (e.g. \'git pull\') before pushing again.  See the ',
						 '\'Note about fast-forwards\' section of \'git push --help\' for details.',))

# Generated at 2022-06-24 06:42:57.491348
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command("git push")
    assert result == "git pull && git push"
    result = get_new_command("git push -f")
    assert result == "git pull && git push -f"
    result = get_new_command("git push -u origin")
    assert result == "git pull && git push -u origin"
    result = get_new_command("git push origin master")
    assert result == "git pull && git push origin master"

# Generated at 2022-06-24 06:42:58.966016
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin as', '')) == 'git pull origin as && git push origin as'

# Generated at 2022-06-24 06:43:07.726174
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] master -> master (fetch first)')) == 'git pull && git push'
    assert get_new_command(Command('git push', '! [rejected] master -> master (non-fast-forward)')) == 'git pull && git push'
    assert get_new_command(Command('git push', '! [rejected] master -> master (non fast-forward)')) == 'git pull && git push'
    assert get_new_command(Command('git push', '! [rejected] master -> master (non - fast-forward)')) == 'git pull && git push'
    assert get_new_command(Command('git push', '! [rejected] master -> master (non-fast - forward)')) == 'git pull && git push'


# Generated at 2022-06-24 06:43:14.847515
# Unit test for function match
def test_match():
    assert match(Command("""git push""", "! [rejected] master -> master (non-fast-forward)\n\
                                                 push to origin/master was rejected\n\
                                                 Updates were rejected because the tip of your current branch is behind its remote\n\
                                                 Try pulling before pushing again.""", "git"))

    assert match(Command("""git push""", "! [rejected] master -> master (non-fast-forward)\n\
                                                 push to origin/master was rejected\n\
                                                 Updates were rejected because the remote contains work that you do\n\
                                                 Try pulling before pushing again.""", "git"))

    assert not match(Command("git pull", "Already up-to-date.", "git"))


# Generated at 2022-06-24 06:43:21.341207
# Unit test for function match

# Generated at 2022-06-24 06:43:31.929633
# Unit test for function get_new_command
def test_get_new_command():
    output = command.Command('git push', 'failed to push some refs to "origin"\n'
                                          'hint: Updates were rejected because the tip of your '
                                          'current branch is behind\n'
                                          'hint: its remote counterpart. Integrate the remote changes')

    assert get_new_command(output) == shell.and_('git pull', 'git push')

    output = command.Command('git push', 'failed to push some refs to "origin"\n'
                                          'hint: Updates were rejected because the remote contains work that you do\n'
                                          'hint: not have locally. This is usually caused by another repository pushing\n'
                                          'hint: to the same ref. You may want to first integrate the remote changes')

    assert get_new_command(output)

# Generated at 2022-06-24 06:43:35.872009
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master master').script == 'git pull && git push origin master master'
    assert get_new_command('git push').script == 'git pull && git push'

# Generated at 2022-06-24 06:43:44.645337
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull && git push'
    assert get_new_command(Command('git push', '! [rejected]')) == 'git pull && git push'
    assert get_new_command(Command('git push', '! [rejected] Upda')) == 'git pull && git push'
    assert get_new_command(Command('git push', '! [rejected] Updates were rejected because the tip')) == 'git pull && git push'
    assert get_new_command(Command('git push', '! [rejected] Updates were rejected because the remote')) == 'git pull && git push'
    assert get_new_command(Command('git push', '! [rejected] UpdU')) != 'git pull && git push'

# Generated at 2022-06-24 06:43:54.922922
# Unit test for function match
def test_match():
    git_status_good = '''
    On branch master
    Your branch is up-to-date with 'origin/master'.
    Untracked files:
      (use "git add <file>..." to include in what will be committed)

          test.py
    nothing added to commit but untracked files present (use "git add" to track)
    '''


# Generated at 2022-06-24 06:44:01.313922
# Unit test for function match
def test_match():
    assert(match(Command('git push', '! [rejected]        master -> master (non-fast-forward)', '', 1)) == True)
    assert(match(Command('git push', 'Updates were rejected because the tip of your current branch is behind', '', 1)) == True)
    assert(match(Command('git push', 'Updates were rejected because the remote contains work that you do', '', 1)) == True)
    assert(match(Command('git push', 'Updates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes before pushing again.', '', 1)) == True)


# Generated at 2022-06-24 06:44:12.790973
# Unit test for function match
def test_match():
    assert match(Command('git push', '''remote: Permission to zhaokun/test.git denied to zhaokun-test.
remote: fatal: unable to access 'https://github.com/zhaokun/test.git/': The requested URL returned error: 403'''))
    assert not match(Command('git push','''sdfsdf'''))

# Generated at 2022-06-24 06:44:16.126808
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', 'Everything'
                                               ' up-to-date',
                                    '')) == 'git push')


enabled_by_default = True

# Generated at 2022-06-24 06:44:17.929275
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    command = Command('git push master')

    assert get_new_command(command) == 'git pull && git push master'

# Generated at 2022-06-24 06:44:24.413985
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To git@github.com:nvbn/thefuck.git\n'
                         ' ! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n'
                         'hint: Updates were rejected because the remote contains work that you do\n'
                         'hint: not have locally. This is usually caused by another repository pushing\n'
                         'hint: to the same ref. You may want to first integrate the remote changes\n'
                         'hint: (e.g., \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:44:33.668407
# Unit test for function get_new_command
def test_get_new_command():
    assert_match(get_new_command(Command('git push',
                                        '')),
                 'git pull',
                 '! [rejected]        master -> master (non-fast-forward)')
    assert_match(get_new_command(Command('git push origin release/2.0',
                                        '')),
                 'git pull origin release/2.0',
                 '! [rejected]        master -> master (non-fast-forward)')
    assert_match(get_new_command(Command('git push',
                                        'Updates were rejected because the tip of your current branch is behind')),
                 'git pull',
                 '! [rejected]        master -> master (non-fast-forward)')

# Generated at 2022-06-24 06:44:35.117172
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git push')) == 'git pull && git push')


# Generated at 2022-06-24 06:44:36.101216
# Unit test for function match
def test_match():
    assert match('git push')
    assert match('git push origin master')


# Generated at 2022-06-24 06:44:41.617294
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] master -> master (non-fast-forward)\n' +
                                  'error: failed to push some refs to ')) == 'git pull && git push'
    assert get_new_command(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n' +
                                  'Updates were rejected because the tip of your current branch is behind')) == 'git pull && git push'
    assert get_new_command(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
                                  'Updates were rejected because the remote contains work that you do')) == 'git pull && git push'


# Generated at 2022-06-24 06:44:46.619986
# Unit test for function match
def test_match():
    assert match(Command('git push', 'error: failed to push some refs to \
    \'https://github.com/th3r3g/thefuck\' Updates were rejected because \
    the tip of your current branch is behind its remote counterpart. \
    Integrate the remote changes (e.g.hint: \'git pull ...\') before pushing \
    again.'))
    assert match(Command('git push', 'error: failed to push some refs to \
    \'https://github.com/th3r3g/thefuck\' Updates were rejected because \
    the remote contains work that you do not have locally. This is usually \
    caused by another repository pushing to the same ref. You may want to \
    first integrate the remote changes (e.g., hint: \'git pull ...\') before \
    pushing again.'))

# Generated at 2022-06-24 06:44:52.190520
# Unit test for function match

# Generated at 2022-06-24 06:44:54.635307
# Unit test for function match
def test_match():
    command = Command('git push', 'error: failed to push some refs to ... ! [rejected]        master -> master (fetch first)')

    assert match(command)



# Generated at 2022-06-24 06:45:04.496898
# Unit test for function match

# Generated at 2022-06-24 06:45:05.981907
# Unit test for function match
def test_match():
    assert match(Command('git init', '', '', 123))
    assert not match(Command('git init', '', '', 123))

# Generated at 2022-06-24 06:45:12.007854
# Unit test for function get_new_command

# Generated at 2022-06-24 06:45:16.226178
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   'Updates were rejected because the remote contains work that you do'
                                   ' not have locally.  This is usually caused by another repository pushing'
                                   ' to the same ref.')) == 'git pull && git push origin master'
    assert get_new_command(Command('git push origin master',
                                   'Updates were rejected because the tip of your current branch is behind'
                                   ' its remote counterpart. Integrate the remote changes (e.g. git pull ...)'
                                   ' before pushing again.')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:45:24.123230
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
                                     'error: failed to push some refs to \'https://github.com/myrepo/myrepo\''
                                     '\nhint: Updates were rejected because the tip of your current branch is behind'
                                     '\nhint: its remote counterpart. Integrate the remote changes (e.g.'
                                     '\nhint: \'git pull ...\') before pushing again.\n'
                                     'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:45:33.132982
# Unit test for function match
def test_match():
    command = 'git push origin master'
    output = '''
            ! [rejected] master -> master (non-fast-forward)
            error: failed to push some refs to 'https://github.com/xxx/xxx.git'
            To prevent you from losing history, non-fast-forward updates were rejected
            Merge the remote changes before pushing again.  See the 'Note about
            fast-forwards' section of 'git push --help' for details.
    '''

    assert match(Command(script=command, output=output)) is False

    command = 'git push origin master'

# Generated at 2022-06-24 06:45:40.276336
# Unit test for function match