

# Generated at 2022-06-24 06:35:40.429224
# Unit test for function match

# Generated at 2022-06-24 06:35:43.396315
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git push origin master', 'Error: failed to push some refs to'))
    assert new_command == 'git pull && git push origin master'

# Generated at 2022-06-24 06:35:50.541663
# Unit test for function match
def test_match():
    command = Command('git push', '''remote: Permission to somerepo/somebranch.git denied to SomeUser.
fatal: unable to access 'https://github.com/somerepo/somebranch.git/': The requested URL returned error: 403''')
    assert match(command)
    assert not match(Command('git push', "error: src refspec master does not match any.\nerror: failed to push some refs to 'http://github.com/somerepo/somebranch'\n"))


# Generated at 2022-06-24 06:35:52.639567
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) ==\
        'git pull && git push origin master'

# Generated at 2022-06-24 06:35:56.621930
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   '! [rejected]        some-branch -> some-branch (fetch first)\n'
                                   'error: failed to push some refs to \'git@github.com:user/repo.git\'', '')) == 'git pull origin master'

# Generated at 2022-06-24 06:36:05.185879
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('git push origin test', '! [rejected]        master -> master (non-fast-forward)\n')
    command2 = Command('git push origin test', '! [rejected]        master -> master (fetch first)\n')
    command3 = Command('git push origin test', '! [rejected]        master -> master (up to date)\n')
    assert get_new_command(command1) == "git pull && git push origin test"
    assert get_new_command(command2) == "git pull && git push origin test"
    assert get_new_command(command3) == "git pull && git push origin test"


# Generated at 2022-06-24 06:36:17.098304
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
        " ! [rejected]        master -> master (non-fast-forward)\n"
        "error: failed to push some refs to 'git@example.com:evilhacker/test.git'\n"
        "hint: Updates were rejected because the tip of your current branch is behind\n"
        "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
        "hint: 'git pull ...') before pushing again.\n"
        "hint: See the 'Note about fast-forwards' in 'git push --help' for details."))



# Generated at 2022-06-24 06:36:21.792561
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '/home/vagrant/'))
    assert match(Command('git push origin master', '', '/home/vagrant/'))
    assert not match(Command('git commit', '', '/home/vagrant/'))
    assert not match(Command('git stash', '', '/home/vagrant/'))
    assert not match(Command('git fetch', '', '/home/vagrant/'))
    assert not match(Command('git push origin master', '', '/home/vagrant/'))


# Generated at 2022-06-24 06:36:30.649974
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git push",
                                   output="""! [rejected] master -> master (non-fast-forward)
            error: failed to push some refs to 'git@github.com:fuckthis/fu.git'
            hint: Updates were rejected because the tip of your current branch is behind
            hint: its remote counterpart. Integrate the remote changes (e.g.
            hint: 'git pull ...') before pushing again.
            hint: See the 'Note about fast-forwards' in 'git push --help' for details.
            """,)) == "git pull"

# Generated at 2022-06-24 06:36:41.772292
# Unit test for function match
def test_match():
    assert match(Command("git push origin master",
                         "! [rejected] \nTo git@github.com:nvbn/thefuck.git\n ! [rejected] master -> master (fetch first)\nerror: failed to push some refs to 'git@github.com:nvbn/thefuck.git'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.\n")) == True

# Generated at 2022-06-24 06:36:49.883999
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '\n! [rejected] master -> master (non-fast-forward)\n'
                                        'error: failed to push some refs to \'git@...\'\n'
                                        'Updates were rejected because the tip of your '
                                        'current branch is behind\n'
                                        'its remote counterpart. Integrate the remote changes\n'
                                        '  (e.g.\n'
                                        '\'git pull ...\') before pushing again.\n'
                                        'See the \'Note about fast-forwards\' in \'git push --help\' '
                                        'for details.'))

# Generated at 2022-06-24 06:36:52.067221
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master')) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:36:57.926204
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         stderr='''fatal: The current branch master has no
                         upstream branch. To push the current branch and set the
                         remote as upstream, use

                         git push --set-upstream origin master

                         ! [rejected]        master -> master (non-fast-forward)
                         error: failed to push some refs to '\
                                '\'https://github.com/jakemcc/git-repo-practice.git\''
                         hint: Updates were rejected because the tip of your
                         current branch is behind
                         hint: its remote counterpart. Integrate the remote
                         changes'''))


# Generated at 2022-06-24 06:37:08.286796
# Unit test for function get_new_command
def test_get_new_command():
    command = ['git', 'push']

# Generated at 2022-06-24 06:37:17.035021
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'remote: Resolving deltas: 100% (93/93), completed with 10 local objects.\nremote: error: unable to create temporary file: No such file or directory\nremote: error: failed to lock ref for update\nremote: error: failed to lock ref for update\nTo https://github.com/coder36/foo\n ! [remote rejected] master -> master (failed to lock)'))
    assert not match(Command('git push', 'Everything up-to-date'))

# Generated at 2022-06-24 06:37:25.335206
# Unit test for function match
def test_match():
    assert match(Command('git push origin master','''

To https://github.com/UserName/RepoName.git
 ! [rejected]        HEAD -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/UserName/RepoName.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.


'''))



# Generated at 2022-06-24 06:37:36.495370
# Unit test for function match
def test_match():
    assert match(Command(script='git push',
                         output=' ! [rejected]        master -> master (fetch first)'))
    assert match(Command(script='git push',
                         output='To git@github.com:nvbn/thefuck.git\n ! [rejected]        master -> master (fetch first)'))
    assert not match(Command(script='git push',
                             output=' ! [rejected]        master -> master (non-fast-forward)'))
    assert not match(Command(script='git push',
                             output=' ! [rejected]        master -> master (fetch first)\nAlready up-to-date.'))


# Generated at 2022-06-24 06:37:40.189284
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master').script == ('git pull && git push origin master')
    assert get_new_command('git push').script == ('git pull')
    assert get_new_command('git push --force').script == ('git pull && git push --force')

# Generated at 2022-06-24 06:37:45.837575
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push -u origin master", "! [rejected] ...")
    assert get_new_command(command) == "git pull -u origin master && git push -u origin master"
    command = Command("git push", "! [rejected] ...")
    assert get_new_command(command) == "git pull && git push"


# Generated at 2022-06-24 06:37:53.083729
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                'To /home/adam/proj/app\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'origin\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))



# Generated at 2022-06-24 06:38:00.618346
# Unit test for function match

# Generated at 2022-06-24 06:38:09.794926
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
        '''remote: Permission to repo denied to user.
! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:user/repo.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.''', ''))
    # rejects
    assert not match(Command('git push origin master',
        '''Everything up-to-date''', ''))

# Generated at 2022-06-24 06:38:11.076448
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command("git push")
    assert result == shell.and_('git pull', 'git push')

# Generated at 2022-06-24 06:38:13.965350
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push origin master',
                                   stdout='[rejected]')) == shell.and_('git pull origin master', 'git push origin master')


# Generated at 2022-06-24 06:38:15.289109
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'fatal: The current branch')).script == shell.and_('git pull', 'git push').script

# Generated at 2022-06-24 06:38:22.205571
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '! [rejected]        master -> master (non-fast-forward)\n'))
    assert match(Command('git push', '', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', '', 'Updates were rejected because the remote contains work that you do'))
    assert not match(Command('git push', '', '[rejected]'))


# Generated at 2022-06-24 06:38:23.781100
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git pull' == get_new_command(Command('git push', '', ''))

# Generated at 2022-06-24 06:38:29.400041
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', ''))
    assert not match(Command('git pull origin master', '', '', ''))
    assert not match(Command('g push origin master', '', '', ''))
    assert not match(Command('git push origin master', '', '', ''))
    assert not match(Command('git push origin master', '', '', ''))
    assert not match(Command('git push origin master', '', '', ''))


# Generated at 2022-06-24 06:38:33.565825
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        first -> first (non-fast-forward)',
                         'error: failed to push some refs to'))
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)',
                         'Updates were rejected because the tip of your current branch is behind'))

# Generated at 2022-06-24 06:38:42.832402
# Unit test for function get_new_command
def test_get_new_command():
    test_command = Command("git push",
                           " ! [rejected]        master -> master (non-fast-forward)\n"
                           "error: failed to push some refs to 'git@heroku.com:polar-headland-5814.git'\n"
                           "To prevent you from losing history, non-fast-forward updates were rejected\n"
                           "Merge the remote changes before pushing again.  See the 'Note about\n"
                           "fast-forwards' section of 'git push --help' for details.")
    test_command.env = {}
    assert get_new_command(test_command) == shell.and_(replace_argument(test_command.script, 'push', 'pull'),
                                                       test_command.script)

# Generated at 2022-06-24 06:38:52.240755
# Unit test for function match
def test_match():
    assert match(Command('git push', 'rejected'))
    assert not match(Command('git pull', 'rejected'))
    assert match(Command('git push origin master', 'rejected'))
    assert not match(Command('git pull origin master', 'rejected'))
    assert not match(Command('ls -a', 'rejected'))


# Generated at 2022-06-24 06:38:55.443515
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push origin master").script == "git pull origin master && git push origin master"
    assert get_new_command("git push --set-upstream origin master").script == "git pull --set-upstream origin master && git push --set-upstream origin master"

# Generated at 2022-06-24 06:38:59.530076
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected] \
        master -> master (non-fast-forward) Updating a99bce8..77d0ae8'))
    assert match(Command('git push', '! [rejected] \
        master -> master (non-fast-forward) error: failed to push some refs to \
        \''))
    assert match(Command('git push', 'Updates were rejected because the tip of \
        your current branch is behind'))
    assert match(Command('git push', 'Updates were rejected because the remote \
        contains work that you do'))
    assert not match(Command('git add', ''))

# Generated at 2022-06-24 06:39:09.708877
# Unit test for function match
def test_match():
    # Test a command that matches the rule
    command = Command("git push", ("Everything up-to-date", "", "", "", "", "", ""), "")
    assert match(command)
    assert get_new_command(command) == "git pull && git push"

    # Test a command that matches the rule but also outputs that the default
    # branch is set to something other than master
    command = Command("git push", ("Everything up-to-date", "", "", "", "", "", "fatal: The current branch master has no upstream branch.\nTo push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n"), "")
    assert match(command)

# Generated at 2022-06-24 06:39:12.471431
# Unit test for function match
def test_match():
    match_test = ["git push"]
    fail_match_test = ["git pull"]
    assert match(match_test)
    assert not match(fail_match_test)


# Generated at 2022-06-24 06:39:17.615667
# Unit test for function get_new_command
def test_get_new_command():
    assert "git pull" in get_new_command(Command('git push', 'error msg'))
    assert "git pull" in get_new_command(Command('git push --force', 'error msg'))
    assert "git pull" in get_new_command(Command('git push origin master', 'error msg'))
    assert "git pull" in get_new_command(Command('git push origin master --force', 'error msg'))

# Generated at 2022-06-24 06:39:19.901273
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull && git push'


enabled_by_default = True

# Generated at 2022-06-24 06:39:27.867313
# Unit test for function match
def test_match():
    assert match(command=Command(script='git push',
                                 output='To https://github.com/320G-Labs/th.git\n'
                                        ' ! [rejected]        master -> master (non-fast-forward)\n'
                                        'error: failed to push some refs to \'https://github.com/320G-Labs/th.git\'\n'
                                        'hint: Updates were rejected because the tip of your current branch is behind\n'
                                        'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                        'hint: \'git pull ...\') before pushing again.\n'
                                        'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')) == True

# Generated at 2022-06-24 06:39:29.642574
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push origin master', '!')) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:39:32.493968
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git push -ff origin branch'
    new_command = get_new_command(Command(script=command))
    assert new_command == 'git pull -ff origin branch; git push -ff origin branch'

# Generated at 2022-06-24 06:39:39.933680
# Unit test for function match

# Generated at 2022-06-24 06:39:50.090409
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                ' ! [rejected]    master -> master (non-fast-forward)\n'
                'error: failed to push some refs to \'git@github.com:jiahaog/test.git\'\n'
                'To prevent you from losing history, non-fast-forward updates were rejected\n'
                'Merge the remote changes (e.g. \'git pull\') before pushing again. See the \'Note about\n'
                'fast-forwards\' section of \'git push --help\' for details.',
                ''))

# Generated at 2022-06-24 06:39:52.213037
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git push origin master", "git push origin master")) == "git pull origin master && git push origin master"

# Generated at 2022-06-24 06:40:01.710638
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '''
                         To https://github.com/user/repo.git
                          ! [rejected]        master -> master (non-fast-forward)
                          error: failed to push some refs to 'https://github.com/user/repo.git'
                          hint: Updates were rejected because the tip of your current branch is behind
                          hint: its remote counterpart. Integrate the remote changes (e.g.
                          hint: 'git pull ...') before pushing again.
                          hint: See the 'Note about fast-forwards' in 'git push --help' for details.
                         '''))


# Generated at 2022-06-24 06:40:12.007031
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command


# Generated at 2022-06-24 06:40:18.718459
# Unit test for function match
def test_match():
  assert match(Command("git push", "! [rejected] ..."))
  assert match(Command("git push", "failed to push some refs"))
  assert match(Command("git push", "Updates were rejected"))
  assert match(Command("git push", "Updates were rejected"))
  assert not match(Command("git pull", "failed to push some refs"))
  assert not match(Command("git pull", "Updates were rejected"))
  assert not match(Command("git push", ""))


# Generated at 2022-06-24 06:40:27.845341
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == shell.and_('git pull origin master', 'git push origin master')
    assert get_new_command(Command('git push origin master', 'Updates were rejected because the tip of your current branch is behind')) == shell.and_('git pull origin master', 'git push origin master')
    assert get_new_command(Command('git push origin master', 'Updates were rejected because the tip of your current branch is behind')) == shell.and_('git pull origin master', 'git push origin master')
    assert get_new_command(Command('git push origin master', 'Updates were rejected because the remote contains work that you do')) == shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-24 06:40:34.961057
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '''error: failed to push some refs to 'https://github.com/Shadeyu/test-repo.git'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.\n'''))

# Generated at 2022-06-24 06:40:36.925059
# Unit test for function get_new_command
def test_get_new_command():
    assert ('git pull; git push' == get_new_command('git push').script)
    assert ('push' == get_new_command('push').script)

enabled_by_default = True

# Generated at 2022-06-24 06:40:46.803793
# Unit test for function match
def test_match():
    assert not match(Command('', ''))
    assert match(Command('push origin master',
        r'''
To git@github.com:nvbn/thefuck.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-24 06:40:49.047159
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git push'
    assert get_new_command(Command(command, '', '')) == 'git pull && git push'

# Generated at 2022-06-24 06:40:55.450976
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push',
                                    'Updates were rejected because the '
                                    'remote contains work that you do'
                                    ' not have locally.  This is usually'
                                    ' caused by another repository '
                                    'pushing to the same ref.  You may'
                                    ' want to first integrate the remote'
                                    ' changes before pushing again.')) ==
            'git pull && git push')

# Generated at 2022-06-24 06:41:03.261123
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command


# Generated at 2022-06-24 06:41:06.384460
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push origin master", "! [rejected]        master -> master (non-fast-forward)\n", "")
    assert (get_new_command(command)) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:41:12.366142
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/Kyeongsoo-Park/test.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.'))

# Generated at 2022-06-24 06:41:21.665246
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To git@github.com:nvit/thefuck.git\n ! [rejected] '
                         'master -> master (fetch first)\n error: failed '
                         'to push some refs to \'git@github.com:'
                         'nvit/thefuck.git\'\n hint: Updates were rejected '
                         'because the remote contains work that you do '
                         'not have locally. This is usually caused by '
                         'another repository pushing to the same ref. '
                         'You may want to first integrate the remote '
                         'changes (e.g., \'git pull ...\') before pushing '
                         'again.\n hint: See the \'Note about fast-forwards\' '
                         'in \'git push --help\' for details.',
                         'git push origin master'))
   

# Generated at 2022-06-24 06:41:30.620601
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '! [rejected]        master -> master (non-fast-forward)\n'
            'error: failed to push some refs to \'https://github.com/name/testrepo.git\''
            '\nhint: Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', '', '! [rejected]        master -> master (non-fast-forward)\n'
            'error: failed to push some refs to \'https://github.com/name/testrepo.git\''
            '\nhint: Updates were rejected because the remote contains work that you do'))



# Generated at 2022-06-24 06:41:35.454570
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master')) == 'git pull'

# Generated at 2022-06-24 06:41:38.317710
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', 'git: \'push\' is not a git command. See \'git --help\'.')
    assert get_new_command(command) == shell.and_('git pull', 'git push')

# Generated at 2022-06-24 06:41:44.049757
# Unit test for function get_new_command
def test_get_new_command():
    """
    This unit test tests the get_new_command function of module pull.
    """
    # Test 1: In the following example, the function has to modify the command
    # and include a pull in the command
    example_output = '''git push origin master
To git@github.com:Thuurb/fuck.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:Thuurb/fuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''

# Generated at 2022-06-24 06:41:51.320836
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         "To github.com:nvbn/thefuck\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to 'git@github.com:nvbn/thefuck.git'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.",
                         ""))

# Generated at 2022-06-24 06:41:57.724818
# Unit test for function get_new_command

# Generated at 2022-06-24 06:42:02.100903
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do not have locally'))
    assert not match(Command('git push', 'Everything up-to-date'))


# Generated at 2022-06-24 06:42:12.825091
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'Updates were rejected because the remote contains work that you do\n'
                         'not have locally. This is usually caused by another repository pushing\n'
                         'to the same ref. You may want to first integrate the remote changes\n'
                         '(e.g., \'git pull ...\') before pushing again.'))

# Generated at 2022-06-24 06:42:16.005116
# Unit test for function get_new_command
def test_get_new_command():
    cmd = 'git push origin master'
    assert get_new_command(Command(script=cmd, output='! [rejected] ...')) == \
           shell.and_('git pull origin master', cmd)

# Generated at 2022-06-24 06:42:22.646387
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To git@github.com:nvbn/thefuck\n'
                         ' ! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to \'git@github.com:nvbn/thefuck\'\n'
                         'hint: Updates were rejected because the remote contains work that you do\n'
                         'hint: not have locally. This is usually caused by another repository pushing\n'
                         'hint: to the same ref. You may want to first integrate the remote changes\n'
                         'hint: (e.g., \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         ''))

# Generated at 2022-06-24 06:42:32.554493
# Unit test for function match
def test_match():
    output1 = "! [rejected]        master -> master (non-fast-forward)\n" \
              "error: failed to push some refs to 'https://github.com/Roshanjossey/first-contributions.git'"

# Generated at 2022-06-24 06:42:41.391368
# Unit test for function match
def test_match():
    assert match(command=Command('git push origin master',
                                 '\n ! [rejected] master -> master (non-fast-forward)',
                                 'error: failed to push some refs to'
                                 ' \'git@github.com:user/repo.git\'\n'
                                 'hint: Updates were rejected because the tip of your current branch is behind\n'
                                 'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                 'hint: \'git pull ...\') before pushing again.\n'
                                 'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))



# Generated at 2022-06-24 06:42:46.807260
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command(script='git push',
                                    output=' ! [rejected]\tdevelop -> develop (non-fast-forward)Updates were rejected because the tip of your current branch is behind its remote counterpart. Merge the remote changes (e.g. \'git pull\') before pushing again.')) == 'git pull && git push')

# Generated at 2022-06-24 06:42:56.433186
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', ''))
    assert match(Command('git push -f origin master', '', ''))

# Generated at 2022-06-24 06:43:05.227571
# Unit test for function match
def test_match():
    assert match(Cmd('git push',
                   'fatal: The current branch fix has no upstream branch.\n'
                   'To push the current branch and set the remote as upstream, use\n'
                   '\n'
                   '    git push --set-upstream origin fix\n',
                   'fuck'))


# Generated at 2022-06-24 06:43:13.558059
# Unit test for function match
def test_match():
    
    command_1 = Command("git push origin master", " ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to 'https://github.com/CynthiaGuo/fuck-git.git'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: 'git pull ...') before pushing again.\n hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n")
    assert match(command_1)
    

# Generated at 2022-06-24 06:43:15.278221
# Unit test for function get_new_command
def test_get_new_command():
    assert git_support(match, get_new_command)

# Generated at 2022-06-24 06:43:25.491165
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '')) == False
    assert match(Command('git push',
                         'failed to push some refs to')) == False
    assert match(Command('git push',
                         'failed to push some refs to\n'
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/test/test.git\'')) == False

# Generated at 2022-06-24 06:43:27.993847
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', '')
    assert get_new_command(command) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:43:39.057538
# Unit test for function match
def test_match():
    assert match(Command('git push',
        'remote: Rejecting non-fast-forward refs/heads/master\n'
        ' To some/remote/repo\n ! [rejected]        master -> master (non-fast-forward)\n'
        'error: failed to push some refs to some/remote/repo\n'
        'hint: Updates were rejected because the tip of your current branch is behind\n'
        'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
        'hint: `git pull ...`) before pushing again.\n'
        'hint: See the `Note about fast-forwards` in `git push --help` for details.'))

# Generated at 2022-06-24 06:43:46.140329
# Unit test for function match
def test_match():
    command = Command('git push', r"""
    remote: Permission to jht323/thefuck denied to mjb316.
    fatal: unable to access 'https://github.com/jht323/thefuck/':
    The requested URL returned error: 403
    """)
    assert match(command)


# Generated at 2022-06-24 06:43:56.696810
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '! [rejected] master -> master (non-fast-forward)\nfatal: The remote end hung up unexpectedly\nTo ssh://stash.int.seagate.com/scm/pdt/pdt.git\n ! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nTo ssh://stash.int.seagate.com/scm/pdt/pdt.git\n   8dabacd..f5b9a5b  master -> master\n'))

# Generated at 2022-06-24 06:44:02.961001
# Unit test for function match

# Generated at 2022-06-24 06:44:07.276538
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git push origin master',
                      output=' ! [rejected]        master -> master (fetch first)')
    new_command = get_new_command(command)
    assert new_command == shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-24 06:44:16.078637
# Unit test for function match
def test_match():
    assert match(Command(script="git push", output='! [rejected]        master -> master (non-fast-forward)\n'
                                                   'error: failed to push some refs to \'https://github.com/zhangyuanjing/sublime_setting.git\'\n'
                                                   'Updates were rejected because the tip of your current branch is behind\n'
                                                   'its remote counterpart. Integrate the remote changes (e.g.\n'
                                                   '\'git pull ...\') before pushing again.\n'
                                                   'See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:44:22.383973
# Unit test for function match
def test_match():
    assert match(Command('git push', "Everything up-to-date\n", ""))
    assert not match(Command('git push', "Everything up-to-date\n", ""))
    assert match(Command('git push', "To git@git.com:xyz.git\n! [rejected]\n",
                         ""))
    assert match(Command('git push', "To git@git.com:xyz.git\n! [rejected]\n",
                         "fatal: The current branch master has no upstream branch.\nTo push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n"))


# Generated at 2022-06-24 06:44:32.599707
# Unit test for function match
def test_match():
    assert_equal(match(Command('git push origin master', '')), False)

# Generated at 2022-06-24 06:44:39.647718
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
        'To git@github.com:nvbn/thefuck\n! [rejected]        master -> master (non-fast-forward)'
        '\nerror: failed to push some refs to\''
        '\'git@github.com:nvbn/thefuck\'\n'
        'hint: Updates were rejected because the tip of your current branch is behind'
        '\nhint: its remote counterpart. Integrate the remote changes (e.g.'
        '\nhint: \'git pull ...\') before pushing again.'
        '\nhint: See the \'Note about fast-forwards\''
        ' in \'git push --help\' for details.'))


# Generated at 2022-06-24 06:44:40.503576
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', ''))


# Generated at 2022-06-24 06:44:47.596590
# Unit test for function match
def test_match():
    assert not match(Command('git push', 'git push'))

# Generated at 2022-06-24 06:44:52.441252
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:44:54.493631
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master')) == Command(
        'git pull origin master && git push origin master')

# Generated at 2022-06-24 06:44:56.128443
# Unit test for function get_new_command
def test_get_new_command():
    _cmd = Command('git push')
    assert get_new_command(_cmd) == 'git pull'

enabled_by_default = True

# Generated at 2022-06-24 06:45:06.335570
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        pr/134 -> pr/134 (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@git.mywebsite.com:team/website.git\'\n'
                         'To prevent you from losing history, non-fast-forward updates were rejected\n'
                         'Merge the remote changes before pushing again.  See the \'Note about\n'
                         'fast-forwards\' section of \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:45:07.257172
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(None) == ['git pull', 'git push']

# Generated at 2022-06-24 06:45:20.351059
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'remote: ! [rejected]        master -> master (non-fast-forward)\n'
                         'To git@github.com:User/Repo.git\n'
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to "git@github.com:User/Repo.git"\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Merge the remote changes\n'
                         'hint: (e.g. "git pull") before pushing again.\n'
                         'hint: See the "Note about fast-forwards" in "git push --help" for details.')) is True

# Generated at 2022-06-24 06:45:24.800455
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin')) == 'git pull origin'

# Generated at 2022-06-24 06:45:32.638145
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/nvbn/thefuck.git\n! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n', ''))


# Generated at 2022-06-24 06:45:39.891848
# Unit test for function match
def test_match():
    assert match(Command('git push origin master:master',
                         '! [rejected]        master -> master '
                         '(non-fast-forward)',
                         'error: failed to push some refs to '
                         '\'git@github.com:ai-traders/django-pj-auth.git\'',
                         'To prevent you from losing history, non-fast-forward '
                         'updates were rejected',
                         'Merge the remote changes (e.g. \'git pull\') '
                         'before pushing again.',
                         'See the \'Note about fast-forwards\' section of '
                         '\'git push --help\' for details.'))
