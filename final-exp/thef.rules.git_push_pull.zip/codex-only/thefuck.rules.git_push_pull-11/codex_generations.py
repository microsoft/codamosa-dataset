

# Generated at 2022-06-24 06:35:41.708538
# Unit test for function get_new_command
def test_get_new_command():
    git_push_rejected = Command('git push origin master',
                                'remote: Permission to alice/repo.git denied to bob.\n'
                                'fatal: unable to access \'https://github.com/alice/repo.git/\': The requested URL returned error: 403')

    git_push_rejected_without_spaces = Command('git pushorigin master',
                                               'remote: Permission to alice/repo.git denied to bob.\n'
                                               'fatal: unable to access \'https://github.com/alice/repo.git/\': The requested URL returned error: 403')


# Generated at 2022-06-24 06:35:43.992310
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('push', '', ''))
            == shell.and_('pull', 'push'))

# Generated at 2022-06-24 06:35:47.930670
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull && git push origin master'
    assert get_new_command("git push origin master:other_branch") == 'git pull && git push origin master:other_branch'

# Generated at 2022-06-24 06:35:53.714238
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git push origin source',
                      output='To git@github.com:nvbn/thefuck.git\n ! [rejected]        source -> source (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nYou can repair this with git pull origin source')
    assert get_new_command(command) == 'git pull origin source && git push origin source'

# Generated at 2022-06-24 06:35:55.164752
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push", "") == "git pull"

# Generated at 2022-06-24 06:36:05.052990
# Unit test for function match
def test_match():
    command_output = "remote: error: GH001: Large files detected.\
                     remote: error: Trace: 7b90c9f9a00cff7e6b4b4ff8b6f3c5d7\
                     remote: error: See http://git.io/iEPt8g for more information.\
                     remote: error: File test.log is 52.80 MB; this exceeds GitHub's file size limit of 100.00 MB\
                     To https://github.com/user/repo.git ! [remote rejected] master -> master (pre-receive hook declined)\
                     error: failed to push some refs to 'https://github.com/user/repo.git'"
    command = Command('git push', command_output)
    assert match(command)



# Generated at 2022-06-24 06:36:11.798973
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == 'git pull && git push origin master'
    assert get_new_command(Command('git push', '')) == 'git pull && git push'

# Generated at 2022-06-24 06:36:13.327239
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull && git push'

# Generated at 2022-06-24 06:36:23.605152
# Unit test for function match
def test_match():
    assert not match(Command('git push origin master', '', '', 0))
    assert not match(Command('git push', '', '', 0))
    assert match(Command(
        'git push origin master',
        'To http://github.com/nvbn/thefuck\n ! [rejected]        master -> master (fetch first)\n error: failed to push some refs to \'http://github.com/nvbn/thefuck\'\n',
        '', 1))

# Generated at 2022-06-24 06:36:26.089978
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push origin master") == "git pull origin master"
    assert get_new_command("git push --tags") == "git pull --tags"
    assert get_new_command("git push origin master --force") == "git pull origin master --force"


# Generated at 2022-06-24 06:36:29.205853
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'
    assert (get_new_command('git push origin master').script ==
            'git pull && git push origin master')

# Generated at 2022-06-24 06:36:30.453480
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'

# Generated at 2022-06-24 06:36:33.947098
# Unit test for function match

# Generated at 2022-06-24 06:36:44.647592
# Unit test for function match
def test_match():
	from thefuck.rules.git_push_pull import match
	from thefuck.types import Command
	assert match(Command('git push',
		'''Failed with error: fatal: Couldn't find remote ref master
		hint: Updates were rejected because the remote contains work that you do not have locally.
		This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes,
		(e.g., 'git pull ...') before pushing again.'''))

# Generated at 2022-06-24 06:36:46.567357
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push','"failed to push')) == 'git pull && git push'

# Generated at 2022-06-24 06:36:56.401056
# Unit test for function match
def test_match():
    assert match(Command(script='git push origin master',
                         output='! [rejected]        master -> master (non-fast-forward)',
                         stderr='ERROR: Failed to push some refs to \'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\'\nhint: Updates were rejected because the tip of your current branch is behind'))
    assert match(Command(script='git push origin master',
                         output='! [rejected]        master -> master (non-fast-forward)',
                         stderr='ERROR: Failed to push some refs to \'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\'\nhint: Updates were rejected because the remote contains work that you do'))

# Generated at 2022-06-24 06:37:01.789455
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to'
                         ' \'https://github.com/CindyLinz/Hello-World.git\'',
                         'hint: Updates were rejected because the tip of your'
                         ' current branch is behind'))
    assert not match(Command('git push', 'Everything up-to-date'))



# Generated at 2022-06-24 06:37:05.485008
# Unit test for function get_new_command
def test_get_new_command():
    assert (match('git push origin master') and
            'git pull origin master' in get_new_command('git push origin master'))

    assert (not match('git pull origin master') and
            'git pull origin master' not in get_new_command('git pull origin master'))

# Generated at 2022-06-24 06:37:08.022638
# Unit test for function get_new_command
def test_get_new_command():
    assert(shell.and_('git pull', 'git push') == get_new_command('git push'))

# Generated at 2022-06-24 06:37:16.859099
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:ralphbean/pkgdb.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))


# Generated at 2022-06-24 06:37:19.328401
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git commit', output='[master 6d3a931] aaa',)
    assert get_new_command(command) == "git pull"

# Generated at 2022-06-24 06:37:20.720714
# Unit test for function get_new_command
def test_get_new_command():
    assert git.get_new_command("git push").script == "git pull && git push"

# Generated at 2022-06-24 06:37:30.865224
# Unit test for function match
def test_match():
    assert match(Command('git push', ""))
    assert match(Command('git push origin master', ""))
    assert match(Command('git push -f', ""))
    assert not match(Command('git push origin master', "", "", "", "", ""))
    assert not match(Command('git push', "! [rejected]"))
    assert not match(Command('git push', "! [rejected]", "", "", "", ""))
    assert not match(Command('git push', "! [rejected] failed to push some refs to"))
    assert not match(Command('git push', "! [rejected] failed to push some refs to", "", "", "", ""))

# Generated at 2022-06-24 06:37:33.773462
# Unit test for function match
def test_match():
    assert match(Command('git push origin master'))
    assert not match(Command('git push origin master', stderr='No error'))
    assert not match(Command('git push origin master', stderr='! [rejected]'))


# Generated at 2022-06-24 06:37:44.700377
# Unit test for function match
def test_match():
    assert match(Command("git push origin test:master", "! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to 'git@github.com:Thefuck/lfs-test-server.git'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart.", None))

# Generated at 2022-06-24 06:37:46.290610
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '', '', '')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:37:56.907350
# Unit test for function match
def test_match():
    assert match(Command("git push origin master",
                         "! [rejected]        master -> master (fetch first)\n"
                         "error: failed to push some refs to 'git@bitbucket.org:Infobip/ucc-backend.git'\n"
                         "hint: Updates were rejected because the remote contains work that you do\n"
                         "hint: not have locally. This is usually caused by another repository pushing\n"
                         "hint: to the same ref. You may want to first integrate the remote changes\n"
                         "hint: (e.g., 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n",
                         "git"), None, None) is not None

# Generated at 2022-06-24 06:38:07.129020
# Unit test for function match
def test_match():
    assert match(Command('git push', '', 'push some message\n'
                                         '! [rejected]        master -> master '
                                         '(non-fast-forward)\n'
                                         'error: failed to push some refs to '
                                         '\'upstream\'\n'
                                         'hint: Updates were rejected because '
                                         'the tip of your current branch is '
                                         'behind\n'
                                         'hint: its remote counterpart. '
                                         'Integrate the remote changes '
                                         '(e.g.\n'
                                         'hint: \'git pull ...\') before pushing '
                                         'again.\n'
                                         'hint: See the \'Note about fast-forwards\' '
                                         'in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:38:15.710595
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         (u"To https://github.com/nvbn/thefuck\n"
                          u" ! [rejected]        master -> master (non-fast-forward)\n"
                          u" error: failed to push some refs to 'https://github.com/nvbn/thefuck'\n"
                          u" hint: Updates were rejected because the tip of your current branch is behind\n"
                          u" hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                          u" hint: 'git pull ...') before pushing again.\n"
                          u" hint: See the 'Note about fast-forwards' in 'git push --help' for details."),
                         1))


# Generated at 2022-06-24 06:38:26.646632
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   '! [rejected]        master -> master (fetch first)\n'
                                   'error: failed to push some refs to \'git@github.com:<username>/<repo>.git\'')) == 'git pull && git push origin master'
    assert get_new_command(Command('git push',
                                   '! [rejected]        master -> master (fetch first)\n'
                                   'error: failed to push some refs to \'git@github.com:<username>/<repo>.git\'')) == 'git pull && git push'

# Generated at 2022-06-24 06:38:28.969515
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '', '! [rejected]        master -> master (non-fast-forward)', 1))


# Generated at 2022-06-24 06:38:37.832101
# Unit test for function match
def test_match():
    assert (match(Command('git push && echo hello', '\n! [rejected]        master -> master (non-fast-forward)\n'
                                                    'error: failed to push some refs to \'git@github.com:...\''
                                                    '\nTo prevent you from losing history, non-fast-forward '
                                                    'updates were rejected\nMerge the remote changes before '
                                                    'pushing again.  See the \'Note about fast-forwards\' section of \'git push --help\' for details.\nhello')) == True)

# Generated at 2022-06-24 06:38:47.749978
# Unit test for function match
def test_match():
    assert match(Command('git push origin master:master',
                         '! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'git@github.com:lalabuy948/fuck.git\'\n'
                         'hint: Updates were rejected because the tip of your'
                         ' current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote'
                         ' changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.\n'
                         '\n')) == True


# Generated at 2022-06-24 06:38:49.066726
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master && git push origin master'



# Generated at 2022-06-24 06:38:50.795279
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push master')) == '&& git pull master'

# Generated at 2022-06-24 06:38:52.007752
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('someting some| push') == 'someting some| pull'

# Generated at 2022-06-24 06:38:53.386528
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', '')
    assert get_new_command(command) == Command('git pull origin master', '')

# Generated at 2022-06-24 06:38:57.371685
# Unit test for function match
def test_match():
    assert match(Command('git push origin master'))
    assert match(Command('git push origin master', 
        output='! [rejected] master -> master (non-fast-forward)\n\
        error: failed to push some refs to \'https://github.com/isif/test\''))
    assert match(Command('git push origin master', 
        output='! [rejected]    master -> master (non-fast-forward)\n\
        error: failed to push some refs to \'https://github.com/isif/test\''))


# Generated at 2022-06-24 06:39:04.621839
# Unit test for function match
def test_match():
    output = '''error: failed to push some refs to 'ssh://git@somerepo.com'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''
    assert match('git push')
    assert match('git push', output) is not None
    assert match('git push', '') is None



# Generated at 2022-06-24 06:39:12.488908
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/rkyle/spacewalk.git\''
                         '\nhint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.'
                         '\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:39:14.000087
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push')
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-24 06:39:14.843197
# Unit test for function match

# Generated at 2022-06-24 06:39:17.055095
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master'))==shell.and_('git pull origin master','git push origin master')


# Generated at 2022-06-24 06:39:25.569803
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         " ! [rejected]        master -> master (fetch first)\n"
                         "error: failed to push some refs to "
                         "'https://example.com/repo.git'\n"
                         "hint: Updates were rejected because the remote "
                         "contains work that you do\n"
                         "hint: not have locally. This is usually caused by "
                         "another repository pushing\n"
                         "hint: to the same ref. You may want to first "
                         "integrate the remote changes\n"
                         "hint: (e.g., 'git pull ...') before pushing again."))



# Generated at 2022-06-24 06:39:34.376538
# Unit test for function match
def test_match():
    """ Test for function match() in thefuck.specific.git.py """
    good_match = git.GitRule()
    good_output = '''\
To https://github.com/BrunoCanella/zsh-completion.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/BrunoCanella/zsh-completion.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''
   

# Generated at 2022-06-24 06:39:39.028666
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   'Updates were rejected because the tip of your '
                                   'current branch is behind')) == shell.and_('git pull origin master', 'git push origin master')

    assert get_new_command(Command('git push origin master',
                                   'Updates were rejected because the remote '
                                   'contains work that you do')) == shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-24 06:39:40.026386
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull'


# Generated at 2022-06-24 06:39:43.353592
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '!'))
    assert match(Command('git push origin master', '', '!'))
    assert match(Command('git push --recurse', '', '!'))



# Generated at 2022-06-24 06:39:51.995217
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To git@gitserver:repo.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to:'
                         '''''To prevent you from losing history, non-fast-forward updates were rejected\nMerge the remote changes (e.g. '
                         ''''git pull) before pushing again.  See the \'Git Documentation\' for details.\n',
                         0))

# Generated at 2022-06-24 06:40:01.556421
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:shiyanhui2012/shiyanhui2012.github.io.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-24 06:40:11.873946
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push',
                                   stdout='''Updates were rejected
                                   because the remote contains work
                                   that you do not have locally.
                                   This is usually caused by another repository
                                   pushing to the same ref. You may want to
                                   first integrate the remote changes (e.g.,
                                   'git pull ...') before pushing again.
                                   See the 'Note about fast-forwards'
                                   in 'git push --help' for details.
                                   ''')) == 'git pull'

# Generated at 2022-06-24 06:40:18.223790
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push --set-upstream origin master', '')) == "git pull && git push --set-upstream origin master"
    assert get_new_command(
        Command('git push --set-upstream origin master', 'stash save')) == "git pull && git push --set-upstream origin master"
    assert get_new_command(
        Command('git push', '')) == "git pull && git push"


# Generated at 2022-06-24 06:40:28.083486
# Unit test for function match

# Generated at 2022-06-24 06:40:35.069538
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push origin master',
                                    '! [rejected] master -> master (fetch first)\n'
                                    'error: failed to push some refs to \'https://github.com/huydhn/test_thefuck_new\'\n'
                                    'hint: Updates were rejected because the tip of your current branch is behind\n'
                                    'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                    'hint: \'git pull ...\') before pushing again.\n'
                                    'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                                    ''))
            == shell.and_('git pull origin master', 'git push origin master'))


# Generated at 2022-06-24 06:40:42.872898
# Unit test for function match

# Generated at 2022-06-24 06:40:44.652385
# Unit test for function match
def test_match():
    assert match('git push')
    assert not match('git pull')
    assert not match('ls')


# Generated at 2022-06-24 06:40:51.458466
# Unit test for function match
def test_match():
    assert match(shell.FromString(
        'git push -u origin master ! [rejected] master -> master '
        '(non-fast-forward) hint: Updates were rejected because '
        'the tip of your current branch is behind hint: '
        'its remote counterpart. Integrate the remote changes '
        '(e.g. hint: git pull ...) before pushing again.'
    ))

    assert match(shell.FromString(
        'git push ! [rejected] master -> master (fetch first) hint: '
        'Updates were rejected because the remote contains work that you do '
        'hint: not have locally. This is usually caused by another repository '
        'hint: pushing to the same ref. You may want to first integrate the '
        'hint: remote changes (e.g., git pull ...) before pushing again.'
    ))

# Generated at 2022-06-24 06:41:01.937842
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', 'Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g. hint: \'git pull ...\') before pushing again.\nfatal: The current branch master has no upstream branch.\nTo push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n\n')
    assert get_new_command(command) == 'git pull && git push'


# Generated at 2022-06-24 06:41:03.296284
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '')) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:41:13.031285
# Unit test for function match
def test_match():
    assert match(Command('git push', 
        '! [rejected]        master -> master (non-fast-forward)\n'
        'error: failed to push some refs to \'git@github.com:louridas/git-up.git\'\n'
        'To prevent you from losing history, non-fast-forward updates were rejected\n'
        'Merge the remote changes (e.g. \'git pull\') before pushing again.  See the\n'
        '\'Note about fast-forwards\' section of \'git push --help\' for details.\n',
        0))


# Generated at 2022-06-24 06:41:21.915390
# Unit test for function match
def test_match():
    git_push_command = """git push --force origin master
                        To theirserver.com:theirrepository.git
                        ! [rejected]        master -> master (non-fast-forward)
                        error: failed to push some refs to 'theiresshurl'
                        hint: Updates were rejected because the tip of your current branch is behind
                        hint: its remote counterpart. Integrate the remote changes (e.g.
                        hint: 'git pull ...') before pushing again.
                        hint: See the 'Note about fast-forwards' in 'git push --help' for details."""

# Generated at 2022-06-24 06:41:28.090069
# Unit test for function match
def test_match():
    command = Command('git push')
    command.output = '''To git@github.com:nvbn/thefuck.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''
    assert(match(command) is True)
    
    command = Command('git push')

# Generated at 2022-06-24 06:41:32.581241
# Unit test for function get_new_command
def test_get_new_command():
    assert git.get_new_command(Command('git push',
                                       ' ! [rejected] master -> master (fetch first)')) == 'git pull'

    assert git.get_new_command(Command('git push',
                                       ' ! [rejected] master -> master (fetch first)')) == 'git pull'

# Generated at 2022-06-24 06:41:36.342810
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do'))
    assert match(Command('git push master', 'Updates were rejected because the tip of your current branch is behind'))
    assert not match(Command('git push master', 'Updates were rejected because the remote contains work that you do'))
    assert not match(Command('ls'))


# Generated at 2022-06-24 06:41:39.445674
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck import shells
    from thefuck.types import Command

    assert get_new_command(Command('git push', '', 'failed to push some refs')) == \
           shells.and_('git pull', 'git push')

# Generated at 2022-06-24 06:41:49.692106
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (fetch first)'
                         '\n'
                         'error: failed to push some refs to '
                         '\'git@github.com:nvbn/thefuck\''))
    assert match(Command('git commit',
                         '! [rejected]        master -> master (fetch first)'
                         '\n'
                         'error: failed to push some refs to '
                         '\'git@github.com:nvbn/thefuck\''))
    assert not match(Command('git commit',
                             'haha (fetch first)'
                             '\n'
                             'error: failed to push some refs to '
                             '\'git@github.com:nvbn/thefuck\''))


# Generated at 2022-06-24 06:41:59.825388
# Unit test for function match
def test_match():
    assert match(Command('git push',
              'To https://github.com/fuck\n! [rejected]   master -> master (fetch first)\nerror: failed to push some refs to \'https://github.com/fuck\'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
              'https://github.com/fuck'))



# Generated at 2022-06-24 06:42:01.411712
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) \
            == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:42:10.210459
# Unit test for function match
def test_match():
    assert match(Command('git push f',
                         ' ! [rejected]'
                         ' failed to push some refs to',
                         'Updates were rejected because the tip'
                         ' of your current branch is behind'))
    assert match(Command('git push',
                         ' ! [rejected]'
                         ' failed to push some refs to',
                         'Updates were rejected because the tip'
                         ' of your current branch is behind'))
    assert match(Command('git push',
                         ' ! [rejected] '
                         ' failed to push some refs to',
                         'Updates were rejected because the remote'
                         ' contains work that you do'))



# Generated at 2022-06-24 06:42:19.514082
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         "To https://github.com/lzana/thefuck.git ! [rejected]\n    master -> master (non-fast-forward)\n\nUpdates were rejected because the tip of your current branch is behind\nfatal: The remote end hung up unexpectedly\n",
                         "", 1, None))
    assert match(Command('git push origin master',
                         "To https://github.com/lzana/thefuck.git ! [rejected]\n    master -> master (non-fast-forward)\n\nUpdates were rejected because the remote contains work that you do\nfatal: The remote end hung up unexpectedly\n",
                         "", 1, None))

# Generated at 2022-06-24 06:42:26.617533
# Unit test for function get_new_command
def test_get_new_command():
    assert GitPushFailed.get_new_command(Command('git push', 'git push origin master', 'To https://github.com/User/Project.git ! [rejected]\nfailed to push some refs to (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nUpdates were rejected because the remote contains work that you do\n'))==shell.and_(replace_argument('git push', 'push', 'pull'),'git push')

# Generated at 2022-06-24 06:42:36.359526
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', 'error: failed to push some refs to \'http://example.com/repo.git/\'\nhint: Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push origin master', '', 'error: failed to push some refs to \'http://example.com/repo.git/\'\nhint: Updates were rejected because the tip of your current branch is behind'))
    assert not match(Command('git push origin master', '', 'everything up-to-date'))
    assert not match(Command('git push origin maste', '', 'error: failed to push some refs to \'http://example.com/repo.git/\'\nhint: Updates were rejected because the tip of your current branch is behind'))

# Generated at 2022-06-24 06:42:40.374791
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_push import get_new_command
    assert get_new_command('git push').script == 'git pull && git push'
    assert get_new_command('git push origin master').script == 'git pull && git push origin master'


enabled_by_default = True

# Generated at 2022-06-24 06:42:44.913938
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push --set-upstream origin master') == 'git pull --set-upstream origin master && git push --set-upstream origin master'
    assert get_new_command('git push origin master') == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:42:55.284973
# Unit test for function match
def test_match():
    assert moshez_match.match(Command('git push origin master', '', '', 0))
    assert moshez_match.match(Command('git push origin blah', '', '', 0))
    assert moshez_match.match(Command('git push origin master', '', '', 0))
    assert moshez_match.match(Command('git push origin master', '', '', 0))
    assert moshez_match.match(Command('git push origin master', '', '', 0))
    #assert moshez_match.match(Command('git push origin master', '', '', 0))
    assert not moshez_match.match(Command('git push origin master', '', '', 0))
    assert not moshez_match.match(Command('git push oigin master', '', '', 0))

# Generated at 2022-06-24 06:43:00.467842
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '...')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:43:05.467024
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '''
To https://github.com/nvbn/thefuck.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''', 'git push origin master'))

# Generated at 2022-06-24 06:43:13.760145
# Unit test for function match
def test_match():
	assert match(Command('git push origin master', 
		'To https://github.com/xzhou1009/test.git\n ! [rejected]        master -> master\n ' 
		'error: failed to push some refs to \'https://github.com/xzhou1009/test.git\'\n'
		'hint: Updates were rejected because the tip of your current branch is behind\n'
		'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
		'hint: \'git pull ...\') before pushing again.\n'
		'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n', '')) == True

# Generated at 2022-06-24 06:43:23.426957
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 'error: failed to push some refs to'))
    assert match(Command('git push origin master', 'error: failed to push some refs to', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push origin master', 'error: failed to push some refs to', 'Updates were rejected because the remote contains work that you do'))
    assert not match(Command('git push origin master', 'error: failed to push some refs to', 'The remote end hung up unexpectedly'))
    assert not match(Command('git push origin master', 'error: failed to push some refs to', 'fatal: The remote end hung up unexpectedly'))

# Generated at 2022-06-24 06:43:25.972284
# Unit test for function match
def test_match():
    assert git_push('git push -f').match(git_push('here'))
    assert not git_push('git pull').match(git_push('here'))


# Generated at 2022-06-24 06:43:37.534779
# Unit test for function get_new_command

# Generated at 2022-06-24 06:43:38.434672
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('git push') == 'git pull'

# Generated at 2022-06-24 06:43:40.267741
# Unit test for function get_new_command
def test_get_new_command():
    command.script = 'git push'
    assert get_new_command(command) == 'eval `thefuck --alias` && git pull && git push'


# Generated at 2022-06-24 06:43:47.184053
# Unit test for function get_new_command

# Generated at 2022-06-24 06:43:49.689003
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:43:58.706853
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin test')
    output = '''
To https://github.com/nvbn/thefuck.git
 ! [rejected]        test -> test (non-fast-forward)
error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''
    assert get_new_command(Command(command.script, output, command.stderr)) == (
        'git pull origin test && git push origin test')

# Generated at 2022-06-24 06:44:09.986568
# Unit test for function match
def test_match():
    assert match(Command(script='git push origin master',
                         output="! [rejected] master -> master "
                         "(non-fast-forward)\nTo https://github.com/nvbn/thefuck.git\n"
                         " ! [rejected] master -> master (non-fast-forward)\n"
                         "error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'\n"
                         "hint: Updates were rejected because the tip of your current branch is\n"
                         "hint: behind its remote counterpart. Integrate the remote changes\n"
                         "hint: (e.g. hint: 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n"))

#

# Generated at 2022-06-24 06:44:20.707628
# Unit test for function match
def test_match():
    assert match(Command(script='git push',
                         output='! [rejected] master -> master (non-fast-forward)\n'
                                'error: failed to push some refs to \'git@github.com:rishabh-bansal/thefuck.git\''))
    assert match(Command(script='git push',
                         output='To git@github.com:rishabh-bansal/thefuck.git\n ! [rejected]        master -> master (non-fast-forward)\n'
                                'error: failed to push some refs to \'git@github.com:rishabh-bansal/thefuck.git\''))

# Generated at 2022-06-24 06:44:23.488766
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin', '', '', '', 0, '')
    assert (get_new_command(command) == 'git pull origin && git push origin')

# Generated at 2022-06-24 06:44:33.118725
# Unit test for function match
def test_match():
    # Test 1: The proper output
    script = 'git push'
    output = 'To https://github.com/eldanny/thefuck.git\n ! [rejected]        master -> master (fetch first)\n error: failed to push some refs to \'https://github.com/eldanny/thefuck.git\'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., \'git pull ...\') before pushing again.'
    command = Command(script, output)
    assert match(command)

    # Test 2: Test for when the tip is behind the remote
    script = 'git push'

# Generated at 2022-06-24 06:44:35.297526
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git push',
                      output='! [rejected]        master -> master (non-fast-forward)')
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-24 06:44:41.470731
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:is-a-developer/my-repo.git\'\n'
                         'hint: Updates were rejected because the tip of your current branc\n'
                         'hint: is behind its remote counterpart. Integrate the remote changes\n'
                         'hint: (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:44:50.793910
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/aditya-mittal/git-test.git\n ! [rejected]        master -> master (fetch first)\n error: failed to push some refs to \'https://github.com/aditya-mittal/git-test.git\'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
                         '')) == True


# Generated at 2022-06-24 06:45:00.474661
# Unit test for function match

# Generated at 2022-06-24 06:45:09.116198
# Unit test for function match
def test_match():
    # Test for a command which should return a function
    command = Command(script = 'git push origin master',
                      stderr = ' ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:xxx/xxx.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert match(command)

    # Test for a command which should return a function

# Generated at 2022-06-24 06:45:20.859693
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin branch1 branch2 branch3', '',
                      '! [rejected]        branch1 -> branch1 (non-fast-forward)\n\
! [rejected]        branch2 -> branch2 (non-fast-forward)\n\
! [rejected]        branch3 -> branch3 (non-fast-forward)\n\
error: failed to push some refs to \
\'https://github.com/something/something.git\'\n\
hint: Updates were rejected because the tip of your current branch is behind\n\
hint: its remote counterpart. Integrate the remote changes (e.g.\n\
hint: \'git pull ...\') before pushing again.\n\
hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'
)

# Generated at 2022-06-24 06:45:28.447966
# Unit test for function get_new_command
def test_get_new_command():

    script_1 = 'git push'
    command_1 = type('Command', (object,), {'script': script_1, 'output': ''})
    output_1 = get_new_command(command_1)
    assert (output_1 == 'git pull && git push')

    script_2 = 'git push origin master'
    command_2 = type('Command', (object,), {'script': script_2, 'output': ''})
    output_2 = get_new_command(command_2)
    assert (output_2 == 'git pull origin master && git push origin master')

# Generated at 2022-06-24 06:45:37.202496
# Unit test for function match