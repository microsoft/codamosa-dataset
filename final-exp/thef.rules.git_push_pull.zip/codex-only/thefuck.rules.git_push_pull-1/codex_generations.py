

# Generated at 2022-06-24 06:35:36.393688
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git push'
    command = Command(script, '')
    assert get_new_command(command) == 'git pull && git push'


# Generated at 2022-06-24 06:35:47.051741
# Unit test for function get_new_command

# Generated at 2022-06-24 06:35:57.399744
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '! [rejected] master -> master (non-fast-forward)\nTo prevent you from losing history, non-fast-forward updates were rejected\nMerge the remote changes (e.g. \'git pull\') before pushing again\n'))
    assert not match(Command('git push foo', '! [rejected] foo -> foo (non-fast-forward)', ''))
    assert not match(Command('git push foo', '! [rejected] foo -> foo (non-fast-forward)\nTo prevent you from losing history, non-fast-forward updates were rejected\nMerge the remote changes (e.g. \'git pull\') before pushing again\n', ''))

# Generated at 2022-06-24 06:36:02.558904
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push -f') == 'git pull -f && git push -f'

# Generated at 2022-06-24 06:36:07.475102
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nupdates were rejected because the remote contains work that you do\n')) == 'git pull && git push'

# Generated at 2022-06-24 06:36:19.031197
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/sole/dotfiles.git\n ! [rejected]      master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/sole/dotfiles.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:36:20.567740
# Unit test for function get_new_command

# Generated at 2022-06-24 06:36:29.086547
# Unit test for function get_new_command
def test_get_new_command():
    # Successful test: git push command
    assert get_new_command(Command('git push origin master', '! [rejected] master -> master (fetch first)\n')) == 'git pull && git push origin master'
    # Failed test: push command not in script
    assert get_new_command(Command('git pull origin master', '! [rejected] master -> master (fetch first)\n')) == ''

# Generated at 2022-06-24 06:36:31.002564
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command("git push", "something something push rejected")) in ['git pull', 'pull']
	

# Generated at 2022-06-24 06:36:35.122896
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push origin master", "$GIT_PUSH_ORIGIN_MASTER")
    assert get_new_command(command) == "git pull origin master && $GIT_PUSH_ORIGIN_MASTER"

# Generated at 2022-06-24 06:36:45.488649
# Unit test for function match

# Generated at 2022-06-24 06:36:52.341786
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.specific.git import git_support
    new_command = git_support(get_new_command)
    assert new_command
    assert new_command(Command('git push',
                               'Updates were rejected because the tip of '
                               'your current branch is behind')) == 'git pull && git push'
    assert new_command(Command('git push',
                               'Updates were rejected because the remote '
                               'contains work that you do')) == 'git pull && git push'

# Generated at 2022-06-24 06:36:56.079261
# Unit test for function match
def test_match():
    assert match(Command("git push", "The tip of your current branch is "
                         "behind its remote counterpart. Integrate the "
                         "remote changes before pushing again."))
    assert not match(Command("git push", ""))
    assert match(Command("git push", "Updates were rejected because the "
                         "remote contains work that you do not have locally."))
    assert match(Command("git push", "Updates were rejected because the tip"
                         " of your current branch is behind."))

# Generated at 2022-06-24 06:36:57.891905
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push origin master")
    assert get_new_command(command) == "git pull origin master && git push origin master"

# Generated at 2022-06-24 06:37:08.235478
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '''To https://github.com/user/repo.git
! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/user/repo.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''))

# Generated at 2022-06-24 06:37:17.000120
# Unit test for function get_new_command
def test_get_new_command():
    script_1 = "git push g1"
    script_2 = "git push g2"
    output_1 = """Updates were rejected because the tip of your current branch is behind
its remote counterpart. Integrate the remote changes (e.g.
    'git pull ...') before pushing again."""
    output_2 = """Updates were rejected because the remote contains work that you do
n't have locally. This is usually caused by another repository pushing
to the same ref. You may want to first integrate the remote changes
(e.g., 'git pull ...') before pushing again."""
    command_1 = Command(script_1, output_1)
    command_2 = Command(script_2, output_2)
    assert get_new_command(command_1) == 'git pull g1 && git push g1'
    assert get_new_command

# Generated at 2022-06-24 06:37:26.879003
# Unit test for function match
def test_match():
    assert match(get_mock_command('git push origin master', 
        ' ! [rejected]        master -> master (non-fast-forward)',
        'error: failed to push some refs to \'git@github.com:qinjx/fuck.git\'',
        'hint: Updates were rejected because the tip of your current branch is behind',
        'hint: its remote counterpart. Integrate the remote changes (e.g.',
        'hint: \'git pull ...\') before pushing again.',
        'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:37:32.633864
# Unit test for function get_new_command

# Generated at 2022-06-24 06:37:39.918164
# Unit test for function get_new_command

# Generated at 2022-06-24 06:37:42.811766
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull && git push origin master'

# Generated at 2022-06-24 06:37:52.346669
# Unit test for function match
def test_match():
    command = Command(script='git push origin master', stderr='''
To git@github.com:nviennot/dotfiles.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'git@github.com:nviennot/dotfiles.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
    ''')
    assert match(command) == True


# Generated at 2022-06-24 06:37:56.860513
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import shell
    from thefuck import types
    script = types.Command('git push',
                           '! [rejected] master -> master '
                           '(fetch first)\n')
    assert get_new_command(script) == shell.and_('git pull', 'git push')


# Generated at 2022-06-24 06:38:07.130227
# Unit test for function match
def test_match():
    command = Command(script='git push', output="""
    error: failed to push some refs to 'git@server:td/tdd.git'
    hint: Updates were rejected because the remote contains work that you do
    hint: not have locally. This is usually caused by another repository pushing
    hint: to the same ref. You may want to first integrate the remote changes
    hint: (e.g., 'git pull ...') before pushing again.
    hint: See the 'Note about fast-forwards' in 'git push --help' for details.""")
    assert match(command)

# Generated at 2022-06-24 06:38:14.495053
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (fetch first)',
                         'error: failed to push some refs to \'git@somegithost:bleh.git\'',
                         'hint: Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to \'git@somegithost:bleh.git\'',
                         'hint: Updates were rejected because the remote contains work that you do'))

# Generated at 2022-06-24 06:38:25.666507
# Unit test for function match

# Generated at 2022-06-24 06:38:34.645333
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ''))
    assert match(Command('git push',
                         '! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to\n'
                         '\'git@gitlab.com:JuStWaNnAdOiT/thefuck.git\'\n'
                         'Updates were rejected because the tip of '
                         'your current branch is behind\n'
                         'its remote counterpart. Integrate the remote changes '
                         '(e.g.\n\'git pull ...\') before pushing again.\n'
                         'See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))

# Generated at 2022-06-24 06:38:41.081008
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 1, None))
    assert match(Command('git push', '', '', 1, None))
    assert match(Command('git push origin', '', '', 1, None))
    assert match(Command('git push --force', '', '', 1, None))
    assert match(Command('git push --dry-run', '', '', 1, None))
    assert not match(Command('git pull', '', '', 1, None))


# Generated at 2022-06-24 06:38:45.023555
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do not have locally'))
    assert not match(Command('git pull', 'Updates were rejected because the tip of your current branch is behind'))

# Generated at 2022-06-24 06:38:46.910781
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git commit & git push origin master')) == 'git commit; git pull origin master'

# Generated at 2022-06-24 06:38:53.555203
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:egarayc/pyco.git\'\n'
                         'To prevent you from losing history, non-fast-forward updates were rejected\n'
                         'Merge the remote changes (e.g. \'git pull\') before pushing again.  See the\n'
                         '\'Note about fast-forwards\' section of \'git push --help\' for details.'))
    assert not match(Command('git push origin master',
                             'To git@github.com:egarayc/pyco.git\n'
                             '   fc31f63..942eba9  master -> master'))

# Generated at 2022-06-24 06:39:03.174792
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to \'git@github.com:'
                         'user/repo.git\'',
                         'hint: Updates were rejected because the tip of your'
                         ' current branch is behind',
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.',
                         'hint: \'git pull ...\') before pushing again.',
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))

# Generated at 2022-06-24 06:39:10.321785
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To https://github.com/thefuck/thefuck.git\n ! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to \'https://github.com/thefuck/thefuck.git\'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

    assert not match(Command('git stash', 'No local changes to save'))



# Generated at 2022-06-24 06:39:13.792608
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = 'git pull --recurse-submodules=check',
                      output = '! [rejected] master -> master (non-fast-forward)')
    assert get_new_command(command) == 'git pull --recurse-submodules=check && git pull --recurse-submodules=check'


# Generated at 2022-06-24 06:39:22.797762
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected] master -> master (non-fast-forward)\n'
                         ' error: failed to push some refs to '
                         '\'git@github.com:fuck.git\'\n'
                         ' hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         ' hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\n'
                         ' hint: \'git pull ...\') before pushing again.\n'
                         ' hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.',
                         '', 2))
    assert not match(Command('git pull origin master', '', '', 0))

# Generated at 2022-06-24 06:39:32.271801
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         "! [rejected]        master -> master (fetch first)\n"
                         "error: failed to push some refs to 'https://github.com/TheFuck/thefuck.git'\n"
                         "hint: Updates were rejected because the remote contains work that you do\n"
                         "hint: not have locally. This is usually caused by another repository pushing\n"
                         "hint: to the same ref. You may want to first integrate the remote changes\n"
                         "hint: (e.g., 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in 'git push --help' for details."))


# Generated at 2022-06-24 06:39:39.736465
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected] master'
                                     ' -> master (fetch first)', ''))
    assert match(Command('git push', 'Total 0 (delta 0), reused 0 (delta 0)'
                                     '\n! [rejected] master -> master '
                                     '(non-fast-forward)'
                                     '\nerror: failed to push some refs'
                                     " to 'https://github.com/123456'", ''))

# Generated at 2022-06-24 06:39:49.988674
# Unit test for function match
def test_match():
    assert match(Command("git push", "remote: Permission to user/repo.git denied to user.\nfatal: unable to access 'https://github.com/user/repo/': The requested URL returned error: 403"))
    assert match(Command("git push", "\n! [rejected]        dev -> dev (fetch first)\nerror: failed to push some refs to '../user_repo'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.\n"))

# Generated at 2022-06-24 06:39:51.365564
# Unit test for function match
def test_match():
    command = Command('git push')
    assert match(command)



# Generated at 2022-06-24 06:39:52.767817
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script=='git pull'

# Generated at 2022-06-24 06:39:55.366920
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', '')
    assert(get_new_command(command) ==  "git pull origin master && git push origin master")

# Generated at 2022-06-24 06:39:59.746807
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(create_command('git push origin master')) == 'git pull && git push origin master'


# Generated at 2022-06-24 06:40:04.244805
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script': 'git push origin master', 'output': 'myoutput'})
    assert get_new_command(command) == 'git pull && git push origin master'


enabled_by_default = True

# Generated at 2022-06-24 06:40:12.430036
# Unit test for function match
def test_match():
    command = "error: failed to push some refs to 'https://github.com/tools/godep.git'"
    assert not match(Command(script=command))

    command = "error: failed to push some refs to 'https://github.com/tools/godep.git'"
    command += "Updates were rejected because the tip of your current branch is behind"
    assert match(Command(command, '', 0))

    command = "error: failed to push some refs to 'https://github.com/tools/godep.git'"
    command += "Updates were rejected because the remote contains work that you do"
    assert match(Command(command, '', 0))


# Generated at 2022-06-24 06:40:21.381693
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', '', '''! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/tyiannak/pyAudioAnalysis'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.''')) ==
            '''&& git pull && git push''')

# Generated at 2022-06-24 06:40:30.913616
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'git@example.com:username/test.git\'\n'
                         'To prevent you from losing history, non-fast-forward '
                         'updates were rejected\n'
                         'Merge the remote changes (e.g. \'git pull\') '
                         'before pushing again.  See the \'Note about\n'
                         'fast-forwards\' section of \'git push --help\' '
                         'for details.\n'))

# Generated at 2022-06-24 06:40:41.139162
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '', 1, '! [rejected]        master -> master (fetch first)\n'
                                              'error: failed to push some refs to '
                                              '\'https://github.com/shenxm/practice.git\'\n'
                                              'hint: Updates were rejected because the remote contains work that you do\n'
                                              'hint: not have locally. This is usually caused by another repository pushing\n'
                                              'hint: to the same ref. You may want to first integrate the remote changes\n'
                                              'hint: (e.g., \'git pull ...\') before pushing again.\n'
                                              'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.', 1))



# Generated at 2022-06-24 06:40:50.617618
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'Updates were rejected because the tip of your current branch is behind its remote counterpart. Merge the remote changes (e.g. \'git pull\') before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.\n')) == shell.and_('git pull', 'git push')
    assert get_new_command(Command('git push', 'Updates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g., \'git pull ...\') before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.\n')) == shell.and_('git pull', 'git push')

# Generated at 2022-06-24 06:41:01.108372
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git push origin master',
                                   '! [rejected]        master -> master (non-fast-forward)\n'
                                   'error: failed to push some refs to \'git@github.com:vog/thefuck.git\'\n'
                                   'To prevent you from losing history, non-fast-forward updates were rejected\n'
                                   'Merge the remote changes (e.g. \'git pull\') before pushing again.  See the\n'
                                   '\'Note about fast-forwards\' section of \'git push --help\' for details.')) == \
                     'git pull && git push origin master'


# Generated at 2022-06-24 06:41:08.449361
# Unit test for function match
def test_match():
    assert match(Command('push', 'failed to push some refs to',
            'To https://github.com/USER/PROJECT.git\n'
            '! [rejected]        master -> master (fetch first)\n'
            'error: failed to push some refs to '
            '\'https://github.com/USER/PROJECT.git\'\n'
            'hint: Updates were rejected because the remote contains work '
            'that you do\n'
            'hint: not have locally. This is usually caused by another '
            'repository pushing\n'
            'hint: to the same ref. You may want to first integrate the '
            'remote changes\n'
            'hint: (e.g., \'git pull ...\') before pushing again.'))

# Generated at 2022-06-24 06:41:12.566816
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull'

# Generated at 2022-06-24 06:41:15.678290
# Unit test for function get_new_command
def test_get_new_command():
    generated_command = "git pull && ./push.sh"
    assert get_new_command(Command(script="git push && ./push.sh",
                                   stdout="[Updates were rejected because the tip of your current branch is behind]")) == generated_command

# Generated at 2022-06-24 06:41:24.702425
# Unit test for function get_new_command
def test_get_new_command():
    output = '''
 ! [rejected]        master     -> master 
 (fetch first)
 error: failed to push some refs to 'https://github.com/user/repo.git'
 hint: Updates were rejected because the tip of your current branch is behind
 hint: its remote counterpart. Integrate the remote changes (e.g.
 hint: 'git pull ...') before pushing again.
 hint: See the 'Note about fast-forwards' in 'git push --help' for details.
 '''

    script = "git push origin master"

    assert get_new_command(Command(script, output)) == script.replace(
        'push', 'pull') + ' &&' + script


# Generated at 2022-06-24 06:41:26.107949
# Unit test for function match
def test_match():
	assert match(Command ("git push -u origin master"))


# Generated at 2022-06-24 06:41:28.536380
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(['./test/julio']) == shell.and_('pull', './test/julio')



# Generated at 2022-06-24 06:41:30.953956
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(command=Command('git push', '', '', '', ''),
                                  settings={})
    assert match(command=Command('git push', '', '', '', ''))
    assert new_command == "git pull && git push"

# Generated at 2022-06-24 06:41:36.268864
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push origin master", "")
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:41:38.315812
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', 0)) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:41:43.926312
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'Updates were rejected because the tip of your '
                         'current branch is behind its remote counterpart. '
                         'Integrate remote changes before pushing again.',
                         '', 0))
    assert match(Command('git push',
                         'Updates were rejected because the remote contains '
                         'work that you do not have locally. This is usually '
                         'caused by another repository pushing to the same '
                         'ref. You may want to first integrate the remote '
                         'changes before pushing again.',
                         '', 0))
    assert not match(Command('ls',
                             '',
                             '', 0))
    assert not match(Command('git push ',
                             'Everything up-to-date',
                             '', 0))


# Generated at 2022-06-24 06:41:51.546041
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@example.com:mm/myproject.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))


# Generated at 2022-06-24 06:41:56.712033
# Unit test for function get_new_command
def test_get_new_command():
    _get_new_command = get_new_command
    assert _get_new_command(Command('git push', '', '', 0)) == 'git pull'
    assert _get_new_command(Command('git push -f',
                                    '',
                                    '',
                                    0)) == 'git pull -f'


# Generated at 2022-06-24 06:42:03.855758
# Unit test for function get_new_command
def test_get_new_command():
    # Matching command
    command = Command('git push origin master', '! [rejected] master -> master (fetch first)\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

    # Non-matching command
    command = Command('git status', '')
    assert get_new_command(command) is None

# Generated at 2022-06-24 06:42:14.088398
# Unit test for function match
def test_match():
    match_1 = 'git push'
    match_2 = 'git push -u origin master'
    match_3 = 'git push --set-upstream origin master'
    match_4 = 'git push -f'
    match_5 = 'git push origin master'
    match_6 = 'git push origin'
    match_7 = 'git push --all'
    match_8 = 'git push --tags'
    match_9 = 'git push -f'
    match_10 = 'git push origin master:local'
    match_11 = 'git push origin master --force'
    match_12 = 'git push origin --force'
    match_13 = 'git push origin --force master'
    match_14 = 'git push origin branch'
    match_15 = 'git push origin branch --force'

# Generated at 2022-06-24 06:42:21.412765
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master').script == 'git pull && git push origin master'
    assert get_new_command('git push origin').script == 'git pull && git push origin'
    assert get_new_command('git push').script == 'git pull && git push'
    assert get_new_command('git push origin --force').script == 'git pull && git push origin --force'
    assert get_new_command('git push origin master -f').script == 'git pull && git push origin master -f'
    assert get_new_command('git push origin master -force').script == 'git pull && git push origin master -force'
    assert get_new_command('git push origin master --force').script == 'git pull && git push origin master --force'

# Generated at 2022-06-24 06:42:32.167675
# Unit test for function match
def test_match():
    assert match(Command('git push', ' ! [rejected]        master -> master (non-fast-forward)\n'
                                        'error: failed to push some refs to \'git@git.git\'\n'
                                        'hint: Updates were rejected because the tip of your current branch is behind\n'
                                        'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                        'hint: \'git pull ...\') before pushing again.\n'
                                        'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:42:42.840260
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', "fatal: 'origin' does not appear to be a git repository\nfatal: Could not read from remote repository.\n\nPlease make sure you have the correct access rights\nand the repository exists.")) == '&& git pull'

# Generated at 2022-06-24 06:42:47.698819
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', 'Updates were rejected because the tip of your current branch is behind')) == 'git pull && git push'
    assert get_new_command(Command('git push -n', '', 'Updates were rejected because the remote contains work that you do')) == 'git pull -n && git push -n'

# Generated at 2022-06-24 06:42:53.237431
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_push_rejected import get_new_command
    command = 'git push -f'
    assert get_new_command([command, 'remote: error: refusing to update'
                ' checked out branch: refs/heads/master [rejected]',
                'To ssh://github.com/nvbn/thefuck']) == 'git pull -f && git push -f'

# Generated at 2022-06-24 06:42:55.743326
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(get_command('git push')) == shell.and_('git pull', 'git push')

# Generated at 2022-06-24 06:43:00.508740
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == shell.and_('git pull', 'git push')

# Generated at 2022-06-24 06:43:05.494029
# Unit test for function match
def test_match():
    # Test for git
    assert match(Command('git push',
            'To git@github.com:nvbn/thefuck.git ! [rejected] master -> master (fetch first)\n'
            'error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n'
            'hint: Updates were rejected because the tip of your current branch is behind\n'
            'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
            'hint: \'git pull ...\') before pushing again.\n'
            'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
            ''))

    # Test for git with space

# Generated at 2022-06-24 06:43:10.219891
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == ('git pull & git push origin master', '')
    assert get_new_command(Command('git push origin master', '! [rejected]        master -> master (non-fast-forward)\n')) == ('git pull & git push origin master', '! [rejected]        master -> master (non-fast-forward)\n')


# Generated at 2022-06-24 06:43:17.877606
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         "To git@github.com:nvbn/thefuck.git\n ! [rejected] "
                         "master -> master (non-fast-forward)\n"
                         "error: failed to push some refs to "
                         "'git@github.com:nvbn/thefuck.git'\n"
                         "hint: Updates were rejected because the tip of "
                         "your current branch is behind\n"
                         "hint: its remote counterpart. Integrate the remote "
                         "changes (e.g.\n"
                         "hint: 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in "
                         "'git push --help' for details.\n"))


# Generated at 2022-06-24 06:43:25.243694
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:...:...\'\n'
                         'To prevent you from losing history, non-fast-forward updates were rejected\n'
                         'Merge the remote changes (e.g. \'git pull\') before pushing again.  See\n'
                         'the \'Note about fast-forwards\' section of \'git push --help\' for details.',
                         '', 1, 3))



# Generated at 2022-06-24 06:43:37.085702
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'error: failed to push some refs to '
                         "'ssh://user@domain.com/~/projects/test.git'"
                         ' ! [rejected] master -> master '
                         '(non-fast-forward) error: failed to push '
                         'some refs to '
                         "'ssh://user@domain.com/~/projects/test.git'"
                         ' hint: Updates were rejected because the tip of '
                         'your current branch is behind hint: its remote '
                         'counterpart. Integrate the remote changes '
                         '(e.g. hint: \'git pull ...\') before pushing again.'
                         ' hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))

# Generated at 2022-06-24 06:43:43.877693
# Unit test for function match
def test_match():
    # Push command which rejects the push attempt due to
    # outdated local changes.
    test_command = Command('git push origin master',
    '''
    To https://github.com/roxanar/thefuck-test.git
     ! [rejected]        master -> master (fetch first)
     error: failed to push some refs to 'https://github.com/roxanar/thefuck-test.git'
     hint: Updates were rejected because the remote contains work that you do
     hint: not have locally. This is usually caused by another repository pushing
     hint: to the same ref. You may want to first integrate the remote changes
     hint: (e.g., 'git pull ...') before pushing again.
     hint: See the 'Note about fast-forwards' in 'git push --help' for details.
    ''')

    assert match

# Generated at 2022-06-24 06:43:45.434940
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git push', 'git pull')) == 'git pull'

# Generated at 2022-06-24 06:43:52.541547
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (fetch first)'))
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)'))
    assert match(Command('git push origin master',
                         'Updates were rejected because the tip of your'
                         ' current branch is behind',
                         'Updates were rejected because the remote '
                         'contains work that you do'))
    assert not match(Command('git push origin master', "Everything up-to-date"))



# Generated at 2022-06-24 06:44:01.036975
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'Updates were rejected because the tip of your '
                         'current branch is behind its remote '
                         'counterpart. Integrate the remote changes '
                         '(e.g.\n'
                         '        git pull ...)\n'
                         'before pushing again.\n'
                         'See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.\n'))


# Generated at 2022-06-24 06:44:12.532792
# Unit test for function match
def test_match():
    user_input = [
        'git push',
        'git push origin master'
    ]
    output = [
        'To https://github.com/rupa/z',
        '! [rejected]        master -> master (non-fast-forward)',
        'error: failed to push some refs to '
        '\'https://github.com/rupa/z\'',
        'hint: Updates were rejected because the tip of your '
        'current branch is behind',
        'hint: its remote counterpart. Integrate the remote changes '
        '(e.g.',
        'hint: \'git pull ...\') before pushing again.',
        'hint: See the \'Note about fast-forwards\' in '
        '\'git push --help\' for details.'
    ]

# Generated at 2022-06-24 06:44:15.038510
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command("git push origin master") == "git pull origin master && git push origin master")

# Generated at 2022-06-24 06:44:17.354680
# Unit test for function match

# Generated at 2022-06-24 06:44:24.401272
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@example.com:mm/mm.git\'\n'
                         'To prevent you from losing history, non-fast-forward updates were rejected\n'
                         'Merge the remote changes (e.g. \'git pull\') before pushing again. \n'
                         'See the \'Note about fast-forwards\' section of \'git push --help\' for details.',
                         '', 1))


# Generated at 2022-06-24 06:44:26.205426
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == shell.and_('git pull','git push')


# Generated at 2022-06-24 06:44:31.310037
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command("git push", "Updates were rejected because the remote contains work that you do not have locally.  This is usually caused by another repository pushing to the same ref.  You may want to first integrate the remote changes before pushing again.  See the 'Note about fast-forwards' in 'git push --help' for details.")) == "git pull && git push"

enabled_by_default = True

# Generated at 2022-06-24 06:44:34.314432
# Unit test for function get_new_command
def test_get_new_command():
	script = 'push origin master'
	output = '! [rejected]        master -> master (fetch first)'
	command = type('Command', (), {'script':script, 'output':output})()
	assert get_new_command(command) == 'git pull origin master'

# Generated at 2022-06-24 06:44:40.747093
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/y/x\n ! [rejected]        master -> master (fetch first)\n error: failed to push some refs to \'https://github.com/y/x\'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., \'git pull ...\') before pushing again.'))

# Generated at 2022-06-24 06:44:45.368828
# Unit test for function match
def test_match():
    assert not match(Command('push origin master', '', ''))
    assert not match(Command('git push origin master', '', ''))
    assert match(Command('git push origin master', '! [rejected]', ''))

# Generated at 2022-06-24 06:44:46.719812
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push").script == "git pull && git push"

# Generated at 2022-06-24 06:44:51.101412
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '''! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'ssh://git@github.com/kennethreitz/requests.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''')
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-24 06:44:53.348988
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull && git push'
    assert get_new_command(Command('git pull', '')) == 'git pull'

# Generated at 2022-06-24 06:45:02.788901
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to \'https://github.com/user/repo.git\'',
                         'hint: Updates were rejected because the tip of your current branch is behind',
                         'hint: its remote counterpart. Integrate the remote changes (e.g.',
                         'hint: \'git pull ...\') before pushing again.',
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:45:07.800489
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', ''))
    assert match(Command('git push origin master', 'error: failed to push some refs to', ''))
    assert match(Command('git push origin master', '', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push origin master', '', 'Updates were rejected because the remote contains work that you do'))


# Generated at 2022-06-24 06:45:14.738307
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To git@github.com:nvbn/thefuck\n'
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:nvbn/thefuck\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
                         None))


# Generated at 2022-06-24 06:45:15.517280
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin') == 'git pull && git push origin'

# Generated at 2022-06-24 06:45:23.935740
# Unit test for function match
def test_match():
    # Function match
    # Create command object
    command = Command('push -u origin head',
                      'To https://github.com/<user>/<repo>.git\n ! [rejected] '
                      'head -> head (non-fast-forward)\n error: failed to '
                      'push some refs to \'https://github.com/<user>/<repo>'
                      '.git\'\n hint: Updates were rejected because the tip '
                      'of your current branch is behind\n hint: its remote '
                      'counterpart. Integrate the remote changes (e.g.'
                      '\n hint: \'git pull ...\') before pushing again.\n '
                      'hint: See the \'Note about fast-forwards\' in '
                      '\'git push --help\' for details.',
                      '')

    # Test

# Generated at 2022-06-24 06:45:33.002661
# Unit test for function match
def test_match():
    # if 'push' not in command.script
    assert match(Command(script='', output='')) == False
    # if '! [rejected]' not in command.output
    assert match(Command(script='push', output='')) == False
    # if 'failed to push some refs to' not in command.output
    assert match(Command(script='push', output='! [rejected]')) == False
    # if ('Updates were rejected because the tip of your current branch is behind' not in command.output
    # or 'Updates were rejected because the remote contains work that you do' not in command.output)
    assert match(Command(script='push', output='! [rejected]\nfailed to push some refs to\n')) == False
    # if all of above conditions are true

# Generated at 2022-06-24 06:45:40.270810
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
                                   '! [rejected]        master -> master '
                                   '(non-fast-forward)\n'
                                   'To prevent you from losing history, '
                                   'non-fast-forward updates were rejected\n'
                                   'Merge the remote changes (e.g. '
                                   '\'git pull\') before pushing again.  See '
                                   'the \'Note about fast-forwards\' section '
                                   'of \'git push --help\' for details.\n')) == 'git pull && git push'