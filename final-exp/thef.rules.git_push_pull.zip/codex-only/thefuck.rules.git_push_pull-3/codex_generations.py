

# Generated at 2022-06-24 06:35:37.020445
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '!! [rejected]')
    new_command = get_new_command(command)
    assert new_command == 'git pull; git push'

# Generated at 2022-06-24 06:35:38.535779
# Unit test for function get_new_command
def test_get_new_command():
    assert ('git pull',
            get_new_command(Command('git push', '')))

# Generated at 2022-06-24 06:35:41.118770
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('git push origin master', '')
    new_cmd = get_new_command(cmd)
    assert new_cmd == 'git pull && git push origin master'

# Generated at 2022-06-24 06:35:43.851320
# Unit test for function match
def test_match():
    assert (match(Command('git push', 'Updates were rejected because the tip'
                          ' of your current branch is behind')) == True)


# Generated at 2022-06-24 06:35:46.445676
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', '', '')) ==
            shell.and_('git pull', 'git push'))

# Generated at 2022-06-24 06:35:51.428253
# Unit test for function match
def test_match():
    assert match(Command("git push", '! [rejected]        master -> master (non-fast-forward)', ""))
    assert not match(Command("git push", '', ""))
    assert not match(Command("git pull", '', ""))
    assert not match(Command("git commit", '', ""))


# Generated at 2022-06-24 06:35:59.767786
# Unit test for function match
def test_match():
    assert match(
        Command('git push origin master:master',
                '! [rejected] master -> master (non-fast-forward)\n'
                'error: failed to push some refs to'
                ' \'git@github.com:USER/REPOSITORY.git\'\n'
                'To prevent you from losing history, '
                'non-fast-forward updates were rejected\n'
                'Merge the remote changes (e.g. \'git pull\') '
                'before pushing again.  See the \'Note about fast-forwards\'\n'
                'section of \'git push --help\' for details.'))

# Generated at 2022-06-24 06:36:06.364295
# Unit test for function match
def test_match():
    assert match(Command(script='git push', output=''))
    assert match(Command(script='git push', output='! [rejected]        master -> master (non-fast-forward)\n'
                                                   'error: failed to push some refs to \'git@github.com:dylang/node-notifier'
                                                   '\nUpdates were rejected because the tip of your current branch is behind'))
    assert match(Command(script='git push', output='error: failed to push some refs to \'git@github.com:dylang/node-notifier\n'
                                                   '! [rejected]        master -> master (non-fast-forward)\n'
                                                   'Updates were rejected because the tip of your current branch is behind'))

# Generated at 2022-06-24 06:36:08.917564
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git push", "\n! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n", "")) == "git pull"

# Generated at 2022-06-24 06:36:16.843107
# Unit test for function match
def test_match():
    assert match(Command('git push -v', '', '', '', ' ! [rejected]        master -> master (non-fast-forward) error: failed to push some refs to \'ssh://git@host/repo.git\' hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes (e.g hint: \'git pull ...\') before pushing again. hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))
    assert not match(Command('git branch -a', '', '', '', ''))

# Generated at 2022-06-24 06:36:24.688780
# Unit test for function get_new_command
def test_get_new_command():
    command = type(
        'CommandObject', (object,), {'script': 'git push',
                                     'output': ("On branch master\n"
                                     "Your branch is up-to-date with 'origin/master'.\n"
                                     "nothing to commit, working directory clean\n"
                                     "Updates were rejected because the tip of your current branch is behind\n"
                                     "fatal: Could not read from remote repository.\n"
                                     "\n"
                                     "Please make sure you have the correct access rights\n"
                                     "and the repository exists.\n")})
    assert get_new_command(command) == 'git pull'

# Generated at 2022-06-24 06:36:30.937403
# Unit test for function match
def test_match():
    command = Command('git push',
                      'To https://github.com/jd/repo.git\n ! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nTo https://github.com/jd/repo.git\n ! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the remote contains work that you do\nneve',
                      '')
    assert match(command)


# Generated at 2022-06-24 06:36:33.706144
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', '')
    assert get_new_command(command) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:36:41.535100
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    command = Command(script='git push origin master',
                    stderr=' ! [rejected]        master -> master (non-fast-forward)\n')
    assert get_new_command(command) == ('git pull origin master && '
                                         'git push origin master')

    command = Command(script='git push origin master',
                    stderr=' ! [rejected]        master -> master (fetch first)\n')
    assert get_new_command(command) == ('git pull origin master && '
                                         'git push origin master')

# Generated at 2022-06-24 06:36:49.741634
# Unit test for function match

# Generated at 2022-06-24 06:36:51.644055
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull'

# Generated at 2022-06-24 06:36:55.037419
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git push', '', '', 'Updates were rejected because the tip of your current branch is behind')) == 'git pull && git push'
    assert get_new_command(Command('git push', '', '', 'Updates were rejected because the remote contains work that you do')) == 'git pull && git push'

# Generated at 2022-06-24 06:37:01.876159
# Unit test for function match
def test_match():
    assert match(Command('git push',
               "To branch master\n ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to 'git@github.com:dylanaraps/pywal.git'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: 'git pull ...') before pushing again.\n hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n",
               stderr='',
               script='git push'
               ))
    

# Generated at 2022-06-24 06:37:10.340807
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', 'git push origin maste')
    assert get_new_command(command) == 'git pull origin master && git push origin maste'
    command = Command('git push origin master', 'git push origin m')
    assert get_new_command(command) == 'git pull origin master && git push origin m'
    command = Command('git push origin master', 'git push origin')
    assert get_new_command(command) == 'git pull origin master && git push origin'
    command = Command('git push origin master', 'git push')
    assert get_new_command(command) == 'git pull origin master && git push'

# Generated at 2022-06-24 06:37:21.548704
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push',
                      ' ! [rejected]        master -> master (non-fast-forward)\n'
                      'error: failed to push some refs to \'https://github.com/fqrouter/fqrouter.git\'\n'
                      'hint: Updates were rejected because the tip of your current branch is behind\n'
                      'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                      'hint: \'git pull ...\') before pushing again.\n'
                      'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')

    assert get_new_command(command) == 'git pull && git push'



# Generated at 2022-06-24 06:37:22.727866
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push')) == 'git pull && git push'

# Generated at 2022-06-24 06:37:28.639766
# Unit test for function get_new_command
def test_get_new_command():

    return_value_1 = ('git', 'commit', '--amend')
    return_value_2 = ('git', 'push', 'origin', 'master')
    return_value_3 = ('git', 'pull', 'origin', 'master')
    assert get_new_command(MagicMock(**{'script': return_value_1})) == return_value_1
    assert get_new_command(MagicMock(**{'script': return_value_2})) == return_value_3
    assert get_new_command(MagicMock(**{'script': return_value_3})) == return_value_3
# End of unit test



# Generated at 2022-06-24 06:37:37.851840
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', 'fatal: The current branch master has no upstream branch.\nTo push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n\n! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to https://github.com/adamalton/test_git.git\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n', '')) ==
            'git pull')



# Generated at 2022-06-24 06:37:45.222486
# Unit test for function match
def test_match():
    # Test 1: Check that command matches
    assert match(Command('git push origin master',
                         'To https://github.com/rupa/z\n ! [rejected]        master -> master '
                         '(fetch first)','','','','','','','','','','','',''))

    # Test 2: Check that command does not match
    assert not match(Command('git add .', '', '', '', '',
                             '', '', '', '', '', '', '', ''))

# Generated at 2022-06-24 06:37:46.950322
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('git push origin master')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:37:57.619321
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master',
                      '''To gitlab.com:awesome/git-conflict.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'git@github.com:awesome/git-conflict.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.''')

# Generated at 2022-06-24 06:38:02.859026
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push', 'Updates were rejected because the tip of your '
                'current branch is behind')) == 'git pull'
    assert get_new_command(
        Command('git push', 'Updates were rejected because the remote '
                'contains work that you do')) == 'git pull'

# Generated at 2022-06-24 06:38:11.374169
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '! [rejected]        master -> master (non-fast-forward)\n'
                                                    'error: failed to push some refs to \'https://github.com/ptim/osquery-configuration.git\'\n'
                                                    'hint: Updates were rejected because the tip of your current branch is behind\n'
                                                    'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                                    'hint: \'git pull ...\') before pushing again.\n'
                                                    'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:38:15.804553
# Unit test for function match
def test_match():
    assert match(Command('git push',
                        'error: failed to push some refs to',
                        '! [rejected]        master -> master (non-fast-forward)',
                        'error: failed to push some refs to',
                        'Updates were rejected because the tip of your',
                        'current branch is behind its remote'))


# Generated at 2022-06-24 06:38:18.578017
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '! [rejected]')) \
           == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:38:19.554658
# Unit test for function match
def test_match():
    assert match(command) == True


# Generated at 2022-06-24 06:38:22.765564
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', None, '! [rejected] master -> master (fetch first)\n')) == shell.and_('git pull', 'git push')

# Generated at 2022-06-24 06:38:32.216668
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push origin master',
                                   stdout = '! [rejected]        master -> master (fetch first)')) == 'git pull origin master'
    assert get_new_command(Command(script='git push origin master',
                                   stdout = '! [rejected]        master -> master (non-fast-forward)')) == 'git pull origin master'
    assert get_new_command(Command(script='git push origin master',
                                   stdout = '! [rejected]        master -> master (fetch first)')) == 'git pull origin master'
    assert get_new_command(Command(script='git push --force origin master',
                                   stdout = '! [rejected]        master -> master (non-fast-forward)')) == 'git pull --force origin master'
    assert get

# Generated at 2022-06-24 06:38:38.045688
# Unit test for function match
def test_match():
    assert not match(Command('git push', output='Thing\n'))
    assert match(Command('git push', output='Thing\n! [rejected]'))
    assert match(Command('git push',
                         output='Thing\n! [rejected]\n'
                                'failed to push some refs to'))
    assert match(Command('git push',
                         output='Thing\n! [rejected]\n'
                                'failed to push some refs to\n'
                                'Updates were rejected because the remote '
                                'contains work that you do'))

# Generated at 2022-06-24 06:38:39.734942
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == \
        'git pull && git push origin master'

# Generated at 2022-06-24 06:38:42.268775
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Mock(stderr='push ! [rejected]', script='push')) == shell.and_('pull', 'push')

# Generated at 2022-06-24 06:38:51.033342
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git push origin branch'
    assert get_new_command(Command(script, '')) == 'git pull origin branch && git push origin branch'
    script = 'git push --set-upstream origin branch'
    assert get_new_command(Command(script, '')) == 'git pull --set-upstream origin branch && git push --set-upstream origin branch'
    script = 'git push origin branch -f'
    assert get_new_command(Command(script, '')) == 'git pull origin branch -f && git push origin branch -f'
    script = 'git push'
    assert get_new_command(Command(script, '')) == 'git pull && git push'
    script = 'git push origin branch -f -u'

# Generated at 2022-06-24 06:38:53.252793
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == shell.and_('git pull', 'git push')
    assert get_new_command('git push -f') == shell.and_('git pull', 'git push -f')

# Generated at 2022-06-24 06:38:55.522467
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('git push -h').script == 'git pull -h')
    assert (get_new_command('git pull -h').script == 'git pull -h')

# Generated at 2022-06-24 06:39:07.051712
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master',
                      ' ! [rejected] \tmaster -> master (fetch first) error: failed to push some refs to \'https://github.com/SimonCouper/font-awesome.git\' hint: Updates were rejected because the remote contains work that you do hint: not have locally. This is usually caused by another repository pushing hint: to the same ref. You may want to first integrate the remote changes hint: (e.g., \'git pull ...\') before pushing again. hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert get_new_command(command).script == 'git pull origin master && git push origin master'


# Generated at 2022-06-24 06:39:16.843160
# Unit test for function match
def test_match():
    assert match(Command('git push', '', ''))
    assert match(Command('git push', '', '''
 ! [rejected]        develop -> develop (non-fast-forward)
error: failed to push some refs to 'git@git.thw.de:git/test.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))


# Generated at 2022-06-24 06:39:21.939235
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'Updates were rejected because the tip of your current branch is behind', '')) == 'git pull'
    assert get_new_command(Command('git push origin master', 'Updates were rejected because the tip of your current branch is behind', '')) == 'git pull origin master'

# Generated at 2022-06-24 06:39:31.679998
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
        'To https://github.com/stamban/test\n ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/stamban/test\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
        'https://github.com/stamban/test'))

# Generated at 2022-06-24 06:39:43.671538
# Unit test for function match
def test_match():
    assert match(Command('git push', '',
                         'Updates were rejected because the tip of your '
                         'current branch is behind its remote counterpart. '
                         'Integrate the remote changes (e.g.\n'
                         '\'git pull ...\') before pushing again.\n'
                         'See the \'Note about fast-forwards\' in \'git push '
                         '--help\' for details.'))
    assert match(Command('git push', '',
                         'Updates were rejected because the remote contains '
                         'work that you do\n'
                         'not have locally. This is usually caused by '
                         'another repository pushing\n'
                         'to the same ref. You may want to first integrate '
                         'the remote changes\n'
                         '(e.g., \'git pull ...\') before pushing again."'))

# Generated at 2022-06-24 06:39:46.710567
# Unit test for function get_new_command
def test_get_new_command():
    assert (match('git push origin master') and
            get_new_command('git push origin master') ==
            '&& git push origin master')


# Generated at 2022-06-24 06:39:52.258886
# Unit test for function match
def test_match():
    assert match('git push origin master')
    assert match('git push origin my_branch')
    assert match('git push origin')
    assert match('git push my_branch')
    assert match('git push')
    assert match('git push -u origin master')
    assert not match('git remote -v')
    assert not match('git add .')
    assert not match('git commit -m "My commit"')


# Generated at 2022-06-24 06:40:01.710555
# Unit test for function match
def test_match():
    """
    Asserts whether a match is returned or not
    """
    command = 'git push origin master'

# Generated at 2022-06-24 06:40:12.009003
# Unit test for function match
def test_match():
    # Test result when output is incorrect
    assert match(Command('git push', '', '')) == False
    # Test result when output contains correct string
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g., \'git pull ...\') before pushing again. See the \'Note about fast-forwards\' in \'git push --help\' for details.', '')) == True
    # Test result when output is correct

# Generated at 2022-06-24 06:40:22.356124
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 0, None))

# Generated at 2022-06-24 06:40:29.962273
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n\
error: failed to push some refs to \'git@bitbucket.org:mccalvin/my_project.git\'\n\
hint: Updates were rejected because the tip of your current branch is behind\n\
hint: its remote counterpart. Integrate the remote changes (e.g.\n\
hint: \'git pull ...\') before pushing again.\n\
hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')) == 'git pull')


enabled_by_default = True

# Generated at 2022-06-24 06:40:33.084431
# Unit test for function match
def test_match():
    assert match(Command('git push', 'error: failed to push some refs to...'))
    assert not match(Command('git push', ''))
    assert not match(Command('ls', ''))



# Generated at 2022-06-24 06:40:35.324204
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', '', '')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:40:37.445941
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', 1, None)) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:40:47.308965
# Unit test for function match
def test_match():
    # Simple case
    assert match(Command('git push', 'Updates were rejected because the tip of your'
                                     ' current branch is behind its remote counterpart.'
                                     ' Integrate the remote changes (e.g. \'git pull ...\')'
                                     ' before pushing again.'))
    # Notice it is "rejected", not "reject"!
    assert not match(Command('git push', 'Updates were reject because the tip of your'
                                        ' current branch is behind its remote counterpart.'
                                        ' Integrate the remote changes (e.g. \'git pull ...\')'
                                        ' before pushing again.'))
    # Others

# Generated at 2022-06-24 06:40:50.058074
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '', 'Updates were rejected because the tip of your current branch is behind')
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-24 06:40:53.171814
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command("git push origin master") == "git pull; git push origin master")
    assert(get_new_command("git push") == "git pull; git push")

# Generated at 2022-06-24 06:40:54.558634
# Unit test for function get_new_command
def test_get_new_command():
    old_command = Command('git push')
    assert get_new_command(old_command) == 'git pull && git push'

# Generated at 2022-06-24 06:40:57.437409
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git push'
    output = 'Updates were rejected because the tip of your current branch is behind'
    assert get_new_command(Command(script, output)) == 'git pull && git push'

# Generated at 2022-06-24 06:40:59.210146
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '', 0)) == shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-24 06:41:04.794837
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (fetch first)',
                         'error: failed to push some refs to \'git@github.com:EngrMohamedAly/dotfiles.git\'',
                         'hint: Updates were rejected because the tip of your current branch is behind',
                         'hint: its remote counterpart. Integrate the remote changes (e.g.',
                         'hint: \'git pull ...\') before pushing again.',
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-24 06:41:06.537284
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('git push origin master') == 'git pull origin master')

# Generated at 2022-06-24 06:41:14.561243
# Unit test for function match

# Generated at 2022-06-24 06:41:17.855762
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '')) \
        == 'git pull origin master'
    assert get_new_command(Command('git push', '', '')) == 'git pull'

# Generated at 2022-06-24 06:41:23.437344
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', 'Updates were rejected because the remote contains work that you do not have locally.  This is usually caused by another repository pushing to the same ref. ')) == 'git pull origin master && git push origin master'


# Generated at 2022-06-24 06:41:33.766982
# Unit test for function match
def test_match():
    assert match(Command('git add .',
            'fatal: Not a git repository (or any of the parent directories): .git'))\
        is None
    assert match(Command('git push', 'To git@github.com:nvbn/thefuck.git\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')) != None

# Generated at 2022-06-24 06:41:43.443678
# Unit test for function match
def test_match():
    command = Command('git push origin master', 'git', 'git')

# Generated at 2022-06-24 06:41:52.574320
# Unit test for function match
def test_match():
    assert(match(Command(script='git push origin master',
                         output='To https://github.com/fgeiger/git-cheat-sheet.git\n ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/fgeiger/git-cheat-sheet.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
                         stderr='',
                         stdout='',
                         env={})))

# Generated at 2022-06-24 06:42:03.629620
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/\''))
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/\''))
    assert match(Command('git push',
                         'To prevent you from losing history, non-fast-forward updates were rejected\n'
                         'error: failed to push some refs to \'https://github.com/\''))

# Generated at 2022-06-24 06:42:06.193844
# Unit test for function get_new_command
def test_get_new_command():
	command = types.Command('git push', 'Submodule path ... does not exist', '')
	assert get_new_command(command) == 'git pull'

# Generated at 2022-06-24 06:42:07.863597
# Unit test for function get_new_command
def test_get_new_command():
    assert git('push origin master').get_new_command() == 'git pull origin master'

# Generated at 2022-06-24 06:42:15.921663
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-24 06:42:22.602088
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                '! [rejected]        master -> master (non-fast-forward)',
                'error: failed to push some refs to '
                '\'git@github.com:SiddheshMhatre/linux.git\'',
                'hint: Updates were rejected because the tip of your '
                'current branch is behind',
                'hint: its remote counterpart. Merge the remote changes '
                '(e.g. \'git pull\')',
                'hint: before pushing again.',
                'hint: See the \'Note about fast-forwards\' in \'git push '
                '--help\' for details.'))


# Generated at 2022-06-24 06:42:29.167184
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 1, None))
    assert match(Command('git push --all', '', '', 1, None))
    assert not match(Command('git push origin master', '', '', 1, None))
    assert not match(Command('git push --all', '', '', 1, None))
    assert not match(Command('cat foo.txt', '', '', 1, None))


# Generated at 2022-06-24 06:42:31.569420
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', '', '')) == 'git pull && git add'

# Generated at 2022-06-24 06:42:40.765244
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'git push --set-upstream master origin', 'Updates were rejected because the tip of your current branch is behind')) == 'git pull && git push --set-upstream master origin'
    assert get_new_command(Command('git push', 'git push --set-upstream master origin', 'Updates were rejected because the remote contains work that you do')) == 'git pull && git push --set-upstream master origin'

# Generated at 2022-06-24 06:42:46.197711
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git push origin master'
    output = ' ! [rejected]        master -> master (non-fast-forward)\n'\
             'error: failed to push some refs to \'git@github.com:...\''
    assert get_new_command(Command(script, output)) ==\
           shell.and_('git pull origin master', script)

# Generated at 2022-06-24 06:42:56.116602
# Unit test for function get_new_command
def test_get_new_command():
    output = '! [rejected]        master -> master (fetch first)\n'\
             'error: failed to push some refs to '\
             '\'git@github.com:nvbn/thefuck.git\'\n'\
             'hint: Updates were rejected because the '\
             'tip of your current branch is behind\n'\
             'hint: its remote counterpart. Integrate the '\
             'remote changes (e.g.\n'\
             'hint: \'git pull ...\') before pushing again.\n'\
             'hint: See the \'Note about fast-forwards\' in '\
             '\'git push --help\' for details.'
    assert get_new_command(Command('git push origin master', output=output)) == \
           'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:43:04.941752
# Unit test for function match
def test_match():
    # Check function match when command _script_ is 'git push'
    assert(match(Command('git push',
                         output=['! [rejected]        master -> master (non-fast-forward)',
                                 'error: failed to push some refs to...'])))

    # Check function match when command _script_ is 'git push origin'
    assert(match(Command('git push origin',
                         output=['! [rejected]        master -> master (non-fast-forward)',
                                 'error: failed to push some refs to...'])))

    # Check function match when command _script_ isn't 'git push'

# Generated at 2022-06-24 06:43:07.932748
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git push origin master',
                      stdout="Updates were rejected because the tip of your current branch is behind")
    assert get_new_command(command) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:43:12.921552
# Unit test for function match

# Generated at 2022-06-24 06:43:20.969034
# Unit test for function get_new_command
def test_get_new_command():
    assert "git pull && git push" == get_new_command("git push")
    assert "git pull && git push" == get_new_command("git pull && git push")
    assert "git pull && git pull && git push" == get_new_command("git pull && git push && git pull")
    assert "git pull && echo asd" == get_new_command("git pull && echo asd")
    assert "git pull && git push" == get_new_command("git pull")

# Generated at 2022-06-24 06:43:31.527049
# Unit test for function match
def test_match():
    cmd="git push"
    cmdout="""git push
To https://github.com/zhyea/Thefuck
! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/zhyea/Thefuck'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details."""
    assert match(Command(cmd,cmdout))
    cmd="git push"

# Generated at 2022-06-24 06:43:39.226073
# Unit test for function match
def test_match():
    test_input1 = "git push origin master"
    test_output1 = "! [rejected]        master -> master (fetch first)"
    test_cmd1 = Command(test_input1, test_output1)
    assert match(test_cmd1)

    test_input2 = "git push origin master"
    test_output2 = "The remote contains work that you do not have locally."
    test_cmd2 = Command(test_input2, test_output2)
    assert match(test_cmd2)


# Generated at 2022-06-24 06:43:45.001541
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_pull_before_push import get_new_command
    new_command = get_new_command(create_command('git push', '! [rejected]        v1.1 -> v1.1 (non-fast-forward)\n'
 'Updates were rejected because the tip of your current branch is behind\n'
 'Updates were rejected because the tip of your current branch is behind\n'
 'failed to push some refs to \'git@github.com:rails/rails.git\''))
    assert 'git pull' in new_command
    assert 'git push' not in new_command


# Generated at 2022-06-24 06:43:50.126305
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git push'
    new_command = get_new_command(command)
    assert new_command == 'git pull && git push'
    command = 'git push -v'
    new_command = get_new_command(command)
    assert new_command == 'git pull && git push -v'
    command = 'git push --set-upstream origin master'
    new_command = get_new_command(command)
    assert new_command == 'git pull && git push --set-upstream origin master'
    command = 'git push --set-upstream origin master -v'
    new_command = get_new_command(command)
    assert new_command == 'git pull && git push --set-upstream origin master -v'

# Generated at 2022-06-24 06:43:51.633763
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push x y', '')) == 'git pull x y && git push x y'

# Generated at 2022-06-24 06:43:51.981014
# Unit test for function get_new_command
def test_get_new_command():
    pass

# Generated at 2022-06-24 06:44:00.721749
# Unit test for function match
def test_match():
    # Test that when the match function works properly
    assert match(Command("git push", "! [rejected] master -> master (non-fast-forward)\n"
                                       "error: failed to push some refs to 'git@github.com:alexkuz/repo.git'\n"
                                       "hint: Updates were rejected because the tip of your current branch is behind\n"
                                       "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                                       "hint: 'git pull ...') before pushing again.\n"
                                       "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n"))

# Generated at 2022-06-24 06:44:04.648476
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = "git push", output = "! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your branch is behind its remote counterpart.")) == 'git pull && git push'

# Generated at 2022-06-24 06:44:15.712764
# Unit test for function match
def test_match():
    output = '''
    ! [rejected]        master -> master (non-fast-forward)
    error: failed to push some refs to 'git@bitbucket.org:username/repo.git'
    hint: Updates were rejected because the tip of your current branch is behind
    hint: its remote counterpart. Integrate the remote changes (e.g.
    hint: 'git pull ...') before pushing again.
    hint: See the 'Note about fast-forwards' in 'git push --help' for details.
    '''
    assert True == match(Command('git push origin master', output))


# Generated at 2022-06-24 06:44:17.816305
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='',
                                   output='Updates were rejected because the tip of your'
                                          ' current branch is behind')) == ['git', 'pull']

# Generated at 2022-06-24 06:44:24.341845
# Unit test for function get_new_command

# Generated at 2022-06-24 06:44:25.765970
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull'

# Generated at 2022-06-24 06:44:31.310201
# Unit test for function get_new_command
def test_get_new_command():
    import pytest
    output = "'''resolve conflict and commit the result.push failed because of non fast forward issues.Updates were rejected because the tip of your current branch is behind'''"
    command = "vim git pull"
    expected = "vim git pull"
    check_command =git_support.get_new_command(command, output)
    assert pytest.approx(check_command) == pytest.approx(expected)

# Generated at 2022-06-24 06:44:38.269362
# Unit test for function match

# Generated at 2022-06-24 06:44:43.093039
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 1, None))
    assert match(Command('git push origin master', '', '', 1, None))
    assert not match(Command('git commit', '', '', 1, None))


# Generated at 2022-06-24 06:44:49.216391
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                                 '')) == True
    assert match(Command('git push origin master',
                                 'To https://github.com/nvbn/thefuck.git\n ! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')) == True

# Generated at 2022-06-24 06:44:57.748041
# Unit test for function match
def test_match():
    assert match(Command('git push', 'To https://github.com/nvbn/thefuck.git\n ! [rejected]        master -> master (fetch first)', '', 123))
    assert match(Command('git push', 'To https://github.com/nvbn/thefuck.git\n ! [rejected]        master -> master (non-fast-forward)', '', 123))
    assert match(Command('git push', 'To https://github.com/nvbn/thefuck.git\n ! [rejected]        master -> master (non-ff)', '', 123))
    assert not match(Command('git add', '', '', 123))


# Generated at 2022-06-24 06:45:03.134776
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', 'Updates were rejected because the remote contains work that you do not have locally.  This is usually caused by another repository pushing to the same ref.  You may want to first integrate the remote changes (e.g., \'git pull ...\') before pushing again.')
    test_new_command = 'git pull origin master && git push origin master'
    assert get_new_command(command) == test_new_command

# Generated at 2022-06-24 06:45:11.154007
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to '
                         "'git@github.com:Jackzeng/TheFuck.git'\n"
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.\n', None))

# Generated at 2022-06-24 06:45:16.388282
# Unit test for function match
def test_match():
    """
    Check if match function can detect the right error type
    """
    assert match(Command('git push',
        'To https://github.com/ryepdx/git.git\n ! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to \'https://github.com/ryepdx/git.git\'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-24 06:45:20.514330
# Unit test for function match
def test_match():
    assert match(Command('git push', '''To http://github.com/Otis24/Git_Test
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'http://github.com/Otis24/Git_Test'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.''',
                                  None, 'git'))


# Generated at 2022-06-24 06:45:31.555460
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         output='To git@github.com:nvbn/thefuck.git\n! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-24 06:45:36.555590
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master',
                      'Updates were rejected because the remote contains'
                      ' work that you do\n'
                      'not have locally. This is usually caused by another'
                      ' repository pushing\n'
                      'to the same ref. You may want to first integrate'
                      ' the remote changes\n'
                      'push failed')
    assert get_new_command(command) == 'git pull && git push origin master'