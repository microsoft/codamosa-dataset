

# Generated at 2022-06-24 06:35:43.945579
# Unit test for function match
def test_match():
    check_match = match(Command('git push origin',
                                ' ! [rejected]      master -> master (non-fast-forward)\n'
                                'error: failed to push some refs to \'/git/git\'\n'
                                'To prevent you from losing history, non-fast-forward updates were rejected\n'
                                'Merge the remote changes before pushing again.  See the \'Note about\n'
                                'fast-forwards\' section of \'git push --help\' for details.'))
    assert check_match == True


# Generated at 2022-06-24 06:35:55.159991
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command


# Generated at 2022-06-24 06:35:59.343581
# Unit test for function match
def test_match():
    """
    Returns True when failed to push some refs to
    """
    assert match(command='git push')


# Generated at 2022-06-24 06:36:06.230090
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = 'git push',
                      output = 'failed to push some refs to \'origin\' ! [rejected] master -> master (fetch first) error: failed to push some refs to \'origin\'')
    assert get_new_command(command) == 'git pull && git push'
    command = Command(script = 'git push',
                      output = 'failed to push some refs to \'origin\' ! [rejected] master -> master (non-fast-forward) error: failed to push some refs to \'origin\' hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes hint: (e.g. hint: \'git pull ...\') before pushing again. hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert get_new_

# Generated at 2022-06-24 06:36:13.043121
# Unit test for function get_new_command

# Generated at 2022-06-24 06:36:16.011308
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command("git push","git pull") == "git pull"
	assert get_new_command("git push origin master","git pull origin master") == "git pull origin master"



# Generated at 2022-06-24 06:36:19.738423
# Unit test for function get_new_command
def test_get_new_command():
    shell = Mock()
    shell.and_.return_value = 'test'
    command = Command(script='git push',
                      output='Updates were rejected because the tip of your'
                             ' current branch is behind')
    command.shell = shell
    assert get_new_command(command) == 'test'

# Generated at 2022-06-24 06:36:30.924904
# Unit test for function match
def test_match():
    assert match(Command('git push origin',
                         '! [rejected] master -> master '
                         '(non-fast forward)'
                         'error: failed to push some refs to'
                         'Updates were rejected because the tip '
                         'of your current branch is behind'))
    assert match(Command('git push origin',
                         '! [rejected] master -> master '
                         '(non-fast forward)'
                         'error: failed to push some refs to'
                         'Updates were rejected because the remote '
                         'contains work that you do'))

# Generated at 2022-06-24 06:36:39.400754
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 'error: failed to push some refs',
                         error=True))
    assert match(Command('git push', 'error: failed to push some refs',
                         error=True))
    assert not match(Command('git push origin master',
                             'Updates were rejected because the remote '
                             'contains work that you do', error=True))
    assert not match(Command('git push origin master',
                             'Updates were rejected because the tip of your'
                             ' current branch is behind', error=True))


# Generated at 2022-06-24 06:36:48.434814
# Unit test for function get_new_command

# Generated at 2022-06-24 06:36:52.727309
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull; git push'
    assert get_new_command('git push origin branch').script == 'git pull; git push origin branch'
    assert get_new_command('git push -u origin branch').script == 'git pull; git push -u origin branch'

# Generated at 2022-06-24 06:36:55.960515
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master').script == 'git pull ; git push origin master'

enabled_by_default = True

# Generated at 2022-06-24 06:36:57.460298
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', '', '', 1)) ==
            'git pull && git push')

# Generated at 2022-06-24 06:37:07.708247
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ''' ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'git@github.com:falsetru/dotfiles.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''))

# Generated at 2022-06-24 06:37:15.467688
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'warning: push.default is unset; its implicit value has changed in\nGit 2.0 from \'matching\' to \'simple\'.')) == 'git pull && git push'
    assert get_new_command(Command('git push', 'To git@github.com:nvbn/thefuck.git\n   7b8cfda..a74c6e1  master -> master')) is None
    assert get_new_command(Command('git push', 'warning: push.default is unset; its implicit value has changed in\nGit 2.0 from \'matching\' to \'simple\'.')) == 'git pull && git push'

# Generated at 2022-06-24 06:37:24.504376
# Unit test for function match
def test_match():
    command = Command('git push',
                      "Updates were rejected because the tip of your current"
                      " branch is behind its remote counterpart. Integrate the"
                      " remote changes (e.g.hint: 'git pull ...') before pushing"
                      " again. See the 'Note about fast-forwards' in 'git push"
                      " --help' for details.", '', 0)
    assert match(command) is True

# Generated at 2022-06-24 06:37:26.243893
# Unit test for function get_new_command
def test_get_new_command():
  assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-24 06:37:38.422793
# Unit test for function match
def test_match():
    # assert match(Command(script='git push',
    #                      output='git: \'push\' is not a git command. See '
    #                             '\'git --help\'.')) is False
    assert match(Command(script='git push', output='! [rejected]')) is True
    assert match(Command(script='git push', output='error: failed to '
                                                   'push some refs to')) is True
    assert match(Command(script='git push', output='Updates were '
                                                   'rejected because the tip'
                                                   ' of your current branch '
                                                   'is behind')) is True
    assert match(Command(script='git push', output='Updates were '
                                                   'rejected because the tip'
                                                   ' of your current branch '
                                                   'is behind'))

# Generated at 2022-06-24 06:37:47.752476
# Unit test for function match
def test_match():
    assert match(Command('git push', '', ''))
    assert match(Command('git push', 'Updates were rejected because the tip of your '
                         'current branch is behind its remote counterpart. Integrate '
                         'the remote changes (e.g.\n'
                         '\'git pull ...\') before pushing again.\n'
                         'See the \'Note about fast-forwards\' in \'git push --help\' '
                         'for details.', ''))

# Generated at 2022-06-24 06:37:58.301454
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   '! [rejected]        test -> '
                                   'test (non-fast-forward)\n'
                                   'Updates were rejected because the tip of '
                                   'your current branch is behind\n'
                                   'its remote counterpart. '
                                   'Integrate the remote changes (e.g.\n'
                                   '\'git pull ...\') before pushing again.')) == 'git pull origin master'


# Generated at 2022-06-24 06:38:08.101792
# Unit test for function match
def test_match():
    assert match(Command('git push',
                    '''To https://github.com/nvbn/thefuck
! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/nvbn/thefuck'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-24 06:38:09.282747
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 1))


# Generated at 2022-06-24 06:38:14.400174
# Unit test for function match
def test_match():
    assert match(Command('git push', '''To git@github.com:fudan/thefuck.git
 ! [rejected]        master -> master (non-fast-forward)

 error: failed to push some refs to 'git@github.com:fudan/thefuck.git'
 hint: Updates were rejected because the tip of your current branch is behind
 hint: its remote counterpart. Merge the remote changes (e.g. 'git pull')
 hint: before pushing again.
 hint: See the 'Note about fast-forwards' in 'git push --help' for details.''', ''))


# Generated at 2022-06-24 06:38:16.147331
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(git.Push('git push origin master')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:38:27.037048
# Unit test for function match
def test_match():
    assert match(Command('git push',
        '''To https://github.com/user/repo
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/user/repo'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-24 06:38:32.829367
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
        "To " + gitlab_repo + "\n ! [rejected]        master -> master (fetch first)\n$ error: failed to push some refs to '" + gitlab_repo +"'"))
    assert not match(Command('git push origin master',
        "To " + gitlab_repo + "\n ! [rejected]        master -> master (non-fast-forward)\n$ error: failed to push some refs to '" + gitlab_repo +"'"))
    assert match(Command('git push origin master',
        "To " + gitlab_repo + "\n ! [rejected]        master -> master (non-fast-forward)\n$ error: failed to push some refs to '" + gitlab_repo +"'\nbrief explanation of what happened"))

# Generated at 2022-06-24 06:38:42.393871
# Unit test for function match
def test_match():
    # Test match for when push does not occur
    assert not match(Command('git checkout master', "", "", 0, False))

    # Test match for when push is rejected
    assert not match(Command('git push', "! [rejected]        master -> master (non-fast-forward)\n", "", 17, False))
    assert match(Command('git push', "! [rejected]        master -> master (non-fast-forward)\n", "", 17, False))

    # Test match for when push is accepted
    assert not match(Command('git push', "Everything up-to-date\n", "", 0, False))

    # Test match for when pull is rejected
    assert not match(Command('git pull', 
        "! [rejected]        master -> master (non-fast-forward)\n", "", 17, False))

   

# Generated at 2022-06-24 06:38:46.995710
# Unit test for function get_new_command
def test_get_new_command():
    # Make assert to avoid dependency of shell object
    assert get_new_command("git push --repo https://www.github.com/user/repo.git") == shell.and_("git pull --repo https://www.github.com/user/repo.git", "git push --repo https://www.github.com/user/repo.git")

# Generated at 2022-06-24 06:38:53.189420
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master')
    command.output = ('To git@github.com:nvbn/thefuck.git\n'
                      '! [rejected]        master -> master '
                      '(non-fast-forward)\n'
                      'error: failed to push some refs to '
                      'git@github.com:nvbn/thefuck.git\n'
                      'To prevent you from losing history, '
                      'non-fast-forward updates were '
                      'rejected\nMerge the remote changes '
                      'before pushing again.  See the '
                      '\'Note about fast-forwards\' section of '
                      '\'git push --help\' for details.')
    assert get_new_command(command) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:39:00.095969
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                'To git@github.com:nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))



# Generated at 2022-06-24 06:39:09.165782
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 'To https://github.com/abc/abc.git\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/abc/abc.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))
    assert not match(Command('git push origin master', 'abcdefghijklmnopqrstuvwxyz'))

# Generated at 2022-06-24 06:39:11.597892
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push')
    actual = get_new_command(command)
    expected = shell.and_('git pull', 'git push')
    assert actual == expected

# Generated at 2022-06-24 06:39:13.657577
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command('git push')) == 'git pull && git push'


enabled_by_default = True

# Generated at 2022-06-24 06:39:22.680143
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@*****\'',
                         ''))
    assert match(Command('git push origin master',
                         'To git@github.com:nvbn/thefuck.git\n'
                         '! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to \'git@*****\'',
                         ''))
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@*****\'',
                         ''))

# Generated at 2022-06-24 06:39:27.302611
# Unit test for function get_new_command
def test_get_new_command():
    command_output = '''Auto-merging hoge.txt
CONFLICT (content): Merge conflict in hoge.txt
Automatic merge failed; fix conflicts and then commit the result.
'''

    assert get_new_command(Command('git push origin master',
                                   command_output)) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:39:29.457250
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', 'error: failed to push some refs to \
\'http://github.com/user/repo.git\'')
    assert str(get_new_command(command)) == 'git pull'

# Generated at 2022-06-24 06:39:30.944372
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:39:35.524323
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master').script == 'git pull && git push origin master'

# Generated at 2022-06-24 06:39:42.276360
# Unit test for function match
def test_match():

    # Test when command output contains "! [rejected]"
    assert match(Command("git push master", "! [rejected]  master -> master (fetch first)\n\
    error: failed to push some refs to 'https://github.com/mingkaikuo5131/Test_Git_Repo.git'",
                       "")) == True

    # Test when command output contains "Updates were rejected because the tip of your current branch is behind"

# Generated at 2022-06-24 06:39:43.972082
# Unit test for function get_new_command

# Generated at 2022-06-24 06:39:46.574555
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command(script = 'git push')) ==
            'git pull && git push')


# Generated at 2022-06-24 06:39:47.914279
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull'

# Generated at 2022-06-24 06:39:55.226889
# Unit test for function match
def test_match():
    from thefuck.shells import Bash
    from thefuck.types import Command

    assert match(Command('git push', '', '', stderr='! [rejected]  master -> master (fetch first)'))
    assert match(Command('git push', '', '', stderr='Updates were rejected because the tip of your current branch is behind'))
    assert not match(Command('git push', '', '', stderr='! [rejected]'))


# Generated at 2022-06-24 06:39:58.552979
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('') == ''

# Generated at 2022-06-24 06:40:07.973997
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push',
                      'Updates were rejected because the tip of your '
                      'current branch is behind its remote counterpart.'
                      'Integrate the remote changes')
    assert get_new_command(command) == \
            'git pull'
    assert get_new_command(Command('git push',
                      'Updates were rejected because the remote '
                      'contains work that you do'
                      'not have locally. This is usually caused by another '
                      'repository pushing to the same ref. You may want to '
                      'first integrate the remote changes')) == \
            'git pull'

# Generated at 2022-06-24 06:40:15.497467
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to \'git@example.com:test/test.git\'\n'
                         'hint: Updates were rejected because the remote contains work that you do\n'
                         'hint: not have locally. This is usually caused by another repository pushing\n'
                         'hint: to the same ref. You may want to first integrate the remote changes\n'
                         'hint: (e.g., \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:40:25.948840
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'error: failed to push some refs to ...',
                         stderr='error: failed to push some refs to ...\n' +
                                'hint: Updates were rejected because the remote' +
                                ' contains work that you do\nhint: not have locally. ' +
                                'This is usually caused by another repository pushing\n' +
                                'hint: to the same ref. You may want to first integrate' +
                                ' the remote changes\nhint: (e.g., ' +
                                '`git pull ...`) before pushing again.\n' +
                                'hint: See the `Note about fast-forwards` in ' +
                                '`git push --help` for details.'))

# Generated at 2022-06-24 06:40:33.062103
# Unit test for function get_new_command
def test_get_new_command():
	command_git_Pull_update_rejected = Command('git pull', 'Total 0 (delta 0), reused 0 (delta 0)\n! [rejected]        master -> master (fetch first)\n', '', 'git pull')
	assert get_new_command(command_git_Pull_update_rejected) == shell.and_('git fetch', 'git pull')

# Generated at 2022-06-24 06:40:35.713844
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', '! [rejected]\nfailed to push some refs to remote')) ==
            'git pull && git push')

# Generated at 2022-06-24 06:40:37.444233
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master')) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:40:41.091637
# Unit test for function match

# Generated at 2022-06-24 06:40:43.633477
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push", "Updates were rejected because the remote contains work that you do\n")
    assert get_new_command(command) == 'git fetch && git pull'

# Generated at 2022-06-24 06:40:52.566633
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
                                       'error: failed to push some refs to \'https://github.com/vijay94858/git-cheatsheet.git\'\n'
                                       'hint: Updates were rejected because the tip of your current branch is behind\n'
                                       'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                       'hint: \'git pull ...\') before pushing again.\n'
                                       'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:41:02.574334
# Unit test for function match
def test_match():
    assert not match(Command('push origin abcdefg',
                             '! [rejected]        master -> master (non-fast-forward)\n'
                             'error: failed to push some refs to \'git@git.gitlab.com:MTC-ISR1/infrastructure-support/samba-config.git\'',
                             '', 3))

# Generated at 2022-06-24 06:41:09.687368
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '! [rejected]        master -> master (non-fast-forward)\n The following commands will resolve the issue\n git pull\n git push origin master'))
    assert match(Command('git push origin master', '! [rejected]     master -> master (non-fast-forward)\n Updates were rejected because the tip of your current branch is behind\n the tip of its remote counterpart. Integrate the remote changes (e.g.\n git pull ...)\n before pushing again.'))

# Generated at 2022-06-24 06:41:17.951190
# Unit test for function match
def test_match():
    assert match(Command(script='git push',
                         output='To https://github.com/nvbn/thefuck\n ! [rejected]        master -> master (non-fast-forward)\n'))
    assert match(Command(script='git push',
                         output='To https://github.com/nvbn/thefuck\n ! [rejected]        master -> master (fetch first)\n'))
    assert not match(Command(script='git fetch',
                             output='To https://github.com/nvbn/thefuck\n ! [rejected]        master -> master (non-fast-forward)\n'))



# Generated at 2022-06-24 06:41:25.634970
# Unit test for function match

# Generated at 2022-06-24 06:41:30.566501
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '''To https://github.com/ravikanth16/githug.git
                            ! [rejected]        master -> master (non-fast-forward)
                            error: failed to push some refs to 'https://github.com/ravikanth16/githug.git'
                            hint: Updates were rejected because the tip of your current branch is behind
                            hint: its remote counterpart. Integrate the remote changes (e.g.
                            hint: 'git pull ...') before pushing again.
                            hint: See the 'Note about fast-forwards' in 'git push --help' for details.
                         '''))


# Generated at 2022-06-24 06:41:32.576447
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '', '', '', '')).script == "git pull"
    assert get_new_command(Command('git push', '', '', '', '', '')).script == "git pull"

# Generated at 2022-06-24 06:41:35.700944
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master && git push origin master'
    assert get_new_command('git push origin') == 'git pull origin && git push origin'
    assert get_new_command('git push') == 'git pull && git push'
    assert get_new_command('git push example') == 'git pull example && git push example'


# Generated at 2022-06-24 06:41:37.835386
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', 'Updates were rejected...')) == '(git pull) && git push'

# Generated at 2022-06-24 06:41:39.875910
# Unit test for function get_new_command
def test_get_new_command():
    new_cmd = get_new_command(Command('git push', ''))
    assert new_cmd == 'git pull && git push'

# Generated at 2022-06-24 06:41:50.229632
# Unit test for function match
def test_match():
    # Test case that is expected to be True
    # push in the script and ! [rejected] and failed to push some refs to and [... and ...] in the output
    assert match(Command(script='git push', output=' ! [rejected]\nfailed to push some refs to\nUpdates were rejected because the tip of your current branch is behind')) == True
    # Test case that is expected to be True
    # push in the script and ! [rejected] and failed to push some refs to and [... and ...] in the output
    assert match(Command(script='git push', output=' ! [rejected]\nfailed to push some refs to\nUpdates were rejected because the remote contains work that you do')) == True
    # Test case that is expected to be True
    # push in the script and ! [rejected] and

# Generated at 2022-06-24 06:41:56.656003
# Unit test for function match
def test_match():

	# Function works as expected
    assert(match(Command("git push origin master", "! [rejected]"
                  "failed to push some refs to"
                  "Updates were rejected because the tip of your"
                  " current branch is behind"
                  "Updates were rejected because the remote contains work that you do", ""))) == True

    # Function does not work as expected
    assert(match(Command("git push origin master", "", "", "")) == False)

# Generated at 2022-06-24 06:41:58.902447
# Unit test for function get_new_command
def test_get_new_command():
    command = command = Command('git push origin master', '~')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:42:09.864267
# Unit test for function match
def test_match():
    assert not match(Command('git push origin master', ''))
    assert match(Command('git push origin master', '''
! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-24 06:42:15.038812
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/user/repo ! [rejected] ...',
                         'Updates were rejected because the tip of your'
                         ' current branch is behind'))
    assert match(Command('git push',
                         'To https://github.com/user/repo ! [rejected] ...',
                         'Updates were rejected because the remote '
                         'contains work that you do'))
    assert not match(Command('git push', '', ''))


# Generated at 2022-06-24 06:42:20.328547
# Unit test for function match
def test_match():
    assert match(Command('git push', ' ! [rejected]        master -> master (fetch first)'))
    assert match(Command('git push', ' ! [rejected]        master -> master (non-fast-forward)'))
    assert match(Command('git push', ' ! [rejected]        master -> master (stale info)'))

# Generated at 2022-06-24 06:42:31.287536
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:XX/XX.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-24 06:42:38.487094
# Unit test for function get_new_command
def test_get_new_command():
    # Setup
    command = Command('git push origin master')
    # Check
    assert (get_new_command(command) ==
            ('git pull; git push origin master'))

# Generated at 2022-06-24 06:42:41.342018
# Unit test for function match
def test_match():
	# Tests for match function
	assert match(Command('git push', ''))
	assert not match(Command('git push origin master', ''))
	assert not match(Command('git checkout master', ''))


# Generated at 2022-06-24 06:42:52.214701
# Unit test for function match
def test_match():
    output = "! [rejected]        master -> master (fetch first)"
    output += "error: failed to push some refs to 'git@heroku.com:xxx.git'"
    output += "hint: Updates were rejected because the remote contains work"
    output += "hint: that you do not have locally. This is usually caused by"
    output += "hint: another repository pushing to the same ref. You may"
    output += "hint: want to first integrate the remote changes (e.g., 'git pull ...')"
    output += "hint: before pushing again.See the 'Note about fast-forwards'"
    output += "hint: section of 'git push --help' for details."

    assert match(Command(script='git push', output=output))


# Generated at 2022-06-24 06:43:01.696842
# Unit test for function match
def test_match():
    assert match(Command('git push', ' ! [rejected]        master -> master (fetch first)'))
    assert match(Command('git push origin master',
        ' ! [rejected]        master -> master (fetch first)'))
    assert match(Command('git push', ' ! [rejected]        master -> master (non-fast-forward)'))
    assert match(Command('git push origin master',
        ' ! [rejected]        master -> master (non-fast-forward)'))
    assert match(Command('git push',
        'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push origin master',
        'Updates were rejected because the tip of your current branch is behind'))

# Generated at 2022-06-24 06:43:03.199205
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git push origin master', '')) == 'git pull && git push origin master')

# Generated at 2022-06-24 06:43:08.561499
# Unit test for function match
def test_match():
    command=Command("git push master", "Updates were rejected because the tip of your current branch is behind")
    assert match(command)
    command= Command("git push master", "Updates were rejected because the remote contains work that you do")
    assert match(command)
    command= Command("git push master", "Updates were rejected because the remote contains work that you don")
    assert not match(command)

# Test for return value of get_new_command

# Generated at 2022-06-24 06:43:10.789367
# Unit test for function get_new_command
def test_get_new_command():
    assert "git pull" == get_new_command(Command("git push", "git push"))
    assert "git push" == get_new_command(Command("git pull", "git pull"))

# Generated at 2022-06-24 06:43:14.155200
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the tip of your\
 current branch is behind', '', 1))
    assert match(Command('git push', 'Updates were rejected because the remote\
 contains work that you do', '', 1))
    assert not match(Command('git push', '', '', 1))


# Generated at 2022-06-24 06:43:24.619105
# Unit test for function match
def test_match():

    command = Command('git push', '''To https://github.com/catherinejd/test.git
! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/catherinejd/test.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.''', '')
    assert match(command) is True


# Generated at 2022-06-24 06:43:36.565845
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/Username/repo.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-24 06:43:37.908822
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull && git push'

# Generated at 2022-06-24 06:43:45.000614
# Unit test for function match
def test_match():
    import pytest
    from thefuck.shells import shell
    from thefuck.types import Command


# Generated at 2022-06-24 06:43:47.405827
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'Updates were rejected')) == shell.and_(replace_argument('git push', 'push', 'pull'),'git push')

enabled_by_default = True

# Generated at 2022-06-24 06:43:57.846348
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command.Command('git push', 'aa\nsomething', 'aa\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\n\'git pull ...\') before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.\nsomething')) == 'git pull && git push'
    assert get_new_command(command.Command('git push', 'aa\nsomething', 'aa\nUpdates were rejected because the remote contains work that you do\nnot have locally.  This is usually caused by another repository pushing\nnew commits to the same ref.  You may want to first integrate the remote\nchanges (e.g., \'git pull ...\') bef')) == 'git pull && git push'

# Generated at 2022-06-24 06:44:08.980314
# Unit test for function get_new_command

# Generated at 2022-06-24 06:44:19.822344
# Unit test for function match
def test_match():
    assert match(Command('git push', '', 'error: failed to push some refs to\n'
        'hint: Updates were rejected because the tip of your current branch is behind'
        '\n'
        'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
        'hint: \'git pull ...\') before pushing again.\n'
        'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:44:28.311540
# Unit test for function match
def test_match():
    assert(match(Command('git push',
    'To http://github.com/user/repo.git\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'http://github.com/user/repo.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) == True)



# Generated at 2022-06-24 06:44:34.138411
# Unit test for function match
def test_match():
    assert match(Command("git push", "remote: Resolving deltas: 100% (4/4), completed with 3 local objects.", ""))
    assert match(Command("git push", "! [rejected] master -> master (non-fast-forward)", "Updates were rejected because the tip of your current branch is behind"))
    assert match(Command("git push", "! [rejected] master -> master (non-fast-forward)", "Updates were rejected because the remote contains work that you do"))
    assert not match(Command("git push", "", ""))


# Generated at 2022-06-24 06:44:35.712319
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master:develop') == 'git pull origin master:develop ; git push origin master:develop'

# Generated at 2022-06-24 06:44:41.734816
# Unit test for function match
def test_match():
    assert not match(Command("git push"))
    assert match(Command("git push -u origin master", "remote: Permission to wuhong/docker-compose-lnmp.git denied to wuhong.\nfatal: unable to access 'https://github.com/wuhong/docker-compose-lnmp.git/': The requested URL returned error: 403"))

# Generated at 2022-06-24 06:44:44.561408
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', None)) == \
        shell.and_('git pull origin master', 'git push origin master')

# Unit use to test that the decorators are working properly

# Generated at 2022-06-24 06:44:53.615827
# Unit test for function match
def test_match():
	command = Command(script = 'git push origin master')
	assert match(command) == (False, 'push stage')

# Generated at 2022-06-24 06:44:56.003956
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do'))
    assert not match(Command('git push', 'Already up-to-date.'))

# Generated at 2022-06-24 06:45:04.029485
# Unit test for function match
def test_match():
    command = Command(script = 'git push', output = '! [rejected]    master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/YoongiMin/RMChocolate.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert match(command) != False


# Generated at 2022-06-24 06:45:05.734845
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) \
           == 'git pull && git push origin master'

# Generated at 2022-06-24 06:45:11.311454
# Unit test for function match
def test_match():
    assert match(Command('git add && git commit && git push',
            '''To https://github.com/xapphire13/Linux-tools-for-penetration-testing.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/xapphire13/Linux-tools-for-penetration-testing.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''', None)) == True


# Generated at 2022-06-24 06:45:12.805898
# Unit test for function match
def test_match():
    command = Command('git push origin master',
                      ' ! [rejected]        master -> master (non-fast-forward)')
    assert match(command)



# Generated at 2022-06-24 06:45:22.268949
# Unit test for function match
def test_match():
    assert match(Command('git push', 'fatal: The remote end hung up unexpectedly'))
    assert match(Command('git push origin master', '! [rejected] master -> master (non-fast-forward)\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:45:24.400401
# Unit test for function get_new_command
def test_get_new_command():
    command = "git push"
    assert get_new_command(command) == "git pull && git push"

# Generated at 2022-06-24 06:45:26.668912
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git push'
    new_command = get_new_command(command)
    assert replace_argument(command, 'push', 'pull') in new_command
    assert command in new_command

# Generated at 2022-06-24 06:45:28.252052
# Unit test for function get_new_command
def test_get_new_command():
    new_cmd = get_new_command('git push')
    assert new_cmd == 'git pull && git push'

# Generated at 2022-06-24 06:45:36.945380
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'Updates were rejected because the tip of your current branch is behind\n'
                         'its remote counterpart. Integrate the remote changes (e.g.\n'
                         'git pull ...) before pushing again.\n',
                         '',
                         123))
    # Abbreviated output
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'Updates were rejected because the remote contains work that you do',
                         '',
                         123))