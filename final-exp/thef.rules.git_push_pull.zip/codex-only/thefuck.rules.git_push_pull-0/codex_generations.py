

# Generated at 2022-06-24 06:35:44.931023
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push origin master',
                                   output='! [rejected]        master -> master (non-fast-forward) error: failed to push some refs to \'git@github.com:tpope/vim-sensible.git\' hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes (e.g. hint: \'git pull ...\') before pushing again. hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) == shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-24 06:35:47.693933
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', ' - ! [rejected]', '', 1)
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:35:57.699366
# Unit test for function match
def test_match():
    """
    Callable that tests if the output from the commmandline
    matches the expected output
    """

# Generated at 2022-06-24 06:36:03.669908
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master')
    assert get_new_command(command) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:36:12.139488
# Unit test for function match
def test_match():
    assert match(Command(script='git push',
                   output='! [rejected]        master -> master (non-fast-forward)\n'
                   'error: failed to push some refs to\''
                   'git@gitlab.com:someuser/somerepo.git\'\n'
                   'hint: Updates were rejected because the tip of your'
                   ' current branch is behind\n'
                   'hint: its remote counterpart. Integrate the remote changes'
                   ' (e.g.\nhint: git pull ...)\n'
                   'hint: before pushing again.\n'
                   'hint: See the \'Note about fast-forwards\' in '
                   '\'git push --help\' for details.\n')
                  ) == True


# Generated at 2022-06-24 06:36:14.032362
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '')).script == 'git pull && git push'

# Generated at 2022-06-24 06:36:24.012979
# Unit test for function get_new_command
def test_get_new_command():
    script1 = 'git push origin master'
    script2 = 'git push origin xyz'
    output1 = '''To https://github.com/tetron82/bioinformatics.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/tetron82/bioinformatics.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''

# Generated at 2022-06-24 06:36:28.631625
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git push origin main",
                                   output='Updates were rejected because the tip of your'
                                          ' current branch is behind'
                                          ' Updating the default upstream branch.'
                                          ' ! [rejected]        main -> main (non-fast-forward)'
                                          ' error: failed to push some refs to'
                                          ' \'git@gitlab.com:<user>/<project>.git\'')
                            ) == 'git pull origin main && git push origin main'


# Generated at 2022-06-24 06:36:39.543787
# Unit test for function match
def test_match():
    assert match(Command('git push','''
To git@github.com:someuser/some-repo.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'git@github.com:someuser/some-repo.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-24 06:36:48.532917
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         stderr='! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:Hellowlol/config.git\''
                         '\nhint: Updates were rejected because the tip of your current branch is'
                         ' behind\nhint: its remote counterpart. Integrate the remote changes '
                         '(e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the '
                         '\'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-24 06:36:50.841352
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git pull && git push origin master' == get_new_command(Command('git push origin master', '', ''))


enabled_by_default = True

# Generated at 2022-06-24 06:36:56.162852
# Unit test for function match
def test_match():
	command = Command("git push origin HEAD:refs/for/master")
	assert match(command)
	command = Command("git push origin HEAD:refs/for/master")
	assert match(command)
	command = Command("git push origin HEAD:refs/for/master")
	assert match(command)
	command = Command("git push origin HEAD:refs/for/master")
	assert not match(command)


# Generated at 2022-06-24 06:37:05.191292
# Unit test for function get_new_command
def test_get_new_command():
  assert match(Command('git push origin master',
                       'Updates were rejected because the tip of your'
                       'current branch is behind')) is True
  assert match(Command('git push origin master',
                       'Updates were rejected because the remote'
                       'contains work that you do')) is True

  assert get_new_command(Command('git push origin master',
                                 'Updates were rejected because the tip of your'
                                 'current branch is behind')) == 'git pull && git push origin master'
  assert get_new_command(Command('git push origin master',
                                 'Updates were rejected because the remote'
                                 'contains work that you do')) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:37:08.128746
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('') == 'git pull'
    assert get_new_command('push origin/master') == 'git pull origin/master'

# Generated at 2022-06-24 06:37:13.032968
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master').script == 'git pull && git push origin master'
    assert get_new_command('git push origin1 origin2').script == 'git pull && git push origin1 origin2'
    assert get_new_command('git push origin1 origin2 branch1 branch2').script == 'git pull && git push origin1 origin2 branch1 branch2'

# Generated at 2022-06-24 06:37:14.821625
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 1), None) == shell.and_('git pull', 'git push')

# Generated at 2022-06-24 06:37:20.830257
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push origin master', '',
                                    'Updates were rejected because the tip of your current branch is behind'))
            == 'git pull origin master && git push origin master')
    assert (get_new_command(Command('git push origin branch', '',
                                    'Updates were rejected because the remote contains work that you do'))
            == 'git pull origin branch && git push origin branch')

# Generated at 2022-06-24 06:37:30.941099
# Unit test for function match
def test_match():
    assert match(Command(script='git push'))
    assert not match(Command(script='git push origin master'))
    assert match(Command(script='git push origin master',
                         output='! [rejected]        master -> master (non-fast-forward) error: failed to push some refs to'))
    assert match(Command(script='git push origin master',
                         output='! [rejected]        master -> master (non-fast-forward) error: failed to push some refs to '
                                'updates were rejected because the tip of your current branch is behind its remote counterpart.'
                                ' Integrate the remote changes (e.g. hint: git pull ...) before pushing again.'))

# Generated at 2022-06-24 06:37:35.012409
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', 'Updates were rejected because the tip of your current branch is behind')) == 'git pull && git push')
    assert (get_new_command(Command('git push', 'Updates were rejected because the remote contains work that you do not have locally')) == 'git pull && git push')

# Generated at 2022-06-24 06:37:45.572096
# Unit test for function match
def test_match():
    command1 = Command("git push origin master",
                       "To https://github.com/user/repo.git\n ! [rejected]\
                       master -> master (fetch first)\n error: failed to\
                       push some refs to 'https://github.com/user/repo.git'\
                       \n hint: Updates were rejected because the remote\
                       contains work that you do\n hint: not have locally.\
                       This is usually caused by another repository pushing\
                       to the same ref. You may\n hint: want to first integrate\
                       the remote changes (e.g., 'git pull ...')\n hint: before\
                       pushing again.\n hint: See the 'Note about fast-forwards'\
                       in 'git push --help' for details.\n", None)

# Generated at 2022-06-24 06:37:54.472337
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 
        '/home/gajjartejas/git/thefuck:master',
        '''To https://github.com/nvbn/thefuck
    ! [rejected]        master -> master (fetch first)
    error: failed to push some refs to 'https://github.com/nvbn/thefuck'
    hint: Updates were rejected because the remote contains work that you do
    hint: not have locally. This is usually caused by another repository pushing
    hint: to the same ref. You may want to first integrate the remote changes
    hint: (e.g., 'git pull ...') before pushing again.
    hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''))


# Generated at 2022-06-24 06:37:58.971311
# Unit test for function get_new_command
def test_get_new_command():
    assert_equal(get_new_command(Command('git push', '', 'Updates were rejected because the remote contains work that you do not have locally.  This is usually caused by another repository pushing to the same ref.  You may want to first integrate the remote changes (e.g., \'git pull ...\') before pushing again.')),'git pull && git push')


# Generated at 2022-06-24 06:38:08.129928
# Unit test for function match
def test_match():
    # Successful match
    assert match(Command('git push',
                         'To https://github.com/nvbn/thefuck.git\n ! [rejected] master -> master (fetch first)\n error: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) == True

    # Unsuccessful match

# Generated at 2022-06-24 06:38:11.421512
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push',
                'To http://github.com/nvbn/thefuck\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'http://github.com/nvbn/thefuck\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
                '', 1)) == shell.and_('git pull', 'git push')

# Generated at 2022-06-24 06:38:13.679754
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin', '','/home')) == shell.and_('git pull origin', 'git push origin')

# Generated at 2022-06-24 06:38:24.861945
# Unit test for function match

# Generated at 2022-06-24 06:38:33.755183
# Unit test for function match
def test_match():
    # Command 1
    command1 = Command('git push origin master',
                       'To https://github.com/jeffery/fuck.git\n ! [rejected]      master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/jeffery/fuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
                       '/Users/jeffery/fuck')

    # Command 2

# Generated at 2022-06-24 06:38:41.343147
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To https://github.com/nvie/gitflow.git\n ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to '
                         '\'https://github.com/nvie/gitflow.git\'\n To prevent you from losing history, non-fast-forward updates were rejected\n Merge the remote changes (e.g. '
                         '\'git pull\') before pushing again. See the \'Note about\n fast-forwards\' section of \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:38:49.538491
# Unit test for function match
def test_match():
    right_cmd = u"""git push -u origin master
! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:Liunx/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details."""
    wrong_cmd = u"""git push -u origin master
! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:Liunx/thefuck.git'"""
    assert match(Command(script=right_cmd))

# Generated at 2022-06-24 06:38:58.258117
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', ''))

# Generated at 2022-06-24 06:39:01.667392
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', output='! [rejected]        master -> master (non-fast-forward)')
    assert get_new_command(command) == 'git fetch && git merge'


enabled_by_default = True

# Generated at 2022-06-24 06:39:03.487358
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:39:10.596864
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'remote: Permission to K42/test.git denied to sandy.\n'
                         'error: failed to push some refs to '
                         '\'git@gitlab.k42.in.th:K42/test.git\'\n'))
    assert not match(Command('git push',
                             'remote: Permission to K42/test.git denied to sandy.\n'
                             'error: failed to push some refs to '
                             '\'git@gitlab.k42.in.th:K42/test.git\'\n'
                             'To git@gitlab.k42.in.th:K42/test.git'))

# Generated at 2022-06-24 06:39:19.160025
# Unit test for function match
def test_match():
    assert match(Command('git push',
                 'To git@github.com:nvie/gitflow.git\n ! [rejected]        release/0.8.3 -> release/0.8.3 (non-fast-forward)\nerror: failed to push some refs to \'git@github.com:nvie/gitflow.git\'\nTo prevent you from losing history, non-fast-forward updates were rejected\nMerge the remote changes (e.g. \'git pull\') before pushing again.  See the\n\'Note about fast-forwards\' section of \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:39:27.262737
# Unit test for function match
def test_match():
    # Check if the match function works correctly
    assert match(Command('git push origin master',
                         'To https://github.com/nvbn/thefuck.git\n'
                         ' ! [rejected]        master -> master\n'
                         'error: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\n'
                         'Updates were rejected because the tip of your current branch is behind\n'
                         'its remote counterpart. Integrate the remote changes (e.g.\n'
                         '\'git pull ...\') before pushing again.\n'
                         'See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

    # Check if the match function works correctly

# Generated at 2022-06-24 06:39:29.098673
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull && git push'

# Generated at 2022-06-24 06:39:37.031607
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == shell.and_('git pull origin master', 'git push origin master')
    assert get_new_command(Command('git push --git-dir=/path/to/git_dir origin master', '')) == shell.and_('git pull --git-dir=/path/to/git_dir origin master', 'git push --git-dir=/path/to/git_dir origin master')
    assert get_new_command(Command('git push --git-dir=/path/to/git_dir', '')) == shell.and_('git pull --git-dir=/path/to/git_dir', 'git push --git-dir=/path/to/git_dir')

# Generated at 2022-06-24 06:39:48.003630
# Unit test for function match
def test_match():
    assert match(Command('git push',
        output='To https://github.com/nvbn/thefuck.git\n'
               '! [rejected]        master -> master (non-fast-forward)\n'
               'error: failed to push some refs to '
               '\'https://github.com/nvbn/thefuck.git\'\n'
               'hint: Updates were rejected because the tip of your '
               'current branch is behind\n'
               'hint: its remote counterpart. Integrate the remote changes '
               '(e.g.\nhint: \'git pull ...\') before pushing again.\n'
               'hint: See the \'Note about fast-forwards\' in '
               '\'git push --help\' for details.\n')) == True


# Generated at 2022-06-24 06:39:53.156084
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '! [rejected] foo -> foo (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\n  git pull ...)\n')) == "git pull"

# Generated at 2022-06-24 06:40:02.101382
# Unit test for function match
def test_match():
    command = Command('git push origin master', '', 1)
    assert not match(command)


# Generated at 2022-06-24 06:40:11.874534
# Unit test for function match
def test_match():
    command = Command("git push", "", "")
    assert not match(command)

    command = Command("git push", "! [rejected]", "failed to push some refs to")
    assert not match(command)

    command = Command("git push", "! [rejected]", "failed to push some refs to \n ")
    assert not match(command)

    command = Command("git push", "! [rejected]", "failed to push some refs to \n Updates were rejected because the tip of your current branch is behind")
    assert match(command)

    command = Command("git push", "! [rejected]", "failed to push some refs to \n Updates were rejected because the remote contains work that you do")
    assert match(command)



# Generated at 2022-06-24 06:40:22.238067
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/maxpoli/lbc.git\n ! [rejected]\n'
                         'To https://github.com/maxpoli/lbc.git\n ! [rejected]'
                         '  dev -> dev (non-fast-forward)\n'
                         'Updates were rejected because the tip of your '
                         'current branch is behind\n',
                         'git pull'))


# Generated at 2022-06-24 06:40:30.132683
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         stderr='To https://github.com/nvbn/thefuck\n! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to \'https://github.com/nvbn/thefuck\'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))


# Generated at 2022-06-24 06:40:40.221079
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                                 stderr='! [rejected] master -> master (non-fast-forward)',
                                 script='git push origin master'))
    assert match(Command('git push upstream master',
                                 stderr='! [rejected] master -> master (non-fast-forward)',
                                 script='git push upstream master'))
    assert match(Command('git push --force upstream master',
                                 stderr='! [rejected] master -> master (non-fast-forward)',
                                 script='git push --force upstream master'))
    assert match(Command('git push --force downstream master',
                                 stderr='! [rejected] master -> master (non-fast-forward)',
                                 script='git push --force downstream master'))

# Generated at 2022-06-24 06:40:49.811938
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git push", "! [rejected] master -> master (non-fast-forward)\n\
                                                error: failed to push some refs to 'git@github.com:L-P/similarity.git'\n\
                                                Updates were rejected because the tip of your current branch is behind\n\
                                                its remote counterpart. Integrate the remote changes (e.g.\n\
                                                'git pull ...') before pushing again.\n\
                                                See the 'Note about fast-forwards' in 'git push --help' for details.")) == "git pull && git push"


# Generated at 2022-06-24 06:41:00.059520
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 'git push origin master\nTo git@github.com:nikhgupta/dotfiles.git\n ! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to \'git@github.com:nikhgupta/dotfiles.git\'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:41:06.324861
# Unit test for function match
def test_match():
    command = Command('git push', '! [rejected]        master -> master (non-fast-forward)\nTo git@github.com:travisghansen/csc710-project.git\n   ab5a57a..a5b5c69  master -> master\nUpdates were rejected because the tip of your current branch is behind\ncsc710-project/master\nTry pulling from\nthe remote branch, resolving any conflicts, and pushing again.\n\ngit pull: \'git pull\' is not a git command. See \'git --help\'. Did you mean this?\n    pull ')
    assert match(command) == True

# Generated at 2022-06-24 06:41:12.327063
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', "! [rejected] master -> master (non-fast-forward)\nerror:failed to push some refs to 'https://github.com/SchneiderMan/thefuck.git'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.", "", 1, False))

# Generated at 2022-06-24 06:41:16.910127
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'Updates were rejected because the tip of your '
                         'current branch is behind'))
    assert match(Command('git push',
                         'Updates were rejected because the remote '
                         'contains work that you do'))
    assert not match(Command('git push', "! [rejected]        master -> master (fetch first)"))


# Generated at 2022-06-24 06:41:26.561331
# Unit test for function match

# Generated at 2022-06-24 06:41:29.455676
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = u'git push origin master')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:41:34.040444
# Unit test for function get_new_command
def test_get_new_command():
    assert(
            get_new_command(
                Command('git push origin master',
                        '! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nremote: Counting objects: 7, done.'))
            ==
            shell.and_(replace_argument('git push origin master', 'push', 'pull'), 'git push origin master')
            )

# Generated at 2022-06-24 06:41:39.160054
# Unit test for function match
def test_match():
    assert(match(Command('git push',
                         'To https://github.com/apt-get-update-plus/apt-get-update-plus.git\n! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/apt-get-update-plus/apt-get-update-plus.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')))

# Generated at 2022-06-24 06:41:41.118824
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master').script == \
        'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:41:50.854923
# Unit test for function match

# Generated at 2022-06-24 06:41:55.772850
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command.Command('git push', '! [rejected]\n'
                                              'Why is it rejected?\n'
                                              'failed to push some refs to\n'
                                              'Updates were rejected because the tip of your'
                                               ' current branch is behind')) == 'git pull'

# Generated at 2022-06-24 06:41:59.162953
# Unit test for function get_new_command
def test_get_new_command():
    assert ('git pull && '
            'git push git@github.com:nvbn/thefuck.git master') in get_new_command(
        Command('git push git@github.com:nvbn/thefuck.git master',
                'git@github.com:nvbn/thefuck.git Permission denied (publickey).\n'
                'fatal: The remote end hung up unexpectedly')).script

# Generated at 2022-06-24 06:42:10.163008
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin dev:dev',
                                   'ERROR: failed to push some refs '
                                   'to \'git@gitlab.com:foolan/thefuck.git\'\n'
                                   'hint: Updates were rejected because '
                                   'the remote contains work that you do '
                                   'not have locally. This is usually caused '
                                   'by another repository pushing to the '
                                   'same ref. You may want to first integrate '
                                   'the remote changes (e.g.,\n'
                                   '\'git pull ...\') before pushing again.',
                                   '')) == \
        'git pull origin dev:dev && git push origin dev:dev'


# Generated at 2022-06-24 06:42:19.471164
# Unit test for function match
def test_match():
    # Test when it should match
    assert match(Command('git push',
                         'To git@github.com:nvbn/thefuck\n ! [rejected] master -> master (non-fast-forward) \n error: failed to push some refs to \'git@github.com:nvbn/thefuck\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:42:25.768171
# Unit test for function get_new_command
def test_get_new_command():
    command_1 = "git push origin dev"
    exp_command_1 = "git pull origin dev; git push origin dev"
    command_2 = "git push origin master"
    exp_command_2 = "git pull origin master; git push origin master"

    assert get_new_command(command_1) == exp_command_1
    assert get_new_command(command_2) == exp_command_2

# Generated at 2022-06-24 06:42:35.583663
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/framboise15/HP-5011.git\n ! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to \'https://github.com/framboise15/HP-5011.git\'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         'https://github.com/framboise15/HP-5011.git'))


# Generated at 2022-06-24 06:42:42.852917
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
            ' ! [rejected]            master -> master (non-fast-forward)\n'
            'error: failed to push some refs to \'git@github.com:...\n'
            'To prevent you from losing history, non-fast-forward updates '
            'were rejected\nMerge the remote changes (e.g. \'git pull\') '
            'before pushing again.  See the \'Note about fast-forwards\' '
            'section of \'git push --help\' for details.'))


# Generated at 2022-06-24 06:42:48.556418
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command("git push",
                       "! [rejected]        master -> master (non-fast-forward)\n"
                       "error: failed to push some refs to 'git@example.com:username/repo.git'\n"
                       "To prevent you from losing history, non-fast-forward updates were rejected\n"
                       "Merge the remote changes (e.g. 'git pull') before pushing again.  See the\n"
                       "'Note about fast-forwards' section of 'git push --help' for details.")

# Generated at 2022-06-24 06:42:54.391493
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'
    assert get_new_command('git push origin master').script == 'git pull && git push origin master'
    assert get_new_command('git push origin master --force').script == 'git pull && git push origin master --force'
    assert get_new_command('git push origin master --force --tags').script == 'git pull && git push origin master --force --tags'

# Generated at 2022-06-24 06:42:59.590670
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push origin master", "! \"[rejected] master -> master (non-fast-forward)\" \n\"error: failed to push some refs to 'ssh://username@hostname/absolutepath/myrepo/'\" \n\"hint: Updates were rejected because the tip of your current branch is behind\" \n\"hint: its remote counterpart. Integrate the remote changes (e.g.\" \n\"hint: 'git pull ...') before pushing again.\" \n\"hint: See the 'Note about fast-forwards' in 'git push --help' for details.\"", "")
    assert get_new_command(command) == "git pull origin master; git push origin master"

# Generated at 2022-06-24 06:43:02.610706
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git push && git pull'
    assert get_new_command('git push origin').script == 'git push origin && git pull'
    assert get_new_command('git push origin master').script == 'git push origin master && git pull'

# Generated at 2022-06-24 06:43:11.596167
# Unit test for function match

# Generated at 2022-06-24 06:43:19.982751
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To https://github.com/nvie/gitflow.git! [rejected] master -> master (non-fast-forward)\n'
                         'error:failed to push some refs to \'https://github.com/nvie/gitflow.git\'\n'
                         'hint:Updates were rejected because the tip of your current branch is behind\n'
                         'hint:its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint:\'git pull ...\') before pushing again.\n'
                         'hint:See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         'git push origin master', 'git pull origin master'))


# Generated at 2022-06-24 06:43:23.411664
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', ''))
    assert not match(Command('git push origin master', '', '', ''))
    assert not match(Command('git push origin master', '', '', '', ''))


# Generated at 2022-06-24 06:43:28.234741
# Unit test for function match
def test_match():
    assert match(Command('push', stderr='''! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/AmyLee33/ama.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''))


# Generated at 2022-06-24 06:43:30.425780
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
            Command('git push origin master', '! [rejected] master -> master (fetch first)')) ==\
            shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-24 06:43:40.340800
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '''
        error: failed to psuh some refs to 'https://github.com/user/repo.git'
        hint: Updates were rejected because the remote contains work that you do
        hint: not have locally. This is usually caused by another repository pushing
        hint: to the same ref. You may want to first integrate the remote changes
        hint: (e.g., 'git pull ...') before pushing again.
        hint: See the 'Note about fast-forwards' in 'git push --help' for details.
    ''')

    new_command = git.get_new_command(command)
    assert new_command == "git stash && git pull && git push && git stash pop"



# Generated at 2022-06-24 06:43:46.162354
# Unit test for function match
def test_match():
    def git_push_error(script, output):
        command = Command(script=script, output=output)
        assert match(command)

    def git_push_ok(script, output):
        command = Command(script=script, output=output)
        assert not match(command)


# Generated at 2022-06-24 06:43:55.760286
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
        '''
To https://github.com/name/repo.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/name/repo.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''', '', None), None)

# Generated at 2022-06-24 06:44:02.409309
# Unit test for function get_new_command
def test_get_new_command():
    # test_and
    assert get_new_command('git push').script == 'git pull & git push'
    # test_and_with_suffix
    assert get_new_command('git push && ls').script == 'git pull && git push && ls'
    # test_or
    assert get_new_command('git push || ls').script == 'git pull || git push || ls'
    # test_or_with_prefix
    assert get_new_command('ls || git push').script == 'ls || git pull || git push'
    # test_pipe
    assert get_new_command('git push | wc -l').script == 'git pull | git push | wc -l'
    # test_pipe_with_prefix

# Generated at 2022-06-24 06:44:06.785729
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push',
                      '! [rejected]        master -> master (non-fast-forward)\n'
                      'error: failed to push some refs to \'tmp/test\'')
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-24 06:44:12.841566
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do'))
    assert not match(Command('git push', ''))
    assert not match(Command('git push', 'Updates were rejected because the tip of your current branch is behind'))



# Generated at 2022-06-24 06:44:21.544829
# Unit test for function get_new_command
def test_get_new_command():
    output_text = "! [rejected]        master -> master (fetch first)\n"
    output_text += "error: failed to push some refs to \\\\\\\\\'git@git.git/git/git.git\\\\\\\\'\n"
    output_text += "hint: Updates were rejected because the remote contains work that you do\n"
    output_text += "hint: n\\\\\\\\'t have locally. This is usually caused by another repository pushing\n"
    output_text += "hint: to the same ref. You may want to first integrate the remote changes\n"
    output_text += "hint: (e.g., \\\\\\\\\'git pull...\\\\\\\\') before pushing again.\n"
    output_text += "hint: See the 'Note about fast-forwards' in 'git push --help' for details."

# Generated at 2022-06-24 06:44:31.803833
# Unit test for function match
def test_match():

    # Test case: 'git push: Updates were rejected because the tip of your'
    # 'current branch is behind'
    command = {'stderr': '! [rejected]        master -> master (non-fast-forward)\n'
                     'error: failed to push some refs to '
                     '\'git@github.com:mislav/dotfiles.git\'\n'
                     'To prevent you from losing history, '
                     'non-fast-forward updates were rejected\n'
                     'Merge the remote changes (e.g. \'git pull\') '
                     'before pushing again.  See the \'Note about'
                     'fast-forwards\' section of \'git push --help\' '
                     'for details.\n',
               'script': 'git push',
               'stdout': ''}
    assert match(command)

# Generated at 2022-06-24 06:44:38.557248
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master',
                      ' ! [rejected]        master -> master (non-fast-forward)\n'
                      'error: failed to push some refs to \'https://github.com/myname/myrepo.git\''
                      '\nhint: Updates were rejected because the tip of your current branch '
                      'is behind\nhint: its remote counterpart. Integrate the remote changes '
                      '(e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See '
                      'the \'Note about fast-forwards\' in \'git push --help\' '
                      'for details.')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-24 06:44:49.999498
# Unit test for function match
def test_match():
	assert not match(Command('git push', '', ''))
	# Upstream rejected
	assert match(Command('git push origin master', '', '''
		To https://github.com/nvbn/thefuck.git
		 ! [rejected]        master -> master (non-fast-forward)
		error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'
		hint: Updates were rejected because the tip of your current branch is behind
		hint: its remote counterpart. Integrate the remote changes (e.g.
		hint: 'git pull ...') before pushing again.
		hint: See the 'Note about fast-forwards' in 'git push --help' for details.
		'''))
	# Upstream rejected

# Generated at 2022-06-24 06:44:54.124468
# Unit test for function match
def test_match():
    assert match(Command('git push', '', ''))
    assert match(Command('git push origin master', '', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git push', '', 'Updates were rejected because the tip of your current branch is behind'))


# Generated at 2022-06-24 06:44:55.491339
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git puse') == 'git pull'

# Generated at 2022-06-24 06:44:58.475464
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command_require_type('git push origin master')) == 'git pull && git push origin master'


# Generated at 2022-06-24 06:45:07.376051
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To https://github.com/user/repo.git\n ! [rejected] '
                         'master -> master (fetch first)\n error: failed to '
                         'push some refs to '
                         '\'https://github.com/user/repo.git\'\n hint: '
                         'Updates were rejected because the tip of your '
                         'current branch is behind\n hint: its remote '
                         'counterpart. Integrate the remote changes (e.g.\n '
                         'hint: \'git pull ...\') before pushing again.\n '
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))



# Generated at 2022-06-24 06:45:20.353415
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         output='! [rejected] master -> master ' +
                                '(non-fast-forward) ' +
                                'error: failed to push some refs to ' +
                                "'git@github.com:xx/xx.git'\n" +
                                'hint: Updates were rejected because ' +
                                'the tip of your current branch is behind\n' +
                                'hint: its remote counterpart. Integrate ' +
                                'the remote changes (e.g\n' +
                                'hint: \'git pull ...\') before pushing ' +
                                'again.\n' +
                                'hint: See the \'Note about fast-forwards\' ' +
                                'in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:45:30.172217
# Unit test for function match
def test_match():
    assert match(
        Command(script="git push",
                output='! [rejected]        master -> master (non-fast-forward)\n'
                       'error: failed to push some refs to ...'))
    assert match(
        Command(script="git push",
                output='! [rejected]        master -> master (non-fast-forward)\n'
                       'Updates were rejected because the tip of ...'))
    assert not match(
        Command(script="git checkout",
                output='! [rejected]        master -> master (non-fast-forward)\n'
                       'error: failed to push some refs to ...'))

# Generated at 2022-06-24 06:45:34.477288
# Unit test for function match
def test_match():
    assert match(Command('git push', ''))
    assert match(Command('git push', '!'))
    assert match(Command('git push origin master', ''))
    assert not match(Command('git push', 'Updates were rejected because the'))
    assert not match(Command('git push origin master', 'Updates were'))

# Generated at 2022-06-24 06:45:40.988469
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', ''))
    assert match(Command('git push origin master', '! [rejected] master -> master (non-fast-forward)\n'
                                                    'error: failed to push some refs to \'https://github.com/sherlocky/thefuck.git\'\n'
                                                    'hint: Updates were rejected because the tip of your current branch is behind\n'
                                                    'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                                    'hint: \'git pull ...\') before pushing again.\n'
                                                    'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))