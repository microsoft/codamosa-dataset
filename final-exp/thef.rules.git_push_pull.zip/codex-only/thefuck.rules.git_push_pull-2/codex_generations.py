

# Generated at 2022-06-24 06:35:48.808238
# Unit test for function match
def test_match():
	# Check the output of git-push if the branch is behind the remote branch
    command = Command('git push',
        'To https://github.com/fabioz/PyDev.git\n ! [rejected]        6.0 -> 6.0 (non-fast-forward)\n error: failed to push some refs to \'https://github.com/fabioz/PyDev.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert match(command)

	# Check the output of git-push if the branch is behind the remote branch and the remote contains work that you do


# Generated at 2022-06-24 06:35:56.412835
# Unit test for function get_new_command
def test_get_new_command():
    assert git_push_updates_were_rejected.get_new_command(
        Command('git push',
                '! [rejected]        master -> master (non-fast-forward)\n'
                'error: failed to push some refs to \'https://some_url/some_repo.git\'\n'
                'hint: Updates were rejected because the tip of your current branch is behind\n'
                'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                'hint: \'git pull ...\') before pushing again.\n'
                'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    ).script == 'git pull && git push'


enabled_by_default = True

# Generated at 2022-06-24 06:36:05.974981
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To https://github.com/nvbn/thefuck\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/nvbn/thefuck\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-24 06:36:18.955341
# Unit test for function match
def test_match():
    assert not match(Command('git push', '', '', '', ''))
    assert not match(Command('git push origin', '', '', '', ''))

# Generated at 2022-06-24 06:36:24.662213
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells.bash import Bash
    command = Command('git push origin my-feature',
                      '! [rejected]        my-feature -> my-feature'
                      ' (non-fast-forward)\n'
                      'updates were rejected\n'
                      'Updates were rejected because the tip of your '
                      'current branch is behind', 1)
    assert get_new_command(command, Bash()) == 'git pull &> /dev/null && git push'

# Generated at 2022-06-24 06:36:31.886705
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
         "To git@github.com:nvbn/thefuck.git\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to 'git@github.com:nvbn/thefuck.git'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.\n")) is True



# Generated at 2022-06-24 06:36:38.513785
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git push",
                                   output="! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nPush rejected, failed to push some refs to 'git@bitbucket.org:...\n",
                                   stderr="",
                                   stdout="",)) == "git fetch && git pull"

# Generated at 2022-06-24 06:36:41.066717
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'Updates were rejected because the tip of your \
	current branch is behind')) == 'git pull && git push'

# Generated at 2022-06-24 06:36:42.853325
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master')) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:36:44.689882
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '! [rejected] ...'))



# Generated at 2022-06-24 06:36:46.566716
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'failed')) == 'git pull && git push'

# Generated at 2022-06-24 06:36:56.399050
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To github.com:DENICeG/MaxiNet.git ! [rejected] master -> master (non-fast-forward) error: failed to push some refs to \'git@github.com:DENICeG/MaxiNet.git\' Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes before pushing again. See the \'Note about fast-forwards\' section of \'git push --help\' for details.'))

# Generated at 2022-06-24 06:37:05.461306
# Unit test for function match
def test_match():
    # Check if command is not matched (unknown file was specified in command)
    assert not match(Command(script='git push ./some_file', output=''))

    # successful pull
    assert not match(Command(script='git pull', output=''))

    # failed pull but only because of unmerged files
    assert not match(Command(
        script='git pull',
        output="""
error: The following untracked working tree files would be overwritten by merge:
	.gitignore
Please move or remove them before you can merge.
Aborting"""))

    # Match command which failed to push some refs to origin branch

# Generated at 2022-06-24 06:37:10.784084
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]\n'
                         'Updates were rejected because the tip of your '
                         'current branch is behind its remote counterpart.\n'
                         'Integrate the remote changes (e.g.\n'
                         'git pull ...)\n'
                         'before pushing again.'))  # noqa



# Generated at 2022-06-24 06:37:16.063720
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git push'
    output = '''
Updates were rejected because the tip of your current branch is behind
Updates were rejected because the remote contains work that you do
! [rejected]        master -> master (non-fast-forward)
'''
    command = Command(script, output)
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-24 06:37:24.897731
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 
                         ' ! [rejected]        master -> master (non-fast-forward)'
                         '\n error: failed to push some refs to '
                         '\'git@github.com:E4em/The-Fuck.git\''
                         '\n hint: Updates were rejected because the tip of your '
                         'current branch is behind'
                         '\n hint: its remote counterpart. Integrate the remote '
                         'changes (e.g'
                         '\n hint: \'git pull ...\') before pushing again.'
                         '\n hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.')) == True


# Generated at 2022-06-24 06:37:31.871358
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
                                   'Updates were rejected because the tip of' 
                                   ' your current branch is behind',
                                   'git push origin master')) == 'git pull'

# Generated at 2022-06-24 06:37:33.658603
# Unit test for function get_new_command
def test_get_new_command():
    assert git.get_new_command(Command('git push origin master', '', '')) == 'git pull && git push origin master'

# Generated at 2022-06-24 06:37:35.485636
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull && git push'

# Generated at 2022-06-24 06:37:45.944128
# Unit test for function match
def test_match():
    assert match(Command('git push', "! [rejected]        master -> master (non-fast-forward)\n"
                         "error: failed to push some refs to "
                         "'git@github.com:dogfalo/materialize.git'\n"
                         "hint: Updates were rejected because the tip of your current branch is behind\n"
                         "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                         "hint: 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in 'git push --help' for details.", 
                         ''))

# Generated at 2022-06-24 06:37:55.281716
# Unit test for function match
def test_match():
    assert not match(Command('git push origin master', '', 0))
    assert match(Command(
        'git push origin master',
        'To git@github.com:nvbn/thefuck.git\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
         0))

# Generated at 2022-06-24 06:38:00.642964
# Unit test for function match
def test_match():
    assert match(Command('git push origin ryan',
                         "! [rejected]        ryan -> ryan (non-fast-forward)\n"
                         "error: failed to push some refs to "
                         "'git@github.com:ryan/test.git'\n"
                         "hint: Updates were rejected because the tip of your "
                         "current branch is behind\n"
                         "hint: its remote counterpart. Integrate the remote "
                         "changes (e.g.\n"
                         "hint: 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in "
                         "'git push --help' for details."))

# Generated at 2022-06-24 06:38:09.831955
# Unit test for function match
def test_match():
    assert match(Command('git push', '', ' ! [rejected]        master -> master (fetch first)\n error: failed to push some refs to \'git@github.com:sugyan/dotfiles.git\'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., \'git pull ...\') before pushing again.')) is not None

# Generated at 2022-06-24 06:38:13.128582
# Unit test for function get_new_command
def test_get_new_command():
    """test_get_new_command() -> unit test for get_new_command()"""
    script = 'git push heroku master'
    result = get_new_command(Command(script))
    assert type(result) == Command
    assert 'git pull heroku master' in result.script

# Generated at 2022-06-24 06:38:22.949945
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                          'error: failed to push some refs to '
                          '\'git@github.com:Kamaal111/CS-Practice.git\'\n'
                          'hint: Updates were rejected because the tip of your current branch is behind\n'
                          'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                          'hint: \'git pull ...\') before pushing again.\n'
                          'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))


# Generated at 2022-06-24 06:38:28.417434
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git push origin master', '', '', 1))

    assert new_command.script == 'git pull && git push origin master'

# Generated at 2022-06-24 06:38:37.340460
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/soarthieves/travis_test.git\n ! \
[rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \
\'https://github.com/soarthieves/travis_test.git\'\nhint: Updates were rejected because \
the tip of your current branch is behind\nhint: its remote counterpart. Integrate the \
remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \
\'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:38:38.582703
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 1))



# Generated at 2022-06-24 06:38:47.841871
# Unit test for function match

# Generated at 2022-06-24 06:38:53.213760
# Unit test for function match
def test_match():
    assert not match(Command('push origin master',
                             '',
                             '/home/user/test'))
    assert not match(Command('push origin master',
                             'Updates were rejected',
                             ''))
    assert not match(Command('push origin master',
                             'failed to push some refs to',
                             ''))
    assert match(Command('push origin master',
                         ("Updates were rejected because the tip of your "
                          "current branch is behind"),
                          ''))
    assert match(Command('push origin master',
                         ("Updates were rejected because the remote "
                          "contains work that you do"),
                          ''))


# Generated at 2022-06-24 06:38:56.621708
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '', '', 0, None)) == shell.and_(Command('git pull origin master', '', '', '', 0, None), Command('git push origin master', '', '', '', 0, None))


# Generated at 2022-06-24 06:39:08.438074
# Unit test for function get_new_command
def test_get_new_command():
    # Case 1: Simple
    assert get_new_command(
        Command('git push origin master',
                '''To git@github.com:nvie/gitflow.git
                 ! [rejected]        master -> master (non-fast-forward)
                 error: failed to push some refs to 'git@github.com:nvie/gitflow.git'
                 hint: Updates were rejected because the tip of your current branch is behind
                 hint: its remote counterpart. Integrate the remote changes (e.g.
                 hint: 'git pull ...') before pushing again.
                 hint: See the 'Note about fast-forwards' in 'git push --help' for details.''',
                '')) == 'git pull origin master && git push origin master'

    # Case 2: With "--force" flag

# Generated at 2022-06-24 06:39:17.982406
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]    master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/lk-geimfari/mimesis.git\'\n'
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes '
                         '(e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))
    assert not match(Command('git push origin master',
                             'Everything up-to-date'))

# Generated at 2022-06-24 06:39:21.048757
# Unit test for function get_new_command
def test_get_new_command():
	command = Command("git push origin master")
	assert get_new_command(command) == "git pull&& git push origin master"



# Generated at 2022-06-24 06:39:23.244562
# Unit test for function match
def test_match():
    match_result = match(Command('git push origin master', 'error: failed to push some refs to...'))
    assert match_result


# Generated at 2022-06-24 06:39:24.311479
# Unit test for function match
def test_match():
  assert False


# Generated at 2022-06-24 06:39:33.319404
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push',
                                   output='! [rejected]        master -> master (non-fast-forward)\n'
                                          'error: failed to push some refs to \'https://github.com/michaloo/thefuck-test.git\'\n'
                                          'hint: Updates were rejected becau se the tip of your current branch is behind\n'
                                          'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                          'hint: \'git pull ...\') before pushing again.\n'
                                          'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'
                                          'Michals-MacBook-Pro:thefuck-test michal$ '))

# Generated at 2022-06-24 06:39:38.719451
# Unit test for function match
def test_match():
    assert match(Command('git foo ! [rejected]')) is False
    assert match(Command('git push ! [rejected]')) is False
    assert match(Command('git push ! [rejected] Updates were rejected')) is False
    assert match(Command('git push ! [rejected] Updates were rejected because the tip of your current branch is behind')) is True
    assert match(Command('git push ! [rejected] Updates were rejected because the remote contains work that you do')) is True


# Generated at 2022-06-24 06:39:41.651785
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', 1))
    assert not match(Command('git push', '', 1))

# Generated at 2022-06-24 06:39:43.566269
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git push",
                                   stdout="Updates were rejected because the tip of your current branch is behind",
                                   stderr="Failed to push some refs")) \
        == 'git pull && git push'

# Generated at 2022-06-24 06:39:45.072343
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command()

# Generated at 2022-06-24 06:39:52.628232
# Unit test for function match
def test_match():
    assert match(Command('git push', '', 'fatal: The current branch '
                         'master has no upstream branch.\nTo push the '
                         'current branch and set the remote as upstream, use\n'
                         '\n    git push --set-upstream origin master\n\n'))

# Generated at 2022-06-24 06:40:01.937129
# Unit test for function match
def test_match():
    assert match(Command("git push origin master", "fatal: The current branch \
        master has no upstream branch.\nTo push the current branch and set the \
        remote as upstream, use\n\n    git push --set-upstream origin master\n"))


# Generated at 2022-06-24 06:40:03.812613
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull'

# Generated at 2022-06-24 06:40:13.673490
# Unit test for function match
def test_match():
    assert match(command='git push origin master')
    assert match(command='git push origin master',
                 output='Updates were rejected because the tip of your '
                        'current branch is behind')
    assert match(command='git push origin master',
                 output='Updates were rejected because the tip of your '
                        'current branch is behind')
    assert match(command='git push origin master',
                 output='Updates were rejected because the remote '
                        'contains work that you do not have locally')
    assert match(command='git push origin master',
                 output='Updates were rejected because the remote '
                        'contains work that you do not have locally')
    assert not match(command="git commit")
    assert not match(command='git add .')

# Generated at 2022-06-24 06:40:24.240368
# Unit test for function match
def test_match():
    assert match(Command(script='git push origin master',))
    assert match(Command(script='git push origin master',
                         output='error: failed to push some refs to \'git@gitlab.com:mannan119/thefuck.git\''))
    assert match(Command(script='git push origin master',
                         output=' ! [rejected]        master -> master (non-fast-forward)'))

# Generated at 2022-06-24 06:40:27.215943
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '', '')
    new_command = replace_argument(command.script, 'push', 'pull')
    assert get_new_command(command) == shell.and_(new_command, command.script)

# Generated at 2022-06-24 06:40:33.905289
# Unit test for function get_new_command

# Generated at 2022-06-24 06:40:39.161415
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert (get_new_command(Command('git push origin master')) ==
            ['git pull origin master', 'git push origin master'])
    assert (get_new_command(Command('git push origin master',
                                    'fatal: The current branch master has '
                                    'no upstream branch.\nTo push the '
                                    'current branch and set the remote as '
                                    'upstream, use\n\tgit push --set-upstream'
                                    ' origin master')) ==
            ['git pull --set-upstream origin master',
             'git push --set-upstream origin master'])

# Generated at 2022-06-24 06:40:43.294577
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind.\n  (use "git pull" to update your local branch)')) == 'git pull && git push'


# Generated at 2022-06-24 06:40:52.277395
# Unit test for function match

# Generated at 2022-06-24 06:40:56.410219
# Unit test for function match
def test_match():
	assert match(Command('git push', 'git push! [rejected] unkonw -> unkonw (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nUpdates were rejected because the remote contains work that you do\n'))

# Generated at 2022-06-24 06:40:59.492025
# Unit test for function get_new_command
def test_get_new_command():
    command = "git push origin master"
    new_command = shell.and_(shell.and_("git pull origin master", command))
    assert get_new_command(Command(command, command))
    assert get_new_command(Command(command, command)) == new_command

# Generated at 2022-06-24 06:41:06.537081
# Unit test for function match
def test_match():
    # Test if the match function is working
    # Create Command class object command
    command = Command('git push', '!'
                      ' [rejected]        master -> master (non-fast-forward)'
                      '\n error: failed to push some refs to \'https://github.com/...\''
                      '\n hint: Updates were rejected because '
                      'the tip of your current branch is behind'
                      '\n hint: its remote counterpart. Integrate the remote changes '
                      '(e.g.\n hint: \'git pull ...\') before pushing again.\n'
                      'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'
                      '\n', '', 0)
    # Do the match
    result = match(command)
    # Print the result
    print(result)
   

# Generated at 2022-06-24 06:41:09.640784
# Unit test for function match
def test_match():
    assert match(command.Script('git push origin master'), None)
    assert not match(command.Script('git pull origin master'), None)


# Generated at 2022-06-24 06:41:14.665398
# Unit test for function get_new_command
def test_get_new_command():
    command = type('obj', (object,),
                   {'script': "git push",
                    'output': 'failed to push some refs to'})
    assert get_new_command(command) == "git pull && git push"


# Generated at 2022-06-24 06:41:26.015971
# Unit test for function match
def test_match():
    # Case 1: script only contains git push, expected return is False
    assert match(Command('git push')) == False
    # Case 2: script contains git push and output contains specific strings,
    # expected return is True
    assert match(Command('git push', '! [rejected] ... failed to push some refs to')) == True
    assert match(Command('git push', '...content...Updates were rejected because the tip of your current branch is behind')) == True
    assert match(Command('git push', '...content...Updates were rejected because the remote contains work that you do')) == True
    # Case 3: script contains git push and output contains specific strings,
    # but output contains more than one of these specific strings, expected return is True

# Generated at 2022-06-24 06:41:34.787819
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]            master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:username/project.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-24 06:41:35.899062
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('push', '', '', '', '', '')) == 'pull'

# Generated at 2022-06-24 06:41:38.351843
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', '', '')
    assert get_new_command(command) == shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-24 06:41:43.171376
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'error: failed to push some refs to ...',
                         'To prevent you from losing history, non-fast-forward'))
    assert match(Command('git push origin master',
                         'error: failed to push some refs to ...',
                         'Updates were rejected because the remote contains'))
    assert not match(Command('git push origin master',
                             'To prevent you from losing history, non-fast-forward'))
    assert not match(Command('git push origin master',
                             'Updates were rejected because the remote contains'))


# Generated at 2022-06-24 06:41:44.991243
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push')
    assert get_new_command(command) == 'git pull'

# Generated at 2022-06-24 06:41:53.396970
# Unit test for function match
def test_match():
    assert match(Command("git push -u origin master", "", ""))
    assert match(Command("git push -u origin master", "To git@github.com:nvbn/thefuck.git\n ! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to 'git@github.com:nvbn/thefuck.git'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.", ""), "git pull && git push -u origin master")

# Generated at 2022-06-24 06:42:03.943617
# Unit test for function match
def test_match():
    assert match(Command('git push',
        "To https://github.com/tford/HW.git\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to 'https://github.com/tford/HW.git'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.",
        'git push https://github.com/tford/HW.git'))
    assert not match(Command('git push', 'Everything up-to-date', 'git push'))

# Generated at 2022-06-24 06:42:13.645998
# Unit test for function match
def test_match():
    assert(match(Command('git push',
                         'To https://github.com/nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
                         'https://github.com/nvbn/thefuck',
                         1408797037.0, None)))


# Generated at 2022-06-24 06:42:20.166576
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'git: ! [rejected]        master -> master (non-fast-forward)\ngit: error: failed to push some refs to \'some_repository\'\ngit: hint: Updates were rejected because the tip of your current branch is behind\ngit: hint: its remote counterpart. Integrate the remote changes (e.g.\ngit: hint: \'git pull ...\') before pushing again.\ngit: hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')) == 'git pull && git push'

# Generated at 2022-06-24 06:42:31.135353
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '',
                         'Updates were rejected because the tip of your '
                         'current branch is behind its remote counterpart. '
                         'Integrate the remote changes (e.g.hint: '
                         ''''git pull ...') before pushing again.\n'''
                         'See the \'Note about fast-forwards\' section of '
                         '\'git push --help\' for details.\n'))


# Generated at 2022-06-24 06:42:33.068003
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push')) == 'git pull'
    assert get_new_command(Command('git push --repo=foo')) == 'git pull --repo=foo'

# Generated at 2022-06-24 06:42:42.948802
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To git@github.com:nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
                         ''))
    assert not match(Command('git push origin master', '', ''))
    assert not match(Command('git commit', '', ''))

# Generated at 2022-06-24 06:42:44.860160
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', 'failed to push some refs to')) == 'git pull'

# Generated at 2022-06-24 06:42:54.863812
# Unit test for function get_new_command

# Generated at 2022-06-24 06:43:00.273558
# Unit test for function get_new_command

# Generated at 2022-06-24 06:43:05.382230
# Unit test for function get_new_command
def test_get_new_command():
    output = (
        'To https://github.com/nvbn/thefuck.git\n ! [rejected]        master -> master (fetch first)\n '
        'error: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\n '
        'hint: Updates were rejected because the remote contains work that you do\n '
        'hint: not have locally. This is usually caused by another repository pushing\n '
        'hint: to the same ref. You may want to first integrate the remote changes\n '
        'hint: (e.g., \'git pull ...\') before pushing again.\n '
        'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n '
    )

# Generated at 2022-06-24 06:43:12.847781
# Unit test for function get_new_command
def test_get_new_command():
    script = "git push origin master"
    output = '''
To github.com:michaln3/thefuck.git
! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:michaln3/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''
    compare_match_and_get_new_command(script, output)

# Generated at 2022-06-24 06:43:15.718123
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git pull && git push' == get_new_command('git push')

# Generated at 2022-06-24 06:43:18.353767
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', '! [rejected] master -> master (non-fast-forward)\n', '')) ==
            'git pull && git push')

# Generated at 2022-06-24 06:43:28.890603
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To git@github.com:nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)',
                         '', 1))
    assert match(Command('git push origin master',
                         """To git@github.com:nvbn/thefuck.git\n ! [rejected]        master -> master (fetch first)""",
                         'error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'', 1))

# Generated at 2022-06-24 06:43:39.716082
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push',
                        'Updates were rejected because the remote contains work that you do not have locally.\n'
                        'This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes before pushing again.\n'
                        'See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert get_new_command(Command('git push',
                                   'Updates were rejected because the remote contains work that you do not have locally.\n'
                                   'This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes before pushing again.\n'
                                   'See the \'Note about fast-forwards\' in \'git push --help\' for details.'
                                    )) == command

# Generated at 2022-06-24 06:43:42.471740
# Unit test for function get_new_command
def test_get_new_command():
    get_new_command(Command("git push origin master", "Updates were rejected because the tip of your current branch is behind some commit remote commit. Merge the remote changes (e.g. 'git pull') before pushing again", "git-push-1")) == "git pull origin master && git push origin master"

# Generated at 2022-06-24 06:43:51.837679
# Unit test for function match
def test_match():
    assert match(Command('git push origin master:master', ''))
    assert not match(Command('git push origin master:master', '', stderr='fatal: The current branch foo has no upstream branch. To push the current branch and set the remote as upstream, use git push --set-upstream origin foo'))
    assert not match(Command('git push origin master:master', '', stderr='fatal: The current branch foo has no upstream branch. To push the current branch and set the remote as upstream, use git push --set-upstream origin foo'))
    assert not match(Command('git push origin master:master', '', stderr='fatal: '))
    assert not match(Command('git push origin master:master', '', stderr='fatal:'))

# Generated at 2022-06-24 06:43:55.107293
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'Updates were rejected because the tip of your current branch is behind some commits')) == 'git pull && git push'


# Generated at 2022-06-24 06:43:57.306448
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master'
    assert get_new_command('git push origin develop') == 'git pull origin develop'

# Generated at 2022-06-24 06:44:07.691135
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
        '! [rejected]        master -> master (fetch first)\n'
        'error: failed to push some refs to \'../../git-repos/git_repo.git\'\n'
        'hint: Updates were rejected because the remote contains work that you do\n'
        'hint: not have locally. This is usually caused by another repository pushing\n'
        'hint: to the same ref. You may want to first integrate the remote changes\n'
        'hint: (e.g., \'git pull ...\') before pushing again.\n'
        'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))



# Generated at 2022-06-24 06:44:14.928950
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push", "! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to 'git@github.com:user/repo.git'\nTo prevent you from losing history, non-fast-forward updates were rejected\nMerge the remote changes before pushing again.  See the 'Note about\nfast-forwards' section of 'git push --help' for details.")
    assert get_new_command(command) == "git pull && git push"

# Generated at 2022-06-24 06:44:23.303228
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '')) == False
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:user/repo.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) == True

# Generated at 2022-06-24 06:44:33.080869
# Unit test for function match

# Generated at 2022-06-24 06:44:39.457283
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push -u origin master', 
                'To https://github.com/user/repo.git\n ! [rejected] master -> master (non-fast-forward)\n\
                error: failed to push some refs to \'https://github.com/user/repo.git\'\n\
                hint: Updates were rejected because the tip of your current branch is behind\n\
                hint: its remote counterpart. Integrate the remote changes (e.g.\n\
                hint: \'git pull ...\') before pushing again.\n\
                hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) == 'git pull --set-upstream origin master && git push -u origin master'

# Generated at 2022-06-24 06:44:49.025951
# Unit test for function match
def test_match():
    # Test if match is true when having a git push problem
    example = Command(script = "git push origin master",
        output = "error: failed to push some refs to 'https://github.com/user/repo.git'\n"
        "hint: Updates were rejected because the tip of your current branch is behind\n"
        "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
        "hint: 'git pull ...') before pushing again.\n"
        "hint: See the 'Note about failepush' in 'git push --help' for details.\n")
    assert match(example)


# Generated at 2022-06-24 06:44:57.297616
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git push'
    output = """To https://github.com/microsoft/vscode-go.git
! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/microsoft/vscode-go.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details."""
    assert get_new_command(Command(script, output)) == "git pull && git push"

# Generated at 2022-06-24 06:45:06.748572
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'error: failed to push some refs to\n'
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'To prevent you from losing history, non-fast-forward updates were rejected\n'
                         'Merge the remote changes (e.g. '
                         '\'git pull\') before pushing again.  See the\n'
                         '\'Note about fast-forwards\' section of \'git push --help\' for details.\n',
                         '', 1))

# Generated at 2022-06-24 06:45:14.575967
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'fatal: The current branch dummy has no upstream branch.\n'
                         'To push the current branch and set the remote as upstream, use\n'
                         '\n'
                         '    git push --set-upstream origin dummy\n'
                         '\n',
                         'git pull'))

# Generated at 2022-06-24 06:45:20.003670
# Unit test for function match
def test_match():
    assert match(Command('git push', 
    '''To git@github.com:user/repo.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'git@github.com:user/repo.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-24 06:45:25.137346
# Unit test for function match
def test_match():
    assert match(Command('git push', 'error: failed to push some refs to'))
    assert not match(Command('git push', 'Not behind'))

# Generated at 2022-06-24 06:45:31.148807
# Unit test for function match
def test_match():
    script1 = 'git push origin master'
    output1 = '''git push origin master
To git@github.com:username/repo.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:username/repo.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''
    script2 = 'git push origin master'

# Generated at 2022-06-24 06:45:41.406582
# Unit test for function match
def test_match():
    command = Command("git push origin master", "")
    git_output = ("! [rejected]        master -> master (non-fast-forward)\n"
                  "error: failed to push some refs to 'git@github.com:xxx/xxx.git'\n"
                  "hint: Updates were rejected because the tip of your current branch is behind\n"
                  "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                  "hint: 'git pull ...') before pushing again.\n"
                  "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n")
    assert match(Command(command.script, git_output))

    command = Command("git push origin master", "")