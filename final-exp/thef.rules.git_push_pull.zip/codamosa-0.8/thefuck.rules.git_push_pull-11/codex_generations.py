

# Generated at 2022-06-12 11:39:54.543418
# Unit test for function match

# Generated at 2022-06-12 11:39:59.265139
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-12 11:40:06.838463
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'remote: ! [rejected]\n'
                         'remote: error: failed to push some refs to\n'
                         'remote: Updating the following files would be '
                         'overwritten by merge:\nremote: \tfile.py\nremote: '
                         'Please, commit your changes or stash them before you '
                         'can merge.')
                  )

# Generated at 2022-06-12 11:40:15.393970
# Unit test for function match
def test_match():
    assert match(command=Command('git push origin master',
                                 '! [rejected] master -> master (non-fast-forward)\n'
                                 'error: failed to push some refs to\n'
                                 'hint: Updates were rejected because the tip'
                                 ' of your current branch is behind\n'
                                 'hint: its remote counterpart. Integrate'
                                 ' the remote changes (e.g.\n'
                                 'hint: \'git pull ...\') before pushing again.\n'
                                 'hint: See the \'Note about fast-forwards\' in'
                                 ' \'git push --help\' for details.'))

# Generated at 2022-06-12 11:40:24.232024
# Unit test for function match

# Generated at 2022-06-12 11:40:26.724497
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.main import Command

    assert get_new_command(Command('git push', '', '')) == 'git pull'


# Generated at 2022-06-12 11:40:33.276997
# Unit test for function match
def test_match():
    assert match(Command('git push --set-upstream origin master',
                         stderr=''' ! [rejected] master -> master (fetch first)
                   error: failed to push some refs to 
                   To prevent you from losing history, non-fast-forward updates were rejected
                   Merge the remote changes (e.g. 'git pull') before pushing again. 
                   See the 'Note about fast-forwards' section of 'git push --help' for details.'''))


# Generated at 2022-06-12 11:40:34.820948
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('push', '', '', '')) == 'pull'

# Generated at 2022-06-12 11:40:43.901910
# Unit test for function match
def test_match():
    assert match(Command('git push', "! [rejected]        master -> master (fetch first)error: failed to push some refs to 'ssh://git@code.example.com/user/repo.git'"))
    assert match(Command('git push', '! [rejected]        master -> master (fetch first)Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', '! [rejected]        master -> master (fetch first)Updates were rejected because the remote contains work that you do'))
    assert not match(Command('git pull', "! [rejected]        master -> master (fetch first)error: failed to push some refs to 'ssh://git@code.example.com/user/repo.git'"))


# Generated at 2022-06-12 11:40:45.249614
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')).script == 'git pull && git push origin master'

# Generated at 2022-06-12 11:40:50.801767
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command('git pull origin master')
    expected_command = '&& git pull origin master'
    assert new_command == expected_command

# Generated at 2022-06-12 11:41:00.454877
# Unit test for function match
def test_match():
    assert match(Command('git push origin master:master',
                         ' ! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to \'git@github.com:lzxb082/test_git.git\'\n'
                         'hint: Updates were rejected because the remote contains work that you do\n'
                         'hint: not have locally. This is usually caused by another repository pushing\n'
                         'hint: to the same ref. You may want to first integrate the remote changes\n'
                         'hint: (e.g., \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')) == True


# Generated at 2022-06-12 11:41:01.927345
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-12 11:41:13.016881
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '! [rejected] master -> master (non-fast-forward)\n'
                     'error: failed to push some refs to \'https://github.com/1612180/1612180.github.io.git\'\n'
                     'hint: Updates were rejected because the tip of your current branch is behind\n'
                     'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                     'hint: \'git pull ...\') before pushing again.\n'
                     'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-12 11:41:23.833186
# Unit test for function match
def test_match():
	assert not match(Command('git push origin master'))
	assert match(Command('git push origin master', "! [rejected]        master -> master (non-fast-forward)\nTo git@github.com:nvbn/thefuck.git\n! [rejected]        master -> master (fetch first)\nTo git@github.com:nvbn/thefuck.git\n   089d3ae..a09adb3  master     -> origin/master\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\nhint: 'git pull ...') before pushing again.\nSee the 'Note about fast-forwards' section of 'git push --help' for details."))

# Generated at 2022-06-12 11:41:29.008900
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                    'Failed with error: fatal: ' +
                    'The remote end hung up unexpectedly'))
    assert match(Command('git push origin master',
                    'Failed with error: fatal: ' +
                    'The remote end hung up unexpectedly'))
    assert match(Command('git push origin master',
                    'Failed with error: fatal: ' +
                    'The remote end hung up unexpectedly'))



# Generated at 2022-06-12 11:41:34.064150
# Unit test for function match
def test_match():
    assert (match(Command('git push', '',
                         'To https://github.com/nvbn/thefuck\n'
                         ' ! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to '
                         "'https://github.com/nvbn/thefuck'\n"
                         'hint: Updates were rejected because the tip of your '
                         "current branch is behind\n"
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\n'
                         'hint: '
                         "'git pull ...') before pushing again.\n"
                         'hint: See the '
                         "'Note about fast-forwards' in 'git push --help' for details.'\n")))

# Generated at 2022-06-12 11:41:37.481095
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push") == shell.and_("git pull", "git push")
    assert "git push" not in get_new_command("git push")

# Generated at 2022-06-12 11:41:39.753819
# Unit test for function match

# Generated at 2022-06-12 11:41:50.641509
# Unit test for function get_new_command
def test_get_new_command():
    output = '''
! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/ififi/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''
    command = Command('git push origin master', output=output)
    assert get_new_command(command) == \
        'git pull origin master && git push origin master'


# Generated at 2022-06-12 11:42:01.273150
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To git@github.com:nvbn/thefuck.git\n ! [rejected] '
                         'master -> master (fetch first)\nerror: failed '
                         'to push some refs to '
                         '\'git@github.com:nvbn/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your'
                         ' current branch is behind\nhint: its remote'
                         ' counterpart. Integrate the remote changes '
                         '(e.g.\nhint: \'git pull ...\') before pushing again.'
                         '\nhint: See the \'Note about fast-forwards\' '
                         'in \'git push --help\' for details.\n'))

# Generated at 2022-06-12 11:42:02.484665
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull'

# Generated at 2022-06-12 11:42:03.836720
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git pull') == 'git pull && git pull'

# Generated at 2022-06-12 11:42:06.660475
# Unit test for function match
def test_match():
    assert match(Command('git push', ''))
    assert not match(Command('git push', 'Everything up-to-date\n'))


# Generated at 2022-06-12 11:42:08.683091
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'


enabled_by_default = True

# Generated at 2022-06-12 11:42:10.781577
# Unit test for function match

# Generated at 2022-06-12 11:42:13.592419
# Unit test for function match
def test_match():
    print(match(Command('git push origin master', '', '', False)))
    print(match(Command('git push origin master', '', '', False)))
    print(match(Command('git push origin master', '', '', False)))


# Generated at 2022-06-12 11:42:22.327318
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to \'https://github.com/USERNAME/REPOSITORY.git\'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))
    assert not match(Command('git push', 'Everything up-to-date'))
    assert not match(Command('git push', ''))

# Generated at 2022-06-12 11:42:32.619312
# Unit test for function match
def test_match():
    assert match(Command('push', 'Updates were rejected because the '
                         'remote contains work that you do not have.'
                         'This is usually caused by another repository pushing'
                         'to the same ref. You may want to first integrate'
                         'the remote changes before pushing again.'))
    assert match(Command('git push', 'Updates were rejected because the tip'
                         'of your current branch is behind its remote'
                         'counterpart. Integrate the remote changes (e.g.'
                         'hint: \'git pull ...\') before pushing again.'))
    assert match(Command('git push', 'Updates were rejected because the remote'
                         ' contains work that you do not have.'
                         'This is usually caused by another repository pushing'
                         'to the same ref. You may want to first integrate the'
                         ' remote changes before pushing again.'))


# Generated at 2022-06-12 11:42:41.002627
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 1, None))
    assert not match(Command('git push origin master', '', '! [rejected]', 1,
                             None))
    assert not match(Command('git push origin master', '', '', 1,
                             None))
    assert not match(Command('git commit', '', '', 1, None))
    assert match(Command('git push origin master', '',
                         'Updates were rejected because the tip of your'
                         ' current branch is behind', 1, None))
    assert match(Command('git push origin master', '',
                         'Updates were rejected because the remote '
                         'contains work that you do', 1, None))

# Generated at 2022-06-12 11:42:46.855581
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', '', '', ''))
    assert not match(Command('git', '', '', '', '', ''))

# Generated at 2022-06-12 11:42:49.653616
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
                                   'Updates were rejected because the remote contains work that you do')) == 'git pull && git push'

# Generated at 2022-06-12 11:42:58.213432
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/amirbawab/Git.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Merge the remote changes (e.g. \'git pull\')\nhint: before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))
    assert not match(Command('git push', 'Counting objects: 33, done.'))

# Generated at 2022-06-12 11:43:05.649862
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]\n'
                         'error: failed to push some refs to'
                         ' \'git@github.com:nvbn/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind its remote counterpart. '
                         'Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.',
                         '', 3.141592653589793))


# Generated at 2022-06-12 11:43:13.867913
# Unit test for function match
def test_match():

    #test 1
    output1='''
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/bouisjulien/PFE_Fond_Blanc_ANDROID.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''

# Generated at 2022-06-12 11:43:21.906280
# Unit test for function match
def test_match():
    command = Command('git push', '! [rejected]        master -> master (fetch first)\n'
                                  'error: failed to push some refs to \'git@github.com:PeterChau1994/test.git\'\n'
                                  'hint: Updates were rejected because the remote contains work that you do\n'
                                  'hint: not have locally. This is usually caused by another repository pushing\n'
                                  'hint: to the same ref. You may want to first integrate the remote changes\n'
                                  'hint: (e.g., \'git pull ...\') before pushing again.')
    assert match(command)



# Generated at 2022-06-12 11:43:25.792167
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push --force') == 'git pull --force && git push --force'
    assert get_new_command('git push --tag') == 'git pull --tag && git push --tag'
    assert get_new_command('git push') == 'git pull && git push'

# Generated at 2022-06-12 11:43:34.017913
# Unit test for function get_new_command
def test_get_new_command():
    assert_equal(get_new_command(
        Command('git push',
                'To git@github.com:nvbn/thefuck.git\n ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')),
                 'git pull && git push')


enabled_by_default = True

# Generated at 2022-06-12 11:43:40.013756
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'git pull origin master')) == shell.and_('git pull', 'git push')
    assert get_new_command(Command('git push -u origin master', 'git pull origin master')) == shell.and_('git pull -u origin master', 'git push -u origin master')

# Generated at 2022-06-12 11:43:44.483164
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command("git push") == "git pull && git push")
    assert(get_new_command("git push origin master") == "git pull origin master && git push origin master")
    assert(get_new_command("git push origin master --force") == "git pull origin master --force && git push origin master --force")


# Generated at 2022-06-12 11:43:52.927092
# Unit test for function match
def test_match():
    assert match(Command('git push', 
                    'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', 
                    'failed to push some refs to'))
    assert match(Command('git push', 
                    'Updates were rejected because the remote contains work that you do'))
    assert not match(Command('git commit', 
                    'failed to push some refs to'))

# Generated at 2022-06-12 11:44:01.302487
# Unit test for function match
def test_match():
    assert match(Command('push', script='git push origin master',
                         output='! [rejected]        master -> master (non-fast-forward)\n\
                                 error: failed to push some refs to \'git@github.com:user/repo.git\'\n\
                                 hint: Updates were rejected because the tip of your current branch is behind\n\
                                 hint: its remote counterpart. Integrate the remote changes (e.g.\n\
                                 hint: \'git pull ...\') before pushing again.\n\
                                 hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:44:09.485504
# Unit test for function get_new_command
def test_get_new_command():
    # Test 1: Check whether get_new_command replaces push and adds
    # "And" command
    assert get_new_command(Command('git push origin master',
                                   '''To https://github.com/tokman/tokman.github.io
    ! [rejected]        master -> master (fetch first)
    error: failed to push some refs to 'https://github.com/tokman/tokman.github.io'
    hint: Updates were rejected because the tip of your current branch is behind
    hint: its remote counterpart. Integrate the remote changes (e.g.
    hint: 'git pull ...') before pushing again.
    hint: See the 'Note about fast-forwards' in 'git push --help' for details.''')) == "git pull origin master && git push origin master"
    # Test 2:

# Generated at 2022-06-12 11:44:11.560339
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull && git push origin master'

# Generated at 2022-06-12 11:44:17.823659
# Unit test for function match
def test_match():
    command = Command('git push origin', '', '', '', '', '')
    assert match(command)

# Generated at 2022-06-12 11:44:19.058497
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git pull' in get_new_command('git push')


priority = 8000

# Generated at 2022-06-12 11:44:29.200909
# Unit test for function match
def test_match():
    git_cmd = 'git push origin master'
    # Test match
    assert match(Command(script=git_cmd, output="""
error: failed to push some refs to 'git@github.com:mislav/dotfiles.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.""")
    )

# Generated at 2022-06-12 11:44:30.832679
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('git push origin master')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-12 11:44:32.321677
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '')
    assert(get_new_command(command) == (
            'git pull && git push'))

# Generated at 2022-06-12 11:44:32.995204
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull && git push'

# Generated at 2022-06-12 11:44:40.922025
# Unit test for function match
def test_match():
    command = Command('git push', 'error: failed to push some refs to...')
    assert match(command)
    command = Command('git baz', 'error: failed to push some refs to...')
    assert not match(command)



# Generated at 2022-06-12 11:44:46.345303
# Unit test for function match
def test_match():
    assert match(Command('git push', "! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Merge the remote changes (e.g. 'git pull') before pushing again.\n"))
    assert not match(Command('git branch', '* master'))
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes before pushing again.'))

# Generated at 2022-06-12 11:44:51.871488
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull && git push'
    assert get_new_command('git push origin master') == 'git pull && git push origin master'
    assert get_new_command('git push --repo test') == 'git pull && git push --repo test'
    assert get_new_command('git push origin master --repo test') == 'git pull && git push origin master --repo test'

# Generated at 2022-06-12 11:44:54.800377
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push origin master', ''))
            == 'git pull origin master && git push origin master')

# Generated at 2022-06-12 11:45:02.483754
# Unit test for function match
def test_match():
    # Test with script that should return True
    output = """
    ! [rejected]        test -> test (non-fast-forward)
    error: failed to push some refs to 'https://github.com/MichMich/MagicMirror.git'
    hint: Updates were rejected because the tip of your current branch is behind
    hint: its remote counterpart. Integrate the remote changes (e.g.
    hint: 'git pull ...') before pushing again.
    hint: See the 'Note about fast-forwards' in 'git push --help' for details.
    """
    command = Command(script="git push origin master", output=output)
    assert match(command)

# Generated at 2022-06-12 11:45:10.968561
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '''To https://github.com/user/repo.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/user/repo.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))



# Generated at 2022-06-12 11:45:20.573126
# Unit test for function match
def test_match():
    assert(match(Command('push', '! [rejected] master -> master (non-fast-forward)\n'
                         'Updates were rejected because the tip of your '
                         'current branch is behind its remote counterpart. '
                         'Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'See the \'Note about fast-forwards\' in \'git push '
                         '--help\' for details.', '', 5)))

# Generated at 2022-06-12 11:45:28.658998
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)', 'Updates were rejected because the remote contains work that you do'))
    assert not match(Command('git push', '! [rejected]        master -> master (non-fast-forward)', 'Updates were rejected because the remote contains work that you do not have locally'))


# Generated at 2022-06-12 11:45:30.543262
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push origin master ', '')) ==
            'git pull origin master && git push origin master')

# Generated at 2022-06-12 11:45:37.137337
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master',
                      'Updates were rejected because the tip of your current branch is behind')
    assert get_new_command(command) == 'git pull origin master && git push origin master'
    command = Command('git push origin master',
                      'Updates were rejected because the remote contains work that you do')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-12 11:45:46.716192
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git push'
    result = 'git pull && git push'
    assert get_new_command(Command(script, '! [rejected]')) == result

# Generated at 2022-06-12 11:45:48.052000
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'

# Generated at 2022-06-12 11:45:52.652999
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', "! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind.\nMerge the remote changes (e.g. 'git pull') before pushing again.\nSee the 'Note about fast-forwards' in 'git push --help' for details.", 'git push')) == "git pull && git push"

# Generated at 2022-06-12 11:45:54.748323
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'
    assert get_new_command('git push origin master').script == 'git pull origin master && git push origin master'

# Generated at 2022-06-12 11:46:04.287739
# Unit test for function get_new_command
def test_get_new_command():
    cur_cmd = 'git push'
    out = ''' ! [rejected]        master -> master (fetch first)
 error: failed to push some refs to 'git@github.com:agiliq/django-payu.git'
 hint: Updates were rejected because the remote contains work that you do
 hint: not have locally. This is usually caused by another repository pushing
 hint: to the same ref. You may want to first integrate the remote changes
 hint: (e.g., 'git pull ...') before pushing again.
 hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''
    assert get_new_command(Command(script=cur_cmd, output=out)) == "git pull && git push"


# Generated at 2022-06-12 11:46:14.410878
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         "To https://sjmoon@github.com/sjmoon/thefuck.git\n ! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to 'https://sjmoon@github.com/sjmoon/thefuck.git'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.\n",
                         '', 1)) 

# Generated at 2022-06-12 11:46:16.562606
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('push')) == 'pull'
    assert get_new_command(Command('push origin master')) == 'pull origin master'

# Generated at 2022-06-12 11:46:23.310473
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do\n  (use "git pull" to update your local branch)'))
    assert not match(Command('git push', 'Everything up-to-date'))
    assert not match(Command('git push', 'Updates were rejected because the remote contains work that you do\n  (use "git pull" to update your local branch)'))
    assert not match(Command('git push', 'Everything up-to-date'))


# Generated at 2022-06-12 11:46:24.895067
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git push", "! [rejected] dev -> dev (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nits remote counterpart. Integrate the remote changes (e.g.\n'git pull ...') before pushing again.\n")) == "git pull && git push"

# Generated at 2022-06-12 11:46:33.548601
# Unit test for function match
def test_match():
    assert match(Command('git push', '/home/user/repo', '', '! [rejected]',
                         'Updates were rejected because the tip of your current branch is behind',
                         'failed to push some refs to'))
    assert match(Command('git push', '/home/user/repo', '', '! [rejected]',
                         'Updates were rejected because the remote contains work that you do',
                         'failed to push some refs to'))

# Generated at 2022-06-12 11:46:55.305219
# Unit test for function match
def test_match():
    assert match(Command(script="git push origin master",
        output='''! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'ssh://git@bitbucket.org/user/repo.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''))

# Generated at 2022-06-12 11:47:00.752223
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         output='! [rejected]        master -> master (non-fast-forward)',
                         ))
    assert not match(Command('git commit',
                             output='! [rejected]        master -> master (non-fast-forward)',
                             ))
    assert not match(Command('git commit',
                             output='! [rejected]        master -> master (non-fast-forward)',
                             ))

# Generated at 2022-06-12 11:47:08.251887
# Unit test for function match
def test_match():
    output_1 = '''To git@git.assembla.com:myrepo.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@git.assembla.com/myrepo.git
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''

# Generated at 2022-06-12 11:47:09.023296
# Unit test for function match
def test_match():
    assert match('git push origin master')


# Generated at 2022-06-12 11:47:11.931506
# Unit test for function match
def test_match():
	# Test 1 Match
	assert match(Command('git push', 'Updates were rejected because the tip of your current branch is behind'))
	# Test 2 Does not match
	assert not match(Command('git add', 'Updating'))

# Generated at 2022-06-12 11:47:20.112731
# Unit test for function match
def test_match():
    command = Command('git push origin abcdef:master', '''\
    To ../abc.git
     ! [rejected]        abcdef -> master   (non-fast-forward)
    error: failed to push some refs to '../abc.git'
    hint: Updates were rejected because the tip of your current branch is behind
    hint: its remote counterpart. Integrate the remote changes (e.g.
    hint: 'git pull ...') before pushing again.
    hint: See the 'Note about fast-forwards' in 'git push --help' for details.
    ''')
    assert match(command)


# Generated at 2022-06-12 11:47:23.014323
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 12, None))
    assert match(Command('git push', '', '', 12, None))
    assert not match(Command('ls', '', '', 1, None))

# Generated at 2022-06-12 11:47:28.353557
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master',
                      'To git@github.com:nvbn/fucking-great-advice.git! [rejected] master -> master (fetch first)\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\n\ngit pull ...\n\n) before pushing again.\nSee the \'Note about fast-forwards\' section of \'git push --help\' for details.')
    assert get_new_command(command) == 'git pull origin master && git push origin master'


# Generated at 2022-06-12 11:47:37.491567
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'fatal: Upda',))
    assert match(Command('git push origin master',
                         'fatal: Upda',
                         'fatal: Updates were rejected because the tip'
                         ' of your current branch is behind',))
    assert match(Command('git push origin master',
                         'fatal: Upda',
                         'fatal: Updates were rejected because the remote '
                         'contains work that you do',))
    assert not match(Command('git push origin master',
                             'fatal: Updates were rejected because the tip'
                             ' of your current branch is behind',))
    assert not match(Command('git push origin master',
                             'fatal: Updates were rejected because the remot'
                             'e contains work that you do',))


# Generated at 2022-06-12 11:47:43.453995
# Unit test for function get_new_command
def test_get_new_command():
    '''Test git pull'''

# Generated at 2022-06-12 11:48:07.069442
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         "! [rejected]        master -> master (non-fast-forward)\n' + \
                         'error: failed to push some refs to ' + \
                         ''https://github.com/nvbn/thefuck.git' + \
                         '\nTo prevent you from losing history, non-fast-forward updates' + \
                         ' were rejected\nMerge the remote changes (e.g. ' + \
                         'git pull) before pushing again.  See the ' + \
                         '\'Note about fast-forwards\' section of ' + \
                         '\'git push --help\' for details.\n",
                         '', 0))


# Generated at 2022-06-12 11:48:14.066562
# Unit test for function match
def test_match():
    assert match(Command('git push',
                                '! [rejected]            master -> master (non-fast-forward)\n'
                                'error: failed to push some refs to \'https://github.com/sigmavirus24/github3.py.git\'\n'
                                'hint: Updates were rejected because the tip of your current branch is behind\n'
                                'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                'hint: \'git pull ...\') before pushing again.\n'
                                'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:48:21.156072
# Unit test for function match

# Generated at 2022-06-12 11:48:23.367289
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git push', '', ''))
    assert new_command == shell.and_('git pull', 'git push')

# Generated at 2022-06-12 11:48:32.430992
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(
        Command('git push',
                'remote: HTTP Basic: Access denied\nfatal: '
                'The remote end hung up unexpectedly\n'
                'error: failed to push some refs to '
                '\'https://github.com/user/repo.git\'',
                '')) ==
            'git pull; git push')

# Generated at 2022-06-12 11:48:38.036508
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script': 'git push',
                    'output': 'Updates were rejected because the tip of your'
                              ' current branch is behind'})
    assert get_new_command(command) == 'git pull && git push'

    command = type('Command', (object,),
                   {'script': 'git push',
                    'output': 'Updates were rejected because the remote '
                              'contains work that you do'})
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-12 11:48:40.404024
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', 'error: failed to push some refs to')) == 'git pull && git push origin master'

# Generated at 2022-06-12 11:48:47.944963
# Unit test for function get_new_command
def test_get_new_command():
    assert set(get_new_command(Command('git push origin master',
                                       '! [rejected] master -> master (fetch first)'
                                       '\nUpdates were rejected because the tip of your'
                                       ' current branch is behind its remote counterpart.'
                                       ' Integrate the remote changes (e.g.'
                                       '\n git pull ...)\nbefore pushing again.'
                                       '\nSee the \'Note about fast-forwards\' in '
                                       '\'git push --help\' for details.',
                                       '')).script) == set(['git pull origin master && git push origin master'])



# Generated at 2022-06-12 11:48:57.241800
# Unit test for function match
def test_match():
    command = Command("git push")
    assert(match(command) == None)

    command = Command("git push origin master")
    assert(match(command) == None)


# Generated at 2022-06-12 11:49:06.382563
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'git@github.com:SuyashLakhotia/dotFiles.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))