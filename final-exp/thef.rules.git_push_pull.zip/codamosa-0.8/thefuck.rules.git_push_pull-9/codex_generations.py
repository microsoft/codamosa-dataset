

# Generated at 2022-06-12 11:39:52.519155
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         "error: failed to push some refs to 'git@some_site:user/test'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g\nhint: 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details."))
    assert not match(Command('ls', ''))

# Generated at 2022-06-12 11:39:57.916145
# Unit test for function match
def test_match():
    assert match(Command('git push origin ', '! [rejected] master -> master (non-fast-forward)', 0))
    assert match(Command('git push origin ', 'error: failed to push some refs to', 0))
    assert match(Command('git push origin ', 'Updates were rejected because the tip of your current branch is behind', 0))
    assert match(Command('git push origin ', 'Updates were rejected because the remote contains work that you do', 0))
    assert not match(Command('git push origin ', 'error: src refspec master does not match any', 0))


# Generated at 2022-06-12 11:40:05.650336
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '1'))
    assert match(Command('git push', '! [rejected]\n error: failed to push some refs to', '1'))
    assert not match(Command('git push', '', '1'))
    assert not match(Command('git push', '! [rejected]\n Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes before pushing again', ''))
    assert not match(Command('git push', '! [rejected]\n Updates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes before pushing', '1'))


# Generated at 2022-06-12 11:40:06.780043
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull'



# Generated at 2022-06-12 11:40:15.393602
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push origin master',
                                    '! [rejected] master -> master (fetch first)\n'
                                    'error: failed to push some refs to \'git@github.com:shit.git\'',
                                    '', 1, None))
            == 'git pull origin master && git push origin master')
    assert (get_new_command(Command('git push origin master',
                                    'To git@github.com:shit.git\n'
                                    ' ! [rejected]        master -> master (non-fast-forward)\n'
                                    'error: failed to push some refs to \'git@github.com:shit.git\'',
                                    '', 1, None))
            == 'git pull origin master && git push origin master')

# Generated at 2022-06-12 11:40:18.741610
# Unit test for function get_new_command
def test_get_new_command():
    f_command = type('Command', (object,), {'script': 'git push origin master', 'output': '! [rejected]'})
    assert get_new_command(f_command) == 'git pull && git push origin master'

# Generated at 2022-06-12 11:40:26.171972
# Unit test for function match
def test_match():
    assert ('git push' in match('git push')[0])
    assert ('git push' in match('git push')[0])
    assert ('git push' in match('git push')[0])
    assert ('git push' in match('git push')[0])
    assert ('git push' in match('git push')[0])
    assert ('git push' in match('git push')[0])
    assert ('git push' in match('git push')[0])
    assert ('git push' in match('git push')[0])
    assert ('git push' in match('git push')[0])
    assert ('git push' in match('git push')[0])
    assert ('git push' in match('git push')[0])
    assert (not 'git push' in match('git push')[0])

# Generated at 2022-06-12 11:40:27.975765
# Unit test for function get_new_command
def test_get_new_command():
    assert '&& git push' == get_new_command(Command('git pull && git push', ''))

# Generated at 2022-06-12 11:40:31.393284
# Unit test for function match
def test_match():
    assert match(Command('git push origin develop', 'error: failed to push some refs to'))
    assert not match(Command('git push', ''))
    assert not match(Command('git add', ''))



# Generated at 2022-06-12 11:40:40.609625
# Unit test for function match
def test_match():
	# If the output contains:
	#failed to push some refs to 'https://github.com/fanglinli/lab.git'
	#Updates were rejected because the tip of your current branch is behind
	#Updates were rejected because the remote contains work that you do
	#Then the match will return true
	match_command = Command('git push','''git push
							fatal: 'origin' does not appear to be a git repository
							fatal: Could not read from remote repository.
							Please make sure you have the correct access rights
							and the repository exists.
							''')
	assert match(match_command)


# Generated at 2022-06-12 11:40:53.498115
# Unit test for function match
def test_match():
	assert match(Command('git push origin testing',
						 '	! [rejected]        testing -> testing (non-fast-forward)',
						 ' error: failed to push some refs to \'ssh://repo/foo/bar.git\'',
						 ' hint: Updates were rejected because the tip of your current branch is behind',
						 ' hint: its remote counterpart. Integrate the remote changes (e.g',
						 ' hint: \'git pull ...\') before pushing again.',
						 ' hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:40:56.518877
# Unit test for function get_new_command
def test_get_new_command():
    """
    Test the function get_new_command :
        - test if get_new_command returns the good command
        - test if get_new_command returns the same command
    """
    assert git_support.get_new_command(git_support.Command('git push', '', '')) == git_support.Command('git push && git pull', '', '')
    assert git_support.get_new_command(git_support.Command('git pull', '', '')) == git_support.Command('git pull', '', '')

# Generated at 2022-06-12 11:41:03.740785
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         "! [rejected] master -> master (non-fast-forward)\n"
                         "error: failed to push some refs to '../../../../../../../'\n"
                         "hint: Updates were rejected because the tip of your current branch is behind\n"
                         "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                         "hint: 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in 'git push --help' for details."))


# Generated at 2022-06-12 11:41:14.059041
# Unit test for function match
def test_match():
    (assert_type, assert_equals) = (TestCase.assertIsInstance, TestCase.assertEquals)

# Generated at 2022-06-12 11:41:24.752153
# Unit test for function match
def test_match():
    assert(match(commands.Command('git push',
                                  '! [rejected]        master -> master (fetch first)\n'
                                  'error: failed to push some refs to \'https://github.com/someuser/somerepo\'\n'
                                  'hint: Updates were rejected because the remote contains work that you do\n'
                                  'hint: not have locally. This is usually caused by another repository pushing\n'
                                  'hint: to the same ref. You may want to first integrate the remote changes\n'
                                  'hint: (e.g., \'git pull ...\') before pushing again.\n'
                                  'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                                  '')))

# Generated at 2022-06-12 11:41:26.195047
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '')) == 'git pull && git push'
    assert get_new_command(Command('git push origin master', '', '')) == 'git pull origin master && git push'


# Generated at 2022-06-12 11:41:32.949738
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'error: failed to push some refs to \'git@gitlab.com:__/__.git\'\n'
                         'hint: Updates were rejected because the remote contains work that you do\n'
                         'hint: not have locally. This is usually caused by another repository pushing\n'
                         'hint: to the same ref. You may want to first integrate the remote changes\n'
                         'hint: (e.g., \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
                         '')) == True


# Generated at 2022-06-12 11:41:41.857120
# Unit test for function get_new_command
def test_get_new_command():
    test_command = Command('git push', 'error: failed to push some refs to \'remote\'\n'
                                                                             'hint: Updates were rejected because the tip of your current branch is behind\n'
                                                                             'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                                                             'hint: \'git pull ...\') before pushing again.\n'
                                                                             'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')
    corrected_command = shell.and_('git pull', 'git push')
    assert get_new_command(test_command) == corrected_command

# Generated at 2022-06-12 11:41:43.440692
# Unit test for function get_new_command
def test_get_new_command():
    assert '&& echo' == _get_new_command('git push')


# Generated at 2022-06-12 11:41:45.861239
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(shell.and_('git push', 'MESSAGE')) == 'git pull && git push'

# Generated at 2022-06-12 11:41:55.055025
# Unit test for function match
def test_match():
    assert match(Command("git push", "! [rejected]        master -> master (non-fast-forward)\n "
                         "error: failed to push some refs to 'git@github.com:xxx/xxx.git'\n "
                         "hint: Updates were rejected because the tip of your current branch is behind\n "
                         "hint: its remote counterpart. Integrate the remote changes (e.g.\n "
                         "hint: 'git pull ...') before pushing again.\n "
                         "hint: See the 'Note about fast-forwards' in 'git push --help' for details."))



# Generated at 2022-06-12 11:42:01.874780
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'Everything up-to-date ! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/walidMimouni/thefuck\' '
                         'To prevent you from losing history, non-fast-forward '
                         'updates were rejected\nMerge the remote changes (e.g. \'git pull\')'
                         ' before pushing again.  See the \'Note about fast-forwards\' section '
                         'of \'git push --help\' for details.'))
    assert not match(Command('git push',
                         'Everything up-to-date ! '))

# Generated at 2022-06-12 11:42:09.102138
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.specific.git import match, get_new_command

    command = Command('git push', (
    "To prevent you from losing history, non-fast-forward updates were rejected",
    "Merge the remote changes (e.g. 'git pull') before pushing again.",
    "See the 'non-fast-forward' section of 'git push --help' for details."))
    
    assert match(command)
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-12 11:42:10.205145
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push").command == "git pull;git push"

# Generated at 2022-06-12 11:42:19.810481
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push ssh://git@bitbucket.org/user/repo.git/',
            '! [rejected]        master -> master (non-fast-forward)\n'
            'error: failed to push some refs to \'ssh://git@bitbucket.org/user/repo.git/\'\n'
            'To prevent you from losing history, non-fast-forward updates were rejected\n'
            'Merge the remote changes (e.g. \'git pull\') before pushing again.  See the\n'
            '\'Note about fast-forwards\' section of \'git push --help\' for details.\n')

# Generated at 2022-06-12 11:42:25.858772
# Unit test for function match
def test_match():
    # Fail
    assert not match(Command(script='git push tester',
                             output=' ! [rejected]        master -> master (non-fast-forward) error: failed to push some refs to \'git@github.com:username/repo.git\' hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes (e.g. hint: \'git pull ...\') before pushing again. hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:42:35.905460
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master:master',
                                   '! [rejected] master -> master (non-fast-forward)\n'
                                   'error: failed to push some refs to \'git@github.com:SED\'\n'
                                   'hint: Updates were rejected because the tip of your current branch is behind\n'
                                   'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                   'hint: \'git pull ...\') before pushing again.\n'
                                   'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                                   'git@github.com:SED')).script == 'git pull origin master:master && git push origin master:master'


# Generated at 2022-06-12 11:42:37.199414
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(shell.and_('git push origin'))
            == ['git pull origin', 'git push origin'])

# Generated at 2022-06-12 11:42:38.588693
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git push origin master")) == 'git pull && git push origin master'

# Generated at 2022-06-12 11:42:44.230975
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         "To https://github.com/USERNAME/REPOSITORY.git\n ! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to 'https://github.com/USERNAME/REPOSITORY.git'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.\n"))


# Generated at 2022-06-12 11:42:54.399012
# Unit test for function match
def test_match():
    # Check if match() returns True if the push command failed.
    assert match(Command('git push',
        ' ! [rejected]        master -> master (fetch first)\n'
        'error: failed to push some refs to \'git@github.com:nvie/gitflow.git\'\n'
        'To prevent you from losing history, non-fast-forward updates were rejected\n'
        'Merge the remote changes (e.g. \'git pull\') before pushing again.  See\n'
        'the \'Note about fast-forwards\' section of \'git push --help\' for details.\n',
        '')) == True

    # Check if match() returns True if the push command failed.

# Generated at 2022-06-12 11:42:55.786938
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'

# Generated at 2022-06-12 11:43:04.263582
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ''' ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/coderholic/slacktee.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

    assert not match(Command('git push origin master', ''))


# Generated at 2022-06-12 11:43:13.126776
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (fetch first)'))
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)'))
    assert match(Command('git commit -m "init"',
                         'error: failed to push some refs to'))
    assert match(Command('git commit -m "init"',
                         'error: failed to push some refs to'))
    assert match(Command('git commit -m "init"',
                         'error: failed to push some refs to'))
    assert match(Command('git commit -m "init"',
                         'error: failed to push some refs to'))

# Generated at 2022-06-12 11:43:18.773560
# Unit test for function get_new_command
def test_get_new_command():	
    script_1 = 'git push origin master'	
    new_command_1 = 'git pull origin master'
    assert get_new_command(script_1) == new_command_1
    script_2 = 'git push origin :branch_name'
    new_command_2 = 'git pull origin :branch_name'
    assert get_new_command(script_2) == new_command_2


enabled_by_default = True

# Generated at 2022-06-12 11:43:20.720573
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master').script == 'git pull && git push origin master'
    assert get_new_command('git push').script == 'git pull && git push'
    assert get_new_command('git push origin master -f').script == 'git pull && git push origin master -f'

enabled_by_default = True

# Generated at 2022-06-12 11:43:28.594347
# Unit test for function match
def test_match():
    assert match(Command('git push origin master:master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:fuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                          ''))



# Generated at 2022-06-12 11:43:36.061642
# Unit test for function match
def test_match():
    get1 = Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
                   'error: failed to push some refs to \'git@github.com:sam/Hellogitworld.git\'\n'
                   'To prevent you from losing history, non-fast-forward updates were rejected\n'
                   'Merge the remote changes before pushing again.  See the \'Note about\n'
                   'fast-forwards\' section of \'git push --help\' for details.\n')
    assert match(get1)


# Generated at 2022-06-12 11:43:39.312287
# Unit test for function match
def test_match():
    assert (match('git push origin master')
            and match('git push production :master')
            and match('git push origin master:master') is not True)


# Generated at 2022-06-12 11:43:40.949701
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command('git push origin master')
    assert new_command == '&& git pull'

# Generated at 2022-06-12 11:43:55.379160
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push origin master',
                '! [rejected]        master -> master (non-fast-forward)\n'
                'error: failed to push some refs to '
                '\'/git/test.git\'\n'
                'hint: Updates were rejected because the tip of your '
                'current branch is behind\n'
                'hint: its remote counterpart. Integrate the remote '
                'changes (e.g\n'
                'hint: \'git pull ...\') before pushing again.\n'
                'hint: See the \'Note about fast-forwards\' in '
                '\'git push --help\' for details.')
    ) == 'git pull && git push origin master'

# Generated at 2022-06-12 11:44:02.894320
# Unit test for function match
def test_match():
    assert match(Command('git push',
                'To https://github.com/nvie/gitflow.git\n ! [rejected]        develop -> develop (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/nvie/gitflow.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-12 11:44:09.830996
# Unit test for function match
def test_match():
    assert match(Command(script = 'git push',
            output = '''To github.com:mislav/dotfiles.git ! [rejected] master -> master (non-fast-forward) error: failed to push some refs to 'git@github.com:mislav/dotfiles.git'''))    
    assert match(Command(script = 'git push',
            output = '''To github.com:mislav/dotfiles.git ! [rejected] master -> master (non-fast-forward) error: failed to push some refs to 'git@github.com:mislav/dotfiles.git'''))

# Generated at 2022-06-12 11:44:14.772566
# Unit test for function match
def test_match():
    assert match(Command(script='git push origin master',
                         output='Everything up-to-date'))
    assert not match(Command(script='git push origin master',
                             output='Updates were rejected because \
                             the remote contains work that you do\
                             not have locally'))
    assert match(Command(script='git push origin master',
                         output='Everything up-to-date'))


# Generated at 2022-06-12 11:44:17.485597
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin [arg]')
    assert get_new_command(command) == 'git pull && git push origin [arg]'

# Generated at 2022-06-12 11:44:24.666971
# Unit test for function match
def test_match():
    assert match(Command('git push origin dev', '', '', '',
                        'remote: Counting objects: 36, done.\
                        \nremote: Compressing objects: 100% (20/20), done.\
                        \nremote: Total 36 (delta 21), reused 36 (delta 21)\
                        \nerror: RPC failed; result=22, HTTP code = 404\
                        \ndelta 21) [rejected] --> ! [rejected]', '', 0))
    assert not match(Command('git push', '', '', '', '', '', 0))


# Generated at 2022-06-12 11:44:34.201024
# Unit test for function match
def test_match():
	assert match(Command('git push origin master', '''fatal: 
		The current branch master has no upstream branch.
		To push the current branch and set the remote as upstream, use

		    git push --set-upstream origin master

		! [rejected]        master -> master (non-fast-forward)
		error: failed to push some refs to 'git@github.com:tien-dang/test.git'
		hint: Updates were rejected because the tip of your current branch is behind
			hint: its remote counterpart. Integrate the remote changes (e.g.
			hint: 'git pull ...') before pushing again.
		hint: See the 'Note about fast-forwards' in 'git push --help' for details.
		''')) == True
# Unit test

# Generated at 2022-06-12 11:44:44.939105
# Unit test for function match
def test_match():
    command = Command('git push',
                      'Updates were rejected because the tip of your'
                      ' current branch is behind its remote counterpart. '
                      'Integrate the remote changes (e.g.\n'
                      'hint: \'git pull ...\') before pushing again.\n'
                      '\n'
                      'See the \'Note about fast-forwards\' in \'git push --help\' for '
                      'details.\n')
    assert match(command)

# Generated at 2022-06-12 11:44:53.616744
# Unit test for function match
def test_match():
    assert match(Command("git push origin master", "failed to push some refs to 'git@github.com:CPSE-Yonsei/Translator.git'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details."))

# Generated at 2022-06-12 11:45:01.814511
# Unit test for function match
def test_match():
    command = Command('git push origin',
                      ' ! [rejected]        master -> master (non-fast-forward)\n'
                      'error: failed to push some refs to \'git@github.com:User/repo.git\'\n'
                      'hint: Updates were rejected because the tip of your current branch is behind\n'
                      'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                      'hint: \'git pull ...\') before pushing again.\n'
                      'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert match(command)
    assert get_new_command(command) == 'git pull origin && git push origin'

# Generated at 2022-06-12 11:45:09.243285
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', 1)) == 'git pull'

# Generated at 2022-06-12 11:45:17.667358
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_push_rejected import get_new_command

# Generated at 2022-06-12 11:45:27.131089
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master && git push origin master'
    assert get_new_command('git push --force origin master') == 'git pull origin master && git push --force origin master'
    assert get_new_command('git push origin master') == 'git pull origin master && git push origin master'
    assert get_new_command('git push --force origin master') == 'git pull origin master && git push --force origin master'
    assert get_new_command('git push origin master' + ' ' + '\n') == 'git pull origin master && git push origin master'
    assert get_new_command('git push --force origin master') == 'git pull origin master && git push --force origin master'


# Generated at 2022-06-12 11:45:34.277899
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected] master -> master '
                         '(non-fast-forward)\n'
                         'error: failed to push some refs to '
                         "'git@github.com:HudsonThomas/Project1.git'\n"
                         'To prevent you from losing history, non-fast-forward '
                         'updates were rejected\n'
                         'Merge the remote changes (e.g. \'git pull\') '
                         'before pushing again. See the '
                         '\'Note about fast-forwards\' section of '
                         '\'git push --help\' for details.\n'))

# Generated at 2022-06-12 11:45:37.058538
# Unit test for function get_new_command
def test_get_new_command():
  assert get_new_command('git push origin master') == 'git pull origin master && git push origin master'


enabled_by_default = True

# Generated at 2022-06-12 11:45:43.121597
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('git pull origin master', 'Error: Your local changes to the following files would be overwritten by merge: file1 file2 Please, commit your changes or stash them before you can merge. Aborting', '')
    command2 = Command('git push origin master', '! [rejected] \tmaster -> master (fetch first) error: failed to push some refs to ''hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes (e.g. hint: ''git pull ...) before pushing again.', '')

# Generated at 2022-06-12 11:45:51.608466
# Unit test for function match
def test_match():
    assert(match(Command('git push origin mybranch',
                         ' ! [rejected]        mybranch -> mybranch (non-fast-forward)',
                         'error: failed to push some refs to ['
                         'Hint: Updates were rejected because the tip of your '
                         'current branch is behind its remote\n'
                         'hint: counterpart. Integrate the remote changes '
                         '(e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.')) == True)


# Generated at 2022-06-12 11:45:53.922297
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'Updates were rejected because the remote contains work that you do\n  (use "git pull" to update your local branch)', '')) == 'git pull'

# Generated at 2022-06-12 11:45:54.639581
# Unit test for function match
def test_match():
    assert match ('git push origin master')


# Generated at 2022-06-12 11:46:02.600367
# Unit test for function match
def test_match():
    assert (match(Command('git push',
                         '''To git@github.com:Syndbg/dotfiles.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:Syndbg/dotfiles.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.''',
                         '', 1, 
                         'git push'))
            == True)

# Generated at 2022-06-12 11:46:11.173453
# Unit test for function match
def test_match():
    assert match(Command(script='git push origin master'))
    assert not match(Command(script='git pull origin master'))

# Generated at 2022-06-12 11:46:13.936127
# Unit test for function match

# Generated at 2022-06-12 11:46:15.627458
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push')) == 'git pull && git push')

# Generated at 2022-06-12 11:46:20.858942
# Unit test for function get_new_command
def test_get_new_command():
    check_output = (' ! [rejected]        master -> master (non-fast-forward)\n'
                    'Updates were rejected because the tip of your current branch is behind\n'
                    'its remote counterpart. Integrate the remote changes (e.g.\n'
                    'hint: \'git pull ...\') before pushing again.\n'
                    'See the \'Note about fast-forwards\' in \'git push --help\' for details.')

    command = Command('git push origin master', check_output)
    assert get_new_command(command) == 'git pull && git push origin master'


# Generated at 2022-06-12 11:46:24.972335
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command


# Generated at 2022-06-12 11:46:27.522947
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '', '$')
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-12 11:46:34.928085
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         ""))

# Generated at 2022-06-12 11:46:37.164375
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', '', '', 1), None)
            == 'git pull')

# Generated at 2022-06-12 11:46:40.275903
# Unit test for function match
def test_match():
    # check if command matches criteria
    assert match(Command('git push origin master', '', '', 0))
    assert not match(Command('git push', '', '', 0))
    assert not match(Command('git push origin', '', '', 0))
    assert not match(Command('git pull', '', '', 0))



# Generated at 2022-06-12 11:46:48.817135
# Unit test for function match
def test_match():
    assert match(Command("git push origin master",
                         "! [rejected]        master -> master (non-fast-forward)\n"
                         "error: failed to push some refs to 'git@bitbucket.org:username/project.git'\n"
                         "To prevent you from losing history, non-fast-forward updates were rejected\n"
                         "Merge the remote changes before pushing again.  See the 'Note about\n"
                         "fast-forwards' section of 'git push --help' for details."))

# Generated at 2022-06-12 11:47:09.158448
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@bitbucket.org:MediGrigri/centralized-calendar-agenda.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) is True

# Generated at 2022-06-12 11:47:16.137957
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = "git push",
                                  stdout = "To https://github.com/jordanh/thefuck.git ! [rejected] " 
                                  "master -> master (non-fast-forward) error: failed to push some refs to 'https://github.com/jordanh/thefuck.git' "
                                  "hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes "
                                  "(e.g. hint: 'git pull ...') before pushing again. hint: See the 'Note about fast-forwards' in 'git push --help' for details.")) == "git pull"

# Generated at 2022-06-12 11:47:20.340845
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'Updates were rejected because the tip of your current branch is behind its remote\n'
                         'counterpart. Integrate the remote changes (e.g.\n'
                         '\'git pull ...\') before pushing again.\n'
                         'See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-12 11:47:27.130508
# Unit test for function match
def test_match():
    assert match(Command('sdsdsd', 'sdsdsd'))
    assert match(Command('git push', "! [rejected]        master -> master (fetch first)"))
    assert match(Command('git push', "! [rejected]        master -> master (non-fast-forward)"))
    assert not match(Command('git push', "To https://github.com/nvbn/thefuck.git"))
    assert not match(Command('git push', "To https://github.com/nvbn/thefuck.git"))
    assert not match(Command('git pushd', ""))
    assert not match(Command('git pushd'))

# Generated at 2022-06-12 11:47:35.139003
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', '! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n')
    result = get_new_command(command)
    assert result == shell.and_('git pull origin master', command.script)

    command = Command('git push origin master',
                      'To git@github.com:nviennot/thefuck.git\n ! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the remote contains work that you do\n')
    result = get_new_command(command)
    assert result == shell.and_('git pull origin master', command.script)

# Generated at 2022-06-12 11:47:42.519676
# Unit test for function match
def test_match():
    assert match(Command('git push origin refs/heads/master:refs/heads/master'
                         ' ! [rejected]        master -> master (non-fast-forward) error: failed to push some refs to '
                         '\'https://github.com/alan-turing-institute/thefuck.git\' Updates were rejected because the tip '
                         'of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.'
                         ' \'git pull ...\') before pushing again.'
                         ' See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:47:44.441428
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push", "")
    assert get_new_command(command) == '$ git pull'

# Generated at 2022-06-12 11:47:52.700221
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git push origin master',
        stdout='''To https://github.com/nvbn/thefuck.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.''',
        stderr='',)
    assert (get_new_command(command)
            == 'git pull origin master && git push origin master')

# Generated at 2022-06-12 11:48:03.583812
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         stderr='To git://example.com/user/repo.git\n   '
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'git@example.com:user/repo.git\'\n'
                         'To prevent you from losing history, non-fast-forward '
                         'updates were rejected\nMerge the remote changes '
                         '(e.g. \'git pull\') b'
                         'efore pushing again.  See the \'Note about\n'
                         'fast-forwards\' section of \'git push --help\' for '
                         'details.\n'))

# Generated at 2022-06-12 11:48:11.872009
# Unit test for function match
def test_match():
    assert match(Command('git push',
        "! [rejected]        master -> master (fetch first)\n"
        "error: failed to push some refs to 'git@github.com:xuset/TheFuck.git'\n"
        "hint: Updates were rejected because the remote contains work that you do\n"
        "hint: n't have locally. This is usually caused by another repository pushing\n"
        "hint: to the same ref. You may want to first integrate the remote changes\n"
        "hint: (e.g., 'git pull ...') before pushing again.\n"
        "hint: See the 'Note about fast-forwards' in 'git push --help' for details.",
        'git pull')
    )


# Generated at 2022-06-12 11:48:39.951629
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'Updates were rejected',
                                   '123')) == 'git pull && git push'

# Generated at 2022-06-12 11:48:48.978381
# Unit test for function match
def test_match():

    #test for case: Output: ! [rejected]        master -> master (fetch first)
    #error: failed to push some refs to 'https://github.com/CS310-2017Jan/cpsc310project_team78.git'
    output = "! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to 'https://github.com/CS310-2017Jan/cpsc310project_team78.git'"    
    command = Command('git push',output)
    assert(match(command))

    #test for case: Output:  ! [rejected]        master -> master (non-fast-forward)
    #error: failed to push some refs to 'https://github.com/CS310-2017Jan/cpsc310project_team78.git'

# Generated at 2022-06-12 11:48:58.110735
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', 'The remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref.', '', 123))
    assert match(Command('git push origin master', '', 'failed to push some refs to \'https://github.com/one-fucking-admin/one-fucking-admin.github.io.git\' Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\n\'git pull ...\') before pushing again. See the \'Note about fast-forwards\' section of \'git push --help\' for details.', '', 123))

# Generated at 2022-06-12 11:49:00.114684
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '','')).script == 'git pull && git push'

# Generated at 2022-06-12 11:49:06.533778
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    output = '''\
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first merge the remote changes (e.g.,
hint: 'git pull') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''
    assert get_new_command(Command('git push origin master', output)) == "git pull' && git push origin master"

# Generated at 2022-06-12 11:49:12.865101
# Unit test for function match
def test_match():
    assert match(Command(script='git push origin master',
                         stderr=' ! [rejected] master -> master (non-fast-forward)',
                         output='error: failed to push some refs to \'git@github.com:prezjordan/SLAE.git\''))

    assert match(Command(script='git push -f origin master',
                         stderr=' ! [rejected] master -> master (non-fast-forward)',
                         output='error: failed to push some refs to \'git@github.com:prezjordan/SLAE.git\''))


# Generated at 2022-06-12 11:49:14.419578
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', ''))
            == 'git pull && git push')

# Generated at 2022-06-12 11:49:23.556571
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n')) == 'git pull && git push'
    assert get_new_command(Command('git push origin master', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n')) == 'git pull origin master && git push origin master'
    assert (get_new_command(Command('git push origin master',
                                    '! [rejected] master -> master (non-fast-forward)\n'
                                    'Updates were rejected because the remote contains work that you do\n'))
            == 'git pull origin master && git push origin master')

# Generated at 2022-06-12 11:49:24.653559
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '')) == 'git pull'

# Generated at 2022-06-12 11:49:32.084277
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '! [rejected] master -> master (non-fast-forward)\n'
                                                  'error: failed to push some refs to \'git@github.com:rudolphmiller/personal-site.git\'\n'
                                                  'hint: Updates were rejected because the tip of your current branch is behind\n'
                                                  'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                                  'hint: \'git pull ...\') before pushing again.'))