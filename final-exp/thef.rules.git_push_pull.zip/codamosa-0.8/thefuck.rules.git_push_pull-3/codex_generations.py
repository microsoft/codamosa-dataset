

# Generated at 2022-06-12 11:39:45.860816
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master')) == 'git pull && git push origin master'

# Generated at 2022-06-12 11:39:55.604932
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(ShellCommand('git push -f', 'push',
                                         '! [rejected] master ->'
                                         ' master(non-fast-forward)',
                                         'Updates were rejected because the'
                                         ' remote contains work that you do'
                                         ' not have locally. This is usually'
                                         ' caused by another repository'
                                         ' pushing to the same ref. You may'
                                         ' want to first integrate the remote'
                                         ' changes (e.g., \'git pull ...\')'
                                         ' before pushing again.',
                                         'Please submit a full'
                                         ' log.\n))'))) == \
            "git pull -f && git push -f"

# Generated at 2022-06-12 11:40:01.263092
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', 'Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.git pull ...) before pushing again.')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

    command = Command('git push', 'Everything up-to-date')
    assert get_new_command(command) == 'git push'

# Generated at 2022-06-12 11:40:11.614758
# Unit test for function match
def test_match():
    # Test match function
    assert not match(Command('cd', stderr='fatal: unable to access'))
    assert not match(Command('git push', stderr='fatal: unable to access'))
    assert not match(Command('git push',
                             stderr='fatal: unable to access'
                                    ' https://github.com/user/repo.git/'
                                    '\nfatal: Authentication failed for'
                                    ' \'https://github.com/user/repo.git/\''
                                    ))
    assert not match(Command('git push', stderr='fatal: Not a git repository'))

# Generated at 2022-06-12 11:40:15.722760
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', '', '', ''))
    assert match(Command('git push origin master', '', '', '', '', ''))
    assert not match(Command('git push origin master', '', '', '', '', ''))


# Generated at 2022-06-12 11:40:23.042975
# Unit test for function get_new_command
def test_get_new_command():
    import os
    import shutil
    import tempfile
    import thefuck.shells.shell

    tmp = tempfile.mkdtemp()
    current_path = os.getcwd()
    os.chdir(tmp)
    shutil.copytree(current_path + '/git_test/git_test1', tmp + '/git_test')
    os.chdir(tmp + '/git_test')
    res = thefuck.main.get_new_command(thefuck.main.Command('git push origin master', 'Updates were rejected because the tip of your current branch is behind'))
    assert res == 'git pull origin master'

# Generated at 2022-06-12 11:40:26.900856
# Unit test for function match
def test_match():
    assert match(Command('git push', "fatal: The current branch master has no \
        upstream branch.\nTo push the current branch and set the \
        remote as upstream, use\n\n    git push --set-upstream origin master\n"))



# Generated at 2022-06-12 11:40:37.307632
# Unit test for function match
def test_match():
    command = Command('git push origin master', '! [rejected]        master -> master (non-fast-forward)')
    assert(match(command) == True)
    command = Command('git push origin master', '! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\n\nhint: \'git pull ...\') before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert(match(command) == True)

# Generated at 2022-06-12 11:40:44.148703
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to \'git@github.com:kdheepak/git-cheat-sheet.git\'',
                         'hint: Updates were rejected because the tip of your current branch is behind',
                         'hint: its remote counterpart. Integrate the remote changes (e.g.',
                         'hint: \'git pull ...\') before pushing again.',
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:40:45.502137
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'

# Generated at 2022-06-12 11:40:58.515028
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]      master -> master (non-fast-forward)',
                         'error: failed to push some refs to '
                         '\'git@git.server:project.git\'',
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind',
                         'hint: its remote counterpart. Integrate the remote changes ',
                         '(e.g.',
                         'hint: \'git pull ...\') before pushing again.',
                         'hint: See the \'Note about fast-forwards\' in \''
                         'git push --help\' for details.'))

# Generated at 2022-06-12 11:41:04.978214
# Unit test for function match
def test_match():
    command = Command(script='git push',
                      output='error: failed to push some refs to'
                             ' \'https://github.com/user/repo.git\''
                             ' ! [rejected]        master -> master'
                             ' (non-fast-forward)'
                             ' error: failed to push some refs to'
                             ' \'https://github.com/user/repo.git\''
                             ' hint: Updates were rejected because the tip of'
                             ' your current branch is behind'
                             ' hint: its remote counterpart. Integrate the'
                             ' remote changes (e.g.'
                             ' hint: \'git pull ...\') before pushing again.'
                             ' hint: See the \'Note about fast-forwards\' in'
                             ' \'git push --help\' for details.')


# Generated at 2022-06-12 11:41:10.660990
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '', 0, None)) == shell.and_('git pull origin master', 'git push origin master')
    assert get_new_command(Command('git push origin master --force', '', '', 0, None)) == shell.and_('git pull origin master --force', 'git push origin master --force')

# Generated at 2022-06-12 11:41:16.469860
# Unit test for function get_new_command
def test_get_new_command():
    # command script
    script = 'git push origin master'
    # command output
    output = """Updates were rejected because the tip of your current branch is behind
    its remote counterpart. Integrate the remote changes (e.g.
    'git pull ...') before pushing again.
    See the 'Note about fast-forwards' in 'git push --help' for details."""
    # expected new command
    expected = 'git pull origin master && git push origin master'
    # command to test
    command = Command(script=script, output=output)
    # expected new command
    assert get_new_command(command) == expected

# Generated at 2022-06-12 11:41:18.823089
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull && git push origin master'

# Generated at 2022-06-12 11:41:28.680375
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to \'https://github.com/syl20bnr/spacemacs.git\''
                         '\nhint: Updates were rejected because the tip'
                         ' of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes '
                         '(e.g.\nhint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.\n',
                         '', 1))


# Generated at 2022-06-12 11:41:33.943965
# Unit test for function match
def test_match():
    assert match(Command('git push -u origin master',
                         'To https://github.com/a/b\n'
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'https://github.com/a/b\'\n'
                         'hint: Updates were rejected because the tip of '
                         'your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.\n'))

# Generated at 2022-06-12 11:41:43.010163
# Unit test for function match

# Generated at 2022-06-12 11:41:44.957675
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-12 11:41:54.090490
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/nvie/gitflow',
                         '! [rejected]        develop  ->  develop (non-fast-forward)',
                         'error: failed to push some refs to \'https://github.com/nvie/gitflow\'',
                         'hint: Updates were rejected because the tip of your current branch is behind',
                         'hint: its remote counterpart. Integrate the remote changes (e.g.',
                         'hint: \'git pull ...\') before pushing again.',
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-12 11:42:11.018128
# Unit test for function match
def test_match():
    assert(match(Command('git push origin master', '')) == True)
    assert(match(Command('git push origin master', '')) == True)
    assert(match(Command('git push origin', '')) == True)
    assert(match(Command('git push', '')) == True)
    assert(match(Command('git push', 'fatal: The current branch '
                                     'master has no upstream branch.\n'
                                     'To push the current branch and set '
                                     'the remote as upstream, use\n'
                                     '\n'
                                     '    git push --set-upstream origin master\n')) == False)

# Generated at 2022-06-12 11:42:17.712888
# Unit test for function get_new_command
def test_get_new_command():
   assert get_new_command(Command('git push origin master',
                                  ' ! [rejected] master -> master (non-fast-forward)',
                                  'error: failed to push some refs to \'git@github.com:Foo/Bar.git\'',
                                  'To prevent you from losing history, non-fast-forward updates were rejected',
                                  'Merge the remote changes (e.g. \'git pull\') before pushing again.',
                                  'See the \'Note about fast-forwards\' section of \'git push --help\' for details.',
                                  '')) == 'git pull && git push origin master'

# Generated at 2022-06-12 11:42:19.294948
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull'

enabled_by_default = True

# Generated at 2022-06-12 11:42:24.604572
# Unit test for function get_new_command
def test_get_new_command():
    import unittest
    class TestGitPush(unittest.TestCase):
        def test_git_push_check_output(self):
            self.assertEqual(get_new_command(command.Command('git push',
                                                  output = 'fatal: The current branch master has no upstream branch.')),'git pull && git push')
            self.assertEqual(get_new_command(command.Command('git push',
                                                  output = 'error:failed to push some refs to')),'error:failed to push some refs to')
    unittest.main()


# Generated at 2022-06-12 11:42:35.166206
# Unit test for function match
def test_match():
    command = Command('git push',
                      '''
                      ! [rejected]        master -> master (non-fast-forward)
                      error: failed to push some refs to 'https://github.com/Gitxq/python_code_repository.git'
                      hint: Updates were rejected because the tip of your current branch is behind
                      hint: its remote counterpart. Integrate the remote changes (e.g.
                      hint: 'git pull ...') before pushing again.
                      hint: See the 'Note about fast-forwards' in 'git push --help' for details.
                ''',
                      'https://github.com/Gitxq/python_code_repository.git')

    assert match(command)


# Generated at 2022-06-12 11:42:44.451684
# Unit test for function match

# Generated at 2022-06-12 11:42:51.884404
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to\n'
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes'
                         ' (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push '
                         '--help\' for details.\n'))



# Generated at 2022-06-12 11:42:57.724406
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
                                   'Updates were rejected because the tip of '
                                   'your current branch is behind')) == \
            'git pull && git push'
    assert get_new_command(Command('git push origin master',
                                   'Updates were rejected because the remote '
                                   'contains work that you do')) == \
            'git pull origin master && git push origin master'

# Generated at 2022-06-12 11:43:00.194677
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'
    assert git_support(get_new_command('git push'))

# Generated at 2022-06-12 11:43:03.500646
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do'))
    assert not match(Command('git push', ''))

# Generated at 2022-06-12 11:43:24.906726
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'ssh://git@github.com/xxxx/xxxx.git\'\n'
                         'To prevent you from losing history, '
                         'non-fast-forward updates were rejected\n'
                         'Merge the remote changes (e.g. \'git pull\') '
                         'before pushing again. See the \'Note about fast-forwards\' section of \'git push --help\' for details'))

# Generated at 2022-06-12 11:43:26.914014
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git push', output='')
    assert get_new_command(command) == "git pull && git push"


# Generated at 2022-06-12 11:43:35.396145
# Unit test for function match
def test_match():
    assert match(Command('git push origin master:master', '', '', 1))
    assert match(Command('git push origin master', '', '', 1))
    assert match(Command('git push', '', '', 1))
    assert match(Command('git push', '', 'To prevent you from losing history, \n'
                                      'non-fast-forward updates were rejected \n'
                                      'Merge the remote changes (e.g. \'git pull\') before pushing again.\n'
                                      'See the \'Note about fast-forwards\' section of \'git push --help\' for details.', 1))

# Generated at 2022-06-12 11:43:37.393420
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-12 11:43:44.857012
# Unit test for function match
def test_match():
    assert(match(Command('git push', '''
To https://github.com/tongwang/pynlpl.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/tongwang/pynlpl.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''')))

# Generated at 2022-06-12 11:43:54.077875
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', '! [rejected] master -> master (non-fast-forward)\n'
                                               'Updates were rejected because the tip of your current branch is behind\n'
                                               'its remote counterpart. Integrate the remote changes (e.g.\n'
                                               'git pull ...) before pushing again.')
    assert get_new_command(command) == 'git pull && git push origin master'


# Generated at 2022-06-12 11:44:00.367607
# Unit test for function match
def test_match():
    assert match(Command("git push origin master", "! [rejected] master -> master (fetch first)\n")) == True
    assert match(Command("git push origin master", "! [rejected] master -> master (non-fast-forward)\n")) == True
    assert match(Command("git push origin master", "! [rejected] master -> master (fetch first)\non the remote side.")) == True
    assert match(Command("git push origin master", "! [rejected] master -> master (non-fast-forward)\non the remote side.")) == True


# Generated at 2022-06-12 11:44:09.313500
# Unit test for function match
def test_match():
	assert match(Command(script="git push", output="! [rejected]        master -> master (fetch first)\n"))
	assert match(Command(script="git push", output="Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\nhint: 'git pull ...') before pushing again.\n"))
	assert match(Command(script="git push", output="Updates were rejected because the remote contains work that you do\nnot have locally. This is usually caused by another repository pushing\nto the same ref. You may want to first integrate the remote changes\n(e.g., 'git pull ...') before pushing again.\nSee the 'Note about fast-forwards' in 'git push --help' for details.\n"))

# Generated at 2022-06-12 11:44:13.814137
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
        'Updates were rejected because the remote contains work that you do'
        ' not have locally. This is usually caused by another repository'
        ' pushing to the same ref. You may want to first integrate the'
        ' remote changes before pushing again.')) == 'git pull && git push'

# Generated at 2022-06-12 11:44:24.499038
# Unit test for function match

# Generated at 2022-06-12 11:44:55.311082
# Unit test for function match
def test_match():
    assert match(Command(script="git push",
                         output='fatal: The current branch master has no upstream branch.\n'
                                'To push the current branch and set the remote as upstream, use\n'
                                '\n'
                                '    git push --set-upstream origin master\n'
                                '\n'))

    assert not match(Command(script="git push",
                             output='fatal: The current branch master has no upstream branch.\n'
                                    'To push the current branch and set the remote as upstream, use\n'
                                    '\n'
                                    '    git push --set-upstream origin master\n'
                                    '\n'))



# Generated at 2022-06-12 11:45:02.751211
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '''To github.com:xxx/xxx.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:xxx/xxx.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-12 11:45:09.767234
# Unit test for function match
def test_match():
	assert match(type('obj', (object,), {'output': "! [rejected]        master -> master (fetch first)", 'script': "git push"})) == True
	assert match(type('obj', (object,), {'output': "! [rejected]        master -> master (fetch first)", 'script': "git pus"})) == False
	assert match(type('obj', (object,), {'output': "! [rejected]        master -> master (fetch first)", 'script': ''})) == False


# Generated at 2022-06-12 11:45:13.377153
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull'
    assert get_new_command('git push origin master').script == 'git pull'
    assert get_new_command('git push github master').script == 'git pull github master'



# Generated at 2022-06-12 11:45:16.774249
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', ''))
    assert match(Command('git push', ''))
    assert match(Command('git push origin', ''))
    assert not match(Command('git push origin master', ''))


# Generated at 2022-06-12 11:45:25.618789
# Unit test for function match
def test_match():
    assert match(Script('git push', '! [rejected]          master -> master (fetch first)', 'error: failed to push some refs to'))
    assert not match(Script('git push', 'Everything up-to-date', 'error: failed to push some refs to'))
    assert not match(Script('git push', 'Everything up-to-date', 'error: failed to push some refs to',
                            'Updates were rejected because the remote contains work that you do'))
    assert match(Script('git push', 'Everything up-to-date', 'error: failed to push some refs to',
                            'Updates were rejected because the remote contains work that you do'))


# Generated at 2022-06-12 11:45:30.214053
# Unit test for function match
def test_match():
  assert match("git push origin master")
  assert match("git push origin master --rebase")
  assert match("git push origin master --force")
  assert not match("git push")
  assert not match("git push --rebase")
  assert not match("git push origin master")
  assert not match("git push origin dev develop")


# Generated at 2022-06-12 11:45:31.732136
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command(script = 'git push')) == 'git pull'


# Generated at 2022-06-12 11:45:40.756379
# Unit test for function match
def test_match():

    # Test 1
    # This should be true
    command = Command('git push blablabla',
                      '! [rejected] master -> master (fetch first)\n'
                      'error: failed to push some refs to\''
                      ' https://github.com/josl/thefuck.git\'\n'
                      'hint: Updates were rejected because the tip of your '
                      'current branch is behind\n'
                      'hint: its remote counterpart. Integrate the remote '
                      'changes (e.g.\nhint: \'git pull ...\') before pushing '
                      'again.\nhint: See the \'Note about fast-forwards\' in '
                      '\'git push --help\' for details.',
                      '', 0)
    assert(match(command))

    # Test 2
    # This should

# Generated at 2022-06-12 11:45:50.564171
# Unit test for function get_new_command
def test_get_new_command():
	from thefuck.rules.git_pull_before_push import get_new_command
	from thefuck.types import Command
	command = Command('git push origin master',
		'Updates were rejected because the remote contains work that you do\r\nnot have locally. This is usually caused by another repository pushing\r\nto the same ref. You may want to first integrate the remote changes\r\n(e.g., \'git pull ...\') before pushing again.\r\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.\r\n',
		 None, 'git')
	assert(get_new_command(command) == "git pull origin master && git push origin master")

# Generated at 2022-06-12 11:46:19.436556
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', "! [rejected]\nUpdates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g., 'git pull ...') before pushing again.\nSee the 'Note about fast-forwards' in 'git push --help' for details.\n"))
    assert not match(Command('git push origin master', ''))

# Generated at 2022-06-12 11:46:21.800364
# Unit test for function match
def test_match():
    assert not match(Command('add .', ''))
    assert not match(Command('pull', ''))
    assert match(Command('push', ''))


# Generated at 2022-06-12 11:46:31.964406
# Unit test for function match
def test_match():
    output=('git push'
            'upstream f3e3cc8f51d7a612:refs/for/master'
            '! [rejected]           master -> master (non-fast-forward)'
            'error: failed to push some refs to'
            'Updates were rejected because the tip of your'
            ' current branch is behind'
            'Updates were rejected because the remote '
            'contains work that you do'
            'Found a swap file by the name '
            'Please move or remove it before you can merge.'
            'Enumerating objects: 6, done.'
            'Counting objects: 100% (6/6), done.'
            'Delta compression using up to 4 threads')

    assert match(Command(script='git push', output=output))

# Generated at 2022-06-12 11:46:36.018830
# Unit test for function get_new_command
def test_get_new_command():
    script = "git push origin"
    command = Command(script, "! [rejected]        master -> master (non-fast-forward)\n")
    assert match(command)
    assert get_new_command(command) == "git pull origin && git push origin"

# Generated at 2022-06-12 11:46:42.937533
# Unit test for function match
def test_match():
    def assert_match(command):
        matched_func = match(command)
        assert matched_func == get_new_command(command)

    assert_match(Command('git push origin master', '  ! [rejected]        master -> master (fetch first)\n    error: failed to push some refs to \'git@git.teambition.com:browser/one.git\'', '', 1, None))

    assert_match(Command('git push origin master', ' ! [rejected]        master -> master (fetch first)\n  error: failed to push some refs to \'git@git.teambition.com:browser/one.git\'', '', 1, None))


# Generated at 2022-06-12 11:46:49.331775
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         "'git@github.com:nvie/gitflow.git'\n"
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Merge the remote '
                         'changes (e.g.\n'
                         'hint: \'git pull\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.',
                         'git push origin master'))

# Generated at 2022-06-12 11:46:56.929177
# Unit test for function match
def test_match():
    assert match(Command('git push',
                'To https://github.com/github/VisualStudio.git\n'
                ' ! [rejected]        master -> master (fetch first)\n'
                'error: failed to push some refs to '
                '\'https://github.com/github/VisualStudio.git\'\n'
                'hint: Updates were rejected because the tip of your '
                'current branch is behind\n'
                'hint: its remote counterpart. Integrate the remote changes '
                '(e.g.\n'
                'hint: \'git pull ...\') before pushing again.\n'
                'hint: See the \'Note about fast-forwards\' in '
                '\'git push --help\' for details.\n',
                'git pull'))


# Generated at 2022-06-12 11:47:05.917853
# Unit test for function match
def test_match():
    assert(match(Command('git push',
                                 'Total 0 (delta 0), reused 0 (delta 0)'
                                 'error: failed to push some refs to'
                                 '! [rejected]        dev -> dev (fetch first)'
                                 'Updates were rejected because the tip of your'
                                 'current branch is behind'
                                 'its remote counterpart. Integrate the remote'
                                 'changes (e.g.hint:git pull...'
                                 'before pushing again.'
                                 'See the \'Note about fast-forwards\' in \'git push --help\' for details.')))

# Generated at 2022-06-12 11:47:14.558709
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '''
                         ! [rejected]        master -> master (fetch first)
                         error: failed to push some refs to 'git@github.com:...'
                         '''))
    assert match(Command('git push origin //master//',
                         '''
                         ! [rejected]        //master// -> //master// (fetch first)
                         error: failed to push some refs to 'git@github.com:...'
                         '''))
    assert match(Command('git push origin master',
                         '''
                         ! [rejected] master -> master (fetch first)
                         error: failed to push some refs to 'git@github.com:...'
                         '''))

# Generated at 2022-06-12 11:47:15.675406
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git push origin master')) == 'git pull && git push origin master'

# Generated at 2022-06-12 11:48:18.067841
# Unit test for function match
def test_match():
    # No error message
    assert not match(Command('git push', ''))
    # No error
    assert not match(Command('git push', '''To git@github.com:123/456.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:123/456.git'
hint: Updates were rejected because a pushed branch tip is behind its remote
hint: counterpart. Check out this branch and integrate the remote changes'''))
    # Match error

# Generated at 2022-06-12 11:48:27.379850
# Unit test for function match
def test_match():
    assert(match(Command('git push origin master',
                         'To https://github.com/user/repo.git\n'
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'https://github.com/user/repo.git\'\n'
                         'hint: Updates were rejected because '
                         'the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes '
                         '(e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.\n')) == True)

# Generated at 2022-06-12 11:48:28.331317
# Unit test for function match

# Generated at 2022-06-12 11:48:33.452948
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add', 'error: failed to push . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ')) == 'git pull && git add'

# Generated at 2022-06-12 11:48:41.911888
# Unit test for function match
def test_match():
    assert match(Command(script='git push',
                         output='! [rejected] master -> master (non-fast-forward)\n'
                                'error: failed to push some refs to ...\n'
                                'To ...\n'
                                ' ! [rejected] master -> master (non-fast-forward)\n'
                                'Updates were rejected because the tip of your current branch is behind\n'
                                'its remote counterpart. Integrate the remote changes (e.g.\n'
                                '$ git pull ... master) before pushing again.'))

# Generated at 2022-06-12 11:48:44.922737
# Unit test for function match
def test_match():
    command = Command('echo thefuck', '', '')
    assert(match(command))



# Generated at 2022-06-12 11:48:53.276111
# Unit test for function match

# Generated at 2022-06-12 11:48:56.343784
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin',
                                   'Updates were rejected because the remote '
                                   'contains work that you do')) == \
                                   'git pull origin'

# Generated at 2022-06-12 11:48:58.034424
# Unit test for function match
def test_match():
    assert match(Command('git push', 'error: failed to push some refs to'))



# Generated at 2022-06-12 11:49:07.114394
# Unit test for function match
def test_match():
    assert match(Command('git push',
        output='To https://github.com/nvbn/zsh-history-substring-search.git ! [rejected]        master -> master (non-fast-forward) error: failed to push some refs to \'https://github.com/nvbn/zsh-history-substring-search.git\' hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes (e.g. hint: \'git pull ...\') before pushing again. hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'
        ))