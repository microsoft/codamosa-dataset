

# Generated at 2022-06-12 11:39:53.070422
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '! [rejected]        master -> master (fetch first)',
                      'error: failed to push some refs to \'https://github.com/THE-FUCK/thefuck.git\'\n'
                      'hint: Updates were rejected because the tip of your current branch is behind\n'
                      'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                      'hint: \'git pull ...\') before pushing again.\n'
                      'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert get_new_command(command) == "git pull && git push"

# Generated at 2022-06-12 11:39:57.898998
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', '', '', ''))
    assert match(Command('git push origin master', '', '', '', '', ''))
    assert match(Command('git push origin master', '', '', '', '', '', ''))
    assert not match(Command('wget', '', '', '', '', ''))


# Generated at 2022-06-12 11:40:06.113285
# Unit test for function match
def test_match():
    command = Command('git push',
                      '! [rejected]        master -> master (non-fast-forward)\n'
                      'error: failed to push some refs to \'git@github.com:nvie/gitflow.git\'\n'
                      'Updates were rejected because the tip of your current branch is behind\n'
                      'its remote counterpart. Integrate the remote changes (e.g.\n'
                      'hint: \'git pull ...\') before pushing again.\n'
                      'See the \'Note about fast-forwards\' in \'git push --help\' for details.')

    assert match(command)


# Generated at 2022-06-12 11:40:13.445123
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master',
                      'To https://github.com/nvbn/thefuck\n ! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: git pull ...) before pushing again.\nhint: See the \'Note about fast-forwards\' in git push --help for details.')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-12 11:40:18.026974
# Unit test for function match

# Generated at 2022-06-12 11:40:25.830202
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', ''))
    assert match(Command('git push origin master', '''
        To git@git.server.com:group/project.git
        ! [rejected]        master -> master (non-fast-forward)
        error: failed to push some refs to 'git@git.server.com:group/project.git'
        hint: Updates were rejected because the tip of your current branch is behind
        hint: its remote counterpart. Integrate the remote changes (e.g.
        hint: 'git pull ...') before pushing again.
        hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''))

# Generated at 2022-06-12 11:40:28.016594
# Unit test for function match
def test_match():
    assert match('git push origin master')
    assert not match('git push origin master')
    assert not match('git show-branch')


# Generated at 2022-06-12 11:40:34.385364
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master').script == 'git pull origin master; git push origin master'
    assert get_new_command('git add . && git commit -m "Updated file." && git push origin master').script == 'git add . && git commit -m "Updated file." && git pull origin master; git push origin master'
    assert get_new_command('git push master').script == 'git pull master; git push master'


# Generated at 2022-06-12 11:40:36.788674
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', 'error: failed to push some refs to ...')
    assert get_new_command(command) == 'git pull && git push origin master'

# Generated at 2022-06-12 11:40:43.606604
# Unit test for function match
def test_match():
    assert match(Command(script="git push", output="! [rejected]"))
    assert match(Command(script="git push", output="! [rejected] failed to push some refs to"))
    assert match(Command(script="git push", output="! [rejected] failed to push some refs to https://github.com/me/myRepo.git"))
    assert not match(Command(script="git push", output="! [rejected] failed to push some refs to http://github.com/me/myRepo.git"))
    assert match(Command(script="git push", output="! [rejected] Updates were rejected because the tip of your current branch is behind"))
    assert match(Command(script="git push", output="! [rejected] Updates were rejected because the remote contains work that you do"))

# Generated at 2022-06-12 11:40:47.809435
# Unit test for function get_new_command
def test_get_new_command():
    pass


enabled_by_default = True

# Generated at 2022-06-12 11:40:50.286730
# Unit test for function get_new_command

# Generated at 2022-06-12 11:41:00.102829
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'Updates were rejected because the remote '
                         'contains work that you do\n'
                         'not have locally. This is usually caused by '
                         'another repository pushing\n'
                         'to the same ref. You may want to first '
                         'integrate the remote changes\n'
                         '(e.g., \'git pull ...\') before pushing again.'))
    assert match(Command('git push',
                         'To prevent you from losing history, '
                         'non-fast-forward updates were rejected\n'
                         'Merge the remote changes (e.g. ''git pull) '
                         'before pushing again.  See the\n'
                         '\'Note about fast-forwards\' section of '
                         '\'git push --help\' for details.'))

# Generated at 2022-06-12 11:41:07.897476
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
                                   output="""
To github.com:nvbn/thefuck.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.""")) == 'git pull && git push'

# Generated at 2022-06-12 11:41:16.753717
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
                                              'error: failed to push some refs to \'git@gitlab.test:test/test.git\'\n'
                                              'hint: Updates were rejected because the tip of your current branch is behind\n'
                                              'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                              'hint: \'git pull ...\') before pushing again.\n'
                                              'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'
                                              '\n', '', '', '')) == 'git pull && git push'


# Generated at 2022-06-12 11:41:23.867469
# Unit test for function get_new_command
def test_get_new_command():
    command = Commands("push", "! [rejected] master -> master (non-fast-forward)\n"
                                "Updates were rejected because the tip of your current branch is behind\n"
                                "To push changes to 'git@git.example.com:master', please pull first\n"
                                "  branch            master  -> FETCH_HEAD\n"
                                "  branch            staging -> FETCH_HEAD")
    assert get_new_command(command) == 'pull && push'

# Generated at 2022-06-12 11:41:30.958258
# Unit test for function match
def test_match():
    new_cmd = 'git push -v --tags --set-upstream origin develop:develop'
    output = '''! [rejected]        develop -> develop (non-fast-forward)
error: failed to push some refs to 'git@github.com:me/project.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''
    assert match(Command('git', 'git push', new_cmd, output))


# Generated at 2022-06-12 11:41:33.546414
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '', 0, None))
    assert not match(Command('git pull', '', '', 0, None))



# Generated at 2022-06-12 11:41:42.953203
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
           'To git@github.com:nvie/gitflow.git\n ! [rejected] master -> master (non-fast-forward)'
           '\n error: failed to push some refs to \'git@github.com:nvie/gitflow.git\''
           '\nhint: Updates were rejected because the tip of your current branch is behind'
           '\nhint: its remote counterpart. Integrate the remote changes (e.g.'
           '\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\''
           '\nhint: in \'git push --help\' for details.')) == True

# Generated at 2022-06-12 11:41:45.945625
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git push", output='! [rejected]    master -> master (fetch first)')) == 'git pull && git push'

# Generated at 2022-06-12 11:41:56.155001
# Unit test for function match
def test_match():

    # Test for true case
    assert match(Command('git push origin develop', '''To git@github.com:user/project.git
 ! [rejected]        develop -> develop (non-fast-forward)
error: failed to push some refs to 'git@github.com:user/project.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

    # Test for false case

# Generated at 2022-06-12 11:41:58.981010
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '')) == 'git pull'
    assert get_new_command(Command('git push --force', '', '')) == 'git pull'

# Generated at 2022-06-12 11:42:06.384187
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 1, None))
    assert not match(Command('git pull origin master', '', '', 1, None))
    assert not match(Command('git push', '', '', 1, None))
    assert not match(Command('git push origin master', '', '', 1, None))
    assert not match(Command('git push origin master', '', '', 1, None))
    assert not match(Command('ls', '', '', 1, None))


# Generated at 2022-06-12 11:42:08.479446
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push origin master") == "git pull && git push origin master"



# Generated at 2022-06-12 11:42:15.454369
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push',
                      ' ! [rejected]        master -> master (non-fast-forward)',
                      'error: failed to push some refs to \'origin\'',
                      'hint: Updates were rejected because the tip of your '
                      'current branch is behind',
                      'hint: its remote counterpart. Integrate the remote '
                      'changes (e.g.',
                      'hint: \'git pull ...\') before pushing again.',
                      'hint: See the \'Note about fast-forwards\' in '
                      '\'git push --help\' for details.',
                      '')
    assert get_new_command(command) == \
           shell.and_('git pull', 'git push')

# Generated at 2022-06-12 11:42:23.727561
# Unit test for function match
def test_match():
    assert match(Command(script='git push',
                         output='error: failed to push some refs to\n'
                                'hint: Updates were rejected because the tip of '
                                'your current branch is behind\n'
                                'hint: its remote counterpart. Integrate the '
                                'remote changes (e.g.\n'
                                'hint: \'git pull ...\') before pushing again.\n'
                                'hint: See the \'Note about fast-forwards\' in '
                                '\'git push --help\' for details.'))

# Generated at 2022-06-12 11:42:26.666526
# Unit test for function get_new_command
def test_get_new_command():
    s = ('git push -u origin master')
    s2 = ('git pull')

    assert get_new_command(Command(s,'failed')) == s2

# Generated at 2022-06-12 11:42:28.788600
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   'Updates were rejected because the tip of your current branch is behind',
                                   '',
                                   '/etc/g'),
                         None) == 'git pull origin master'

# Generated at 2022-06-12 11:42:37.748876
# Unit test for function get_new_command
def test_get_new_command():

    command = Command(script='git push',
                      stderr=' ! [rejected]        master -> master (non-fast-forward)\n'
                             'error: failed to push some refs to \'git@github.com:praw/praw.git\'\n'
                             'hint: Updates were rejected because the tip of your current branch is behind\n'
                             'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                             'hint: \'git pull ...\') before pushing again.\n'
                             'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')

    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-12 11:42:45.273859
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', "! [rejected]        master -> master (fetch first)\n\
error: failed to push some refs to\n\
Updates were rejected because the tip of your current branch is behind\n\
its remote counterpart. Integrate the remote changes (e.g.\n\
'git pull ...') before pushing again.\n\n\
See the 'Note about fast-forwards' in 'git push --help' for details."
)) == 'git pull && git push'

# Generated at 2022-06-12 11:43:02.252396
# Unit test for function match
def test_match():

    assert match(Command('git push',
                         'To https://github.com/nvbn/navigate.git\n! [rejected] master -> master (fetch first)\nerror: failed to push some refs to \'https://github.com/nvbn/navigate.git\'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:43:06.268362
# Unit test for function get_new_command
def test_get_new_command():
    assert "git pull && git push git@github.com:HengXun/hexun.github.io.git master" == get_new_command("git push git@github.com:HengXun/hexun.github.io.git master")

# Generated at 2022-06-12 11:43:08.826629
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push master") == "git pull master && git push master"
    assert get_new_command("git commit -m 'test'") == None

# Generated at 2022-06-12 11:43:15.007201
# Unit test for function match
def test_match():
    assert(match(Command('git push', 'failed to push some refs to'
                   ' \'https://github.com/pavlos-liavan/thefuck.git/\''
                   '\nUpdates were rejected because the tip of your'
                   ' current branch is behind\n'
                   'its remote counterpart. Integrate the remote changes'
                   ' (e.g.\n\'git pull ...\') before pushing again.'
                   '\nSee the \'Note about fast-forwards\' in '
                   '\'git push --help\' for details.')))

# Generated at 2022-06-12 11:43:24.324511
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', None, '''
To git@github.com:user/repo.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'git@github.com:user/repo.git'
Updates were rejected because the remote contains work that you do
not have locally. This is usually caused by another repository pushing
to the same ref. You may want to first integrate the remote changes
(e.g., 'git pull ...') before pushing again.
See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-12 11:43:31.556929
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('git push origin master').script==
            'git pull origin master')
    assert (get_new_command('git push -f origin master').script==
            'git pull -f origin master')
    assert (get_new_command('git push origin master:other').script==
            'git pull origin master:other')
    assert (get_new_command('git push origin master --verbose').script==
            'git pull origin master --verbose')
    assert (get_new_command('git push origin').script==
            'git pull origin')

# Generated at 2022-06-12 11:43:33.329152
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', ''))
    assert not match(Command('git push origin master', 'Everything up-to-date'))

# Generated at 2022-06-12 11:43:36.098110
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull && git push'

# Generated at 2022-06-12 11:43:42.200997
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push', output="! [rejected] master -> master (fetch first)\nUpdates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g., 'git pull ...') before pushing again.\nSee the 'Note about fast-forwards' in 'git push --help' for details.")) == 'git pull && git push'

# Generated at 2022-06-12 11:43:52.492185
# Unit test for function match
def test_match():

    # Tests on git output
    command = Command('test', 'git push', output='test! [rejected] test -> test (non-fast-forward)\n test')
    assert match(command)
    command = Command('test', 'git push', output='test! [rejected] test -> test (non-fast-forward)\n test')
    assert match(command)
    command = Command('test', 'git push', output='test! [rejected] test -> test (non-fast-forward)\n test')
    assert match(command)
    command = Command('test', 'git push', output='test! [rejected] test -> test (non-fast-forward)\n test')
    assert match(command)

    # Tests on git output

# Generated at 2022-06-12 11:44:14.836936
# Unit test for function match
def test_match():
	assert match(Command('git push', 
		'remote: Permission to user/repo.git denied to User.\n'
		'fatal: unable to access \'http://github.com/user/repo.git/\': The '
		'requested URL returned error: 403\n'))

# Generated at 2022-06-12 11:44:22.931209
# Unit test for function match
def test_match():
    assert not match(Command('', '! [rejected]        master -> master (non-fast-forward)'))
    assert not match(Command('', '! [rejected]        master -> master (non-fasforward)'))
    assert match(Command('', '! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind its remote\n  counterpart. Integrate the remote changes (e.g.\n  \'git pull ...\') before pushing again.\n  See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:44:32.629987
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To http://github.com/nvbn/thefuck\n ! [rejected] master -> master (non-fast-forward)',
                         '', 1))
    assert match(Command('git push',
                         'To http://github.com/nvbn/thefuck\n ! [rejected]        master -> master (non-fast-forward)',
                         '', 1))
    assert match(Command('git push',
                         'To http://github.com/nvbn/thefuck\n ! [rejected]        master -> master (non-fast-forward)\n'
                         'Updates were rejected because the tip of your current branch is behind\n'
                         'Updates were rejected because the remote contains work that you do',
                         '', 1))

# Generated at 2022-06-12 11:44:37.062115
# Unit test for function match
def test_match():
    match_new_command = git.match(git.__name__,
                                  "git push origin master:master",
                                  "Permission denied (publickey).\n"
                                  "fatal: Could not read from remote repository.\n"
                                  "\n"
                                  "Please make sure you have the correct access "
                                  "rights\n"
                                  "and the repository exists.\n",
                                  None)
    assert not match_new_command


# Generated at 2022-06-12 11:44:39.588343
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(Command("git push origin master", "", ""))
    assert result == "git pull origin master"

# Generated at 2022-06-12 11:44:44.332686
# Unit test for function match
def test_match():
    assert match(Command('git push origin newbranch',
                         ' ! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to "git@git.cs.ucla.edu:cs111/cs111-spr16.git"',
                         ''))



# Generated at 2022-06-12 11:44:49.645648
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push origin master',
                                    'Updates were rejected because the remote'
                                    ' contains work that you do',
                                    'git pull origin master')) ==
            Command(script='git pull origin master && git push origin master',
                    stderr='Updates were rejected because the remote'
                           ' contains work that you do',
                    stdout='Already up-to-date.'))

# Generated at 2022-06-12 11:44:55.128418
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git pull' == get_new_command('git push').script
    assert 'git pull' == get_new_command('git push origin master').script
    assert 'git pull' == get_new_command('git push origin master --force').script
    assert 'git pull' == get_new_command('git push origin master:master').script
    assert 'git pull' == get_new_command('git push https://github.com/nvbn/thefuck').script
    assert 'git pull' == get_new_command('git push --set-upstream origin master').script



# Generated at 2022-06-12 11:45:02.120369
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git push -u origin master",
                                   "! [rejected]        master -> master (fetch first)",
                                   "error: failed to push some refs to 'git@github.com:FooBarUser/foobar.git'",
                                   "hint: Updates were rejected because the tip of your current branch is behind",
                                   "hint: its remote counterpart. Integrate the remote changes (e.g.",
                                   "hint: 'git pull ...') before pushing again.",
                                   "hint: See the 'Note about fast-forwards' in 'git push --help' for details.")) == "git pull -u origin master && git push -u origin master"

# Generated at 2022-06-12 11:45:11.494133
# Unit test for function match

# Generated at 2022-06-12 11:45:40.231582
# Unit test for function get_new_command
def test_get_new_command():
  from thefuck.rules.git_push import get_new_command
  assert get_new_command('git push') == shell.and_('git pull', 'git push')


# Generated at 2022-06-12 11:45:46.760781
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command("git push origin master") == "git pull origin master && git push origin master")
    assert(get_new_command("git push origin master --force") == "git pull origin master && git push origin master --force")
    assert(get_new_command("git push") == "git pull && git push")
    assert(get_new_command("git push --force") == "git pull && git push --force")

# Generated at 2022-06-12 11:45:53.263775
# Unit test for function get_new_command
def test_get_new_command():
    output = """ ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/jojo/git-tutorial'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details."""
    command = Command('git push origin master', output)
    assert get_new_command(command).script == 'git pull'

# Generated at 2022-06-12 11:45:56.083607
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', 'error: failed to push some refs'
                                  'to....Updates were rejected because the'
                                  'tip of your current branch is behind'
                                  )
    assert get_new_command(command) == 'git pull'

# Generated at 2022-06-12 11:46:05.817808
# Unit test for function match
def test_match():
    cmd = Command('git push origin master',
                  output=' ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:user/repo.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert match(cmd)

# Generated at 2022-06-12 11:46:15.909805
# Unit test for function match
def test_match():
    assert match(Command("git push",
                    "To https://github.com/AdamNiederer/SkiResortSim.git\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to 'https://github.com/AdamNiederer/SkiResortSim.git'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details."))


# Generated at 2022-06-12 11:46:17.822232
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master')) == Command(
        'git pull origin master && git push origin master')

# Generated at 2022-06-12 11:46:20.513174
# Unit test for function match
def test_match():
    assert(match(Command('git push', '', ' ! [rejected]         master -> master (non-fast-forward) error: failed to push some refs to')) == True)


# Generated at 2022-06-12 11:46:21.845130
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git push", "")) == "git pull"

# Generated at 2022-06-12 11:46:31.425461
# Unit test for function match
def test_match():
    assert match(Command('git push', ' ! [rejected] master -> master (non-fast-forward)\n'
                                     'Updates were rejected because the tip of your '
                                     'current branch is behind',
                         '', 0, None))
    assert match(Command('git push', ' ! [rejected] master -> master (non-fast-forward)\n'
                                     'Updates were rejected because the remote '
                                     'contains work that you do',
                         '', 0, None))
    assert not match(Command('git push', ' ! [rejected] master -> master (non-fast-forward)\n'
                                     'Updates were rejected because the remote '
                                     'contains work that you do',
                         '', 0, None))


# Generated at 2022-06-12 11:47:29.562181
# Unit test for function get_new_command
def test_get_new_command():
    command = "git push origin master"
    new_command = "git pull origin master && git push origin master"

    assert get_new_command(command) == new_command


# Generated at 2022-06-12 11:47:39.064376
# Unit test for function match

# Generated at 2022-06-12 11:47:40.668899
# Unit test for function get_new_command
def test_get_new_command():
    assert match(Command('push'))
    assert get_new_command(Command('git push')) == 'git pull && git push'

# Generated at 2022-06-12 11:47:43.979005
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('git push origin master', '', 'fatal: The current branch')) is False
    assert match(Command('git push origin master', '', 'Updates were rejected because the tip of your')) is True


# Generated at 2022-06-12 11:47:45.436748
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'


# Generated at 2022-06-12 11:47:51.725208
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master')
    assert "git pull" == get_new_command(command)

    command = Command("git push")
    assert "git pull" == get_new_command(command)

    command = Command("git push origin master --set-upstream")
    assert "git pull origin master --set-upstream" == get_new_command(command)

    command = Command("git push -u origin master")
    assert "git pull -u origin master" == get_new_command(command)

# Generated at 2022-06-12 11:47:52.914971
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull; git push'

# Generated at 2022-06-12 11:48:02.310707
# Unit test for function get_new_command

# Generated at 2022-06-12 11:48:11.004392
# Unit test for function get_new_command

# Generated at 2022-06-12 11:48:15.530298
# Unit test for function match
def test_match():
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert not match('git push origin')
    assert not match('git push origin master >/dev/null 2>&1')
    assert not match('git push origin master')

test_match()

