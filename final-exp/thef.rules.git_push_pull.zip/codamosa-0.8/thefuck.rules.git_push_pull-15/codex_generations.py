

# Generated at 2022-06-12 11:39:49.186185
# Unit test for function match
def test_match():
    assert match(Command('git push',
      'failed to push some refs to \'git@github.com:michaelliao/awesome-python3-webapp.git\'\n'
      'hint: Updates were rejected because the tip of your current branch is behind\n'
      'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
      'hint: \'git pull ...\') before pushing again.\n'
      'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
      '',
      ''))

# Generated at 2022-06-12 11:39:57.440590
# Unit test for function match
def test_match():
    from thefuck.specific.git import git_support
    from thefuck.shells import shell
    command = shell.and_('git push origin dev',
                         "! [rejected]        dev -> dev (fetch first)\n"
                         "error: failed to push some refs to 'git@github.com:user/repo.git'\n"
                         "hint: Updates were rejected because the remote contains work that you do\n"
                         "hint: not have locally. This is usually caused by another repository pushing\n"
                         "hint: to the same ref. You may want to first integrate the remote changes\n"
                         "hint: (e.g., 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in 'git push --help' for details.")
   

# Generated at 2022-06-12 11:40:05.888269
# Unit test for function match
def test_match():
    assert match(Command('git push origin',
                         " ! [rejected]        master -> master (non-fast-forward)\n"
                         "error: failed to push some refs to 'git@github.com:cjjeakle/TheFuck.git'\n"
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         "'git pull ...' ) before pushing again.\n"
                         'hint: See the '
                         "'Note about fast-forwards' in 'git push --help' for details.\n"))

# Generated at 2022-06-12 11:40:08.390864
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin',
                                   '! [rejected] master -> master (fetch first)')) \
                                   == 'git pull origin && git push origin'

# Generated at 2022-06-12 11:40:12.270631
# Unit test for function match
def test_match():
    assert match('git push origin master')
    assert match('git push origin HEAD:master')
    assert match('git push origin user/branch')
    assert match('git push origin user/branch:branch')


# Generated at 2022-06-12 11:40:22.099027
# Unit test for function get_new_command
def test_get_new_command():
    command = ''
    assert get_new_command(command) == 'git pull'
    command = 'git push'
    assert get_new_command(command) == 'git pull'
    command = 'git remote add origin https://github.com/user/repo.git'
    assert get_new_command(command) == command
    command = 'git commit'
    assert get_new_command(command) == command
    command = 'git add'
    assert get_new_command(command) == command
    command = 'git push origin master'
    assert get_new_command(command) == 'git pull origin master'
    command = 'git push --set-upstream origin master'
    assert get_new_command(command) == 'git pull --set-upstream origin master'


# Generated at 2022-06-12 11:40:23.787363
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == 'git pull origin master'

# Generated at 2022-06-12 11:40:26.192708
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'stdout', 'stderr')) == shell.and_('git pull', 'git push')

# Generated at 2022-06-12 11:40:36.748741
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (fetch first)\n'))


# Generated at 2022-06-12 11:40:43.567085
# Unit test for function match
def test_match():
    assert match(Command('git push origin branch',
                        'Everything up-to-date\n'))
    assert not match(Command('git clone https://github.com/nvbn/thefuck',
                             'Cloning into \'thefuck\'...\n'))
    assert match(Command('git push origin branch',
                        '! [rejected]        branch -> branch (non-fast-forward)\n'
                        'error: failed to push some refs to \'https://github.com/nvbn/thefuck\'\n'
                        'To prevent you from losing history, non-fast-forward updates were rejected\n'
                        'Merge the remote changes (e.g. \'git pull\') before pushing again.  See the\n'
                        '\'Note about fast-forwards\' section of \'git push --help\' for details.\n'))


# Generated at 2022-06-12 11:40:48.854013
# Unit test for function get_new_command
def test_get_new_command():
	assert (get_new_command('git push origin master') == 'git pull && git push origin master')


# Generated at 2022-06-12 11:40:59.153389
# Unit test for function match
def test_match():
    assert not match(Command('git push'))
    assert match(Command('git push', 'fatal: ! [rejected] ... '))
    assert match(Command('git push', '! [rejected] ... '))
    assert match(Command('git push', 'Updates were rejected ...'))
    assert match(Command('git push', 'Updates were rejected ...\n'
                         'Updates were rejected ...'))
    assert match(Command('git push', 'Updates were rejected ...\n'
                         '! [rejected] ... '))
    assert match(Command('git push', '! [rejected] ...\n'
                         'Updates were rejected ...'))
    assert match(Command('git push', '! [rejected] ...\n'
                         '! [rejected] ... '))

# Generated at 2022-06-12 11:41:00.525473
# Unit test for function get_new_command
def test_get_new_command():
    _command = Command('git push')
    assert get_new_command(_command) == 'git pull && git push'

# Generated at 2022-06-12 11:41:03.740906
# Unit test for function match
def test_match():
    assert(match('git push origin master:master'))
    assert(not match('git push origin master'))
    assert(not match('git push'))
    assert(not match('git pull origin master:master'))

# Generated at 2022-06-12 11:41:05.077681
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'

# Generated at 2022-06-12 11:41:14.232719
# Unit test for function match

# Generated at 2022-06-12 11:41:18.370042
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull'
    assert get_new_command(
        Command('git push origin master:dev', '')) == 'git pull origin master:dev'


enabled_by_default = True
priority = 1000
require_output = False

# Generated at 2022-06-12 11:41:27.354169
# Unit test for function match
def test_match():
    assert match(Command('git push',
        'To https://github.com/nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n'
        'error: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\n'
        'hint: Updates were rejected because the tip of your current branch is behind\n'
        'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
        'hint: \'git pull ...\') before pushing again.\n'
        'hint: see the \'Note about fast-forwards\' in \'git push --help\' for details.\n')) == True


# Generated at 2022-06-12 11:41:37.658767
# Unit test for function get_new_command
def test_get_new_command():
    # Check function get_new_command
    assert get_new_command(Command('git push origin master','''
To git@github.com:nvbn/thefuck.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'
To prevent you from losing history, non-fast-forward updates were rejected
Merge the remote changes (e.g. 'git pull') before pushing again.  See the
'Note about fast-forwards' section of 'git push --help' for details.
''')) == shell.and_('git pull origin master', 'git push origin master')


# Generated at 2022-06-12 11:41:39.246966
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git push').script == 'git pull')



# Generated at 2022-06-12 11:41:48.548623
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git pull && git push' == get_new_command('')
    assert 'git pull && git push -f' == get_new_command('-f')
    assert 'git pull && git push --force' == get_new_command('--force')
    assert 'git pull && git push -f --force' == get_new_command('-f --force')

enabled_by_default = True

# Generated at 2022-06-12 11:41:54.640047
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 1, None))
    assert match(Command('git push origin master', '', '! [rejected]\n', 1, None))
    assert match(Command('git push origin master', '',
                         'failed to push some refs to\n', 1, None))
    assert match(Command('git push origin master', '', ('Updates were rejected because the tip of your current branch is behind'
                                                         'confrmation message\n'), 1, None))
    assert not match(Command('git push origin master', '', '', 1, None))


# Generated at 2022-06-12 11:42:01.672080
# Unit test for function match
def test_match():
    assert match(command=Command('git push -f origin master', '! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n its remote counterpart. Integrate the remote changes (e.g.\n git pull ...) before pushing again.\n'))
    assert match(command=Command('git push -f origin master', '! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the remote contains work that you do\n not have locally. This is usually caused by another repository pushing\n to the same ref. You may want to first integrate the remote changes\n (e.g., \'git pull ...\') before pushing again.\n'))

# Generated at 2022-06-12 11:42:12.236249
# Unit test for function match
def test_match():
     assert not match(Command('git difftool',
                              stderr='error: The following untracked \
                                      working tree files would be \
                                      overwritten by merge:'))
     assert match(Command('git pull origin branch',
                          output='! [rejected]        branch -> branch \
                                  (non-fast-forward)\nerror: failed to push \
                                  some refs to "..."',
                          script='git push origin branch'))
     assert not match(Command('git push origin master',
                              output='Everything up-to-date',
                              script='git push origin master'))

# Generated at 2022-06-12 11:42:18.984663
# Unit test for function get_new_command
def test_get_new_command():
    get_new_command_1 = get_new_command('git push')
    assert get_new_command_1 == '&& git pull'
    get_new_command_2 = get_new_command('git push abc')
    assert get_new_command_2 == '&& git pull abc'
    get_new_command_3 = get_new_command('git push --force')
    assert get_new_command_3 == '&& git pull --force'

# Generated at 2022-06-12 11:42:25.498765
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', 'Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\n      git pull ...) before pushing again.\n      See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert get_new_command(command) == 'git pull && git push'
    command = Command('git push origin master', 'Updates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g.,\n      git pull ...)\n      before pushing again.\n      See the \'Note about fast-forwards\' in \'git push --help\' for details.')

# Generated at 2022-06-12 11:42:27.153945
# Unit test for function match
def test_match():
    assert match(command="git push origin master")
    assert not match(command="git push")


# Generated at 2022-06-12 11:42:32.283597
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/lovac42/ReplaceDict.git\n ! [rejected] master -> master (fetch first)\n'
                         'error: failed to push some refs to \'https://github.com/lovac42/ReplaceDict.git\'\n'
                         'hint: Updates were rejected because the remote contains work that you do\n'
                         'hint: not have locally. This is usually caused by another repository pushing\n'
                         'hint: to the same ref. You may want to first integrate the remote changes\n'
                         'hint: (e.g., \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:42:39.365525
# Unit test for function match
def test_match():
  assert match(Command(script = 'git push', stderr = ' ! [rejected] master -> master (fetch first)\n error: failed to push some refs to \'https://github.com/northlop/HackyHacks.git\'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-12 11:42:49.981366
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'Total 0 (delta 0), reused 0 (delta 0)',
                         'To git@github.com:p-e-w/argbash.git',
                         ' ! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to \'git@github.com:p-e-w/argbash.git\'',
                         'hint: Updates were rejected because the tip of your current branch is behind',
                         'hint: its remote counterpart. Integrate the remote changes (e.g.',
                         'hint: \'git pull ...\') before pushing again.',
                         '',
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:43:05.551238
# Unit test for function match

# Generated at 2022-06-12 11:43:11.649791
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '! [rejected] master -> master (non-fast-forward) error: failed to push some refs to \'git@github.com:alexkuznetsov/thefuck.git\' hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes (e.g. hint: \'git pull ...\') before pushing again. hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))
    

# Generated at 2022-06-12 11:43:21.098861
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_pull_first import get_new_command

    assert get_new_command(
        Command('git push',
                'To https://github.com/nvbn/thefuck\n   a9874f0..4d4ee4f  master -> master\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/nvbn/thefuck\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n', '')) == 'git pull && git push'

# Generated at 2022-06-12 11:43:25.296551
# Unit test for function get_new_command
def test_get_new_command():
    new_cmd = get_new_command(Command('git push',
                                      'git push fatal: '
                                      'Updates were rejected because the '
                                      'remote contains work that you do',
                                      ''))
    assert new_cmd == shell.and_('git pull', 'git push')

enabled_by_default = True

# Generated at 2022-06-12 11:43:31.834249
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'Updates were rejected because the tip of your '
                         'current branch is behind its remote'
                         ' counterpart. Integrate the remote changes'
                         ' (e.g.\n'
                         '\'git pull ...\') before pushing again.\n'
                         'See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))
    assert not match(Command('git push origin master', ''))


# Generated at 2022-06-12 11:43:35.300773
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '', 0, 0)) == 'git pull origin master ; git push origin master'


# Generated at 2022-06-12 11:43:44.066343
# Unit test for function match
def test_match():
    assert match(Command('git checkout master', "", ""))
    assert not match(Command('git add remote', "", ""))
    assert match(Command('git push', "To https://github.com/nvbn/thefuck.git\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to 'https://github.com/nvbn/thefuck.git'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details\n", "https://github.com/nvbn/thefuck"))

# Generated at 2022-06-12 11:43:51.668224
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   '',
                                   'Updates were rejected because'
                                   ' the tip of your current branch'
                                   ' is behind')) == \
        shell.and_('git pull origin master', 'git push origin master')

    assert get_new_command(Command('git push origin master',
                                   '',
                                   'Updates were rejected because'
                                   ' the remote contains work that'
                                   ' you do')) == \
        shell.and_('git pull origin master', 'git push origin master')



# Generated at 2022-06-12 11:43:58.801668
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         output= ('! [rejected]        master -> master (non-fast-forward)\n'
                                  'error: failed to push some refs to\''
                                  ' git@bitbucket.org:douglasmiranda/tf-tests.git\'\n'
                                  'To prevent you from losing history, non-fast-forward '
                                  'updates were rejected\n'
                                  'Merge the remote changes before pushing again.  See the \'Note about\n'
                                  'fast-forwards\' section of \'git push --help\' for details.\n'
                                 )
                        )
              )


# Generated at 2022-06-12 11:44:08.132437
# Unit test for function match
def test_match():
    assert match(Command('git push',
                                 """
error: failed to push some refs to 'https://github.com/user/hello.git'
hint: Updates were rejected because the remote contains work that you do
hint: n't have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
                                 """))


# Generated at 2022-06-12 11:44:30.490720
# Unit test for function match
def test_match():
    assert match(Command('git push origin feature',
                         '! [rejected] feature -> feature (non-fast-forward)',
                         '', '', '', '/path'))
    assert match(Command('git push origin master',
                         '! [rejected] master -> master (fetch first)\n'
                         'Updates were rejected because the remote contains '
                         'work that you do\n',
                         '', '', '', '/path'))
    assert not match(Command('git push origin master',
                             'To git@github.com:nvie/gitflow.git\n'
                             ' * [new branch]      master -> master\n',
                             '', '', '', '/path'))


# Generated at 2022-06-12 11:44:31.502570
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command({}) == 'git pull'

# Generated at 2022-06-12 11:44:38.625382
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
            "git: 'push' is not a git command. See 'git --help'."))
    assert not match(Command('git push origin master', ''))

# Generated at 2022-06-12 11:44:43.195185
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', '! [rejected]        master -> master (fetch first)')
    new_command = get_new_command(command)
    assert "pull" in new_command
    assert "push" not in new_command


# Generated at 2022-06-12 11:44:44.178554
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '')) == 'git pull'

# Generated at 2022-06-12 11:44:53.411105
# Unit test for function match
def test_match():
    assert match(command = Command('git push origin master',
    'remote: Permission to user1/repo1.git denied to user2.\nfatal: unable to access '
    '\'https://github.com/git-user1/git-repo1.git/\': The requested URL returned error: 403'))
    assert not match(command = Command(script = 'echo bla',
    stderr = 'remote: Permission to user1/repo1.git denied to user2.\nfatal: unable to access '
    '\'https://github.com/git-user1/git-repo1.git/\': The requested URL returned error: 403'))

# Generated at 2022-06-12 11:45:01.679692
# Unit test for function match
def test_match():
    assert match(Command('git push --force',
        '/home/user/code/code-repo master ! [rejected] master -> master (non-fast-forward)\n'
        'error: failed to push some refs to \'https://github.com/user/code-repo.git\'\n'
        'hint: Updates were rejected because the tip of your current branch is behind\n'
        'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
        'hint: \'git pull ...\') before pushing again.\n'
        'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-12 11:45:11.289040
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To git@github.com:nvbn/thefuck.git\n ! [rejected]      master -> master (non-fast-forward)\nerror: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:45:18.844466
# Unit test for function match
def test_match():
    command = Command("git push", stderr=" ! [rejected]        master -> master (fetch first)")
    assert match(command)
    command = Command("git push", stderr=" ! [rejected]        master -> master (non-fast-forward)")
    assert match(command)
    command = Command("git push", stderr=" ! [rejected]        master -> master")
    assert not match(command)
    command = Command("git branch foobar", stderr="E: Can not open log file")
    assert not match(command)

#Get a new command based on the original command

# Generated at 2022-06-12 11:45:29.302780
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/nvbn/thefuck\n! [rejected] '
                         'master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to'
                         ' \'https://github.com/nvbn/thefuck\'\n'
                         'hint: Updates were rejected because the tip of '
                         'your current branch is behind\n'
                         'hint: its remote counterpart. '
                         'Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing '
                         'again.\n'
                         'hint: See the \'Note about fast-forwards\' '
                         'in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:46:06.561766
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/dylnmc/lms\''
                         '\nhint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-12 11:46:12.139997
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull && git push'
    assert get_new_command('git remote add origin git@github.com:nvbn/thefuck.git && git push -u origin master') == 'git remote add origin git@github.com:nvbn/thefuck.git && git pull && git push -u origin master'
    assert get_new_command('') == ''

# Generated at 2022-06-12 11:46:13.938087
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', '', '', ''))



# Generated at 2022-06-12 11:46:18.018362
# Unit test for function get_new_command
def test_get_new_command():
    command = types.Command('git push origin master',
                            '! [rejected]\n'
                            'Updates were rejected because the '
                            'remote contains work that you do not have locally.'
                            '\n(use "git pull" to update your local branch)',
                            '')
    assert get_new_command(command) == 'git pull && git push origin master'

# Generated at 2022-06-12 11:46:28.533724
# Unit test for function match
def test_match():
    print("testing git-push.py")

    test_cases = [ "git push -u origin master",
                    "git push origin master",
                    "git push",
                    "git push --all"]

# Generated at 2022-06-12 11:46:30.674028
# Unit test for function get_new_command
def test_get_new_command():
    script = "git push"
    new_command = get_new_command(Command(script, "! [rejected]", ""))
    assert new_command == "&& git push"

# Generated at 2022-06-12 11:46:32.583435
# Unit test for function match
def test_match():
    assert match(Command('function', 'function error'))
    assert match(Command('function', 'function error'))
    assert not match(Command('function', 'function'))

# Generated at 2022-06-12 11:46:35.553507
# Unit test for function get_new_command
def test_get_new_command():
    # If 'push' in command.script
    assert get_new_command(Command(script='git push'))==shell.and_('git pull', 'git push')


# Generated at 2022-06-12 11:46:41.209067
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 'error: failed to push some refs to \'https://github.com/user/repo.git\'', '', 1, None))
    assert match(Command('git push origin', 'error: failed to push some refs to \'https://github.com/user/repo.git\'', '', 1, None))
    assert match(Command('git push origin', '', '', 1, None))
    assert not match(Command('grep -R --exclude-dir=.git word /path/', '', '', 1, None))


# Generated at 2022-06-12 11:46:48.363020
# Unit test for function match
def test_match():
    command = Command('git push', output='''
remote: error: GH005: Large files detected.
remote: error: Trace: 2706b3c6b5ebd9b9a10b9725cc652b55
remote: error: See http://git.io/iEPt8g for more information.
remote: error: File lib/hello.pdf is 412.46 MB; this exceeds GitHub's file size limit of 100.00 MB
To https://github.com/nvbn/thefuck
 ! [remote rejected]  master -> master (pre-receive hook declined)
error: failed to push some refs to 'https://github.com/nvbn/thefuck'
''')

    assert match(command)



# Generated at 2022-06-12 11:47:53.575551
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Object', (object,), {
        'script': 'git push',
        'output': 'Updates were rejected because the tip of your current branch \
is behind'
    })
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-12 11:48:04.753972
# Unit test for function match
def test_match():
    assert match(Command(script='git push',
                 output='! [rejected]        master -> master (non-fast-forward)\n'
                        'error: failed to push some refs to\''
                        '\'git@git.example.com:thefuck/thefuck\''
                        '\'\nUpdates were rejected because the tip'
                        ' of your current branch is behind\n'
                        'its remote counterpart. Integrate the remote'
                        ' changes (e.g.\n''git pull ...) before pushing again.'
                 ))


# Generated at 2022-06-12 11:48:12.711765
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To https://github.com/JakobGlock/LyricsGenius\n! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/JakobGlock/LyricsGenius\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         1,
                         'git push origin master')) is True

# Generated at 2022-06-12 11:48:20.693360
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push', '! [rejected] master -> master (non-fast-forward)\n'
                            'error: failed to push some refs to '
                            "'git@github.com:nvbn/thefuck.git'\n"
                            'hint: Updates were rejected because the tip of your '
                            'current branch is behind\n'
                            'hint: its remote counterpart. Integrate the remote '
                            'changes (e.g.\n'
                            'hint: \'git pull ...\') before pushing again.')) == \
           "git pull && git push"

# Generated at 2022-06-12 11:48:22.624760
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', '', '', '', '', ''))
            == 'git pull')


# Generated at 2022-06-12 11:48:24.776608
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '! [rejected] master -> master (fetch first)'))


# Unit Test for function get_new_command

# Generated at 2022-06-12 11:48:29.603604
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push origin master',
                                    'failed to push some refs to '
                                    '\'git@github.com:nvbn/thefuck\'\n'
                                    'Updates were rejected because '
                                    'the tip of your current branch is behind\n'
                                    'its remote counterpart. Integrate the remote '
                                    'changes (e.g.\n\'git pull ...\') '
                                    'before pushing again.\n'
                                    'See the \'Note about fast-forwards\' in '
                                    '\'git push --help\' for details.')) ==
        ['git pull origin master', 'git push origin master'])

# Generated at 2022-06-12 11:48:37.149668
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', "! [rejected] master -> master (non-fast-forward)\nerror: failed to push some refs to 'git@github.com:rails/rails.git'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.\n"))

# Generated at 2022-06-12 11:48:38.601245
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '')) == 'git pull'

# Generated at 2022-06-12 11:48:47.914525
# Unit test for function match
def test_match():
    assert match(Command('git push origin myfeature',
                         '! [rejected]        myfeature -> myfeature (fetch first)\n'
                         'error: failed to push some refs to \'git@***.***.***.***:***/***/***.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.', 1.0))
    assert not match(Command('git push origin myfeature', 'Everything up-to-date', 1.0))