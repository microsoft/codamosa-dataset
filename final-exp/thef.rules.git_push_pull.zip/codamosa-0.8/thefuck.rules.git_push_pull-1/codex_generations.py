

# Generated at 2022-06-12 11:39:55.066671
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         stderr='Updates were rejected because the tip of ' +
                                'your current branch is behind its remote ' +
                                'counterpart. Integrate the remote changes ' +
                                '(e.g.\n' +
                                'hint: \'git pull ...\') before pushing ' +
                                'again.\n' +
                                'See the \'Note about fast-forwards\' in ' +
                                '\'git push --help\' for details.\n'))

# Generated at 2022-06-12 11:40:04.028242
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == shell.and_(replace_argument('git push origin master', 'push', 'pull'), 'git push origin master')
    assert get_new_command(Command('git push origin master', '!2 [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nUpdates were rejected because the remote contains work that you do\n')) == shell.and_(replace_argument('git push origin master', 'push', 'pull'), 'git push origin master')

# Generated at 2022-06-12 11:40:06.207271
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '!'))
    assert not match(Command('git push', '', ''))
    assert not match(Command('cd git push', '', ''))


# Generated at 2022-06-12 11:40:07.696780
# Unit test for function match
def test_match():
    assert match(Command('git push'))



# Generated at 2022-06-12 11:40:15.392959
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]\n'
                         'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', '! [rejected]\n'
                         'Updates were rejected because the remote contains work that you do'))
    assert not match(Command('git push', '! [rejected]\n'
                             'Updates were rejected because the remote contains work that you do\n'
                             'git pull'))
    assert not match(Command('git push origin master', '! [rejected]\n'
                             'Updates were rejected because the tip of your current branch is behind'))
    assert not match(Command('git push', ''))


# Generated at 2022-06-12 11:40:23.373861
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '! [rejected]\n    ...'
                                 'Updates were rejected because the tip of your current'
                                 'branch is behind', ''))
    assert match(Command('git push origin master', '! [rejected]\n    ...'
                                 'Updates were rejected because the remote contains work that you do'
                                 'not have locally', ''))
    assert not match(Command('git push origin master', '', ''))
    assert not match(Command('git push origin master', '! [rejected]\n    ...'
                                 'Updates were rejected because the remote contains work that you do'
                                 'not have locally', ''))


# Generated at 2022-06-12 11:40:24.601173
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull'

# Generated at 2022-06-12 11:40:27.122458
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '', 2))
    assert not match(Command('git push', '', '', 1))



# Generated at 2022-06-12 11:40:28.761257
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', 'Updates were rejected')) == 'git pull'

# Generated at 2022-06-12 11:40:37.309095
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push origin master',
                '''! [rejected]        master -> master (non-fast-forward)
    error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'
    hint: Updates were rejected because the tip of your current branch is behind
    hint: its remote counterpart. Integrate the remote changes (e.g.
    hint: 'git pull ...') before pushing again.
    hint: See the 'Note about fast-forwards' in 'git push --help' for details.
    ''')) == 'git pull origin master; git push origin master'

# Generated at 2022-06-12 11:40:41.813218
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push").script == 'git pull'
    assert get_new_command("git push origin master").script == 'git pull origin master'

# Generated at 2022-06-12 11:40:48.592304
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 
                         'To https://github.com/user/repo\n ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/user/repo\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-12 11:40:58.552837
# Unit test for function match

# Generated at 2022-06-12 11:41:04.978437
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (fetch first)', '', '', ''))
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)', '', '', ''))
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)', '', '', ''))
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)', '', '', ''))

# Generated at 2022-06-12 11:41:07.424312
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master'
    assert get_new_command('git push origin HEAD') == 'git pull origin HEAD'

# Generated at 2022-06-12 11:41:16.495543
# Unit test for function match
def test_match():
    command = Command('git push origin master',
                      '''
To git@github.com:nviennot/thefuck.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'git@github.com:nviennot/thefuck.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''')
    assert match(command)

# Generated at 2022-06-12 11:41:27.189900
# Unit test for function match
def test_match():
    # case 1:
    assert match(Command('git push',
                         'Username for \'https://github.com\': ',
                         'remote: Invalid username or password.',
                         'fatal: Authentication failed for \
                         \'https://github.com/codingjoe/tilde.git/\'',
                         ))
    # case 2:

# Generated at 2022-06-12 11:41:28.719720
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '')) == 'git pull && git push'

# Generated at 2022-06-12 11:41:38.546773
# Unit test for function match
def test_match():
    command = Command('git push', '''To https://github.com/yyuu/pyenv.git
! [rejected]        master     -> master (fetch first)
error: failed to push some refs to 'https://github.com/yyuu/pyenv.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''')
    assert match(command)
    assert get_new_command(command) == \
           "git pull && git push"

# Generated at 2022-06-12 11:41:45.551712
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git pull origin master', '', '')) == 'git pull origin master && git pull'
    assert get_new_command(Command('git push origin master', '', '')) == 'git pull origin master && git push'
    assert get_new_command(Command('git push', '', '')) == 'git pull && git push'
    assert get_new_command(Command('git push origin', '', '')) == 'git pull origin && git push'



# Generated at 2022-06-12 11:41:56.880099
# Unit test for function match
def test_match():
    assert match(create_mock_command('git push', '! [rejected]'))
    assert match(create_mock_command('git push',
        'Updates were rejected because the tip of your current branch is behind'))
    assert match(create_mock_command('git push',
        'Updates were rejected because the remote contains work that you do'))
    assert not match(create_mock_command('git push', 'Updates were rejected'
        ' because the remote contains work that you do not have locally.'))
    assert not match(create_mock_command('git push', 'To prevent you from lo'
        'sing history, non-fast-forward updates were rejected Merge the remote'
        ' changes (e.g. git pull ...) before pushing again.'))

# Generated at 2022-06-12 11:42:00.793341
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '! [rejected]'
                                   'Updates were rejected because the tip of '
                                   'your current branch is behind...')) == shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-12 11:42:02.406780
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '')) == 'git pull && git push'

# Generated at 2022-06-12 11:42:09.441930
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git pull --rebase && git push',
                      '! [rejected]        master -> master (non-fast-forward)\n'
                      'error: failed to push some refs to \'ssh://git@bitbucket.org/filipepinto/test.git\'\n'
                      'hint: Updates were rejected because the tip of your current branch is behind\n'
                      'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                      'hint: \'git pull ...\') before pushing again.\n'
                      'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
                      'ghit')
    new_command = get_new_command(command)

# Generated at 2022-06-12 11:42:15.978782
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/user/repo.git\'\n'
                         'hint: Updates were rejected because the tip of your'
                         ' current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.',
                         ''))



# Generated at 2022-06-12 11:42:23.295411
# Unit test for function match
def test_match():
    assert match(Command('git push',
      'To http://github.com/nvbn/thefuck'
      '\n ! [rejected]        master -> master (fetch first)'
      '\nerror: failed to push some refs to \'http://github.com/nvbn/thefuck\''
      '\nhint: Updates were rejected because the remote contains work that you do'
      'n\'t have locally. This is usually caused by another repository pushing to the same ref.'
      '\nhint: If you are able to commit at the command line, you may'
      '\nhint: want to try using git push --force to push again.',
      '', 1))


# Generated at 2022-06-12 11:42:25.348759
# Unit test for function match
def test_match():
    command = Command("git push origin master", "")

    assert match(command) is True



# Generated at 2022-06-12 11:42:35.520641
# Unit test for function match
def test_match():
    assert match(Command('git push',
                  output='! [rejected] master -> master (fetch first)                                                                                                                                           error: failed to push some refs to \'git@github.com:adamin/TheFuck.git\'                        Updates were rejected because the tip of your current branch is behind'
                  ))
    
    assert match(Command('git push',
                  output='! [rejected] master -> master (non-fast-forward)                                                                                                                                           error: failed to push some refs to \'git@github.com:adamin/TheFuck.git\'                        Updates were rejected because the remote contains work that you do'
                  ))
    

# Generated at 2022-06-12 11:42:37.636452
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push origin master", "failed to push some refs to")
    assert get_new_command(command) == "git pull origin master && git push origin master"

# Generated at 2022-06-12 11:42:40.529051
# Unit test for function match
def test_match():
    assert match(u'git push origin master')
    assert not match(u'git push origin master Hello World')
    assert not match(u'git push origin master')

# Generated at 2022-06-12 11:42:52.639253
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push origin") == "git pull origin && git push origin"

# Generated at 2022-06-12 11:43:02.857606
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
                                        'error: failed to push some refs to \'http://github.com/user/repo.git\''
                                        '\nhint: Updates were rejected because the tip of your '
                                        'current branch is behind hint: its remote counterpart.'
                                        ' Integrate the remote changes hint: (e.g. hint: \'git pull ...\')'
                                        ' before pushing again.'
                                        '\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:43:12.990767
# Unit test for function match

# Generated at 2022-06-12 11:43:15.949538
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', ''))
    assert not match(Command('git push --force origin master', ''))
    assert not match(Command('git pull --rebase origin master', ''))


# Generated at 2022-06-12 11:43:25.389095
# Unit test for function match
def test_match():
    command = Command("git push -u origin master", "\n ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to 'git@github.com:Yugiro/dotfiles.git'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: 'git pull ...') before pushing again.\n hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n")
    assert match(command)

# Generated at 2022-06-12 11:43:31.921742
# Unit test for function match
def test_match():
    assert not match(Command('git push', '', ''))

    assert match(Command('git push', '! [rejected]', ''))

    assert match(Command('git push', 'failed to push some refs to', ''))

    assert match(Command('git push',
                         'Updates were rejected because the tip of your '
                         'current branch is behind', ''))

    assert match(Command('git push',
                         'Updates were rejected because the remote '
                         'contains work that you do', ''))



# Generated at 2022-06-12 11:43:42.738557
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 1, 5))
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (fetch first)',
                         'error: failed to push some refs to \'git@heroku.com:thawing-dusk-8153.git\'',
                         1, 5))
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to \'git@heroku.com:thawing-dusk-8153.git\'',
                         1, 5))

# Generated at 2022-06-12 11:43:51.146287
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', '! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:django/django.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.', '', '')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-12 11:43:59.674222
# Unit test for function match
def test_match():
    # test match() function
    from thefuck.types import Command

    assert match(Command('git push origin master',
                         stderr=' ! [rejected]        master -> master (non-fast-forward)',
                         script='git push origin master'))

    assert match(Command('git push origin master',
                         stderr=' ! [rejected]        master -> master (fetch first)',
                         script='git push origin master'))

    assert not match(Command('git push origin master',
                             stderr=' ! [rejected]        master -> master (fetch first)',
                             script='echo hello'))

    assert not match(Command('git push origin master',
                             stderr=' ! [rejected]        master -> master (fetch first)',
                             script='git clone hello'))


# Generated at 2022-06-12 11:44:06.640636
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected] master -> master (non-fast-forward) error: failed to push some refs to \'git@example.com:some/repo.git\' hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes (e.g. hint: \'git pull ...\') before pushing again. hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-12 11:44:35.492161
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'Everything up-to-date\n'))
    assert not match(Command('git push', ''))

# Generated at 2022-06-12 11:44:36.684784
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'

# Generated at 2022-06-12 11:44:41.214167
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master'
    assert get_new_command('git push') == 'git pull'
    assert get_new_command('git push origin') == 'git pull origin'
    

# Generated at 2022-06-12 11:44:43.770814
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push', output='Updates were rejected because the tip of your current branch is behind')) == shell.and_('git pull', 'git push')

# Generated at 2022-06-12 11:44:52.664977
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to \'http://github.com/user/repo.git\'\n'
                         'hint: Updates were rejected because the remote contains work that you do\n'
                         'hint: not have locally. This is usually caused by another repository pushing\n'
                         'hint: to the same ref. You may want to first integrate the remote changes\n'
                         'hint: (e.g., \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', True)) == True



# Generated at 2022-06-12 11:45:00.888383
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '!')) == False
    assert match(Command('git push', '', 'Updates were rejected because the tip'+
                         ' of your current branch is behind its remote'+
                         ' counterpart. Merge the remote changes (e.g. '+
                         '\'git pull\') before pushing again.')) == True

# Generated at 2022-06-12 11:45:10.703018
# Unit test for function match
def test_match():
    tc = Command('git push origin master',
                 "...\n ! [rejected]        master -> master (non-fast-forward)\n"
                 "error: failed to push some refs to 'git@github.com:...\n"
                 "To prevent you from losing history, non-fast-forward updates were rejected\n"
                 "Merge the remote changes (e.g. 'git pull') before pushing again.  See the\n"
                 "the 'Note about fast-forwards' section of 'git push --help' for details.\n",
                 '/foo/bar')
    assert match(tc)
    

# Generated at 2022-06-12 11:45:20.326989
# Unit test for function get_new_command

# Generated at 2022-06-12 11:45:25.231035
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push origin master',
                                   stderr='git-push: error: failed to push some refs to...',
                                   env={'PATH': '/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games'})) == 'git pull origin master'

# Generated at 2022-06-12 11:45:34.024667
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to \'https://github.com/nifty/pride.git\'',
                         'hint: Updates were rejected because the tip of your current branch is behind',
                         'hint: its remote counterpart. Integrate the remote changes (e.g.',
                         'hint: \'git pull ...\') before pushing again.',
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:46:20.575387
# Unit test for function match

# Generated at 2022-06-12 11:46:21.527250
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(' ', ' '))

# Generated at 2022-06-12 11:46:31.749658
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '''fatal: The current branch master has no upstream branch.
To push the current branch and set the remote as upstream, use

    git push --set-upstream origin master

To push into master in the remote repository use

    git push origin master:master

! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/user/repo'
'''))

# Generated at 2022-06-12 11:46:33.923693
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected] ... Updates were rejected because '
                         'the tip of your current branch is behind'))



# Generated at 2022-06-12 11:46:40.514409
# Unit test for function match

# Generated at 2022-06-12 11:46:49.011093
# Unit test for function match

# Generated at 2022-06-12 11:46:51.177013
# Unit test for function get_new_command
def test_get_new_command():
    for command in [Command('git push', 'git pull'),
                    Command('git push origin HEAD', 'git pull origin HEAD')]:
        assert get_new_command(command) == command.script

# Generated at 2022-06-12 11:46:53.811002
# Unit test for function match
def test_match():
    assert match(command="/usr/bin/git push")
    assert not match(command="/usr/bin/git push -v")
    assert not match(command="/usr/bin/git pull")


# Generated at 2022-06-12 11:46:55.157653
# Unit test for function match
def test_match():
    assert match('git push origin master')
    assert match('git push')
    assert not match('git pull')

# Generated at 2022-06-12 11:47:02.604041
# Unit test for function match
def test_match():
    command = Command('git push origin master',
                      ' ! [rejected]        master -> master (non-fast-forward)\n'
                      'error: failed to push some refs to \'git@github.com:danrneal/git-cheat-sheet.git\'\n'
                      'To prevent you from losing history, non-fast-forward updates were rejected\n'
                      'Merge the remote changes (e.g. \'git pull\') before pushing again.  See the\n'
                      '\'Note about fast-forwards\' section of \'git push --help\' for details.\n')
    assert match(command)


# Generated at 2022-06-12 11:47:54.984992
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To git@github.com:nvbn/thefuck.git ! [rejected]        '
                         'master -> master (fetch first) error: failed to '
                         'push some refs to \'git@github.com:nvbn/thefuck.git\'\n'
                         'Updates were rejected because the tip of your current branch is behind\n'
                         'its remote counterpart. Integrate the remote changes (e.g.\n'
                         '\'git pull ...\') before pushing again.\n'
                         'See the \'Note about fast-forwards\' section of \'git push --help\' for details.',
                         '', 0, 'git push origin master'))


# Generated at 2022-06-12 11:48:04.753307
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         "! [rejected]        master -> master (non-fast-forward)\n"
                         "error: failed to push some refs to 'https://github.com/angelo-v/eloquent-javascript.git'\n"
                         "hint: Updates were rejected because the tip of your current branch is behind\n"
                         "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                         "hint: 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n"))


# Generated at 2022-06-12 11:48:06.295531
# Unit test for function match
def test_match():
    command = Command('git push')
    assert match(command)


# Generated at 2022-06-12 11:48:13.577758
# Unit test for function match
def test_match():
    command = Command('git push', 'fatal: The current branch master has no upstream branch.\n\nTo push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n\n', 'git', 'push')
    assert match(command) == False
    command = Command('git push', 'To push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n\n', 'git', 'push')
    assert match(command) == False
    command = Command('git push', 'To push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n\n', 'git', 'push')
    assert match(command) == False

# Generated at 2022-06-12 11:48:23.327925
# Unit test for function match
def test_match():
    assert match(Command('git push origin development',
                        stderr='To https://github.com/BikramAdhikari/helloworld.git\n ! [rejected]\n     development -> development (fetch first)\n error: failed to push some refs to \'https://github.com/BikramAdhikari/helloworld.git\'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:48:23.846608
# Unit test for function match
def test_match():
    pass

# Generated at 2022-06-12 11:48:25.052990
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull'

# Generated at 2022-06-12 11:48:32.102526
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To git@gitlab.com:ekdy88/project.git ! [rejected]          master -> master (non-fast-forward) error: failed to push some refs to'
                         '\'git@gitlab.com:ekdy88/project.git\' hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes hint: (e.g.'
                         'git pull ...) before pushing again" hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))



# Generated at 2022-06-12 11:48:40.847857
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
        'error: failed to push some refs to \'git@github.com:luongvo209/git-cheat-sheet.git\'\n'
        'hint: Updates were rejected because the tip of your current branch is behind\n'
        'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
        'hint: \'git pull ...\') before pushing again.\n'
        'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'
        ))

# Generated at 2022-06-12 11:48:46.964958
# Unit test for function match
def test_match():
    # Test case of pushed file not exist on remote
    command = Command('git push origin master',
    '')
    assert match(command)
    # Test case of pushed file already exist on remote
    command = Command('git push origin master',
    '')
    assert not match(command)
    # Test case of other case
    command = Command('git push origin master',
    '')
    assert not match(command)



# Generated at 2022-06-12 11:49:47.881631
# Unit test for function match
def test_match():
    assert match(Command('git push',
        'To https://github.com/nvbn/thefuck.git\n ! [rejected] \
        master -> master (fetch first)\nerror: failed to push some refs to \
        \'https://github.com/nvbn/thefuck.git\'\nhint: Updates were rejected \
        because the remote contains work that you do\nhint: not have locally. \
        This is usually caused by another repository pushing\nhint: to the same \
        ref. You may want to first integrate the remote changes\nhint: (e.g., \
        \'git pull ...\') before pushing again.\nhint: See the \'Note about \
        fast-forwards\' in \'git push --help\' for details.'))
