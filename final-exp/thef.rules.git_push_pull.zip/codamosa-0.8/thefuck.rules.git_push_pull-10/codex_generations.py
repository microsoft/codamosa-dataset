

# Generated at 2022-06-12 11:39:44.728870
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull && git push origin master'

# Generated at 2022-06-12 11:39:54.695164
# Unit test for function match
def test_match():
    assert match(
        Command('git push',
                'To git@github.com:USERNAME/Hello-World.git\n '
                ' ! [rejected]        master -> master (non-fast-forward)'
                '\nerror: failed to push some refs to'
                '\'git@github.com:USERNAME/Hello-World.git\''
                '\nhint: Updates were rejecetd because the tip of your'
                'current branch is behind'
                '\nhint: its remote counterpart. Integrate the remote changes'
                '(e.g'
                '\nhint: git pull ...) before pushing again.'
                '\nhint: See the \'Note about fast-forwards\' in '
                '\'git push --help\' for details.')) == True


# Generated at 2022-06-12 11:40:00.157266
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         stderr='To https://github.com/nvbn/thefuck.git\n ! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'
                         )).script == 'git pull && git push'

# Generated at 2022-06-12 11:40:05.347987
# Unit test for function get_new_command
def test_get_new_command():
    git_push = u'git push'
    git_pull = u'git pull'
    assert get_new_command(Command(git_push, u'! [rejected]\nUpdates were rejected because the tip of your current branch is behind', '', '')) == shell.and_(git_pull, git_push)
    assert get_new_command(Command(git_push, u'Updates were rejected because the remote contains work that you do', '', '')) == shell.and_(git_pull, git_push)

# Generated at 2022-06-12 11:40:14.503430
# Unit test for function get_new_command
def test_get_new_command():
    command_diff = Command("git push origin master", "")
    command_diff.script = "git push origin master"
    command_diff.output = """To https://github.com/nvbn/thefuck.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
"""

# Generated at 2022-06-12 11:40:17.895423
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push')
    new_command = get_new_command(command)
    assert not new_command.script.startswith('sudo ')
    assert new_command.script.endswith('git pull')

# Generated at 2022-06-12 11:40:24.137154
# Unit test for function match
def test_match():
    example_output = '''
To https://github.com/user/repo.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/user/repo.git'
To prevent you from losing history, non-fast-forward updates were rejected
Merge the remote changes (e.g. 'git pull') before pushing again.  See the
'Note about fast-forwards' section of 'git push --help' for details.
'''
    assert match(Command('git push', example_output))

# Generated at 2022-06-12 11:40:35.044301
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 2))

# Generated at 2022-06-12 11:40:38.410186
# Unit test for function match
def test_match():
    assert match(Command('git push', 'error: failed to push some refs to',''))
    assert not match(Command('git push', '',''))
    assert not match(Command('git pull', 'error: failed to push some refs to',''))


# Generated at 2022-06-12 11:40:46.807492
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push origin foobranch',
                ' ! [rejected] foobranch -> foobranch (non-fast-forward)\n'
                'error: failed to push some refs to \'ssh://git@git.corp.google.com:29418/repo.git\'')) \
        == 'git pull && git push origin foobranch'

# Generated at 2022-06-12 11:40:56.848461
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push origin master',
                                    '! [rejected] master -> master (fetch first)'))) == 'git pull origin master'
    assert (get_new_command(Command('git push origin master',
                                    '! [rejected] master -> master (fetch first)'))) == 'git pull origin master'
    assert (get_new_command(Command('git push origin master',
                                    '! [rejected] master -> master (fetch first)'))) == 'git pull origin master'


# Generated at 2022-06-12 11:40:57.892204
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull; git push'


# Generated at 2022-06-12 11:41:04.687174
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '''To git.assembla.com:zaza-zzz/zaza.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@git.assembla.com:zaza-zzz/zaza.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-12 11:41:08.732144
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'Username for \'https://github.com\':',
                         stderr='fatal: could not read Password for \'https://Username@github.com\'\: No such file or directory\n'))


# Generated at 2022-06-12 11:41:11.259542
# Unit test for function match
def test_match():
	assert match(Command('git push origin master',
                         stderr='error: failed to push some refs to'))



# Generated at 2022-06-12 11:41:13.273854
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected]  master -> master (fetch first)')) == 'git pull && git push'

# Generated at 2022-06-12 11:41:23.098062
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/katherine/pydanny-event-notes.git\n ! [rejected]        master -> master (fetch first)\n error: failed to push some refs to \'https://github.com/katherine/pydanny-event-notes.git\'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
                         'git push'))


# Generated at 2022-06-12 11:41:24.406046
# Unit test for function match
def test_match():
    assert match(command('git push origin master'))


# Generated at 2022-06-12 11:41:28.849231
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '! [rejected]\nhint: Updates were rejected '
                      'because the tip of your current branch is behind',
                      'https://developer.github.com/v3')
    assert get_new_command(command).script == 'git pull && git push'



# Generated at 2022-06-12 11:41:38.764441
# Unit test for function match
def test_match():
    assert match(Command("git push origin master", "! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n its remote counterpart. Integrate the remote changes (e.g\n.\ngit pull . . .\n))"))
    assert match(Command("git push master", "! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n its remote counterpart. Integrate the remote changes (e.g\n.\ngit pull . . .\n))"))
    assert not match(Command("git push origin master", ""))
    assert not match(Command("git push master", ""))


# Generated at 2022-06-12 11:41:48.687712
# Unit test for function match
def test_match():
    assert match(Command('git push dokku master', '', ''))
    assert match(Command('git push dokku master origin', '', ''))
    assert match(Command('git push dokku', '', ''))
    assert not match(Command('git push', '', ''))
    assert not match(Command('git status', '', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git checkout', '', ''))


# Generated at 2022-06-12 11:41:55.824507
# Unit test for function match

# Generated at 2022-06-12 11:41:57.088609
# Unit test for function match
def test_match():
    assert match(Command("git push origin master", "foo"))


# Generated at 2022-06-12 11:42:08.523484
# Unit test for function match
def test_match():

    assert match(Command('git push origin myfeature',
                         ''' ! [rejected]        myfeature -> myfeature (non-fast-forward)
error: failed to push some refs to 'git@github.com:my/repo.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''))


# Generated at 2022-06-12 11:42:12.352457
# Unit test for function match
def test_match():
    assert not match(Command('git push origin master',
                             ' ! [rejected] master -> master (fetch first)'))
    assert not match(Command('git push origin master',
                             'To git@github.com:nvbn/thefuck.git'
                             ' ! [rejected] master -> master (fetch first)'))


# Generated at 2022-06-12 11:42:18.345990
# Unit test for function match
def test_match():
    assert match(Command('git push -u origin master',
                         'Username for \'https://github.com\': Username\n'
                         'Password for \'https://Username@github.com\':'
                         ' Everything up-to-date\n'))
    assert not match(Command('git push -u origin master',
                             'Username for \'https://github.com\': Username\n'
                             'Password for \'https://Username@github.com\':'
                             ' Everything up-to-date\n'
                             'error: failed to push some refs to\''
                             'https://github.com/Username/Repository.git\''))

# Generated at 2022-06-12 11:42:22.890627
# Unit test for function match
def test_match():
    assert match(Command(script='git pus',
                         stderr='''! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'git@github.com:Webkul/magnum-ci.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''))
    assert not match(Command(script='git push'))
    assert not match(Command(script='git pull'))

# Generated at 2022-06-12 11:42:24.689758
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master').script == 'git pull && git push origin master'

# Generated at 2022-06-12 11:42:31.946953
# Unit test for function match
def test_match():
    command = Command('git push origin master', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n')
    assert match(command)
    assert not match(Command('git push origin master', 'Updates were rejected because the remote contains work that you do\n'))
    assert not match(Command('git push origin master', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind'))



# Generated at 2022-06-12 11:42:36.098441
# Unit test for function match
def test_match():
    assert ('git push origin master' in match(Command('git push origin master', ''))
            == True)
    assert ('git push origin master' in match(Command('git push origin master', ''))
            == True)
    assert ('git push origin master' in match(Command('git push origin master', ''))
            == True)

# Generated at 2022-06-12 11:42:52.390077
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push',
                                    ' ! [rejected]        master -> master (fetch first)\n'
                                    'error: failed to push some refs to \'git@github.com:user/repo.git\'\n'
                                    'hint: Updates were rejected because the remote contains work that you do\n'
                                    'hint: not have locally. This is usually caused by another repository pushing\n'
                                    'hint: to the same ref. You may want to first integrate the remote changes\n'
                                    'hint: (e.g., \'git pull ...\') before pushing again.\n'
                                    'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                                 'git pull; git push')))



# Generated at 2022-06-12 11:43:02.658044
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to \'git@example.com:yyy/xxx.git\'',
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind',
                         'hint: its remote counterpart. Integrate the remote changes ',
                         '(e.g. hint: \'git pull ...\') before pushing again. hint:',
                         'hint: See the \'Note about fast-forwards\' '
                         'in \'git push --help\' for details.'))


# Generated at 2022-06-12 11:43:12.868608
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/jingbao-chen/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.'))

# Generated at 2022-06-12 11:43:22.454260
# Unit test for function get_new_command
def test_get_new_command():
    import os
    import pdb
    pdb.set_trace()
    os.chdir('/home/aj/trash/test_git')
    from thefuck.rules.git_push_rejected import get_new_command
    from thefuck.shells import Shell
    # import pdb; pdb.set_trace()

# Generated at 2022-06-12 11:43:32.272138
# Unit test for function match
def test_match():
    assert match(Command("git push", "ERROR: ! [rejected]", ""))
    assert match(Command("git push", "ERROR: ! [rejected]", "Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g. by running \"git pull ...\") before pushing again. See the 'Note about fast-forwards' in 'git push --help' for details."))
    assert match(Command("git push", "ERROR: ! [rejected]", "Updates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g., 'git pull ...') before pushing again. See the 'Note about fast-forwards' in 'git push --help' for details."))


# Generated at 2022-06-12 11:43:36.096160
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git push", "Updates were rejected because the remote contains work that you do")) == shell.and_("git pull", "git push")

# Generated at 2022-06-12 11:43:44.431362
# Unit test for function get_new_command

# Generated at 2022-06-12 11:43:53.527378
# Unit test for function match
def test_match():
    assert (match(
        Command(script='git push origin master',
                output="Everything up-to-date\n"))._fail)

# Generated at 2022-06-12 11:44:01.386727
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push origin master',
                " ! [rejected]        master -> master (non-fast-forward)\n"
                "error: failed to push some refs to "
                "'git@bitbucket.org:james-jiang/test.git'\n"
                "hint: Updates were rejected because the tip of "
                "your current branch is behind\n"
                "hint: its remote counterpart. Integrate the remote "
                "changes (e.g.\n"
                "hint: 'git pull ...') before pushing again.\n"
                "hint: See the 'Note about fast-forwards' in "
                "'git push --help' for details.\n")) == 'git pull && git push origin master'

# Generated at 2022-06-12 11:44:09.506827
# Unit test for function match
def test_match():
    assert match(Command('git push',
            """To http://github.com/nvbn/thefuck
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'http://github.com/nvbn/thefuck'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.""",
            ''))

# Generated at 2022-06-12 11:44:25.745142
# Unit test for function match

# Generated at 2022-06-12 11:44:35.128355
# Unit test for function match

# Generated at 2022-06-12 11:44:37.544253
# Unit test for function get_new_command
def test_get_new_command():
    if get_new_command:
        command = Command('git push', '!!')
        assert get_new_command(command) == 'git pull'

        command = Command('git push', '!!')
        assert get_new_command(command) == 'git pull'

# Generated at 2022-06-12 11:44:43.847803
# Unit test for function get_new_command
def test_get_new_command():
    script = "git push"
    command = Command(script, "Updates were rejected because the remote contains work that you do not have locally.  This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g., 'git pull ...') before pushing again.", '', '', '')

    assert get_new_command(command) == shell.and_('git pull', script)

# Generated at 2022-06-12 11:44:53.068235
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g. \'git pull ...\') before pushing again.'))
    assert match(Command('git push', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g. \'git pull ...\') before pushing again.'))

# Generated at 2022-06-12 11:45:01.594683
# Unit test for function match
def test_match():
    command = Command('git push origin master', 
        '''To http://www.example.com/foo/bar.git
         ! [rejected]        master -> master (non-fast-forward)
         error: failed to push some refs to 'http://www.example.com/foo/bar.git'
         hint: Updates were rejected because the tip of your current branch is behind
         hint: its remote counterpart. Integrate the remote changes (e.g.
         hint: 'git pull ...') before pushing again.
         hint: See the 'Note about fast-forwards' in 'git push --help' for details.''')
    assert match(command)

# Generated at 2022-06-12 11:45:07.087471
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git push' == get_new_command("git push")
    assert 'git push -f' == get_new_command("git push -f")
    assert 'git push origin' == get_new_command("git push origin")
    assert 'git push origin --tags' == get_new_command("git push origin --tags")

enabled_by_default = True

# Generated at 2022-06-12 11:45:08.076233
# Unit test for function match
def test_match():
    # to be implemented
    pass


# Generated at 2022-06-12 11:45:14.170924
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/user/repo.git\n ! [rejected]      master -> master (fetch first)\nerror: failed to push some refs to \'https://github.com/user/repo.git\'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))


# Generated at 2022-06-12 11:45:22.020375
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'error: failed to push some refs to',
                         ''))
    assert match(Command('git push',
                         'error: failed to push some refs to\n'
                         'Updates were rejected because the tip of your '
                         'current branch is behind',
                         ''))
    assert match(Command('git push',
                         'error: failed to push some refs to\n'
                         'Updates were rejected because the remote '
                         'contains work that you do',
                         ''))
    assert not match(Command('git commit',
                             'error: failed to push some refs to',
                             ''))


# Generated at 2022-06-12 11:45:35.690462
# Unit test for function match
def test_match():
    match_test = '''
To https://github.com/strikkhu/thefuck.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/strikkhu/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''

    assert match(Command(script='git push',
                         output=match_test)) is True
    assert match(Command(script='git push origin master',
                         output=match_test)) is True

# Generated at 2022-06-12 11:45:42.608711
# Unit test for function get_new_command
def test_get_new_command():
    import pytest
    from thefuck.rules.git_push_update_rejected import get_new_command
    from thefuck.rules.git_push_update_rejected import match
    from thefuck.types import Command
    

# Generated at 2022-06-12 11:45:46.866476
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 0, None))
    assert not match(Command('git push origin master', '', '', 0, None))
    assert not match(Command('git pull origin master', '', '', 0, None))


# Generated at 2022-06-12 11:45:54.648886
# Unit test for function match
def test_match():
    command = Command('git push')
    output = Command('! [rejected]        master -> master (non-fast-forward)\n'
                     'error: failed to push some refs to \'git@github.com:Bangoura/thefuck\''
                     '\nhint: Updates were rejected because the tip of your'
                     ' current branch is behind\nhint: its remote counterpart. Integrate'
                     ' the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.'
                     '\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert match(command, output)

    command = Command('git push')

# Generated at 2022-06-12 11:46:04.206400
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   stderr='To git@github.com:nvbn/thefuck.git\n ! [rejected]        develop -> develop (non-fast-forward)\n error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-12 11:46:14.365396
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/theriverman/dotfiles.git\n ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:theriverman/dotfiles.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
                         '', 0))

# Generated at 2022-06-12 11:46:16.219299
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'Updates were rejected because the tip of your current branch is behind')) == 'git pull && git push'

# Generated at 2022-06-12 11:46:17.588741
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push master')) == 'git pull master'

# Generated at 2022-06-12 11:46:22.076921
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', 'Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.hint: git pull ... ) before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert get_new_command(command) == shell.and_('git pull', 'git push')

# Generated at 2022-06-12 11:46:24.972707
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = 'git push origin master', output = "")) == 'git pull origin master && git push origin master'

# Generated at 2022-06-12 11:46:44.834109
# Unit test for function match

# Generated at 2022-06-12 11:46:46.045194
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '')) == 'git pull'

# Generated at 2022-06-12 11:46:49.012928
# Unit test for function get_new_command
def test_get_new_command():
    """Function get_new_command shall return script including pull"""
    from mock import Mock
    shell_command = Mock(script = 'git push')
    new_command = get_new_command(shell_command)
    assert 'git pull' in new_command


# Generated at 2022-06-12 11:46:50.228223
# Unit test for function get_new_command
def test_get_new_command():
    assert git.get_new_command('git push origin master') == 'git pull origin master'

# Generated at 2022-06-12 11:46:51.461700
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull && git push'

# Generated at 2022-06-12 11:46:57.976265
# Unit test for function match

# Generated at 2022-06-12 11:47:05.777377
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', ''))
    assert match(Command('git push origin master', '''
To git@github.com:hansonxu/thefuck.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:hansonxu/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-12 11:47:07.684536
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('push', '')

    assert get_new_command(command) == '&& pull'

# Generated at 2022-06-12 11:47:16.063581
# Unit test for function match
def test_match():
    assert match(Command(script="git push",
                         stderr='''! [rejected] master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))


# Generated at 2022-06-12 11:47:24.668197
# Unit test for function match
def test_match():
    assert match(Command('git push origin master -sasdfds',
                         stderr=' ! [rejected]                master -> master (non-fast-forward)',
                         stdout='failed to push some refs to \'git@github.com:wjxhuainan/helloworld.git\'\n'
                                'Updates were rejected because a pushed branch tip is behind its remote\n'
                                'counterpart. Check out this branch and integrate the remote changes\n'
                                '(e.g.\n'
                                'git pull ... ) before pushing again.\n'
                                'See the \'Note about fast-forwards\' in \'git push --help\' for details.')) == True

# Generated at 2022-06-12 11:48:06.336991
# Unit test for function match

# Generated at 2022-06-12 11:48:14.297513
# Unit test for function match
def test_match():
    command = Command("git push origin master")
    output = "! [rejected]    master -> master (fetch first)\n" \
             "error: failed to push some refs to 'git@github.com:SebastianJ/dotfiles.git'\n" \
             "hint: Updates were rejected because the remote contains work that you do\n" \
             "hint: not have locally. This is usually caused by another repository pushing\n" \
             "hint: to the same ref. You may want to first integrate the remote changes\n" \
             "hint: (e.g., 'git pull ...') before pushing again.\n" \
             "hint: See the 'Note about fast-forwards' in 'git push --help' for details."
    assert match(Command(command, output))
    
    command

# Generated at 2022-06-12 11:48:24.039473
# Unit test for function match
def test_match():
    assert match(Command('git push', '''error: failed to push some refs to
 'https://github.com/username/repo_name.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''))

# Generated at 2022-06-12 11:48:33.177908
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (fetch first)',
                         ' error: failed to push some refs to',
                         ' hint: Updates were rejected because the tip of your',
                         ' hint: current branch is behind its remote counterpart.',
                         ' hint: Integrate the remote changes (e.g. hint:',
                         ' hint: git pull ...) before pushing again.',
                         ' hint: See the note about fast-forwards in the',
                         ' hint: \'Pulling from a remote\' section of \'git push --help\' for details.'))

# Generated at 2022-06-12 11:48:41.593963
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '''To https://github.com/user/repo
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/user/repo'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''
                        ))

# Generated at 2022-06-12 11:48:48.263239
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push origin branch', stderr='! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n')) == 'git pull && git push origin branch'
    assert get_new_command(Command(script='git push origin branch', stderr='! [rejected]        master -> master (fetch first)\nUpdates were rejected because the remote contains work that you do\n')) == 'git pull && git push origin branch'


# Generated at 2022-06-12 11:48:51.539546
# Unit test for function get_new_command
def test_get_new_command():
    assert git_support(get_new_command) is False
    assert get_new_command('git branch master && git push origin master') == 'git branch master && git pull origin master'
    assert get_new_command('git push origin master') == 'git pull origin master'

# Generated at 2022-06-12 11:48:53.157103
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push')) == 'git pull'


# Generated at 2022-06-12 11:48:54.934075
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command('git push origin master')
    assert new_command == 'git pull && git push origin master'

# Generated at 2022-06-12 11:49:01.441897
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git push origin master",
                                   output="! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g. git pull ...) before pushing again.\n\nGit Output: error: failed to push some refs to")).script == shell.and_('git pull origin master', 'git push origin master')