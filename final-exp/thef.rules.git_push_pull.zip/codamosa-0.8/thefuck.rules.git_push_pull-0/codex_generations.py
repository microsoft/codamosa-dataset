

# Generated at 2022-06-12 11:39:53.861576
# Unit test for function match
def test_match():
    assert match(Command("git push origin master",
                         "To https://github.com/nvie/gitflow.git\n ! [rejected]        master -> master (fetch first)\n error: failed to push some refs to 'https://github.com/nvie/gitflow.git'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., 'git pull ...') before pushing again.\n hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n",
                             1))

# Generated at 2022-06-12 11:40:03.865113
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to ''\n''To prevent you from '
                         'losing history, non-fast-forward updates were rejected',
                         'Merge the remote changes (e.g. ''git pull'') before pushing again.',
                         'See the ''Note about fast-forwards'' in ''git push --help'' for details.'))

# Generated at 2022-06-12 11:40:05.772702
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push',
                     stderr='Failed to push branch to remote')) == shell.and_('git pull', 'git push')

# Generated at 2022-06-12 11:40:14.794978
# Unit test for function match
def test_match():
    assert match(Command('git push origin newbranch',
                         '! [rejected] newbranch -> newbranch (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:...\'\n'
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' '
                         'for details.',
                         ''))

# Generated at 2022-06-12 11:40:23.862736
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/user/repo.git\n\
! [rejected]        master -> master (non-fast-forward)\n\
error: failed to push some refs to \'https://github.com/user/repo.git\'\n\
hint: Updates were rejected because the tip of your current branch is behind\n\
hint: its remote counterpart. Merge the remote changes (e.g. \'git pull\')\n\
hint: before pushing again.\n\
hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:40:31.534499
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push", "")
    new_command = get_new_command(command)
    assert new_command == "git pull && git push"
    command = Command("git push origin master", "")
    new_command = get_new_command(command)
    assert new_command == "git pull && git push origin master"
    command = Command("git push origin a b c", "")
    new_command = get_new_command(command)
    assert new_command == "git pull && git push origin a b c"

# Generated at 2022-06-12 11:40:41.440314
# Unit test for function get_new_command

# Generated at 2022-06-12 11:40:44.645644
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(git.And('git push','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','')) == '&& git pull'

# Generated at 2022-06-12 11:40:53.361378
# Unit test for function get_new_command
def test_get_new_command():
    command_1 = Command('git push')
    assert get_new_command(command_1) == 'git pull && git push'

    command_2 = Command('git push origin master')
    assert get_new_command(command_2) == 'git pull origin master && git push origin master'

    command_3 = Command('git push origin develop')
    assert get_new_command(command_3) == 'git pull origin develop && git push origin develop'

    command_4 = Command('git push origin release/2.3.0')
    assert get_new_command(command_4) == 'git pull origin release/2.3.0 && git push origin release/2.3.0'

# Generated at 2022-06-12 11:41:02.199688
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '''To https://github.com/nvbn/thefuck.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))


# Generated at 2022-06-12 11:41:15.187060
# Unit test for function match
def test_match():
    # Unit test for case when output is incorrect
    assert not match(Command('vim', '', '! [rejected] master->master (non-fast-forward) error: failed to push some refs to \'https://github.com/pk-lega/EIC_tools.git\'', ''))
    # Unit test for case when output is correct

# Generated at 2022-06-12 11:41:16.475329
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull'

# Generated at 2022-06-12 11:41:27.191214
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]\n'
                         'error: failed to push some refs to \'git@github.com:nvbn/thefuck-unit-test.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))
    assert not match(Command('git push origin master', '', '', 1))
    assert not match(Command('git pull origin master', '', '', 1))

# Generated at 2022-06-12 11:41:29.047561
# Unit test for function match
def test_match():
    assert match(Command(script='git push',
                output='! [rejected]        master -> master (fetch first)'))


# Generated at 2022-06-12 11:41:37.147833
# Unit test for function match
def test_match():
    assert match(Command('git push origin master'
                         '', '! [rejected] master -> master (fetch first)', ''))
    assert match(Command('git push origin master'
                         '', 'Updates were rejected because the tip of your'
                         ' current branch is behind', ''))
    assert match(Command('git push origin master'
                         '', 'Updates were rejected because the remote '
                         'contains work that you do', ''))
    assert not match(Command('git push origin master'
                             '', '', ''))


# Generated at 2022-06-12 11:41:39.483455
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master')) == 'git pull'
    assert get_new_command(Command('git push -u origin master')) == 'git pull'

# Generated at 2022-06-12 11:41:49.947398
# Unit test for function match
def test_match():
    assert not match('git push')
    assert not match('git push origin master')
    assert match('git push origin master '
                 '! [rejected] master -> master (fetch first)'
                 'Updates were rejected because the remote contains work that you do '
                 'not have locally. This is usually caused by another repository pushing '
                 'to the same ref. You may want to first integrate the remote changes '
                 '(e.g., git pull ...) before pushing again.')
    assert match('git push origin master '
                 '! [rejected] master -> master (fetch first)'
                 'Updates were rejected because the tip of your current branch is behind '
                 'its remote counterpart. Integrate the remote changes (e.g. '
                 'git pull ...) before pushing again.')

# Generated at 2022-06-12 11:41:53.058564
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git push --force origin master',
                                          'failed to push some refs to git@github.com:test/test.git',
                                          '1'))
    assert new_command == "git pull && git push --force origin master"

# Generated at 2022-06-12 11:41:56.973445
# Unit test for function match
def test_match():
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin')

    assert not match('git pull origin master')
    assert not match('git push origin --tags')
    assert not match('git remote -v')
    assert not match('git push origin master -f')

# Generated at 2022-06-12 11:42:07.474859
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 
    '''To https://github.com/fasilm/thefuck.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/fasilm/thefuck.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''), 'git pull origin master')


# Generated at 2022-06-12 11:42:13.114446
# Unit test for function get_new_command
def test_get_new_command():
    new_script = ('git pull', 'git push')
    command = Command('git pull', '')
    assert get_new_command(command) == new_script

# Generated at 2022-06-12 11:42:22.154334
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\nupdates were rejected because the tip of your current branch is behind\nits remote counterpart. integrate the remote changes(e.g\nwith git pull ...) before pushing again'))
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\nupdates were rejected because the remote contains work that you do\nhave locally. this is usually caused by another repository pushing\nto the same ref. you may want to first integrate the remote changes\n(e.g. with ``git pull ...) before pushing again.'))
    assert not match(Command('git push', 'everything up-to-date'))
    assert not match(Command('git push', ''))

# Generated at 2022-06-12 11:42:24.168469
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push -f origin master', '', '')) == "git pull && git push -f origin master"

# Generated at 2022-06-12 11:42:34.755259
# Unit test for function match
def test_match():
    assert match(Command('git push', 'some_files'
                         ' ! [rejected]        master -> master '
                         '(non-fast-forward)'
                         'error: failed to push some refs to \'git@github.com:'
                         'some_stuff\''
                         'Updates were rejected because the tip of your '
                         'current branch is behind'))

    assert match(Command('git push', 'some_files'
                         ' ! [rejected]        master -> master '
                         '(non-fast-forward)'
                         'error: failed to push some refs to \'git@github.com:'
                         'some_stuff\''
                         'Updates were rejected because the remote contains '
                         'work that you do'))


# Generated at 2022-06-12 11:42:35.462804
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git pull' == get_new_command('git push')

# Generated at 2022-06-12 11:42:37.251407
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('push', None) == 'pull'
    assert get_new_command('git push origin master', None) == 'git pull'

# Generated at 2022-06-12 11:42:40.572113
# Unit test for function get_new_command

# Generated at 2022-06-12 11:42:45.410886
# Unit test for function get_new_command
def test_get_new_command():
    command_input = 'git push origin master'
    command_output = 'Updates were rejected because the tip of your current branch is behind'
    assert get_new_command(Command(command_input, command_output)) == 'git pull origin master && git push origin master'


enabled_by_default = True

# Generated at 2022-06-12 11:42:53.608643
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
            '! [rejected] master -> master (non-fast-forward)\n'
            'error: failed to push some refs to \'https://github.com/\''))
    assert match(Command('git push origin master',
            '! [rejected] master -> master (fetch first)\n'
            'error: failed to push some refs to \'https://github.com/\''))
    assert match(Command('git push origin master',
            '! [rejected] master -> master (non-fast-forward)\n'
            'error: failed to push some refs to \'https://github.com/\''))

# Generated at 2022-06-12 11:43:03.572854
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', ''))
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to \'git@***.***.***\''))
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@***.***.***\''))

# Generated at 2022-06-12 11:43:14.512197
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', ''))
    assert match(Command('git push origin master', 'To https://github.com/',
                         '! [rejected] master -> master '
                         '(non-fast-forward)\n'
                         'error: failed to push some refs to\n'
                         '\'https://github.com/\''))
    assert match(Command('git push origin master', '',
                         '! [rejected] master -> master '
                         '(fetch first)\n'
                         'error: failed to push some refs to\n'
                         '\'https://github.com/\''))

# Generated at 2022-06-12 11:43:23.763486
# Unit test for function match
def test_match():
    command = Command('git push origin master', '! [rejected]        master -> master (fetch first)\nUpdates were rejected because the tip of your current branch is behind\n  (use "git push" to publish your local commits)')
    assert match(command)

    command = Command('git push origin master', '! [rejected]        master -> master (fetch first)\nUpdates were rejected because the remote contains work that you do\n  (use "git push" to publish your local commits)')
    assert match(command)

    command = Command('git push origin master', '! [rejected]        master -> master (fetch first)\nUpdates were rejected because the tip of your current branch is behind\n  (use "git push" to publish your local commits)')
    assert match(command)


# Generated at 2022-06-12 11:43:33.297645
# Unit test for function match
def test_match():
    assert match(Command('git push 3', 'fatal: '
                '! [rejected]        master -> master (non-fast-forward)',
                '', 123))
    assert match(Command('git push',
                'To https://github.com/nvie/gitflow'
                '\n ! [rejected]        release/0.11.0 -> release/0.11.0 '
                '(non-fast-forward)'
                '\n error: failed to push some refs to '
                '\'https://github.com/nvie/gitflow\'', 123))

# Generated at 2022-06-12 11:43:42.586348
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (fetch first)\nfatal: failed to push some refs to \'git@github.com:tlhakhan/compiler-design.git\'\n'))
    assert match(Command('git push', '! [rejected]        master -> master (fetch first)\nfatal: failed to push some refs to \'git@github.com:tlhakhan/compiler-design.git\'\n'))
    assert not match(Command('git push', 'error: failed to push some refs to \'git@github.com:tlhakhan/compiler-design.git\''))


# Generated at 2022-06-12 11:43:52.628929
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'remote: Permission to se452-project/Homework.git '
                         'denied to liang-fanwu.\n'
                         'fatal: unable to access \'https://github.'
                         'com/se452-project/Homework/\': The requested '
                         'URL returned error: 403\n'))
    assert match(Command('git push origin  --set-upstream master',
                         ' ! [rejected]        master -> master (fetch '
                         'first)\nerror: failed to push some refs to '
                         '\'https://github.com/se452-project/Homework/\''))

# Generated at 2022-06-12 11:43:55.468855
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 0))
    assert not match(Command('git commit -m "test"', '', '', 0))
    assert not match(Command('git push origin master', '', '', 0))

# Generated at 2022-06-12 11:44:02.962222
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 'git pull origin master'))
    assert match(Command('git push origin master', 'git pull origin master'))

# Generated at 2022-06-12 11:44:06.675246
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
                                   '! [rejected] master -> master (non-fast-forward)\n'
                                   'error: failed to push some refs to \'https://github.com/AlDanial/cloc\'')) == 'git pull && git push'



# Generated at 2022-06-12 11:44:15.625398
# Unit test for function match
def test_match():
    assert match(Command('git push origin master:master',
                         'To git@github.com:nvbn/thefuck.git\n ! [rejected] '
                         'master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'git@github.com:nvbn/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of '
                         'your current branch is behind its remote counterpart. '
                         'Merge the remote changes (e.g. \'git pull\') '
                         'before pushing again.\nhint: See the \'Note about'
                         ' fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:44:25.432450
# Unit test for function match
def test_match():
    assert match(Command('git push master', '! [rejected]        master -> master (non-fast-forward)\n'
            'error: failed to push some refs to \'https://github.com/user/repo.git\'\n'
            'hint: Updates were rejected because the tip of your current branch is behind\n'
            'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
            'hint: \'git pull ...\') before pushing again.\n'
            'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
            '', 1, None))

# Generated at 2022-06-12 11:44:34.921638
# Unit test for function match
def test_match():
    assert match(Command('push', 'Updates were rejected because the tip of '
                         'your current branch is behind'))
    assert match(Command('push', 'Updates were rejected because the remote'
                         ' contains work that you do'))
    assert not match(Command('push', 'everything up-to-date'))
    assert not match(Command('push', 'Everything up-to-date'))
    assert not match(Command('push', 'Updates were rejected because the'
                            ' remote contains work that you do not have'))


# Generated at 2022-06-12 11:44:43.573281
# Unit test for function get_new_command
def test_get_new_command():
    def _git_support(command):
        command.script = 'git push -f'
        command.output = ('Updates were rejected because the tip of your '
                          'current branch is behind its remote counterpart.'
                          ' Integrate the remote changes (e.g.'
                          ' git pull ...) before pushing again. See the '
                          '\'Note about fast-forwards\' in \'git push --help\' '
                          'for details.')

    with patch('thefuck.specific.git.git_support', _git_support):
        assert get_new_command(Mock()) == 'git pull ; git push -f'

# Generated at 2022-06-12 11:44:51.069212
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]\n'+'failed to push some refs to'+
                         'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', '! [rejected]\n'+'failed to push some refs to'+
                         'Updates were rejected because the remote contains work that you do'))
    assert not match(Command('git push'))
    assert not match(Command('git push', '! [rejected]'))
    assert not match(Command('git push', '! [rejected]\n'+'failed to push'))



# Generated at 2022-06-12 11:44:54.721818
# Unit test for function get_new_command
def test_get_new_command():
    new_cmd = 'git pull'
    assert get_new_command(get_mock_command(new_cmd)) == new_cmd

# Generated at 2022-06-12 11:45:02.439345
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (fetch first)',
                         'error: failed to push some refs to '
                         "'git@github.com:<user>/<repo>'",
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind its remote',
                         'hint: counterpart. Integrate the remote changes '
                         '(e.g',
                         'hint: git pull ...) before pushing again.',
                         'hint: See the '
                         '\'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))

# Generated at 2022-06-12 11:45:03.714110
# Unit test for function get_new_command
def test_get_new_command():
    script = 'push'
    assert get_new_command(script) == 'pull'

# Generated at 2022-06-12 11:45:05.216392
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git pull ; git push' == get_new_command('git push')

# Generated at 2022-06-12 11:45:12.744757
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'git@github.com:ogom/dotfiles.git\'\n'
                         'To prevent you from losing history, non-fast-forward '
                         'updates were rejected\n'
                         'Merge the remote changes (e.g. \'git pull\') '
                         'before pushing again.  See the \'Note about\n'
                         'fast-forwards\' section of \'git push --help\' for details.\n',
                         '', 0))
    assert not match(Command('git log --no-color', '', '', 0))

# Generated at 2022-06-12 11:45:18.008733
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push my_branch',
                      '! [rejected]        my_branch -> my_branch (non-fast-forward)\n'
                      'Updates were rejected because the tip of your current branch is behind\n', 0)
    new_command = get_new_command(command)
    assert 'git pull --rebase && git push my_branch' == new_command

# Generated at 2022-06-12 11:45:28.398278
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '! [rejected] master -> master (non-fast-forward)\nTo git://github.com/nvie/gitflow\n   a11bef0..7b080e5  master     -> master\nUpdates were rejected because the tip of your current branch is behind\nUpdates were rejected because the tip of your current branch is behind\n'))
    assert not match(Command('git push origin master', 'To git://github.com/nvie/gitflow\n   a11bef0..7b080e5  master     -> master\n'))

# Generated at 2022-06-12 11:45:33.080155
# Unit test for function match
def test_match():
    assert match(Command('git push', 'fuck'))


# Generated at 2022-06-12 11:45:34.669267
# Unit test for function match
def test_match():
    assert match(Command('', ''))
    assert not match(Command('', ''))


# Generated at 2022-06-12 11:45:42.450659
# Unit test for function match

# Generated at 2022-06-12 11:45:52.321804
# Unit test for function match
def test_match():
    assert match(Command('git push',
                "! [rejected] master -> master (non-fast-forward)\n"
                "error: failed to push some refs to 'git@github.com:ogi-y/thefuck.git'\n"
                "hint: Updates were rejected because the tip of your current branch is behind\n"
                "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                "hint: 'git pull ...') before pushing again.\n"
                "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n",
                ""))

# Generated at 2022-06-12 11:46:00.759575
# Unit test for function match
def test_match():
    assert match(Command('git push',
        '''To https://github.com/brwngrldrn/cs188.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:brwngrldrn/cs188.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))


# Generated at 2022-06-12 11:46:10.818840
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                     'To https://github.com/user/repo.git\n ! [rejected] master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/user/repo.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                     '', 1, 'git push origin master'))

# Generated at 2022-06-12 11:46:19.468541
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
        '''To https://github.com/remote/repo.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:remote/repo.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-12 11:46:30.013795
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push',
                "Updates were rejected because the remote contains work that "
                "you do not have locally. This is usually caused by another "
                "repository pushing to the same ref. You may want to first "
                "integrate the remote changes (e.g., 'git pull ...') before "
                "pushing again.\nSee the 'Note about fast-forwards' in 'git "
                "push --help' for details.\n")) == (
        "git pull && git push")

# Generated at 2022-06-12 11:46:37.631704
# Unit test for function match
def test_match():
    assert match(Command("git push origin master", "! [rejected] master -> master (non-fast-forward) \n  \n  \n  error: failed to push some refs to 'git@github.com:YueYueZ/dotfiles-windows.git' \n  hint: Updates were rejected because the tip of your current branch is behind \n  hint: its remote counterpart. Integrate the remote changes (e.g. \n  hint: 'git pull ...') before pushing again.\n  hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n"))
    assert not match(Command("git push origin master", ""))

# Generated at 2022-06-12 11:46:46.426633
# Unit test for function match
def test_match():
    command1 = Command('git push origin branchname',
    'To https://github.com/...\n ! [rejected]        branchname -> branchname (non-fast-forward)\n error: failed to push some refs to \'https://github.com/...\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')

# Generated at 2022-06-12 11:46:53.144520
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '', 1, None))
    assert match(Command('git push origin master', '', '', 1, None))
    assert not match(Command('git pull origin master', '', '', 1, None))



# Generated at 2022-06-12 11:46:57.621567
# Unit test for function get_new_command

# Generated at 2022-06-12 11:47:02.115672
# Unit test for function get_new_command
def test_get_new_command():
    assert ('git pull' == get_new_command('git push').script)
    assert ('git pull' == get_new_command('git pull').script)
    assert ('git push' == get_new_command('git push -f').script)
    assert ('git push' == get_new_command('git pull -f').script)

# Generated at 2022-06-12 11:47:05.014497
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push origin master") == "git pull origin master && git push origin master"
    assert get_new_command("git push origin master:master") == "git pull origin master && git push origin master:master"

# Generated at 2022-06-12 11:47:06.739196
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull && git push'

# Generated at 2022-06-12 11:47:13.528379
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   '''1. ! [rejected]        master -> master (non-fast-forward)
    2. error: failed to push some refs to 'https://github.com/github.git'
    3. hint: Updates were rejected because the tip of your current branch is behind its remote
       4. hint: counterpart. Integrate the remote changes (e.g. hint: 'git pull ...') before pushing again.
       5. hint: See the 'Note about fast-forwards' in 'git push --help' for details.''')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-12 11:47:15.285728
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git push x', '', '', 0))
    assert new_command == 'git pull x'

# Generated at 2022-06-12 11:47:22.633632
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         """To https://github.com/thefuck/thefuck.git
 ! [rejected]                master -> master (fetch first)
error: failed to push some refs to 'https://github.com/thefuck/thefuck.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.""",
                         ''))


# Generated at 2022-06-12 11:47:24.035275
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git pull && git push' == get_new_command('git push')

# Generated at 2022-06-12 11:47:30.169168
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push origin master',
                '! [rejected]        master -> master (non-fast-forward)'
                '\nUpdates were rejected because the tip of your'
                ' current branch is behind\n'
                '\nTo push or pull them, you need to'
                ' run git fetch again.')) == 'git pull origin master && git push origin master'


# Generated at 2022-06-12 11:47:47.432701
# Unit test for function match
def test_match():
    match_out1 = ('[root@dxb-1-L-07 ~]# git push origin master\n'
                  'To /data/gitdev1/pms\n'
                  '! [rejected]        master -> master (non-fast-forward)\n'
                  'error: failed to push some refs to '
                  '/data/gitdev1/pms\n'
                  'hint: Updates were rejected because the tip of your '
                  'current branch is behind\n'
                  'hint: its remote counterpart. Integrate the remote '
                  'changes (e.g.\n'
                  'hint: \'git pull ...\') before pushing again.\n'
                  'hint: See the \'Note about fast-forwards\' in '
                  '\'git push --help\' for details.\n')
    match

# Generated at 2022-06-12 11:47:55.008556
# Unit test for function match
def test_match():
	cmd = Command('git push origin develop','','','')
	assert match(cmd) == True
	cmd = Command('git push origin develop','','Updates were rejected because the remote contains work that you do','fatal: Could not read from remote repository.\n\nPlease make sure you have the correct access rights\nand the repository exists.')
	assert match(cmd) == True
	cmd = Command('git push origin develop','','Updates were rejected because the tip of your current branch is behind','fatal: The remote end hung up unexpectedly')
	assert match(cmd) == True
	cmd = Command('git push origin develop','','Updates were rejected because the tip of your current branch is behind','fatal: The remote end hung up unexpectedly')
	assert match(cmd) == True

# Generated at 2022-06-12 11:48:03.319309
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push',
                                   output='! [rejected]\n'
                                          'Updates were rejected because the'
                                          ' remote contains work that you do '
                                          ' not have locally. This is usually'
                                          ' caused by another repository '
                                          ' pushing to the same ref. You may'
                                          ' want to first integrate the '
                                          'remote changes (e.g., ''git pull '
                                          '...'') before pushing again.'))

# Generated at 2022-06-12 11:48:10.585792
# Unit test for function match
def test_match():
    assert match(Command(script="git push origin master",
                         stderr="failed to push some refs to 'git@github.com:vader/deathstar.git'"))
    assert match(Command(script="git push origin master",
                         stderr="Updates were rejected because the remote contains work that you do"))
    assert match(Command(script="git push origin master",
                         stderr="Updates were rejected because the tip of your current branch is behind"))
    assert not match(Command(script="git push origin master",
                             stderr="Updates were rejected because the tip of current branch is behind"
                             "Updates were rejected because the remote contains work that you do"))

# Generated at 2022-06-12 11:48:20.221948
# Unit test for function match
def test_match():
    command = Command('git push',
                      'Total 0 (delta 0) error: failed to push some refs to '
                      '\'http://github.com/Foo.git\' hint: Updates were '
                      'rejected because the tip of your current branch '
                      'is behind hint: its remote counterpart. Integrate '
                      'the remote changes (e.g. hint: \'git pull ...\') '
                      'before pushing again hint: See the \'Note about '
                      'fast-forwards\' in \'git push --help\' for details.')
    assert match(command)

# Generated at 2022-06-12 11:48:28.959439
# Unit test for function match

# Generated at 2022-06-12 11:48:36.443472
# Unit test for function match
def test_match():
    assert match(Command('git push',
                   "To https://github.com/nvbn/thefuck\n ! [rejected]\
 dev -> dev (fetch first)\n error: failed to push some refs to \
'https://github.com/nvbn/thefuck'\n\
hint: Updates were rejected because the remote contains work that you do\
n't have locally. This is usually caused by another repository pushing\
to the same ref. You may want to first integrate the remote changes\
(e.g., 'git pull ...') before pushing again.\n\
hint: See the 'Note about fast-forwards' in 'git push --help' for details.\
", "git remote -v;git status;git push"))



# Generated at 2022-06-12 11:48:46.592245
# Unit test for function match

# Generated at 2022-06-12 11:48:48.379435
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '!'))
    assert not match(Command('git push origin master', '', ''))



# Generated at 2022-06-12 11:48:57.579065
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         stderr=('To https://github.com/nvbn/thefuck.git\n'
                             ' ! [rejected]        master -> master (non-fast-forward)\n'
                             'error: failed to push some refs to '
                             '\'https://github.com/nvbn/thefuck.git\'\n'
                             'hint: Updates were rejected because the tip of your current branch is behind\n'
                             'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                             'hint: \'git pull ...\') before pushing again.\n'
                             'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')))

# Generated at 2022-06-12 11:49:12.539174
# Unit test for function match
def test_match():
    assert match(Command('git push raj master', '', 'Error', 1))
    assert match(Command('git push raj master', '', '! [rejected]', 1))
    assert match(Command('git push raj master', '',
                         '! [rejected]        master -> master (non-fast-forward)', 1))
    assert match(Command('git push raj master', '', '', 0))
    assert not match(Command('git push raj --force', '', '', 1))
    assert not match(Command('git status', '', '', 1))
    assert not match(Command('git push', '', '', 1))
    assert not match(Command('', '', '', 1))


# Generated at 2022-06-12 11:49:22.240785
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (fetch first)',
                         'error: failed to push some refs to'))
    assert match(Command('git push origin master',
                         """! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'""",
                         ''))
    assert match(Command('git push origin branch',
                         """! [rejected]        branch -> branch (fetch first)
error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'""",
                         ''))

# Generated at 2022-06-12 11:49:30.478198
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@gitee.com:xxxxxx/xxxxx.git\'',
                         'git push origin master'))
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to \'git@gitee.com:xxxxxx/xxxxx.git\'',
                         'git push origin master'))

# Generated at 2022-06-12 11:49:38.402080
# Unit test for function match
def test_match():
    # Test 1
    command = "git push origin dev:dev"
    output  = ("To https://github.com/user/repo_name.git\n"
               " ! [rejected]        dev -> dev (non-fast-forward)\n"
               "error: failed to push some refs to 'https://github.com/user/repo_name.git'\n"
               "hint: Updates were rejected because the tip of your current branch is behind\n"
               "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
               "hint: 'git pull ...') before pushing again.\n"
               "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n")


# Generated at 2022-06-12 11:49:45.625097
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/django/django\''
                         '\nhint: Updates were rejected because the tip of your current branch'
                         ' is behind\nhint: its remote counterpart. Integrate the remote changes'
                         ' (e.g.\nhint:  \'git pull ...\') before pushing again.\nhint: See'
                         ' the \'Note about fast-forwards\' in \'git push --help\' for details.'))
