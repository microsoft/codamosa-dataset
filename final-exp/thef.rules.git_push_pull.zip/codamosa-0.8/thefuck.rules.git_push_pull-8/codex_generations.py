

# Generated at 2022-06-12 11:39:52.818988
# Unit test for function match

# Generated at 2022-06-12 11:39:55.319766
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]\nUpdates were rejected'
                         'because the tip of your current branch is behind',
                         ''))
    assert not match(Command('git push', '', ''))

# Generated at 2022-06-12 11:40:03.725818
# Unit test for function get_new_command
def test_get_new_command():
    command = namedtuple('Command', 'script output')('git push',\
    '! [rejected]        master -> master (fetch first)\n'
    'error: failed to push some refs to ...\n\n'
    'Updates were rejected because the remote contains work that you do\n'
    'not have locally. This is usually caused by another repository pushing\n'
    'to the same ref. You may want to first integrate the remote changes\n'
    '(e.g., \'git pull ...\') before pushing again.\n'
    'See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-12 11:40:05.105243
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull --rebase && git push origin master'

# Generated at 2022-06-12 11:40:08.479861
# Unit test for function match
def test_match():
    assert match(Command(script='git push', output='! [rejected] master -> master (fetch first)'))
    assert match(Command(script='git push', output='! [rejected] master -> master (non-fast-forward)'))
    assert not match(Command())

# Generated at 2022-06-12 11:40:15.933520
# Unit test for function match
def test_match():
    assert match(
        Command('git push origin master', "ERROR: Repository not found.\nfatal: Could not read from remote repository.\n\nPlease make sure you have the correct access rights\nand the repository exists."))
    assert not match(
        Command('git push origin master'))

# Generated at 2022-06-12 11:40:17.676159
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push origin master").script == \
           "git pull origin master && git push origin master"

# Generated at 2022-06-12 11:40:23.965794
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'error: failed to push some refs to\n'
                         '! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to\n'
                         'hint: Updates were rejected because the tip of your'
                         ' current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote'
                         ' changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.',
                         ''))


# Generated at 2022-06-12 11:40:34.866700
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'git@github.com:slackbot/thefuck.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1, 3))

# Generated at 2022-06-12 11:40:44.271396
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         " ! [rejected] master -> master (non-fast-forward)\n"
                         " error: failed to push some refs to 'git@example.com:repo.git'\n"
                         "To prevent you from losing history, non-fast-forward "
                         "updates were rejected\n"
                         "Merge the remote changes (e.g. 'git pull') before pushing again."
                         "See the 'Note about fast-forwards' section of 'git push --help' for details."))

# Generated at 2022-06-12 11:40:49.533497
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command("git push origin develop") == "git pull origin develop && git push origin develop")

# Generated at 2022-06-12 11:40:59.585973
# Unit test for function match
def test_match():
	assert match(Command('git push origin master',
						'error: failed to push some refs to \'https://github.com/pauloortins/consulta-email-por-arquivo.git\'\n'
						'hint: Updates were rejected because the tip of your current branch is behind\n'
						'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
						'hint: \'git pull ...\') before pushing again.\n'))

# Generated at 2022-06-12 11:41:02.458805
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', 'Updates were rejected because the tip of your'
                                  ' current branch is behind')
    new_command = get_new_command(command)
    assert new_command == shell.and_('git pull', 'git push')

# Generated at 2022-06-12 11:41:12.042768
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', "! [rejected]        master -> master (non-fast-forward)\n"
                      "error: failed to push some refs to 'git@github.com:USER/REPO.git'\n"
                      "hint: Updates were rejected because the tip of your current branch is behind\n"
                      "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                      "hint: 'git pull ...') before pushing again.\n"
                      "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n")
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-12 11:41:13.662429
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull && git push'


# Generated at 2022-06-12 11:41:19.464803
# Unit test for function match
def test_match():
    assert match(Command('git push', '', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', '', 'Updates were rejected because the remote contains work that you do'))
    assert match(Command('git push', '! [rejected]  master -> master (non-fast-forward)', ''))
    assert not match(Command('git pull', '', ''))

# Generated at 2022-06-12 11:41:21.864339
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '', '')) == 'git pull origin master'


# Generated at 2022-06-12 11:41:30.622073
# Unit test for function match

# Generated at 2022-06-12 11:41:33.330087
# Unit test for function match
def test_match():
    assert match(Command(script="git push origin master",
        output="\n ! [rejected]        master -> master (non-fast-forward)\n"))



# Generated at 2022-06-12 11:41:42.836875
# Unit test for function match
def test_match():
    assert match(Command("git push origin master", "! [rejected]        master -> master (fetch first)\n"
                                                  "error: failed to push some refs to 'git@github.com:MohamadKh75/test_repo.git'\n"
                                                  "hint: Updates were rejected because the remote contains work that you do\n"
                                                  "hint: not have locally. This is usually caused by another repository pushing\n"
                                                  "hint: to the same ref. You may want to first integrate the remote changes\n"
                                                  "hint: (e.g., 'git pull ...') before pushing again.\n"
                                                  "hint: See the 'Note about fast-forwards' in 'git push --help' for details.")) is True

# Generated at 2022-06-12 11:41:49.048704
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 0, '', ''))
    assert not match(Command('git push origin master', '', '', 0, '', ''))


# Generated at 2022-06-12 11:41:55.989978
# Unit test for function match
def test_match():
    command = Command(script='git push',
                      stderr=''' ! [rejected]        master -> master (fetch first)
error: failed to push some refs to ''',
                      stdout='''To https://github.com/user/repository.git
! [rejected]        master -> master (fetch first)
error: failed to push some refs to ''',
                      env={})
    assert match(command)

    command = Command(script='git push',
                      stderr='',
                      stdout='''To https://github.com/user/repository.git
! [rejected]        master -> master (fetch first)
error: failed to push some refs to ''',
                      env={})
    assert match(command) is None


# Generated at 2022-06-12 11:41:58.585217
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push") == "git pull && git push"
    assert get_new_command("git push origin master") == "git pull origin master && git push origin master"

# Generated at 2022-06-12 11:42:02.569274
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', '! [rejected]        master -\> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nfatal: The remote end hung up unexpectedly')
    assert (get_new_command(command) == 'git pull; git push origin master')

# Generated at 2022-06-12 11:42:03.832842
# Unit test for function match
def test_match():
	assert match(Command('git push'), None)


# Generated at 2022-06-12 11:42:06.660236
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(shell.and_('git push origin master',
                                      'git pull')) == 'git pull && git push origin master'

# Generated at 2022-06-12 11:42:13.809777
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '',
                         '! [rejected] <the local branch> -> master (non-fast-forward)',
                         'Updates were rejected because the tip of your current branch is behind its remote'))
    assert match(Command('git push origin master', '', '',
                         '! [rejected] <the local branch> -> master (non-fast-forward)',
                         'Updates were rejected because the remote contains work that you do'
                         'Not currently on any branch.'))
    assert not match(Command('git push origin master', '', '', '',
                             'Everything up-to-date'))

# Generated at 2022-06-12 11:42:17.561153
# Unit test for function get_new_command

# Generated at 2022-06-12 11:42:24.787922
# Unit test for function match

# Generated at 2022-06-12 11:42:35.304871
# Unit test for function match

# Generated at 2022-06-12 11:42:49.780041
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', "! [rejected]\
    master -> master (fetch first)\n error: failed to push some refs to 'git@github.com:usrname/thefuck.git'\
    Updates were rejected because the tip of your current branch is behind\
    its remote counterpart. Integrate the remote changes (e.g.\n hint: 'git pull ...') before pushing again.\
    See the 'Note about fast-forwards' in 'git push --help' for details.\n"))

# Generated at 2022-06-12 11:42:52.283765
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
        '')) == shell.and_('git pull', 'git push')

# Generated at 2022-06-12 11:43:02.579431
# Unit test for function match
def test_match():
    # check match
    assert match(Command(script = 'git push',
                         output = 'To git@github.com:nvbn/thefuck.git\n! [rejected]        master -> master (non-fast-forward) \nerror: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-12 11:43:05.100717
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push')) == 'git pull &&'

# Generated at 2022-06-12 11:43:13.534356
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to '
                         '\'git@github.com:helloworld/hello-world.git\'\n'
                         'Updates were rejected because the tip of '
                         'your current branch is behind its remote\n'
                         'counterpart. Integrate the remote changes '
                         '(e.g.\n\'git pull ...\') before pushing again.'))


# Generated at 2022-06-12 11:43:23.260457
# Unit test for function match
def test_match():
    list = [
        'Password for \'https://eileen0312@github.com\':',
        'To https://github.com/eileen0312/test.git',
        ' ! [rejected]        master -> master (non-fast-forward)',
        'error: failed to push some refs to \'https://github.com/eileen0312/test.git\'',
        'hint: Updates were rejected because the tip of your current branch is behind',
        'hint: its remote counterpart. Integrate the remote changes (e.g.',
        'hint: \'git pull ...\') before pushing again.',
        'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'
    ]
    assert match('\n'.join(list))

# Generated at 2022-06-12 11:43:32.928282
# Unit test for function match
def test_match():
    assert match(Command(script='git push origin master', output='! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'origin\'\n'
                         'Updates were rejected because the tip of your current branch is behind\n'
                         'its remote counterpart. Merge the remote changes (e.g. \'git pull\')\n'
                         'before pushing again.\n'
                         'See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:43:33.954490
# Unit test for function match
def test_match():
    assert match('git push origin master')


# Generated at 2022-06-12 11:43:43.369719
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push origin master", "! [rejected] master -> master (non-fast-forward)\n"
            "error: failed to push some refs to 'git@github.com:ogom/dotfiles.git'\n"
            "hint: Updates were rejected because the tip of your current branch is behind\n"
            "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
            "hint: 'git pull ...') before pushing again.\n"
            "hint: See the 'Note about fast-forwards' in 'git push --help' for details.")
    new_command = get_new_command(command)
    assert new_command == "git pull origin master && git push origin master"

# Generated at 2022-06-12 11:43:47.620259
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', ' ! [rejected] master -> master (non-fast-forward)',
                                   'Updates were rejected because the tip of your curre',
                                   'Updates were rejected because the tip of your curre')) == shell.and_('git pull', 'git push')

# Generated at 2022-06-12 11:43:56.696262
# Unit test for function match
def test_match():
    # Case 1: match
    assert match(Command("git push", "Updates were rejected because the \
remote contains work that you do \
not have locally. This is usually caused by another repository pushing \
to the same ref. You may want to first integrate the remote changes \
(e.g., 'git pull ...') before pushing again. \
See the 'Note about fast-forwards' in 'git push --help' for details.",
                        "", 0))

    # Case 2: no match
    assert not match(Command("git push", "", "", 0))

# Generated at 2022-06-12 11:44:03.426868
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:shiyanhui/test.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 0, '')) is True

# Generated at 2022-06-12 11:44:06.292961
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push')) == 'git pull; git push'
    assert get_new_command(Command(script='git push origin master')) == 'git pull origin master; git push origin master'

# Generated at 2022-06-12 11:44:15.348321
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git reset --hard' in get_new_command('git push origin master')
    assert 'git pull' in get_new_command('git push origin master')
    assert 'git push panda master' in get_new_command('git push panda master')
    assert 'git fetch' in get_new_command('git fetch origin master')
    assert 'git fetch' not in get_new_command('git push origin master')
    assert 'git pull' not in get_new_command('git fetch origin master')
    assert 'git reset --hard' not in get_new_command('git fetch origin master')
    assert 'git fetch panda master' in get_new_command('git fetch panda master')
    assert 'git reset --hard' not in get_new_command('git fetch panda master')
    assert 'git pull' not in get

# Generated at 2022-06-12 11:44:25.183436
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git push origin master'
    output = '! [rejected]        master -> master (non-fast-forward) ' \
             '\n error: failed to push some refs to ' \
             '\'https://github.com/user/repo.git\'\n' \
             'hint: Updates were rejected because the tip of your ' \
             'current branch is behind\n hint: its remote counterpart. ' \
             'Integrate the remote changes (e.g.\n hint: \'git pull ...\') ' \
             'before pushing again.\n hint: See the \'Note about ' \
             'fast-forwards\' in \'git push --help\' for details.'
    assert get_new_command(Command(script=script, output=output)) == \
           shell.and_('git pull origin master', script)



# Generated at 2022-06-12 11:44:29.700652
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '! [rejected] master -> master (fetch first)\n'
                                                  'error: failed to push some refs to \'https://github.com/adamzjk/fuck.git\'\n'
                                                  'hint: Updates were rejected because the remote contains work that you do\n'
                                                  'hint: not have locally. This is usually caused by another repository pushing\n'
                                                  'hint: to the same ref. You may want to first integrate the remote changes\n'
                                                  'hint: (e.g., \'git pull ...\') before pushing again.\n'
                                                  'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) is True


# Generated at 2022-06-12 11:44:35.824388
# Unit test for function match

# Generated at 2022-06-12 11:44:38.710353
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command('git push origin master')
    assert result == 'git pull && git push origin master'
    assert result == "git pull && git push origin master"

# Generated at 2022-06-12 11:44:41.167299
# Unit test for function match
def test_match():
    assert match(Command(script='git push'))
    assert not match(Command(script='git'))


# Generated at 2022-06-12 11:44:47.843883
# Unit test for function match
def test_match():
    assert not match(Command('', ''))
    assert not match(Command('push', ''))
    assert not match(Command('push', '! [rejected]'))
    assert not match(Command('push', '! [rejected] failed to push'))
    assert match(Command('push', '! [rejected] failed to push some refs to'))
    assert match(Command('push', '! [rejected] failed to push some refs '
                                 'to\nUpdates were rejected because the tip'
                                 ' of your\ncurrent branch is behind'))
    assert match(Command('push', '! [rejected] failed to push some refs '
                                 'to\nUpdates were rejected because the '
                                 'remote contains\nwork that you do'))
    # Match the case when only the first error message is present

# Generated at 2022-06-12 11:45:02.461405
# Unit test for function match
def test_match():
    assert not match(Command('git push', ''))
    assert not match(Command('git push', '', ''))
    assert not match(Command('git push', '', 'ERROR: failed to push some refs to'))
    assert not match(Command('git push', '', 'ERROR: failed to push some refs to'
                             '\n! [rejected]'))
    assert not match(Command('git push', '', 'ERROR: failed to push some refs to'
                             '\n! [rejected]\nUpdates were rejected because the '
                             'remote contains work that you do'))

# Generated at 2022-06-12 11:45:11.690975
# Unit test for function match
def test_match():
    # Testing with `git push`
    # Rejected because working tree is not clean
    assert (match(Command('git push',
                          '''! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@gitlab.com:joao/python.git'
Updates were rejected because the tip of your current branch is behind
its remote counterpart. Integrate the remote changes (e.g.
'git pull ...') before pushing again.
''')) == True)
    # Testing with `git push`
    # Rejected because remote contains work that you do not have locally

# Generated at 2022-06-12 11:45:20.027480
# Unit test for function match
def test_match():
    """
    Test for the function match from the module git_push
    """
    assert match(Command('git push', 'error: failed to push some refs to ... ' +
            'Updates were rejected because the tip of your current branch ' +
            'is behind'))
    assert match(Command('git push', 'error: failed to push some refs to ... ' +
            'Updates were rejected because the remote contains work that you do'))
    assert match(Command('git push origin master', 'error: failed to push some' +
            ' refs to ... Updates were rejected because the tip of your current' +
            ' branch is behind'))
    assert not match(Command('git status', ''))


# Generated at 2022-06-12 11:45:22.734533
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == \
    shell.and_(replace_argument('git push', 'push', 'pull'),
               'git push')

# Generated at 2022-06-12 11:45:24.154590
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('git push').script == 'git pull')

# Generated at 2022-06-12 11:45:26.042911
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git push && git push'

# Generated at 2022-06-12 11:45:32.994068
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', ''))
    assert not match(Command('git commit', ''))
    assert match(Command('git push origin master', '''Failed to push some refs to 'https://github.com/petalmd/petalmd.github.io.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))


# Generated at 2022-06-12 11:45:35.118448
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', '', '')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-12 11:45:38.638184
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 1, None))
    assert not match(Command('git status', '', '', 1, None))
    assert not match(Command('', '', '', 1, None))

# Generated at 2022-06-12 11:45:40.269369
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull && git push'

# Generated at 2022-06-12 11:46:03.003877
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:fuck\n',
                         ''))

# Generated at 2022-06-12 11:46:13.070239
# Unit test for function match
def test_match():
    assert not match(Command('push hello world', ''))
    assert not match(Command('git push hello world', ''))

    assert match(Command('git push origin master', '''To https://github.com/nvbn/thefuck.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''))


# Generated at 2022-06-12 11:46:20.657785
# Unit test for function match
def test_match():
    # assert match(Command('git push origin master', "! [rejected] master -> master (fetch first)\nUpdates were rejected because the remote contains work that you do not have locally.  This is usually caused by another repository pushing to the same ref.  You may want to first integrate the remote changes (e.g., 'git pull ...') before pushing again."))
    assert match(Command('git push origin master', "! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nits remote counterpart. Integrate the remote changes (e.g.\n'git pull ...') before pushing again.\nSee the 'Note about fast-forwards' in 'git push --help' for details."))
    assert not match(Command('git push origin master', "Everything up-to-date"))

# Generated at 2022-06-12 11:46:31.052013
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         output=' ! [rejected] master -> master (non-fast-forward)\n'
                                'error: failed to push some refs to \'git@server:project.git\'\n'
                                'To prevent you from losing history, non-fast-forward '
                                'updates were rejected\n'
                                'Merge the remote changes (e.g. \'git pull\') before pushing again. '
                                'See the \'Note about fast-forwards\' section of \'git push --help\' for details.'))

# Generated at 2022-06-12 11:46:36.633678
# Unit test for function get_new_command
def test_get_new_command():
    command = """git push""".split()
    output = """To https://github.com/test/test
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/test/test'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details."""

    assert get_new_command(FakeCommand(command, output)) == 'git pull; git push'


# Generated at 2022-06-12 11:46:45.541120
# Unit test for function match
def test_match():
    assert match(Command(script="git push",
                         stderr=["remote: error: insufficient permission for adding an object to repository database .",
                                 "remote: fatal: failed to write object"],
                         returncode=1))
    assert match(Command(script="git push",
                         stderr=["! [rejected]        development -> development (non-fast-forward)",
                                 "error: failed to push some refs to 'git@gitserver:rnd.git'",
                                 "hint: Updates were rejected because the tip of your current branch is behind",
                                 "hint: its remote counterpart. Integrate the remote changes (e.g",
                                 "hint: 'git pull ...') before pushing again."],
                         returncode=1))

# Generated at 2022-06-12 11:46:54.011826
# Unit test for function match
def test_match():
    assert match(Command('git branch',
            "error: failed to push some refs to 'git@git.example.com:foo/bar.git'\n"
            'hint: Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git branch',
            "error: failed to push some refs to 'git@git.example.com:foo/bar.git'\n"
            'hint: Updates were rejected because the remote contains work that you do'))
    assert not match(Command('git branch', '''
    error: failed to push some refs
    hint: Updates were rejected
    '''))
    assert not match(Command('git branch', '''
    error: failed
    hint: Updates were rejected
    '''))

# Generated at 2022-06-12 11:46:54.826379
# Unit test for function match
def test_match():
    assert match(Command("git push"))


# Generated at 2022-06-12 11:47:04.036866
# Unit test for function get_new_command
def test_get_new_command():
    _git_push_script = "git push"

# Generated at 2022-06-12 11:47:06.552247
# Unit test for function match
def test_match():
    assert match(Command('git push origin master','','','','','','','','','','','','','','','','','','','','','','','','','','',''))
    assert not match(Command('git commit -m'))


# Generated at 2022-06-12 11:47:50.394029
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/helloworldrwth/SocialNetwork-Search.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.', '', 1))

# Generated at 2022-06-12 11:47:59.386597
# Unit test for function match
def test_match():

    assert match(Command('git pull', '', '! [rejected] master -> master '
                                          '(fetch first)\n'
                                          'error: failed to push some refs to '
                                          '\'ssh://git@bitbucket.org/my/repo.git\'',
                         'ssh://git@bitbucket.org/my/repo'))
    assert match(Command('git remote update', '', 'Fetching origin\n'
                         '! [rejected]        master     -> origin/master  (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'ssh://git@bitbucket.org/my/repo.git\'',
                         'ssh://git@bitbucket.org/my/repo'))

# Generated at 2022-06-12 11:48:09.720143
# Unit test for function match
def test_match():
    func = match
    command1 = Command('git push origin master')
    assert func(command1) == False
    command2 = Command('git push origin master',
        'To git.example.com:user/repo\n ! [rejected]        master -> master\n(non-fast-forward) error: failed to push some refs to \'git.example.com:user/repo\' hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes (e.g. hint: \'git pull ...\') before pushing again. hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert func(command2) == True

# Generated at 2022-06-12 11:48:11.576359
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master')
    assert get_new_command(command) == 'git pull origin master && git push origin master'


enabled_by_default = True

# Generated at 2022-06-12 11:48:21.480105
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '',
                         'To https://github.com/nvbn/thefuck\n'
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         '\'https://github.com/nvbn/thefuck\'\n'
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))


# Generated at 2022-06-12 11:48:30.194362
# Unit test for function match
def test_match():
    # init
    command = Command('git push', '! [rejected] master -> master (fetch first)\n'
                                  'error: failed to push some refs to \'git@github.com:rfc2822/linux-scripts.git\'\n'
                                  'hint: Updates were rejected because the remote contains work that you do\n'
                                  'hint: not have locally. This is usually caused by another repository pushing\n'
                                  'hint: to the same ref. You may want to first integrate the remote changes\n'
                                  'hint: (e.g., \'git pull ...\') before pushing again.\n'
                                  'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')

    assert match(command)


# Generated at 2022-06-12 11:48:37.420111
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to \'git@github.com:shiyanhui/shiyanhui.github.io.git\'',
                         'hint: Updates were rejected because the tip of your current branch is behind',
                         'hint: its remote counterpart. Integrate the remote changes (e.g.',
                         'hint: \'git pull ...\') before pushing again.',
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-12 11:48:47.386890
# Unit test for function get_new_command
def test_get_new_command():
    output = ("! [rejected]        master -> master (fetch first)\n"
              "error: failed to push some refs to 'git@github.com:fuck.git'\n"
              "hint: Updates were rejected because the remote contains work that you do\n"
              "hint: not have locally. This is usually caused by another repository pushing\n"
              "hint: to the same ref. You may want to first integrate the remote changes\n"
              "hint: (e.g., 'git pull ...') before pushing again.\n"
              "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n")
    script = "git push origin master"
    new_command = get_new_command(Command(script, output))

# Generated at 2022-06-12 11:48:54.238402
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to \'git@example.com:proj.git\'',
                         'hint: Updates were rejected because the tip of your current branch is behind',
                         'hint: its remote counterpart. Integrate the remote changes (e.g.',
                         'hint: \'git pull ...\') before pushing again.\n',
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', '', ''))



# Generated at 2022-06-12 11:49:01.693390
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', ''))
    assert match(Command('git push', '', ''))
    assert match(Command('git push --foo bar', '', ''))
    assert match(Command('git pull', '', ''))
    assert match(Command('git pull --foo bar', '', ''))
    assert match(Command('git pull origin master', '', ''))
    assert not match(Command('git push origin master', '', '', '', True))
    assert not match(Command('git pull origin master', '', '', '', True))
