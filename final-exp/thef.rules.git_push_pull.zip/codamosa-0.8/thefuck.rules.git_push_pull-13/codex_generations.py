

# Generated at 2022-06-12 11:39:47.350228
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] blah blah blah', None)) \
    == 'git pull && git push'
    

# Generated at 2022-06-12 11:39:56.508086
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', ''))
    assert match(Command('git push origin master',
         'To https://github.com/sorenbouma/dotfiles.git\n'
         ' ! [rejected]        master -> master (non-fast-forward)\n'
         'error: failed to push some refs to '
         '\'https://github.com/sorenbouma/dotfiles.git\'\n'
         'hint: Updates were rejected because the tip of your current branch is behind\n'
         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
         'hint: \'git pull ...\') before pushing again.\n'
         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-12 11:39:58.549034
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git push origin master', 'Output'))
           == "git pull && git push origin master")

# Generated at 2022-06-12 11:40:00.040086
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command="git push").script == "git pull; git push"

# Generated at 2022-06-12 11:40:07.193441
# Unit test for function match
def test_match():
  assert match(Command(script="git push")) == False
  assert match(Command(script="git push", output="! [rejected]")) == False
  assert match(Command(script="git push", output="failed to push some refs to")) == False
  assert match(Command(script="git push", output="Updates were rejected because the tip of your current branch is behind")) == False
  assert match(Command(script="git push", output="Updates were rejected because the remote contains work that you do")) == False
  assert match(Command(script="git push", output="! [rejected]failed to push some refs toUpdates were rejected because the tip of your current branch is behind")) == True
  assert match(Command(script="git push", output="! [rejected]failed to push some refs toUpdates were rejected because the remote contains work that you do"))

# Generated at 2022-06-12 11:40:15.493537
# Unit test for function match
def test_match():
    assert match(Command('git push',
        'To https://github.com/nvie/gitflow.git\n ! [rejected]        release/0.4.0-tore-test -> release/0.4.0-tore-test (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nfatal: The remote end hung up unexpectedly\n',
        '', 1, False))

# Generated at 2022-06-12 11:40:17.262608
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('git push', '')
    assert get_new_command(cmd) == 'git pull && git push'

# Generated at 2022-06-12 11:40:23.898204
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git push origin master').script == 'git pull origin master && git push origin master')
    assert(get_new_command('git push origin master').stdout == None)
    assert(get_new_command('git push origin master').stderr == None)
    assert(get_new_command('git push origin master').script == 'git pull origin master && git push origin master')
    assert(get_new_command('git push origin master').stdout == None)
    assert(get_new_command('git push origin master').stderr == None)
    

# Generated at 2022-06-12 11:40:34.866348
# Unit test for function match

# Generated at 2022-06-12 11:40:42.994221
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To git@github.com:nvbn/thefuck\n'
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:nvbn/thefuck\'\n'
                         'To prevent you from losing history, non-fast-forward updates were rejected\n'
                         'Merge the remote changes (e.g. \'git pull\') before pushing again.  See the\n'
                         '\'Note about fast-forwards\' section of \'git push --help\' for details.'))

 # Unit test for function get_new_command

# Generated at 2022-06-12 11:40:48.801976
# Unit test for function match
def test_match():
    assert match(Command('git push', ''))
    assert match(Command('git push origin master', ''))
    assert not match(Command('git commit', ''))

# Generated at 2022-06-12 11:40:59.114622
# Unit test for function match

# Generated at 2022-06-12 11:41:04.783309
# Unit test for function match
def test_match():
    assert match(Command('git push', stderr='! [rejected]        master -> master (fetch first)\n'))
    assert match(Command('git push', stderr='! [rejected]        master -> master (non-fast-forward)\n'))
    assert match(Command('git push', stderr='Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', stderr='Updates were rejected because the remote contains work that you do'))
    assert not match(Command('git push', stderr='fatal: unable to access'))
    assert match(Command('git push', stderr='The following untracked working tree files would be overwritten by merge'))


# Generated at 2022-06-12 11:41:13.104562
# Unit test for function match
def test_match():
    match_output=u"""
    ! [rejected]        master -> master (non-fast-forward)
    error: failed to push some refs to 'git@git.assembla.com:bms-dev.git'
    hint: Updates were rejected because the tip of your current branch is behind
    hint: its remote counterpart. Integrate the remote changes (e.g.
    hint: 'git pull ...') before pushing again.
    hint: See the 'Note about fast-forwards' in 'git push --help' for details.
    """
    assert match(Command('git push', match_output))



# Generated at 2022-06-12 11:41:15.106159
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push origin master', '', 0, ''))
            == 'git pull origin master && git push origin master')

# Generated at 2022-06-12 11:41:24.358156
# Unit test for function match
def test_match():
    c = Command('git push origin master', '! [rejected]        master -> master (fetch first)\n error: failed to push some refs to \'git@github.com:gracebin/gracebin.github.io.git\'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert match(c) == True


# Generated at 2022-06-12 11:41:32.100574
# Unit test for function match

# Generated at 2022-06-12 11:41:36.288882
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', 'fatal: The remote end hung up unexpectedly')
    assert get_new_command(command) == shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-12 11:41:39.753819
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '', 1))
    assert match(Command('git push', '', '', 1))
    assert not match(Command('git push', '', '', 1))

if __name__ == '__main__':
    test_match()

# Generated at 2022-06-12 11:41:49.273197
# Unit test for function match
def test_match():
    assert match(Command(script='git push',
                         stdout='To https://github.com/nvbn/thefuck\n ! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to \'https://github.com/nvbn/thefuck\'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))



# Generated at 2022-06-12 11:41:55.265279
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(shell.Script('git push origin master', '', 0, None)) == shell.Script('git pull origin master', '', 0, None)

# Generated at 2022-06-12 11:42:01.008901
# Unit test for function match
def test_match():
    package_check.package_requirement_list([('git', 'git')])
    tests = ['git push ! [rejected]        master -> master (non-fast-forward)',
             'git push ! [rejected]        master -> master (non-fast-forward)'
             'Updates were rejected because the tip of your current branch is'
             ' behind',
             'git push ! [rejected]        master -> master (non-fast-forward)'
             'Updates were rejected because the remote contains work that you do'
             ' not have locally.']

    for test in tests:
        assert match.match(Command(script=test))


# Generated at 2022-06-12 11:42:11.497316
# Unit test for function match
def test_match():
    res_script = 'git push -u origin master'
    res_output= '''To https://github.com/TseTseFly/git-auto-correct.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/TseTseFly/git-auto-correct.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''

# Generated at 2022-06-12 11:42:16.831308
# Unit test for function match
def test_match():
    assert match(Command('git push -f', 'error: failed to push some refs'))
    assert match(Command('git push -f', 'error: failed to push some refs'))
    assert not match(Command('git push', 'error: failed to push some refs'
                             'to'))

# Unit Test for function get_new_command

# Generated at 2022-06-12 11:42:20.937678
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '! [rejected]        master -> master (non-fast-forward)', ''))
    assert match(Command('git push origin master', '! [rejected]        master -> master (non-fast-forward)', ''))
    assert not match(Command('git push origin master', '! [rejected]', ''))

# Generated at 2022-06-12 11:42:26.757753
# Unit test for function match
def test_match():
	assert match(Command('git push live master', 'error: failed to push some refs to \'git@bitbucket.org:companyname/project-repo-name.git\'')) == True
	assert match(Command('git push live master', 'Updates were rejected because the remote contains work that you do')) == True
	assert match(Command('git pull', 'Already up-to-date')) == False

# Generated at 2022-06-12 11:42:29.789385
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', '', '', ''))
    assert match(Command('git push --set-upstream origin master', '', '', '', '', ''))
    assert match(Command('git push origin master', '', '', '', '', ''))
    assert match(Command('git push --set-upstream origin master', '', '', '', '', ''))


# Generated at 2022-06-12 11:42:38.772704
# Unit test for function match

# Generated at 2022-06-12 11:42:46.107848
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git push origin master',
                                    stderr='! [rejected]        master -> master (non-fast-forward)'))
    assert new_command == 'git pull && git push origin master'
    new_command = get_new_command(Command('git push origin master',
                                    stderr='! [rejected]        master -> master (fetch first)'))
    assert new_command == 'git pull && git push origin master'

priority = 1000

# Generated at 2022-06-12 11:42:52.291209
# Unit test for function match
def test_match():
    """
    Function expects that the output contains the strings
    "! [rejected]" and "Updates were rejected because the remote
    contains work that you do" and "failed to push some refs to"
    """
    assert match(Command('git push origin master',
                         '! [rejected]\n'
                         'Updates were rejected because the remote '
                         'contains work that you do\n'
                         'failed to push some refs to'))
    assert not match(Command('git push origin master', ''))



# Generated at 2022-06-12 11:42:57.980929
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add .', '', '', 0, '')).script == 'git pull && git push'


# Generated at 2022-06-12 11:43:03.821586
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '! [rejected]        master -> master (fetch first)\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.', 'git')
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-12 11:43:12.083235
# Unit test for function get_new_command
def test_get_new_command():
    assert ('git pull && git push -u'
            in get_new_command(
                Command('git push -u', '', "Everything up-to-date")
                ))
    assert ('git pull && git push'
            in get_new_command(
                Command('git push', '', "Everything up-to-date")
                ))
    assert ('git pull && git push'
            in get_new_command(
                Command('git push', '', "Everything up-to-date")
                ))
    assert ('git pull && git push -u'
            in get_new_command(
                Command('git push -u', '', "Everything up-to-date")
                ))

# Generated at 2022-06-12 11:43:17.546546
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = 'git push',
                                   output = "Updates were rejected because the tip of your current branch is behind"
                                            "its remote counterpart. Integrate the remote changes (e.g.\n"
                                            "'git pull ...') before pushing again.\n"
                                            "See the 'Note about fast-forwards' in 'git push --help' for details.")) == 'git pull && git push'

# Generated at 2022-06-12 11:43:26.914077
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         output='Everything up-to-date\n'))

# Generated at 2022-06-12 11:43:29.319388
# Unit test for function match
def test_match():
    assert match(Command(script='git push origin master',
                         stderr='! [rejected]        master -> master (fetch first)'))



# Generated at 2022-06-12 11:43:32.188783
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push',
                                    output='Updates were rejected because the tip of your current branch is behind',
                                    stderr='error')) == 'git pull && git push'

# Generated at 2022-06-12 11:43:42.971443
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         " ! [rejected]        master -> master (fetch first)\n"
                        "error: failed to push some refs to 'git@github.com:lugia/lugia-web.git'\n"
                        "hint: Updates were rejected because the remote contains work that you do\n"
                        "hint: not have locally. This is usually caused by another repository pushing\n"
                        "hint: to the same ref. You may want to first integrate the remote changes\n"
                        "hint: (e.g., 'git pull ...') before pushing again.\n"
                        "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n"))

# Generated at 2022-06-12 11:43:52.659417
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         output='To https://github.com/nvbn/tests.git ! [rejected]    master -> master (fetch first) error: failed to push some refs to \'https://github.com/nvbn/tests.git\' Updates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g., \'git pull ...\') before pushing again.'))

# Generated at 2022-06-12 11:43:59.645524
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:agermanidis/dotfiles.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.'))

# Generated at 2022-06-12 11:44:05.243579
# Unit test for function get_new_command
def test_get_new_command():
  assert get_new_command(Command('git push', '', '')) == Command('git pull', '', '')


# Generated at 2022-06-12 11:44:07.752123
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', False))
    assert not match(Command('git push origin master', '', True))
    assert not match(Command('git add .', '', False))



# Generated at 2022-06-12 11:44:16.290074
# Unit test for function get_new_command
def test_get_new_command():
    # Valid test case
    assert get_new_command(Command(script='git push',
                                   output=('To https://github.com/andreypopp/npm-check-updates.git\n ! [rejected]\n error: failed to push some refs to \'https://github.com/andreypopp/npm-check-updates.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))) == 'git pull && git push'
    # Invalid test case

# Generated at 2022-06-12 11:44:18.299935
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git pull', '')) == 'git pull && git pull'


enabled_by_default = True

# Generated at 2022-06-12 11:44:23.237131
# Unit test for function match
def test_match():
    command = Command('git commit -m "2"', '', '', 0, '', '')
    assert match(command)
    command = Command('git push -f', '', '', 0, '', '')
    assert not match(command)
    command = Command('git push', '', '', 0, '', '')
    assert not match(command)


# Generated at 2022-06-12 11:44:24.537927
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'

# Generated at 2022-06-12 11:44:34.086944
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '', '! [rejected] master -> master (fetch first)\n'
    'error: failed to push some refs to \'git@github.com:henrik/git-it-electron.git\'\n'
    'hint: Updates were rejected because the remote contains work that you do\n'
    'hint: not have locally. This is usually caused by another repository pushing\n'
    'hint: to the same ref. You may want to first integrate the remote changes\n'
    'hint: (e.g., \'git pull ...\') before pushing again.\n'
    'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-12 11:44:44.848163
# Unit test for function match
def test_match():
    assert match(Command('git push', 'error_msg'))
    assert not match(Command('git push', '! [rejected]'))
    assert not match(Command('git push', '! [rejected] failed to push some'
                             'refs to \'https://github.com/kennethreitz/requests.git\''))
    assert not match(Command('git push', '! [rejected] failed to push some'
                              'refs to \'https://github.com/kennethreitz/requests.git\''
                              '\n(non-fast-forward)\n\n'
                              'To prevent you from losing history, non-fast-forward'
                              'updates were rejected\nMerge the remote changes before'
                              'pushing again.'))

# Generated at 2022-06-12 11:44:47.266498
# Unit test for function get_new_command

# Generated at 2022-06-12 11:44:55.329048
# Unit test for function match
def test_match():
	# Check if a string will match the match function
    assert match(Command('git push', '! [rejected]        master -> master (fetch first)\n'
                                      'error: failed to push some refs to \'git@github.com:rackerlabs/docs-cloud-monitoring.git\'\n'
                                      'hint: Updates were rejected because the remote contains work that you do\n'
                                      'hint: not have locally. This is usually caused by another repository pushing\n'
                                      'hint: to the same ref. You may want to first integrate the remote changes\n'
                                      'hint: (e.g., \'git pull ...\') before pushing again.\n'
                                      'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))


# Generated at 2022-06-12 11:45:06.553642
# Unit test for function match

# Generated at 2022-06-12 11:45:13.512652
# Unit test for function match
def test_match():
	assert(match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'
		'Updates were rejected because the tip of your current branch is behind\n'
		'its remote counterpart. Integrate the remote changes (e.g.\n'
		'"git pull ...") before pushing again.', '', 1)) == True)

# Generated at 2022-06-12 11:45:15.738565
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push')
    assert get_new_command(command) == shell.and_('git pull', 'git push')

# Generated at 2022-06-12 11:45:17.799114
# Unit test for function get_new_command
def test_get_new_command():
  script = 'git push'
  assert get_new_command({'script': script}) == shell.and_(script.replace('push', 'pull'), script)

# Generated at 2022-06-12 11:45:25.480661
# Unit test for function match
def test_match():
    git_push_failed_command = Command("sudo git push", "! [rejected]        master -> master (fetch first)\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.")
    assert match(git_push_failed_command) == True




# Generated at 2022-06-12 11:45:27.136506
# Unit test for function get_new_command
def test_get_new_command():
    assert("git pull" == get_new_command("git push"))

# Generated at 2022-06-12 11:45:34.355423
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]\n'
                         ' error: failed to push some refs to'
                         ' \'https://github.com/user/repo.git\''
                         '\n hint: Updates were rejected because'
                         ' the tip of your current branch is'
                         ' behind\n hint: its remote counterpart.'
                         ' Integrate the remote changes before, hint: pushing'
                         ' again.\n hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))


# Generated at 2022-06-12 11:45:42.435223
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the tip of your current branch is behind\nUpdates were rejected because the remote contains work that you do not have locally.\nThis is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g.,\n\'git pull ...\') before pushing again.'))
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do not have locally.\nThis is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g.,\n\'git pull ...\') before pushing again.'))

# Generated at 2022-06-12 11:45:47.412347
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', 'fatal: The current branch master has no upstream branch.\nTo push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n\n')
    assert 'git pull origin master' == get_new_command(command)


enabled_by_default = True

# Generated at 2022-06-12 11:45:54.962508
# Unit test for function match
def test_match():
    # Sanity check for True
    command = Command('git push origin master',
                      'To https://github.com/nvbn/thefuck.git\n ! [rejected] master -> master (fetch first)\n error: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert match(command) is True
    # Sanity check for False

# Generated at 2022-06-12 11:46:08.067282
# Unit test for function match
def test_match():
    assert match(Command('git push',
            output='! [rejected]  master -> master (fetch first)'))
    assert match(Command('git push',
            output='remote: Resolving deltas: 100% (4/4), completed with 4 '
            'local objects.\n! [rejected]        master -> master (non-fast-forward)'))
    assert match(Command('git push',
            output='! [rejected]        master -> master (non-fast-forward)'))
    assert match(Command('git push',
            output='To ssh://git.local\n! [rejected]        master -> master (non-fast-forward)'))

# Generated at 2022-06-12 11:46:17.186938
# Unit test for function match
def test_match():
    assert match(Command('git push 2>&1', '\nUpdates were rejected because the'
            ' remote contains work that you do\n'))
    assert match(Command('git push 2>&1', '\nUpdates were rejected because the'
            ' tip of your current branch is behind\n'))
    assert not match(Command('git push 2>&1', '\nUsages: git push [option] ....\n'))
    assert not match(Command('git pull 2>&1', '\nFrom ...\n'))
    assert not match(Command('git fetch 2>&1', '\nFrom ....\n'))
    assert not match(Command('git push 2>&1', '\nEverything up-to-date\n'))

# Generated at 2022-06-12 11:46:19.070946
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '')) == shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-12 11:46:21.756237
# Unit test for function get_new_command
def test_get_new_command():
    # call get_new_command()
    command_new = get_new_command('')
    # Check if the output is correct
    assert command_new == shell.and_('git pull', '')

# Generated at 2022-06-12 11:46:24.362122
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull && git push'

# Generated at 2022-06-12 11:46:31.198189
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git push'
    output = '! [rejected] master -> master (non-fast-forward)\n\
        error: failed to push some refs to \'https://github.com/kamalbend/thefuck.git\''
    assert get_new_command(Command(command, output)) == shell.and_('git pull', 'git push')

    command = 'git push'
    output = 'Updates were rejected because the tip of your current branch is behind'
    assert get_new_command(Command(command, output)) == shell.and_('git pull', 'git push')

# Generated at 2022-06-12 11:46:37.030998
# Unit test for function match
def test_match():
    command = Command('git push origin master', '! [rejected] master -> master (fetch first)\n\
    error: failed to push some refs to \'git@github.com:user/repo.git\'\n\
    hint: Updates were rejected because the remote contains work that you do\n\
    hint: not have locally. This is usually caused by another repository pushing\n\
    hint: to the same ref. You may want to first integrate the remote changes\n\
    hint: (e.g., \'git pull ...\') before pushing again.\n\
    hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert match(command) == True


# Generated at 2022-06-12 11:46:37.731905
# Unit test for function match
def test_match():
    assert match(Command("git push"))

# Generated at 2022-06-12 11:46:42.391893
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', '')) ==
            'git pull && git push')
    assert (get_new_command(Command('git push origin master', '')) ==
            'git pull && git push origin master')
    assert (get_new_command(Command('git push -f', '')) ==
            'git pull && git push -f')

# Generated at 2022-06-12 11:46:49.451896
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   'Updates were rejected because the tip of your'
                                   ' current branch is behind its remote counterpart.'
                                   ' Integrate the remote changes (e.g.'
                                   ' git pull ...) before pushing again.'
                                   'See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-12 11:47:02.154990
# Unit test for function match
def test_match():
    commander = Command('git push', 'git push\n! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to \'confused.com\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.')
    assert match(commander)
    

# Generated at 2022-06-12 11:47:08.886684
# Unit test for function match
def test_match():
    assert match(Command('git push', 'ERROR: failed to push some refs to\
    \'https://github.com/murthy10/ViperAPI.git\'' ))
    assert not match(Command('git push', 'Something else'))

# Generated at 2022-06-12 11:47:12.089760
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', '', ''))
    assert not match(Command('git push origin master', '', '', '', ''))
    assert not match(Command('git pull origin master', '', '', '', ''))


# Generated at 2022-06-12 11:47:13.807256
# Unit test for function match
def test_match():
    assert match('git push origin master')
    assert not match('git push')
    assert not match('git add')
    assert not match('git commit')

# Generated at 2022-06-12 11:47:22.113438
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
        'To http://github.com/user/repo.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'http://github.com/user/repo.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:47:26.394513
# Unit test for function get_new_command
def test_get_new_command():
    actual = get_new_command(Command('git push', 'Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.hint: git pull ...) before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))
    assert actual == ' && git pull'

# Generated at 2022-06-12 11:47:35.580159
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:fuck.git\'',
                         ''))
    assert match(Command('git push',
                         'To git@github.com:fuck.git\n'
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:fuck.git\'',
                         ''))

# Generated at 2022-06-12 11:47:42.777425
# Unit test for function match
def test_match():
   cmd = Command(script='git push heroku master')
   assert not match(cmd)
   cmd = Command(script='git push origin develop',
                 output='''To https://github.com/user/project.git
  ! [rejected]        develop -> develop (non-fast-forward)
  error: failed to push some refs to 'https://github.com/user/project.git'
  hint: Updates were rejected because the tip of your current branch is behind
  hint: its remote counterpart. Integrate the remote changes (e.g.
  hint: 'git pull ...') before pushing again.
  hint: See the 'Note about fast-forwards' in 'git push --help' for details.''')
   assert match(cmd)

# Generated at 2022-06-12 11:47:52.243859
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         output='! [rejected]        master -> master (fetch first) \n'
                                'error: failed to push some refs to \'git@github.com:AgileVentures/WebsiteOne.git\'\n'
                                'To prevent you from losing history, non-fast-forward updates were rejected\n'
                                'Merge the remote changes (e.g. \'git pull\') before pushing again.  See the\n'
                                '\'Note about fast-forwards\' section of \'git push --help\' for details.'))

# Generated at 2022-06-12 11:48:03.225954
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:mc1arke/dotfiles.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-12 11:48:19.775781
# Unit test for function match
def test_match():
    command = Command('git push origin master', '\n! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/<username>/example_repo.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')
    assert match(command)

# Generated at 2022-06-12 11:48:27.941519
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master','''
To https://github.com/pooja/computer-science-and-engineering.git
! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/pooja/computer-science-and-engineering.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''')) == shell.and_('git pull origin master', 'git push origin master')


# Generated at 2022-06-12 11:48:34.594051
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', 'Updates were rejected because the tip of your current branch is behind\n'))
            == 'git pull && git push')
    assert (get_new_command(Command('git push', 'Updates were rejected because the remote\n'
                                               'contains work that you do not have locally. This is usually caused by\n'
                                               'another repository pushing to the same ref. You may want to first integrate\n'
                                               'the remote changes before pushing again.'))
            == 'git pull && git push')

# Generated at 2022-06-12 11:48:44.818039
# Unit test for function match
def test_match():
    assert match(Command('git push', '',
                         'To https://github.com/nvbn/thefuck.git\n'
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         "'https://github.com/nvbn/thefuck.git'\n"
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\n'
                         'hint: `git pull ...`) before pushing again.\n'
                         'hint: See the '
                         '`Note about fast-forwards` in '
                         '\'git push --help\' for details.', 1))

# Generated at 2022-06-12 11:48:49.360267
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', '', '', '! [rejected] master -> master (non-fast-forward)', 1)) == 'git pull')
    assert (get_new_command(Command('git push', '', '', '! [rejected] master -> master (non-fast-forward)', 1)) != 'git push')
    assert (get_new_command(Command('git push', '', '', '! [rejected] master -> master (non-fast-forward)', 1)) != 'git fetch')

# Generated at 2022-06-12 11:48:58.845036
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '/home/user/fake_repository\n! [rejected] '
                         'master -> master (fetch first)\n'
                         'error: failed to push some refs to '
                         "'git@gitlab.com:user/fake_repository.git'\n"
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.\n',
                         'git push', '', None)) == True

# Generated at 2022-06-12 11:49:00.225273
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '', '', ''))


# Generated at 2022-06-12 11:49:03.433288
# Unit test for function get_new_command
def test_get_new_command():
    assert('git fetch && git pull' in get_new_command('git push'))
    assert('git fetch && git pull --global' in get_new_command('git push --global'))
    assert('git fetch && git pull --force' in get_new_command('git push --force'))

# Generated at 2022-06-12 11:49:10.752902
# Unit test for function match

# Generated at 2022-06-12 11:49:19.749809
# Unit test for function match
def test_match():
    assert (match(Command(script = 'git push',
                         output = '! [rejected]        master -> master (non-fast-forward)\n'
                                                    'error: failed to push some refs to \'https://github.com/bethanydong/Labyrinth_Python.git\''
                                                    '\n'
                                                    'hint: Updates were rejected because the tip of your current branch is behind\n'
                                                    'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                                    'hint: \'git pull ...\') before pushing again.\n'
                                                    'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'
                         ))) == True

# Generated at 2022-06-12 11:49:45.776363
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master '
                         '(non-fast-forward)\n'
                         'error: failed to push some refs to ...',
                         'git push origin master ...'))
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master '
                         '(non-fast-forward)\n'
                         'error: failed to push some refs to ...',
                         'git push origin master --force'))
