

# Generated at 2022-06-26 06:07:41.261832
# Unit test for function match
def test_match():
    var_0 = 'git push'
    var_1 = ' ! [rejected]        master -> master (non-fast-forward) error: failed to push some refs to \'https://github.com/psf/requests.git\' hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes (e.g. hint: \'git pull ...\') before pushing again. hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'

    command = Command(script=var_0,output=var_1)
    var_2 = match(command)
    assert var_2 == False

    var_0 = 'git push'

# Generated at 2022-06-26 06:07:43.163244
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = get_new_command()
    print(var_0)


# Generated at 2022-06-26 06:07:46.314388
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = 'echo "Ahoj"'
    var_1 = 'Ahoj'
    var_2 = get_new_command(var_0, var_1)
    print(var_2)



# Generated at 2022-06-26 06:07:57.807728
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected] master -> master (fetch first)\n'
    'error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n'
    'hint: Updates were rejected because the remote contains work that you do\n'
    'hint: not have locally. This is usually caused by another repository pushing\n'
    'hint: to the same ref. You may want to first integrate the remote changes\n'
    'hint: (e.g., \'git pull ...\') before pushing again.\n'
    'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'), None)

# Generated at 2022-06-26 06:08:05.761576
# Unit test for function match
def test_match():
    assert match(Command('git push', '''To https://github.com/nvbn/thefuck.git
 ! [rejected]            master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''
                                 ))



# Generated at 2022-06-26 06:08:07.739250
# Unit test for function get_new_command
def test_get_new_command():
    int_0 = -3454
    var_0 = get_new_command(int_0)
    print("Unit test for function get_new_command")
    print("The output is " + str(var_0))

# output if input is int

# Generated at 2022-06-26 06:08:09.992348
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git push origin master'
    output = ''' ! [rejected]        master -> master (non-fast-forward)
'''
    assert get_new_command(command, output) == 'git pull && git push origin master'

# Generated at 2022-06-26 06:08:10.798892
# Unit test for function get_new_command
def test_get_new_command():
    pass

# Generated at 2022-06-26 06:08:13.769376
# Unit test for function get_new_command
def test_get_new_command():
    print("\n\n Running test case 0")
    int_0 = -3454
    var_0 = get_new_command(int_0)


# Generated at 2022-06-26 06:08:17.276296
# Unit test for function match
def test_match():
    int_0 = -3454
    var_0 = match(int_0)
    assert var_0 == (False, -845)



# Generated at 2022-06-26 06:08:27.342981
# Unit test for function match
def test_match():
    assert match(Command('git push -u origin master',
                         'To https://github.com/nvbn/thefuck.git\n ! [rejected]  master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n', '', 1))

# Generated at 2022-06-26 06:08:34.206012
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected] \tmaster -> master (fetch first)\n',
                         '',
                         125))
    assert match(Command('git push origin master',
                         ' ! [rejected] \tmaster -> master (non-fast-forward)\n',
                         '',
                         125))
    assert not match(Command('git push origin master',
                              '  \tmaster -> master (non-fast-forward)\n',
                              '',
                              125))



# Generated at 2022-06-26 06:08:44.945492
# Unit test for function match
def test_match():
    assert git.match(Command('git push origin master',
                             "! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n"))
    assert not git.match(Command('git push origin master',
                                 "! [rejected]        maste -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n"))
    assert git.match(Command('git push origin master',
                             "! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the remote contains work that you do\n"))

# Generated at 2022-06-26 06:08:54.522758
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
        'To https://github.com/nvbn'
        '/theshell-zsh.git\n ! [rejected]        master -> master'
        ' (non-fast-forward)\nerror: failed to push some refs to'
        ' \'https://github.com/nvbn/theshell-zsh.git\'\n'
        'hint: Updates were rejected because the tip of your current'
        ' branch is behind\nhint: its remote counterpart. Integrate'
        ' the remote changes (e.g.\nhint: \'git pull ...\')'
        ' before pushing again.\nhint: See the \'Note about fast-forwards\' in '
        '\'git push --help\' for details.\n')) == True


# Generated at 2022-06-26 06:08:59.727696
# Unit test for function match
def test_match():
    assert match(Command(script='git push', output='! [rejected]        master -> master (non-fast-forward)'))
    assert not match(Command(script='git push', output='Everything up-to-date'))
    assert not match(Command(script='git pull', output='Everything up-to-date'))


# Generated at 2022-06-26 06:09:01.813814
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('git push')) == 'git pull && git push'

# Generated at 2022-06-26 06:09:13.605979
# Unit test for function match

# Generated at 2022-06-26 06:09:24.513359
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:user/repo.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
                         ''))

# Generated at 2022-06-26 06:09:29.417530
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git pull && git push' in get_new_command(Command('git push', ''))
    assert 'git pull && git push origin master' in get_new_command(Command('git push origin master', ''))


# Generated at 2022-06-26 06:09:32.025499
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '', '', '', '')) == 'git pull && git push'

# Generated at 2022-06-26 06:09:44.924321
# Unit test for function match
def test_match():
    assert not match(Command(script='git log',
                             output='fatal: Not a git repository (or any of the parent directories): .git'))
    assert match(Command(script='git push',
                         output='To https://github.com/nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-26 06:09:55.879763
# Unit test for function match

# Generated at 2022-06-26 06:10:06.302483
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         "To https://github.com/nvbn/thefuck.git\n! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: 'git pull ...') before pushing again.\n hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n"))

# Generated at 2022-06-26 06:10:14.305327
# Unit test for function match
def test_match():
    assert match(Command(script='git remote add origin git@github.com:nvbn/thefuck.git',
                         output='fatal: remote origin already exists.'))
    assert match(Command(script='git add file123 file345',
                         output='error: invalid path \'file345\''))
    assert match(Command(script='git commit',
                         output="fatal: your current branch 'master' does not have any commits yet"))
    assert not match(Command(script='git status',
                             output='On branch master'))



# Generated at 2022-06-26 06:10:19.914875
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', 'Updates were rejected because the tip of '
                      'your current branch is behind its remote counterpart. '
                      'Integrate the remote changes before pushing again.')
    new_command = get_new_command(command)
    assert new_command == 'git pull && git push'


# Generated at 2022-06-26 06:10:25.792753
# Unit test for function match
def test_match():
    def execute_match(script, output):
        return match(Command(script, output))

    assert execute_match('git push', 'error: failed to push some refs to')
    assert execute_match('git push', 'Updates were rejected because the tip of '
                         'your current branch is behind its remote'
                         ' counterpart. Merge the remote changes (e.g. '
                         '\'git pull\') before pushing again.')
    assert execute_match('git push', 'Updates were rejected because the remote '
                         'contains work that you do not have locally.')
    assert not execute_match('git push', 'no error')

# Generated at 2022-06-26 06:10:34.636897
# Unit test for function get_new_command
def test_get_new_command():
	command = Command("git push", "failed to push some refs to 'git@github.com:raghavjindal/The-fuck.git'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.\n")
	get_new_command(command)
	assert "git pull && git push" == str(get_new_command(command))

# Generated at 2022-06-26 06:10:42.613921
# Unit test for function match
def test_match():
    assert match(Command('git push origin',
        "To https://github.com/nvbn/thefuck\n ! [rejected]        fix -> fix (non-fast-forward)\n error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: 'git pull ...') before pushing again.\n hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n",
        '', 2))


# Generated at 2022-06-26 06:10:47.328657
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push abcd').script == 'git pull && git push abcd'



# Generated at 2022-06-26 06:10:48.862180
# Unit test for function match
def test_match():
    assert match('git push origin master')


# Generated at 2022-06-26 06:11:03.866995
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin') == 'git pull origin && git push origin'
    assert get_new_command('git push') == 'git pull && git push'

# Generated at 2022-06-26 06:11:15.487708
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)',
                         'error: failed to push some refs to...'))
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (fetch first)',
                         'error: failed to push some refs to...'))
    assert match(Command('git push origin',
                         'To...',
                         ' ! [rejected]        master -> master (fetch first)',
                         ' error: failed to push some refs to...'))
    assert not match(Command('git push origin master',
                             'Everything up-to-date',
                             'To...'))


# Generated at 2022-06-26 06:11:26.222900
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push', '')) ==
            shell.and_('git pull', 'git push'))
    assert (get_new_command(Command('git push origin', '')) ==
            shell.and_('git pull origin', 'git push origin'))
    assert (get_new_command(Command('git push origin', '', 'pwd')) ==
            shell.and_('git -C pwd pull origin', 'git -C pwd push origin'))
    assert (get_new_command(Command('git push', '', 'pwd')) ==
            shell.and_('git -C pwd pull', 'git -C pwd push'))



# Generated at 2022-06-26 06:11:38.151842
# Unit test for function match
def test_match():
    """
    1) Test script contains push command, and output contains ! [rejected]
    2) Test script contains push command, output contains failed to push some 
        refs to
    3) Test script contains push command, output contains no updates were 
        rejected because the remote contains work that you do not have locally
    4) Test script contains push command, output contains no updates were 
        rejected because the tip of your current branch is behind
    5) Test script contains push command, output contains no updates were 
        rejected because the remote contains work that you do not have locally.
        Updates were rejected because the tip of your current branch is behind
    All these outputs should match
    """

# Generated at 2022-06-26 06:11:44.399242
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the tip of your current branch is behind', error=True))
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do', error=True))
    assert not match(Command('git push', 'To git@github.com:nvie/gitflow.git'))


# Generated at 2022-06-26 06:11:56.735839
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '',
                                   '! [rejected] master -> master '
                                   '(non-fast-forward) error: failed to '
                                   'push some refs to \'origin\'')) == 'git pull && git push origin master'


# Generated at 2022-06-26 06:12:02.891506
# Unit test for function match
def test_match():
    test_cases = [
        ('git push', False),
        ('git push origin master', False),
        ('git push origin master! [rejected]', False),
        ('git push origin master! [rejected] failed to push some refs to', False),
        ('git push origin master! [rejected] failed to push some refs to '
         'Updates were rejected because the tip of your current branch is '
         'behind', True),
        ('git push origin master! [rejected] failed to push some refs to '
         'Updates were rejected because the remote contains work that you do', True)
    ]

    for command, result in test_cases:
        assert match(Command(command)) == result


# Generated at 2022-06-26 06:12:04.219047
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push master',
                                   '')) == 'git pull master && git push master'

# Generated at 2022-06-26 06:12:15.795306
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git push --set-upstream origin master', '')) \
        == 'git pull --set-upstream origin master && git push --set-upstream origin master'
    assert get_new_command(Command('git push origin master', '')) \
        == 'git pull origin master && git push origin master'
    assert get_new_command(Command('git push origin master', '')) \
        == 'git pull origin master && git push origin master'
    assert get_new_command(Command('git pu origin master', '')) \
        == 'git pull origin master && git pu origin master'
    assert get_new_command(Command('git pull', '')) \
        == 'git pull && git pull'

# Generated at 2022-06-26 06:12:26.942502
# Unit test for function match
def test_match():
    assert not match(Command('git push origin master'))
    # This case may occur for the future
    #   assert match(Command('git push origin master', '! [rejected] master -> master (non-fast-forward)'))

# Generated at 2022-06-26 06:12:54.459551
# Unit test for function get_new_command
def test_get_new_command():
    """
    Test that the new command is updated
    """
    command = Command('git push', 'Updates were rejected because the tip of '
                                  'your current branch is behind its remote '
                                  'counterpart. Integrate the remote changes'
                                  ' before pushing again.')
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-26 06:13:04.608094
# Unit test for function match

# Generated at 2022-06-26 06:13:08.156850
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'
    assert get_new_command('git push origin').script == 'git pull origin && git push origin'

# Generated at 2022-06-26 06:13:10.609720
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'


# Generated at 2022-06-26 06:13:17.562297
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to ...\n'
                         'Update was rejected because the tip of your current branch is behind.\n'
                         'hint: ...'))
    assert match(Command('git push',
                         '! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to ...\n'
                         'Update was rejected because the remote contains work that you do\n'
                         'hint: ...'))

# Generated at 2022-06-26 06:13:26.365464
# Unit test for function get_new_command
def test_get_new_command():
    test_get_new_command.last_command = Command('git push -f', '! [rejected]\n'
                                                'Updates were rejected because '
                                                'the tip of your current branch'
                                                ' is behind')
    assert get_new_command(test_get_new_command.last_command) == shell.and_('git pull', 'git push -f')
    test_get_new_command.last_command = Command('git push', '! [rejected]\n'
                                                'Updates were rejected because '
                                                'the tip of your current branch'
                                                ' is behind')
    assert get_new_command(test_get_new_command.last_command) == shell.and_('git pull', 'git push')

# Generated at 2022-06-26 06:13:35.793504
# Unit test for function get_new_command

# Generated at 2022-06-26 06:13:43.535090
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(
            Command('git push origin master',
                    'Updates were rejected because the tip of your current branch is behind'))
            == 'git pull origin master && git push origin master')

    assert (get_new_command(
            Command('git push origin master',
                    'Updates were rejected because the remote contains work that you do'))
            == 'git pull origin master && git push origin master')

# Generated at 2022-06-26 06:13:48.242569
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('git push origin master', '', 1)) == 'git pull origin master && git push origin master'

# Generated at 2022-06-26 06:13:57.032873
# Unit test for function match
def test_match():
    assert (match(Command('git push',
                          output='! [rejected]        master -> master (non-fast-forward)'
                                 'error: failed to push some refs to \'ssh://host/repo\''
                                 'Updates were rejected because the tip of your '
                                 'current branch is behind')))
    assert not match(Command('git push', output='Already up-to-date'))
    assert (match(Command('git push',
                          output='! [rejected]        master -> master (non-fast-forward)'
                                 'error: failed to push some refs to \'ssh://host/repo\''
                                 'Updates were rejected because the remote '
                                 'contains work that you do')))

# Generated at 2022-06-26 06:14:59.504668
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = "git push", output = "! [rejected]        master -> master (non-fast-forward)\n")) == 'git pull && git push'

# Generated at 2022-06-26 06:15:11.546709
# Unit test for function match

# Generated at 2022-06-26 06:15:22.169110
# Unit test for function match

# Generated at 2022-06-26 06:15:34.292722
# Unit test for function match
def test_match():
    assert match(Command('git push',
                     '! [rejected]        master -> master (non-fast-forward)',
                     'error: failed to push some refs to ',
                     'Updates were rejected because the tip of your '
                     'current branch is behind'))
    assert match(Command('git push',
                     '! [rejected]        master -> master (non-fast-forward)',
                     'error: failed to push some refs to ',
                     'Updates were rejected because the remote '
                     'contains work that you do'))
    assert not match(Command('git push',
                             '! [rejected]        master -> master (non-fast-forward)',
                             'error: failed to push some refs to ',
                             'Failed with error'))

# Generated at 2022-06-26 06:15:40.945717
# Unit test for function match
def test_match():
    # Test 1
    command = Command('git push')
    assert match(command) != True
    
    # Test 2
    command = Command('git push')
    command.output = 'Updates were rejected because the tip of your ' \
                    'current branch is behind'
    assert match(command) == True
    
    # Test 3
    command = Command('git push')
    command.output = 'Updates were rejected because the remote ' \
                    'contains work that you do'
    assert match(command) == True

# Generated at 2022-06-26 06:15:46.926230
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'Updates were rejected because the tip of your '
                         'current branch is behind '))
    assert not match(Command('git push', 'Everything up-to-date'))
    assert not match(Command('git commit', 'Everything up-to-date'))

# Generated at 2022-06-26 06:15:51.528796
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push origin master',
                'Updates were rejected because the tip of your current branch is behind',
                'git pull origin master')
    ) == 'git pull origin master && git push origin master'

# Generated at 2022-06-26 06:15:53.707455
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull && git push'

# Generated at 2022-06-26 06:16:01.426376
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'
    assert get_new_command('git push origin master').script == 'git pull origin master && git push origin master'
    assert get_new_command('git push origin release').script == 'git pull origin release && git push origin release'
    assert get_new_command('git push origin feature').script == 'git pull origin feature && git push origin feature'
    assert get_new_command('git push origin hotfix').script == 'git pull origin hotfix && git push origin hotfix'


# Generated at 2022-06-26 06:16:12.677817
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'Everything up-to-date\n'))
    assert match(Command('git push origin master',
                         'Everything up-to-date\n'))
    assert match(Command('git push origin master',
                         '! [rejected]\n'))
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'))
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (fetch first)\n'))
    assert match(Command('git push origin master',
                         'Updates were rejected because the tip of your '
                         'current branch is behind\n'))