

# Generated at 2022-06-26 06:07:40.563331
# Unit test for function match

# Generated at 2022-06-26 06:07:44.696853
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '\n! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nits remote counterpart. Merge the remote changes (e.g. \'git pull\')\nbefore pushing again.\nother@remote.com\'s password: Permission denied, please try again.\nother@remote.com\'s password: '))


# Generated at 2022-06-26 06:07:45.752968
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master'

# Generated at 2022-06-26 06:07:47.740591
# Unit test for function get_new_command
def test_get_new_command():
    assert match() == var_0

# Generated at 2022-06-26 06:07:50.772588
# Unit test for function match
def test_match():
    int_0 = -4797
    var_1 = match(int_0)

test_match()
test_case_0()

# Generated at 2022-06-26 06:07:51.566352
# Unit test for function match
def test_match():
    assert True


# Generated at 2022-06-26 06:07:58.303368
# Unit test for function match
def test_match():
    assert match(Command('git push', '\n    ! [rejected]        master -> master (non-fast-forward)\n    error: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\n    hint: Updates were rejected because the tip of your current branch is behind\n    hint: its remote counterpart. Integrate the remote changes (e.g.\n    hint: \'git pull ...\') before pushing again.\n    hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))


# Generated at 2022-06-26 06:08:00.756461
# Unit test for function match
def test_match():
    assert(match(Mock(script='git push',
                      output='! [rejected]        master -> master (fetch first)')) == True)


# Generated at 2022-06-26 06:08:08.685337
# Unit test for function match
def test_match():
    assert match(Command('! [rejected]        master -> master (non-fast-forward) error: failed to push some refs to '
                         '\'git@github.com:nvbn/thefuck.git\' hint: Updates were rejected because the tip of your '
                         'current branch is behind hint: its remote counterpart. Merge the remote changes (e.g. '
                         '\'git pull\') hint: before pushing again. hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.',
                         'git push'))


# Generated at 2022-06-26 06:08:18.463059
# Unit test for function get_new_command
def test_get_new_command():
    assert not match(Command('git push', '', ''))

# Generated at 2022-06-26 06:08:22.727316
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push") == "git pull && git push"

# Generated at 2022-06-26 06:08:26.137177
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', ''))
    assert not match(Command('git log', ''))



# Generated at 2022-06-26 06:08:36.314274
# Unit test for function match
def test_match():
    assert match(
        Command(script='git push',
                output='! [rejected]        master -> master (non-fast-forward)')
    )
    assert match(
        Command(script='git push',
                output='! [rejected]        master -> master (fetch first)')
    )
    assert match(
        Command(script='git push',
                output='! [rejected]        master -> master (already exists)')
    )
    assert match(
        Command(script='git push',
                output='! [rejected]        master -> master (non-fast-forward)')
    )
    assert match(
        Command(script='git push',
                output='Updates were rejected because the tip of your '
                       'current branch is behind')
    )

# Generated at 2022-06-26 06:08:45.307402
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\n  git pull ...) before pushing again.\n  See the \'Note about fast-forwards\' section of \'git push --help\' for details.')) == 'git pull && git push'
    assert get_new_command(Command('git push', 'Updates were rejected because the remote contains work that you do\nnot have locally. This is usually caused by another repository pushing\nto the same ref. You may want to first integrate the remote changes\n(e.g., \'git pull ...\') before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.')) == 'git pull && git push'

# Generated at 2022-06-26 06:08:49.412852
# Unit test for function match
def test_match():
    command = "git push origin master"
    assert match(Command(script=command,
                         output="! [rejected]        master -> master (non-fast-forward)\n"
                                "error: failed to push some refs to 'git@github.com:dvberkel/config.git'\n"
                                "hint: Updates were rejected because the tip of your current branch is behind\n"
                                "hint: its remote counterpart. Integrate the remote changes (e.g.! [rejected]\n"
                                "hint: 'git pull ...') before pushing again.\n"
                                "hint: See the 'Note about fast-forwards' in 'git push --help' for details."))
    command = "git push origin master"

# Generated at 2022-06-26 06:08:52.406300
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull && git push'
    assert get_new_command(Command('git push origin master', '')) == \
           'git pull origin master && git push origin master'

# Generated at 2022-06-26 06:08:56.673289
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master')
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-26 06:09:04.968927
# Unit test for function match
def test_match():
    assert match(Command(script='git push',
                         stderr='remote: Resolving deltas: 100% (5/5), completed with 5 local objects.\nTo https://github.com/codeforamerica/mapti-frontend.git\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/aamob/grit.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) == True

# Generated at 2022-06-26 06:09:14.070787
# Unit test for function match
def test_match():
    command = Command('git push origin master', 
                      '! [rejected]        master -> master (non-fast-forward)')
    assert(match(command))
    command = Command('git push origin master', 
                      "Updates were rejected because the tip of your current branch is behind.\n"
                      "Use 'git pull' to merge the remote changes (e.g. 'git pull') before pushing again.")
    assert(match(command))
    command = Command('git push origin master', 
                      "Updates were rejected because the remote contains work that you do\n"
                      "not have locally. This is usually caused by another repository pushing\n"
                      "to the same ref. You may want to first integrate the remote changes\n"
                      "(e.g., 'git pull ...') before pushing again.")
    assert(match(command))
   

# Generated at 2022-06-26 06:09:17.357303
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push github master', '', 3)) == shell.and_('git pull github master', 'git push github master')

# Generated at 2022-06-26 06:09:26.221708
# Unit test for function get_new_command
def test_get_new_command():
    _input = command('git push origin master')
    assert get_new_command(_input) == 'git pull origin master ; git push origin master'

# Generated at 2022-06-26 06:09:34.879563
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:'
                         'user/test.git\'\n'
                         'To prevent you from losing history, non-fast-'
                         'forward updates were rejected\n'
                         'Merge the remote changes (e.g. \'git pull\') '
                         'before pushing again.  See the \'Note about\n'
                         'fast-forwards\' section of \'git push --help\' for '
                         'details.\n',
                         'git push origin master'))


# Generated at 2022-06-26 06:09:45.613560
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'fatal: Couldn\'t find remote ref master\n'
                         'To https://github.com/xxx/xxx.git\n'
                         ' ! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to'
                         ' \'https://github.com/xxx/xxx.git\'',
                         ''))

    assert match(Command('git push origin master',
                         'Everything up-to-date\n'
                         'To https://github.com/xxx/xxx.git\n'
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to'
                         ' \'https://github.com/xxx/xxx.git\'',
                         ''))


# Generated at 2022-06-26 06:09:49.054664
# Unit test for function match
def test_match():
    assert match('git push')
    assert match('git push origin master')
    assert not match('git pull')
    assert not match('git checkout')

# Generated at 2022-06-26 06:09:57.182372
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git push'
    out = '! [rejected]        master -> master (fetch first)\n\
error: failed to push some refs to \'https://github.com/gabrielfalcao/HTTPretty\'\n\
hint: Updates were rejected because the remote contains work that you do\n\
hint: not have locally. This is usually caused by another repository pushing\n\
hint: to the same ref. You may want to first integrate the remote changes\n\
hint: (e.g., \'git pull ...\') before pushing again.\n\
hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'
    command = Command(script, out)

# Generated at 2022-06-26 06:10:06.674509
# Unit test for function match
def test_match():
    assert not match(Command("git push", ""))
    assert match(Command("git push", "! [rejected] master -> master (non-fast-forward)\n"
                 "error: failed to push some refs to 'git@github.com:user/repository.git'\n"
                 "hint: Updates were rejected because the tip of your current branch is behind\n"
                 "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                 "hint: 'git pull ...') before pushing again.\n"
                 "hint: See the 'Note about fast-forwards' in 'git push --help' for details."))

# Generated at 2022-06-26 06:10:11.738447
# Unit test for function match
def test_match():
    assert match(Command('git push origin master -u',
                         ' ! [rejected]\n'
                         ' error: failed to push some refs to\n'
                         ' hint: Updates were rejected because the tip of your ',
                         ''))



# Generated at 2022-06-26 06:10:23.743941
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'remote: Permission to test_user/test_project.git denied to test_user.\n'
                         'fatal: unable to access \'https://github.com/test_user/test_project.git/\': The requested URL returned error: 403',
                         '', 1))
    assert match(Command('git push origin master',
                         'Updates were rejected because the tip of your current branch is behind',
                         '', 1))
    assert match(Command('git push origin master',
                         'Updates were rejected because the remote contains work that you do',
                         '', 1))
    assert not match(Command('git push origin master',
                             'Updates were rejected because of an add/change conflict.',
                             '', 1))

# Generated at 2022-06-26 06:10:35.415579
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/ShailenNaidoo/pyfuck.git\n! '
                         '[rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to '
                         '\'https://github.com/ShailenNaidoo/pyfuck.git\'\n'
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\nhint: \'git pull ...\') before pushing '
                         'again.\nhint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))

# Generated at 2022-06-26 06:10:43.190848
# Unit test for function match

# Generated at 2022-06-26 06:11:05.792566
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'remote: Resolving deltas: 100% (180/180), completed with 119 local objects.\n'
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:kong0/test.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-26 06:11:12.318631
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push origin master',
                                   stdout=u' ! [rejected]        master -> master (non-fast-forward)\n'
                                          u'error: failed to push some refs to\'')) == u'git pull && git push origin master'

# Generated at 2022-06-26 06:11:17.239038
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the tip of your current branch is behind '
                                 'Updates were rejected because the remote contains work that you do '
                                 '! [rejected]        master -> master (non-fast-forward) '
                                 'error: failed to push some refs to '
                                 '\'git@example.com:repo_owner/repo_name.git\''))



# Generated at 2022-06-26 06:11:27.723502
# Unit test for function match
def test_match():
    assert match(Command('git push', "! [rejected]        master -> master (fetch first)\n error: failed to push some refs to 'https://github.com/wayou/demo.git'\n hint: Updates were rejected because the remote contains work that you do"))
    assert match(Command('git push', "! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to 'https://github.com/wayou/demo.git'\n hint: Updates were rejected because the tip of your current branch is behind"))
    assert not match(Command('git push', "Success"))
    assert not match(Command('git push', "error: src refspec master does not match any.\nerror: failed to push some refs to 'https://github.com/wayou/demo.git" ))


# Generated at 2022-06-26 06:11:38.767880
# Unit test for function match

# Generated at 2022-06-26 06:11:44.428564
# Unit test for function get_new_command
def test_get_new_command():
    wrong_command = 'git push'
    new_command = 'git push &amp;&amp; git pull'
    assert(get_new_command(Command(script=wrong_command,
                                   stderr='! [rejected]',
                                   output='failed to push some refs to')) == new_command)


# Generated at 2022-06-26 06:11:54.713975
# Unit test for function match
def test_match():
    assert match(Command('git push', '', ''))
    assert not match(Command('git diff', '', ''))
    assert not match(Command('git push',
                             ('Everything up-to-date\n'
                              'Completed with errors, see above.'),''))
    assert match(Command('git push',
                         ('Updates were rejected because the tip of'
                          ' your current branch is behind'),''))
    assert match(Command('git push',
                         ('Updates were rejected because the remote'
                          ' contains work that you do'),''))


# Generated at 2022-06-26 06:12:05.419018
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '''To https://github.com/Foo/bar
! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/Foo/bar'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''', '', 0, ''))

# Generated at 2022-06-26 06:12:13.536301
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '! [rejected] master -> master (non-fast-forward)', 0))
    assert match(Command('git push origin master', '', 'Updates were rejected because the tip of your current branch is behind', 0))
    assert match(Command('git push origin master', '', 'Updates were rejected because the remote contains work that you do', 0))


# Generated at 2022-06-26 06:12:18.461524
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected] master -> master (non-fast-forward)'))
    assert not match(Command('git push origin master',
                             'Everything up-to-date'))
    assert not match(Command('git push origin master',
                             'Updates were rejected because the remote '
                             'contains work  that you do'))
    assert not match(Command('git push origin master',
                             'Updates were rejected because the tip of '
                             'your current branch is behind'))
    assert not match(Command('git commit -am "message"',
                             ' ! [rejected] master -> master (non-fast-forward)'))



# Generated at 2022-06-26 06:12:44.871527
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)', 'Updates were rejected because the tip of your current branch is behind its remote counterpart'))
    assert match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)', 'Updates were rejected because the remote contains work'))
    assert not match(Command('git push',
                         '! [rejected]        master -> master (non-fast-forward)', 'Updates were rejected because the remote contains work'))


# Generated at 2022-06-26 06:12:55.194921
# Unit test for function match
def test_match():
    assert match(Command(script='git push --set-upstream upstream master',
             output=' ! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-26 06:13:03.658517
# Unit test for function match
def test_match():
    assert (match(Command(script = 'git push origin master',
                          output = 'failed to push some refs to \'https://github.com/prince-chrismc/thefuck.git\'\n'
                                   'hint: Updates were rejected because the tip of your current branch is behind\n'
                                   'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                   'hint: \'git pull ...\') before pushing again.\nhint:\nhint: See the \'Note about'
                                   ' fast-forwards\' in \'git push --help\' for details.')) == True)


# Generated at 2022-06-26 06:13:14.573226
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To http:/...\n ! [rejected] master -> master (fetch first)\n error: failed to push some refs to \'http:/...\'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-26 06:13:16.838238
# Unit test for function match
def test_match():
    assert match(Command(script='git push origin master',
                         stderr='error: failed to push some refs to \'origin\'',
                         stdout=' ! [rejected]        master -> master (fetch first)')
                 )


# Generated at 2022-06-26 06:13:25.721692
# Unit test for function match
def test_match():
    # assert match('git push')
    assert match(Command('git push origin master'))
    assert match(Command('git push origin master',
                         stderr=' ! [rejected]        master -> master (non-fast-forward)\n'
                                'error: failed to push some refs to \'git@example.com:mm/repo.git\'\n'
                                'hint: Updates were rejected because the tip of your current branch is behind\n'
                                'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                'hint: \'git pull ...\') before pushing again.\n'
                                'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-26 06:13:34.982923
# Unit test for function match
def test_match():
    assert match(Command('git push', ''))
    assert match(Command('git push',
                         'To https://github.com/nvie/gitflow.git\n! [rejected] '
                         'develop -> develop (non-fast-forward)\n'
                         'error: failed to push some refs to '
                         'https://github.com/nvie/gitflow.git\n'
                         'hint: Updates were rejected because the tip of '
                         'your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in '
                         '\'git push --help\' for details.'))
    assert match

# Generated at 2022-06-26 06:13:37.981341
# Unit test for function get_new_command
def test_get_new_command():
    assert('&& git push' == get_new_command(shell.and_('git pull', 'git push')))

# Generated at 2022-06-26 06:13:46.852845
# Unit test for function match
def test_match():
    command = Command('git push', '''To https://github.com/fuckgithub/gitfuck.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/fuckgithub/gitfuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.''')
    assert match(command)

# Generated at 2022-06-26 06:13:57.460380
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'Username for \'https://github.com\':',
                         'To https://github.com/user/repo.git ! '
                         '[rejected]     master -> master (fetch first) '
                         'error: failed to push some refs to '
                         '\'https://github.com/user/repo.git\' '
                         'Updates were rejected because the tip of your '
                         'current branch is behind its remote counterpart. '
                         'Integrate the remote changes '
                         '(e.g.\'git pull ...\') before pushing again. '
                         'See the \'Note about fast-forwards\' '
                         'in \'git push --help\' for details.'))

# Generated at 2022-06-26 06:15:03.218779
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         stderr='! [rejected]        master -> master (non-fast-forward)\n'
                                "\t'Updates were rejected because the tip of your current branch is behind\n"
                                '\n'
                                'To git@github.com:user/proj.git\n'
                                ' - [deleted]\t\t(none)\t-> master\n'))


# Generated at 2022-06-26 06:15:12.570905
# Unit test for function match

# Generated at 2022-06-26 06:15:22.549993
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:micropython/micropython.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-26 06:15:33.677855
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '''! [rejected] master -> master (fetch first)
error: failed to push some refs to 'git@github.com:user/test.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''')
    new_command = get_new_command(command)
    assert new_command.script == 'git pull && git push'


# Generated at 2022-06-26 06:15:42.401584
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         "To https://github.com/nvbn/thefuck\n ! [rejected] master -> master (non-fast-forward)\n\
error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'\n\
hint: Updates were rejected because the tip of your current branch is behind\n\
hint: its remote counterpart. Integrate the remote changes (e.g.\n\
hint: 'git pull ...') before pushing again.\n\
hint: See the 'Note about fast-forwards' in 'git push --help' fo\n",
             ""))

    # Test with different string
    assert not match(Command('git push origin master', "", ""))



# Generated at 2022-06-26 06:15:51.363471
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                'To https://github.com/nvbn/thefuck.git\n ! [rejected]    master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-26 06:15:54.368050
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.specific.git import git_support
    test1 = git_support(get_new_command)
    assert test1("git push") == "git pull"

# Generated at 2022-06-26 06:15:56.435008
# Unit test for function match
def test_match():
    assert match(u'git push heroku master               ')


# Generated at 2022-06-26 06:16:01.813207
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git push', stderr='Updates were rejected..')
    assert get_new_command(command) == 'git pull && git push'


# Test for function match

# Generated at 2022-06-26 06:16:12.790868
# Unit test for function match
def test_match():
    assert match(Command('git push', "To git@github.com:nvbn/thefuck.git\n ! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to 'git@github.com:nvbn/thefuck.git'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.\n", '')) is True