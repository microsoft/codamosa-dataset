

# Generated at 2022-06-26 06:07:32.869195
# Unit test for function match
def test_match():
    assert True == match('')


# Generated at 2022-06-26 06:07:39.623047
# Unit test for function match
def test_match():
    cmd = Command('git push', "! [rejected]        master -> master (non-fast-forward)\n'error: failed to push some refs to '\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.\n")
    assert match(cmd) == True


# Generated at 2022-06-26 06:07:48.609352
# Unit test for function get_new_command
def test_get_new_command():
    function_command = 'git push'
    function_output = '''
git push
To git@github.com:nvbn/thefuck.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''.strip()
    assert get_new_command(Command(function_command, function_output)) == 'git pull && git push'

    function_command = 'git push'

# Generated at 2022-06-26 06:07:51.144690
# Unit test for function match
def test_match():
    int_0 = True
    var_0 = match(int_0)


# Generated at 2022-06-26 06:07:52.476639
# Unit test for function get_new_command
def test_get_new_command():
    test_case_0()
    

# Generated at 2022-06-26 06:07:58.563198
# Unit test for function match
def test_match():
    int_0 = True
    var_0 = Command("git push --set-upstream", "! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details.")
    assert match(var_0) == int_0


# Generated at 2022-06-26 06:08:09.219635
# Unit test for function match
def test_match():
    assert match(Command(script='')) == False
    assert match(Command(script='', output='')) == False
    assert match(Command(script='', output='! [rejected]')) == False
    assert match(Command(script='', output='! [rejected] failed to push some refs to')) == False
    assert match(Command(script='', output='! [rejected] failed to push some refs to', output='')) == False
    assert match(Command(script='', output='! [rejected] failed to push some refs to', output='Updates were rejected because the remote contains work that you do not have locally.')) == True
    assert match(Command(script='', output='', output='Updates were rejected because the remote contains work that you do not have locally.')) == False

# Generated at 2022-06-26 06:08:18.766606
# Unit test for function match
def test_match():
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')
    assert match('git push origin master')

# Generated at 2022-06-26 06:08:20.361809
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('') == ''



# Generated at 2022-06-26 06:08:22.347406
# Unit test for function match
def test_match():
    var_2 = False
    int_0 = get_new_command(var_2)


# Generated at 2022-06-26 06:08:27.299057
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = get_new_command(0)


# Generated at 2022-06-26 06:08:29.740732
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push") == "git pull && git push"


# Generated at 2022-06-26 06:08:31.448244
# Unit test for function get_new_command
def test_get_new_command():
    assert 0
test_get_new_command()


# Generated at 2022-06-26 06:08:33.383082
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(int_0) == shell.and_(replace_argument(int_0.script, 'push', 'pull'),
                      int_0.script)


# Generated at 2022-06-26 06:08:39.562302
# Unit test for function match
def test_match():
    int_4 = 0
    int_0 = 6
    var_1 = shell.Command(script='$ git push', stdout=int_0, stderr=int_4)
    int_3 = match(var_1)
    assert int_3 == False


# Generated at 2022-06-26 06:08:40.700364
# Unit test for function match
def test_match():
    test_case_0()


# Generated at 2022-06-26 06:08:42.477014
# Unit test for function match
def test_match():
    assert match(get_new_command('git push origin master'))
    assert match(get_new_command('git push origin master'))


# Generated at 2022-06-26 06:08:45.211599
# Unit test for function match
def test_match():
    assert match('git push my-repo foo:bar')


# Generated at 2022-06-26 06:08:47.202995
# Unit test for function match
def test_match():
    assert match('git push origin master') == True


# Generated at 2022-06-26 06:08:55.129235
# Unit test for function match
def test_match():
    assert match("git push -u origin master\n ! [rejected]        master -> master (non-fast-forward)\nTo prevent you from losing history, non-fast-forward updates were rejected\nMerge the remote changes (e.g. 'git pull') before pushing again.  See the\n'Note about fast-forwards' section of 'git push --help' for details.") == False
    assert match("git push -u origin master\n ! [rejected]        master -> master (non-fast-forward)\nTo prevent you from losing history, non-fast-forward updates were rejected\nMerge the remote changes (e.g. 'git pull') before pushing again.  See the\n'Note about fast-forwards' section of 'git push --help' for details.") == False

# Generated at 2022-06-26 06:09:09.408597
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
            'To git@github.com:dsp9107/uap-toolbox.git\n ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:dsp9107/uap-toolbox.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))


# Generated at 2022-06-26 06:09:15.781253
# Unit test for function match
def test_match():
    command = Command(script='''git show RABBIT-539''',
        stderr='''
error: pathspec 'RABBIT-539' did not match any file(s) known to git.
''',
        stdout='''

''',
        args='''
''')
    result = match(command)
    assert result


# Generated at 2022-06-26 06:09:19.585678
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('$ git push', 'Updates were rejected because the remote contains work that you do\n', '')
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-26 06:09:25.594811
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push',
                                   output='Updates were rejected because '
                                          'the tip of your current branch '
                                          'is behind its remote counterpart.')) == 'git pull && git push'

# Generated at 2022-06-26 06:09:31.845963
# Unit test for function match
def test_match():
    assert match(Command('git push', ''))
    assert not match(Command('git push', '', ''))
    assert not match(Command('git push', 'Updates were rejected because the tip of your branch is behind'))
    assert match(Command('git push', 'Updates were rejected because the remote contains work that you do not have locally.'))


# Generated at 2022-06-26 06:09:44.845624
# Unit test for function match
def test_match():
    assert match(Command('git push',
        ' ! [rejected]        master -> master (non-fast-forward)\n'
        'error: failed to push some refs to \'git@github.com:nviennot/thefuck'
        '\'.\n'
        'Updates were rejected because the tip of your current branch is '
        'behind\n'
        'its remote counterpart. Integrate the remote changes before pushing '
        'again.\n'
        ' See the \'Note about fast-forwards\' in \'git push --help\' for '
        'details.'))

# Generated at 2022-06-26 06:09:50.789967
# Unit test for function match
def test_match():
    assert match(Command('git push', ''))
    assert match(Command('git push origin master', ''))
    assert not match(Command('ls', '', ''))
    assert not match(Command('git push', 'Already up-to-date.'))


# Generated at 2022-06-26 06:09:55.502314
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', '! [rejected] ...')) == 'git pull origin master'
    assert get_new_command(Command('git push origin branch', '! [rejected] ...')) == 'git pull origin branch'
    assert get_new_command(Command('git push origin branch:branch2', '! [rejected] ...')) == 'git pull origin branch:branch2'


# Generated at 2022-06-26 06:10:05.992730
# Unit test for function match
def test_match():
    assert match(Command('git push --set-upstream origin master',
                         '''To https://github.com/angvoz/linux-scripts.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/angvoz/linux-scripts.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.''',
                         '/home/user/linux-scripts',
                         'https://github.com/angvoz/linux-scripts.git')) is True


# Generated at 2022-06-26 06:10:16.316117
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '! [rejected]\n'
                    'failed to push some refs to "https://"\n'
                    'hint: Updates were rejected because the tip of your '
                    'current branch is behind'))
    assert match(Command('git push', '', '! [rejected]\n'
                    'failed to push some refs to "https://"\n'
                    'hint: Updates were rejected because the remote '
                    'contains work that you do'))

# Generated at 2022-06-26 06:10:30.691210
# Unit test for function match
def test_match():
    assert match(Command('git push', '', '', '! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind its remote\n  (use "git push" to publish your local commits)\n\n'))
    assert not match(Command('git push', '', '', ''))


# Generated at 2022-06-26 06:10:42.951796
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
        "To git@github.com:nvbn/thefuck.git\n ! [rejected]        master -> master (fetch first)\n error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'\n hint: Updates were rejected because the remote contains work that you do\nt hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., 'git pull ...') before pushing again.\n hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n ",
        "nvbn@nvbn-box:~/Projects/thefuck$ "))

# Generated at 2022-06-26 06:10:53.983866
# Unit test for function match
def test_match():
    assert match(Command('git push origin mycode',
        '/usr/bin/git push origin mycode\n \nTo https://github.com/lzy20021010/lzy20021010.github.io\n ! [rejected]        gh-pages -> gh-pages (non-fast-forward)\n error: failed to push some refs to \'https://github.com/lzy20021010/lzy20021010.github.io\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n '
        ))



# Generated at 2022-06-26 06:10:56.760668
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git push origin master') == u'git pull origin master && git push origin master'

# Generated at 2022-06-26 06:11:07.255800
# Unit test for function match
def test_match():
    command = Command(script='git push', output='! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nUpdates were rejected because the remote contains work that you do\nfailed to push some refs to\n')
    assert match(command)
    command = Command(script='git push', output='remote: ! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nUpdates were rejected because the remote contains work that you do\nfailed to push some refs to\n')
    assert match(command)

# Generated at 2022-06-26 06:11:11.831250
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '! [rejected]        master -> master (fetch first)', '', 0)
    get_new_command(command) == shell.and_('git pull', 'git push')

# Generated at 2022-06-26 06:11:17.891293
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', 'Updates were rejected because the \
tip of your current branch is behind\n')
    assert get_new_command(command) == 'git pull && git push'

    command = Command('git push', 'Updates were rejected because the \
remote contains work that you do\n')
    assert get_new_command(command) == 'git pull && git push'

    #error = Command('git push', 'Updates were rejected because the \
#tip of your current branch is behind\n')
    #assert get_new_command(error) != 'git pull && git push'

# Generated at 2022-06-26 06:11:20.254958
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master', 'git push', ''))


# Generated at 2022-06-26 06:11:28.912534
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '''
! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'git@github.com:syl20bnr/spacemacs.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))


# Generated at 2022-06-26 06:11:35.999193
# Unit test for function match
def test_match():
    command = Command(script='git push origin master',
                      output='To https://github.com/nvbn/thefuck.git\n ! [rejected]        master -> master (fetch first)')
    assert match(command)
    command = Command(script='git push origin master',
                      output='To https://github.com/nvbn/thefuck.git\n ! [rejected]        master -> master (fetch first)')
    assert match(command)


# Generated at 2022-06-26 06:11:53.507833
# Unit test for function match
def test_match():
    assert match(Command(script = 'git push origin master',output = '[rejected]'))
    assert not match(Command(script = 'git pull origin master',output = '[rejected]'))
    assert match(Command(script = 'git push origin master',output = 'failed to push some refs to'))
    assert match(Command(script = 'git push origin master',output = 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command(script = 'git push origin master',output = 'Updates were rejected because the remote contains work that you do'))


# Generated at 2022-06-26 06:11:58.628907
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 0))
    assert match(Command('git push', '', '', 0))
    assert match(Command('git push --all origin', '', '', 0))
    assert match(Command('git push origin master', '', '', 0))
    assert match(Command('git push origin HEAD', '', '', 0))
    assert match(Command('git push', '', '', 0))
    assert match(Command('git push', '', '', 0))
    assert match(Command('git push', '', '', 0))


# Generated at 2022-06-26 06:12:04.623861
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push origin master',
        output=' ! [rejected] master -> master (non-fast-forward) '
            '\n error: failed to push some refs to \'git@github.com:user/repo.git\'\n'
            'hint: Updates were rejected because the tip of your current branch is behind\n'
            'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
            'hint: \'git pull ...\') before pushing again.\n'
            'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) \
        == 'git pull && git push origin master'

# Generated at 2022-06-26 06:12:07.277922
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull'


# Generated at 2022-06-26 06:12:17.239450
# Unit test for function match
def test_match():
    s = Shell()
    assert match(Command('git push origin master', '', s))
    assert match(Command('git push origin master', 'To https://github.com/michal-h21/thefuck.git ! [rejected] master -> master (fetch first) error: failed to push some refs to \'https://github.com/michal-h21/thefuck.git\' hint: Updates were rejected because the tip of your current branch is behind hint: its remote counterpart. Integrate the remote changes (e.g. hint: \'git pull ...\') before pushing again. hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.', s))

# Generated at 2022-06-26 06:12:21.554643
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull;git push'
    assert get_new_command('git push origin') == 'git pull origin;git push origin'

# Generated at 2022-06-26 06:12:23.814398
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', '', '', ''))


# Generated at 2022-06-26 06:12:35.914423
# Unit test for function match
def test_match():
    assert match(Command('git push origin/master',
                '! [rejected]  master -> master (non-fast-forward)',
                'error: failed to push some refs to ...',
                'Updates were rejected because the tip of your current '
                'branch is behind'))
    assert match(Command('git push origin/master',
                '! [rejected]  master -> master (non-fast-forward)',
                'error: failed to push some refs to ...',
                'Updates were rejected because the remote contains work '
                'that you do'))
    assert not match(Command('git push origin/master',
                '! [rejected]  master -> master (non-fast-forward)',
                'error: failed to push some refs to ...'))

# Generated at 2022-06-26 06:12:44.632316
# Unit test for function match
def test_match():
    assert match(Command('push origin Feature_1', '''To
https://github.com/fuzzytolerance/thefuck
 ! [rejected]        Feature_1 -> Feature_1 (non-fast-forward)
error: failed to push some refs to
'https://github.com/fuzzytolerance/thefuck'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))


# Generated at 2022-06-26 06:12:55.093960
# Unit test for function match

# Generated at 2022-06-26 06:13:25.454889
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 1, None))
    assert not match(Command('git', '', '', 1, None))

# Generated at 2022-06-26 06:13:27.822239
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master && git push origin master'

# Generated at 2022-06-26 06:13:36.434056
# Unit test for function match

# Generated at 2022-06-26 06:13:38.999612
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '')) == 'git pull && git push'

# Generated at 2022-06-26 06:13:45.158887
# Unit test for function match
def test_match():
    command=Command('git push -u origin master', '! [rejected]        master -> master (fetch first)\nUpdates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g., \'git pull ...\') before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert match(command)



# Generated at 2022-06-26 06:13:55.091415
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    script = 'git push'
    output = 'To https://github.com/nvbn/thefuck\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/nvbn/thefuck\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'
    assert get_new_command(Command(script=script, output=output)) == 'git pull && git push'


# Generated at 2022-06-26 06:13:56.654990
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git push upstream master', '')) ==
            'git pull upstream master && git push upstream master')

# Generated at 2022-06-26 06:13:59.764888
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master')) == \
        'git pull origin master && git push origin master'

# Generated at 2022-06-26 06:14:02.796576
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git push origin master", "", "")) == 'git pull && git push origin master'

# Generated at 2022-06-26 06:14:08.491958
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',''))
    assert not match(Command('git pull origin master',''))
    assert not match(Command('git push origin master','''
To https://github.com/lgcheng/thesis.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/lgcheng/thesis.git'
'''))

# Generated at 2022-06-26 06:15:32.488853
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         ' error: failed to push some refs to \'git@github.com:oleksmarkh/thefuck.git\'',
                         '', 123))
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         ' error: failed to push some refs to \'git@github.com:oleksmarkh/thefuck.git\'',
                         '', 123))
    assert not match(Command('git push origin master',
                             'Everything up-to-date',
                             '', 123))


# Generated at 2022-06-26 06:15:42.160073
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', "! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nits remote counterpart. Integrate the remote changes (e.g.\n'git pull ...') before pushing again.\n", False)) is not None
    assert match(Command('git push origin master', "! [rejected]        master -> master (fetch first)\nUpdates were rejected because the remote contains work that you do\nnot have locally. This is usually caused by another repository pushing\nto the same ref. You may want to first integrate the remote changes\n(e.g., 'git pull ...') before pushing again.\n", False)) is not None

# Generated at 2022-06-26 06:15:51.307984
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/nvbn/thefuck.git\n ! [rejected] '
                         'master -> master (fetch first)\n error: failed to '
                         'push some refs to '
                         '\'https://github.com/nvbn/thefuck.git\'\n hint: '
                         'Updates were rejected because the remote contains '
                         'work that you do not have locally. This is usually '
                         'caused by another repository pushing to the same '
                         'ref. You may want to first integrate the remote '
                         'changes (e.g., \'git pull ...\') before pushing '
                         'again.'))

# Generated at 2022-06-26 06:15:58.497053
# Unit test for function get_new_command

# Generated at 2022-06-26 06:16:03.366319
# Unit test for function match
def test_match():
    assert match(Command('git push', '''
To https://github.com/nvbn/theshit
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'https://github.com/nvbn/theshit'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))


# Generated at 2022-06-26 06:16:09.144200
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '''
        fatal: The current branch master has no upstream branch.
        To push the current branch and set the remote as upstream, use

            git push --set-upstream origin master
        '''))
    assert not match(Command('git push origin master', ''))

# Generated at 2022-06-26 06:16:20.355315
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push test hello',
                                   output='Updates were rejected because the remote contains work that you do\n	(push test hello)',
                                   stderr='! [rejected]	hello -> hello (non-fast-forward)\nerror: failed to push some refs to \'test\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) == 'git pull test hello'

# Generated at 2022-06-26 06:16:25.861619
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 'fatal: Not a git repository'))
    assert not match(Command('git push origin master', ''))
    assert not match(Command('git commit', ''))
    assert match(Command('git push', ''))


# Generated at 2022-06-26 06:16:35.038573
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         stderr='! [rejected] master -> master '
                                '(non-fast-forward)\n'
                                'error: failed to push some refs to '
                                "'git@git.repo.com:x/x.git'\n"
                                'hint: Updates were rejected because '
                                'the tip of your current branch is '
                                'behind\n'
                                'hint: its remote counterpart. '
                                'Integrate the remote changes (e.g.\n'
                                'hint: \'git pull ...\') before '
                                'pushing again.\n'
                                'hint: See the \'Note about fast-forwards\' '
                                'in \'git push --help\' for details.\n'))
    assert match

# Generated at 2022-06-26 06:16:43.412731
# Unit test for function match
def test_match():
    assert not match(Command(script='git push',
                             stderr='To git@github.com:nvbn/thefuck.git\n ! [rejected] master -> master (fetch first)'))
    assert match(Command(script='git push',
                         stderr='To git@github.com:nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))