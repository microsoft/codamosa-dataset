

# Generated at 2022-06-26 06:07:40.947286
# Unit test for function match

# Generated at 2022-06-26 06:07:47.116225
# Unit test for function match
def test_match():
    var_10 = shell.and_('git push origin develop', '! [rejected]        develop -> develop (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind its remote\n  (use "git push" to publish your local commits)\n')
    float_0 = -704.8033
    var_11 = get_new_command(float_0)
    assert var_10 is not None
    assert var_11 is not None


# Generated at 2022-06-26 06:07:49.742217
# Unit test for function match
def test_match():
    float_1 = -120.8067
    var_1 = match(float_1)


# Generated at 2022-06-26 06:07:59.558966
# Unit test for function match
def test_match():
    assert match('git push origin master')
    assert match('git push origin master ! [rejected]'
                 ' (non-fast-forward)')
    assert match('git push origin master ! [rejected]'
                 ' (non-fast-forward)'
                 ' failed to push some refs to')
    assert match('git push origin master'
                 ' ! [rejected] master -> master (non-fast-forward)')
    assert match('git push origin master'
                 ' ! [rejected] master -> master (non-fast-forward)'
                 ' failed to push some refs to')
    assert not match('git push origin master'
                     ' ! [rejected] master -> master (non-fast-forward)'
                     ' failed to push some refs to'
                     ' failed to push some refs to')

# Generated at 2022-06-26 06:08:00.446037
# Unit test for function get_new_command
def test_get_new_command():
    assert True == True


# Generated at 2022-06-26 06:08:03.203312
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = UCase(-70.623)
    var_1 = get_new_command(var_0)

    var_2 = LCase(9.876)
    var_3 = get_new_command(var_2)



# Generated at 2022-06-26 06:08:15.082960
# Unit test for function match
def test_match():
    assert match() == False
    assert match('git push') == False
    assert match('git push origin master') == False
    assert match('git push') == False
    assert match('git pull') == False
    assert match('git pull origin master') == False
    assert match('git push') == False
    assert match('git push origin master') == False
    assert match('git fetch') == False
    assert match('git fetch origin master') == False
    assert match('git fetch') == False
    assert match('git fetch origin master') == False
    assert match('git fetch') == False
    assert match('git fetch origin master') == False
    assert match('git fetch') == False
    assert match('git fetch origin master') == False
    assert match('git fetch') == False
    assert match('git fetch origin master') == False

# Generated at 2022-06-26 06:08:19.623895
# Unit test for function get_new_command
def test_get_new_command():
    float_0 = -704.8033
    var_0 = get_new_command(float_0)

if __name__ == '__main__':
    test_get_new_command()
    test_case_0()

# Generated at 2022-06-26 06:08:23.397124
# Unit test for function get_new_command
def test_get_new_command():
    float_0 = -704.8033
    data = [
        (0, 'push')
    ]
    for val0, val1 in data:
        assert get_new_command(val0, val1) == data[0][2]



# Generated at 2022-06-26 06:08:25.721615
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command.__doc__ is not None


# Generated at 2022-06-26 06:08:37.032436
# Unit test for function match

# Generated at 2022-06-26 06:08:43.422779
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'error: failed to push some refs to \'blabla\'\n'
                         'hint: Updates were rejected because the tip of your '
                         'current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote '
                         'changes (e.g.\nhint: \'git pull ...\') before pushing '
                         'again.'))
    assert not match(Command('git push origin master', ''))

# Generated at 2022-06-26 06:08:46.285843
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'

# Generated at 2022-06-26 06:08:52.660271
# Unit test for function match
def test_match():
    # print(match('git push origin master').__str__())
    assert match('git push origin master').__str__() is not None
    assert match('git push origin master').__str__() == "<Match: ('git', 'push', 'origin', 'master')>"
    assert match('git push origin master') == ("'git push origin master'", None, {"script": "'git push origin master'"})

fast_test_match = match

# Generated at 2022-06-26 06:09:03.352066
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', ''))
    assert not match(Command('git branch', '', ''))
    assert not match(Command('git push origin master', '',
                             'fatal: unable to access \'https://github.com/InsightDataScience/donorschoose-starter-code.git/\': Failed to connect to github.com port 443: Connection timed out'))
    assert not match(Command('git push origin master', '',
                             'Everything up-to-date'))
    assert not match(Command('git push origin master', '',
                             'error: failed to push some refs to ....'))
    assert not match(Command('git push origin master', '',
                             'error: src refspec master does not match any.'))

# Generated at 2022-06-26 06:09:13.841175
# Unit test for function match
def test_match():
    # 1th test
    command = Command('git push origin master',
                      '! [rejected]        master -> master '
                      '(fetch first)\n'
                      'error: failed to push some refs to '
                      '\'git@github.com:...\''
                      '\n'
                      'hint: Updates were rejected because '
                      'the remote contains work that you do '
                      'not have locally. This is usually caused '
                      'by another repository pushing to the same '
                      'ref. You may want to first integrate the '
                      'remote changes (e.g., \'git pull ...\') '
                      'before pushing again.\nhint: See the '
                      '\'Note about fast-forwards\' in '
                      '\'git push --help\' for details.')
    assert match(command)

    # 2th test

# Generated at 2022-06-26 06:09:24.581256
# Unit test for function match

# Generated at 2022-06-26 06:09:31.917493
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
        '''Total 0 (delta 0), reused 0 (delta 0)
        ! [rejected]        master -> master (non-fast-forward)
        error: failed to push some refs to ''', False, False))

    assert not match(Command('git push origin master',
        '''fatal: The remote end hung up unexpectedly''', False,  False))



# Generated at 2022-06-26 06:09:44.874171
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '! [rejected] master -> master (fetch first)\nUpdates were rejected because the tip of your current branch is behind.\n  (use "git pull" to update your local branch)\nfailed to push some refs to')
    assert get_new_command(command) == 'git pull && git push'

    command = Command('git push', '! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind.\n  (use "git pull" to update your local branch)\nfailed to push some refs to')
    assert get_new_command(command) == 'git pull && git push'


# Generated at 2022-06-26 06:09:55.880764
# Unit test for function match

# Generated at 2022-06-26 06:10:03.461264
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git push', '', 'git: \'push\' is not a git command.')) == \
        shell.and_(shell.and_('git pull', 'git push'), 'git push')

# Generated at 2022-06-26 06:10:15.292338
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward) '
                         '\n error: failed to push some refs to '
                         '\n''hint: Updates were rejected because the tip of your '
                         'current branch is behind'
                         '\n hint: its remote counterpart. Integrate the remote changes'
                         ' (e.g.'
                         '\n hint: git pull ...) before pushing again.'
                         '\n hint: See the '
                         '\n hint: git push manpage for details'))

# Generated at 2022-06-26 06:10:24.518857
# Unit test for function match
def test_match():
    # Test when command is failed
    assert not match(Command('push', '! [rejected] master -> master (non-fast-forward)\n' \
                             'error: failed to push some refs to\n' \
                             'To prevent you from losing history, ' \
                             'non-fast-forward updates were rejected\n' \
                             'Merge the remote changes (e.g. \'git pull\') ' \
                             'before pushing again. ' \
                             'See the \'Note about fast-forwards\' ' \
                             'section of \'git push --help\' for details.',
                '', 1))


# Generated at 2022-06-26 06:10:35.744298
# Unit test for function match
def test_match():
    assert match(Command('git push', 
                         'fatal: The remote end hung up unexpectedly', True,
                         'git'))

    assert not match(Command('git push origin master', 
                             'Everything up-to-date', False,
                             'git'))


# Generated at 2022-06-26 06:10:45.662529
# Unit test for function match
def test_match():
    assert not match(Command('', ''))

    command = Command('''git push origin master''',
                      """
To git@github.com:rafaelmagu/thefuck.git
 ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:rafaelmagu/thefuck.git'
hint: Updates were rejected because a pushed branch tip is behind its remote
hint: counterpart. Check out this branch and merge the remote changes
hint: (e.g. 'git pull') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
""")
    assert match(command)


# Generated at 2022-06-26 06:10:50.339170
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 0))
    assert isinstance(get_new_command(Command('git push origin master', '', '', 0)), ShellCommand)
    assert not match(Command('git push origin master', '', '', 0))
    assert not match(Command('git ', '', '', 0))

# Generated at 2022-06-26 06:10:58.283662
# Unit test for function match
def test_match():
    assert match(Command('git push origin master:master', '! [rejected] master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/thefuck/thefuck.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 1))


# Generated at 2022-06-26 06:11:07.806915
# Unit test for function match

# Generated at 2022-06-26 06:11:11.687208
# Unit test for function get_new_command
def test_get_new_command():
    assert_equal(
        get_new_command(Command('git push origin master', '', '')),
        shell.and_('git pull origin master', 'git push origin master'))

# Generated at 2022-06-26 06:11:19.139311
# Unit test for function match
def test_match():
    command = namedtuple('Command', 'script output')('git push',
                                                    '! [rejected]\n'
                                                    'failed to push some '
                                                    'refs to\n'
                                                    'Updates were rejected '
                                                    'because the tip of your '
                                                    'current branch is behind'
                                                    '\n')


# Generated at 2022-06-26 06:11:33.336872
# Unit test for function match
def test_match():
	c=Command("git push", "Updates were rejected because the tip of your current branch is behind\nUpdates were rejected because the tip of your current branch is behind")
	assert match(c) == True


# Generated at 2022-06-26 06:11:41.597470
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push origin +0123456789abcdef0123456789abcdef01234567",
                      " ! [rejected]        master -> master (non-fast-forward)\n"
                      "error: failed to push some refs to 'https://github.com/gw0/thefuck.git'\n"
                      "hint: Updates were rejected because the tip of your current branch is behind\n"
                      "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                      "hint: 'git pull ...') before pushing again.\n"
                      "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n")


# Generated at 2022-06-26 06:11:44.395473
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', 'stdout')) == True
    assert match(Command('git push origin master', 'stderr')) == False



# Generated at 2022-06-26 06:11:56.181574
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To https://github.com/nvbn/git-secret\n! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to \'https://github.com/nvbn/git-secret\'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n',
                         '', 1)) == True
        

# Generated at 2022-06-26 06:12:05.372438
# Unit test for function get_new_command
def test_get_new_command():
    command_1 = Command(script = 'git push', stdout =
                        'To git@git.some_address.some_other_address\n ! [rejected]        master -> master (non-fast-forward)\n   error: failed to push some refs to\'http://git.some_address.some_other_address\'\n   hint: Updates were rejected because the tip of your current branch is behind\n   hint: its remote counterpart. Integrate the remote changes (e.g.\n   hint: \'git pull ...\') before pushing again.\n   hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')

    assert get_new_command(command_1) == 'git pull'

# Generated at 2022-06-26 06:12:14.645557
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git push origin master'
    output = 'Updates were rejected because the remote contains work that'
    output += ' you do not have locally. This is usually caused by another'
    output += ' repository pushing to the same ref. You may want to first '
    output += 'integrate the remote changes (e.g., '
    output += "'git pull ...') before pushing again."
    command = Command(script=script, output=output)
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-26 06:12:18.598476
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', 'error: failed to push...',
                                   'git push')) == 'git pull'

# Generated at 2022-06-26 06:12:27.486025
# Unit test for function match

# Generated at 2022-06-26 06:12:34.935156
# Unit test for function match
def test_match():
    assert match(Command(script='git push', output='! [rejected] master -> master (non-fast-forward)\n'
                                                   'error: failed to push some refs to \'https://github.com/MasinEhsan/git.git\'\n'
                                                   'hint: Updates were rejected because the tip of your current branch is behind\n'
                                                   'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                                   'hint: \'git pull ...\') before pushing again.\n'
                                                   'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n')) is True

# Generated at 2022-06-26 06:12:41.906979
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_merge_conflict import get_new_command

# Generated at 2022-06-26 06:13:13.757619
# Unit test for function match
def test_match():
    assert match(Command('push',
                         output='Updates were rejected because the tip of your current'
                                ' branch is behind its remote counterpart. Integrate the '
                                'remote changes (e.g.hint: \'git pull ...\') before pushing again. '
                                'See the \'Note about fast-forwards\' in \'git push --help\' for details'))
    assert match(Command('git push',
                         output='Updates were rejected because the remote '
                                'contains work that you do not have locally. This is '
                                'usually caused by another repository pushing to the same ref. '
                                'You may want to first integrate the remote changes (e.g. hint: \'git pull ...\') '
                                'before pushing again.'))

# Generated at 2022-06-26 06:13:24.044892
# Unit test for function match
def test_match():
    # Command not recognized
    assert match(Command('sudo blabla', '', '')) == False

    # Rejected push and local commits are missing
    assert match(Command('git push origin master',
                         'To https://github.com/user/repo.git\n ! [rejected] master -> master (fetch first)\n error: failed to push some refs to \'https://github.com/user/repo.git\'\n hint: Updates were rejected because the remote contains work that you do\n hint: not have locally. This is usually caused by another repository pushing\n hint: to the same ref. You may want to first integrate the remote changes\n hint: (e.g., \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.', '')) == True



# Generated at 2022-06-26 06:13:33.233061
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
    'To git@github.com:nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n'
    'error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\'\n'
    'To prevent you from losing history, non-fast-forward updates were rejected\n'
    'Merge the remote changes before pushing again.  See the \'Note about\n'
    'fast-forwards\' section of \'git push --help\' for details.\n',
    'git push origin master'))



# Generated at 2022-06-26 06:13:34.959427
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '', '')) == 'git pull'

# Generated at 2022-06-26 06:13:37.980038
# Unit test for function get_new_command
def test_get_new_command():
    assert git.get_new_command('git push') == 'git pull && git push'


# Generated at 2022-06-26 06:13:46.852339
# Unit test for function match
def test_match():
    assert match(Command('git push', '', ' ! [rejected]        master -> master (non-fast-forward)\n'
                                                                 'error: failed to push some refs to \'git@github.com:/.git\'\n'
                                                                 'hint: Updates were rejected because the tip of your current branch is behind\n'
                                                                 'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                                                 'hint: \'git pull ...\') before pushing again.\n'
                                                                 'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-26 06:13:48.825442
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master')) == 'git pull origin master && git push origin master'

# Generated at 2022-06-26 06:13:57.288537
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', ' ! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\n  its remote counterpart. Integrate the remote changes (e.g.\n  \'git pull ...\') before pushing again.\n  See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert(get_new_command(command) == shell.and_('git pull origin master', 'git push origin master'))


# Generated at 2022-06-26 06:14:09.413567
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '', 0))
    assert match(Command('git push', '', '', 0))
    assert not match(Command('git pull', '', '', 0))
    assert not match(Command('git push origin master', '', 'Already up to date.', 0))
    assert not match(Command('git push origin master', '', 'Everything up to date', 0))
    assert not match(Command('git push origin master', '', "fatal: The current branch master has no upstream branch.", 0))
    assert not match(Command('git push origin master', '', "fatal: The current branch master has no upstream branch. To push the current branch and set the remote as upstream, use", 0))

# Generated at 2022-06-26 06:14:19.652870
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'Username for \'https://github.com\': '
                         '! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to '
                         '\'https://github.com/user/thefuck.git\'\n'
                         'To prevent you from losing history, '
                         'non-fast-forward updates were rejected\n'
                         'Merge the remote changes (e.g. \'git pull\') '
                         'before pushing again.  See the \'Note about'
                         ' fast-forwards\' section of \'git push --help\' '
                         'for details.',
                         ''))


# Generated at 2022-06-26 06:15:22.747170
# Unit test for function match
def test_match():
    assert match(Command('git push', ''))
    assert match(Command('git push he', 'Updates were rejected because the tip of your current branch is behind'
                                         'its remote counterpart. Integrate the remote changes (e.g.\n'
                                         '\'git pull ...\') before pushing again.\n'
                                         'See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-26 06:15:28.289914
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(Command('git push', '', '! [rejected] master -> master (fetch first)', ''))
    result = result.split()
    assert(result[0] == 'git')
    assert(result[1] == 'pull')

# Generated at 2022-06-26 06:15:37.433446
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to \'git@github.com:rails/rails.git\'\n'
                         'hint: Updates were rejected because the remote contains work that you do\n'
                         'hint: not have locally. This is usually caused by another repository pushing\n'
                         'hint: to the same ref. You may want to first integrate the remote changes\n'
                         'hint: (e.g., \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         '', 3))

# Generated at 2022-06-26 06:15:39.381888
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == 'git pull origin master; git push origin master'



# Generated at 2022-06-26 06:15:50.507584
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'fatal: The current branch master has '
                         'no upstream branch.\n'
                         'To push the current branch and set the remote'
                         ' as upstream, use\n'
                         '\n'
                         '    git push --set-upstream origin master'))
    assert match(Command('git push origin',
                         'fatal: The current branch master has '
                         'no upstream branch.\n'
                         'To push the current branch and set the remote'
                         ' as upstream, use\n'
                         '\n'
                         '    git push --set-upstream origin master'))

# Generated at 2022-06-26 06:15:53.900955
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'Updates were rejected because the tip of your '
                         'current branch is behind'))

# Generated at 2022-06-26 06:16:03.007744
# Unit test for function match
def test_match():
    assert match(Command(script='git push',
                         output=' ! [rejected]        master -> master (non-fast-forward)\n'
                                'error: failed to push some refs to \'git@gitlab.example.com:repo/project.git\'\n'
                                'hint: Updates were rejected because the tip of your current branch is behind\n'
                                'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                'hint: \'git pull ...\') before pushing again.\n'
                                'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))


# Generated at 2022-06-26 06:16:13.140277
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git push origin master',
                                   '''error: failed to push some refs to
fatal: The remote end hung up unexpectedly''', 1)) == 'git pull origin master && git push origin master'
    assert get_new_command(Command('git push origin master',
                                   '''error: failed to push some refs to
fatal: The remote end hung up unexpectedly''', 1)) == 'git pull origin master && git push origin master'

# Generated at 2022-06-26 06:16:22.089194
# Unit test for function match
def test_match():
    assert match(Command('git push', '', 'To https://github.com/rohitkumar-rk/test.git\n	! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/rohitkumar-rk/test.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-26 06:16:30.739235
# Unit test for function match