

# Generated at 2022-06-26 06:07:33.300040
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = ":b~Tj'{=t}A,tE|Wa"
    str_1 = "git push origin master"
    str_2 = "'U-|9~Z J69Pak|"
    var_0 = get_new_command(str_1)
    print(str_0)
    print(str_1)
    print(str_2)
    print(var_0)

# Generated at 2022-06-26 06:07:42.240319
# Unit test for function get_new_command
def test_get_new_command():
    print("Testing Function git_push_to_pull")

    str_input = "git push"
    str_correct_output = "git pull"

    assert get_new_command(str_input) == str_correct_output

    str_input = "git push"
    str_correct_output = "git pull"

    assert get_new_command(str_input) == str_correct_output

    str_input = "git push"
    str_correct_output = "git pull"

    assert get_new_command(str_input) == str_correct_output

    str_input = "git push -u origin master"
    str_correct_output = "git pull -u origin master"

    assert get_new_command(str_input) == str_correct_output

    print("done!")



# Generated at 2022-06-26 06:07:45.345802
# Unit test for function match
def test_match():
    input_str = "git push ! [rejected]        master -> master (fetch first)"
    expected_output = True
    assert match(input_str) == expected_output

# Generated at 2022-06-26 06:07:51.922198
# Unit test for function get_new_command
def test_get_new_command():
    try:
        assert match(":'U-|9~Z J69Pak|") == True
        assert get_new_command(":'U-|9~Z J69Pak|") == "git pull && :'U-|9~Z J69Pak|"
    except:
        return False


# Generated at 2022-06-26 06:07:55.673802
# Unit test for function get_new_command
def test_get_new_command():
    str_1 = ":e5v-~$a Z7_9QzW`"
    var_1 = get_new_command(str_1)

    assert func_0(var_1, str_1) == True


# Generated at 2022-06-26 06:08:03.758024
# Unit test for function match
def test_match():
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True
    assert match('git push') is True

# Generated at 2022-06-26 06:08:09.689023
# Unit test for function match
def test_match():
  test_str_0 = "git push"
  test_str_1 = "git pull"
  test_str_2 = "git clone"
  assert match(test_str_0)
  assert not match(test_str_1)
  assert not match(test_str_2)


# Generated at 2022-06-26 06:08:12.799494
# Unit test for function get_new_command
def test_get_new_command():
    arg0 = ":'U-|9~Z J69Pak|"
    var0 = get_new_command(arg0)
    assert var0 == "'git pull'", "Unit test for function get_new_command: FAIL"
    return 0

# Generated at 2022-06-26 06:08:20.582588
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = "'U-|9~Z p69Pak|"
    var_0 = get_new_command(str_0)
    str_1 = "'U-|9~Z '69Pak|"
    var_1 = get_new_command(str_1)
    str_2 = "'U-|9~Z m69Pak|"
    var_2 = get_new_command(str_2)
    str_3 = "'U-|9~Z `69Pak|"
    var_3 = get_new_command(str_3)
    str_4 = "'U-|9~Z c69Pak|"
    var_4 = get_new_command(str_4)
    str_5 = "'U-|9~Z '69Pak|"
    var_5 = get_new_command(str_5)
   

# Generated at 2022-06-26 06:08:27.480451
# Unit test for function match
def test_match():
    str_0 = "git push origin master"
    str_1 = "To https://github.com/nvbn/thefuck.git\n ! [rejected]        master -> master (fetch first)\nerror: failed to push some refs to 'https://github.com/nvbn/thefuck.git'\nhint: Updates were rejected because the remote contains work that you do\nhint: not have locally. This is usually caused by another repository pushing\nhint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., 'git pull ...') before pushing again.\nhint: See the 'Note about fast-forwards' in 'git push --help' for details."
    str_2 = "git push --force"
    str_3 = "git push --force origin master"
    str_

# Generated at 2022-06-26 06:08:37.775064
# Unit test for function match
def test_match():
    assert match('function') == False
    assert match('Y6Uxfp') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function') == False
    assert match('function')

# Generated at 2022-06-26 06:08:45.202215
# Unit test for function get_new_command
def test_get_new_command():
    # function = test_case_0
    function = get_new_command
    assert function == get_new_command(
        'git push origin master',
        """ ! [rejected]        master -> master (non-fast-forward)
error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.""")


test_get_new_command()

# Generated at 2022-06-26 06:08:47.204505
# Unit test for function match
def test_match():
    assert match(str_0) == True


# Generated at 2022-06-26 06:08:55.129731
# Unit test for function match
def test_match():
    input1 = "git push origin master"
    input2 = "error: failed to push some refs to 'git@github.com:ai/e17.git'\n"
    input3 = "hint: Updates were rejected because the tip of your current branch is behind\n"
    input4 = "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
    input5 = "hint: 'git pull ...') before pushing again.\n"
    input6 = "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n"
    input7 = ""
    input8 = ""
    input9 = ""
    input10 = "git push origin master"

# Generated at 2022-06-26 06:09:04.006488
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = "git pull origin master"
    str_1 = "git pull remote master"
    str_2 = "git push origin master"
    str_3 = "git fetch origin master"
    str_4 = "git fetch remote master"
    str_5 = "git fetch origin dev"
    str_6 = "git fetch remote dev"
    assert get_new_command(str_0) == "git pull origin master"
    assert get_new_command(str_1) == "git pull remote master"
    assert get_new_command(str_2) == "git pull origin master"
    assert get_new_command(str_3) == "git fetch origin master"
    assert get_new_command(str_4) == "git fetch remote master"

# Generated at 2022-06-26 06:09:09.709222
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = "git push"
    str_1 = "git pull"
    var_0 = get_new_command(str_0)
    print(var_0)
    var_1 = get_new_command(str_1)
    print(var_1)
    
test_get_new_command()

# Generated at 2022-06-26 06:09:11.669805
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push origin master") == "git pull origin master && git push origin master"

# Generated at 2022-06-26 06:09:15.835861
# Unit test for function match
def test_match():
    str_0 = "->j|bna ktM{`"
    var_0 = git_support(str_0)
    assert var_0 == True


# Generated at 2022-06-26 06:09:20.152646
# Unit test for function match
def test_match():
    str_1 = ":'U-|9~Z J69Pak|"
    var_1 = match(str_1)
    assert var_1 == True

# unit test for function get_new_command


# Generated at 2022-06-26 06:09:23.891329
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push") == "git pull ; git push"


# Generated at 2022-06-26 06:09:36.033699
# Unit test for function match
def test_match():
    assert match( 'git push origin master' ) == True
    assert match( 'git add . && git commit -m \'Add minor changes\' && git push -u origin master' ) == True
    assert match( 'git push origin master' ) == True
    assert match( 'git push origin HEAD' ) == True
    assert match( 'git push origin' ) == True
    assert match( 'git push' ) == True
    assert match( 'git push origin master' ) == True
    assert match( 'git push origin master' ) == True
    assert match( 'git push origin master' ) == True
    assert match( 'git push origin master' ) == True
    assert match( 'git push origin master' ) == True
    assert match( 'git push origin master' ) == True
    assert match( 'git push origin master' ) == True

# Generated at 2022-06-26 06:09:38.030436
# Unit test for function match
def test_match():
    assert get_new_command
    assert git_support


# Generated at 2022-06-26 06:09:46.579788
# Unit test for function match
def test_match():
    var_0 = match(script="""git push""")
    assert var_0 == False
    var_1 = match(script="""git push origin""")
    assert var_1 == False
    var_2 = match(script="""git push --set-upstream origin master""")
    assert var_2 == False
    var_3 = match(script="""git push origin master""")
    assert var_3 == False
    var_4 = match(script="""git push -u origin master""")
    assert var_4 == False
    var_5 = match(script="""git push -u origin HEAD""")
    assert var_5 == False
    var_6 = match(script="""git push custom destination:master""")
    assert var_6 == False

# Generated at 2022-06-26 06:09:56.405951
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = "git push origin master"
    str_0 = "! [rejected]        master -> master (non-fast-forward)\n"
    str_0 += "error: failed to push some refs to 'git@www.github.com:root/test.git'\n"
    str_0 += "hint: Updates were rejected because the tip of your current branch is behind\n"
    str_0 += "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
    str_0 += "hint: 'git pull ...') before pushing again.\n"
    str_0 += "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n"
    var_3 = match(Command(var_0, str_0))
    var_

# Generated at 2022-06-26 06:09:59.025309
# Unit test for function get_new_command
def test_get_new_command():
    # tbd: Write unit tests for function get_new_command if needed
    assert True



# Generated at 2022-06-26 06:10:00.344928
# Unit test for function get_new_command
def test_get_new_command():
    assert test_case_0()

# Generated at 2022-06-26 06:10:03.034265
# Unit test for function match
def test_match():
    input_0 = ":$&+_mYssm-R&J6"
    var_0 = match(input_0)
    assert var_0 == True


# Generated at 2022-06-26 06:10:04.583125
# Unit test for function match
def test_match():
    assert match


# Generated at 2022-06-26 06:10:05.749279
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = "git push"
    var_0 = get_new_command(str_0)
    assert var_0 == "git pull"


# Generated at 2022-06-26 06:10:16.203299
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push origin master') == "git pull && git push origin master"
    assert get_new_command('git push git@github.com:vinta/fuck.git refs/heads/master:refs/heads/master') == "git pull && git push git@github.com:vinta/fuck.git refs/heads/master:refs/heads/master"
    assert get_new_command('git push --tags') == "git pull && git push --tags"
    assert get_new_command('git push origin master') == "git pull && git push origin master"
    assert get_new_command('git push origin develop') == "git pull && git push origin develop"

# Generated at 2022-06-26 06:10:21.572963
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git push origin master').script == u'git pull && git push origin master'
    assert get_new_command(u'git push origin master').script == u'git pull && git push origin master'

# Generated at 2022-06-26 06:10:26.230316
# Unit test for function match
def test_match():
    # Test if function returns False when command does not contain "push"
    assert not match(Command('git branch', '', ''))
    # Test if function returns False when command does not contain "! [rejected]" and "failed to push some refs to"
    assert not match(Command('git push', '! [rejected]', ''))
    assert not match(Command('git push', '', 'failed to push some refs to'))
    # Test if function returns False when command does not contain "Updates were rejected because the tip of your current branch is behind" or "Updates were rejected because the remote contains work that you do"
    assert not match(Command('git push', '! [rejected]', 'failed to push some refs to', stderr='Updates were rejected because the remote contains work that you do'))

# Generated at 2022-06-26 06:10:31.442914
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', '', '', '', '', '')
    new_cmd = get_new_command(command)
    assert new_cmd == shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-26 06:10:39.663098
# Unit test for function match
def test_match():
    valid = ("git push origin master", """
To https://github.com/nvbn/thefuck.git
 ! [rejected]        7.5.1 -> 7.5.1 (non-fast-forward)
error: failed to push some refs to 'https://github.com/nvbn/thefuck.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.""")

# Generated at 2022-06-26 06:10:46.722218
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
        "! [rejected]        master -> master (fetch first)\n"
        "error: failed to push some refs to 'git@github.com:agermanidis/fuck.git'\n"
        "hint: Updates were rejected because the remote contains work that you do\n"
        "hint: not have locally. This is usually caused by another repository pushing\n"
        "hint: to the same ref. You may want to first integrate the remote changes\n"
        "hint: (e.g., 'git pull ...') before pushing again.\n"
        "hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n"))


# Generated at 2022-06-26 06:10:57.257177
# Unit test for function match
def test_match():
    command = type('Command', (object,), {
        'script': 'git push',
        'output': 'Updates were rejected because the tip of your current branch is behind'
    })
    assert match(command)

    command = type('Command', (object,), {
        'script': 'git push',
        'output': 'Updates were rejected because the remote contains work that you do'
    })
    assert match(command)

    command = type('Command', (object,), {
        'script': 'git push',
        'output': 'remote: ! [rejected]'
    })
    assert not match(command)

    command = type('Command', (object,), {
        'script': 'git push',
        'output': 'Updates were rejected because the'
    })
    assert not match(command)

# Unit test

# Generated at 2022-06-26 06:11:06.522392
# Unit test for function match
def test_match():
    assert match(Command('git push', '''\
To git@github.com:nvbn/thefuck.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
'''))

# Generated at 2022-06-26 06:11:08.861211
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'

# Generated at 2022-06-26 06:11:10.647763
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'


enabled_by_default = True

# Generated at 2022-06-26 06:11:13.403046
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command("git push origin master").script ==
            "git pull origin master")

# Generated at 2022-06-26 06:11:24.548257
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == u'git pull && git push'
    assert get_new_command('git push origin master') == u'git pull origin master && git push origin master'

# Generated at 2022-06-26 06:11:33.193105
# Unit test for function get_new_command
def test_get_new_command():
    command_1 = Command('git push origin master', '', '', 3)
    command_2 = Command('git push origin master-temp', '', '', 4)
    assert get_new_command(command_1) == shell.and_('git pull origin master', 'git push origin master')
    assert get_new_command(command_2) == shell.and_('git pull origin master-temp', 'git push origin master-temp')

# Generated at 2022-06-26 06:11:38.015082
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'
    assert get_new_command('git push origin master').script == 'git pull && git push origin master'
    assert get_new_command('git push').script == 'git pull && git push'
    assert get_new_command('git push -u origin master').script == 'git pull && git push -u origin master'

# Generated at 2022-06-26 06:11:41.151827
# Unit test for function get_new_command
def test_get_new_command():
    ls = shell.and_('git pull', 'git push')
    assert get_new_command(ls) == ls

# Generated at 2022-06-26 06:11:48.543716
# Unit test for function match
def test_match():
    command = Command('git push --set-upstream origin master',
                      "error: failed to push some refs to 'https://github.com/user/hello-world.git'\n"
                      'hint: Updates were rejected because the tip of your current branch is behind\n'
                      "hint: its remote counterpart. Integrate the remote changes (e.g.\n"
                      "hint: 'git pull ...') before pushing again.\n"
                      'hint: See the '
                      "'Note about fast-forwards' in 'git push --help' for details.\n")
    assert match(command)
    new_command = get_new_command(command)
    assert new_command == shell.and_('git pull --set-upstream origin master',
                                     'git push --set-upstream origin master')


#

# Generated at 2022-06-26 06:11:51.675049
# Unit test for function get_new_command
def test_get_new_command():
    command.script = 'git push origin master'
    assert get_new_command(command) == 'git pull origin master && git push origin master'

# Generated at 2022-06-26 06:11:59.929346
# Unit test for function match
def test_match():

    # command output in case of match
    assert match(Command('git push origin master',
                 'To https://github.com/nvbn/thefuck.git\n ! [rejected] master -> master (non-fast-forward)\n error: failed to push some refs to '
                 '\'https://github.com/nvbn/thefuck.git\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes '
                 '(e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'))

# Generated at 2022-06-26 06:12:02.508046
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(FIXTURES) == FIXTURES_COMMAND


# Generated at 2022-06-26 06:12:07.439706
# Unit test for function match

# Generated at 2022-06-26 06:12:17.274089
# Unit test for function match
def test_match():
    assert match(Command(script="git push origin master",
                         output="error: failed to push some refs to "
                         "'git@github.com:XXX/XXX.git'\n"
                         "hint: Updates were rejected because "
                         "the tip of your current branch is behind\n"
                         "hint: its remote counterpart. Integrate "
                         "the remote changes (e.g.\n"
                         "hint: 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' "
                         "in 'git push --help' for details.",
                         stderr="",
                         env={}))

# Generated at 2022-06-26 06:12:39.659130
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.main import Command

    assert (get_new_command(Command('git push',
                                    'Updates were rejected because a'
                                    ' pushed branch tip is behind its'
                                    ' remote counterpart.'
                                    ' If you did not intend to push'
                                    ' that branch, you may want to'
                                    ' specify branches to push'
                                    ' or set the \'push.default\' configuration'
                                    ' variable to \'current\' or \'upstream\'\n'
                                    'To git@github.com:user/repo.git\n'
                                    '   9200d8c..9ee43b1  master -> master'))
            == ['git pull', 'git push'])


# Generated at 2022-06-26 06:12:42.665106
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git push origin master")
    new_command = get_new_command(command)
    assert new_command == " && ".join(["git pull origin master", "git push origin master"])

# Generated at 2022-06-26 06:12:45.200433
# Unit test for function get_new_command
def test_get_new_command():
    assert "git pull" in get_new_command(Command('git push origin master'))

# Generated at 2022-06-26 06:12:55.331253
# Unit test for function match
def test_match():
    # Check case when command output contains ! [rejected]
    assert match(Command('git push',
        ' ! [rejected]        master -> master (fetch first)',
        'error: failed to push some refs to \'git@github.com:nvbn/thefuck.git\''
        ))
    # Check case when command output contains Updates were rejected because the tip of your current branch is behind

# Generated at 2022-06-26 06:12:59.281116
# Unit test for function get_new_command
def test_get_new_command():
    result = git.and_('push', 'push')
    assert result == 'pull'
    result = git.and_('push', 'push -f')
    assert result == 'pull -f'

# Generated at 2022-06-26 06:13:02.038243
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin branch', '! [rejected]\nEverything up-to-date')) == 'git pull origin branch && git push origin branch'

# Generated at 2022-06-26 06:13:13.725202
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         '''$ git push
To git@github.com:nvbn/thefuck.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.

$ git pull
Already up-to-date.
'''))


# Generated at 2022-06-26 06:13:14.674916
# Unit test for function get_new_command
def test_get_new_command():
    asser

# Generated at 2022-06-26 06:13:18.175808
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git push')
    assert(get_new_command(command)) == '&& git pull'
    return True    # Dummy True

enabled_by_default = True

# Generated at 2022-06-26 06:13:27.300075
# Unit test for function match
def test_match():
    assert(match(Command(script='git push',
                         output='To https://github.com/notifications\n ! [rejected]        master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/notifications\'\nHint: Updates were rejected because the tip of your current branch is behind\nHint: its remote counterpart. Integrate the remote changes (e.g.\nHint: \'git pull ...\') before pushing again.\nHint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')) == True)


# Generated at 2022-06-26 06:13:59.965412
# Unit test for function match

# Generated at 2022-06-26 06:14:10.189153
# Unit test for function match

# Generated at 2022-06-26 06:14:20.409693
# Unit test for function match
def test_match():
    command = Command('git push origin master',
                      'To https://github.com/user/repo\n ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to \'https://github.com/user/repo\'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: \'git pull ...\') before pushing again.\n hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert match(command)

# Generated at 2022-06-26 06:14:31.417074
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected] origin -> master (non-fast-forward)', '123'))
    assert match(Command('git push', '! [rejected] master -> master (non-fast-forward)', '123'))
    assert match(Command('git push', '! [rejected] origin -> master (fetch first)', '123'))
    assert match(Command('git push', '! [rejected] master -> master (fetch first)', '123'))
    assert match(Command('git push', '! [rejected] origin -> master (updating a handful', '123'))
    assert match(Command('git push', '! [rejected] master -> master (updating a handful', '123'))

# Generated at 2022-06-26 06:14:35.458540
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push") == "git pull;git push"
    assert get_new_command("git push origin master") == "git pull origin master;git push origin master"

# Generated at 2022-06-26 06:14:42.639065
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', ''))
    assert not match(Command('git push origin master', '', 'Updates were rejected because the tip of your current branch is behind its remote counterpart. Merge the remote changes (e.g. "git pull") before pushing again.'))
    assert not match(Command('git push origin master', '', 'Updates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g., "git pull ...") before pushing again.'))
    assert not match(Command('git push origin master', '', 'Everything up-to-date'))


# Generated at 2022-06-26 06:14:52.183014
# Unit test for function match
def test_match():
    assert match(Command('git push',
                  'To https://github.com/nvbn/thefuck.git\n ! [rejected] master -> master (fetch first)\n error: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\n hint: Updates wer\nhint: Updates were rejected because the remote contains work that you do\ne hint: not have locally. This is usually caused by another repository pushing\ne hint: to the same ref. You may want to first integrate the remote changes\nhint: (e.g., \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
              )


# Generated at 2022-06-26 06:14:54.393629
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git push").script == "git pull"

# Generated at 2022-06-26 06:15:03.085648
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'remote: ! [rejected]        master -> master (fetch first)\n'
                         'error: failed to push some refs to \'https://github.com/jack/hello-world\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.\n'
                         '',
                         ''))

# Generated at 2022-06-26 06:15:12.519852
# Unit test for function match
def test_match():
    assert match(Command('git push', output='! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nfailed to push some refs to '))
    assert match(Command('git push', output='! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the remote contains work that you do\nfailed to push some refs to '))
    assert not match(Command('git push'))
    assert not match(Command('git push', output='Already up-to-date.'))
    assert not match(Command('git push -n origin master', output='! [rejected]        master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nfailed to push some refs to '))

# Generated at 2022-06-26 06:16:20.667067
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push',
                                   stdout='Updates were rejected because '
                                          'the remote contains work that you '
                                          'do not have locally.')) == shell.and_(
                                                                             'git pull',
                                                                             'git push')

    assert get_new_command(Command(script='git push',
                                   stdout='Updates were rejected because '
                                          'the tip of your current branch is behind')) == shell.and_(
                                                                                              'git pull',
                                                                                              'git push')




# Generated at 2022-06-26 06:16:24.442449
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == 'git pull && git push'


enabled_by_default = True
priority = 9001
requires_output = True

# Generated at 2022-06-26 06:16:31.641345
# Unit test for function match
def test_match():
    assert match(Command('git push', ''))
    assert match(Command('git push origin master', ''))
    assert match(Command('git push -f', ''))
    assert match(Command('git push', '''
    To ssh://git@gitlab.example.com:1234/repo.git
    ! [rejected]        master -> master (non-fast-forward)
    error: failed to push some refs to 'ssh://git@gitlab.example.com:1234/repo.git'
    hint: Updates were rejected because the tip of your current branch is behind
    hint: its remote counterpart. Integrate the remote changes (e.g.
    hint: 'git pull ...') before pushing again.
    hint: See the 'Note about fast-forwards' in 'git push --help' for details.
    '''))

   

# Generated at 2022-06-26 06:16:33.608718
# Unit test for function get_new_command
def test_get_new_command():
    assert ('git pull && git push') == get_new_command('git push')

# Generated at 2022-06-26 06:16:42.887972
# Unit test for function match
def test_match():
    match_output = "! [rejected]        master -> master (non-fast-forward)\n" \
        "error: failed to push some refs to 'git@heroku.com:project-1.git'"
    not_match_output = "error: failed to push some refs to 'git@heroku.com:project-1.git'\n" \
        "hint: Updates were rejected because the tip of your current branch is behind\n" \
        "hint: its remote counterpart. Integrate the remote changes (e.g.\n" \
        "hint: 'git pull ...') before pushing again.\n" \
        "hint: See the 'Note about fast-forwards' in 'git push --help' for details."
    assert match(Command("git push origin master", match_output))
    assert not match

# Generated at 2022-06-26 06:16:44.915729
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull && git push'

# Generated at 2022-06-26 06:16:52.443710
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/THF-zz/thefuck\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.'))

# Generated at 2022-06-26 06:16:56.340404
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push', '\n! [rejected]        master -> master (non-fast-forward)') == 'git pull'

# Generated at 2022-06-26 06:17:03.187295
# Unit test for function match
def test_match():
    assert match(Command('git push origin master', '', '! [rejected]        master -> master (fetch first)\n'
       'error: failed to push some refs to \'git@github.com:Sofia1209/helloworld.git\'\n'
       'hint: Updates were rejected because the remote contains work that you do\n'
       'hint: not have locally. This is usually caused by another repository pushing\n'
       'hint: to the same ref. You may want to first integrate the remote changes\n'
       'hint: (e.g., \'git pull ...\') before pushing again.\n'
       'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.', '')) == True

# Generated at 2022-06-26 06:17:12.889563
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git push'