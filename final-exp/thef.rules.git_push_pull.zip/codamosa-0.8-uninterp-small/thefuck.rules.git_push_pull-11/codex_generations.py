

# Generated at 2022-06-26 06:07:36.723706
# Unit test for function get_new_command
def test_get_new_command():
    bool_0 = True
    var_0 = get_new_command(bool_0)
    bool_0 = False
    var_0 = get_new_command(bool_0)
    bool_0 = False
    var_0 = get_new_command(bool_0)


# Generated at 2022-06-26 06:07:47.759951
# Unit test for function match
def test_match():
    var_0 = 'git push origin master'

# Generated at 2022-06-26 06:07:58.471024
# Unit test for function match
def test_match():

    # Python3.5 and below
    if version_info < (3,6):
        assert(match(Command('git push', "! [rejected]        master -> master (non-fast-forward)   Updating a..b   error: failed to push some refs to 'git@github.com:sgtest/test.git'   hint: Updates were rejected because the tip of your current branch is behind   hint: its remote counterpart. Integrate the remote changes (e.g.   hint: 'git pull ...') before pushing again.   hint: See the 'Note about fast-forwards' in 'git push --help' for details.")))

    # Python3.6 and above

# Generated at 2022-06-26 06:08:09.080203
# Unit test for function match
def test_match():
    assert match(Command('git push', 'fatal: The current branch master has no upstream branch.\nTo push the current branch and set the remote as upstream, use\n\n    git push --set-upstream origin master\n'))
    assert match(Command('git push', 'ERROR: Permission to USERNAME/REPO.git denied to OTHERUSER.\nfatal: Could not read from remote repository.\n\nPlease make sure you have the correct access rights\nand the repository exists.\n'))

# Generated at 2022-06-26 06:08:10.001196
# Unit test for function get_new_command
def test_get_new_command():
    assert True

# Generated at 2022-06-26 06:08:21.605345
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = 'thefuck --alias default --interactive'
    var_1 = 'git push origin master'
    var_2 = Command(var_0, var_1)
    var_3 = 'Updates were rejected because the remote contains work that you do\nnot have locally. This is usually caused by another repository pushing\nto the same ref. You may want to first integrate the remote changes\n(e.g., \'git pull ...\') before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.'
    var_2.set_output(var_3)
    var_4 = 'thefuck --alias default --interactive && git pull origin master'
    assert var_4 == get_new_command(var_2)

# Generated at 2022-06-26 06:08:31.608413
# Unit test for function get_new_command
def test_get_new_command():
  assert(get_new_command("Push to git origin") == "Pull from git origin")
  assert(get_new_command("Push to origin") == "Pull from origin")
  assert(get_new_command("Push to git") == "Pull from git")
  assert(get_new_command("Push to") == "Pull from")
  assert(get_new_command("Pull to") == "Pull to")
  assert(get_new_command("Push") == "Push")
  assert(get_new_command("Pull") == "Pull")



# Generated at 2022-06-26 06:08:33.517042
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('git push origin master', '')
    new_cmd = get_new_command(cmd)
    assert new_cmd == 'git pull && git push origin master'

# Generated at 2022-06-26 06:08:35.984798
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(False) == 'git pull && git push'

# Generated at 2022-06-26 06:08:40.864573
# Unit test for function get_new_command
def test_get_new_command():
    bool_0 = False
    var_0 = get_new_command(bool_0)
    var_1 = get_new_command(var_0)
    var_2 = get_new_command(var_1)


# Generated at 2022-06-26 06:08:54.246782
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '! [rejected]        master -> master (fetch first)\nUpdates were rejected because the remote contains work that you do not have locally. This is usually caused by another repository pushing to the same ref. You may want to first integrate the remote changes (e.g., git pull ...) before pushing again.\nSee the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert get_new_command(command) == shell.and_('git pull', 'git push')

# Generated at 2022-06-26 06:09:03.309299
# Unit test for function get_new_command

# Generated at 2022-06-26 06:09:06.549511
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == 'git pull && git push'


# Generated at 2022-06-26 06:09:18.366084
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '''git@github.com: Permission denied (publickey).
                         fatal: Could not read from remote repository.

                         Please make sure you have the correct access rights
                         and the repository exists.
                         '''))

# Generated at 2022-06-26 06:09:24.480567
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push', '! [rejected] master -> master (non-fast-forward)\nTo git@git.git\n ! [rejected] master -> master (non-fast-forward)\nTo git@git.git\nerror: failed to push some refs to  git@git.git\nUpdates were rejected because the tip of your current branch is behind\nUpdates were rejected because the remote contains work that you do\n')
    assert get_new_command(command) == 'git pull && git push'


# Generated at 2022-06-26 06:09:33.482489
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '''
                         ! [rejected]        master -> master (non-fast-forward)
                         error: failed to push some refs to 'ssh://git@stash.domain.com:7999/project/library.git'
                         hint: Updates were rejected because the tip of your current branch is behind
                         hint: its remote counterpart. Integrate the remote changes (e.g.
                         hint: 'git pull ...') before pushing again.
                         hint: See the 'Note about fast-forwards' in 'git push --help' for details.
                         '''))


# Generated at 2022-06-26 06:09:44.660225
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push feature', '! [rejected]\n'
                      'failed to push some refs to \'ssh://git@stash:7999/'
                      'scm/jir/projectname.git\'\n'
                      'Updates were rejected because the tip of your '
                      'current branch is behind its remote\n'
                      'hint: counterpart. Integrate the remote changes '
                      '(e.g.\nhint: \'git pull ...\') before pushing again.'
                      '\nhint: See the \'Note about fast-forwards\' '
                      'in \'git push --help\' for details.')
    assert get_new_command(command) == 'git pull feature && ' \
                                      'git push feature'

# Generated at 2022-06-26 06:09:51.761424
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push',
                                   'Updates were rejected because the tip of your current branch is behind')) == 'git pull && git push'
    assert get_new_command(Command('git push',
                                   'Updates were rejected because the remote contains work that you do')) == 'git pull && git push'

# Generated at 2022-06-26 06:09:57.618604
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         ' ! [rejected] master -> master (fetch first)',
                         'error: failed to push some refs to ' +
                         "'git@github.com:L-TChen/git.git'\n" +
                         'hint: Updates were rejected because the tip of your ' +
                         'current branch is behind\n' +
                         "hint: its remote counterpart. Integrate the remote changes" +
                         " (e.g.\n" +
                         "hint: 'git pull ...') before pushing again.\n" +
                         "hint: See the 'Note about fast-forwards' in " +
                         "'git push --help' for details.\n"))


# Generated at 2022-06-26 06:10:02.175325
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git push origin master', 'Updates were rejected because the remote contains work that you do\n  (use "git pull" to update your local branch)')
    assert get_new_command(command) == 'git pull && git push origin master'

# Generated at 2022-06-26 06:10:15.395330
# Unit test for function match
def test_match():
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'))
    assert match(Command('git push', 'To https://github.com/nvbn/thefuck.git\n ! [rejected]        master -> master (non-fast-forward)\n'))
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'))
    assert match(Command('git push', '! [rejected]        master -> master (non-fast-forward)\n'))
    assert not match(Command('git checkout master', ''))



# Generated at 2022-06-26 06:10:24.563292
# Unit test for function match
def test_match():
    # Testing if function match returns True when it
    # should return True
    mocked_command = type('', (object,), {'script': 'git push',
                                          'output': '! [rejected] to master ! [rejected] to master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind\nfailed to push some refs to'})
    assert(match(mocked_command) == True)

    # Testing if function match returns False when it
    # should return False
    mocked_command = type('', (object,), {'script': 'git push',
                                          'output': '! [rejected] to master ! [rejected] to master (non-fast-forward)\nUpdates were rejected because the remote contains work that you do\nfailed to push some refs to'})

# Generated at 2022-06-26 06:10:32.946703
# Unit test for function match
def test_match():
    a = Command("git push", "", "failed to push some refs to 'repo'")
    b = Command("git push", "", "Updates were rejected because the tip of your \
        current branch is behind its remote counterpart")
    c = Command("git push", "", "Updates were rejected because the remote \
        contains work that you do not have locally")
    assert match(a)
    assert match(b)
    assert match(c)



# Generated at 2022-06-26 06:10:43.852195
# Unit test for function match
def test_match():
    assert match(Command('git push',
    '''To https://github.com/nhamid/hellogitworld.git
! [rejected]        master -> master (fetch first)
error: failed to push some refs to 'https://github.com/nhamid/hellogitworld.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
''')) == True

# Generated at 2022-06-26 06:10:50.060253
# Unit test for function match
def test_match():
    assert match(Command('git push', '', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', '', 'Updates were rejected because the remote contains work that you do'))
    assert not match(Command('git push', '', 'The upstream branch of your current branch does not match'))

# Generated at 2022-06-26 06:10:58.515018
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@bitbucket.org:CKIAGroup/ckia-cms.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         'git push origin master'))

# Generated at 2022-06-26 06:11:03.185308
# Unit test for function match
def test_match():
    assert match(Command('git push', "Username for 'https://github.com': abc"))
    assert match(Command('git push https://github.com/user/repo',
                         "Username for 'https://github.com': abc"))
    assert not match(Command('git push origin master', ''))
    assert not match(Command('git push repo master', ''))
    assert match(Command('git push origin master',
                         '! [rejected]                 master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/user/repo\''))

# Generated at 2022-06-26 06:11:08.538769
# Unit test for function get_new_command
def test_get_new_command():
    return get_new_command(Command('git push', '/tmp', ''))

# Generated at 2022-06-26 06:11:17.896081
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'error: failed to push some refs to'))
    assert match(Command('git push origin master',
                         'fatal: The current branch master has no upstream branch.'))
    assert match(Command('git push origin master',
                         'Updates were rejected because the tip of your \
                         current branch is behind'))
    assert match(Command('git push origin master',
                         'Updates were rejected because the remote '
                         'contains work that you do'))
    assert not match(Command('git push origin master',
                         'everything is up-to-date'))
    assert not match(Command('git push origin master',
                         'Everything up-to-date'))
    assert not match(Command('git push origin master',
                         '! [rejected]'))

# Generated at 2022-06-26 06:11:25.272081
# Unit test for function match
def test_match():
    command = Command('git push', 'rejected ...')
    assert match(command)
    command = Command('git push', 'rejected ...')
    assert match(command)
    command = Command('git push', 'rejected ...')
    assert match(command)
    command = Command('git push', 'rejected ...')
    assert match(command)
    command = Command('git push', 'rejected ...')
    assert match(command)


# Generated at 2022-06-26 06:11:41.079012
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git push", "! [rejected] master -> master (non-fast-forward)\nUpdates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes before pushing again.\n", "", "", "")) == 'git pull; git push'


# Generated at 2022-06-26 06:11:46.218751
# Unit test for function match
def test_match():
    assert match(Command('git push', ''))
    assert match(Command('git push origin master',
                         'Updates were rejected because the tip of '
                         'your current branch is behind'))
    assert match(Command('git push origin master',
                         'Updates were rejected because the remote '
                         'contains work that you do'))
    assert not match(Command('git push', 'Already up-to-date.'))


# Generated at 2022-06-26 06:11:53.817115
# Unit test for function match
def test_match():
    from tests.utils import Command

    assert match(Command('git push', '', 'Updates were rejected because the tip of your current branch is behind'))
    assert match(Command('git push', '', 'Updates were rejected because the remote contains work that you do'))
    assert match(Command('git push', '', 'Error'))
    assert not match(Command('git push', '', ''))


# Generated at 2022-06-26 06:11:59.083725
# Unit test for function match
def test_match():
    assert match(Command('git push', 'Updates were rejected because the tip'
                         ' of your current branch is behind'))
    assert match(Command('git push', 'Updates were rejected because the '
                         'remote contains work that you do'))

# Generated at 2022-06-26 06:12:06.781036
# Unit test for function match
def test_match():
    assert not match(Command('push branch1 branch2'))
    assert match(Command('git push', " ! [rejected] master -> master (non-fast-forward) \n error: failed to push some refs to 'git@git.git' \n hint: Updates were rejected because the tip of your current branch is behind \n hint: its remote counterpart. Integrate the remote changes (e.g. \n hint: 'git pull ...') before pushing again. \n hint: See the 'Note about fast-forwards' in 'git push --help' for details.")) # SyntaxError: EOL while scanning string literal

# Generated at 2022-06-26 06:12:17.032711
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push origin master',
                                   '! [rejected]        master -> master (non-fast-forward)\n'
                                   'error: failed to push some refs to \'git@github.com:nvie/gitflow.git\'\n'
                                   'hint: Updates were rejected because the tip of your current branch is behind\n'
                                   'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                                   'hint: \'git pull ...\') before pushing again.')) == shell.and_('git pull origin master', 'git push origin master')

# Generated at 2022-06-26 06:12:20.789760
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push') == shell.and_('git pull', 'git push')

enabled_by_default = True

# Generated at 2022-06-26 06:12:28.203304
# Unit test for function match
def test_match():

    assert match(Command('git push',
                         'To git@github.com:nvie/gitflow.git\n'
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
                         'error: failed to push some refs to \'git@github.com:nvie/gitflow.git\'\n'
                         'hint: Updates were rejected because the tip of your current branch is behind\n'
                         'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                         'hint: \'git pull ...\') before pushing again.\n'
                         'hint: See the \'Note about fast-forwards\' in \'git push --help\' for details.',
                         'git@github.com:nvie/gitflow.git')) \
        == True


# Generated at 2022-06-26 06:12:33.120468
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git push', '! [rejected] master -> master (fetch first)\nfailed to push some refs to \'https://github.com/freenit/django-freenit.git\'\n', '', 1)) == 'git pull && git push'

# Generated at 2022-06-26 06:12:37.408229
# Unit test for function get_new_command
def test_get_new_command():
    from mock import Mock
    command = Mock(script = 'git push',
                   output = (' failed to push some refs '
                             'to remote : [rejected]'))
    assert get_new_command(command) == 'git pull && git push'

# Generated at 2022-06-26 06:13:05.505790
# Unit test for function match
def test_match():
    assert match(Command('push', ''))
    assert match(Command('git push', ''))
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (fetch first)\n'
       'Updates were rejected because the tip of your current branch is behind\n'
       'its remote counterpart. Integrate the remote changes (e.g.\n'
       '\'git pull ...\') before pushing again.'))
    assert match(Command('git push origin master',
                         ' ! [rejected]        master -> master (non-fast-forward)\n'
       'Updates were rejected because the tip of your current branch is behind\n'
       'its remote counterpart. Integrate the remote changes (e.g.\n'
       '\'git pull ...\') before pushing again.'))

# Generated at 2022-06-26 06:13:14.460255
# Unit test for function match
def test_match():
    command = 'git push'
    output = 'Updates were rejected because the tip of your'\
             ' current branch is behind '
    assert match(Command(command, output))

    command = 'git push'
    output = 'Updates were rejected because the remote '\
             'contains work that you do'
    assert match(Command(command, output))

    command = 'git push'
    output = 'Updates were rejected because the branch is'\
             ' behind '
    assert not match(Command(command, output))

    command = 'git push'
    output = 'Updates were rejected because the remote '\
             'contains work that you didn\'t '
    assert match(Command(command, output))

# Generated at 2022-06-26 06:13:15.846515
# Unit test for function match
def test_match():
    is_matched = match(Command('git push'))
    assert is_matched == False


# Generated at 2022-06-26 06:13:25.291388
# Unit test for function match
def test_match():
    assert match(Command('git push origin abcd', "! [rejected] master -> master (non-fast-forward)\n\
error: failed to push some refs to 'https://github.com/adilshah/test.git'\
\n\
To prevent you from losing history, non-fast-forward updates were rejected\
\n\
Merge the remote changes before pushing again.  See the 'Note about\
\n\
fast-forwards' section of 'git push --help' for details.\n"))


# Generated at 2022-06-26 06:13:33.040533
# Unit test for function match

# Generated at 2022-06-26 06:13:40.733670
# Unit test for function get_new_command
def test_get_new_command():
    original_command  = "git push origin master"
    new_command = "git pull origin master"
    assert get_new_command(Command(original_command, "Updates were rejected because the tip of your current branch is behind its remote counterpart. Integrate the remote changes (e.g. commit the conflict resolution) before pushing again.")) == new_command




# Generated at 2022-06-26 06:13:47.340804
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         " ! [rejected]        master ->master (non-fast-forward)\n"
                         "error: failed to push some refs to '/git/project.git'\n"
                         "hint: Updates were rejected because the tip of your"
                         " current branch is behind\n"
                         "hint: its remote counterpart. Integrate the remote"
                         " changes (e.g.\n"
                         "hint: 'git pull ...') before pushing again.\n"
                         "hint: See the 'Note about fast-forwards' in "
                         "'git push --help' for details."))

# Generated at 2022-06-26 06:13:56.529829
# Unit test for function match
def test_match():
    ret = match(Command('git push origin master',
                        '! [rejected]        master -> master (non-fast-forward)\n'
                        'error: failed to push some refs to '
                        '\'https://github.com/user/repo.git\'\n'
                        'hint: Updates were rejected because the tip of your current branch is behind\n'
                        'hint: its remote counterpart. Integrate the remote changes (e.g.\n'
                        'hint: \'git pull ...\') before pushing again.',
                        ''))
    assert ret


# Generated at 2022-06-26 06:14:08.852154
# Unit test for function match
def test_match():
    command = Command('git push origin master')
    assert(match(command) == False)

    command = Command(
        'git push origin master',
        'To https://github.com/nvbn/thefuck.git\n! [rejected]  master -> master (non-fast-forward)\nerror: failed to push some refs to \'https://github.com/nvbn/thefuck.git\'\nhint: Updates were rejected because the tip of your current branch is behind\nhint: its remote counterpart. Integrate the remote changes (e.g.\nhint: \'git pull ...\') before pushing again.\nhint: See the \'Note about fast-forwards\' in \'git push --help\' for details.')
    assert(match(command) == True)


# Generated at 2022-06-26 06:14:20.175858
# Unit test for function get_new_command

# Generated at 2022-06-26 06:15:16.467314
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git push').script == "git pull" and \
    get_new_command('git --amend push').script == "git --amend pull"


# Generated at 2022-06-26 06:15:23.165011
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'To git@github.com:nvie/gitflow.git ! [rejected]',
                         'Updates were rejected because the tip of your',
                         'current branch is behind'))
    assert match(Command('git push origin master',
                         'To git@github.com:nvie/gitflow.git ! [rejected]',
                         'Updates were rejected because the remote',
                         'contains work that you do'))
    assert not match(Command('git push origin master',
                        'To git@github.com:nvie/gitflow.git',
                        'Updates were rejected because the tip of your',
                        'current branch is behind'))



# Generated at 2022-06-26 06:15:30.027212
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    command = Command('git push origin master',
                      ' ! [rejected]     master -> master (fetch first)\n'
                      'error: failed to push some refs to \'git@github.com:WhoGotCode/whoGotCode-backend.git\'',)
    assert get_new_command(command) == 'git pull && git push origin master'

# Generated at 2022-06-26 06:15:39.646678
# Unit test for function get_new_command
def test_get_new_command():
    # Check the case when the current branch is behind
    assert get_new_command(Command('git push origin master',
                                   'Updates were rejected because the tip of '
                                   'your current branch is behind',
                                   '')) == 'git pull origin master && git push origin master'

    # Check the case when the remote contains work
    assert get_new_command(Command('git push origin master',
                                   'Updates were rejected because the remote '
                                   'contains work that you do',
                                   '')) == 'git pull origin master && git push origin master'



# Generated at 2022-06-26 06:15:50.572415
# Unit test for function match
def test_match():
    assert match(Command(script = 'git push',
                         output = '! [rejected] master -> master (non-fast-forward) \
                         error: failed to push some refs to \'git@github.com:.../.../master\''))
    assert match(Command(script = 'git push',
                         output = '! [rejected] master -> master (non-fast-forward) \
                         error: failed to push some refs to \'https://.../.../master\''))
    assert match(Command(script = 'git push',
                         output = 'Updates were rejected because the tip of your \
                         current branch is behind'))
    assert match(Command(script = 'git push',
                         output = 'Updates were rejected because the remote contains \
                         work that you do'))

# Generated at 2022-06-26 06:15:57.456933
# Unit test for function get_new_command
def test_get_new_command():
    assert_equal(get_new_command(Command("git push",
       "To git@github.com:nvbn/thefuck.git\n ! [rejected]        master -> master (non-fast-forward)\n error: failed to push some refs to 'git@github.com:nvbn/thefuck.git'\n hint: Updates were rejected because the tip of your current branch is behind\n hint: its remote counterpart. Integrate the remote changes (e.g.\n hint: 'git pull ...') before pushing again.\n hint: See the 'Note about fast-forwards' in 'git push --help' for details.\n\n")),
       "git pullgit push")

# Generated at 2022-06-26 06:16:00.461041
# Unit test for function get_new_command
def test_get_new_command():
    assert git.get_new_command(git.match('git push')) == 'git pull'
    assert git.get_new_command(git.match('git remote -v')) == 'git remote -v'




# Generated at 2022-06-26 06:16:07.707308
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         '''Username for 'https://github.com': xxx
git@github.com: Permission denied (publickey).
fatal: Could not read from remote repository.

Please make sure you have the correct access rights
and the repository exists.'''))
    assert not match(Command('git push origin master'))

# Generated at 2022-06-26 06:16:16.200982
# Unit test for function match
def test_match():
    assert match(Command('git push',
                         'To https://github.com/nvie/gitflow.git\n ! [rejected] develop -> develop (non-fast-forward)\n'
                         'error: failed to push some refs to \'https://github.com/nvie/gitflow.git\'\n'
                         'hint: Updates were rejected because the tip of\n'
                         'hint: your current branch is behind its remote\n'
                         'hint: counterpart. Integrate the remote changes\n'
                         'hint: (e.g.\n'
                         'hint:   \'git pull ...\') before pushing again.',
                         ''))
    assert not match(Command('git push', '', ''))

# Generated at 2022-06-26 06:16:21.693407
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command('git push origin master', 'Updates were rejected because '
                      'the tip of your current branch is behind its remote '
                      'counterpart. Integrate the remote changes (e.g.\n'
                      '\'git pull ...\') before pushing again.\n'
                      'See the \'Note about fast-forwards\' in \'git push '
                      '--help\' for details.\n')

    assert get_new_command(command) == "git pull origin master && git push " \
                                       "origin master"