

# Generated at 2022-06-26 13:12:56.608608
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    walla_i_e = WallaIE(url)
    assert walla_i_e._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:12:57.996503
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla


# Generated at 2022-06-26 13:12:59.068335
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_case_0()

# Generated at 2022-06-26 13:13:00.791833
# Unit test for constructor of class WallaIE
def test_WallaIE():
    if WallaIE() is not None:
        assert(True)
    else:
        assert(False)

# Generated at 2022-06-26 13:13:03.157710
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() == walla_i_e_0


# Generated at 2022-06-26 13:13:03.802507
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(walla_i_e_0, WallaIE)


# Generated at 2022-06-26 13:13:05.153186
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:13:07.689668
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()

test_WallaIE()
test_case_0()

# Generated at 2022-06-26 13:13:14.643359
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert len(list(WallaIE._VALID_URL, )) < 100
    assert WallaIE._TEST['url']
    assert WallaIE._TEST['info_dict']
    assert WallaIE._TEST['params']

# Generated at 2022-06-26 13:13:16.024525
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()


# Generated at 2022-06-26 13:13:23.649877
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'http://player.walla.co.il/main/flash/player_external.swf')
    return w

# Generated at 2022-06-26 13:13:28.616657
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._TEST['url']
    assert WallaIE._TEST['info_dict']
    assert WallaIE._TEST['params']
    assert WallaIE._VALID_URL



# Generated at 2022-06-26 13:13:36.444467
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("test", "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert(ie.VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)")
    assert(ie.TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert(ie._SUBTITLE_LANGS[u'עברית'] == "heb")


# Generated at 2022-06-26 13:13:38.371673
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-26 13:13:44.318810
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    obj = WallaIE()
    mobj = re.match(obj._VALID_URL, url)
    assert mobj.group('id') == "2642630", "Bad ID"
    assert mobj.group('display_id') == "one-direction-all-for-one", "Bad Display ID"

# Generated at 2022-06-26 13:13:55.511742
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:13:56.439463
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:14:07.409854
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla_ie = WallaIE(url)
    assert walla_ie._VALID_URL == WallaIE._VALID_URL
    assert walla_ie._download_xml == WallaIE._download_xml
    assert walla_ie._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert walla_ie._real_extract == WallaIE._real_extract
    assert walla_ie.ie_key() == 'Walla'
    assert walla_ie.suitable(url)
    assert not walla_ie

# Generated at 2022-06-26 13:14:09.971783
# Unit test for constructor of class WallaIE
def test_WallaIE(): # TODO: write this unit test
    assert False, (
        "Write a unit test that tests the constructor of class WallaIE.")

# Generated at 2022-06-26 13:14:17.892023
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE(dict())
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:35.314608
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie=WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ret = ie._real_extract(ie.url)
    assert(ret['subtitles']['heb'][0]['url']=='http://walla.co.il/subtitles/2642630_2642630_heb.srt')

# Generated at 2022-06-26 13:14:40.373078
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(test_url)

# Generated at 2022-06-26 13:14:50.663447
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()
    ext = t._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ext['id'] == '2642630'
    assert ext['display_id'] == 'one-direction-all-for-one'
    assert ext['title'] == 'וואן דיירקשן: ההיסטריה'
    assert re.match(r'^\d{3}$', ext['duration']) == None
    assert ext['formats'][0]['url'] == 'rtmp://wafla.walla.co.il/vod'

# Generated at 2022-06-26 13:14:55.628528
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:14:57.193129
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-26 13:15:01.517335
# Unit test for constructor of class WallaIE
def test_WallaIE():

    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    self = WallaIE(url)

    assert self._VALID_URL == url

# Generated at 2022-06-26 13:15:02.510921
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert True

# Generated at 2022-06-26 13:15:04.824136
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_class = WallaIE()
    assert test_class

# Generated at 2022-06-26 13:15:11.819255
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # There are four test cases.
    # The first test case is a URL that is not matched.
    mobj = re.match(WallaIE._VALID_URL, 'http://walla.com')
    assert mobj is None

    # The second test case is a URL that is matched.
    mobj = re.match(WallaIE._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert mobj is not None

    # The third test case is a URL that is matched and the
    # video ID and the display ID are extracted from the URL.

# Generated at 2022-06-26 13:15:18.866568
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    video_id = "2642630"
    display_id = "one-direction-all-for-one"

    mobj = ie._VALID_URL.match(url)
    assert mobj
    assert mobj.group('id') == video_id
    assert mobj.group('display_id') == display_id

# Generated at 2022-06-26 13:15:40.219187
# Unit test for constructor of class WallaIE
def test_WallaIE():
	i = WallaIE()
	assert i is not None

# Generated at 2022-06-26 13:15:44.294643
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:15:47.256691
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-26 13:15:54.266986
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Testing
test_WallaIE()

# Generated at 2022-06-26 13:16:06.343247
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS == {'עברית': 'heb'}
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:16:09.948619
# Unit test for constructor of class WallaIE

# Generated at 2022-06-26 13:16:15.104604
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"
    assert WallaIE._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    a = WallaIE._TEST


# Generated at 2022-06-26 13:16:25.324858
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Run:
    pytest -v --tb=line test_WallaIE.py
    """
    w = WallaIE()
    # Test URL --  Invalid URL
    url = "https://www.youtube.com/watch?v=p7eaHwWiOio"
    res = w._real_extract(url)
    assert(res == None)
    # Test URL --  Valid URL
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    res = w._real_extract(url)
    assert(res != None)

# Generated at 2022-06-26 13:16:27.769118
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w.get_subtitle_langs() == ['heb']

# Generated at 2022-06-26 13:16:28.865109
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-26 13:17:10.154108
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:17:10.959162
# Unit test for constructor of class WallaIE
def test_WallaIE():
    aie = WallaIE('', '')
    assert aie is not None

# Generated at 2022-06-26 13:17:20.939196
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert (ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-26 13:17:24.722674
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert (WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-26 13:17:27.475485
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    
    return WallaIE()

# Generated at 2022-06-26 13:17:31.936035
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:17:34.723055
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-26 13:17:46.891837
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE()
    assert walla_ie._VALID_URL == 'https?://vod\\.walla\\.co\\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:17:49.919715
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-26 13:17:51.345156
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("url") is not None

# Generated at 2022-06-26 13:19:51.455784
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert not WallaIE.suitable("http://www.walla.co.il/")
    assert not WallaIE.suitable("http://rss.walla.co.il/")
    assert not WallaIE.suitable("http://www.walla.co.il/news/")


# Unit Test for method "extract" of class WallaIE

# Generated at 2022-06-26 13:20:03.350692
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:20:07.106102
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import *
    from .walla import *
    from .walla import WallaIE

    test_WallaIE()

# Generated at 2022-06-26 13:20:14.848204
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert isinstance(ie, WallaIE)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'
    assert ie._TEST['info_dict']['title']

# Generated at 2022-06-26 13:20:24.587193
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:20:37.013805
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._downloader.params['skip_download']
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-26 13:20:41.827900
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('', '')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:20:47.485669
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """ Unit test for constructor of class WallaIE
    """
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.extract(url)

# Generated at 2022-06-26 13:20:56.071793
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:20:57.724570
# Unit test for constructor of class WallaIE
def test_WallaIE():
	wie = WallaIE()