

# Generated at 2022-06-26 13:12:49.758137
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE


# Generated at 2022-06-26 13:12:58.392900
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()
    # Test for params (dict)
    assert walla_i_e._downloader.params is not None
    assert isinstance(walla_i_e._downloader.params, dict)
    # Test for urlopen (YoutubeDL object)
    assert walla_i_e._downloader.urlopen is not None
    assert isinstance(walla_i_e._downloader.urlopen, YoutubeDL)
    # Test for to_screen (function)
    assert walla_i_e._downloader.to_screen is not None
    assert callable(walla_i_e._downloader.to_screen)
    # Test for trouble (function)
    assert walla_i_e._downloader.trouble is not None

# Generated at 2022-06-26 13:13:01.204948
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(url)

# Generated at 2022-06-26 13:13:08.675242
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()._TEST
    url = test['url']
    info_dict = test['info_dict']
    params = test['params']
    params.update(i_e_key=WallaIE._ie_key(), info_dict=info_dict)
    assert WallaIE._real_extract(walla_i_e_0, url, params)

# Generated at 2022-06-26 13:13:10.131958
# Unit test for constructor of class WallaIE
def test_WallaIE():
	walla_i_e = WallaIE()

# Generated at 2022-06-26 13:13:10.624543
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()

# Generated at 2022-06-26 13:13:13.783026
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-26 13:13:17.275112
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-26 13:13:23.805693
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert 'WallaIE' in globals()
    walla_i_e = WallaIE()
    expected_valid_url = 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert walla_i_e._VALID_URL == expected_valid_url
    assert 'rtmp://wafla.walla.co.il/vod' in walla_i_e._downloader.params
    assert 'rtmp://walla.co.il/vod' in walla_i_e._downloader.params
    assert 'rtmp://wowza.walla.co.il:1935/vod' in walla_i_e._downloader.params

# Generated at 2022-06-26 13:13:34.018782
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()
# Test for method WallaIE._real_extract(url)
    mobj = re.match(walla_i_e._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    url = mobj.group('id')
    url = mobj.group('display_id')
    real_extract = walla_i_e._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:13:43.744931
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS == {'עברית': 'heb'}
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:13:48.539212
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    ie_object = WallaIE("Walla")
    assert ie_object.ie_key() == 'Walla'
    assert ie_object.ie_id() == 'walla'

# Generated at 2022-06-26 13:13:57.013674
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:01.001219
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:14:02.554260
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w

# Generated at 2022-06-26 13:14:04.565853
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except Exception:
        assert False, 'Unit test for WallaIE constructor raised an exception'

# Generated at 2022-06-26 13:14:16.388492
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for constructor of class WallaIE"""
    ie_Walla = WallaIE()
    assert ie_Walla.ie_key() == 'walla'
    assert ie_Walla.ie_name() == 'Walla!'

# Generated at 2022-06-26 13:14:26.959177
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert walla._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert walla._TEST['info_dict']['id'] == '2642630'
    assert walla._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert walla._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-26 13:14:30.033463
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.SUFFIX == 'walla.co.il'

# Generated at 2022-06-26 13:14:30.912032
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-26 13:14:42.880680
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()
	print(ie)		


# Generated at 2022-06-26 13:14:46.819934
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE()
    assert walla_ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-26 13:14:58.274405
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:15:00.331753
# Unit test for constructor of class WallaIE
def test_WallaIE():
	test_WallaIE.test_WallaIE = WallaIE()


# Generated at 2022-06-26 13:15:01.719251
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global w
    w = WallaIE()

# Generated at 2022-06-26 13:15:03.253409
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:15:05.425442
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie=WallaIE()
    assert isinstance(ie,WallaIE)

# Generated at 2022-06-26 13:15:07.767272
# Unit test for constructor of class WallaIE
def test_WallaIE():
    y = WallaIE('None')
    assert unicode(y, 'utf-8') == 'WallaIE()'

# Generated at 2022-06-26 13:15:09.367613
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:15:10.792427
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:15:33.973424
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for WallaIE"""
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    return ie

# Generated at 2022-06-26 13:15:37.005683
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__.__name__ == 'WallaIE'
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie._TEST == WallaIE._TEST
    assert ie._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert WallaIE.suitable(WallaIE._TEST['url']) == True

# Generated at 2022-06-26 13:15:46.891798
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from sys import argv, exit
    from pytube import YouTube, exceptions
    def usage():
        print("Usage: python %s URL" % argv[0])
        exit(0)

    url = 'https://www.youtube.com/watch?v=OUpoOoyZQO8'
    if len(argv) == 2:
        url = argv[1]
    else:
        usage()

    try:
        yt = YouTube(url)
    except exceptions.PytubeError:
        print("Error: invalid URL")
        usage()

    yt.streams.filter(progressive=True).first().download()

# Generated at 2022-06-26 13:15:50.112333
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    obj=WallaIE()
    res=obj.suitable(url)
    assert res
    res2=obj._real_extract(url)

# Generated at 2022-06-26 13:15:57.743379
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert re.match(ie._VALID_URL, ie._TEST['url'])
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'
    assert ie._TEST['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'
    assert ie._TEST['info_dict']['duration'] == 3600

# Generated at 2022-06-26 13:16:00.787101
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:16:02.673429
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-26 13:16:05.316543
# Unit test for constructor of class WallaIE
def test_WallaIE():
 
    """ Unit test for class WallaIE constructor """
 
    wie = WallaIE()
    expected_values = ["walla.co.il"]
    assert(wie._VALID_URL in expected_values)

# Generated at 2022-06-26 13:16:08.819943
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("WallaIE")
    assert ie.ie_key() == 'Walla'
    assert ie.test()


# Generated at 2022-06-26 13:16:10.793769
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert isinstance(x, WallaIE)

# Generated at 2022-06-26 13:16:56.063303
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('')
    assert ie is not None
    assert ie.url_result('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is not None
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-26 13:16:59.970101
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('https://vod.walla.co.il/video?w=null/null/14169/@@/video/flv_pl')

# Generated at 2022-06-26 13:17:04.798534
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
        extractor = WallaIE(url)
    except AssertionError as e:
        if e.args[0] != 'Invalid URL':
            raise e

# Generated at 2022-06-26 13:17:07.884838
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE()
    assert isinstance(walla_ie, InfoExtractor)


# Generated at 2022-06-26 13:17:14.199067
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._SUBTITLE_LANGS == {'עברית': 'heb'}



# Generated at 2022-06-26 13:17:15.037019
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:17:25.367307
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie1 = WallaIE() # check that the class is instanciated ok
    assert(ie1.get_username() == None) # check that the default value is None
    assert(ie1.get_password() == None) # check that the default value is None
    ie2 = WallaIE('test_user', 'test_pass') #check that it can be instanciated with a username and a password
    assert(ie2.get_username() == 'test_user') # check that the username is correct
    assert(ie2.get_password() == 'test_pass') # check that the password is correct

# Generated at 2022-06-26 13:17:37.259992
# Unit test for constructor of class WallaIE

# Generated at 2022-06-26 13:17:41.521165
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.ext == 'flv')
    assert(ie.subtitle_langs == ie._SUBTITLE_LANGS)

# Generated at 2022-06-26 13:17:42.917607
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w

# Generated at 2022-06-26 13:19:31.437570
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE()(url);

# Generated at 2022-06-26 13:19:35.829216
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE.WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract()

# Generated at 2022-06-26 13:19:40.626899
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # verifying whether the following raises exception or not
    # testing with .to_screen() method
    try:
        ie = WallaIE()
        ie.to_screen();
    except:
        assert False
    assert True

# Generated at 2022-06-26 13:19:53.420691
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('walla', 'vod.walla.co.il', 'testid1', 'testid2')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:20:03.887022
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    expected_display_id = "one-direction-all-for-one"
    expected_video_id = "2642630"
    expected_duration = 3600
    expected_title = "וואן דיירקשן: ההיסטריה"

    walla = WallaIE()

    assert walla._VALID_URL.match(url) is not None
    meta = walla.extract(url)
    assert meta['video_id'] == expected_video_id
    assert meta['display_id'] == expected_display_id
    assert meta['duration'] == expected_duration
    assert meta['title'] == expected_title

# Generated at 2022-06-26 13:20:06.015782
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    print(ie.IE_NAME)


# Generated at 2022-06-26 13:20:10.621322
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    print(ie.__dict__)
    return ie

# Generated at 2022-06-26 13:20:15.892763
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert '2642630' == ie._VALID_URL
    assert 'one-direction-all-for-one' == ie._TEST
    assert '2642630' == ie._SUBTITLE_LANGS
    assert 'one-direction-all-for-one' == ie._real_extract
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert '2642630' == ie._VALID_URL
    assert 'one-direction-all-for-one' == ie._TEST
    assert '2642630' == ie._SUBTITLE_LANGS

# Generated at 2022-06-26 13:20:24.907523
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test that checks that the constructor, input_url and download_link work.
    """

# Generated at 2022-06-26 13:20:27.660801
# Unit test for constructor of class WallaIE
def test_WallaIE():
	test = WallaIE()
	test.test()
	test.setTest('WallaIE')
	test.startTest()
	test.endTest()