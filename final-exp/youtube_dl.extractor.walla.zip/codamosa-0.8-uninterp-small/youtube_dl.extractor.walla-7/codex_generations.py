

# Generated at 2022-06-26 13:12:51.409502
# Unit test for constructor of class WallaIE
def test_WallaIE():
    verify.accumulate_examples = False
    verify(WallaIE)

    if __name__ == "__main__":
        import unittest
        unittest.main()

# Generated at 2022-06-26 13:12:59.948379
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        walla_i_e_0 = WallaIE()
        if walla_i_e_0 is None:
            print ("Unit test for WallaIE constructor: FAIL")
        else:
            print ("Unit test for WallaIE constructor: PASS")
    except:
        print ("Unit test for WallaIE constructor: FAIL")


# Generated at 2022-06-26 13:13:11.123256
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # To make sure the class constructor of WallaIE can be called
    foo = WallaIE()

    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)', \
        'To make sure the class attribute _VALID_URL is correct'

    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb', \
        'To make sure the class attribute _SUBTITLE_LANGS is correct'


# Generated at 2022-06-26 13:13:16.189309
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:13:19.762714
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # construct an object WallaIE
    walla_i_e = WallaIE()

test_WallaIE()

# Generated at 2022-06-26 13:13:20.846111
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()
    assert walla_i_e.extractor  # it should return True


# Generated at 2022-06-26 13:13:21.408960
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert callable(WallaIE)


# Generated at 2022-06-26 13:13:22.231060
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-26 13:13:34.931069
# Unit test for constructor of class WallaIE
def test_WallaIE():

    walla_i_e = WallaIE()

    assert walla_i_e.url_result('http://walla.co.il/israel/walla_vod_30/2651524/walla_vod_30_ozodot_mishpaot_26_10_2016', 'WallaIE') == 'http://vod.walla.co.il/movie/2651524/walla_vod_30_ozodot_mishpaot_26_10_2016', 'url_result failed to extract the right display_id'


# Generated at 2022-06-26 13:13:37.684506
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla_i_e = WallaIE()
    r = walla_i_e.suitable(url)
    assert r == True


# Generated at 2022-06-26 13:13:54.836177
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert "WallaIE" in repr(ie)
    assert ie.SUFFIX == 'co.il'
    assert ie.IE_NAME == 'walla'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:13:56.377221
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:13:58.314020
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(WallaIE, InfoExtractor)

# Generated at 2022-06-26 13:14:01.930375
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:14:03.921453
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('',{})
    assert ie.__class__.__name__ == 'WallaIE'

# Generated at 2022-06-26 13:14:06.158684
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.get_ie_key() == 'walla'

# Generated at 2022-06-26 13:14:08.395053
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    print(ie.__dict__)


# Generated at 2022-06-26 13:14:16.392431
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert w.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert w.smuggle_url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert w.video_id == '2642630'
    assert w.display_id == 'one-direction-all-for-one'

# Generated at 2022-06-26 13:14:20.543789
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.video_id == '2642630'
    assert ie.display_id == 'one-direction-all-for-one'

# Generated at 2022-06-26 13:14:22.459530
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE()
    assert isinstance(i, WallaIE)

# Generated at 2022-06-26 13:14:37.171090
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(1,2)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST.keys() == ['url', 'info_dict', 'params']
    assert ie._SUBTITLE_LANGS == { 'עברית': 'heb', }


# Generated at 2022-06-26 13:14:39.650786
# Unit test for constructor of class WallaIE
def test_WallaIE():
    m = WallaIE()
    assert m is not None


# Generated at 2022-06-26 13:14:50.440067
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # This is the result of running WallaIE.extract() and calling json.dumps() on the result.
    # It is valid python, but not valid json.  So, we have to manually rearrange the dictionary here.

# Generated at 2022-06-26 13:14:51.778906
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-26 13:14:53.131535
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(downloader=None)

# Generated at 2022-06-26 13:14:55.754480
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:14:56.763579
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:14:58.037741
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()._TEST

# Generated at 2022-06-26 13:15:01.857444
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE()._real_extract(url)

# Generated at 2022-06-26 13:15:04.327582
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL



# Generated at 2022-06-26 13:15:31.508371
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w=WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:15:38.785696
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj.IE_NAME == 'walla'
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:15:49.466251
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for testing the constructor of WallaIE"""
    import itertools
    import httplib
    import urllib2
    import cookielib
    import urllib
    import re
    import time
    import hashlib
    import json
    import random
    import os
    import sys
    import requests
    import re
    import base64
    import zlib
    import binascii
    import HTMLParser
    import urlparse
    import urlgrabber
    import subprocess
    from xml.dom import minidom
    from xml.etree import ElementTree
    import gzip
    import xml.sax
    import cStringIO
    import textwrap
    import shutil
    import errno
    import tempfile
    import fileinput
    import string
    import calendar
    import getpass
    import multip

# Generated at 2022-06-26 13:15:51.124459
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().extractor_key == 'walla'
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-26 13:15:51.971481
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:15:53.295994
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:15:55.427185
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:15:58.984675
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video = WallaIE("https://vod.walla.co.il/movie/3263917/inferno")
    assert "vod.walla.co.il" in video.url

# Generated at 2022-06-26 13:16:05.120930
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    w.extract(url)
    assert w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:16:06.965155
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.SUCCEEDED

# Generated at 2022-06-26 13:16:55.645170
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.INFO_TEMPLATE == '%s - %s'



# Generated at 2022-06-26 13:16:57.608232
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('www.walla.co.il', 'video_id')

# Generated at 2022-06-26 13:17:05.369854
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie.MAIN_URL == 'http://video2.walla.co.il/'
    assert ie.VALID_URL == ie._VALID_URL
    assert ie.TEST == ie._TEST
    assert ie.__name__ == 'Walla'
    assert ie.__doc__ == 'Walla! VOD (get.walla.co.il)'

# Generated at 2022-06-26 13:17:08.896160
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:17:14.870727
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.IE_NAME == 'walla:video')
    assert(ie.IE_DESC == 'Walla! video')
    assert(ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')


# Generated at 2022-06-26 13:17:26.640875
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:17:34.757780
# Unit test for constructor of class WallaIE
def test_WallaIE():
    c = WallaIE()
    c.suite()

suite = unittest.makeSuite(WallaIE)
suite.addTest(doctest.DocTestSuite(WallaIE))

if __name__ == "__main__":
    runner = unittest.TextTestRunner(verbosity = 2)
    runner.run(suite)

# Generated at 2022-06-26 13:17:39.056433
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert instance

# Generated at 2022-06-26 13:17:48.147391
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-26 13:17:50.307173
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for 'WallaIE()'
    ie = WallaIE()

# Generated at 2022-06-26 13:19:40.998235
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.get_description() == 'Download videos from walla.co.il')
    assert(ie.get_domain() == 'vod.walla.co.il')
    assert(ie.get_extractor_key() == 'walla')
    assert(ie.get_name() == 'Walla!')

# Generated at 2022-06-26 13:19:46.021801
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert(re.match(WallaIE._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is not None)

# Generated at 2022-06-26 13:19:54.673303
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._TEST['info_dict'] == {
        'id': '2642630',
        'display_id': 'one-direction-all-for-one',
        'ext': 'flv',
        'title': 'וואן דיירקשן: ההיסטריה',
        'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        'thumbnail': r're:^https?://.*\.jpg',
        'duration': 3600,
    }

# Generated at 2022-06-26 13:19:55.635741
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE

# Generated at 2022-06-26 13:19:56.972124
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    assert ie is not None

# Generated at 2022-06-26 13:19:58.381334
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE


# Generated at 2022-06-26 13:19:59.181122
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:20:03.091761
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST == WallaIE._TEST
    assert WallaIE()._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert WallaIE()._real_extract == WallaIE._real_extract

# Generated at 2022-06-26 13:20:13.380366
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    instance = ie.extract(test_url)

    # Test the constructor
    assert(isinstance(ie, InfoExtractor))
    assert(ie.VALID_URL == ie._VALID_URL)
    assert(ie.TEST == ie._TEST)
    assert(ie.IE_NAME == 'WallaIE')
    assert(ie.NETRC_MACHINE == 'walla')
    assert(ie.subtitle == ie._SUBTITLE_LANGS)
    assert(ie.real_extract == ie._real_extract)

# Generated at 2022-06-26 13:20:23.213388
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("Unit test for WallaIE")
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'
