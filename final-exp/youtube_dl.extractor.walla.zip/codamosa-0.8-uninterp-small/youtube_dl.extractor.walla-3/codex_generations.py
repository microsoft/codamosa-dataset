

# Generated at 2022-06-26 13:12:50.021440
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()

# Generated at 2022-06-26 13:12:51.834543
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Just check if it's created
    assert WallaIE()

# Generated at 2022-06-26 13:12:55.741460
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE
    assert walla_i_e


# Generated at 2022-06-26 13:12:57.132914
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_1 = WallaIE()

# Generated at 2022-06-26 13:12:59.675340
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_0 = WallaIE()
    return walla_i_e_0

# Generated at 2022-06-26 13:13:01.260307
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_0 = WallaIE()


# Generated at 2022-06-26 13:13:04.222685
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()
    return walla_i_e


# Generated at 2022-06-26 13:13:04.717706
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-26 13:13:05.539226
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert test_case_0()


# Generated at 2022-06-26 13:13:06.961586
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE()
    assert walla_ie
    return



# Generated at 2022-06-26 13:13:20.816664
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check for the a testing URL
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    url_testing = WallaIE._VALID_URL
    if re.match(url_testing, url):
        ret = WallaIE._real_extract(url)
        assert ret.items() >= WallaIE._TEST.items()

# Generated at 2022-06-26 13:13:24.542283
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for constructor of class WallaIE"""
    # test correct initialization
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.get_id('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:13:32.487276
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test initialization of the class in case of a valid URL
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.__class__ is WallaIE
    # Test initialization of the class in case of a invalid URL
    ie = WallaIE('http://example.com')
    assert ie.__class__ is not WallaIE

# Generated at 2022-06-26 13:13:36.580353
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie is not None


# Generated at 2022-06-26 13:13:41.800904
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = WallaIE._VALID_URL % {'id': 2642630, 'display_id': 'one-direction-all-for-one'}

# Generated at 2022-06-26 13:13:53.030459
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = {"_SUBTITLE_LANGS" : {'עברית' : 'heb'} }
    w = WallaIE(t)
    assert w.test() == False
    t = {"_SUBTITLE_LANGS" : {'עברית' : 'heb'}  , '_VALID_URL' : r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'}
    w = WallaIE(t)
    assert w.test() == True

# Generated at 2022-06-26 13:14:06.081755
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:09.550045
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """test constructor of class WallaIE"""
    assert WallaIE(WallaIE._VALID_URL).ie_key() == 'Walla'


# Generated at 2022-06-26 13:14:17.788532
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:18.591831
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE()

# Generated at 2022-06-26 13:14:34.129411
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_inst = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', {})
    assert re.match(WallaIE._VALID_URL, test_inst._get_url())

# Generated at 2022-06-26 13:14:35.826778
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    print (a.get_class())
    print (a._VALID_URL)
    print (a.IE_NAME)

# Generated at 2022-06-26 13:14:38.025245
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-26 13:14:45.094727
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_ie = WallaIE('some_url')
    res = video_ie._build_rx(re.compile('(?P<tag>)'), 'tag')
    assert res
    res = video_ie._build_rx(re.compile('(?P<tag>)'), 'tag', fatal=False)
    assert res



# Generated at 2022-06-26 13:14:50.182626
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ieObj = WallaIE()
    if ieObj is None:
        print("Unit test for WallaIE failed - failed to create object")
        return False
    return True

# Generated at 2022-06-26 13:14:53.129963
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is not None

# Generated at 2022-06-26 13:14:54.025794
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:14:56.182103
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    assert(re.match(WallaIE._VALID_URL, ie._VALID_URL))

# Generated at 2022-06-26 13:14:59.113757
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_One = WallaIE(None)
    assert test_One


if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-26 13:15:01.787339
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    asser

# Generated at 2022-06-26 13:15:23.080165
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert WallaIE._VALID_URL == ie._VALID_URL

# Generated at 2022-06-26 13:15:27.293853
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Correct format
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    # Incorrect format
    assert WallaIE._VALID_URL != r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>+)'


# Generated at 2022-06-26 13:15:28.578912
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None, None)

# Generated at 2022-06-26 13:15:30.200809
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global t
    t = WallaIE()

# Generated at 2022-06-26 13:15:34.887573
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'Walla'
    assert ie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:15:43.761096
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Testing constructor of class WallaIE"""
    assert WallaIE._VALID_URL.match("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one") is not None
    assert WallaIE._VALID_URL.match("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one") is not None


# Generated at 2022-06-26 13:15:45.978868
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE()._real_extract(url)

# Generated at 2022-06-26 13:15:49.722150
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:15:58.499226
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Params: url, IE_name, expected_IE_name
    # Note that IE_name should be in this form:
    #     site-subclass, like 'walla-WallaIE'
    # We need to check if 'walla-WallaIE' is recognized as a subclass of WallaIE
    testcases = [('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
                  'walla-WallaIE', 'walla-WallaIE')]
    for url, IE_name, expected_IE_name in testcases:
        info_dict = InfoExtractor.gen_extractor_classes()[IE_name]._real_extract(
            InfoExtractor(None), url)

# Generated at 2022-06-26 13:16:07.750986
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert re.match(ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._extract_id('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == ('2642630', 'one-direction-all-for-one')
    assert ie._extract_id('http://vod.walla.co.il/movie/1234567890/some-title') == ('1234567890', 'some-title')
    assert ie._extract_id('http://vod.walla.co.il/movie/1234567890/some-title/more-title') == ('1234567890', 'some-title')

# Generated at 2022-06-26 13:16:51.398097
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test for constructor of class WallaIE"""
    # Constructor test
    WallaIE(None)

# Generated at 2022-06-26 13:16:59.440945
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE({}, {'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'})

    assert ie._VALID_URL == '^https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)$'

# Generated at 2022-06-26 13:17:00.809174
# Unit test for constructor of class WallaIE
def test_WallaIE():
    parser = WallaIE("")
    assert parser

# Generated at 2022-06-26 13:17:04.051398
# Unit test for constructor of class WallaIE

# Generated at 2022-06-26 13:17:07.282946
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(WallaIE._TEST['url'])

# Generated at 2022-06-26 13:17:08.234074
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE()

# Generated at 2022-06-26 13:17:09.661729
# Unit test for constructor of class WallaIE
def test_WallaIE():
    r = WallaIE()
    assert r is not None

# Generated at 2022-06-26 13:17:11.570860
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-26 13:17:13.666781
# Unit test for constructor of class WallaIE
def test_WallaIE():
    unit_test_IE = WallaIE()

# Generated at 2022-06-26 13:17:17.399726
# Unit test for constructor of class WallaIE
def test_WallaIE():
	name = 'Walla'
	ie = WallaIE()
	assert ie._VALID_URL == WallaIE._VALID_URL
	assert ie._TEST == WallaIE._TEST
	assert ie._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
	assert ie.name == name
	assert ie.ie_key() == name.lower()
	assert ie.ie_key() == 'walla'
	assert ie.ie_key() != 'wallawalla'

# Test for .extract() method of WallaIE

# Generated at 2022-06-26 13:19:03.771230
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:19:07.924832
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(url)

# Generated at 2022-06-26 13:19:12.522078
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract()

# Generated at 2022-06-26 13:19:22.093475
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE(None)

    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    mobj = re.match(w._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')

    video = w._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id)

    item = video.find('./items/item')

    title = xpath_text(item, './title', 'title')
    description = xpath_text(item, './synopsis', 'description')
    thumbnail = xpath

# Generated at 2022-06-26 13:19:33.582279
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # First test case of WallaIE constructor
    ie = WallaIE()
    res = ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert res['id'] == '2642630'
    assert res['display_id'] == 'one-direction-all-for-one'
    assert res['ext'] == 'flv'
    assert res['title'] == 'וואן דיירקשן: ההיסטריה'
    assert res['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert re.match(r'^https?://.*\.jpg', res['thumbnail'])

# Generated at 2022-06-26 13:19:43.711542
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:19:54.132017
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create test data
    from .common import testdata

    url, _ = testdata.get('walla.co.il_video_2642630_one-direction-all-for-one', True)

    # Run test
    ie = WallaIE(TestOption({'verbose' : True}))
    video = ie.extract(url)

    assert video
    assert video['id'] == '2642630'
    assert video['display_id'] == 'one-direction-all-for-one'
    assert video['ext'] == 'flv'
    assert video['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-26 13:19:56.643389
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Assert that the constructor works without raising any exception
    assert ie

# Generated at 2022-06-26 13:20:00.194580
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Constructor of class WallaIE
    """

    # Default arguments.
    w = WallaIE()

    # Another arguments.
    w = WallaIE(url="")

# Generated at 2022-06-26 13:20:05.988719
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'
    assert ie._TEST