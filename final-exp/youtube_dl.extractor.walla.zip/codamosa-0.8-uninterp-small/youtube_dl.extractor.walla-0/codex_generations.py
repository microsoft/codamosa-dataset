

# Generated at 2022-06-26 13:12:49.936445
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()

# Generated at 2022-06-26 13:12:58.503421
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_0 = WallaIE()
    assert walla_i_e_0._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert walla_i_e_0._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert walla_i_e_0._TEST['info_dict']['id'] == '2642630'
    assert walla_i_e_0._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-26 13:13:00.278986
# Unit test for constructor of class WallaIE
def test_WallaIE():

    verify_walla_i_e_0 = WallaIE()

# Generated at 2022-06-26 13:13:04.577997
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import InfoExtractor
    from .walla import WallaIE
    from ..utils import (
        xpath_text,
        int_or_none,
    )

# Generated at 2022-06-26 13:13:05.048640
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-26 13:13:06.802763
# Unit test for constructor of class WallaIE

# Generated at 2022-06-26 13:13:08.889894
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE.__name__ == 'WallaIE')
    walla_i_e = WallaIE()


# Generated at 2022-06-26 13:13:17.044027
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print ('Testing for class WallaIE')
    walla_i_e_0 = WallaIE()
    assert(WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(WallaIE()._SUBTITLE_LANGS == {'עברית': 'heb', })


# Generated at 2022-06-26 13:13:19.128474
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_0 = WallaIE()

# Generated at 2022-06-26 13:13:19.980479
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:13:28.767749
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'

# Generated at 2022-06-26 13:13:37.066113
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    obj = WallaIE()
    mobj = re.match(obj._VALID_URL, url)
    obj.video_id = mobj.group('id')
    obj.display_id = mobj.group('display_id')
    obj._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % obj.video_id,
        obj.display_id)

# Generated at 2022-06-26 13:13:38.437753
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)

# Generated at 2022-06-26 13:13:46.942275
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"

# Generated at 2022-06-26 13:13:56.458727
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:07.411003
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE.ie_key('walla:movie:2642630')
    assert ie.name == 'Walla'
    assert ie.url_re == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>[^/]+)'
    assert ie.test_video_re == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:14:09.612960
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from __main__ import WallaIE
    assert WallaIE(None)._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:12.443931
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaie = WallaIE()
    assert 'WallaIE' == wallaie.IE_NAME
    assert 'Walla!' == wallaie.IE_DESC
    assert 'Walla!' == wallaie.ie_key()


# Generated at 2022-06-26 13:14:21.215167
# Unit test for constructor of class WallaIE

# Generated at 2022-06-26 13:14:26.938302
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_cases = [
        r'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ]
    for test_case in test_cases:
        extractor = WallaIE()
        extractor._real_initialize()
        extractor._real_extract(test_case)

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-26 13:14:38.025428
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert ('WallaIE' in globals()) == True

# Generated at 2022-06-26 13:14:49.554007
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert w._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert w._TEST['info_dict']['id'] == '2642630'
    assert w._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert w._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-26 13:14:54.560115
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert walla_ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:57.111961
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().IE_NAME == 'walla:video'
    url = WallaIE()._VALID_URL
    assert re.compile(url).match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert WallaIE()._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:15:06.077770
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://vod.walla.co.il/movie.2642630/one-direction-all-for-one')
    assert not ie.suitable('http://walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:15:06.807740
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:15:09.368407
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie2 = WallaIE()
    assert isinstance(ie2._SUBTITLE_LANGS, dict)

# Generated at 2022-06-26 13:15:10.793192
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:15:12.140562
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-26 13:15:15.062630
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Make sure the class can be created
    ie = WallaIE()

# Generated at 2022-06-26 13:15:37.326518
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert test_obj.url, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert test_obj.video_id, '2642630'
    assert test_obj.display_id, 'one-direction-all-for-one'

# Generated at 2022-06-26 13:15:40.011878
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._TEST['url'] == ie._VALID_URL

# Generated at 2022-06-26 13:15:41.174485
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-26 13:15:50.338481
# Unit test for constructor of class WallaIE

# Generated at 2022-06-26 13:16:01.527976
# Unit test for constructor of class WallaIE

# Generated at 2022-06-26 13:16:02.343089
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:16:05.431899
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url='http://vod.walla.co.il/?w=null/null/1626108/@@/video/flv_pl'
    x=WallaIE()
    print(x.download(url))
    
test_WallaIE()

# Generated at 2022-06-26 13:16:09.523946
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # generation of the instance of class WallaIE 
    wallaIE = WallaIE()
    # test that the instance has been successfully constructed
    assert wallaIE

# Generated at 2022-06-26 13:16:13.052653
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    video = ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:16:17.017854
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:17:01.710722
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from walla_tests.walla_test_params import WallaTestParams
    WallaTestParams().add_completed_test(WallaIE._TEST)

# Generated at 2022-06-26 13:17:03.116864
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('WallaIE')

# Generated at 2022-06-26 13:17:06.022102
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('any')
    assert isinstance(ie, WallaIE)
    assert ie.SUCCESS

    ie = WallaIE('any', 'any', 'any')
    assert isinstance(ie, WallaIE)
    assert ie.SUCCESS



# Generated at 2022-06-26 13:17:08.894570
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-26 13:17:14.951053
# Unit test for constructor of class WallaIE
def test_WallaIE():
	if not hasattr(WallaIE, '_download_xml'):
		WallaIE._download_xml = lambda *args, **kwargs: ''

	assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one').get_video_id() == '2642630'
	assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one').get_title() == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-26 13:17:16.897605
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:17:22.229713
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
        print ('walla ie constructor test: succeeded!')
    except AssertionError as e:
        print ('walla ie constructor test: FAILED!')
        print ('walla ie constructor test exception: %s' % (e))

# Generated at 2022-06-26 13:17:24.760765
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()(url='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:17:37.037005
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == re.compile(r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-26 13:17:47.654671
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:19:37.897353
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(isinstance (ie, InfoExtractor))


# Generated at 2022-06-26 13:19:38.737944
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()

# Generated at 2022-06-26 13:19:47.114317
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from walla import WallaIE
    a = WallaIE()
    assert(a.get_name() == 'walla')
    assert(a.get_description() == 'Walla! VOD')
    assert(a.get_supported_categories() == [u'vod'])
    assert(a.get_available_quality_levels() == ['640P', '360P', '720P', 'HD'])

# Generated at 2022-06-26 13:19:50.313037
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:19:51.651206
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj

# Generated at 2022-06-26 13:19:53.694020
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE()
    True

# Generated at 2022-06-26 13:20:01.112139
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie._VALID_URL, re._pattern_type)
    assert ie._VALID_URL.match(WallaIE._TEST['url'])
    assert isinstance(ie._SUBTITLE_LANGS, dict)
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'


# Generated at 2022-06-26 13:20:12.875730
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # assert ie._TEST['info_dict'] == 'md5:de9e2512a92442574cdb0913c49bc4d8' # TODO-function-test
    assert ie._TEST['params'] == {
            # rtmp download
            'skip_download': True,
        }
    # test function _real_extract
    ie = WallaIE(None)
    ie._download

# Generated at 2022-06-26 13:20:24.054701
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert ie._TEST['info_dict']['id'] == "2642630"
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == "flv"
   

# Generated at 2022-06-26 13:20:33.037477
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie._download_xml = 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl'
    ie.display_id = 'one-direction-all-for-one'
    ie.video_id = '2642630'
    ie._real_extract(ie._VALID_URL)