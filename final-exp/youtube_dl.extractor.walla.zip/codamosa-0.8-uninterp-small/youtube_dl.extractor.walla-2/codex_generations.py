

# Generated at 2022-06-26 13:12:53.103753
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_0 = WallaIE()
# http://vod.walla.co.il/movie/2642630/one-direction-all-for-one
# http://vod.walla.co.il/item/2642630/one-direction-all-for-one


# Generated at 2022-06-26 13:12:58.784316
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-26 13:12:59.816669
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()

# Generated at 2022-06-26 13:13:01.146194
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE() != None)


# Generated at 2022-06-26 13:13:03.017543
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_case_0()

# Generated at 2022-06-26 13:13:08.403015
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla_i_e = WallaIE()
    walla_i_e._real_extract(url)


# Generated at 2022-06-26 13:13:12.327664
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla_i_e = WallaIE()
    walla_i_e.extract(url)



# Generated at 2022-06-26 13:13:15.822676
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #
    # Run all the constructor test cases here
    #
    test_case_0()

if __name__ == '__main__':
    #
    # Run all the constructor test cases here
    #
    test_WallaIE()

# Generated at 2022-06-26 13:13:16.642235
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-26 13:13:19.055549
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()



# Generated at 2022-06-26 13:13:25.793106
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()

# Generated at 2022-06-26 13:13:36.444187
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie.ie_id() == 'walla'
    ext = ie._VALID_URL.rsplit('.', 1)[1]
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+).%s' % ext

# Generated at 2022-06-26 13:13:37.654233
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except:
        raise Exception('WallaIE constructor failed!!!')

# Generated at 2022-06-26 13:13:40.949229
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL
    assert ie._TEST
    assert ie._SUBTITLE_LANGS

# Generated at 2022-06-26 13:13:43.562889
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    # should not raise
    WallaIE().suitable(url)

# Generated at 2022-06-26 13:13:46.821421
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:13:52.874570
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'http://vod.walla.co.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:05.237809
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['params']['skip_download'] == True
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'
    

# Generated at 2022-06-26 13:14:06.559883
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:14:15.576078
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test URL
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    assert ie.__class__.__name__ == 'WallaIE'
    assert ie.urls[0] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.extract_info('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')['id'] == '2642630'

# Generated at 2022-06-26 13:14:26.680898
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None, {})

# Generated at 2022-06-26 13:14:28.560675
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE

# Generated at 2022-06-26 13:14:33.149030
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL
    assert WallaIE._TEST
    assert WallaIE._SUBTITLE_LANGS

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-26 13:14:35.659857
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') # bool(True)

# Generated at 2022-06-26 13:14:37.381329
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:14:49.055206
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:51.188507
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor of class WallaIE
    r = WallaIE()
    assert r._VALID_URL == WallaIE._VALID_URL
    assert r._TEST == WallaIE._TEST
    assert r._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS

# Generated at 2022-06-26 13:14:52.553977
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for contructor of class WallaIE
    """
    WallaIE()

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-26 13:15:00.008777
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:15:10.246113
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST.get('url', False) == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST.get('info_dict', False).get('id', False) == '2642630'
    assert ie._TEST.get('info_dict', False).get('display_id', False) == 'one-direction-all-for-one'
    assert ie._TEST.get('info_dict', False).get('ext', False) == 'flv'
    assert ie._TEST.get

# Generated at 2022-06-26 13:15:31.138257
# Unit test for constructor of class WallaIE
def test_WallaIE():
   ie = WallaIE()
   assert(isinstance(ie, InfoExtractor))

# Generated at 2022-06-26 13:15:35.365076
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    url = 'http://vod.walla.co.il/movie/' + video_id + '/' + display_id
    return WallaIE._TEST

# Generated at 2022-06-26 13:15:37.593281
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla != None


# Main method

# Generated at 2022-06-26 13:15:48.823469
# Unit test for constructor of class WallaIE
def test_WallaIE():
    check_Walla = WallaIE('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl').result()
    assert check_Walla['id'] == '2642630'
    assert check_Walla['display_id'] == 'one-direction-all-for-one'
    assert check_Walla['ext'] == 'flv'
    assert check_Walla['title'] == 'וואן דיירקשן: ההיסטריה'
    assert check_Walla['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert check_Walla['thumbnail'] == r're:^https?://.*\.jpg'

# Generated at 2022-06-26 13:15:58.113559
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = WallaIE()._TEST.get('url')
    test_input = WallaIE()._TEST.get('input')
    test_info_dict = WallaIE()._TEST.get('info_dict')

    test_downloader = WallaIE(test_url, test_input)

    test_downloader._real_extract(WallaIE._VALID_URL)
    test_downloader._real_initialize(WallaIE._VALID_URL)
    test_downloader._real_extract(WallaIE._VALID_URL)
    test_downloader._real_extract(WallaIE._VALID_URL)
    test_downloader._real_extract(WallaIE._VALID_URL)


# Generated at 2022-06-26 13:16:05.239465
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one");
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one");
    assert ie._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)";

# Generated at 2022-06-26 13:16:15.757476
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._VALID_URL == 'http://vod.walla.co.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    mobj = re.match('http://vod.walla.co.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)', url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    print(video_id)

# Generated at 2022-06-26 13:16:22.740558
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._VALID_URL == \
           r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:16:26.057162
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('id', 'display_id', 'title', 'description', 'thumbnail', 'duration', ['formats'], ['subtitles'])

# Generated at 2022-06-26 13:16:27.294649
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # TODO: implement test for constructor of WallaIE class
    pass

# Generated at 2022-06-26 13:17:09.732640
# Unit test for constructor of class WallaIE
def test_WallaIE():
        walla = WallaIE()
        print("%r" % walla)

    # Unit test for extract method of class WallaIE

# Generated at 2022-06-26 13:17:18.074219
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:17:27.588359
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import re
    _VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:17:29.254618
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-26 13:17:33.942772
# Unit test for constructor of class WallaIE
def test_WallaIE():
	init = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
	assert init.__class__.__name__ == "WallaIE"

# Generated at 2022-06-26 13:17:35.600075
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:17:41.725971
# Unit test for constructor of class WallaIE
def test_WallaIE():
    was_run  = False
    try:
        WallaIE()
        was_run = True
    except:
        # Do not fail on import errors from rtmpdump:
        # ModuleNotFoundError: No module named 'rtmpdump'
        pass
    return was_run

# Generated at 2022-06-26 13:17:42.555489
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE()

# Generated at 2022-06-26 13:17:43.488240
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:17:49.387292
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)

    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:19:36.814014
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE()
    assert info_extractor.test_WallaIE()

# Generated at 2022-06-26 13:19:39.303838
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suite()


# Generated at 2022-06-26 13:19:40.633077
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None

# Generated at 2022-06-26 13:19:44.298752
# Unit test for constructor of class WallaIE
def test_WallaIE():
    yt = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:19:45.170679
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:19:51.845416
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.VALID_URL == WallaIE._VALID_URL
    assert ie.TEST == WallaIE._TEST
    assert ie.__dict__['_SUBTITLE_LANGS'] == WallaIE._SUBTITLE_LANGS

# Generated at 2022-06-26 13:19:58.911999
# Unit test for constructor of class WallaIE
def test_WallaIE():
    if sys.version_info >= (3,0):
        def decode_data(data):
            return data.decode('UTF-8')

    test_video = WallaIE(decode_data(b'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'))


# Generated at 2022-06-26 13:20:00.259311
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('Walla')

# Generated at 2022-06-26 13:20:01.449344
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)


# Generated at 2022-06-26 13:20:11.921201
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from youtube_dl.downloader import YoutubeDL
    from youtube_dl.extractor import gen_extractors
    from youtube_dl.urlorlist import test_url_or_list
    d = YoutubeDL()
    d.add_info_extractor(WallaIE)
    gen_extractors(d)
    #TODO: Add more tests
    result = test_url_or_list(d, ['http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'])
    assert len(result) == 1
    assert result[0]['id'] == '2642630'