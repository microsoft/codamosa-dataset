

# Generated at 2022-06-26 13:12:57.460522
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == re.compile(r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-26 13:12:58.502228
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_0 = WallaIE()

# Generated at 2022-06-26 13:12:59.816985
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() != None

# Generated at 2022-06-26 13:13:12.670026
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:13:14.100861
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_1 = WallaIE()

# Generated at 2022-06-26 13:13:15.796834
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_case_0()

# Generated at 2022-06-26 13:13:18.121566
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None


# Generated at 2022-06-26 13:13:21.905439
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()
    walla_i_e.suitable("https://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:13:23.329123
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()


# Generated at 2022-06-26 13:13:24.945514
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test case #0
    test_case_0()

# Generated at 2022-06-26 13:13:39.578613
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    w._real_extract(url)

# Generated at 2022-06-26 13:13:41.555041
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_1 = WallaIE()



# Generated at 2022-06-26 13:13:50.189941
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla_i_e_0 = WallaIE()
    result_0 = walla_i_e_0._real_extract(url)
# This test passes
# assert result_0 == expected_0
#
# # Unit test of _real_extract 

# Generated at 2022-06-26 13:13:52.174105
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Case 1: no parameter
    assert WallaIE() is not None

# Generated at 2022-06-26 13:13:54.173584
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert test_case_0() == None


# Generated at 2022-06-26 13:13:55.646291
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert callable(WallaIE)


# Generated at 2022-06-26 13:13:58.161485
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_0 = WallaIE()


# Generated at 2022-06-26 13:14:00.462926
# Unit test for constructor of class WallaIE
def test_WallaIE():
    constructor_test_helper(WallaIE)


# Generated at 2022-06-26 13:14:03.440992
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert issubclass(WallaIE, InfoExtractor), "Class WallaIE should subclass class InfoExtractor"


# Generated at 2022-06-26 13:14:10.542894
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert len(WallaIE.__doc__) > 0
    assert len(WallaIE.IE_DESC) > 0
    assert WallaIE.IE_NAME != ''
    assert WallaIE.IE_NAME != None
    assert WallaIE.VALID_URL != ''
    assert WallaIE.VALID_URL != None


# Generated at 2022-06-26 13:14:22.469408
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE == WallaIE()


# Generated at 2022-06-26 13:14:24.020624
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Testing url of url class WallaIE

# Generated at 2022-06-26 13:14:36.763557
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.extractor import TwitchIE
    from youtube_dl.extractor import VineIE
    from youtube_dl.extractor import InstagramIE
    from youtube_dl.extractor import DailymotionIE
    from youtube_dl.extractor import MetacafeIE
    from youtube_dl.extractor import FacebookIE
    from youtube_dl.extractor import YoukuIE
    from youtube_dl.extractor import VimeoIE
    from youtube_dl.extractor import SoundcloudIE
    from youtube_dl.extractor import BandcampIE
    from youtube_dl.extractor import GenericIE
    from youtube_dl.extractor import LiveLeakIE
    from youtube_dl.extractor import MNetIE
    from youtube_dl.extractor import TEDIE

# Generated at 2022-06-26 13:14:48.537129
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:49.844879
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()

# Generated at 2022-06-26 13:14:52.414748
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # One argument:
    # url: URL of Walla video
    if len(sys.argv) is 2:
        walla_i_e_1 = WallaIE(sys.argv[1])

# Generated at 2022-06-26 13:14:54.369445
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() == WallaIE()


# Generated at 2022-06-26 13:14:55.791770
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert (isinstance(WallaIE, object))


# Generated at 2022-06-26 13:15:08.440408
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("Here are some tests for WallaIE()\n")
    print("Here is a test for both __init__ and _real_extract:\n")
    walla_i_e_1 = WallaIE()
    # both methods should return a new object, hence the special characters
    assert walla_i_e_1 is not None, "walla_i_e_1 is None, it should be a new object!!"
    assert walla_i_e_1._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one") is not None, "_real_extract returned None instead of a dict"
    print("passed __init__ and _real_extract\n")
    print("Here is test for _real_extract\n")

# Generated at 2022-06-26 13:15:11.924274
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_1 = WallaIE()
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'


# Generated at 2022-06-26 13:15:23.845469
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None

# Generated at 2022-06-26 13:15:31.896961
# Unit test for constructor of class WallaIE
def test_WallaIE():
    inst = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(inst._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-26 13:15:33.288880
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()



# Generated at 2022-06-26 13:15:34.501527
# Unit test for constructor of class WallaIE
def test_WallaIE():
    m = WallaIE(None)
    return m

# Generated at 2022-06-26 13:15:37.657774
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:15:47.623242
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._TEST['url'] == r'http://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:15:51.262472
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.download("2642630")

# Generated at 2022-06-26 13:15:55.773278
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # The title is correct for this case
    assert ie.title == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-26 13:16:00.925125
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import utils
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    video = WallaIE().get_info(url)
    utils.show_video(url, video)

# Generated at 2022-06-26 13:16:07.243256
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for the constructor of class WallaIE
    """
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE()
    mobj = re.match(ie._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    assert video_id == '2642630'
    assert display_id == 'one-direction-all-for-one'


# Generated at 2022-06-26 13:16:34.193524
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-26 13:16:39.473887
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Dummy assertions to satisfy pylint
    assert WallaIE._VALID_URL == WallaIE._VALID_URL
    assert WallaIE._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS


# Generated at 2022-06-26 13:16:40.736609
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:16:43.221172
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._TEST['url'] == ie._VALID_URL

# Generated at 2022-06-26 13:16:48.541035
# Unit test for constructor of class WallaIE
def test_WallaIE():
    field_names = ['_VALID_URL', 'IE_NAME', '_VALID_URL', '_TEST']

# Generated at 2022-06-26 13:16:49.088454
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Should not raise exception
    WallaIE()

# Generated at 2022-06-26 13:16:51.595251
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-26 13:16:54.796246
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract()

# Generated at 2022-06-26 13:16:57.040924
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert re.match(WallaIE._VALID_URL, WallaIE._TEST['url']) is not None

# Generated at 2022-06-26 13:17:00.944285
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie.ie_key() in ie.supported_ie

# Generated at 2022-06-26 13:17:57.097507
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for constructor of class WallaIE"""
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE(url)
    info = ie._real_extract(url)
    # Test extractor
    assert 'ראש הממשלה' in info['title']
    # Test subtitles
    assert len(info['subtitles']) == 1
    assert 'heb' in info['subtitles']


# Generated at 2022-06-26 13:17:59.365709
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class_constructor = WallaIE(InfoExtractor());
    assert class_constructor is not None

# Generated at 2022-06-26 13:18:05.052294
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    test1 = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    result = ie._real_extract(test1)
    assert result

# Generated at 2022-06-26 13:18:06.342422
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(True)


# Generated at 2022-06-26 13:18:07.717142
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert isinstance(walla, InfoExtractor)

# Generated at 2022-06-26 13:18:13.429404
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://video2.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.suitable("http://video2.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:18:16.933327
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructor of class WallaIE
    ie = WallaIE()

    # Check _VALID_URL constant
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:18:17.521525
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE(None)

# Generated at 2022-06-26 13:18:29.258442
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """ Test for constructor of class WallaIE """

    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    the_url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

    video_id = "2642630"
    display_id = "one-direction-all-for-one"
    title = u"וואן דיירקשן: ההיסטריה"

# Generated at 2022-06-26 13:18:35.368672
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE(None, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    except:
        assert False, "WallaIE is unable to constructor"
# Test extract method of class WallaIE

# Generated at 2022-06-26 13:20:25.476873
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/')
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/')

# Generated at 2022-06-26 13:20:37.883951
# Unit test for constructor of class WallaIE
def test_WallaIE():
    inst = WallaIE()
    assert inst._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:20:38.973863
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE()
    assert isinstance(i, InfoExtractor)


# Generated at 2022-06-26 13:20:44.558759
# Unit test for constructor of class WallaIE
def test_WallaIE():
	url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	test = WallaIE()
	test._real_extract(url)

test_WallaIE()

# Generated at 2022-06-26 13:20:54.427288
# Unit test for constructor of class WallaIE
def test_WallaIE():
    web_page = """
        <!doctype html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Example Domain</title>
            <meta http-equiv="Content-Type" content="text/html; utf-8"/>
            <meta name="viewport" content="width=device-width, initial-scale=1" />
        </head>
        <body>
            <div id="main" class="container">
            <section>
                <p>example</p>
            </section>
        </body>
        </html>
    """
    assert WallaIE().suitable(web_page) == True



# Generated at 2022-06-26 13:20:55.690969
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'

# Generated at 2022-06-26 13:21:07.350105
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"
    assert ie._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie._real_extract(ie._TEST['url'])

# Generated at 2022-06-26 13:21:09.073182
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)

# Generated at 2022-06-26 13:21:16.519046
# Unit test for constructor of class WallaIE
def test_WallaIE():
  ie = WallaIE()
  ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
  ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:21:19.091674
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
        assert True
    except Exception as e:
        assert False