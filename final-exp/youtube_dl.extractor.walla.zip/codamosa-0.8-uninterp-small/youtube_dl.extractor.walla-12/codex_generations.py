

# Generated at 2022-06-26 13:12:49.711417
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()
    assert isinstance(walla_i_e, WallaIE)

# Generated at 2022-06-26 13:12:52.906329
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL is not None
    assert WallaIE()._TEST is not None
    assert WallaIE()._SUBTITLE_LANGS is not None

# Generated at 2022-06-26 13:13:04.187919
# Unit test for constructor of class WallaIE

# Generated at 2022-06-26 13:13:14.240995
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # First test
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Second test
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    url = url
    # print url
    # print url
    # print url
    # print url
    # print url

    assert 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one' in WallaIE()._VALID_URL
    assert 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one' in WallaIE()._VALID_URL

# Generated at 2022-06-26 13:13:16.500361
# Unit test for constructor of class WallaIE
def test_WallaIE():
    constructor_test_0( walla_i_e_0 )



# Generated at 2022-06-26 13:13:21.872518
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-26 13:13:23.256760
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check if true is true
    assert True

# Generated at 2022-06-26 13:13:34.907689
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #assert walla_i_e_0.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert walla_i_e_0.valid_url == '^https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert len(walla_i_e_0.configuration) == 2
    assert walla_i_e_0.URL_RE == '^https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'



# Generated at 2022-06-26 13:13:36.789387
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()


# Generated at 2022-06-26 13:13:38.165235
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None

# Generated at 2022-06-26 13:13:44.828870
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE()

# Generated at 2022-06-26 13:13:53.068309
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(ie._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    assert video_id == '2642630'
    assert display_id == 'one-direction-all-for-one'

# Generated at 2022-06-26 13:14:01.857290
# Unit test for constructor of class WallaIE
def test_WallaIE():
	
	# test by constructor
	WallaIE('url')

	# test by url
	WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

	# test by url
	WallaIE('http://vod.walla.co.il/person/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:14:05.126614
# Unit test for constructor of class WallaIE
def test_WallaIE():
    l = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    print(l)

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-26 13:14:06.419909
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-26 13:14:10.400467
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.download()

# Generated at 2022-06-26 13:14:11.862617
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("test").test()

# Generated at 2022-06-26 13:14:21.032234
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:28.955510
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()
    assert test._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:31.558321
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()
    assert wie.SUFFIX == 'co.il'

# Generated at 2022-06-26 13:14:45.178622
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    # unit test for class WallaIE
    assert obj.__class__.__name__ == 'WallaIE', "obj is not of class WallaIE"

# Generated at 2022-06-26 13:14:57.901085
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:15:07.780501
# Unit test for constructor of class WallaIE
def test_WallaIE():
    extractor = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert extractor._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert extractor._SUBTITLE_LANGS['עברית'] == 'heb'
    assert not extractor._TEST['params']['skip_download']


# Testing extraction process in constructor of class WallaIE

# Generated at 2022-06-26 13:15:09.436652
# Unit test for constructor of class WallaIE
def test_WallaIE():
        ie = WallaIE()
        assert ie is not None

# Generated at 2022-06-26 13:15:20.007863
# Unit test for constructor of class WallaIE

# Generated at 2022-06-26 13:15:29.618179
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    assert video.display_id == 'one-direction-all-for-one';
    assert video.id == '2642630';
    assert video.title == 'וואן דיירקשן: ההיסטריה'
    assert video.description == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert video.thumbnail == r're:^https?://.*\.jpg'
    assert video.duration == 3600;
    assert len(video.subtitles) == 0;
    assert len(video.formats) == 2;

# Generated at 2022-06-26 13:15:35.398166
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # According to Wikipedia, the URL is wrong.
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == False

# Generated at 2022-06-26 13:15:37.592306
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # construct object
    WallaIE()
    # No exception should be thrown.

# Generated at 2022-06-26 13:15:44.827948
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', {}, {})
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-26 13:15:47.530699
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert isinstance(x, WallaIE)
    # TODO - Add better tests

# Generated at 2022-06-26 13:16:16.356421
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:16:26.539061
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # success
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    ie = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    ie = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    # failure
    ie = WallaIE('https://youtube.com/');

# Generated at 2022-06-26 13:16:28.581393
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert re.match(ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:16:34.157608
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    ie = WallaIE(WallaIE._VALID_URL)
    assert ie.url == WallaIE._VALID_URL


# Generated at 2022-06-26 13:16:38.949305
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    assert a.params['skip_download'] == True
    assert a._SUBTITLE_LANGS['עברית'] == 'heb'


# Generated at 2022-06-26 13:16:41.901743
# Unit test for constructor of class WallaIE
def test_WallaIE():
	m = WallaIE
	assert m._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-26 13:16:43.699362
# Unit test for constructor of class WallaIE
def test_WallaIE():
	t = WallaIE()
	assert isinstance(t, InfoExtractor)

# Generated at 2022-06-26 13:16:44.925887
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE is not None

# Generated at 2022-06-26 13:16:57.510906
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create an instance of WallaIE with its default constructor
    ie = WallaIE();
    # Check that the class name is WallaIE
    assert ie.IE_NAME == 'walla'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:17:02.642078
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # This is a test for constructor of class WallaIE
    WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:17:55.263589
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:17:57.558837
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for constructor of class WallaIE"""
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(url)

# Generated at 2022-06-26 13:18:09.170246
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(WallaIE._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')

    video = WallaIE._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id)

    item = video.find('./items/item')

    title = xpath_text(item, './title', 'title')
    description = xpath_text(item, './synopsis', 'description')

# Generated at 2022-06-26 13:18:14.686275
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"

# Generated at 2022-06-26 13:18:16.332768
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__.__name__ == WallaIE.__name__


# Generated at 2022-06-26 13:18:18.247328
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None

# Generated at 2022-06-26 13:18:19.739869
# Unit test for constructor of class WallaIE
def test_WallaIE():
    e = WallaIE()
    assert e



# Generated at 2022-06-26 13:18:21.357283
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:18:26.202477
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

if __name__ == "__main__":
    test_WallaIE()

# Generated at 2022-06-26 13:18:28.918799
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_obj = WallaIE(None)
    assert test_obj is not None

# Generated at 2022-06-26 13:20:10.926743
# Unit test for constructor of class WallaIE
def test_WallaIE():
    unit = WallaIE()
    assert unit != None

# Generated at 2022-06-26 13:20:23.457638
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.url_re == WallaIE._VALID_URL
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie._TEST == WallaIE._TEST
    test = WallaIE._TEST.copy()
    test['url'] = 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._real_extract(test['url']) == WallaIE._TEST
    assert ie._real_extract(test['url']) == WallaIE._TEST
    test['url'] = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
   

# Generated at 2022-06-26 13:20:29.778847
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    video = test_WallaIE._TEST
    video['params'] = {'skip_download': True}
    # Video info
    video_info = w._real_extract(video['url'])
    # Test for expected values
    for key, value in video['info_dict'].items():
        assert video_info[key] == value

# Generated at 2022-06-26 13:20:39.679437
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = WallaIE._TEST['url']
    ie = WallaIE()
    ie.is_suitable(url)
    info = ie.extract(url)
    assert(ie.is_suitable(url) == True)
    assert info['id'] == WallaIE._TEST['info_dict']['id']
    assert info['display_id'] == WallaIE._TEST['info_dict']['display_id']
    assert info['ext'] == WallaIE._TEST['info_dict']['ext']
    assert info['title'] == WallaIE._TEST['info_dict']['title']
    assert info['description'] == WallaIE._TEST['info_dict']['description']

# Generated at 2022-06-26 13:20:47.820962
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://vod.walla.co.il/player/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://vod.walla.co.il/')

# Generated at 2022-06-26 13:20:50.494496
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create a constructor
    ie = WallaIE()
    # Test whether constructor is successfully created
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-26 13:20:51.451985
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert 'WallaIE' in x._real_extract(x._TEST['url'])['title']

# Generated at 2022-06-26 13:20:52.956098
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert x.SUCCESS == x._get_success_from_file('Walla.txt')
    assert x.FAILURE == x._get_success_from_file('Walla_failure.txt')


# Generated at 2022-06-26 13:20:57.645382
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla'
    assert ie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:20:59.890637
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE({})
    assert instance.name == "Walla"