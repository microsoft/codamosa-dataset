

# Generated at 2022-06-26 13:12:57.461001
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass
    # Do not test _real_extract because it will interact with the network
    # walla_i_e = WallaIE()
    # assert (walla_i_e._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == {
    #     'id': '2642630',
    #     'display_id': 'one-direction-all-for-one',
    #     'ext': 'flv',
    #     'title': 'וואן דיירקשן: ההיסטריה',
    #     'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
    #     'thumbnail':

# Generated at 2022-06-26 13:12:59.064938
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert 'WallaIE' in globals()


# Generated at 2022-06-26 13:13:00.418215
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()


# Generated at 2022-06-26 13:13:03.158350
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_1 = WallaIE()
    print(walla_i_e_1)


# Generated at 2022-06-26 13:13:13.903807
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = b'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # feed url with TEST case url
    walla_i_e = WallaIE()
    # obtain information in json format
    info_json = walla_i_e._real_extract(url)
    # obtain title information from json
    title = info_json.get('title')
    # obtain id information from json
    video_id = info_json.get('id')
    # obtain display_id information from json
    video_display_id = info_json.get('display_id')
    # obtain description information from json
    description = info_json.get('description')
    # obtain duration information from json
    duration = info_json.get('duration')
    # obtain subtitles information

# Generated at 2022-06-26 13:13:18.416207
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_1 = WallaIE()
#     var_1 = walla_i_e_1.extract_url(walla_i_e_1.http_headers);
#     var_2 = walla_i_e_1.extract_url(walla_i_e_1.http_query);
    var_3 = walla_i_e_1.extract_url(walla_i_e_1._VALID_URL);
    pass

# Generated at 2022-06-26 13:13:20.400259
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()



# Generated at 2022-06-26 13:13:21.233199
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-26 13:13:22.626676
# Unit test for constructor of class WallaIE
def test_WallaIE():
# Init a WallaIE object
    walla_i_e_1 = WallaIE()


# Generated at 2022-06-26 13:13:23.941681
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_case_0()
    return

# Generated at 2022-06-26 13:13:32.330996
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('Walla', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie != None

# Generated at 2022-06-26 13:13:41.609073
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    result = WallaIE()._real_extract(url)
    assert(result['id'] == '2642630')
    assert(result['title'] == "וואן דיירקשן: ההיסטריה")
    assert(result['display_id'] == "one-direction-all-for-one")

# Generated at 2022-06-26 13:13:46.821038
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("vod.walla.co.il/movie/2642630/one-direction-all-for-one", "2642630", "one-direction-all-for-one")


# Generated at 2022-06-26 13:13:48.181920
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("1","1")

# Generated at 2022-06-26 13:13:56.898320
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:13:59.615547
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w is not None


# Generated at 2022-06-26 13:14:03.310626
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie == WallaIE

# Generated at 2022-06-26 13:14:04.199402
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('url', 'context')

# Generated at 2022-06-26 13:14:16.238396
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie is not None

# Generated at 2022-06-26 13:14:24.642493
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert w._TEST.get('url') == url
    assert w._TEST.get('info_dict') is not None
    assert w._TEST.get('params') is not None


# Generated at 2022-06-26 13:14:40.536627
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._download_xml('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl', 'one-direction-all-for-one')

# Generated at 2022-06-26 13:14:41.425934
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:14:45.424310
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl')
    assert obj.__class__ in globals().values()

# Generated at 2022-06-26 13:14:54.654879
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    class constructor(WallaIE):
        def __init__(self, url):
            self.url = url

    # Test whether the WallaIE constructor can be initialized
    try:
        obj = constructor(url)
    except AssertionError:
        raise AssertionError("WallaIE constructor cannot be initialized")

# Generated at 2022-06-26 13:15:01.302523
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'walla'
    assert ie._VALID_URL == \
        r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.url_result(url) is not None
    assert ie._TEST['url'] == url
    info = ie._TEST
    assert info['id'] == '2642630'
    assert info['display_id'] == 'one-direction-all-for-one'
    assert info['ext'] == 'flv'
    assert info

# Generated at 2022-06-26 13:15:10.754647
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Sample url
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    # obj _TEST of class WallaIE
    # which is a member of class InfoExtractor
    ie = WallaIE()

    # obj TestInfoExtractor
    ie_test = ie._real_extract(url)

    # Unit test for extract_id
    assert ie_test['id'] == ie._VALID_URL

    # Unit test for extract_title
    assert ie_test['title'] == 'וואן דיירקשן: ההיסטריה'

    # Unit test for extract_description

# Generated at 2022-06-26 13:15:16.022509
# Unit test for constructor of class WallaIE
def test_WallaIE():
    youtube_ie = WallaIE()
    print("Test 1: instance of WallaIE: " + str("youtube" in str(youtube_ie)))


if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-26 13:15:28.290102
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.geo_verification_headers = {}
    example_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    parsed_uri = urlparse(example_url)
    domain = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
    assert ie.SUBTITLE_LANGS == {
        'עברית': 'heb',
    }
    assert ie.VALID_URL == 'https?://%s[^/]+/(?P<id>\d+)/(?P<display_id>.+)' % re.escape(domain)

# Generated at 2022-06-26 13:15:33.146320
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()
    assert t._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:15:35.797210
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.match_url("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.match_url("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:15:58.235527
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.name == 'walla'

# Generated at 2022-06-26 13:16:03.311512
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract("url")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:16:08.486376
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    obj = WallaIE(url)
    obj.to_screen()


# Generated at 2022-06-26 13:16:10.325591
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__.__name__ == 'WallaIE'


# Generated at 2022-06-26 13:16:13.933357
# Unit test for constructor of class WallaIE
def test_WallaIE():

    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    
    

# Generated at 2022-06-26 13:16:23.435934
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(WallaIE._VALID_URL)
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    info = ie._real_extract(url)
    assert info['display_id'] == 'one-direction-all-for-one'
    assert info['id'] == '2642630'

# Generated at 2022-06-26 13:16:29.041000
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl')
    assert ie.url_result.get('info_dict') #Tests that the returned dict is not empty


# Generated at 2022-06-26 13:16:34.921996
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:16:45.689118
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:16:51.188801
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Exercise that the constructor succeeded and did not throw an exception
    pass

# Generated at 2022-06-26 13:17:34.615722
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:17:36.638885
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.name == 'Walla'

# Generated at 2022-06-26 13:17:47.529728
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'
    assert ie.REAL_URL == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'vod.walla.co.il'

# Generated at 2022-06-26 13:17:50.694135
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:17:54.406420
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE("")
    assert (IE.get_url_re().pattern == WallaIE._VALID_URL)

# Generated at 2022-06-26 13:17:55.323576
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:18:01.366814
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """

# Generated at 2022-06-26 13:18:06.722593
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Just checking that it works with all the change for correct RTMP handling
    WallaIE()._download_webpage({}, 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl', '2642630')

# Generated at 2022-06-26 13:18:10.350356
# Unit test for constructor of class WallaIE
def test_WallaIE():
    checker = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert checker._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-26 13:18:13.080613
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create an instance of WallaIE
    walla = WallaIE()
    assert walla

# Generated at 2022-06-26 13:20:01.602450
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie != None


# Generated at 2022-06-26 13:20:02.752540
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)

# Generated at 2022-06-26 13:20:09.404094
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('Walla')
    assert 'Walla' == ie.ie_key()
    assert 'http' in ie._formats
    assert 'rtmp' in ie._formats
    assert 'httpd' in ie._formats

# Unit test from constructor of class WallaMediaExtractor

# Generated at 2022-06-26 13:20:10.723265
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:20:12.918955
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-26 13:20:15.265361
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie = WallaIE(_VALID_URL)

# Generated at 2022-06-26 13:20:24.739994
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.host == 'video2.walla.co.il', 'host is not video2.walla.co.il'
    assert ie.get_url == '2642630', 'get_url should be 2642630'
    assert ie.link == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'link is not the link we added'
    assert ie.video_id == '2642630', 'video_id is not 2642630'
    assert ie.display_

# Generated at 2022-06-26 13:20:30.064919
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-26 13:20:39.789672
# Unit test for constructor of class WallaIE
def test_WallaIE():

    expected_title = 'וואן דיירקשן: ההיסטריה'
    expected_description = 'md5:de9e2512a92442574cdb0913c49bc4d8'
    expected_duration = 3600
    expected_thumbnail = r're:^https?://.*\.jpg'

# Generated at 2022-06-26 13:20:41.388174
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()