

# Generated at 2022-06-26 13:12:56.608672
# Unit test for constructor of class WallaIE

# Generated at 2022-06-26 13:12:58.833203
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert_raises_regexp(
        ExtractorError,
        'Invalid URL',
        walla_i_e_0._real_extract('https://www.youtube.com/watch?v=w4ApvzsV0nA'),
        'should throw error because the url is not valid'
    )

# Generated at 2022-06-26 13:13:03.461631
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__bases__ == (InfoExtractor,)
    assert walla_i_e_0._VALID_URL == '%s://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)' % ('https?',)


walla_i_e_0 = WallaIE()


# Generated at 2022-06-26 13:13:04.140836
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_0 = WallaIE()

# Generated at 2022-06-26 13:13:04.991328
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()
    assert walla_i_e is not None


# Generated at 2022-06-26 13:13:05.542907
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert str is not None

# Generated at 2022-06-26 13:13:07.197716
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()
    assert WallaIE == walla_i_e.__class__


# Generated at 2022-06-26 13:13:18.524303
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Testing for correct initialization
    assert(WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(WallaIE._TEST['info_dict']['id'] == '2642630')
    assert(WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one')
    assert(WallaIE._TEST['info_dict']['ext'] == 'flv')

# Generated at 2022-06-26 13:13:19.325623
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suite()


# Generated at 2022-06-26 13:13:21.235695
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert walla_i_e_0


# Generated at 2022-06-26 13:13:26.532475
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:13:37.203281
# Unit test for constructor of class WallaIE
def test_WallaIE():

	walla_ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
	assert walla_ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:13:42.250633
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()
    assert hasattr(IE, '_VALID_URL')
    assert hasattr(IE, '_TEST')
    assert hasattr(IE, '_SUBTITLE_LANGS')
    assert hasattr(IE, '_real_extract')

# Generated at 2022-06-26 13:13:48.112820
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    mobj = re.match(ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie._real_extract(mobj.group())

# Generated at 2022-06-26 13:13:50.901714
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Run a unit test using an external program.
    """

# Generated at 2022-06-26 13:13:55.040169
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.get_id() == u'2642630'
    assert ie.get_display_id() == u'one-direction-all-for-one'
    assert ie.get_doctype() == 'vod'

# Generated at 2022-06-26 13:13:55.950444
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:14:03.051542
# Unit test for constructor of class WallaIE
def test_WallaIE():
    sub_langs = {
        'עברית': 'heb',
    }
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._SUBTITLE_LANGS == sub_langs

# Generated at 2022-06-26 13:14:04.607589
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class_under_test = WallaIE(None)
    assert class_under_test != None

# Generated at 2022-06-26 13:14:13.471824
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie._real_initialize()
    ie.url = test_url
    assert ie.url == test_url
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.video_id == '2642630'

# Generated at 2022-06-26 13:14:24.577620
# Unit test for constructor of class WallaIE
def test_WallaIE():
	try:
		w = WallaIE()
	except:
		assert False
	else:
		assert True

# Generated at 2022-06-26 13:14:28.992623
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:14:29.892871
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-26 13:14:38.270331
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # TODO: Implement unit test for constructor of class WallaIE
    w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(w.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(w._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:14:44.724213
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    expected_regex = r'https?://.*\.jpg'
    assert re.match(expected_regex, ie._TEST['info_dict']['thumbnail'])

# Generated at 2022-06-26 13:14:49.659290
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test that the current url of 'self._TEST' is working
    url = WallaIE._TEST['url']
    ie = WallaIE()
    ie.extract(url)

# Generated at 2022-06-26 13:14:59.046351
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.initialize()
    mobj = re.match(ie._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    video = ie._download_xml(
            'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
            display_id)
    item = video.find('./items/item')
    for subtitle in item.findall('./subtitles/subtitle'):
        lang = xpath_text(subtitle, './title')
       

# Generated at 2022-06-26 13:15:01.719807
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-26 13:15:10.938422
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'
    assert WallaIE._TEST['info_dict']['id'] == '2642630'
    assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['ext'] == 'flv'
    assert WallaIE._TEST['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'
    assert WallaIE._TEST['info_dict']['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'

# Generated at 2022-06-26 13:15:13.016328
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-26 13:15:36.151927
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check need to skip test for Windows, see https://github.com/rg3/youtube-dl/issues/14391
    if sys.platform == "win32":
        pytest.skip("Skip test on windows as it fails")
    # Check constructor of class WallaIE
    instance = WallaIE()
    # Assert type of instance
    assert isinstance(instance, WallaIE)

# Generated at 2022-06-26 13:15:48.114707
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create instance of WallaIE with URL, then check the fields.
    w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:15:51.937355
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.SUCCEEDED == 0
    assert ie.FAILED == 1
    assert ie.TRIED == 2
    assert ie.SKIPPED == 3
    assert ie.MAX_RETRIES == 10
    assert ie._sleep_time() == 2
    assert ie._sleep_time(1) == 2
    assert ie._sleep_time(2) == 4
    assert ie._sleep_time(3) == 8
    assert ie._sleep_time(10) == 1024
    assert ie._sleep_time(11) == 1024

# Generated at 2022-06-26 13:15:53.784844
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE({})
    assert isinstance(obj, WallaIE)

# Generated at 2022-06-26 13:15:56.065650
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-26 13:15:58.985707
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:16:07.899565
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one' in ie._TEST['url']
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-26 13:16:14.605825
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.SUFFIX == 'walla'
    assert ie.IE_NAME == 'walla'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-26 13:16:26.916228
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test_result = {'id': '2642630',
                   'display_id': 'one-direction-all-for-one',
                   'ext': 'flv',
                   'title': 'וואן דיירקשן: ההיסטריה',
                   'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
                   'thumbnail': r're:^https?://.*\.jpg',
                   'duration': 3600,
                   'params': {'skip_download': True}}
    res = WallaIE()._real_extract(test_url)
    assert res

# Generated at 2022-06-26 13:16:28.503212
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:17:08.666536
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # This test is to check that the constructor is still valid
    assert ie is not None


# Generated at 2022-06-26 13:17:12.288233
# Unit test for constructor of class WallaIE
def test_WallaIE():
    aie = WallaIE()
    assert WallaIE._VALID_URL == aie._VALID_URL
    assert WallaIE._TEST == aie._TEST

# Generated at 2022-06-26 13:17:14.373121
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://video2.walla.co.il/?w=null/null/2642630')

# Generated at 2022-06-26 13:17:15.719452
# Unit test for constructor of class WallaIE
def test_WallaIE():
	return WallaIE("")

# Generated at 2022-06-26 13:17:20.311540
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # TODO: Automatically test full functionality of WallaIE()
    assert True == True

if __name__ == '__main__':
    test_WallaIE()
    print("Success")

# Generated at 2022-06-26 13:17:23.416540
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class_ = WallaIE
    # check if constructor has been properly implemented
    instance = class_(None)
    assert instance != None

# Generated at 2022-06-26 13:17:26.056135
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:17:34.652783
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.download("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-26 13:17:37.301490
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS.get('עברית')  #Do not delete this line

# Generated at 2022-06-26 13:17:40.458670
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE()

if __name__ == "__main__":
    test_WallaIE()

# Generated at 2022-06-26 13:19:33.560245
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()

    assert ie.suitable(url)
    assert ie.IE_NAME == 'walla'
    assert ie.valid_url(url) == True
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == url

# Generated at 2022-06-26 13:19:35.122392
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:19:35.958418
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:19:40.911015
# Unit test for constructor of class WallaIE
def test_WallaIE():
	try:
		assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one") == 4
	except:
		raise


# Generated at 2022-06-26 13:19:47.256854
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # check that the WallaIE instance is created
    assert(isinstance(ie, WallaIE))
    

# Generated at 2022-06-26 13:19:56.308326
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(ie._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    video = ie._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id)

    item = video.find('./items/item')


# Generated at 2022-06-26 13:20:04.839767
# Unit test for constructor of class WallaIE

# Generated at 2022-06-26 13:20:07.294896
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()
    test._VALID_URL



# Generated at 2022-06-26 13:20:14.915139
# Unit test for constructor of class WallaIE
def test_WallaIE():
    result = WallaIE()
    assert_equal(result._VALID_URL,'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert_equal(result._TEST['url'] ,'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert_equal(result._TEST['info_dict']['id'] ,'2642630')
    assert_equal(result._TEST['info_dict']['display_id'] ,'one-direction-all-for-one')
    assert_equal(result._TEST['info_dict']['ext'] ,'flv')

# Generated at 2022-06-26 13:20:24.609857
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'