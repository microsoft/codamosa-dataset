

# Generated at 2022-06-26 13:12:49.664862
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(walla_i_e_0, WallaIE)


# Generated at 2022-06-26 13:12:51.590914
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(walla_i_e_0)


# Generated at 2022-06-26 13:12:57.828835
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import InfoExtractor
    walla_i_e_0 = WallaIE()
    # Test for 'instanceof'
    assert isinstance(walla_i_e_0, InfoExtractor)


# Generated at 2022-06-26 13:12:59.266817
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None

# Generated at 2022-06-26 13:13:01.803015
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Default
    walla_i_e = WallaIE()
    assert (not walla_i_e.IE_NAME == None)


# Generated at 2022-06-26 13:13:09.211273
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert walla_i_e_0.get_host() == 'vod.walla.co.il'
    assert walla_i_e_0._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-26 13:13:18.006263
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import InfoExtractor
    IE_DESC = 'walla.co.il'
    IE_NAME = 'walla'
    ie = WallaIE()

    ie_desc = ie._SUBTITLE_LANGS
    assert ie_desc == {u'\u05d0\u05d1\u05e8\u05d9\u05ea': u'heb'}, 'Description should be %s' % repr(IE_DESC)

    ie_name = ie.ie_key()
    assert ie_name == 'Walla', 'Name should be %s' % repr(IE_NAME)

# Generated at 2022-06-26 13:13:21.094601
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(walla_i_e_0, WallaIE), "walla_i_e_0 is not instance of expected class"


# Generated at 2022-06-26 13:13:22.275890
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert 'WallaIE' == WallaIE.__name__


# Generated at 2022-06-26 13:13:24.149208
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_0 = WallaIE()


# Generated at 2022-06-26 13:13:30.054183
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:13:32.034208
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._TEST['url']


# Generated at 2022-06-26 13:13:35.695035
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj.extract_id('https://vod.walla.co.il/movies/2238697/mama') == '2238697'

# Generated at 2022-06-26 13:13:36.514898
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:13:41.470694
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:13:44.898372
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w is not None
    assert w._SUBTITLE_LANGS is not None

# Generated at 2022-06-26 13:13:55.757216
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    info_dict = {'id': '2642630', 'display_id': 'one-direction-all-for-one', 'ext': 'flv', 'title': 'וואן דיירקשן: ההיסטריה', 'description': 'md5:de9e2512a92442574cdb0913c49bc4d8', 'thumbnail': 're:^https?://.*\.jpg', 'duration': 3600}
    ie = WallaIE()
    ie._downloader = FakeDownloader()
    ie.download(url)
    assert ie.extract(url) == info_dict

# Generated at 2022-06-26 13:14:00.387051
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:14:02.483470
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None, None)


# Generated at 2022-06-26 13:14:05.126101
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # constructor of class WallaIE
    wie = WallaIE()
    assert wie.ie_key() == 'Walla'
    assert wie.ie_name() == 'Walla'

# Generated at 2022-06-26 13:14:15.235883
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:14:15.662324
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:14:26.097155
# Unit test for constructor of class WallaIE
def test_WallaIE():
  # url = https://vod.walla.co.il/movie/2642630/one-direction-all-for-one
  # Done
  check_walla = WallaIE()
  mobj = re.match(check_walla._VALID_URL, 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
  video_id = mobj.group('id')
  display_id = mobj.group('display_id')
  check_walla._download_xml('http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id, display_id)
  assert True
#test_WallaIE()

# Generated at 2022-06-26 13:14:27.924579
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    return x

# Generated at 2022-06-26 13:14:33.214422
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global WallaIE
    url = "http://c.files.bbci.co.uk/CA21/production/_82494446_donkey.jpg"
    wallaIE = WallaIE(url)
    assert wallaIE is not None

# Generated at 2022-06-26 13:14:38.979806
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:14:40.972597
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla is not None

# Generated at 2022-06-26 13:14:42.955546
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()(WallaIE._TEST['url'])

# Generated at 2022-06-26 13:14:43.480987
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)


# Generated at 2022-06-26 13:14:46.515043
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:15:08.723797
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl')

# Generated at 2022-06-26 13:15:10.127093
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    w.suite()

# Generated at 2022-06-26 13:15:14.585202
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:15:18.924732
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    IE = WallaIE()

# Generated at 2022-06-26 13:15:28.982237
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    # Check if URL is valid
    assert instance._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)' 
    # Check if id is valid
    assert instance._TEST['info_dict']['id'] == '2642630'
    # Check if name is valid
    assert instance._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    # Check if title is valid
    assert instance._TEST['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-26 13:15:32.653939
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    return WallaIE({'url' : url})

# Generated at 2022-06-26 13:15:35.298049
# Unit test for constructor of class WallaIE
def test_WallaIE():
    '''
    Unit test for constructor of class WallaIE
    '''
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-26 13:15:37.522942
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w.__name__ == 'walla'

# Generated at 2022-06-26 13:15:39.572819
# Unit test for constructor of class WallaIE
def test_WallaIE():
        ie = WallaIE()
        ie.download_webpage()
        pass

# Generated at 2022-06-26 13:15:43.103235
# Unit test for constructor of class WallaIE
def test_WallaIE():

    from .walla import WallaIE # import to remove flake8 F811
    # WallaIE is not a test
    assert WallaIE

# Generated at 2022-06-26 13:16:29.725131
# Unit test for constructor of class WallaIE
def test_WallaIE():
    s = WallaIE()
    assert(s._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-26 13:16:31.896911
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WordPressIE(WallaIE)

# test_WallaIE()

# Generated at 2022-06-26 13:16:37.060975
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'
    ie = WallaIE({})
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie.IE_NAME == 'walla'
    assert ie.ie_key() == 'WallaIE'

# Generated at 2022-06-26 13:16:40.534532
# Unit test for constructor of class WallaIE
def test_WallaIE():
    sut = WallaIE()
    assert sut._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert [x for x in sut._SUBTITLE_LANGS] == ['עברית']

# Generated at 2022-06-26 13:16:41.923880
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-26 13:16:44.359905
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:16:45.544276
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL

# Generated at 2022-06-26 13:16:47.598043
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    result = w._TEST

# Generated at 2022-06-26 13:16:52.808761
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE()
    ui_mod = __import__('youtube_dl.ui')
    info_extractor._downloader = ui_mod.console_ui.ConsoleUI()

# Generated at 2022-06-26 13:16:59.230151
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        # Call the constructor for WallaIE
        ie = WallaIE()
    except:
        raise AssertionError('Failed to create class WallaIE.')

    # Verify that WallaIE.suitable
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    if not ie.suitable(url):
        raise AssertionError('WallaIE should recognize suitable URL %s' % url)

    url = "http://google.com"
    if ie.suitable(url):
        raise AssertionError('WallaIE should not recognize suitable URL %s' % url)

# Generated at 2022-06-26 13:18:38.896778
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert WallaIE()._TEST == WallaIE._TEST
    assert WallaIE()._real_extract == WallaIE._real_extract

# Generated at 2022-06-26 13:18:49.987344
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert a._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert a._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert a._TEST['info_dict']['id'] == '2642630'
    assert a._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert a._TEST['info_dict']['ext'] == 'flv'
   

# Generated at 2022-06-26 13:18:52.761460
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.name == 'walla'

# Generated at 2022-06-26 13:18:59.058052
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import sys
    from .common import to_unicode
    from .netrc_test import add_test_netrc_file

    with add_test_netrc_file():
        ie = WallaIE()
        ie.report_warning = sys.stderr.write
        ie.to_screen = to_unicode
        ie.extract('http://vod.walla.co.il/movie/2659571/walla-interviews-paul-mccartney')

# Generated at 2022-06-26 13:19:01.802322
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://walla.co.il/url')


# Generated at 2022-06-26 13:19:05.727706
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()
    assert t._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-26 13:19:11.983444
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # This url is from TEST, above
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Test parsing the url, above
    w = WallaIE(url)
    assert w.url == url
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:19:18.896585
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Check type of variable
    assert isinstance(WallaIE._VALID_URL, str)

    # Check value of variable
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:19:20.208468
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-26 13:19:25.154847
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')