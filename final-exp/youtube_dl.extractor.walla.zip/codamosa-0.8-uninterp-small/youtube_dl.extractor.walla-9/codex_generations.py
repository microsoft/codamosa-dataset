

# Generated at 2022-06-26 13:12:56.810797
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == r'http://vod.walla.co.il/[^/]+/\d+/.+'
    assert WallaIE()._TEST['url'] == r'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE()._TEST['info_dict']['id'] == '2642630'
    assert WallaIE()._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert WallaIE()._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-26 13:12:57.419124
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_case_0()

# Generated at 2022-06-26 13:13:02.518691
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == 'WallaIE'
    walla_i_e = WallaIE()
    assert walla_i_e.url_result('Uri')
    assert walla_i_e.suitable('Uri')
    assert walla_i_e.ie_key() == 'Walla'


# Generated at 2022-06-26 13:13:05.428782
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert walla_i_e_0.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert walla_i_e_0.suitable(walla_i_e_0.url) == True
    assert walla_i_e_0.valid_url(walla_i_e_0.url) == True
    assert walla_i_e_0.extract_id(walla_i_e_0.url) == '2642630'

# Generated at 2022-06-26 13:13:07.108502
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(WallaIE(), InfoExtractor)

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-26 13:13:14.088278
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url_walla = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla_i_e = WallaIE()
    walla_i_e.extract(url_walla)

# Generated at 2022-06-26 13:13:15.796666
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None



# Generated at 2022-06-26 13:13:22.056120
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("Testing constructor of WallaIE")
    walla_i_e = WallaIE()
    assert walla_i_e is not None, "walla_i_e is none! There is no instance of WallaIE"
    print("Successfully tested constructor of WallaIE")


# Generated at 2022-06-26 13:13:23.453045
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()


# Generated at 2022-06-26 13:13:29.071952
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-26 13:13:47.333136
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:13:48.185507
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-26 13:13:49.035489
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:13:55.074114
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert hasattr(walla_i_e_0, 'extract')
    assert hasattr(walla_i_e_0, '_REAL_EXTENSION')
    assert hasattr(walla_i_e_0, '_VALID_URL')
    assert hasattr(walla_i_e_0, '_TEST')
    assert hasattr(walla_i_e_0, '_SUBTITLE_LANGS')


# Generated at 2022-06-26 13:13:56.578664
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_1 = WallaIE()

# Generated at 2022-06-26 13:14:01.769368
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = InfoExtractor.calculate_ie()
    from .common import InfoExtractor
    from .common import gen_extractors_map
    assert ie == 'walla'



# Generated at 2022-06-26 13:14:03.138204
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj_w = WallaIE()


# Generated at 2022-06-26 13:14:08.928433
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:09.873787
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == 'WallaIE'


# Generated at 2022-06-26 13:14:11.264969
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_case_0()

# Generated at 2022-06-26 13:14:29.450094
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    m = ie._VALID_URL.search(url);
    if m:
        video_id = m.group('id')
        display_id = m.group('display_id')
    else:
        raise Exception('invalid url: "%s"' % url)
    video_url = 'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id
    xml = ie._download_xml(video_url, display_id)
    item = xml.find('./items/item')
    title = xpath_text(item, './title', 'title')
    description

# Generated at 2022-06-26 13:14:34.465065
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for the constructor of WallaIE"""
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    x = WallaIE(url)
    print(x)

# Generated at 2022-06-26 13:14:38.239855
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.host() == 'walla.co.il'

# Generated at 2022-06-26 13:14:42.955148
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl')

# Generated at 2022-06-26 13:14:45.260903
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Testing the constructor of class WallaIE
    ie = WallaIE()
    assert ie is not None

# Generated at 2022-06-26 13:14:51.836465
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create a WallaIE object
    obj = WallaIE()
    # Test regular expression of URL
    assert re.match(obj._VALID_URL, "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:14:53.199247
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE({}) is not None

# Generated at 2022-06-26 13:14:57.655984
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL = 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:15:02.703578
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Test WallaIE constructor
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-26 13:15:06.888555
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.get_info('2642630', 'one-direction-all-for-one')

# Generated at 2022-06-26 13:15:33.147039
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #test_WallaIE.test_WallaIE()
    ie = WallaIE()
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:15:33.572779
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-26 13:15:34.922559
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 13:15:38.130947
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE()

# Generated at 2022-06-26 13:15:39.646441
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:15:44.988264
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class_ = WallaIE
    ie = class_()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla! VOD'
    assert ie.ie_id() == class_.ie_key()



# Generated at 2022-06-26 13:15:56.603489
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:15:58.984931
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('test','test')
    # Assert a class
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-26 13:16:04.137190
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Using __name__ as display_id
    WallaIE(__name__)._real_extract(url)

# Generated at 2022-06-26 13:16:15.423960
# Unit test for constructor of class WallaIE

# Generated at 2022-06-26 13:17:00.412626
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """ Unit test for constructor of class WallaIE """

    # Test invalid format
    with pytest.raises(ValueError):
        WallaIE("invalid url")



# Generated at 2022-06-26 13:17:04.724465
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:17:16.358853
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor.
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE(url)
    assert w.url == url
    assert w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert w._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert w._TEST['info_dict']['id'] == '2642630'
    assert w._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-26 13:17:27.028236
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Using just one of the cases from WallaIE._TEST
	url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
	test_case = WallaIE._TEST['url']

	info = test_case["info_dict"]
	# Passing in just url for now, but we might want to pass in more.
	video = WallaIE(url)

	# Test that the video has correct parameters
	assert video.url == url
	assert video.display_id == info["display_id"]
	assert video.title == info["title"]
	assert video.description == info["description"]
	assert video.thumbnail == info["thumbnail"]
	assert video.duration == info["duration"]

	# Test that the class has the right functions
	assert hasattr

# Generated at 2022-06-26 13:17:37.687999
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie._TEST == WallaIE._TEST
    assert ie.suitable(url) == True
    assert ie.IE_NAME == 'walla'
    assert ie.__name__ == 'WallaIE'
    assert ie.get_metadata('title') == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-26 13:17:46.185120
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie.ie_key() == WallaIE.ie_key()
    assert ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc') is None
    info_dict = ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert info_dict['id'] == '2642630'
    assert 'title' in info_dict

# Generated at 2022-06-26 13:17:57.124067
# Unit test for constructor of class WallaIE
def test_WallaIE():
    constructor_test(WallaIE, [
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
    ])

# Generated at 2022-06-26 13:17:58.914726
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE({})
    assert instance.ie_key() == 'Walla'

# Generated at 2022-06-26 13:18:00.767855
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-26 13:18:05.343003
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb', 'subtitle language: hebrew'

# Generated at 2022-06-26 13:20:04.135079
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test the constructor of WallaIE class
    """
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-26 13:20:06.470345
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-26 13:20:09.875557
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:20:11.228298
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for the constructor
    assert WallaIE(None, None)

# Generated at 2022-06-26 13:20:14.496269
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-26 13:20:18.089131
# Unit test for constructor of class WallaIE
def test_WallaIE():
	"""
	Test class WallaIE for constructor.

	@return: None
	"""
	wallaIE = WallaIE()

	assert wallaIE

# Generated at 2022-06-26 13:20:21.611746
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:20:25.035153
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.name == 'walla'
    assert ie.SUBTITLE_LANGS == {u'עברית': 'heb'}

# Generated at 2022-06-26 13:20:28.727200
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__ == WallaIE
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie._TEST == WallaIE._TEST

# Generated at 2022-06-26 13:20:30.970678
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    

# Test the WallaIE