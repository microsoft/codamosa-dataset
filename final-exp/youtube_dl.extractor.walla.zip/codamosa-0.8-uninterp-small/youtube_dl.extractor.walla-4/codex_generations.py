

# Generated at 2022-06-26 13:12:51.626182
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_2 = WallaIE()
    assert walla_i_e_2.ie_key() == 'Walla'
    assert WallaIE.ie_key() == 'Walla'


# Generated at 2022-06-26 13:12:55.051177
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().IE_NAME == 'walla'


# Generated at 2022-06-26 13:12:56.993296
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_0 = WallaIE()


# Generated at 2022-06-26 13:12:58.922151
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__bases__[0] == InfoExtractor


# Generated at 2022-06-26 13:13:02.433840
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE.__name__ == 'WallaIE')
    assert(WallaIE.__doc__ == 'Walla extractor')
    assert(WallaIE.__module__ == 'walla')



# Generated at 2022-06-26 13:13:04.151112
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE


# Generated at 2022-06-26 13:13:06.178147
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        walla_i_e_0 = WallaIE()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-26 13:13:07.133398
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_0 = WallaIE()
    return

# Generated at 2022-06-26 13:13:08.093853
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert('WallaIE' in globals())

# Generated at 2022-06-26 13:13:19.158028
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:13:35.823015
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:13:36.654687
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:13:37.375734
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:13:43.264570
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    extractor = WallaIE(wallaIE)
    extractor._download_webpage = MagicMock()
    extractor._extract_feed_info(url)
    assert extractor.name == 'Walla!'
    return True

# Generated at 2022-06-26 13:13:49.321986
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.working() is True
    assert ie.info_dict.get('title') == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-26 13:13:52.991603
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from wallaie import WallaIE
    test_object = WallaIE()
    assert test_object.expected_warnings == [
       'Extractor WallaIE is deprecated, you should use walla instead.',
    ]

# Generated at 2022-06-26 13:13:57.933227
# Unit test for constructor of class WallaIE
def test_WallaIE():
    module = "walla"
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    WallaIE(module, url)

# Generated at 2022-06-26 13:14:03.527996
# Unit test for constructor of class WallaIE
def test_WallaIE():
    urls = [
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
    ]

# Generated at 2022-06-26 13:14:05.317530
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # TODO: parameter 'skip_download' is not supported
    pass

# Generated at 2022-06-26 13:14:13.868160
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check if video of type Web can be initialized
    obj = WallaIE('http://some/url')
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


if __name__ == '__main__':
    # Run the test if it is not imported
    test_WallaIE()

# Generated at 2022-06-26 13:14:26.545360
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE("WallaIE")
    print("Unit test for constructor of class WallaIE")
    assert("WallaIE" == instance.ie_key()), "Unit test for constructor of class WallaIE failed"
# end test_WallaIE

# Generated at 2022-06-26 13:14:27.678033
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:14:32.987052
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('xx', {})._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:35.276905
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:14:40.301189
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:41.779665
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None

# Generated at 2022-06-26 13:14:44.427430
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Unit test for constructor of class WallaIE
    # TODO: Need to implement
    assert(False)

# Generated at 2022-06-26 13:14:48.624173
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:14:52.119899
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)

# Generated at 2022-06-26 13:14:59.889158
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    item = WallaIE(None)._real_extract(url)
    assert item['id'] == '2642630'
    assert item['display_id'] == 'one-direction-all-for-one'
    assert item['title'] == 'וואן דיירקשן: ההיסטריה'
    assert item['description'] == ''

# Generated at 2022-06-26 13:15:20.182349
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    pass

# Generated at 2022-06-26 13:15:23.706777
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(WallaIE.suitable(WallaIE._TEST['url']))

# Generated at 2022-06-26 13:15:24.535149
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:15:27.379367
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_DESC == 'Walla! VOD'
    assert ie.ie_key() == 'Walla'
    assert ie.SUITABLE_URL == WallaIE._VALID_URL

# Generated at 2022-06-26 13:15:35.227865
# Unit test for constructor of class WallaIE
def test_WallaIE():

    ans = WallaIE()
    assert ans._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    ans = WallaIE(ans)
    assert ans._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:15:37.924976
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)


# Generated at 2022-06-26 13:15:49.056253
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:15:53.092037
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.name == 'walla'
    assert ie.ie_key() == 'walla'
    assert ie.VERSION == '0.0'


# Generated at 2022-06-26 13:15:54.738645
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Just to make sure that WallaIE is exist
    """

    assert(WallaIE)


# Generated at 2022-06-26 13:16:06.587485
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:16:49.733937
# Unit test for constructor of class WallaIE
def test_WallaIE():
	pass

# Generated at 2022-06-26 13:16:58.929769
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()
	assert ie.outputs_file == True
	assert ie.type_video == 'video'
	assert ie.url_regex == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
	assert ie.suitable_url == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
	assert ie.downloader == 'rtmpdump'
	assert ie.extractor == 'WallaIE'
	assert ie.extractor_key == 'walla'
	assert ie.name == 'WallaIE extractor'

# Generated at 2022-06-26 13:17:02.693164
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:17:09.437528
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:17:10.792289
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:17:11.364103
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("123")

# Generated at 2022-06-26 13:17:18.077326
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test WallaIE
    # FIXME: Currently no way to test the constructor of InfoExtractor
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:17:27.588527
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'

    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    assert WallaIE._TEST['info_dict']['id'] == '2642630'
    assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['ext'] == 'flv'
   

# Generated at 2022-06-26 13:17:32.796130
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    assert a.test('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True

# Generated at 2022-06-26 13:17:35.100597
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test for class constructor
    ie = WallaIE()
    print("Unit test for class constructor is completed.")


# Generated at 2022-06-26 13:19:33.017143
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.ie_key() == 'walla'
    assert WallaIE.ie_key() != 'walla2'
    assert WallaIE.ie_key() != 'awalla'
    assert WallaIE.ie_key() != 'awalla2'
    assert WallaIE.ie_key() != 'awalla3'
    assert WallaIE.ie_key() != 'WAlla'
    assert WallaIE.ie_key() != 'wallaie'
    assert WallaIE.ie_key() != 'walla_IE'
    assert WallaIE.ie_key() != 'WallaExtractor'
    assert WallaIE.ie_key() != 'WallaExtractor2'
    assert WallaIE.ie_key() != 'WallaExtractor3'
    assert WallaIE.ie_

# Generated at 2022-06-26 13:19:36.723110
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:19:44.460665
# Unit test for constructor of class WallaIE
def test_WallaIE():
  (mobj) = re.match(WallaIE._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
  WallaIE._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# UNIT test for method _real_extract
#def test_real_extract():
#  (mobj) = re.match(WallaIE._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
#  results = WallaIE._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for

# Generated at 2022-06-26 13:19:54.314350
# Unit test for constructor of class WallaIE
def test_WallaIE():
    testdata = {
         #'video_id'
         'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
         'info_dict': {
            'id': '2642630',
            'display_id': 'one-direction-all-for-one',
            'ext': 'flv',
            'title': 'וואן דיירקשן: ההיסטריה',
            'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
            'thumbnail': r're:^https?://.*\.jpg',
            'duration': 3600,
         }
    }

# Generated at 2022-06-26 13:20:04.208230
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_WallaIE.test_WallaIE = WallaIE
    obj = WallaIE(None)
    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:20:11.228310
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.suitable(url)
    assert ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:20:23.588860
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass
# class WallaIE:
#     _VALID_URL = r'https?://vod\d*\.walla\.co\.il/wvod/%s/@@/%s/flv_pl/' % (VIDEO_ID, VIDEO_ID)
#     IE_NAME = 'walla:vod'
#     _TEST = {
#         'url': 'http://vod.walla.co.il/wvod/2642630/@@/2642630/flv_pl/',
#         'info_dict': {
#             'id': '2642630',
#             'ext': 'flv',
#             'title': 'וואן דיירקשן: ההיסטריה',
#             'description': 'md5:

# Generated at 2022-06-26 13:20:26.103970
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('WallaIE')._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-26 13:20:28.246002
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try :
        w = WallaIE()
    except:
        assert False
    assert True


# Generated at 2022-06-26 13:20:30.392590
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Unit test for initalization of object WallaIE
    Walla_ie = WallaIE()
    print("[*]Test pass")