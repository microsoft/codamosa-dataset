

# Generated at 2022-06-26 13:12:49.563629
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE()
    walla_ie.url_result()


# Generated at 2022-06-26 13:12:51.792003
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(walla_i_e_0, WallaIE)

# Get url

# Generated at 2022-06-26 13:12:52.966110
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-26 13:12:57.617716
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-26 13:13:05.045200
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Example from WallaIE
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla_i_e_0 = WallaIE()

    # Test variables for method _real_extract()
    video = walla_i_e_0._download_xml(
            'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl',
            'one-direction-all-for-one')
    item = video.find('./items/item')

    # Test method
    walla_i_e_0._real_extract(url)

# Generated at 2022-06-26 13:13:05.929469
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE


# Generated at 2022-06-26 13:13:14.797013
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test the constructor method of WallaIE
    """
    assert (WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-26 13:13:16.150049
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert callable(WallaIE)


# Generated at 2022-06-26 13:13:18.549947
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(WallaIE(), InfoExtractor)

# Generated at 2022-06-26 13:13:19.349333
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e = WallaIE()
    assert walla_i_e

# Generated at 2022-06-26 13:13:26.089640
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:13:30.266060
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:13:38.083563
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert(ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(ie._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert(ie._TEST['info_dict']['id'] == "2642630")
    assert(ie._TEST['info_dict']['display_id'] == "one-direction-all-for-one")

# Generated at 2022-06-26 13:13:42.086658
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    test = ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert (test)

# Generated at 2022-06-26 13:13:46.265899
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:13:52.952742
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert 'walla.co.il' in ie._VALID_URLs
    assert ie._VALID_URL == ie._VALID_URLs[0][0]
    assert ie._TEST['url'] in ie._VALID_URLs
    assert ie._TEST['url'] == ie._VALID_URLs[1][0]

# Generated at 2022-06-26 13:13:53.835032
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:13:54.624327
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("")

# Generated at 2022-06-26 13:13:55.463379
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:14:01.931521
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:14:13.517280
# Unit test for constructor of class WallaIE
def test_WallaIE():
    if __name__ == "__main__":
        wIE = WallaIE()

# Generated at 2022-06-26 13:14:17.719545
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global WallaIE
    if __name__ == '__main__':
        ie = WallaIE()

# Generated at 2022-06-26 13:14:21.239100
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE(InfoExtractor())
    assert wie._SUBTITLE_LANGS['עברית'] == 'heb'


# Generated at 2022-06-26 13:14:25.026465
# Unit test for constructor of class WallaIE
def test_WallaIE():
    kwargs = {'url': WallaIE._TEST['url'], 'expected_status':'200'}
    ie = WallaIE(kwargs)
    assert ie.get('url') == WallaIE._TEST['url']

# Generated at 2022-06-26 13:14:33.669239
# Unit test for constructor of class WallaIE

# Generated at 2022-06-26 13:14:34.180430
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _ = WallaIE()

# Generated at 2022-06-26 13:14:37.954879
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:14:42.140901
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:14:44.137223
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.AUTHORIZATION_TOKEN == ""

# Generated at 2022-06-26 13:14:48.252092
# Unit test for constructor of class WallaIE
def test_WallaIE():
	#This is a constructor
	WallaIE(InfoExtractor)
	#Test for these URLs
	#"http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
	#"https://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-26 13:15:19.420968
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'nerd')
    assrt = ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert assrt['id'] == '2642630'
    assert assrt['display_id'] == 'one-direction-all-for-one'
    assrt = ie._real_extract(
        'http://vod.walla.co.il/homevideo/2542402/one-direction-all-for-one')
    assert assrt['id'] == '2542402'
    assert assrt['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-26 13:15:29.400518
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') != WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:15:30.736122
# Unit test for constructor of class WallaIE
def test_WallaIE():
    constructor_test(WallaIE)



# Generated at 2022-06-26 13:15:36.629994
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"

# Generated at 2022-06-26 13:15:37.924742
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(0)

# Generated at 2022-06-26 13:15:48.099833
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.report_warning = lambda msg: None
    ie._downloader = None
    ie.suitable('http://vod.walla.co.il/movie/2610114/harry-potter-and-the-deathly-hallows-part2')
    ie.suitable('http://vod.walla.co.il/movie/2610114')
    assert ie.suitable('http://vod.walla.co.il/movie/2610114/') is False
    assert ie.suitable('http://vod.walla.co.il/movie/2610114/harry-potter-and-the-deathly-hallows-part2/') is False

# Generated at 2022-06-26 13:15:52.114728
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie.video_id = '2642630'
    ie.display_id = 'one-direction-all-for-one'
    ie.title = 'וואן דיירקשן: ההיסטריה'
    ie.description = 'md5:de9e2512a92442574cdb0913c49bc4d8'
    ie.thumbnail = 'http://img.youtube.com/vi/7ZTxcMZuKm0/hqdefault.jpg'
    ie.duration = 3600

# Generated at 2022-06-26 13:15:53.433183
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE != None

# Generated at 2022-06-26 13:16:00.088972
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test
    """
    ####################################################
    # Basic unit test to make sure the constructor of WallaIE works:
    ie = WallaIE()

    ####################################################
    # Unit test for WallaIE._SUBTITLE_LANGS
    ####################################################
    assert(ie._SUBTITLE_LANGS) is not None
    assert("ישראלית" in ie._SUBTITLE_LANGS)
    assert("עברית" in ie._SUBTITLE_LANGS)
    assert("אנגלית" in ie._SUBTITLE_LANGS)
    
    ####################################################
    # Unit test for WallaIE._VALID_URL
    ####################################################
    assert(ie._VALID_URL) is not None
   

# Generated at 2022-06-26 13:16:04.445576
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.download("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:16:50.636171
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    WallaIE._SUBTITLE_LANGS

# Generated at 2022-06-26 13:16:59.231965
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    info = ie.extract()
    assert(info['id'] == '2642630')
    assert(info['display_id'] == 'one-direction-all-for-one')
    assert(info['title'] == 'וואן דיירקשן: ההיסטריה')
    assert(info['ext'] == 'flv')
    assert(info['thumbnail'] == 'http://img.wcdn.co.il/f_auto,w_50,t_51/2/3/6/7/2367328-51.jpg')
    assert(info['duration'] == 3600)

# Generated at 2022-06-26 13:17:07.209480
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test the constructor of WallaIE
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)

    assert ie.url == url
    assert ie._VALID_URL == re.compile(r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert ie.name == 'walla:vod'
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.video_id == '2642630'

# Generated at 2022-06-26 13:17:08.146714
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:17:12.425398
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Run WallaIE constructor test"""
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj is not None

# Generated at 2022-06-26 13:17:18.322746
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-26 13:17:24.799300
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_key() in WallaIE._ies
    assert ie.suitable
    assert ie.working
    assert ie.url_re.match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:17:25.540854
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:17:37.332295
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:17:38.641962
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert True

# Generated at 2022-06-26 13:19:30.114621
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-26 13:19:42.881754
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE()
    assert wallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:19:47.546853
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.get_id() == '2642630'

# Generated at 2022-06-26 13:19:53.198649
# Unit test for constructor of class WallaIE
def test_WallaIE():
    iex = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # see assert in _real_extract
    iex._download_xml('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl', 'one-direction-all-for-one')

# Generated at 2022-06-26 13:19:54.556047
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None


# Generated at 2022-06-26 13:19:56.578747
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-26 13:19:58.511517
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE(None)
    assert wie is not None

# Generated at 2022-06-26 13:20:05.509216
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:20:07.219916
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE



# Generated at 2022-06-26 13:20:10.790195
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE()
    cases = [
    #    ('')
    ]

    for case in cases:
        wallaIE._real_extract()