

# Generated at 2022-06-26 13:12:49.301714
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert(WallaIE() != None)


# Generated at 2022-06-26 13:12:57.892542
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['id'] == '2642630'
    assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['ext'] == 'flv'
    assert WallaIE._TEST['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-26 13:13:00.774084
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Arrange
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    # Act
    walla_i_e_0 = WallaIE()
    # Assert
    assert walla_i_e_0._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-26 13:13:01.619824
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-26 13:13:10.466791
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:13:10.938113
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()


# Generated at 2022-06-26 13:13:11.628633
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass


# Generated at 2022-06-26 13:13:13.530544
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert test_case_0() == None
    

# Generated at 2022-06-26 13:13:18.472337
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check if every field of walla_i_e_0 has the correct type
    walla_i_e_0 = WallaIE()
    assert type(walla_i_e_0._VALID_URL) == str
    assert type(walla_i_e_0._TEST) == dict
    assert type(walla_i_e_0._SUBTITLE_LANGS) == dict
    assert type(walla_i_e_0._real_extract) == types.FunctionType


# Generated at 2022-06-26 13:13:19.077866
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # TODO:?
    pass

# Generated at 2022-06-26 13:13:26.580566
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("WallaIE")
    assert ie != None

# Generated at 2022-06-26 13:13:28.767976
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print(WallaIE._SUBTITLE_LANGS)

# Generated at 2022-06-26 13:13:33.796204
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE(test_url)
    assert ie.url == test_url
    assert ie.params == {'skip_download': True} # skip_download is True by default

# Generated at 2022-06-26 13:13:35.094645
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert "WallaIE" in globals()

# Generated at 2022-06-26 13:13:39.371076
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        assert isinstance(WallaIE(), WallaIE)
        assert isinstance(WallaIE(InfoExtractor()), WallaIE)
    except:
        return False
    else:
        return True

# Generated at 2022-06-26 13:13:43.387957
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.valid_url(ie._VALID_URL)
    ie.extract(ie._VALID_URL)

# Generated at 2022-06-26 13:13:50.115953
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/five')

# Generated at 2022-06-26 13:13:52.848574
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.init()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:13:55.471596
# Unit test for constructor of class WallaIE
def test_WallaIE():
  ie = WallaIE()
  ie.extract(WallaIE._TEST['url'])

# Generated at 2022-06-26 13:13:56.984634
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE({}, {}, {})

# Generated at 2022-06-26 13:14:09.039106
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.download()

# Generated at 2022-06-26 13:14:16.337293
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-26 13:14:22.840213
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import pytest
    from tests.test_utils import get_test_instance

    ie = get_test_instance()
    assert isinstance(ie, WallaIE)

    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._valid_url(test_url, ie.IE_NAME)

    ie._real_extract(test_url)

# Generated at 2022-06-26 13:14:24.403213
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 13:14:36.897570
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:38.612044
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:14:49.782491
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .ooyalaIE import OoyalaIE
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.download = OoyalaIE.download
    ie.prepare_rtmp_params = OoyalaIE.prepare_rtmp_params
    ie.download_rtmp_video = OoyalaIE.download_rtmp_video
    ie.handle_download = OoyalaIE.handle_download
    ie._download_webpage = OoyalaIE._download_webpage
    ie._download_xml = OoyalaIE._download_xml
    ie._sort_formats = OoyalaIE._sort_formats
    # Compare md5 of the output of test()
    # with the md5 of the correct result.


# Generated at 2022-06-26 13:14:51.799129
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("Testing constructor of WallaIE")
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie = WallaIE(url)
    print("Testing constructor success")

# Generated at 2022-06-26 13:14:57.282260
# Unit test for constructor of class WallaIE
def test_WallaIE():
	test_info = {
		'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
		}
	obj = WallaIE(test_info)

# Generated at 2022-06-26 13:14:58.041116
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:15:23.079440
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie._real_extract(url)

# Generated at 2022-06-26 13:15:28.808520
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:15:30.401232
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()


# Generated at 2022-06-26 13:15:31.749501
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-26 13:15:38.865315
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.name == 'Walla!'
    assert ie.m3u8_id == 'vod'
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._VALID_URL == r'https?://(?:www\.)?walla\.co\.il/item/(?P<id>\d+)'

# Generated at 2022-06-26 13:15:49.465641
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:15:55.109803
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    info_dict=ie._real_extract(url)
    print(info_dict)
    print(type(info_dict))
if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-26 13:16:02.816053
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.SUITABLE_YOUTUBE_URL is None
    assert hasattr(ie, 'extract_id')
    assert ie.VALID_URL == _VALID_URL
    assert ie._TEST == TEST
    assert ie._SUBTITLE_LANGS == SUBTITLE_LANGS
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-26 13:16:06.943828
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    print (ie.video_id)
    print (ie.display_id)
    assert(ie.video_id == '2642630')
    assert(ie.display_id == 'one-direction-all-for-one')

# Generated at 2022-06-26 13:16:12.763448
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from walla import WallaIE
    instance = WallaIE(_VALID_URL)
    assert instance._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:17:01.710353
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.extract(url)

# Generated at 2022-06-26 13:17:02.497255
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test WallaIE with dummy information."""
    # TODO(yihui): Implement this.
    pass

# Generated at 2022-06-26 13:17:04.350331
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()
    ret = t.suitable('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ret == True
    ret = t.suitable('https://www.youtube.com/watch?v=HNO3rCOrRNo')
    assert ret == False

# Generated at 2022-06-26 13:17:12.355285
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    instance.url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert instance.valid_url()
    instance.url = ""
    assert not instance.valid_url()
    data = instance.extract()
    assert len(data) == 11


# Generated at 2022-06-26 13:17:14.657668
# Unit test for constructor of class WallaIE
def test_WallaIE():
    result = WallaIE._SUBTITLE_LANGS.get('עברית', 'heb')
    assert result == 'heb'

# Generated at 2022-06-26 13:17:17.791343
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    #TODO: check the validity of this object
    assert ie

# Generated at 2022-06-26 13:17:19.109372
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-26 13:17:22.889887
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test for constructor of class WallaIE"""
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:17:24.798899
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj is not None

# Test case for WallaIE.suitable

# Generated at 2022-06-26 13:17:27.556986
# Unit test for constructor of class WallaIE
def test_WallaIE():
    klass = WallaIE
    klass({}, WallaIE._VALID_URL)



# Generated at 2022-06-26 13:19:30.853497
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_dict = WallaIE()._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert 'id' in info_dict
    assert 'display_id' in info_dict
    assert 'ext' in info_dict
    assert 'title' in info_dict
    assert 'description' in info_dict
    assert 'thumbnail' in info_dict
    assert 'duration' in info_dict

# Generated at 2022-06-26 13:19:43.051308
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.name == "Walla"
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:19:46.314747
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        class WallaIE(InfoExtractor):
            pass
        assert 1 == 1
    except TypeError:
        assert 1 == 0

# Generated at 2022-06-26 13:19:47.262515
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        o = WallaIE()
    except:
        import traceback
        traceback.print_exc()
        assert False
    assert True

# Generated at 2022-06-26 13:19:48.945535
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie._VALID_URL == WallaIE._VALID_URL)
    assert(ie._TEST == WallaIE._TEST)

# Generated at 2022-06-26 13:19:51.913141
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Test #1
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    # Test #2
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:19:53.959406
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Initialize the class
	WallaIE({})

# Generated at 2022-06-26 13:19:57.658115
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().suitable('http://vod.walla.co.il')
    assert WallaIE().suitable('http://vod.walla.co.il/movie/')

# Generated at 2022-06-26 13:19:58.975585
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-26 13:20:00.327321
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie= WallaIE();