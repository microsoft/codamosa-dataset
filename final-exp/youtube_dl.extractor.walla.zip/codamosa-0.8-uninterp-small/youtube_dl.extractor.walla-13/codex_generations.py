

# Generated at 2022-06-26 13:12:50.067576
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert walla_i_e_0 == WallaIE()



# Generated at 2022-06-26 13:12:53.103248
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_0 = WallaIE(url_or_request='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-26 13:12:54.220609
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert 'WallaIE' == WallaIE.ie_key()


# Generated at 2022-06-26 13:12:56.368230
# Unit test for constructor of class WallaIE
def test_WallaIE():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-26 13:12:58.312479
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE == WallaIE()
    assert WallaIE != None

# Generated at 2022-06-26 13:12:59.503112
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass


# Generated at 2022-06-26 13:13:04.008386
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-26 13:13:07.058415
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_i_e_0 = WallaIE()
    assert isinstance(walla_i_e_0, WallaIE)


# Generated at 2022-06-26 13:13:08.022309
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # All cases are handled in test_case_0
    pass

# Generated at 2022-06-26 13:13:16.706181
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ROOT = 'http://vod.walla.co.il/movie/'
    URL = ROOT + '2642630/one-direction-all-for-one'
    VALID_URL = 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert re.match(VALID_URL, URL)


# Generated at 2022-06-26 13:13:34.613242
# Unit test for constructor of class WallaIE
def test_WallaIE():
    zhongguo = ('http://vod.walla.co.il/movie/2637953/%D7%92%D7%A0%D7%AA'
                '%D7%99%D7%99%D7%94-%D7%A0%D7%99%D7%95%D7%99%D7%95%D7%A0%D7%99'
                '%D7%A0%D7%95%D7%A7%D7%A1%D7%99%D7%9D')
    assert WallaIE._VALID_URL.match(zhongguo)
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-26 13:13:43.225748
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Example of a valid input to class (Url of a video of walla.co.il)
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Checks if the url matches with WallaIE regex
    assert ie._VALID_URL == re.match(ie._VALID_URL, url).regex
    # Checks if the input to the class is an instance of WallaIE
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-26 13:13:54.555289
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructor of class WallaIE
    ie = WallaIE()
    ie_url = ie.IE_NAME + '://'

    # unregistered IE
    assert(ie.suitable(ie_url) == False)

    # registered IE
    ie.IE_NAME = 'walla'
    assert(ie.suitable(ie_url) == True)

    # not Walla video
    url = 'http://www.youtube.com/'
    assert(ie.suitable(url) == False)

    # Walla video
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert(ie.suitable(url) == True)



# Generated at 2022-06-26 13:13:59.771011
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("test_WallaIE") 
    # Note: WallaIE.__init__ is not called when importing this module.
    # Only a method will call WallaIE.__init__

# Generated at 2022-06-26 13:14:08.124346
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('WallaIE', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.url_re == re.compile('(?i)https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert ie.name == 'WallaIE'
    assert ie.display_id == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:14:14.044648
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:25.837258
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:30.836330
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('re:https?://vod.walla.co.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-26 13:14:36.011958
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:14:37.595605
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE is not None

# Generated at 2022-06-26 13:14:48.756697
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 13:14:50.840216
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
	a = ie._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:14:52.637198
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Testing that the constructor doesn't raise any exception
    WallaIE()

# Generated at 2022-06-26 13:14:53.404549
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-26 13:14:54.874345
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-26 13:14:57.406156
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('md5:de9e2512a92442574cdb0913c49bc4d8');
    # Run a test for class 'WallaIE'
    assert obj.test();


# Generated at 2022-06-26 13:15:09.182361
# Unit test for constructor of class WallaIE
def test_WallaIE():
    options = Options()
    options.thumbnail_format = 'jpg'
    options.write_all_thumbnails = True
    options.format = 'best[height<=480]'
    options.merge_output_format = 'mkv'
    options.cachedir = True
    options.nooverwrites = True
    options.noplaylist = True
    options.skip_download = False
    options.proxy = None
    options.verbose = True
    options.outtmpl = 'C:\\Users\\תומר\\Videos\\%(title)s.%(ext)s'
    options.logtostderr = False
    options.ratelimit = None
    options.nocheckcertificate = False
    options.debug_printtraffic = False
    options.username = None
    options.playlist

# Generated at 2022-06-26 13:15:12.199905
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-26 13:15:15.134469
# Unit test for constructor of class WallaIE
def test_WallaIE():
    my_ie = WallaIE()
    assert my_ie is not None

# Generated at 2022-06-26 13:15:17.234776
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # TODO remove this test in the future, when removing the old_ie feature
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-26 13:15:45.409473
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test creating WallaIE instance
    """
    # The url of this sample video is: http://media.walla.co.il/item/2658848?ver=0
    sample_url = "http://vod.walla.co.il/movie/2658848/naomi-klein-the-story-of-capitalism-9/"
    w = WallaIE()
    w.extract(sample_url)
    return w

# Generated at 2022-06-26 13:15:47.042505
# Unit test for constructor of class WallaIE
def test_WallaIE():
	a = WallaIE()

# Generated at 2022-06-26 13:15:49.590941
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.title == 'Walla!'


# Generated at 2022-06-26 13:15:54.266593
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()

    # test for constructor response
    assert ie.suitable(url)
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-26 13:15:57.653414
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one' )

# Generated at 2022-06-26 13:16:07.453049
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('rtmp://wafla.walla.co.il/vod/2642630/2642630.mp4')._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE('rtmp://wafla.walla.co.il/vod/2642630/2642630.mp4')._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:16:16.199596
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-26 13:16:21.853652
# Unit test for constructor of class WallaIE
def test_WallaIE():
    full_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    other = WallaIE()
    x = other.extract(full_url)
    y = other.extract(full_url)

# Generated at 2022-06-26 13:16:29.487791
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    assert ie._VALID_URL ==  'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:16:38.672793
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    #assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._TEST['info_dict']['id'] == '

# Generated at 2022-06-26 13:17:22.891270
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check the instance of this class
    assert isinstance(WallaIE, InfoExtractor)
    # Check the constructor of this class
    ie = WallaIE("")
    assert ie is not None

# Generated at 2022-06-26 13:17:27.502831
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert wie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert wie.VALUE == 'Walla!,VOD'
    assert wie.SUCCESS == '<title>One Direction: The Story</title>'

# Generated at 2022-06-26 13:17:35.829491
# Unit test for constructor of class WallaIE
def test_WallaIE():
    
    vod_walla_co_il_url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    wr = WallaIE()
    
    
    # test URL formation
    assert vod_walla_co_il_url==wr._VALID_URL.replace('https?://','')
    assert wr._real_extract(vod_walla_co_il_url)

# Generated at 2022-06-26 13:17:38.986143
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        instance = WallaIE()
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-26 13:17:42.203530
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:17:44.233135
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-26 13:17:46.064429
# Unit test for constructor of class WallaIE
def test_WallaIE():
  w = WallaIE()
  w.download("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-26 13:17:53.224191
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    info = ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-26 13:18:00.698781
# Unit test for constructor of class WallaIE
def test_WallaIE():
    loader = WallaIE()
    assert loader
    assert loader.url == 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert loader.id == '2642630'
    assert loader.display_id == 'one-direction-all-for-one'
    assert loader.info_dict['id'] == '2642630'
    assert loader.info_dict['display_id'] == 'one-direction-all-for-one'
    assert loader.info_dict['ext'] == 'flv'
    assert loader.info_dict['title'] == 'וואן דיירקשן: ההיסטריה'
    assert loader.params['skip_download'] == True

# Generated at 2022-06-26 13:18:06.375075
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test successful initialization
    ie = WallaIE('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl')
    assert ie.name == 'walla'

# Generated at 2022-06-26 13:19:53.698582
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-26 13:20:03.988740
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# pylint: disable=wildcard-import
	"""Unit-test for constructor of class WallaIE"""
	test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	walla = WallaIE()
	
	extractor_test_result=walla._real_extract(test_url)
	
	#check the content of test
	assert(extractor_test_result.get('id', None) == u'2642630')
	assert(extractor_test_result.get('description', None) == u'וואן דיירקשן: ההיסטריה')
	assert(extractor_test_result.get('duration', None) == 3600)

# Generated at 2022-06-26 13:20:08.856371
# Unit test for constructor of class WallaIE

# Generated at 2022-06-26 13:20:15.356164
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:20:24.759700
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__name__ == 'walla.co.il'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-26 13:20:28.426200
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(ie.__class__.__name__ == 'WallaIE')

# Generated at 2022-06-26 13:20:30.068407
# Unit test for constructor of class WallaIE
def test_WallaIE():
    clazz = WallaIE
    instance = clazz()
    assert clazz != instance

# Generated at 2022-06-26 13:20:35.860671
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert i.name() == 'Walla'
    assert i.ie_key() == 'Walla'
    assert i.domain() == 'vod.walla.co.il'

# Generated at 2022-06-26 13:20:38.013281
# Unit test for constructor of class WallaIE
def test_WallaIE():
    manager = ie.BaseIE._create_ie('Walla')
    assert isinstance(manager, WallaIE)

# Generated at 2022-06-26 13:20:38.928915
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._VALID_URL == WallaIE._VALID_URL