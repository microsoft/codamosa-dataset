

# Generated at 2022-06-24 13:39:42.297093
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:39:49.728114
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info = WallaIE()._real_extract(WallaIE._TEST['url'])
    assert info.get('title') == WallaIE._TEST['info_dict']['title']
    assert info.get('description') == WallaIE._TEST['info_dict']['description']
    assert info.get('thumbnail') == WallaIE._TEST['info_dict']['thumbnail']
    assert info.get('duration') == WallaIE._TEST['info_dict']['duration']

# Generated at 2022-06-24 13:39:55.480488
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test case 1:
    # WallaIE(common.InfoExtractor)
    # Get basic unit test coverage for WallaIE
    # We don't want to make this test case too complex
    # because WallaIE has the basic infrastructure that
    # other sites inherit from
    ie1 = WallaIE(InfoExtractor)
    assert ie1


# Generated at 2022-06-24 13:39:56.741756
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:39:57.348679
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().IE_NAME == 'walla'

# Generated at 2022-06-24 13:40:07.849653
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"

# Generated at 2022-06-24 13:40:08.562215
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None) is not None

# Generated at 2022-06-24 13:40:10.481704
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST == WallaIE._TEST

# Generated at 2022-06-24 13:40:17.686610
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test a walla.co.il video.
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Test basic fields.
    video = WallaIE()._real_extract(url)
    assert video['id'] == '2642630'
    assert video['display_id'] == 'one-direction-all-for-one'
    assert video['title']
    assert video['description']
    assert video['thumbnail']
    assert video['duration']

# Generated at 2022-06-24 13:40:26.143243
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()
    assert IE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert IE._SUBTITLE_LANGS == {'עברית': 'heb'}
    assert IE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:40:27.082858
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-24 13:40:35.389063
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.url is 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.video_id is '2642630'
    assert ie.display_id is 'one-direction-all-for-one'
    assert ie._VALID_URL is 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:45.017911
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:55.211483
# Unit test for constructor of class WallaIE
def test_WallaIE():
    r = WallaIE()._build_rtmp_url({'url': 'rtmp://wafla.walla.co.il/vod', 'play_path': '172/59/315.mp4'}, {})
    assert r == 'rtmp://wafla.walla.co.il/vod playpath=172/59/315.mp4 swfUrl=http://isc.walla.co.il/w9/swf/video_swf/vod/WallaMediaPlayerAvod.swf pageUrl=live=true'

    r = WallaIE()._build_rtmp_url({'url': 'rtmp://wafla.walla.co.il/vod', 'play_path': '172/59/315.mp4', 'live': True}, {})

# Generated at 2022-06-24 13:40:56.915700
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.tld == 'walla.co.il'

# Generated at 2022-06-24 13:40:59.524667
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one").extract()

# Generated at 2022-06-24 13:41:01.476356
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # This test does nothing, and is here for just a reminder
    ieObj = WallaIE()

# Generated at 2022-06-24 13:41:04.240334
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    print (WallaIE._VALID_URL)
    print (WallaIE._SUBTITLE_LANGS)
    return obj

# Generated at 2022-06-24 13:41:09.588564
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.VALID_URL == ie._VALID_URL
    assert ie.TEST == ie._TEST
    assert '_SUBTITLE_LANGS' not in str(ie.__dict__)

# Generated at 2022-06-24 13:41:10.195630
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert issubclass(WallaIE, InfoExtractor)

# Generated at 2022-06-24 13:41:19.587319
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Receive an instance of WallaIE constructor
	IE = WallaIE()	
	# Unit test for _VALID_URL instance variable
	if IE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)':
		print("%s is valid" % IE._VALID_URL)
	else:
		print("%s is not valid" % IE._VALID_URL)
	# Unit test for _TEST instance variable
	if IE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one':
		print("%s is valid" % IE._TEST['url'])

# Generated at 2022-06-24 13:41:20.499942
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None, None)
    assert ie

# Generated at 2022-06-24 13:41:23.617071
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE({})
    assert type(ie.VALID_URL) is re._pattern_type

# Test for __real_extract() in class WallaIE

# Generated at 2022-06-24 13:41:24.976968
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('WallaIE')
    assert ie == 'WallaIE'

# Generated at 2022-06-24 13:41:27.971968
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    v = w.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert v.g

# Generated at 2022-06-24 13:41:28.814156
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        assert WallaIE
    except NameError:
        return False
    return True

# Generated at 2022-06-24 13:41:29.877487
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS != None

# Generated at 2022-06-24 13:41:31.803943
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # User friendly info for yourself and others
    assert WallaIE._TEST, "Unit test not implemented!"


# Generated at 2022-06-24 13:41:40.742152
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from __main__ import WallaIE
    from .common import InfoExtractor
    from ..utils import compat_urllib_request

    IE = WallaIE('http://vod.walla.co.il/item/2642630/one-direction-all-for-one')
    assert isinstance(IE, WallaIE)
    assert isinstance(IE, InfoExtractor)
    assert IE.url == 'http://vod.walla.co.il/item/2642630/one-direction-all-for-one'
    assert IE.file_id == '2642630'
    assert IE.display_id == 'one-direction-all-for-one'
    assert IE.name == 'Walla'
    assert IE.content_type == 'video'

# Generated at 2022-06-24 13:41:41.281139
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE == WallaIE('WallaIE')

# Generated at 2022-06-24 13:41:46.158242
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(WallaIE._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    new_wallaIE = WallaIE(None)
    extract_info = new_wallaIE._real_extract(url)
    assert extract_info['id'] == video_id
    assert extract_info['display_id'] == display_id
    assert extract_info['title'] == u'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:41:53.398186
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:41:56.338990
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert re.match(obj._VALID_URL,
                    "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    return

# Generated at 2022-06-24 13:42:08.216739
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:09.700682
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE()

# Generated at 2022-06-24 13:42:16.279465
# Unit test for constructor of class WallaIE
def test_WallaIE():
	walla_ie = WallaIE()
	mobj = re.match(walla_ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
	assert mobj.group('id') == '2642630'
	assert mobj.group('display_id') == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:42:18.469556
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:42:19.209561
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() != None

# Generated at 2022-06-24 13:42:25.782079
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .test import main
    f_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:42:27.765216
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:42:30.008144
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:42:31.020765
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-24 13:42:40.763865
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.SUCCESS == 'Skip')
    assert(ie._VALID_URL ==  'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:42:43.281509
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:42:44.182388
# Unit test for constructor of class WallaIE
def test_WallaIE():
    we = WallaIE()

# Generated at 2022-06-24 13:42:48.590959
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert(ie.url == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert(ie.subtitle_langs == {'עברית': 'heb'})
    return

# Generated at 2022-06-24 13:42:57.418951
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:43:05.236883
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    # Create an instance of class WallaIE for testing
    walla_ie = WallaIE(None)

    # Make sure that the provided regular expression is correct
    assert (walla_ie._VALID_URL ==
            r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

    # Make sure that the regular expression is good for all of the examples
    for url in ('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',):
        assert(walla_ie._VALID_URL == re.match(walla_ie._VALID_URL, url).group(0))

# Generated at 2022-06-24 13:43:07.151740
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

if __name__ == "__main__":
    # Add an argument for the Unit test of class WallaIE
    test_WallaIE()

# Generated at 2022-06-24 13:43:09.182122
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test_WallaIE::test_constructor::start

    i = WallaIE()

    assert isinstance(i, WallaIE)

    # test_WallaIE::test_constructor::end


# Generated at 2022-06-24 13:43:10.079287
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suite()

# Generated at 2022-06-24 13:43:14.022132
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('fake url')
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:17.489237
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE(None)
    assert wallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'



# Generated at 2022-06-24 13:43:22.658088
# Unit test for constructor of class WallaIE
def test_WallaIE():
  ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
  assert("WallaIE" in str(ie))
  assert(ie.display_id == 'one-direction-all-for-one')
  assert(ie.video_id == '2642630')

# Generated at 2022-06-24 13:43:23.554443
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-24 13:43:24.115034
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:43:32.678056
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://example.com')
    assert_equal(ie.__class__.__name__, "WallaIE")
    assert_equal(ie.ie_key(), 'Walla')
    assert_equal(ie.SUCCESS, "Your download should start in %d seconds.")
    assert_equal(ie._VALID_URL, r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:43:35.010917
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:43.522507
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from contextlib import contextmanager
    from .common import temporary_directory
    from ..utils import make_HTTPServer, make_fake_httpserver_handler
    from ..compat import compat_urllib_parse
    import os

    @contextmanager
    def fake_url(cache_dir, url, body):
        with temporary_directory(prefix='WallaIE-unit-test-') as dir_path:
            sub_path = os.path.join(dir_path, 'video2.walla.co.il')
            with make_HTTPServer(sub_path, make_fake_httpserver_handler(body)) as httpd:
                url = url.format(httpd.port)
                ie = WallaIE(cache_dir=cache_dir, downloader=None)
                query_string = compat_urllib_parse

# Generated at 2022-06-24 13:43:45.586981
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:46.926601
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE(InfoExtractor)
    assert test  # test is not None

# Generated at 2022-06-24 13:43:51.827398
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'    
    assert ie.SUFFIX == 'walla.co.il'

# Generated at 2022-06-24 13:43:54.724066
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:43:58.439230
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.extract(video_url)

# Generated at 2022-06-24 13:44:01.102498
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ex = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert(ex != None)

# Generated at 2022-06-24 13:44:02.014426
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-24 13:44:04.439287
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(ie._TEST['url'])

# Generated at 2022-06-24 13:44:12.929225
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test constructor of WallaIE class
    """
    to_test = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert to_test._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:13.815467
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass


# Generated at 2022-06-24 13:44:15.658394
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:44:16.441136
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:44:17.145748
# Unit test for constructor of class WallaIE
def test_WallaIE():
  test_WallaIE = WallaIE()
  return test_WallaIE

# Generated at 2022-06-24 13:44:28.154130
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.__class__ == WallaIE
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:30.818653
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    ie.get_info("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:44:32.329944
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()
    assert t.__name__ == 'Walla'
    assert t._WORKING == True

# Generated at 2022-06-24 13:44:36.132952
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:44:45.738444
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == "WallaIE"
    assert WallaIE.__doc__ == "WallaIE for http://www.walla.co.il."
    assert WallaIE.__rtype__ == "WallaIE"
    assert WallaIE.__module__ == "walla"
    assert WallaIE.__dict__ == {}
    assert WallaIE.IE_NAME == u'\u05e8\u05db\u05e7 \u05d5\u05d5\u05e0 \u05d3\u05d9\u05e8\u05e7\u05e9\u05df'
    assert WallaIE.__version__ == "1.0.0"
    assert WallaIE.__author__ == "Omer Katz"

# Generated at 2022-06-24 13:44:49.891997
# Unit test for constructor of class WallaIE
def test_WallaIE():
    res = WallaIE()
    assert res._VALID_URL == WallaIE._VALID_URL
    assert res._TEST == WallaIE._TEST
    assert res._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert "_real_extract" in dir(res)

# Generated at 2022-06-24 13:44:58.724695
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # This unit test was created for debugging the constructor of class WallaIE
    # using pdb.set_trace()

    # For initializing the class I use an input string that was captured by the
    #  Wireshark program and saved in a file.
    # The string can be viewed in file 'test_WallaIE_url.txt' in the folder
    # 'tests'
    # This string is a request of a web page that contains information about a
    # VOD clip. The request was captured over the internet.
    # The request as shown in the Wireshark program is a base64 encoded
    # text.
    # In the 'tests' folder I used the program 'base64' to convert it back to
    # text.

    f = open('test_WallaIE_url.txt', 'rt')
    url = f.read

# Generated at 2022-06-24 13:45:02.103321
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:45:02.601699
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:45:11.820356
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:14.778985
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2643234/manray-mohamed-ramadan-mohamed-hemeda')
    assert ie.subtitle_languages['heb'] == 'עברית'

# Generated at 2022-06-24 13:45:21.602752
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    mobj = re.match(ie._VALID_URL, url)
    assert mobj.group('id') == '2642630' and mobj.group('display_id') == 'one-direction-all-for-one' and ie._DOWNLOAD_XML == 1

# Generated at 2022-06-24 13:45:27.784462
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('vod.walla.co.il', {}, {}, {})
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-24 13:45:31.105637
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # In case an exception is raised, this test will fail
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:45:32.432537
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass
if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:45:34.041431
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie_object = WallaIE('http://foo.bar')
    assert isinstance(ie_object, WallaIE)

# Generated at 2022-06-24 13:45:38.112487
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.extract(url)
    assert ie.title == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:45:38.862442
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:45:46.674245
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:49.429468
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('rtmp://wafla.walla.co.il/vod/mp4:2550904/high_quality/2642630.mp4/@@/video/flv_pl')

# Generated at 2022-06-24 13:45:50.848923
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Check that the class constructor is not broken
    assert WallaIE(_VALID_URL)

# Generated at 2022-06-24 13:45:54.000726
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:54.479359
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:45:59.956882
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:01.007122
# Unit test for constructor of class WallaIE
def test_WallaIE():
    main_obj=WallaIE()

# Generated at 2022-06-24 13:46:01.937494
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import unittest
    unittest.main()

# Generated at 2022-06-24 13:46:12.466221
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    # Test case 1: extract video id
    video_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._match_id(video_url) == '2642630'

    # Test case 2: extract display id
    assert ie._match_id(video_url, 'display_id') == 'one-direction-all-for-one'

    # Test case 3: extract title
    video

# Generated at 2022-06-24 13:46:13.060789
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(InfoExtractor)

# Generated at 2022-06-24 13:46:16.209795
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:17.750821
# Unit test for constructor of class WallaIE
def test_WallaIE():
    inst = WallaIE({})
    assert inst.IE_NAME == 'Walla'

# Generated at 2022-06-24 13:46:18.328079
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-24 13:46:19.189954
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-24 13:46:20.100760
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE(InfoExtractor)

# Generated at 2022-06-24 13:46:20.890364
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()

# Generated at 2022-06-24 13:46:25.814326
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:28.445088
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie._VALID_URL, re._pattern_type)


if __name__ == "__main__":
    test_WallaIE()

# Generated at 2022-06-24 13:46:29.357721
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w

# Generated at 2022-06-24 13:46:30.439041
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _WallaIE = WallaIE('test', {}, {})

# Generated at 2022-06-24 13:46:31.030979
# Unit test for constructor of class WallaIE
def test_WallaIE():
	return WallaIE()

# Generated at 2022-06-24 13:46:33.044734
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-24 13:46:44.221602
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(ie._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    ie._download_xml(url, display_id)
    ie._download_xml('http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id, display_id)

# Test cases run:
#-> test_WallaIE()
#-> test_download_webpage
#-> test_url_result
#-> test_search_youtube
#-> test_none
#-> test_

# Generated at 2022-06-24 13:46:47.664325
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie2 = WallaIE()
    assert ie._VALID_URL == ie2._VALID_URL
    assert ie._TEST == ie2._TEST
    assert ie._SUBTITLE_LANGS == ie2._SUBTITLE_LANGS

# Generated at 2022-06-24 13:46:54.983250
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE.
    """
    # Fail: Invalid URL.

# Generated at 2022-06-24 13:47:02.700058
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Test the case: the url is valid
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._match_id(url) == '2642630', 'Error! URL should be valid'
    # Test the case: the url is invalid
    url = 'http://vod.walla.co.il/movie/one-direction-all-for-one'
    assert ie._match_id(url) is None, 'Error! URL should be invalid'


# Generated at 2022-06-24 13:47:04.644925
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-24 13:47:14.176259
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_page = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    info_page = 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl'
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'

    video = WallaIE()

    video.video_page = video_page
    video.info_page = info_page
    video.video_id = video_id
    video.display_id = display_id

    assert re.match(video._VALID_URL, video_page)
    assert video.video_page == video_page
    assert video.info_page == info_page

# Generated at 2022-06-24 13:47:17.457439
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE()
    assert i._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:47:18.316280
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()


# Generated at 2022-06-24 13:47:25.910325
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:26.591581
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    exit(0)

# Generated at 2022-06-24 13:47:27.331880
# Unit test for constructor of class WallaIE
def test_WallaIE():
  test_WallaIE = WallaIE()

# Generated at 2022-06-24 13:47:30.442535
# Unit test for constructor of class WallaIE
def test_WallaIE():
    '''
    Unit tests for constructor of class WallaIE
    @input : None
    @output : None
    '''
    assert 'Walla' in globals()


# Generated at 2022-06-24 13:47:31.140985
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-24 13:47:32.805378
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    if ie is not None:
        pass

# Generated at 2022-06-24 13:47:35.977209
# Unit test for constructor of class WallaIE
def test_WallaIE():
    infoExtractor = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert infoExtractor


# Generated at 2022-06-24 13:47:39.201125
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:40.867665
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print(WallaIE.ie_key())
    print(WallaIE._SUBTITLE_LANGS)

# Generated at 2022-06-24 13:47:42.395815
# Unit test for constructor of class WallaIE
def test_WallaIE():
    app = WallaIE()
    assert isinstance(app, InfoExtractor)


# Generated at 2022-06-24 13:47:49.828568
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:47:57.590309
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:04.061899
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()
	assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
	assert ie._TEST
	assert ie._SUBTITLE_LANGS == {
	    'עברית': 'heb',
	}


# Generated at 2022-06-24 13:48:06.080260
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(2, 3)
    assert ie.name == "walla"
    assert ie.test == _TEST

# Generated at 2022-06-24 13:48:14.126164
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    test_dict = ie._TEST
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:21.598788
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE.
    """

    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test_valid_url = WallaIE._VALID_URL
    _ = WallaIE(test_url)
    assert re.match(test_valid_url, test_url)

# Generated at 2022-06-24 13:48:31.851493
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_info = WallaIE()._real_extract(WallaIE._TEST['url'])
    assert video_info['id'] == '2642630'
    assert video_info['display_id'] == 'one-direction-all-for-one'
    assert video_info['ext'] == 'flv'
    assert video_info['title'] == 'וואן דיירקשן: ההיסטריה'
    assert video_info['description'] == \
        'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert video_info['thumbnail'] == 're:^https?://.*\.jpg'
    assert video_info['duration'] == 3600

# Generated at 2022-06-24 13:48:34.481700
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("Creating WallaIE object")
    ie_obj = WallaIE()
    print("Created WallaIE object")


# Generated at 2022-06-24 13:48:38.722575
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("just testing")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# End of Unit test for constructor of class WallaIE



# Generated at 2022-06-24 13:48:39.338594
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:48:41.778051
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(WallaIE().extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'), dict)

# Generated at 2022-06-24 13:48:42.629806
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:48:44.814212
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla is not None

# Generated at 2022-06-24 13:48:45.624954
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:48:51.129206
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ClassUnderTest = WallaIE(InfoExtractor)

    assert True == hasattr(ClassUnderTest, "_SUBTITLE_LANGS")
    assert True == hasattr(ClassUnderTest, "_VALID_URL")
    assert True == hasattr(ClassUnderTest, "_TEST")
    assert True == hasattr(ClassUnderTest, "_real_extract")


# Generated at 2022-06-24 13:48:55.167754
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.extract(url)
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-24 13:49:02.556407
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert WallaIE().__name__ == 'WallaIE'
    assert WallaIE().ie_key() == 'Walla'
    assert WallaIE()._TEST == WallaIE._TEST
    assert WallaIE()._real_extract == WallaIE._real_extract
    return True


# Generated at 2022-06-24 13:49:04.254092
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .wallaIE import WallaIE
    info_extractor = WallaIE()
    assert isinstance(info_extractor, WallaIE)

# Generated at 2022-06-24 13:49:07.375711
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.download('2642630')

test_WallaIE()

# Generated at 2022-06-24 13:49:17.820782
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == "walla"
    assert ie.ie_name() == "Walla"
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', True)
    assert not ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', False)
    assert not ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/')

# Generated at 2022-06-24 13:49:20.337178
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:49:22.519614
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    expected_object = WallaIE
    assert(isinstance(ie, expected_object))


# Generated at 2022-06-24 13:49:27.921476
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    tst = WallaIE()
    tst._real_extract(url)
    assert tst._VALID_URL
    assert tst._TEST

# Generated at 2022-06-24 13:49:34.091102
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for constructor of class WallaIE"""
    info = WallaIE()._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert info['title'] == "וואן דיירקשן: ההיסטריה"