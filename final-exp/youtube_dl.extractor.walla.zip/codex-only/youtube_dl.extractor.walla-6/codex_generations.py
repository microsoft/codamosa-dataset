

# Generated at 2022-06-24 13:39:39.004766
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    expected_url_regex = r'http://video2\.walla\.co\.il/\?w=null/null/2642630/@@/video/flv_pl'
    expected_play_path_regex = r'^mp4:(?P<height>\d+)p/'
    expected_page_url = url

    w = WallaIE()
    m = re.match(w._VALID_URL, url)
    assert m is not None

    w._downloader = mock_downloader(html=None)
    w._real_extract(url)
    last_download = w._downloader.last_request

# Generated at 2022-06-24 13:39:40.757045
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_ie = WallaIE()
    if not video_ie:
        assert False, "Problem with creating WallaIE instance"


# Generated at 2022-06-24 13:39:42.017975
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL

# Generated at 2022-06-24 13:39:53.504809
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE()
    assert info_extractor.IE_NAME == 'Walla'

    assert info_extractor._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:04.536616
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie1 = WallaIE()
    assert ie1.ie_key() == 'Walla'
    assert ie1.SUFFIX == 'sig'
    assert ie1._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:13.703774
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj.suitable
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:23.264900
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:40:27.274558
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(WallaIE(None)._SUBTITLE_LANGS, dict)
    assert re.match(WallaIE(None)._VALID_URL, 'http://walla.co.il/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:37.690341
# Unit test for constructor of class WallaIE
def test_WallaIE():
    unit_test = WallaIE()
    assert unit_test._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:38.246066
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-24 13:40:39.967188
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global WallaIE
    WallaIE('WallaIE', 'Walla')


# Generated at 2022-06-24 13:40:48.386663
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:40:55.481009
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    video = ie.extract()
    assert video['id'] == '2642630'
    assert video['display_id'] == 'one-direction-all-for-one'
    assert video['title'] == 'וואן דיירקשן: ההיסטריה'
    assert video['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert video['thumbnail'] == 're:^https?://.*\.jpg'
    assert video['duration'] == 3600

# Generated at 2022-06-24 13:41:03.150410
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info = WallaIE()._extract_url(WallaIE._TEST['url'])
    WallaIE._TEST['info_dict']['duration'] is None or info['duration'] == 3600
    WallaIE._TEST['info_dict']['thumbnail'] is None or info['thumbnail'] == "http://images.wafla.co.il/images/5/5/5/2/7/5552700.jpg"
    WallaIE._TEST['info_dict']['title'] is None or info['title'] == "וואן דיירקשן: ההיסטריה"

# Generated at 2022-06-24 13:41:13.322685
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)

    assert ie.url == url
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.video_id == '2642630'
    assert ie.pattern_url == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    # Test for _SUBTITLE_LANGS
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:41:14.306287
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test for building an object successfully
    ie = WallaIE()
    assert ie.IE_NAME == "walla"

# Generated at 2022-06-24 13:41:15.652786
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test WallaIE constructor"""
    i = WallaIE()
    assert i.url_re == i._VALID_URL

# Generated at 2022-06-24 13:41:16.585216
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:41:17.129955
# Unit test for constructor of class WallaIE
def test_WallaIE():
	pass

# Generated at 2022-06-24 13:41:18.970785
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL is not None
    assert WallaIE._TEST is not None

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:41:21.761758
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:41:31.473683
# Unit test for constructor of class WallaIE
def test_WallaIE():
    
    # Test data
    test_data = {
                'id': '2642630',
                'display_id': 'one-direction-all-for-one',
                'title': 'וואן דיירקשן: ההיסטריה',
                'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
                'thumbnail': 'http://wafla.walla.co.il/media/thumbs/64/2868964/2868964_12.jpg',
                'duration': 3600,
                }
    
    # Expected result

# Generated at 2022-06-24 13:41:32.083592
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:41:36.723616
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Test for _VALID_URL: should be public
    ie._VALID_URL
    # Test for _TEST: should be public
    ie._TEST
    # Test for _SUBTITLE_LANGS: should be public
    ie._SUBTITLE_LANGS
    # Test for _real_extract()
    ie._real_extract()

# Generated at 2022-06-24 13:41:37.721982
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:41:38.708684
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:41:39.836358
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Instantiate the class
    ie = WallaIE()
    assert ie != None


# Generated at 2022-06-24 13:41:46.001044
# Unit test for constructor of class WallaIE
def test_WallaIE():
    module_name = 'walla'
    video_id = '2645756'
    url = 'http://vod.walla.co.il/movie/%s/made-in-israel' % video_id
    walla = WallaIE()
    assert walla._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert walla._SUBTITLE_LANGS['עברית'] == 'heb'
    assert walla._downloader is None
    assert walla.suitable(url)
    assert walla.IE_NAME in walla.ie_key()
    assert walla.ie_key() in walla.supported_ie()
    assert walla

# Generated at 2022-06-24 13:41:50.435936
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE({})
    assert ie
    assert ie._VALID_URL
    assert ie._TEST
    assert ie._SUBTITLE_LANGS
    assert ie._real_extract

# Generated at 2022-06-24 13:41:54.117727
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.description is not None
    assert ie.thumbnail is not None
    assert ie.title == "וואן דיירקשן: ההיסטריה"

# Generated at 2022-06-24 13:41:58.800859
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Test if object is created when constructor is called with valid url.
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    url = 'http://vod.walla.co.il/movie/%s/%s' % (video_id, display_id)
    WallaIE(url)
    pass

# Generated at 2022-06-24 13:42:05.854221
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video = WallaIE()
    assert video._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:09.330752
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert ("WallaIE", True, ["url"]) == WallaIE._build_ie_result(WallaIE._VALID_URL)

# Generated at 2022-06-24 13:42:20.514988
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla_ie = WallaIE()
    mobj = re.match(walla_ie._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')

    video = walla_ie._download_xml('http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,display_id)
    item = video.find('./items/item')
    title = xpath_text(item, './title', 'title')
    description = xpath_text(item, './synopsis', 'description')

# Generated at 2022-06-24 13:42:24.855890
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one") == False

# Generated at 2022-06-24 13:42:26.007234
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE(None);
	assert ie is not None;

# Generated at 2022-06-24 13:42:27.235435
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:42:27.876122
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:42:35.692520
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.title == 'וואן דיירקשן: ההיסטריה'
    assert 'One Direction All' in ie.description
    assert ie.duration == 3600
    assert ie.thumbnail == 'http://images.walls.co.il/images/1063443.jpg'
    assert ie.display_id == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:42:45.342688
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    wallaIE = WallaIE()
    mobj = re.match(wallaIE._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    subtitle_langs = wallaIE._SUBTITLE_LANGS
    video = wallaIE._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id)
    item = video.find('./items/item')
    title = xpath_text(item, './title', 'title')
    description

# Generated at 2022-06-24 13:42:47.271326
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('www.unittest.co.il')._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:49.179737
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_id() == 'walla'

# Generated at 2022-06-24 13:42:58.546736
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from ..WallaIE import WallaIE
    from ..utils import ExtractorError
    from .common import HEADRequest
    from .mtv import MTVIE
    from io import BytesIO
    from six.moves import urllib

    walla = WallaIE()
    assert walla._downloader is not None
    assert walla._downloader.cache.get.return_value is None
    assert isinstance(walla._downloader.cache.get('some_cache_key'), HEADRequest)
    assert walla._downloader.cache.get.call_count == 1

    class FakeDict(dict):

        def __eq__(self, other):
            if isinstance(other, dict):
                return dict.__eq__(self, other)
            return False


# Generated at 2022-06-24 13:43:06.237867
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for basic constructor of class WallaIE
    """
    # Positive test
    test_data = {
        'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
    }
    temp_walla_ie = WallaIE(test_data)
    assert temp_walla_ie.url == test_data['url']
    # Negative test
    test_data = {
        'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
    }
    temp_walla_ie = WallaIE(test_data)

# Generated at 2022-06-24 13:43:07.318815
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__module__ == "jswa.extractor.walla"

# Generated at 2022-06-24 13:43:13.216848
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:14.900064
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    assert ie == WallaIE();
    assert ie != InfoExtractor();

# Generated at 2022-06-24 13:43:18.746390
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(WallaIE._downloader, WallaIE._VALID_URL)
    # Video url download
    video_download = ie.download(WallaIE._VALID_URL)
    # Find all tags
    for tags in video_download:
        print(tags)


# Generated at 2022-06-24 13:43:21.405580
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Unit test: verify if the constructor of the class WallaIE produces correct output
# Tested with test case of One Direction All For One

# Generated at 2022-06-24 13:43:30.282203
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Test if the name is set correctly
    if ie.IE_NAME != 'walla':
        raise Exception(
            "Expected instatiation of class WallaIE to have IE_NAME == 'walla'")
    # Test if the regex is set correctly
    if not ie._VALID_URL.match("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"):
        raise Exception("Expected to apply regex on 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'")
    # Test if the regex does not match an invalid URL

# Generated at 2022-06-24 13:43:33.002285
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w != None
    info_dict = w.ie_key()
    assert info_dict != None


# Generated at 2022-06-24 13:43:36.226747
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    # Test object creation with valid url
    WallaIE(w._VALID_URL)
    # Test object creation with invalid url
    try:
        WallaIE("http://walla.co.il/movie/2642630/one-direction-all-for-one")
    except Exception:
        pass
    else:
        raise Exception("WallaIE not failed with invalid url")

# Generated at 2022-06-24 13:43:38.473688
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-24 13:43:41.774761
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:44.288625
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except Exception:
        raise Exception
    return None

# Generated at 2022-06-24 13:43:47.265868
# Unit test for constructor of class WallaIE
def test_WallaIE():
    e=WallaIE()
    e._real_extract('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

test_WallaIE()

# Generated at 2022-06-24 13:43:48.547497
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
        assert True
    except:
        assert False

# Generated at 2022-06-24 13:43:50.171387
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_obj = WallaIE()
    assert isinstance(test_obj, InfoExtractor)



# Generated at 2022-06-24 13:43:52.923961
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for constructor of class WallaIE"""
    video = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    print("mobj is of type: " + str(type(video)))

# Generated at 2022-06-24 13:44:00.032807
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global unit_test_initialized
    unit_test_initialized = False
    from ..utils import ExtractorError
    try:
        unit_test_initialized = True
        WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
        unit_test_initialized = False
        assert False
    except Exception as e:
        if not isinstance(e, ExtractorError):
            assert False
        assert True


# Generated at 2022-06-24 13:44:04.155892
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ppl = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one");

    assert ppl.url == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one";

# Generated at 2022-06-24 13:44:05.809289
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:44:08.832205
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:44:09.972933
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE('url')
    print(i)

# Generated at 2022-06-24 13:44:13.815028
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #print WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one').extract()
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:44:21.822742
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE._TEST
    assert t['info_dict']['id'] == '2642630'
    assert t['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert t['info_dict']['ext'] == 'flv'
    assert t['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'
    assert t['info_dict']['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert t['info_dict']['thumbnail'] == r're:^https?://.*\.jpg'
    assert t['info_dict']['duration'] == 3600

# Generated at 2022-06-24 13:44:25.996738
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
        print ('Test passed')
    except:
        print ('Test failed')

# Generated at 2022-06-24 13:44:26.670561
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-24 13:44:30.115198
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla:video'
    assert ie.SUITES[0] == ('regex', r'^https?://vod\.walla\.co\.il/[^/]+/.+')

# Generated at 2022-06-24 13:44:31.354720
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-24 13:44:38.061673
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert w._TEST.get('url') == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert w._TEST.get('info_dict').get('id') == '2642630'
    assert w._TEST.get('info_dict').get('display_id') == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:44:47.268869
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Check if the object was initialized correctly
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:56.743781
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:57.550083
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().IE_NAME == 'walla'

# Generated at 2022-06-24 13:44:58.639292
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE(None, None) is not None

# Generated at 2022-06-24 13:45:00.754398
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    walla._real_initialize()

# Generated at 2022-06-24 13:45:07.545890
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert (ie.SUBTITLE_LANGS == {
        'עברית': 'heb',
    })
    assert (ie.VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:45:08.850611
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:45:10.604501
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.DESCRIPTION == "Walla"
    assert ie.IE_NAME == "walla"

# Generated at 2022-06-24 13:45:12.527368
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """ Test that WallaIE constructor behaviour is correct """
    b = InfoExtractor("1", "2")
    assert b.ie_key() == "Walla"

# Generated at 2022-06-24 13:45:18.611869
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }


# Generated at 2022-06-24 13:45:23.129217
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    result = ie._real_extract(url)
    assert(result['id'] == '2642630')
    assert(result['title'] == 'וואן דיירקשן: ההיסטריה')

# Generated at 2022-06-24 13:45:24.164960
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:45:26.296309
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:45:27.187086
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-24 13:45:29.217935
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    except:
        import sys
        import traceback
        traceback.print_exc(file=sys.stdout)

# Generated at 2022-06-24 13:45:31.366920
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj.__class__.__name__ == WallaIE.__name__

# Generated at 2022-06-24 13:45:40.043496
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == 'WallaIE'
    assert WallaIE.__doc__ != None
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'
    assert WallaIE._TEST['info_dict']['id'] == '2642630'

# Generated at 2022-06-24 13:45:44.233276
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Testing constructor of class WallaIE
    def constructor_test():
        # Test 1:
        # Test if the instance is created correctly
        ie = WallaIE()
        assert ie is not None

    # Test if the constructor works as expected
    constructor_test()



# Generated at 2022-06-24 13:45:45.174998
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("WallaIE", "testcase")

# Generated at 2022-06-24 13:45:48.239570
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Instantiate WallaIE (An subclass of YoutubeIE and InfoExtractor)
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    # Call _real_extract method
    result = ie._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert result['formats'][0]['format_id'] == 'HD'

# Generated at 2022-06-24 13:45:48.851994
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:45:50.601623
# Unit test for constructor of class WallaIE
def test_WallaIE():
    intst = WallaIE()
    assert intst.get_domain() == 'walla.co.il'

# Generated at 2022-06-24 13:45:53.778934
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:59.307670
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wa = WallaIE()
    assert wa._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:01.708097
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla:video'
    assert ie._VALID_URL

# Generated at 2022-06-24 13:46:12.286703
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Initialize a WallaIE instance for unit-testing
    ie = WallaIE()
    # Check that the instance is initialized correctly
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:14.998727
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    print(ie.extract())

# Generated at 2022-06-24 13:46:23.746992
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    we = WallaIE(url)

# Generated at 2022-06-24 13:46:26.508819
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # create instance of class WallaIE
    # and makes sure it is not null (i.e. it is an object)
    assert WallaIE(InfoExtractor()) is not None



# Generated at 2022-06-24 13:46:32.549988
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for non-existing URL
    wrong_url = 'http://vod.walla.co.il/zxc123/1234567890123'
    ie = WallaIE(wrong_url)
    assert ie._VALID_URL == WallaIE._VALID_URL

    # Test for existing URL
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert ie._VALID_URL == WallaIE._VALID_URL


# Generated at 2022-06-24 13:46:41.445844
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL.match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'
    mobj = re.match(ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/on')
    assert mobj.group('id') == '2642630'
    assert mobj.group('display_id') == 'on'

# Generated at 2022-06-24 13:46:43.060320
# Unit test for constructor of class WallaIE
def test_WallaIE():
	info_extractor = WallaIE()
	assert info_extractor != None

# Generated at 2022-06-24 13:46:43.942650
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None

# Generated at 2022-06-24 13:46:47.542725
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert re.match(ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:46:48.218602
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()


# Generated at 2022-06-24 13:46:51.993224
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None).ie_key() == 'Walla'
    # url from youtube-dl/tests/test_WallaIE.py
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one').ie_key() == 'Walla'

# Generated at 2022-06-24 13:46:54.698131
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.NAME == 'walla'
    assert ie.VALID_URL == WallaIE._VALID_URL
    assert ie.TEST == WallaIE._TEST

# Generated at 2022-06-24 13:46:57.946547
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:47:02.174919
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:04.768412
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Testing constructor of WallaIE
    """
    # To test WallaIE class
    assert WallaIE

# Generated at 2022-06-24 13:47:05.309533
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:47:07.794579
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:47:10.077785
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from walla import WallaIE
    assert WallaIE.__name__ == 'WallaIE'

# Generated at 2022-06-24 13:47:10.936542
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suite()

# Generated at 2022-06-24 13:47:19.202923
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert w.url == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert w.urls == ['http://vod.walla.co.il/movie/2642630/one-direction-all-for-one']
    assert w.display_id == 'one-direction-all-for-one'
    assert w.extractor_key == 'walla'
    assert w.expected_errors == []
    assert w.extract_flat == None
    assert w.suitable == [u'WALLA! VOD']

# Generated at 2022-06-24 13:47:19.719064
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE

# Generated at 2022-06-24 13:47:20.531670
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()

# Generated at 2022-06-24 13:47:25.436686
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:47:28.699948
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    wie = WallaIE()
    wie.download(url)




# Generated at 2022-06-24 13:47:33.766446
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST == WallaIE._TEST
    assert WallaIE()._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert WallaIE._real_extract('test') == None

# Generated at 2022-06-24 13:47:36.124922
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:47:40.100637
# Unit test for constructor of class WallaIE
def test_WallaIE():
  testWallaIE = WallaIE('WallaIE')
  res = str(testWallaIE)

  if 'WallaIE' in res:
    print('Test successful. WallaIE is in res')
  else:
    print('Test failed')

# Run the test
test_WallaIE()

# Generated at 2022-06-24 13:47:42.042121
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:47:49.479499
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.get_url() == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.get_id() == 2642630
    assert ie.get_display_id() == 'one-direction-all-for-one'
    assert ie.get_type() == 'rtmp'
    assert ie.is_dash() == False

# Generated at 2022-06-24 13:47:51.062159
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE('url')
    assert 'WallaIE' == type(IE).__name__


# Generated at 2022-06-24 13:48:00.903659
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:02.192297
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:48:02.883764
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()

# Generated at 2022-06-24 13:48:11.978301
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://www.walla.co.il/item/2642225')
    assert ie.parse()['id'] == '2642225'
    assert ie.parse()['display_id'] == '2642225'
    assert ie.parse()['description'] == 'md5:6a2b6bd1af6a85d6c45c6b51a6a35d4a'
    assert ie.parse()['title'] == 'מחקר: כיצד מוציאים הסכסוכים את הכסף מהבית'
    assert ie.parse()['thumbnail'] == 're:^https?://.*\.jpg'

# Generated at 2022-06-24 13:48:24.663942
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:27.039290
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Smoke test for WallaIE
    ie = WallaIE(None)
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-24 13:48:28.788804
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Field self.ie_key is not used in __init__() of class WallaIE
    pass


# Generated at 2022-06-24 13:48:31.485434
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("rtmp://wafla.walla.co.il/vod?p=vod/@@/1085674/waflacom/mov/_df/20140509_1085674_waflacom_mov.flv")

# Generated at 2022-06-24 13:48:42.079967
# Unit test for constructor of class WallaIE
def test_WallaIE():
	"""
	Unit test for constructor of class WallaIE
	"""
	# Check if video URL is valid
	url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	assert WallaIE._VALID_URL == re.match(WallaIE._VALID_URL, url).re

	# Check if video web page is valid
	assert WallaIE._TEST['url'] == url

	# Check if video info dictionary is valid
	assert WallaIE._TEST['info_dict']['id'] == '2642630'
	assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
	assert WallaIE._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:48:51.529942
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit testing for WallaIE.
    Will create an instance of WallaIE and check
    if the given url is valid.
    """
    # Create a WallaIE instance
    walla_ie_obj = WallaIE()

    # Testing valid url
    assert walla_ie_obj.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    # Testing invalid url
    assert not walla_ie_obj.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/')

# Generated at 2022-06-24 13:48:54.361272
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE()
    assert info_extractor._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:48:55.977593
# Unit test for constructor of class WallaIE
def test_WallaIE():
    Test.assertEquals(WallaIE('WallaIE', 'WallaIE').ie_key(), 'Walla')

# Generated at 2022-06-24 13:48:56.490211
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:48:59.159142
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__.__name__ == 'WallaIE'

# Unit test of extractor

# Generated at 2022-06-24 13:49:00.429995
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE("")
    assert w is not None

# Generated at 2022-06-24 13:49:03.167828
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie == WallaIE

# Generated at 2022-06-24 13:49:06.276281
# Unit test for constructor of class WallaIE
def test_WallaIE():
    m = WallaIE.WallaIE
    # http://vod.walla.co.il/movie/2642630/one-direction-all-for-one
    url = m._VALID_URL
    mobj = re.match(url, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:49:07.755415
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    instance = WallaIE()
    assert instance

# Generated at 2022-06-24 13:49:09.297688
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();

    assert ie.ie_key() == 'Walla'
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-24 13:49:09.947012
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:49:16.266016
# Unit test for constructor of class WallaIE
def test_WallaIE():
  # Test with some arguments
  x = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
  # Ensure that it returns values which are not null
  assert x is not None

# Test for extractor of class WallaIE

# Generated at 2022-06-24 13:49:20.705294
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructor object
    obj_constructor = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    # Instance the object
    obj_instance = obj_constructor

# Generated at 2022-06-24 13:49:26.687597
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    extractor_test = WallaIE(InfoExtractor())
    assert extractor_test._VALID_URL == extractor_test.VALID_URL
    assert extractor_test._TEST['url'] == url

# Generated at 2022-06-24 13:49:28.951562
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # TODO
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:49:29.518535
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-24 13:49:35.897751
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.VALID_URL == WallaIE._VALID_URL
    assert ie._TEST == WallaIE._TEST
    assert ie._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert ie._real_extract == WallaIE._real_extract