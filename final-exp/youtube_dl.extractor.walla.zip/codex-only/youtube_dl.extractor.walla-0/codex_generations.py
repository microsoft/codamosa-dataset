

# Generated at 2022-06-24 13:39:36.421919
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)

    assert ie.__name__ == 'Walla'
    assert WallaIE._VALID_URL == WallaIE._TEST['url']
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-24 13:39:37.085997
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE()

# Generated at 2022-06-24 13:39:38.565360
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE()
    print(info_extractor._VALID_URL)


# Generated at 2022-06-24 13:39:45.752421
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test with 
    test_url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    test_IE = WallaIE(test_url)

    #assert test_IE.url == test_url
    assert test_IE.is_valid_url(test_url, True)
    assert test_IE.info_extractor() == 'walla'
    assert test_IE.get_url(test_url) == test_url
    assert test_IE.get_url(test_url) == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:39:57.630751
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:00.360853
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert (ie.url) == url
    assert (ie.is_valid()) == True
    assert (ie.validate()) == None


# Generated at 2022-06-24 13:40:03.613036
# Unit test for constructor of class WallaIE
def test_WallaIE():
    match = WallaIE._VALID_URL.match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert match is not None
    assert match.group('id') == '2642630'
    assert match.group('display_id') == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:40:04.337048
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-24 13:40:13.498708
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Testing constructor
    ie = WallaIE('')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:14.080773
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:40:22.611482
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:40:33.398776
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    video = WallaIE._real_extract(url)
    assert video['display_id'] == 'one-direction-all-for-one'
    assert video['id'] == '2642630'
    assert video['title'] == 'וואן דיירקשן: ההיסטריה'
    assert video['duration'] == 3600
    assert video['thumbnail'] == 're:^https?://.*\\.jpg'
    assert video['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert len(video['subtitles']) == 1
    assert len

# Generated at 2022-06-24 13:40:37.967889
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wr = WallaIE(url)
    assert wr is not None
    assert wr.video_id is '2642630'
    assert wr.display_id is 'one-direction-all-for-one'

# Generated at 2022-06-24 13:40:46.982656
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaie = WallaIE()
    assertequal(wallaie.ie_key(), 'walla')

# Generated at 2022-06-24 13:40:48.836815
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:40:51.529142
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    print (ie._VALID_URL);

# Generated at 2022-06-24 13:41:02.290335
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert wallaIE.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:04.610740
# Unit test for constructor of class WallaIE
def test_WallaIE():
    newWallaIE = WallaIE()
    assert newWallaIE.url_result() == newWallaIE._VALID_URL

# Generated at 2022-06-24 13:41:05.219479
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return

# Generated at 2022-06-24 13:41:06.077284
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:41:16.660866
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
                'test')
    assert a._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:20.529665
# Unit test for constructor of class WallaIE
def test_WallaIE():
    r = WallaIE()
    assert r.ie_key() == 'Walla'
    assert r.IE_NAME == 'Walla'
    assert r.ie_key() in r.gen_extractors()
    assert WallaIE.ie_key() == 'Walla'
    assert WallaIE.IE_NAME == 'Walla'
    assert WallaIE.ie_key() in WallaIE.gen_extractors()

# Generated at 2022-06-24 13:41:24.516021
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Creating instance of WallaIE class
    walla_ie_instance = WallaIE()
    # Checking if this instance is really an instance of WallaIE class
    assert isinstance(walla_ie_instance, WallaIE)

# Generated at 2022-06-24 13:41:25.858645
# Unit test for constructor of class WallaIE
def test_WallaIE():
    extractor = WallaIE()
    assert extractor is not None

# Generated at 2022-06-24 13:41:34.715257
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # class attribute
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}
    # method

# Generated at 2022-06-24 13:41:36.430195
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert re.match(WallaIE._VALID_URL, WallaIE._TEST['url'])

# Generated at 2022-06-24 13:41:38.842926
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS['עברית'] == 'heb'


# Generated at 2022-06-24 13:41:41.494470
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST == ie.test()

# Generated at 2022-06-24 13:41:43.993879
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_class = WallaIE()
    assert test_class

# Generated at 2022-06-24 13:41:47.125290
# Unit test for constructor of class WallaIE
def test_WallaIE():
	video_id = "2642630"
	display_id = "one-direction-all-for-one"
	url = "http://vod.walla.co.il/movie/" + video_id + "/" + display_id
	ie = WallaIE(url)
	return

# Generated at 2022-06-24 13:41:50.754386
# Unit test for constructor of class WallaIE
def test_WallaIE():
  wallaIE = WallaIE()
  assert wallaIE._VALID_URL != None
  assert wallaIE._TEST != None
  assert wallaIE._SUBTITLE_LANGS != None

# Generated at 2022-06-24 13:41:59.130772
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE('Walla')

    # Following line raises AttributeError: 'WallaIE' object has no attribute '_VALID_URL'
    instance.test_WallaIE()

# Generated at 2022-06-24 13:42:04.701321
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:08.324505
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._download_xml('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl', 'one-direction-all-for-one') is not None

# Generated at 2022-06-24 13:42:09.362881
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None



# Generated at 2022-06-24 13:42:10.487055
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:42:15.765424
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Arrange
    valid_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Act
    WallaIE()._real_extract(valid_url)
    # Assert
    # No exception should be raised

# Generated at 2022-06-24 13:42:18.013788
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:42:24.605167
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # dict of url and video_id
    mapping = [
        ('http://vod.walla.co.il/movie/2641013/e-t-the-extra-terrestrial', '2641013'),
        ('http://vod.walla.co.il/player/2641002/one-direction-all-for-one', '2641002'),
        ('http://vod.walla.co.il/item/2641003/e-t-the-extra-terrestrial', '2641003')
    ]
    for url, video_id in mapping:
        mobj = ie._VALID_URL.match(url)
        assert mobj is not None
        assert mobj.group('id') == video_id

# Generated at 2022-06-24 13:42:26.590775
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:42:28.665840
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:42:38.897404
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE({})
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:44.639339
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test empty attributes
    ie = WallaIE()
    assert ie._VALID_URL is None
    assert ie._TEST is None
    assert ie._SUBTITLE_LANGS is None

    # test regular attributes
    WallaIE._VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:51.987820
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test of constructor of class WallaIE"""
    instance = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert instance._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:53.297448
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test the class constructor
    obj = WallaIE()
    return obj

# Generated at 2022-06-24 13:42:57.457503
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().match('http://vods.walla.co.il/movie/2642630/one-direction-all-for-one') == 'http://vods.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:43:05.257982
# Unit test for constructor of class WallaIE
def test_WallaIE():
	walla = WallaIE()
	assert walla._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
	assert walla._SUBTITLE_LANGS['עברית'] == 'heb'
	assert walla._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	assert walla._TEST['info_dict']['id'] == '2642630'
	assert walla._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:43:11.770843
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(downloader=None, download_defaults={'ftp_proxy': None})
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(ie._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    download_url = 'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id
    xml_data = ie._download_webpage(download_url, display_id, note='Downloading XML', errnote='Unable to download XML')
    video = ie._parse_xml(xml_data, display_id)

# Generated at 2022-06-24 13:43:17.996260
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create an instance of WallaIE
    ie = WallaIE()

    # Check if we are at homepage of WallaIE
    homepage = ie.homepage
    expected_homepage = 'http://www.walla.co.il/'
    assert homepage == expected_homepage

    # Check if we can access the extractor function
    extractor_function = ie.extract_func
    expected_extractor_func = WallaIE._real_extract

    assert extractor_function == expected_extractor_func



# Generated at 2022-06-24 13:43:19.869529
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE(None, None)
    assert w.SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-24 13:43:21.357867
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except Exception:
        pass
    assert WallaIE.__name__ == 'WallaIE'

# Generated at 2022-06-24 13:43:22.225602
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:43:24.171581
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:26.266337
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Creating an instance of the walla class
	walla = WallaIE()
	# Testing an instance has been created
	assert(walla is not None)

# Generated at 2022-06-24 13:43:31.707307
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla:movie'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert repr(ie) == '<WallaIE(walla:movie)>'


# Generated at 2022-06-24 13:43:37.516704
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.url=='https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Please add more test cases

# Generated at 2022-06-24 13:43:47.223074
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test fail without url
    assert(WallaIE() == None)

    # Test fail with invalid url
    assert(WallaIE('notaurl') == None)

    # Test success with valid url and attributes
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(url)
    assert(WallaIE(url)._VALID_URL ==
           r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:43:48.502879
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global WallaIE
    WallaIE(None, None)

# Generated at 2022-06-24 13:43:50.783305
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:56.112161
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie_result = ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie_result['id'] == '2642630'
    assert ie_result['display_id'] == 'one-direction-all-for-one'


# Generated at 2022-06-24 13:43:58.746424
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:44:01.056420
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert re.match(ie._VALID_URL, ie._TEST.get('url'));

# Generated at 2022-06-24 13:44:05.498333
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = r'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.initialize(url)



# Generated at 2022-06-24 13:44:06.029041
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-24 13:44:14.562136
# Unit test for constructor of class WallaIE
def test_WallaIE():
    u = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(u)
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == u
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:44:16.407900
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:44:22.656716
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from YDStreamExtractor import create_IE
    from YDStreamExtractor.compat import compat_str, compat_urllib_parse_urlparse

    ie = create_IE("walla")("http://vod.walla.co.il/movie/2504773/snowden")
    info = ie.extract()
    assert info["id"] == "2504773"
    assert info["display_id"] == "snowden"
    assert info["title"] == "סנודן"
    assert info["ext"] == "flv"

    assert info["http_headers"]["User-Agent"] == ie._USER_AGENT

    # Needed to support various formats for youtube-dl
    # https://github.com/rg3/youtube-dl/pull/11598

# Generated at 2022-06-24 13:44:23.600520
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('url')

# Generated at 2022-06-24 13:44:27.423303
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.get_info({"url":"http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"})

# Generated at 2022-06-24 13:44:28.716402
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'Walla'

# Generated at 2022-06-24 13:44:36.720992
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# url is "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
	WallaIE_test = WallaIE()
	assert_equals(WallaIE_test._VALID_URL, r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
	ex = WallaIE_test._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:44:46.174698
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE({})
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.IE_NAME == 'Walla'
    assert ie.LANG == 'he'
    assert ie.template == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:44:47.658098
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:44:56.956769
# Unit test for constructor of class WallaIE
def test_WallaIE():
	w = WallaIE();
	assert w.IE_NAME == 'walla'
	assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:59.041654
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('')
    ie._VALID_URL = WallaIE._VALID_URL
    ie._TEST = WallaIE._TEST
    ie.suite()

# Generated at 2022-06-24 13:45:00.211058
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # check if WallaIE can be initialized
    obj = WallaIE()

# Generated at 2022-06-24 13:45:09.419001
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:15.860195
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    assert ie.get_id() == "walla"
    assert ie.get_name() == "Walla"
    assert ie.get_url_regular_expression() == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.get_test()['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.get_test()['info_dict']['id'] == '2642630'
    assert ie.get_test()['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:45:18.754208
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-24 13:45:29.355786
# Unit test for constructor of class WallaIE
def test_WallaIE():
    inst = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert inst._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:30.683480
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-24 13:45:33.848958
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:35.754342
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:45:43.284548
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:45.452950
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:47.196127
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert len(obj._SUBTITLE_LANGS.values()) == 1

# Generated at 2022-06-24 13:45:56.470783
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == '', 'Test failed: _VALID_URL == ""'
    ie._VALID_URL = 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    
    assert ie._SUBTITLE_LANGS == {}, 'Test failed: _SUBTITLE_LANGS == {}'
    ie._SUBTITLE_LANGS = {'עברית': 'heb'}
    
    assert ie._TEST == {}, 'Test failed: _TEST == {}'

# Generated at 2022-06-24 13:45:57.885590
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS.get('עברית') == 'heb'

# Generated at 2022-06-24 13:46:00.913157
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:05.496231
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    print ("test_WallaIE Completed")


# Generated at 2022-06-24 13:46:08.562817
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert 'walla.co.il' in ie.IE_NAME
    assert 'ההיסטריה' in ie._TEST['info_dict']['title']

# Generated at 2022-06-24 13:46:10.641649
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj_WallaIE = WallaIE()
    assert obj_WallaIE != None, 'Could not create an object of class WallaIE!'


# Generated at 2022-06-24 13:46:11.584460
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:46:14.330208
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:23.329151
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .six.moves.configparser import ConfigParser
    import ast
    import os
    import pkgutil
    import re
    import sys

    #make every class in IE available
    import youtube_dl.extractor
    gl = globals()
    gl.update({ie.IE_NAME: ie for ie in youtube_dl.extractor.gen_extractors()})

    def extract_constants(text):
        """Return the Python objects names in a text."""
        return re.findall(r'[A-Z][A-Z0-9_]+', text)

    class MockYDL(object):
        """If you experience any error running this test, you may want
        to comment out some tests in YoutubeDL.test()
        """
        def __init__(self):
            self.ies = []


# Generated at 2022-06-24 13:46:31.380954
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:46:43.111123
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie._WORKING
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:48.022700
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaie = WallaIE('http://www.walla.co.il')
    assert(wallaie.url == 'http://www.walla.co.il')
    assert(wallaie.ie_key == 'Walla')
    assert(wallaie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:46:49.418940
# Unit test for constructor of class WallaIE
def test_WallaIE():
    '''
    constructor test
    '''
    obj = WallaIE()

# Generated at 2022-06-24 13:46:51.167043
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.get_subtitle_langs() == {'heb'}

# Generated at 2022-06-24 13:47:01.281320
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:47:01.773514
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:47:08.137582
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # install instance of WallaIE
    # and assert that it is an instance of InfoExtractor
    ie = WallaIE()
    assert(isinstance(ie, InfoExtractor))

    # test class method suitable()
    # empty url
    assert(not ie.suitable(""))
    # video_id only
    assert(not ie.suitable("2642630"))
    # video_id with display_id
    assert(ie.suitable("2642630/one-direction-all-for-one"))
    # url with an invalid prefix
    assert(not ie.suitable("http://www.walla.co.il/2642630"))
    # url with vaild prefix
    assert(ie.suitable("http://vod.walla.co.il/2642630/one-direction-all-for-one"))

   

# Generated at 2022-06-24 13:47:13.200796
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE("test_url")

    expected_valid_url = re.compile("https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)")
    assert walla._VALID_URL == expected_valid_url
    assert walla._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert walla._TEST['info_dict']['id'] == '2642630'
    assert walla._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:47:14.092901
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suite()

# Generated at 2022-06-24 13:47:22.903307
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:24.121650
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE(InfoExtractor()).IE_NAME == 'walla'

# Generated at 2022-06-24 13:47:28.984491
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['id'] == '2642630'
    assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:47:39.560225
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = WallaIE()._TEST['url']
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST == WallaIE._TEST
    assert WallaIE()(url).display_id == WallaIE()._TEST['info_dict']['display_id']
    assert WallaIE()(url).title == WallaIE()._TEST['info_dict']['title']
    assert WallaIE()(url).description == WallaIE()._TEST['info_dict']['description']
    assert WallaIE()(url).thumbnail == WallaIE()._TEST['info_dict']['thumbnail']
    assert WallaIE()(url).duration == WallaIE()._TEST['info_dict']['duration']



# Generated at 2022-06-24 13:47:41.232496
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('NoArgs', {})

# Generated at 2022-06-24 13:47:43.648207
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:47:53.423184
# Unit test for constructor of class WallaIE
def test_WallaIE():
	temp = WallaIE('url', {'skip_download': True})
	assert temp._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:55.529856
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == ie.ie_key()
    ie = WallaIE('Walla')
    assert ie.IE_NAME == 'Walla'

# Generated at 2022-06-24 13:47:56.615511
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-24 13:48:06.729379
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    assert ie.name == 'Walla';
    assert ie.url_re == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)';
    assert ie.display_id_re == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)';
    assert ie.test.__class__.__name__ == '_Dict';


# Generated at 2022-06-24 13:48:14.464766
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import sys
    import os
    import unittest
    sys.path.append(os.path.join(os.path.split(os.path.realpath(__file__))[0], '../..'))
    from youtube_dl.utils import parse_duration

    # Test record for WallaIE
    class TestWallaIE(unittest.TestCase):

        def setUp(self):
            self.ie = WallaIE()

        def test_extract_from_WallaIE(self):
            url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:48:20.526131
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    url = 'http://vod.walla.co.il/movie/%s/%s' % (video_id, display_id)
    ie = WallaIE(url)
    assert ie

# Generated at 2022-06-24 13:48:21.933101
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # constructor call
    WallaIE(WallaIE.ie_key())

# Generated at 2022-06-24 13:48:27.135176
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import sys
    try:
        WallaIE(sys.argv[1])
    except IndexError:
        print("Please enter a valid URL for class WallaIE")
    except:
        print("Unexpected error:", sys.exc_info()[0])

if __name__ == "__main__":
    test_WallaIE()

# Generated at 2022-06-24 13:48:29.252611
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:48:30.114145
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .universal import _test_ie
    _test_ie(WallaIE)()

# Generated at 2022-06-24 13:48:35.629958
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test the WallaIE constructor
    # In order to test WallaIE, we need a test for the constructor.
    # Since the constructor does nothing, we rely on the parent class
    from .common import InfoExtractor
    from .walla import WallaIE
    ie = WallaIE(InfoExtractor())
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-24 13:48:37.480440
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_ie = WallaIE()
    video_ie.initialize()
    

# Generated at 2022-06-24 13:48:46.197396
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE({})
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:48.859217
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:48:50.000051
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w

# Generated at 2022-06-24 13:48:58.631073
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # This extractor is supposed to be derived from the class InfoExtractor
    derived_class_name = "WallaIE"
    constructor_class_name = type(WallaIE()).__name__

    assert derived_class_name == constructor_class_name, "The derived class name '%s' does not match to the constructor class name '%s'." % (derived_class_name, constructor_class_name)
    assert derived_class_name != constructor_class_name, "The derived class name '%s' should not match to the constructor class name '%s'." % (derived_class_name, constructor_class_name)

# Generated at 2022-06-24 13:49:00.501783
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:49:06.253490
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    assert(ie.name == 'Walla')
    assert(ie.valid_url == WallaIE._VALID_URL)

    vid = _TEST = '2642630'
    assert(ie.url_to_id(ie._VALID_URL % vid) == vid)

    return ie


# Generated at 2022-06-24 13:49:09.601136
# Unit test for constructor of class WallaIE
def test_WallaIE():
    g = globals()
    for key, val in g.iteritems():
        if key.startswith('WallaIE'):
            assert val

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:49:11.783107
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ### Test WallaIE
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:49:20.358369
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'
   

# Generated at 2022-06-24 13:49:27.077727
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/?w=mobile/2642630/one-direction-all-for-one"
    match = WallaIE._VALID_URL.match(url)
    assert match is not None
    assert match.groupdict()['id'] == '2642630'
    assert match.groupdict()['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:49:30.163211
# Unit test for constructor of class WallaIE
def test_WallaIE():
    c = WallaIE()
    assert c.ID == 'Walla'
    assert c.NAME == 'Walla vod'
    assert c.PATTERN == WallaIE._VALID_URL

# Generated at 2022-06-24 13:49:33.896502
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    _ = WallaIE()._real_extract(url)