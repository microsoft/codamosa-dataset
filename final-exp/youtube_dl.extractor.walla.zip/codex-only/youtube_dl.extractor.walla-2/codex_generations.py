

# Generated at 2022-06-24 13:39:45.794054
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert repr(ie) == '<WallaIE>'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:39:51.292287
# Unit test for constructor of class WallaIE
def test_WallaIE():
    r = re.match(WallaIE._VALID_URL, WallaIE._TEST['url'])
    assert r.group('id') == WallaIE._TEST['info_dict']['id']
    assert r.group('display_id') == WallaIE._TEST['info_dict']['display_id']

# Generated at 2022-06-24 13:40:00.537118
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test basic initialization
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    # Test wrong url
    from .common import ExtractorError
    from ..compat import compat_urlparse
    url = compat_urlparse.urljoin("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one",
                                  "http://local.walla.co.il/vod/films22/2643872/video/2643872.mp4")
    assert_raises(ExtractorError,WallaIE,url)

# Generated at 2022-06-24 13:40:06.945613
# Unit test for constructor of class WallaIE
def test_WallaIE():
    website = WallaIE('test').test()
    assert website.display_id == 'one-direction-all-for-one'
    assert website.title == 'וואן דיירקשן: ההיסטריה'
    assert website.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:40:12.343547
# Unit test for constructor of class WallaIE
def test_WallaIE():
	from .common import InfoExtractor
	ie = InfoExtractor()
	assert ie.IE_NAME == 'walla'
	assert ie.IE_DESC == 'Walla! vod'
	assert ie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
	assert ie.TEST.keys() == [
		'url',
		'info_dict',
		'params'
	]
	assert ie.TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:40:14.358890
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-24 13:40:15.667357
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._real_extract(_TEST)

# Generated at 2022-06-24 13:40:18.834520
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('walla.co.il', 'walla.co.il/vod/2642630/one-direction-all-for-one')
    assert ie.extractor_key == 'Walla'

# Generated at 2022-06-24 13:40:26.859627
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test ok
    w = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    video = w._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id)

    item = video.find('./items/item')

    title = 'וואן דיירקשן: ההיסטריה' #xpath_text(item, './title', 'title')

# Generated at 2022-06-24 13:40:29.193422
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:31.480879
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    print(ie._VALID_URL)
    print(ie._TEST)


# Generated at 2022-06-24 13:40:34.110945
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert hasattr(x, '_SUBTITLE_LANGS')
    assert hasattr(x, '_VALID_URL')

# Generated at 2022-06-24 13:40:38.292311
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.SUFFIX == 'walla.co.il'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:47.221832
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_urls = ["http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"]
    for test_url in test_urls:
        ie = WallaIE()

    if (ie._VALID_URL != r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'):
        raise Exception("The url is not valid")

    if (ie._TEST["url"] != "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"):
        raise Exception("The url is not valid")


# Generated at 2022-06-24 13:40:54.979546
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from walla_ie import WallaIE
    from datetime import datetime
    video = WallaIE._download_xml(
            'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl',
            "2642630")
    item = video.find('./items/item')
    title = WallaIE._search_regex(r'<title>([^<]+)', item, 'title', default=None)
    description = WallaIE._search_regex(r'<synopsis>([^<]+)', item, 'description', default=None)
    assert title == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:41:02.656751
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert re.match(WallaIE._VALID_URL, url)
    ie = WallaIE()
    mobj = re.match(ie._VALID_URL, url)
    assert video_id == mobj.group('id')
    assert display_id == mobj.group('display_id')

# Generated at 2022-06-24 13:41:06.550316
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:10.838933
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    print(ie._VALID_URL)
    print(ie._download_xml)
# test_WallaIE()

# Generated at 2022-06-24 13:41:20.047428
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:30.403024
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:31.471789
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:41:33.006900
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None, 'Failed to create WallaIE'

# Generated at 2022-06-24 13:41:42.321477
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Unit test code from:
    # https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/walla.py
    #
    # This is a unit test for the constructor of the class WallaIE
    #
    # 
    # Note:
    # This unit test is note meant to be a complete
    # testing of the functionality of WallaIE, it is only
    # to verify the functionality of the constructor of WallaIE

    # Basic unit test variables
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test_args = []

# Generated at 2022-06-24 13:41:44.032123
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    walla

# Generated at 2022-06-24 13:41:48.686461
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    print(repr(ie))
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    print(repr(ie))

# Generated at 2022-06-24 13:41:51.025342
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:41:51.649065
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:41:55.137345
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.matches("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert not ie.matches("http://walla.co.il")

# Generated at 2022-06-24 13:41:56.006862
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert info_extractor is not None

# Generated at 2022-06-24 13:41:59.095772
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie = WallaIE('Walla')
    assert ie.ie_key() == 'Walla'

    ie = WallaIE(ie_key='Walla')
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-24 13:42:06.161307
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:09.874215
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:42:14.524646
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test WallaIE
    """
    walla = WallaIE()
    walla._download_xml('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl','one-direction-all-for-one')

# Generated at 2022-06-24 13:42:15.289275
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global  WallaIE
    assert WallaIE

# Generated at 2022-06-24 13:42:24.577333
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:34.931248
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    obj = WallaIE()
    assert obj._VALID_URL =="https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"
    assert obj._TEST['url'] == test_url
    assert obj._TEST['info_dict']['id'] == '2642630'
    assert obj._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert obj._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:42:36.529651
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla is not None

# Generated at 2022-06-24 13:42:38.387318
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("<URL>")
    assert ie._VALID_URL is not None

# Generated at 2022-06-24 13:42:39.283687
# Unit test for constructor of class WallaIE
def test_WallaIE():
	x = WallaIE()


# Generated at 2022-06-24 13:42:41.601392
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .__main__ import main
    main(WallaIE.ie_key(), 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:42:49.048565
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    ie._TEST_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

    ie._SUBTITLE_LANGS = {
        'עברית': 'heb',
    }
    assert ie._SUBTITLE_LANGS.get('עברית') == 'heb'

# Generated at 2022-06-24 13:42:51.097666
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("https://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.download("2642630")

# Generated at 2022-06-24 13:42:51.765024
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-24 13:43:00.826280
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(ie._VALID_URL, test_url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    video = ie._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id)
    item = video.find('./items/item')
    title = xpath_text(item, './title', 'title')
    # Return the video title
    return title


# Generated at 2022-06-24 13:43:02.229882
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:09.407750
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test 1
    _test_url_1 = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    _test_info_dict_1 = {
        'id': '2642630',
        'display_id': 'one-direction-all-for-one',
        'ext': 'flv',
        'title': 'וואן דיירקשן: ההיסטריה',
        'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        'thumbnail': r're:^https?://.*\.jpg',
        'duration': 3600,
    }

    ie = WallaIE(_test_url_1)
    #

# Generated at 2022-06-24 13:43:14.747338
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'videos.walla.co.il'
    ie._VALID_URL == 'http://vod.walla.co.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:16.965307
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:43:26.556083
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()
    assert IE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:28.450245
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 13:43:28.981588
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:43:38.846404
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:48.765306
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    urls = ie._extract_urls(video_url)

    video_id = "2642630"
    display_id = "one-direction-all-for-one"

    assert urls == [video_url]
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:56.841144
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.SUFFIX, 'vod.walla.co.il'
    assert ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST, 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl'
    assert ie._SUBTITLE_LANGS, 'עברית'

# Generated at 2022-06-24 13:43:59.090344
# Unit test for constructor of class WallaIE
def test_WallaIE():
	test_WallaIE = WallaIE(None)
	assert test_WallaIE != None

# Generated at 2022-06-24 13:44:03.393883
# Unit test for constructor of class WallaIE
def test_WallaIE():
    site = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert (site.video_id == "2642630")
    assert (site.display_id == "one-direction-all-for-one")



# Generated at 2022-06-24 13:44:03.932974
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:44:05.150147
# Unit test for constructor of class WallaIE
def test_WallaIE():
    if __name__ == '__main__':
        WallaIE().download_test()

# Generated at 2022-06-24 13:44:09.427204
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert obj._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:44:11.103794
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:44:11.666872
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:44:19.478687
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor_o= WallaIE()
    # Unit test for _real_extract method
    res_dict = info_extractor_o._real_extract(url='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert res_dict['id'] == '2642630'
    assert res_dict['display_id'] == 'one-direction-all-for-one'
    assert res_dict['ext'] == 'flv'
    assert res_dict['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:44:21.280563
# Unit test for constructor of class WallaIE
def test_WallaIE():
  ie = WallaIE(None)
  assert ie.VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:44:23.473881
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check if WallaIE(InfoExtractor) is type of InfoExtractor
    assert issubclass(WallaIE, InfoExtractor)


# Generated at 2022-06-24 13:44:33.659909
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:44.715751
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class_ = WallaIE
    assert type(class_) == type

    instance = class_(None)
    assert type(instance) == class_
    info = instance._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert info['id'] == '2642630'
    assert info['display_id'] == 'one-direction-all-for-one'
    assert info['ext'] == 'flv'
    assert info['title'] == 'וואן דיירקשן: ההיסטריה'
    assert info['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert info['thumbnail'] == r

# Generated at 2022-06-24 13:44:46.837065
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.extract_info(url)

# Generated at 2022-06-24 13:44:56.493929
# Unit test for constructor of class WallaIE
def test_WallaIE():
    "Test for class constructor"
    # Input: 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Expected: WallaIE object

    # TEST 1:
    # Try to instantiate WallaIE class for testing.
    # If it fails raise ValueError.
    try:
        walla_ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    except ValueError:
        raise

    # Verify that class WallaIE has been initalized as expected
    if not type(walla_ie) == WallaIE:
        raise TypeError("WallaIE initialization was unsuccessful.")

# Generated at 2022-06-24 13:44:59.003263
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_desc() == 'Walla!'
    assert ie._VALID_URL == ie.VALID_URL


# Generated at 2022-06-24 13:45:01.154544
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:02.562618
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 13:45:03.052262
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:45:03.875746
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:45:10.182900
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert x._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:12.424094
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-24 13:45:14.476945
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', {'skip_download': True})

# Generated at 2022-06-24 13:45:18.705868
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    return ie


if __name__ == '__main__':
    r = test_WallaIE()
    print(r)

# Generated at 2022-06-24 13:45:21.530583
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:23.816964
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:27.927989
# Unit test for constructor of class WallaIE
def test_WallaIE():
    vod = WallaIE()
    assert vod._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert vod.__name__ == 'Walla'

# Generated at 2022-06-24 13:45:28.967954
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:45:32.611678
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    video = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    oe = ie.extract(video)

# Generated at 2022-06-24 13:45:35.964792
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Class constants are available during the test
    test = WallaIE(None)
    # Class methods are available during the test
    assert test._real_extract(test._TEST['url'])['title'] == test._TEST['info_dict']['title']

# Generated at 2022-06-24 13:45:36.873830
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()
    assert IE

# Generated at 2022-06-24 13:45:39.467150
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)
    assert ie._downloader is not None


# Generated at 2022-06-24 13:45:43.279109
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable(WallaIE._TEST['url'])
    ie.extract(WallaIE._TEST['url'])
    ie.extract(WallaIE._TEST['url'], download=False)

# Generated at 2022-06-24 13:45:44.188617
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.initialize()

# Generated at 2022-06-24 13:45:53.690762
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import sys
    import re
    import unittest

    class test_WallaIE(unittest.TestCase):
        def setUp(self):
            self.WallaIE = WallaIE('WallaIE', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

        def test_get_code(self):
            self.assertEqual(self.WallaIE._VALID_URL, 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')


# Generated at 2022-06-24 13:45:54.911439
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from extractors.walla import WallaIE
    v = WallaIE()
    assert v.extractor_key == 'walla'

# Generated at 2022-06-24 13:45:56.844629
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:45:57.802626
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE();
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-24 13:46:08.729983
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('Walla.co.il', 'Walla.co.il', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    video = ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert video['id'] == '2642630'
    assert video['display_id'] == 'one-direction-all-for-one'
    assert video['title'] == 'וואן דיירקשן: ההיסטריה'
    assert video['description'] == '\nmd5:de9e2512a92442574cdb0913c49bc4d8'

# Generated at 2022-06-24 13:46:10.494039
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:12.343858
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test that isinstance(WallaIE(), InfoExtractor) == True
    assert isinstance(WallaIE(), InfoExtractor)

# Generated at 2022-06-24 13:46:21.213954
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie=WallaIE()
    ie._VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:24.955417
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie)


# Generated at 2022-06-24 13:46:32.962281
# Unit test for constructor of class WallaIE
def test_WallaIE():
    main_object = WallaIE()
    assert main_object.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert main_object.IE_NAME == 'walla'
    assert main_object.info_dict.keys() == ['id', 'display_id', 'ext', 'title', 'description', 'thumbnail', 'duration']
    assert main_object.info_dict['id'] == '2642630'
    assert main_object.info_dict['display_id'] == 'one-direction-all-for-one'
    assert main_object.info_dict['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'

# Generated at 2022-06-24 13:46:35.123700
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _WallaIE = WallaIE()

# Generated at 2022-06-24 13:46:44.327494
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("")
    ie.create_instance("")
    assert ie.__class__.__name__ == 'WallaIE'
    assert ie.ie_key() == 'Walla'
    assert ie.server_url() == 'http://vod.walla.co.il/'
    assert ie.title() == 'וואלה! ודיגיטל'
    assert ie.description() == 'הכתבות החמות ביותר בעולם הטכנולוגיה והאינטרנט'
    assert ie.extractor_key() == 'Walla'

# Generated at 2022-06-24 13:46:52.551789
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-24 13:46:57.625716
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructing WallaIE object
    ie = WallaIE()
    # Testing url from _TEST dict
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Testing validity of url
    ie._match_id(url)
    # Testing extraction of information
    ie.extract(url)

# Generated at 2022-06-24 13:47:03.337611
# Unit test for constructor of class WallaIE
def test_WallaIE():
#     test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    # retrieve the video by the url
    video = WallaIE().suitable(test_url)[0].extract(test_url)
    # print the url
    print (video)

# Generated at 2022-06-24 13:47:07.332664
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download_webpage(ie._TEST['url'], html_fname='WallaIE/webpage.html')
    assert ie.extract_info(ie._TEST['url'], download_webpage=False)

# Generated at 2022-06-24 13:47:13.596771
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_cases = [
        (
            'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
            {
                'id': '2642630',
                'display_id': 'one-direction-all-for-one'
            }
        )
    ]

    for i, test in enumerate(test_cases):
        ie = WallaIE(test[0])
        assert test[1]['id'] == ie._VALID_URL

# Generated at 2022-06-24 13:47:17.870707
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:20.801136
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-24 13:47:25.197960
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

    # Test #1
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert obj._match_id(url) == (264230, 'one-direction-all-for-one')

# Generated at 2022-06-24 13:47:27.671564
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")


# Test for method of class WallaIE that extract the video

# Generated at 2022-06-24 13:47:30.494264
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:47:31.638918
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None, None)

# Generated at 2022-06-24 13:47:35.874088
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._VALID_URL == WallaIE.VALID_URL
    assert re.match(WallaIE._VALID_URL, url)

# Generated at 2022-06-24 13:47:40.245371
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(ie.validate() == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')



# Generated at 2022-06-24 13:47:43.235793
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suite()
    ie.setUp()
    ie.extract()
    ie.tearDown()

# Generated at 2022-06-24 13:47:44.932843
# Unit test for constructor of class WallaIE
def test_WallaIE():
    constructor = WallaIE(None)
    assert constructor == WallaIE

# Generated at 2022-06-24 13:47:45.568890
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:47:47.515576
# Unit test for constructor of class WallaIE
def test_WallaIE():
    init = WallaIE()
    assert isinstance(init, WallaIE)



# Generated at 2022-06-24 13:47:49.982895
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import WallaIE
    from .common import InfoExtractor

    assert isinstance(WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"), InfoExtractor)==True

# Generated at 2022-06-24 13:47:50.945818
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:47:52.381553
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info = WallaIE().extract(WallaIE._TEST['url'])
    print(info)

# Generated at 2022-06-24 13:47:53.266541
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # unit test case is not ready yet.
    pass

# Generated at 2022-06-24 13:48:00.127315
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:48:05.998444
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #Constancts
    TEST_URL = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    TEST_VIDEO_ID = '2642630'
    TEST_DISPLAY_ID = 'one-direction-all-for-one'
    TEST_TITLE = 'וואן דיירקשן: ההיסטריה'
    TEST_DURATION = 3600
    TEST_SUBTITLE_URL = 'http://wafla.walla.co.il/vod/vod_sub/2642630_270514_146713.srt'
    TEST_GUID = '@@/movie/2642630/one-direction-all-for-one'
    TEST_PREVIEW

# Generated at 2022-06-24 13:48:09.480780
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        e = WallaIE("https://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    except:
        print("fail to create WallaIE")
        return False
    return True

# Generated at 2022-06-24 13:48:13.247805
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == { 'עברית': 'heb' }

# Generated at 2022-06-24 13:48:23.665562
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    walla_test = w._TEST
    assert walla_test['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert walla_test['info_dict']['id'] == '2642630'
    assert walla_test['info_dict']['ext'] == 'flv'
    assert walla_test['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:48:25.317071
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None, {}, '0') is not None

# Generated at 2022-06-24 13:48:27.090406
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS.get('עברית') == 'heb'

# Generated at 2022-06-24 13:48:35.399228
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:37.257109
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE('walla', True)
    assert isinstance(IE, InfoExtractor)

# Generated at 2022-06-24 13:48:39.376713
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:48:40.717811
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.ie_key() == 'Walla'

# Generated at 2022-06-24 13:48:42.787631
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("")
    ie.extract("")
    ie = WallaIE("")
    ie.extract("")


# Generated at 2022-06-24 13:48:49.314182
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()
	assert ie._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"

# Generated at 2022-06-24 13:49:00.174969
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:49:09.772333
# Unit test for constructor of class WallaIE
def test_WallaIE():
    sample_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wie = WallaIE()
    obj = wie._call_downloader(sample_url)
    assert obj['info_dict']['id'] == '2642630'
    assert obj['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert obj['info_dict']['ext'] == 'flv'
    assert obj['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:49:13.057561
# Unit test for constructor of class WallaIE
def test_WallaIE():
        t = WallaIE()
        assert t

# Generated at 2022-06-24 13:49:14.952423
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._SUBTITLE_LANGS == { 'עברית': 'heb' }


if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:49:20.710062
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Verify that we can create the class
    ie = WallaIE()
    # Verify that the class has all the methods given by the class template.
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_download_json')
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_download_xml')
    assert hasattr(ie, '_sort_formats')
    assert hasattr(ie, '_html_search_regex')
    assert hasattr(ie, '_html_search_meta')
    assert hasattr(ie, '_extract_url')
    # Verify that the constants have the correct values

# Generated at 2022-06-24 13:49:28.687448
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wallaIE = WallaIE(url)
    assert wallaIE._VALID_URL.match(url)
    assert wallaIE._TEST.get('url') == url

# Generated at 2022-06-24 13:49:30.246305
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__.__name__ == 'WallaIE'


# Generated at 2022-06-24 13:49:33.993564
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    WallaIE(InfoExtractor()).suitable(url)

# Generated at 2022-06-24 13:49:37.649327
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

test_WallaIE()