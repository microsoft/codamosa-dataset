

# Generated at 2022-06-24 13:39:37.060273
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from . import main
    main(WallaIE, {}, {'skip_download':True})

# Generated at 2022-06-24 13:39:40.872868
# Unit test for constructor of class WallaIE
def test_WallaIE():
    applet = WallaIE()
    assert applet._VALID_URL == WallaIE._VALID_URL
    assert applet._TEST == WallaIE._TEST
    assert applet._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    return True

# Generated at 2022-06-24 13:39:43.330064
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Run a unit test that makes sure the 'Walla' class is not missing any
    # instance variable by just creating a new instance of the class.
    return WallaIE()

# Generated at 2022-06-24 13:39:55.080597
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:39:58.908805
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create a new instance of WallaIE
    ie = WallaIE()

    ie = WallaIE()
    ie = WallaIE({})
    ie = WallaIE(ie)
    ie = WallaIE(ie, verbose=True)

# Generated at 2022-06-24 13:40:00.883424
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    ie.download('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    return "WallaIE constructor doesn't raise any exceptions"

# Generated at 2022-06-24 13:40:07.363865
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:08.563165
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test instance of class WallaIE
    ie = WallaIE(None)


# Generated at 2022-06-24 13:40:09.106191
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_WallaIE = WallaIE()

# Generated at 2022-06-24 13:40:19.644351
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE(None)

    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:20.577368
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)

# Generated at 2022-06-24 13:40:27.935545
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:29.435315
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    unit test for constructor of WallaIE
    """
    ie = WallaIE("None")
    print("Walla IE object initialized correctly")

if __name__ == "__main__":
    test_WallaIE()

# Generated at 2022-06-24 13:40:33.348166
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        assert WallaIE()
        assert WallaIE is not None
        assert WallaIE != None
    except:
        print("test_WallaIE Failed")
        assert False
    else:
        print("test_WallaIE Passed")
        assert True


# Generated at 2022-06-24 13:40:43.208494
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:54.677218
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import unittest, walla
    class TestWallaIE(unittest.TestCase):
        def setUp(self):
            self.w = walla.WallaIE()

# Generated at 2022-06-24 13:40:57.274712
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(10)
    assert ie.name == 'walla'
    assert ie.ie_key() == 'walla'



# Generated at 2022-06-24 13:41:02.008297
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    assert(ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)');

if __name__ == "__main__":
    test_WallaIE();

# Generated at 2022-06-24 13:41:04.969872
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert re.match(WallaIE._VALID_URL, url) is not None
    obj = WallaIE()
    assert obj._real_extract(url) is not None

# Generated at 2022-06-24 13:41:07.201558
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__.__name__ == 'WallaIE'


# Generated at 2022-06-24 13:41:11.916540
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.url == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"


# Generated at 2022-06-24 13:41:13.353232
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:41:19.695401
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE(object());

    assert wallaIE._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

    assert wallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)' 

    # since we used the object(), we need to mock the urllib2.urlopen
    def urlopen(url):
        # since WallaIE not using this method, we just return a null object
        return object()
    
    # monkey patch!
    wallaIE._download_xml = urlopen


# Generated at 2022-06-24 13:41:25.783661
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test the case that href of the link to video includes only the video ID
    url = 'http://vod.walla.co.il/movie/2642630'
    walla = WallaIE()
    mobj = re.match(walla._VALID_URL, url)
    assert(mobj.group('id'))
    assert(mobj.group('display_id'))
    assert(walla._real_extract(url))

    # Test the case that href of the link to video includes the video ID and the title
    url = 'http://vod.walla.co.il/movie/2642630/vidoe-1-title'
    walla = WallaIE()
    mobj = re.match(walla._VALID_URL, url)
    assert(mobj.group('id'))


# Generated at 2022-06-24 13:41:34.438462
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    # test to get an url
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    m = re.match(ie._VALID_URL, url)

# Generated at 2022-06-24 13:41:43.873677
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:41:49.889731
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:42:00.793811
# Unit test for constructor of class WallaIE
def test_WallaIE():

    params = {'extractor_key' : 'WallaIE'}
    params['url'] = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    params['ie_key'] = 'Common'


    ie = InfoExtractor.get_info_extractor(**params)


    ie.prepare()

    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.video_id == '2642630'
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.ext == 'flv'

# Generated at 2022-06-24 13:42:12.925115
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test with valid video Url
    ie = WallaIE()
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    # Test with fake url
    ie = WallaIE()
    ie.url = 'vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.url == None

    # Test with invalid video Url
    ie = WallaIE()
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/'

# Generated at 2022-06-24 13:42:13.725344
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-24 13:42:23.518926
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL  == WallaIE._VALID_URL
    assert WallaIE()._TEST       == WallaIE._TEST
    assert WallaIE()._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS

    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.suitable('http://vod.walla.co.il/movie/afsgdh/afgd')
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is not None

# Generated at 2022-06-24 13:42:25.010044
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:42:30.009325
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'



# Generated at 2022-06-24 13:42:30.972860
# Unit test for constructor of class WallaIE
def test_WallaIE():
    constructor_test(WallaIE)

# Generated at 2022-06-24 13:42:35.605908
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert WallaIE.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one") == True


# Generated at 2022-06-24 13:42:36.266808
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:42:38.467299
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('www.walla.co.il')
    assert ie._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:42:40.048131
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test for constructor of class WallaIE"""
    assert WallaIE.__doc__ == 'Walla! Video extractor.'

# Generated at 2022-06-24 13:42:49.048608
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._SUBTITLE_LANGS['עברית'] == 'heb'
    m = re.match(WallaIE._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert m.group('id') == '2642630'
    assert m.group('display_id') == 'one-direction-all-for-one'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['id'] == '2642630'

# Generated at 2022-06-24 13:42:58.443680
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:42:59.920091
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:43:04.684812
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = InfoExtractor(WallaIE._VALID_URL)
    expectedParams = {
        'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
        'id': '2642630',
        'display_id': 'one-direction-all-for-one'
    }
    assert ie._VALID_URL == WallaIE._VALID_URL and ie._params == expectedParams

# Generated at 2022-06-24 13:43:05.283439
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()


# Generated at 2022-06-24 13:43:06.348263
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # try to start and create instance
    i = WallaIE()

# Generated at 2022-06-24 13:43:14.021763
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Download the webpage and extract the player key
    ie = WallaIE()
    ie._download_webpage = lambda url, video_id: u'preview_pic_url'
    info = ie._real_extract(url)
    assert info.get('id') == u'2642630'
    assert info.get('display_id') == u'one-direction-all-for-one'

# Generated at 2022-06-24 13:43:15.333617
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie


# Generated at 2022-06-24 13:43:20.609677
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert re.search('walla_video_2642630', ie._VALID_URL, re.IGNORECASE)
    assert repr(ie) == 'WallaIE(\'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one\')'


# Generated at 2022-06-24 13:43:21.809445
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-24 13:43:22.689097
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-24 13:43:27.567040
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:43:30.124555
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w.url_result("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one",
                        "Walla")

# Generated at 2022-06-24 13:43:33.125066
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie is not None


# Generated at 2022-06-24 13:43:34.800704
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._download_xml('www.google.com', 1)

# Generated at 2022-06-24 13:43:38.930269
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:43:40.120071
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    y = WallaIE()
    y.extract()

# Generated at 2022-06-24 13:43:44.128739
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-24 13:43:49.254940
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

    assert(w._VALID_URL ==
           r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(w.IE_NAME == 'walla:video')
    assert(w.IE_DESC == 'Walla! video')

# Generated at 2022-06-24 13:43:56.371408
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.__class__ == WallaIE
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:58.994598
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('https://vod.walla.co.il/2642606/one-direction-all-for-one')

# Generated at 2022-06-24 13:44:07.668628
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test WallaIE constructor - basic fields
    """
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:08.521166
# Unit test for constructor of class WallaIE
def test_WallaIE():
    downloader = InfoExtractor('WallaIE')

# Generated at 2022-06-24 13:44:10.356632
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE(None, None)
    except (AttributeError, TypeError):
        # This error is raised when the constructor of WallaIE is called with
        # 0 or 1 argument
        assert True
    except:
        assert False

# Generated at 2022-06-24 13:44:12.507574
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:44:14.395547
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.name == "Walla"
    assert ie.url_re == WallaIE._VALID_URL

# Generated at 2022-06-24 13:44:21.311319
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie
    assert ie._VALID_URL == u'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:31.986429
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE()
    my_assert_raises_regex(
        ValueError,
        '^Unsupported URL: 11$',
        info_extractor.extract,
        '11')
    my_assert_raises_regex(
        ValueError,
        '^Unsupported URL: https://11$',
        info_extractor.extract,
        'https://11')
    my_assert_raises_regex(
        ValueError,
        '^Unsupported URL: http://11$',
        info_extractor.extract,
        'http://11')

# Generated at 2022-06-24 13:44:35.833370
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except NameError:
        raise Exception("Test failed: class WallaIE could not be found.")


# Generated at 2022-06-24 13:44:36.408735
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return True

# Generated at 2022-06-24 13:44:38.325867
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # test_IEs.py -s test_WallaIE

# Generated at 2022-06-24 13:44:47.914660
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .test import TestIE

    walla = WallaIE({})

    # Test WallaIE
    test_walla = TestIE([walla.ie_key()])
    fetch_result = test_walla.run()

    # Test WallaIE._real_extract()
    for fetch in fetch_result:
        if fetch['ie_key'] == 'Walla':
            result = walla._real_extract(fetch['url'])
            assert(result['id'] == '2642630')
            assert(result['display_id'] == 'one-direction-all-for-one')
            assert(result['ext'] == 'flv')
            assert(result['title'] == 'וואן דיירקשן: ההיסטריה')

# Generated at 2022-06-24 13:44:50.085009
# Unit test for constructor of class WallaIE
def test_WallaIE():
    loader = WallaIE()
    # tests that WallaIE class was constructed without error
    assert loader is not None

test_WallaIE()

# Generated at 2022-06-24 13:44:50.577919
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-24 13:44:59.003699
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    # Make sure url regex matches url
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    match = re.match(ie._VALID_URL, url)

    assert match

    video_id = match.groupdict()['id']
    display_id = match.groupdict()['display_id']

    # Fetch xml object
    video = ie._download_xml(
            'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
            display_id)
    assert video is not None

    # Fetch item from xml
    item = video.find('./items/item')

    # Fetch title from item


# Generated at 2022-06-24 13:45:01.405648
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:02.773318
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    if (ie == None):
        print('Constructor for class WallaIE has failed')

# Generated at 2022-06-24 13:45:07.176345
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test_ie = WallaIE(None)
    test_ie._download_webpage('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'one-direction-all-for-one')
    test_ie._real_extract(test_url)

# Generated at 2022-06-24 13:45:09.920772
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        w = WallaIE()
    except:
        assert False, 'Couldn\'t create an instance of WallaIE'
test_WallaIE.func_code = WallaIE.__dict__['__init__'].func_code

# Generated at 2022-06-24 13:45:13.721181
# Unit test for constructor of class WallaIE
def test_WallaIE():

    #Test illegal url
    url = "http://vod.walla.co.il/movie/some-illegal-url"
    assert WallaIE.suitable(url) == False

    #Test legal url
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert WallaIE.suitable(url) == True

# Generated at 2022-06-24 13:45:16.043099
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:45:24.189246
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Tests URL: http://vod.walla.co.il/movie/2642630/one-direction-all-for-one
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    mobj = re.match(ie._VALID_URL, url)
    assert mobj is not None
    assert video_id == mobj.group('id')
    assert display_id == mobj.group('display_id')


# Generated at 2022-06-24 13:45:34.235172
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from ..utils import get_testdata_file
    file_path = get_testdata_file('walla.html')
    with open(file_path) as file_object:
        html_string = file_object.read()
    video_string = WallaIE._html_search_regex(WallaIE._VALID_URL, html_string, 'video URL')
    instance = WallaIE(WallaIE._build_url_result('walla', video_string))
    info_dict = instance._real_extract(WallaIE._build_url_result('walla', video_string))
    assert info_dict['id'] == '2642630'
    assert info_dict['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:45:44.316432
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:45:47.157076
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://walla.co.il/js-unittest?url=http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:45:48.060670
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-24 13:45:54.969958
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.SUFFIX == 'co.il'
    assert ie.ie_key() == 'Walla'
    ie.correctURL('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.correctURL('http://vod.walla.co.il/item/2642630/one-direction-all-for-one')
    ie.correctURL('http://vod.walla.co.il/one-direction-all-for-one/2642630')

# Generated at 2022-06-24 13:46:04.084831
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:46:08.769839
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import InfoExtractor
    from ..utils import (
        xpath_text,
        int_or_none,
    )
    from .WallaIE import _SUBTITLE_LANGS
    ie = InfoExtractor(urls=_VALID_URL)
    ie._real_extract(url=_VALID_URL)
    assert True


# Generated at 2022-06-24 13:46:09.658451
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE(None);

# Generated at 2022-06-24 13:46:11.803264
# Unit test for constructor of class WallaIE
def test_WallaIE():
  test_obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
  assert test_obj != None

# Generated at 2022-06-24 13:46:17.751039
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == url
    assert ie._TEST == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-24 13:46:19.845321
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:46:24.436986
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.VALID_URL == WallaIE._VALID_URL
    assert ie.TEST == WallaIE._TEST

# Generated at 2022-06-24 13:46:27.710983
# Unit test for constructor of class WallaIE
def test_WallaIE():
    new_catcher = WallaIE()
    assert(new_catcher._VALID_URL ==
           'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:46:29.641128
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:31.711603
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:43.385591
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import mock
    import unittest

    class TestWallaIE(unittest.TestCase):
        def setUp(self):
            self.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
            self.video_id = '2642630'
            self.display_id = 'one-direction-all-for-one'

        def test_constructor(self):
            self.assertTrue(WallaIE.suitable(self.url))
            self.assertEqual(WallaIE.IE_NAME, 'Walla')
            self.assertEqual(WallaIE.IE_DESC, 'Walla! video')


# Generated at 2022-06-24 13:46:44.748977
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE is not None

# Generated at 2022-06-24 13:46:45.293395
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:46:46.807796
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .WallaIE import WallaIE
    obj = WallaIE()
    assert isinstance(obj, WallaIE)

# Generated at 2022-06-24 13:46:48.436933
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(WallaIE(), InfoExtractor)

# Generated at 2022-06-24 13:46:50.754731
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj is not None

# Generated at 2022-06-24 13:46:52.907153
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._download_webpage('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl')

# Generated at 2022-06-24 13:47:02.848609
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert str(ie) == 'Walla'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:06.508191
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create a new WallaIE object
    instance = WallaIE()
    instance.suitable('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:47:10.533993
# Unit test for constructor of class WallaIE
def test_WallaIE():
	try:
		WallaIE('Walla', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
		return True
	except KeyError:
		return False


# Generated at 2022-06-24 13:47:19.405282
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = WallaIE._TEST['url']
    mobj = re.match(WallaIE._VALID_URL, test_url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    video = WallaIE._download_xml(
            'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
            display_id)
    item = video.find('./items/item')
    title = xpath_text(item, './title', 'title')
    description = xpath_text(item, './synopsis', 'description')
    thumbnail = xpath_text(item, './preview_pic', 'thumbnail')
    duration = int_

# Generated at 2022-06-24 13:47:22.569408
# Unit test for constructor of class WallaIE
def test_WallaIE():
    e = WallaIE('Walla', 'web')
    assert e.IE_NAME == 'Walla'
    assert e.ie_key() == 'Walla'
    assert e.web_ie == 'web'
    assert e.app_ie == 'web'


# Generated at 2022-06-24 13:47:28.175537
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:47:29.464459
# Unit test for constructor of class WallaIE
def test_WallaIE():
	constructor_test(WallaIE, None)

# Generated at 2022-06-24 13:47:33.818639
# Unit test for constructor of class WallaIE
def test_WallaIE():
    cls = WallaIE
    print("\n** initiating unit test for class WallaIE **")
    print("\n  checking class WallaIE...")
    assert cls.__name__ in globals()
    print("  class WallaIE exists in the global namespace")

# Generated at 2022-06-24 13:47:34.418733
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:47:43.764995
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Testing constructor of class WallaIE
	assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	assert WallaIE._TEST['id'] == '2642630'
	assert WallaIE._TEST['display_id'] == 'one-direction-all-for-one'
	assert WallaIE._TEST['ext'] == 'flv'
	assert WallaIE._TEST['title'] == 'וואן דיירקשן: ההיסטריה'
	assert WallaIE._TEST['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'

	# Testing constructor of methods


# Generated at 2022-06-24 13:47:44.736084
# Unit test for constructor of class WallaIE
def test_WallaIE(): pass

# Generated at 2022-06-24 13:47:47.195270
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:48.267764
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    return ie

# Generated at 2022-06-24 13:47:49.943887
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE(None)
    except:
        assert False, 'WallaIE constructor raises exception'
    assert True


# Generated at 2022-06-24 13:47:51.838869
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:47:54.430122
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor of WallaIE class
    assert WallaIE(None)._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:55.492753
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:48:07.125070
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:09.287146
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.set_downloader(None)
    ie._real_extract(ie._TEST['url'])

# Generated at 2022-06-24 13:48:12.961135
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE(url)
    assert ie.url == url
    assert ie.id == '2642630'
    assert ie.display_id == "one-direction-all-for-one"

# Generated at 2022-06-24 13:48:17.529459
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url_test = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE()._real_extract(url_test)

# Generated at 2022-06-24 13:48:28.789590
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # content of the field _VALID_URL
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    # content of the field _TEST
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:48:31.113884
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie != None

# Generated at 2022-06-24 13:48:33.124823
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except:
        assert False, 'Failed to create instance of WallaIE'

# Generated at 2022-06-24 13:48:43.366154
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-24 13:48:44.298924
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:48:55.785059
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = 2642630
    display_id = 'one-direction-all-for-one'
    url = 'http://vod.walla.co.il/movie/%s/%s' % (video_id, display_id)
    item = WallaIE()._real_extract(url)
    assert item['id'] == str(video_id) 
    assert item['display_id'] == display_id
    assert item['title'] == 'וואן דיירקשן: ההיסטריה'
    assert item['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert item['thumbnail'] == 're:^https?://.+.jpg'

# Generated at 2022-06-24 13:48:59.714498
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(InfoExtractor())
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie._TEST == WallaIE._TEST

# Generated at 2022-06-24 13:49:04.381007
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("test", "test", "test")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:49:07.153816
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:49:09.097025
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-24 13:49:13.553811
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla:vod'
    assert ie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {
        'עברית': 'heb'
    }



# Generated at 2022-06-24 13:49:19.517073
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('url')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:49:20.378140
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("some url")

# Generated at 2022-06-24 13:49:23.398344
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.DISPLAY_ID()

# Generated at 2022-06-24 13:49:25.717708
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w

# Generated at 2022-06-24 13:49:32.083974
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert (ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert (ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    data = ie._TEST['info_dict'].copy()
    assert (data['id'] == '2642630')
    assert (data['display_id'] == 'one-direction-all-for-one')
    assert (data['ext'] == 'flv')
    assert (data['title'] == 'וואן דיירקשן: ההיסטריה')

# Generated at 2022-06-24 13:49:41.888279
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class_WallaIE = WallaIE

    # test for _VALID_URL which should match
    valid_url_regex = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    m = re.match(valid_url_regex, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    assert m is not None

    # test for _TEST
    test = class_WallaIE._TEST
    assert test['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert test['info_dict']['id'] == '2642630'
