

# Generated at 2022-06-24 13:39:41.850116
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:39:43.228410
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-24 13:39:47.330600
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Just a plain unit test for WallaIE class constructor."""
    instance = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(instance.SUCCESS == True)


# Generated at 2022-06-24 13:39:49.616355
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS == {u'עברית': 'heb'}

# Generated at 2022-06-24 13:39:52.137856
# Unit test for constructor of class WallaIE
def test_WallaIE():

    class ConstructorUnitTest(object):
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-24 13:39:57.404268
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Load test links from file
    f = open('walla_test_links.txt', 'r')
    url_list = [line.rstrip('\n') for line in f]
    f.close()

    # Test links
    for url in url_list:
        ie = WallaIE()
        ie._real_extract(url)

# Generated at 2022-06-24 13:40:00.698125
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie.SUITES == ['master']
    assert ie.subtitle_language() == 'heb'

# Generated at 2022-06-24 13:40:02.430756
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 13:40:11.928170
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:13.887855
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE().extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:15.235397
# Unit test for constructor of class WallaIE
def test_WallaIE():
	result = WallaIE()
	assert result.ie_key() == 'Walla'

# Generated at 2022-06-24 13:40:19.905159
# Unit test for constructor of class WallaIE
def test_WallaIE():
    e = InfoExtractor()
    e._downloader = DummyDownloader()
    e.httpserver = DummyHttpServer()
    e.httpserver.start()

    ie = WallaIE(e)
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:23.061438
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    This extractor tries to download a web page and compare the fields of object
    extracted from this web page with the fields of object that been expected.
    This test checks if the extractor works correctly.
    """
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:26.918396
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    w._real_extract(url)
    assert w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    w

# Generated at 2022-06-24 13:40:30.469766
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    instance._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    print ("Unit test finished: WallaIE")


# Generated at 2022-06-24 13:40:33.541572
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print('Testing WallaIE constructor')
    try:
        ie = WallaIE()
    except Exception as e:
        print(e)
        return False

    return True

# ---------------------------------- main ------------------------------

# Generated at 2022-06-24 13:40:37.367702
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert isinstance(ie, WallaIE)
# What is the point of this test if it recreates the constructor?

# Generated at 2022-06-24 13:40:41.356493
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")


# Generated at 2022-06-24 13:40:44.853858
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class_ = WallaIE
    config = {
        'class': class_,
        'module': 'walla',
        'title': 'וואן דיירקשן: ההיסטריה',
    }
    return config

# Generated at 2022-06-24 13:40:55.021237
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.IE_NAME == 'walla:vod'
    assert ie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:01.420779
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie._VALID_URL
    ie.IE_NAME
    ie._TEST
    ie._TESTS
    ie._WORKING
    ie.BR_DESC
    ie.SUCCESS_REGEX
    ie.IE_DESC
    ie.IE_NAME
    ie.ie

# Generated at 2022-06-24 13:41:03.180140
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except:
        import sys, traceback
        raise Exception(sys.exc_info()[1]) from None


# Generated at 2022-06-24 13:41:10.697944
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test a good URL
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(url)
    # Test a bad URL
    url = 'http://vod.walla.co.il/movie/264260/one-direction-all-for-one'
    exception_raised = False
    try:
        WallaIE(url)
    except:
        exception_raised = True
    assert exception_raised

# Generated at 2022-06-24 13:41:18.027301
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert WallaIE().suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert WallaIE().suitable('/movie/2642630/one-direction-all-for-one')
    assert not WallaIE().suitable('http://vod.walla.co.il/')
    assert not WallaIE().suitable('http://youtube.com/')


# Generated at 2022-06-24 13:41:19.663511
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:41:30.089461
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:33.083855
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.url_re == WallaIE._VALID_URL
    assert ie.fetch_info.__name__ == WallaIE._real_extract.__name__

# Generated at 2022-06-24 13:41:37.911104
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE
    item = walla._TEST
    url = item['url']
    ie = walla(url)
    assert ie.video_id == item['info_dict']['id']
    assert ie.display_id == item['info_dict']['display_id']
    assert ie._VALID_URL == walla._VALID_URL

# Generated at 2022-06-24 13:41:46.166922
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(w._VALID_URL, url)
    assert WallaIE._VALID_URL == w._VALID_URL
    assert '2642630' == mobj.group('id')
    assert 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl' ==  w._download_xml_url(url)

# Generated at 2022-06-24 13:41:51.029137
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'


# Generated at 2022-06-24 13:41:52.279583
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert False, "Unit test for constructor of class WallaIE has no implementation."

# Generated at 2022-06-24 13:41:54.046146
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract()

# Generated at 2022-06-24 13:42:01.957490
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-24 13:42:02.827379
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # check the constructor works correctly
    assert WallaIE()

# Generated at 2022-06-24 13:42:03.565285
# Unit test for constructor of class WallaIE
def test_WallaIE():
	w = WallaIE()


# Generated at 2022-06-24 13:42:08.163692
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'Walla'
    assert ie.IE_DESC == 'Walla'
    assert ie._VALID_URL == '^https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)$'

# Generated at 2022-06-24 13:42:12.660471
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test if the constructor of class WallaIE works as intended.
    assert WallaIE.__doc__ is not None
    assert WallaIE.__name__ is not None
    assert WallaIE.__module__ is not None
    assert WallaIE.__dict__ is not None

# Generated at 2022-06-24 13:42:19.076015
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');    
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert w._TEST["url"] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert w._TEST["info_dict"]["id"] == "2642630"
    assert w._TEST["info_dict"]["display_id"] == "one-direction-all-for-one"
    assert w._TEST["info_dict"]["ext"] == "flv"


# Generated at 2022-06-24 13:42:27.551823
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader.rtmp import download_rtmp_video
    from youtube_dl.utils import sanitized_Request
    from requests import Session
    from .common import FakeYDL
    from .test_walla import walla_test
    from .utils import urlopen

    walla = WallaIE()

# Generated at 2022-06-24 13:42:38.005460
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['id'] == '2642630'
    assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:42:38.651390
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert True

# Generated at 2022-06-24 13:42:41.189484
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-24 13:42:42.852879
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    print(ie._SUBTITLE_LANGS)

# Generated at 2022-06-24 13:42:43.753423
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-24 13:42:51.468410
# Unit test for constructor of class WallaIE
def test_WallaIE():
	import re
	import unittest
	from WallaIE import WallaIE
	
	class TestWallaIE(unittest.TestCase):
		"""Unit test class"""
		def setUp(self):
			self.walla = WallaIE()
		
		def test_init(self):
			self.assertEqual(self.walla._VALID_URL, r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
		

# Generated at 2022-06-24 13:42:54.817284
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL
    assert ie._TEST
    assert ie._SUBTITLE_LANGS
    assert ie._real_extract

# Generated at 2022-06-24 13:43:02.961737
# Unit test for constructor of class WallaIE
def test_WallaIE():
    youtube_ie = WallaIE()
    assert (youtube_ie._VALID_URL ==
            'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert youtube_ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert youtube_ie._TEST['info_dict']['id'] == '2642630'
    assert youtube_ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert youtube_ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:43:12.386022
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:16.816454
# Unit test for constructor of class WallaIE
def test_WallaIE():
    '''
    Test the constructor of the WallaIE class.
    '''
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    assert ie.match_url(test_url)
    assert ie._VALID_URL == ie.regex.pattern

# Generated at 2022-06-24 13:43:21.043764
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://www.walla.co.il')
    assert ie._downloader.params['force_generic_extractor'] == True


# Generated at 2022-06-24 13:43:27.905451
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Verifies the class was correctly initialized with the url
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    # Verifies the url is a match for the regular expression
    assert re.match(WallaIE._VALID_URL, url)

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:43:28.551553
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()

# Generated at 2022-06-24 13:43:35.115993
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:35.687446
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:43:40.434587
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    a = WallaIE()
    a.suitable('http://static.walla.co.il/?w=2/null/null/null/null/null/null/null/null')

# Generated at 2022-06-24 13:43:41.249391
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie != None

# Generated at 2022-06-24 13:43:51.614736
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("Test WallaIE")

    # Test for for fixture 'WallaIE'
    ie = WallaIE()
    ie_name = ie.ie_key()
    ie_url = ie.working_as_of()

    print("Used class '{}' for {}".format(ie_name, ie_url))

    # Test for parameter _VALID_URL
    valid_url = ie._VALID_URL
    print("\nParameter _VALID_URL:\n\tvalue = '{}'".format(valid_url))

    # Test for parameter _TEST
    test = ie._TEST
    print("\nParameter _TEST:\n")
    for key, value in test.items():
        print("\t{} = '{}'".format(key,value))

    # Test for parameter _SUB

# Generated at 2022-06-24 13:44:02.953317
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('WallaIE', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', '2642630')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:44:03.845264
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE({})
    assert ie

# Generated at 2022-06-24 13:44:04.398863
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:44:06.216902
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:44:08.321170
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie

# Generated at 2022-06-24 13:44:09.468224
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-24 13:44:10.985998
# Unit test for constructor of class WallaIE
def test_WallaIE():
    [walla] = [
        i
        for i in globals().values()
        if getattr(i, 'suite', None) == 'ypc'
    ]
    return walla

# Generated at 2022-06-24 13:44:14.603286
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

    assert obj.name == 'walla.co.il'
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:44:15.552241
# Unit test for constructor of class WallaIE
def test_WallaIE():
  # Testing constructor
  WallaIE()

# Generated at 2022-06-24 13:44:16.338991
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:44:18.268309
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.download('2642630')

# Generated at 2022-06-24 13:44:19.138157
# Unit test for constructor of class WallaIE
def test_WallaIE():
	wallaIE = WallaIE()


# Generated at 2022-06-24 13:44:29.985328
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.IE_NAME = 'walla'
    ie.ie_key = 'walla'
    ie.IE_DESC = 'Walla! video'
    ie._VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:32.855265
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # WallaIE(common.common.InfoExtractor)
    assert WallaIE(common.common.InfoExtractor)._VALID_URL is not None
    # common.common.InfoExtractor.__init__(common.common.InfoExtractor, type)
    assert common.common.InfoExtractor.__init__(
        common.common.InfoExtractor, type) is not None

# Generated at 2022-06-24 13:44:39.993049
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert str(ie) == 'Walla'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == { 'עברית': 'heb', }

# Generated at 2022-06-24 13:44:46.184509
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # setup
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ied = WallaIE(url)
    video_id = ied._real_extract(url)['id']

    # tests
    assert "http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl" % video_id == ied._download_xml(ied._API_URL % id, id).url

# Generated at 2022-06-24 13:44:49.069357
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # test function _real_extract
    ie._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    return 1

# Generated at 2022-06-24 13:44:51.806583
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Just test that the constructor doesn't do any harm
    inst = WallaIE(0)
    assert inst.ie_key() == 'Walla'

# Generated at 2022-06-24 13:44:54.187132
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.SUCCEEDED

# Generated at 2022-06-24 13:44:57.018647
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:45:00.055836
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    if re.match(instance._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == None:
        raise AssertionError("Pattern doesn't match.")

# Generated at 2022-06-24 13:45:02.194769
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.url_re == ie._VALID_URL
    assert ie.regex == re.compile(ie.url_re)
    assert ie.name == 'Walla! VOD'

# Generated at 2022-06-24 13:45:03.089710
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global WallaIE
    WallaIE()

# Generated at 2022-06-24 13:45:04.478099
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 13:45:06.102026
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download(url)

# Generated at 2022-06-24 13:45:14.406142
# Unit test for constructor of class WallaIE
def test_WallaIE():
	obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
	assert obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:45:20.423933
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert w._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:45:23.366126
# Unit test for constructor of class WallaIE
def test_WallaIE():
	walla = WallaIE()
	assert(walla!=None)


# Generated at 2022-06-24 13:45:26.243546
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:36.048664
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'
   

# Generated at 2022-06-24 13:45:36.948476
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:45:40.166670
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.download(test_url)

# Generated at 2022-06-24 13:45:41.587786
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()

# Generated at 2022-06-24 13:45:43.541183
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 13:45:48.456209
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert_raises (AttributeError, getattr, w, '_TEST')
    assert_raises (AttributeError, getattr, w, '_SUBTITLE_LANGS')

# Generated at 2022-06-24 13:45:49.468742
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("test WallaIE")

# Generated at 2022-06-24 13:45:58.374119
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create unit test object of class WallaIE
    wallaIE = WallaIE()
    # Test url & check if url is valid
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wallaIE._real_extract(url)
    # Test display_id & check if display_id is valid
    display_id = wallaIE._VALID_URL[wallaIE._VALID_URL.find('/') + 1:len('<display_id>') + wallaIE._VALID_URL.find('/')]
    assert display_id == '<display_id>'
    # Test video_id & check if video_id is valid

# Generated at 2022-06-24 13:46:00.158373
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructor of class WallaIE
    obj = WallaIE()

# Generated at 2022-06-24 13:46:01.529467
# Unit test for constructor of class WallaIE
def test_WallaIE():

    ie = WallaIE()
    assert ie == 'WallaIE'

# Generated at 2022-06-24 13:46:12.143745
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == "walla"
    assert ie._VALID_URL == r"(https?://)?([^/]+\.)?vod\.walla\.(co\.il|tv)/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"

# Generated at 2022-06-24 13:46:12.645905
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:46:13.912592
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.extractor == WallaIE
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-24 13:46:14.661702
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:46:23.576118
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.video_id == "2642630"
    assert ie.display_id == "one-direction-all-for-one"
    assert ie._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"

# Generated at 2022-06-24 13:46:31.623076
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Unit tests for constructor of class WallaIE
    test = WallaIE()
    assert test._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:36.970241
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()

    ie.extract(url)

    # See if the same IE returns the same output
    ie.extract(url)

# Generated at 2022-06-24 13:46:39.910593
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE({"url": "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"})

# Generated at 2022-06-24 13:46:48.863988
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-24 13:46:54.391601
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Execute constructor to test
	test = WallaIE()
	# Check attributes of class
	assert test._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:56.471832
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    assert isinstance(a, InfoExtractor)


# Generated at 2022-06-24 13:46:58.564997
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = ("http://vod.walla.co.il/movie/2643754/one-direction-all-for-one")
    w = WallaIE()
    assert w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)' , "Test of constructor of class WallaIE '_VALID_URL' member failed"

# Generated at 2022-06-24 13:46:59.919776
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:47:01.063623
# Unit test for constructor of class WallaIE
def test_WallaIE():
	obj = WallaIE("")

# Generated at 2022-06-24 13:47:11.407350
# Unit test for constructor of class WallaIE
def test_WallaIE():
	class dummy_IE(WallaIE):
		def _download_xml(self, *args, **kwargs): return None
	url = 'http://vod.walla.co.il/zero/2642630/one-direction-all-for-one'
	# We don't test the video extraction, just the correct initialization of the class
	ie = dummy_IE(url)
	assert ie._VALID_URL == re.compile(r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
	assert ie._TEST['url'] == url
	assert ie._TEST['info_dict']['id'] == '2642630'

# Generated at 2022-06-24 13:47:14.264296
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import urllib
    url = WallaIE._VALID_URL

    # Chech if WallaIE can be initialized with an url,
    # this will throw an exception if it is not possible
    url_test = urllib.urlopen(url)

# Generated at 2022-06-24 13:47:18.197603
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:19.364244
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:47:28.433864
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla.name == 'Walla'
    assert walla.IE_NAME == 'walla'
    assert walla.MAIN_URL == 'http://www.walla.co.il'
    assert walla.IE_DESC == 'Walla.co.il'
    assert walla._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert walla.FILE_SUFFIX == '.flv'
    assert walla.url_result('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == None

# Generated at 2022-06-24 13:47:31.345052
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert list(sorted(ie.IE_DESC)) == ['walla']

# Generated at 2022-06-24 13:47:36.757908
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('Walla', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one' )
    assert ie.name == 'Walla'
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:47:37.374354
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-24 13:47:37.971105
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE({})

# Generated at 2022-06-24 13:47:41.947752
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.download("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:47:51.880922
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert i._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert i._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:47:57.850724
# Unit test for constructor of class WallaIE
def test_WallaIE():
    res = WallaIE()._real_extract(WallaIE._TEST['url'])
    assert res['id'] == WallaIE._TEST['info_dict']['id']
    assert res['display_id'] == WallaIE._TEST['info_dict']['display_id']
    assert res['title'] == WallaIE._TEST['info_dict']['title']
    assert res['description'] == WallaIE._TEST['info_dict']['description']
    # No thumbnails in the test
    # assert res['thumbnail'] == WallaIE._TEST['info_dict']['thumbnail']
    assert res['duration'] == WallaIE._TEST['info_dict']['duration']
    assert res['subtitles'] == {}

# Generated at 2022-06-24 13:48:07.124523
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = [
        "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one",
        "http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl"
    ]
    wallaIE = WallaIE()
    if wallaIE.suitable(test_url[0]):
        print("Suitable url")
    if not wallaIE.suitable(test_url[1]):
        print("Unsuitable url")

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:48:12.285417
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract('http://vod.walla.co.il/movie/2634684/one-direction-all-for-one')
    ie.extract('http://vod.walla.co.il/movie/2636003/one-direction-all-for-one')

# Generated at 2022-06-24 13:48:17.183279
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:48:19.882279
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:48:22.432890
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:48:27.354361
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"
    assert obj._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert obj._TEST['info_dict']['id'] == "2642630"
    assert obj._TEST['info_dict']['display_id'] == "one-direction-all-for-one"
    assert obj._TEST['info_dict']['ext'] == "flv"

# Generated at 2022-06-24 13:48:33.872576
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(_test_preload_content=False, _test_download=False)
    mobj = re.match(ie._VALID_URL, "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    assert mobj is not None
    assert mobj.group('id') == video_id
    assert mobj.group('display_id') == display_id
    return True


# Generated at 2022-06-24 13:48:44.009557
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST.get('url') == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST.get('info_dict.id') == '2642630'
    assert ie._TEST.get('info_dict.display_id') == 'one-direction-all-for-one'
    assert ie._TEST.get('info_dict.ext') == 'flv'

# Generated at 2022-06-24 13:48:47.392703
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for checking of class attributes.
    ie = WallaIE
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}



# Generated at 2022-06-24 13:48:58.553501
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE()._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE()._TEST['info_dict']['id'] == '2642630'
    assert WallaIE()._TEST['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'
    assert WallaIE()._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:49:02.167842
# Unit test for constructor of class WallaIE
def test_WallaIE():
    e = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert e.video_id == '2642630'
    assert e.display_id == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:49:04.085169
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:49:07.125873
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE(InfoExtractor())
    assert i._VALID_URL == WallaIE._VALID_URL
    assert i._TEST == WallaIE._TEST
    assert i._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS

# Generated at 2022-06-24 13:49:12.812659
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie_object = WallaIE(WallaIE._TEST['url'])
    assert (ie_object.get_name() == 'Walla')
    assert (ie_object._VALID_URL == re.compile(WallaIE._VALID_URL))
    assert (ie_object._TEST == WallaIE._TEST)


# Generated at 2022-06-24 13:49:17.205347
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla.co.il'
    assert ie.VALID_URL == WallaIE._VALID_URL
    assert ie.extract(WallaIE._TEST['url']) == WallaIE._TEST
    assert WallaIE._TEST['url'] == ie.VALID_URL

# Generated at 2022-06-24 13:49:28.577381
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    result = w.extract(url)
    assert result['id'] == '2642630'
    assert result['display_id'] == 'one-direction-all-for-one'
    assert result['title'] == 'וואן דיירקשן: ההיסטריה'
    assert result['description'] == 'מאת הדוקומנטרי ניק סטאס'
    assert result['thumbnail'] == 'http://images.walla.co.il/fm/1/3/6/@537888-1.jpg'
   

# Generated at 2022-06-24 13:49:29.596973
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:49:31.136510
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_obj = WallaIE()
    assert isinstance(test_obj, WallaIE)


# Generated at 2022-06-24 13:49:33.384791
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download_webpage()