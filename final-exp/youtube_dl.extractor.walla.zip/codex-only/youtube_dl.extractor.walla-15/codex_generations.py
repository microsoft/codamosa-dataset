

# Generated at 2022-06-24 13:39:35.661826
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_class('WallaIE', WallaIE, expected_class=InfoExtractor)

# Generated at 2022-06-24 13:39:45.246985
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.__class__ == WallaIE
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:39:47.721820
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w is not None
    assert WallaIE.__name__ == 'WallaIE'


# Generated at 2022-06-24 13:39:50.474894
# Unit test for constructor of class WallaIE
def test_WallaIE():
    e = WallaIE()
    assert e.__class__.__name__ == WallaIE.__name__



# Generated at 2022-06-24 13:40:01.902866
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # constructor test
    # assert that the given string is a valid URL and a correct URL pattern
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # assert that the URL is valid for WallaIE
    assert ie.match_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # assert that the given URL is invalid for WallaIE
    assert not ie.match_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/movie')
    # assert that the given URL is invalid for WallaIE, because of wrong path

# Generated at 2022-06-24 13:40:03.029555
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(WallaIE._TEST['url'])

# Generated at 2022-06-24 13:40:03.770058
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-24 13:40:06.041284
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == 'WallaIE'
    assert WallaIE.__doc__ == 'Walla! VOD'

# Generated at 2022-06-24 13:40:07.714086
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL
    assert ie._TEST

# Generated at 2022-06-24 13:40:09.897582
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie.search_re, re.Pattern)
    assert isinstance(ie.subtitle_langs, dict)
    assert isinstance(ie.subtitle_langs, dict)
    assert callable(ie.real_extract)

# Generated at 2022-06-24 13:40:13.113917
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-24 13:40:14.409856
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.ext='flv'

# Generated at 2022-06-24 13:40:23.844989
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert w._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test = w._TEST['info_dict']
    assert test['id'] == '2642630'
    assert test['display_id'] == 'one-direction-all-for-one'
    assert test['ext'] == 'flv'

# Generated at 2022-06-24 13:40:30.210967
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """ Executes constructor test for class WallaIE """
    # Test for instantiating WallaIE
    # Should return true if instantiated
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url, {}, {}, {})
    assert ie is not None, str(type(WallaIE)) + " could not be instantiated"
    return ie


# Generated at 2022-06-24 13:40:34.066596
# Unit test for constructor of class WallaIE
def test_WallaIE():
	vod_movie_id = "2642630"
	w = WallaIE(vod_movie_id)
	#assert(w.vod_movie_id == vod_movie_id)

if __name__ == "__main__":
	test_WallaIE()

# Generated at 2022-06-24 13:40:35.437622
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-24 13:40:36.521962
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:40:45.837947
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from walla.utils import format_list
    import walla
    # Create a instance of WallaIE, is it possible?

# Generated at 2022-06-24 13:40:56.018377
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = WallaIE._VALID_URL
    mobj = re.match(WallaIE._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    video = WallaIE()._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id)

    item = video.find('./items/item')

    title = xpath_text(item, './title', 'title')
    description = xpath_text(item, './synopsis', 'description')
    thumbnail = xpath_text(item, './preview_pic', 'thumbnail')

# Generated at 2022-06-24 13:41:03.781483
# Unit test for constructor of class WallaIE
def test_WallaIE():
   # Test with extractor channel
   channel = WallaIE(WallaIE.ie_key())
   channel.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

   # Test with extractor channel and specific display_id
   channel = WallaIE(WallaIE.ie_key())
   channel.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'one-direction-all-for-one')

# Generated at 2022-06-24 13:41:06.210018
# Unit test for constructor of class WallaIE
def test_WallaIE():
    inst = WallaIE()
    assert inst._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'



# Generated at 2022-06-24 13:41:07.427411
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()(WallaIE._TEST['url']) == WallaIE._TEST

# Generated at 2022-06-24 13:41:17.619788
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    # check the constructor
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.extractor_key == 'walla'

    # check the functions of class InfoExtractor
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')['id'] == '2642630'

# Generated at 2022-06-24 13:41:20.477967
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:22.429652
# Unit test for constructor of class WallaIE
def test_WallaIE():
	"""
	Constructor of WallaIE test
	"""
	
	# Constructor
	walla_ie = WallaIE()
	
	# Check instance object
	assert isinstance(walla_ie, WallaIE) == True


# Generated at 2022-06-24 13:41:24.652891
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:41:27.606186
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', {})
    print(ie.get_name())

# Generated at 2022-06-24 13:41:35.701027
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import sys
    import unittest

    reload(sys)
    sys.setdefaultencoding('utf-8')

    class TestWallaIE(unittest.TestCase):
        def test_WallaIE(self):
            url = WallaIE._TEST['url']
            name = WallaIE._TEST['display_id']
            video = WallaIE.suitable(url)
            assert video == name

            # Test with a WallaIE object
            video_name = WallaIE(url)._TEST['display_id']
            assert video_name == name

            # Test WallaIE _real_extract
            real_extract = WallaIE._real_extract(url)
            info_dict = WallaIE._TEST['info_dict']
            assert real_extract['id'] == info_

# Generated at 2022-06-24 13:41:42.020440
# Unit test for constructor of class WallaIE
def test_WallaIE():
    fail_IE = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    pass_IE = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert test_WallaIE.__name__ == fail_IE.test_WallaIE.__name__
    assert fail_IE.test_WallaIE() == pass_IE.test_WallaIE()

# Generated at 2022-06-24 13:41:48.731743
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from xml.etree import cElementTree, ElementTree

    group = cElementTree.Element('group')
    group.tail = '\n'
    title = cElementTree.SubElement(group, 'title')
    title.text = 'hello'
    title.tail = '\n'
    item = cElementTree.SubElement(group, 'item')
    item.text = title.text
    item.tail = '\n'

    wi = WallaIE(ElementTree.fromstring(cElementTree.tostring(group)))
    assert wi._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:49.394442
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE({})

# Generated at 2022-06-24 13:41:54.898931
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert obj._TEST['info_dict']['id'] == '2642630'
    assert obj._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert obj._TEST['info_dict']['ext'] == 'flv'
   

# Generated at 2022-06-24 13:41:55.757188
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie=WallaIE()

# Generated at 2022-06-24 13:41:56.428364
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:42:04.478241
# Unit test for constructor of class WallaIE
def test_WallaIE():

    url = WallaIE._VALID_URL

    # Test using real web page
    mobj = re.match(WallaIE._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')

    assert WallaIE._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id) is not None

# Generated at 2022-06-24 13:42:08.974639
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()
	text = ie._VALID_URL
	assert "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)" == text
	

# Generated at 2022-06-24 13:42:20.229783
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:21.214354
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()

# Generated at 2022-06-24 13:42:31.502457
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:33.975244
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.extract()

# Generated at 2022-06-24 13:42:36.028226
# Unit test for constructor of class WallaIE
def test_WallaIE():
	""" Test WallaIE class constructor """
	# Success case
	WallaIE
	# Failure case
	try:
	    WallaIE(TypeError)
	except Exception as e:
		assert(type(e) == TypeError)
		assert(str(e) == "Argument 'test' isn't a valid URL")

# Generated at 2022-06-24 13:42:36.999393
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()


# Generated at 2022-06-24 13:42:46.495731
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    obj = object.__new__(WallaIE)
    ie.__init__(obj)   # pylint: disable=no-member
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:55.919630
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:56.716240
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE()


# Generated at 2022-06-24 13:42:58.051846
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL



# Generated at 2022-06-24 13:43:01.065004
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla = WallaIE()
    assert walla.suitable(url) is True
    walla.extract(url)

# Generated at 2022-06-24 13:43:02.199414
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _test = WallaIE()
    assert _test



# Generated at 2022-06-24 13:43:06.138492
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert_equals(ie._VALID_URL, ie.VALID_URL)
    assert_equals('2642630', ie.video_id)
    assert_equals('one-direction-all-for-one', ie.display_id)


# Generated at 2022-06-24 13:43:08.107596
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    ie.download();

# Generated at 2022-06-24 13:43:12.945609
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_obj = WallaIE()
    assert test_obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:21.405244
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:24.335430
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/?w=null/null/2542843/@@/video/flv_pl'
    video_id = '2542843'
    display_id = '2542843'

# Generated at 2022-06-24 13:43:26.795068
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie=WallaIE(WallaIE._TEST)

# Generated at 2022-06-24 13:43:37.047878
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert WallaIE.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/")
    assert WallaIE.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one?test=test")
    assert not WallaIE.suitable("http://vod.walla.co.il/")
    assert not WallaIE.suitable("http://vod.walla.co.il")

# Generated at 2022-06-24 13:43:38.125504
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('test') == 'test'

# Generated at 2022-06-24 13:43:42.438484
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    VideoPage = WallaIE(url)
    assert VideoPage._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:43:43.752548
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:43:44.774660
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie != None

# Generated at 2022-06-24 13:43:49.517506
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert re.match(WallaIE._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert re.match(WallaIE._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one.flv')

# Generated at 2022-06-24 13:43:51.409085
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert "WallaIE" in ie.IE_NAME


# Generated at 2022-06-24 13:43:52.583707
# Unit test for constructor of class WallaIE
def test_WallaIE():
    bob = WallaIE(__name__)
    print(bob)

# Generated at 2022-06-24 13:43:59.883037
# Unit test for constructor of class WallaIE
def test_WallaIE():
    example_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(example_url)
    actual_url = ie._VALID_URL
    expected_url = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert actual_url == expected_url

# Generated at 2022-06-24 13:44:07.391262
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    info_dict = ie._real_extract(ie._VALID_URL)
    assert '2642630' in info_dict
    assert 'one-direction-all-for-one' in info_dict
    assert '3600' in info_dict
    assert 'de9e2512a92442574cdb0913c49bc4d8' in info_dict
    assert 'rtmp://wafla.walla.co.il/vod' in info_dict

# Generated at 2022-06-24 13:44:10.000338
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL  # pylint: disable=protected-access
    ie._TEST  # pylint: disable=protected-access
    ie._SUBTITLE_LANGS  # pylint: disable=protected-access
    ie._real_extract  # pylint: disable=protected-access

# Generated at 2022-06-24 13:44:15.430357
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    expected_regex = r'^https?://video2\.walla\.co\.il/\?w=null/null/2642630/@@/video/flv_pl$'
    assert re.match(expected_regex, ie._downloader._request_webpage.__defaults__[0], re.ASCII)

# Generated at 2022-06-24 13:44:21.993376
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__.__name__ == 'WallaIE'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True, "Failed suitable test"
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/') == False, "Failed suitable test"
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/One-Direction-All-For-One') == True, "Failed suitable test"

# Generated at 2022-06-24 13:44:31.856324
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Init extractor by url
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    extractor = InfoExtractor.get_info_extractor(url)
    # Test if constructor succeeded
    assert type(extractor) is WallaIE
    # Test if expected result
    assert extractor._VALID_URL is not None
    assert extractor._TEST is not None
    assert extractor._SUBTITLE_LANGS is not None
    assert extractor._real_extract is not None
    # Test if expected result of method extractor._extract_subtitles
    assert extractor._extract_subtitles(url) is None



# Generated at 2022-06-24 13:44:43.481062
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()._TEST
    assert(type(test) == dict);
    assert(type(test) == dict);
    assert(type(test['params']) == dict);
    assert(test['params']['skip_download'] == True);
    assert(type(test['info_dict']) == dict);
    assert(type(test['info_dict']['duration']) == int);
    assert(type(test['info_dict']['duration']) == int);
    assert(type(test['info_dict']['title']) == unicode);
    assert(type(test['info_dict']['ext']) == unicode);
    assert(type(test['info_dict']['display_id']) == unicode);

# Generated at 2022-06-24 13:44:50.087006
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # 1. Test that vod.walla.co.il is not registered
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    registered_ies = InfoExtractor._ALL_CLASSES
    assert WallaIE.suitable(url)
    assert WallaIE.__name__ not in registered_ies
    # 2. Test that constructor of WallaIE class registers it
    WallaIE(None)
    assert WallaIE.__name__ in registered_ies

# Generated at 2022-06-24 13:44:56.658280
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for constructor of WallaIE class
    # This test asserts the object is created successfully
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie is not None, 'Object is not created successfully'
    # This test asserts the  method real_extract is called successfully
    assert ie.real_extract(ie.url) is not None, 'WallaIE.real_extract is not called successfully'

# Generated at 2022-06-24 13:44:57.688843
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video = WallaIE('test')
    video.get_test()

# Generated at 2022-06-24 13:44:58.218684
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-24 13:44:59.050138
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("WallaIE")

# Generated at 2022-06-24 13:45:01.933445
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test case 1 - test the constructor of class WallaIE
    url_1 = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    test_case_1 = WallaIE(url_1)
    

# Generated at 2022-06-24 13:45:08.644460
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:15.377843
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Test with a short url
    url = "http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl"
    w = WallaIE()
    w.download(url)
    assert w.video_id == 2642630
    assert w.display_id == 'one-direction-all-for-one'

    video = w.video

    assert video.title == 'וואן דיירקשן: ההיסטריה'
    assert video.formats[0]['format_id'] == '239p'
    assert len(video.formats) == 6
    assert video.duration == 3600

# Generated at 2022-06-24 13:45:20.501156
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    walla_video = WallaIE(url)
    assert "WallaIE" == walla_video.__class__.__name__

# Generated at 2022-06-24 13:45:22.592480
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()


# Generated at 2022-06-24 13:45:24.822121
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:45:34.823027
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie = WallaIE("WallaIE")
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert ie.IE_NAME == 'walla:vod'
    assert ie.IE_DESC == 'Walla! vod'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    #assert ie._TEST == 'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
    #'info_dict': {
    #    'id': '26426

# Generated at 2022-06-24 13:45:35.609559
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()



# Generated at 2022-06-24 13:45:36.821360
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_WallaIE = WallaIE()

# Generated at 2022-06-24 13:45:39.940162
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor of WallaIE
    ie = WallaIE({"A":1})
    assert ie.IE_NAME == "walla"
    assert ie.ie_key() == "walla:video"
    assert ie.ie_url() == "walla.co.il"

# Generated at 2022-06-24 13:45:50.057644
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test WallaIE constructor
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:55.050968
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    res = ie.__dict__
    keys = ['url', '_VALID_URL', '_TEST', '_SUBTITLE_LANGS', '_real_extract']
    for key in keys:
        assert key in res


# Generated at 2022-06-24 13:45:56.983814
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# unit test for regular expressions, _VALID_URL

# Generated at 2022-06-24 13:45:58.656150
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:01.352713
# Unit test for constructor of class WallaIE
def test_WallaIE():
	def foo(arg1, arg2, **kwargs):
		pass

	foo(1, 2, a=3, b=4)

# Generated at 2022-06-24 13:46:03.532925
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    return WallaIE

# Generated at 2022-06-24 13:46:09.286528
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.SUBTITLE_LANGS == {'עברית': 'heb'}
    assert ie.VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:10.124039
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = InfoExtractor(WallaIE)

# Generated at 2022-06-24 13:46:12.810183
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:46:14.949507
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('WallaIE', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:15.835380
# Unit test for constructor of class WallaIE
def test_WallaIE():
    main = WallaIE(InfoExtractor)

# Generated at 2022-06-24 13:46:16.972977
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:46:24.993431
# Unit test for constructor of class WallaIE
def test_WallaIE():
	result = ["WallaIE"]
	previousIP = "127.0.0.1" # get the previous IP-address; this doesn't really matter.

# Generated at 2022-06-24 13:46:26.589855
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    assert isinstance(a, InfoExtractor)


# Generated at 2022-06-24 13:46:27.830341
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:46:29.801231
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    except TypeError:
        return False;
    return True;

# Generated at 2022-06-24 13:46:33.045001
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Check if we can construct the WallaIE object with a valid url
    """
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    WallaIE(url)

# Generated at 2022-06-24 13:46:35.725155
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(WallaIE(FakeYDL()), WallaIE)

# Generated at 2022-06-24 13:46:45.172607
# Unit test for constructor of class WallaIE
def test_WallaIE():

    class Args():
        def __init__(self, ie, url, note, must_fail):
            self.ie = ie
            self.url = url
            self.note = note
            self.must_fail = must_fail

    test_cases = [
        (Args(ie="WallaIE", url="http://vod.walla.co.il/movie/2642630/one-direction-all-for-one", note="test", must_fail=False)),
        (Args(ie="WallaIE", url="http://vod.walla.co.il/movie/2642630/one-direction-all-for-one", note="test", must_fail=True))
    ]


# Generated at 2022-06-24 13:46:46.049159
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Unit test for constructor of class WallaIE
    info_extractor = WallaIE()

# Generated at 2022-06-24 13:46:50.658139
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("test_WallaIE(): ", WallaIE.__name__)
    video_id = 2642630
    display_id = "one-direction-all-for-one"
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    WallaIE._real_extract(
        WallaIE(),
        url
    )

# Generated at 2022-06-24 13:46:56.376468
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info = WallaIE("url", {})._real_extract({'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'})
    assert info['title'] == "וואן דיירקשן: ההיסטריה"
    assert info['duration'] == 3600

# Generated at 2022-06-24 13:46:56.901362
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:46:57.695823
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-24 13:47:03.376115
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test WallaIE constructor
    t = WallaIE(None)
    # Should be _VALID_URL
    assert t._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    # Should be _SUBTITLE_LANGS
    assert t._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-24 13:47:10.035488
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from ..test import get_testcases
    from ..extractor_tests import IE_DESC, ExtensionTest

    suite = [
        ExtensionTest(
            # walla video with subtitles
            IE_DESC, 'http://vod.walla.co.il/item/2642630',
            get_testcases('walla', '2642630', 'http://vod.walla.co.il/item/2642630')),
    ]
    return suite

# Generated at 2022-06-24 13:47:13.236742
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("https://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.download("https://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:47:15.590154
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Should not throw exception
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:47:21.504882
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url ='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wallaIE = WallaIE()
    mobj = re.match(wallaIE._VALID_URL, url)

    # Test if the url is valid
    assert(mobj is not None)
    assert(mobj.group('id') == '2642630')
    assert(mobj.group('display_id') == 'one-direction-all-for-one')


# Generated at 2022-06-24 13:47:22.988357
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-24 13:47:26.837050
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:30.595794
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:31.471791
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-24 13:47:34.362737
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:47:35.520324
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    return ie

# Generated at 2022-06-24 13:47:36.518681
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert True


# Generated at 2022-06-24 13:47:40.785296
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Unit test for constructor of class WallaIE
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # TODO: add test for constructor in WallaIE
    #ie = WallaIE(url)
    #ie.extract()


# Generated at 2022-06-24 13:47:51.478475
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj.__class__.__name__ == 'WallaIE'
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:52.096989
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:47:52.604716
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:47:53.726020
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    print(a)

# Generated at 2022-06-24 13:48:04.872733
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:05.436969
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE()

# Generated at 2022-06-24 13:48:08.055344
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('www.walla.co.il')
    assert isinstance(ie, WallaIE)
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-24 13:48:08.368677
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:48:18.669142
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for WallaIE.
    """

    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    wallaIE = WallaIE(url)

    assert wallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert wallaIE.url == url
    assert wallaIE._TEST['url'] == url

    assert wallaIE._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

    # Test of method _real_extract
    actual = wallaIE._real_extract(url)


# Generated at 2022-06-24 13:48:19.882401
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None

# Generated at 2022-06-24 13:48:20.581233
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-24 13:48:21.599255
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:48:23.088549
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-24 13:48:23.717846
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:48:29.573275
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie.suitable(WallaIE._VALID_URL)
    assert not ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:48:33.079554
# Unit test for constructor of class WallaIE
def test_WallaIE():
    o = WallaIE()
    assert o._TEST['url'] is not None
    assert o._TEST['url'] is not None
    assert o._TEST['info_dict'] is not None
    assert o._TEST['params'] is not None

# Generated at 2022-06-24 13:48:33.620687
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:48:36.581417
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:48:45.534837
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:48:52.406472
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Arrange
	url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	ie = WallaIE()

	# Act
	# assert_raises is used to verify that a specific exception gets raised
	with pytest.raises(RegexMatchError) as match:
		ie._real_extract(url)

	# Assert
	assert match.value.regex == ie._VALID_URL

# Generated at 2022-06-24 13:49:02.709189
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """ Testing constructor of class WallaIE """
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla_ie = WallaIE()
    if not walla_ie:
        raise "WallaIE not initialized"

# Generated at 2022-06-24 13:49:03.390104
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:49:12.458082
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.__class__.__name__ == 'WallaIE'
    assert ie.ie_key() == 'walla'
    assert ie.host() == 'vod.walla.co.il'
    assert ie.MANIFEST_URL == 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl'
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', False) == True
    assert ie.valid

# Generated at 2022-06-24 13:49:15.091297
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._real_extract('http://vod.walla.co.il/movie/2649123/kakaotv')

# Generated at 2022-06-24 13:49:21.785332
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:49:24.958503
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.suitable('http://vod.walla.co.il/tv/33246/once-upon-a-time-s4-e18/VIDEOS/16348460/')
    ie.suitable('http://vod.walla.co.il/item/3110966/')

# Generated at 2022-06-24 13:49:31.986847
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie_obj = WallaIE()
    assert ie_obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:49:32.764838
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE

# Generated at 2022-06-24 13:49:34.189324
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()
