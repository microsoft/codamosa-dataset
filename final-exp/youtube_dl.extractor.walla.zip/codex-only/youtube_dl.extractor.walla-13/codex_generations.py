

# Generated at 2022-06-24 13:39:42.838081
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import unittest
    import sys
    from ytdl_options import WallaIE
    # When argument is invalid
    try:
        WallaIE(None, None, None, None, None)
        assert (False)
    except TypeError as e:
        assert (str(e) == '__init__() takes at least 6 arguments (5 given)')

    # When argument is valid
    try:
        WallaIE(None, None, None, None, None, None)
        assert (True)
    except TypeError as e:
        assert (False)

# Generated at 2022-06-24 13:39:45.134693
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None).add_ie(WallaIE.ie_key())
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-24 13:39:48.782041
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create an object of class WallaIE
    obj_walla = WallaIE()

    # Check if object is an instance of class WallaIE
    assert isinstance(obj_walla, WallaIE)

# Generated at 2022-06-24 13:39:54.009735
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._check_valid_url(url)
    assert ie._match_id(url) == ('2642630', 'one-direction-all-for-one')

# Generated at 2022-06-24 13:40:04.984485
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = "https://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    exp_url = "http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl"
    exp_file = "2642630.xml"
    exp_display_id = "one-direction-all-for-one"
    exp_video_id = "2642630"

    ie = WallaIE()
    ie.download(test_url)
    file_url = ie.get_file_url()
    display_id = ie.get_display_id()
    video_id = ie.get_video_id()
    assert file_url == exp_url
    assert display_id == exp_display_id

# Generated at 2022-06-24 13:40:05.445034
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:40:05.931311
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:40:06.684845
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-24 13:40:07.629182
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("In test_WallaIE()")
    assert WallaIE


# Generated at 2022-06-24 13:40:15.560506
# Unit test for constructor of class WallaIE
def test_WallaIE():

    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:24.740346
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.SUFFIX == 'walla.co.il'
    assert ie.IE_NAME == 'walla:video'
    assert ie.ie_key() == 'Walla'
    assert ie.REAL_DEAL == 'http://video2.walla.co.il'
    assert ie.VERSION == '0.1'
    assert ie.DIRECT_URL == 'http://wafla.walla.co.il/vod'
    assert ie.IP_DOMAIN == 'ip.walla.co.il'

# Generated at 2022-06-24 13:40:27.892767
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    result = WallaIE()._real_extract(url)
    print(result)

# Generated at 2022-06-24 13:40:30.682836
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE({})
    assert(IE.name() == 'Walla.co.il')
    assert(IE.ie_key() == 'Walla')

# Generated at 2022-06-24 13:40:34.696680
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video = WallaIE()._real_extract(WallaIE._TEST['url'])
    assert video['id'] == WallaIE._TEST['info_dict']['id']
    assert video['display_id'] == WallaIE._TEST['info_dict']['display_id']
    assert video['title'] == WallaIE._TEST['info_dict']['title']
    assert video['description'] == WallaIE._TEST['info_dict']['description']
    assert video['thumbnail'] == WallaIE._TEST['info_dict']['thumbnail']
    assert video['duration'] == WallaIE._TEST['info_dict']['duration']

# Generated at 2022-06-24 13:40:44.480025
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url);
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:40:47.204133
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:50.192004
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-24 13:40:54.162584
# Unit test for constructor of class WallaIE
def test_WallaIE():

    class TestWallaIE(WallaIE):
        def _download_xml(x, y, z):
            class Object:
                def find(a, b):
                    return None
            return Object()

    test_WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:41:02.070361
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:11.310764
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """test the constructor of class WallaIE"""
    # test valid URL
    WallaIE(WallaIE._VALID_URL)

    # test invalid URL
    invalid_urls = [
        'http://vod.walla.co.il/movie/264260/one-direcion-all-for-one',
        'http://vod.walla.co.il/movie/264260/',
    ]
    for invalid_url in invalid_urls:
        try:
            WallaIE(invalid_url)
            raise AssertionError('Expected invalid URL to raise ValueError')
        except ValueError:
            pass

# Generated at 2022-06-24 13:41:13.610221
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    w = WallaIE(url)
    assert w.url == url
    assert w.extract(url)['id'] == '2642630'


# Generated at 2022-06-24 13:41:15.269666
# Unit test for constructor of class WallaIE
def test_WallaIE():
    downloader = WallaIE()

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:41:16.178802
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w is not None

# Generated at 2022-06-24 13:41:21.812840
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._VALID_URL == WallaIE._VALID_URL
    assert WallaIE._TEST == WallaIE._TEST
    assert WallaIE._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert WallaIE(url)._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')



# Generated at 2022-06-24 13:41:22.400613
# Unit test for constructor of class WallaIE
def test_WallaIE():
	pass

# Generated at 2022-06-24 13:41:23.856512
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()
    assert type(t) == WallaIE

# Generated at 2022-06-24 13:41:33.222513
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:42.557186
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE()
    assert(i._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:41:44.417680
# Unit test for constructor of class WallaIE
def test_WallaIE():
    if __name__ == "__main__":
        WallaIE()

# Generated at 2022-06-24 13:41:50.291238
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.scan_urls(['http://vod.walla.co.il/movie/2642630/one-direction-all-for-one']) == ['http://vod.walla.co.il/movie/2642630/one-direction-all-for-one']
    assert ie.scan_urls(['http://vod.walla.co.il/news/2642630/one-direction-all-for-one']) == []

# Generated at 2022-06-24 13:41:55.147879
# Unit test for constructor of class WallaIE
def test_WallaIE():
	info_dict = WallaIE(WallaIE._TEST, None).extract()
	assert info_dict['id'] == '2642630'
	assert info_dict['display_id'] == 'one-direction-all-for-one'
	assert info_dict['ext'] == 'flv'
	assert info_dict['title'] == 'וואן דיירקשן: ההיסטריה'
	assert info_dict['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
	assert info_dict['thumbnail'] == r're:^https?://.*\.jpg'

# Generated at 2022-06-24 13:41:58.913054
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)

    # Test regex of valid URL
    regex_url_valid = ie._VALID_URL
    assert re.match(regex_url_valid, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:42:05.975165
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test of WallaIE.
    """

# Generated at 2022-06-24 13:42:06.419795
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:42:07.950866
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie_class = WallaIE
    ie_instance = ie_class()
    assert ie_instance.__class__ == ie_class, 'test_WallaIE: constructor should return instance of its class'


# Generated at 2022-06-24 13:42:15.321088
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.NAME == "Walla"
    assert ie.IE_CNAME == "Walla"
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert ie._TEST['info_dict']['id'] == "2642630"
    assert ie._TEST['info_dict']['display_id'] == "one-direction-all-for-one"
    assert ie._TEST['info_dict']['ext'] == "flv"
    assert ie._

# Generated at 2022-06-24 13:42:22.234520
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.__name__ == 'Walla'
    assert ie.IE_NAME == 'walla:vod'

# Generated at 2022-06-24 13:42:23.954063
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_dict = {}
    ie = WallaIE(info_dict)
    assert ie.extract() == info_dict

# Generated at 2022-06-24 13:42:34.069303
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:40.204571
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME  == 'walla'
    #assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    #assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all') == False

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:42:40.725470
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("")

# Generated at 2022-06-24 13:42:42.531602
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE('test')
	return ie.constructor_test

# Generated at 2022-06-24 13:42:46.453201
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create object of class WallaIE
    ies = WallaIE()

    # Test _VALID_URL
    assert ies._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)', "Missing _VALID_URL"

# Generated at 2022-06-24 13:42:48.758707
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.url_regex == WallaIE._VALID_URL

# Generated at 2022-06-24 13:42:49.850442
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-24 13:42:54.980370
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert i.match_id == '2642630'
    assert i.match_displayid == 'one-direction-all-for-one'
    assert i.match_title == None

# Generated at 2022-06-24 13:42:55.877067
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('url')

# Generated at 2022-06-24 13:42:58.137366
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()
    test._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:43:05.881480
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor

    # Create instance of WallaIE
    IE = WallaIE("")

    # Run tests
    assert len(IE.IE_DESC) > 0 # class variable must contain description
    assert (IE.IE_NAME == "Walla") # class variable must contain name
    assert len(IE.IE_VERSION) > 0 # class variable must contain version
    assert len(IE.WEBPAGE_URL) > 0 # class variable must contain webpage url
    assert len(IE.VALID_URL) > 0 # class variabl must contain valid url
    assert len(IE.LANG) > 0 # class variabl must contain language

# Generated at 2022-06-24 13:43:11.917755
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for constructor of class WallaIE
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert 'WallaIE' in ie.__class__.__name__
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:20.752144
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import get_testcases
    from .test_walla import WallaIE
    ie = WallaIE()
    for url, data in get_testcases(WallaIE, 'url', 'data'):
        m = re.match(ie._VALID_URL, url)
        data['id'] = m.group('id')
        data['display_id'] = m.group('display_id')
        data['ext'] = 'flv'
        data['subtitles'] = {
            'עברית': [
                {
                    'ext': 'srt',
                    'url': 'http://media.walla.co.il/playlist/subtitles/subtitles_2642630.srt',
                }
            ]
        }

# Generated at 2022-06-24 13:43:23.252026
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie.extract()

# Generated at 2022-06-24 13:43:31.984292
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    # Test class constructor
    ie = WallaIE(url)
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.url == url

# Generated at 2022-06-24 13:43:37.780843
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ret = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    print("TEST: WallaIE")
    print("\tURL: http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    print("\tID: %s" % ret.video_id)
    print("\tDISPLAY ID: %s" % ret.display_id)
    print("\tTITLE: %s" % ret.title)
    print("\tFORMATS: %d" % len(ret.formats))
    print("\tDURATION: %s" % ret.duration)

# Generated at 2022-06-24 13:43:39.880094
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Run test code
    ie = WallaIE()
    ie.extract_urls('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:40.488957
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-24 13:43:42.854711
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suite()


# Generated at 2022-06-24 13:43:44.188635
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None

# Generated at 2022-06-24 13:43:46.543886
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:49.868559
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:51.353586
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:44:00.848602
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Args:
        url:string, the url of vod.walla.co.il

    Returns:
        the instance of WallaIE
    """
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.video_id == '2642630'
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:44:06.409408
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(WallaIE._VALID_URL, url)
    assert mobj.group('id') == '2642630'
    assert mobj.group('display_id') == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:44:07.391710
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:44:08.561773
# Unit test for constructor of class WallaIE
def test_WallaIE():
    r = WallaIE()
    assert not r.test()

# Generated at 2022-06-24 13:44:10.116720
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:44:18.494932
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:19.294829
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-24 13:44:21.071221
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:44:22.060628
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE().test()

# Generated at 2022-06-24 13:44:22.687936
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-24 13:44:25.376982
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Make sure an exception is raised for invalid URL
    assert ie.suitable(ie.VALID_URL)

# Generated at 2022-06-24 13:44:30.257492
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test WallaIE.__init__()
    """
    i = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert i.display_id == 'one-direction-all-for-one'
    assert i.video_id == '2642630'

# Generated at 2022-06-24 13:44:30.964668
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download(_TEST['url'])

# Generated at 2022-06-24 13:44:37.863960
# Unit test for constructor of class WallaIE
def test_WallaIE():
    testcases = [
        ['http://video4.walla.co.il/?w=null/null/null/@@/video/flv_pl', 'WallaMediaPlayerAvod.swf'],
        ['http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'WallaMediaPlayerAvod.swf'],
    ]

    for video_url, player_url in testcases:
        ie = WallaIE(None, {}, video_url)
        video = ie._download_xml(
            video_url, 'test_video')
        item = video.find('./items/item')
        quality = item.find('./qualities/quality[1]')

# Generated at 2022-06-24 13:44:38.568152
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:44:39.190600
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:44:41.576457
# Unit test for constructor of class WallaIE
def test_WallaIE():
  # Unit test for constructor without parameter
  assert WallaIE(None) is not None
  assert WallaIE(None, {}) is not None

# Generated at 2022-06-24 13:44:45.355323
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test to see if the WallaIE class is working
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    _ = WallaIE()(url)

# Generated at 2022-06-24 13:44:51.618703
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert ie.rss_url=='http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl'
    assert ie.video_id=='2642630'
    assert ie.display_id=='one-direction-all-for-one'

# Generated at 2022-06-24 13:44:59.685759
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert x._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:00.524191
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:45:03.080937
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE(url)
    assert w.url == url


# Generated at 2022-06-24 13:45:08.224232
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE()._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE()._TEST['info_dict']['id'] == '2642630'
    assert WallaIE()._TEST['params']['skip_download'] == True

# Generated at 2022-06-24 13:45:09.028435
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor
    WallaIE('WallaIE')

# Generated at 2022-06-24 13:45:12.222209
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert isinstance(ie,WallaIE)


if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:45:12.735953
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-24 13:45:22.070986
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.name == 'walla'
    assert ie.app_id == 'wallaMovies'
    assert ie.app_name == 'wallaMovies'
    assert ie.url_pattern == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.valid_url('http://vod.walla.co.il')
    assert not ie.valid_url('http://walla.co.il')

# Generated at 2022-06-24 13:45:22.808104
# Unit test for constructor of class WallaIE
def test_WallaIE():
    testObj = WallaIE()

# Generated at 2022-06-24 13:45:29.696515
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for the constructor
    wallaIE = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert(wallaIE.url == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert(wallaIE.video_id == "2642630")
    assert(wallaIE.display_id == "one-direction-all-for-one")


# Generated at 2022-06-24 13:45:31.693010
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

if __name__ == "__main__":
    test_WallaIE()

# Generated at 2022-06-24 13:45:32.180777
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:45:41.843146
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Test 1:
    assert WallaIE._VALID_URL == 'https?://vod\\.walla\\.co\\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['info_dict'].get('id') == '2642630'
    assert WallaIE._TEST['info_dict'].get('display_id') == 'one-direction-all-for-one'
    assert WallaIE._TEST['info_dict'].get('ext') == 'flv'
    assert WallaIE._TEST['info_dict'].get('title') == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:45:51.630250
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:45:54.741625
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:45:56.996244
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .test_downloader import test_fetch_extract_url
    # path to the testdata
    test_fetch_extract_url(WallaIE())

# Generated at 2022-06-24 13:45:57.710714
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE.suite()

# Generated at 2022-06-24 13:45:58.881219
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie == WallaIE()


# Generated at 2022-06-24 13:46:02.024244
# Unit test for constructor of class WallaIE
def test_WallaIE():
	"Function tests the constructor of the WallaIE class."
	# Test the constructor of the class
	ie = WallaIE()
	assert(ie.SUCCESS)
	

# Generated at 2022-06-24 13:46:12.539469
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:18.372977
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:26.114492
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test constructor of class WallaIE
    """
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-24 13:46:30.710895
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # TODO: Remove this line if non-english languages are fully supported
    return

    # Test Subtitles
    ie = WallaIE('http://walla.co.il')
    sub_langs = ie._SUBTITLE_LANGS
    assert sub_langs['עברית'] == sub_langs['Hebrew'] == 'heb'

# Generated at 2022-06-24 13:46:39.865147
# Unit test for constructor of class WallaIE
def test_WallaIE():
    res = WallaIE()._real_extract(WallaIE._TEST['url'])
    assert res['id'] == WallaIE._TEST['info_dict']['id']
    assert res['title'] == WallaIE._TEST['info_dict']['title']
    assert res['description'] == WallaIE._TEST['info_dict']['description']
    assert res['thumbnail'] == WallaIE._TEST['info_dict']['thumbnail']
    assert res['duration'] == WallaIE._TEST['info_dict']['duration']

# Generated at 2022-06-24 13:46:42.428156
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:46.451385
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.ie_key() == 'Walla'
    assert ie.url_re.match(ie.url).group('id') == '2642630'
    assert ie.url_re.match(ie.url).group('display_id') == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:46:52.580159
# Unit test for constructor of class WallaIE
def test_WallaIE():
    data = WallaIE()._real_extract(url=WallaIE()._TEST['url'])
    data_assert = WallaIE()._TEST['info_dict']
    assert data_assert['url'] == data['url']
    assert data_assert['id'] == data['id']
    assert data_assert['display_id'] == data['display_id']
    assert data_assert['ext'] == data['ext']
    assert data_assert['title'] == data['title']
    assert data_assert['description'] == data['description']
    assert data_assert['thumbnail'] == data['thumbnail']
    assert data_assert['duration'] == data['duration']

# Generated at 2022-06-24 13:46:54.959915
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie=WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract()

# Generated at 2022-06-24 13:47:04.456962
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:14.011522
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:47:22.829641
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE._VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:25.370834
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._VALID_URL == WallaIE._VALID_URL
    assert WallaIE(None)._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS

# Generated at 2022-06-24 13:47:30.545533
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one").WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one") == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-24 13:47:40.915572
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:42.130504
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:47:44.129032
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    obj = WallaIE()
    assert obj is not None

# Generated at 2022-06-24 13:47:48.653587
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:47:53.036537
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert ie.url == url
    assert ie.name == 'walla'
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.video_id == '2642630'

# Generated at 2022-06-24 13:47:53.833054
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w

# Generated at 2022-06-24 13:48:04.873816
# Unit test for constructor of class WallaIE
def test_WallaIE():
	#from youtube_dl import YoutubeDL
	#from youtube_dl.extractor import WallaIE
	from walla_dl.extractor import WallaIE
	import json
	#from walla_dl.core import YoutubeDL
	#from walla_dl.extractor import WallaIE
	#from walla_dl.downloader import YoutubeDL
	#from walla_dl.extractor import WallaIE
	#import walla_dl.extractor
	#print json.dumps(walla_dl.extractor.WallaIE.__dict__)
	#Y_dl = YoutubeDL()
	#print json.dumps(Y_dl.__dict__)
	#Y_dl.add_default_info_extractors()
	#WallaIE.__init__(Y_dl)
	#print json.

# Generated at 2022-06-24 13:48:13.363465
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global video_id, display_id, video, item, title, description, thumbnail, duration, subtitles, English, English_ID, English_Subtitles, English_Subtitles_ID, English_Subtitles_VTT, English_Subtitles_VTT_ID, quality, formats

    class TestWallaIE(WallaIE):
        def _real_extract(self, url):
            return {'url': url}

    # Make a dictionary of arguments to function _download_xml
    # Expecting a Request made for url and data to be returned
    def _download_xml(self, url, display_id):
        global video_id, display_id, video, item, title, description, thumbnail, duration, subtitles, English, English_ID, English_Subtitles, English_Subtitles_ID, English_Subtitles_VTT

# Generated at 2022-06-24 13:48:18.613949
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.__class__.__name__ == 'WallaIE'


# Generated at 2022-06-24 13:48:29.209025
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_dict = {
        'id': '2642630',
        'display_id': 'one-direction-all-for-one',
        'ext': 'flv',
        'title': 'וואן דיירקשן: ההיסטריה',
        'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        'thumbnail': r're:^https?://.*\.jpg',
        'duration': 3600,
    }

    WallaIE(object, info_dict)._real_extract(
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:48:30.139208
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://test.com') != None

# Generated at 2022-06-24 13:48:30.674541
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:48:36.434948
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    @param url: url to the video
    @return: title of the video
    """
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    walla = WallaIE()
    info_dict = walla._real_extract(url)
    return info_dict['title']

# Generated at 2022-06-24 13:48:37.392573
# Unit test for constructor of class WallaIE
def test_WallaIE():
    (WallaIE()._VALID_URL)

# Generated at 2022-06-24 13:48:43.161141
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url_str = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    regex = WallaIE._VALID_URL
    regex = regex.replace("?", "")
    regex = regex.replace(".", "\.")
    regex = regex.replace("/", "\/")
    regex = "^" + regex + "$"
    matches = re.match(regex, url_str)
    assert not matches

# Generated at 2022-06-24 13:48:45.204699
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');


# Generated at 2022-06-24 13:48:48.203862
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    w.test_url(WallaIE._TEST['url'])

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:48:48.814226
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:48:50.000643
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('WallaIE')

# Generated at 2022-06-24 13:49:00.631982
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:49:01.109689
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:49:01.996279
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None

# Generated at 2022-06-24 13:49:11.231314
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:49:12.354034
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except:
        pass

# Generated at 2022-06-24 13:49:20.461145
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:49:23.120188
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(obj == 1)

# Generated at 2022-06-24 13:49:29.501432
# Unit test for constructor of class WallaIE
def test_WallaIE():
    '''
    Constructor of WallaIE must work with a URL.
    '''
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert ie.url == url
    assert ie.video_id == '2642630'
    assert ie.display_id == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:49:39.717426
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'