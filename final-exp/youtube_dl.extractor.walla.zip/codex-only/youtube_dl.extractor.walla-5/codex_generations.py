

# Generated at 2022-06-24 13:39:41.892427
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'http://vod.walla.co.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:39:45.351803
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    assert ie.suitable(url)


# Generated at 2022-06-24 13:39:49.448422
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert '2642630' in ie.constructor_test_results.keys()

# Generated at 2022-06-24 13:40:00.974534
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:02.022136
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("vod.walla.co.il", 2642630,"one-direction-all-for-one");

# Generated at 2022-06-24 13:40:05.557223
# Unit test for constructor of class WallaIE
def test_WallaIE():
	print('TEST [%s]' % sys._getframe().f_code.co_name)
	url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	res = WallaIE()._real_extract('url')
	print(res)
	
# Call to main()
if __name__ == '__main__':
	main()

# Generated at 2022-06-24 13:40:06.313012
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()


# Generated at 2022-06-24 13:40:07.982782
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test basic functionality of the constructor of class WallaIE."""
    ie = WallaIE()
    assert ie is not None

# Generated at 2022-06-24 13:40:12.024704
# Unit test for constructor of class WallaIE
def test_WallaIE():
    result = WallaIE()._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert result['display_id'] == 'one-direction-all-for-one'
    assert result['id'] == '2642630'

# Generated at 2022-06-24 13:40:12.569065
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-24 13:40:13.159251
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:40:17.276778
# Unit test for constructor of class WallaIE
def test_WallaIE():
    '''
    This function unit-tests the console script 'youtube-dl'.
    Currently it only tests the constructor of class WallaIE.
    '''
    ie = WallaIE('http')
    assert(ie.IE_NAME == 'Walla')
    assert(ie.IE_DESC == 'Walla! video')

# Generated at 2022-06-24 13:40:20.164400
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.__class__.__name__ == 'WallaIE'

# Generated at 2022-06-24 13:40:22.436943
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:22.893674
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:40:33.828573
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert w._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert w._TEST['info_dict']['id'] == '2642630'
    assert w._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert w._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:40:36.396253
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download(url='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:36.894639
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE({})

# Generated at 2022-06-24 13:40:37.229068
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-24 13:40:37.787129
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()


# Generated at 2022-06-24 13:40:39.872441
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:44.895969
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(WallaIE._TEST)
    ie._downloader.params.update({'writesubtitles': True, 'writeautomaticsub': True, 'allsubtitles':  True, 'allsubtitles':  True, 'forcejson': True})
    ie.download('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:49.523278
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("Test WallaIE")
    url = WallaIE._TEST['url']
    ieobject = WallaIE()
    assert(ieobject._VALID_URL == WallaIE._VALID_URL)
    #assert(ieobject._TEST == WallaIE._TEST)
    ieobject._real_extract(url)

# Generated at 2022-06-24 13:40:52.587410
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor.
    # TODO: test with real data
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:40:53.426971
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None, None)

# Generated at 2022-06-24 13:41:01.422443
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:41:08.827412
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WALLA_TEST = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    ie = WallaIE(WALLA_TEST)

    assert ie
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.url
    assert ie.embed_webpage
    assert ie.title
    assert ie.description
    assert ie.thumbnail
    assert ie.duration
    assert ie.subtitles

# Generated at 2022-06-24 13:41:09.977802
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE


# Generated at 2022-06-24 13:41:11.089400
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE() == WallaIE()

# Generated at 2022-06-24 13:41:13.837158
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except Exception as e: #if fail to create object, raise error
        raise Exception('Fail to create WallaIE object')


# Generated at 2022-06-24 13:41:14.785515
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-24 13:41:15.357678
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-24 13:41:21.849115
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w=WallaIE()
    # All vod.walla.co.il urls should be valid
    assert w._VALID_URL==r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    # Unit test for real_extract() method of WallaIE class
    assert w._TEST.get('url')=='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Unit test for real_extract() method of WallaIE class

# Generated at 2022-06-24 13:41:31.210964
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class_ = WallaIE
    # constructor should handle video with one quality
    video_id = 2642630
    data = class_.suite()._TEST
    assert data['url'].count(str(video_id)) == 1, 'video ID not found in URL'
    data['info_dict']['id'] = str(video_id)
    instance = class_(data)
    data['url'] = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert data['url'].count(str(video_id)) == 1, 'video ID not found in URL'
    assert data['info_dict']['id'] == str(video_id)
    instance = class_(data)

# Generated at 2022-06-24 13:41:32.119068
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE()



# Generated at 2022-06-24 13:41:41.452034
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"
    assert ie._TEST["url"] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert ie._TEST["info_dict"]["id"] == "2642630"
    assert ie._TEST["info_dict"]["display_id"] == "one-direction-all-for-one"
    assert ie._TEST["info_dict"]["ext"] == "flv"

# Generated at 2022-06-24 13:41:44.664391
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie.ie_name() == 'Walla!'

# Generated at 2022-06-24 13:41:52.128058
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # This test case is not included in WallaIE.TEST

    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    url = 'http://vod.walla.co.il/movie/' + video_id + '/' + display_id

    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import _write_string

# Generated at 2022-06-24 13:41:53.641032
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:41:54.983383
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    assert(ie != None);

# Generated at 2022-06-24 13:41:57.262523
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except:
        raise AssertionError("Test WallaIE failed")


# Generated at 2022-06-24 13:42:09.152489
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:20.364262
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test_expected_id = '2642630'

    w = WallaIE()
    w._downloader.http.head_response['Location'] = test_url
    assert isinstance(w, InfoExtractor)
    assert w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    w.suitable(test_url)
    w.extract(test_url)

    # Test for expected id in returned result
    test_result = w.extract(test_url)
    assert test_expected_id in test_result

# Generated at 2022-06-24 13:42:23.202406
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    WallaIE().suitable(url)

# Generated at 2022-06-24 13:42:33.120449
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    assert(ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:42:40.104706
# Unit test for constructor of class WallaIE
def test_WallaIE():
    cases = [
        # Will go to the 'real extractor' but will not download.
        {
            'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
            'only_matching': True,
        },
    ]
    for case in cases:
        ie = WallaIE()
        result = ie.suitable(case['url'])
        assert result == True


if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:42:42.580521
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Check if the constructor of the class WallaIE works well
    """
    instance = WallaIE()
    assert instance

# Generated at 2022-06-24 13:42:43.838224
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE._SUBTITLE_LANGS)


# Generated at 2022-06-24 13:42:51.518980
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    if ie._VALID_URL is None or ie._VALID_URL.match(url) is None:
        # It's impossible to test the extractor without URL
        return

    mobj = re.match(ie._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')

    video = ie._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id)

    item = video.find('./items/item')

    url

# Generated at 2022-06-24 13:43:00.120541
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    expected = {
        'id': '2642630',
        'display_id': 'one-direction-all-for-one',
        'ext': 'flv',
        'title': 'וואן דיירקשן: ההיסטריה',
        'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        'thumbnail': r're:^https?://.*\.jpg',
        'duration': 3600,
    }
    assert (ie.extract() == expected)

# Generated at 2022-06-24 13:43:02.199301
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:04.052650
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:05.349303
# Unit test for constructor of class WallaIE
def test_WallaIE():
    with walla_initializer() as (ie, _):
        assert isinstance(ie, WallaIE)

# Generated at 2022-06-24 13:43:06.128714
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None

# Generated at 2022-06-24 13:43:09.026631
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE();
	assert_equal(ie.IE_NAME,'walla');
	assert_equal(ie.VALID_URL,'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)');

# Generated at 2022-06-24 13:43:13.535556
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL is WallaIE._VALID_URL
    assert ie._SUBTITLE_LANGS is WallaIE._SUBTITLE_LANGS

# Generated at 2022-06-24 13:43:14.551131
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie_object = WallaIE()

# Generated at 2022-06-24 13:43:16.157247
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    print(walla)
    assert walla


# Generated at 2022-06-24 13:43:20.709802
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:29.600988
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test constructor of class WallaIE
    """
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    extracted = WallaIE()._real_extract(url)
    assert extracted['id'] == '2642630'
    assert extracted['display_id'] == 'one-direction-all-for-one'
    assert extracted['title'] == 'וואן דיירקשן: ההיסטריה'
    assert extracted['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert extracted['thumbnail'] == 're:^https?://.*\.jpg'
    assert extracted['duration'] == 3600

# Generated at 2022-06-24 13:43:30.341487
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w is not None

# Generated at 2022-06-24 13:43:34.421829
# Unit test for constructor of class WallaIE
def test_WallaIE():
    d = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert d.__class__.__name__ == 'WallaIE'
    assert d.ie_key() == 'Walla'

# Generated at 2022-06-24 13:43:35.086638
# Unit test for constructor of class WallaIE
def test_WallaIE():
	test_WallaIE = WallaIE()

# Generated at 2022-06-24 13:43:35.968757
# Unit test for constructor of class WallaIE
def test_WallaIE():
    r = WallaIE()
    assert r != None

# Generated at 2022-06-24 13:43:41.854908
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla = WallaIE()
    video = walla._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    assert video['id'] == '2642630'
    assert video['display_id'] == 'one-direction-all-for-one'
    assert video['ext'] == 'flv'
    assert video['title'] == 'וואן דיירקשן: ההיסטריה'
    assert video['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'

# Generated at 2022-06-24 13:43:46.287942
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie_Walla = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert hasattr(ie_Walla, '_real_extract')

# Generated at 2022-06-24 13:43:50.628018
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print('Input URL and extract it:')
    input_url = raw_input()
    ie = WallaIE()
    ie_result = ie._real_extract(input_url)
    print(ie_result)


# If exist:
# if __name__ == '__main__':
#     test_WallaIE()

# Generated at 2022-06-24 13:43:52.983796
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable(WallaIE._VALID_URL) == True
    assert ie.IE_NAME == 'walla'



# Generated at 2022-06-24 13:43:54.681475
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test constructing WallaIE
    """
    ie = WallaIE()

# Generated at 2022-06-24 13:43:56.402262
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_class = WallaIE(InfoExtractor)
    assert test_class

# Generated at 2022-06-24 13:44:06.342621
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:14.923917
# Unit test for constructor of class WallaIE
def test_WallaIE():

    ie = WallaIE('http://www.walla.co.il')

    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:44:19.322931
# Unit test for constructor of class WallaIE
def test_WallaIE():
	b = WallaIE.WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
	assert b.display_id == 'one-direction-all-for-one'
	assert b.video_id == '2642630'
	assert b.url == 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:44:26.625349
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:44:35.293079
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla!'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['params']['skip_download'] == True
    assert ie._SUB

# Generated at 2022-06-24 13:44:36.971787
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(WallaIE._TEST['url'])

# Generated at 2022-06-24 13:44:39.752095
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # For now the constructor of class WallaIE only verify the validity
    # of the URL, so this test is only to create an object of WallaIE
    WallaIE('url')

# Generated at 2022-06-24 13:44:42.489482
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test the constructor of WallaIE
    assert(WallaIE._SUBTITLE_LANGS == {
        'עברית': 'heb',
    })

# Generated at 2022-06-24 13:44:45.528328
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor of class WallaIE
    class_WallaIE = WallaIE("")
    assert class_WallaIE

    # Test constructor of class InfoExtractor
    class_InfoExtractor = InfoExtractor("")
    assert class_InfoExtractor

# Generated at 2022-06-24 13:44:49.263742
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.test_url()
    assert ie.test_subtitles()
    assert ie.test_formats()
    ie.test_get_subtitles()
    ie.test_get_formats()


# Generated at 2022-06-24 13:44:52.419080
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.__class__.__name__ == 'WallaIE'

# Generated at 2022-06-24 13:44:54.022358
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test if WallaIE constructor works"""
    w = WallaIE()
    assert w is not None


# Generated at 2022-06-24 13:44:57.282798
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("https://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.download("https://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:44:59.700465
# Unit test for constructor of class WallaIE
def test_WallaIE():
    result = WallaIE().match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    
    assert result == "WallaIE"

# Generated at 2022-06-24 13:45:01.109802
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:45:07.887851
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.VALID_URL == 'http://vod.walla.co.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.VALID_URL == WallaIE._VALID_URL
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.video_id == '2642630'
    assert ie.SUBTITLE_LANGS['עברית'] == 'heb'
    assert ie

# Generated at 2022-06-24 13:45:10.566481
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check all the function calls
    WallaIE()._downloader.urlopen.assert_called_once_with(
            WallaIE()._downloader.urlopen.return_value.__enter__().geturl.return_value)

# Generated at 2022-06-24 13:45:11.926438
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__.__name__ == 'WallaIE'


# Generated at 2022-06-24 13:45:22.140000
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE('', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:23.819247
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    ie.download();
    pass;

# Generated at 2022-06-24 13:45:25.192999
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE()
    assert wallaIE != None

# Generated at 2022-06-24 13:45:28.980738
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w.lang_sorting
    assert w.lang_sorting[0] == 'heb'
    assert w.lang_sorting[1] == 'עברית'
    assert w.lang_sorting[2] == 'en'

# Generated at 2022-06-24 13:45:31.502596
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .test import test_WallaIE
    WallaIE = test_WallaIE.TestWallaIE
    assert WallaIE


# Generated at 2022-06-24 13:45:33.244140
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('')
    if not ie.subtitle_langs:
        raise Exception('subtitle_langs must be initialized')

# Generated at 2022-06-24 13:45:41.395332
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:45:44.017276
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructor of WALLAIE succeeds
    ie = WallaIE("www.walla.co.il")
    assert(ie is not None)


# Generated at 2022-06-24 13:45:47.892196
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    res = ie.extract()
    print(res['title'])
    print(res['duration'])
    print(res['formats'])

# Generated at 2022-06-24 13:45:48.458249
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-24 13:45:51.399902
# Unit test for constructor of class WallaIE
def test_WallaIE():

    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()

    ie.extract(url)

# Generated at 2022-06-24 13:45:52.388174
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()

# Generated at 2022-06-24 13:45:53.689847
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()
    assert WallaIE('walla')

# Generated at 2022-06-24 13:45:54.968415
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:45:58.854640
# Unit test for constructor of class WallaIE
def test_WallaIE():
#    ie = WallaIE({"}, params={'format': 'best'})
    ie = WallaIE({'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'}, params={'format': 'best'})


#if __name__ == '__main__':
#    test_WallaIE()

# Generated at 2022-06-24 13:46:05.102800
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Check if class WallaIE constructor can handle a given url
    """
    assert WallaIE._VALID_URL == WallaIE.IE_NAME
    instance = WallaIE(WallaIE.IE_NAME)
    assert instance.ie_key() == WallaIE.ie_key()
    assert instance.suitable(WallaIE.IE_NAME)


# Generated at 2022-06-24 13:46:06.610339
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test instance of the class
    assert isinstance(WallaIE(), InfoExtractor)

# Generated at 2022-06-24 13:46:08.893273
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(u'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:17.751513
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    Video = WallaIE()
    video = Video._real_extract(url)
    assert video.get('id') == video_id
    assert video.get('display_id') == display_id
    assert video.get('title') == 'וואן דיירקשן: ההיסטריה'
    assert video.get('description') == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert video.get('duration') == 3600

# Generated at 2022-06-24 13:46:18.749002
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert "WallaIE" == WallaIE.ie_key()

# Generated at 2022-06-24 13:46:25.641214
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("url")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    return

# Generated at 2022-06-24 13:46:28.607447
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:35.827168
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from walla import WallaIE
    from walla import _VALID_URL, _TEST
    from walla import _SUBTITLE_LANGS, _real_extract
    from walla import InfoExtractor
    assert _VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert _TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert _TEST['info_dict']['id'] == '2642630'
    assert _TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:46:45.232684
# Unit test for constructor of class WallaIE
def test_WallaIE():
	test_ie = WallaIE();
	test_instance = test_ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
	assert test_instance['id'] == '2642630'
	assert test_instance['display_id'] == 'one-direction-all-for-one'
	assert test_instance['title'] == 'וואן דיירקשן: ההיסטריה'
	assert len(test_instance['formats']) == 8
	assert test_instance['duration'] == 3600

# Generated at 2022-06-24 13:46:53.263870
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    assert (ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)');

# Generated at 2022-06-24 13:46:54.651635
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wIE = WallaIE()
    assert wIE is not None

# Generated at 2022-06-24 13:46:56.375609
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test instantiating the class WallaIE
    WallaIE()


# Generated at 2022-06-24 13:47:01.323540
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.get_data_url(ie.format_data_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'test')) == 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/test'

# Generated at 2022-06-24 13:47:09.897189
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # test
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.IE_NAME == 'walla:video'
    assert ie.IE_DESC == 'Walla video'
    assert ie.VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-24 13:47:11.772750
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj.ie_key() == 'Walla'
    assert obj.ie_name() == 'Walla'

# Generated at 2022-06-24 13:47:13.318586
# Unit test for constructor of class WallaIE
def test_WallaIE():
    expected_return = "Unit test for constructor of class WallaIE"
    return expected_return

# Generated at 2022-06-24 13:47:14.991737
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    _ = WallaIE()


# Generated at 2022-06-24 13:47:21.622883
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.name == 'walla'
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:26.962344
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.name == 'Walla'
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.video_id == '2642630'

# Generated at 2022-06-24 13:47:37.956887
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import test_value
    from .common import test_url
    from .common import test_type

    # Test of regular expression
    assert re.match(WallaIE._VALID_URL, "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one") is not None
    assert re.match(WallaIE._VALID_URL, "http://vod.walla.co.il/movie/2642630/") is None

    # Test of video info loader
    # Test of video url extracting
    test_type(WallaIE._real_extract, "url", "str")
    test_value(WallaIE._real_extract, "id", '2642630')

# Generated at 2022-06-24 13:47:38.886363
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()



# Generated at 2022-06-24 13:47:40.235504
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.test_test

# Generated at 2022-06-24 13:47:44.371831
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
        ie_key=None, downloader=None, params=None)

# Generated at 2022-06-24 13:47:45.472170
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None

# Generated at 2022-06-24 13:47:47.425390
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except:
        assert 0, "Fail - WallaIE"
    assert 1

# Generated at 2022-06-24 13:47:50.698896
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert(ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:47:52.459758
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE('')
    assert wie is not None
    assert isinstance(wie, InfoExtractor)

# Generated at 2022-06-24 13:47:55.940412
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Tests may not have FFmpeg installed
    WallaIE()._downloader.params.update({'skip_download': True})
    result = WallaIE().extract(url)
    assert result is not None
    assert len(result) > 0

# Generated at 2022-06-24 13:47:56.809411
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()
    assert(t)

# Generated at 2022-06-24 13:47:59.208642
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == "WallaIE"



# Generated at 2022-06-24 13:48:04.010516
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('NOTREAL', 'NOTREAL')
    assert ie.walla_id == 'NOTREAL'
    assert ie.display_id == 'NOTREAL'
    assert ie.url =='http://vod.walla.co.il/movie/NOTREAL/NOTREAL'

# Generated at 2022-06-24 13:48:04.606144
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-24 13:48:09.143333
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://youtube.com/watch?v=XOEkgYe8j3E')

# Generated at 2022-06-24 13:48:16.376176
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-24 13:48:20.965524
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie._TEST == WallaIE._TEST
    assert ie._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS

# Generated at 2022-06-24 13:48:27.751903
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'
    assert WallaIE.__name__ == 'WallaIE'


if __name__ == "__main__":
    test_WallaIE()

# Generated at 2022-06-24 13:48:31.487380
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Instantiating WallaIE() and adding a test case
    ie.add_test(['url = %s' % ie._TEST['url']], ie._TEST)
    # Using run_tests() to run all the test cases

# Generated at 2022-06-24 13:48:34.547415
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:48:44.173078
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('WallaIE',"http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:48:50.807251
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Takes this video as input
    input = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Creates an instance of WallaIE, and tries to search for information of the video
    ie = WallaIE()
    info = ie.extract(input)
    # Asserts it can find the video url
    assert info['formats'][0]['url'] is not None

# Generated at 2022-06-24 13:48:55.546671
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._download_xml = lambda *args, **kwargs: None
    ie._sort_formats = lambda *args, **kwargs: None
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:48:59.715875
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    eq_(ie.__class__.__name__, 'WallaIE')

# Generated at 2022-06-24 13:49:00.214470
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-24 13:49:01.435523
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:49:05.859843
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()
    test._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    test._VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:49:08.610833
# Unit test for constructor of class WallaIE
def test_WallaIE():
	""" Tests the constructor of WallaIE.
	"""
	# instantiate test class
	walla = WallaIE()
	# test attributes
	for attribute in ["_VALID_URL", "_TEST", "_SUBTITLE_LANGS"]:
		assert hasattr(walla, attribute), "Attribute '{}' not found in WallaIE class".format(attribute)

# Generated at 2022-06-24 13:49:19.394092
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'url error'
    
    # extract function
    assert ie._real_extract(ie.url)['id'] == '2642630', 'id not match'
    assert ie._real_extract(ie.url)['display_id'] == 'one-direction-all-for-one', 'display_id not match'

# Generated at 2022-06-24 13:49:29.784731
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Test that it's an instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)
    # Test that it's the concrete class
    assert type(ie) == WallaIE
    # Test that it has an attribute ie_key
    assert hasattr(ie, 'ie_key')
    # Test that it has an attribute ie_key
    assert ie.ie_key == 'walla:video'
    # Test that it has an attribute _VALID_URL
    assert hasattr(ie, '_VALID_URL')
    # Test that it has an attribute IE_NAME
    assert hasattr(ie, 'IE_NAME')
    # Test that it has an attribute _TEST

# Generated at 2022-06-24 13:49:30.661605
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print(WallaIE())

# Generated at 2022-06-24 13:49:36.377927
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for init method
    # Test whether the constructor not raise exception
    walla = WallaIE()

    # Test whether constructor raise exception if url is wrong
    url_wrong = "wrong url"
    try:
        walla = WallaIE(url_wrong)
    except ValueError as e:
        assert e.message == 'Invalid URL: ' + url_wrong
