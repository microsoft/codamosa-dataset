

# Generated at 2022-06-24 13:39:42.013286
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:39:43.433910
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj.name == 'Walla'

# Generated at 2022-06-24 13:39:46.637220
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("WALLAID","WALLAURL")
    ie.extract("WALLAURL")
    ie.extract("http://www.walla.co.il")

# Generated at 2022-06-24 13:39:55.814467
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract('http://vod.walla.co.il/movie/2669146/***Y***')
    ie.extract('http://vod.walla.co.il/movie/2669146/%D8%A7%D9%84%D8%A7%D8%AA%D8%AE%D8%A7%D8%A8%D8%A7%D8%AA')

# Generated at 2022-06-24 13:39:58.743607
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:03.585803
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:04.165014
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:40:07.212684
# Unit test for constructor of class WallaIE
def test_WallaIE():
    site = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert site.__class__ == WallaIE


# Generated at 2022-06-24 13:40:07.918326
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:40:15.658691
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:20.251572
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class TestClass(WallaIE):
        pass

    test_class = TestClass()
    assert test_class._VALID_URL == WallaIE._VALID_URL
    assert test_class._TEST == WallaIE._TEST
    assert test_class._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS

# Generated at 2022-06-24 13:40:29.445634
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()
    assert test._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:31.829989
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    assert(instance._SUBTITLE_LANGS['עברית']=='heb')
    assert(instance._VALID_URL=='https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:40:36.395083
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert WallaIE().match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is None



# Generated at 2022-06-24 13:40:38.890219
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.ie_key() == 'walla'
    assert WallaIE.ie_key_re() == re.compile(r'walla\.co\.il')

# Generated at 2022-06-24 13:40:39.516262
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:40:42.025118
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Test if constructor of class WallaIE needs a 'url' or not

# Generated at 2022-06-24 13:40:42.606225
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:40:43.577074
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w.suitable

# Generated at 2022-06-24 13:40:45.525576
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-24 13:40:53.404428
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().ie_key() == 'walla'
    assert WallaIE().suitable(WallaIE._VALID_URL) == True
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST['url'] == WallaIE._TEST['url']
    assert WallaIE()._TEST['info_dict'] == WallaIE._TEST['info_dict']
    assert WallaIE()._TEST['params'] == WallaIE._TEST['params']


# Test _real_extract method of class WallaIE

# Generated at 2022-06-24 13:40:55.480126
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:56.582930
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w.SUCCESS

# Generated at 2022-06-24 13:41:00.054259
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wallaIE = WallaIE()

# Generated at 2022-06-24 13:41:02.439151
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.IE_NAME == 'Walla'

# Generated at 2022-06-24 13:41:05.165053
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test WallaIE constructor"""
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:41:11.100988
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # init WallaIE class
    ie = WallaIE()

    # test if init WallaIE class
    if ie is None:
        m = 'init WallaIE class fail'
        print(m)
        assert False, m

    # test if init WallaIE class is ok
    m = 'init WallaIE class ok'
    print(m)
    assert True, m

# Generated at 2022-06-24 13:41:13.014569
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(IE.site == 'Walla')
    assert(IE.IE_CODE == 'walla')

# Generated at 2022-06-24 13:41:19.298279
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:29.724829
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert IE.__module__ == 'walla'
    assert IE.__name__ == 'WallaIE'
    assert IE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:31.622763
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-24 13:41:33.518446
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST == WallaIE._TEST

# Generated at 2022-06-24 13:41:37.708128
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:41:38.664529
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:41:41.330988
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()
    wie.extract("http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl")

# Generated at 2022-06-24 13:41:45.822912
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.video_url == u'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl'
    assert ie.display_id == u'one-direction-all-for-one'


# Generated at 2022-06-24 13:41:48.762170
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global WallaIE
    assert WallaIE
    test = WallaIE(None)

# Generated at 2022-06-24 13:41:54.325632
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # WallaIE is a subclass of InfoExtractor
    instance = WallaIE()
    instance.get_info = lambda url, ie=None, download=True: '"id" = %s' % url
    url = instance.url_result("http://vod.walla.co.il/movie/2642609/")
    assert url == "http://vod.walla.co.il/movie/2642609/"
    assert instance.url_result("http://vod.walla.co.il/movie/2642609/") == "http://vod.walla.co.il/movie/2642609/"
    url = instance.url_result("http://vod.walla.co.il/movie/2642609/")

# Generated at 2022-06-24 13:41:58.612717
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'test')



# Generated at 2022-06-24 13:42:10.325311
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:18.787188
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert re.match(WallaIE._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert re.match(WallaIE._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie = WallaIE();
    ie = WallaIE(WallaIE._VALID_URL);
    ie = WallaIE(WallaIE._TEST['url']);


# Generated at 2022-06-24 13:42:25.481857
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    expected_result = {
        'id': '2642630',
        'display_id': 'one-direction-all-for-one',
        'ext': 'flv',
        'title': 'וואן דיירקשן: ההיסטריה',
        'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        'thumbnail': r're:^https?://.*\.jpg',
        'duration': 3600,
    }

    ie = WallaIE()
    result = ie._real_extract(url)

    assert result == expected_result


# Generated at 2022-06-24 13:42:34.844392
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Make sure that you receive the key 'title', 'id', 'thumbnail', 'formats' and 'subtitles'
	# This test is different so you will fail it
	ie = WallaIE()
	tests = ['http://vod.walla.co.il/movie/2642630/one-direction-all-for-one']
	for t in tests:
		info = ie.extract(t)
		#assert 'id' in info
		#assert 'display_id' in info
		#assert 'title' in info
		assert 'formats' in info
		if ('subtitles' in info):
			assert 'heb' in info['subtitles']

# Generated at 2022-06-24 13:42:44.788111
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert walla.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert walla.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert walla.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True

# Generated at 2022-06-24 13:42:46.362693
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert type(ie) == WallaIE


# Generated at 2022-06-24 13:42:49.216091
# Unit test for constructor of class WallaIE
def test_WallaIE():
    constructor_test(WallaIE, {
        'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
        'only_matching': True,
    })

# Download test for WallaIE

# Generated at 2022-06-24 13:42:58.584188
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    assert ie.suitable(url)

    mobj = re.match(ie._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')

    video_xml = ie._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id)

    item = video_xml.find('./items/item')

    title = xpath_text(item, './title', 'title')

# Generated at 2022-06-24 13:43:00.036723
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

    assert obj._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:43:01.697120
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(test_url)

# Generated at 2022-06-24 13:43:03.670340
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # We try to play a unit test inside the constructor of class WallaIE
    url = "http://vod.walla.co.il/movie/2440861/over-the-edge"
    WallaIE()._real_extract(url)

# Generated at 2022-06-24 13:43:04.753077
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download("some walla url")

# Generated at 2022-06-24 13:43:07.661410
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-24 13:43:12.205236
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL is not None
    assert WallaIE._TEST is not None
    assert WallaIE.__name__ is not None
    assert WallaIE.test() is not None

# Generated at 2022-06-24 13:43:20.403454
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:43:22.226749
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:43:22.937419
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('/')

# Generated at 2022-06-24 13:43:27.152600
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        # In python 2 xrange() and range() are the same
        range_ = xrange
    except NameError:
        range_ = range

    for i in range_(0, 2):
        try:
            _ = WallaIE()
        except TypeError as e:
            if i == 1:
                raise TypeError(e)
            continue

# Generated at 2022-06-24 13:43:28.434522
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.IE_NAME == 'Walla')

# Generated at 2022-06-24 13:43:35.092511
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Verify that the constructor of class WallaIE will only accept a valid url"""

    # Test url: valid url
    valid_url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    WallaIE(valid_url)

    # Test url: invalid url -> raises an exception
    invalid_url = "invalid_url"
    try:
        WallaIE(invalid_url)
    except Exception:
        pass
    else:
        assert False

# Generated at 2022-06-24 13:43:35.635287
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-24 13:43:36.053998
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-24 13:43:38.507758
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:39.061549
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:43:39.600037
# Unit test for constructor of class WallaIE
def test_WallaIE():
	pass

# Generated at 2022-06-24 13:43:49.738470
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:00.634143
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE('http://vod.walla.co.il/one-direction-all-for-one')
	assert ie.VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
	assert ie.TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	assert ie.TEST['info_dict']['id'] == '2642630'
	assert ie.TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
	assert ie.TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:44:08.557945
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(ie._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')

# Generated at 2022-06-24 13:44:09.592348
# Unit test for constructor of class WallaIE
def test_WallaIE():
    cons = WallaIE();

# Generated at 2022-06-24 13:44:10.468452
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.NAME == 'walla'

# Generated at 2022-06-24 13:44:18.788510
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one");
    assert ie._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"

# Generated at 2022-06-24 13:44:19.587547
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:44:22.636284
# Unit test for constructor of class WallaIE
def test_WallaIE():
    result = WallaIE()._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    #print(result)

# Generated at 2022-06-24 13:44:24.394255
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__.__name__ == 'WallaIE'


# Generated at 2022-06-24 13:44:26.898618
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE
    assert WallaIE._VALID_URL
    assert WallaIE._TEST

# Generated at 2022-06-24 13:44:27.890408
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj is not None

# Generated at 2022-06-24 13:44:31.227624
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:38.000186
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_obj = WallaIE()
    assert test_obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert test_obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert test_obj._TEST['info_dict']['id'] == '2642630'
    assert test_obj._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert test_obj._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:44:39.005633
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(WallaIE() ,WallaIE)

# Generated at 2022-06-24 13:44:40.376264
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE();
    print (IE.working)

# Generated at 2022-06-24 13:44:41.914884
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:44:52.233293
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    info = ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Check if basic info is extracted correctly
    assert info['id'] == '2642630'
    assert info['display_id'] == 'one-direction-all-for-one'
    assert info['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:44:53.208853
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    print(x)

# Generated at 2022-06-24 13:44:55.239540
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-24 13:45:03.251139
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:09.773335
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    video = ie._real_extract(url)
    assert video.get('id') == '2642630'
    assert video.get('display_id') == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:45:10.867830
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE()
    info_extractor.suite()

# Generated at 2022-06-24 13:45:17.033511
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:45:17.925882
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'


# Generated at 2022-06-24 13:45:19.965814
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True

# Generated at 2022-06-24 13:45:20.669159
# Unit test for constructor of class WallaIE
def test_WallaIE():
  WallaIE()

# Generated at 2022-06-24 13:45:32.114109
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.__class__ is WallaIE
    assert ie.info_dict == {'display_id': 'one-direction-all-for-one',
                            'id': '2642630',
                            'ext': 'flv',
                            'title': 'וואן דיירקשן: ההיסטריה',
                            'thumbnail': 're:^https?://.*\.jpg',
                            'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
                            'duration': 3600}

# Generated at 2022-06-24 13:45:35.057629
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
test_WallaIE()


# Generated at 2022-06-24 13:45:36.157151
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    print(ie)

# Generated at 2022-06-24 13:45:43.582060
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import Extractor
    from ..utils import compat_urllib_parse_urlparse
    from .common import InfoExtractor
    from .common import _test_valid_extractor
    import unittest


# Generated at 2022-06-24 13:45:44.484785
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:45:46.568861
# Unit test for constructor of class WallaIE
def test_WallaIE():
    extractor = WallaIE(None)
    assert extractor.descriptions == [
        'title', 'description', 'thumbnail', 'duration']

# Generated at 2022-06-24 13:45:48.947238
# Unit test for constructor of class WallaIE
def test_WallaIE():
    aWallaIE = WallaIE(None)

    assert (aWallaIE.subtitle_langs == {
        'עברית': 'heb',
    })

# Generated at 2022-06-24 13:45:57.994078
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import FileIE, TitleSequenceIE
    from ..utils import StrDateIE

    e = WallaIE()
    # Test private vars initialization
    assert e._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:00.379356
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Play a video
    w = WallaIE()
    w._real_extract(w._TEST['url'])

# Generated at 2022-06-24 13:46:03.262983
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie_object = WallaIE(None)
    assert(isinstance(ie_object, WallaIE))


# Generated at 2022-06-24 13:46:13.247179
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL ==  r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:14.615943
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ied = WallaIE()
    assert ied.__class__ == WallaIE

# Generated at 2022-06-24 13:46:19.020408
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.suitable('http://vod.walla.co.il/quick_clip/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:21.115123
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie

# Generated at 2022-06-24 13:46:31.040481
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import unittest
    class WallaIETest(unittest.TestCase):
        def test_url_to_id_returns_valid_id(self):
            ie = WallaIE()
            self.assertEqual(ie._url_to_id('http://vod.walla.co.il/movie/2642630/one-direction'), '2642630')
            self.assertEqual(ie._url_to_id('http://vod.walla.co.il/movie/2642630/one-direction/'), '2642630')
            self.assertEqual(ie._url_to_id('http://vod.walla.co.il/movie/2642630/one-direction/something.html'), '2642630')

# Generated at 2022-06-24 13:46:32.687567
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # instantiate class
    WallaIE(test=True)

# Generated at 2022-06-24 13:46:35.217864
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert 'WallaIE' == w.ie_key()

# Generated at 2022-06-24 13:46:42.114612
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'Walla! video'
    assert ie.IE_DESC == 'Walla! video'
    assert ie.VALID_URL == WallaIE._VALID_URL
    assert ie.BRAND == 'walla'
    assert ie.SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert ie.REAL_EXTRACT == WallaIE._real_extract
    assert ie.TEST == WallaIE._TEST

# Generated at 2022-06-24 13:46:48.486097
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Construction of test video url
    url = 'http://vod.walla.co.il/movie/2893613/%D7%94%D7%9C%D7%9C%D7%99%D7%99%D7%9D-%D7%91%D7%92%D7%A8%D7%A0%D7%98%D7%A0%D7%A7'
    # Construction of WallaIE instance to test
    temp = WallaIE()
    print(temp._real_extract(url))

# Generated at 2022-06-24 13:46:49.275410
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None, None, None)

# Generated at 2022-06-24 13:46:53.177411
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie._TEST == WallaIE._TEST
    assert ie._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert ie.__name__ == WallaIE.__name__
    assert ie.suitable == WallaIE.suitable

# Generated at 2022-06-24 13:46:57.187752
# Unit test for constructor of class WallaIE
def test_WallaIE():
	p = WallaIE()
	assert p._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

test_WallaIE()

# Generated at 2022-06-24 13:46:59.685883
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == 'WallaIE'
    assert len(WallaIE._VALID_URL) > 0
    assert len(WallaIE._TEST) > 0

# Generated at 2022-06-24 13:47:00.887628
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE()

# Generated at 2022-06-24 13:47:01.786297
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # TODO
    assert WallaIE()

# Generated at 2022-06-24 13:47:07.150984
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie._VALID_URL == 'https?://vod.walla.co.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:47:08.002414
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('WallaIE')

# Generated at 2022-06-24 13:47:12.269661
# Unit test for constructor of class WallaIE
def test_WallaIE():
    given_url = 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    extractor = WallaIE()

    # When
    result = extractor.match(given_url)

    # Then
    assert result is not None

# Generated at 2022-06-24 13:47:13.415665
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-24 13:47:16.139383
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("None")
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:47:24.464916
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Dummy function for constructor
    def __init__(self, *args, **kwargs):
        pass
    # Create a dummy class and assign to WallaIE
    temp_WallaIE = type('temp_WallaIE', (WallaIE, object), {'__init__': __init__, '_download_json':lambda self,*args,**kwargs: {}})
    # Create instance of the class
    w = temp_WallaIE()
    # Call function _real_extract()
    result = w._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Check the results

# Generated at 2022-06-24 13:47:26.514324
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:47:31.847780
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(WallaIE._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    WallaIE()(url)


# Generated at 2022-06-24 13:47:33.022707
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("https://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:47:34.064369
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-24 13:47:36.024773
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()
    test.constructor_test(WallaIE)

# Generated at 2022-06-24 13:47:37.689226
# Unit test for constructor of class WallaIE
def test_WallaIE():
	"""constructor of class WallaIE test"""
	WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")


# Generated at 2022-06-24 13:47:40.111325
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:45.690665
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST == WallaIE._TEST
    assert WallaIE()._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert WallaIE()._download_xml == InfoExtractor._download_xml

# Generated at 2022-06-24 13:47:54.627008
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Test present
	assert bool(WallaIE.__name__) == True
	assert bool(WallaIE.__doc__) == True
	assert bool(WallaIE._VALID_URL) == True
	assert bool(WallaIE._TEST) == True
	assert bool(WallaIE._SUBTITLE_LANGS) == True
	assert bool(WallaIE._real_extract) == True
	# Test return type
	assert type(WallaIE._VALID_URL) == re._pattern_type
	assert type(WallaIE._TEST) == dict
	assert type(WallaIE._SUBTITLE_LANGS) == dict
	assert type(WallaIE._real_extract) == instancemethod
	assert type(WallaIE.suitable) == instancemethod

# Generated at 2022-06-24 13:47:59.858194
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(_VALID_URL)
    assert (ie._VALID_URL is _VALID_URL)
    assert (ie._TEST is _TEST)
    assert (ie._SUBTITLE_LANGS is _SUBTITLE_LANGS)
    assert (ie.IE_NAME == 'walla:vod')

# Generated at 2022-06-24 13:48:00.482263
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-24 13:48:10.785658
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE("", "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert w.VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:13.076180
# Unit test for constructor of class WallaIE
def test_WallaIE():

    ie = WallaIE();
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:48:26.088123
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Assure that WallaIE can be instantiated

    ie = WallaIE(None)

    assert ie.NAME == 'walla'
    assert ie.IE_DESC == 'Walla'
    assert ie.VALID_URL == WallaIE._VALID_URL
    assert ie.URL_RETRIEVE_MULTIPLE_NOTES == ''
    assert ie.api == None
    assert ie.cache == None
    assert ie.cmd == None
    assert ie.curl_cache == None
    assert ie.curl_handle == None
    assert ie.curl_progress_bytes == None
    assert ie.curl_progress_hook == None
    assert ie.curl_progress_temp_file == None
    assert ie.curl_opts == None
    assert ie.default_outtmpl == None
   

# Generated at 2022-06-24 13:48:34.763612
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert obj._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"
    assert obj._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert obj._TEST['info_dict']['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert obj._TEST['info_dict']['id'] == "2642630"

# Generated at 2022-06-24 13:48:37.544412
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-24 13:48:39.836839
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # pylint: disable=W0612
    from .test_walla import WallaTestCase
    cases = WallaTestCase.test_walla_constructor(WallaIE, 'WallaIE')
    for k, v in cases.items():
        locals()['test_' + k] = v

# Generated at 2022-06-24 13:48:41.121055
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("test", {'test': 'test'})

# Generated at 2022-06-24 13:48:42.874983
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('')
    assert isinstance(ie, WallaIE)


# Generated at 2022-06-24 13:48:45.719013
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:48:48.762553
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:48:51.128706
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:48:51.937436
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert True

# Generated at 2022-06-24 13:48:56.322882
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = "2642630"
    display_id = "one-direction-all-for-one"

    video = 'http://vod.walla.co.il/movie/' + video_id + '/' + display_id

    # Test for constructor of class WallaIE
    WallaIE(video)

# Generated at 2022-06-24 13:49:01.132374
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # I'm just testing that the WallaIE class is constructed.
    # It creates no unexpected errors.
    ie = WallaIE('http://some.site.com')
    ret = ie.suitable('http://some.site.com')
    assert ret

# Generated at 2022-06-24 13:49:05.114355
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'

    walla = WallaIE({})
    mobj = re.match(walla._VALID_URL, url)
    assert mobj.group('id') == video_id
    assert mobj.group('display_id') == display_id

# Generated at 2022-06-24 13:49:08.930310
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._download_xml(
            'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % '2642630',
            'one-direction-all-for-one')

# Generated at 2022-06-24 13:49:13.329015
# Unit test for constructor of class WallaIE
def test_WallaIE():
    bbb = WallaIE()
    assert bbb._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert bbb._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert bbb._TEST['info_dict']['id'] == '2642630'
    assert bbb._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert bbb._TEST['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'



# Generated at 2022-06-24 13:49:14.125290
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:49:20.037400
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from . import WallaIE
    w = WallaIE()
    w.url = 'https://walla.co.il/item/2642630'
    w.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    pass

# Generated at 2022-06-24 13:49:30.234653
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    assert ie.suitable(video_url)
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla!'
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.get_info_extractor() == 'WallaIE'
    assert ie.get_id(video_url) == '2642630'
    assert ie.get_display_id(video_url) == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:49:40.799482
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test = WallaIE()._real_extract(url)

    assert(test['id'] == 2642630)
    assert(test['display_id'] == 'one-direction-all-for-one')
    assert(test['title'] == 'וואן דיירקשן: ההיסטריה')
    assert(test['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8')
    assert(test['thumbnail'] == 'http://img.walla.co.il/B/4/2/4.2/4.2.4.4.4.jpeg')