

# Generated at 2022-06-24 13:39:41.808815
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('WallaIE', True)
    # Normal url
    assert ie.match_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    result = ie.match_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert result['id'] == '2642630'
    assert result['display_id'] == 'one-direction-all-for-one'
    assert result['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Not a Walla! url

# Generated at 2022-06-24 13:39:51.401301
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Create object for WallaIE test
	x = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
	# Test method _real_extract of class WallaIE
	y = x._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
	# Print test result

# Generated at 2022-06-24 13:39:52.084078
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:39:54.124956
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # check if WallaIE's constructor (__init__) has been implemented properly.
    WallaIE(None)

# Generated at 2022-06-24 13:40:05.168004
# Unit test for constructor of class WallaIE
def test_WallaIE():
    if __name__ == '__main__':
        test_instance = WallaIE()
        assert test_instance._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:08.214303
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .walla_vod import WallaIE
    ie = WallaIE()
    assert(ie.get_id() == 'walla')
    assert(ie.get_valid_urls() == WallaIE._VALID_URL)
    assert(ie.get_test_urls() == WallaIE._TEST)

# Generated at 2022-06-24 13:40:13.180258
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    info = WallaIE()._real_extract(video_url)
    assert '2642630' == info['id']
    assert 'one-direction-all-for-one' == info['display_id']
    assert 'וואן דיירקשן: ההיסטריה' == info['title']
    assert 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one' == info['thumbnail']
    assert 'md5:de9e2512a92442574cdb0913c49bc4d8' == info['description']

# Generated at 2022-06-24 13:40:19.331465
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie.ie_key() in type(ie)._ies
    assert ie.SUITABLE_IE_KEYS == [ie.ie_key()]
    assert ie.SUITABLE_IE_KEYS == [re.compile(ie._VALID_URL)]
    assert ie.test_test()
    assert ie.test_test_parameters()
    assert ie.test_test_missing()

# Generated at 2022-06-24 13:40:21.307800
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'

# Generated at 2022-06-24 13:40:28.360239
# Unit test for constructor of class WallaIE
def test_WallaIE():
    vod_walla_co_il = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    valid_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    ie = WallaIE()
    video_ID = ie._VALID_URL.match(vod_walla_co_il).group('id')
    display_ID = ie._VALID_URL.match(vod_walla_co_il).group('display_id')
    assert ie._VALID_URL == valid_URL
    assert ie._TEST['url'] == vod_walla_co_il

# Generated at 2022-06-24 13:40:29.446383
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE("")
	assert ie != None

# Generated at 2022-06-24 13:40:31.443125
# Unit test for constructor of class WallaIE
def test_WallaIE():
	w = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
	w.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:40:39.500433
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.IE_NAME == 'walla:vod'

    info_dict = ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert info_dict['title'] == 'וואן דיירקשן: ההיסטריה'
    assert info_dict['id'] == '2642630'

# Generated at 2022-06-24 13:40:48.078172
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:52.914528
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    ie._download_xml = lambda *args: None
    ie._sort_formats = lambda *args: None
    ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:53.735545
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert x != None

# Generated at 2022-06-24 13:41:01.696111
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:41:04.032058
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(InfoExtractor())
    assert ie.SUCCESS == WallaIE._TEST['info_dict']['id']

# Generated at 2022-06-24 13:41:07.558150
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE({})._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:12.245528
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    ie.extract(ie._TEST['url']);

# Generated at 2022-06-24 13:41:14.432019
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');

# Generated at 2022-06-24 13:41:20.962984
# Unit test for constructor of class WallaIE
def test_WallaIE():
    inputUrl = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    expectedUrl = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    expectedDisplayId = 'one-direction-all-for-one'
    expectedId = '2642630'
    expectedTitle = 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:41:21.917849
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:41:22.479447
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-24 13:41:26.575084
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_walla_link = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(test_walla_link)
    assert ie


if __name__ == "__main__":
    test_WallaIE()

# Generated at 2022-06-24 13:41:28.412920
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.host == 'vod.walla.co.il'

# Generated at 2022-06-24 13:41:30.486079
# Unit test for constructor of class WallaIE
def test_WallaIE():
    if __name__ == '__main__':
        w = WallaIE()
        w._real_extract(w._TEST['url'])

# Generated at 2022-06-24 13:41:31.193557
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:41:34.755078
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS.get('עברית') == 'heb'
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:41:38.398571
# Unit test for constructor of class WallaIE
def test_WallaIE():
    urlForTesting = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.extract(urlForTesting)

# Generated at 2022-06-24 13:41:41.411182
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:42.098714
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("", "")



# Generated at 2022-06-24 13:41:46.150881
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642159/legenda-o-bogatyre'
    ie_obj = WallaIE()
    ret = ie_obj.suitable(url)
    assert ret == True, 'should return True'

# Generated at 2022-06-24 13:41:53.337391
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:54.149823
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()


# Generated at 2022-06-24 13:41:57.153182
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.download(url)

# Generated at 2022-06-24 13:42:04.369945
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global ie
    ie = WallaIE(0)
    # Test loading of global commons module
    assert(ie.commons_module_path == "fetch_common/common.py")
    assert(ie.commons_module_name == "fetch_common.common")
    # Test constructor
    assert(isinstance(ie, InfoExtractor))

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:42:16.066677
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.__name__ == 'Walla'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    # Test the expected result of _extract_urls
    ie_result = ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Test result of the returned 'formats'
    assert ie_result['formats'][0]['url'] == 'rtmp://wafla.walla.co.il/vod'

# Generated at 2022-06-24 13:42:19.636711
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:42:20.940238
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie == WallaIE()

# Generated at 2022-06-24 13:42:23.573326
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download( "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one" )

# Generated at 2022-06-24 13:42:26.010199
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-24 13:42:29.623511
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.supported_extensions() == ['flv']

# Generated at 2022-06-24 13:42:39.600985
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(ie._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    info = ie.extract(url)
    assert info['id'] == video_id
    assert info['display_id'] == display_id

# Generated at 2022-06-24 13:42:42.373754
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:42:42.942689
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:42:46.207246
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
   # assert ie._netrc_machine == 'walla'

# Generated at 2022-06-24 13:42:48.278265
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Testing constructor of class WallaIE"""
    ie = WallaIE("http://asdf.com")
    assert ie.url == "http://asdf.com"

# Generated at 2022-06-24 13:42:54.136928
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        from wallachat import WallaVod
        from wallachat import WallaVideo
        from wallachat import WallaPlayer
        from wallachat import WallaQuality
        from wallachat import WallaSubtitle
    except ImportError:
        WallaVod = None
    e = WallaIE()
    assert(e._VALID_URL == WallaVod.VALID_URL)
    assert(e._TEST == WallaVideo.TEST)
    assert(e._download_xml == WallaVod.download_xml)
    assert(e._real_extract == WallaVod.real_extract)
    assert(e._SUBTITLE_LANGS == WallaSubtitle.SUBTITLE_LANGS)
    assert(e._find_videos == WallaPlayer.find_videos)

# Generated at 2022-06-24 13:42:55.372650
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-24 13:42:58.241017
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE(None, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    except:
        pass
    return True


# Generated at 2022-06-24 13:42:59.060350
# Unit test for constructor of class WallaIE
def test_WallaIE():
	a=WallaIE()

# Generated at 2022-06-24 13:43:02.687338
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE("www.walla.com/movie/one-direction")
    assert(w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(w.IE_NAME == 'Walla!')

# Generated at 2022-06-24 13:43:03.448243
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:43:08.397425
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # A test URL from Walla's website
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    # Create WallaIE object
    ie = WallaIE(url)
    # Check if the url is the same as the passed url
    assert ie.url ==  url
    # Check if last_data is None
    assert ie.last_data == None
    # Check if the regex passed to constructor
    assert ie.regex == WallaIE._VALID_URL
    # Check if the regexp is compiled
    assert ie.regex.pattern == re.compile(ie.regex.pattern).pattern
    # Check if the class name is Walla
    assert ie.__class__.__name__ == "WallaIE"
    # Check if we have

# Generated at 2022-06-24 13:43:12.951162
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.__class__ == WallaIE

# Generated at 2022-06-24 13:43:15.337351
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    w.GEO_COUNTRIES
    w._VALID_URL
    w.l
    w.lang
    w.ie

# Generated at 2022-06-24 13:43:25.778899
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_id() == 'walla'
    assert ie.SUCCESS == 'SUCCESS'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:27.763968
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie == WallaIE(WallaIE.ie_key())

# Generated at 2022-06-24 13:43:35.087754
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create instance of class WallaIE
    walla = WallaIE()

    # Check url is valid
    assert walla.suitable("http://vod.walla.co.il/movie/2638260/movie-8-before-death") == True
    assert walla.suitable("http://vod.walla.co.il/movie/2638260/movie-8-before-death.html") == True
    assert walla.suitable("http://vod.walla.co.il/movie/2638260/movie-8-before-death.flv") == True
    assert walla.suitable("http://vod.walla.co.il/movie/2638260/movie-8-before-death.mp4") == False

# Generated at 2022-06-24 13:43:39.880092
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.__class__ == WallaIE
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'



# Generated at 2022-06-24 13:43:46.293457
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Arrange
    video_ID = "2642630"
    app_name = "vod"
    WallaIE.suitable(WallaIE.IE_NAME, video_ID, app_name)


if __name__ == '__main__':
    import unittest
    suite = unittest.TestLoader().loadTestsFromTestCase(TestWallaIE)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-24 13:43:47.895386
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_video = WallaIE()
    assert walla_video is not None

# Generated at 2022-06-24 13:43:50.549747
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:51.042626
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:43:52.583725
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()
    q = wie.constructor(None, None)
    assert q is not None

# Generated at 2022-06-24 13:43:54.445507
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructor of class WallaIE
    WallaIE(None)

# Generated at 2022-06-24 13:44:04.964279
# Unit test for constructor of class WallaIE
def test_WallaIE():
    vw = WallaIE(None)
    assert vw._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:13.434541
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"
    assert WallaIE(None)._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-24 13:44:14.542204
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE is not None

# Generated at 2022-06-24 13:44:15.550509
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:44:20.001312
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # This method checks that all required stuff is given to constructor and
    # that it is parsed properly.
    # Note: it is not testing if video is actually loaded or not.
    assert(WallaIE.__name__ == 'WallaIE')
    assert(WallaIE.IE_NAME == 'Walla!') # i.e. http://www.walla.co.il/


# Generated at 2022-06-24 13:44:31.020418
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from unittest import TestCase
    global WallaIE
    class TestWallaIE(TestCase):
        def setUp(self):
            self.wallaie = WallaIE(None)

        def tearDown(self):
            self.wallaie = None

    # test method extract on WallaIE
    # unit tests of the wordpress constructor
    # 1. tests for all basic extract methods
    # 2. tests for all custom extract methods
    # 3. tests for different user types
    # 4. tests for different user roles
    # 5. tests for different post types
    
    # test 1.1 - extract top level element and all its subelements
    def test_extract_top_level_elements(self):
        # 1.1.1 - extract title and save to a dict
        title = wallaie.extract

# Generated at 2022-06-24 13:44:37.888074
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    info = WallaIE()._extract(url)

    assert info['id'] == '2642630'
    assert info['display_id'] == 'one-direction-all-for-one'
    assert info['ext'] == 'flv'
    assert info['title'] == 'וואן דיירקשן: ההיסטריה'
    assert info['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert info['thumbnail'] == r're:^https?://.*\.jpg'
    assert info['duration'] == 3600


# Generated at 2022-06-24 13:44:41.913165
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one').__class__ == WallaIE
    assert WallaIE('http://vod.walla.co.il/').__class__ != WallaIE

# Generated at 2022-06-24 13:44:43.367702
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()

# Generated at 2022-06-24 13:44:50.018293
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert re.match(WallaIE._VALID_URL, url) is not None
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    #assert WallaIE._TEST['params'] == {'skip_download': True}
    #assert WallaIE._TEST['playlist_mincount'] == 3

# Generated at 2022-06-24 13:44:53.052555
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Test constructor
    ie = WallaIE()
    ie.extract(url)

# Generated at 2022-06-24 13:45:02.203821
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL = WallaIE._VALID_URL
    ie._TEST = WallaIE._TEST
    ie._download_xml = WallaIE._download_xml
    ie._real_extract = WallaIE._real_extract
    ie._SUBTITLE_LANGS = WallaIE._SUBTITLE_LANGS
    ie._sort_formats = WallaIE._sort_formats
    ie._extract_subtitles = WallaIE._extract_subtitles
    ie._get_subtitles = WallaIE._get_subtitles
    ie._get_subtitle_lang = WallaIE._get_subtitle_lang
    ie._get_subtitle_path = WallaIE._get_subtitle_path
    ie._get_subtitle

# Generated at 2022-06-24 13:45:06.139064
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    res = ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    assert res['title'] == u'וואן דיירקשן: ההיסטריה';

if ( __name__ == '__main__' ):
    test_WallaIE();

# Generated at 2022-06-24 13:45:08.056344
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-24 13:45:08.682834
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-24 13:45:11.602227
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Check that the constructor can be called
    WallaIE({})

    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:17.503403
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'
   

# Generated at 2022-06-24 13:45:18.680955
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:45:26.166065
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('WallaIE', {})
    assert ie.name == 'WallaIE'
    assert ie.VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:26.996970
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL



# Generated at 2022-06-24 13:45:32.254381
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    instance = WallaIE()
    assert instance._VALID_URL is not None
    assert instance._TEST is not None
    assert test_url == instance._TEST['url']
    assert instance.suitable(test_url) == True

# Generated at 2022-06-24 13:45:37.317888
# Unit test for constructor of class WallaIE
def test_WallaIE():
	from . import expert
	from . import walla
	from . import utils
	assert(isinstance(walla.WallaIE(), expert.InfoExtractor))
	assert(isinstance(walla.WallaIE()._VALID_URL, str))
	assert(isinstance(walla.WallaIE()._TEST, utils.ExtractorTest))
	assert(isinstance(walla.WallaIE()._SUBTITLE_LANGS, dict))

# Generated at 2022-06-24 13:45:41.470898
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.display_id == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:45:43.757422
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:45:46.932750
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:45:48.171131
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE == type(WallaIE()), 'Constructor of class WallaIE should return its own Object. Check its __init__() method'

# Generated at 2022-06-24 13:45:52.186787
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test for constructor with valid URL
    WallaIE(WallaIE._VALID_URL)
    # test for constructor with invalid URL

# Generated at 2022-06-24 13:46:00.033810
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Functorial unit test for class WallaIE
    """
    from urllib import urlencode
    from urlparse import parse_qs
    from xml.etree import ElementTree
    from xml.parsers.expat import ExpatError
    from collections import OrderedDict
    from walla.common import WallaTestCase
    import walla.extractor

    for test in walla.extractor.WallaIE._TEST:
        if test.has_key('params'):
            params = test['params']
        else:
            params = {}

        url = test['url']
        i = walla.extractor.WallaIE(
            *[url],
            *[params]
        )


# Generated at 2022-06-24 13:46:03.442495
# Unit test for constructor of class WallaIE
def test_WallaIE():
	try:
		c = WallaIE()
		assert isinstance(c, WallaIE)
	except:
		print("WallaIE test failed")


# Generated at 2022-06-24 13:46:12.949314
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.js_to_json == None
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:18.971741
# Unit test for constructor of class WallaIE
def test_WallaIE():
	url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
	assert WallaIE._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"
	assert WallaIE._TEST['url'] == url

# Generated at 2022-06-24 13:46:24.470432
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import unittest.mock as mock
    # construct VidibleIE
    test_vidible = WallaIE(mock.MagicMock())
    assert test_vidible
    # create a video ID
    video_id = '12345'
    assert video_id
    # parse a url
    url = 'http://vod.walla.co.il/movie/%s/one-direction-all-for-one' % video_id
    assert url
    # extract video information
    test_vidible.extract(url)

# Generated at 2022-06-24 13:46:31.460377
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:46:42.862370
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.ie_key() == 'Walla'
    assert ie.video_id == '2642630'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:46:45.792898
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test with a valid url
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    WallaIE(url)

# Generated at 2022-06-24 13:46:48.104517
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie


# unit test for validurl of WallaIE

# Generated at 2022-06-24 13:46:49.688425
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class Test(WallaIE):
        def __init__(self):
            super(Test, self).__init__()
    assert Test()

# Generated at 2022-06-24 13:46:51.126185
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla is not None

# Generated at 2022-06-24 13:46:56.865542
# Unit test for constructor of class WallaIE
def test_WallaIE():
	"""Unit test for constructor of class WallaIE"""
	video_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	video_id = '2642630'
	video_display_id = 'one-direction-all-for-one'
	title = 'וואן דיירקשן: ההיסטריה'
	description = 'md5:de9e2512a92442574cdb0913c49bc4d8'
	thumbnail = r're:^https?://.*\.jpg'
	duration = 3600

	# Test for the constructor of class WallaIE
	walla_IE = WallaIE(url=video_url)

	# Test for the method _real_

# Generated at 2022-06-24 13:47:05.491055
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE._SUBTITLE_LANGS == {'עברית': 'heb',})
    assert(WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:47:06.273350
# Unit test for constructor of class WallaIE
def test_WallaIE():
	pass

# Generated at 2022-06-24 13:47:07.380404
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None

# Generated at 2022-06-24 13:47:10.325816
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test loading of a test case vod.walla.co.il
    ie = WallaIE()
    ie.download(ie._TEST['url'])



# Generated at 2022-06-24 13:47:11.529115
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    assert instance._VALID_URL

# Generated at 2022-06-24 13:47:12.756446
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.__class__ is WallaIE

# Generated at 2022-06-24 13:47:19.284093
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    This function will test creating an instance of the class WallaIE.
    """
    # build a test url for this
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    # build an instance of the class WallaIE
    walla_ie = WallaIE(url)
    assert walla_ie.url == url
    assert walla_ie.extractor_key == 'walla'
    assert walla_ie.extractor_type == 'IE'


# Generated at 2022-06-24 13:47:20.801563
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None

# Generated at 2022-06-24 13:47:23.298759
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    instance.extract()
    assert isinstance(instance, WallaIE)

# Generated at 2022-06-24 13:47:25.346788
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Check that WallaIE constructor
    """
    ie = WallaIE()
    assert(ie.url_result.regex.pattern == WallaIE._VALID_URL)


# Generated at 2022-06-24 13:47:27.115069
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .test_imports import ytdl_extract
    ytdl_extract(WallaIE, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:47:38.200787
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:47:40.045091
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()
    assert t.url == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-24 13:47:40.952381
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(InfoExtractor())

# Generated at 2022-06-24 13:47:43.483708
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #print(WallaIE()._VALID_URL)
    #print(WallaIE()._TEST)
    assert True

# Generated at 2022-06-24 13:47:48.904513
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    WallaIE._TEST['skip'] = False
    ie_result = ie.suitable("vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    WallaIE._TEST['skip'] = True
    assert ie_result == True, "URL is not suitable to this IE"

# Generated at 2022-06-24 13:47:50.788239
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE()
    assert walla_ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:47:54.392510
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        instance = WallaIE()
        assert isinstance(instance, WallaIE)
    except AssertionError:
        raise AssertionError("Fail to create instance of class WallaIE")
    else:
        print("Success to create instance of class WallaIE")


# Generated at 2022-06-24 13:48:05.567256
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    assert a._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:06.444638
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:48:14.366213
# Unit test for constructor of class WallaIE
def test_WallaIE():
    init = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert init._VALID_URL == 'http://vod.walla.co.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:16.576632
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-24 13:48:28.038842
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.SINGLE_URL == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.VALID_URL_REGEX == re.compile(r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert ie.SUCCESS == True

# Generated at 2022-06-24 13:48:35.937843
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:42.178432
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create an instance of WallaIE class
    w = WallaIE()
    # Test all fields in expected dict, to test if
    # the structure of expected dict is good or not.
    # This test does not test that the values are good,
    # only the fact that they exist.
    for key in w._TEST.keys():
        value = getattr(w, key, None)
        assert key in w._TEST, "Missing %s" % key
    print("Unit test: WallaIE: Success")

# Generated at 2022-06-24 13:48:44.356776
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:48:55.505545
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # 1. Check that default constructor returns WallaIE.
    assert WallaIE.__name__ == 'WallaIE'

    # 2. Check that class WallaIE has fields
    #    "_VALID_URL", "_TEST", "_SUBTITLE_LANGS" and "_real_extract".
    assert len(WallaIE._VALID_URL) > 0
    assert len(WallaIE._TEST) > 0
    assert len(WallaIE._SUBTITLE_LANGS) > 0
    assert WallaIE._real_extract != None

    # 3. Check that constructor of class WallaIE sets
    #    "_SUBTITLE_LANGS" correctly.
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:48:56.190193
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:48:58.584654
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE()

# Generated at 2022-06-24 13:48:59.495252
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:49:03.151739
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie_w = WallaIE()
    # Test for name of instance ie_w
    assert ie_w.ie_key() == 'Walla'
    # Test for ie_key of instance ie_w
    assert ie_w.ie_key() == 'Walla'

# Generated at 2022-06-24 13:49:12.279901
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:49:15.217858
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert i.extractor_key == 'Walla'

# Generated at 2022-06-24 13:49:21.994352
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:49:22.560129
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE(WallaIE._TEST)

# Generated at 2022-06-24 13:49:26.123937
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    return obj

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:49:27.941179
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');

# Generated at 2022-06-24 13:49:38.922732
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'