

# Generated at 2022-06-24 13:39:37.876427
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.download('2642630')

# Generated at 2022-06-24 13:39:43.177497
# Unit test for constructor of class WallaIE
def test_WallaIE():
	"""Unit test for constructor of class WallaIE."""
	obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
	assert obj is not None
	assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:39:45.923536
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info = WallaIE()
    return info.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:39:47.024352
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(_download_webpage)

# Generated at 2022-06-24 13:39:52.996669
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Initilize instance of class WallaIE
    w = WallaIE()
    print("w: ", w)
    # Call method _real_extract()
    r = w._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    print("r: ", r)

# Generated at 2022-06-24 13:39:53.677060
# Unit test for constructor of class WallaIE
def test_WallaIE():
	pass

# Generated at 2022-06-24 13:39:56.667523
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:39:59.130006
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:00.340856
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    ie.add_info_extractor(WallaIE.ie_key())

# Generated at 2022-06-24 13:40:02.603871
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Very simple function which only instantiates the WallaIE 
    # object and makes sure that it is of that class
    wallaie = WallaIE()
    wallaie.test_urls()
    assert isinstance(wallaie, WallaIE)

# Generated at 2022-06-24 13:40:03.277706
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None

# Generated at 2022-06-24 13:40:04.400811
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.WallaIE.__init__()


# Generated at 2022-06-24 13:40:07.445408
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:40:08.892663
# Unit test for constructor of class WallaIE
def test_WallaIE():
    InfoExtractor("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:40:15.909366
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class WallaIE_test(WallaIE):

        def _download_xml(self, url, display_id):
            return self._download_json(url, display_id)

        def _download_webpage_handle(self, url, note, errnote):
            webpage = url.split('/@@/')
            return webpage[0]

    ie = WallaIE_test()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:18.630814
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable(WallaIE._TEST['url'])
    assert not ie.suitable('http://www.youtube.com')



# Generated at 2022-06-24 13:40:26.741686
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # pylint: disable=protected-access
    obj = WallaIE()
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:40:30.679737
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    try:
        ie._download_xml(url)
    except:
        return False
    return True

# Generated at 2022-06-24 13:40:40.684976
# Unit test for constructor of class WallaIE
def test_WallaIE():
	_TEST = {
	'url':  'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
	'info_dict': {
	       	'id': '2642630',
		'display_id': 'one-direction-all-for-one',
		'ext': 'flv',
		'title': 'וואן דיירקשן: ההיסטריה',
		'description': 'One Direction: The Inside Story.',
		'thumbnail': r're:^https?://.*\.jpg',
		'duration': 3600,
		},
	}
	
	ie = WallaIE(_TEST['url'])
	assert ie._VALID_URL

# Generated at 2022-06-24 13:40:42.072590
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    print(ie._VALID_URL)

# Generated at 2022-06-24 13:40:49.608632
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:51.337833
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # This line is just for convenience during development
    ie.extract(ie._TEST['url'])

# Generated at 2022-06-24 13:40:55.558890
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create an instance of WallaIE
    ie = WallaIE()

    # Check that the regex value of declared variable _VALID_URL is actually compilable
    try:
        re.compile(ie._VALID_URL)
    except:
        # If it does not compile, then throw an error
        raise Exception('WallaIE: declared _VALID_URL is not a compilable regular expression!')

# Generated at 2022-06-24 13:40:59.335232
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-24 13:41:10.756087
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-24 13:41:12.299038
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:41:14.114995
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'


# Generated at 2022-06-24 13:41:15.743167
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)


# Generated at 2022-06-24 13:41:18.902136
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert (obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:41:23.097279
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.download("http://vod.walla.co.il/news/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:41:32.749333
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import os
    import unittest

    class MockWallaIE(WallaIE):
        def _download_xml(self, url, video_id):
            return self._parse_xml(self._search_regex(
                r'(<item[^>]+</item>)',
                self._download_webpage(self._VALID_URL, None),
                'walla_video'),
                video_id)

    mockWallaIE = MockWallaIE(unittest.TestCase)
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    info = mockWallaIE.url_result(url)
    ie_result = info.result
    for file in ie_result.get('formats'):
        io = None

# Generated at 2022-06-24 13:41:40.439498
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()
	assert hasattr(ie,"url") == True
	assert hasattr(ie,"_VALID_URL") == True
	assert hasattr(ie,"_TEST") == True
	assert hasattr(ie,"_SUBTITLE_LANGS") == True
	assert hasattr(ie,"_download_webpage") == True
	assert hasattr(ie,"_download_xml") == True
	assert hasattr(ie,"_real_extract") == True
	assert hasattr(ie,"_real_extract") == True
	assert hasattr(ie,"_real_extract") == True


# Generated at 2022-06-24 13:41:41.447570
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-24 13:41:42.596990
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert True == isinstance(WallaIE(), InfoExtractor)

# Generated at 2022-06-24 13:41:49.047321
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
	assert '<extractors.walla.WallaIE object at' in repr(ie)
	assert ie._VALID_URL == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
	assert ie._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"


# Generated at 2022-06-24 13:41:50.133771
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-24 13:41:52.438833
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:41:54.671279
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE()

# Generated at 2022-06-24 13:41:55.702874
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()

# Generated at 2022-06-24 13:42:07.597225
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Tests for constructor of class WallaIE
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:08.802253
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert isinstance(x, WallaIE)

# Generated at 2022-06-24 13:42:10.820801
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert isinstance(ie, WallaIE)


# Generated at 2022-06-24 13:42:15.651460
# Unit test for constructor of class WallaIE
def test_WallaIE():
    elem = WallaIE('this is the base constructor')
    assert elem.ie_key() == 'Walla'
    assert elem.ie_codec() == 'video'
    assert elem.ie_extract() == 'http://vod.walla.co.il/'

# Generated at 2022-06-24 13:42:23.508799
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = type('test', (object,), {
        '_extract_id': lambda self,url: 'abc',
        '_download_xml': lambda self,url,video_id: None,
        '_SUBTITLE_LANGS': {'עברית': 'heb'}
        })
    result = WallaIE(test, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._real_extract(
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert result['id'] == 'abc'

# Generated at 2022-06-24 13:42:25.010807
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # this function is not used but it is here to be tested
    w = WallaIE('list')


# Generated at 2022-06-24 13:42:27.225605
# Unit test for constructor of class WallaIE
def test_WallaIE():
    downloads = WallaIE()
    assert downloads.extractor_key == 'Walla'
    assert downloads.IE_NAME == 'Walla'

# Generated at 2022-06-24 13:42:29.864974
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TEST')

# Generated at 2022-06-24 13:42:37.610081
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Test for _VALID_URL
    assert re.match(WallaIE._VALID_URL, ie.url)
    # Test for _SUBTITLE_LANGS
    assert 'עברית' in WallaIE._SUBTITLE_LANGS
    # Test for _download_xml
    assert re.match(ie._download_xml(ie.url, ie.display_id),'<items><item>.*</item>.*</items>')

# Generated at 2022-06-24 13:42:40.048690
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one");
    assert ie != None

# Generated at 2022-06-24 13:42:49.048619
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('someurl', 'somequery')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:42:50.777145
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:42:55.284857
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj.suitable('http://example.com/foobar') == False
    assert obj.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True

# Generated at 2022-06-24 13:43:01.901231
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.categories = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie.urls = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie._real_extract(url)

# Generated at 2022-06-24 13:43:11.170847
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:43:12.157786
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:43:20.898505
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test url, url with http and url wrong
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:43:29.807030
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.extract(url)
    assert ie.urls[0] == 'rtmp://wafla.walla.co.il/vod'
    assert ie.ids[0] == '2642630'
    assert ie.titles[0] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:43:31.129403
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE, "WallaIE class is not defined"

# Generated at 2022-06-24 13:43:32.632460
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE(None)

# Generated at 2022-06-24 13:43:33.170860
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:43:34.065562
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None

# Generated at 2022-06-24 13:43:42.929092
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:43:45.280396
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', {})

# Generated at 2022-06-24 13:43:53.532176
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:57.939425
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:44:00.179844
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:44:02.953835
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.url_re == WallaIE._VALID_URL
    assert not ie._TEST.has_key('subtitles')

# Generated at 2022-06-24 13:44:05.539308
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:44:06.370489
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # assert 1 == 2
    assert 1 == 1

# Generated at 2022-06-24 13:44:07.391707
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:44:09.110751
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    except:
        # TODO: Handle exception
        assert False

# Generated at 2022-06-24 13:44:11.119667
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Need to setup website
    return
    IE = WallaIE()
    # Success case, test with a video in the website
    IE.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:44:14.072082
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("rtsp://wafla.walla.co.il/vod/mp4:2014/08/12/2651540/2651540_sd_mp4_800k_20140812_1622554332.mp4")

# Generated at 2022-06-24 13:44:16.781509
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE._VALID_URL = r'https?://(?P<url>.+)'
    WallaIE(WallaIE.ie_key())
    WallaIE._VALID_URL = WallaIE._TEST['url']

# Generated at 2022-06-24 13:44:17.952789
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:44:20.383678
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:44:22.355139
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:44:23.688902
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    assert "WallaIE" in repr(instance)

# Generated at 2022-06-24 13:44:33.842916
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()
    assert test._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:37.236349
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:44:39.346649
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj.get_url_regex() == WallaIE._VALID_URL

# Generated at 2022-06-24 13:44:45.120731
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert WallaIE.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not WallaIE.suitable('http://vod.walla.co.il/search?a=b')

test = WallaIE()


# Generated at 2022-06-24 13:44:48.003281
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global ie
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    info = ie._real_extract(ie.url)

# Generated at 2022-06-24 13:44:52.277644
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert i.url == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"


# Generated at 2022-06-24 13:44:54.711833
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print(WallaIE())

# Generated at 2022-06-24 13:45:02.737553
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Extract information from url string
    url_string = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    _, ie_key = ie_key_for_url(url_string)
    assert ie_key == 'Walla'

    wallaIE = WallaIE(url_string)
    assert wallaIE.url == url_string

    # Extract information from video id
    video_id = 2642630
    display_id = "one-direction-all-for-one"
    url_string = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

    wallaIE = WallaIE(url_string, video_id=video_id, display_id=display_id)


# Generated at 2022-06-24 13:45:11.091005
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.IE_NAME == "walla")
    assert(ie.IE_DESC == "Walla VOD")
    assert(ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    m = re.match(ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(m.group('id') == '2642630')
    assert(m.group('display_id') == 'one-direction-all-for-one')

# Generated at 2022-06-24 13:45:17.185895
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test instantiation of class WallaIE
    # testing the basic functionality of WallaIE, without downloading the file from the internet
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # testing the dictionary returned by their method _real_extract
    # ie._real_extract is not implemented yet
    ie_info = ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # testing some of the dictionary's keys
    assert ie_info['id'] == '2642630'
    assert ie_info['display_id'] == 'one-direction-all-for-one'
    assert ie_info['ext'] == 'flv'

# Generated at 2022-06-24 13:45:25.717379
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    ie = WallaIE(None)
    assert ie.SUCCESS == 'SUCCESS'
    assert ie.FAILED == 'FAILED'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:27.165365
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert (WallaIE == WallaIE().__class__)

# Generated at 2022-06-24 13:45:36.864540
# Unit test for constructor of class WallaIE
def test_WallaIE():
    my_dict = {
        'id': '2642630',
        'display_id': 'one-direction-all-for-one',
        'ext': 'flv',
        'title': 'וואן דיירקשן: ההיסטריה',
        'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        'thumbnail': r're:^https?://.*\.jpg',
        'duration': 3600,
    }
    my_url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE()
    ie._real_extract(my_url)
    # Checks that the returned value is

# Generated at 2022-06-24 13:45:41.970603
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    w.urls = ['http://vod.walla.co.il/movie/2642630/one-direction-all-for-one']
    w._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:45:44.557337
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Init an empty object of WallaIE
    walla_ie = WallaIE()

    # Assert that the url is correct
    assert walla_ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

    # Assert that the subtitle languages is correct
    assert walla_ie._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-24 13:45:45.508310
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None

# Generated at 2022-06-24 13:45:46.603854
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _WallaIE = WallaIE().ie_key()
    assert _WallaIE == 'Walla'

# Generated at 2022-06-24 13:45:47.920284
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_WallaIE = WallaIE()._real_extract(WallaIE._TEST['url'])



# Generated at 2022-06-24 13:45:48.898634
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)

# Generated at 2022-06-24 13:45:51.757545
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:45:59.825606
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj.VALID_URL == 'http://vod.walla.co.il/[^/]+/(\\d+)/(.+)'

# Generated at 2022-06-24 13:46:00.868629
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)


# Generated at 2022-06-24 13:46:10.816118
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'
   

# Generated at 2022-06-24 13:46:16.057946
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(WallaIE(False), InfoExtractor)
    WallaIE(False)._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    WallaIE(False)._real_extract('http://vod.walla.co.il/movie/2644390/red-band-society-life-is-what-you-make-it')
    WallaIE(False)._real_extract('http://vod.walla.co.il/movie/2644402/red-band-society-lifes-a-bitch')

# Generated at 2022-06-24 13:46:20.538351
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #Test WallaIE constructor
    walla_ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert walla_ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:46:25.370288
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:46:27.581573
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:30.746982
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE, to test if it does not raise any exceptions
    """
    try:
        obj = WallaIE()
        return
    except:
        assert False, "Failed to instantiate WallaIE!"


# Generated at 2022-06-24 13:46:37.530761
# Unit test for constructor of class WallaIE
def test_WallaIE():
    videoIE = WallaIE("Walla", "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert videoIE.ie_key() == "Walla"
    assert videoIE.ie_url() == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-24 13:46:40.438970
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:42.473577
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE();
    assert(w._SUBTITLE_LANGS["עברית"] == "heb")

# Generated at 2022-06-24 13:46:45.322423
# Unit test for constructor of class WallaIE
def test_WallaIE():    
    ie = WallaIE()
    assert ie.url == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    ie = WallaIE(None)
    assert ie.url == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:49.050865
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl' in str(wallaIE)

# Generated at 2022-06-24 13:46:49.855357
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()

# Generated at 2022-06-24 13:46:50.977097
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()

# Generated at 2022-06-24 13:46:51.657509
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:47:01.787464
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:04.520842
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert str(ie) == '<WallaIE: <url_regex=%s>>' % ie._VALID_URL

# Generated at 2022-06-24 13:47:05.385449
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-24 13:47:06.787711
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.get_class() == WallaIE

# Generated at 2022-06-24 13:47:09.443639
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("Walla", "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:47:14.011813
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('test', {}, False)

    m = ie._VALID_URL
    ie._match_id(m)
    ie._search_regex(m, 'test', default='default')

    ie = WallaIE('test', {}, False)
    ie._download_webpage('test', 'test.id')
    ie._download_xml('test', 'test.id')

# Generated at 2022-06-24 13:47:22.829534
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:26.513803
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.name == 'Walla')
    assert(ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(ie._SUBTITLE_LANGS == {
        'עברית': 'heb',
    })

# Generated at 2022-06-24 13:47:27.360579
# Unit test for constructor of class WallaIE
def test_WallaIE():
	x = WallaIE()

# Generated at 2022-06-24 13:47:38.459110
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:47:40.550115
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:47:42.749273
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST == WallaIE._TEST

# Generated at 2022-06-24 13:47:44.829933
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:47:54.025754
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:54.834603
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:47:55.330984
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:47:56.068732
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:48:07.503104
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:10.633290
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie._VALID_URL
    ie.test(url)

# Generated at 2022-06-24 13:48:11.438327
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ins = WallaIE()
    assert ins

# Generated at 2022-06-24 13:48:24.046572
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Unit test for constructor of class WallaIE
    # The format the WallaIE returns the video
    # WallaIE is a subclass of InfoExtractor in YouTube-DL
    # The constructor of Info Extracor can get the parameters:
    # youtube_id, youtube_url, video_url and video_id
    # WallaIE can initialize with only one parameter: url (str)
    walla_IE = WallaIE()
    # Returns a boolean value:
    # True for url with the Walla's pattern and
    # False for url without the Walla's pattern
    walla_IE.is_suitable = walla_IE.suitable(walla_IE._VALID_URL)
    # Returns the md5 hash of the string
    walla_IE.ie_key = walla_IE.ie_key()
    # D

# Generated at 2022-06-24 13:48:29.479619
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    m = re.match(WallaIE._VALID_URL, url)
    assert m, 'url doesnt match'
    # assert m.group('id') == '2642630'
    # assert m.group('display_id') == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:48:33.233134
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie._download_xml = lambda *a: a[1]
    ie._sort_formats = lambda *a: a[0]
    ie._real_extract(url)

# Generated at 2022-06-24 13:48:36.117835
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # default constructor of class WallaIE
    ie = WallaIE()
    assert ie.IE_NAME == 'walla:video'

# Generated at 2022-06-24 13:48:38.179995
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL is WallaIE._VALID_URL
    assert ie._TEST is WallaIE._TEST
    assert ie._SUBTITLE_LANGS is WallaIE._SUBTITLE_LANGS

# Generated at 2022-06-24 13:48:39.869321
# Unit test for constructor of class WallaIE
def test_WallaIE():

    walla = WallaIE()

    assert walla



# Generated at 2022-06-24 13:48:40.808261
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-24 13:48:43.203199
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(InfoExtractor(None))._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:48:55.254494
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    ######################################################################
    # Successful case
    #
    ######################################################################
    # Check of different URLs
    # 1. URL of video with Hebrew subtitles
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test_display_id = 'one-direction-all-for-one'
    test_video_id = '2642630'

# Generated at 2022-06-24 13:48:55.673293
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:48:56.349496
# Unit test for constructor of class WallaIE
def test_WallaIE():
	return WallaIE()

# Generated at 2022-06-24 13:49:01.216868
# Unit test for constructor of class WallaIE
def test_WallaIE():
	w = WallaIE()
	def test():
		print("worked")
		return
	w.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:49:05.203480
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}


# Generated at 2022-06-24 13:49:11.667014
# Unit test for constructor of class WallaIE
def test_WallaIE():
	walla_ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
	assert walla_ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
	assert walla_ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:49:12.759966
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE
    w = WallaIE()
    assert w

# Generated at 2022-06-24 13:49:15.850315
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    except:
        return False
    return True

# Generated at 2022-06-24 13:49:23.168371
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    video = WallaIE(None)._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id)
    assert video.find('./items/item').attrib['id'] == video_id

# Generated at 2022-06-24 13:49:27.426691
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE('WallaIE', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 13:49:38.183485
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'