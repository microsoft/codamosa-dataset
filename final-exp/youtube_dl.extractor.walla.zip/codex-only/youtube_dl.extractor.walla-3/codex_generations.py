

# Generated at 2022-06-24 13:39:35.990420
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.SUCCESS == 200
    assert ie.FAILED == 400

# Generated at 2022-06-24 13:39:42.190213
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info = WallaIE()._real_extract(WallaIE._TEST['url'])
    assert info['id'] == WallaIE._TEST['info_dict']['id']
    assert info['display_id'] == WallaIE._TEST['info_dict']['display_id']
    assert info['title'] == WallaIE._TEST['info_dict']['title']
    assert info['description'] == WallaIE._TEST['info_dict']['description']
    assert info['duration'] == WallaIE._TEST['info_dict']['duration']

# Generated at 2022-06-24 13:39:47.557642
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://www.walla.co.il')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    #assert ie._TEST['id'] == '2642630'
test_WallaIE()

# Generated at 2022-06-24 13:39:56.266310
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Instantiate WallaIE
    wallaIE = WallaIE(None)

    # Check _VALID_URL of WallaIE
    assert wallaIE._VALID_URL == new_WallaIE._VALID_URL

    # Check _SUBTITLE_LANGS of WallaIE
    assert wallaIE._SUBTITLE_LANGS == new_WallaIE._SUBTITLE_LANGS

    # Check _TEST of WallaIE
    assert wallaIE._TEST == new_WallaIE._TEST

    return


# Generated at 2022-06-24 13:39:57.405905
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_WallaIE = WallaIE()

# Generated at 2022-06-24 13:39:58.256299
# Unit test for constructor of class WallaIE
def test_WallaIE():
    whe = WallaIE(None)
    assert isinstance(whe, WallaIE)

# Generated at 2022-06-24 13:40:00.589028
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().ie_key() == 'walla'
    ie = WallaIE(WallaIE.ie_key())
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:40:05.929121
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('WallaIE', WallaIE._VALID_URL)
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == WallaIE._TEST['info_dict']
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == WallaIE._TEST['info_dict']
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == WallaIE._TEST['info_dict']

# Generated at 2022-06-24 13:40:06.422209
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:40:08.098461
# Unit test for constructor of class WallaIE
def test_WallaIE():
    result = WallaIE()
    assert result.ie_key() == "WallaIE"

if __name__ == "__main__":
    test_WallaIE()

# Generated at 2022-06-24 13:40:13.820700
# Unit test for constructor of class WallaIE
def test_WallaIE():
#   Test case #1
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla_ie = WallaIE(url)
    assert walla_ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'
    assert walla_ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:40:23.343826
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # test extracting media id
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._match_id('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == '2642630'
    # test extracting display id
    assert ie._match_id('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', False) == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:40:24.711278
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.SUCCESS

# Generated at 2022-06-24 13:40:34.112414
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'WallaIE')._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:40:36.294201
# Unit test for constructor of class WallaIE
def test_WallaIE():
    '''
    test for constructor of class WallaIE
    '''
    WallaIE(InfoExtractor)
    

# Generated at 2022-06-24 13:40:45.720962
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'
    assert ie._

# Generated at 2022-06-24 13:40:55.874540
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._download_xml(ie._VALID_URL, ie._TEST['display_id'])
    assert ie._download_xml(ie._VALID_URL, ie._TEST['info_dict'])
    assert ie._download_xml(ie._VALID_URL, ie._TEST['params'])
    assert ie._download_xml(ie._VALID_URL, ie._TEST['url'])

# Generated at 2022-06-24 13:41:06.342687
# Unit test for constructor of class WallaIE
def test_WallaIE():
    input = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE()._TEST['extra'] == 'skip_download'
    assert WallaIE()._TEST['url'] == input
    assert WallaIE()._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert WallaIE()._TEST['info_dict']['duration'] == 3600


# Generated at 2022-06-24 13:41:07.051618
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:41:17.334700
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # testing URL: http://vod.walla.co.il/movie/2642630/one-direction-all-for-one
    assert(ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(ie.IE_NAME == 'walla')
    assert(list(ie._SUBTITLE_LANGS.keys()) == ['עברית'])
    assert(list(ie._SUBTITLE_LANGS.values()) == ['heb'])
    assert(ie._TEST.get("url") == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")


# Generated at 2022-06-24 13:41:19.776807
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-24 13:41:21.597111
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.ie_key() == 'walla'

# Generated at 2022-06-24 13:41:24.887475
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:41:34.075316
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie_obj = WallaIE()
    url_to_check = ie_obj._TEST['url']
    info_to_check = ie_obj._TEST['info_dict']
    extracted_info = ie_obj._real_extract(url_to_check)

    assert extracted_info['info_dict']['id'] == info_to_check['id']
    assert extracted_info['info_dict']['display_id'] == info_to_check['display_id']
    assert extracted_info['info_dict']['ext'] == info_to_check['ext']
    assert extracted_info['info_dict']['title'] == info_to_check['title']
    assert extracted_info['info_dict']['description'] == info_to_check['description']

# Generated at 2022-06-24 13:41:43.532517
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:49.434627
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("Starting to test WallaIE...")

    a = WallaIE()

    # Following are the test cases:
    # 1. Test case of empty URL
    assert a._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

    # Following are the test cases:
    # 1. Test case of empty URL
    assert a.suitable('') is False

    # 2. Test case of valid URL
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert a.suitable(url) is True

    print("Finishing testing WallaIE...")

# Generated at 2022-06-24 13:41:50.049828
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:41:58.855345
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.suitable('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert WallaIE.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert WallaIE.suitable('https://vod.walla.co.il/item/2642630/one-direction-all-for-one')
    assert WallaIE.suitable('http://vod.walla.co.il/item/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:42:00.251060
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert WallaIE._VALID_URL == ie._VALID_URL

# Generated at 2022-06-24 13:42:09.121011
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE(VideoInfoExtractor())
    obj.suitable('http://vod.walla.co.il/movie/2642630/one-direciton-all-for-one')
    assert obj.IE_NAME == 'walla'
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:12.816219
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    a._real_extract(url)

# Generated at 2022-06-24 13:42:19.707522
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:20.846578
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Simply runs constructor of class WallaIE
    WallaIE()


# Generated at 2022-06-24 13:42:31.021522
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        import HTMLParser, urllib
    except ImportError:
        import html.parser as HTMLParser
        import urllib.request, urllib.parse, urllib.error as urllib
    global HTMLParser
    videoId = '2614817'
    videoTitle = 'מונה מדי - דמות השליח'
    videoTitleExpected = 'מונה מדי - דמות השליח'
    videoDescription = 'md5:c22b967ac1cffa2e2dbf3e3ab829f0f6'

# Generated at 2022-06-24 13:42:32.327360
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Please add here test for Page does not exist
    assert WallaIE()

# Generated at 2022-06-24 13:42:33.302127
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-24 13:42:39.190729
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # constructor with valid url
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(test_url)
    # constructor with bad url
    test_url = 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(test_url)
    pass

# Generated at 2022-06-24 13:42:40.809114
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Test constructor
    obj = WallaIE()

# Generated at 2022-06-24 13:42:41.628800
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-24 13:42:43.192288
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None).IE_NAME == "walla"

# Generated at 2022-06-24 13:42:51.083536
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()
    assert t._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert t._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-24 13:42:52.147569
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:42:57.085130
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'



# Generated at 2022-06-24 13:42:57.568135
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:42:59.968298
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # a WallaIE object has been created, which has IE name as an attribute
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    
    

# Generated at 2022-06-24 13:43:01.105408
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create instance of WallaIE without fail
    ie = WallaIE()

# Generated at 2022-06-24 13:43:06.645933
# Unit test for constructor of class WallaIE
def test_WallaIE():
	robot = WallaIE()
	assert robot.IE_NAME == WallaIE.ie_key()
	assert robot.test()
	assert robot.name() != ''
	assert robot.url_regex() != ''
	assert robot.working() is True
	assert robot.valid_url("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one") is True
	assert robot.valid_url("http://vod.walla.co.il/movie/2642630/") is False
	assert robot.valid_url("http://www.youtube.com/watch?v=BaW_jenozKc") is False
	assert robot.valid_url("file:///C:/Users/adir/.vim/bundle/YouCompleteMe/test/test.cpp") is False


# Generated at 2022-06-24 13:43:07.390794
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()

# Generated at 2022-06-24 13:43:18.390885
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._TEST
    assert test['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert test['id'] == '2642630'
    assert test['display_id'] == 'one-direction-all-for-one'
    assert test['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert test['thumbnail'] == r're:^https?://.*\.jpg'
    assert test['duration'] == 3600
    assert test['params'] == {'skip_download': True}

# Generated at 2022-06-24 13:43:19.993311
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert(w)



# Generated at 2022-06-24 13:43:23.589379
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    assert("_VALID_URL" in instance.__dict__)
    assert("_TEST" in instance.__dict__)
    assert("_SUBTITLE_LANGS" in instance.__dict__)
    assert("_real_extract" in instance.__dict__)


# Generated at 2022-06-24 13:43:25.341577
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()
    instance = IE(None)
    assert isinstance(instance, WallaIE)

# Generated at 2022-06-24 13:43:31.554116
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Test the case '_VALID_URL' is found in URL 
    filtered_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie._match_id(filtered_url)
    # Test the case '_VALID_URL' is not found in URL
    filtered_url = 'https://www.youtube.com/watch?v=t1Ek5v5XERQ'
    assert ie._match_id(filtered_url) is None


# Generated at 2022-06-24 13:43:41.369445
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    url = 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl'
    video = WallaIE()._download_xml(url, '2642630')
    # check attributes of video
    assert video.attrib['type'] == 'news'
    assert video.attrib['item_type'] == 'movie'
    assert video.attrib['name'] == '02642630'
    assert video.attrib['id'] == '2642630'
    assert video.attrib['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:43:49.473056
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Basic test for constructor of class WallaIE
    """

    # noinspection PyTypeChecker
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    res = ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert res[u'id'] == '2642630'
    assert res[u'display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:43:56.476378
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test default constructor:
    ie = WallaIE()
    assert isinstance(ie, WallaIE)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:06.374839
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _WALLA_URL = WallaIE._VALID_URL
    constr = WallaIE(InfoExtractor())
    mobj = re.match(_WALLA_URL, 'http://www.pornhub.com/video/7612')
    assert mobj is None
    mobj = re.match(_WALLA_URL, 'http://vod.walla.co.il/?meta=1&id=2642630')
    assert mobj is None
    mobj = re.match(_WALLA_URL, 'http://vod.walla.co.il/movie/2642630/milon-ha-argaman')
    assert mobj.group('display_id') == 'milon-ha-argaman'
    assert mobj.group('id') == '2642630'

# Generated at 2022-06-24 13:44:14.978093
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    f = ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert f['id'] == '2642630'
    assert f['title'] == u'וואן דיירקשן: ההיסטריה'
    assert f['_type'] == 'url_transparent'
    assert f['display_id'] == 'one-direction-all-for-one'
    assert f['duration'] == 3600
    assert f['thumbnail'] == 'http://img.waflacdn.com/4/4/4/2642630_300_200.jpg'

# Generated at 2022-06-24 13:44:17.253296
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:23.182468
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w.name == 'walla'
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:28.063866
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create an instance of WallaIE 
    instance = WallaIE()
    # Check if WallaIE's _VALID_URL matches this URL
    assert instance._match_id('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == '2642630'

# Generated at 2022-06-24 13:44:29.666777
# Unit test for constructor of class WallaIE
def test_WallaIE():
    e = WallaIE('foo')
    assert isinstance(e, WallaIE)

# Generated at 2022-06-24 13:44:30.251051
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:44:37.448387
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from ydl_info_extractor.extractor.walla import WallaIE
    walla = WallaIE()

# Generated at 2022-06-24 13:44:39.140628
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global w
    w = WallaIE()


# Generated at 2022-06-24 13:44:40.688338
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # assert isinstance(WallaIE, InfoExtractor)
    WallaIE()

# Generated at 2022-06-24 13:44:49.153849
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('WallaIE')
    config = ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert config['id'] == '2642630'
    assert config['display_id'] == 'one-direction-all-for-one'
    assert config['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:44:58.180911
# Unit test for constructor of class WallaIE
def test_WallaIE():    
    # Testing WallaIE
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    
    info_dict = {
        'id': '2642630',
        'display_id': 'one-direction-all-for-one',
        'ext': 'flv',
        'title': 'וואן דיירקשן: ההיסטריה',
        'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        'thumbnail': r're:^https?://.*\.jpg',
        'duration': 3600,
    }
    

# Generated at 2022-06-24 13:44:58.692323
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-24 13:45:07.952854
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("www.walla.co.il/")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:10.045698
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test constructor of WallaIE
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:45:11.164771
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_WallaIE = WallaIE()
    print(test_WallaIE)

# Generated at 2022-06-24 13:45:13.023498
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'walla.co.il'


# Generated at 2022-06-24 13:45:23.129791
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import json
    import unittest
    from units import EntriesTestBase, EntriesListTestBase
    from units import EntryTestBase

    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

    class WallaListTest(EntriesListTestBase):
        _w = WallaIE(url)

        def test_get_entries(self):
            entries = self._w.get_entries(url)
            self.assertIsInstance(entries, list)

        def test_get_entries_count_and_name(self):
            entries = self._w.get_entries(url)
            self.assertEqual(entries[0]._id, 2642630)

# Generated at 2022-06-24 13:45:33.315305
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla_ie = WallaIE(url)
    assert walla_ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert walla_ie.video_id == video_id
    assert walla_ie.display_id == display_id
    assert walla_ie.url == url

# Generated at 2022-06-24 13:45:40.952620
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Initialize the class from a URL
    wallaIE = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Confirm that it was initialized to the right URL
    print("URL: %s" % wallaIE._url)
    assert wallaIE._url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    print("REAL_URL: %s" % wallaIE._real_url)
    assert wallaIE._real_url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:45:50.936842
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == (r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/'
                             r'(?P<display_id>.+)')
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:45:55.478503
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._real_extract(
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie._real_extract(
        'http://vod.walla.co.il/movie/2642867/one-direction-all-for-one/')

# Generated at 2022-06-24 13:45:56.888669
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._SUBTITLE_LANGS == { 'עברית': 'heb' }

# Generated at 2022-06-24 13:46:07.480712
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert re.match(r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/.+', obj._VALID_URL)
    assert obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert obj._TEST['info_dict']['id'] == '2642630'
    assert obj._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert obj._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:46:15.532269
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        from .extractors import WallaIE
    except ImportError:
        return

    import sys
    import unittest
    import re
    if sys.hexversion < 0x02070000:
        import unittest2 as unittest
    else:
        import unittest

    class WallaIETestCases(unittest.TestCase):
        def setUp(self):
            self.wallaIE = WallaIE()

        def assertIsNotNone(self, obj, msg=None):
            """
            Just like self.assertTrue(obj is not None), but with a nicer
            default message.
            """
            if obj is None:
                standardMsg = 'unexpectedly None'
                self.fail(self._formatMessage(msg, standardMsg))

        # @unittest.skip('

# Generated at 2022-06-24 13:46:16.422313
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:46:24.798574
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    res = ie.extract()

# Generated at 2022-06-24 13:46:31.615601
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:43.346700
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:43.845721
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:46:45.169700
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(str(ie) == 'Walla')

# Generated at 2022-06-24 13:46:51.039848
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from ..compat import fake_httpretty_response

    # We do not have any tests for this extractor.
    # Because of this we will test the creation of the object
    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            info = self._extract_info()
            self._assert_extracted_info(info)

        def _extract_info(self):
            return NotImplementedError
        def _assert_extracted_info(self, info):
            return NotImplementedError

    # Create the object
    test_obj = FakeInfoExtractor()

    # This is what the original method (without any changes) will return

# Generated at 2022-06-24 13:46:53.104275
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:54.433258
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:46:56.038219
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:47:04.976665
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:06.070031
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-24 13:47:15.590642
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL ==  r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:47:18.355291
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(ie,WallaIE)

# Generated at 2022-06-24 13:47:25.940641
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE()._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE()._TEST['info_dict']['id'] == '2642630'
    assert WallaIE()._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert WallaIE()._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:47:26.876678
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE.ie_key()
    assert t == 'walla'

# Generated at 2022-06-24 13:47:33.023165
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    i.extract()
    assert i.id == '2642630'
    assert i.display_id == 'one-direction-all-for-one'
    assert i.url == 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:47:37.204177
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # construct instance of WallaIE class
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['params']['skip_download'] == True

# Generated at 2022-06-24 13:47:40.367347
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(WallaIE._TEST['url'])
    assert WallaIE._TEST['url'] == ie._VALID_URL
    assert WallaIE._TEST['info_dict'] == ie._TEST

# Generated at 2022-06-24 13:47:48.115196
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:48.567818
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:47:55.931891
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    r = WallaIE()._real_extract(url)
    assert r['id'] == '2642630'
    assert r['display_id'] == 'one-direction-all-for-one'
    assert r['title'] == 'וואן דיירקשן: ההיסטריה'
    assert r['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert r['thumbnail'] == 're:^https?://.*\.jpg'
    assert r['duration'] == 3600

# Generated at 2022-06-24 13:48:07.376615
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.__class__.__name__ == 'WallaIE'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    # test_download_info
    mobj = re.match(ie._VALID_URL, ie._TEST['url'])
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')

# Generated at 2022-06-24 13:48:14.727257
# Unit test for constructor of class WallaIE
def test_WallaIE():

    class MyWallaIE(WallaIE):
        pass

    x = MyWallaIE()
    assert x.__class__ == MyWallaIE
    assert x._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:15.721656
# Unit test for constructor of class WallaIE
def test_WallaIE():
	return WallaIE()

# Generated at 2022-06-24 13:48:17.970895
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wm = WallaIE()
    assert wm.__class__.__name__ == 'WallaIE'

# Generated at 2022-06-24 13:48:24.235561
# Unit test for constructor of class WallaIE
def test_WallaIE():
    params = {'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'}
    assert WallaIE().suitable(params)
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:26.327240
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS == {u'עברית': 'heb'}

# Generated at 2022-06-24 13:48:29.572010
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert WallaIE._VALID_URL == ie.VALID_URL
    assert WallaIE._TEST == ie.TEST


# Generated at 2022-06-24 13:48:30.484916
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-24 13:48:30.955368
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE()

# Generated at 2022-06-24 13:48:33.003256
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(WallaIE._TEST['url'])

# Generated at 2022-06-24 13:48:34.993927
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:48:44.396066
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:49.851680
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)

    assert ie.__class__ is WallaIE
    assert ie._VALID_URL is WallaIE._VALID_URL
    assert ie._TEST is WallaIE._TEST
    assert ie._SUBTITLE_LANGS is WallaIE._SUBTITLE_LANGS



# Generated at 2022-06-24 13:48:55.172850
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    info_dict = ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert info_dict['id'] == '2642630'
    assert info_dict['display_id'] == 'one-direction-all-for-one'
    assert len(info_dict['subtitles'].keys()) == 1
    assert len(info_dict['subtitles']['heb']) == 1
    assert info_dict['subtitles']['heb'][0]['url'] == \
        'http://video2-sub.walla.co.il/sub/subtitle/?id=%26subid=2642630'
    assert len(info_dict['formats']) == 2
    assert info

# Generated at 2022-06-24 13:48:57.322762
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE == InfoExtractor.make_test_case(WallaIE, "Walla")

# Generated at 2022-06-24 13:49:00.265166
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.download("2642630")

# Generated at 2022-06-24 13:49:02.511025
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:49:06.252627
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie._real_initialize()
    assert ie.suitable(url)
    assert ie._real_extract(url)

# Generated at 2022-06-24 13:49:08.559365
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:49:09.198177
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:49:09.815266
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:49:17.495428
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.id == '2642630'
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:49:19.859840
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE()
    print(i)
    

if __name__ == "__main__":
    test_WallaIE()

# Generated at 2022-06-24 13:49:30.121993
# Unit test for constructor of class WallaIE
def test_WallaIE():
        options = {'password': 'qrkzrk', 'username': 'qrkzrk'}
        walla_ie = WallaIE(WallaIE.ie_key(), 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', options)
        results = walla_ie._extract_info()

        # These were the first two formats, change if site changes

# Generated at 2022-06-24 13:49:40.279941
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()