

# Generated at 2022-06-24 13:39:44.776344
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE()
    assert re.match(r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)',
                    'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['id'] == '2642630'
    assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:39:48.451571
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('rtmp://wafla.walla.co.il/vod')
    assert ie.rtmp_real_time == 'rtmp://wafla.walla.co.il/vod'

# Generated at 2022-06-24 13:39:51.401591
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:39:52.679379
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.IE == 'walla')
    assert(ie.NAME == 'walla.co.il')

# Generated at 2022-06-24 13:39:55.910850
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla:video'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-24 13:40:06.697704
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Create info extractor instance
    xtractor_instance = WallaIE()

    # Create info extractor object
    xtractor_object = type(xtractor_instance)

    # Check if test URL is suitable for this info extractor
    assert(xtractor_object._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)")
    assert(xtractor_object._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:40:07.517064
# Unit test for constructor of class WallaIE
def test_WallaIE():
	abbr = WallaIE()

# Generated at 2022-06-24 13:40:10.224912
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE().suitable(url), 'Incorrect constructor params!'
    assert WallaIE().extract(url), 'Incorrect extractor!'

# Generated at 2022-06-24 13:40:15.000925
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:24.035785
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructing the class instance without arguments should fail.
    try:
        ie = WallaIE()
    except TypeError:
        pass

    # Constructing the class instance with a invalid URL should fail.
    try:
        ie = WallaIE(url='invalid-url')
    except AssertionError:
        pass

    # Constructing the class instance with a valid URL
    test_video_url = 'http://vod.walla.co.il/movie/2642630/one-directio'
    ie = WallaIE(url=test_video_url)

    # This extract method should return a dictionary.
    test_video_return = ie.extract(test_video_url)
    assert(type(test_video_return) == dict)

# Generated at 2022-06-24 13:40:34.488341
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL = WallaIE._VALID_URL
    ie._TEST = WallaIE._TEST
    ie._SUBTITLE_LANGS = WallaIE._SUBTITLE_LANGS
    ie._real_extract = WallaIE._real_extract
    ie._sort_formats = WallaIE._sort_formats
    ie._download_xml = WallaIE._download_xml
    ie._xpath = WallaIE._xpath
    ie._xpath_ns = WallaIE._xpath_ns
    ie._xpath_text = WallaIE._xpath_text
    ie._type = WallaIE._type
    ie._search_regex = WallaIE._search_regex
    ie._html_search_regex = WallaIE._

# Generated at 2022-06-24 13:40:35.835433
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == 'WallaIE'

# Generated at 2022-06-24 13:40:41.071628
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.SUBS_RE == re.compile(r'<subtitle.*?>\s*<title>\s*(.+?)\s*</title>\s*<src>\s*(.+?)\s*</src>\s*</subtitle>')
    assert ie.LANG_MAP == {'עברית': 'heb'}

# Generated at 2022-06-24 13:40:44.268983
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:54.741605
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info = WallaIE()._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert info['id'] == '2642630'
    assert info['display_id'] == 'one-direction-all-for-one'
    assert info['title'] == 'וואן דיירקשן: ההיסטריה'
    assert info['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert info['thumbnail'] == 're:^https?://.*\.jpg'
    assert info['duration'] == 3600

# Generated at 2022-06-24 13:40:59.791093
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE("NONE")
    assert instance._VALID_URL == WallaIE._VALID_URL
    assert instance._TEST == WallaIE._TEST
    assert instance._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert instance._real_extract != WallaIE._real_extract

# Generated at 2022-06-24 13:41:01.743123
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().get_login_info() == None
    assert WallaIE().IE_NAME == 'walla'

# Generated at 2022-06-24 13:41:04.394925
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # this url is valid and it should be able to find a video
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-24 13:41:07.040481
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    instance.suitable('walla.co.il')
    instance.suitable('walla.com')

# Generated at 2022-06-24 13:41:12.189995
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Test for url without http://
    url = "vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    mobj = re.match(ie._VALID_URL, url)
    assert mobj.group('id') == '2642630'

# Generated at 2022-06-24 13:41:16.828970
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(video_url)
    assert ie.url == video_url
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.video_id == '2642630'

# Generated at 2022-06-24 13:41:23.033534
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:41:24.886578
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaie = WallaIE(None)
    assert wallaie is not None
    return True

# Generated at 2022-06-24 13:41:34.075841
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:41:36.137236
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:41:45.191876
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:47.747338
# Unit test for constructor of class WallaIE
def test_WallaIE():
  w = WallaIE()


# Generated at 2022-06-24 13:41:49.703288
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-24 13:41:56.155015
# Unit test for constructor of class WallaIE
def test_WallaIE():
    videoUrl = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wallaIE = WallaIE()._real_initialize()
    assert(wallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(WallaIE._TEST['url'] == videoUrl)

# Generated at 2022-06-24 13:41:57.212887
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-24 13:41:58.968660
# Unit test for constructor of class WallaIE
def test_WallaIE():
    if __name__ == "__main__":
        WallaIE()

# Generated at 2022-06-24 13:42:01.824947
# Unit test for constructor of class WallaIE
def test_WallaIE():
    temp_Walla_object = WallaIE({})
    assert temp_Walla_object._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:07.852683
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE("WallaIE", "walla.co.il", None, {}, {}, downloader=None, ui=None, params={})

    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:42:09.459356
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w.subtitle_langs == {'עברית': 'heb'}

# Generated at 2022-06-24 13:42:11.611427
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(test_WallaIE.__annotations__['url'])

# Generated at 2022-06-24 13:42:19.066797
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['params'] == {
        # rtmp download
        'skip_download': True,
    }

# Generated at 2022-06-24 13:42:19.532517
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-24 13:42:22.778021
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.url == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert ie.valid_url == True

# Generated at 2022-06-24 13:42:23.876407
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie
    assert ie._TEST

# Generated at 2022-06-24 13:42:24.752456
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-24 13:42:27.637472
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None
    #assert ie.get_link is not None
    #assert(WallaIE.get_link() == 'www.walla.co.il')

# Generated at 2022-06-24 13:42:38.241864
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl'
    display_id = 'one-direction-all-for-one'
    video_id = '2642630'

    #urlparse constructor
    urlparse_walla_ie = WallaIE(url)
    assert urlparse_walla_ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert urlparse_walla_ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert urlparse_walla_ie._TEST

# Generated at 2022-06-24 13:42:45.501525
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import InfoExtractor
    from .wdr import WdrIE
    from .yahoo import YahooIE

    # Sanity check for #4365
    IE_DESC = {
        'WdrIE': 'wdr',
        'WallaIE': 'walla',
        'YahooIE': 'yahoo',
    }
    for ie_name, ie_desc in IE_DESC.items():
        ie = globals()[ie_name]()
        assert ie_desc == ie.IE_NAME, 'Expected %s, got %s' % (ie_desc, ie.IE_NAME)

# Generated at 2022-06-24 13:42:47.932848
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-24 13:42:50.193609
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie is not None


# Generated at 2022-06-24 13:42:51.809504
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert isinstance(obj, WallaIE)


# Generated at 2022-06-24 13:42:52.998640
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE('WallaIE','http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:42:55.963288
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Should not raise any exception
    ie = WallaIE()
    assert ie.IE_NAME == 'walla:vod'

# Generated at 2022-06-24 13:43:04.111869
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = InfoExtractor('WallaIE')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-24 13:43:06.440072
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('url')
    assert(ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:43:07.491448
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()
    assert isinstance(wie, InfoExtractor)

# Generated at 2022-06-24 13:43:12.682526
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.video_id == '2642630'

# Generated at 2022-06-24 13:43:13.578477
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert x

# Generated at 2022-06-24 13:43:22.216338
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:43:31.050142
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:39.920890
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == test_url
    assert ie._TEST['info_dict']['id'] == video_id
    assert ie._TEST['info_dict']['display_id'] == display_id

# Generated at 2022-06-24 13:43:41.231583
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # WallaIE.__init__ will not raise an exception if no error occurs
    WallaIE('', '')

# Generated at 2022-06-24 13:43:42.042885
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE is not None

# Generated at 2022-06-24 13:43:44.537927
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert x is not None



# Generated at 2022-06-24 13:43:46.198220
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test for constructor of class WallaIE
    :return: None
    """
    WallaIE('walla')

# Generated at 2022-06-24 13:43:48.456992
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    print(ie)

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:43:49.033564
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:43:49.953277
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:43:50.500387
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:43:58.946599
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test empty url
    url = ""
    ie = WallaIE(url)
    assert ie.url == url

    # Test invalid url
    url = "invalid_walla_url"
    ie = WallaIE(url)
    assert ie.url == url
    assert ie.is_valid() == False

    # Test valid url
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE(url)
    assert ie.url == url
    assert ie.is_valid() == True

# Generated at 2022-06-24 13:44:07.671197
# Unit test for constructor of class WallaIE
def test_WallaIE():
    downloader = WallaIE()
    link = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert("http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl" in downloader._real_extract(link)["id"])
    assert("http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl" in downloader._real_extract(link)["display_id"])
    assert("http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl" in downloader._real_extract(link)["title"])

# Generated at 2022-06-24 13:44:10.182701
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    inst = WallaIE(None)
    # test pattern of url
    mobj = re.match(inst._VALID_URL, test_url)
    assert mobj



# Generated at 2022-06-24 13:44:18.563265
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor parameters with valid url
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['id'] == '2642630'
    assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:44:19.964129
# Unit test for constructor of class WallaIE
def test_WallaIE():
    expected = WallaIE
    actual = WallaIE
    assert actual == expected


# Generated at 2022-06-24 13:44:31.355273
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for correct initialization of class model
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    info = w.extract(url)
    assert info['id'] == '2642630'
    assert info['display_id'] == 'one-direction-all-for-one'
    assert info['ext'] == 'flv'
    assert info['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:44:32.272794
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .test_walla import test_WallaIE
    test_WallaIE(WallaIE, __name__)

# Generated at 2022-06-24 13:44:36.598245
# Unit test for constructor of class WallaIE
def test_WallaIE():
    calling_object=WallaIE('', '', {}, '')
    video_id='2642630'
    video_url='https://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl'%video_id
    video_xml='<video_xml>'
    calling_object._download_xml(video_url, video_id,video_xml, note='Downloading video XML', errnote=None)

# Generated at 2022-06-24 13:44:37.142178
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:44:38.792685
# Unit test for constructor of class WallaIE
def test_WallaIE():
	wallaie=WallaIE()
	wallaie.extract()

# Generated at 2022-06-24 13:44:39.755756
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie



# Generated at 2022-06-24 13:44:44.556537
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.name == 'Walla'
    assert ie.description == 'Walla!'
    assert ie.ie_key() == 'Walla'
    assert ie.host == 'vod.walla.co.il'

# Generated at 2022-06-24 13:44:54.345477
# Unit test for constructor of class WallaIE
def test_WallaIE():
    tester = WallaIE(InfoExtractor(), 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert tester._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:55.495373
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:45:01.749175
# Unit test for constructor of class WallaIE
def test_WallaIE():
    for arg in [{'url': "http://video2.walla.co.il/", 'id': "2642630/one-direction-all-for-one"},
                {'url': "http://video2.walla.co.il/", 'id': "2642630/one-direction-all-for-one", 'display_id': "3242561/one-direction"}]:
        n = WallaIE(arg)
        n.test()

#
# Test:
# http://video2.walla.co.il/movie/2642630/one-direction-all-for-one
#

# Generated at 2022-06-24 13:45:02.154109
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-24 13:45:03.026341
# Unit test for constructor of class WallaIE
def test_WallaIE(): 
    test = WallaIE(); 
    test.download(_TEST['url']);

# Generated at 2022-06-24 13:45:12.252660
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'

# Generated at 2022-06-24 13:45:14.325524
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    t.test()

# Generated at 2022-06-24 13:45:21.818438
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:45:22.808047
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None, None)
    assert ie is not None

# Generated at 2022-06-24 13:45:23.469966
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert True

# Generated at 2022-06-24 13:45:24.489148
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-24 13:45:25.461936
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == 'Walla'

# Generated at 2022-06-24 13:45:26.092586
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-24 13:45:27.496323
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test the constructor
    obj = WallaIE()


# Generated at 2022-06-24 13:45:37.305821
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:40.834718
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #Test if the class is instantiated without any parameters
        ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
        assert ie

# Generated at 2022-06-24 13:45:44.107182
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    w = WallaIE()


# Generated at 2022-06-24 13:45:53.600285
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:56.595285
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    except:
        assert False, 'Can\'t init class WallaIE'

# Generated at 2022-06-24 13:46:02.202801
# Unit test for constructor of class WallaIE
def test_WallaIE():
	w = WallaIE()
	assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
	assert w._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	assert w._TEST['info_dict']['id'] == '2642630'
	assert w._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
	assert w._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:46:12.642217
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:46:14.208122
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:23.214877
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE()
    # test _VALID_URL
    assert_equal(walla_ie._VALID_URL,
        r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    # test _TEST

# Generated at 2022-06-24 13:46:24.297519
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE()

# Generated at 2022-06-24 13:46:25.640151
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.name == 'Walla!'

# Generated at 2022-06-24 13:46:27.870369
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(WallaIE._TEST['url'])
    assert isinstance(ie, WallaIE)


# Generated at 2022-06-24 13:46:28.614277
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()


# Generated at 2022-06-24 13:46:31.310416
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:46:35.815864
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE()
    ie.extract(url)

# Generated at 2022-06-24 13:46:38.537915
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-24 13:46:45.088990
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    w._VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    w._SUBTITLE_LANGS = {
        'עברית': 'heb',
    }
    # Test the constructor of class WallaIE
    assert w != None and type(w) == WallaIE


# Generated at 2022-06-24 13:46:46.271701
# Unit test for constructor of class WallaIE
def test_WallaIE(): 
    w = WallaIE()
    assert w is not None

# Generated at 2022-06-24 13:46:48.097015
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:53.552097
# Unit test for constructor of class WallaIE
def test_WallaIE():
    input_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    res = w.extract(input_url)
    assert res['id'] == '2642630'
    assert res['display_id'] == 'one-direction-all-for-one'
    assert res['title'] == 'וואן דיירקשן: ההיסטריה'
    assert res['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert res['duration'] == 3600

# Generated at 2022-06-24 13:46:56.859867
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    WallaIE(WallaIE._VALID_URL, url)

# Generated at 2022-06-24 13:47:05.491665
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_WallaIE.walla_ie = WallaIE()
    assert '' == test_WallaIE.walla_ie._VALID_URL
    assert '' == test_WallaIE.walla_ie._TEST['url']
    assert '' == test_WallaIE.walla_ie._TEST['info_dict']['id']
    assert '' == test_WallaIE.walla_ie._TEST['info_dict']['display_id']
    assert '' == test_WallaIE.walla_ie._TEST['info_dict']['ext']
    assert '' == test_WallaIE.walla_ie._TEST['info_dict']['title']
    assert '' == test_WallaIE.walla_ie._TEST['info_dict']['description']

# Generated at 2022-06-24 13:47:09.350521
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for WallaIE.
    """
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    """ WallaIE(url) """

# Generated at 2022-06-24 13:47:12.263073
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._download_xml('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl', 'one-direction-all-for-one')

# Generated at 2022-06-24 13:47:20.228252
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test the WallaIE constructor, the class used to extract the video url

    Author: Tomer Filiba
    """
    # test success
    valid_url = WallaIE._VALID_URL
    mobj = re.match(valid_url, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert mobj is not None
    assert mobj.group('id') == '2642630'
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'
    assert WallaIE._SUBTITLE_LANGS['עברי'] == 'עברי'

# Generated at 2022-06-24 13:47:21.070342
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None

# Generated at 2022-06-24 13:47:25.485697
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('test')
    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert obj._downloader.params['noprogress'] == True

# Generated at 2022-06-24 13:47:26.028157
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-24 13:47:29.188657
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE(None)
    except (AssertionError, TypeError) as e:
        assert False, 'creating WallaIE object failed with %s' % e
    assert True, 'creating WallaIE object failed'

# Generated at 2022-06-24 13:47:39.830006
# Unit test for constructor of class WallaIE
def test_WallaIE():
    testie = WallaIE('test')
    assert(testie._VALID_URL ==  r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:47:50.820679
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:51.470098
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:47:55.856677
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert 'skip_download' in ie._TEST['params']

# Generated at 2022-06-24 13:47:56.733010
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-24 13:48:00.280947
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("Test")
    ie = WallaIE()
    ie._real_extract("Test")
    test = ie._download_xml("Test", "Test")
    print("Done")

# Generated at 2022-06-24 13:48:02.761913
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Initialisation of test WallaIE object
    test_WallaIE = WallaIE()
    assert test_WallaIE

# Generated at 2022-06-24 13:48:08.602841
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:11.246857
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    ctor_params = {}
    ctor_params['ie_key'] = 'Walla'
    ctor_params['ie_key'] = 'Walla'
    ctor_params['ie_key'] = 'Walla'

# Generated at 2022-06-24 13:48:23.810224
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    eq_('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', ie.url)
    eq_('2642630', ie.video_id)
    eq_('one-direction-all-for-one', ie.display_id)

# Generated at 2022-06-24 13:48:24.427952
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:48:27.656242
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-24 13:48:29.022221
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie == WallaIE

# Generated at 2022-06-24 13:48:32.592017
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    instances = repr(ie).split('\n')
    assert int(instances[0].split()[-1]) == WallaIE._TOTAL_INSTANCES
    assert len(instances) == WallaIE._TOTAL_INSTANCES + 1


# Generated at 2022-06-24 13:48:42.875314
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:48:46.094734
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:48:57.917108
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:59.359188
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'

# Generated at 2022-06-24 13:49:02.686403
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = WallaIE._TEST['url']
    walla = WallaIE()
    assert walla._real_extract(test_url)['id'] == WallaIE._TEST['info_dict']['id']

# Generated at 2022-06-24 13:49:04.937789
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()
	assert ie.ie_key() == "Walla"
	assert ie.ie_key() in ie.WORKING_IE_KEY

# Generated at 2022-06-24 13:49:13.161145
# Unit test for constructor of class WallaIE
def test_WallaIE():
	url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	display_id = 'one-direction-all-for-one'
	video_id = '2642630'
	video = {
		'site': 'walla',
		'site_url': 'http://vod.walla.co.il/',
		'_type': 'url_transparent',
		'url': url,
		'display_id': display_id,
		'ie_key': 'Walla',
		'id': video_id,
		'view_count': None,
	}
	assert WallaIE()._match_id(url) == video

# Generated at 2022-06-24 13:49:20.904106
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    info = ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert info['id'] == '2642630'
    assert info['display_id'] == 'one-direction-all-for-one'
    assert info['ext'] == 'flv'
    assert info['title'] == 'וואן דיירקשן: ההיסטריה'
    assert info['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'

# Generated at 2022-06-24 13:49:21.515545
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:49:28.158145
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.id == 'walla'
    assert ie.name == 'Walla! Video'
    assert ie.description == 'Walla! Video'
    assert ie.suitable == 'all'
    assert ie.valid_urls == ['http://vod.walla.co.il/']
    assert ie.IE_NAME == 'walla:video'


# Generated at 2022-06-24 13:49:38.922591
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert i._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'