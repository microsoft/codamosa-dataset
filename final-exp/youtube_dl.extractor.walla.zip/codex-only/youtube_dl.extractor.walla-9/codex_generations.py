

# Generated at 2022-06-24 13:39:41.849621
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:39:42.828204
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL

# Generated at 2022-06-24 13:39:54.412176
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from ..compat import compat_urllib_parse
    import os
    import sys

    # Get path to directory of this file
    path_to_this_file_dir = os.path.split(os.path.realpath(__file__))[0]

    # Add path to parent directory to system path
    parent_dir_path = os.path.abspath(os.path.join(path_to_this_file_dir, '..'))
    sys.path.insert(0, parent_dir_path)

    # Import module
    module = __import__('walla')

    # Get class WallaIE
    walla_ie_class = module.WallaIE

    # Get url of walla video

# Generated at 2022-06-24 13:39:58.300554
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE(InfoExtractor())
    assert w == WallaIE(InfoExtractor())

    # TODO: write more tests...
    # assert x in y
    # w.x = y
    # assert w.x == y

# Generated at 2022-06-24 13:39:58.953531
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suite()

# Generated at 2022-06-24 13:40:02.543459
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:05.859896
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/?w=search/@@search@@q=one+direction&type=all'
    ie = WallaIE()
    assert_raises(TypeError, ie.url_result(url))
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie._TEST == WallaIE._TEST

# Generated at 2022-06-24 13:40:06.614498
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE({}) is not None

# Generated at 2022-06-24 13:40:07.080245
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:40:07.764105
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-24 13:40:08.465005
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-24 13:40:09.739620
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-24 13:40:12.756754
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()
    assert IE.get_version() is not None
    assert IE.get_canonical() is not None

# Generated at 2022-06-24 13:40:13.330167
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:40:19.082941
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.video_id == '2642630'
    assert ie.display_id == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:40:22.437114
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert WallaIE()._TEST == WallaIE._TEST

# Generated at 2022-06-24 13:40:24.222061
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-24 13:40:28.165246
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = IE_TESTS[WallaIE.ie_key()]()
	assert ie.ie_key() == 'walla'
	assert ie.working == True
	assert ie.extractor() == WallaIE
	assert ie.working == True
	assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
	assert ie.working == True


# Generated at 2022-06-24 13:40:38.386300
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['id'] == '2642630'
    assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['ext'] == 'flv'


# Generated at 2022-06-24 13:40:47.016823
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_short() == 'Walla'
    assert ie.jsp_objectname() == 'walla.vod'
    assert ie.jsp_path() == '/wvod/vod/walla.vod/@@/walla/vod/walla.vod/walla.vod.js'
    assert ie.description() == 'Walla! Video on Demand'
    assert ie.ie_urls() == ['walla.co.il', 'walla.co.il/it']
    assert not ie.working
    assert ie.hosts() == ['wafla.walla.co.il']
    assert ie.age_limit() == 0



# Generated at 2022-06-24 13:40:54.902401
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:58.682663
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE.__name__ == 'WallaIE')
    assert(WallaIE.__doc__ == None)
    assert(repr(WallaIE).find('WallaIE(InfoExtractor)') > -1)

# Generated at 2022-06-24 13:41:06.342520
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['display_id'] == "one-direction-all-for-one"


# Generated at 2022-06-24 13:41:08.526860
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ufc_match='http://vod.walla.co.il/movie/2642714/ufc-fights-from-hell-ufc-165-jones-vs-gustafsson'
    WallaIE(ufc_match)

# Generated at 2022-06-24 13:41:10.145039
# Unit test for constructor of class WallaIE
def test_WallaIE():
    c = WallaIE()
    c.to_screen()

# Generated at 2022-06-24 13:41:19.646930
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:41:30.089318
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    #assert ie._TEST['info_dict']['id'] == '2642630'
    #assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    #assert ie._TEST['info_dict']['ext'] == 'flv'
    #assert ie._TEST['info_dict']['title'] == 'וואן די

# Generated at 2022-06-24 13:41:31.436387
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._download_xml

# Generated at 2022-06-24 13:41:40.830335
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    # check if url is valid
    assert WallaIE._VALID_URL.match(url) is not None
    ie = WallaIE(url)

    # check if extractor extracts correct information from url
    video = ie._real_extract(url)
    assert video['id'] == "2642630"
    assert video['display_id'] == "one-direction-all-for-one"
    assert video['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:41:44.987978
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class Tester(WallaIE):
        def _real_extract(self, url):
            return self._extract_from_id(
                '2642630',
                'http://vod.walla.co.il/2642630/one-direction-all-for-one')
    t = Tester()
    t.to_screen('Testing unit test for constructor of class WallaIE')
    t._downloader.params.update({'verbose': True})
    t.download('http://vod.walla.co.il/2642630/one-direction-all-for-one')
    assert(t.IE_NAME == 'walla:vod')

# Generated at 2022-06-24 13:41:55.240776
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert video.match(url)
    #extracted = video.extract(url)
    #assert len(extracted['subtitles']) > 0
    #assert len(extracted['subtitles']['heb']) > 0
    #assert extracted['subtitles']['heb'][0]['ext'] == 'srt'
    #assert extracted['subtitles']['heb'][0]['url'] is not None

# Generated at 2022-06-24 13:41:55.900722
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:41:58.612544
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:42:01.515992
# Unit test for constructor of class WallaIE
def test_WallaIE():
    Walla = WallaIE('Walla.co.il')
    assert Walla._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:13.722169
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert(ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:42:15.773729
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:42:16.452445
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:42:23.303419
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('www.walla', {}, False)
    assert list(ie._SUBTITLE_LANGS.keys()) == [u'עברית']
    assert ie._SUBTITLE_LANGS[u'עברית'] == 'heb'

# Generated at 2022-06-24 13:42:30.634326
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert str(ie).decode('utf-8') == "WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')"
    assert str(repr(ie)).decode('utf-8') == "WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')"

# Generated at 2022-06-24 13:42:40.483538
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test construction of class WallaIE
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)', 'did not initialize _VALID_URL'

# Generated at 2022-06-24 13:42:43.666108
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(w, WallaIE)

# Generated at 2022-06-24 13:42:44.571587
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()


# Generated at 2022-06-24 13:42:47.083535
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(ie.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"))

# Generated at 2022-06-24 13:42:56.705170
# Unit test for constructor of class WallaIE
def test_WallaIE():
	W = WallaIE()
	assert W == None
	assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:04.800562
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test constructor of class WallaIE.
    """
    # testing with empty params
    walla = WallaIE()
    assert walla._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:43:06.873535
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(InfoExtractor.IE_NAME).ie_key() == 'walla'
    assert WallaIE(InfoExtractor.IE_NAME)._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:43:17.569649
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class Init:
        def __init__(self, url):
            self.url = url
    args = Init('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    W = WallaIE()
    mobj = W._real_extract(args)
    print('\n' + mobj['id'])
    print('\n' + mobj['display_id'])
    print('\n' + mobj['title'])
    print('\n' + mobj['description'])
    print('\n' + mobj['thumbnail'])
    print('\n' + str(mobj['duration']))
    print('\n' + str(mobj['subtitles']))

# Generated at 2022-06-24 13:43:18.669052
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-24 13:43:26.736348
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_IE = WallaIE()
    assert walla_IE.name == 'walla'
    assert walla_IE.ie_key() == 'walla'
    assert walla_IE.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')['id'] == '2642630'
    assert walla_IE.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')['subtitles']['heb'][0]['url'] == 'rtmp://wafla.walla.co.il:1935/wafla/subtitle?id=2642630&lang=heb'

# Generated at 2022-06-24 13:43:27.275693
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-24 13:43:30.007353
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Testing constructor - WallaIE
    ie = WallaIE(None)
    assert ie is not None
    # Testing extractor - WallaIE
    ie = WallaIE(None)
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:31.362346
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('')

# Generated at 2022-06-24 13:43:41.172504
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test case to check if format_id will be set
    ie = WallaIE()
    ie.set_player_url('http://isc.walla.co.il/w9/swf/video_swf/vod/WallaMediaPlayerAvod.swf')
    ie.set_page_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.set_url('rtmp://wafla.walla.co.il/vod')
    ie.set_play_path('_definst_/s2/wafla/vod/2642630_hd.video')
    ie.set_ext('flv')
    ie.download_wafla_stream()
    assert ie.format_id == 'HD'

   

# Generated at 2022-06-24 13:43:41.968312
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-24 13:43:52.250996
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert obj._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-24 13:43:54.950162
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.get_test()['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:43:58.289894
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('WallaVod', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == WallaIE

# Generated at 2022-06-24 13:44:03.450884
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.id == '2642630'


# Generated at 2022-06-24 13:44:05.676715
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    if ie is None:
        print("WallaIE class is not initialized.")
        exit(1)
    print("WallaIE class is initialized.")

# Generated at 2022-06-24 13:44:07.726319
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-24 13:44:08.624131
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:44:12.690618
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert ie.url == url
    assert ie.video_id == '2642630'
    assert ie.display_id == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:44:14.562282
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:44:21.431549
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.expected_results['entries'] == [{
        'id': '2642630',
        'display_id': 'one-direction-all-for-one',
        'ext': 'flv',
        'title': 'וואן דיירקשן: ההיסטריה',
        'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        'thumbnail': r're:^https?://.*\.jpg',
        'duration': 3600,
    }]

# Generated at 2022-06-24 13:44:28.281287
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Simple test to see if a WallaIE object is constructed.
    ie = WallaIE(None)
    assert ie is not None

    # Making sure that the object has a working method to download a video URL.
    videoUrl = 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl'
    x = ie._downloadXml(videoUrl, 'Walla! VOD - 2642630')
    assert x is not None

# Generated at 2022-06-24 13:44:30.593422
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().ie_key() == "Walla"
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:44:32.446334
# Unit test for constructor of class WallaIE
def test_WallaIE():
	W = WallaIE()
	assert isinstance(W, InfoExtractor)
# Test for the class WallaIE for the method _real_extract

# Generated at 2022-06-24 13:44:34.949284
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:44:38.516748
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Tests that the WallaIE constructor can set up the module."""
    ie = WallaIE()
    assert ie.SUCCESS == 1
    assert ie.FAILURE == 0
    assert ie.WARNING == -1
    assert ie.INFO == 2

# Generated at 2022-06-24 13:44:48.033651
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create an instance of class WallaIE
    unit = WallaIE('')

    # Check that all class fields are initialized to the expected values
    assert unit._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:57.235999
# Unit test for constructor of class WallaIE
def test_WallaIE():

    assert WallaIE._TEST['url'] == WallaIE._VALID_URL
    ie = WallaIE(WallaIE._TEST)
    # ie.download will try to download the file
    # ie.params['skip_download'] avoids this
    ie.params['skip_download'] = True

    result = ie.extract(WallaIE._TEST['url'])

    assert result['id'] == WallaIE._TEST['info_dict']['id']
    assert result['display_id'] == WallaIE._TEST['info_dict']['display_id']
    assert result['title'] == WallaIE._TEST['info_dict']['title']
    assert result['description'] == WallaIE._TEST['info_dict']['description']
    assert result['thumbnail'] == WallaIE

# Generated at 2022-06-24 13:44:58.687622
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.app_name
    assert ie.app_key

# Generated at 2022-06-24 13:45:01.812084
# Unit test for constructor of class WallaIE
def test_WallaIE():
    for url in ['http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'http://vod.walla.co.il/broad/2642619/one-direction-all-for-one/']:
        assert WallaIE().suitable(url)


# Generated at 2022-06-24 13:45:07.271256
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:08.915310
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:45:11.237590
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE(_download_function=None, _downloader=None, _working_dir=None, _progress_hooks=[], _progress_hooks_mutex=None))

# Generated at 2022-06-24 13:45:11.713761
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:45:12.220784
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-24 13:45:22.453039
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from datetime import datetime
    from .test_common import get_testdata_file, make_tmpdir, FakeYDL
    from .extractors import walla

    TEST_DATE = datetime.strptime('2016-03-08 19:16:17', '%Y-%m-%d %H:%M:%S')

    # Create the test instance
    WallaIEInstance = walla.WallaIE({'outtmpl': '%(upload_date)s', 'writesubtitles': True, 'skip_download': True})

    # Check that an exception is raised in case of invalid URL
    invalid_url = 'https://vod.walla.co.il/unsupported/123456789.html'

# Generated at 2022-06-24 13:45:24.303941
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE();
    assert instance.__class__.__name__ == "WallaIE"


# Generated at 2022-06-24 13:45:34.362530
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test a normal video.
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ID = "2642630"
    DISPLAY_ID = "one-direction-all-for-one"
    page = WallaIE._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % ID, DISPLAY_ID)

    video = WallaIE(url)

    # Test the class' instance.
    assert video.url == url
    assert video.video_display_id == DISPLAY_ID
    assert video.video_id == ID
    assert '<path>' in str(video.download_xml)

    # Test a video without subtitles.


# Generated at 2022-06-24 13:45:43.802113
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:45:49.210840
# Unit test for constructor of class WallaIE
def test_WallaIE():
    source_code = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    result = w._real_extract(source_code)
    assert result.get('id') == '2642630'
    assert result.get('title') == 'וואן דיירקשן: ההיסטריה'
    assert result.get('description') == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert result.get('thumbnail') == r're:^https?://.*\.jpg'
    assert result.get('duration') == 3600

# Generated at 2022-06-24 13:45:50.607007
# Unit test for constructor of class WallaIE
def test_WallaIE():
	w = WallaIE()
	assert w != None


# Generated at 2022-06-24 13:45:52.689943
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # WallaIE.__init__()
    ie = WallaIE(None)
    assert ie.name == 'walla'

# Generated at 2022-06-24 13:45:53.999807
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL is not None

# Generated at 2022-06-24 13:45:55.267536
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');

# Generated at 2022-06-24 13:45:59.513198
# Unit test for constructor of class WallaIE
def test_WallaIE():
    '''Constructor of class WallaIE'''
    instance = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert instance.__class__.__name__ == 'WallaIE'
    # Not required because it uses regex
    # assert instance.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # assert not(instance.suitable('http://www.youtube.com/watch?v=BaW_jenozKc'))


# Generated at 2022-06-24 13:46:01.002380
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:46:02.305549
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(_VALID_URL)

# Generated at 2022-06-24 13:46:03.627559
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:46:06.657905
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.__class__ == WallaIE

# Generated at 2022-06-24 13:46:08.472674
# Unit test for constructor of class WallaIE
def test_WallaIE():
	walla = WallaIE()

# Generated at 2022-06-24 13:46:10.276281
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:46:19.226964
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:28.782773
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test WallaIE constructor
    try:
        wallaIE = WallaIE()
    except:
        print("WallaIE constructor failed")
        raise
    # Test WallaIE constructor with options
    try:
        wallaIE = WallaIE(options={})
    except:
        print("WallaIE constructor failed when called with options")
        raise
    # Test other WallaIE functions
    try:
        wallaIE._real_extract({})
        wallaIE._real_initialize({})
    except:
        print("WallaIE real extract or real initialize failed")
        raise

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:46:29.990392
# Unit test for constructor of class WallaIE
def test_WallaIE():
	walla = WallaIE()
	assert walla != None

# Generated at 2022-06-24 13:46:30.819495
# Unit test for constructor of class WallaIE
def test_WallaIE():
    Test = WallaIE()

# Generated at 2022-06-24 13:46:35.493643
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-24 13:46:43.651580
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # download_xml test
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla_ie = WallaIE(InfoExtractor())
    
    xml = walla_ie._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id)
    
    assert xml!=None


# Generated at 2022-06-24 13:46:52.100269
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:47:02.106727
# Unit test for constructor of class WallaIE
def test_WallaIE():

    ie = WallaIE()

    mobj = re.match(ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert mobj.group('id') == '2642630'
    assert mobj.group('display_id') == 'one-direction-all-for-one'
    mobj = re.match(ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/')
    assert mobj.group('id') == '2642630'
    assert mobj.group('display_id') == 'one-direction-all-for-one'

# Generated at 2022-06-24 13:47:12.716745
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    id_ = ie._match_id(url)
    assert id_ == '2642630'

    mobj = ie._extract_url(url)
    assert mobj.group('id') == '2642630'
    assert mobj.group('display_id') == 'one-direction-all-for-one'

    video = ie._download_xml('http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % id_, '2642630')

    item = video.find('./items/item')

    title = xpath_text(item, './title', 'title')

# Generated at 2022-06-24 13:47:15.728101
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:47:17.161263
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #instance1 = WallaIE(None, None, )
    if True:
        pass

# Generated at 2022-06-24 13:47:19.637101
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # As a test, I just want to make sure that the WallaPlayer is created.
    obj = WallaIE(None)
    assert(obj.player is not None)
    return('Done testing WallaIE')

# Generated at 2022-06-24 13:47:20.146410
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:47:20.650968
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert True

# Generated at 2022-06-24 13:47:21.150041
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:47:22.462949
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import unittest
    unittest.main()

# Generated at 2022-06-24 13:47:24.874164
# Unit test for constructor of class WallaIE
def test_WallaIE():
    vid_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    w._real_extract(vid_url)

# Generated at 2022-06-24 13:47:26.025734
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_obj = WallaIE('test', '')
    assert(isinstance(test_obj, WallaIE))

# Generated at 2022-06-24 13:47:29.188910
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test that constructor of WallaIE class doesn't fail when
    instantiating it."""
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-24 13:47:32.049916
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")


# Generated at 2022-06-24 13:47:42.005133
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    item = ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:47:43.565434
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:47:46.185715
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    instance._real_extract(instance._TEST['url'])

# Generated at 2022-06-24 13:47:46.928506
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:47:54.690399
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = "2642630"
    display_id = "one-direction-all-for-one"
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert w._TEST['url'] == url

# Generated at 2022-06-24 13:48:05.917097
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:08.999900
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:16.297618
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:48:17.480198
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract()

# Generated at 2022-06-24 13:48:18.667175
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(InfoExtractor)

# Generated at 2022-06-24 13:48:29.619243
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._VALID_URL == url

# Generated at 2022-06-24 13:48:30.057401
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:48:30.628700
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE

# Generated at 2022-06-24 13:48:31.574208
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None);

# Generated at 2022-06-24 13:48:35.221688
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:38.154162
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(a, WallaIE)

# Generated at 2022-06-24 13:48:42.874550
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    obj = WallaIE()
    # mobj is a match object
    # mobj.group(1) is the video_id
    mobj = re.match(obj._VALID_URL, url)
    obj.extract(url)

# Generated at 2022-06-24 13:48:46.073996
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print ('print_WallaIE ')
    print ('============================================================')
    # execution of the extracted method WallaIE
    w = WallaIE
    print ('Completed execution of WallaIE')
    print ('============================================================')
    return w

# call of WallaIE to get the information
# WallaIE()

# Generated at 2022-06-24 13:48:49.719558
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE(url)
    assert ie


# Generated at 2022-06-24 13:49:00.430538
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:49:01.304715
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:49:02.212920
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-24 13:49:03.449308
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w is not None


# Generated at 2022-06-24 13:49:07.367426
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.__name__ == 'Walla'
    assert ie.ie_key() == 'Walla'
    assert ie.info_dict == None

# Generated at 2022-06-24 13:49:18.061270
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("/src/id/name")
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:49:19.859497
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE({'_downloader': None})
    assert x.ie_key() == 'walla'

# Generated at 2022-06-24 13:49:22.322397
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:49:24.132574
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:49:28.157905
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:49:38.924096
# Unit test for constructor of class WallaIE