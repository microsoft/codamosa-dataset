

# Generated at 2022-06-24 13:39:44.555305
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    browser = ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    assert browser['id'] == '2642630'
    assert browser['display_id'] == 'one-direction-all-for-one'
    assert len(browser['formats']) == 5
    assert len(browser['subtitles']) == 1
    assert browser['title'] == 'וואן דיירקשן: ההיסטריה'
    assert browser['thumbnail'] is not None
    assert browser['duration'] == 3600

# Generated at 2022-06-24 13:39:56.437109
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Test for correct regex for link validation
    assert(ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)')
    assert(ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(ie._TEST['info_dict']['id'] == '2642630')
    assert(ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one')

# Generated at 2022-06-24 13:39:58.024965
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE({})
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-24 13:40:02.901159
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(re.match(ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'))

# Generated at 2022-06-24 13:40:05.720792
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_2 = WallaIE()
    assert test_2._download_xml('http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl', '2642630')
    assert test_2._SUBTITLE_LANGS('עברית')

# Generated at 2022-06-24 13:40:08.861006
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test for https://github.com/rg3/youtube-dl/issues/7302
    ie = WallaIE()
    assert ie.SUBS_LANG_TO_CODE == {'עברית': 'heb'}

# Generated at 2022-06-24 13:40:11.901495
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test for video 'Walla' for different classes like common, adobe, dailymotion, youtube
    # Walla_functions.test_Walla()
    pass

# Generated at 2022-06-24 13:40:15.319202
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    result = ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    print_result(result)

# Helper function for unit test

# Generated at 2022-06-24 13:40:19.224399
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test for constructor of class WallaIE"""
    test = WallaIE('')
    assert test._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'



# Generated at 2022-06-24 13:40:27.701866
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test whether constructors could be implemented
    if WallaIE.__dict__.get('suitable') is not None:
        assert WallaIE.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is True
        assert WallaIE.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is False
    else:
        assert WallaIE.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is True
        assert WallaIE.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is False
    assert WallaIE

# Generated at 2022-06-24 13:40:38.118402
# Unit test for constructor of class WallaIE
def test_WallaIE():
	
	import os
	import sys
	
	print("Testing with relative path...")
	
	mypath=os.path.dirname(os.path.realpath(__file__))
	print("mypath is [{}]".format(mypath))
	
	sys.path.append(mypath+"/..")
	
	import youtube_dl
	
	walla_extractor=youtube_dl.extractor.WallaIE()
	

# Generated at 2022-06-24 13:40:40.204611
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Testing WallaIE with a valid url
    test_url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE(test_url)
    assert (ie.get_type() == 'Walla')



# Generated at 2022-06-24 13:40:48.535213
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert wallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:56.322919
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.__class__ == WallaIE
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:40:58.525917
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert isinstance(ie, WallaIE)


# Generated at 2022-06-24 13:41:03.443913
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    #assert isinstance(ie, InfoExtractor)
    return ie

if __name__ == '__main__':
    ie = WallaIE()

# Generated at 2022-06-24 13:41:04.610240
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.constructor == 'WallaIE'

# Generated at 2022-06-24 13:41:11.310717
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.IE_NAME
    assert ie.IE_NAME == 'walla'
    ie.IE_DESC
    assert ie.IE_DESC == 'Walla!'
    ie.VALID_URL
    assert ie.VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:14.021671
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.SUCCESS(ie._TEST['url'])
    return "The constructor of WallaIE have been tested."



# Generated at 2022-06-24 13:41:15.311856
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # test class constructor
    assert ie

# Generated at 2022-06-24 13:41:17.253042
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    i = WallaIE()
    assert i.SUCCESS

# Generated at 2022-06-24 13:41:20.828498
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL = WallaIE._VALID_URL
    ie._SUBTITLE_LANGS = WallaIE._SUBTITLE_LANGS
    ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:41:21.917456
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-24 13:41:31.639137
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.IE_NAME == 'walla'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:41.042251
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    http_req_headers = "Accept-encoding: identity; q=1, *; q=0"
    ie = WallaIE()
    ie.http_headers = http_req_headers
    # Unit test of _real_extract()
    result = ie._real_extract(url)
    assert result['id'] == "2642630"
    assert result['display_id'] == "one-direction-all-for-one"
    assert result['ext'] == "flv"
    assert result['title'] == "וואן דיירקשן: ההיסטריה"

# Generated at 2022-06-24 13:41:41.731315
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None

# Generated at 2022-06-24 13:41:45.537095
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()

# Generated at 2022-06-24 13:41:47.396746
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:41:48.375298
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:41:50.753662
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:41:51.755069
# Unit test for constructor of class WallaIE
def test_WallaIE():
    xct = WallaIE()

# Generated at 2022-06-24 13:41:54.046535
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:41:57.042071
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_json_url = 'http://vod.walla.co.il/movie/2648430/the-good-the-bad-the-weird'
    WallaIE(test_json_url)

# Generated at 2022-06-24 13:41:59.235621
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor of WallaIE
    # This test is not actually implemented, but will pass the test framework
    assert WallaIE

# Generated at 2022-06-24 13:42:01.515623
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.SUCCESS == True

# Generated at 2022-06-24 13:42:04.587586
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-24 13:42:09.402594
# Unit test for constructor of class WallaIE
def test_WallaIE():
  ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
  assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:42:12.650489
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie.__name__ == WallaIE.__name__


# Generated at 2022-06-24 13:42:16.225423
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # If this fails, it's because you didn't create a WallaIE class
    ie = WallaIE()
    assert(ie.__class__.__name__ == 'WallaIE')


# Generated at 2022-06-24 13:42:20.230753
# Unit test for constructor of class WallaIE
def test_WallaIE():
	x = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
	assert x.display_id == 'one-direction-all-for-one'
	assert x.video_id == '2642630'

# Generated at 2022-06-24 13:42:21.203701
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w

# Generated at 2022-06-24 13:42:21.681202
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE

# Generated at 2022-06-24 13:42:23.461449
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w != None

test_WallaIE()

# Generated at 2022-06-24 13:42:24.629860
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #TODO: use some real html
    assert WallaIE()



# Generated at 2022-06-24 13:42:25.766388
# Unit test for constructor of class WallaIE
def test_WallaIE():
	walla = WallaIE()

# Generated at 2022-06-24 13:42:26.467527
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE

# Generated at 2022-06-24 13:42:31.910548
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # We should raise an error if we are not given an url parameter which is needed
    assertInfoExtractorError(WallaIE, 'Must pass a url')
    i = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert i.IE_NAME == 'walla:video'

# Generated at 2022-06-24 13:42:34.021542
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:42:37.226049
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.__class__ == WallaIE

# Generated at 2022-06-24 13:42:39.024348
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('rtmp://wafla.walla.co.il/vod/')

# Generated at 2022-06-24 13:42:44.639602
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:42:45.974619
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Basic test to check constructor of the class WallaIE
    """
    url = "http://vod.walla.co.il/"
    WallaIE(url)

# Generated at 2022-06-24 13:42:47.035364
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(WallaIE._TEST['url'])

# Generated at 2022-06-24 13:42:52.630297
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    res = ie._real_extract(ie._VALID_URL)
    assert 'id' in res
    assert 'display_id' in res
    assert 'title' in res
    assert 'description' in res
    assert 'thumbnail' in res
    assert 'duration' in res
    assert 'formats' in res
    assert 'subtitles' in res

# Generated at 2022-06-24 13:43:01.366699
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    assert i._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)';
    assert i._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one';
    assert i._TEST['info_dict']['id'] == '2642630';
    assert i._TEST['info_dict']['display_id'] == 'one-direction-all-for-one';
    assert i._TEST['info_dict']['ext'] == 'flv';

# Generated at 2022-06-24 13:43:04.674061
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # This is a simple unit test for WallaIE
    # The purpose of this test is to verify that the constructor of WallaIE
    # class is working
    ie_obj = WallaIE()
    if ie_obj.IE_NAME is None:
        raise AssertionError('The IE_NAME field seems to be None')
    # the following is a very simple test for the constructor
    assert ie_obj.IE_DESC is not None

# Generated at 2022-06-24 13:43:10.637872
# Unit test for constructor of class WallaIE
def test_WallaIE():
    num = 1
    prev_display_id = ""
    prev_title = ""
    prev_description = ""
    prev_duration = ""

    while (num < 20):
        url = "http://vod.walla.co.il/movie/2645482/%d" % num
        ie = WallaIE(url=url)
        assert ie.display_id < prev_display_id
        assert ie.title < prev_title
        assert ie.description < prev_description
        assert ie.duration > prev_duration
        prev_display_id = ie.display_id
        prev_title = ie.title
        prev_description = ie.description
        prev_duration = ie.duration
        num += 1

# Generated at 2022-06-24 13:43:20.068635
# Unit test for constructor of class WallaIE

# Generated at 2022-06-24 13:43:21.048827
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE(InfoExtractor())._VALID_URL

# Generated at 2022-06-24 13:43:21.893006
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj != None

# Generated at 2022-06-24 13:43:23.804466
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('www.walla.co.il')
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-24 13:43:25.564435
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _ = WallaIE()

# Generated at 2022-06-24 13:43:28.894819
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('any url')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'



# Generated at 2022-06-24 13:43:33.034721
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructor of class WallaIE
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    # Now we can test if there is a url for the class
    assert ie.url is "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-24 13:43:35.050111
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:37.187060
# Unit test for constructor of class WallaIE
def test_WallaIE():
    constructor = WallaIE()

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:43:38.304527
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass


# Generated at 2022-06-24 13:43:40.158143
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:41.287162
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #TODO: Add test case for the WallaIE class
    assert False

# Generated at 2022-06-24 13:43:42.079120
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-24 13:43:43.077867
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _WallaIE = WallaIE()
    assert _WallaIE == WallaIE

# Generated at 2022-06-24 13:43:49.498901
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(('WallaIE', 'WallaIE', 're:^https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)$','','','','','','',''))
    assert ie.NAME == 'WallaIE'
    assert ie.VALID_URL == 're:^https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)$'
    assert ie.IE_NAME == 'WallaIE'
    assert ie.IE_DESC == ''
    assert ie.URL_TEMPLATE == '%s'
    assert ie.BAD_CASTS == ()
    assert ie.BRAND == ''

# Generated at 2022-06-24 13:43:52.718677
# Unit test for constructor of class WallaIE
def test_WallaIE():
    data = {
        'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
    }
    WallaIE()._real_initialize(data)

# Generated at 2022-06-24 13:43:57.072763
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Basic instantiation of WallaIE
    WallaIE()

    # Instantiation with a URL and calling the extract() method
    WallaIE().extract(
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:43:58.478075
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:44:03.561308
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info = WallaIE()._real_extract(WallaIE._TEST['url'])
    titles = info['title'].replace(" ", "")
    assert titles == 'וואןדיירקשן:ההיסטריה', 'title is incorrect'
    assert info['subtitles'] == {}, 'subtitles are not empty'

# Generated at 2022-06-24 13:44:06.691704
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test for instance
    info_extractor = WallaIE("WALLAIE", "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert isinstance(info_extractor, WallaIE)

# Generated at 2022-06-24 13:44:15.274848
# Unit test for constructor of class WallaIE
def test_WallaIE():
	'''
	Проверка конструктора экстрактора WallaIE
	'''
	try:
		WallaIE()
	except Exception as e:
		return False
	return True

if __name__ == '__main__':
	if test_WallaIE():
		print('Спасибо за использование моего экстрактора!')
		print('Тестирование прошло успешно!')

# Generated at 2022-06-24 13:44:24.788083
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:34.267445
# Unit test for constructor of class WallaIE
def test_WallaIE():
    inst = WallaIE()
    assert inst.__class__ == WallaIE
    assert inst._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:44:35.446905
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE()

# Generated at 2022-06-24 13:44:42.225624
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._real_extract(ie._TEST['url']) == ie._TEST['info_dict']

# Generated at 2022-06-24 13:44:43.759981
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    assert instance

# Test for _VALID_URL regex

# Generated at 2022-06-24 13:44:53.602585
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE()
    assert walla_ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:01.237235
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class TestWallaIE(WallaIE):
        _VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:45:02.471823
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(InfoExtractor())._SUBTITLE_LANGS['עברית'] == 'heb'


# Generated at 2022-06-24 13:45:02.950304
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert 1 == 1

# Generated at 2022-06-24 13:45:03.679377
# Unit test for constructor of class WallaIE
def test_WallaIE():
        WallaIE("WallaIE", {})

# Generated at 2022-06-24 13:45:04.418811
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE().test()

# Generated at 2022-06-24 13:45:04.860468
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:45:05.681550
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE()

# Generated at 2022-06-24 13:45:07.946219
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-24 13:45:09.065788
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except AssertionError:
        assert False

# Generated at 2022-06-24 13:45:15.725947
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie._VALID_URL, type(re.compile('')))
    assert ie._VALID_URL.match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL.match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one?')
    assert ie._VALID_URL.match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one#')

# Generated at 2022-06-24 13:45:19.567688
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS == {'עברית': 'heb'}


# Generated at 2022-06-24 13:45:23.928552
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    # test the completion of the url
    url = w._real_extract("2642630")
    assert url == "http://vod.walla.co.il/movie/2642630"
    # test the valid of the url
    try:
        w._real_extract("htp://vod.walla.co.il/movie/2642630")
        assert False
    except re.error:
        assert True

# Generated at 2022-06-24 13:45:34.017309
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert test_WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:45:35.537455
# Unit test for constructor of class WallaIE
def test_WallaIE():
	try:
		WallaIE()
	except:
		print("Error in constructor of class WallaIE")

# Generated at 2022-06-24 13:45:37.875955
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    This function serves as constructor of class WallaIE
    """
    walla = WallaIE()
    assert walla.ie_key() == 'Walla'

# Generated at 2022-06-24 13:45:39.617772
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None, None)._SUBTITLE_LANGS['עברית'] == 'heb'


# Generated at 2022-06-24 13:45:40.750679
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE()

# Generated at 2022-06-24 13:45:41.928706
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()

    return True

# Generated at 2022-06-24 13:45:46.754991
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Unit test for constructor of class WallaIE

    # a Walla link
    # TODO: add tests
    '''
    walla_link = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE(walla_link)
    w.extract()
    '''

# Generated at 2022-06-24 13:45:56.056122
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Set up
	url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	expected_id = '2642630'
	expected_display_id = 'one-direction-all-for-one'
	expected_title = 'וואן דיירקשן: ההיסטריה'
	expected_description = 'md5:de9e2512a92442574cdb0913c49bc4d8'
	expected_duration = 3600
	
	# Excercise
	ie = WallaIE()
	actual_extractor = ie.suitable(url)
	actual_id = ie._real_extract(url)['id']
	actual_display_id = ie._real

# Generated at 2022-06-24 13:45:59.406229
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'Walla'
    assert ie.IE_DESC == 'Walla!'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:46:00.636253
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None

# Generated at 2022-06-24 13:46:01.979558
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-24 13:46:12.501453
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)';
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one';

# Generated at 2022-06-24 13:46:12.985193
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE

# Generated at 2022-06-24 13:46:15.067121
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert ie.get_video_id() == '2642630'



# Generated at 2022-06-24 13:46:23.814989
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');

    assert(ie._VALID_URL.match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'));
    assert(ie._VALID_URL.match('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'));
    assert(ie._VALID_URL.match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'));

# Generated at 2022-06-24 13:46:28.406379
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(WallaIE._downloader, 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.ie_key() == 'Walla'
    assert ie.url_re.match('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-24 13:46:29.601674
# Unit test for constructor of class WallaIE
def test_WallaIE():
   ie = WallaIE(None)
   assert ie is not None

# Generated at 2022-06-24 13:46:31.669617
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()
	assert ie.ie_key() == 'Walla'
	assert ie.ie_key() in InfoExtractor._ALL_CLASSES

# Generated at 2022-06-24 13:46:33.366277
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__, WallaIE

# Generated at 2022-06-24 13:46:35.955222
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    we = WallaIE()
    assert we._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-24 13:46:37.815706
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # TODO - this test is a stub; it should be replaced with real test
    assert False


# Generated at 2022-06-24 13:46:42.908936
# Unit test for constructor of class WallaIE
def test_WallaIE():
	url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	ie = WallaIE()
	obj = ie._real_extract(url)
	assert(obj['title'] == 'וואן דיירקשן: ההיסטריה')

# Generated at 2022-06-24 13:46:45.165501
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.constructor_name == 'WallaIE'


# Generated at 2022-06-24 13:46:46.685147
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('WallaIE')._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:46:48.485715
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    return 0

# Generated at 2022-06-24 13:46:50.791691
# Unit test for constructor of class WallaIE
def test_WallaIE():
    e = WallaIE(None)
    assert e
    assert str(type(e)) == "<class 'youtube_dl.extractor.walla.WallaIE'>"

# Generated at 2022-06-24 13:46:56.158626
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(WallaIE._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    assert ie._real_extract(url)['id'] == video_id
    assert ie._real_extract(url)['display_id'] == display_id
    assert ie._real_extract(url)['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-24 13:47:05.033054
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()
    e = test._real_extract(test._TEST['url'])
    assert(e['id'] == '2642630')
    assert(e['display_id'] == 'one-direction-all-for-one')
    assert(e['ext'] == 'flv')
    assert(e['title'] == 'וואן דיירקשן: ההיסטריה')
    assert(e['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8')
    assert(e['thumbnail'] == r're:^https?://.*\.jpg')
    assert(e['duration'] == 3600)
    assert(e['params']['skip_download'] == True)

# Generated at 2022-06-24 13:47:14.596603
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('rtmp://wafla.walla.co.il/vod/mp4:VOD_CONTENT/Content/VOD_CONTENT/2642630_504829.mp4?playurl=rtmp://wafla.walla.co.il/vod/mp4:VOD_CONTENT/Content/VOD_CONTENT/2642630_504829.mp4?playurl=rtmp://wafla.walla.co.il/vod/mp4:VOD_CONTENT/Content/VOD_CONTENT/2642630_504829.mp4')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:15.276735
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:47:16.181182
# Unit test for constructor of class WallaIE
def test_WallaIE():
    s = WallaIE()
    s.test()

# Generated at 2022-06-24 13:47:26.724131
# Unit test for constructor of class WallaIE
def test_WallaIE():
    searcher = WallaIE()
    assert searcher._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:27.519200
# Unit test for constructor of class WallaIE
def test_WallaIE():
    result = WallaIE()
    assert result is not None

# Generated at 2022-06-24 13:47:38.639164
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie._VALID_URL == 'http://vod.walla.co.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-24 13:47:40.370535
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-24 13:47:51.442805
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:47:52.872201
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Constructor test"""
    global WallaIE
    w_ie = WallaIE()
    assert w_ie

# Generated at 2022-06-24 13:47:53.688718
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()
    t.extract()

# Generated at 2022-06-24 13:48:03.398885
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # If a constructor requires a parameter, we need to pass it
    # explicitly.
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one", "http://vod.walla.co.il/")
    webpage = ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert webpage["id"] == "2642630"
    assert webpage["display_id"] == "one-direction-all-for-one"
    assert webpage["duration"] == 3600
    assert len(webpage["formats"]) > 0

# Generated at 2022-06-24 13:48:04.376456
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:48:06.365319
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global obj
    obj = WallaIE()

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-24 13:48:14.312344
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.downloader import RtmpFD
    from youtube_dl.compat import urlparse

    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    youtube_ie = YoutubeIE()
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.suitable(url)
    assert ie.working==True
    assert YoutubeIE.working==True
    assert youtube_ie.working==True
    assert ie.working==True

    # Check if the video is actually playable
    info = ie.extract(url)
    assert info['id'] == '2642630'

# Generated at 2022-06-24 13:48:17.468012
# Unit test for constructor of class WallaIE
def test_WallaIE():
    extractor0 = WallaIE()
    extractor1 = WallaIE()
    assert extractor0 is not extractor1

# Generated at 2022-06-24 13:48:18.667040
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor
    ie = WallaIE()

# Generated at 2022-06-24 13:48:29.616370
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:48:31.448301
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-24 13:48:33.743466
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for constructor of class WallaIE
    instance = WallaIE()
    assert isinstance(instance, WallaIE)



# Generated at 2022-06-24 13:48:43.969760
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.extract(url)
    assert ie._VALID_URL == re.compile(r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert ie._TEST['url'] == url
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-24 13:48:55.506530
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-24 13:48:56.451624
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()

# Generated at 2022-06-24 13:48:57.922416
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-24 13:48:58.746254
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    return

# Generated at 2022-06-24 13:49:02.181955
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor with empty unit test framework
    # - no url, no extractor object
    # - no url, valid extractor object
    # - invalid url, no extractor object
    # - invalid url, valid extractor object
    assert WallaIE() != None

# Generated at 2022-06-24 13:49:05.612469
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    expected = '2642630'
    # actual = WallaIE(url)
    assert (WallaIE.suitable(url) == True)
    # assert (actual.video_id(url) == expected)

# Generated at 2022-06-24 13:49:10.855220
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:49:15.107070
# Unit test for constructor of class WallaIE
def test_WallaIE():
    o = WallaIE()
    assert o.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-24 13:49:16.224634
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-24 13:49:21.044635
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ret = ie._real_extract(test_url)
    assert ret['id'] in test_url

# Generated at 2022-06-24 13:49:30.797348
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/4970562/')
    assert ie.url == 'http://vod.walla.co.il/movie/4970562/'
    assert ie.display_id == '4970562'
    assert ie.video_id == '4970562'
    assert ie._VALID_URL == 'http://vod\.walla\.co\.il/(?:[^/]+/)*(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-24 13:49:32.079978
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()


# Generated at 2022-06-24 13:49:34.450120
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    assert(WallaIE._VALID_URL == ie._VALID_URL);

# Generated at 2022-06-24 13:49:35.170827
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-24 13:49:37.315842
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = InfoExtractor("WallaIE")
    assert ie.__class__.__name__ == 'WallaIE'
