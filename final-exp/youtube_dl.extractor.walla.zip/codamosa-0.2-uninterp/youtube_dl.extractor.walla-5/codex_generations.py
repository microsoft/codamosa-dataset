

# Generated at 2022-06-18 15:16:45.936224
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-18 15:16:54.275603
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['news']
    assert ie.extractor_countries() == ['IL']
    assert ie.extractor_languages() == ['he']
    assert ie.extractor_domains() == ['walla.co.il']

# Generated at 2022-06-18 15:17:01.144626
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:17:08.653185
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 15:17:18.809679
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['News']
    assert ie.extractor_countries() == ['IL']
    assert ie.extractor_languages() == ['he']
    assert ie.extractor_duration() == 0
    assert ie.extractor_age_limit() == 0

# Generated at 2022-06-18 15:17:28.472999
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:17:38.554039
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:17:43.825194
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_version() == '0.1'

# Generated at 2022-06-18 15:17:55.934968
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:17:57.305908
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.supported_extractors() == ['Walla']

# Generated at 2022-06-18 15:18:21.460358
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'video'
    assert ie.extractor_genres() == ['general']
    assert ie.extractor_countries() == ['IL']
    assert ie.extractor_languages() == ['he']
    assert ie.extractor_domains() == ['walla.co.il']

# Generated at 2022-06-18 15:18:24.019196
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'

# Generated at 2022-06-18 15:18:31.880529
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_description() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.ie_info_dict() == {
        'id': 'Walla',
        'name': 'Walla',
        'description': 'Walla',
        'version': '0.1',
    }
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_description() == 'Walla'
    assert ie.ie_version() == '0.1'

# Generated at 2022-06-18 15:18:41.918492
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/1')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/1/')

# Generated at 2022-06-18 15:18:50.362584
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:18:55.111773
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-18 15:19:06.874307
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:19:15.840900
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:19:25.532227
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:19:29.935559
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_version() == '0.1'

# Generated at 2022-06-18 15:20:10.060703
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/@@/video/flv_pl')

# Generated at 2022-06-18 15:20:17.085485
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_version() == '0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_version() == '0.1'
    assert ie.extractor_type() == 'playlist'

# Generated at 2022-06-18 15:20:24.052426
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '1.0'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_version() == '1.0'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['news', 'sports', 'entertainment', 'music', 'movies', 'comedy', 'documentary', 'lifestyle', 'kids', 'tech', 'auto']
    assert ie.extractor_countries() == ['IL']
    assert ie.extractor_languages() == ['he']
    assert ie.extractor_domains() == ['walla.co.il']
   

# Generated at 2022-06-18 15:20:34.141131
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:20:44.364897
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:20:54.249900
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:20:58.000875
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'

# Generated at 2022-06-18 15:21:03.597903
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_version() == '0.1'
    assert ie.extractor_type() == 'playlist'

# Generated at 2022-06-18 15:21:08.120226
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-18 15:21:18.247658
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:22:23.830620
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:22:33.546295
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:22:40.459440
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:22:46.294954
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-18 15:22:51.027937
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.1'

# Generated at 2022-06-18 15:22:57.820610
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') != False
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is True
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is not False

# Generated at 2022-06-18 15:23:02.612558
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-18 15:23:04.881582
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-18 15:23:05.473269
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-18 15:23:14.827932
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:25:24.828064
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'

# Generated at 2022-06-18 15:25:35.176434
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'video'
    assert ie.extractor_genres() == ['news']
    assert ie.extractor_countries() == ['IL']
    assert ie.extractor_languages() == ['he']
    assert ie.extractor_domains() == ['walla.co.il']

# Generated at 2022-06-18 15:25:41.469787
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:25:44.505003
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'

# Generated at 2022-06-18 15:25:53.003997
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:25:59.082638
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:26:03.487268
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:26:12.073006
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:26:20.932296
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'video'
    assert ie.extractor_genres() == ['general']
    assert ie.extractor_countries() == ['IL']
    assert ie.extractor_languages() == ['he']
    assert ie.extractor_domains() == ['walla.co.il']
    assert ie.extractor_urls() == ['http://vod.walla.co.il/']
    assert ie.extractor_short

# Generated at 2022-06-18 15:26:22.945678
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'