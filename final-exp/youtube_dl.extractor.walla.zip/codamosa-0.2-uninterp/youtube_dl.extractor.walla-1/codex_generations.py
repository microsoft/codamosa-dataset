

# Generated at 2022-06-18 15:16:51.248445
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie.ie_name() == 'walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') != False
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is True

# Generated at 2022-06-18 15:16:54.866262
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-18 15:16:58.733823
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://www.walla.co.il/')

# Generated at 2022-06-18 15:17:11.966489
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') != False
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') != None

# Generated at 2022-06-18 15:17:16.191878
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-18 15:17:26.607289
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:17:36.359066
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/@@/video/flv_pl')

# Generated at 2022-06-18 15:17:47.209858
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:17:58.585371
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:18:08.245075
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True

# Generated at 2022-06-18 15:18:27.188354
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-18 15:18:38.009373
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:18:43.803143
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'video'

# Generated at 2022-06-18 15:18:51.719857
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:19:02.808292
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:19:12.900410
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/1')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/1/')

# Generated at 2022-06-18 15:19:21.996601
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:19:24.937871
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_key() in ie.gen_extractors()
    assert ie.ie_key() in ie.list_extractors()

# Generated at 2022-06-18 15:19:34.019915
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:19:42.329200
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['news', 'sports', 'entertainment', 'music', 'kids', 'documentary', 'comedy']
    assert ie.extractor_countries() == ['IL']
    assert ie.extractor_languages() == ['he']

# Generated at 2022-06-18 15:20:13.363143
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'

# Generated at 2022-06-18 15:20:21.684715
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-18 15:20:32.179657
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') != False
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is True

# Generated at 2022-06-18 15:20:42.671351
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:20:47.343342
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:20:52.214526
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-18 15:20:59.041497
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'video'
    assert ie.extractor_genres() == ['general']
    assert ie.extractor_countries() == ['IL']
    assert ie.extractor_languages() == ['he']
    assert ie.extractor_domains() == ['walla.co.il']

# Generated at 2022-06-18 15:21:09.474342
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:21:19.012706
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.name == 'walla'
    assert ie.ie_key() == 'walla'
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'Walla')
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'Walla') is not None
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'Walla') is not False


# Generated at 2022-06-18 15:21:27.424951
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:22:29.124654
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:22:37.642491
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') != False
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') != None

# Generated at 2022-06-18 15:22:47.923501
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:22:55.586649
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:22:59.586041
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'

# Generated at 2022-06-18 15:23:10.728851
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! VOD'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:23:18.672263
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:23:29.686270
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.video_id == '2642630'
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._

# Generated at 2022-06-18 15:23:39.728812
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:23:48.321652
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:26:01.243154
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-18 15:26:04.279366
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'

# Generated at 2022-06-18 15:26:07.933960
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-18 15:26:16.136646
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:26:24.682368
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/1')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/1/')

# Generated at 2022-06-18 15:26:33.440601
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'