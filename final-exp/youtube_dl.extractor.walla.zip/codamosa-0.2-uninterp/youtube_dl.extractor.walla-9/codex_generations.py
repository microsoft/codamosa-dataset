

# Generated at 2022-06-18 15:16:50.476051
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:16:52.577270
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_key() in ie.gen_extractors()

# Generated at 2022-06-18 15:17:00.002657
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! VOD'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:17:13.244890
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:17:21.548823
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:17:26.842861
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extractor_key() == 'walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.1'
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'Walla')

# Generated at 2022-06-18 15:17:31.117674
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-18 15:17:42.434558
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.SUCCESS == True
    assert ie.FAILURE == False
    assert ie.VALID_URL == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.VALID_URL == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.VALID_URL == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-18 15:17:48.923634
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie.ie_name() == 'walla.co.il'
    assert ie.supported_extractors() == ['WallaIE']
    assert ie.supported_domains() == ['walla.co.il']
    assert ie.supported_urls() == [
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one']

# Generated at 2022-06-18 15:17:59.795479
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:18:09.379584
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-18 15:18:18.925885
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:18:28.419018
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'video'
    assert ie.extractor_genres() == ['News', 'Entertainment', 'Sports', 'Music', 'Kids', 'Tech', 'Lifestyle', 'Comedy', 'Movies', 'Series']
    assert ie.extractor_countries() == ['IL']
    assert ie.extractor_languages() == ['he']
    assert ie.extractor_dom

# Generated at 2022-06-18 15:18:39.202885
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:18:48.203816
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'video'
    assert ie.is_suitable(WallaIE._VALID_URL) == True
    assert ie.is_suitable('http://www.walla.co.il') == False
    assert ie.is_suitable('http://www.walla.co.il/item/2642630') == False

# Generated at 2022-06-18 15:18:57.319229
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:19:08.955322
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:19:17.396912
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:19:22.788308
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-18 15:19:31.988480
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['news', 'sports', 'entertainment', 'music', 'kids', 'movies', 'comedy', 'documentary', 'lifestyle', 'tech']
    assert ie.extractor_countries() == ['IL']
    assert ie.extractor_languages() == ['he']
    assert ie.ext

# Generated at 2022-06-18 15:19:54.460974
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True

# Generated at 2022-06-18 15:20:01.347015
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:20:02.458684
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-18 15:20:06.885201
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_version() == '0.1'

# Generated at 2022-06-18 15:20:16.037431
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:20:23.372592
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:20:29.004192
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-18 15:20:39.778337
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:20:42.418394
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'

# Generated at 2022-06-18 15:20:44.293917
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'

# Generated at 2022-06-18 15:21:13.591835
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:21:21.889190
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:21:31.971765
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:21:41.773100
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['News', 'Entertainment']
    assert ie.extractor_countries() == ['IL']
    assert ie.extractor_languages() == ['he']
    assert ie.extractor_duration() == 'short'
    assert ie.extractor_age_limit() == 0

# Generated at 2022-06-18 15:21:46.000776
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-18 15:21:57.511939
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:22:04.176481
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:22:10.578443
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:22:21.383565
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:22:31.138144
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.1'

# Generated at 2022-06-18 15:23:22.788446
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/1')
    assert not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/1/')

# Generated at 2022-06-18 15:23:35.331235
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') != False
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is True

# Generated at 2022-06-18 15:23:45.035534
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:23:53.114318
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:23:56.753072
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_key() in ie.extractor_key_map
    assert ie.extractor_key_map[ie.ie_key()] == ie.__class__

# Generated at 2022-06-18 15:24:05.088262
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_name() == 'Walla'
    assert ie.extractor_version() == '0.0.1'
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'Walla')

# Generated at 2022-06-18 15:24:11.863485
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:24:21.506287
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:24:30.399034
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-18 15:24:36.928896
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'
    assert ie.extractor_key() == 'Walla'
    assert ie.extractor_version() == '0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_keywords() == ['Walla']
    assert ie.extractor_description() == 'Walla'
    assert ie.extractor_short_description() == 'Walla'
    assert ie.extractor_icon() == 'icon.png'
    assert ie.extractor_genres() == ['News']
    assert ie.extractor_categories() == ['News']
    assert ie.extractor_language