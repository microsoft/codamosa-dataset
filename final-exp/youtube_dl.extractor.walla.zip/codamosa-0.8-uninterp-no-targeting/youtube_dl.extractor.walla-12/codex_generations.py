

# Generated at 2022-06-22 08:49:54.719595
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable(WallaIE._VALID_URL)
    ie.get_url_data(WallaIE._TEST['url'])
    ie.extract(WallaIE._TEST['url'])

# Generated at 2022-06-22 08:50:00.463277
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Test constructor without any argument
	WallaIE()

	# Test constructor with url and download arguments
	#WallaIE(url='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', download=True)

# Generated at 2022-06-22 08:50:06.188947
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

    assert obj._VALID_URL == WallaIE._VALID_URL
    assert obj._TEST == WallaIE._TEST
    assert obj._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS

    assert obj.IE_NAME == "walla"
    assert obj.IE_DESC == "Walla! Video"

    assert obj.WS_URL == "http://video2.walla.co.il"

    assert obj._real_extract(obj._TEST['url']) == obj._TEST['info_dict']

# Generated at 2022-06-22 08:50:07.567795
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-22 08:50:08.634642
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()
    print(IE)

# Generated at 2022-06-22 08:50:10.687244
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__.__name__ == 'WallaIE'


# Generated at 2022-06-22 08:50:11.749815
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()



# Generated at 2022-06-22 08:50:23.385523
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.host() == "vod.walla.co.il"
    assert ie.url() == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert ie.title() == "וואן דיירקשן: ההיסטריה"
    assert ie.description() == "md5:de9e2512a92442574cdb0913c49bc4d8"
    assert ie.thumbnail() == "re:^https?://.*\.jpg"
    assert ie.duration() == 3600
    assert ie.video_id()

# Generated at 2022-06-22 08:50:25.147469
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for constructor of class WallaIE
    WallaIE(None)

# Generated at 2022-06-22 08:50:30.290430
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Check constructor for WallaIE"""
    class_walla_ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert class_walla_ie.ie_key() == 'Walla'

# Generated at 2022-06-22 08:50:44.683656
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wie = WallaIE(None)
    wie._real_extract(url)

# Generated at 2022-06-22 08:50:47.557432
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .test import test_main
    from .walla import WallaIE
    test_main(WallaIE)

# Generated at 2022-06-22 08:50:50.465566
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()
    res = IE._construct_class_fullname(WallaIE)
    assert res == 'WallaIE', 'Class full name must be \'WallaIE\' and not \'{}\''.format(res)


# Generated at 2022-06-22 08:50:54.948103
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il')
    assert ie.name == 'walla'
    assert ie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:55.676946
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE('test')

# Generated at 2022-06-22 08:50:56.150547
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE(None)

# Generated at 2022-06-22 08:50:58.940588
# Unit test for constructor of class WallaIE
def test_WallaIE():
    item = WallaIE('WallaIE', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(item, (WallaIE, InfoExtractor))


# Generated at 2022-06-22 08:51:09.251400
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """ Unit test for the constructor of class WallaIE. """
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:51:19.176111
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    video_info = ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert video_info['id'] == '2642630'
    assert video_info['display_id'] == 'one-direction-all-for-one'
    assert video_info['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-22 08:51:29.974018
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for WallaIE"""

# Generated at 2022-06-22 08:51:43.886012
# Unit test for constructor of class WallaIE
def test_WallaIE():
    testcases = [
        (WallaIE._SUBTITLE_LANGS, {'עברית': 'heb'})
    ]
    for (src, expected) in testcases:
        assert src == expected, "Expected %s, got %s" % (expected, src)

# Generated at 2022-06-22 08:51:46.266890
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.SUBS[0]['title'] == "ישראל"



# Generated at 2022-06-22 08:51:50.415476
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.SUCCESS == '_real_extract'
    assert type(ie.VALID_URL) is re._pattern_type
    assert type(ie._SUBTITLE_LANGS) is dict

# Generated at 2022-06-22 08:52:00.696456
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:52:08.021469
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # This is a test for the constructor of class WallaIE.
    # It requires that the module nose is installed.
    # In the command line , enter: "nosetests test_WallaIE.py"
    # If all tests succeed, you'll see "......." , otherwise error messages
    video_id = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wallaIE = WallaIE()
    wallaIE.initialize()
    res = wallaIE.extract(video_id)

# Generated at 2022-06-22 08:52:13.182868
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"))
    assert(ie.IE_NAME == "walla")
    assert(ie.IE_DESC == "Walla")

# Generated at 2022-06-22 08:52:18.042800
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:52:22.993621
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla:video'
    assert ie.extractor_key == 'WallaIE'
    assert ie.working == False

# Generated at 2022-06-22 08:52:24.372870
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._TEST['url'] == WallaIE._VALID_URL

# Generated at 2022-06-22 08:52:31.068103
# Unit test for constructor of class WallaIE
def test_WallaIE():

    w = WallaIE()
    assert w is not None
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert w._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'


# Generated at 2022-06-22 08:52:49.566836
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test normal constructor case
    w = WallaIE()
    # Test constructor arguments
    w = WallaIE(WallaIE.ie_key())
    # Test invalid constructor arguments
    try:
        w = WallaIE('Invalid argument')
        assert(False)
    except AssertionError:
        raise AssertionError('Constructor with invalid argument should not be allowed')
    except Exception:
        pass

test_WallaIE()

# Generated at 2022-06-22 08:52:57.462181
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test the basic attributes of the class
    config = WallaIE()

    # Test regexes

    # Test regex
    assert config._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'

    # Test the method _real_extract()
    config.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:53:02.356421
# Unit test for constructor of class WallaIE

# Generated at 2022-06-22 08:53:04.382300
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #test = WallaIE()
    #print "test=",test
    pass

# Generated at 2022-06-22 08:53:04.991456
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-22 08:53:10.229389
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('https://github.com/rg3/youtube-dl')
    main_page = ie.urlopen('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie._html_search_regex(ie._VALID_URL, main_page, 'url')

# Generated at 2022-06-22 08:53:21.061929
# Unit test for constructor of class WallaIE
def test_WallaIE():
	w = WallaIE()
	assert(w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-22 08:53:23.198099
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == 'WallaIE'

# Generated at 2022-06-22 08:53:25.692136
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None).suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:53:37.230732
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    vod = ie.ie_key()
    tests = {
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one': {
            'id': '2642630',
            'display_id': 'one-direction-all-for-one',
            'title': 'וואן דיירקשן: ההיסטריה',
            'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        },
    }
    for test, expected in tests.iteritems():
        info = ie._real_extract(test)
        expected_keys = expected.keys()
        assert info.keys() == expected_keys


# Generated at 2022-06-22 08:54:11.888569
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
	assert WallaIE._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-22 08:54:18.330203
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj._VALID_URL == '^https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:54:28.191282
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST[0] == 'url'
    assert WallaIE._TEST[1]['info_dict']['id'] == '2642630'
    assert WallaIE._TEST[1]['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert WallaIE._TEST[1]['info_dict']['ext'] == 'flv'

# Generated at 2022-06-22 08:54:32.665569
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:54:35.076515
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie_sub = ie.subtitle()
    assert ie_sub == ie.subtitle()

# Generated at 2022-06-22 08:54:36.628223
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:54:37.851713
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    return a is not None

# Generated at 2022-06-22 08:54:44.116664
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
	assert ie.title == "וואן דיירקשן: ההיסטריה"
	assert ie.description == "md5:de9e2512a92442574cdb0913c49bc4d8"
	assert ie.duration == 3600

# Generated at 2022-06-22 08:54:46.108755
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TEST')

# Generated at 2022-06-22 08:54:54.404372
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert ie.valid_url()

    ie.url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert ie.valid_url()

    ie.url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert ie.valid_url()

# Generated at 2022-06-22 08:55:56.115718
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-22 08:56:05.335444
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(not None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:56:06.609724
# Unit test for constructor of class WallaIE
def test_WallaIE():
	e = WallaIE()
	assert e.__init__()

# Generated at 2022-06-22 08:56:07.778115
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(walla.info.extractor.common.InfoExtractor())

# Generated at 2022-06-22 08:56:18.606401
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-22 08:56:19.969893
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE == WallaIE(None).ie_key()

# Generated at 2022-06-22 08:56:21.557588
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-22 08:56:23.714303
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ydl = WallaIE()
    print(0)

# Generated at 2022-06-22 08:56:26.110378
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:56:27.212702
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('1')

# Generated at 2022-06-22 08:58:50.742750
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.VALID_URL == 'http://vod.walla.co.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}
    assert ie.IE_NAME == 'walla'
    # test .ie_key() method
    assert ie.ie_key() == 'Walla'
    # test .constructor() method
    assert ie.constructor('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # test ._real_ext

# Generated at 2022-06-22 08:58:55.180831
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:59:02.879219
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test_str_url = WallaIE._VALID_URL
    test_res = []
    test_res.append(re.match(test_str_url, test_url))
    test_res.append(re.match(test_str_url, WallaIE._TEST['url']))
    assert all(test_res)==True
    # Test if the _TEST dict is valid
    return WallaIE._TEST


# Generated at 2022-06-22 08:59:05.545604
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:59:11.991728
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    info = {'id':'2642630', 'display_id':'one-direction-all-for-one', 'ext':'flv', 'title':'וואן דיירקשן: ההיסטריה', 'description':'md5:de9e2512a92442574cdb0913c49bc4d8', 'thumbnail':'re:^https?://.*\.jpg', 'duration':3600}
    params = {'skip_download':True}

    WallaIE(url, info, params)

# Generated at 2022-06-22 08:59:19.891117
# Unit test for constructor of class WallaIE

# Generated at 2022-06-22 08:59:21.257257
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Tested in WallaIE._real_extract
    pass

# Generated at 2022-06-22 08:59:23.498220
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    obj.extract()

# Generated at 2022-06-22 08:59:25.902072
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:59:26.430705
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE()