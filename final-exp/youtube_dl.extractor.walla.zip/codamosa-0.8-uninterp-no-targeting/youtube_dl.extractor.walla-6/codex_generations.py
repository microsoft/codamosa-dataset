

# Generated at 2022-06-22 08:49:50.612731
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(WallaIE._TEST['url'])

# Generated at 2022-06-22 08:49:57.749133
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    This test is not very stable since it executes code from the internet.
    """
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'



# Generated at 2022-06-22 08:49:58.464765
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE()

# Generated at 2022-06-22 08:50:00.168621
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj is not None

# Generated at 2022-06-22 08:50:07.428517
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    video_id = "2642630"
    display_id = "one-direction-all-for-one"
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == url
    assert ie._TEST['info_dict']['id'] == video_id
    assert ie._TEST['info_dict']['display_id'] == display_id
    url = ie._VALID_URL
    mobj = re.match(url, url)
    assert mobj

# Generated at 2022-06-22 08:50:13.249311
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from urllib import urlopen
    from urlparse import urlparse
    from urlparse import urljoin
    import unicodedata
    import re

    # unit tests for the WallaIE class
    test = WallaIE()

    # unit tests for the check_exists function
    def check_exists_unit_test(url):
        """
        check if the given url is a valid video link and return the matched video code.
        :param url: the video link to check.
        :return: the video code if link is valid and False if not.
        """
        # check if the url matches one of the standards url formats.

# Generated at 2022-06-22 08:50:19.582886
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_code() == 'walla'
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Unit test to test the source code of the video with videoId=='2642630'

# Generated at 2022-06-22 08:50:28.737067
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert(obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-22 08:50:33.031637
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:50:35.392854
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == "WallaIE"
#Unit test method WallaIE.extract

# Generated at 2022-06-22 08:50:47.076929
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()
    # An URL
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert t._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert t._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is not None

# Generated at 2022-06-22 08:50:50.119561
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # check inheritance of class WallaIE from InfoExtractor
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:50:50.916865
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj is not None

# Generated at 2022-06-22 08:51:00.611131
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:51:10.157033
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)

    #test for valid video id and display id
    testValid = ie._VALID_URL
    testUrl = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(testValid, testUrl)
    assert mobj.group('id') == '2642630'
    assert mobj.group('display_id') == 'one-direction-all-for-one'

    #test for valid video id and display id
    testValid = ie._VALID_URL
    testUrl = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(testValid, testUrl)

# Generated at 2022-06-22 08:51:19.022319
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie._download_xml = lambda url: True # avoid calling "download_xml" in constructor
    ie.ie_key = 'Walla'
    info = ie.extract(url)
    assert info['id'] == '2642630'
    assert info['display_id'] == 'one-direction-all-for-one'
    assert 'formats' in info
    assert 'subtitles' in info

# Generated at 2022-06-22 08:51:28.383367
# Unit test for constructor of class WallaIE
def test_WallaIE():
    runner = unittest.TextTestRunner()
    # Test 01: Constructor test
    print("\nUnit Test 01: Constructor test of class WallaIE")
    runner.run(WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"))
    # Test 02: Test if "url" variable is initialized
    print("\nUnit Test 02: Test if \"url\" variable is initialized")
    assert  WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one").url=="http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-22 08:51:28.936904
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:51:40.338608
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:51:51.794639
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    # Test extract_id
    assert(walla._extract_id(
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == 2642630)
    assert(walla._extract_id(
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') != 2642631)
    # Test extract_display_id
    assert(walla._extract_display_id(
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == 'one-direction-all-for-one')

# Generated at 2022-06-22 08:52:09.978500
# Unit test for constructor of class WallaIE
def test_WallaIE():
    res = WallaIE()
    assert res.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert res.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert res.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert res.suitable('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True

# Generated at 2022-06-22 08:52:10.830857
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:52:14.542856
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:52:15.201726
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE

# Generated at 2022-06-22 08:52:16.863221
# Unit test for constructor of class WallaIE
def test_WallaIE():
    downloader = InfoExtractor()
    assert WallaIE(downloader)._SUBTITLE_LANGS == {'עברית': 'heb'}



# Generated at 2022-06-22 08:52:19.030104
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE(None)._SUBTITLE_LANGS["עברית"] == 'heb'

# Generated at 2022-06-22 08:52:31.336414
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test constructor of class WallaIE"""
    IE = WallaIE()
    assert(str(IE.__class__) == "<class '__main__.WallaIE'>")
    assert(IE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(IE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:52:40.995543
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('')
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    ie._valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
                  'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    mobj = re.match(ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert mobj.group('id') == '2642630'

# Generated at 2022-06-22 08:52:47.604907
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE()._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-22 08:52:51.558863
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE()
    with open("wallaIE.txt", "w") as text_file:
        for key, value in wallaIE.__dict__.items():
            text_file.write('%s:%s\n' % (key, value))

# Generated at 2022-06-22 08:53:14.583410
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import test_IE
    from .common import _extract_data
    test_IE(_extract_data)

# Generated at 2022-06-22 08:53:22.983249
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import json
    from .common import InfoExtractor
    from .walla import WallaIE
    from .common import fake_http_response

    ie = InfoExtractor()
    ie.add_info_extractor(WallaIE)

    test = WallaIE._TEST

    video_info = ie.extract(test['url'])
    video_info['formats'].sort()
    video_info_str = json.dumps(video_info, sort_keys=True)
    test_str = json.dumps(test, sort_keys=True)
    assert test_str == video_info_str, 'Test output and real output is different'

# Generated at 2022-06-22 08:53:27.358211
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:53:28.763050
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-22 08:53:39.243036
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import InfoExtractor
    # WallaIE - constructor
    # input:
    #        ie - instance of InfoExtractor
    # return:
    #        object - instance of constructor of WallaIE
    ie = InfoExtractor()
    ie_object_WallaIE = WallaIE(ie, {})
    assert(isinstance(ie_object_WallaIE, InfoExtractor))
    # _real_initialize
    # input:
    #        ie_object_WallaIE - constructor of WallaIE
    # return:
    #        None
    ie_object_WallaIE._real_initialize()
    assert(ie_object_WallaIE._downloader is not None)

# Generated at 2022-06-22 08:53:45.564485
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME=='walla', (ie.IE_NAME, ie)
    assert ie.IE_DESC=='Walla.co.il', (ie.IE_DESC, ie)
    assert ie._VALID_URL==r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)', (ie._VALID_URL, ie)
    # don't know how to test the _TEST

# Generated at 2022-06-22 08:53:56.879144
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    class_ = WallaIE
    Obj = class_(url)
    assert Obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert Obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert Obj._TEST['info_dict']['id'] == '2642630'
    assert Obj._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-22 08:53:59.842929
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-22 08:54:02.451559
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-22 08:54:04.211501
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE() 
	ie.__init__()

# Generated at 2022-06-22 08:54:48.739157
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-22 08:54:49.654139
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-22 08:54:51.905764
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    assert(WallaIE is not None)

# Generated at 2022-06-22 08:54:54.198133
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # This test checks if the constructor of the class is working.
    # It should return a non-null value
    assert ie is not None

# Generated at 2022-06-22 08:54:55.701143
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS.get('עברית') == 'heb'

# Generated at 2022-06-22 08:55:00.489981
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.download('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:55:06.656288
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test constructor of class WallaIE"""
    url = 'http://vod.walla.co.il/movie/2642630/one-direcion-all-for-one'
    try:
        extractor = WallaIE()
        WallaIE._download_xml(extractor, url, 'one-direcion-all-for-one')
    except:
        print("constructor test failed")

# Generated at 2022-06-22 08:55:09.719426
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL is not None

# Generated at 2022-06-22 08:55:11.955246
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.download("2642630")

# Generated at 2022-06-22 08:55:16.784681
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.server_encoding() == 'cp1255'
    assert ie.content_type == 'videos'
    assert ie.host() == 'vod.walla.co.il'
    assert ie.url_regex() == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:57:25.816356
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    _, _, video_id, display_id = ie._extract_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert video_id == '2642630'
    assert display_id == 'one-direction-all-for-one'

# Generated at 2022-06-22 08:57:35.460234
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:57:39.250008
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except Exception:
        raise AssertionError('Failed to instantiate WallaIE')

# Generated at 2022-06-22 08:57:43.876000
# Unit test for constructor of class WallaIE
def test_WallaIE():
    cls = WallaIE
    data = { 'url':'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'display_id':'one-direction-all-for-one', 'id':'2642630' }
    inst = cls(data)
    assert inst is not None


# Generated at 2022-06-22 08:57:45.797312
# Unit test for constructor of class WallaIE
def test_WallaIE():
	s = WallaIE()
	assert s.display_id == '2642630'
	assert s.video_id == 'one-direction-all-for-one'

# Generated at 2022-06-22 08:57:46.306362
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()


# Generated at 2022-06-22 08:57:55.874701
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info = WallaIE()._real_extract(WallaIE._TEST['url'])
    assert info['id'] == WallaIE._TEST['info_dict']['id']
    assert info['display_id'] == WallaIE._TEST['info_dict']['display_id']
    assert info['ext'] == WallaIE._TEST['info_dict']['ext']
    assert info['title'] == WallaIE._TEST['info_dict']['title']
    assert info['description'] == WallaIE._TEST['info_dict']['description']
    assert info['thumbnail'] == WallaIE._TEST['info_dict']['thumbnail']
    assert info['duration'] == WallaIE._TEST['info_dict']['duration']

# Generated at 2022-06-22 08:57:56.577450
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-22 08:58:03.686810
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>\.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['id'] == '2642630'
    assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-22 08:58:05.213511
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)