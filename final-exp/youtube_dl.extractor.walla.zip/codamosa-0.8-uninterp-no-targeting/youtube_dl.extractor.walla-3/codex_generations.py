

# Generated at 2022-06-22 08:49:53.252354
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test WallaIE constructor.
    instance = WallaIE()
    assert isinstance(instance, WallaIE)
    

# Generated at 2022-06-22 08:49:55.637418
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'

# Generated at 2022-06-22 08:49:57.433293
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:49:59.507973
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._download_xml('url', None)

# Generated at 2022-06-22 08:50:06.767213
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.host == 'vod.walla.co.il'
    assert ie.video_id == '2642630'
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.params == {'skip_download': True}
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:50:17.833154
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:19.194746
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-22 08:50:21.351223
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:24.859409
# Unit test for constructor of class WallaIE
def test_WallaIE():
    m = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert m._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:26.949582
# Unit test for constructor of class WallaIE
def test_WallaIE():
    videoClient = WallaIE()

# Generated at 2022-06-22 08:50:33.114220
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-22 08:50:37.690299
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url_walla = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    obj_walla = WallaIE()

# Generated at 2022-06-22 08:50:39.051772
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie == WallaIE

# Generated at 2022-06-22 08:50:39.527988
# Unit test for constructor of class WallaIE
def test_WallaIE():
	pass

# Generated at 2022-06-22 08:50:50.723821
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    info_dict = {
        'id': '2642630',
        'display_id': 'one-direction-all-for-one',
        'ext': 'flv',
        'title': 'וואן דיירקשן: ההיסטריה',
        'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        'thumbnail': r're:^https?://.*\.jpg',
        'duration': 3600,
    }
    params = {
        'skip_download': True,
    }

# Generated at 2022-06-22 08:50:54.796753
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor for class WallaIE
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

    # Test name of the class
    assert ie.ie_key() == 'walla'


# Generated at 2022-06-22 08:50:56.775540
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert type(WallaIE.suitable(None)) == bool
    assert WallaIE.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:57.689788
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass



# Generated at 2022-06-22 08:51:01.632079
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.url == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert ie.id == "2642630"
    assert ie.display_id == "one-direction-all-for-one"

# Generated at 2022-06-22 08:51:13.196865
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS.get('עברית') == 'heb'
    assert WallaIE._TEST.keys() == {'url', 'info_dict', 'params'}
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._TEST['info_dict'].keys() == {'id', 'display_id', 'ext', 'title', 'description', 'thumbnail', 'duration'}
    assert WallaIE._TEST['info_dict']['id'] == '2642630'
    assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-22 08:51:25.115956
# Unit test for constructor of class WallaIE
def test_WallaIE():
    VideoIE = WallaIE
    assert(VideoIE.__name__ == "WallaIE")

# Generated at 2022-06-22 08:51:32.618835
# Unit test for constructor of class WallaIE
def test_WallaIE():
    vod = WallaIE()
    assert vod._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert vod._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:51:38.293369
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(WallaIE.ie_key())
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.suitable('http://www.walla.co.il')
    ie.get_url_info(WallaIE._VALID_URL)

# Generated at 2022-06-22 08:51:41.121017
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class_ = WallaIE
    instance = class_('rtmp://wafla.walla.co.il/vod')
    assert isinstance(instance, WallaIE)

# Generated at 2022-06-22 08:51:41.651948
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:51:45.534171
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE(url)
    assert ie.url == url
    assert ie.valid_url == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-22 08:51:46.284464
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()



# Generated at 2022-06-22 08:51:48.737585
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.name == 'Walla!'
    assert ie.supported_ie

# Generated at 2022-06-22 08:51:49.596530
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:51:52.192364
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.class_name() == 'WallaIE'
    assert ie.ie_key() == 'walla'

# Generated at 2022-06-22 08:52:22.381689
# Unit test for constructor of class WallaIE

# Generated at 2022-06-22 08:52:24.192600
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_obj = WallaIE()
    assert test_obj != None, "Unexpected constructor return"

# Generated at 2022-06-22 08:52:25.953884
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructor test
    ie = WallaIE()
    assert ie.SUCCESS == 200

# Generated at 2022-06-22 08:52:29.281445
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE()
    assert i.ie_key() == "WallaIE"
    assert i.info_dict()["name"] == "WallaIE"

# Generated at 2022-06-22 08:52:39.610096
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    a =  WallaIE()
    r = a.extract(url)
    assert r['id'] == '2642630'
    assert r['display_id'] == 'one-direction-all-for-one'
    assert r['ext'] == 'flv'
    assert r['title'] == 'וואן דיירקשן: ההיסטריה'
    assert r['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert r['thumbnail'] == 're:^https?://.*\.jpg'
    assert r['duration'] == 3600
   

# Generated at 2022-06-22 08:52:43.492209
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:52:46.114706
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-22 08:52:48.207014
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-22 08:52:58.279086
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:53:08.921764
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:53:55.617680
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'


# Generated at 2022-06-22 08:53:59.711294
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE().suitable(test_url)


# Generated at 2022-06-22 08:54:00.616667
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE()

# Generated at 2022-06-22 08:54:11.137745
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("test", "")
    assert ie.SUCCESS_PATTERN == r'><iframe.*?src="(?P<url>.*?)"'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:54:18.055220
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    dir(wallaIE)

# Generated at 2022-06-22 08:54:27.549520
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(ie._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')

    metadata_url = 'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id
    video = ie._download_xml(metadata_url, display_id)
    item = video.find('./items/item')
    title = xpath_text(item, './title', 'title')


# Generated at 2022-06-22 08:54:30.692414
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-22 08:54:32.008421
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.subtitle_langs == ['heb']

# Generated at 2022-06-22 08:54:34.166735
# Unit test for constructor of class WallaIE
def test_WallaIE():

    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)

    assert ie is not None
    assert repr(ie) == "<WallaIE(%s)>" % url



# Generated at 2022-06-22 08:54:36.751910
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one");

# Generated at 2022-06-22 08:56:17.897001
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:56:21.300617
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:56:21.779843
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:56:23.952142
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-22 08:56:32.237338
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.video_id_re() == re.compile(r'^\d+$')
    assert re.match(ie.video_id_re(), ie.video_id('http://www.walla.co.il/?w=/1/26/2687648'))
    assert ie.valid_url('http://vod.walla.co.il/movie/2687648/%D7%93%D7%95%D7%9C%D7%A4%D7%A2%D7%A8%D7%99-%D7%91%D7%9C%D7%91%D7%A8%D7%95%D7%9C')

# Generated at 2022-06-22 08:56:39.447718
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(" ")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)', "Test that ie is instance of WallaIE"
    assert ie._TEST is not None, "Test that ie has _TEST"
    assert ie._SUBTITLE_LANGS is not None, "Test that ie has _SUBTITLE_LANGS"
    assert ie.IE_NAME == 'walla', "Test that ie is instance of InfoExtractor"


# Generated at 2022-06-22 08:56:39.997642
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-22 08:56:40.626470
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:56:41.536105
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE is not None

# Generated at 2022-06-22 08:56:51.645363
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Arrange
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    # Act
    ie = WallaIE()

    # Assert
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST[u'url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST[u'info_dict'][u'id'] == '2642630'