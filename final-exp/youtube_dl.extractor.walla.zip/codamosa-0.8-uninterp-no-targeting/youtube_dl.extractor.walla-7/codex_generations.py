

# Generated at 2022-06-22 08:49:48.970980
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-22 08:49:54.195779
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('vod.walla.co.il', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:49:55.742679
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE()
    assert(i)

# Generated at 2022-06-22 08:49:58.666885
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE.test();

if __name__ == '__main__':
    test_WallaIE();

# Generated at 2022-06-22 08:50:00.263456
# Unit test for constructor of class WallaIE
def test_WallaIE(): # pragma: no cover
    assert WallaIE(WallaIE._VALID_URL).get_info('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:01.023517
# Unit test for constructor of class WallaIE
def test_WallaIE():
    raise Exception("Can't create unit test for %s" % (WallaIE))

# Generated at 2022-06-22 08:50:03.333515
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.url = "http://vod.walla.co.il/item/2642630"
    ie.extract()

# Generated at 2022-06-22 08:50:05.151122
# Unit test for constructor of class WallaIE
def test_WallaIE():
  IE = WallaIE()
  assert isinstance(IE, InfoExtractor)


# Generated at 2022-06-22 08:50:05.859479
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-22 08:50:17.102941
# Unit test for constructor of class WallaIE
def test_WallaIE():
	import unittest
	# import re matching URL validation
	# import logging to print errors
	import logging
	# import json to test definition of format_dict 
	import json
	# import sys to get program arguments
	import sys

	class test_WallaIE(unittest.TestCase):
		def setUp(self):
			self.ie = WallaIE()

		def test_constructor(self):
			self.assertTrue(re.match(self.ie._VALID_URL, self.ie._TEST['url']))
			self.assertEqual(self.ie._TEST['info_dict']['id'], self.ie._TEST['url'].split('/')[-2])

# Generated at 2022-06-22 08:50:23.122859
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(WallaIE._TEST)

# Generated at 2022-06-22 08:50:27.592216
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from . import WallaIE
    assert(WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is not None)

# Generated at 2022-06-22 08:50:33.604883
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(WallaIE._VALID_URL, url)

    assert mobj.group('id') == '2642630'
    assert mobj.group('display_id') == 'one-direction-all-for-one'

    ie = WallaIE(url) # test constructor
    assert ie._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-22 08:50:35.029618
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:45.070913
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    obj = WallaIE()
    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:49.232403
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Test that WallaIE is a subclass of InfoExtractor
	w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
	assert isinstance(w, InfoExtractor)

# Generated at 2022-06-22 08:50:53.679434
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # simple case
    ie = WallaIE(WallaIE._VALID_URL, {}, download_webpage_handle)
    assert(ie._match_id)

    # no match
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one1', {}, download_webpage_handle)
    assert(not ie._match_id)

# Generated at 2022-06-22 08:50:54.403794
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE().test()

# Generated at 2022-06-22 08:50:57.342838
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()

# Generated at 2022-06-22 08:50:59.473452
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    ie.set_property('subtitle_langs', {
        'עברית': 'heb',
    })

# Generated at 2022-06-22 08:51:14.686301
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:51:23.948542
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import inspect
    import sys
    import os
    import unittest

    class TestWallaIE(unittest.TestCase):
        def get_constructor_args(self, o):
            return inspect.getargspec(o.__init__).args

        def test_constructor(self):
            args = self.get_constructor_args(WallaIE)

            self.assertEqual(args, ['self'])

    suite = unittest.TestLoader().loadTestsFromTestCase(TestWallaIE)
    result = unittest.TextTestRunner(verbosity=1).run(suite)

    if result.errors or result.failures:
        sys.exit(1)

# Generated at 2022-06-22 08:51:28.163001
# Unit test for constructor of class WallaIE
def test_WallaIE():
	vod = WallaIE()

	assert vod.get_title('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-22 08:51:30.469842
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:51:31.918944
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert('WallaIE' in ie.NAME)

# Generated at 2022-06-22 08:51:34.813245
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:51:46.368459
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:51:47.536310
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w is not None

# Generated at 2022-06-22 08:51:49.189132
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie._TEST == WallaIE._TEST

# Generated at 2022-06-22 08:51:55.872035
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert walla_ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert walla_ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    print("TEST PASSED")

# Generated at 2022-06-22 08:52:20.077502
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Unit test for constructor of class WallaIE
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    theWallaIE = WallaIE()
    result = WallaIE._real_extract(theWallaIE, url)

# Generated at 2022-06-22 08:52:25.414552
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:52:26.761967
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-22 08:52:38.108922
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:52:50.503764
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_class = WallaIE()
    assert test_class._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:52:56.106693
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'
    

# Generated at 2022-06-22 08:52:58.271354
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie.ie_codec() == 'walla'

# Generated at 2022-06-22 08:53:03.979847
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.name == 'Walla'
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:53:05.698718
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None, None)._SUBTITLE_LANGS


# Generated at 2022-06-22 08:53:06.529308
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-22 08:53:50.498525
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:54:01.927729
# Unit test for constructor of class WallaIE

# Generated at 2022-06-22 08:54:06.123570
# Unit test for constructor of class WallaIE
def test_WallaIE():
	url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one';
	assert ('one-direction-all-for-one' == WallaIE._VALID_URL('2642630',url));


# Generated at 2022-06-22 08:54:12.423734
# Unit test for constructor of class WallaIE
def test_WallaIE():
    for url in (WallaIE._VALID_URL,):
        print("Testing URL: " + url)
        assert WallaIE._VALID_URL == (
            r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-22 08:54:14.252876
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:54:18.160797
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__.__name__ == 'WallaIE'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:54:19.772755
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Test constructor of WallaIE
    obj = WallaIE()

    assert obj is not None



# Generated at 2022-06-22 08:54:28.714632
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Test case 1:
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    _, ext = ie._get_id_and_ext(url)
    # Test case 2:
    url = 'http://vod.walla.co.il/person/2642630/one-direction-all-for-one'
    _, ext = ie._get_id_and_ext(url)
    # Test case 3:
    url = 'http://vod.walla.co.il/category/2642630/one-direction-all-for-one'
    _, ext = ie._get_id_and_ext(url)

# Generated at 2022-06-22 08:54:32.752120
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST == WallaIE._TEST



# Generated at 2022-06-22 08:54:35.827162
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert isinstance(obj, InfoExtractor)
    assert obj.IE_DESC == 'walla.co.il'


# Generated at 2022-06-22 08:56:17.896585
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'http://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-22 08:56:20.329028
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie



# Generated at 2022-06-22 08:56:21.021887
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-22 08:56:24.071165
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:56:25.461890
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-22 08:56:26.038983
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE()

# Generated at 2022-06-22 08:56:33.373613
# Unit test for constructor of class WallaIE
def test_WallaIE():
    unit = WallaIE()
    assert unit._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:56:35.585841
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()
    assert wie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-22 08:56:39.466168
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test WallaIE constructor"""
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:56:40.823005
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('WallaIE')
    walla_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie.extract_video_info(walla_url)