

# Generated at 2022-06-22 08:49:56.308615
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:02.497760
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == { 'עברית': 'heb' }


# Generated at 2022-06-22 08:50:04.295350
# Unit test for constructor of class WallaIE
def test_WallaIE():
    result = WallaIE()

# Generated at 2022-06-22 08:50:07.840889
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.get_method() == 'GET'
    assert ie.get_url_components() == ''


# Generated at 2022-06-22 08:50:08.477765
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-22 08:50:15.075005
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.IE_NAME == 'Walla'
    assert ie.VALID_URL == ie._VALID_URL
    assert ie.URL_TEMPLATE == 'http://vod.walla.co.il/movie/%s/%s'

# Generated at 2022-06-22 08:50:17.071912
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-22 08:50:18.134616
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()



# Generated at 2022-06-22 08:50:24.558097
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.ie_key() == 'Walla'
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Unit tests for all functions in class WallaIE

# Generated at 2022-06-22 08:50:35.727928
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert obj._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert obj._TEST['info_dict']['id'] == "2642630"
    assert obj._TEST['info_dict']['display_id'] == "one-direction-all-for-one"
    assert obj._TEST['info_dict']['ext'] == "flv"
   

# Generated at 2022-06-22 08:50:41.340147
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == "WallaIE"

# Generated at 2022-06-22 08:50:44.261300
# Unit test for constructor of class WallaIE
def test_WallaIE():
    temp = WallaIE()
    assert re.match(temp._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert temp._download_xml('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl', 'one-direction-all-for-one')

# Generated at 2022-06-22 08:50:49.573063
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:50.860956
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Tested in _real_extract()
    pass

# Generated at 2022-06-22 08:51:00.587090
# Unit test for constructor of class WallaIE
def test_WallaIE():
    videoUrl = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    videoId = '2642630'
    videoDisplayId = 'one-direction-all-for-one'
    infoDict = {
        'id': '2642630',
        'display_id': 'one-direction-all-for-one',
        'ext': 'flv',
        'title': 'וואן דיירקשן: ההיסטריה',
        'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        'thumbnail': r're:^https?://.*\.jpg',
        'duration': 3600,
    }
    extractor

# Generated at 2022-06-22 08:51:02.699173
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:51:14.085963
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("url")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-22 08:51:16.121917
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("vod.walla.co.il")


# Generated at 2022-06-22 08:51:20.825086
# Unit test for constructor of class WallaIE

# Generated at 2022-06-22 08:51:27.442877
# Unit test for constructor of class WallaIE
def test_WallaIE():
  eg_url="http://vod.walla.co.il/movie/2751289/star-wars-episode-vii-the-force-awakens"
  w = WallaIE(eg_url)
  assert w.url == eg_url
  assert w.display_id == "star-wars-episode-vii-the-force-awakens"
  assert w.video_id == "2751289"


# Generated at 2022-06-22 08:51:40.389665
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()
    assert t is not None
    assert t.get_url_regex() == WallaIE._VALID_URL


# Generated at 2022-06-22 08:51:43.234950
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:51:44.577870
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.SUCCESS == True

# Generated at 2022-06-22 08:51:46.101999
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.name == 'Walla!'

# Generated at 2022-06-22 08:51:48.948012
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:51:53.509989
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS == {
        'עברית': 'heb'
    }
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:52:02.381238
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://www.walla.com/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:52:03.427005
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video = WallaIE()
# test_WallaIE()

# Generated at 2022-06-22 08:52:10.332079
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:52:13.353081
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL



# Generated at 2022-06-22 08:52:41.977985
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:52:44.605221
# Unit test for constructor of class WallaIE
def test_WallaIE(): 
    video = WallaIE("url")
    assert(type(video) == WallaIE)

# Generated at 2022-06-22 08:52:48.132060
# Unit test for constructor of class WallaIE
def test_WallaIE():
	wallaIE = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one", "Test Class WallaIE")


# Generated at 2022-06-22 08:52:58.242651
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().IE_NAME == 'walla'
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE().SUBTITLE_LANGS == {'עברית': 'heb',}
    assert WallaIE()._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE()._TEST['info_dict']['id'] == '2642630'
    assert WallaIE()._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert Wall

# Generated at 2022-06-22 08:52:59.968323
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(WallaIE.ie_key())._SUBTITLE_LANGS is not None

# Generated at 2022-06-22 08:53:02.436601
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "https://vod.walla.co.il/item/2642630"
    module = WallaIE()
    assert module.suitable(url)


# Generated at 2022-06-22 08:53:06.630943
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)
    assert isinstance(ie, InfoExtractor)
    assert hasattr(ie, "_SUBTITLE_LANGS")
    assert hasattr(ie, "_VALID_URL")

# Generated at 2022-06-22 08:53:17.185317
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:53:18.230381
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()


# Generated at 2022-06-22 08:53:21.159695
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instantiatable = (c for c in globals().values() if getattr(c, 'suitable', False) and not getattr(c, 'ie_key', False))
    for ie in instantiatable:
        ie()

# Generated at 2022-06-22 08:54:08.594973
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:54:16.998643
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    result = ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert result['id'] == '2642630'
    assert result['display_id'] == 'one-direction-all-for-one'
    assert result['title'] == 'וואן דיירקשן: ההיסטריה'
    assert result['thumbnail'] == 'http://images1.walla.co.il/images/1337007/big.jpg'
    assert result['duration'] == 3600

# Generated at 2022-06-22 08:54:19.507003
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # check if WallaIE is instantiated.
    ie = WallaIE()
    assert ie is not None, "WallaIE is not instantiated"

# Generated at 2022-06-22 08:54:25.066679
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test: get name of the class
    class_name = WallaIE.__name__
    assert class_name == 'WallaIE'

    # Test: instance of the class
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(obj, WallaIE)

# Generated at 2022-06-22 08:54:27.327494
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test case where the constructor is called without an argument
    WallaIE()
    # Test case where the constructor is called with an argument
    WallaIE('dummy')


# Generated at 2022-06-22 08:54:30.494842
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie



# Generated at 2022-06-22 08:54:39.369627
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert re.match("http://vod.walla.co.il/[^/]+/\d+/[^/]+$", ie.VALID_URL)

# Generated at 2022-06-22 08:54:42.825590
# Unit test for constructor of class WallaIE
def test_WallaIE():
    c = WallaIE()
    c.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:54:47.299687
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructor of WallaIE class
    obj = WallaIE()
    # Assert 1:
    assert obj._SUBTITLE_LANGS == {
        'עברית': 'heb'
    }
    # Assert 2:
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:54:55.703176
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import unittest.mock

# Generated at 2022-06-22 08:56:44.903378
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import WallaIE as test_unit

# Generated at 2022-06-22 08:56:49.625591
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test for constructor of class WallaIE
    """
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    assert(w._VALID_URL.match(url))
    assert(w.ie_key() == 'Walla')

# Generated at 2022-06-22 08:56:53.802840
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-22 08:56:54.939707
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == 'WallaIE'

# Generated at 2022-06-22 08:56:55.847439
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE(None).download_webpage(None, {})

# Generated at 2022-06-22 08:56:57.387761
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-22 08:56:58.058282
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-22 08:56:58.653205
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:57:00.881530
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    # Test = Test for class WallaIE
    w.test(WallaIE._TEST)

# Generated at 2022-06-22 08:57:04.882980
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Arrange
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    # Act
    ie = WallaIE(test_url)

    # Assert
    assert ie != None
