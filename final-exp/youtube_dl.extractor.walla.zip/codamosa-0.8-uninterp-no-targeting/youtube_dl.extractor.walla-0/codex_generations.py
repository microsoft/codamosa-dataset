

# Generated at 2022-06-22 08:49:55.632193
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:00.114914
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:02.196031
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:06.954399
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # instantiate class
    ie = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # check if there is no exception
    ie.extract(url)
    pass

# Generated at 2022-06-22 08:50:13.158925
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:23.786636
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:30.084357
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Description:
        Test the constructor of class WallaIE
    """
    url = 'vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    if ie:
        return True
    else:
        return False


# Generated at 2022-06-22 08:50:32.788659
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(url)
    assert_true(True)

# Generated at 2022-06-22 08:50:36.932006
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-22 08:50:38.302505
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _ = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:50:53.882001
# Unit test for constructor of class WallaIE
def test_WallaIE():
	test_url   = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	test_video = WallaIE()
	test_video.url = test_url
	assert test_video.url == test_url
	return True

# Generated at 2022-06-22 08:51:00.029029
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test with a single non-empty format
    video = WallaIE()._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert video["id"] == '2642630'
    assert video["title"] == 'וואן דיירקשן: ההיסטריה'
    assert video["description"] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert video["thumbnail"] == r're:^https?://.*\.jpg'
    assert video["duration"] == 3600
    f = video["formats"][0]

# Generated at 2022-06-22 08:51:05.097539
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    video = ie.extract(url)

# Generated at 2022-06-22 08:51:05.737957
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-22 08:51:06.436248
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-22 08:51:18.639920
# Unit test for constructor of class WallaIE

# Generated at 2022-06-22 08:51:23.344992
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie=WallaIE()
    ie.extract(url)

# Generated at 2022-06-22 08:51:26.570507
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    """
    extractor = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert extractor

# Generated at 2022-06-22 08:51:27.485428
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:51:29.668548
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-22 08:51:41.322680
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(isinstance(WallaIE(), WallaIE))

# Generated at 2022-06-22 08:51:43.133885
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Simplest test : testing whether WallaIE class is initiating or not
    assert WallaIE, 'WallaIE class failed initiating.'

# Generated at 2022-06-22 08:51:45.045799
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL is not None
    assert obj._downloader is not None

# Generated at 2022-06-22 08:51:45.473691
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-22 08:51:49.268623
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global WallaIE
    ie = WallaIE()
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:51:49.953001
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:51:57.333657
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()
	ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:52:03.954192
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test constructor
    video = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert video.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert video.video_id == '2642630'
    assert video.display_id == 'one-direction-all-for-one'

# Generated at 2022-06-22 08:52:06.955278
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:52:07.710844
# Unit test for constructor of class WallaIE
def test_WallaIE():
    e = WallaIE()

# Generated at 2022-06-22 08:52:36.324748
# Unit test for constructor of class WallaIE
def test_WallaIE():
    field_map = {
        '_VALID_URL': WallaIE._VALID_URL,
        '_downloader': InfoExtractor._downloader,
        '_SUBTITLE_LANGS': WallaIE._SUBTITLE_LANGS,
    }
    for key in field_map:
        if not hasattr(WallaIE, key):
            print('Test failed ' + key + ' is missing')
            return False
    return True

if __name__ == "__main__":
    if test_WallaIE():
        print('Success: All tests are passed')

# Generated at 2022-06-22 08:52:38.739703
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # the extractor should be able to download, it is not a bug if it fails
    ie.download(_TEST['url'])

# Generated at 2022-06-22 08:52:39.325305
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-22 08:52:41.194521
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    # Subtitles
    ie._SUBTITLE_LANGS


# Generated at 2022-06-22 08:52:43.141649
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:52:54.254025
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}
    #TODO get TEST to work
    #assert ie._TEST == {'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
    #'info_dict': {'id': '2642630', 'display_id': 'one-direction-all-for-one', 'ext': 'flv', 'title': 'וואן דיירקשן: הה

# Generated at 2022-06-22 08:52:57.875900
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test creates a WallaIE object
    test = WallaIE()
    # Test tries to extract some info from a link, but doesn't download anything
    test.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:52:58.668836
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print(WallaIE()._VALID_URL)

# Generated at 2022-06-22 08:53:03.563031
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    except:
        raise AssertionError('Unit test for WallaIE class constructor failed')


# Generated at 2022-06-22 08:53:05.808877
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:53:56.534118
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.download('2642630')

# Generated at 2022-06-22 08:54:02.347732
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:54:04.461430
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert re.match(WallaIE._VALID_URL, ie._TEST['url'])

# Generated at 2022-06-22 08:54:09.598781
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-22 08:54:12.803429
# Unit test for constructor of class WallaIE
def test_WallaIE():
    oIE = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert oIE.__class__.__name__ == 'WallaIE'

# Generated at 2022-06-22 08:54:17.990049
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ('vod.walla.co.il', '2642630', 'וואן דיירקשן: ההיסטריה') == ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:54:20.931476
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:54:24.284069
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert isinstance (ie, InfoExtractor)
    assert isinstance (ie, WallaIE)

# Generated at 2022-06-22 08:54:25.412723
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-22 08:54:26.093829
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-22 08:56:23.246743
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'
   

# Generated at 2022-06-22 08:56:25.351088
# Unit test for constructor of class WallaIE
def test_WallaIE():   
    obj = WallaIE()
    assert obj._VALID_URL is not None
    

# Generated at 2022-06-22 08:56:32.860527
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ydl = WallaIE()
    assert ydl._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:56:37.930881
# Unit test for constructor of class WallaIE
def test_WallaIE():
    res = WallaIE()._real_extract(WallaIE._TEST['url'])
    assert res['id'] == WallaIE._TEST['info_dict']['id']
    assert res['display_id'] == WallaIE._TEST['info_dict']['display_id']
    assert res['ext'] == WallaIE._TEST['info_dict']['ext']
    assert res['title'] == WallaIE._TEST['info_dict']['title']
    assert res['description'] == WallaIE._TEST['info_dict']['description']
    assert res['duration'] == WallaIE._TEST['info_dict']['duration']

# Generated at 2022-06-22 08:56:38.426656
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE("","")


# Generated at 2022-06-22 08:56:41.450750
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_WallaIE = WallaIE()
    class_name = test_WallaIE.__class__.__name__
    assert class_name == 'WallaIE' , 'the class name should be WallaIE'


# Generated at 2022-06-22 08:56:42.754658
# Unit test for constructor of class WallaIE
def test_WallaIE():
    const = WallaIE()


# Generated at 2022-06-22 08:56:48.415739
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test_WallaIE = WallaIE()
    if test_WallaIE._real_extract(url):
        print('Constructor of class WallaIE is OK')
    else:
        print('Constructor of class WallaIE is wrong')


# Generated at 2022-06-22 08:56:50.413449
# Unit test for constructor of class WallaIE
def test_WallaIE():
    if __name__ == "__main__":
        from .test_suite import run_test
        run_test(WallaIE, 'walla')

# Generated at 2022-06-22 08:57:00.202542
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .walla import WallaIE
    x = WallaIE()
    assert x.id == 'walla'
    assert x.format_id == 'walla'
    assert x.ext == 'walla'
    assert x.format == 'walla'
    assert x.url == 'walla'
    assert x.player_url == 'walla'
    assert x.page_url == 'walla'
    assert x.display_id == 'walla'
    assert x.width == 'walla'
    assert x.height == 'walla'
    assert x.tbr == 'walla'
    assert x.fps == 'walla'
    assert x.vcodec == 'walla'
    assert x.acodec == 'walla'
    assert x.container == 'walla'
    assert x