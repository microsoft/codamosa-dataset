

# Generated at 2022-06-22 08:49:59.651235
# Unit test for constructor of class WallaIE
def test_WallaIE():
	obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', {})
	assert obj.ie_key() == 'walla'
	assert obj.ie_url() == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:00.272065
# Unit test for constructor of class WallaIE
def test_WallaIE():
   WallaIE()

# Generated at 2022-06-22 08:50:01.093536
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-22 08:50:02.369463
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:50:11.579345
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:16.137941
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL


if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-22 08:50:18.413940
# Unit test for constructor of class WallaIE
def test_WallaIE():

	wallaIE = WallaIE('walla', 'walla.co.il', 'walla')
	assert wallaIE.suitable('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
	assert wallaIE.suitable('https://www.youtube.com/watch?v=CgVl0vr1C-8') == False

# Generated at 2022-06-22 08:50:20.368822
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-22 08:50:22.835000
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE(None)._extract_info(
        WallaIE._TEST.get('url'),
        WallaIE._TEST.get('info_dict')
    )

# Generated at 2022-06-22 08:50:23.819878
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-22 08:50:38.038023
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url="http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE()
    ie.extract(url)

# Generated at 2022-06-22 08:50:42.977909
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract('http://vod.walla.co.il/movie/2642773/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:53.623625
# Unit test for constructor of class WallaIE
def test_WallaIE():
    returns = WallaIE()._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert returns['id'] == '2642630'
    assert returns['display_id'] == 'one-direction-all-for-one'
    assert returns['url'] == 'rtmp://wafla.walla.co.il/vod'
    assert len(returns['formats']) == 3
    assert returns['formats'][0]['format_id'] == '1080p'
    assert returns['formats'][0]['height'] == 1080
    assert returns['formats'][1]['format_id'] == '720p'
    assert returns['formats'][1]['height'] == 720

# Generated at 2022-06-22 08:50:55.445237
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS)

# Generated at 2022-06-22 08:50:56.850765
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == "walla"

# Generated at 2022-06-22 08:50:57.764298
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:50:58.556390
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla

# Generated at 2022-06-22 08:50:59.608491
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# test constructor
	test_IE = WallaIE
	assert type(test_IE) is type

# Generated at 2022-06-22 08:51:00.410219
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:51:04.855826
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.ie_key() == 'Walla')
    assert(ie.ie_name() == 'Walla')
    assert(ie.supported_extractors() == ['Walla'])

# Generated at 2022-06-22 08:51:27.400921
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test constructor of class WallaIE"""
    assert WallaIE

# Generated at 2022-06-22 08:51:29.631294
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:51:30.842191
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert x

# Generated at 2022-06-22 08:51:36.572417
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    assert(isinstance(ie, InfoExtractor))
    assert(ie.ie_key() == 'Walla')
    assert(ie.ie_key() != 'walla')
    assert(ie.ie_key() != 'walla.co.il')


# Generated at 2022-06-22 08:51:38.071016
# Unit test for constructor of class WallaIE
def test_WallaIE():
	w = WallaIE()


# Generated at 2022-06-22 08:51:41.322914
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video = WallaIE()._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert video['id'] == '2642630'

# Generated at 2022-06-22 08:51:52.667838
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.initialize()
    res = ie._real_extract(url)
    assert res['id'] == '2642630'
    assert res['display_id'] == 'one-direction-all-for-one'
    assert res['ext'] == 'flv'
    assert res['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-22 08:51:54.393241
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE()

# Generated at 2022-06-22 08:51:56.860726
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:51:57.982120
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for constructor of class WallaIE"""
    return WallaIE()

# Generated at 2022-06-22 08:52:22.279142
# Unit test for constructor of class WallaIE
def test_WallaIE():
	try:
		WallaIE()
	except:
		assert False
	assert True

# Generated at 2022-06-22 08:52:33.808484
# Unit test for constructor of class WallaIE

# Generated at 2022-06-22 08:52:34.828028
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Unit test for constructor of WallaIE
    w = WallaIE
    w._real_extract(w._TEST['url'])

# Generated at 2022-06-22 08:52:39.881913
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.suitable('http://vod.walla.co.il/ls/2642177/one-direction-all-for-one/videos')
    return

# Generated at 2022-06-22 08:52:41.141831
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().ie_key() == 'walla'


# Generated at 2022-06-22 08:52:51.559458
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.http.request(
        "http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl")
    # Test if metadata of the video is parsed successfully
    assert ie._download_xml(
        "http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl", "one-direction-all-for-one").find(
        "./items/item/title").text == "וואן דיירקשן: ההיסטריה"

# Generated at 2022-06-22 08:53:01.862627
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one") is True
    assert ie.suitable("rtmp://wafla.walla.co.il/mp4:vod/2642630.mp4") is False

# Generated at 2022-06-22 08:53:02.438633
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE

# Generated at 2022-06-22 08:53:03.646110
# Unit test for constructor of class WallaIE
def test_WallaIE():
        # Instantiating test object of class WallaIE
        ie = WallaIE()

# Generated at 2022-06-22 08:53:14.523558
# Unit test for constructor of class WallaIE
def test_WallaIE():
    minstance = WallaIE()
    assert minstance._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:54:04.332775
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()


# Generated at 2022-06-22 08:54:09.495059
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    assert(ie.IE_NAME == 'walla')
    assert(ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(ie._SUBTITLE_LANGS == {
        'עברית': 'heb',
    })

# Generated at 2022-06-22 08:54:11.573513
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://www.walla.co.il")
    assert ie is not None, "Called constructor with wrong parameters"

# Generated at 2022-06-22 08:54:13.864178
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:54:15.501679
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()
    assert wie != None
    assert wie.ie_key() == 'Walla'

# Generated at 2022-06-22 08:54:25.608236
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:54:33.864895
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    mobj = re.match(ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert mobj != None
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    assert video_id == '2642630'
    assert display_id == 'one-direction-all-for-one'

# Generated at 2022-06-22 08:54:35.498885
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:54:39.366244
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()
	ie.extract(WallaIE._TEST['url'])


# Generated at 2022-06-22 08:54:40.290365
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('WallaIE')

# Generated at 2022-06-22 08:56:31.988709
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(WallaIE(None), InfoExtractor)

# Generated at 2022-06-22 08:56:33.112729
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Just to make sure we can instantiate the class
    w = WallaIE()
    assert w is not None

# Generated at 2022-06-22 08:56:35.365038
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-22 08:56:40.662293
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Test extracting the video ID from a URL
    mobj = re.match(WallaIE._VALID_URL, WallaIE._TEST['url'])
    assert ie.videoID(WallaIE._TEST['url']) == mobj.group('id')
    # Test extracting the display ID from a URL
    assert ie.displayID(WallaIE._TEST['url']) == mobj.group('display_id')

# Generated at 2022-06-22 08:56:42.082481
# Unit test for constructor of class WallaIE
def test_WallaIE():
    result = WallaIE("url")
    assert type(result) is WallaIE


# Generated at 2022-06-22 08:56:47.169091
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    # Check if the regex matches
    m = re.match(w._VALID_URL, url)
    if not m:
        raise AssertionError("The URL shouldn't match")

# Generated at 2022-06-22 08:56:51.279424
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one', {})

# Generated at 2022-06-22 08:56:51.933002
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:56:54.826010
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE(None)
    except NameError as ex:
        assert False, "Unexpected error on initialization of class WallaIE"
    else:
        assert True

# Generated at 2022-06-22 08:56:57.450549
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
