

# Generated at 2022-06-22 08:49:50.085349
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-22 08:49:52.521611
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.constructor_test_suite()

# Generated at 2022-06-22 08:49:58.146000
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    assert i.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'


# Generated at 2022-06-22 08:49:59.456978
# Unit test for constructor of class WallaIE
def test_WallaIE():
        pass

# Generated at 2022-06-22 08:50:07.050769
# Unit test for constructor of class WallaIE
def test_WallaIE():
    extractor = WallaIE()
    assert extractor._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:10.860211
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:12.840085
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # If this fails, the class WallaIE failed to initialize
    assert ie is not None

# Generated at 2022-06-22 08:50:13.928859
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-22 08:50:16.997336
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    ie = WallaIE()
    ie._real_extract(url)

# Generated at 2022-06-22 08:50:27.922275
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    mobj = re.match(walla._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')

    video = walla._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id)

    item = video.find('./items/item')

    title = xpath_text(item, './title', 'title')
    description = xpath_text(item, './synopsis', 'description')

# Generated at 2022-06-22 08:50:43.977428
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:51.802456
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    expected = '2642630'
    expected2 = 'one-direction-all-for-one'
    mobj = re.match(WallaIE._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    actual = video_id
    actual2 = display_id

# Generated at 2022-06-22 08:50:52.982576
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-22 08:50:57.231773
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one", "")
    assert wallaIE.url == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-22 08:51:00.468339
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.ie_key() == 'Walla', ie.ie_key()
    assert ie.url_result("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Test for _real_extract of WallaIE

# Generated at 2022-06-22 08:51:06.013525
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video = WallaIE()

# Generated at 2022-06-22 08:51:08.577430
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert(ie is not None)

# Generated at 2022-06-22 08:51:11.229997
# Unit test for constructor of class WallaIE
def test_WallaIE():
    extractor = WallaIE()
    assert extractor.extractor_key() == 'Walla'
    assert extractor.ie_key() == 'walla'
    assert extractor.suitable(WallaIE._VALID_URL)

# Generated at 2022-06-22 08:51:19.762845
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:51:21.180911
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:51:40.603478
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = r'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    x = ie.suitable(url)
    assert(x) # should be True
    x = ie.extract(url)
    assert(x['id'] == '2642630')
    assert(x['display_id'] == 'one-direction-all-for-one')
    assert(x['title'] == 'וואן דיירקשן: ההיסטריה')

# Generated at 2022-06-22 08:51:41.422910
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-22 08:51:42.316721
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import WallaIE
    WallaIE()

# Generated at 2022-06-22 08:51:43.440645
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj is not None

# Generated at 2022-06-22 08:51:46.680130
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-22 08:51:50.416303
# Unit test for constructor of class WallaIE
def test_WallaIE():
    us = WallaIE()
    assert isinstance(us, InfoExtractor), "Is WallaIE not an instance of InfoExtractor?"
    assert isinstance(us.suitable(WallaIE._VALID_URL), bool)

# Generated at 2022-06-22 08:51:54.832465
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:51:57.683367
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ieObj = WallaIE()
    # If there's a problem with the constructor, it will throw an exception
    print("Test succeeded. Constructor of class WallaIE (#%s) ran without a problem." % ieObj)

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-22 08:52:03.066738
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:52:03.780968
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-22 08:52:36.417321
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:52:38.281484
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert Fixtures.ID == WallaIE(Fixtures.url)._VALID_URL


# Generated at 2022-06-22 08:52:50.723903
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)
    assert not hasattr(ie, '_login_form')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:53:01.720414
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:53:09.360231
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _test_example_url = WallaIE._TEST.get('url')
    _test_example_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    e = WallaIE(WallaIE._SUBTITLE_LANGS)._real_extract(_test_example_url)

# Generated at 2022-06-22 08:53:09.809628
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:53:14.325308
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.url == ie._VALID_URL

# Generated at 2022-06-22 08:53:24.563614
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE.
    """
    ie = WallaIE()
    ie_instance = ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie_instance
    assert ie_instance['id'] == '2642630'
    assert ie_instance['display_id'] == 'one-direction-all-for-one'
    assert ie_instance['ext'] == 'flv'
    assert ie_instance['title'] == 'וואן דיירקשן: ההיסטריה'
    assert ie_instance['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert ie

# Generated at 2022-06-22 08:53:35.833566
# Unit test for constructor of class WallaIE
def test_WallaIE():
	obj = WallaIE()
	assert obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	assert obj._TEST['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'
	assert obj._TEST['info_dict']['duration'] == 3600
	assert obj._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
	assert obj._TEST['info_dict']['id'] == '2642630'
	assert obj._TEST['params']['skip_download'] == True

# Generated at 2022-06-22 08:53:36.860854
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert isinstance(WallaIE({}), InfoExtractor)

# Generated at 2022-06-22 08:54:27.916993
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE('Walla', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one').display_id == 'one-direction-all-for-one')

# Generated at 2022-06-22 08:54:38.981581
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(WallaIE.ie_key())._VALID_URL.startswith('https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert WallaIE(WallaIE.ie_key())._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:54:42.566970
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL.match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-22 08:54:44.817573
# Unit test for constructor of class WallaIE
def test_WallaIE():
    values = {}
    test_class = WallaIE(values)
    assert test_class.__class__.__name__ == 'WallaIE'


# Generated at 2022-06-22 08:54:53.831520
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert walla_ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert walla_ie.url == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-22 08:54:54.364257
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE()

# Generated at 2022-06-22 08:54:56.166699
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS['עברית'] == 'heb'


# Generated at 2022-06-22 08:55:02.568947
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

    # test an instance of WallaIE
    assert isinstance(obj, WallaIE)
    # test the path of WallaIE
    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    # test the function
    # WallaIE._real_extract(self, url) raises ExtractorError
    # when url is None
    assert obj._real_extract(None) is None

# Generated at 2022-06-22 08:55:06.040600
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    assert ie.VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-22 08:55:09.672444
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # TODO: refactor this test into actual unit test
    import json
    res = WallaIE()._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    print(json.dumps(res))

# Generated at 2022-06-22 08:57:13.772474
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:57:16.564065
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import unittest; unittest.TestCase().assertTrue(True)

# Generated at 2022-06-22 08:57:19.684140
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(walla, WallaIE)

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-22 08:57:30.681779
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Define test values for test_WallaIE
    test_video_id = '2642630'
    test_video_title = 'וואן דיירקשן: ההיסטריה'
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test_download_id = test_video_id
    test_video_description = 'md5:de9e2512a92442574cdb0913c49bc4d8'
    test_video_url = 'rtmp://wafla.walla.co.il/vod' # rtmp download
    test_video_ext = 'flv'
    test_video_handlers = ['rtmp']

   

# Generated at 2022-06-22 08:57:35.408499
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    assert instance._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert instance._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert instance._TEST['info_dict']['duration'] == 3600
    assert instance._TEST['info_dict']['ext'] == 'flv'
    assert instance._TEST['params']['skip_download'] == True

# Generated at 2022-06-22 08:57:36.998890
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.extract(test_url)

# Generated at 2022-06-22 08:57:41.123829
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie.WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:57:43.048904
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:57:45.129587
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()
	assert isinstance(ie, WallaIE)

# Generated at 2022-06-22 08:57:47.661779
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE('url')
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert w._SUBTITLE_LANGS == {'עברית': 'heb'}