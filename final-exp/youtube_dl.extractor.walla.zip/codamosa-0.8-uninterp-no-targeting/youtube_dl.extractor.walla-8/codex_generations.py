

# Generated at 2022-06-22 08:49:56.349800
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:00.151696
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    # match
    m = instance._VALID_URL
    print(m)
    # search
    assert re.search(m, instance._TEST['url']) is not None
    

# test class WallaIE
test = test_WallaIE()

# Generated at 2022-06-22 08:50:03.879691
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') != None
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') != None

# Generated at 2022-06-22 08:50:06.233287
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Make sure constructor of WallaIE works"""

    # check the basic case (no error)
    WallaIE()

# Generated at 2022-06-22 08:50:09.158963
# Unit test for constructor of class WallaIE
def test_WallaIE():
	obj = WallaIE()
	assert obj.__class__.__name__ == WallaIE.__name__


# Generated at 2022-06-22 08:50:10.742581
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-22 08:50:12.679527
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.SUFFIX == 'walla.co.il'

# Generated at 2022-06-22 08:50:18.183022
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.suitable('http://vod.walla.co.il/movie/2642630')
    ie.suitable('http://vod.walla.co.il/movie/2642630')



# Generated at 2022-06-22 08:50:19.796755
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)


# Generated at 2022-06-22 08:50:23.440265
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST == WallaIE._TEST

Walla = WallaIE

# Generated at 2022-06-22 08:50:35.172792
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._VALID_URL()

# Generated at 2022-06-22 08:50:36.279083
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()

# Generated at 2022-06-22 08:50:39.012480
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-22 08:50:49.917836
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    video = ie._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert video["id"] == '2642630'
    assert video["display_id"] == 'one-direction-all-for-one'
    assert video["ext"] == 'flv'
    assert video["title"] == 'וואן דיירקשן: ההיסטריה'
    assert video["description"] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert video["thumbnail"] == r

# Generated at 2022-06-22 08:50:55.791836
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test 1:
    # Test object constructor and set_canary method
    canary = 1
    test_object = WallaIE({})
    test_object.canary = canary
    if canary != test_object.canary:
        raise Exception('Unit test for constructor of class WallaIE failed.')

# Generated at 2022-06-22 08:50:58.363539
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.source == 'walla'

# Generated at 2022-06-22 08:51:00.033570
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-22 08:51:02.001919
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wrl = WallaIE()

# Generated at 2022-06-22 08:51:04.513001
# Unit test for constructor of class WallaIE

# Generated at 2022-06-22 08:51:05.920159
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.getClass()


# Generated at 2022-06-22 08:51:26.960595
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #Modify this unit test to match the name of your class:
    ie = WallaIE()

# Generated at 2022-06-22 08:51:31.592611
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie.ie_name() == 'walla.co.il'
    assert ie.valid_url(ie._VALID_URL, ie.ie_key())

# Generated at 2022-06-22 08:51:34.902542
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE
    return
# Testing code for constructor of class WallaIE
if __name__ == '__main__':
    test_WallaIE()
# End of testing code for constructor of class WallaIE

# Generated at 2022-06-22 08:51:42.140291
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for generating url for WallaIE
    url = WallaIE()._url_for_test(
        {
            'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
            'only_matching': True,
        }
    )

    assert url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:51:43.476601
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None
    return ie


# Generated at 2022-06-22 08:51:54.338515
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import ExtractorError
    from .MainIE import _call_downloader
    from .rtmp import RtmpIE
    from .ooyala import OoyalaIE
    from .youtube import YoutubeIE
    from .wimp import WimpIE
    from .vimeo import VimeoIE

    def check_instances(url, ie_list):
        for ie in ie_list:
            try:
                ie(url)
                assert False
            except ExtractorError:
                pass

    def check_youtubeIE_instance(url):
        ie = YoutubeIE(url)
        assert ie._VALID_URL
        assert ie._TEST
        assert ie._download_webpage
        assert ie._get_video_info
        assert ie._extract_video_id


# Generated at 2022-06-22 08:51:58.615034
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert str(ie.SUITABLE_YOUTUBE_URL).endswith('walla.co.il/')
    assert ie.url_re() == WallaIE._VALID_URL
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.__class__.__name__ == 'WallaIE'

# Generated at 2022-06-22 08:52:00.115811
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-22 08:52:01.158314
# Unit test for constructor of class WallaIE
def test_WallaIE():
	#assert WallaIE()
	assert True

# Generated at 2022-06-22 08:52:04.785162
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE()
    res = ie.extract(url)
    assert res.get('id') == "2642630"
    assert res.get('display_id') == "one-direction-all-for-one"
    assert res.get('title') == "וואן דיירקשן: ההיסטריה"

# Generated at 2022-06-22 08:52:35.572224
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:52:41.273471
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is True

# Generated at 2022-06-22 08:52:45.574365
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE(wallaCoIl=True)
    except Exception as ex:
        print(ex)
    except:
        pass
    else:
        assert(False)

# Generated at 2022-06-22 08:52:48.079146
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE

# Generated at 2022-06-22 08:52:48.712181
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-22 08:52:49.671885
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:52:55.827017
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert_equal(ie._VALID_URL, r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert_equal(ie._SUBTITLE_LANGS, {'עברית': 'heb'})

# Generated at 2022-06-22 08:52:57.319789
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE
    IE_test = IE({})
    assert IE_test

# Generated at 2022-06-22 08:52:59.312409
# Unit test for constructor of class WallaIE
def test_WallaIE():
    Loader.loadModule('WallaIE')
    w = WallaIE()
    assert isinstance(w, InfoExtractor)
    assert isinstance(w, WallaIE)

# Generated at 2022-06-22 08:53:00.118770
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('WallaIE')

# Generated at 2022-06-22 08:53:48.915060
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:53:51.929972
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("https://vod.walla.co.il/item/2642630").to_screen()

# Generated at 2022-06-22 08:53:57.349348
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check WALLAIE is derived from InfoExtractor
    assert issubclass(WallaIE, InfoExtractor)
    # Define valid url
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    # Check that WALLAIE accepts valid url
    assert WallaIE._VALID_URL.match(url)

# Generated at 2022-06-22 08:54:01.926655
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(url, None)

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-22 08:54:05.781366
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:54:12.467002
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._SUBTITLE_LANGS == {'עברית': 'heb'}
# Test for WallaIE._download_xml

# Generated at 2022-06-22 08:54:14.589796
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().check_valid_url("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:54:19.945679
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:54:23.086355
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    print(ie)


# Code for getting url of videos
# print ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:54:24.283519
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-22 08:56:11.562218
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_dict = WallaIE._TEST
    substract_dict = {'_type': 'url_transparent', 'url': 'http://isc.walla.co.il/w9/swf/video_swf/vod/WallaMediaPlayerAvod.swf', 'player_url': 'http://isc.walla.co.il/w9/swf/video_swf/vod/WallaMediaPlayerAvod.swf', 'ext': 'flv', 'format_id': None}
    for i, format in enumerate(test_dict['info_dict']['formats']):
        test_dict['info_dict']['formats'][i] = {k: v for k, v in format.iteritems() if k not in substract_dict}

# Generated at 2022-06-22 08:56:16.063106
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL = WallaIE._VALID_URL
    ie.extract('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:56:16.693794
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:56:21.955712
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert walla.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert walla.video_id == '2642630'
    assert walla.display_id == 'one-direction-all-for-one'

# Generated at 2022-06-22 08:56:23.993239
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE()

# Generated at 2022-06-22 08:56:24.500141
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-22 08:56:28.939573
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2640502/one-direction-all-for-one"
    obj = WallaIE()
    obj.url_result = []
    obj.urls = []
    obj._downloader = None
    obj.add_default_info_extractors()

# Generated at 2022-06-22 08:56:31.272551
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._SUBTITLE_LANGS!=[]
    assert ie.SUFFIX=='walla'
    assert ie._downloader!=None
    assert ie._downloader.params['rtmpdump']!=None

# Generated at 2022-06-22 08:56:32.743754
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-22 08:56:35.261596
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    video = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert walla._VALID_URL.match(video)
    assert walla._TEST['url'] == video