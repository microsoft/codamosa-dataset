

# Generated at 2022-06-22 08:49:54.779686
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class WallaIE_Test(object):
        def __init__(self):
            self.IE_NAME = 'walla'
            self.IE_DESC = 'Walla VOD'
            self._VALID_URL = WallaIE._VALID_URL
            self._TESTS = WallaIE._TEST
            self._downloader = None
    WallaIE_Test()

# Generated at 2022-06-22 08:49:58.251384
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Test if the constrctor was executed without any errors
    assert(ie != None)


# Generated at 2022-06-22 08:50:06.137963
# Unit test for constructor of class WallaIE
def test_WallaIE():
    object = WallaIE()
    assert object._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:06.840511
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-22 08:50:08.800790
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(ie._TEST['url'])


# Generated at 2022-06-22 08:50:12.349143
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    w._real_extract(url)

# Generated at 2022-06-22 08:50:19.840416
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'
    assert WallaIE._TEST['info_dict']['duration'] == 3600
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'



# Generated at 2022-06-22 08:50:23.220389
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:50:27.228838
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        # test instantiation of WallaIE class
        WallaIE()
    except:
        print('test instantiation of WallaIE class')
        raise

# Generated at 2022-06-22 08:50:37.337836
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    assert ie._TEST['url'] == ie._TEST['info_dict']['url']
    assert ie._TEST['info_dict']['title'] == ie._TEST['info_dict']['title']
    assert ie._TEST['info_dict']['description'] == ie._TEST['info_dict']['description']
    assert ie._TEST['info_dict']['duration'] == ie._TEST['info_dict']['duration']
    assert ie._TEST['info_dict']['id'] == ie._TEST['info_dict']['id']
    assert ie._TEST['info_dict']['display_id'] == ie

# Generated at 2022-06-22 08:50:53.624728
# Unit test for constructor of class WallaIE
def test_WallaIE():

    filename = 'data/walla/vod/walla_vod_flv_pl_2642630.xml'
    # Test -> Open File from Disk
    data = read_data(filename)
    # Test -> Initialize WallaIE
    ie = WallaIE()
    # Test -> Extract Data from xml
    ie._extract_data(data)

    # Test -> Check for a valid 'title', 'description', 'duration' and 'thumbnail'
    expected_title = 'וואן דיירקשן: ההיסטריה'
    expected_description = 'md5:de9e2512a92442574cdb0913c49bc4d8'
    expected_duration = 3600

# Generated at 2022-06-22 08:50:55.857464
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:57.214494
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:51:00.034667
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Test that the constructor is working
    assert(ie is not None)

# Generated at 2022-06-22 08:51:05.476048
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla', 'invalid ie_key'
    assert ie.ie_name() == 'Walla', 'invalid ie_name'
    assert ie.VALID_URL == WallaIE._VALID_URL, 'invalid VALID_URL'

# Generated at 2022-06-22 08:51:10.816275
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'
    assert WallaIE._TEST['info_dict']['title'] == 'וואן דיירקשן: ההיסטריה'
    assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-22 08:51:19.686043
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL ==  r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:51:24.198913
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        loader = WallaIE()
    except:
        assert False, "WallaIE is not being initialized correctly"
    assert isinstance(loader, WallaIE), "WallaIE is not being initialized correctly"


# Generated at 2022-06-22 08:51:26.657739
# Unit test for constructor of class WallaIE
def test_WallaIE():
    m = WallaIE()
    # Unit test for _real_extract()
    m._real_extract(m._TEST['url'])

# Generated at 2022-06-22 08:51:34.105628
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    info_dict = {
        'id': '2642630',
        'display_id': 'one-direction-all-for-one',
        'ext': 'flv',
        'title': 'וואן דיירקשן: ההיסטריה',
        'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        'thumbnail': r're:^https?://.*\.jpg',
        'duration': 3600,
    }

    params = {
        # rtmp download
        'skip_download': True,
    }

    ex = WallaIE()


# Generated at 2022-06-22 08:51:45.442187
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w

# Generated at 2022-06-22 08:51:56.685756
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    # Check the type of the class WallaIE
    assert isinstance(ie, InfoExtractor) == True

    # Check _VALID_URL
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'

    # Check _TEST['url']
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    # Check _TEST['info_dict']['id']
    assert ie._TEST['info_dict']['id'] == '2642630'

    # Check _TEST['info_dict']['display_id']

# Generated at 2022-06-22 08:51:58.443186
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:52:07.193854
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # pylint: disable=protected-access,no-member
    WallaIE._download_xml = lambda self, url: {}
    info = WallaIE()._real_extract(u'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Ensure all last known fields are present
    expected = [
        ('description', 'description'), ('title', 'title'), ('id', u'2642630'), ('duration', 3600), ('display_id', u'one-direction-all-for-one')
    ]
    for name, value in expected:
        assert name in info and info[name] == value

# Generated at 2022-06-22 08:52:09.047548
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    instance._SUBTITLE_LANGS
    instance._VALID_URL
    instance._TEST
    instance._real_extract

# Generated at 2022-06-22 08:52:13.182441
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE()._VALID_URL  == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:52:14.413090
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().ie_key() == 'Walla'



# Generated at 2022-06-22 08:52:21.660869
# Unit test for constructor of class WallaIE
def test_WallaIE():

    from .generic import YoutubeIE
    from .mtvservices import MtvServicesInfoExtractor
    from .aol import AolIE
    from .theplatform import ThePlatformIE

    u = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    assert w == YoutubeIE.suitable(u) == MtvServicesInfoExtractor.suitable(u) == AolIE.suitable(u) == ThePlatformIE.suitable(u)

# Generated at 2022-06-22 08:52:24.282455
# Unit test for constructor of class WallaIE

# Generated at 2022-06-22 08:52:29.584772
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    print(ie.get_info('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'))

# test_WallaIE()

# Generated at 2022-06-22 08:52:53.753879
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_info = WallaIE._TEST['info_dict']
    url = WallaIE._TEST['url']
    WallaIE(url, test_info)

# Generated at 2022-06-22 08:53:04.234773
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # First we must call class constructor
    assert isinstance(ie, InfoExtractor)
    # Next test a regular expression of class WallaIE
    assert re.match(ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Next test a dictionary of class WallaIE
    assert isinstance(ie._TEST, dict)
    #  Next test a fields of class WallaIE
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'

# Generated at 2022-06-22 08:53:05.560212
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #tests all the functions in the class
    WallaIE()

# Generated at 2022-06-22 08:53:16.475270
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Testing URL 1:
	video_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	# Create object
	ie = WallaIE()
	# Get InfoExtractor object
	info_extractor_object = ie.ie_key()
	# Checking if object contains specific key (URL)
	assert 'walla:' + video_url == info_extractor_object, 'Failed to create WallaIE object!' 
	# Testing URL 2:
	video_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	# Create object
	ie = WallaIE()
	# Get InfoExtractor object
	info_extractor_object = ie.ie_key()
	

# Generated at 2022-06-22 08:53:19.005057
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-22 08:53:19.615169
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:53:20.872453
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-22 08:53:23.339497
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(WallaIE._TEST['url'])

# Generated at 2022-06-22 08:53:23.963810
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-22 08:53:35.211697
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:54:31.488105
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:54:40.839815
# Unit test for constructor of class WallaIE
def test_WallaIE():
  ie = WallaIE()
  assert ie._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"
  assert ie._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
  assert ie._TEST['info_dict']['id'] == "2642630"
  assert ie._TEST['info_dict']['display_id'] == "one-direction-all-for-one"
  assert ie._TEST['info_dict']['ext'] == "flv"

# Generated at 2022-06-22 08:54:43.083711
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'

# Generated at 2022-06-22 08:54:46.198763
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ex = WallaIE(1)
    assert_equal(ex._VALID_URL, r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-22 08:54:56.603581
# Unit test for constructor of class WallaIE
def test_WallaIE():

	test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	info_dict = {'id': '2642630', 'display_id': 'one-direction-all-for-one', 'title': 'וואן דיירקשן: ההיסטריה', 'description': 'md5:de9e2512a92442574cdb0913c49bc4d8', 'ext': 'flv', 'thumbnail': 're:^https?://.*\.jpg', 'duration': 3600, 'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'}
	params = {'skip_download': True}
	

# Generated at 2022-06-22 08:54:59.394312
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST == WallaIE._TEST

# Generated at 2022-06-22 08:55:02.477577
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from walla import WallaIE
    target = WallaIE(5)
    assert isinstance(target, WallaIE)

# Generated at 2022-06-22 08:55:12.107061
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE(None)._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE(None)._TEST['info_dict']['id'] == '2642630'
    assert WallaIE(None)._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert WallaIE(None)._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-22 08:55:19.977026
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #
    # Test class WallaIE
    #
    # TEST_URL is a url which was taken from a real
    # call to _real_extract of WallaIE
    #
    TEST_URL = 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    TEST_URL_MATCH = ('https?://vod\.walla\.co\.il/[^/]+/'
                      r'(?P<id>\d+)/(?P<display_id>.+)')
    TEST_ID = '2642630'
    TEST_DISPLAY_ID = 'one-direction-all-for-one'
    TEST_TITLE = 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-22 08:55:30.010818
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test - test_WallaIE
    """
    # Test if _VALID_URL is correct
    res = re.match(WallaIE._VALID_URL, "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:57:33.786960
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-22 08:57:34.639120
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-22 08:57:45.049037
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert(obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-22 08:57:47.559688
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:57:54.374568
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()
    mobj = re.match(wie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert mobj.group('id') == '2642630'
    assert mobj.group('display_id') == 'one-direction-all-for-one'

# Generated at 2022-06-22 08:57:59.420006
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST.get('url') == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'


# Generated at 2022-06-22 08:58:01.699162
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("url", None, None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:58:04.397876
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_WallaIE = WallaIE()
    assert test_WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert test_WallaIE._real_extract(url)

# Generated at 2022-06-22 08:58:07.726697
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.IE_NAME == 'walla')
    assert(ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-22 08:58:10.452600
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(ie.name == 'Walla!')