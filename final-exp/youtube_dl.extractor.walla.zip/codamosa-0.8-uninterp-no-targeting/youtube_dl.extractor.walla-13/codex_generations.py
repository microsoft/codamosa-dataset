

# Generated at 2022-06-22 08:49:51.117688
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.SUCCESS(ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')))

# Generated at 2022-06-22 08:49:57.590344
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.download(url)
    # For debugging, print(ie._download_webpage(url, ie._VALID_URL, None, False))

# Generated at 2022-06-22 08:50:06.461276
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod.walla.co.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:50:07.789924
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-22 08:50:10.687492
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check that WallaIE is instantiable
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:22.995559
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()
    assert wie.IE_NAME == 'walla'
    assert wie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:23.632822
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:50:24.373962
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:50:25.284259
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:50:33.374484
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)

    assert len(ie._SUBTITLE_LANGS) > 0
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.ie_key() == 'walla'
    assert ie.suitable(url)
    assert ie.extract(url)

# Generated at 2022-06-22 08:50:42.540619
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for constructor of WallaIE"""
    walla = WallaIE()
    assert walla._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:53.566894
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
        This is a test to check if a content of a specific media is downloaded using class WallaIE().
        This test checks whether the download and conversion media is correct.
    """
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    expected_url = ["rtmp://wafla.walla.co.il/vod/mp4:mp4_700/2642630_2610_157.mp4"]
    expected_title = "וואן דיירקשן: ההיסטריה"

# Generated at 2022-06-22 08:50:59.745123
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().IE_NAME == 'walla'

    # Unit test for class method WallaIE._real_extract()
    def test_real_extract():
        # check that the data received from the server
        # is the same as the required data
        ie = WallaIE()

        url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
        actual_data = ie._extract_video_data_from_url(url)

        title = 'וואן דיירקשן: ההיסטריה'
        assert actual_data['title'] == title

        description = 'md5:de9e2512a92442574cdb0913c49bc4d8'

# Generated at 2022-06-22 08:51:03.940759
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://now.walla.co.il/?w=//1939840&auto=true"
    vid_id, display_id = WallaIE._VALID_URL.split('/')[-2:]
    WallaIE(url, vid_id, display_id)



# Generated at 2022-06-22 08:51:08.567755
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print('===========================')
    print('Unit test for constructor of class WallaIE')
    print('===========================')

    ie = WallaIE()
    ie.extract_info('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    print('===========================')


# Generated at 2022-06-22 08:51:14.390625
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    )
    assert(obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)' )

# Generated at 2022-06-22 08:51:16.176884
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:51:18.073959
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__.__name__ == 'WallaIE'

# Generated at 2022-06-22 08:51:19.521473
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w == WallaIE()

# Generated at 2022-06-22 08:51:28.893142
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:51:40.024004
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert isinstance(WallaIE(None, None), InfoExtractor)

# Generated at 2022-06-22 08:51:41.071680
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()


# Generated at 2022-06-22 08:51:42.278494
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == WallaIE()._VALID_URL

# Generated at 2022-06-22 08:51:43.064508
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-22 08:51:46.318267
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-22 08:51:49.585415
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie is not None

# Generated at 2022-06-22 08:51:54.528524
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert x._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:52:02.879020
# Unit test for constructor of class WallaIE
def test_WallaIE():
	from ..parser import extractor
	import sys

	current_module = sys.modules[__name__]
	extractor_class = extractor.gen_extractor_classes(current_module)

	extractor_class.__name__ = 'WallaIE' + 'Unit'
	assert 'WallaIE' in globals()
	globals()['WallaIE' + 'Unit'] = extractor_class


# Generated at 2022-06-22 08:52:04.756910
# Unit test for constructor of class WallaIE
def test_WallaIE():
	w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
	#print w

# Generated at 2022-06-22 08:52:09.774931
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    print("url = {}".format(url))

    walla_ie = WallaIE()

    mobj = re.match(walla_ie._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    print("video_id = {}".format(video_id))
    print("display_id = {}".format(display_id))

    return 0

# Generated at 2022-06-22 08:52:32.096930
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._TEST['url']
    assert WallaIE._TEST['info_dict']
    assert WallaIE._TEST['params']


# Generated at 2022-06-22 08:52:37.174240
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie = WallaIE('Walla')
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:52:43.511971
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test creating instance of WallaIE
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Test the _VALID_URL attribute
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    # Test the _TEST attribute
    test = ie._TEST
    assert test['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Test the info_dict attribute
    info_dict = test['info_dict']
    assert info_dict['id'] == '2642630'
    assert info_

# Generated at 2022-06-22 08:52:45.306090
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test constructor of class WallaIE"""
    WallaIE()

# Generated at 2022-06-22 08:52:49.296133
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import unittest
    class TestConstructor(unittest.TestCase):
        def test_WallaIE(self):
            ie = WallaIE()
            self.assertTrue(isinstance(ie, WallaIE))
    unittest.main()

# Generated at 2022-06-22 08:52:49.907378
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:52:53.752624
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    return WallaIE()._real_extract(url)

# Generated at 2022-06-22 08:53:04.821310
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(0)
    assert type(ie).__name__ == 'WallaIE'
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.video_id == '2642630'
    assert ie.display_id == 'one-direction-all-for-one'

# Generated at 2022-06-22 08:53:09.631088
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    

# Generated at 2022-06-22 08:53:13.224550
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Extracting for the test case
    ie = WallaIE()
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:53:58.553505
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.test()

# Generated at 2022-06-22 08:53:59.178193
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-22 08:54:01.611324
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._TEST['url'] == WallaIE()._TEST['url']

# Generated at 2022-06-22 08:54:07.368589
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    expected_url = 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl'
    actual_url = WallaIE._build_url(url)

    assert expected_url == actual_url

# Generated at 2022-06-22 08:54:16.602125
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert not ie._login()
    assert ie.IE_NAME == 'walla:video'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:54:25.061048
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import os
    import sys
    test_dir = os.path.dirname(__file__)
    src_dir = os.path.join(test_dir, '../..')
    sys.path.append(src_dir)
    from you_get.extractors import walla as walla_extractor
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    result = walla_extractor.WallaIE().url_to_module(url)
    assert "WallaIE" == result

# Generated at 2022-06-22 08:54:25.572344
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-22 08:54:37.659887
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_WallaIE.video_id = '2642630'
    test_WallaIE.display_id = 'one-direction-all-for-one'
    test_WallaIE.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test_WallaIE.subtitle_url = 'http://feeds.walla.co.il/feeds/subtitle/subtitleTvShow/2642630'
    test_WallaIE.embed_url = 'http://vod.walla.co.il/movie/@@/262702/@@/2642630/@@/one-direction-all-for-one'

# Generated at 2022-06-22 08:54:39.288575
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie,InfoExtractor)

# Generated at 2022-06-22 08:54:40.240911
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.match

# Generated at 2022-06-22 08:56:29.205371
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for constructor, ie. __init__(self) of class WallaIE
    WallaIE()
    # Test for _real_extract, ie.  _real_extract(self, url) of class WallaIE
    WallaIE()._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:56:29.934761
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()


# Generated at 2022-06-22 08:56:31.149180
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_Walla = WallaIE()
    test_Walla.extract(WallaIE._TEST)

# Generated at 2022-06-22 08:56:32.860188
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for constructor of class WallaIE"""
    vod = WallaIE({})
    assert 'WallaIE' in repr(vod)


# Generated at 2022-06-22 08:56:35.564479
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #test for getting an instance of class WallaIE
    ie = WallaIE()
    #testing that instance is indeed an instance of WallaIE
    assert isinstance(ie, WallaIE)
    #testing that instance is indeed an instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-22 08:56:45.335183
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:56:50.774429
# Unit test for constructor of class WallaIE
def test_WallaIE():
    u = WallaIE({0:'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'})
    assert u._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert u.__class__.__name__ == 'WallaIE'

# Generated at 2022-06-22 08:56:51.755254
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-22 08:57:00.970673
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class_object = WallaIE()
    assert_equal(class_object.host, 'vod.walla.co.il')
    assert_equal(class_object.ie_key(), 'Walla')
    assert_equal(class_object.description, 'Walla')
    assert_equal(class_object.SUBTITLE_LANGS, {'עברית': 'heb'})
    assert_equal(class_object.age_limit, None)
    assert_equal(class_object.FILE_EXTENSIONS, {})
    assert_equal(class_object.SUFFIX, '^(?:[^/]+/)?(?:[^/]+/)*%s(?:/|$)' % class_object._VALID_URL)
    assert_equal(class_object.can_download(), False)


# Generated at 2022-06-22 08:57:09.322011
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    assert hasattr(instance, '_download_xml'), 'no download_xml method'
    assert hasattr(instance, '_VALID_URL'), 'no valid_url regexp'
    assert hasattr(instance, '_TEST'), 'no unit test metadata'
    assert instance._TEST['url'] in instance._VALID_URL, 'url not in _VALID_URL regexp'
    instance._download_xml(instance._TEST['url'], instance._TEST['info_dict']['display_id'])
    assert hasattr(instance, '_real_extract'), 'no real_extract method'
    instance._real_extract(instance._TEST['url'])