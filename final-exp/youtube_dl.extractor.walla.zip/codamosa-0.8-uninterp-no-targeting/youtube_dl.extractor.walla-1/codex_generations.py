

# Generated at 2022-06-22 08:49:50.503839
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:49:53.840778
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:05.069278
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Here we test the constructor of class WallaIE, which takes a URL and returns the appropriate subclass
    import unittest
    from yt_dl.extractor.walla import WallaIE

    # Test for WallaIE (movie)
    class TestWallaMovieIE(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(TestWallaMovieIE, self).__init__(*args, **kwargs)
            self.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
            self.name = 'walla:vod'
        def runTest(self):
            ie = WallaIE(self.url)
            self.assertEqual(ie.name, self.name)

    # Test for

# Generated at 2022-06-22 08:50:06.190422
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import unittest
    unittest.main()

# Generated at 2022-06-22 08:50:17.334662
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:19.840079
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check that an url is valid (to avoid error)
    if not WallaIE()._VALID_URL:
        raise Exception('Error in _VALID_URL')

# Generated at 2022-06-22 08:50:26.771074
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info = WallaIE()._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert info['id'] == '2642630'
    assert info['title'] == 'וואן דיירקשן: ההיסטריה'
    assert info['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'

# Generated at 2022-06-22 08:50:28.873732
# Unit test for constructor of class WallaIE
def test_WallaIE():
  w = WallaIE(InfoExtractor())
  assert isinstance(w, InfoExtractor) == True

# Generated at 2022-06-22 08:50:39.077597
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    
    # Test case #1: using url that is not a string
    url_test_1 = {'url': url, 'info_dict': {} }
    assert ie.suitable(url_test_1) == False
   
    # Test case #2: using valid url
    url_test_2 = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.suitable(url_test_2) == True
   
    # Test case #3: using invalid url

# Generated at 2022-06-22 08:50:43.879019
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.ie_key() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.working == True

# Generated at 2022-06-22 08:50:50.730573
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None


from ..utils import qualities



# Generated at 2022-06-22 08:50:57.886234
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import InfoExtractor
    from .walla import WallaIE
    from ..utils import (
        compat_str,
        compat_urllib_parse,
        compat_urlparse,
    )
    assert WallaIE.__name__ == 'WallaIE'
    assert WallaIE.__doc__ == InfoExtractor.__doc__
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:51:03.925969
# Unit test for constructor of class WallaIE

# Generated at 2022-06-22 08:51:15.593867
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one?w=/123/456')
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one#abc')
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one?w=/123/456#abc')

# Generated at 2022-06-22 08:51:19.426331
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'vod.walla.co.il'

    w = WallaIE()
    assert w.IE_NAME == 'vod.walla.co.il'

# Generated at 2022-06-22 08:51:21.541069
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(InfoExtractor())._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-22 08:51:23.993493
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('rtmp://wafla.walla.co.il/vod')

# Generated at 2022-06-22 08:51:30.278757
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test: constructor of class WallaIE
    ie = WallaIE()

    # Test: _download_xml
    video = ie._download_xml('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl', '2642630')
    assert xpath_text(video.find('./items/item'), './title', 'title') == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-22 08:51:35.545061
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    video = ie._real_extract(url)
    assert video['title'] == "וואן דיירקשן: ההיסטריה"

# Generated at 2022-06-22 08:51:41.926543
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # http://vod.walla.co.il/movie/2642630/one-direction-all-for-one
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert ie.id == 2642630
    assert ie.display_id == 'one-direction-all-for-one'

# Generated at 2022-06-22 08:51:56.686043
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE();
    assert(info_extractor._VALID_URL==r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-22 08:52:01.361448
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.name == "walla"
    assert ie.supported_template_url == "http://vod.walla.co.il/movie/<id>/<display_id>"

# Generated at 2022-06-22 08:52:08.927088
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.name == "Walla"
    assert ie.description == 'Walla!'
    assert ie.valid_url("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert not ie.valid_url("")
    assert not ie.valid_url("http://walla.co.il")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:52:11.853316
# Unit test for constructor of class WallaIE
def test_WallaIE():

    assert WallaIE._TEST
    assert WallaIE._SUBTITLE_LANGS
    assert WallaIE._VALID_URL
    assert WallaIE.__name__


# Generated at 2022-06-22 08:52:18.778595
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.name == 'walla'
    assert ie.ie_key == 'walla'
    assert ie.domain == 'vod.walla.co.il'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-22 08:52:23.536500
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL is not None
    assert WallaIE._TEST is not None
    assert WallaIE._SUBTITLE_LANGS is not None


# Generated at 2022-06-22 08:52:26.993581
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Function of test class
    from tests.test_walla import test_WallaIE
    # Passing test instance to test function
    test_WallaIE(WallaIE)
    # Print result
    print('Unit test successful')

# Generated at 2022-06-22 08:52:28.646729
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:52:29.740841
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-22 08:52:30.883524
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None

# Generated at 2022-06-22 08:52:57.940974
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL in WallaIE._TEST['url']
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-22 08:53:01.053106
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE(downloader=None)
	ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
	# print ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# This is where I call the test of class WallaIE
test_WallaIE()

# Generated at 2022-06-22 08:53:02.789332
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:53:05.026431
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE('', '')
    assert w.NAME == 'walla'

# Generated at 2022-06-22 08:53:11.546995
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    # Create instance
    WallaIE_instance = WallaIE()

    # Check attribute that tell us what kind of sites we are looking for
    assert WallaIE_instance._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-22 08:53:23.108955
# Unit test for constructor of class WallaIE
def test_WallaIE():
    
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    # create instance of WallaIE
    wallaIE = WallaIE(url)
    print ("URL:", wallaIE._VALID_URL)
    # test _real_extract method
    info_dict = wallaIE._real_extract(url)
    
    assert info_dict['id'] == '2642630'
    assert info_dict['display_id'] == 'one-direction-all-for-one'
    assert info_dict['title'] == 'וואן דיירקשן: ההיסטריה'
    assert info_dict['duration'] == 3600

# Generated at 2022-06-22 08:53:25.979367
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    #Test that the constructor did not fail
    assert ie is not None

# Generated at 2022-06-22 08:53:26.961738
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert x

# Generated at 2022-06-22 08:53:29.159445
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie = WallaIE('Walla')


# Generated at 2022-06-22 08:53:30.231574
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:54:27.660325
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(WallaIE.ie_key()).ie_key() == 'Walla'

# Generated at 2022-06-22 08:54:28.484837
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:54:31.975200
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(InfoExtractor())._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-22 08:54:40.061215
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert info_extractor._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:54:41.426037
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-22 08:54:44.742026
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie.walla_download()

# Generated at 2022-06-22 08:54:53.183295
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one' == ie.get_real_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert 'http://www.walla.co.il' == ie.get_real_url('http://www.walla.co.il')

# Generated at 2022-06-22 08:54:56.053635
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    instance.match(WallaIE._VALID_URL)
    instance.match(WallaIE._TEST['url'])
    instance.extract(WallaIE._TEST['url'])

# Generated at 2022-06-22 08:54:56.802692
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:55:05.388686
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:57:16.564041
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:57:18.885377
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._is_valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-22 08:57:19.467270
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:57:24.225132
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    except Exception as exc:
        print("Exception: %s" % exc)

# Unit test to check compliance with standard YoutbeIE

# Generated at 2022-06-22 08:57:34.481813
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructor of WallaIE
    ie = WallaIE(None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:57:44.901791
# Unit test for constructor of class WallaIE
def test_WallaIE():
    args = []
    kwargs = {'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'}
    inst = WallaIE(*args, **kwargs)

    assert inst._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:57:51.534107
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    ie=WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    tdl=YoutubeDL({'nooverwrites':True,'continue_dl':False,'format':'best'})
    tdl.add_default_info_extractors()
    tdl.process_ie_result(ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'))

# Generated at 2022-06-22 08:58:00.099176
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:58:10.106693
# Unit test for constructor of class WallaIE
def test_WallaIE():
    args = {}
    args["url"] = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    expected_return = {
        'id': '2642630',
        'display_id': 'one-direction-all-for-one',
        'ext': 'flv',
        'title': 'וואן דיירקשן: ההיסטריה',
        'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        'thumbnail': r're:^https?://.*\.jpg',
        'duration': 3600,
    }
    return_value = WallaIE._real_extract(WallaIE(),**args)
   

# Generated at 2022-06-22 08:58:14.043813
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

test_WallaIE()