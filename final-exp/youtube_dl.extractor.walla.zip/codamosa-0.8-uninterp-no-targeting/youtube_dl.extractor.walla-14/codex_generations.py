

# Generated at 2022-06-22 08:49:50.032464
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE('WallaIE')

# Generated at 2022-06-22 08:49:56.842391
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test return of __init__
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST
    assert ie._SUBTITLE_LANGS

# Generated at 2022-06-22 08:49:57.701179
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:49:59.919281
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:07.233936
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-22 08:50:08.318956
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-22 08:50:12.071315
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not WallaIE().suitable('http://vod.walla.co.il/movie')

# Generated at 2022-06-22 08:50:19.925879
# Unit test for constructor of class WallaIE
def test_WallaIE():
    extractor_constructor = WallaIE.ie_key()
    extractor = extractor_constructor('Walla') # should match only 'Walla'
    assert_equal(extractor_constructor.ie_key(), extractor_constructor)
    assert_equal(extractor.IE_NAME, 'Walla')
    assert_equal(extractor.extractor, WallaIE)
    assert_equal(extractor.ie_key(), extractor_constructor)

# Generated at 2022-06-22 08:50:24.328188
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class_ = WallaIE
    instance = class_('www.walla.co.il')
    assert(instance.url_result('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', '2642630'))

# Generated at 2022-06-22 08:50:28.003898
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from . import WallaIE
    # Instantiation of WallaIE
    # abc = WallaIE()
    # print abc

# Generated at 2022-06-22 08:50:34.263685
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:50:40.678321
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # check whether WallaIE has the name "walla"
    assert WallaIE.ie_key() == 'walla'
    # check whether WallaIE has the name "Walla"
    assert WallaIE.ie_key_name() == 'Walla'

    # check whether WallaIE.ie_key() returns the expected value
    ie = InfoExtractor(WallaIE.ie_key())
    assert isinstance(ie, WallaIE)


# Generated at 2022-06-22 08:50:51.949734
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from walla import WallaIE
    from six import assertRegex
    from six.moves.urllib import parse

    assertRegex(WallaIE, WallaIE._VALID_URL, 'http://vod.walla.co.il/movies/2642630/one-direction-all-for-one')
    assertRegex(WallaIE, WallaIE._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assertRegex(WallaIE, WallaIE._VALID_URL, 'http://vod.walla.co.il/movies/2642630/one-direction-all-for-one/')

# Generated at 2022-06-22 08:50:57.477572
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for YoutubeIE constructor"""

    # Testing with a Walla video URL
    assert WallaIE.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    # Testing with a non-Walla video URL
    assert not WallaIE.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-22 08:51:00.864848
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.VALID_URL == WallaIE._VALID_URL
    assert ie.URL_RE.match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:51:12.477996
# Unit test for constructor of class WallaIE
def test_WallaIE():
    client = WallaIE()
    assert client._VALID_URL == \
            'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert client._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert client._TEST['info_dict']['id'] == '2642630'
    assert client._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert client._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-22 08:51:23.621942
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL = 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:51:31.961278
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(a.url == 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(a.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)')
    assert(a.display_id == 'one-direction-all-for-one')
    assert(a.video_id == '2642630')
    assert(a.video_url == 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl')

# Generated at 2022-06-22 08:51:33.694459
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()

# Generated at 2022-06-22 08:51:35.545316
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert WallaIE._VALID_URL == ie._VALID_URL



# Generated at 2022-06-22 08:51:51.779594
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert walla._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-22 08:51:53.857529
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._TEST

# Generated at 2022-06-22 08:51:56.032801
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie != None

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-22 08:51:59.582707
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:52:01.158194
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-22 08:52:02.346369
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    assert isinstance(instance, WallaIE)

# Generated at 2022-06-22 08:52:04.539956
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:52:05.345105
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()


# Generated at 2022-06-22 08:52:05.874917
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:52:08.329340
# Unit test for constructor of class WallaIE
def test_WallaIE():
  ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
  ie.download("2642630")

# Generated at 2022-06-22 08:52:29.162206
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:52:33.009512
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    assert ie.VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)";


# Generated at 2022-06-22 08:52:33.476678
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(InfoExtractor())



# Generated at 2022-06-22 08:52:34.692088
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:52:37.970430
# Unit test for constructor of class WallaIE

# Generated at 2022-06-22 08:52:43.445249
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', ie='Walla')

# Generated at 2022-06-22 08:52:47.086149
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test WallaIE
    from .walla import WallaIE
    webpage = WallaIE._VALID_URL
    print("Unit test for WallaIE, webpage="+webpage)



# Generated at 2022-06-22 08:52:48.205928
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-22 08:52:58.278197
# Unit test for constructor of class WallaIE
def test_WallaIE():
    result = WallaIE()
    assert(result != None)
    assert(result._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-22 08:53:03.421650
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract('http://vod.walla.co.il/movie/2090606/the-lego-movie')

# Generated at 2022-06-22 08:53:49.097787
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie._real_extract(ie._VALID_URL)

# Generated at 2022-06-22 08:53:51.502560
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE("url")
    assert not walla_ie == None

# Generated at 2022-06-22 08:53:52.575961
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# construct the WallaIE instance
	IE_instance = WallaIE(None)

# Generated at 2022-06-22 08:53:53.657338
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE()

# Generated at 2022-06-22 08:53:56.232403
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(url)

# Generated at 2022-06-22 08:54:00.661144
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == "walla"
    assert ie.IE_DESC == "Walla"
    assert ie._VALID_URL != ""
    assert ie._TEST != ""
    assert ie._SUBTITLE_LANGS != ""

# Generated at 2022-06-22 08:54:02.615472
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-22 08:54:05.240157
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:54:16.181752
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl')
    assert ie.extractor_key == "Walla"
    assert ie.IE_NAME == "Walla"
    assert ie._VALID_URL == "https?://vod\\.walla\\.co\\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)"

# Generated at 2022-06-22 08:54:16.679859
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:56:01.049580
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global WallaIE
    WallaIE()

# Generated at 2022-06-22 08:56:08.919152
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        # First, we'll create a test VideoExtractor by passing it a test URL.
        # It's common practice to name the instance 'ie' for 'Information
        # Extractor'.
        ie = WallaIE('http://vod.walla.co.il/movie/2642630/?w=/124/124/2642630/@@/movie/flv_pl')

        # Then, we try to download this URL.
        info = ie.extract(ie.url)

        # Make sure the file we get is of the expected type.
        assert info.get('id')
        assert info.get('title')
        assert info.get('formats')

    except Exception as e:
        print(e)
        print('TEST FAILED')
        exit(1)

    print('TEST SUCCESS')


# Generated at 2022-06-22 08:56:18.769729
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test for constructor of class WallaIE
    """

    obj = WallaIE("vod.walla.co.il", "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert obj.name == 'Walla'
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert obj._downloader is not None
    assert obj._downloader.params['username'] is None
    assert obj._downloader.params['password'] is None
    assert obj._downloader.params['usenetrc'] is False
    assert obj._downloader.params['noprogress'] is True
    assert obj._

# Generated at 2022-06-22 08:56:20.637203
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE({})
    assert obj is not None


# Generated at 2022-06-22 08:56:23.993032
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE()
    assert info_extractor._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-22 08:56:28.404778
# Unit test for constructor of class WallaIE
def test_WallaIE():
    S = WallaIE('https://www.instagram.com/p/BQupLCBDb9X/');

# Generated at 2022-06-22 08:56:37.281277
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Testing Urls
    assert WallaIE._VALID_URL.match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is not None
    assert WallaIE._VALID_URL.match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/') is not None
    assert WallaIE._VALID_URL.match('http://vod.walla.co.il/clip/2643271/one-direction-all-for-one') is not None
    assert WallaIE._VALID_URL.match('http://vod.walla.co.il/clip/2643271/one-direction-all-for-one/') is not None

# Generated at 2022-06-22 08:56:42.722767
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .test_common import TestCommon
    ie = WallaIE()

    ie.match_url_test(TestCommon.patterns['walla'], 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.parse_url_test(TestCommon.patterns['walla'], 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:56:44.117505
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-22 08:56:45.722268
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL