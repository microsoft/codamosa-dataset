

# Generated at 2022-06-22 08:49:54.632284
# Unit test for constructor of class WallaIE
def test_WallaIE():
    inst = WallaIE('WallaIE','http://vod.walla.co.il/movie/2642630/one-direction-all-for-one','2642630','one-direction-all-for-one')
    assert inst.suitable == 'true'
    assert inst.ie_key() ==  'WallaIE:http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert inst._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-22 08:49:55.690867
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass


# Generated at 2022-06-22 08:50:04.073252
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ans1 = ie._VALID_URL
    ans2 = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert ans1 == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"
    assert ans2 == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"


# Generated at 2022-06-22 08:50:15.694129
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(WallaIE._TEST['info_dict']['id'] == '2642630')
    assert(WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one')
    assert(WallaIE._TEST['info_dict']['ext'] == 'flv')

# Generated at 2022-06-22 08:50:17.564720
# Unit test for constructor of class WallaIE
def test_WallaIE():
    infoExtractor = WallaIE()
    assert infoExtractor.IE_NAME == "walla"

# Generated at 2022-06-22 08:50:19.754046
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:24.410447
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # print (WallaIE._TEST)
    # print (WallaIE._TEST.get('info_dict'))
    # print (WallaIE._TEST.get('info_dict').get('id'))
    assert WallaIE._TEST.get('info_dict').get('id') == '2642630'
    print ('TEST OK!')

# test_WallaIE()

# Generated at 2022-06-22 08:50:27.118231
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.WallaIE()

# Generated at 2022-06-22 08:50:28.332530
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj is not None

# Generated at 2022-06-22 08:50:31.053048
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    constructor test
    """
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:39.724581
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'Walla'
    assert ie.IE_DESC == 'Walla'


# Generated at 2022-06-22 08:50:46.179676
# Unit test for constructor of class WallaIE
def test_WallaIE():
  url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
  ie = WallaIE(url)
  assert ie.video_id == '2642630'
  assert ie._TEST['url'] == url
  assert ie._TEST['info_dict']['url'] == url
  assert ie._TEST['info_dict']['id'] == '2642630'
  assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
  assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-22 08:50:53.085518
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test constructor of class WallaIE
    """
    extractor = WallaIE()
    assert extractor._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert extractor._SUBTITLE_LANGS == {'עברית': 'heb'}


# Generated at 2022-06-22 08:50:54.572661
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()(WallaIE()._VALID_URL)

# Generated at 2022-06-22 08:50:57.132820
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE()
    assert i.get_url() == WallaIE._VALID_URL
    assert i.get_test() == WallaIE._TEST

# Generated at 2022-06-22 08:50:57.797973
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _ = WallaIE()

# Generated at 2022-06-22 08:50:59.017268
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # this is a content video
    IE = WallaIE('test')

# Generated at 2022-06-22 08:51:09.335287
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert obj.VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:51:15.979358
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE.suitable(url) == True
    assert WallaIE.__name__ == 'Walla'

    # Check that the constructor works
    obj = WallaIE(url)
    assert obj.url == url

# Generated at 2022-06-22 08:51:25.799926
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # test constructor
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:51:48.303594
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'
   

# Generated at 2022-06-22 08:51:50.826293
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:51:51.769653
# Unit test for constructor of class WallaIE
def test_WallaIE():
	v = WallaIE()


# Generated at 2022-06-22 08:51:56.542144
# Unit test for constructor of class WallaIE
def test_WallaIE():
    constructor_test({
        'IE': 'Walla',
        'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
        'test': WallaIE._TEST,
    })

# Generated at 2022-06-22 08:52:02.171684
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one") is not None

# Generated at 2022-06-22 08:52:04.392101
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('')

    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-22 08:52:05.016179
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:52:16.216124
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:52:17.314403
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Add some unit tests
    pass

# Generated at 2022-06-22 08:52:21.932834
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test to create instance of WallaIE class
    # It should work with no exception raised
    WallaIE(None)
    # Check if it supports the url
    ie = WallaIE(None)
    assert ie.suported('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:52:45.843857
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl'
    WallaIE(url)

# Generated at 2022-06-22 08:52:46.914471
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()
    test.test()

# Generated at 2022-06-22 08:52:57.397469
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(['walla'])
    assert ie.SUFFIX == ['walla']
    assert ie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:53:08.316745
# Unit test for constructor of class WallaIE

# Generated at 2022-06-22 08:53:09.359377
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie != None

# Generated at 2022-06-22 08:53:20.426435
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-22 08:53:30.792348
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:53:33.480979
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST == WallaIE._TEST
    assert WallaIE()._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS


# Generated at 2022-06-22 08:53:35.720291
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('')
    assert isinstance(ie, WallaIE)


# Generated at 2022-06-22 08:53:39.165861
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:54:39.281558
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    match = WallaIE._VALID_URL.match(video_url)
    assert match.group('id') == '2642630'
    assert match.group('display_id') == 'one-direction-all-for-one'

    # Test for the case that an exception is raised
    import sys
    from io import BytesIO as StringIO
    sys_stdout = sys.stdout
    sys.stdout = io = StringIO()
    try:
        raise Exception('Test')
    except:
        import traceback
        traceback.print_exc(file=io)
    exception_str = io.getvalue()
    sys.stdout = sys_stdout

# Generated at 2022-06-22 08:54:47.350799
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST.get("url") == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._download_xml("url", "display_id") == "video"
    assert ie._real_extract("url") == "video"
    assert ie._SUBTITLE_LANGS["עברית"] == 'heb'

# Generated at 2022-06-22 08:54:55.774554
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    assert(ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert('id' in ie._TEST['info_dict'] and ie._TEST['info_dict']['id'] == '2642630')

# Generated at 2022-06-22 08:54:58.242568
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert 'Walla' in ie.IE_NAME

# Generated at 2022-06-22 08:55:05.762708
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #print('start test of WallaIE')

    # test with private function _download_xml
    def _download_xml(self,url_or_request, video_id, note=None, errnote=None, fatal=True):
        #print('start test of function _download_xml')
        url_or_request = url_or_request.replace('@@', '@')
        #print('url_or_request:', url_or_request)
        return "url_or_request"

    WallaIE._download_xml = _download_xml
    url='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)

    # test with private function _real_extract

# Generated at 2022-06-22 08:55:14.648284
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert (WallaIE._VALID_URL == 
            r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-22 08:55:16.262637
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:55:17.425350
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-22 08:55:26.817326
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import sys

    if sys.version_info[0] >= 3:
        from unittest.mock import Mock
    else:
        from mock import Mock

    # Test constructor with a mock object
    info_dict = {
        'id': '2642630',
        'display_id': 'one-direction-all-for-one',
        'ext': 'flv',
        'title': 'וואן דיירקשן: ההיסטריה',
        'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        'thumbnail': r're:^https?://.*\.jpg',
        'duration': 3600,
    }

# Generated at 2022-06-22 08:55:28.511401
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ieExt = WallaIE()
    assert str(ieExt) == 'Walla'

# Generated at 2022-06-22 08:57:34.993760
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert "WallaIE" in ie.IE_NAME
    assert "Walla" in ie.IE_DESC
    assert "walla" in ie.rul

# Generated at 2022-06-22 08:57:42.110283
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE(None)._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:57:46.304855
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:57:52.103341
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! video'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }


# Generated at 2022-06-22 08:57:54.626201
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")


# Generated at 2022-06-22 08:57:55.406738
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:58:03.263342
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE("url")
    assert wie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:58:04.560801
# Unit test for constructor of class WallaIE
def test_WallaIE():
    temp = WallaIE()

    print("Test WallaIE is passed!")

# Generated at 2022-06-22 08:58:12.236279
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:58:21.957608
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Tests the constructor of WallaIE
    """
    # Test with valid url and rtmp download
    ie = WallaIE(downloader=None, params={'rtmp-download': True})
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie._TEST == WallaIE._TEST
    assert ie._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert ie.__name__   == 'Walla'
    assert ie.IE_NAME    == 'Walla'
    assert ie.ie_key()   == 'Walla'
    assert ie.can_extract()
    # Test with invalid url and rtmp download
    ie = WallaIE(downloader=None, params={'rtmp-download': True})
    assert not ie.can_