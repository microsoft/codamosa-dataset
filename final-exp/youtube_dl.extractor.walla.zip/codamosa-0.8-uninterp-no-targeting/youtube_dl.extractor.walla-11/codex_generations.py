

# Generated at 2022-06-22 08:49:50.842575
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.name == 'Walla'
    assert ie.VALID_URL == WallaIE._VALID_URL
    assert ie.test == WallaIE._TEST

# Generated at 2022-06-22 08:50:03.650893
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE("")
    assert wallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:11.757665
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('1', '2')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:23.383881
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == \
           'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == \
           'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-22 08:50:27.417648
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    a.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:29.905101
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:32.952898
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wIE = WallaIE()
    assert wIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:33.900970
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-22 08:50:36.756763
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.url_result('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:50:38.278153
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('')
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-22 08:50:45.505983
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print('Starting test for constructor of class WallaIE...')
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wallaIE_test = WallaIE()
    wallaIE_test.download(url)
    print('Finished test for constructor of class WallaIE!')



# Generated at 2022-06-22 08:50:46.653174
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-22 08:50:51.499245
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    re_str = ie._VALID_URL
    assert re_str == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:50:53.882558
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for a constructed class WallaIE
    assert WallaIE._VALID_URL



# This is a test for the WallaIE class

# Generated at 2022-06-22 08:50:54.993966
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-22 08:50:59.536609
# Unit test for constructor of class WallaIE
def test_WallaIE():
    if __name__ == "__main__":
        url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
        IE = WallaIE()
        assert(IE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')



# Generated at 2022-06-22 08:51:05.192948
# Unit test for constructor of class WallaIE
def test_WallaIE():
    tester = WallaIE()
    tester._download_xml = lambda x, y: '<html></html>'
    tester._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    tester._real_extract('http://vod.walla.co.il/item/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:51:07.120320
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one').test()

# Generated at 2022-06-22 08:51:19.381930
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import BaseIE
    from . import WallaIE
    assert issubclass(WallaIE, BaseIE)
    assert WallaIE._VALID_URL[0] == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['id'] == '2642630'
    assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-22 08:51:23.862617
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-22 08:51:40.708358
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_class = WallaIE()
    test_case = test_class._TEST
    valid_url = test_case['url']
    test_instance = WallaIE(url= valid_url)
    assert test_instance._VALID_URL == test_class._VALID_URL
    assert test_instance._TEST == test_case
    assert test_instance._SUBTITLE_LANGS == test_class._SUBTITLE_LANGS

# Generated at 2022-06-22 08:51:48.234571
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:51:49.129219
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.IE_NAME



# Generated at 2022-06-22 08:51:51.886940
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for constructor of class WallaIE"""
    this = WallaIE()
    this = WallaIE(this.options, this.params)
    return this


# Generated at 2022-06-22 08:51:55.281438
# Unit test for constructor of class WallaIE
def test_WallaIE():

    params = {'url': 'url', 'downloader': 'downloader', 'ie': 'ie'}

    WallaIE(params)

# Generated at 2022-06-22 08:51:55.999380
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_WallaIE_object = WallaIE()

# Generated at 2022-06-22 08:52:07.621012
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie= WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.module == 'WallaIE'
    assert ie.module == ie.IE_NAME
    assert ie.module in ie.supported_ie_list()
    assert ie.module in ie.get_info(ie.module)['extractor']
    info = ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert info['id'] == '2642630'
    assert info['display_id'] == 'one-direction-all-for-one'
    assert info['ext'] == 'flv'

# Generated at 2022-06-22 08:52:12.736616
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._TEST['url'] == w.TEST_URL
    assert w._VALID_URL == w.VALID_URL
    assert w._TEST['info_dict'] == w.TEST_INFO_DICT
    assert w._TEST['params'] == w.TEST_PARAMS

# Generated at 2022-06-22 08:52:17.417732
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for constructor without any parameters
    assert(WallaIE() is not None)

    # Test for constructor with a whitespace
    assert(WallaIE(video_id=' ') is not None)

    # Test for constructor with video_id
    assert(WallaIE(video_id='2642630') is not None)

# Generated at 2022-06-22 08:52:21.287767
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = type('Test', (object,), dict(
        _download_xml=lambda x, y: y,
        _sort_formats=lambda x, y: y))
    ie = WallaIE()
    ie._real_extract('walla', IE)

# Generated at 2022-06-22 08:52:47.868398
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:52:52.459127
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:53:02.308727
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    WallaIE(url)
    assert WallaIE(url)._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:53:11.226936
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:53:16.149200
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    print(ie._VALID_URL)
    print(ie._TEST)
    print(ie._SUBTITLE_LANGS)

# Generated at 2022-06-22 08:53:17.185678
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE())

# Generated at 2022-06-22 08:53:20.220527
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(None)._real_extract(url)

# Generated at 2022-06-22 08:53:23.102592
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'WallaIE'
    assert ie.ie_name() == 'Walla'

# Generated at 2022-06-22 08:53:28.035464
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(ie.VALID_URL)
    assert(ie.TEST)
    assert(ie.SUBTITLE_LANGS)
    assert(ie.real_extract)

# Generated at 2022-06-22 08:53:30.680507
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-22 08:54:20.204317
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()


# Generated at 2022-06-22 08:54:21.202519
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:54:21.791601
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:54:23.084627
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(isinstance(ie, InfoExtractor))

# Generated at 2022-06-22 08:54:30.933330
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
                 lambda x: [x])
    result = ie.url_result('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', get_title=lambda x: "title")
    assert result["url"] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert result["ie_key"] == "Walla"
    assert ie.url_result('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', get_title=lambda x: "title") == result


# Generated at 2022-06-22 08:54:39.604356
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    result = ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert result['id'] == '2642630', 'Test WallaIE: constructor: id'
    assert result['display_id'] == 'one-direction-all-for-one', 'Test WallaIE: constructor: display-id'
    assert result['ext'] == 'flv', 'Test WallaIE: constructor: ext'
    assert result['title'] == 'וואן דיירקשן: ההיסטריה', 'Test WallaIE: constructor: title'

# Generated at 2022-06-22 08:54:49.076252
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class WallaClass:
        def __init__(self):
            self.id = ""
            self.display_id = ""
            self.title = ""
            self.description = ""
            self.thumbnail = ""
            self.duration = ""
            self.formats = []
            self.subtitles = {}

    inp = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    obj = WallaIE()
    out = obj._real_extract(inp)
    outObj = WallaClass()

    outObj.id = out['id']
    outObj.display_id = out['display_id']
    outObj.title = out['title']
    outObj.description = out['description']
    outObj.thumbnail = out

# Generated at 2022-06-22 08:54:58.678261
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:55:02.865262
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie.ie_version() == '0.1'

# Generated at 2022-06-22 08:55:04.293422
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__ == WallaIE

# Generated at 2022-06-22 08:57:08.082991
# Unit test for constructor of class WallaIE

# Generated at 2022-06-22 08:57:08.963600
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE().suite()

# Generated at 2022-06-22 08:57:12.377667
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:57:21.547020
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:57:32.408393
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:57:33.937163
# Unit test for constructor of class WallaIE
def test_WallaIE():
	class_ = WallaIE()
	assert class_.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:57:36.636981
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video = WallaIE()
    video._download_xml('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl', 'one-direction-all-for-one')

# Generated at 2022-06-22 08:57:43.082666
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('rtmp://wafla.walla.co.il/vod', {'play_path': 'foo/bar/d.flv', 'page_url': 'http://foo.bar', 'player_url': 'http://www.walla.co.il/swf/video_player.swf?vid=12345', 'ext': 'flv'}, 'foo')

# Generated at 2022-06-22 08:57:44.376558
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:57:46.880413
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')