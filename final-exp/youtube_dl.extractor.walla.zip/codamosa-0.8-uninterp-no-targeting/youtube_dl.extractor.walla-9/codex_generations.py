

# Generated at 2022-06-22 08:49:51.539496
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor of class WallaIE
    ie = WallaIE()
    ie._VALID_URL = 'http://vod.walla.co.il/movie'
    ie._SUBTITLE_LANGS = {}

    # Test constructor of class InfoExtractor
    ie = InfoExtractor()

# Generated at 2022-06-22 08:49:52.771333
# Unit test for constructor of class WallaIE

# Generated at 2022-06-22 08:49:53.906413
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:49:57.852910
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    return ie

# Generated at 2022-06-22 08:49:58.430140
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-22 08:49:59.042577
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-22 08:50:00.709694
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:50:02.024110
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Tests for class WallaIE"""
    WallaIE()

# Generated at 2022-06-22 08:50:11.555618
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-22 08:50:17.446818
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.video_id == '2642630'
    assert ie.display_id == 'one-direction-all-for-one'

# Generated at 2022-06-22 08:50:31.040723
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.ie_key() == 'Walla'
    assert ie.video_id == '2642630'
    assert ie.display_id == 'one-direction-all-for-one'

# Generated at 2022-06-22 08:50:33.634910
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test that constructs the `WallaIE` class and
    checks if it is a subclass of `InfoExtractor`.
    """

    WallaIE()
    print("Unit test for constructor of class WallaIE succeed!")


# Generated at 2022-06-22 08:50:34.571556
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check that the class can be initialized
    ie = WallaIE()


# Generated at 2022-06-22 08:50:35.194340
# Unit test for constructor of class WallaIE
def test_WallaIE():
	pass

# Generated at 2022-06-22 08:50:41.966455
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TEST == ie.TEST
    # assert ie._SUBTITLE_LANGS == ie.SUBTITLE_LANGS

    assert ie._real_extract == ie._real_extract

# Generated at 2022-06-22 08:50:42.764706
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:50:49.990184
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://vod.walla.co.il')
    assert not ie.suitable('http://news.walla.co.il/')
    assert ie.IE_NAME == 'walla.co.il:vod'

# Generated at 2022-06-22 08:50:56.643225
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_inst = WallaIE(InfoExtractor(None))
    assert_equals(test_inst.SUBTITLE_LANGS,
                  {'עברית': 'heb'})
    assert_equals(test_inst.VALID_URL,
                  r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')


# Generated at 2022-06-22 08:50:59.524578
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == "^https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)$"

# Generated at 2022-06-22 08:51:08.646062
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # run constructor WallaIE
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # assert url is correct
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # assert ie.id is correct
    assert ie.id == '2642630'
    # assert ie.display id is correct
    assert ie.display_id == 'one-direction-all-for-one'
    # assert ie.thumbnail is correct
    # assert ie.description is correct
    # assert ie.duration is correct
    # assert ie.subtitles is correct


# Generated at 2022-06-22 08:51:24.058032
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import FakeYDL
    walla = WallaIE()
    walla._downloader = FakeYDL()
    walla._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:51:28.583263
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test unit for WallaIE class."""
    walla_url = WallaIE()._VALID_URL
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert re.match(walla_url, url) is not None


# Generated at 2022-06-22 08:51:29.493602
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-22 08:51:41.023212
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie._VALID_URL==r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(ie._TEST['url']== 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(ie._TEST['info_dict']['id']== '2642630')
    assert(ie._TEST['info_dict']['display_id']== 'one-direction-all-for-one')
    assert(ie._TEST['info_dict']['ext']== 'flv')

# Generated at 2022-06-22 08:51:48.476350
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:51:50.844216
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE(None)
    assert obj.ie_key() == 'Walla'
    assert obj.SUCCESS

# Generated at 2022-06-22 08:51:51.421807
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:52:01.607443
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    assert(w != None)
    assert(w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(w._TEST != None)
    assert(w._download_xml != None)
    assert(w._real_extract != None)
    assert(w._SUBTITLE_LANGS != None)
    assert(w._SUBTITLE_LANGS.get('עברית') == 'heb')
    assert(w._SUBTITLE_LANGS.get('engish') == None)

# Generated at 2022-06-22 08:52:02.225913
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-22 08:52:04.020612
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("WallaIE", "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-22 08:52:25.812462
# Unit test for constructor of class WallaIE
def test_WallaIE():
	obj = WallaIE()

# Generated at 2022-06-22 08:52:32.671986
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()
	assert ie.url is None
	assert ie.display_id is None
	assert ie.video_id is None
	assert ie.rating is None
	assert ie.rating_count is None
	assert ie.categories is None
	assert ie.age_limit is None
	assert ie.like_count is None
	assert ie.dislike_count is None
	assert ie.extractors is None



# Generated at 2022-06-22 08:52:33.740949
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-22 08:52:36.373579
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-22 08:52:37.573386
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()


# Generated at 2022-06-22 08:52:43.677191
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wallaIE = WallaIE()
    info = wallaIE._real_extract(url)
    assert info['id'] == video_id
    assert info['display_id'] == display_id
    assert info['title'] == 'וואן דיירקשן: ההיסטריה'
    assert (info['description'] ==
            'md5:de9e2512a92442574cdb0913c49bc4d8')

# Generated at 2022-06-22 08:52:44.867369
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:52:51.757678
# Unit test for constructor of class WallaIE
def test_WallaIE():
    result = WallaIE()
    assert result.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert result.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/')
    assert result.suitable('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one/')
    assert not result.suitable('http://vod.walla.co.il/movie/2642630/')
    assert not result.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/asdf')

# Generated at 2022-06-22 08:53:01.861143
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:53:06.466774
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.name() == 'walla'
    assert ie._downloader.params['noprogress'] == True

# Generated at 2022-06-22 08:53:54.774590
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.__name__ == 'Walla'

# Generated at 2022-06-22 08:54:05.025599
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:54:08.890179
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for constructor of class WallaIE.
    """
    assert WallaIE()


# Generated at 2022-06-22 08:54:12.384052
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._download_xml("http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl", "one-direction-all-for-one");

# Generated at 2022-06-22 08:54:23.656578
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL==r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:54:24.518296
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-22 08:54:27.614126
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print('test_WallaIE')
    ie = WallaIE()
    ie.download('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    #ie.download(sys.argv[1])


# Generated at 2022-06-22 08:54:30.393866
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-22 08:54:31.167781
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test exsist
    return WallaIE(True)

# Generated at 2022-06-22 08:54:35.701085
# Unit test for constructor of class WallaIE
def test_WallaIE():
    json_obj = {
        'description': 'description',
        'title': 'title',
        'id': 'id',
        'display_id': 'display_id',
    }
    obj = WallaIE(json_obj)
    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:56:31.373621
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    assert str(instance) == "WallaIE {}"

# Generated at 2022-06-22 08:56:31.834153
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-22 08:56:38.144678
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """

    # URL with valid id
    video_url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    # Create instance of WallaIE
    w = WallaIE(WallaIE._VALID_URL)
    # Call function _real_extract(video_url)
    w._real_extract(video_url)
    # If call returns none then test passed

test_WallaIE()

# Generated at 2022-06-22 08:56:46.639171
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import inspect
    import sys
    import unittest

    if 'WallaIE' in sys.modules:
        del sys.modules['WallaIE']

    from .WallaIE import WallaIE

    # Tests
    class WallaIETestCase(unittest.TestCase):

        def test_constructor(self):
            member_names = dir(WallaIE)
            constructor_member_names = dir(WallaIE())
            # make sure the constructor did not add undesired members
            self.assertEqual(
                len(member_names), len(constructor_member_names),
                'constructor added undesired members')

# Generated at 2022-06-22 08:56:54.937727
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info = WallaIE()._real_extract(WallaIE()._TEST['url'])
    assert info['id'] == '2642630'
    assert info['display_id'] == 'one-direction-all-for-one'
    assert info['ext'] == 'flv'
    assert info['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-22 08:56:59.407532
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    video = WallaIE._real_extract(WallaIE(), url)
    assert video['display_id'] == 'one-direction-all-for-one'
    assert video['id'] == '2642630'

# Generated at 2022-06-22 08:57:09.041090
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-22 08:57:21.044213
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert WallaIE.suitable('http://vod.walla.co.il/item/2642630/one-direction-all-for-one')
    assert WallaIE.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one?a=b')
    assert WallaIE.suitable('http://vod.walla.co.il/item/2642630/one-direction-all-for-one?a=b')
    assert not WallaIE.suitable('http://vod.walla.co.il/movie/2642630/')
    assert not WallaIE.suitable

# Generated at 2022-06-22 08:57:24.030400
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test constructor for class WallaIE"""
    ie=WallaIE(None);
    assert isinstance(ie,InfoExtractor)
    assert isinstance(ie,WallaIE)

# Generated at 2022-06-22 08:57:28.578035
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Create an instance of WallaIE
	#walla = WallaIE(InfoExtractor)
	#assert isinstance(walla, WallaIE)
	#assert issubclass(walla, InfoExtractor)
	#assert isinstance(walla, InfoExtractor)
	pass

