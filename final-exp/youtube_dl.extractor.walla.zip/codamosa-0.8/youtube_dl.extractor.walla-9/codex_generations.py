

# Generated at 2022-06-12 18:49:00.133911
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE(None)
    obj.init()

# Generated at 2022-06-12 18:49:00.656354
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:49:04.185222
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    # Test if the URL is valid (a Walla URL)
    is_valid = bool(re.match(ie._VALID_URL, url))
    assert is_valid

# Generated at 2022-06-12 18:49:06.082159
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:49:07.116617
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    assert ie is not None

# Generated at 2022-06-12 18:49:08.935412
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test 1:
    # Test that when we construct WallaIE with a valid url,
    # the object is successfully created
    WallaIE(walla_url)



# Generated at 2022-06-12 18:49:12.231584
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for WallaIE
    t1 = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert t1.name == 'Walla'

# Generated at 2022-06-12 18:49:15.290591
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_case = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(test_case.__class__.__name__ == 'WallaIE')

# Generated at 2022-06-12 18:49:16.935201
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE("test_WallaIE", "test_WallaIE");
    assert obj

# Generated at 2022-06-12 18:49:21.984169
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from . import WallaIE
    wal = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-12 18:49:38.875169
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extractor = None
    ie.IE_NAME = None
    ie.ie_key = None
    ie.host = None
    ie.extractor_key = None
    ie.ie = None
    # in case of constructor as follows:
    # def __init__(self):
    #     ie_key = 'walla'
    #     ie = WallaIE
    assert ie.ie_key is None
    assert ie.ie is None
    assert ie.extractor is None
    assert ie.IE_NAME is None
    assert ie.host is None
    assert ie.extractor_key is None


# Generated at 2022-06-12 18:49:40.546079
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('1', {}, {}, {})

# Generated at 2022-06-12 18:49:45.803725
# Unit test for constructor of class WallaIE
def test_WallaIE():
    '''
    A unit test for the constructor of class WallaIE with the following parameters
    :param url: http://vod.walla.co.il/movie/2642630/one-direction-all-for-one
    :return: A WallaIE object
    '''
    wallaIE = WallaIE()
    assert isinstance(wallaIE, WallaIE)
    # TODO: add more assert for testing WallaIE object

# Generated at 2022-06-12 18:49:53.280035
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    The constructor of WallaIE
    """
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:55.682594
# Unit test for constructor of class WallaIE
def test_WallaIE():
   # Checks if the constructor of class WallaIE is working properly
   assert WallaIE().ie_key() == 'Walla'

# Generated at 2022-06-12 18:49:59.206740
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    title = 'שקט'
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    t = ie.extract_info(url)
    assert t['title'] == title

# Generated at 2022-06-12 18:50:03.265610
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Using the url of the test
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE()._real_extract(url)

# Generated at 2022-06-12 18:50:12.649369
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Test that an instance of WallaIE is returned,
    # and that the following attributes are defined and not empty.
    ie = WallaIE(url)
    assert ie.url == url 
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:50:17.258419
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(test_WallaIE.TEST['url'])
    test_WallaIE.TEST.update(ie.result)


# Generated at 2022-06-12 18:50:25.218488
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:51.844803
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:57.384850
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', {})
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'


# Generated at 2022-06-12 18:50:57.894628
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global object
    object = WallaIE()

# Generated at 2022-06-12 18:51:02.275516
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE()
    assert i._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:51:09.738487
# Unit test for constructor of class WallaIE
def test_WallaIE():

    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    mobj = WallaIE._match_id(url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')

    video = WallaIE._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id)

    item = video.find('./items/item')

    title = WallaIE._text(item.find('./title'))
    description = WallaIE._text(item.find('./synopsis'))

# Generated at 2022-06-12 18:51:14.346175
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_url = 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    assert ie.suitable(video_url) == True
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla video'

# Generated at 2022-06-12 18:51:16.208821
# Unit test for constructor of class WallaIE
def test_WallaIE():
	wallaIE = WallaIE()
	print(wallaIE)
	return wallaIE


# Generated at 2022-06-12 18:51:17.454208
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """ This should fail."""
    name = 'WallaIE'
    WallaIE(name)

# Generated at 2022-06-12 18:51:23.515197
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _WallaIE = WallaIE("url")
    assert _WallaIE.VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"

# Generated at 2022-06-12 18:51:25.002859
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global IE_DESC
    ie = WallaIE()

# Generated at 2022-06-12 18:52:24.739326
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("")._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"
    assert WallaIE("")._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert WallaIE("")._SUBTITLE_LANGS['עברית'] == "heb"
    print("Unit test completed for class WallaIE")

if __name__ == "__main__":
    test_WallaIE()

# Generated at 2022-06-12 18:52:26.539224
# Unit test for constructor of class WallaIE
def test_WallaIE():
    '''
    This unit test checks if WallaIE is properly initialized.
    '''
    ie = WallaIE()
    print('{} is initialized: {}'.format(ie, ie is not None))



# Generated at 2022-06-12 18:52:29.932526
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE().GET('vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-12 18:52:34.535671
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    w = WallaIE()
    w.extract(url)
    assert w.url
    print(w.url)

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-12 18:52:37.893309
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # check that the method _real_extract is defined (public)
    assert hasattr(ie,'_real_extract')
    # check that the method _real_extract is not defined (private)
    assert not hasattr(ie,'_WallaIE__real_extract')

# Generated at 2022-06-12 18:52:45.175288
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    assert ie.IS_SUITABLE
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:52:46.546608
# Unit test for constructor of class WallaIE
def test_WallaIE():
	test_WallaIE = WallaIE()
	test_WallaIE.test()

# Generated at 2022-06-12 18:52:47.679118
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one", None, None)

# Generated at 2022-06-12 18:52:49.573439
# Unit test for constructor of class WallaIE
def test_WallaIE():
    g = globals()
    l = locals()
    ie = WallaIE(g, l)
    assert ie.__name__ == 'WallaIE'

# Generated at 2022-06-12 18:52:50.541756
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST == WallaIE._TEST

# Generated at 2022-06-12 18:54:56.339824
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from walla import WallaIE
    wie = WallaIE()
    assert wie != None


# Generated at 2022-06-12 18:54:58.970647
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:55:00.513882
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Would fail if object is not of class WallaIE
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-12 18:55:02.298992
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie == WallaIE

# Generated at 2022-06-12 18:55:03.389178
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie != None


# Generated at 2022-06-12 18:55:04.813541
# Unit test for constructor of class WallaIE
def test_WallaIE():
	test_Walla = WallaIE()
	assert isinstance(test_Walla, WallaIE)


# Generated at 2022-06-12 18:55:05.550165
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None, None).valid

# Generated at 2022-06-12 18:55:06.923332
# Unit test for constructor of class WallaIE
def test_WallaIE():
    vod_walla = WallaIE()
    assert vod_walla is not None

# Generated at 2022-06-12 18:55:09.553187
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('empty')
    # assert that _SUBTITLE_LANGS is a dictionary
    for key,value in ie._SUBTITLE_LANGS.items() :
            assert(unicode)
            assert(unicode)

# Generated at 2022-06-12 18:55:11.552794
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie._VALID_URL == 'http://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')