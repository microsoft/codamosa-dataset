

# Generated at 2022-06-12 18:48:59.375236
# Unit test for constructor of class WallaIE
def test_WallaIE():

    from .WallaTest import WallaTest
    from .WallaTest import test_WallaIE

    w = WallaTest()
    w.setUp()
    w.test_WallaIE()

# Generated at 2022-06-12 18:49:07.393080
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == re.compile('https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert w._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert w._TEST['info_dict']['id'] == '2642630'
    assert w._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert w._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-12 18:49:16.382035
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-12 18:49:20.177519
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie._VALID_URL, str)
    assert isinstance(ie._TEST, dict)
    assert isinstance(ie._SUBTITLE_LANGS, dict)

# Generated at 2022-06-12 18:49:26.736362
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("https://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-12 18:49:28.604990
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("")
    assert ie is not None

# Generated at 2022-06-12 18:49:31.263375
# Unit test for constructor of class WallaIE
def test_WallaIE():
	w_i_e = WallaIE()
	w_i_e.extract(test_WallaIE)

# Generated at 2022-06-12 18:49:35.632540
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.url_result('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.url_result('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:49:40.321673
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test constructor WallaIE with url
    url = WallaIE._VALID_URL.replace('www', 'vod')
    walla_url = WallaIE(url)
    assert walla_url._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-12 18:49:49.224991
# Unit test for constructor of class WallaIE
def test_WallaIE():
	walla_ie = WallaIE()
	if(walla_ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'):
		print("VALID_URL is correct")
	else:
		print("VALID_URL is incorrect")

# Generated at 2022-06-12 18:50:02.692321
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    WallaIE(walla_co_il, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:12.444722
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'

    # Test case 1
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE._VALID_URL = re.compile(WallaIE._VALID_URL)
    assert WallaIE._VALID_URL.match(url) is not None

    # Test case 2
    mobj = re.match(WallaIE._VALID_URL, url)
    assert mobj.group('id') == video_id
    assert mobj.group('display_id') == display_id

    # Test case 3
    assert WallaIE._TEST['url'] == url

# Generated at 2022-06-12 18:50:16.861189
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-12 18:50:19.200608
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:23.584491
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = 2642630
    url = 'http://vod.walla.co.il/movie/' + str(video_id) + '/one-direction-all-for-one'
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:24.698167
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:50:26.056306
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('www.walla.co.il', {'fmt_id': '9'})

# Generated at 2022-06-12 18:50:28.128402
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'

# Generated at 2022-06-12 18:50:30.181706
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import pytest

    # Constructor of class WallaIE must raise exception if URL is invalid
    with pytest.raises(Exception):
        WallaIE()._real_extract('http://vod.walla.co.il/movie/')

# Generated at 2022-06-12 18:50:31.602852
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check if the constructor of class WallaIE works without fail
    WallaIE()

# Generated at 2022-06-12 18:51:00.512767
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test instantiation of WallaIE class
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    
    # Test to check if url is fetched from url or not
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert ie.url == url
    
    # Test if the class is instance of Youtube object
    assert isinstance(ie,WallaIE)

# Generated at 2022-06-12 18:51:08.556722
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Downloader.download_object is not implemented yet
    class Downloader:
        def __init__(self, params):
            self.params = params
    video = WallaIE._real_extract(Downloader({
        'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
    }))
    assert video['id'] == '2642630'
    assert video['display_id'] == 'one-direction-all-for-one'
    assert 'title' in video
    assert 'description' in video
    assert 'thumbnail' in video
    assert video['duration'] == 3600
    assert 'formats' in video
    format = video['formats'][0]

# Generated at 2022-06-12 18:51:14.346534
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test the constructor using url, url_type and class name instead of url_type
    """
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = InfoExtractor.ie_key_map.get('Walla', WallaIE)(url)
    assert ie.url_type == 'Walla'

# Generated at 2022-06-12 18:51:16.214524
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import youtube_dl

# Generated at 2022-06-12 18:51:19.106094
# Unit test for constructor of class WallaIE
def test_WallaIE():
    
    """
    Test if a constructed object is instance of YoutubeIE.
    """

    ie = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:51:20.518484
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE({})
    assert obj._SUBTITLE_LANGS.get('עברית') == 'heb'

# Generated at 2022-06-12 18:51:23.213158
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()
    if test is None:
        print('Failed to create instance of class WallaIE')
        exit(1)

test_WallaIE()

# Generated at 2022-06-12 18:51:27.149572
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.IE_NAME == 'walla')
    assert(ie.VALID_URL == _VALID_URL)
    assert(ie.SUBTITLE_LANGS == _SUBTITLE_LANGS)

# Generated at 2022-06-12 18:51:28.689682
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(WallaIE(), WallaIE)

# Generated at 2022-06-12 18:51:37.929581
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    # Default value of host should be 'vod.walla.co.il'
    assert ie._HOST == 'vod.walla.co.il'

    # Default value of IE_NAME should be 'walla'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:52:04.752400
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(ie._TEST.get('url') == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(ie._TEST.get('info_dict').get('id') == '2642630')
    assert(ie._TEST.get('info_dict').get('display_id') == 'one-direction-all-for-one')
    assert(ie._TEST.get('info_dict').get('ext') == 'flv')

# Generated at 2022-06-12 18:52:07.653474
# Unit test for constructor of class WallaIE
def test_WallaIE():
	test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	ex = WallaIE()
	result = ex._real_extract(test_url)

# Generated at 2022-06-12 18:52:14.295725
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL

    test_WallaIE._TEST['url']
    test_WallaIE._TEST['info_dict']
    test_WallaIE._TEST['params']

    mobj = re.match(WallaIE._VALID_URL, test_WallaIE._TEST['url'])
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')

# Generated at 2022-06-12 18:52:15.734896
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie != None

# Generated at 2022-06-12 18:52:18.942815
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == "walla"
    assert ie.IE_DESC == "Walla"
    assert ie.VALID_URL == _VALID_URL
    assert ie.TEST == _TEST

# Generated at 2022-06-12 18:52:27.930929
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:52:35.615633
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .test_utils import TestIE
    from ytdl_server.ttypes import Request

    # Sample request
    request = Request(
        url='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
        method='GET',
        headers={},
        body='')

    # Create a WallaIE object
    ie = TestIE(request)
    ie.run()

    # Check that class is of expected type
    assert isinstance(ie, WallaIE)


# Generated at 2022-06-12 18:52:37.749951
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.SUCCESS == ie.initialize()
    assert ie.get_num_courses() == 0
    assert ie.get_num_videos() == 0


# Generated at 2022-06-12 18:52:44.560462
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import test_video_regex, test_video_id, test_extractors
    from .common import test_video_id_param, test_download_url
    from .common import test_subtitles

    # Test: Call the constructor
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', test_subtitles)

    # Test: Call the test_video_regex 
    test_video_regex(WallaIE)

    # Test: Call the test_extractors
    test_extractors(WallaIE)

    # Test: Call the test_download_url
    test_download_url(WallaIE)

    # Test: Call the test_video_id_param
    test_video_id_param

# Generated at 2022-06-12 18:52:50.616098
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)', WallaIE._VALID_URL
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb', WallaIE._SUBTITLE_LANGS
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', WallaIE._TEST['url']

    if __name__ == '__main__':
        WallaIE.test()

# Generated at 2022-06-12 18:53:49.161572
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._download_xml = lambda url, video_id: video_id
    ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:53:50.374039
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://www.theurl.com')

# Generated at 2022-06-12 18:53:51.141109
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == 'Walla'

# Generated at 2022-06-12 18:53:54.220107
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE('rtmp://wafla.walla.co.il/vod/').play_path == '')
    assert(WallaIE('rtmp://wafla.walla.co.il/vod/test').play_path == 'test')

# Generated at 2022-06-12 18:54:00.215877
# Unit test for constructor of class WallaIE
def test_WallaIE():
	test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:54:01.804347
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()
    assert type(IE) is not None

# Generated at 2022-06-12 18:54:11.443845
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # The test string of the constructor
    tstr = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    mobj = re.match(WallaIE._VALID_URL, tstr)
    # Testing the match object
    assert mobj is not None
    assert mobj.groupdict()['id'] == '2642630'
    assert mobj.groupdict()['display_id'] == 'one-direction-all-for-one'
    # Testing the class
    walla_video = WallaIE(mobj)
    assert walla_video != None
    assert walla_video.endswith("/2642630/one-direction-all-for-one")
    assert WallaIE.ie_key() == 'walla'

# Generated at 2022-06-12 18:54:17.189734
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert (WallaIE("WallaIE")._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert (WallaIE("WallaIE")._REQUIRED_FIELDS == {'title', 'description', 'duration', 'thumbnail'})
    assert (WallaIE("WallaIE")._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert (WallaIE("WallaIE")._TEST['info_dict']['id'] == '2642630')

# Generated at 2022-06-12 18:54:26.466192
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:54:29.832616
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)

# Generated at 2022-06-12 18:56:34.097542
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()

# Generated at 2022-06-12 18:56:42.127525
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import unittest
    class TestWallaIE(unittest.TestCase):
        class MockWallaIE(WallaIE):
            def _real_extract(self,url):
                return dict()
        def test_WallaIE_should_be_instance_of_InfoExtractor(self):
            self.assertTrue(issubclass(WallaIE,InfoExtractor))
        def test_WallaIE_should_set__VALID_URL_to_be_a_regex(self):
            self.assertIsInstance(WallaIE._VALID_URL,type(re.compile('')))
        def test_WallaIE_should_have__TEST_defined(self):
            self.assertTrue(hasattr(WallaIE,'_TEST'))

# Generated at 2022-06-12 18:56:42.926642
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();

# Generated at 2022-06-12 18:56:44.994609
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie is not None

# Generated at 2022-06-12 18:56:47.613024
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("Unit test for constructor of class WallaIE")
    video = WallaIE()
    video._download_xml('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl', 'one-direction-all-for-one')

# Generated at 2022-06-12 18:56:49.105361
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:56:50.402080
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-12 18:56:55.879334
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("Test object WallaIE")
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.extract(url)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == url
    assert ie._TEST['info_dict']['id'] ==  '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'
    assert ie._

# Generated at 2022-06-12 18:57:00.813494
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie_result = ie.extract() # prepare the test
    assert ie_result['id'] == '2642630'
    assert ie_result['display_id'] == 'one-direction-all-for-one'
    assert ie_result['filename'] == '2642630-one-direction-all-for-one'

# Generated at 2022-06-12 18:57:05.432838
# Unit test for constructor of class WallaIE
def test_WallaIE():
    if __name__ == "__main__": # needed so that the constructor test will not run on import
        IE_NAME = 'walla'
        ie = globals()[IE_NAME+'IE']()
        ie.working = False # set to False because we depend on external rtmpdump and ffmpeg
        ie_test_suite = globals()['test_'+IE_NAME]
        ie_test_suite.checkModule()
        ie_test_suite.test_WallaIE()