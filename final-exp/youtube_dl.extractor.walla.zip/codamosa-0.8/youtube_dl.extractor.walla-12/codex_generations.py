

# Generated at 2022-06-12 18:49:00.770744
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-12 18:49:02.265819
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL


# Generated at 2022-06-12 18:49:06.082709
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST

# Generated at 2022-06-12 18:49:06.812597
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('test')

# Generated at 2022-06-12 18:49:07.681805
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL ==  WallaIE()._VALID_URL

# Generated at 2022-06-12 18:49:08.109749
# Unit test for constructor of class WallaIE
def test_WallaIE():

    assert WallaIE()

# Generated at 2022-06-12 18:49:09.247789
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Initialization of WallaIE
	WallaIE()



# Generated at 2022-06-12 18:49:10.713959
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    pass

# Generated at 2022-06-12 18:49:19.266073
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:49:24.196936
# Unit test for constructor of class WallaIE
def test_WallaIE():
   try:
       test = WallaIE("WallaIE", "vod.walla.co.il", False)
   except Exception as e:
       fail("Unable to instantiate class: %s" % (e.message) )
   return True


# Generated at 2022-06-12 18:49:31.139841
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(InfoExtractor())

# Generated at 2022-06-12 18:49:31.979851
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('WallaIE').test()

# Generated at 2022-06-12 18:49:38.172705
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check for extraction of title and duration
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    # Check other function (not tested)
    ie.extract('http://vod.walla.co.il/series/2629385/one-direction-all-for-one')
    ie.extract('http://vod.walla.co.il/item/2629385/one-direction-all-for-one')
    ie.extract('http://vod.walla.co.il/trends/2629385/one-direction-all-for-one')

# Generated at 2022-06-12 18:49:47.962306
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """ Unit test for constructor of class WallaIE"""
    ie = WallaIE("walla", "walla")
    assert ie.SUFFIX == ".co.il"
    assert ie.ie_key() == "walla"
    assert ie.ie_key("walla") == "walla"
    assert ie.ie_key("Walla") == "walla"
    assert ie.ie_key("walla.co.il") == "walla"
    assert ie.ie_key("Walla.co.il") == "walla"
    assert ie.ie_key("www.walla.co.il") == "walla"
    assert ie.ie_key("www.Walla.co.il") == "walla"
    assert ie.ie_key("") == "walla"
    assert ie.ie_

# Generated at 2022-06-12 18:49:49.785302
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .unit_tests import WallaIE_test
    assert issubclass(WallaIE_test, WallaIE)

# Generated at 2022-06-12 18:49:52.597411
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:49:54.643968
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    res = repr(WallaIE())
    assert 'WallaIE("WallaIE")' == res

# Generated at 2022-06-12 18:49:57.569551
# Unit test for constructor of class WallaIE
def test_WallaIE():
  from .common import InfoExtractor
  from .walla import WallaIE
  walla_ie = WallaIE()
  assert isinstance(walla_ie, InfoExtractor)

# Generated at 2022-06-12 18:50:03.266179
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}
    ie.url_result(ie._TEST.get('url'))
    test = ie._TEST
    assert ie._VALID_URL == test['url']
    assert ie._real_extract(test['url']) == test['info_dict']

# Generated at 2022-06-12 18:50:03.641998
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-12 18:50:16.486859
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable(ie._VALID_URL)


# Generated at 2022-06-12 18:50:24.393837
# Unit test for constructor of class WallaIE
def test_WallaIE():
    s = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    s.extract_info("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-12 18:50:28.877238
# Unit test for constructor of class WallaIE
def test_WallaIE():
    exp_url = 'https://vod.walla.co.il/w/c/3/3/1/3/@/331334/'
    exp_playpath = 'mp4:2014/11/30/15/331334.mp4'
    exp_page_url = 'https://vod.walla.co.il/w/c/3/3/1/3/@/331334/'
    exp_ext = 'flv'
    exp_format_id = '720p'
    exp_format_url = 'rtmp://wafla.walla.co.il/vod'
    exp_format_player_url = 'http://isc.walla.co.il/w9/swf/video_swf/vod/WallaMediaPlayerAvod.swf'
   

# Generated at 2022-06-12 18:50:35.468037
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Create object of WallaIE
	wallaIE = WallaIE()
	# Get _VALID_URL
	valid_url = wallaIE._VALID_URL
	# Get _TEST dict
	test = wallaIE._TEST
	# Print _VALID_URL, _TEST and __name__ (class name)

# Generated at 2022-06-12 18:50:36.337791
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-12 18:50:42.299319
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # WallaIE should extract information from the given url
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.VERSION == '0.1'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:50:45.104656
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE();
    assert i.__class__.__name__ == 'WallaIE'

# Generated at 2022-06-12 18:50:54.174155
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:51:01.315660
# Unit test for constructor of class WallaIE
def test_WallaIE():
    if not WallaIE()._downloader.params.get('test'):
        return

    # Simple test
    w = WallaIE()
    assert w.test('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True, 'Wrong URL'

    # Testing non-matching URL
    assert w.test('http://vod.walla.co.il/movie/2642630/') == False, 'Wrong URL'

# Generated at 2022-06-12 18:51:11.799359
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:51:28.743372
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_VERSION == 'test'
    assert ie.VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-12 18:51:31.119576
# Unit test for constructor of class WallaIE
def test_WallaIE():
	wallaIE = WallaIE("url")

	# Test for method name
	assert wallaIE._download_xml == InfoExtractor._download_xml

# Generated at 2022-06-12 18:51:35.494686
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    expected = WallaIE
    actual = infoExtractor_factory(url)
    assert expected == actual, 'Expected class is %s, actual %s' % (expected, actual)

# Generated at 2022-06-12 18:51:42.238722
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla!VOD'
    assert ie.ie_name() == 'Walla!VOD'
    assert ie.ie_version() == '0.0.0'
    assert ie.INFO_LABEL_KEYS == ['id', 'display_id', 'ext', 'title', 'description', 'thumbnail', 'duration', 'timestamp', 'upload_date']
    assert ie.SUCCEEDED_INIT == True

# Generated at 2022-06-12 18:51:50.418593
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE(WallaIE._downloader)._VALID_URL == WallaIE._VALID_URL
	assert WallaIE(WallaIE._downloader)._TEST['url'] == WallaIE._TEST['url']
	assert WallaIE(WallaIE._downloader)._TEST['info_dict'] == WallaIE._TEST['info_dict']
	assert WallaIE(WallaIE._downloader)._TEST['params'] == WallaIE._TEST['params']
	assert WallaIE(WallaIE._downloader)._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
	#print WallaIE._download_xml(WallaIE._downloader, WallaIE._downloader, "http://video2.walla.co.il/?w=null/null

# Generated at 2022-06-12 18:51:52.165934
# Unit test for constructor of class WallaIE
def test_WallaIE():
	walla = WallaIE()
	assert walla is not None, "Failed WallaIE constructor"

# Generated at 2022-06-12 18:51:53.476758
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    print(ie)


# Generated at 2022-06-12 18:52:00.087506
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.VALID_URL == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'


# Generated at 2022-06-12 18:52:08.179317
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Create instance of WallaIE
    walla_ie = WallaIE()
    # Check _VALID_URL for match
    match = re.match(walla_ie._VALID_URL, url)
    if not match:
        from nose.tools import assert_true
        return assert_true(False, 'Regex did not match compound URL')
    # Check _download_xml
    video_id = match.group('id')
    display_id = match.group('display_id')

# Generated at 2022-06-12 18:52:09.813972
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-12 18:52:34.973453
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()._check_class("WallaIE")

# Generated at 2022-06-12 18:52:42.815730
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(InfoExtractor())
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:52:49.087766
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class_name = 'WallaIE'
    if class_name in globals():
        WallaClass = globals()[class_name]
        # Run unit test for this class
        test = WallaClass()
        test._downloader.http.cookiejar.clear_session_cookies()
        video_id = test._TEST['info_dict']['id']
        url = test._TEST['url']
        m = re.match(test._VALID_URL, url)
        test_obj = WallaClass()
        test_obj.url = url
        assert test_obj._real_extract(url)['id'] == video_id, \
          '%s unit test failed: ID field must be %s' %(class_name, video_id)


test_WallaIE()

# Generated at 2022-06-12 18:52:51.265736
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is not None


# Generated at 2022-06-12 18:52:52.332678
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:52:53.497272
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-12 18:52:55.516475
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wv = WallaIE()

# Generated at 2022-06-12 18:52:57.164008
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(WallaIE._TEST['url'])

# Generated at 2022-06-12 18:52:58.428323
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # must succeed
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE().suitable(test_url)


# Generated at 2022-06-12 18:53:06.616333
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:54:01.890031
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL
    assert ie._TEST
    assert ie._SUBTITLE_LANGS


# Generated at 2022-06-12 18:54:02.753196
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE() is not None

# Generated at 2022-06-12 18:54:06.238632
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE().suitable(url)
    ie = WallaIE()
    ie.extract(url)

# Generated at 2022-06-12 18:54:14.490389
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one";

# Generated at 2022-06-12 18:54:19.128309
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE({})
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-12 18:54:27.381247
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:54:37.599880
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert obj.video_id == '2642630'
    assert obj.display_id == 'one-direction-all-for-one'
    assert obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# test for

# Generated at 2022-06-12 18:54:39.431028
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()
    assert wie._VALID_URL is not None
    assert wie._TEST is not None

# Generated at 2022-06-12 18:54:40.188773
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-12 18:54:42.790989
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-12 18:56:58.516155
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'Walla! VOD'
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie._TEST == WallaIE._TEST

# Generated at 2022-06-12 18:57:05.701586
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import sys
    import os, time
    import unittest
    from xml.dom.minidom import parse
    from unittest import TestCase
  
    class TestWallaIE(TestCase):
        def setUp(self):
            self.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:57:14.258321
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:57:14.668137
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:57:15.520258
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE()

# Generated at 2022-06-12 18:57:22.663277
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    title = 'וואן דיירקשן: ההיסטריה'
    description = 'md5:de9e2512a92442574cdb0913c49bc4d8'
    thumbnail = (r're:^https?://.*\.jpg')
    duration = 3600
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Create instance of WallaIE
    w = WallaIE(None)
    # Check correct initialization of item's id

# Generated at 2022-06-12 18:57:23.151299
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:57:28.135679
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE()
    assert WallaIE._VALID_URL == WallaIE.VALID_URL
    assert WallaIE._TEST == WallaIE.TEST
    assert WallaIE._SUBTITLE_LANGS == WallaIE.SUBTITLE_LANGS
    assert WallaIE._VALID_URL == info_extractor.VALID_URL
    assert WallaIE._TEST == info_extractor.TEST
    assert WallaIE._SUBTITLE_LANGS == info_extractor.SUBTITLE_LANGS
    assert WallaIE._real_extract == info_extractor._real_extract
    assert WallaIE.suitable == info_extractor.suitable
    assert WallaIE.IE_NAME == info_extractor.IE_NAME
    assert Walla

# Generated at 2022-06-12 18:57:31.564937
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-12 18:57:34.007472
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')