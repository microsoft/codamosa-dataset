

# Generated at 2022-06-12 18:48:59.184437
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/')

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-12 18:49:01.996399
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .test import TestCase

    testCase = TestCase()
    testCase._runTestCases([WallaIE])

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-12 18:49:02.903905
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-12 18:49:09.410474
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:12.151738
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()

# Generated at 2022-06-12 18:49:14.615670
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.test_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:49:20.422071
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        from youtube_dl.extractor.walla import WallaIE

        # Testing a correct URL
        test = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
        assert(test.get_video_id() == '2642630')

        # Testing an illegal URL
        test = WallaIE('https://vod.walla.co.il/movie/2642630/bad_url')
        assert(test.get_video_id() == None)
    except ImportError:
        print('Unable to import WallaIE')


# Generated at 2022-06-12 18:49:21.227617
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().IE_NAME == 'walla'

# Generated at 2022-06-12 18:49:22.495221
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # init the WallaIE
    WallaIE()

# Generated at 2022-06-12 18:49:35.044106
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(WallaIE.IE_NAME)
    _VALID_URL = WallaIE._VALID_URL
    _TEST = WallaIE._TEST
    ie._download_xml = lambda url, video_id: video_id
    ie._sort_formats = lambda formats: [format['format_id'] for format in formats]
    info = ie._real_extract('http://vod.walla.co.il/some_text/2642630/one-direction-all-for-one')
    assert info['id'] == '2642630'
    assert info['display_id'] == 'one-direction-all-for-one'
    assert info['title'] == '2642630'
    assert info['description'] == '2642630'

# Generated at 2022-06-12 18:49:52.677038
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    instance = w._real_extract(test_url)
    assert ('2642630', 'one-direction-all-for-one') == (instance['id'], instance['display_id'])
    assert '' != instance['title']
    assert 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl' == instance['url']
    assert {'heb': [{'ext': 'srt', 'url': 'http://media.video2.walla.co.il/media/movie/2642630/2642630.srt'}]} == instance['subtitles']

# Generated at 2022-06-12 18:49:59.134011
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(
        'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract(
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract(
        'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:10.172066
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == r'^https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)$'
    assert obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert obj._TEST['info_dict']['id'] == '2642630'
    assert obj._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert obj._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-12 18:50:11.050578
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE('Walla')

# Generated at 2022-06-12 18:50:21.662867
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:22.165115
# Unit test for constructor of class WallaIE
def test_WallaIE():       
    assert WallaIE

# Generated at 2022-06-12 18:50:25.103090
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor of class WallaIE
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:26.196694
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-12 18:50:26.650825
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-12 18:50:31.156650
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._SUBTITLE_LANGS['עברית']=='heb'

# Generated at 2022-06-12 18:50:44.870620
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.SUCCESS == True

# Generated at 2022-06-12 18:50:45.423403
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE

# Generated at 2022-06-12 18:50:47.904321
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE({}, {})
    assert ie.ie_key() == 'Walla'
    assert ie.test()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-12 18:50:54.313624
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_WallaIE = WallaIE()
    # test with a variable
    assert test_WallaIE.__class__.__name__ == 'WallaIE'
    # test with a variable
    assert test_WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:57.384070
# Unit test for constructor of class WallaIE
def test_WallaIE():
    constructor_test(WallaIE, [("WallaIE", "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")])

# Generated at 2022-06-12 18:50:59.152311
# Unit test for constructor of class WallaIE
def test_WallaIE():
  w = WallaIE()

# Test re.match(WallaIE._VALID_URL, v)

# Generated at 2022-06-12 18:51:02.811446
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert walla_ie is not None
    assert walla_ie.ie_key() == 'Walla'

# Generated at 2022-06-12 18:51:05.275974
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    # (Nicolas.Grekas) Seems that some unit tests depend on this,
    # and I can't reproduce it locally.
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-12 18:51:10.667560
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create a WallaIE instance
    assert WallaIE(None, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Call WallaIE constructor again with no URL
    try:
        WallaIE(None, '')
    except TypeError:
        pass
    except:
        #Unexpected exception
        assert False
    # Call WallaIE constructor again with invalid URL
    try:
        WallaIE(None, 'www.walla.co.il')
    except TypeError:
        pass
    except:
        #Unexpected exception
        assert False

# Generated at 2022-06-12 18:51:12.907529
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except Exception as e:
        assert False
        assert str(e) == "Test failed"


# Generated at 2022-06-12 18:51:43.468725
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert str(ie) == 'Walla', repr(ie)
    assert TestWallaIE.test_cases is TestWallaIE._TEST
    test_cases = TestWallaIE.test_cases
    assert test_cases['url'] == TestWallaIE._TEST['url']


# Generated at 2022-06-12 18:51:44.645079
# Unit test for constructor of class WallaIE
def test_WallaIE():
	w = WallaIE()
	assert w
	assert w._VALID_URL

# Generated at 2022-06-12 18:51:51.406042
# Unit test for constructor of class WallaIE
def test_WallaIE():
    vod = WallaIE()
    # Assert that the constructor for class WallaIE is working properly
    assert vod._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:51:58.048578
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test WallaIE constructor
    """
    ie = WallaIE()
    ie._VALID_URL # pylint: disable=protected-access
    ie._TEST # pylint: disable=protected-access
    ie._SUBTITLE_LANGS # pylint: disable=protected-access

    ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') # pylint: disable=protected-access

# Generated at 2022-06-12 18:51:59.171110
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:52:07.438716
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:52:09.005638
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:52:10.995390
# Unit test for constructor of class WallaIE
def test_WallaIE():
	import pytest
	
	with pytest.raises(AssertionError):
		WallaIE('https://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-12 18:52:13.588512
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE('http://www.walla.co.il')
    assert info_extractor._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:52:16.683914
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = InfoExtractor("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == "WallaIE"

# Generated at 2022-06-12 18:53:12.411905
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_video_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(test_video_url)
    assert ie.name == 'Walla!'
    assert ie.ie_key() == 'Walla'
    assert ie.valid_url(test_video_url)
    assert '2642630' == ie.video_id(test_video_url)

# Generated at 2022-06-12 18:53:12.935349
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:53:17.753587
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE(None)
    assert obj.SUFFIX == 'co.il'
    assert obj.IE_NAME == 'walla:video'
    assert obj._TEST.get('subtitles') == {
            'heb': [{
                'ext': 'srt',
                'url': 'http://subs.video2.walla.co.il/?w=null/null/2642630/subtitle/subtitle%s.srt',
            }],
        }

# Generated at 2022-06-12 18:53:18.808277
# Unit test for constructor of class WallaIE
def test_WallaIE():
   ie = WallaIE()

test_WallaIE()

# Generated at 2022-06-12 18:53:20.219243
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:53:23.493443
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test constructor argument
    ie = WallaIE(url="http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

    # Test get_id()
    assert '2642630' in ie.get_id()

    # Test get_extractor()
    if WallaIE.ies:
        assert 'walla' in WallaIE.get_extractor().get_id()


if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-12 18:53:34.522782
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print("Unit test for constructor of class WallaIE")
    obj = WallaIE(None)
    assert obj.SUBTITLE_LANGS == {'עברית': 'heb'}
    assert obj.VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:53:36.150211
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except:
        assert False, "Can't create instance of class WallaIE"

# Generated at 2022-06-12 18:53:44.877989
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.name == 'vod.walla.co.il'
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.video_id == '2642630'

    ie = WallaIE('https://vod.walla.co.il/item/2626946/walla-player')
    assert ie.name == 'vod.walla.co.il'
    assert ie.display_id == 'walla-player'

# Generated at 2022-06-12 18:53:45.794927
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:55:37.586886
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-12 18:55:43.406647
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:55:44.160240
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()


# Generated at 2022-06-12 18:55:46.132868
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL ==  r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:55:49.453054
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert walla.WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")


# Generated at 2022-06-12 18:55:50.188053
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()


# Generated at 2022-06-12 18:55:56.903989
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class_ = WallaIE
    if hasattr(class_, 'suitable'):
        instances = [class_, class_()]
        for instance in instances:
            url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
            mobj = re.match(instance._VALID_URL, url)
            assert mobj.group('id') == '2642630'
            assert mobj.group('display_id') == 'one-direction-all-for-one'

# Generated at 2022-06-12 18:56:06.972626
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:56:08.142685
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("test_url")
    ie.download("test_url")

# Generated at 2022-06-12 18:56:08.896437
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None, {})