

# Generated at 2022-06-12 18:49:01.107194
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test1 = WallaIE(None)
    test2 = WallaIE(WallaIE)
    test3 = WallaIE(WallaIE)
    assert type(test1) is WallaIE
    assert isinstance(test2, WallaIE)
    assert isinstance(test3, WallaIE)
    assert test2 is test3

# Generated at 2022-06-12 18:49:03.758148
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630'
    mobj = re.match(WallaIE._VALID_URL, url)
    assert mobj is not None


# Generated at 2022-06-12 18:49:06.218269
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') # noqa:F841
    assert ie.ie_key() == 'Walla'



# Generated at 2022-06-12 18:49:14.919026
# Unit test for constructor of class WallaIE
def test_WallaIE():
    we = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

    assert we._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:21.575711
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None
    assert ie.IE_NAME == 'walla'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:49:22.916754
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert type(WallaIE(InfoExtractor)) == WallaIE

# Generated at 2022-06-12 18:49:34.976718
# Unit test for constructor of class WallaIE
def test_WallaIE():
    expected_dict = {
        'ext': 'flv',
        'duration': 3600,
        'thumbnail': r're:^https?://.*\.jpg',
        'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
        'id': '2642630',
        'display_id': 'one-direction-all-for-one',
        'title': 'וואן דיירקשן: ההיסטריה'}
    assert WallaIE()._real_extract(
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')\
        == expected_dict

# Generated at 2022-06-12 18:49:45.657806
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:57.353932
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    u = ie._VALID_URL
    assert (re.match(u, 'http://vod.walla.co.il/movie/816675/conar-big-bang') is not None)
    assert (re.match(u, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is not None)
    assert (re.match(u, 'http://vod.walla.co.il/movie/819126/the-secret-life-of-the-american-teenager') is not None)

# Generated at 2022-06-12 18:49:59.147502
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global wallaIE
    wallaIE = WallaIE('')
    assert(wallaIE is not None)


# Generated at 2022-06-12 18:50:13.008912
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extractor._SUBTITLE_LANGS = {
        'עברית': 'heb'
    }

    # test URL
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    mobj = re.match(ie._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    expected_video_id = '2642630'
    expected_display_id = 'one-direction-all-for-one'
    assert video_id == expected_video_id
    assert display_id == expected_display_id

    # test subtitles languages

# Generated at 2022-06-12 18:50:17.301611
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:20.871427
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.VOD_HOST == 'wafla.walla.co.il'
    assert ie.VOD_AP == 'vod'

# Generated at 2022-06-12 18:50:22.846996
# Unit test for constructor of class WallaIE
def test_WallaIE():
	IE = WallaIE();
	pass;

# Generated at 2022-06-12 18:50:25.367924
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test extraction from http://vod.walla.co.il/
    assert WallaIE().suitable(WallaIE()._VALID_URL)



# Generated at 2022-06-12 18:50:26.716267
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('Test', 'Test', 'Test', 'Test')
    assert ie != None

# Generated at 2022-06-12 18:50:33.839192
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import sys
    import unittest
    import re

    # setUp Test Case
    tester = WallaIE()

    # Tests
    assert tester._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert tester.IE_NAME == 'walla:vod'
    assert tester.BR_DESC == 'walla:vod'



# Generated at 2022-06-12 18:50:41.837886
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE('http://vod.walla.co.il/news_sport/israel/2643277/one_direction_all_for_one')
	assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:44.124086
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE().suite()

# Generated at 2022-06-12 18:50:53.116494
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE(None)
    assert obj._SUBTITLE_LANGS == {'עברית': 'heb'}
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:59.471793
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.get_info_dict.test()

# Generated at 2022-06-12 18:51:04.037575
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    a = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert a.urls == 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:51:07.305916
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    test = WallaIE()
    #TODO: Y.T: add more tests
    assert True

# Generated at 2022-06-12 18:51:11.460048
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Instance of WallaIE
    wie = WallaIE()

    # Check if class WallaIE  have VALID_URL
    assert wie._VALID_URL is not None
    assert wie._TEST is not None

# Generated at 2022-06-12 18:51:13.539219
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    print('WallaIE class is created')

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-12 18:51:16.072898
# Unit test for constructor of class WallaIE
def test_WallaIE():
	info_extractor = WallaIE()
	# print(info_extractor._VALID_URL)
	print(info_extractor._TEST)

# Generated at 2022-06-12 18:51:19.919788
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import yaml

# Generated at 2022-06-12 18:51:21.960178
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:51:23.404482
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('WallaIE')
    ie.WallaIE.__name__ == 'WallaIE'

# Generated at 2022-06-12 18:51:34.986333
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.LANG == 'he'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-12 18:51:48.071340
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()


# Generated at 2022-06-12 18:51:58.082838
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    assert a.__class__ == WallaIE
    assert a._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert a._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:51:59.682764
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-12 18:52:02.013102
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()
    # Access to protected member of class WallaIE
    WallaIE._WallaIE__download_xml()
    # Call of missing method
    WallaIE.test()

# Generated at 2022-06-12 18:52:04.449577
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL = WallaIE._VALID_URL
    assert ie._real_extract(ie._TEST['url']) == ie._TEST

# Generated at 2022-06-12 18:52:05.548879
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test only constructor because this IE is abstract
    WallaIE()

# Generated at 2022-06-12 18:52:07.547963
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('WallaIE', 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') is not None

# Generated at 2022-06-12 18:52:08.803550
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    w._real_extract(w._TEST['url'])

# Generated at 2022-06-12 18:52:19.673625
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one' 
    IE = WallaIE()
    assert IE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)' 
    assert IE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert IE._TEST['info_dict']['id'] == '2642630'
    assert IE._TEST['params']['skip_download'] == True

# Generated at 2022-06-12 18:52:23.527208
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("https://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:52:48.347776
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:52:50.495631
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.SUBTITLE_LANGS == {
        'עברית': 'heb',
    }


# Generated at 2022-06-12 18:52:51.735937
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-12 18:52:52.332735
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:53:01.799226
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(ie, WallaIE)
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:53:06.539113
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-12 18:53:08.511298
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie == WallaIE

# Generated at 2022-06-12 18:53:16.363088
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:53:21.977184
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    # TODO: refactor
    assert ie.NAME == 'Walla! VOD'

    assert ie._VALID_URL == re.compile(r'^https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)$')
    assert ie._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-12 18:53:33.704684
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Test url
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    info = ie._real_extract(url)
    assert info['id'] == '2642630'
    assert info['display_id'] == 'one-direction-all-for-one'
    assert info['ext'] == 'flv'
    assert info['title'] == 'וואן דיירקשן: ההיסטריה'
    assert info['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert info['thumbnail'] == r're:^https?://.*\.jpg'

# Generated at 2022-06-12 18:54:35.153093
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = '7233083'
    url = 'http://vod.walla.co.il/movie/7233083/panic-room'
    wallaIE = WallaIE(url)
    WallaIE._VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:54:37.434973
# Unit test for constructor of class WallaIE
def test_WallaIE():
    W = WallaIE()
    # constructor for class WallaIE
    assert True is True


# Generated at 2022-06-12 18:54:39.533864
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._real_initialize()

# Generated at 2022-06-12 18:54:45.437609
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj is not None
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:54:47.595771
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-12 18:54:49.283130
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:54:51.916774
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.extractor_key == 'walla'
    assert ie.get_info_url == 'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl'
    assert ie.test_rtmp == True

# Generated at 2022-06-12 18:54:52.998525
# Unit test for constructor of class WallaIE
def test_WallaIE():
	w = WallaIE("www.walla.co.il","")
	assert w.IE_NAME == "walla"

# Generated at 2022-06-12 18:54:54.393091
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-12 18:54:55.591354
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-12 18:56:50.579209
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # TODO
    pass

# Generated at 2022-06-12 18:56:54.848725
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WALLA_URL = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    _ = ie.extract(WALLA_URL)
    return True


# Generated at 2022-06-12 18:56:57.522761
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()
    assert wie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:57:00.120736
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #
    # Tests for existence of object
    #
    ie = WallaIE()
    assert ie.__class__.__name__ == 'WallaIE'


if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-12 18:57:06.006132
# Unit test for constructor of class WallaIE
def test_WallaIE():
    d_id = 'test_display_id'
    v_id = 'test_id'
    url = 'test_url'
    result = WallaIE._build_rtmp_url(url, d_id, v_id)
    if result != \
    'rtmp://wafla.walla.co.il/vod test_url pageUrl=test_url playpath=test_display_id swfUrl=http://isc.walla.co.il/w9/swf/video_swf/vod/WallaMediaPlayerAvod.swf swfVfy=1 live=0':
        raise RuntimeError('test_WallaIE failed')

# Generated at 2022-06-12 18:57:14.637164
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:57:21.997382
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['ext'] == 'flv'
    assert ie._TEST['info_dict']['thumbnail'] == 'http://img.walla.co.il/u0b814/7/w_m_A.2642630.jpg'

# Generated at 2022-06-12 18:57:23.985488
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # The following is similar to the example url extracted in _TEST
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE()._real_extract(url)

# Generated at 2022-06-12 18:57:28.804165
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    This test case tests the constructor of WallaIE.
    """

    # Test case #1
    _WallaIE = WallaIE(None)
    assert _WallaIE._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"

    # Test case #2
    _WallaIE = WallaIE('')
    assert _WallaIE._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"

    # Test case #3
    _WallaIE = WallaIE('http://vod.walla.co.il')
    assert _WallaIE._VAL

# Generated at 2022-06-12 18:57:29.873373
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()