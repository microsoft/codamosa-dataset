

# Generated at 2022-06-12 18:49:05.112525
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:06.165846
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj

# Generated at 2022-06-12 18:49:11.476875
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    This test is for checking that WallaIE object is constructed as we expect.
    """
    from .common import InfoExtractor
    from ..utils import xpath_text
    from ..compat import compat_str

    # URL to test
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

    # Create a new WallaIE object
    ie = InfoExtractor(WallaIE)

    # Check that WallaIE object is an instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)

    # Check that WallaIE object has appropriate name
    assert ie.IE_NAME == 'walla'

    # Check that WallaIE object has appropriate url
    assert ie.url == url

    # Check that WallaIE object has appropriate _VAL

# Generated at 2022-06-12 18:49:19.636067
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:26.074757
# Unit test for constructor of class WallaIE
def test_WallaIE():
	"""Unit test for constructor of class: WallaIE"""
	ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:49:31.257653
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """ Unit test for constructor of class WallaIE """
    walla = WallaIE()
    assert WallaIE._TEST == walla.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:49:33.571596
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()
    assert isinstance(x, WallaIE)


# Generated at 2022-06-12 18:49:34.238999
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:49:35.854001
# Unit test for constructor of class WallaIE
def test_WallaIE():
    W = WallaIE()
    assert W != None

# Generated at 2022-06-12 18:49:43.841592
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = WallaIE()._TEST['url']
    mobj = re.match(WallaIE._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    WallaIE().suite()
    assert WallaIE()._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id).find('./items/item') is not None

# Generated at 2022-06-12 18:49:54.559543
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:49:56.527898
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-12 18:50:06.855758
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:10.251398
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("vod.walla.co.il")
    assert ie.SUCCESS == ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-12 18:50:10.791218
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:50:21.255042
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:50:23.452160
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()

# Generated at 2022-06-12 18:50:25.205750
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__.__name__ == 'WallaIE'


# Generated at 2022-06-12 18:50:26.300260
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE()
    wallaIE.test()

# Generated at 2022-06-12 18:50:30.984591
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = WallaIE._TEST.get('url')
    ie = WallaIE()
    ie._downloader.params.update(WallaIE._TEST.get('params', {}))
    assert ie.suitable(url)
    info = ie.extract(url)
    assert info.get('id', None)
    assert 'video' in info

# Generated at 2022-06-12 18:50:54.630462
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # If no test is provided, we should at least test that the constructor
    # does not raise any exception
    ie = WallaIE()

# Generated at 2022-06-12 18:50:58.088108
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE()
    ie.suitable(url)

# Generated at 2022-06-12 18:51:03.215164
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test constructor of class WallaIE"""

    object_WallaIE = WallaIE('http://video.walla.co.il/', 'skip_download')

    assert object_WallaIE != None

    # Check
    assert object_WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:51:05.446227
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-12 18:51:06.588200
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """ Test WallaIE constructor """
    WallaIE('WallaIE', {})

# Generated at 2022-06-12 18:51:09.331875
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE({})
    assert isinstance(obj.SUFFIX_MAP, dict)
    assert 'heb' not in obj.SUFFIX_MAP

# Generated at 2022-06-12 18:51:12.523798
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:51:17.325017
# Unit test for constructor of class WallaIE
def test_WallaIE():
   ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
   assert ie.url == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
   assert ie.video_id == "2642630"
   assert ie.display_id == "one-direction-all-for-one"

# Generated at 2022-06-12 18:51:23.416206
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Testing class WallaIE
    """
    ie = WallaIE()
    assert ie.IE_NAME == 'walla:video'
    assert ie.VALID_URL == ie._VALID_URL
    assert ie.SUCCESS == 1
    assert ie.FAIL == 0
    assert ie.BAD_CREDENTIALS == -2
    assert ie.LOGGED_OUT == -3
    assert ie.SUBSCRIBERS_ONLY == -4
    assert ie.LOGIN_REQUIRED == -5
    assert ie.USAGE_LIMIT_REACHED == -6
    assert ie.NOT_LOGGED_IN == -7
    assert ie.API_ERROR == -8
    assert ie.COPYRIGHT_INFRINGEMENT == -9


# Generated at 2022-06-12 18:51:29.706961
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'



# Generated at 2022-06-12 18:51:56.250024
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il')._real_extract()

# Generated at 2022-06-12 18:51:59.386291
# Unit test for constructor of class WallaIE
def test_WallaIE():
	url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	wallaIE = WallaIE()
	wallaIE._real_extract(url)

# Generated at 2022-06-12 18:52:00.693860
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_WallaIE.test_object = WallaIE()

# Generated at 2022-06-12 18:52:01.555628
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:52:04.371665
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Minimal test
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE()
    ie.extract(url)

# Generated at 2022-06-12 18:52:11.474434
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        import urllib2
    except ImportError:
        import urllib.request as urllib2
    opener = urllib2.build_opener()
    opener.addheaders = [('User-agent', 'Mozilla/5.0')]
    data = opener.open('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one').read()

    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._match_id('2642630')
    assert len(WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')._file_metadata(data)) > 0
    assert Walla

# Generated at 2022-06-12 18:52:22.350794
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:52:24.009948
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-12 18:52:25.438343
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert (ie.get_name() == 'walla.co.il')

# Generated at 2022-06-12 18:52:32.385001
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    # Unit test for the regexes
    match = re.match(ie._VALID_URL, url)
    assert match
    assert match.group('id') == '2642630'
    assert match.group('display_id') == 'one-direction-all-for-one'

# Generated at 2022-06-12 18:53:24.796249
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE('') is not None)

# Generated at 2022-06-12 18:53:35.204215
# Unit test for constructor of class WallaIE
def test_WallaIE():
    constructor_test_base(
        WallaIE,
        {
      	    'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',
        },
        {
            'id': '2642630',
            'display_id': 'one-direction-all-for-one',
            'ext': 'flv',
            'title': 'וואן דיירקשן: ההיסטריה',
            'description': 'md5:de9e2512a92442574cdb0913c49bc4d8',
            'thumbnail': r're:^https?://.*\.jpg',
            'duration': 3600,
        },
        True)

# Generated at 2022-06-12 18:53:44.174078
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Without arguments
    obj = WallaIE()
    assert obj.ie_key() == 'Walla'
    assert obj.test() == {}

    # With arguments
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj.ie_key() == 'Walla'

# Generated at 2022-06-12 18:53:50.077309
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create the instance
    vod_walla_co_il = WallaIE()

    # Check the initialization
    assert vod_walla_co_il._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

if __name__ == '__main__':
    # Test of class WallaIE for constructor
    test_WallaIE()
    print('Unit test completed')

# Generated at 2022-06-12 18:53:57.512259
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.description == 'Walla! VOD'
    assert ie.extractor_key == 'walla'
    assert ie.ie_key() == 'Walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:53:58.375801
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:54:00.496925
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-12 18:54:10.602008
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE()._SUBTITLE_LANGS == { 'עברית': 'heb', }

# Generated at 2022-06-12 18:54:12.335785
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._SUBTITLE_LANGS[u'עברית'] == 'heb'

# Generated at 2022-06-12 18:54:13.784811
# Unit test for constructor of class WallaIE
def test_WallaIE():
    myIE = WallaIE()
    assert myIE is not None

# Generated at 2022-06-12 18:56:18.149119
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return


# Generated at 2022-06-12 18:56:20.035333
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie.suitable(WallaIE._VALID_URL)

# Generated at 2022-06-12 18:56:23.143733
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-12 18:56:23.914454
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-12 18:56:24.661870
# Unit test for constructor of class WallaIE
def test_WallaIE():
    main_test(WallaIE)

# Generated at 2022-06-12 18:56:26.802245
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Testing constructor of WallaIE class
    # ie = WallaIE()
    ie = (WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"))

# Generated at 2022-06-12 18:56:28.140646
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:56:33.782197
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from ..utils import request_mock
    with request_mock.disable():
        WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Tests for method _real_extract of class WallaIE

# Generated at 2022-06-12 18:56:36.542452
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()
    # Constructor test
    assert IE.__name__ == 'Walla'
    assert IE.ie_key() == 'Walla'
    assert IE.server_url() == 'vod.walla.co.il'

# Generated at 2022-06-12 18:56:37.321374
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie)