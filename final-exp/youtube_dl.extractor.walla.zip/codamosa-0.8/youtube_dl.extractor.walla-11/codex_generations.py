

# Generated at 2022-06-12 18:48:58.458123
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for construction of WallaIE
    WallaIE()

# Generated at 2022-06-12 18:49:06.618885
# Unit test for constructor of class WallaIE
def test_WallaIE():
    unit = WallaIE()
    assert unit._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:08.673368
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
        print("Constructor of class WallaIE is working.")
    except:
        print("Constructor of class WallaIE is not working.")



# Generated at 2022-06-12 18:49:13.366294
# Unit test for constructor of class WallaIE
def test_WallaIE():
    inst = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert inst._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)' is True

# Generated at 2022-06-12 18:49:15.736002
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('example.com')
    WallaIE('WallaIE')
    WallaIE('http://somethingsomething.com')
    WallaIE('https://somethingsomething.com')

# Generated at 2022-06-12 18:49:19.174576
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # tests for the constructor for WallaIE
    # the construction will be tested, not the methods of the class
    try:
        WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    except:
        assert False, "test for constructor of WallaIE failed"

# Generated at 2022-06-12 18:49:24.580633
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Testing an object of class WallaIE
    walla_ie = WallaIE()
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    info = walla_ie.suitable(url)
    assert info is not None

# Generated at 2022-06-12 18:49:27.218339
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:36.326559
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:49:46.893086
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:57.486253
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-12 18:50:02.607966
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for constructor of class WallaIE
    # Test for valid url
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Test for invalid url
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one')



# Generated at 2022-06-12 18:50:04.071395
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE.suite()

# Generated at 2022-06-12 18:50:08.728287
# Unit test for constructor of class WallaIE
def test_WallaIE():

    class TmpExtractor(WallaIE):
        def _real_extract(self, url):
            raise NotImplementedError

    tmpExtractor = TmpExtractor(None)
    tmpExtractor._download_xml = lambda url: None
    tmpExtractor._real_extract(TmpExtractor._VALID_URL)

# Generated at 2022-06-12 18:50:10.662184
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:20.993963
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import sys
    sys.path.append('../..')
    from ydl.extractor import VideoExtractor
    from ydl.update import update_self
    from ydl.options import get_option
    from ydl.utils import match_filter, urlhandle_detect_ext

    # Update self first
    update_self(get_option('-U'), get_option('--add-downloader'), get_option('--rm-downloader'))

    # Test WallaIE #1
    vid_id_1 = '2642630/one-direction-all-for-one'
    vid_url_1 = 'http://vod.walla.co.il/movie/' + vid_id_1
    WallaIE_test_1 = VideoExtractor.gen_extractor(vid_url_1)
   

# Generated at 2022-06-12 18:50:24.002750
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.match_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:26.041362
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie_obj = ie

    assert ie_obj.ie_key() == 'Walla'
    assert ie_obj.ie_docs() == 'docs for WallaIE'

# Generated at 2022-06-12 18:50:28.020556
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test initialization of class WallaIE
    obj = WallaIE()
    assert isinstance(obj, WallaIE)

# Generated at 2022-06-12 18:50:37.623112
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_obj = WallaIE()
    assert test_obj._VALID_URL == re.compile(r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert test_obj._downloader == None
    assert test_obj._download_webpage == None
    assert test_obj._download_xml == None
    assert test_obj._og_search_thumbnail == None
    assert test_obj._og_search_description == None
    assert test_obj._html_search_meta == None
    assert test_obj._html_search_regex == None
    assert test_obj._html_search_meta == None
    assert test_obj.BRIGHTCOVE_URL_TEMPLATE == None
    assert test_

# Generated at 2022-06-12 18:51:00.139919
# Unit test for constructor of class WallaIE
def test_WallaIE(): # TODO: Move this test to WallaIE class
    try:
        ie = WallaIE()
        ie = WallaIE(ie)
    except:
        assert False, 'Creating instance of WallaIE class failed'

# Generated at 2022-06-12 18:51:01.402220
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert isinstance(WallaIE, InfoExtractor)


# Generated at 2022-06-12 18:51:01.958085
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:51:09.531322
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

    wallaIE = WallaIE(url)

    assert wallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:51:12.222030
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one") is not None

# Generated at 2022-06-12 18:51:13.665461
# Unit test for constructor of class WallaIE
def test_WallaIE():
	from walla import WallaIE
	print('Test Walla being created')
	from walla import WallaIE
	walla_ie = WallaIE()

# Generated at 2022-06-12 18:51:20.959890
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import unittest
    from .test_imports import WallaIE
    from .test_imports import parse_duration
    from .test_imports import parse_filesize
    
    
    class TestWallaIE(unittest.TestCase):
        VALID_URL = WallaIE._VALID_URL
        INVALID_URL = 'http://www.walla.co.il/'
        TEST = WallaIE._TEST
        VALID_VIDEO = TEST['url']
        VALID_ID = TEST['info_dict']['id']
        VALID_NAME = TEST['info_dict']['display_id']
        VALID_AUDIO = TEST['info_dict']['ext']
        VALID_VIDEO_TITLE = TEST['info_dict']['title']
        VALID_VIDEO_

# Generated at 2022-06-12 18:51:27.254453
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test basic constructor
    wie = WallaIE()
    assert wie.extractor_key == 'walla'
    assert wie.ie_key == 'Walla'
    assert wie.ie_key == 'Walla'
    assert wie.ie_key == 'Walla'
    assert wie.ie_key == 'Walla'
    assert wie.ie_key == 'Walla'

# Generated at 2022-06-12 18:51:30.398307
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-12 18:51:33.714724
# Unit test for constructor of class WallaIE
def test_WallaIE():
    vod_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(None).suitable(vod_url)

# Generated at 2022-06-12 18:52:24.369838
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for constructor of class WallaIE

    Make sure that every expected attribute of the class is initialized.
    """
    obj = WallaIE(None)
    for (attr, type_) in [
    ('_VALID_URL', str),
    ('_SUBTITLE_LANGS', dict),
    ('_TESTS', list),
    ('_DOWNLOAD_SUCCESSFUL', str),
    ('_DOWNLOAD_ERROR', str),
    ('_TEST', dict)]:
        assert hasattr(obj, attr) and isinstance(getattr(obj, attr), type_)

# Generated at 2022-06-12 18:52:24.898695
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:52:27.599727
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie.extract('2642630')

# Generated at 2022-06-12 18:52:37.813072
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla_ie = WallaIE()

    # Test '_VALID_URL' attribute
    assert walla_ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

    # Test '_TEST' attribute

# Generated at 2022-06-12 18:52:40.914189
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.get_url() == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"


# Generated at 2022-06-12 18:52:42.665802
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:52:43.071579
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-12 18:52:44.258053
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-12 18:52:44.728610
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:52:46.138655
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:53:40.648015
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    _ = WallaIE()._real_extract(url)

# Generated at 2022-06-12 18:53:41.179378
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:53:43.986597
# Unit test for constructor of class WallaIE
def test_WallaIE():
    i = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert i.SUFFIX == '@@/video/flv_pl'

# Generated at 2022-06-12 18:53:44.499178
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:53:53.335553
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()
    assert IE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:53:59.235583
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.video_id == '2642630'
    assert ie._VALID_URL == 'http\:\/\/vod\.walla\.co\.il\/[^\/]+\/(?P<id>\\d+)\/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-12 18:53:59.741006
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-12 18:54:05.570678
# Unit test for constructor of class WallaIE
def test_WallaIE():
	x = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
	assert x.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one';
	assert x.display_id == 'one-direction-all-for-one';
	assert x.id == '2642630';

# Generated at 2022-06-12 18:54:14.114534
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(ie, WallaIE)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:54:18.616452
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert(len(ie._SUBTITLE_LANGS) == 1)
    assert('עברית' in ie._SUBTITLE_LANGS)
    assert(ie._SUBTITLE_LANGS['עברית'] == 'heb')

# Generated at 2022-06-12 18:56:22.916196
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE.test()

# Generated at 2022-06-12 18:56:23.672560
# Unit test for constructor of class WallaIE
def test_WallaIE():
	info_extractor = WallaIE()
	pass

# Generated at 2022-06-12 18:56:29.156585
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.md5 = fake_md5
    assert ie.md5('bababa') == '9a3f9a0378d05b86f1e8f0859a0d0099'
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.match('http://vod.walla.co.il/movie/2643167/depeche-mode-live-berlin') == True
    assert ie.match('http://vod.walla.co.il/movie/2643167/depeche-mode-live-berlin') == True

# Generated at 2022-06-12 18:56:33.539448
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract()

# Generated at 2022-06-12 18:56:34.368146
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:56:36.508401
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:56:36.994723
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:56:38.197935
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Just a test for call the constructor of the class WallaIE
    WallaIE()

# Generated at 2022-06-12 18:56:46.090523
# Unit test for constructor of class WallaIE
def test_WallaIE():
    input_url = 'http://vod.walla.co.il/movie/2642630/one_direction_all_for_one'
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert w._get_video_id(input_url) == '2642630'
    assert w._get_video_id('http://vod.walla.co.il/movie/2642605/%D7%9E%D7%95%D7%97%D7%99%D7%9F') == '2642605'

# Generated at 2022-06-12 18:56:55.552835
# Unit test for constructor of class WallaIE
def test_WallaIE():

    # Check that constructor of WallaIE class has been
    # created appropriately - method __init__
    # should return WallaIE class after class initialization
    # with parameters url and ie_key.

    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ieKey = 'Walla'
    url = url
    ieKey = ieKey
    wallaIE = WallaIE(url, ieKey)
    instanceClass = wallaIE.__class__.__name__
    assert instanceClass == 'WallaIE'
