

# Generated at 2022-06-12 18:48:56.454912
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()

# Generated at 2022-06-12 18:48:57.018977
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-12 18:49:00.453710
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL is not None
    assert WallaIE._TEST is not None
    assert WallaIE._SUBTITLE_LANGS is not None
    assert WallaIE._real_extract() is not None

# Generated at 2022-06-12 18:49:07.932771
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("1")
    "Title of this new instance is 1. It's in the init method."
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:08.715606
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test that the constructor succeeds.
    ie = WallaIE(None)

# Generated at 2022-06-12 18:49:11.605743
# Unit test for constructor of class WallaIE
def test_WallaIE():
    vod_video_id='2642630'
    vod_display_id='one-direction-all-for-one'
    WallaIE(vod_video_id, vod_display_id)

# Generated at 2022-06-12 18:49:13.782613
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:49:19.173858
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test for the construction of class WallaIE
    """
    # Case 1: Valid URL
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    # Case 2: Invalid URL
    assert WallaIE._VALID_URL != 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>)'

# Generated at 2022-06-12 18:49:28.493223
# Unit test for constructor of class WallaIE
def test_WallaIE():
    u = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert u.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:29.399918
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:49:37.780703
# Unit test for constructor of class WallaIE
def test_WallaIE():
	url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
	return WallaIE(url)

# Generated at 2022-06-12 18:49:40.231292
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except:
        raise AssertionError("Failed to construct class WallaIE")

# Generated at 2022-06-12 18:49:40.812335
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-12 18:49:43.933546
# Unit test for constructor of class WallaIE
def test_WallaIE():
	print("\nUnit test for WallaIE")
	print("-----------------------------")
	walla = WallaIE(1)
	assert walla.name == 'walla'
	assert walla.ie_key() == 'walla'

# Generated at 2022-06-12 18:49:44.662907
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.test()

# Generated at 2022-06-12 18:49:45.952856
# Unit test for constructor of class WallaIE
def test_WallaIE():

    ie = WallaIE()
    ie.to_screen('test')

# Generated at 2022-06-12 18:49:47.045142
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:49:48.947881
# Unit test for constructor of class WallaIE
def test_WallaIE():
  # Try calling class constructor
  ie = WallaIE()
  #assert successful call
  assert ie.return_code > 0

# Generated at 2022-06-12 18:49:51.910885
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.url == 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:49:53.957974
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(WallaIE._TEST)
    # assert ie.IE_NAME == 'Walla'


# Generated at 2022-06-12 18:50:03.856716
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    ie.download('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:06.040562
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        video = WallaIE()
    except:
        print('constructor of WallaIE is not working')


# Generated at 2022-06-12 18:50:08.432996
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        w = WallaIE("http://www.walla.co.il")
    except TypeError:
        pass

# Generated at 2022-06-12 18:50:15.295811
# Unit test for constructor of class WallaIE
def test_WallaIE():
	objWallaIE = WallaIE("WallaIE", "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
	assert objWallaIE._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
	assert objWallaIE._TEST['info_dict']['id'] == "2642630"
	assert objWallaIE._TEST['info_dict']['display_id'] == "one-direction-all-for-one"
	assert objWallaIE._TEST['info_dict']['ext'] == "flv"

# Generated at 2022-06-12 18:50:16.486688
# Unit test for constructor of class WallaIE
def test_WallaIE():
	walla = WallaIE()
	return walla

# Generated at 2022-06-12 18:50:21.367524
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from walla import WallaIE
    ie = walla.WallaIE(force_smil_url=True)
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')['title']

# Generated at 2022-06-12 18:50:22.198683
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()

# Generated at 2022-06-12 18:50:26.572607
# Unit test for constructor of class WallaIE
def test_WallaIE():
    parser = WallaIE()
    assert parser.ie_key() == 'Walla'
    assert parser.suitable("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert parser.suitable("https://vod.walla.co.il/movie/2642630/one-direction-all-for-one")


# Generated at 2022-06-12 18:50:29.807820
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = WallaIE._TEST['url']
    assert re.match(WallaIE._VALID_URL, test_url)
    assert WallaIE()._real_extract(test_url)

# Generated at 2022-06-12 18:50:30.817657
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-12 18:50:45.104524
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:45.693009
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:50:49.023880
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wIE = WallaIE()

# Generated at 2022-06-12 18:50:50.425626
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()

# Generated at 2022-06-12 18:50:57.656547
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
	assert ie.VALID_URL == WallaIE._VALID_URL
	assert ie.TEST == WallaIE._TEST
	assert ie.SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
	assert ie.extract == WallaIE._real_extract

# Generated at 2022-06-12 18:50:58.228135
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-12 18:51:01.313832
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:51:09.122995
# Unit test for constructor of class WallaIE
def test_WallaIE():
	import shutil, tempfile
	from unittest import TestCase
	from re import match
	from .common import InfoExtractor

	class CDNWallaIE(WallaIE):
		_VALID_URL = WallaIE._VALID_URL.replace("walla\.co", "cdn\.walla\.co")

	class TestWallaIE(TestCase):
		def setUp(self):
			self.temp_dir = tempfile.mkdtemp()

		def test_Inheritance(self):
			self.assertTrue(issubclass(WallaIE, InfoExtractor))

		def test_URLs(self):
			url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:51:12.174630
# Unit test for constructor of class WallaIE
def test_WallaIE():
	url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	WallaIE(url)


# Generated at 2022-06-12 18:51:14.132006
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:51:49.002711
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #constructor of WallaIE
    ie = WallaIE(' ')

    #try to get params of url validation
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = ie._VALID_URL
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'

    #test url validation
    assert re.match(mobj, url)

    #test _real_extract function
    video = ie._download_xml(
        'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' % video_id,
        display_id)

    item = video.find('./items/item')

    title

# Generated at 2022-06-12 18:51:50.358441
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla is not None

# Generated at 2022-06-12 18:51:52.446208
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:51:59.552343
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    test_instance = WallaIE(test_url)

    assert test_instance._VALID_URL == WallaIE._VALID_URL
    assert test_instance.video_id == "2642630" and test_instance.display_id == "one-direction-all-for-one"
    assert test_instance.url == test_url
    assert test_instance.base_url == "vod.walla.co.il"

# Generated at 2022-06-12 18:52:00.441171
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-12 18:52:01.636150
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import WallaIE
    WallaIE.WallaIE(False)

# Generated at 2022-06-12 18:52:02.029733
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:52:02.854371
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('vod.walla.co.il/')
    assert ie.name == 'WallaIE'

# Generated at 2022-06-12 18:52:03.727099
# Unit test for constructor of class WallaIE
def test_WallaIE():
    unit = WallaIE()



# Generated at 2022-06-12 18:52:07.128237
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Check that class WallaIE has all attributes of class InfoExtractor
    assert type(ie) == type(InfoExtractor())
    # Check that instances of class WallaIE has a attribute password
    assert ie.password == ie.passwd

# Generated at 2022-06-12 18:52:55.976529
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:53:00.862799
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # It's just for coverage
    ie = WallaIE(WallaIE._create_get_url_regex())
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:53:01.852299
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()

# Generated at 2022-06-12 18:53:02.867968
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-12 18:53:04.417110
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-12 18:53:04.997385
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE

# Generated at 2022-06-12 18:53:08.737326
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://www.walla.co.il/')
    assert ie.VIDEO_ID_RE == 'http://vod.walla.co.il/[^/]+/(\d+)/(.+)'

# Generated at 2022-06-12 18:53:12.746663
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extractor = InfoExtractor()
    #__init__(self, url)
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.extractor.info_extractors[0] == ie
    assert ie.extractor.suitable(url)

# Generated at 2022-06-12 18:53:19.851863
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:53:20.513172
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-12 18:55:17.575856
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    res = ie._real_extract(url)
    assert res['id'] == '2642630'
    assert res['display_id'] == 'one-direction-all-for-one'
    assert res['ext'] == 'flv'
    assert res['title'] == 'וואן דיירקשן: ההיסטריה'
    assert res['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert res['thumbnail'] == 're:^https?://.*\.jpg'
    assert res['duration'] == 3600

# Generated at 2022-06-12 18:55:21.735628
# Unit test for constructor of class WallaIE
def test_WallaIE():
	walla = WallaIE()
	assert walla._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:55:23.646008
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS.get('עברית') == 'heb'

# Generated at 2022-06-12 18:55:24.470110
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()

# Generated at 2022-06-12 18:55:33.881840
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:55:35.040135
# Unit test for constructor of class WallaIE
def test_WallaIE():
    d = WallaIE()
    assert d._VALID_URL is not None

# Generated at 2022-06-12 18:55:41.440474
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:55:49.322727
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:55:52.476085
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-12 18:55:53.386836
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()