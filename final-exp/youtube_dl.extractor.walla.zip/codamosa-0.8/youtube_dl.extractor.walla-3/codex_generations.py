

# Generated at 2022-06-12 18:48:59.045740
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE
    except:
        raise TypeError('class WallaIE was not declared')


# Generated at 2022-06-12 18:49:00.512795
# Unit test for constructor of class WallaIE
def test_WallaIE():
    o = WallaIE()
    assert o.__class__ is WallaIE

# Generated at 2022-06-12 18:49:07.987072
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 0)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:10.998312
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-12 18:49:14.053141
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test case for missing attributes in Video object
    WallaIE(WallaIE._downloader,WallaIE._VALID_URL)._real_extract(WallaIE._TEST['url'])



# Generated at 2022-06-12 18:49:21.087106
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()
    assert t._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:23.169862
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Not a good test:
    # assert("object" != str(WallaIE()))

    assert("object" == str(WallaIE()))

# Generated at 2022-06-12 18:49:27.144054
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE().suitable(url)


# Generated at 2022-06-12 18:49:29.506031
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().extract(WallaIE._TEST['url']) == WallaIE._TEST

# Generated at 2022-06-12 18:49:30.764336
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:49:42.403205
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie = InfoExtractor()


# Generated at 2022-06-12 18:49:50.889942
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import sys
    try:
        from pyquery import PyQuery
    except ImportError:
        sys.exit(
                'ERROR: Please install PyQuery in order to test walla.co.il')

    walla = WallaIE(None, None, None)
    info = walla._real_extract(
            'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert info['title'] is not None
    assert info['url'] is not None
    assert info['duration'] is not None
    assert info['thumbnail'] is not None

    info = walla._real_extract(
            'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert info['description'] is not None

# Generated at 2022-06-12 18:50:00.144897
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:50:10.704342
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    _VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:11.589985
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except:
        return False
    return True

# Generated at 2022-06-12 18:50:16.316983
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    ie = WallaIE()
    if (ie is None):
        raise ValueError('Cannot initialize WallaIE')


# Generated at 2022-06-12 18:50:17.800985
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE()
    assert info_extractor.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:18.335938
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:50:22.120901
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.VIDEO_URL_TEMPLATE == 'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl'


# Generated at 2022-06-12 18:50:24.813665
# Unit test for constructor of class WallaIE
def test_WallaIE():
	ie = WallaIE()
	assert ie is not None, "Failed to initialize instance of WallaIE"
	assert repr(ie)

# Generated at 2022-06-12 18:50:51.317677
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)

    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie.br == None
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}


# Generated at 2022-06-12 18:50:53.378926
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(WallaIE._downloader, WallaIE._VALID_URL)

# Generated at 2022-06-12 18:51:03.727088
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    # test _VALID_URL
    mobj = re.match(ie._VALID_URL, 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert (mobj.group('id') == '2642630')
    assert (mobj.group('display_id') == 'one-direction-all-for-one')

    # test _real_extract
    assert (ie._real_extract(ie.url)['display_id'] == 'one-direction-all-for-one')
    assert (ie._real_extract(ie.url)['id'] == '2642630')

# Generated at 2022-06-12 18:51:04.890291
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wireless = WallaIE()
    assert wireless.ie_key() == 'Walla'

# Generated at 2022-06-12 18:51:07.217625
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-12 18:51:07.887380
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:51:17.643818
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()
    test = test._download_webpage('https://youtu.be/RtFgciOvSN8', None)
    test = test._real_extract('https://youtu.be/RtFgciOvSN8', None)
    assert 'no_video_in_db' == None
    assert 'video not found' == None
    assert 'this video is not avilable for your country' == None
    assert 'video_not_available' == None
    assert 'the video is not available in your country' == None
    assert 'We’re sorry, this video is no longer available' == None
    assert 'You have requested a password protected video' == None
    assert 'asked to enter your username and password' == None

# Generated at 2022-06-12 18:51:18.090882
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("")

# Generated at 2022-06-12 18:51:19.098010
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE("test")
    assert wallaIE is not None

# Generated at 2022-06-12 18:51:19.551854
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:52:20.614692
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:52:21.825722
# Unit test for constructor of class WallaIE
def test_WallaIE():
    thisIE = WallaIE("url")
    assert thisIE is not None


# Generated at 2022-06-12 18:52:32.511600
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:52:34.495407
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie.ie_key() == 'WallaCom'
    assert ie.ie_name() == 'walla'

# Generated at 2022-06-12 18:52:40.147860
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.SUFFIX == '@@/video/flv_pl'
    assert ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.match_id == '2642630'
    assert ie.match_name == 'one-direction-all-for-one'
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-12 18:52:41.541516
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()
    assert wie.ie_key() == 'walla'

# Generated at 2022-06-12 18:52:42.279724
# Unit test for constructor of class WallaIE
def test_WallaIE():
    result = WallaIE(None)

# Generated at 2022-06-12 18:52:48.189530
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from .common import InfoExtractor
    from .common import warn
    wia = WallaIE(InfoExtractor())
    assert wia._SUBTITLE_LANGS == {'עברית': 'heb'}
    # init of WallaIE class is OK
    assert wia._WORKING == True
    # since _SUBTITLE_LANGS is OK, test for conversion between Hebrew to heb
    # hebrew to he is OK
    assert wia._search_regex(r'^(?P<height>\d+)[Pp]', r'360P', 'height') == '360'
    # hebrew to he is not OK
    assert wia._search_regex(r'^(?P<height>\d+)[Pp]', r'360', 'height') == None
    #

# Generated at 2022-06-12 18:52:48.680050
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()


# Generated at 2022-06-12 18:52:49.649300
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w != None

# Unit tests for method _real_extract of class WallaIE

# Generated at 2022-06-12 18:53:44.568868
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test the constructor of the class WallaIE
    assert WallaIE.__name__ == 'WallaIE'

# Generated at 2022-06-12 18:53:48.471832
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Unit test for the constructor of the WallaIE class
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(WallaIE._VALID_URL, url)
    WallaIE(url, mobj)

# Generated at 2022-06-12 18:53:50.374496
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:53:51.241653
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE._TEST

# Generated at 2022-06-12 18:53:51.648886
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert True == True

# Generated at 2022-06-12 18:53:52.511998
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.su

# Generated at 2022-06-12 18:53:53.642212
# Unit test for constructor of class WallaIE
def test_WallaIE():
	wallaIE = WallaIE(None)
	assert wallaIE is not None

# Generated at 2022-06-12 18:53:59.827047
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE
    """
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    # Test the constructor
    walla_ie = WallaIE()
    # Test if the private attribute _VALID_URL has been initialized
    assert walla_ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    # Test if the private attribute _TEST has been initialized

# Generated at 2022-06-12 18:54:09.951172
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE({})
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:54:14.905289
# Unit test for constructor of class WallaIE
def test_WallaIE():
    asserEqual(WallaIE._VALID_URL, r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-12 18:56:21.011664
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert (WallaIE()._VALID_URL == WallaIE._VALID_URL)
    assert (WallaIE()._TEST == WallaIE._TEST)

# Generated at 2022-06-12 18:56:23.105511
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.set_downloader(Downloader())
    ie.extract(TEST_CODE)


# Generated at 2022-06-12 18:56:31.159123
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:56:34.808330
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(ie, WallaIE), 'Class built correctly'

# Generated at 2022-06-12 18:56:35.668791
# Unit test for constructor of class WallaIE
def test_WallaIE():
    t = WallaIE()

# Generated at 2022-06-12 18:56:36.408424
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()._extract_videos()

# Generated at 2022-06-12 18:56:44.405320
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:56:45.535498
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-12 18:56:50.713287
# Unit test for constructor of class WallaIE
def test_WallaIE():
    dl = WallaIE()
    assert dl._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:56:51.988697
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()