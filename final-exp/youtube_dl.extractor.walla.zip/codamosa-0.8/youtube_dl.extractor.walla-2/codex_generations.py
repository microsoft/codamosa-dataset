

# Generated at 2022-06-12 18:49:04.464812
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:06.617251
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaie = WallaIE()
    fields = {'url', 'ie_key', '_WORKING'}
    assert all(hasattr(wallaie, field) for field in fields)

# Generated at 2022-06-12 18:49:08.011277
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla.ie_key() == 'Walla'
    assert walla.ie_name() == 'Walla'

# Generated at 2022-06-12 18:49:09.758559
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-12 18:49:18.767980
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert (
        WallaIE._SUBTITLE_LANGS == {
            'עברית': 'heb',
        }
    )

# Generated at 2022-06-12 18:49:25.229485
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    inst = WallaIE()
    inst._download_xml('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl', 'one-direction-all-for-one')

# Generated at 2022-06-12 18:49:31.942463
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check that constructor of class WallaIE is able to download
    # a video from urls reffering to videos with subtitles.
    wallaIE = WallaIE()
    assert wallaIE.url_result(
        'http://vod.walla.co.il/movie/2643141/legend-of-troy-extended-cut')


# Generated at 2022-06-12 18:49:33.451320
# Unit test for constructor of class WallaIE
def test_WallaIE():
    print('test_WallaIE')
    wallaIE = WallaIE()
    assert wallaIE is not None

# Generated at 2022-06-12 18:49:34.732577
# Unit test for constructor of class WallaIE
def test_WallaIE():
    unit = WallaIE()
    print(unit._VALID_URL)
    print(unit._TEST)

# Generated at 2022-06-12 18:49:36.073810
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:49:50.039399
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from ..compat import compat_kwargs
    w = WallaIE()
    assert w._SUBTITLE_LANGS['עברית'] == 'heb'
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:49:51.585662
# Unit test for constructor of class WallaIE
def test_WallaIE():
  ie = WallaIE()

# Generated at 2022-06-12 18:49:53.200999
# Unit test for constructor of class WallaIE
def test_WallaIE():
    extractor = WallaIE()
    assert WallaIE.__name__ == 'WallaIE'


# Generated at 2022-06-12 18:49:56.351271
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:49:56.789382
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:50:07.511587
# Unit test for constructor of class WallaIE
def test_WallaIE():
    unit_test = WallaIE()
    assert unit_test._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:08.899455
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == 'WallaIE'

# Generated at 2022-06-12 18:50:10.128199
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    assert isinstance(a, InfoExtractor)

# Generated at 2022-06-12 18:50:13.867997
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    mobj = re.match(ie._VALID_URL, url)
    assert mobj.group('id') == '2642630'
    assert mobj.group('display_id') == 'one-direction-all-for-one'

# Generated at 2022-06-12 18:50:15.377290
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:50:29.066029
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Basic test for WallaIE"""
    ie = WallaIE()
    if not ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'):
        return False
    return True

# Generated at 2022-06-12 18:50:38.770188
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:40.112044
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-12 18:50:40.645063
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:50:46.025665
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(ie, InfoExtractor)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-12 18:50:55.338491
# Unit test for constructor of class WallaIE
def test_WallaIE():
    s = WallaIE()
    assert s._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    #assert s._TEST == {'url': 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', 'info_dict': {'id': '2642630', 'display_id': 'one-direction-all-for-one', 'ext': 'flv', 'title': 'וואן דיירקשן: ההיסטריה', 'description': 'md5:de9e2512a92442574cdb0913c49bc4d8', 'thumbnail': r

# Generated at 2022-06-12 18:50:57.757504
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().match('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:51:03.231512
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _WallaIE = WallaIE()
    assert _WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert _WallaIE.__name__ == 'Walla'
    assert _WallaIE._SUBTITLE_LANGS.get('עברית') == 'heb'

# Generated at 2022-06-12 18:51:04.129649
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(1 == 1)

# Generated at 2022-06-12 18:51:08.112183
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:51:33.668504
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url= 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE(url)

# Generated at 2022-06-12 18:51:34.982664
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except Exception as e:
        print(e)

# Generated at 2022-06-12 18:51:46.026830
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:51:48.466956
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.extract(url)

# Generated at 2022-06-12 18:51:52.265414
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.url = test_url
    ie.prepare()


# Generated at 2022-06-12 18:51:53.242950
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:51:57.371672
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = "http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl"
    ie._download_webpage(url, "foo.xml")
    ie._download_xml(url, "foo.xml")

# Generated at 2022-06-12 18:51:58.042510
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:52:00.320112
# Unit test for constructor of class WallaIE
def test_WallaIE():
	walla=WallaIE()
	assert(walla.IE_NAME=='walla')

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-12 18:52:01.271757
# Unit test for constructor of class WallaIE
def test_WallaIE():
    constructor_test(WallaIE)

# Generated at 2022-06-12 18:52:49.652971
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("WallaIE")._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:52:50.963052
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #test consructor of WallaIE
    ie = WallaIE(None)
    assert ie != None

# Generated at 2022-06-12 18:53:00.760566
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    #def __init__(self, ie_name, ie_key, ie_test, ie_version, ie_downloader=None, ie_age_limit=None, ie_gen=None, ie_video_password_only=False, ie_special_ad_fetcher=False, **kwargs):

    i = ie._real_extract(url='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert i['id'] == "2642630"
    assert i['title'] == "וואן דיירקשן: ההיסטריה"

# Generated at 2022-06-12 18:53:06.306133
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.__class__.__name__ == 'WallaIE'
    assert ie.IE_NAME == 'walla:vod'
    assert ie.VALID_URL == WallaIE._VALID_URL
    assert ie.TEST == WallaIE._TEST
    assert ie.SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS

# Generated at 2022-06-12 18:53:08.946375
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == "walla"
    assert ie.valid_url(ie._VALID_URL) == True

# Generated at 2022-06-12 18:53:09.732052
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None

# Generated at 2022-06-12 18:53:10.571853
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:53:18.174319
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie = WallaIE()
    ie = WallaIE()
    ie = WallaIE(_SUBTITLE_LANGS = {'עברית': 'heb'})
    ie = WallaIE(_SUBTITLE_LANGS = {'עברית': 'heb'})
    ie = WallaIE(_SUBTITLE_LANGS = {'עברית': 'heb'})
    ie = WallaIE(_SUBTITLE_LANGS = {'עברית': 'heb'})
    ie = WallaIE(_SUBTITLE_LANGS = {'עברית': 'heb'})

# Generated at 2022-06-12 18:53:30.341046
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Direct check
    inst = WallaIE()
    assert inst._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:53:30.827116
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:55:32.810951
# Unit test for constructor of class WallaIE
def test_WallaIE():
    with test_WallaIE() as WallaIE:
        assert WallaIE is not None
        assert WallaIE._VALID_URL is not None
        assert WallaIE._TEST is not None
        assert WallaIE._SUBTITLE_LANGS is not None
        assert WallaIE._real_extract is not None



# Generated at 2022-06-12 18:55:36.817344
# Unit test for constructor of class WallaIE
def test_WallaIE():
    "Test the constructor of class WallaIE"
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert ie.url == url
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.id == '2642630'


# Generated at 2022-06-12 18:55:37.896524
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla

# Generated at 2022-06-12 18:55:41.867810
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}


# Generated at 2022-06-12 18:55:46.319570
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().IE_NAME == 'walla:video'
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST == WallaIE._TEST
    assert WallaIE()._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert WallaIE().__doc__ == WallaIE.__doc__


# Generated at 2022-06-12 18:55:47.498925
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.test() == True

# Generated at 2022-06-12 18:55:48.276884
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:55:57.299685
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:56:07.248594
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:56:09.196004
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    return WallaIE(url).build_extractor