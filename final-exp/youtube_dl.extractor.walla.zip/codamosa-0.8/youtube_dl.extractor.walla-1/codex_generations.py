

# Generated at 2022-06-12 18:48:56.361196
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 18:49:05.219054
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test for constructor of class WallaIE
    """
    ie = WallaIE()
    assert ie.IE_NAME == 'walla:vod'
    assert ie.IE_DESC == 'Walla! VOD'
    assert ie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:07.303118
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(InfoExtractor)._VALID_URL == WallaIE._VALID_URL
    assert WallaIE(InfoExtractor)._TEST == WallaIE._TEST


# Generated at 2022-06-12 18:49:09.795912
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:49:13.515287
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    # Test video without subtitle
    assert ie.extract()['subtitles'] == {}


# Generated at 2022-06-12 18:49:14.693473
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)


# Class test for constructor of class WallaIE

# Generated at 2022-06-12 18:49:21.441183
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # pylint: disable=protected-access

    assert(WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-12 18:49:24.870230
# Unit test for constructor of class WallaIE
def test_WallaIE():
    '''
    Test constructor of class WallaIE
    '''
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE(url)
    assert ie.url == url


# Generated at 2022-06-12 18:49:25.622381
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-12 18:49:27.009272
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE is not None

# Generated at 2022-06-12 18:49:34.767855
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    a._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-12 18:49:44.611964
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()
    assert IE.get_type_is_video() == True
    assert IE.match_url_is_valid('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert IE.match_url_is_valid('http://vod.walla.co.ill/movie/2642630/one-direction-all-for-one') == False
    assert IE._SUBTITLE_LANGS['עברית'] == 'heb'
    assert IE._SUBTITLE_LANGS['English'] == 'English'

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-12 18:49:45.886055
# Unit test for constructor of class WallaIE
def test_WallaIE():
    myWalla = WallaIE()
    myWalla.get_real_title("")

# Generated at 2022-06-12 18:49:52.391758
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    w = WallaIE()
    info = w._real_extract(url)
    assert type(info) == dict
    assert info['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-12 18:49:53.288928
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-12 18:49:58.142924
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:01.177467
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-12 18:50:06.175262
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    website_testcase = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._match_id(website_testcase) == '2642630', "id is not match the one in the website"
    return True

# Generated at 2022-06-12 18:50:14.248419
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Basic instantiation
    walla_ie = WallaIE()
    assert walla_ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:23.217960
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:34.369185
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('')
    assert ie

# Generated at 2022-06-12 18:50:38.158384
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:39.553190
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-12 18:50:50.589554
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE({})
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:53.628818
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:57.948034
# Unit test for constructor of class WallaIE
def test_WallaIE():
	try:
		WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
	except:
		assert False, "Can't create object of class WallaIE"


# Generated at 2022-06-12 18:51:01.005335
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.IE_NAME == 'walla'

# Generated at 2022-06-12 18:51:04.890291
# Unit test for constructor of class WallaIE
def test_WallaIE():
	#walla = WallaIE()
	url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
	#info_dict = walla._real_extract(url)
	#print(info_dict)
	print('Test passed')

#test_WallaIE()

# Generated at 2022-06-12 18:51:11.457340
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Run this code with "python -m unittest -v" command
	# in order to test the constructor of the class
	print("test_WallaIE constructor")
	wallaIE = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
	assert wallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
	assert wallaIE.IE_NAME == 'walla'

	print("test_WallaIE regex pattern")

# Generated at 2022-06-12 18:51:19.592094
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    assert instance._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:51:46.507129
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert not ie.suitable('http://www.yahoo.com/')

# Generated at 2022-06-12 18:51:50.558918
# Unit test for constructor of class WallaIE
def test_WallaIE():
  video_id = 2642630
  display_id = 'one-direction-all-for-one'
  url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

  # Unit test constructor of class WallaIE
  ie = WallaIE()

  ie.url = url
  assert ie.url == url
  assert ie.video_id == video_id
  assert ie.display_id == display_id

# Generated at 2022-06-12 18:51:57.424435
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_info = WallaIE()._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

    # Not a complete test coverage
    assert video_info['id'] == '2642630'
    assert video_info['display_id'] == 'one-direction-all-for-one'
    assert video_info['title'] == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-12 18:52:00.482180
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one", "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-12 18:52:04.287896
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wie = WallaIE()
    assert wie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert wie._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-12 18:52:11.411999
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import unittest
    class WallaIETestCase(unittest.TestCase):
        def test_WallaIE__real_extract_valid_url(self):
            ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
            ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
        def test_WallaIE__real_extract_invalid_url(self):
            ie = WallaIE('http://vod.walla.co.il/movie/2642630')

# Generated at 2022-06-12 18:52:17.472237
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Arrange
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()

    # Act
    ie.extract(url)

    # Assert - does not return anything, so test passes if it does not throw any exception

# Generated at 2022-06-12 18:52:22.814882
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check constructor of WallaIE
    ie = WallaIE()
    assert ie.ie_key() == 'Walla', "ie_key() don't return 'Walla'"
    assert ie.ie_key_no_ie() == 'Walla', "ie_key_no_ie() don't return 'Walla'"
    assert ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-12 18:52:23.352305
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:52:24.703327
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-12 18:53:22.584172
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test for Walla
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wa = WallaIE(walla_url = test_url) # Test constructor
    assert wa.url == test_url # Test object's url
    assert wa.walla_url == test_url # Test object's url
    assert wa.VIDEO_URL_TEMPLATE == 'http://video2.walla.co.il/?w=null/null/%s/@@/video/flv_pl' # Test object's url
    assert wa.walla_video_path_id == '2642630' # Test object's path_id
    assert wa.walla_url_display_id == 'one-direction-all-for-one' # Test object's

# Generated at 2022-06-12 18:53:34.298942
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(WallaIE._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')
    # test __init__
    WallaIE(url)
    # test extract
    WallaIE(url).extract()
    # test result
    WallaIE(url).extract()['id'] == video_id
    WallaIE(url).extract()['display_id'] == display_id
    WallaIE(url).extract()['title'] == 'וואן דיירקשן: ההיסטריה'
   

# Generated at 2022-06-12 18:53:35.908599
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL
    assert WallaIE._TEST


# Generated at 2022-06-12 18:53:36.421991
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-12 18:53:45.118141
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:53:53.869386
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE.__name__ == 'WallaIE'
    assert WallaIE.__doc__ == 'Walla! Video Extractor'
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:54:02.909372
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # test 1
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test = WallaIE()._real_extract(url)
    assert test['id'] == '2642630'
    assert test['display_id'] == 'one-direction-all-for-one'
    assert test['title'] == u'וואן דיירקשן: ההיסטריה'
    assert test['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert test['thumbnail']
    assert test['duration'] == 3600
    assert test['subtitles'] == {}
    assert len(test['formats']) == 4

# Generated at 2022-06-12 18:54:05.455741
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS == {
        'עברית': 'heb',
    }

# Generated at 2022-06-12 18:54:06.620521
# Unit test for constructor of class WallaIE
def test_WallaIE():
    _WallaIE = WallaIE()

# Generated at 2022-06-12 18:54:14.564618
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:56:15.842192
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'


# Generated at 2022-06-12 18:56:16.687224
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructor of class WallaIE is called
    WallaIE()


# Generated at 2022-06-12 18:56:20.469795
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructor of WallaIE class
    from youtube_dl.extractor import YoutubeIE
    # Check if created object is an instace of YoutubeIE class
    assert isinstance(WallaIE(WallaIE._create_get_info_extractor()), YoutubeIE)

# Generated at 2022-06-12 18:56:21.678153
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None, None)

# Generated at 2022-06-12 18:56:29.253666
# Unit test for constructor of class WallaIE
def test_WallaIE():
    W = WallaIE()
    assert (W._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(W._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:56:35.973325
# Unit test for constructor of class WallaIE
def test_WallaIE():
    m = WallaIE()
    wurl = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    if  m.suitable(wurl):
        print("Url from Walla IE")
    else:
        print("Url is not from Walla IE")

# This function is to test the function extract of WallaIE

# Generated at 2022-06-12 18:56:38.796412
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert ie.url == url
    assert ie.tbr == 400
    assert ie.timeout ==30

# Generated at 2022-06-12 18:56:40.793774
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:56:41.803154
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE({})

# Generated at 2022-06-12 18:56:48.456307
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'