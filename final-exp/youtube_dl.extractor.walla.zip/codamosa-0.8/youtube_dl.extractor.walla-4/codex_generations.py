

# Generated at 2022-06-12 18:49:07.272061
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'http://vod.walla.co.il/(?P<id>[^/]+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['title']=='וואן דיירקשן: ההיסטריה'
    assert WallaIE._TEST['info_dict']['duration'] == 3600
    assert WallaIE._TEST['params']['skip_download'] == True

# Generated at 2022-06-12 18:49:09.715497
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-12 18:49:18.702416
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('url')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:22.130683
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:49:31.424588
# Unit test for constructor of class WallaIE
def test_WallaIE():

    class Options:
        def __init__(self):
            self.test = True
            self.ca_certs = 'ca_certs'

    test_case = WallaIE()
    # test for method _real_extract
    arg1 = 'url'
    arg2 = Options()
    res = test_case._real_extract(arg1, arg2)

    assert isinstance(res, dict)
    assert res['id'] == '2642630'
    assert res['title'] == 'וואן דיירקשן: ההיסטריה'
    assert res['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'

# Generated at 2022-06-12 18:49:38.815232
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['id'] == '2642630'
    assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert WallaIE._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-12 18:49:39.720837
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:49:40.487399
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()
    WallaIE()._real_extract()

# Generated at 2022-06-12 18:49:50.319714
# Unit test for constructor of class WallaIE
def test_WallaIE():
	obj = WallaIE('https://www.walla.co.il/')
	assert (obj.name == 'walla')
	assert (obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
	assert (obj._SUBTITLE_LANGS == {'עברית': 'heb'})

# Generated at 2022-06-12 18:49:52.390633
# Unit test for constructor of class WallaIE
def test_WallaIE():
	item = WallaIE(None)
	assert item is not None, "Should be not none"

# Generated at 2022-06-12 18:50:03.761467
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direcetion-all-for-one")
    assert(ie.params['video_id']) == '2642630'
    assert(ie.params['video_display_id']) == 'one-direcetion-all-for-one'

# Generated at 2022-06-12 18:50:06.980441
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-12 18:50:08.304088
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("1", "2")

# Generated at 2022-06-12 18:50:10.210774
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie 

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-12 18:50:12.769427
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Just a unit test for the constructor of class WallaIE
    """
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie

# Generated at 2022-06-12 18:50:16.612883
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:19.282225
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:20.457698
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()._real_extract(WallaIE._TEST['url'])

# Generated at 2022-06-12 18:50:24.277761
# Unit test for constructor of class WallaIE
def test_WallaIE():
    main.WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:30.953545
# Unit test for constructor of class WallaIE
def test_WallaIE():
        ie = WallaIE()
        assert(ie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
        assert(ie.TEST.keys() == ['url', 'info_dict', 'params'])
        assert(ie.TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
        assert(ie.TEST['info_dict'].keys() == ['id', 'display_id', 'ext', 'title', 'description', 'thumbnail', 'duration'])
        assert(ie.TEST['info_dict']['id'] == '2642630')

# Generated at 2022-06-12 18:50:52.395108
# Unit test for constructor of class WallaIE
def test_WallaIE():
	extractor = WallaIE()

	assert extractor._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:51:03.273737
# Unit test for constructor of class WallaIE
def test_WallaIE():
    videoIE = WallaIE()
    assert videoIE.IE_NAME == 'walla:video:vod'
    assert videoIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:51:04.005084
# Unit test for constructor of class WallaIE
def test_WallaIE():
    s = WallaIE()

# Generated at 2022-06-12 18:51:05.502836
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:51:06.928658
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaie = WallaIE(_VALID_URL)
    assert wallaie != None

# Generated at 2022-06-12 18:51:07.464397
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:51:08.470424
# Unit test for constructor of class WallaIE
def test_WallaIE():

	WallaIE()
	

# Generated at 2022-06-12 18:51:09.334605
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:51:18.429384
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert instance._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:51:19.195990
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._TEST

# Generated at 2022-06-12 18:51:44.998564
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-12 18:51:45.715681
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-12 18:51:51.810607
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}
    assert ie.true_url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie.video_id == '2642630'
    assert ie.display_id == 'one-direction-all-for-one'

    if __name__ == '__main__':
        test_Wall

# Generated at 2022-06-12 18:51:54.474046
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE(None)._download_xml(None, None) == None
    assert WallaIE(None)._real_extract(None) == None

# Generated at 2022-06-12 18:51:55.028190
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-12 18:51:58.123007
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:52:05.809013
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test_url_bad = 'http://example.com'
    class_ = WallaIE
    match_part = 'http://vod.walla.co.il/'
    regex = re.compile(r'^%s.*' % re.escape(match_part))
    ie = class_()
    mobj = re.match(ie._VALID_URL, test_url)
    assert mobj is not None
    mobj = re.match(ie._VALID_URL, test_url_bad)
    assert mobj is None
    assert ie._real_extract(test_url)['id'] == '2642630'

# Generated at 2022-06-12 18:52:08.029593
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for constructor of class WallaIE"""
    ie = WallaIE()
    assert ie.get_host() == "vod.walla.co.il"

# Generated at 2022-06-12 18:52:08.760242
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:52:19.633332
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:53:16.116893
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Test constructor of class WallaIE."""

    # Create an instance of class WallaIE
    walla_ie = WallaIE()

    assert walla_ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert walla_ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:53:16.800978
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w

# Generated at 2022-06-12 18:53:20.294393
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """ Test constructor of class WallaIE """
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wallaIE = WallaIE(url)
    print(wallaIE)

# Generated at 2022-06-12 18:53:21.326145
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("url")._real_extract("")

# Generated at 2022-06-12 18:53:27.265821
# Unit test for constructor of class WallaIE
def test_WallaIE():
    testUrl = r'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    mobj = re.match(ie._VALID_URL, testUrl)
    assert mobj.group('id') == '2642630'
    assert mobj.group('display_id') == 'one-direction-all-for-one'

# Generated at 2022-06-12 18:53:37.892925
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wallaIE = WallaIE()
    assert wallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert wallaIE._SUBTITLE_LANGS == { 'עברית': 'heb' }

# Generated at 2022-06-12 18:53:38.771406
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("", "")

# Generated at 2022-06-12 18:53:46.582036
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    instance.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    instance.suitable('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    instance.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/?w=null/null/2642630/@@/video/flv_pl')
    instance.suitable('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one/?w=null/null/2642630/@@/video/flv_pl')

# Generated at 2022-06-12 18:53:47.293528
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE()

# Generated at 2022-06-12 18:53:55.476823
# Unit test for constructor of class WallaIE
def test_WallaIE():
    walla = WallaIE()
    assert walla.get_id() == 'Walla'
    assert walla.get_type() == 'video'
    assert walla.get_short_type() == 'video'
    assert walla.get_long_type() == 'Walla video'
    assert walla.get_url_re() == "https?://vod.walla.co.il/[^/]+/(\d+)/(.+)"
    assert walla.get_example_url() == 'https://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:56:02.808577
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test with a good url.
    tags = WallaIE._VALID_URL.split('|')
    ie = WallaIE(tags[0])
    ie._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:56:06.664811
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test basic instantiation of class WallaIE
    ie = WallaIE()
    # Test extraction of a valid URL
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._parse_video_id(url) == '2642630'

# Generated at 2022-06-12 18:56:07.834373
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-12 18:56:10.030583
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('foo', 'bar')
    assert ie.SUBTITLE_LANGS == {'עברית': 'heb'}


# Generated at 2022-06-12 18:56:11.789622
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:56:14.991017
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert  not w.suitable('http://vod.walla.co.il/')
    assert  not w.suitable('http://walla.co.il/')

# Generated at 2022-06-12 18:56:16.437857
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('www.walla.com', {'title': 'title'})
    assert ie.title == 'title'

# Generated at 2022-06-12 18:56:19.923407
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('WallaIE', 'vod.walla.co.il', 'http://vod.walla.co.il/?w=null/null/2642630/@@/video/flv_pl', 2642630)

# Generated at 2022-06-12 18:56:20.757549
# Unit test for constructor of class WallaIE
def test_WallaIE():
      assert WallaIE().IE_NAME == 'walla'

# Generated at 2022-06-12 18:56:27.465393
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Example URL
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # Create WallaIE instance
    walla_instance = WallaIE()
    # Call _real_extract function with given URL
    res = walla_instance._real_extract(url)
    # Get duration variable
    duration = int_or_none(xpath_text(res, './duration'))
    # Check that duration is in range of [3600 - 1, 3600 + 1]
    # and if not, print an error message