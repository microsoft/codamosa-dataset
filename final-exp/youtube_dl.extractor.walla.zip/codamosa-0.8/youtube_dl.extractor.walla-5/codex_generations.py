

# Generated at 2022-06-12 18:49:04.226067
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie._VALID_URL = r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:07.177264
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.url == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-12 18:49:09.906949
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(ie.vid == '2642630')
    assert(ie.display_id == 'one-direction-all-for-one')

# Generated at 2022-06-12 18:49:18.045443
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create an instance of class WallaIE
    i = WallaIE()
    # Call function _real_extract of class WallaIE
    i._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Call function _real_extract of class WallaIE
    i._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Call function _real_extract of class WallaIE
    i._real_extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:49:20.299913
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.compat_str('abc') == 'abc'

# Generated at 2022-06-12 18:49:26.296265
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test is meant to be run only when needed; see #18548.
    if not hasattr(re, '_pattern_type'):
        return
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    if ie:
        return

# Generated at 2022-06-12 18:49:36.667725
# Unit test for constructor of class WallaIE
def test_WallaIE():
	assert WallaIE._VALID_URL == re.compile(r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
	assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	assert WallaIE._TEST['info_dict']['id'] == '2642630'
	assert WallaIE._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
	assert WallaIE._TEST['info_dict']['ext'] == 'flv'

# Generated at 2022-06-12 18:49:39.197093
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    obj = ie.ie_key()
    assert obj == 'Walla'

test_WallaIE()

# Generated at 2022-06-12 18:49:41.202234
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie


# Generated at 2022-06-12 18:49:43.613197
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global WallaIE
    y = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-12 18:50:00.433754
# Unit test for constructor of class WallaIE
def test_WallaIE():
    part = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one',{'skip_download': True})
    assert part.get('ext') == 'flv'
    assert int(part.get('duration')) > 0
    assert part.get('thumbnail') != ''
    assert part.get('title') != ''
    assert part.get('description') != ''
    assert part.get('id') == '2642630'
    assert part.get('display_id') == 'one-direction-all-for-one'

# Generated at 2022-06-12 18:50:10.704425
# Unit test for constructor of class WallaIE
def test_WallaIE():
    valid_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    invalid_url = 'http://tv.walla.co.il/item/2642630/one-direction-all-for-one'
    valid_url_video_id = 2642630
    valid_url_display_id = 'one-direction-all-for-one'
    ie = WallaIE()
    valid_url_mobj = re.match(ie._VALID_URL, valid_url)

    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert valid_url_mobj.group('id') == str

# Generated at 2022-06-12 18:50:11.591018
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('url')
    assert ie.SUCCESS



# Generated at 2022-06-12 18:50:16.317729
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Make an instance of class WallaIE for test
    ie = WallaIE()

    # Run unit tests for test_WallaIE
    assert WallaIE._TEST == ie._TEST



# Generated at 2022-06-12 18:50:20.298490
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Constructor
    demo_unit_test = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    # Inherited from InfoExtractor
    assert demo_unit_test._downloader is not None
    assert demo_unit_test._WORKING_URL_RE is not None

# Generated at 2022-06-12 18:50:28.109669
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:50:34.067760
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check if the class is correctly initialized
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-12 18:50:35.583051
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    # Constructor does not raise exception
    ie = WallaIE(None)

# Generated at 2022-06-12 18:50:37.253389
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:38.242217
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-12 18:50:48.850759
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:50:49.827234
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
        assert 0 == 1
    except TypeError:
        assert 1 == 1

# Generated at 2022-06-12 18:50:55.488136
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    test_obj = WallaIE(url)
    assert test_obj._SUBTITLE_LANGS.get('עברית') == 'heb'

# Generated at 2022-06-12 18:50:58.271584
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    ie.download()

# Generated at 2022-06-12 18:51:00.648573
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract(WallaIE._TEST['url'], WallaIE._TEST['info_dict'])

# Generated at 2022-06-12 18:51:03.243221
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check that url parsing regexp works
    assert WallaIE._VALID_URL.match("http://vod.walla.co.il/wtv/1/1/1/1/1/1/1")

# Generated at 2022-06-12 18:51:05.483712
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert True # Run test

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-12 18:51:09.866947
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Test object constructor
    """
    ie = WallaIE("WallaIE", "/some/path/testfile.html")
    assert ie.working_directory == '/some/path'
    assert ie.test_filename == 'testfile'
    assert ie.test_file == '/some/path/testfile.html'

# Generated at 2022-06-12 18:51:10.721542
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-12 18:51:15.314160
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie._TEST == WallaIE._TEST
    assert ie._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS
    assert ie._real_extract == WallaIE._real_extract

# Generated at 2022-06-12 18:51:48.430922
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie=WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie.getURL() == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert ie.getVideoId() == "2642630"
    assert ie.getVideoDisplayId() == "one-direction-all-for-one"
    assert ie.getURLTemplate() == WallaIE._VALID_URL
    assert ie.getRegex() == WallaIE._VALID_URL



# Generated at 2022-06-12 18:51:58.450993
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE().ie_key() == 'Walla'
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE()._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:52:06.083437
# Unit test for constructor of class WallaIE
def test_WallaIE():
    youtube_ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert youtube_ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert youtube_ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert youtube_ie._TEST['info_dict']['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:52:12.834227
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# test constructor
	walla_obj = WallaIE('https://vod.walla.co.il/vod/2642630/one-direction-all-for-one')
	assert walla_obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
	assert walla_obj._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:52:16.123689
# Unit test for constructor of class WallaIE
def test_WallaIE():
    c = WallaIE('', '', '', '')
    assert c.download('', '', '') == None

# Generated at 2022-06-12 18:52:20.985275
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # This is really a terrible test, but it's good enough for now.
    # TODO Make this test meaningful.
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE._VALID_URL == WallaIE._TEST['url']
    WallaIE(WallaIE._TEST)._real_extract(url)

# Generated at 2022-06-12 18:52:22.267021
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-12 18:52:23.675988
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()
    assert(a is not None)

# Generated at 2022-06-12 18:52:27.338545
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from extractor import Extractor
    extr = Extractor()
    extr.add_info_extractor(WallaIE)
    video = extr.fetch('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one', force_http=True)
    assert video.get('title', None) == 'וואן דיירקשן: ההיסטריה'

# Generated at 2022-06-12 18:52:27.995484
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:53:25.800337
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # check if valid_url of WallaIE class is working
    ie = WallaIE(None)
    test_urls = [
        WallaIE._TEST['url']
    ]
    for test_url in test_urls:
        mobj = re.match(ie._VALID_URL, test_url)
        assert mobj
        assert mobj.group('id') == WallaIE._TEST['info_dict']['id']
        assert mobj.group('display_id') == WallaIE._TEST['info_dict']['display_id']


# Generated at 2022-06-12 18:53:33.350815
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.construct_from_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.display_id == 'one-direction-all-for-one'
    assert ie.video_id == '2642630'
    assert isinstance(ie.x, WallaIE)

if __name__ == '__main__':
    # test_WallaIE()
    print('Unit tests are not fully ready')

# Generated at 2022-06-12 18:53:40.092913
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:53:43.248584
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:53:48.556434
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = '2642630'
    display_id = 'all-for-one'

# Generated at 2022-06-12 18:53:50.119996
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie is not None, 'Failed to create WallaIE'


# Generated at 2022-06-12 18:53:57.549726
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Check if the WallaIE class constructor works
    # Check if the constructor raises ValueError if url is poorer
    from ..utils import ExtractorError
    from ..compat import compat_http_client
    import six
    if six.PY2:
        from urllib2 import HTTPError
    else:
        from urllib.error import HTTPError

    url = 'http://www.youtube.com' # try to use a valid url
    ie = WallaIE(url)
    assert(isinstance(ie, WallaIE))
    # try to use an invalid url
    with pytest.raises(ExtractorError):
        ie = WallaIE('http://www.youtubewithinvalidurl.com')

    #Check if the constructor raises HTTPError if url is valid but does not exist

# Generated at 2022-06-12 18:54:00.308982
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("")
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:54:10.417479
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    assert WallaIE._VALID_URL == WallaIE.VALID_URL
    assert WallaIE._TEST == WallaIE.TEST
    assert WallaIE._SUBTITLE_LANGS == WallaIE.SUBTITLE_LANGS
    assert WallaIE._real_extract == WallaIE.real_extract
    assert re.match(WallaIE._VALID_URL, url)
    assert re.search(WallaIE._TEST['info_dict']['description'], WallaIE._TEST['description'])

# Generated at 2022-06-12 18:54:13.335991
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    assert(len(ie._VALID_URL) > 0)
    assert(ie._TEST['url'] is not None)
    assert(ie._TEST['info_dict'] is not None)
    assert(ie._TEST['params'] is not None)

# Generated at 2022-06-12 18:56:19.124077
# Unit test for constructor of class WallaIE
def test_WallaIE():
	# Test case 1:
	# url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	# ie = WallaIE(url)
	# print ie.get_videoID()
	# print ie.get_videoTitle()
	# print ie.get_videoExt()
	# print ie.get_videoURL()
	# print ie.get_videoDesc()
	
	# Test case 2:
	url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	ie = WallaIE(url)

# Generated at 2022-06-12 18:56:23.107053
# Unit test for constructor of class WallaIE
def test_WallaIE():
  # URL to test the constructor
  URL = 'http://www.walla.co.il'
  # Creating new instance of WallaIE
  WallaIEInstance = WallaIE(WallaIE.DEFAULT_WORKER_CLASS(), {})
  # Checking that URL is instance of WallaIE
  assert WallaIEInstance.suitable(URL)

# Generated at 2022-06-12 18:56:27.519295
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:56:29.715840
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE('Some url')
    except AttributeError:
        raise AssertionError('Constructor of class WallaIE failed')
    
    return True

# Generated at 2022-06-12 18:56:39.867438
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Unit test for constructor of class WallaIE.
    """
    url = 'http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl'
    expected_video_id = '2642630'
    expected_display_id = 'one-direction-all-for-one'

    m = re.match(WallaIE._VALID_URL,
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert m.group('id') == expected_video_id
    assert m.group('display_id') == expected_display_id


# Generated at 2022-06-12 18:56:41.010319
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE()
    test.WallaIE()

# Generated at 2022-06-12 18:56:48.061045
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE('url', {}, {}, {}, {})
    # Test for VIDEO_URL
    assert instance._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    # Test for extract()

# Generated at 2022-06-12 18:56:52.112662
# Unit test for constructor of class WallaIE
def test_WallaIE():
  ie = WallaIE()
  ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
  ie.extract()

# Generated at 2022-06-12 18:57:00.082960
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert re.search('https?://vod\.walla\.co\.il/', ie.valid_url('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')) is not None
    assert re.search('https?://vod\.walla\.co\.il/', ie.valid_url('http://vod.walla.co.il/x/2642630/one-direction-all-for-one')) is None
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:57:06.704066
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """Unit test for constructor of class WallaIE"""
    instance = WallaIE()
    assert instance._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert instance._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'