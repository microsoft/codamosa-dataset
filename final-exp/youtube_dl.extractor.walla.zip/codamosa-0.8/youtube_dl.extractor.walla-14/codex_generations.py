

# Generated at 2022-06-12 18:48:59.516309
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.suitable('vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    ie.extract('vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:49:00.612632
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('',{})

# Generated at 2022-06-12 18:49:03.796082
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    className = WallaIE
    constructor = globals()[className.__name__]
    instance = constructor(url)



# Generated at 2022-06-12 18:49:05.520737
# Unit test for constructor of class WallaIE
def test_WallaIE():
    if __name__ == '__main__':
        url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
        WallaIE()._real_extract(url)

# Generated at 2022-06-12 18:49:06.751145
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE()

# Generated at 2022-06-12 18:49:10.258798
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # In this case the argument is not a url to a webpage or a content of a webpage
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE(url)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == url

# Generated at 2022-06-12 18:49:17.083942
# Unit test for constructor of class WallaIE
def test_WallaIE():
    input_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    walla = WallaIE()
    output = walla.extract(input_url)
    assert '_id' in output
    assert output['_id'] == '2642630'
    assert 'duration' in output
    assert output['duration'] == 3600
    assert 'title' in output
    assert 'description' in output
    assert 'thumbnail' in output
    assert 'formats' in output
    assert 'subtitles' in output

# Generated at 2022-06-12 18:49:20.050298
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE()

# Generated at 2022-06-12 18:49:21.188292
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None)

# Generated at 2022-06-12 18:49:22.135751
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()

# Generated at 2022-06-12 18:49:36.938051
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._SUBTITLE_LANGS['עברית'] == 'heb'
    assert WallaIE()._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:47.054279
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w.okToProcess(TESTS)



# Generated at 2022-06-12 18:49:57.939796
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    # The videoId is 2642630
    assert 2642630 == ie.videoId
    # The displayId is one-direction-all-for-one
    assert "one-direction-all-for-one" == ie.displayId
    # The videoUrl is http://vod.walla.co.il/movie/2642630/one-direction-all-for-one
    assert "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one" == ie.videoUrl
    # The _VALID_URL is correct

# Generated at 2022-06-12 18:50:00.179854
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-12 18:50:02.178861
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE("WallaMelodyIE()")._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-12 18:50:03.653673
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:50:06.897559
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Arrange
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    # Act
    WallaIE()

    # Assert
    assert True

# Generated at 2022-06-12 18:50:09.246742
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-12 18:50:09.800618
# Unit test for constructor of class WallaIE
def test_WallaIE():
    pass

# Generated at 2022-06-12 18:50:15.484088
# Unit test for constructor of class WallaIE
def test_WallaIE():
    info_extractor = WallaIE()
    assert info_extractor.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert info_extractor.suitable('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl')
    assert not info_extractor.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one/1')
    assert not info_extractor.suitable('https://www.youtube.com/watch?v=BaW_jenozKc')


# Generated at 2022-06-12 18:50:28.186052
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """
    Use these command to make a test:
    curl "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one" | grep "var movie"
    """
    # test - real url
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    ie = WallaIE()
    ie.extract(url)
    info = ie._info
    #assert info['id'] == 2642630
    #assert info['display_id'] == 'one-direction-all-for-one'
    #assert info['ext'] == 'flv'
    #assert info['title'] == 'וואן דיירקשן: ההיסטר

# Generated at 2022-06-12 18:50:32.763383
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # If you want to see the HTTP request
    # set global variable 'WALLA_DEBUG' to True
    # import os
    # os.environ['WALLA_DEBUG'] = 'True'
    #
    ie = WallaIE()
    ie.download(WallaIE._TEST['url'])

# Generated at 2022-06-12 18:50:36.626064
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(ie.VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-12 18:50:39.388733
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(obj, WallaIE)

# Generated at 2022-06-12 18:50:41.653534
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL
    ie._TEST
    ie._real_extract
    #TODO add test for other methods, attributes

# Generated at 2022-06-12 18:50:47.769171
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    # Check if video id is extracted correctly
    assert ie._real_extract(_TEST.get('url'))['id'] == '2642630'
    # Check if video display id is extracted correctly
    assert ie._real_extract(_TEST.get('url'))['display_id'] == 'one-direction-all-for-one'

# Generated at 2022-06-12 18:50:49.531626
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_obj = WallaIE()
    assert type(test_obj) is WallaIE

# Generated at 2022-06-12 18:50:51.196443
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE(None)
    assert ie


# Generated at 2022-06-12 18:51:02.554995
# Unit test for constructor of class WallaIE
def test_WallaIE():
    e = WallaIE()
    assert e._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:51:05.049074
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie is not None


# Generated at 2022-06-12 18:51:17.603966
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_instance = WallaIE()
    assert test_instance is not None

# Generated at 2022-06-12 18:51:23.631629
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

    # print the value of some members of class WallaIE
    print( ie._VALID_URL )
    print( ie._TEST )
    print( ie._SUBTITLE_LANGS )
    print( ie._real_extract )

    assert( ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)' )

# Generated at 2022-06-12 18:51:29.604827
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('walla', {})
    assert ie.ie_key() == 'walla'
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True
    assert ie.suitable('http://www.google.co.il/') == False

# Generated at 2022-06-12 18:51:30.595122
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE()

# Generated at 2022-06-12 18:51:37.376817
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("walla")
    assert ie.ie_key() == 'walla'
    assert ie.suitable("""http://vod.walla.co.il/movie/2642630/one-direction-all-for-one""")
    assert ie.suitable("""http://vod.walla.co.il/movie/2642630/one-direction-all-for-one""") == True
    assert ie.suitable("""http://vod.walla.co.il/movie/2642630/one-direction-all-for-one""") == True

# Generated at 2022-06-12 18:51:37.811258
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-12 18:51:40.195952
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-12 18:51:47.314091
# Unit test for constructor of class WallaIE
def test_WallaIE():
	print("testing WallaIE")
	url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
	wallaIE = WallaIE()
	print("testing WallaIE real_extract")
	try:
		wallaIE._real_extract(url)
	except Exception as e:
		print("WallaIE real_extract raises an exception: "+str(e))
		return False
	return True

# Generated at 2022-06-12 18:51:47.993453
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE()


# Generated at 2022-06-12 18:51:49.597709
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    assert isinstance(instance, WallaIE)

# Generated at 2022-06-12 18:52:19.504985
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.name == WallaIE.ie_key()
    expected = 'Walla'
    if expected == ie.ie_key():
        assert 'Walla' == ie.ie_key()
    else:
        assert ie.name == ie.ie_key()
    assert WallaIE.ie_key() in ie.name

# Generated at 2022-06-12 18:52:21.813406
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.VALID_URL == _VALID_URL
    assert ie.TEST == _TEST

# Generated at 2022-06-12 18:52:23.602568
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        return WallaIE()
    except:
        raise AssertionError("failed to instantiate a WallaIE object")

# Generated at 2022-06-12 18:52:25.076477
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:52:25.987085
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-12 18:52:27.066136
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:52:29.181233
# Unit test for constructor of class WallaIE
def test_WallaIE():
    instance = WallaIE({})
    assert isinstance(instance, WallaIE)

# Generated at 2022-06-12 18:52:30.636995
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wallaIE = WallaIE()
    wallaIE

# Generated at 2022-06-12 18:52:33.236034
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.download("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-12 18:52:40.728859
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'

    WallaIE._real_extract(WallaIE(), "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one", '2642630', 'one-direction-all-for-one')

    # checking that the regex works or not
    assert re.match(WallaIE._VALID_URL, "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert re.match(WallaIE._VALID_URL, "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one") == None

# Generated at 2022-06-12 18:53:33.601375
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_class_WallaIE = WallaIE()
    print('test_class_WallaIE.constructor:', test_class_WallaIE)



# Generated at 2022-06-12 18:53:34.334205
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:53:37.720896
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    instance = WallaIE()
    instance.suitable(url)
    instance.extract(url)
    instance.suitable(url)

# Generated at 2022-06-12 18:53:38.930257
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except TypeError:
        assert False

# Generated at 2022-06-12 18:53:42.050493
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE(WallaIE.suitable)
    if not (isinstance(obj, WallaIE) and obj.SUITABLE == WallaIE.suitable):
        raise AssertionError()


# Generated at 2022-06-12 18:53:43.622929
# Unit test for constructor of class WallaIE
def test_WallaIE():
    unit_test_WallaIE = WallaIE('WallaIE')
    unit_test_WallaIE
    return unit_test_WallaIE

# Generated at 2022-06-12 18:53:52.644971
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(ie, WallaIE)
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:53:59.208762
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert (ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-12 18:54:04.061470
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Arrange
    # Act
    wallaIE = WallaIE()
    # Assert
    assert(len(wallaIE.IE_NAME) > 0)
    assert(wallaIE.IE_NAME == 'walla')
    assert(wallaIE.IE_DESC == 'Walla! video')
    assert(len(wallaIE._VALID_URL) > 0)



# Generated at 2022-06-12 18:54:08.490924
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:56:11.243027
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-12 18:56:15.024204
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert type(ie) is WallaIE
    assert ie.ie_key() == 'Walla'
    assert ie.ie_name() == 'Walla'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'


# Generated at 2022-06-12 18:56:16.097485
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test_ie = WallaIE(InfoExtractor())
    assert isinstance(test_ie, InfoExtractor)

# Generated at 2022-06-12 18:56:18.797501
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie
    assert ie._VALID_URL
    assert ie._TEST
    assert ie._SUBTITLE_LANGS

# Generated at 2022-06-12 18:56:26.463708
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE()
    assert obj._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"
    assert obj._TEST['url'] == "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-12 18:56:27.876815
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:56:29.679532
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:56:31.966279
# Unit test for constructor of class WallaIE
def test_WallaIE():
	WallaIE()


# Generated at 2022-06-12 18:56:35.286852
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# todo:
# - parse subtitles

# Generated at 2022-06-12 18:56:36.306114
# Unit test for constructor of class WallaIE
def test_WallaIE():
    x = WallaIE("", {""})
    assert x is not None