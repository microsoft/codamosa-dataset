

# Generated at 2022-06-12 18:48:58.059841
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:49:00.138030
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert 'video2.walla.co.il' in ie._downloader.urlopen.__module__


# Generated at 2022-06-12 18:49:07.740337
# Unit test for constructor of class WallaIE
def test_WallaIE():
    from utils import fix_xml_ampersands
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(WallaIE._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')

# Generated at 2022-06-12 18:49:09.715700
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:49:18.701147
# Unit test for constructor of class WallaIE
def test_WallaIE():
    
    ie = WallaIE('http://www.walla.co.il', {}, {}, {})

    assert(
        ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    )
    

# Generated at 2022-06-12 18:49:32.138825
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'Walla'
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:34.801670
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("https://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie is not None

# Generated at 2022-06-12 18:49:37.662789
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:49:47.533254
# Unit test for constructor of class WallaIE
def test_WallaIE():
	info = WallaIE._build_url_result('url')
	assert info['id'] == '2642630'
	assert info['display_id'] == 'one-direction-all-for-one'
	assert info['ext'] == 'flv'
	assert info['title'] == 'וואן דיירקשן: ההיסטריה'
	assert info['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
	assert info['thumbnail'] == r're:^https?://.*\.jpg'
	assert info['duration'] == 3600
	assert info['params']['skip_download'] == True
	assert info['_type'] == 'url'

# Generated at 2022-06-12 18:49:58.340621
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('WallaIE')._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE('WallaIE')._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:50:04.907796
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'Walla'

# Generated at 2022-06-12 18:50:06.258731
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.title == 'Walla'

# Generated at 2022-06-12 18:50:14.298112
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert(ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')
    assert(ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert(ie._TEST['info_dict']['id'] == '2642630')
    assert(ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one')

# Generated at 2022-06-12 18:50:16.208295
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL
    assert WallaIE()._TEST == WallaIE._TEST
    assert WallaIE()._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS

# Generated at 2022-06-12 18:50:18.417045
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:20.380080
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_key() in ie.descriptions

# Generated at 2022-06-12 18:50:22.709229
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w is not None

# Generated at 2022-06-12 18:50:26.366487
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE._VALID_URL == "https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)")
    assert(WallaIE._SUBTITLE_LANGS == {'עברית': 'heb'})

# Generated at 2022-06-12 18:50:29.509067
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(ie, WallaIE)

# Generated at 2022-06-12 18:50:30.522302
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # TODO: Add a unit test
    return False

# Generated at 2022-06-12 18:50:37.026648
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:50:49.024040
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('url')
    assert obj.IE_NAME == 'walla:video'
    assert obj._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:50:54.105733
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test that the class is constructable
    WallaIE('rtmp://wafla.walla.co.il/vod/mp4:tv/yom/yom_12/yom_12_kippur/yom_12_kippur_report1.mp4')

# Generated at 2022-06-12 18:50:54.740674
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:50:55.595543
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-12 18:51:01.226805
# Unit test for constructor of class WallaIE
def test_WallaIE():
    obj = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj.SUCCESS == True
    # Test constructor
    obj2 = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert obj2.SUCCESS == True

# Generated at 2022-06-12 18:51:05.389247
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert (ie._VALID_URL == WallaIE._VALID_URL)
    assert (ie._TEST == WallaIE._TEST)
    assert (ie._SUBTITLE_LANGS == WallaIE._SUBTITLE_LANGS)

if __name__ == '__main__':
    test_WallaIE()

# Generated at 2022-06-12 18:51:08.233391
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('a')
    assert ie.extractor_key == 'walla'
    assert ie.ie_key == 'Walla'
    assert ie.name == 'walla'
    assert ie.host == 'vod.walla.co.il'

# Generated at 2022-06-12 18:51:11.157981
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ieTest = WallaIE(None)
    assert ieTest is not None
    assert ieTest.__class__.__name__ == 'WallaIE'

# Generated at 2022-06-12 18:51:12.909284
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert(WallaIE()._SUBTITLE_LANGS['עברית'] == 'heb')

# Generated at 2022-06-12 18:51:29.054561
# Unit test for constructor of class WallaIE
def test_WallaIE():
    test = WallaIE({})
    assert test._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:51:30.496466
# Unit test for constructor of class WallaIE
def test_WallaIE():
    vod_walla_il = WallaIE()

# Generated at 2022-06-12 18:51:31.777874
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:51:32.781376
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:51:34.170423
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'

# Generated at 2022-06-12 18:51:40.841718
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(ie, WallaIE)
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:51:49.842013
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test with url of type http://vod.walla.co.il/movie/2642630/one-direction-all-for-one
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    info_dict = WallaIE()._real_extract(url)

# Generated at 2022-06-12 18:51:54.938837
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Test URL of type http://vod.walla.co.il/movie/2642630/one-direction-all-for-one
    test_url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    wi = WallaIE()
    print(wi.extract(test_url))

# Generated at 2022-06-12 18:51:59.427571
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    obj = object.__new__(ie.__class__)
    ie.__init__(obj)
    assert ie.ie_key() == 'Walla' # ie_key() function has no side effect
    assert ie.ie_key() == 'Walla'
    assert ie.SUCCESS == True
    assert ie.test() == True

# Generated at 2022-06-12 18:51:59.762152
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:52:28.962026
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"

# Generated at 2022-06-12 18:52:32.469386
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert isinstance(ie, WallaIE)


# Generated at 2022-06-12 18:52:33.113372
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:52:35.917113
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()
    assert IE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:52:37.881270
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # call constructor with given arguments
    WallaIE(url='http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:52:43.375003
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'walla'
    assert ie.ie_name() == 'walla.co.il'
    assert ie.server_encoding == 'iso-8859-8'
    assert ie.http_headers == {
        'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:35.0) Gecko/20100101 Firefox/35.0',
    }
    assert ie.regex == [re.compile(WallaIE._VALID_URL)]

# Generated at 2022-06-12 18:52:45.396680
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.SUFFIX == '.flv'


# Generated at 2022-06-12 18:52:46.064729
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE()
    assert w is not None

# Generated at 2022-06-12 18:52:49.527907
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:52:51.654839
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.pid == 2642630
    assert ie.display_id == 'one-direction-all-for-one'


# Generated at 2022-06-12 18:53:48.155497
# Unit test for constructor of class WallaIE
def test_WallaIE():
    #TODO: write assertions for class WallaIE
    ie = WallaIE(dict())
    assert isinstance(ie, WallaIE)


# Generated at 2022-06-12 18:53:52.065933
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one"
    expected_result = "2642630"
    w_i_e = WallaIE(url)
    actual_result = w_i_e.video_id
    assert actual_result == expected_result

# Generated at 2022-06-12 18:53:54.867130
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == "http://vod.walla.co.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"

# Generated at 2022-06-12 18:54:04.212304
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('rtmp://wafla.walla.co.il/vod/?_fcs_vhost=rtmp://wafla.walla.co.il')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:54:13.470855
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Create a constructor for class YoutubeIE
    yt_constructor = WallaIE()

    assert yt_constructor._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:54:14.586739
# Unit test for constructor of class WallaIE
def test_WallaIE():
    try:
        WallaIE()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-12 18:54:15.767285
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE(None, None)

# Generated at 2022-06-12 18:54:19.829544
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'))
    assert(not ie.suitable('http://www.google.com'))

# Generated at 2022-06-12 18:54:27.616414
# Unit test for constructor of class WallaIE
def test_WallaIE():
    import json
    import requests
    from urlparse import urlparse

    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    _VALID_URL = r'http://vod.walla.co.il/movie/([\d]+)/(.+)'
    assert re.match(_VALID_URL, url)

    mobj = re.match(r'http://vod.walla.co.il/movie/([\d]+)/(.+)', url)
    video_id = mobj.group(1)
    display_id = mobj.group(2)


# Generated at 2022-06-12 18:54:29.478080
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'

# Generated at 2022-06-12 18:56:33.865410
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-12 18:56:36.607352
# Unit test for constructor of class WallaIE
def test_WallaIE():
    class WallaIE_test(WallaIE):
        def _real_initialize(self):
            pass
        def _real_extract(self, url):
            pass
    test_class = WallaIE_test('test_password')

# Generated at 2022-06-12 18:56:44.567006
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video = WallaIE()._real_extract(
        'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert video['id'] == '2642630'
    assert video['display_id'] == 'one-direction-all-for-one'
    assert video['ext'] == 'flv'
    assert video['title'] == 'וואן דיירקשן: ההיסטריה'
    assert video['description'] == 'md5:de9e2512a92442574cdb0913c49bc4d8'
    assert video['thumbnail'] == r're:^https?://.*\.jpg'
    assert video['duration'] == 3600

# Generated at 2022-06-12 18:56:48.746238
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST.keys() == [ 'url', 'info_dict', 'params' ]
    assert 'id' in ie._TEST['info_dict'].keys()
    assert 'display_id' in ie._TEST['info_dict'].keys()
    assert 'videoid' in (ie._TEST['params']).keys()

# Generated at 2022-06-12 18:56:55.151061
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.suitable('https://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.suitable('http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl')

# Generated at 2022-06-12 18:56:59.901718
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-12 18:57:00.713515
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie

# Generated at 2022-06-12 18:57:05.584363
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:57:09.297090
# Unit test for constructor of class WallaIE

# Generated at 2022-06-12 18:57:11.057583
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert(re.match('^walla:', ie.IE_NAME) is not None)