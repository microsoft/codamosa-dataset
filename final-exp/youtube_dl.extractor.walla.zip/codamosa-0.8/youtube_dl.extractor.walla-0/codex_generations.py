

# Generated at 2022-06-12 18:48:58.986794
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Tests that WallaIE follows the old style of writing
    # constructors of classes and that asserts is used.
    assert True

# Generated at 2022-06-12 18:49:07.079872
# Unit test for constructor of class WallaIE
def test_WallaIE():
  ie = WallaIE()
  ie.extractor(test_dict['url'])
  #assert ie.extractor(test_dict['url']) == test_dict['info_dict']
  assert ie.extractor(test_dict['url']) == test_dict['info_dict']
  #assert test_dict.__eq__(test_dict)


# Generated at 2022-06-12 18:49:10.120243
# Unit test for constructor of class WallaIE
def test_WallaIE():
    IE = WallaIE()
    video = IE._real_extract("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert video['id'] == '2642630'
    assert video['display_id'] == 'one-direction-all-for-one'
    assert video['ext'] == 'flv'
    assert len(video['formats']) == 4

# Generated at 2022-06-12 18:49:10.879862
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:49:15.273428
# Unit test for constructor of class WallaIE
def test_WallaIE():
    testObject = WallaIE()
    assert(testObject._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-12 18:49:16.934387
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert isinstance(WallaIE, InfoExtractor) == True

# Generated at 2022-06-12 18:49:22.697985
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.ie_key() == 'Walla'
    assert ie.ie_id() == 'Walla'
    assert ie.site_url() == 'http://www.walla.co.il/'

# Generated at 2022-06-12 18:49:31.475858
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['params']['skip_download'] == True

# Generated at 2022-06-12 18:49:32.722588
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:49:33.715392
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE();
    assert str(ie) == 'Walla'

# Generated at 2022-06-12 18:49:41.465836
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')


# Generated at 2022-06-12 18:49:50.176965
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:49:51.978694
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == WallaIE._VALID_URL
    assert ie._TEST == WallaIE._TEST

# Generated at 2022-06-12 18:49:52.850892
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:49:54.192016
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()._VALID_URL == WallaIE._VALID_URL

# Generated at 2022-06-12 18:49:57.623298
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.extract()['id'] == '2642630'

# Generated at 2022-06-12 18:50:06.387442
# Unit test for constructor of class WallaIE
def test_WallaIE():
    vd = WallaIE()
    assert vd.__class__.__name__ == "WallaIE", "Test failed"
    # Test with no parameters
    try:
        vd.test_without_parameters()
        assert False, "Test failed"
    except TypeError:
        assert True, "Test failed"
    # Test with wrong parameters
    try:
        vd.test_with_wrong_parameters("test")
        assert False, "Test failed"
    except TypeError:
        assert True, "Test failed"
    # Test with correct parameters
    vd.test_with_correct_parameters("test")
    assert True

# Generated at 2022-06-12 18:50:14.369559
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TEST')
    assert hasattr(ie, '_real_extract')
    ie = WallaIE(WallaIE.ie_key())
    ie_test = ie._TEST
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie_test['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie_test['info_dict']['id'] == 2642630
    assert ie_test['info_dict']['display_id']

# Generated at 2022-06-12 18:50:14.755298
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE

# Generated at 2022-06-12 18:50:23.384176
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert WallaIE._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert type(WallaIE._TEST) == dict

# Generated at 2022-06-12 18:50:34.984612
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('1','2')

# Generated at 2022-06-12 18:50:37.335908
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video = WallaIE()

# Generated at 2022-06-12 18:50:38.097183
# Unit test for constructor of class WallaIE
def test_WallaIE():
	pass

# Generated at 2022-06-12 18:50:39.480351
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:50:50.550867
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == r"https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)"
    assert ie._SUBTITLE_LANGS == {'עברית': 'heb'}

# Generated at 2022-06-12 18:50:54.059175
# Unit test for constructor of class WallaIE
def test_WallaIE():
    """ Test function for testing constructor of class WallaIE """
    ie = WallaIE()
    assert ie is not None
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 18:50:56.153383
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE('http://vod.walla.co.il/movie/2642630/')

# Generated at 2022-06-12 18:50:59.181789
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.suitable('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one') == True


# Generated at 2022-06-12 18:51:07.828245
# Unit test for constructor of class WallaIE
def test_WallaIE():
    w = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one');
    assert (w._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)');

# Generated at 2022-06-12 18:51:14.058252
# Unit test for constructor of class WallaIE
def test_WallaIE():
	"""
	Unit test for constructor of class WallaIE
	"""
	print ("Unit test for constructor of class WallaIE")
	print ("----------------------------------------------------------------------")
	# Test case 1 (URL)
	ie = WallaIE("http://video2.walla.co.il/?w=null/null/2642630/@@/video/flv_pl")
	print (ie)
	print ("----------------------------------------------------------------------")


# Generated at 2022-06-12 18:51:47.353061
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # Given
    given_url = r'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    # When
    when_instantiate_WallaIE = WallaIE('youtube-dl')
    # Then
    assert(when_instantiate_WallaIE._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)')

# Generated at 2022-06-12 18:51:47.784528
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:51:49.894640
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie._VALID_URL
    ie._TEST
    ie._download_xml

# Generated at 2022-06-12 18:51:52.314755
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:51:56.536288
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:51:57.081452
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:51:59.144307
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert hasattr(ie, "_VALID_URL")
    assert hasattr(ie, "_TEST")


# Generated at 2022-06-12 18:51:59.720806
# Unit test for constructor of class WallaIE
def test_WallaIE():
    assert WallaIE()

# Generated at 2022-06-12 18:52:00.331481
# Unit test for constructor of class WallaIE
def test_WallaIE():
    WallaIE()

# Generated at 2022-06-12 18:52:02.101359
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie.url == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

# Generated at 2022-06-12 18:52:45.395820
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()

# Generated at 2022-06-12 18:52:55.936792
# Unit test for constructor of class WallaIE
def test_WallaIE():
    a = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert a._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:53:03.717102
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE("http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    assert ie._TEST['url'] == 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert ie._TEST['info_dict']['id'] == '2642630'
    assert ie._TEST['info_dict']['display_id'] == 'one-direction-all-for-one'
    assert ie._TEST['info_dict']['duration'] == 3600
    assert ie._

# Generated at 2022-06-12 18:53:09.396930
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
# End of unit test for constractor of class WallaIE


# Generated at 2022-06-12 18:53:12.782871
# Unit test for constructor of class WallaIE
def test_WallaIE():
    video_id = '2642630'
    display_id = 'one-direction-all-for-one'
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    WallaIE()._real_extract(url)

# Generated at 2022-06-12 18:53:13.342728
# Unit test for constructor of class WallaIE
def test_WallaIE():
    return WallaIE({})


# Generated at 2022-06-12 18:53:14.249385
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('')
    assert ie._VALID_URL()

# Generated at 2022-06-12 18:53:17.421516
# Unit test for constructor of class WallaIE
def test_WallaIE():

    class Walla_Input:
        def __init__(self):
            self.big_test = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'

    args = Walla_Input()
    assert(InfoExtractor(WallaIE()).suitable(args.big_test))


# Generated at 2022-06-12 18:53:28.480927
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    mobj = re.match(WallaIE._VALID_URL, url)
    video_id = mobj.group('id')
    display_id = mobj.group('display_id')

    video = 'http://video2.walla.co.il/?w=null/null/' + video_id + '/@@/video/flv_pl'
    #video = self._download_xml(video, display_id)

    item = video.find('./items/item')

    title = xpath_text(item, './title', 'title')
    description = xpath_text(item, './synopsis', 'description')

# Generated at 2022-06-12 18:53:35.108290
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie.IE_NAME == 'walla'
    assert ie.IE_DESC == 'ערוץ וואלה! וודאו - walla video'
    
    assert ie._VALID_URL == r'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:55:35.669100
# Unit test for constructor of class WallaIE
def test_WallaIE():
    # create an instance of class WallaIE
    x = WallaIE()
    # check the name of the IE
    assert x._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'
    # check the name of the instance
    assert x.IE_NAME == 'walla'


# Generated at 2022-06-12 18:55:37.440897
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    ie.extract('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')

# Generated at 2022-06-12 18:55:45.837267
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:55:53.884206
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE('http://vod.walla.co.il/movie/2642630/one-direction-all-for-one')
    assert ie._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:55:56.367782
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
    assert ie._SUBTITLE_LANGS['עברית'] == 'heb'

# Generated at 2022-06-12 18:56:05.277182
# Unit test for constructor of class WallaIE
def test_WallaIE():
  test = WallaIE()
  # assertEqual(expected, WallaIE._TEST)
  # self.assertEqual(test.get_url(), "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
  # assertEqual(test._VALID_URL, "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")
  # assertEqual(test._TEST, "http://vod.walla.co.il/movie/2642630/one-direction-all-for-one")

# Generated at 2022-06-12 18:56:06.998352
# Unit test for constructor of class WallaIE
def test_WallaIE():
    wIE = WallaIE.ie_key()
    m = wIE._VALID_URL
    assert m
    m = wIE._SUBTITLE_LANGS
    assert m

# Generated at 2022-06-12 18:56:07.934455
# Unit test for constructor of class WallaIE
def test_WallaIE():
    global walla_ie
    walla_ie = WallaIE()
# Test for extract method of class WallaIE

# Generated at 2022-06-12 18:56:15.748447
# Unit test for constructor of class WallaIE
def test_WallaIE():
    url = 'http://vod.walla.co.il/movie/2642630/one-direction-all-for-one'
    assert WallaIE().suitable(url)
    assert WallaIE()._VALID_URL == 'https?://vod\.walla\.co\.il/[^/]+/(?P<id>\\d+)/(?P<display_id>.+)'

# Generated at 2022-06-12 18:56:16.411604
# Unit test for constructor of class WallaIE
def test_WallaIE():
    ie = WallaIE()
