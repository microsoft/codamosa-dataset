

# Generated at 2022-06-22 19:41:02.844075
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as intended"""
    global CLIARGS
    CLIARGS = GlobalCLIArgs({'test_key': 'test_value'})
    assert cliargs_deferred_get('test_key')() == 'test_value'
    assert cliargs_deferred_get('test_key2', 'test_value_default')() == 'test_value_default'
    CLIARGS = GlobalCLIArgs({'test_key': ['a', 'b']})
    assert cliargs_deferred_get('test_key', shallowcopy=True)() == ['a', 'b']


# Legacy API to be removed in Ansible 2.10

# Generated at 2022-06-22 19:41:12.777671
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Test(object):
        x = cliargs_deferred_get('x')

    bla = Test()
    assert bla.x() == {}
    _init_global_context({'x': {'somevar': 'somevalue'}, 'y': ['one', 'two']})
    assert bla.x()['somevar'] == 'somevalue'
    assert bla.x() is bla.x()
    assert bla.x()['somevar'] is CLIARGS['x']['somevar']
    assert isinstance(bla.x(), dict)
    assert not isinstance(bla.x(), Mapping)
    assert isinstance(bla.x()['somevar'], str)
    assert not isinstance(bla.x()['somevar'], basestring)

# Generated at 2022-06-22 19:41:20.094022
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Tests for ``cliargs_deferred_get``"""
    import pytest

    # make sure that the closure works and that the default is returned
    cliargs_getter = cliargs_deferred_get('default', 'sparky')
    assert cliargs_getter() == 'sparky'

    # make sure that the closure works and that the value is returned
    cliargs_getter = cliargs_deferred_get('testkey')
    CLIARGS.update(testkey='testvalue')
    assert cliargs_getter() == 'testvalue'
    CLIARGS.update(testkey=['testvalue1', 'testvalue2'])
    assert cliargs_getter() == ['testvalue1', 'testvalue2']

    # make sure that the closure works and that the shallow copy of

# Generated at 2022-06-22 19:41:31.215515
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Ensure that cliargs_deferred_get creates a closure for deferred value setting

    Originally added this as part of PR #105864 to ensure that cliargs_deferred_get created a
    closure to use for the default.
    """
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CliArgs
    from ansible.utils.context_objects import _init_global_context
    _init_global_context(CliArgs({'foo': 'bar'}))
    assert cliargs_deferred_get('foo')() is cliargs_deferred_get('foo')()

    # Make a change to CliArgs
    modified_dict = CliArgs({'foo': 'bar'})
    modified_dict['foo'] = 42
    _init_global

# Generated at 2022-06-22 19:41:42.367011
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.module_utils.common.collections import is_sequence

    class FakeCliargs(object):
        def __init__(self, keys):
            self.keys = keys
        def get(self, key, default=None):
            if key in self.keys:
                return self.keys[key]
            return default

    FakeKey = namedtuple('FakeKey', ['name', 'value'])

    # Test 1: Deferred get with no shallow copy
    # Sequence, mapping, and set

# Generated at 2022-06-22 19:41:48.743113
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    try:
        _init_global_context(dict(foo='bar'))
        cliargs_get_foo = cliargs_deferred_get('foo', default='baz')
        assert cliargs_get_foo() == 'bar'

        _init_global_context(dict(bar='foo'))
        cliargs_get_foo = cliargs_deferred_get('foo', default='baz')
        assert cliargs_get_foo() == 'baz'
    finally:
        CLIARGS = GlobalCLIArgs({})

# Generated at 2022-06-22 19:41:57.337469
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function
    """
    global CLIARGS
    CLIARGS = CLIArgs(dict(key=['value']))
    assert cliargs_deferred_get('key')() == ['value']
    assert cliargs_deferred_get('key', shallowcopy=True)() == ['value']
    CLIARGS = CLIArgs(dict(key='value'))
    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('key', shallowcopy=True)() == 'value'
    CLIARGS = CLIArgs(dict(key=dict(subkey='subvalue')))
    assert cliargs_deferred_get('key')() == dict(subkey='subvalue')

# Generated at 2022-06-22 19:42:06.171022
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that deferred get works correctly"""
    class Dummy(object):
        pass
    cliargs = Dummy()
    cliargs.foo = 'Foo String'
    # String
    assert cliargs_deferred_get('foo')() == 'Foo String'
    # Shallow copy string
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'Foo String'
    # Default
    assert cliargs_deferred_get('doesnotexist', default='Default')() == 'Default'
    # Shallow copy default
    assert cliargs_deferred_get('doesnotexist', default='Default', shallowcopy=True)() == 'Default'

    # List
    cliargs.foobar = ['Foo', 'Bar']

# Generated at 2022-06-22 19:42:08.607978
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'test_key': 'test_val'})
    assert cliargs_deferred_get('test_key')() == 'test_val'
    with_default = cliargs_deferred_get('test_key_with_default', default='default')
    assert with_default() == 'default'

# Generated at 2022-06-22 19:42:17.794607
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Reset the global to what we get immediately after parsing cli_args
    global CLIARGS
    CLIARGS = CLIARGS.default()

    # Make sure we get the default when asking for an unset value
    assert cliargs_deferred_get('foo', 7)() == 7

    # Make sure we get the value that is set when we ask for it
    CLIARGS['foo'] = 9
    assert cliargs_deferred_get('foo', 7)() == 9

    # Test the shallowcopy
    CLIARGS['foo'] = [1, 2, 3]
    assert cliargs_deferred_get('foo', 7, shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo', 7, shallowcopy=False)() == [1, 2, 3]


# Generated at 2022-06-22 19:42:28.743557
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'connection': 'smart',
                'module_path': '/path/to/modules/', 'forks': 10,
                'become': True, 'diff': True, 'check': True,
                'private_key_file': '/path/to/some/key',
                'verbosity': 4}

    # check shallow copies
    assert cliargs_deferred_get("module_path", shallowcopy=True)() == cli_args['module_path']
    assert cliargs_deferred_get("verbosity", shallowcopy=True)() == cli_args['verbosity']
    assert cliargs_deferred_get("forks", shallowcopy=True)() == cli_args['forks']

    cli_list = [4, 5]

# Generated at 2022-06-22 19:42:39.241713
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    # Helper function to assert that we've copied the type properly
    def assert_copied_type(obj, expected_type):
        obj_copy = cliargs_deferred_get(None, default=obj, shallowcopy=True)()
        assert isinstance(obj_copy, expected_type)
        assert obj_copy is not obj
    # dict
    obj = dict()
    assert_copied_type(obj, dict)
    # list
    obj = list()
    assert_copied_type(obj, list)
    # tuple
    obj = tuple()
    assert_copied_type(obj, tuple)
    # set
    obj = set()
    assert_copied_type(obj, set)
    # frozenset
    obj = frozenset()
    assert assert_copied_

# Generated at 2022-06-22 19:42:49.775735
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(foo='bar'))
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('baz') is None
    assert cliargs_deferred_get('baz', 'baz') == 'baz'
    assert cliargs_deferred_get('foo', 'baz') == 'bar'
    _init_global_context(dict(foo=dict(bar='baz')))
    assert cliargs_deferred_get('foo')['bar'] == 'baz'
    assert cliargs_deferred_get('foo', default={'bar': 'baz'})['bar'] == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)['bar'] == 'baz'


# Generated at 2022-06-22 19:42:58.739868
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_arg_value = {'a':'b', 'c':'d', 'e': [1, 2, 3]}
    _init_global_context(test_arg_value)
    assert cliargs_deferred_get('a')(), CLIARGS['a']
    assert cliargs_deferred_get('a', 'b')(), CLIARGS['a']
    assert cliargs_deferred_get('b', 'b')(), 'b'
    assert cliargs_deferred_get('d', 'd')(), 'd'
    assert cliargs_deferred_get('e', shallowcopy=True)(), CLIARGS['e'][:]

# Generated at 2022-06-22 19:43:08.713905
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test normal case
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'

    # Test context
    cliargs = {'foo': 'bar'}
    _init_global_context(cliargs)
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'

    # Test copy
    _init_global_context(cliargs)
    mylist = cliargs_deferred_get('foo', 'baz', shallowcopy=True)()
    assert mylist == 'bar'
    mylist += 'z'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert mylist == 'barz'

# Generated at 2022-06-22 19:43:10.504596
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'
    value = cliargs_deferred_get('foo')()
    assert value == 'bar'



# Generated at 2022-06-22 19:43:20.034633
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    # Verify that CLIARGS is replaced
    global CLIARGS
    old_cliargs = CLIARGS
    assert old_cliargs is not None
    assert type(old_cliargs) is not GlobalCLIArgs

    # Verify that getter can get the default and that it returns a copy
    getter_default = cliargs_deferred_get('test', default='test_value')
    assert getter_default() == 'test_value'
    assert getter_default() is not 'test_value'

    # Verify that getter can work after CLIARGS has been replaced
    CLIARGS = GlobalCLIArgs.from_options({'test': 'test_value'})
    assert old_cliargs is not CLIARGS
    assert type(CLIARGS) is GlobalCLIArgs
    getter_value

# Generated at 2022-06-22 19:43:29.965899
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 1, 'bar': [1, 2, 3], 'baz': {'a': 1, 'b': 2}}
    _init_global_context(cli_args)
    args_get_default = cliargs_deferred_get('does_not_exist')
    assert args_get_default() is None

    args_get_foo = cliargs_deferred_get('foo')
    assert args_get_foo() == 1

    cli_args['foo'] = 2
    assert args_get_foo() == 2

    # Shallow copy test (defaults to True)
    args_get_bar = cliargs_deferred_get('bar')
    assert args_get_bar() == [1, 2, 3]
    cli_args['bar'].append(4)

# Generated at 2022-06-22 19:43:38.198172
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({'foo': [1, 2, 3], 'bar': "baz"})
    assert cliargs_deferred_get('foo', default=None, shallowcopy=False)() == [1, 2, 3]
    assert cliargs_deferred_get('bar', shallowcopy=False)() == "baz"
    assert cliargs_deferred_get('bar', default=None, shallowcopy=False)() == "baz"
    assert cliargs_deferred_get('baz', default=None, shallowcopy=False)() is None
    assert cliargs_deferred_get('baz', None, shallowcopy=False)() is None

    assert cliargs_deferred_get('foo', default=None, shallowcopy=True)

# Generated at 2022-06-22 19:43:41.554756
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})

    assert cliargs_deferred_get('foo')().pop('bar') == 'baz'
    # We return a new copy so we don't mutate the CLIARGS
    assert CLIARGS._options['foo']['bar'] == 'baz'

# Generated at 2022-06-22 19:43:48.002716
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # this is outside of the function so that the replacement doesn't get lost when we enter
    # the function.  Note that the function is not called in the outside of this function
    # so that calling this function doesn't break the replacement
    global CLIARGS
    orig_cliargs = CLIARGS

# Generated at 2022-06-22 19:43:56.639117
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test default
    assert cliargs_deferred_get('test')(), None

    # Test with a value
    CLIARGS['test'] = 'test'
    assert cliargs_deferred_get('test')(), 'test'

    # Test with a value + shallow copy
    CLIARGS['test'] = 'test'
    assert cliargs_deferred_get('test', shallowcopy=True)(), 'test'

    # Test with a value + deep copy
    CLIARGS['test'] = 'test'
    assert cliargs_deferred_get('test', shallowcopy=False)(), 'test'

    # Test with a sequence + deep copy
    CLIARGS['test'] = ['test']
    test = cliargs_deferred_get('test', shallowcopy=False)()

# Generated at 2022-06-22 19:44:06.837942
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('fop', 'baz')() == 'baz'
    assert cliargs_deferred_get('fop', ['baz'])() == ['baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', ['baz'], shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('fop', ['baz'], shallowcopy=True)() == ['baz']

# Generated at 2022-06-22 19:44:16.959493
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns a closure over ``CliArgs.get`` that uses the correct value when it is called

    Need to use an explicit closure because ``mock.patch.object`` doesn't work with
    non-singleton ``CLIARGS``
    """
    global CLIARGS
    CLIARGS = CLIArgs({'a': 123, 'b': 456})
    def_a = cliargs_deferred_get('a')
    def_b = cliargs_deferred_get('b')
    assert def_a() == 123
    assert def_b() == 456
    CLIARGS = CLIArgs({'a': 111, 'b': 222})
    assert def_a() == 111
    assert def_b() == 222



# Generated at 2022-06-22 19:44:27.351367
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def inner(key, default=None, shallowcopy=False):
        value = CLIARGS.get(key, default=default)
        if not shallowcopy:
            return value
        elif is_sequence(value):
            return value[:]
        elif isinstance(value, (Mapping, Set)):
            return value.copy()
        return value

    # TODO: this test is incomplete.
    # Create a mock version of CliArgs to test that the closure works properly
    class mock_CliArgs(CLIArgs):
        def __init__(self, cli_args):
            CLIArgs.__init__(self, cli_args)

        def get(self, key, default=None):
            if key == 'foo':
                return 'bar'


# Generated at 2022-06-22 19:44:38.766690
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.context import cliargs_deferred_get

    @pytest.fixture
    def cliargs(monkeypatch):
        cliargs = {}
        monkeypatch.setattr('ansible.context.CLIARGS', cliargs)
        return cliargs

    @pytest.fixture
    def cliargs_default(cliargs):
        cliargs['default'] = 'foo'
        return cliargs

    @pytest.fixture
    def cliargs_default_shallowcopy(cliargs):
        cliargs['default'] = ['foo']
        return cliargs


# Generated at 2022-06-22 19:44:48.281409
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLI_ARGS = {'foo': 'bar', 'baz': [1, 2, 3], 'bam': {'one': 1, 'two': 2}}
    CLIARGS = CLIArgs(CLI_ARGS)
    for key, cli_args_value in CLI_ARGS.items():
        assert cliargs_deferred_get(key)(), cli_args_value
    assert cliargs_deferred_get('fuzz', 'default')(), 'default'
    assert cliargs_deferred_get('baz', shallowcopy=True)(), CLI_ARGS['baz']
    assert cliargs_deferred_get('bam', shallowcopy=True)(), CLI_ARGS['bam']

# Generated at 2022-06-22 19:44:53.861525
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    foo_deferred_get = cliargs_deferred_get('foo')
    CLIARGS['foo'] = 5
    assert foo_deferred_get() == 5
    CLIARGS['foo'] = [1, 2, 3]
    assert foo_deferred_get() == [1, 2, 3]
    assert foo_deferred_get(shallowcopy=True) == [1, 2, 3]
    CLIARGS['foo'] = {'bar': 'baz'}
    assert foo_deferred_get() == {'bar': 'baz'}
    assert foo_deferred_get(shallowcopy=True) == {'bar': 'baz'}

# Generated at 2022-06-22 19:44:55.887629
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the deferred get function.

    This test needs some answers...
    """
    pass

# Generated at 2022-06-22 19:45:06.394303
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get

    Ensures that the function returns the default value and does not copy it if
    cliargs is not set.

    Also tests that it returns the value as is (i.e. not shallowcopied) if
    shallowcopy is False.
    """
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import UserDict
    from ansible.module_utils.common.collections import is_sequence

    class DummyCliArgs(UserDict):
        def __init__(self, *args, **kwargs):
            super(DummyCliArgs, self).__init__(*args, **kwargs)
            self.original_data_dict = self.data


# Generated at 2022-06-22 19:45:15.377899
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    input_value = {'one': 1, 'two': 2}
    _init_global_context(input_value)
    func = cliargs_deferred_get('one')
    assert func() == 1
    func = cliargs_deferred_get('two', shallowcopy=True)
    # shallow copy
    assert func() == 2
    input_value['two'] = -2
    # shallow copy
    assert func() == 2
    func = cliargs_deferred_get('three', default='three')
    assert func() == 'three'



# Generated at 2022-06-22 19:45:25.185996
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo':'bar', 'nested': {'bar': 1, 'foo': 2}})
    assert cliargs_deferred_get('notkey')() is None
    assert cliargs_deferred_get('notkey', default=1)() == 1
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('notkey', default=1)() == 1
    assert cliargs_deferred_get('nested')() == {'bar': 1, 'foo': 2}
    assert cliargs_deferred_get('nested', shallowcopy=True)() == {'bar': 1, 'foo': 2}
    assert cliargs_deferred_get

# Generated at 2022-06-22 19:45:36.743500
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo') == None
    assert cliargs_deferred_get('foo', default='bar') == 'bar'
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo') == 'bar'

    # test shallow copies
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo', shallowcopy=True) == [1, 2, 3]
    CLIARGS = CLIArgs({'foo': {'a': 1}})
    assert cliargs_deferred_get('foo', shallowcopy=True) == {'a': 1}

# Generated at 2022-06-22 19:45:46.788256
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-22 19:45:56.698865
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get

    * Tests that the default value is returned when the key is not defined
    * Tests that the value is returned when the key is defined
    * Test that the value is returned when the key is defined and the default is not used
    * Test that the default value is returned when the key is defined to None
    """
    class FakeOptions(dict):
        def __init__(self, options):
            self.update(options)
        def __getattr__(self, key):
            return self[key]

    options = FakeOptions({'other': 'value'})
    cli_args = FakeOptions({'other': 'value'})
    # Test the default value is returned when the key is not defined

# Generated at 2022-06-22 19:46:08.693516
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    foo = {'bar': 1}
    baz = [1, 2, 3]
    foo_copy = foo.copy()
    baz_copy = baz[:]

    CLIARGS.update({'foo': foo, 'baz': baz})

    assert cliargs_deferred_get('foo') is foo
    assert cliargs_deferred_get('baz') is baz
    assert cliargs_deferred_get('foo', shallowcopy=True) == foo_copy
    assert cliargs_deferred_get('baz', shallowcopy=True) == baz_copy
    assert cliargs_deferred_get('qux', default=foo) is foo

# Generated at 2022-06-22 19:46:15.412197
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Dummy(object):
        key = 'key'
        default = 'default'
    dummy = Dummy()
    cli_args = {dummy.key: 'cliarg_value'}
    cli_args_copy = cli_args.copy()
    key = cliargs_deferred_get(dummy.key, dummy.default)
    _init_global_context(cli_args)
    assert key() == 'cliarg_value'
    _init_global_context({})
    assert key() == 'default'

    # test that we don't modify the CLIARGS
    assert CLIARGS == cli_args_copy

    # test that even if we are modifying the CLIARGS outside of
    # cliargs_deferred_get that it doesn't modify what we are fetching

# Generated at 2022-06-22 19:46:24.124760
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['some_option'] = {'complex':'value'}
    val = cliargs_deferred_get('some_option', shallowcopy=False)()
    assert val == {'complex': 'value'}
    val = cliargs_deferred_get('some_option', shallowcopy=True)()
    assert val == {'complex': 'value'}
    assert val is not CLIARGS['some_option']
    val = cliargs_deferred_get('some_option', default={'other':'value'}, shallowcopy=False)()
    assert val == {'complex': 'value'}
    val = cliargs_deferred_get('some_option', default={'other':'value'}, shallowcopy=True)()
    assert val == {'complex': 'value'}

# Generated at 2022-06-22 19:46:33.827732
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def inner():
        # assert that the inner closure has been called (and thus CLIARGS has been created)
        assert CLIARGS is not None
        return cliargs_deferred_get('foo')(), cliargs_deferred_get('foo', default='baz')(), \
            cliargs_deferred_get('list', default=[1, 2, 3])(), cliargs_deferred_get('list', default=[1, 2, 3], shallowcopy=True)(), \
            cliargs_deferred_get('set', default={'a', 'b'})()

    # Note: we're not directly testing against a global variable so we need to assert against the
    # return from the function that references it.
    global CLIARGS
    CLIARGS = None

# Generated at 2022-06-22 19:46:37.974270
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = GlobalCLIArgs({})
    assert callable(cliargs_deferred_get('foo'))
    CLIARGS.set_options({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'


# Generated at 2022-06-22 19:46:48.521038
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CliArgs(object):
        def __getitem__(self, key):
            # note: dict always returns a shallow copy
            return dict.__getitem__(CLIARGS, key)

    def test(shallowcopy, expected_return):
        CLIARGS.clear()
        get = cliargs_deferred_get('something', default=list((1,2,3)), shallowcopy=shallowcopy)
        returned = get()
        assert returned == expected_return
        assert CLIARGS['something'] == list((1,2,3))

    test(False, [1,2,3])
    test(True, [1,2,3])
    del CLIARGS
    CLIARGS = CliArgs()
    test(False, [1,2,3])

# Generated at 2022-06-22 19:46:57.995424
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=missing-docstring
    def _test():
        assert cliargs_deferred_get('no_key')(), None
        assert cliargs_deferred_get('no_key', default='foo')(), 'foo'
        CLIARGS.update(dict(foo='bar'))
        assert cliargs_deferred_get('foo')(), 'bar'
        CLIARGS.update(dict(foo=['bar']))
        assert cliargs_deferred_get('foo', copy=True)(), ['bar']
        CLIARGS.update(dict(foo=('bar',)))
        assert cliargs_deferred_get('foo', copy=True)(), ('bar',)
        CLIARGS.update(dict(foo={'bar': 'baz'}))
        assert cliargs

# Generated at 2022-06-22 19:47:00.728421
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for cliargs_deferred_get

    cliargs_deferred_get does not actually have a unit test associated with it.
    Instead, this test verifies that the method works as expected in FieldAttribute.test_default_function_as_dict
    """
    assert True

# Generated at 2022-06-22 19:47:12.338797
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the closure around cli_args.get"""
    CLIARGS['test'] = 'test'
    assert cliargs_deferred_get('test')() == 'test'
    assert cliargs_deferred_get('test', default='default')() == 'test'
    assert cliargs_deferred_get('test', shallowcopy=True)() == 'test'
    assert cliargs_deferred_get('test', default='default', shallowcopy=True)() == 'test'
    assert cliargs_deferred_get('not-test')() is None
    assert cliargs_deferred_get('not-test', default='default')() == 'default'
    assert cliargs_deferred_get('not-test', shallowcopy=True)() is None

# Generated at 2022-06-22 19:47:17.396178
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('')() is None
    assert cliargs_deferred_get('default')() == 'default'
    assert cliargs_deferred_get('', 'default')() == 'default'
    assert cliargs_deferred_get('default', 'default2')() == 'default'
    assert cliargs_deferred_get('default', shallowcopy='default')() == 'default'

# Generated at 2022-06-22 19:47:28.342793
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'a': 'b', 'c': 2})
    assert cliargs_deferred_get('a')() == 'b'
    assert cliargs_deferred_get('b')() is None
    assert cliargs_deferred_get('b', default='c')() == 'c'
    l1 = cliargs_deferred_get('a', shallowcopy=True)()
    l1[0] = 'x'
    assert cliargs_deferred_get('a')() == 'x'
    l2 = cliargs_deferred_get('a', shallowcopy=True)()
    assert l2 == 'x'
    l2 = 'y'
    assert cliargs_deferred_get('a')() == 'x'

# Generated at 2022-06-22 19:47:37.741231
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def inner(key, default, unset=False, shallowcopy=False):
        # If a default is provided, the result should just be the default
        if unset:
            default = default()

        assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == default

    # Test that the function returns the default value when the key is not found in
    # CLIARGS.
    inner('test1', None)
    inner('test2', 'foo')
    inner('test3', dict(foo='bar'))
    inner('test3', dict(foo='bar'), shallowcopy=True)
    inner('test4', ['foo', 'bar'])
    inner('test4', ['foo', 'bar'], shallowcopy=True)

    # TODO: How to test that a copy of the value is

# Generated at 2022-06-22 19:47:43.133131
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make the getter for a particular key
    getter = cliargs_deferred_get('foo', 'bar')
    assert getter() == 'bar'

    # Set the value of foo in CLIARGS and make sure the getter picks up the new value
    CLIARGS['foo'] = 'baz'
    assert getter() == 'baz'

    # Set the value of foo to a sequence and try to shallow-copy it
    CLIARGS['foo'] = [1, 2, 3]
    value = getter(shallowcopy=True)
    assert value == [1, 2, 3]
    value[0] = 'foo'
    assert CLIARGS['foo'][0] == 'foo'

    # Set the value of foo to a mapping and try to shallow-copy it

# Generated at 2022-06-22 19:47:53.647604
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function ``cliargs_deferred_get``

    :returns: Nothing
    :rtype: None
    """
    from ansible.utils.context_objects import GlobalCLIArgs

    cli_args = {
        'vault_password_file': '/dev/null',
        'become': True,
        'become_user': 'abc',
        'become_method': 'sudo',
        'ask_become_pass': True,
        'ask_pass': True,
        'connect_timeout': 30,
        'private_key_file': None,
        'remote_user': 'root',
    }
    _init_global_context(GlobalCLIArgs.from_options(cli_args))

    def _assert_deep_eq(_left, _right):
        assert _left == _

# Generated at 2022-06-22 19:48:02.564205
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    test_args = {'foo': 'bar', 'bar': ['wee', 'woo'], 'baz': {'ansible': 'cool'}}
    CLIARGS = CLIArgs(test_args)
    # Test the happy path
    assert cliargs_deferred_get('foo')() == 'bar'
    # Test the default value
    assert cliargs_deferred_get('something', default='bar')() == 'bar'
    # Test sequence shallow copy
    assert cliargs_deferred_get('bar', shallowcopy=True)() == ['wee', 'woo']
    assert isinstance(cliargs_deferred_get('bar', shallowcopy=True)(), list)
    # Test Set and Mapping shallow copy

# Generated at 2022-06-22 19:48:13.334281
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({'v': 2, 'test_value': 'hi', 'test_list': [1,2,3]})
    assert cliargs_deferred_get('v')(), 2
    assert cliargs_deferred_get('test_value')(), 'hi'
    assert cliargs_deferred_get('test_value', shallowcopy=True)(), 'hi'
    assert cliargs_deferred_get('test_list')(), [1,2,3]
    assert cliargs_deferred_get('test_list', shallowcopy=True)(), [1,2,3]
    CLIARGS['test_list'].append(4)

# Generated at 2022-06-22 19:48:18.713874
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(0, default=1)()
    cliargs_deferred_get(0, [])()
    cliargs_deferred_get(0, ('a', 'b', 'c'))()
    cliargs_deferred_get(0, {'a': 1, 'b': 2})()
    cliargs_deferred_get(0, {1, 2, 3})()

# Generated at 2022-06-22 19:48:29.508073
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_cliargs = CLIArgs({'a': 2, 'b': {'c': 3, 'd': 4}})
    get_a = cliargs_deferred_get('a')
    get_e = cliargs_deferred_get('e')
    get_a_shallow = cliargs_deferred_get('a', shallowcopy=True)
    get_b = cliargs_deferred_get('b')
    get_b_shallow = cliargs_deferred_get('b', shallowcopy=True)
    get_b_c = cliargs_deferred_get('c', default={'c': 3}, shallowcopy=True)

    global CLIARGS
    CLIARGS = test_cliargs

    assert get_a() == 2
    assert get_e() is None
    assert get

# Generated at 2022-06-22 19:48:40.596534
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the function cliargs_deferred_get"""
    from ansible.utils.context_objects import CliArgs
    _CLIARGS = CliArgs({'hello': 'World!'})
    default = 'default'
    getter = cliargs_deferred_get('hello', default)
    assert getter() == 'World!'  # test that it correctly gets the value
    _CLIARGS['hello'] = 'Ansible!'
    assert getter() == 'Ansible!'  # test that it correctly gets the new value
    _CLIARGS['hello'] = default  # test that it correctly gets the default
    assert getter() == default

# Generated at 2022-06-22 19:48:50.744436
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the right data"""

    # Test that the default value is returned if the key is not in CLIARGS
    assert cliargs_deferred_get('key')() == None

    # Test that the CLIARGS value is returned if the key is in CLIARGS
    CLIARGS['key'] = 'value'
    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('key', default='default')() == 'value'

    # Test that a shallow copy is returned for a list
    CLIARGS['list'] = ['value']
    assert cliargs_deferred_get('list', shallowcopy=True)() == ['value']
    assert cliargs_deferred_get('list', shallowcopy=True)() is not CLI

# Generated at 2022-06-22 19:49:01.603954
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo')(), "" == {}
    assert cliargs_deferred_get('foo')(), "None" == {}
    assert cliargs_deferred_get('foo', shallowcopy=True)(), "None, shallowcopy" == {}
    CLIARGS = CLIArgs({'foo': []})
    assert cliargs_deferred_get('foo')(), "[]" == []
    assert cliargs_deferred_get('foo', shallowcopy=True)(), "[], shallowcopy" != []
    CLIARGS = CLIArgs({'foo': {}})
    assert cliargs_deferred_get('foo')(), "{}" == {}

# Generated at 2022-06-22 19:49:07.859833
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    f = cliargs_deferred_get('foo')
    # Verify that the default is set
    assert f() is None
    # Set the value
    CLIARGS['foo'] = 42
    # Verify we got the new value
    assert f() == 42
    # Verify we can override the default
    CLIARGS['foo'] = 123
    assert f(default=42) == 123

# Generated at 2022-06-22 19:49:16.410676
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert [1] == cliargs_deferred_get(default=[1])()
    assert [] == cliargs_deferred_get(key='not-a-valid-key-value', default=[1])()
    assert [1] == cliargs_deferred_get(key='not-a-valid-key-value', shallowcopy=True, default=[1])()

    lst = [1]
    lst_copy = cliargs_deferred_get(key='not-a-valid-key-value', default=lst)()
    # copy should be independent of original
    lst.append(2)
    assert [1] == lst_copy

    dct = {'foo': 'bar'}

# Generated at 2022-06-22 19:49:26.965958
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.clear()
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', 'zoo')() == 'bar'
    assert cliargs_deferred_get('foo', 'zoo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', 'zoo', shallowcopy=False)() == 'bar'
    assert cliargs_deferred_get('foo', 'zoo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', 'zoo', shallowcopy=False)() == 'bar'
    assert cliargs_deferred_get('blah', 'zoo', shallowcopy=False)() == 'zoo'

# Generated at 2022-06-22 19:49:34.942869
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    new_cliargs = CLIArgs(dict(a=dict(b=dict(c=1)), d=2))
    CLIARGS = new_cliargs

    inner = cliargs_deferred_get('a')
    assert inner() is new_cliargs['a']
    assert inner() is not new_cliargs['a']
    assert inner() == new_cliargs['a']

    inner = cliargs_deferred_get('d')
    assert inner() is new_cliargs['d']
    assert inner() is not new_cliargs['d']
    assert inner() == new_cliargs['d']

    inner = cliargs_deferred_get('d', shallowcopy=True)
    assert inner() is new_cliargs['d']
    assert inner() is new_cliargs['d']

# Generated at 2022-06-22 19:49:44.914380
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Testing for getting a value for a key that does not exist should work.
    # NOTE: This does not verify whether or not the value actually exists
    # in the CLIARGS object, it only verifies that the function cliargs_deferred_get
    # will return the provided default value if the key does not exist.
    assert cliargs_deferred_get('NOT_EXIST', default=True)() is True
    assert cliargs_deferred_get('NOT_EXIST', default=True)() is not False
    # Testing for getting a value for a key that does exist should work.
    # NOTE: This does not verify whether or not the value actually exists
    # in the CLIARGS object, it only verifies that the function cliargs_deferred_get
    # will return the value associated with the key.
    assert cliargs

# Generated at 2022-06-22 19:49:52.416297
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.cli import CLI
    test_args = ['ansible-playbook', '-i', 'inventory', 'playbook.yml']
    test_parser = CLI.base_parser(constants.defaults, runas_opts=True, async_opts=True)
    (options, args) = test_parser.parse_args(args=test_args)
    _init_global_context(vars(options))
    assert cliargs_deferred_get('inventory') == 'inventory'

# Generated at 2022-06-22 19:49:57.403590
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Verify default
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Verify default is not returned if the key already exists
    CLIARGS._options = {'foo':'baz'}
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'baz'

# Generated at 2022-06-22 19:50:02.928643
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'key1': 'value1'})
    assert cliargs_deferred_get('key1') == 'value1'
    assert cliargs_deferred_get('key2') is None
    assert cliargs_deferred_get('key2', 'default2') == 'default2'
    assert cliargs_deferred_get('key3', shallowcopy=True) is None
    assert cliargs_deferred_get('key3', 'default3', shallowcopy=True) == 'default3'
    assert cliargs_deferred_get('key1', shallowcopy=True) == 'value1'

# Generated at 2022-06-22 19:50:12.220661
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def assert_inner(expected):
        """Check that ``inner`` returns the expected value"""
        assert inner() == expected

    inner = cliargs_deferred_get('missing', 'foo', shallowcopy=False)
    assert_inner('foo')

    CLIARGS['missing'] = 'bar'
    assert_inner('bar')
    CLIARGS['missing'] = 'baz'
    assert_inner('baz')

    # Check the shallow copy option
    def check_shallow_inner(expected):
        """Check that the ``inner`` function is returning expected values"""
        actual = inner()
        assert actual == expected
        # change the original object and verify that it has changed
        expected.append('qux')
        assert actual == expected

    CLIARGS['missing'] = []

# Generated at 2022-06-22 19:50:21.858573
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    g = GlobalCLIArgs({'a': 1, 'b': 2})
    CLIARGS = g
    assert CLIARGS.get('a') == 1
    assert cliargs_deferred_get('a')() == 1

    g.a = 2
    assert CLIARGS.get('a') == 2
    assert cliargs_deferred_get('a')() == 2

    g2 = dict(a=3, b=4)
    CLIARGS = g2
    assert CLIARGS.get('a') == 3
    assert cliargs_deferred_get('a')() == 3

    g2['a'] = 4
    assert CLIARGS.get('a') == 4
    assert cliargs_deferred_get('a')() == 4

# Generated at 2022-06-22 19:50:33.263525
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def construct_cliargs(**kwargs):
        return CLIArgs(kwargs)

    # Test that shallowcopy works
    foo = ['foo', 'bar']
    bar = {'foo': 'bar'}
    baz = set(['foo', 'bar'])
    global CLIARGS
    CLIARGS = construct_cliargs(foo=foo, bar=bar, baz=baz)
    assert cliargs_deferred_get('foo')() == foo
    assert cliargs_deferred_get('foo', shallowcopy=True)() != foo
    assert cliargs_deferred_get('bar')() == bar
    assert cliargs_deferred_get('bar', shallowcopy=True)() != bar
    assert cliargs_deferred_get('baz')() == baz
    assert cliargs_

# Generated at 2022-06-22 19:50:40.371058
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it passes back a closure that returns the right thing
    assert cliargs_deferred_get('whatever', 'default')(), 'default'
    assert cliargs_deferred_get('whatever', default=['default'], shallowcopy=True)(), ['default']
    assert cliargs_deferred_get('whatever', default=['default'], shallowcopy=False)(), ['default']
    assert cliargs_deferred_get('whatever', default={'default'}, shallowcopy=True)(), {'default'}
    assert cliargs_deferred_get('whatever', default={'default'}, shallowcopy=False)(), {'default'}

# Generated at 2022-06-22 19:50:47.589076
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # set up some test data
    _init_global_context(dict(
        verbosity=1,
        debug=dict(a=1, b=2),
        hosts=['foo.example.com', 'bar.example.com'],
        verbose=[1,2,3],
    ))
    # test getting members
    assert cliargs_deferred_get('verbosity') == 1
    assert cliargs_deferred_get('debug') == dict(a=1, b=2)
    assert cliargs_deferred_get('hosts') == ['foo.example.com', 'bar.example.com']
    assert cliargs_deferred_get('nonmembership', default='default') == 'default'
    # test getting shallow copies

# Generated at 2022-06-22 19:50:59.021378
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    assert cliargs_deferred_get('foo')() is None  # default value, empty parameters
    CLIARGS = CLIArgs(foo=True)
    assert cliargs_deferred_get('foo')() is True  # CLIARGS value, empty parameters
    assert cliargs_deferred_get('foo', default=False)() is True  # CLIARGS value, specified default
    assert cliargs_deferred_get('bar', default=True)() is True  # default value, default specified
    assert cliargs_deferred_get('bar', default=False)() is False  # default value, default specified
    assert cliargs_deferred_get('foo', shallowcopy=True)() is True  # CLIARGS value,