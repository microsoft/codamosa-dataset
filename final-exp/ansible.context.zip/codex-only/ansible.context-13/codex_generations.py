

# Generated at 2022-06-22 19:41:07.438459
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    assert cliargs_deferred_get('foo')() is None
    # This also tests that it returns the default
    assert cliargs_deferred_get('foo', default='default')() == 'default'
    CLIARGS.update(foo='bar')
    assert cliargs_deferred_get('foo')().startswith('<ansible.module_utils.common.context_objects.')
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True, default='default')() == 'bar'
    CLIARGS.clear()

# Generated at 2022-06-22 19:41:16.101136
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({'foo': 1, 'bar': [1, 2, 3], 'baz': {'a': 1}})
    assert 1 == cliargs_deferred_get('foo')()
    assert [1, 2, 3] == cliargs_deferred_get('bar')()
    assert {'a': 1} == cliargs_deferred_get('baz')()
    assert 'testing 1 2' == cliargs_deferred_get('missing', 'testing 1 2')()

    # Shallow copy
    cliargs = CLIArgs({'foo': 1, 'bar': [1, 2, 3], 'baz': {'a': 1}})
    assert 1 == cliargs_deferred_get('foo', shallowcopy=True)()
    assert [1, 2, 3] == cli

# Generated at 2022-06-22 19:41:26.625455
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test without the copy functionality
    CLIARGS['foo'] = 'bar'
    closure = cliargs_deferred_get('foo')
    assert closure() == 'bar'
    CLIARGS['foo'] = 42
    assert closure() == 42

    # Test with the copy functionality
    CLIARGS['foo'] = 'bar2'
    closure = cliargs_deferred_get('foo', shallowcopy=True)
    assert closure() == 'bar2'
    bar2 = closure()
    assert bar2 is not 'bar2'
    CLIARGS['foo'] = 42
    assert closure() == 42

    CLIARGS['foo'] = ['bar', 'baz']
    closure = cliargs_deferred_get('foo', shallowcopy=True)
    assert closure() == ['bar', 'baz']

# Generated at 2022-06-22 19:41:37.936349
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MyGlobalCLIArgs(GlobalCLIArgs):
        def __init__(self):
            self._options = {}

        def __setitem__(self, key, value):
            self._options[key] = value

    def test_get(key, default=None, shallowcopy=False):
        return cliargs_deferred_get(key, default, shallowcopy)()

    global CLIARGS
    CLIARGS = MyGlobalCLIArgs()
    assert test_get('a') is None
    CLIARGS['a'] = 1
    assert test_get('a') == 1
    assert test_get('b') is None
    assert test_get('b', 2) == 2

    CLIARGS['a'] = [1, 2, 3]
    assert test_get('a') == [1, 2, 3]


# Generated at 2022-06-22 19:41:44.290857
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MockCliArgs(object):
        def get(self, key, default=None):
            return {
                'a': 1,
                'b': [1],
                'c': {'foo': 'bar'},
                'd': {'foo', 'bar'},
            }.get(key, default)

    cliargs = MockCliArgs()
    global CLIARGS
    original_cliargs = CLIARGS
    CLIARGS = cliargs


# Generated at 2022-06-22 19:41:51.017717
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with a simple setting
    CLIARGS.setdefault('foo', 'bar')
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='foobar')() == 'bar'
    assert cliargs_deferred_get('foo', default='foobar')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True, default='foobar')() == 'bar'

# Generated at 2022-06-22 19:41:58.440028
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for ``cliargs_deferred_get``"""
    # Note: we can't use unittest unit test features as this is called in an
    # ``if __name__ == '__main__':`` block

    # Defer getting an attribute that is not set
    assert CLIARGS.get('foo', None) is None
    assert cliargs_deferred_get('foo')() is None

    # Defer getting an attribute that is set
    CLIARGS['foo'] = 'bar'
    assert CLIARGS.get('foo') == 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Defer getting an attribute that is set with a default
    CLIARGS['foo'] = 'baz'
    assert CLIARGS.get('foo', 'bar') == 'baz'

# Generated at 2022-06-22 19:42:06.742579
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Foo:
        pass
    global CLIARGS
    CLIARGS = CLIArgs(dict(a='a', b=1, c=2, d=[1, 2], e=Foo()))
    # First four should work
    assert cliargs_deferred_get('a')() == 'a'
    assert cliargs_deferred_get('b')() == 1
    assert cliargs_deferred_get('c')() == 2
    assert cliargs_deferred_get('d')() == [1, 2]
    assert cliargs_deferred_get('d', shallowcopy=True)() == [1, 2]
    assert cliargs_deferred_get('a', default='b')() == 'a'
    assert cliargs_deferred_get('b', default='b')() == 1

# Generated at 2022-06-22 19:42:16.924508
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    _init_global_context({'key': 'value'})
    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('fake')() is None
    assert cliargs_deferred_get('fake', '')() == ''
    assert cliargs_deferred_get('fake', default='other')() == 'other'
    assert cliargs_deferred_get('key', shallowcopy=True)() == 'value'
    assert cliargs_deferred_get('key', deepcopy=False)() == 'value'
    assert cliargs_deferred_get('key', shallowcopy=True)() == 'value'

# Generated at 2022-06-22 19:42:25.135071
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    orig_CLIARGS = CLIARGS

# Generated at 2022-06-22 19:42:34.080159
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    import pytest
    # test function is a function with no arguments that returns the
    # value of the key to get
    @pytest.fixture
    def test_function(mocker):
        return mocker.Mock(return_value='value')

    def test(test_function, key, default, shallowcopy, cli_args, expected_value):
        mocker = pytest.importorskip('mock')
        # Make sure we start with a clean slate
        CLIARGS = CLIArgs({})
        test_function = test_function()
        test_function.reset_mock()
        # Setup context
        _init_global_context(cli_args)
        # Get value
        result = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)()

# Generated at 2022-06-22 19:42:39.995633
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Case 1: CLIARGS is the singleton version
    CLIARGS._singleton = 'a singleton'
    assert cliargs_deferred_get('_singleton')() == 'a singleton'

    # Case 2: CLIARGS is replaced with a new object
    CLIARGS = CLIArgs({'a': '1'})
    assert cliargs_deferred_get('a')() == '1'

# Generated at 2022-06-22 19:42:50.511207
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access

    def test_deferred_get(key, value=None, shallowcopy=False, expect=None):
        if value is None:
            expect = key
            value = key
        # Validate that the get actually gets what we expect
        assert cliargs_deferred_get(key, default=value, shallowcopy=False)() == expect
        retval = cliargs_deferred_get(key, default=value, shallowcopy=shallowcopy)()

        if shallowcopy:
            # If we've shallow copied, then the original should not have changed
            assert CLIARGS._cli_args[key] == expect
            # If we've shallow copied, then the returned value should be different
            assert retval != expect

        # Validate that the returned value is what we expect
        # This is dupl

# Generated at 2022-06-22 19:43:00.415906
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'l': ['l1', 'l2', 'l3']}
    _init_global_context(cli_args)
    l = cliargs_deferred_get('l')()
    l.append('l4')
    assert CLIARGS['l'] == ['l1', 'l2', 'l3', 'l4']
    l = cliargs_deferred_get('l', default=[])()
    l.append('l4')
    assert CLIARGS['l'] == ['l1', 'l2', 'l3', 'l4']
    l = cliargs_deferred_get('l', shallowcopy=True)()
    assert isinstance(l, list)
    l.append('l5')

# Generated at 2022-06-22 19:43:10.581760
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-argument
    def check(cliargs, key, default=None, shallowcopy=False):
        # pylint: disable=missing-docstring,protected-access
        cliargs._value.clear()
        expected = cliargs.get(key, default=default)
        def_get = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)
        assert expected == def_get()
        cliargs._value[key] = expected
        assert expected == def_get()
        cliargs._value[key] = None
        assert not def_get()
        cliargs._value.clear()
        assert not def_get()
    import pytest

    check(CLIARGS, 'verbosity')

# Generated at 2022-06-22 19:43:20.034417
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS

    # Test when cli_args have not been parsed
    CLIARGS.clear()
    getter = cliargs_deferred_get('foo')
    assert getter() is None

    # Test with CLIARGS set to something
    CLIARGS['bar'] = True
    getter = cliargs_deferred_get('foo', default='baz')
    assert getter() == 'baz'

    # Test that shallow copies work
    CLIARGS['bar'] = ['foo']
    getter = cliargs_deferred_get('bar')
    assert getter() == ['foo']
    getter = cliargs_deferred_get('bar', shallowcopy=True)
    assert getter() == ['foo']
    CLIAR

# Generated at 2022-06-22 19:43:28.446234
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    global CLIARGS

    CLIARGS = GlobalCLIArgs.from_options({'verbosity': 12})
    assert cliargs_deferred_get('verbosity', 8)() == 12
    assert cliargs_deferred_get('comment', 8)() == 8

    CLIARGS = GlobalCLIArgs.from_options({'forks': 12})
    assert cliargs_deferred_get('forks', 8)() == 12
    assert cliargs_deferred_get('forks', 8)() == 12
    assert cliargs_deferred_get('verbosity', 8)() == 8

# Generated at 2022-06-22 19:43:34.146309
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    obj1 = [1, 2, 3]
    obj2 = [4, 5, 6]
    CLIARGS['test_list'] = obj1
    testfunc = cliargs_deferred_get('test_list', default=obj2)
    assert obj1 is testfunc()
    ret = obj2[:]
    CLIARGS['test_list'] = None
    assert obj2 is not testfunc()
    assert ret == testfunc()
    assert obj2 is not testfunc()

# Generated at 2022-06-22 19:43:43.859444
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test function when cliargs are set
    class FakeArgs(object):
        """Fake dictionary that returns ``None`` for unknown keys"""
        def __getitem__(self, key):
            return None

    cli_args = FakeArgs()
    _init_global_context(cli_args)

    assert cliargs_deferred_get('blah')() is None

    cli_args.blah = 'gah'
    assert cliargs_deferred_get('blah')() == 'gah'

    assert cliargs_deferred_get('blah', default='foo')() == 'gah'
    assert cliargs_deferred_get('bleah', default='foo')() == 'foo'

    def side_effect():
        return 'inside'


# Generated at 2022-06-22 19:43:54.846306
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the function with a default value
    no_default_dfn = cliargs_deferred_get('no_key_present', default='default_value')
    assert no_default_dfn() == 'default_value'

    # Test the function with a default value, with a key present in cliargs
    _init_global_context({'key': 'value'})
    with_default_dfn = cliargs_deferred_get('key', default='default_value')
    assert with_default_dfn() == 'value'

    # Test the function with no default value, with the key present in cliargs
    no_default_with_key_dfn = cliargs_deferred_get('key')
    assert no_default_with_key_dfn() == 'value'

    # Test the function with no

# Generated at 2022-06-22 19:44:04.393747
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    got = cliargs_deferred_get('foo', shallowcopy=True)()
    assert got == [1, 2, 3]
    assert got is not cliargs

# Generated at 2022-06-22 19:44:13.887734
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit Test for cliargs_deferred_get()"""
    cliargs_dict = {'foo': ['bar', 'baz']}
    _init_global_context(cliargs_dict)
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    cliargs_dict.update({'foo': 'baz'})
    assert cliargs_deferred_get('foo')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'baz'

# Generated at 2022-06-22 19:44:15.272467
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pragma: no cover
    # TODO: to be implemented.
    pass

# Generated at 2022-06-22 19:44:24.792856
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for ``cliargs_deferred_get`` function"""
    import pytest

    def _test(cli_args, test_key, expected_value, shallowcopy=False):
        """Test ``cliargs_deferred_get`` with a particular test scenario"""
        _init_global_context(cli_args)
        getter = cliargs_deferred_get(test_key, shallowcopy=shallowcopy)
        assert getter() == expected_value

    def _test_not_set(test_key):
        """Test ``cliargs_deferred_get`` with key not set"""
        _init_global_context(None)
        getter = cliargs_deferred_get(test_key, default='foo')
        assert getter() == 'foo'


# Generated at 2022-06-22 19:44:32.537792
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence

    import contextlib
    from io import StringIO

    @contextlib.contextmanager
    def capture_sys_output():
        capture_out, capture_err = StringIO(), StringIO()
        current_out, current_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = capture_out, capture_err
            yield capture_out, capture_err
        finally:
            sys.stdout, sys.stderr = current_out, current_err

    with capture_sys_output() as (stdout, stderr):
        f = cliargs_deferred_get('check')
        f()

    # Bare minimum test to make sure the deferred_get doesn't blow up
    assert stdout

# Generated at 2022-06-22 19:44:40.737288
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for ``cliargs_deferred_get``"""
    # Test simple value
    def _test_simple():
        expected_value = "my_value"
        were_defaults_applied = False

        # test when key is set -- both shallowcopy False and True
        cliargs = CLIArgs({"key": expected_value})
        f = cliargs_deferred_get("key")
        assert f() == expected_value
        # Validate that we didn't shallow copy it by changing the value
        cliargs["key"] = "new value"
        assert f() == "new value"

        # test when key is not set -- both shallowcopy False and True
        expected_default = "my_default"
        f = cliargs_deferred_get("key", default=expected_default)

# Generated at 2022-06-22 19:44:50.921465
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping

    assert cliargs_deferred_get.__name__ == 'cliargs_deferred_get'
    assert cliargs_deferred_get.__doc__ is not None
    assert cliargs_deferred_get.__module__ == __name__

    class FakeCLIArgs(object):

        _cli_args = {
            'defaultval': 'default',
            'shallowcopy': 'shallowcopy',
            'mapping': {'a': 1, 'b': 2},
            'mutablemapping': MutableMapping(a=1, b=2),
        }

        def get(self, key, default=None):
            return self._cli_args.get(key, default)

    # Test the

# Generated at 2022-06-22 19:45:02.144143
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This function is not directly bound to ``CliArgs`` so that it works with
    # ``CLIARGS`` being replaced
    def cliargs_deferred_get(key, default=None, shallowcopy=False):
        def inner():
            value = CLIARGS.get(key, default=default)
            if not shallowcopy:
                return value
            elif is_sequence(value):
                return value[:]
            elif isinstance(value, (Mapping, Set)):
                return value.copy()
            return value
        return inner

    cls = CLIArgs
    cls.from_options(dict(a=1, b=dict(c=2)))._init_global_context(dict(a=3, b=dict(c=4)))

# Generated at 2022-06-22 19:45:10.405087
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.replace({'foo': 'bar', 'baz': [1, 2], 'buzz': {'x': 1, 'y': 2}})
    foo_value = cliargs_deferred_get('foo')()
    assert foo_value == CLIARGS.get('foo')
    baz_value = cliargs_deferred_get('baz')()
    assert baz_value == CLIARGS.get('baz')
    buzz_value = cliargs_deferred_get('buzz')()
    assert buzz_value == CLIARGS.get('buzz')
    foo_value = cliargs_deferred_get('foo', shallowcopy=True)()
    assert foo_value == CLIARGS.get('foo')

# Generated at 2022-06-22 19:45:17.782558
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test cliargs_deferred_get"""
    # pylint: disable=too-few-public-methods
    class CliArgs(object):
        """Wrapper around CLIARGS to be passed to _init_global_context"""
        def __init__(self):
            self.args = {}
    cli_args = CliArgs()
    cli_args.args = {'foo': []}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo', shallowcopy=True) is not cli_args.args['foo']
    assert cliargs_deferred_get('foo', shallowcopy=True) == cli_args.args['foo']
    assert cliargs_deferred_get('foo') is cli_args.args['foo']
   

# Generated at 2022-06-22 19:45:26.509104
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'bob': {'hope': 'has', 'a': 'name'}, 'abc': {1, 2, 3}, 'xyz': None})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('x')() is None
    assert cliargs_deferred_get('x', default='not')() == 'not'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('bob', shallowcopy=True)()

# Generated at 2022-06-22 19:45:37.351131
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that deferred get works with a particular value"""
    # pylint: disable=unused-variable,unused-argument

    def test_context(default):
        """Test that getter function works with default value given and initial context is empty"""
        expected_key = 'foo'
        expected_value = 'bar'
        my_context = CLIArgs({})
        getter = cliargs_deferred_get(expected_key, default=default)
        my_context[expected_key] = expected_value
        assert getter() == expected_value
        del my_context[expected_key]
        assert getter() == default

    # Expecting a string
    test_context('baz')
    # Expecting a list
    test_context([])
    # Expecting a list with a particular value

# Generated at 2022-06-22 19:45:46.802239
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set

    def test_list():
        cliargs = {}
        _init_global_context(cliargs)
        fn = cliargs_deferred_get('test_list', default=[])
        assert fn() == []
        cliargs = {'test_list': ['foo', 'bar']}
        _init_global_context(cliargs)
        assert fn() == cliargs['test_list']

    def test_list_shallowcopy():
        cliargs = {}
        _init_global_context(cliargs)
        fn = cliargs_deferred_get('test_list', default=[], shallowcopy=True)
        assert fn() == []

# Generated at 2022-06-22 19:45:56.697141
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=protected-access
    # context is not public API

    CLIARGS._context = CLIArgs({'key1': 'a', 'key2': {'deep': 'b'}, 'key3': [1, 2, 3]})

    assert cliargs_deferred_get('key1')() == 'a'
    assert cliargs_deferred_get('key2')() == {'deep': 'b'}
    assert cliargs_deferred_get('key3')() == [1, 2, 3]

    assert cliargs_deferred_get('key1', default='default')() == 'a'
    assert cliargs_deferred_get('key2', default='default')() == {'deep': 'b'}


# Generated at 2022-06-22 19:46:02.623222
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Test the simple case
    CLIARGS = CLIArgs({'nope': 'yep'})
    assert cliargs_deferred_get('nope') == 'yep'
    # Test the default case
    assert cliargs_deferred_get('nonexistent', default='yep') == 'yep'
    # Test the shallowcopy case
    CLIARGS = CLIArgs({'nope': ('yep', 'nope')})
    assert cliargs_deferred_get('nope', shallowcopy=True) == ('yep', 'nope')

# Generated at 2022-06-22 19:46:11.210958
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {1: 2}, 'd': {1, 2}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('a', default=0)() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('b', default=[])() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {1: 2}
    assert cliargs_deferred_get('d')() == {1, 2}
    assert cliargs_deferred_get('e')() is None
    assert cliargs_

# Generated at 2022-06-22 19:46:21.814518
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    import copy

# Generated at 2022-06-22 19:46:33.024693
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({
        'c': 1,
        'a': {1: 2},
        'b': [1, 2]
    })
    assert cliargs_deferred_get('c')() == 1
    assert cliargs_deferred_get('a')() == {1: 2}
    assert cliargs_deferred_get('b')() == [1, 2]

    assert cliargs_deferred_get('c', shallowcopy=True)() == 1
    assert cliargs_deferred_get('a', shallowcopy=True)() == {1: 2}
    assert cliargs_deferred_get('b', shallowcopy=True)() == [1, 2]


# Generated at 2022-06-22 19:46:40.572432
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_test = CLIArgs({'a': 'b'})
    a = cliargs_test['a']
    del cliargs_test['a']

    def inner():
        return cliargs_test['b']

    assert a == 'b'
    assert cliargs_test.get('a', 'b') == 'b'
    assert cliargs_deferred_get('a')('b') == 'b'
    assert cliargs_deferred_get('a', 'b')('b') == 'b'
    assert cliargs_deferred_get('b', 'a')('b') == 'a'
    assert cliargs_deferred_get('b', default='a')('b') == 'a'

# Generated at 2022-06-22 19:46:51.200458
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with no value set
    test_dict = {}
    get = cliargs_deferred_get('foo')
    assert get() == None

    # Test with a standard value set
    test_dict = {'foo': 'bar'}
    get = cliargs_deferred_get('foo')
    assert get() == 'bar'

    # Test with a default set
    test_dict = {}
    get = cliargs_deferred_get('foo', 'baz')
    assert get() == 'baz'

    # Test with a shallow_copy set
    test_dict = {'foo': 'bar'}
    get = cliargs_deferred_get('foo', shallowcopy=True)
    assert get() == 'bar'
    test_dict['foo'] = 'baz'

# Generated at 2022-06-22 19:46:59.632416
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Check that deferred_get works as expected"""
    global CLIARGS

    # check that it defaults to the specified default value if the value has not been specified
    cliargs = {'a': 1}  # We don't populate CLIARGS directly so that the function works with the singleton
    _init_global_context(cliargs)
    get_b = cliargs_deferred_get('b', default=2)
    assert get_b() == 2

    # check that it defaults to the specified default value if the value has not been specified with shallowcopy=True
    get_b = cliargs_deferred_get('b', default=[2], shallowcopy=True)
    assert get_b() == [2]

    # check that we can retrieve a value
    get_a = cliargs_deferred_get('a')
   

# Generated at 2022-06-22 19:47:04.735533
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CLIArgsSub(CLIArgs):
        def __init__(self, *args, **kwargs):
            super(CLIArgsSub, self).__init__(*args, **kwargs)
            self.fields = {}

    # mock out CLIARGS so it can be used in the test
    global CLIARGS
    CLIARGS = CLIArgsSub(dict(foo=[1, 2, 3]))
    assert cliargs_deferred_get('foo')(), [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)(), [1, 2, 3]

    CLIARGS = CLIArgsSub(dict(foo={'bar': 1, 'baz': 2}))

# Generated at 2022-06-22 19:47:14.202735
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''
    >>> l = [1]
    >>> sl = cliargs_deferred_get('some_key', l)()
    >>> assert sl is l
    >>> sl[0] = 2
    >>> assert sl is l
    >>> assert sl[0] == 2
    >>> assert l[0] == 2

    Using a shallowcopy results in a different list
    >>> l = [1]
    >>> sl = cliargs_deferred_get('some_key', l, shallowcopy=True)()
    >>> assert sl is not l
    >>> assert sl[0] == 1
    >>> sl[0] = 2
    >>> assert sl[0] == 2
    >>> assert l[0] == 1
    '''
    pass

# Generated at 2022-06-22 19:47:24.458652
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-22 19:47:34.534872
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test': [1,2,3]})
    assert cliargs_deferred_get('test')() == [1,2,3]
    assert cliargs_deferred_get('test', shallowcopy=True)() == [1,2,3]
    CLIARGS = CLIArgs({'test': (1,2,3)})
    assert cliargs_deferred_get('test')() == (1,2,3)
    assert cliargs_deferred_get('test', shallowcopy=True)() == (1,2,3)
    CLIARGS = CLIArgs({'test': {'a': 'b'}})
    assert cliargs_deferred_get('test')() == {'a': 'b'}
    assert cliargs_

# Generated at 2022-06-22 19:47:43.502516
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cliargs = CLIArgs({'foo': 'bar', 2: 5, 'baz': [5, 6]})
    CLIARGS = cliargs

    cases = [
        ('foo', 'bar'),
        (2, 5),
        ('baz', [5, 6]),
        ('something else', None),
        ('something else', 'default value'),
        (3, None),
        (3, 'default value'),
    ]
    for (position, value) in cases:
        assert cliargs_deferred_get(position, value)() == value
        assert cliargs_deferred_get(position, value, shallowcopy=True)() == value

    CLIARGS = GlobalCLIArgs.from_options(cliargs)

# Generated at 2022-06-22 19:47:50.936129
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Check default
    assert cliargs_deferred_get('does not exist')([]) == None
    assert cliargs_deferred_get('does not exist', 2)([]) == 2

    # Check CliArgs returning shallow copy
    assert cliargs_deferred_get('does not exist 2')({'does not exist 2': [1, 2, 3]}) == [1, 2, 3]
    assert cliargs_deferred_get('does not exist 2')({'does not exist 2': {'1': 1, '2': 2, '3': {'4': 4}}}
                                                    ) == {'1': 1, '2': 2, '3': {'4': 4}}

# Generated at 2022-06-22 19:48:02.105163
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Set up
    global CLIARGS
    args = dict(a=1, b='foo', c=[1, 2, 3])
    CLIARGS = CLIArgs(args)
    assert 1 == cliargs_deferred_get('a')()
    assert 'foo' == cliargs_deferred_get('b')()
    assert [1, 2, 3] == cliargs_deferred_get('c')()
    assert 1 == cliargs_deferred_get('a', shallowcopy=True)()
    assert 'foo' == cliargs_deferred_get('b', shallowcopy=True)()
    assert [1, 2, 3] == cliargs_deferred_get('c', shallowcopy=True)()
    # Use the default if a non-existent key is passed
    assert 2 == cliargs_

# Generated at 2022-06-22 19:48:09.631902
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS['foo'] = ['bar', 'baz']
    closure = cliargs_deferred_get('foo')
    assert closure() == ['bar', 'baz']

    # Ensure that shallow copies are not just references
    closure_shallow = cliargs_deferred_get('foo', shallowcopy=True)
    closure_shallow()[0] = 'fie'
    assert closure() == ['bar', 'baz']

    # Ensure that deep copies are returned when shallowcopy=False
    assert closure_shallow() == ['fie', 'baz']

# Generated at 2022-06-22 19:48:15.734984
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    def _test_asserts(actual, expected):
        if is_sequence(expected):
            assert actual == expected
            assert id(actual) != id(expected)
        elif isinstance(expected, (Mapping, Set)):
            assert actual == expected
            assert id(actual) != id(expected)
        else:
            assert actual == expected
            assert id(actual) == id(expected)

    cli_args = {'z': [1,2,3]}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('z', shallowcopy=False)() == [1,2,3]
    assert id(cliargs_deferred_get('z', shallowcopy=False)()) != id([1,2,3])


# Generated at 2022-06-22 19:48:23.495287
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import tempfile
    import os
    import shutil
    import sys
    import textwrap
    import random
    import string
    import json

    _, mod_base = tempfile.mkstemp(prefix='ansible_module_')
    shutil.copyfile(os.path.join(os.path.dirname(__file__), '__init__.py'),
                    '%s.py' % mod_base)

    # Get some args to test getting values from
    args = ['value', '--one_dict', '{"value": 1}']
    random_str = ''.join(random.choice(string.ascii_letters) for _ in range(10))
    random_list = [random_str for _ in range(5)]

# Generated at 2022-06-22 19:48:33.839708
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = dict(
        key1='key1value',
        key2=[],
        key3=dict(),
        key4=set(),
    )
    _init_global_context(cli_args)
    assert cliargs_deferred_get('key1')() == 'key1value'
    assert cliargs_deferred_get('key1', 'defaultvalue')() == 'key1value'
    assert cliargs_deferred_get('key2')() == []
    assert cliargs_deferred_get('key2', [])() == []
    assert cliargs_deferred_get('key3')() == {}
    assert cliargs_deferred_get('key3', dict())() == {}
    assert cliargs_deferred_get('key4')() == set()

# Generated at 2022-06-22 19:48:41.999720
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'ANSIBLE_STRICT': 'error', 'ANSIBLE_HOST_KEY_CHECKING': 'false'})
    assert CLIARGS['ANSIBLE_STRICT'] == 'error'
    assert cliargs_deferred_get('ANSIBLE_STRICT')() == 'error'

    _init_global_context({'ANSIBLE_STRICT': 'warn', 'ANSIBLE_HOST_KEY_CHECKING': 'false'})
    assert CLIARGS['ANSIBLE_STRICT'] == 'warn'
    assert cliargs_deferred_get('ANSIBLE_STRICT')() == 'warn'


# Generated at 2022-06-22 19:48:52.198449
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default='baz')() == 'baz'

    class Foo:
        pass
    foo = Foo()
    CLIARGS = CLIArgs({'foo': foo})
    assert cliargs_deferred_get('foo', default='baz')() is foo

    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')

# Generated at 2022-06-22 19:49:03.245733
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Check that closure works
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Check that variables work
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', default='semibar')() == 'bar'
    assert cliargs_deferred_get('nonfoo', default='semibar')() == 'semibar'

    # Check that shallow copy works properly
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() != CLIARGS['foo']
    CLIARGS['foo'] = [1, 2, 3]

# Generated at 2022-06-22 19:49:13.549684
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    global CLIARGS
    CLIARGS = CLIArgs({'foo': {'bar': 42}})

    def test_key(key, expected):
        assert expected == cliargs_deferred_get(key)()

    def test_copy_type(key, expected, shallowcopy):
        assert expected == cliargs_deferred_get(key, shallowcopy=shallowcopy)()

    test_key('foo', {'bar': 42})
    test_key('bar', None)

    test_copy_type('foo', {'bar': 42}, False)
    test_copy_type('foo', {'bar': 42}, True)
    test_copy_type

# Generated at 2022-06-22 19:49:22.128225
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    CLIARGS.setdefault('foo', {'bar': 'baz'})
    assert cliargs_deferred_get('foo') == {'bar': 'baz'}
    assert cliargs_deferred_get('foo', shallowcopy=True) == {'bar': 'baz'}
    assert cliargs_deferred_get('not_foo') is None
    # Make sure that a shallow copy is a different object
    assert cliargs_deferred_get('foo', shallowcopy=True) is not cliargs_deferred_get('foo')
    assert cliargs_deferred_get('foo', shallowcopy=True) == cliargs_deferred_get('foo')
    # Changing the shallow copy should not change the original
   

# Generated at 2022-06-22 19:49:33.079079
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    cliargs = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='not-bar')() == 'bar'
    assert cliargs_deferred_get('foo', default='default')() == 'bar'
    assert cliargs_deferred_get('missing')() is None
    assert cliargs_deferred_get('missing', default='default')() == 'default'
    assert cliargs_deferred_get('missing', default='default', shallowcopy=True)() == 'default'

    lst = ['1', '2', '3']
    cliargs = CLIArgs({'foo': lst})

# Generated at 2022-06-22 19:49:43.713911
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get("foo", default='baz')() == ['bar']
    assert cliargs_deferred_get("baz", default='bar')() == 'bar'

    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get("foo", default={'bazzle': 'dazzle'})() == {'bar': 'baz'}
    assert cliargs_deferred_get("baz", default={'bar': 'baz'})() == {'bar': 'baz'}
    assert cliargs_deferred_get("baz", default=set([1,2]))() == set([1,2])
   

# Generated at 2022-06-22 19:49:54.189673
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_cliargs = CLIArgs({'test_list': [1, 2, 3], 'test_dict': {'test_set': {1, 2, 3}}, 'test_str': 'foo'})
    set_the_global(test_cliargs)

    assert cliargs_deferred_get('test_list')() == [1, 2, 3]
    assert cliargs_deferred_get('test_dict')() == {'test_set': {1, 2, 3}}
    assert cliargs_deferred_get('test_str')() == 'foo'

    set_the_global(CLIArgs({}))
    assert cliargs_deferred_get('test_list')() == None
    assert cliargs_deferred_get('test_dict')() == None
    assert cliargs_def

# Generated at 2022-06-22 19:50:04.376703
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    from ansible.utils.context_objects import CliArgs
    test_args = {'foo': 1, 'bar': 2}
    cliargs = CliArgs(test_args)
    _init_global_context(cliargs)
    func = cliargs_deferred_get('foo')
    assert func() == 1
    func = cliargs_deferred_get('bar')
    assert func() == 2
    func = cliargs_deferred_get('baz', default=3)
    assert func() == 3
    test_args['foo'] = [1, 2, 3]
    func = cliargs_deferred_get('foo', shallowcopy=True)
    assert func() == [1, 2, 3]
    retval = func()
   

# Generated at 2022-06-22 19:50:11.697241
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', 'default')() == 'bar'
    assert cliargs_deferred_get('notfoo', 'default')() == 'default'
    assert cliargs_deferred_get('foo', 'default', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', ['default'], shallowcopy=True)() == 'bar'

# Generated at 2022-06-22 19:50:21.680414
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # setup
    _init_global_context({})
    # test
    value = cliargs_deferred_get('connection_plugins', shallowcopy=False)
    assert isinstance(value, list)
    assert value is cliargs_deferred_get('connection_plugins', shallowcopy=False)(), "shallowcopy=False should return the original list instance"
    assert value is not cliargs_deferred_get('connection_plugins', shallowcopy=True)(), "shallowcopy=True should return a copy of the list"

    value = cliargs_deferred_get('vault_password_files', 'files', shallowcopy=False)
    assert isinstance(value, list)

# Generated at 2022-06-22 19:50:33.080589
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def foo(bar):
        return lambda: bar

    assert cliargs_deferred_get('not_there')('baz')() == 'baz'
    assert cliargs_deferred_get('not_there', 'baz')('baz')() == 'baz'
    assert cliargs_deferred_get('not_there', default='baz', shallowcopy=True) == 'baz'
    assert cliargs_deferred_get('not_there', default=['baz', 'zab']) == ['baz', 'zab']
    assert cliargs_deferred_get('not_there', default=['baz', 'zab'], shallowcopy=True) == ['baz', 'zab']

# Generated at 2022-06-22 19:50:41.768090
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Wrap the dict in GlobalCLIArgs so that we can get
    # from_options to run to convert the dict to the
    # appropriate subclass
    def init(cli_args):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    # Verify the results of the closure over CLIARGS.get
    def check_closure(key, defaults):
        v = cliargs_deferred_get(key)
        for clone in (False, True):
            for shallow in (False, True):
                d = cliargs_deferred_get(key, default=defaults, shallowcopy=shallow)
                assert d() == v()
                assert id(d()) != id(v())

    # Setup
    cli_args = {}
    init(cli_args)

    # No

# Generated at 2022-06-22 19:50:48.489240
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Replace global singleton with a dictionary
    global CLIARGS
    cli_args = {
        'foo': 'bar',
        'bar': 'baz',
        'qux': ['quux', 'corge'],
    }
    CLIARGS = cli_args

    # Test getting a value
    foo_getter = cliargs_deferred_get('foo')
    assert foo_getter() == 'bar'

    # Test getting a value that doesn't exist
    bar_getter = cliargs_deferred_get('bar')
    assert bar_getter() == 'baz'

    # Test copy
    qux_getter = cliargs_deferred_get('qux', shallowcopy=True)
    assert qux_getter() == ['quux', 'corge']
    assert qu

# Generated at 2022-06-22 19:50:56.008380
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Before initialization (CLIARGS not replaced with a singleton)
    assert cliargs_deferred_get('become')() is None
    assert cliargs_deferred_get('become', shallowcopy=True)() is None
    assert cliargs_deferred_get('become', default="user")() == "user"
    assert cliargs_deferred_get('become', default="user", shallowcopy=True)() == "user"

    # After initialization
    _init_global_context(dict(become="user"))
    assert cliargs_deferred_get('become')() == "user"
    assert cliargs_deferred_get('become', shallowcopy=True)() == "user"

# Generated at 2022-06-22 19:51:01.761522
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = {'foobar': ['foo', 'bar'], 'baz': {'qux': ['quux']}}
    _init_global_context(cliargs)
    getter = cliargs_deferred_get('foobar', shallowcopy=True)
    retval = getter()
    assert retval == cliargs['foobar']
    assert retval != cliargs['foobar']
    getter = cliargs_deferred_get('baz', shallowcopy=True)
    retval = getter()
    assert retval == cliargs['baz']
    assert retval != cliargs['baz']

