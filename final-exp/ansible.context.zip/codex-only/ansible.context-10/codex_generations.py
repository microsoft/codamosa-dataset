

# Generated at 2022-06-22 19:41:03.318166
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['array'] = ['value']
    CLIARGS['dict'] = dict(key='value')
    CLIARGS['set'] = set(['value'])
    CLIARGS['string'] = 'value'
    CLIARGS['bool_true'] = True
    CLIARGS['bool_false'] = False
    CLIARGS['none'] = None

    def assert_same_values(shallowcopy, key, value):
        copy_val = cliargs_deferred_get(key, shallowcopy=shallowcopy)()
        if shallowcopy:
            assert copy_val is value
        else:
            assert copy_val == value

    assert_same_values(False, 'array', ['value'])
    assert_same_values(True, 'array', ['value'])

# Generated at 2022-06-22 19:41:14.420216
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs(dict(a='A',b=['1','2'],c=dict(c1='c1',c2='c2'),d=set(['d1','d2'])))
    cliargs_deferred_get.a = cliargs_deferred_get('a',shallowcopy=True)
    cliargs_deferred_get.b = cliargs_deferred_get('b',shallowcopy=True)
    cliargs_deferred_get.c = cliargs_deferred_get('c',shallowcopy=True)
    cliargs_deferred_get.d = cliargs_deferred_get('d',shallowcopy=True)
    global CLIARGS
    CLIARGS = cliargs
    assert cliargs_deferred_get.a()

# Generated at 2022-06-22 19:41:24.936635
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def assert_same_as(func_or_obj, value):
        assert func_or_obj() is value  # no copy

    def assert_shallow_copy(func_or_obj, value):
        copy = func_or_obj()
        assert copy is not value
        assert copy == value
        assert isinstance(copy, type(value))

    # test function object
    assert_same_as(CLIARGS.get, None)
    assert_same_as(CLIARGS.get('--no-log', default=None), None)
    assert_same_as(CLIARGS.get('--no-log', default=None, shallowcopy=True), None)

    # test lists

# Generated at 2022-06-22 19:41:35.521557
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get

    This is really a test for ``FieldAttribute`` but it's easier to test this function directly
    """
    class Class(object):
        # Note: The class doesn't matter.  We only care that the deferred_get function
        # is called and returns

        def __init__(self, cliargs):
            self.__dict__['_Mock__cliargs'] = cliargs

        @property
        def _assert(self):
            self._Mock__cliargs.get('_assert')
            return True

        def __getattribute__(self, name):
            if name == '_assert':
                return self._assert
            raise AttributeError("'Mock' object has no attribute '%s'" % name)


# Generated at 2022-06-22 19:41:45.905470
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Verify that deferred_get works as expected"""

    import pytest

    cliargs = CLIArgs({'foo': 'bar'})

    # Verify that getting a key works
    get_foo = cliargs_deferred_get('foo')
    assert get_foo() == 'bar'
    # Verify that getting the default works
    get_bar = cliargs_deferred_get('bar', default='foobar')
    assert get_bar() == 'foobar'
    # Verify that shallow copy works
    get_foo_shallow = cliargs_deferred_get('foo', shallowcopy=True)
    assert get_foo_shallow() == 'bar'
    # Verify that getting a shallow copy of a list works

# Generated at 2022-06-22 19:41:54.031122
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar', 'list': [1, 2, 3]}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('list')(False) == cli_args['list']
    assert cliargs_deferred_get('list')() == cli_args['list'][:]
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='boo')() == 'boo'

# Generated at 2022-06-22 19:42:04.324304
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Test for CLIARGS being a CLIArgs
    CLIARGS._storage = {'key': 'value'}
    assert cliargs_deferred_get('key')() == 'value'

    # Test for CLIARGS being a GlobalCLIArgs
    CLIARGS._storage = CLIArgs({'key': 'value'})
    assert cliargs_deferred_get('key')() == 'value'

    # Test for CLIARGS being a GlobalCLIArgs with --extra-vars
    CLIARGS._storage = CLIArgs({'key': 'value', 'extra_vars': {'ext_key': 'ext_val'}})
    assert cliargs_deferred_get('key')() == 'value'

# Generated at 2022-06-22 19:42:14.703830
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['test_key'] = 'test_value'
    getter = cliargs_deferred_get('test_key')

    assert getter() == 'test_value'

    CLIARGS['test_key'] = tuple('tuple')
    getter = cliargs_deferred_get('test_key', shallowcopy=True)
    assert getter() == ('t', 'u', 'p', 'l', 'e')

    CLIARGS['test_key'] = set('set')
    getter = cliargs_deferred_get('test_key', shallowcopy=True)
    assert getter() == set(('s', 'e', 't'))

    CLIARGS['test_key'] = {'one': 1, 'two': 2}

# Generated at 2022-06-22 19:42:18.734649
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import namedtuple
    GlobalCLIArgs = namedtuple('GlobalCLIArgs', 'connection')
    CLIARGS = GlobalCLIArgs(connection='smart')
    assert cliargs_deferred_get('connection')() == 'smart'

# Generated at 2022-06-22 19:42:26.070586
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Ctx:
        pass
    class CliArgs:
        def __getitem__(self, key):
            return self.get(key)

        def get(self, key, default=None):
            return getattr(self, key, default)

    cli_args = CliArgs()
    cli_args.var1 = 'val1'
    ctx = Ctx()
    ctx.cli_args = cli_args
    ctx.key = 'var1'
    ctx.default = 'default'
    ctx.get_value = cliargs_deferred_get(ctx.key, ctx.default)

    # Get with no setting
    assert 'default' == ctx.get_value()

    # Get with setting
    ctx.cli_args.var1 = 'val2'


# Generated at 2022-06-22 19:42:35.900668
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    context = {'test_key': 'test_value'}
    CLIARGS.set_options(context)
    cliargs_deferred_get_func = cliargs_deferred_get('test_key')
    cliargs_deferred_get_func_default = cliargs_deferred_get('test_key_default', 'test_value')
    assert cliargs_deferred_get_func() == 'test_value'
    assert cliargs_deferred_get_func_default() == 'test_value'
    # check whether dict and set are copied
    context = {'dict_value': {'key1': 'value1'}, 'set_value': {'a', 'b'}}
    CLIARGS.set_options(context)
    dict_value = cliargs_deferred_get

# Generated at 2022-06-22 19:42:45.131691
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    args = {'a': 1, 'b': {'c': 3}}

    global CLIARGS
    CLIARGS = CLIArgs(args)

    assert cliargs_deferred_get('a', shallowcopy=True) == 1
    assert cliargs_deferred_get('a', shallowcopy=False) == 1
    assert cliargs_deferred_get('b', shallowcopy=True) == {'c': 3}
    assert cliargs_deferred_get('b', shallowcopy=False) == {'c': 3}
    assert cliargs_deferred_get('c', default=5, shallowcopy=True) == 5
    assert cliargs_deferred_get('c', default=5, shallowcopy=False) == 5

# Generated at 2022-06-22 19:42:56.780788
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """test cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'a': 'value'})
    g = cliargs_deferred_get('a')
    assert g() == 'value'
    g = cliargs_deferred_get('b', default='default')
    assert g() == 'default'

    CLIARGS = CLIArgs({'a': 'value', 'b': True, 'c': (1, 2), 'd': {'a': 1}, 'e': set([1, 2, 3])})
    a = cliargs_deferred_get('a')
    assert a() == 'value'
    b = cliargs_deferred_get('b')
    assert b() is True
    c = cliargs_deferred_get('c')

# Generated at 2022-06-22 19:43:03.780463
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo') () is None
    assert cliargs_deferred_get('foo', default=5) () == 5

    CLIARGS = CLIArgs({'foo': 10})
    assert cliargs_deferred_get('foo', default=5) () == 10

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default=5) () == 'bar'
    assert cliargs_deferred_get('foo', default=5, shallowcopy=True) () == 'bar'

    CLIARGS = CLIArgs({'foo': [1, 2, 3]})

# Generated at 2022-06-22 19:43:14.440129
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_classes(value):
        # Need to check that the returned value is a shallow copy of the dict
        assert value == {'a': 1}
        value['a'] = 2
        assert value == {'a': 2}
        assert CLIARGS['dict_value'] == {'a': 1}

        # NOTE: There is no good way to check that the returned value is a shallow copy of the list
        # If a list value is in the cliargs, we assume it is a list and a shallow copy will be made
        assert value == ['b']
        assert CLIARGS['list_value'] == ['b']

    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', default=None, shallowcopy=True)() is None
    CLIARGS['dict_value']

# Generated at 2022-06-22 19:43:21.544623
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from unittest import TestCase, mock
    from .common import set_default_cliargs_for_testing
    set_default_cliargs_for_testing()
    test_dict = {'a': 10}
    test_list = [1, 2]
    test_cli_args = CLIARGS.as_dict()
    test_cli_args['test_dict'] = test_dict
    test_cli_args['test_list'] = test_list
    _init_global_context(test_cli_args)
    with mock.patch('ansible.cli.CLIARGS', new=CLIARGS):
        verify_dict = cliargs_deferred_get('test_dict')()
        verify_list = cliargs_deferred_get('test_list')()
        verify_dict_copy = cli

# Generated at 2022-06-22 19:43:31.357464
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=W0612,W0613
    ret = [None, None]

    def my_func():
        ret[0] = 'abc'
        return 'abc'

    default = cliargs_deferred_get('foo', my_func)
    value = cliargs_deferred_get('foo', default)
    assert value() == my_func()
    assert value() is ret[0]
    assert ret[0] == 'abc'

    ret[0] = None
    default = cliargs_deferred_get('foo', my_func)
    value = cliargs_deferred_get('foo', default, shallowcopy=True)
    assert value() == my_func()
    assert value() is not ret[0]
    assert ret[0] is None

# Generated at 2022-06-22 19:43:36.448663
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the key from CLIARGS when it exists and the default when it doesn't
    """
    old_cliargs = CLIARGS
    try:
        CLIARGS = {'default': 1}
        f = cliargs_deferred_get('default')
        assert f() == 1
        f = cliargs_deferred_get('key', default=5)
        assert f() == 5
    finally:
        CLIARGS = old_cliargs

# Generated at 2022-06-22 19:43:43.171095
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Test function used for CLIARGS.set
    def _set_callback(key, value):
        context['key'] = key
        context['value'] = value
        context['cliargs_set'] = True

    # Test function to replace CLIARGS
    def _replace_cliargs():
        CLIARGS.set = _set_callback

    context = {}
    cliargs = CLIARGS
    cliargs._set('foo', 'bar')
    _replace_cliargs()
    cliargs_deferred_get('foo')()
    assert context == {}
    cliargs._initialize()
    assert context['foo'] == 'bar'

# Generated at 2022-06-22 19:43:54.542885
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import stringc

    def configure_display():
        display = Display()
        display.columns = 80
        return display

    class FakeCLIArgs(Mapping):
        def __init__(self):
            self._args_dict = dict()

        def __iter__(self):
            return iter(self._args_dict)

        def __len__(self):
            return len(self._args_dict)

        def __getitem__(self, key):
            return self._args_dict[key]

        def set_simple_dict(self, var, value):
            self._args_dict[var] = value



# Generated at 2022-06-22 19:44:04.219016
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _assert_no_references(ret):
        assert ret == [10, 20, 30]
        assert ret is not CLIARGS['some_list']
        assert ret[0] is CLIARGS['some_list'][0]
        assert ret[1] is CLIARGS['some_list'][1]
        assert ret[2] is CLIARGS['some_list'][2]

    global CLIARGS
    CLIARGS = CLIArgs({'some_list': [10, 20, 30]})
    a = cliargs_deferred_get('some_list', shallowcopy=True)
    _assert_no_references(a())
    CLIARGS = CLIArgs({'some_list': [40, 50, 60]})

# Generated at 2022-06-22 19:44:15.397502
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    x = 1
    y = 2
    l = [1, 2]
    c = {'a': 1, 'b': 2}
    s = set(['a', 'b'])
    CLIARGS.update(x=x, y=y, l=l, c=c, s=s)
    for arg in ('x', 'y', 'l', 'c', 's'):
        assert getattr(CLIARGS, arg) == cliargs_deferred_get(arg)()
        assert getattr(CLIARGS, arg) is not cliargs_deferred_get(arg)()
    l.append(3)
    l.append(4)
    l.append(5)
    l.append(6)
    l.append(7)
    l.append(8)
    l

# Generated at 2022-06-22 19:44:24.919264
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Note: it would be nice to also test that the return value is shallowcopied
    # if requested but we don't have a good way to do that.
    _init_global_context(dict(mykey=123))
    assert cliargs_deferred_get('mykey')() == 123
    assert cliargs_deferred_get('mykey', default=456)() == 123
    assert cliargs_deferred_get('mykey', default=456, shallowcopy=True)() == 123
    assert cliargs_deferred_get('otherkey', default=456)() == 456
    assert cliargs_deferred_get('otherkey', default=456, shallowcopy=True)() == 456

# Generated at 2022-06-22 19:44:32.602613
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # A simple get with a default value
    _init_global_context(dict())
    f = cliargs_deferred_get('foo', default='bar')
    assert f() == 'bar'

    # A simple get without a default value
    _init_global_context(dict(foo='bar'))
    f = cliargs_deferred_get('foo')
    assert f() == 'bar'

    # A get with a default that is a list
    # Without shallow copy
    _init_global_context(dict())
    f = cliargs_deferred_get('foo', default=['bar'], shallowcopy=False)
    assert f() == ['bar']
    assert f() is not ['bar']  # Prove it is a copy

    #

# Generated at 2022-06-22 19:44:40.762828
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1]})
    get_foobar = cliargs_deferred_get('foo')
    assert get_foobar() == 'bar'
    get_foo = cliargs_deferred_get('foo', default='default')
    assert get_foo() == 'bar'
    get_baz = cliargs_deferred_get('baz', shallowcopy=True)
    assert get_baz() == [1]
    # Make sure we are using a shallow copy
    get_baz()[0] = 2
    assert CLIARGS['baz'][0] == 1
    get_default = cliargs_deferred_get('defval', default='default')
    assert get_default() == 'default'

# Generated at 2022-06-22 19:44:50.956279
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(key='foo')() is None
    assert cliargs_deferred_get(key='foo', default=1)() == 1

    _init_global_context(cli_args={'foo': 2})
    assert cliargs_deferred_get(key='foo')() == 2
    assert cliargs_deferred_get(key='foo', default=1)() == 2

    # shallow copy
    _init_global_context(cli_args={'foo': [1, 2, 3]})
    assert cliargs_deferred_get(key='foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get(key='foo')() == [1, 2, 3]

# Generated at 2022-06-22 19:44:59.028436
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo')() == None
    # Check that it's not bound
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == None
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Check that it is returned by value
    CLIARGS['foo'] = {'a': 'b'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'a': 'b'}

# Generated at 2022-06-22 19:45:08.357826
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.data = {'a': 5, 'b': {'c': 'd'}}
    assert cliargs_deferred_get('a')() == 5
    assert cliargs_deferred_get('b')() == {'c': 'd'}
    assert cliargs_deferred_get('a', shallowcopy=True)() == 5
    assert cliargs_deferred_get('b', shallowcopy=True)() == {'c': 'd'}
    assert cliargs_deferred_get('b', shallowcopy=True)() == {'c': 'd'}
    assert cliargs_deferred_get('b', shallowcopy=True)() == {'c': 'd'}
    assert cliargs_deferred_get('a')() == 5

# Generated at 2022-06-22 19:45:17.451777
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'a':{'b':3}})
    deferred = cliargs_deferred_get('a', default={'b':4})
    assert deferred() == {'b': 3}

    _init_global_context({'a':{'b':3}})
    deferred = cliargs_deferred_get('a', default={'b':4}, shallowcopy=True)
    assert deferred() == {'b': 3}

    _init_global_context({'a':[1,2,3]})
    deferred = cliargs_deferred_get('a')
    assert deferred() == [1,2,3]

    _init_global_context({'a':[1,2,3]})
    deferred = cliargs_deferred_get('a', shallowcopy=True)


# Generated at 2022-06-22 19:45:24.630896
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.cli.arguments import OptionParserConnection, OptionParserBecome
    parser = GlobalCLIArgs._get_parser()
    OptionParserConnection(parser)
    OptionParserBecome(parser)
    cli_args = parser.parse_args([])
    _init_global_context(cli_args)
    assert cliargs_deferred_get('connection') == 'smart'
    assert cliargs_deferred_get('become', default=True) is True
    assert cliargs_deferred_get('become_user', default='test') == 'test'

# Generated at 2022-06-22 19:45:30.704794
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test': 'value'})
    # Test simple replacement of values in a closure
    cliargs = cliargs_deferred_get('test')
    assert cliargs() == 'value'
    CLIARGS = CLIArgs({'test': 'something'})
    assert cliargs() == 'something'

    # Test with defaults
    cliargs = cliargs_deferred_get('other', default='default')
    assert cliargs() == 'default'
    CLIARGS = CLIArgs({'other': 'value'})
    assert cliargs() == 'value'

    # Test with a shallow copy
    CLIARGS = CLIArgs({'list': [1, 2]})

# Generated at 2022-06-22 19:45:36.279692
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS.update({'a': 'b'})
    assert cliargs_deferred_get('a')() == 'b'

    CLIARGS = {'a': 'b'}
    assert cliargs_deferred_get('a')() == 'b'

    CLIARGS = None
    assert cliargs_deferred_get('a', 'c')() == 'c'

# Generated at 2022-06-22 19:45:46.394759
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for module cliargs_deferred_get"""
    global CLIARGS
    # Test getting an item from the default empty container
    assert cliargs_deferred_get('foo')() == None

    # Test getting an item from a filled CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test getting a non-existing item, with a default
    assert cliargs_deferred_get('foo2', default='baz')() == 'baz'

    # Test getting a non-existing item, without a default
    assert cliargs_deferred_get('foo3')() == None

    # Test getting an item with a default that's not used, with a default
    assert cliargs_deferred_get

# Generated at 2022-06-22 19:45:53.179012
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1})
    assert cliargs_deferred_get('a', default=2)() == 1
    assert cliargs_deferred_get('b', default=2)() == 2
    assert cliargs_deferred_get('a', default=(2, 3))() == (1,)

    # The default value should not be affected by the second call
    assert cliargs_deferred_get('b', default=(2, 3))() == (2, 3)

# Generated at 2022-06-22 19:46:02.409454
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import unittest
    import sys
    import os

    class CLIOptions(object):
        """Represents options that would be parsed by the arg parser"""
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class TestCliArgsDeferredGet(unittest.TestCase):
        """Unit test CLIArgs"""
        def test_get_args(self):
            """Get args from CLIArgs"""
            test_directory = os.path.dirname(os.path.abspath(__file__))
            os.environ['ANSIBLE_CONFIG'] = os.path.join(test_directory, 'cli_args', 'test.cfg')
            cli_args = CLIOptions(verbosity=3)
            _init_global_context(cli_args)
           

# Generated at 2022-06-22 19:46:11.093613
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    assert CLIARGS.get('baz_cli') == cliargs_deferred_get('baz_cli') == 'baz_cli_default'

    CLIARGS = GlobalCLIArgs()

    assert cliargs_deferred_get('baz_cli', default='baz_cli_default') == 'baz_cli_default'
    assert cliargs_deferred_get('baz_cli', default='baz_cli_default') == 'baz_cli_default'
    CLIARGS.update({'baz_cli': 'I GOT SEPPUKU'})
    assert cliargs_deferred_get('baz_cli', default='baz_cli_default') == 'I GOT SEPPUKU'

# Generated at 2022-06-22 19:46:21.733870
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Check value retrieval
    cliargs = {'a': 3, 'b': [1, 2, 3]}
    _init_global_context(cliargs)

    assert cliargs_deferred_get('a')() == 3
    # Check default
    assert cliargs_deferred_get('c')(default=4) == 4
    # Check that copy is actually independent of CLIARGS contents
    assert cliargs_deferred_get('a', shallowcopy=True)() is not CLIARGS['a']
    # Check list shallowcopy
    assert cliargs_deferred_get('b', shallowcopy=True)() is not CLIARGS['b']
    assert cliargs_deferred_get('b', shallowcopy=True)() == [1, 2, 3]
    # Check that copy is actually independent of CLIAR

# Generated at 2022-06-22 19:46:32.953439
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'debug': True, 'remote_tmp': '/tmp/a', 'accelerate': None, 'ssh_common_args': ['-x', '-F'], 'connection': 'ansible.connection.ssh', 'inventory': [], 'module_path': None, 'timeout': 10, 'ssh_executable': 'ssh', 'private_key_file': None, 'remote_user': 'root', 'host_key_checking': True, 'become': False, 'ask_pass': False, 'verbosity': 0, 'vault_password_files': [], 'forks': 5}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('debug', False)
    assert cliargs_deferred_get('debug', False)()
    assert cliargs_deferred_

# Generated at 2022-06-22 19:46:40.509083
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils._text import to_text
    _init_global_context({'list_key': ['foo', 'bar'], 'mapping_key': {'qux': 'qux_val'}})
    assert cliargs_deferred_get('list_key') == ['foo', 'bar']
    assert cliargs_deferred_get('mapping_key') == {'qux': 'qux_val'}
    assert cliargs_deferred_get('str_key') is None
    assert cliargs_deferred_get('str_key', default='default_value') == 'default_value'
    assert cliargs_deferred_get('list_key', shallowcopy=True) == ['foo', 'bar']

# Generated at 2022-06-22 19:46:51.200730
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({})

    # Test that cliargs_deferred_get works when the cliargs aren't parsed yet
    value = cliargs_deferred_get('something')(); assert value is None

    cli_args = {'something': 5}
    CLIARGS = GlobalCLIArgs.from_options(cli_args)

    # Test that cliargs_deferred_get works when the cliargs have been parsed
    value = cliargs_deferred_get('something')(); assert value == 5

    # Test that the closure actually returns a copy and not the original value
    cli_args['something'] = 6
    value = cliargs_deferred_get('something')(); assert value == 5

    # Test that the closure returns a copy and not the original value

# Generated at 2022-06-22 19:46:59.635427
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible import context
    import os

    # Write a few test files we can use
    tempdir = mkdtemp()
    test_file_paths = []
    for number in range(10):
        test_file_name = os.path.join(tempdir, 'testfile_%d' % (number))
        with open(test_file_name, 'w') as f:
            f.write('Test File %d' % (number))
        test_file_paths.append(os.path.realpath(test_file_name))

# Generated at 2022-06-22 19:47:11.010725
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs

    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo') == None

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('foo', 'baz') == 'bar'

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('baz', 'default') == 'default'

    CLIARGS = CLIArgs({'foos': ['bar', 'baz']})
    assert cliargs_deferred_get('foos') == ['bar', 'baz']

# Generated at 2022-06-22 19:47:19.721789
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({
        'foo': [1, 2, 3],
        'bar': {
            'baz': 'qux',
            'quux': ['corge'],
            'grault': {'garply': 'waldo'},
        }
    })

    get_foo = cliargs_deferred_get('foo')
    get_foo_shallowcopy = cliargs_deferred_get('foo', shallowcopy=True)
    get_bar = cliargs_deferred_get('bar')
    get_bar_shallowcopy = cliargs_deferred_get('bar', shallowcopy=True)
    get_quux = cliargs_deferred_get('bar.quux')

# Generated at 2022-06-22 19:47:30.384176
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import unittest

    from ansible.utils.context_objects import GlobalCLIArgs, CLIArgs

    class MockGlobalCLIArgs(GlobalCLIArgs):
        """Mock out GlobalCLIArgs for test code."""
        def __getitem__(self, key):
            if key == 'foo':
                return 'bar'
            elif key == 'baz':
                return ['bat', 'ball']
            raise KeyError

    class TestCLIArgs(unittest.TestCase):

        def setUp(self):
            self.old_CLIARGS = CLIARGS
            self.new_CLIARGS = MockGlobalCLIArgs.from_options({})
            CLIARGS = self.new_CLIARGS
            return super(TestCLIArgs, self).setUp()


# Generated at 2022-06-22 19:47:39.860078
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS

    def do_test(args, key, default, shallowcopy, expected_value):
        CLIARGS = CLIArgs(args)
        assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == expected_value

    do_test({}, 'foo', 1, False, 1)
    do_test({'foo': 2}, 'foo', 1, False, 2)
    do_test({'foo': 'bar'}, 'foo', 1, False, 'bar')
    do_test({}, 'foo', [], True, [])
    do_test({'foo': ['bar']}, 'foo', [], True, ['bar'])

# Generated at 2022-06-22 19:47:49.696583
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that ``cliargs_deferred_get`` does what we expect"""
    global CLIARGS
    # Defaults
    CLIARGS = GlobalCLIArgs.from_options({})
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'bar'

    # Present with no shallowcopy
    CLIARGS = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

# Generated at 2022-06-22 19:47:59.627885
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': [1, 2, 3],
                       'bar': {'a': 'b', 'c': 'd'},
                       'baz': ['s', 'm', 'l']})
    func = cliargs_deferred_get('foo', [], True)
    assert func() == [1, 2, 3]
    func = cliargs_deferred_get('bar', {}, True)
    assert func() == {'a': 'b', 'c': 'd'}
    func = cliargs_deferred_get('baz', [])
    assert func() == ['s', 'm', 'l']
    func = cliargs_deferred_get('baz', [], True)
    assert func() == ['s', 'm', 'l']


# Generated at 2022-06-22 19:48:09.720265
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    global CLIARGS
    cli_args = {'foo': [1, 2, 3], 'bar': {1: '1', 2: '2'}}
    CLIARGS = CLIArgs(cli_args)

    assert cliargs_deferred_get('foo')(), cli_args['foo']
    assert cliargs_deferred_get('foo', shallowcopy=True)(), cli_args['foo'][:]
    assert cliargs_deferred_get('foobar')(), None
    assert cliargs_deferred_get('foobar', 'baz')(), 'baz'
    assert cliargs_deferred_get('bar')(), cli_args['bar']

# Generated at 2022-06-22 19:48:15.632466
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the value returned by the closure
    test_val = '123'
    closure = cliargs_deferred_get('test_key', test_val)
    assert closure() == test_val

    # Test the value returned by the closure before and after CLIARGS is changed
    test_val_2 = '456'
    closure = cliargs_deferred_get('test_key_2', test_val_2)
    assert closure() == test_val_2
    global CLIARGS
    CLIARGS['test_key_2'] = test_val_2

    closure_value = closure
    closure_value()
    assert closure() == test_val_2


# TODO: create context objects for the various contexts
# TODO: Do we need to handle the role context here?

# Generated at 2022-06-22 19:48:21.048993
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(a='a', b=dict(c='c')))

    assert cliargs_deferred_get('a')() == 'a'
    assert cliargs_deferred_get('b')()['c'] == 'c'

    assert cliargs_deferred_get('a', shallowcopy=True)() == 'a'
    assert cliargs_deferred_get('b', shallowcopy=True)()['c'] == 'c'
    assert isinstance(cliargs_deferred_get('b', shallowcopy=True)(), dict)

    assert cliargs_deferred_get('a', shallowcopy=False)() == 'a'
    assert cliargs_deferred_get('b', shallowcopy=False)()['c'] == 'c'


# Generated at 2022-06-22 19:48:27.042438
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    initial = CLIARGS._CLIArgs__values
    cliargs_deferred_get(key='foo')() == initial[key]
    CLIARGS._CLIArgs__values = {'foo': 'bar'}
    cliargs_deferred_get(key='foo')() == CLIARGS._CLIArgs__values[key]

# Generated at 2022-06-22 19:48:37.335129
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This test comes apart in py2 since we can't redefine or reassign a global
    # to a different type.
    import pytest
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.collections import DeepDict, Mapping, MutableMapping
    from ansible.utils.context_objects import GlobalCLIArgs
    from itertools import chain

    class foo(MutableMapping):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __getitem__(self, key):
            return self.kwargs.get(key)

        def __setitem__(self, key, val):
            self.kwargs[key] = val


# Generated at 2022-06-22 19:48:48.091333
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    CLIARGS = {}
    import copy
    # test single value
    key, value = 'one', 1
    CLIARGS[key] = value
    assert cliargs_deferred_get(key)() == value
    assert cliargs_deferred_get(key, shallowcopy=True)() == value
    assert cliargs_deferred_get(key, shallowcopy=True)() is value
    # test with default
    key, value = 'one', 1
    assert cliargs_deferred_get(key, default=value)() == value
    assert cliargs_deferred_get(key, default=value, shallowcopy=True)() == value
    assert cliargs_deferred_

# Generated at 2022-06-22 19:48:56.207880
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_default_value(default):
        cliargs_get_default = cliargs_deferred_get('missing_key', default=default)
        assert cliargs_get_default() == default
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(dict(a='a'))
        assert cliargs_get_default() == default

    test_default_value(None)
    test_default_value(default='a')

    def test_value_from_cliargs(value, shallowcopy):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(dict(a=value))
        cliargs_get_a = cliargs_deferred_get('a', shallowcopy=shallowcopy)
        assert cliargs_get_a() == value


# Generated at 2022-06-22 19:49:02.313142
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    a = [1, 2]
    CLIARGS = CLIArgs({'a': a})
    b = cliargs_deferred_get('a', shallowcopy=True)()
    assert b == a
    b.append(3)

    b = cliargs_deferred_get('a', shallowcopy=False)()
    assert b == a
    b.append(4)



# Generated at 2022-06-22 19:49:12.813009
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': ['bat', 'bat2'], 'bat': {'k1': 'v1', 'k2': 'v2'}, 'bak': set(['bats'])})

    assert cliargs_deferred_get('foo')(), 'bar'
    assert cliargs_deferred_get('foo', default=None)(), 'bar'
    assert cliargs_deferred_get('foo', default='bar')(), 'bar'
    assert cliargs_deferred_get('baz')(), ['bat', 'bat2']
    assert cliargs_deferred_get('baz', default=None)(), ['bat', 'bat2']

# Generated at 2022-06-22 19:49:20.073144
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # avoid side effects in other tests
    global CLIARGS
    CLIARGS = CLIArgs({})

    assert cliargs_deferred_get('foo')() is None
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='default')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True, default=['default'])() == 'bar'

    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo', default='default')() == ['bar']
    assert cliargs_

# Generated at 2022-06-22 19:49:30.872377
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'config_file': "one"}

    # check if the function raises error when we haven't
    # set CLIARGS yet
    try:
        cliargs_deferred_get('config_file')
    except NameError:
        pass

    _init_global_context(cli_args)

    assert cliargs_deferred_get('config_file') == 'one'
    cli_args['config_file'] = "two"
    assert cliargs_deferred_get('config_file') == 'two'

    # Note: In Python, functions are first-class objects, so we can pass function
    # around like other objects
    assert cliargs_deferred_get('config_file')() == 'two'
    del cli_args['config_file']
    assert cliargs_

# Generated at 2022-06-22 19:49:34.420943
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pytest is going to import this module but it doesn't define any real tests.  Instead
    # the tests for this function are in test/unit/cli/test_cli.py
    pass

# Generated at 2022-06-22 19:49:44.875137
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import Mock
    from ansible.module_utils.six import callable
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    # Check that we can get a default when cliargs is uninitialized
    assert cliargs_deferred_get('fake-key', 'default') == 'default'

    # Check that we can get a key that has not been initialized
    assert cliargs_deferred_get('fake-key') == None

    # Check that we can get a value that has been initialized
    cliargs = CLIArgs()

# Generated at 2022-06-22 19:49:53.852749
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert cliargs_deferred_get('foo')() is None
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    assert cliargs_deferred_get('bar')() is None
    # Default value overrides the default None
    assert cliargs_deferred_get('bar', default='foobar')() == 'foobar'

    CLIARGS = CLIArgs({'bar': 'baz'})
    assert cliargs_deferred_get('bar')() == 'baz'
    assert cliargs_deferred_get('bar', default='foobar')() == 'baz'

    CLIARGS = CLIArgs({'list': ['a', 'b', 'c']})
    assert cliargs

# Generated at 2022-06-22 19:50:00.994309
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Initialize a field with a default using this method
    f = field.FieldAttribute(default=cliargs_deferred_get('not_there'))
    assert f.default is None
    # Check that parsing causes the value to be derived from the cli_args
    _init_global_context(dict(not_there=True))
    assert f.default is True

    value = [1, 2, 3]
    _init_global_context(dict(value=value))
    # test_shallowcopy = True
    f = field.FieldAttribute(default=cliargs_deferred_get('value', shallowcopy=True))
    assert f.default is not value
    assert f.default == value
    assert f.default is not CLIARGS['value']

    # test_shallowcopy = False (same for sequence, mapping and set)

# Generated at 2022-06-22 19:50:11.509102
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for cliargs_deferred_get"""
    global CLIARGS  # pylint: disable=global-statement

    assert cliargs_deferred_get('a', default='a_default')() is 'a_default'
    CLIARGS = CLIArgs({'a': 'a_value'})
    assert cliargs_deferred_get('a', default='a_default')() is 'a_value'
    CLIARGS = GlobalCLIArgs({'a': 'a_value'})
    assert cliargs_deferred_get('a', default='a_default')() is 'a_value'
    assert cliargs_deferred_get('b', default='b_default')() is 'b_default'

# Generated at 2022-06-22 19:50:21.655409
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # test function with 'CLIARGS.get' returning a string
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    assert cliargs_deferred_get('bar', shallowcopy=True)() is None
    assert cliargs_deferred_get('bar', default='baz', shallowcopy=True)() == 'baz'

    # test function with 'CLIARGS.get' return a list
    CLIARGS = CLI

# Generated at 2022-06-22 19:50:33.078920
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Test ``cliargs_deferred_get`` works

    Test the functions return value is bound to CLIARGS
    """
    global CLIARGS

    test_values = {'foo': ['a', 'b'],
                   'bar': 'baz'}
    _init_global_context(test_values)
    assert cliargs_deferred_get('foo')() == ['a', 'b']
    assert cliargs_deferred_get('bar')() == 'baz'
    test_values['foo'].append('c')
    assert cliargs_deferred_get('foo')() == ['a', 'b', 'c']

    # make sure a shallow copy is returned
    result = cliargs_deferred_get('foo', shallowcopy=True)()

# Generated at 2022-06-22 19:50:41.794954
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # we test this function by mocking CLIARGS as an empty dict
    global CLIARGS
    _old_cliargs = CLIARGS
    CLIARGS = {}


# Generated at 2022-06-22 19:50:53.386401
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test closure over getting a key from CLIARGS with shallow copy functionality"""
    global CLIARGS
    # Check that it works with the empty object
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('am_i_in_cli_args')() is None

    # Check that it works before initialization
    # Note: This unit test cannot run in parallel with others because other tests are
    # also setting CLIARGS
    _init_global_context({'am_i_in_cli_args': 'I sure am'})
    assert cliargs_deferred_get('am_i_in_cli_args')() == 'I sure am'
    assert cliargs_deferred_get('am_i_in_cli_args', default='no')() == 'I sure am'
    assert cliargs_

# Generated at 2022-06-22 19:51:01.563770
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # None is the default
    assert cliargs_deferred_get('foo', None)() is None
    # Value gets default
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    # Value gets default
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo2', 'baz')() == 'baz'
    # Shallow copy
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', None, shallowcopy=True)() == 'bar'
    # Shallow copy
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})