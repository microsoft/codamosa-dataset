

# Generated at 2022-06-22 19:41:08.413463
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function returns something
    cli_args = dict(foo='bar')
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo', 'baz') == 'bar'
    assert cliargs_deferred_get('bar', 'baz') == 'baz'
    assert cliargs_deferred_get('baz', 'bar') is None

    # Test that it does a shallow copy
    cli_args = dict(foo=['bar'])
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo', shallowcopy=True) == ['bar']
    cli_args = dict(foo=set(['bar']))
    _init_global_context(cli_args)
    assert cliargs_deferred

# Generated at 2022-06-22 19:41:16.921829
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def run_asserts(key, expected):
        assert cliargs_deferred_get(key, default='not set')() == expected
        assert cliargs_deferred_get(key, default='not set', shallowcopy=True)() == expected

        assert cliargs_deferred_get(key, default='not set')() == expected
        assert cliargs_deferred_get(key, default='not set', shallowcopy=True)() == expected

    cliargs = {'a': 1, 'b': [2], 'c': {'d': 3}}
    _init_global_context(cliargs)
    run_asserts('a', 1)
    run_asserts('b', [2])
    run_asserts('c', {'d': 3})
    run_asserts('d', 'not set')

# Generated at 2022-06-22 19:41:22.402779
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class UnitTestCLIArg:
        def __init__(self):
            self.ansible_facts = {'fact_one': 'fact_one_value'}
            self.ansible_defaults = {'default_one': 'default_one_value'}
            self.ansible_inventory = {'inventory_one': 'inventory_one_value'}
            self.ansible_config = {'config_one': 'config_one_value'}

    cli_args = UnitTestCLIArg()
    _init_global_context(cli_args)

    value = cliargs_deferred_get('ansible_facts', {})
    assert value['fact_one'] == 'fact_one_value'
    value['fact_one'] = 'new_fact_one_value'

# Generated at 2022-06-22 19:41:33.525555
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function ``cliargs_deferred_get``

    This only tests the simplest cases for the sake of simplicity.  See the
    ``test_cliargs_deferred_get.yml`` integration test for more tests
    """
    args = CLIArgs({'foo': 'bar', 'baz': 10})
    get_key = cliargs_deferred_get('foo')
    assert get_key() == 'bar'
    get_key = cliargs_deferred_get('bar')
    assert get_key() is None
    get_key = cliargs_deferred_get('baz')
    assert get_key() == 10
    get_key = cliargs_deferred_get('baz', shallowcopy=True)
    assert get_key() == 10



# Generated at 2022-06-22 19:41:43.658300
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({
        'what': 'ever',
        'wishes': ['granted'],
        'request': {'blah'},
        'to_be': set(),
        })
    for k in ('what', 'wishes', 'request', 'to_be'):
        before = CLIARGS[k]
        getter = cliargs_deferred_get(k, shallowcopy=False)
        after = getter()
        assert before == after
        assert id(before) == id(after)
        before = CLIARGS[k]
        getter = cliargs_deferred_get(k, shallowcopy=True)
        after = getter()
        assert before == after
        assert id(before) != id(after)

# Generated at 2022-06-22 19:41:50.672308
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test case 1
    CLIARGS._data = {'some_key': 'some_value'}
    assert cliargs_deferred_get('some_key')(), 'some_value'

    # Test case 2
    CLIARGS._data = {'some_key': ['a', 'b', 'c']}
    assert cliargs_deferred_get('some_key')(), ['a', 'b', 'c']
    assert cliargs_deferred_get('some_key', shallowcopy=True)(), ['a', 'b', 'c']

    # Test case 3
    CLIARGS._data = {'some_key': {'a': 1, 'b': 2, 'c': 3}}

# Generated at 2022-06-22 19:41:58.289874
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function ``cliargs_deferred_get``"""
    class CliArgs(object):
        def __init__(self):
            self.options = {
                'd': 'default',
                'f': [1, 2, 3],
                'm': {'a': 1, 'b': 2},
                's': {1, 2, 3}
            }

    cli_args = CliArgs()

    #Check that a value from ``cli_args.options`` is returned when not shallowcopied
    assert cliargs_deferred_get('d')(), cli_args.options['d']

    #Check that a shallowcopied value from ``cli_args.options`` is returned when shallowcopied
    assert cliargs_deferred_get('f', shallowcopy=True)() == cli_args.options

# Generated at 2022-06-22 19:42:07.316979
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    assert CLIARGS == CLIArgs({})
    get = cliargs_deferred_get('unfound')
    assert get() is None
    get = cliargs_deferred_get('unfound', default='default')
    assert get() == 'default'
    CLIARGS = CLIArgs({'present': 'simple'})
    get = cliargs_deferred_get('present')
    assert get() == 'simple'
    get = cliargs_deferred_get('present', default='default')
    assert get() == 'simple'

    CLIARGS = CLIArgs({'present': 'simple', 'unfound': None})
    get = cliargs_deferred_get('present')
    assert get() == 'simple'
    get = cliargs_deferred_get('unfound')
   

# Generated at 2022-06-22 19:42:17.422117
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy

    global CLIARGS
    CLIARGS = CLIArgs({})
    assert not cliargs_deferred_get('foo')(), 'got a value from an empty dictionary'
    assert cliargs_deferred_get('foo', default=True)(), 'got no value from an empty dictionary with a default'

    CLIARGS.update(dict(foo=True, bar='bar', baz=[1, 2, 3], bam={'a': 1, 'b': 2}, ban={1, 2, 3}))
    assert cliargs_deferred_get('foo')(), 'got no value from a populated dictionary'
    assert cliargs_deferred_get('baz')(), 'got no value from a populated dictionary'

# Generated at 2022-06-22 19:42:28.061042
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeArgs(object):
        def get(self, key):
            return key
    global CLIARGS
    CLIARGS = FakeArgs()

    assert cliargs_deferred_get('foo')(), 'foo'
    assert cliargs_deferred_get('background')(), 'background'

    # Return a copy of the object
    val = [1, 2, 3]
    assert cliargs_deferred_get('foo', default=val, shallowcopy=True)(), val[:]
    assert cliargs_deferred_get('foo', default=val, shallowcopy=True)(), val[:]

if __name__ == '__main__':
    import sys, pytest
    sys.exit(pytest.main(['-v', __file__]))

# Generated at 2022-06-22 19:42:36.552627
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import defaultdict

    CLIARGS['some_key'] = 'value'
    # Test non-shallow copy
    assert cliargs_deferred_get('some_key')() == 'value'
    assert cliargs_deferred_get('some_key', shallowcopy=True)() == 'value'
    # Test shallow copies
    assert cliargs_deferred_get('some_key', default=[1,2,3])() == [1,2,3]
    assert cliargs_deferred_get('not_existing', default=[1,2,3], shallowcopy=True)() == [1,2,3]

# Generated at 2022-06-22 19:42:46.615124
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs(dict(foo=dict(bar='baz')))
    assert cliargs_deferred_get('foo')() == dict(bar='baz')
    assert cliargs_deferred_get('foo')() == dict(bar='baz')
    assert cliargs_deferred_get('foo', default=dict(this='that'))() == dict(bar='baz')
    assert cliargs_deferred_get('foo', default=dict(this='that'), shallowcopy=True)() == dict(bar='baz')
    assert cliargs_deferred_get('foo', default=dict(this='that'), shallowcopy=False)() == dict(bar='baz')
    assert cliargs_deferred

# Generated at 2022-06-22 19:42:57.929488
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is the most trivial.  The get() method on the CLIArig object
    # will cause a recursion error so we need to test it this way
    from ansible.utils.context_objects import GlobalCLIArgs
    context = GlobalCLIArgs({})
    getter = cliargs_deferred_get('imaginary')
    assert getter() is None

    # test that we get the default
    getter = cliargs_deferred_get('imaginary', default=2)
    assert getter() == 2

    # test that we get the value
    context = GlobalCLIArgs({'imaginary': 42})
    getter = cliargs_deferred_get('imaginary')
    assert getter() == 42

    # test shallow copy

# Generated at 2022-06-22 19:43:07.829606
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert CLIARGS.get('whatever') is None
    assert cliargs_deferred_get('whatever')() is None

    CLIARGS = CLIArgs({'whatever': 'default'})
    assert CLIARGS['whatever'] == 'default'
    assert cliargs_deferred_get('whatever')() == 'default'
    assert cliargs_deferred_get('whatever2')() is None
    assert cliargs_deferred_get('whatever', default='not default')() == 'default'
    assert cliargs_deferred_get('whatever2', default='not default')() == 'not default'

    # Test shallow copy
    CLIARGS = CLIArgs({'whatever': [1, 2, 3]})

# Generated at 2022-06-22 19:43:11.067809
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update(dict(foo=42))
    actual = cliargs_deferred_get('foo')
    assert actual() == 42
    CLIARGS['foo'].append(43)
    assert actual() == [42, 43]

# Generated at 2022-06-22 19:43:20.336751
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence, is_set, is_list, is_dict

    class DummyCliArgs(dict):
        def __init__(self, *args):
            super(DummyCliArgs, self).__init__(*args)
            self.__shallowcopy = False

        def copy(self):
            return self

        @property
        def should_shallowcopy(self):
            return self.__shallowcopy

        @should_shallowcopy.setter
        def should_shallowcopy(self, value):
            self.__shallowcopy = value

    class DummyCliArgsSubclass(DummyCliArgs):
        def copy(self):
            return self

    test_dict = {'foo': 'bar'}

# Generated at 2022-06-22 19:43:30.106030
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test ``cliargs_deferred_get``"""
    cli_args = dict(
        foo=dict(bar=1, baz=2),
        qux = [3, 4],
        quux = set([5, 6]),
        corge=7
    )
    _init_global_context(cli_args)
    assert CLIARGS['foo']['bar'] == 1
    assert CLIARGS['foo']['baz'] == 2
    assert CLIARGS['qux'] == [3, 4]
    assert CLIARGS['quux'] == set([5, 6])
    assert CLIARGS['corge'] == 7

    # Check that the copy version
    cliargs_foo_bar = cliargs_deferred_get('foo', 'bar', shallowcopy=True)
    cliargs_

# Generated at 2022-06-22 19:43:38.337677
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that we can get values from the CLIARGS object when it's not the singleton
    # instance
    cliargs_dict = {'foo': 'bar'}
    global CLIARGS
    CLIARGS = CLIArgs(cliargs_dict)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='quux')() == 'quux'
    # Test that we can get values from the CLIARGS object when it is the singleton
    # instance
    CLIARGS = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred

# Generated at 2022-06-22 19:43:45.445927
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # set up test data
    cli_arg_obj = CLIArgs({'foo': 'bar',
                           'mylist': ['a', 'b', 'c'],
                           'mydict': {'a': 'b', 'c': 'd'},
                           'myset': {'a', 'b', 'c'},
                           'no_copy': 'a'})
    global CLIARGS
    oldcliargs = CLIARGS
    CLIARGS = cli_arg_obj

    # test handling of unset keys
    assert cliargs_deferred_get('missing_key')() is None
    assert cliargs_deferred_get('missing_key', 'xyz')() == 'xyz'

    # test handling of string keys


# Generated at 2022-06-22 19:43:55.475556
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get"""
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.collections import is_sequence
    global CLIARGS
    CLIARGS = CLIArgs({
        'foo': 'bar',
        'baz': ['ab'],
        'quux': Sequence(['a']),
        'quuux': {'a': 1},
        'quuuux': set(['a']),
        'quuuuux': 'a',
    })

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='a')() == 'bar'
    assert cliargs_deferred_get('baz')() == ['ab']


# Generated at 2022-06-22 19:44:05.608854
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    class DummyArgs(object):  # pylint: disable=too-few-public-methods
        def __init__(self, arg_dict):
            self._args = arg_dict

        def __getitem__(self, key):
            try:
                return self._args[key]
            except KeyError:
                raise AttributeError(key)

        def get(self, key, default=None):
            return self._args.get(key, default)

    CLIARGS = DummyArgs(arg_dict=dict(v1=[1, 2, 3], v2=dict(v21=11, v22=22)))

    assert cliargs_deferred_get('v1')() == [1, 2, 3]

# Generated at 2022-06-22 19:44:07.702993
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('ansible_version')() == '2.3'

# Generated at 2022-06-22 19:44:17.915802
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Make sure cliargs_deferred_get gets the right value"""
    global CLIARGS
    CLIARGS = CLIArgs({'ansible_test_key1': 'test_value1',
                       'ansible_test_key2': 'test_value2',
                       'ansible_test_key3': 'test_value3'})
    assert cliargs_deferred_get('ansible_test_key1')() == 'test_value1'
    assert cliargs_deferred_get('ansible_test_key1', default='ansible_test_default1')() == 'test_value1'
    assert cliargs_deferred_get('ansible_test_key2', default='ansible_test_default2')() == 'test_value2'

# Generated at 2022-06-22 19:44:28.206331
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check_value(key, expected, cli_args):
        _init_global_context(cli_args)
        value = cliargs_deferred_get(key)()
        assert value == expected

    # value not set: check default
    cli_args = {}
    check_value('no_def_key', None, cli_args)
    check_value('def_key', 'default_value', cli_args)

    # value set: check value
    cli_args = {'def_key': 'cli_value'}
    check_value('def_key', 'cli_value', cli_args)

    # value set to None: check None
    cli_args = {'def_key': None}
    check_value('def_key', None, cli_args)
    # but

# Generated at 2022-06-22 19:44:38.879551
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FieldAttribute:
        def __init__(self, defaults):
            self.defaults = defaults
        def __get__(self, instance, owner):
            if instance is None:
                return self
            try:
                return cliargs_deferred_get(instance.key, default=self.defaults, shallowcopy=instance.shallowcopy)()
            except TypeError:
                if self.defaults is None:
                    raise AttributeError("Field attribute %s does not exist" % instance.key)
                else:
                    return self.defaults

    class Module:
        def __init__(self, module_name, module_args, key, defaults, shallowcopy=False):
            self.name = module_name
            self.key = key
            self.defaults = defaults
            self.shallowcopy = shallowcopy
           

# Generated at 2022-06-22 19:44:49.246465
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for ``cliargs_deferred_get`` and ``CLIARGS``"""

    CLIARGS.update({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'one': {'two': 2}}})

    for key in CLIARGS:
        # Test that we can get the keys
        assert cliargs_deferred_get(key)() == CLIARGS.get(key)

        # Test defaulted values
        assert cliargs_deferred_get(key, 'hello')() == CLIARGS.get(key, 'hello')
        assert cliargs_deferred_get(key, 'hello', True)() == CLIARGS.get(key, 'hello', True)
        assert cliargs_deferred_get(key, 'hello', False)() == CLIARGS

# Generated at 2022-06-22 19:44:59.818781
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    # Note that this is a dynamic mock.  It is called like a static mock (i.e.
    # foo = MagicMock()) but it is used as a class (i.e. bar = foo())
    class CliArgs:
        """Test class which behaves like CLIARGS"""
        def __init__(self):
            self.default_return_value = None

        def get(self, key, default=None):
            # pylint: disable=arguments-differ,unused-argument
            return self.default_return_value


# Generated at 2022-06-22 19:45:05.938114
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_func():
        return cliargs_deferred_get('action', 'test')

    CLIARGS.options = {'action': 'not_test'}
    assert test_func() == 'not_test'

    CLIARGS.options = {}
    assert test_func() == 'test'


try:
    from ansible.cli.arguments import CLIARGS  # pylint: disable=import-error
except ImportError:
    pass

# Generated at 2022-06-22 19:45:15.212130
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({1: 1, 2: [1, 2]})
    assert cliargs_deferred_get(1)() == 1
    assert cliargs_deferred_get(2)() == [1, 2]
    assert cliargs_deferred_get(3, default=3)() == 3

    # Test shallow copy
    assert cliargs_deferred_get(2, shallowcopy=True)() == [1, 2]
    assert cliargs_deferred_get(2, shallowcopy=True)() is not CLIARGS[2]

# Generated at 2022-06-22 19:45:25.186076
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MockCliArgs(dict):
        def get(self, key, default=None):
            if key == 'list-key':
                return [1, 2, 3]
            elif key == 'dict-key':
                return {'a': 1, 'b': 2, 'c': 3}
            elif key == 'str-key':
                return 'a_str'
            return default

    global CLIARGS
    CLIARGS = MockCliArgs()

    cliargs_deferred_get_list = cliargs_deferred_get('list-key', shallowcopy=True)
    cliargs_deferred_get_dict = cliargs_deferred_get('dict-key', shallowcopy=True)

# Generated at 2022-06-22 19:45:30.940734
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Test that cliargs_deferred_get behaves as expected

    This is a unit test for the function cliargs_deferred_get but is implicitly also a unit test
    for the GlobalCLIArgs object using the namedtuple_factory that is used in production
    """
    #
    # Validate that shallow copy behaves as expected
    #
    expected_list = [1, 2, 3]
    expected_tuple = (1, 2, 3)
    expected_set = {1, 2, 3}
    expected_dict = {1: 1, 2: 2, 3: 3}

    # First verify that when shallow copy is not passed that the original list is returned
    assert id(expected_list) == id(cliargs_deferred_get('some_key', default=expected_list)())

# Generated at 2022-06-22 19:45:36.968945
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the closure created by cliargs_deferred_get"""
    import mock

    global CLIARGS
    with mock.patch('ansible.context.CLIARGS', new=CLIArgs({'test': 3})) as cliargs:
        inner = cliargs_deferred_get('test')
        assert inner() == 3
        cliargs['test'] = 5
        assert inner() == 5

# Generated at 2022-06-22 19:45:45.060857
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'actual_key': 'actual_value'})
    cliargs_func = cliargs_deferred_get('actual_key')
    assert cliargs_func() == 'actual_value'
    cliargs_func = cliargs_deferred_get('missing_key', default='actual_value')
    assert cliargs_func() == 'actual_value'


# this should return a value with a ``copy`` method if the value is mutable
# it must always return the same value when called with the same argument
cliargs_default = cliargs_deferred_get

# Generated at 2022-06-22 19:45:51.264127
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestObject(object):
        pass

    class TestContainer(object):
        pass

    good_str = 'good_str'
    bad_str = 'bad_str'
    good_int = 1
    bad_int = 2
    good_float = 3.0
    bad_float = 4.0
    good_bool = False
    bad_bool = True
    good_obj = TestObject()
    bad_obj = TestObject()
    good_list = [1, 2, 3]
    bad_list = [4, 5, 6]
    good_dict = {'good_key': 1}
    bad_dict = {'bad_key': 2}
    good_set = set([1, 2, 3])
    bad_set = set([4, 5, 6])
    good_container = TestContainer()


# Generated at 2022-06-22 19:46:01.535804
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Create a list with a mutable element to ensure shallow copy is working
    lst = ['test', {'test': 'value'}]
    cli_args = CLIArgs({'key': lst})
    global CLIARGS
    CLIARGS = cli_args

    # Test for dict
    val = cliargs_deferred_get('key', shallowcopy=True)()
    assert val == lst, val
    assert val is not lst, val

    # Test for list
    val = cliargs_deferred_get('key', shallowcopy=False)()
    assert val == lst, val
    assert val is lst, val

    # Test for default
    val = cliargs_deferred_get('bogus', shallowcopy=True)()
    assert val is None, val

    # Test for defaults

# Generated at 2022-06-22 19:46:04.468470
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_args = {'foo': 'bar'}
    _init_global_context(test_args)
    assert cliargs_deferred_get('foo')() == 'bar'

# Generated at 2022-06-22 19:46:11.881246
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.setdefault('a', []).append('alpha')
    CLIARGS.setdefault('a', []).append('beta')
    CLIARGS.setdefault('a', []).append('gamma')
    CLIARGS.setdefault('b', {'a': 'b'})['c'] = 'd'
    CLIARGS.setdefault('s', set()).add('alpha')
    assert cliargs_deferred_get('a') == ['alpha', 'beta', 'gamma']
    assert cliargs_deferred_get('b') == {'a': 'b', 'c': 'd'}
    assert cliargs_deferred_get('s') == set(['alpha'])

    # shallow copies

# Generated at 2022-06-22 19:46:21.970433
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This isn't a full unit test but is testing to make sure that cliargs_deferred_get isn't
    # broken by other modifications to the test code
    from ansible.module_utils.common.collections import get_collection_type
    # Test that the closure returns the correct value
    test_clicloud = {'test': 'value'}
    try:
        # Test that it caches the value
        CLIARGS.setdefault('test', cliargs_deferred_get('test'))
        CLIARGS.update(test_clicloud)
        assert CLIARGS['test'] == 'value'
    finally:
        # Test that it doesn't leak state to other tests
        CLIARGS.pop('test', None)

    # Test that the closure returns the default when no cliargs have been set
    CLI

# Generated at 2022-06-22 19:46:30.067623
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # setup
    global CLIARGS
    old_cliargs = CLIARGS
    CLIARGS = CLIArgs({'A': 'B', 'C': ['d', 'e']})
    # test
    assert 'B' == cliargs_deferred_get('A')()
    assert ['d', 'e'] == cliargs_deferred_get('C', shallowcopy=True)()
    assert 'x' == cliargs_deferred_get('D', 'x')()
    # cleanup
    CLIARGS = old_cliargs

# Generated at 2022-06-22 19:46:38.832864
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from collections import Counter
    CLIARGS.data = {'key': 'value'}
    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('non-existant', shallowcopy=False) is None
    assert cliargs_deferred_get('non-existant', 'default', shallowcopy=False) == 'default'
    assert cliargs_deferred_get('non-existant', default=['default'], shallowcopy=False) == ['default']
    assert cliargs_deferred_get('non-existant', Counter(default=1)) == Counter(default=1)
    CLIARGS.data = {'list': [1, 2, 3]}

# Generated at 2022-06-22 19:46:49.695265
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.module_utils.common.collections as collections

    class FakeArgs(CLIArgs):
        def __init__(self, args):
            super(FakeArgs, self).__init__(args)
            self.opts = args

        def get(self, key, default=None):
            return self.opts.get(key, default)

    # Test not shallow copy
    obj = object()
    args = FakeArgs({'key': obj})
    assert obj is cliargs_deferred_get('key')(), \
        'Object should be returned when shallow copy is false'
    assert obj is cliargs_deferred_get('key', default='test')(), \
        'Object should be returned when shallow copy is false'

# Generated at 2022-06-22 19:46:55.350014
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    _init_global_context({})
    f = cliargs_deferred_get('inventory')
    ans = f()
    assert ans == []

    _init_global_context({'inventory': ['my', 'hosts']})
    f = cliargs_deferred_get('inventory')
    ans = f()
    assert ans == ['my', 'hosts']

# Generated at 2022-06-22 19:47:02.421321
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # _init_global_context() should have been called before this test, so we
    # better not have CLIARGS as a CLIArgs instance
    assert not isinstance(CLIARGS, CLIArgs)

    # First we'll try without accessing the inner() function
    dg1 = cliargs_deferred_get('foo')
    assert dg1.__name__ == 'inner'  # We have the right function
    assert CLIARGS['foo'].__name__ == 'inner'  # We have a reference to the inner function

    # Now we'll access the inner function, which results in the default value
    assert dg1() is None

    # Set the value and access the inner function
    CLIARGS['foo'] = 'bar'
    assert dg1() == 'bar'

    # Now we'll access the inner function with the shallow

# Generated at 2022-06-22 19:47:14.078668
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # A bare-bones circular import so that we can 'import ansible' without
    # importing the whole of ansible when testing the context
    class BareBonesAnsibleModule:
        pass

    ansible = BareBonesAnsibleModule()
    ansible.module_utils = BareBonesAnsibleModule()
    ansible.module_utils.common = BareBonesAnsibleModule()
    ansible.module_utils.common.context_objects = BareBonesAnsibleModule()

    from ansible.module_utils.common.context_objects import CLIArgs
    cliargs = CLIArgs({'foo': 'bar', 'bar': [1, 2, 3], 'baz': {'key': 'value'}})
    get_foo = cliargs_deferred_get('foo')
    get_bar = cliargs

# Generated at 2022-06-22 19:47:24.321184
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # test with different types of value
    for v in [
            {'a': 'b'},
            ['c'],
            'd',
            101,
            None,
    ]:
        assert cliargs_deferred_get(key=v)(key=v) == v
        assert cliargs_deferred_get(shallowcopy=True, key=v, default=v)(key=v, default=v) == v
        assert cliargs_deferred_get(key=v, default=v)(key=v, default=v) == v
        assert cliargs_deferred_get(shallowcopy=True, key=v, default=v)(key=v, default=v) == v

    # default value

# Generated at 2022-06-22 19:47:34.420473
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3]})
    #no copy
    assert cliargs_deferred_get('foo', shallowcopy=False)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=False)() == [1, 2, 3]
    #no copy default
    assert cliargs_deferred_get('foo2', 'bar2', shallowcopy=False)() == 'bar2'
    assert cliargs_deferred_get('baz2', 'bar2', shallowcopy=False)() == 'bar2'
    #shallow copy
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

# Generated at 2022-06-22 19:47:43.159891
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    values = {'foo': 'bar', 'very': {'deep': 'value'}, 'shallow': {'deep': 'value'}, 'singleton': []}
    CLIARGS.update(values)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('very__deep')() == 'value'
    assert cliargs_deferred_get('very__deep__default', default='not_found')() == 'value'
    assert cliargs_deferred_get('not_found__default', default='not_found')() == 'not_found'
    assert cliargs_deferred_get('shallow', shallowcopy=True)() is not values['shallow']

# Generated at 2022-06-22 19:47:53.686185
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('this_is_not_there')() is None
    CLIARGS['test_option'] = 1
    assert cliargs_deferred_get('test_option')() == 1
    assert cliargs_deferred_get('test_option', shallowcopy=True)() == 1
    CLIARGS['test_option'] = 'immutable'
    assert cliargs_deferred_get('test_option')() == 'immutable'
    assert cliargs_deferred_get('test_option', shallowcopy=True)() == 'immutable'
    CLIARGS['test_option'] = ['immutable', 'sequence']
    assert cliargs_deferred_get('test_option')() == ['immutable', 'sequence']

# Generated at 2022-06-22 19:48:02.603034
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({})
    assert cliargs_deferred_get('foo')() is None
    CLIARGS['foo'] = 'foo'
    assert cliargs_deferred_get('foo')() == 'foo'
    assert cliargs_deferred_get('foo', default='bar')() == 'foo'
    assert cliargs_deferred_get('bar', default='bar')() == 'bar'
    cliargs_deferred_get('foo')()
    CLIARGS['mutate'] = ['foo']
    assert cliargs_deferred_get('mutate', shallowcopy=True)() == ['foo']
    orig_value = CLIARGS['mutate']

# Generated at 2022-06-22 19:48:10.425377
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    for cliargs in (CLIARGS, GlobalCLIArgs.from_options({})):
        for thing in (1, False, 'foo', 1.2, [1, 2, 3], {'foo': 'bar'}, {1, 2}):
            assert cliargs_deferred_get(thing, default=thing)() == thing
        assert cliargs_deferred_get(None)() is None
        assert cliargs_deferred_get(None, default=thing)() == thing
        assert cliargs_deferred_get(None, default=thing, shallowcopy=True)() == thing

# Generated at 2022-06-22 19:48:20.148526
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS_test = CLIArgs(dict(foo='bar', no_copy=dict(a=1, b=2, c=3)))
    data = cliargs_deferred_get('foo')()
    assert data == 'bar'
    data = cliargs_deferred_get('no_copy')()
    assert data == {'a': 1, 'b': 2, 'c': 3}
    assert data is CLIARGS_test.get('no_copy')

    data = cliargs_deferred_get('foo', shallowcopy=True)()
    assert data == 'bar'
    data = cliargs_deferred_get('no_copy', shallowcopy=True)()
    assert data == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-22 19:48:28.756720
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_dict = {'foo': 'bar'}
    test_values = [
        ('foo', 'bar'),
        ('boo', None),
        ('fooz', 'boo', False)
    ]
    _init_global_context({'foo': test_dict})

    for (name, default, shallow_copy) in test_values:
        result = cliargs_deferred_get(name, default, shallow_copy)()
        assert result == CLIARGS.get(name, default=default)

    test_dict['foo'] = 'bam'
    assert cliargs_deferred_get('foo', None)() == 'bam'

# Generated at 2022-06-22 19:48:39.917189
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Test function level documentation
    assert cliargs_deferred_get.__doc__

    # Test if it can be used within ``FieldAttribute`` properly
    assert cliargs_deferred_get("foo")() is None
    CLIARGS.update({"foo": "bar"})
    assert cliargs_deferred_get("foo")() == "bar"

    # Test if shallow copy works as expected
    CLIARGS.update({"bar": ["foo", "bar", "baz"]})
    assert cliargs_deferred_get("bar")() == ["foo", "bar", "baz"]
    assert cliargs_deferred_get("bar", shallowcopy=True)() == ["foo", "bar", "baz"]
    assert cliargs_deferred_get("bar", shallowcopy=True)() is not CLI

# Generated at 2022-06-22 19:48:49.914352
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Ensure that the function cliargs_deferred_get works as expected

    This test could use mocks but we don't actually want the cliargs to be parsed
    in unit tests.  Just want to check the logic for getting the values
    """
    args = {'list': [1, 2], 'dict': {'key': 'value'}, 'tuple': (1, 2)}
    global CLIARGS
    CLIARGS = CLIArgs(args)
    assert cliargs_deferred_get('list')() == [1, 2]
    assert cliargs_deferred_get('tuple')() == (1, 2)
    assert cliargs_deferred_get('dict')() == {'key': 'value'}


# Generated at 2022-06-22 19:49:00.178805
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test ``cliargs_deferred_get``"""
    from ansible.utils.context_objects import CliArgs
    cliargs = CliArgs(dict(a='b'))

    def test_get_uncopied(cliargs=cliargs):
        """Test getting an uncopied value"""
        get_a = cliargs_deferred_get('a')
        assert get_a() == 'b'
        assert get_a() is cliargs['a']

    def test_get_copied(cliargs=cliargs):
        """Test getting a copied value"""
        get_a = cliargs_deferred_get('a', shallowcopy=True)
        assert get_a() == 'b'
        assert get_a() is not cliargs['a']


# Generated at 2022-06-22 19:49:11.146442
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""

    # Test basic functionality
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz', default=7)() == 7

    # Test shallow copy
    list_val = [1, 2, 3]
    CLIARGS.update(list_val=list_val)
    list_clone = cliargs_deferred_get('list_val', shallowcopy=True)()
    assert list_clone is not list_val
    assert list_clone == list_val
    list_clone.append(4)
    assert list_val != list_clone

    # Test deep copy

# Generated at 2022-06-22 19:49:18.048361
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(ANSIBLE_SHELL=['/bin/sh'], ANSIBLE_SSH_CONTROL_PATH='/dev/null'))
    assert 'ANSIBLE_SHELL' in CLIARGS
    assert 'ANSIBLE_SSH_CONTROL_PATH' in CLIARGS

    # Test simple lookup
    factory_get_shallow = cliargs_deferred_get('ANSIBLE_SHELL', shallowcopy=True)
    assert factory_get_shallow() == ['/bin/sh']

    factory_get_deep = cliargs_deferred_get('ANSIBLE_SHELL', shallowcopy=False)
    assert factory_get_deep() == ['/bin/sh']

    # Test default

# Generated at 2022-06-22 19:49:29.612159
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-22 19:49:41.048169
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cli_args = {'ANSIBLE_LOG_PATH': 'test_log'}
    _init_global_context(cli_args)
    assert CLIARGS.get('ANSIBLE_LOG_PATH') == 'test_log'
    assert cliargs_deferred_get('ANSIBLE_LOG_PATH', 'default_log')() == 'test_log'
    assert cliargs_deferred_get('ANSIBLE_LOG_PATH2', 'default_log')() == 'default_log'
    cli_args['ANSIBLE_LOG_PATH'] = ['test_log', 'abc']
    assert cliargs_deferred_get('ANSIBLE_LOG_PATH', 'default_log')() == ['test_log', 'abc']

# Generated at 2022-06-22 19:49:52.591928
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with empty
    global CLIARGS
    old_CLIARGS = CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    assert cliargs_deferred_get('foo', default=['bar'])() == ['bar']
    assert cliargs_deferred_get('foo')(shallowcopy=True) is None
    assert cliargs_deferred_get('foo', default=['bar'], shallowcopy=True)() == ['bar']

    # Test with data
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_def

# Generated at 2022-06-22 19:50:00.070007
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    class FakeCliArgs(object):
        fake_cliargs = {}

        @staticmethod
        def get(key, default=None):
            return FakeCliArgs.fake_cliargs.get(key, default)

    _init_global_context(FakeCliArgs)

    assert callable(cliargs_deferred_get('foo'))
    try:
        cliargs_deferred_get('foo')()
    except KeyError:
        pass
    else:
        assert False
    FakeCliArgs.fake_cliargs.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that that we get a shallow copy of mutable objects

# Generated at 2022-06-22 19:50:09.266116
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Ensure that it works when CLIARGS is still a CLIArgs object
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    # Ensure that it works when CLIARGS is a GlobalCLIArgs object
    class test_cliargs:
        def get(self, key, default=None):
            return 'baz'
    global CLIARGS
    past_cliargs = CLIARGS
    CLIARGS = test_cliargs()
    assert cliargs_deferred_get('foo', 'bar')() == 'baz'
    CLIARGS = past_cliargs

# Generated at 2022-06-22 19:50:17.298475
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    orig_cliargs = CLIARGS

# Generated at 2022-06-22 19:50:23.676979
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def list_default_getter():
        return []
    def dictionary_default_getter():
        return {}
    def set_default_getter():
        return set()
    def scalar_default_getter():
        return "1"

    shallowcopy = True
    assert cliargs_deferred_get("not_there", default=list_default_getter(), shallowcopy=shallowcopy)() is None
    assert cliargs_deferred_get("not_there", default=dictionary_default_getter(), shallowcopy=shallowcopy)() is None
    assert cliargs_deferred_get("not_there", default=set_default_getter(), shallowcopy=shallowcopy)() is None

# Generated at 2022-06-22 19:50:32.267453
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    const_value = 'constant'
    global CLIARGS
    result = cliargs_deferred_get('doesntexist', default=const_value)
    assert result() == const_value
    value = {'a' : 'b'}
    CLIARGS = GlobalCLIArgs.from_options({'doesntexist' : value})
    result = cliargs_deferred_get('doesntexist', shallowcopy=True)
    assert result() is not value
    assert result() == value
    result = cliargs_deferred_get('doesntexist', shallowcopy=False)
    assert result() is value

# Generated at 2022-06-22 19:50:41.402572
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def inner(args):
        """Closure for unit tests"""
        def inner2(key, default=None):
            global CLIARGS
            cliargs = CLIArgs(args)
            CLIARGS = cliargs
            value = cliargs_deferred_get(key, default=default)()
            CLIARGS = CLIArgs({})
            return value
        return inner2
    # Test non-copy
    assert inner(dict(a=dict(b=1)))('a', default={}) == dict(b=1)
    # Test non-copy with default
    assert inner(dict(a=dict(b=1)))('b', default={}) == {}
    # Test non-copy with default, no set key
    assert inner(dict(a=dict(b=1)))('c', default={}) == {}

# Generated at 2022-06-22 19:50:48.257251
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS

    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'zot': set([1, 2, 3])})

    assert cliargs_deferred_get('foo')(), 'bar'
    assert not cliargs_deferred_get('bar')(), None

    assert cliargs_deferred_get('baz', shallowcopy=True)(), [1, 2, 3]
    assert cliargs_deferred_get('baz')(), [1, 2, 3]

    assert cliargs_deferred_get('qux', shallowcopy=True)(), {'a': 1, 'b': 2}
    assert cli

# Generated at 2022-06-22 19:50:55.907723
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = [1, 2, 3]
    assert cliargs_deferred_get('foo') == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True) == [1, 2, 3]
    CLIARGS['foo'] = {'bar': 'baz'}
    assert cliargs_deferred_get('foo') == {'bar': 'baz'}
    assert cliargs_deferred_get('foo', shallowcopy=True) == {'bar': 'baz'}

    from ansible.module_utils.common._collections_compat import Set
    CLIARGS['foo'] = Set(['bar', 'baz'])
    assert cliargs_deferred_get('foo') == Set(['bar', 'baz'])


# Generated at 2022-06-22 19:51:02.669101
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from .common import AnsibleExitJson, AnsibleFailJson
    from .common import CLICommonArgParser
    from ansible.module_utils._text import to_native
    # Use a copy of the existing module_utils.common.args.MODULE_ARGS
    # so we don't accidentally mutate it
    from ansible.module_utils.common.args import MODULE_ARGS as M_ARGS
    cli_args = M_ARGS.copy()