

# Generated at 2022-06-22 19:41:08.344344
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def reset_globals():
        global CLIARGS
        CLIARGS = CLIArgs({})

    # test that the inner function returns the correct value
    reset_globals()
    CLIARGS.add({'foo': ['bar']})
    func = cliargs_deferred_get('foo')
    assert func() == ['bar']

    # test that the inner function correctly performs a shallow copy
    reset_globals()
    CLIARGS.add({'foo': ['bar']})
    func = cliargs_deferred_get('foo', shallowcopy=True)
    tmp = func()
    assert tmp == ['bar']
    tmp.append('baz')
    assert func() == ['bar']

    # test that the inner function correctly performs a shallow copy for
    # non-sequence types
    reset_globals

# Generated at 2022-06-22 19:41:16.858282
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CliArgs(object):
        def get(self, key, default=None):
            return {'one': 1, 'two': [1, 2], 'three': {'one': 1}}.get(key, default)

    # No copy
    global CLIARGS
    CLIARGS = CliArgs()
    assert cliargs_deferred_get('one')() == 1
    assert cliargs_deferred_get('two')() == [1, 2]
    assert cliargs_deferred_get('three')() == {'one': 1}

    # Make a copy
    assert cliargs_deferred_get('one', shallowcopy=True)() == 1
    assert cliargs_deferred_get('two', shallowcopy=True)() == [1, 2]
    assert cliargs_deferred_

# Generated at 2022-06-22 19:41:22.367280
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    context = {
        'a': 1,
        'b': 2,
        'c': [1, 2],
        'd': {'foo': 3},
        'e': set(),
        'f': (1, 2),
        'g': [],
        'h': {},
    }
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options(context)
    for key, value in context.items():
        if is_sequence(value):
            if value:
                assert cliargs_deferred_get(key)() is value, 'Deepcopy failed in cliargs_deferred_get'

# Generated at 2022-06-22 19:41:33.482351
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Make sure that deferred_cliargs_get returns the right values

    Should test the following:

    - Return of the default value
    - Return of the actual value
    - Return of the shallow copied value
    - Return of the shallow copied dict
    - Return of the shallow copied list
    - Return of the shallow copied int and string
    - Test that we can still get field attributes after the context has been initialized
    - Test that we can still get field attributes after the context has been replaced
    """
    import pytest

    @pytest.fixture(scope='function')
    def cliargs(request):
        orig_cliargs = CLIARGS
        cliargs = CLIArgs({'key' : 'value'})
        CLIARGS = cliargs
        def fin():
            CLIARGS = orig_cliargs

# Generated at 2022-06-22 19:41:44.299913
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for function cliargs_deferred_get"""
    global CLIARGS

    # The closure cannot be called until CLIARGS has been set
    def _inner_value():
        return list(CLIARGS.items())

    # Test that it works as a singleton closure
    cli_args = {'test': 'value'}
    _init_global_context(cli_args)
    cliargs_deferred_get('test')() == 'value'
    assert _inner_value() == list(cli_args.items())

    # Test that it works as a everytime closure
    def everytime_value():
        return list(CLIARGS.items())

    cli_args = {'test': 'value'}
    _init_global_context(cli_args)
    value = cliargs_

# Generated at 2022-06-22 19:41:54.392101
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from unittest import mock

    cliargs = {'a': 'b',}
    cliargs_get = mock.Mock()
    cliargs_get.return_value = 'c'
    with mock.patch('ansible.context.CLIARGS', cliargs):
        c1 = cliargs_deferred_get('c', default='d')
        c2 = cliargs_deferred_get('a')
        c3 = cliargs_deferred_get('b', default='e')
        c4 = cliargs_deferred_get('a', shallowcopy=True)
        c5 = cliargs_deferred_get('b', shallowcopy=True)

    assert c1() == 'd'
    assert c2() == 'b'
    assert c3() == 'e'


# Generated at 2022-06-22 19:42:04.634957
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""

    # Create the dummy CLIARGS object
    class TestCLIArgs(object):
        def __init__(self, init_dict):
            self._data = init_dict

        def get(self, key, default=None):
            return self._data.get(key, default)

        def __getitem__(self, key):
            return self._data[key]

    # Test the default value when key not found
    global CLIARGS
    CLIARGS = TestCLIArgs({})
    value = cliargs_deferred_get('one')()
    assert value == None, 'Default value not returned'

    # Test the default value when key not found but default provided
    global CLIARGS
    CLIARGS = TestCLIArgs({})
    value = cli

# Generated at 2022-06-22 19:42:15.123414
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""

    # pylint:disable=protected-access
    #
    # We are setting up the CliArgs object and then checking its value.  This is an
    # internal bit and we're unit testing that object so it's fine to access protected
    # attributes

    import pytest

    # Pretend we have parsed all the CLI args
    _init_global_context({'ANSIBLE_JINJA2_NATIVE': True})

    # Test closure over the value
    assert cliargs_deferred_get('ANSIBLE_JINJA2_NATIVE')()

    # Test closure with a default
    assert cliargs_deferred_get('ANSIBLE_BAR', default=True)()

    # Test closure with a non-existent key and a default
    assert not cliargs_

# Generated at 2022-06-22 19:42:23.817238
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS.ABC = 'abc'
    assert cliargs_deferred_get('ABC') == 'abc'

    CLIARGS.LIST = ['abc']
    assert cliargs_deferred_get('LIST') == ['abc']
    assert cliargs_deferred_get('LIST', shallowcopy=True) == ['abc']

    CLIARGS.DICT = {'abc': 'abc'}
    assert cliargs_deferred_get('DICT') == {'abc': 'abc'}
    assert cliargs_deferred_get('DICT', shallowcopy=True) == {'abc': 'abc'}

    CLIARGS.SET = set('abc')
    assert cliargs_deferred_get('SET') == set('abc')

# Generated at 2022-06-22 19:42:25.221255
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get('a', default='b')

# Generated at 2022-06-22 19:42:30.398971
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS.data = {'boolean_opt': True, 'array_opt': [1, 2, 3]}
    assert cliargs_deferred_get('boolean_opt')()
    assert cliargs_deferred_get('array_opt')(shallowcopy=True) == [1, 2, 3]
    CLIARGS = CLIArgs({'boolean_opt': False})
    assert not cliargs_deferred_get('boolean_opt')()

# Generated at 2022-06-22 19:42:37.361796
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    val = {'foo': 'bar'}
    CLIARGS.set('foo', val)

    get_foo = cliargs_deferred_get('foo')
    assert val is get_foo()

    get_bar = cliargs_deferred_get('bar', default='bar')
    assert 'bar' == get_bar()

    val = ['foo', 'bar']
    CLIARGS.set('foo', val)
    get_foo = cliargs_deferred_get('foo', shallowcopy=True)
    assert val is not get_foo()
    assert val == get_foo()
    # Weakly test that it doesn't copy something that doesn't need a copy
    get_bar = cliargs_deferred_get('bar', default='bar', shallowcopy=True)
    assert 'bar' == get_bar()

# Generated at 2022-06-22 19:42:47.961842
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # stub cliargs as a dictionary
    global CLIARGS
    CLIARGS = {'key1': 'payload1', 'key2': ['payload2a', 'payload2b']}
    assert cliargs_deferred_get('key1')() == 'payload1'
    assert cliargs_deferred_get('key2')() == ['payload2a', 'payload2b']
    assert cliargs_deferred_get('key3')() is None
    assert cliargs_deferred_get('key1', default='default1')() == 'payload1'
    assert cliargs_deferred_get('key3', default='default3')() == 'default3'

# Generated at 2022-06-22 19:42:58.519744
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Unit test for function cliargs_deferred_get

    These tests use a mock CLI object to ensure that the function works properly with
    the global cli obj being replaced after initialization
    """

    from ansible.module_utils._text import to_text
    from unittest.mock import Mock, patch

    # Create a dummy cli argument object
    cli_args = Mock()
    cli_args.test_arg_1 = 'foo'
    cli_args.test_arg_2 = [1, 2, 3]
    cli_args.test_arg_3 = {'a': 1, 'b': 2, 'c': 3}

    # Create a GlobalCLIArgs
    global_args = GlobalCLIArgs.from_options(cli_args)

    # Create a closure to get the arg with


# Generated at 2022-06-22 19:43:09.209433
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs()
    cliargs['foo'] = 'bar'
    cliargs['bar'] = [1, 2, 3]
    cliargs['baz'] = {'qux': True}

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() == [1, 2, 3]
    assert cliargs_deferred_get('baz')() == {'qux': True}

    cliargs['bar'].append(4)
    assert cliargs_deferred_get('bar', shallowcopy=True)() == [1, 2, 3, 4]
    assert cliargs_deferred_get('baz', shallowcopy=True)() == {'qux': True}

# Generated at 2022-06-22 19:43:18.108484
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({'foo': 42})
    assert cliargs_deferred_get('foo')() == 42
    CLIARGS = None
    assert cliargs_deferred_get('foo')('default') == 'default'

    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]


# Generated at 2022-06-22 19:43:29.531006
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update(dict(foo='bar'))
    assert 'bar' == cliargs_deferred_get('foo')()
    assert 'bar' != cliargs_deferred_get('foo')()
    # test shallowcopy
    CLIARGS.update(dict(foo=['bar', 'baz']))
    assert 'bar' == cliargs_deferred_get('foo')()[0]
    assert 'baz' == cliargs_deferred_get('foo')()[1]
    assert 'bar' == cliargs_deferred_get('foo', shallowcopy=True)()[0]
    assert 'baz' == cliargs_deferred_get('foo', shallowcopy=True)()[1]

# Generated at 2022-06-22 19:43:37.821046
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='default')() == 'bar'
    assert cliargs_deferred_get('baz', default='default')() == 'default'
    assert cliargs_deferred_get('baz', default=42)() == 42

    CLIARGS['baz'] = [1, 2, 3]
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('baz', default=[1, 2, 3])() is not [1, 2, 3]
    # shallow copy is True by default
    assert cliargs_

# Generated at 2022-06-22 19:43:44.967212
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for function cliargs_deferred_get"""
    global CLIARGS

    CLIARGS = CLIArgs({'foo': 'Hello'})
    expected = 'Hello'
    result = cliargs_deferred_get('foo')()
    assert result == expected

    CLIARGS = CLIArgs({'foo': 'Hello'})
    expected = 'default'
    result = cliargs_deferred_get('bar', 'default')()
    assert result == expected

    CLIARGS = CLIArgs({'foo': [1, 2]})
    expected = [1, 2]
    result = cliargs_deferred_get('foo')()
    assert result == expected

    CLIARGS = CLIArgs({'foo': [1, 2]})
    expected = [1, 2]
    result = cliargs_def

# Generated at 2022-06-22 19:43:55.230153
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for cliargs_deferred_get"""
    original_value = {"foo": "bar"}
    original_set = {'foo', 'bar', 'baz'}
    CLIARGS.update({'original_value': original_value, 'original_list': [1, 2, 3], 'original_tuple': (4, 5, 6), 'original_set': original_set})

    # Test non-shallow copy
    assert cliargs_deferred_get('original_value')() is original_value
    assert cliargs_deferred_get('original_list')() is not [1, 2, 3]
    assert cliargs_deferred_get('original_tuple')() is not (4, 5, 6)
    assert cliargs_deferred_get('original_set')() is not original_

# Generated at 2022-06-22 19:44:05.032524
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy

    def check_copy(key, value):
        inner = cliargs_deferred_get(key, value)
        cli_value = inner()
        value_copy = copy.copy(value)
        assert cli_value is not value
        assert cli_value == value_copy

    from ansible.module_utils.common.text.converters import to_bytes

    class CLIArgs(object):
        def get(self, key, default=None):
            if key == 'val':
                return [1, 2, 3]
            elif key == 'str':
                return to_bytes('some string')
            elif key == 'dict':
                return {'k1': 'v1', 'k2': 'v2'}
            else:
                return default

    global CLIARGS
    previous

# Generated at 2022-06-22 19:44:15.901534
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Simple value
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert 'bar' == cliargs_deferred_get('foo')()

    # Copy value
    global CLIARGS
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert [1, 2, 3] != cliargs_deferred_get('foo', shallowcopy=True)()

    # Copy value
    global CLIARGS
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert [1, 2, 3] == cliargs_deferred_get('foo', shallowcopy=True)()

    # Default value
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert 'bar' == cliargs_deferred_get

# Generated at 2022-06-22 19:44:26.032985
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCliArgs(GlobalCLIArgs):
        def __init__(self, data):
            self.mapping = data

    test_cliargs = TestCliArgs({'foo': 'bar', 'baz': [1, 2, 3], 'quux': {'a': 1, 'b': 2}, 'waldo': set('abcd')})

    # If we don't shadow CLIARGS anywhere we should get no err
    _init_global_context(test_cliargs)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('quux')() == {'a': 1, 'b': 2}

# Generated at 2022-06-22 19:44:32.793086
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the non-shallowcopy case
    cli_args = {'one': "one", 'two': "two", 'three': [1, 2, 3]}
    CLIARGS = CLIArgs(cli_args)
    assert cliargs_deferred_get('two')() == "two"
    assert cliargs_deferred_get('two', default="nothing")() == "two"
    assert cliargs_deferred_get('five', default="nothing")() == "nothing"
    assert cliargs_deferred_get('five')() is None
    assert cliargs_deferred_get('three', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('two', shallowcopy=True)() == "two"
    # Test the shallowcopy case.  Need to

# Generated at 2022-06-22 19:44:40.855253
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_closure(val, shallowcopy):
        cli_args = CLIArgs({'foo': val})
        global CLIARGS
        CLIARGS = cli_args
        return cliargs_deferred_get('foo', shallowcopy=shallowcopy)

    assert test_closure([1, 2, 3], False)() == [1, 2, 3]
    assert test_closure([1, 2, 3], True)() == [1, 2, 3]
    assert test_closure((1, 2, 3), False)() == (1, 2, 3)
    assert test_closure((1, 2, 3), True)() == (1, 2, 3)
    # String is immutable so shallow copy doesn't copy the string
    assert test_closure('str', False)() == 'str'

# Generated at 2022-06-22 19:44:51.024210
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # set up a fake global CLIARGS
    d = {'foo': 'bar', 'bar': 'baz'}
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options(d)
    # Test the default
    default_callback = cliargs_deferred_get('nonexistent')
    assert default_callback() is None
    # Test the no-copy
    callback_no_copy = cliargs_deferred_get('foo')
    assert callback_no_copy() is CLIARGS.get('foo')
    # Test the shallowcopy
    callback_copy = cliargs_deferred_get('bar', default='default_value', shallowcopy=True)
    assert callback_copy() is not CLIARGS.get('bar')
    assert callback_copy() == CLIARGS['bar']
   

# Generated at 2022-06-22 19:44:58.745283
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test when cliargs are not yet initialized
    global CLIARGS
    old = CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('test')() is None
    # Test when cliargs are initialized
    CLIARGS = CLIArgs({'test': True})
    assert cliargs_deferred_get('test')() is True
    CLIARGS.test = False
    assert cliargs_deferred_get('test')() is False
    CLIARGS = old

# Generated at 2022-06-22 19:45:08.146282
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Try a shallow, non-copyable value
    cliargs = CLIArgs({'foo': 'bar'})
    value = cliargs_deferred_get('foo', shallowcopy=True)
    assert value() == 'bar'

    # Try a shallow, copyable value
    cliargs = CLIArgs({'foo': [1, 2, 3]})
    value = cliargs_deferred_get('foo', shallowcopy=True)
    assert value() == [1, 2, 3]

    # Try a deep, non-copyable value
    cliargs = CLIArgs({'foo': 'bar'})
    value = cliargs_deferred_get('foo', shallowcopy=False)
    assert value() == 'bar'

    # Try a deep, copyable value

# Generated at 2022-06-22 19:45:16.190714
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This can be called with CLIARGS not set, so do a null op
    assert cliargs_deferred_get('fake_key', 'default_value')() == 'default_value'

    # This will fail if the function is not binding correctly
    global CLIARGS
    CLIARGS = CLIArgs({'key': 'value'})
    assert cliargs_deferred_get('key')(), 'value'

    # This will fail if the function is not binding correctly
    CLIARGS = CLIArgs({'key': 'new_value'})
    assert cliargs_deferred_get('key')(), 'new_value'

# Generated at 2022-06-22 19:45:22.600401
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'hello': 'world', 'answer': 42})

    assert cliargs_deferred_get('answer') == 42
    assert cliargs_deferred_get('answer', default=7) == 42
    assert cliargs_deferred_get('question', default='life') == 'life'

    assert cliargs_deferred_get('answer', shallowcopy=True) == 42
    assert cliargs_deferred_get('answer', shallowcopy=False) == 42

# Generated at 2022-06-22 19:45:29.710359
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import UserDict
    import copy

    class TestCLIArgs(UserDict):
        pass

    cli_args = CLIARGS.copy()
    cli_args_list = [1, 2, 3]
    cli_args_dict = {'a': 1, 'b': 2, 'c': 3}
    cli_args['list'] = cli_args_list
    cli_args['dict'] = cli_args_dict
    cli_args['string'] = "string"
    cli_args['int'] = 1
    cli_args['float'] = 1.0

    # String
    assert cliargs_deferred_get('string')() == 'string'

# Generated at 2022-06-22 19:45:34.275031
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(verbosity=3, inventory='/path/to/inventory'))
    verbosity = cliargs_deferred_get('verbosity')
    assert verbosity() == 3
    inventory = cliargs_deferred_get('inventory', shallowcopy=True)
    assert inventory() == '/path/to/inventory'

# Generated at 2022-06-22 19:45:41.495417
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Note, this is not the singleton version.  The singleton is only created
    # once the program has actually parsed the args
    CLIARGS = CLIArgs({})
    f = cliargs_deferred_get('test_key')
    assert f() is None, "f() before CLIARGS are set should be None"
    CLIARGS = CLIArgs({'test_key': 'test value'})
    assert f() == 'test value', "f() after CLIARGS is set"

# Generated at 2022-06-22 19:45:49.804172
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cli_args = {'total_processes':1, 'inventory': ['/some/inventory'], 'vault_password_files':['foo']}
    cli_args_clone = dict(cli_args)
    _init_global_context(cli_args)
    assert cliargs_deferred_get('total_processes')() == cli_args['total_processes']
    assert cliargs_deferred_get('vault_password_files', shallowcopy=True)() == cli_args['vault_password_files']
    cli_args.pop('vault_password_files')
    assert cliargs_deferred_get('vault_password_files', shallowcopy=True)() == []

# Generated at 2022-06-22 19:45:57.653531
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test usage of ``cliargs_deferred_get``

    Very simple unit test.  Only tests for default and for existing keys.  Does shallow copy
    of value.
    """
    global CLIARGS
    # Test for default value
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('key')() == None

    # Test for existing value
    CLIARGS = CLIArgs({'key': 'value'})
    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('key', default='other')() == 'value'

    # Test shallow copy of value
    value = {'key' : 'value'}
    CLIARGS = CLIArgs({'key': value})

# Generated at 2022-06-22 19:46:02.596022
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Foo():
        bar = cliargs_deferred_get('bar')

    args = {'bar': [1, 2]}
    _init_global_context(args)
    foo = Foo()
    assert foo.bar == args['bar']

    # Test that shallow copies work
    foo.bar.append(3)
    assert foo.bar == args['bar']

    # Test that specifying no shallow copy makes the same object
    assert Foo.bar == args['bar']



# Generated at 2022-06-22 19:46:08.000767
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    data = dict(foo=dict(bar=5))
    _init_global_context(data)
    assert cliargs_deferred_get('foo')() == dict(bar=5)
    assert cliargs_deferred_get('foo', shallowcopy=True)() == dict(bar=5)
    assert cliargs_deferred_get('foo')() is CLIARGS.get('foo')

# Generated at 2022-06-22 19:46:15.091267
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _init_global_context(cli_args):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    class _Noop(object):
        def __init__(self):
            self.called = 0

        def __call__(self):
            self.called += 1

    options = dict(
        list=[1, 2, 3, 4],
        dict={'1': '2', '3': 4, '5': [1, 2, '3']},
        set={'1', '2', '3'},
    )
    # default, no key
    getter = cliargs_deferred_get('default', default=_Noop())
    getter()
    assert getter.called == 1
    # default, with key
    getter = cliargs

# Generated at 2022-06-22 19:46:23.913222
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    v = CLIARGS.get('--foo', default=1)
    assert v == 1
    CLIARGS['--foo'] = 10
    v = CLIARGS.get('--foo', default=1)
    assert v == 10
    assert cliargs_deferred_get('--foo', default=1)() == 10
    assert cliargs_deferred_get('--foo', default=1, shallowcopy=True)() == 10
    l = [1,2,3]
    CLIARGS['--foo'] = l
    assert cliargs_deferred_get('--foo', default=1, shallowcopy=True)() == l
    assert cliargs_deferred_get('--foo', default=1, shallowcopy=True)() is not l
    d = {1:2}
   

# Generated at 2022-06-22 19:46:33.778024
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Opts(object):
        FOO_DEFAULT = cliargs_deferred_get('foo')
        BAR_DEFAULT = cliargs_deferred_get('bar')

    global CLIARGS
    CLIARGS = CLIArgs({'foo': ['A'], 'bar': ['B']})
    opts = Opts()
    assert opts.FOO_DEFAULT == ['A']
    assert opts.BAR_DEFAULT == ['B']
    CLIARGS = CLIArgs({'foo': ['C'], 'bar': ['D']})
    assert opts.FOO_DEFAULT == ['C']
    assert opts.BAR_DEFAULT == ['D']
    del CLIARGS
    CLIARGS = CLIArgs({'foo': ['E'], 'bar': ['F']})

# Generated at 2022-06-22 19:46:41.193561
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Check that cliargs_deferred_get creates closures that can be used to get attributes later"""
    _init_global_context({'key1': 'abc'})
    assert cliargs_deferred_get('key1')() == 'abc'
    assert cliargs_deferred_get('key2', 'def')() == 'def'
    assert cliargs_deferred_get('key1', shallowcopy=True)() == 'abc'
    assert cliargs_deferred_get('key1', shallowcopy=True)() is not cliargs_deferred_get('key1', shallowcopy=True)()
    # test shallow copies of sequences
    s = ['abc']
    _init_global_context({'key1': s})
    assert cliargs_deferred_get('key1')() == s
   

# Generated at 2022-06-22 19:46:51.796771
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = GlobalCLIArgs({"a": 1, "b": [1, 2, 3], "c": {"d": 1}})
    foo = cliargs_deferred_get("a")
    assert foo() == 1

    foo = cliargs_deferred_get("c", default=None, shallowcopy=True)
    assert foo() == {"d": 1}
    assert foo() is not CLIARGS["c"]

    foo = cliargs_deferred_get("c", default=None, shallowcopy=False)
    assert foo() == CLIARGS["c"]

    foo = cliargs_deferred_get("d", default={"e": 1})
    assert foo() == {"e": 1}
    assert foo() is not CLIARGS.get("d", {"e": 1})

# Generated at 2022-06-22 19:47:00.555040
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.unsafe_proxy import wrap_var
    global CLIARGS

    test_args = {'list': ['foo', 'bar'],
                 'dict': {'foo': 'bar'},
                 'set': {'foo', 'bar'},
                 'int': 123}
    CLIARGS = GlobalCLIArgs.from_options(wrap_var(test_args))

    getter = cliargs_deferred_get('does_not_exist')
    assert getter() is None

    getter = cliargs_deferred_get('does_not_exist', 'default')
    assert getter() == 'default'

    getter = cliargs_deferred_get('list')

# Generated at 2022-06-22 19:47:12.169654
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeCliArgs(object):
        def get(self, key, default=None):
            return {'string': 'string',
                    'list': ['string'],
                    'set': set(),
                    'dict': {'key': 'val'},
                    }.get(key, default)

    import types

    test_cliargs = FakeCliArgs()
    cliargs = CLIARGS.__class__.from_options(test_cliargs)
    test_cliargs.get = types.MethodType(cliargs.get, test_cliargs)

    # Test basic functionality
    assert 'string' == cliargs_deferred_get('string')()
    assert None == cliargs_deferred_get('not_present')()

# Generated at 2022-06-22 19:47:20.673224
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make sure that we don't accidentally copy the values by default
    class Foo(object):
        _orig_list = []
        _list = cliargs_deferred_get('foo')

        _orig_dict = {}
        _dict = cliargs_deferred_get('bar')

        _orig_set = set()
        _set = cliargs_deferred_get('foobar')

        def init(self):
            self._orig_list.append(self)
            self._orig_dict[self] = self
            self._orig_set.add(self)

    foo = Foo()
    foo.init()
    assert len(foo._orig_list) == 1
    assert len(foo._orig_dict) == 1
    assert len(foo._orig_set) == 1

    # Make sure that we do shallowcopy

# Generated at 2022-06-22 19:47:30.946623
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test: Simple Types
    cliargs = {'foo': 2}
    _init_global_context(cliargs)
    assert cliargs_deferred_get('foo')(), cliargs['foo']
    assert cliargs_deferred_get('bar')(), None

    # Test: Sequence types
    cliargs = {'foo': [2]}
    _init_global_context(cliargs)
    assert cliargs_deferred_get('foo')(), cliargs['foo']
    assert cliargs_deferred_get('foo', shallowcopy=True)(), cliargs['foo'][:]
    assert cliargs_deferred_get('bar')(), None
    assert cliargs_deferred_get('bar', shallowcopy=True)(), None

    # Test: Mapping types
   

# Generated at 2022-06-22 19:47:40.260923
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'test': 'one'})
    def_get = cliargs_deferred_get('test')
    assert def_get() == 'one'
    def_get2 = cliargs_deferred_get('test')
    assert def_get2() == 'one'

    CLIARGS = CLIArgs({'test': 'two'})
    assert def_get() == 'two'
    assert def_get2() == 'two'

    def_get = cliargs_deferred_get('other')
    CLIARGS = CLIArgs({'other': 'three'})
    assert def_get() == 'three'

    def_get = cliargs_deferred_get('other', default='four')
    assert def_get() == 'three'
    def_get

# Generated at 2022-06-22 19:47:49.760640
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': ['bar']})

    # If the cli args are not set, get the default
    assert cliargs_deferred_get('baz', default='spam') == 'spam'

    # If the cli args are set, get the value
    assert cliargs_deferred_get('foo', default='bar') == ['bar']

    # Shallowcopy works on lists
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True) == ['bar']

    # Shallowcopy works on dicts
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True) == {'bar': 'baz'}



# Generated at 2022-06-22 19:48:00.151162
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pragma: no cover
    def assert_cliargs_deferred_get(key, expected, **kwargs):
        """Check the output of cliargs_deferred_get"""
        result = cliargs_deferred_get(key, **kwargs)()
        assert result is expected, "Expected value of cliargs_deferred_get({!r}, **{!r}) to be {!r} but got {!r}".format(key, kwargs, expected, result)

    # Check that cliargs_deferred_get works in simple cases
    global CLIARGS
    CLIARGS = CLIArgs({'key1': 1, 'key2': 'a'})
    assert_cliargs_deferred_get('key1', 1, shallowcopy=False)

# Generated at 2022-06-22 19:48:07.717063
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import AnsibleContextObject
    cli_args = AnsibleContextObject({'foo': 1, 'bar': [1, 2, 3], 'baz': {'abc': 123, 'def': 456}})
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 1
    assert cliargs_deferred_get('bar')() == [1, 2, 3]
    assert cliargs_deferred_get('baz')() == {'abc': 123, 'def': 456}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 1
    assert cliargs_deferred_get('bar', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_def

# Generated at 2022-06-22 19:48:15.402089
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(None)() is None
    assert cliargs_deferred_get('null', None)() is None
    assert cliargs_deferred_get('not_found', 42)() == 42
    assert cliargs_deferred_get('none')() is None
    assert cliargs_deferred_get('bool_true')()
    assert not cliargs_deferred_get('bool_false')()
    assert cliargs_deferred_get('list')() == [42, 'not_found']
    assert cliargs_deferred_get('list')() is not cliargs_deferred_get('list')()
    assert cliargs_deferred_get('list', shallowcopy=True)() == [42, 'not_found']
    assert cliargs_deferred

# Generated at 2022-06-22 19:48:23.447624
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs
    cliargs = CliArgs({'foo': 'bar', 'seq': [1, 2, 3], 'map': {'1': 'one', '2': 'two'}, 'set': set([1, 2, 3])})

    # Test we can access the value via the function
    assert cliargs.get('foo') == cliargs_deferred_get('foo', default=None)(),\
        'deferred_get should return the same value as cliargs.get does'

    # Test that the function returns a shallow copy of the value
    for key in ('seq', 'map', 'set'):
        value = cliargs_deferred_get(key, shallowcopy=True)()
        # Modify the value and make sure cliargs doesn't change
        value

# Generated at 2022-06-22 19:48:30.686054
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects.cliargs import cliargs_deferred_get as cliargs_deferred_get_orig
    import copy

    CLIARGS_orig = CLIARGS
    CLIARGS = CLIArgs()

    def assert_get(key, expected, shallowcopy=False):
        expected = copy.deepcopy(expected)
        func = cliargs_deferred_get(key, shallowcopy=shallowcopy)
        value = func()
        assert value == expected, '{} != {}'.format(value, expected)
        if shallowcopy and isinstance(expected, Mapping):
            # Modify the copy and make sure the original remains unchanged
            value['copy'] = True
            assert CLIARGS.get(key).get('copy') is None

    # Test basic get

# Generated at 2022-06-22 19:48:41.099537
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    val_1 = {"a": "b", "c": "d"}
    val_2 = {"a": "b", "c": "d"}
    test_dict = {"foo": val_1, "bar": val_2}
    CLIARGS.clear()
    CLIARGS.update(test_dict)
    assert cliargs_deferred_get("foo", default="default_value")() == val_1
    assert cliargs_deferred_get("foo", default="default_value", shallowcopy=True)() != val_1
    assert cliargs_deferred_get("bar", default="default_value")() == val_2
    assert cliargs_deferred_get("bar", default="default_value", shallowcopy=True)() != val_2

# Generated at 2022-06-22 19:48:50.823949
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'bam': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    foo = cliargs_deferred_get('foo')()
    assert foo == 'bar'
    assert foo is CLIARGS.foo
    bam = cliargs_deferred_get('bam', shallowcopy=True)()
    assert bam == {'a': 1, 'b': 2}
    assert bam is not CLIARGS.bam
    zot = cliargs_deferred_get('zot', default='zoink')()
    assert zot == 'zoink'
    assert zot is not CLI

# Generated at 2022-06-22 19:49:00.037699
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeCLIArgs(dict):
        def get(self, key, default=None):
            return dict.get(self, key, default)

    fake_cliargs = FakeCLIArgs()
    # Replace ``CLIARGS`` with fake version
    old_cliargs = CLIARGS
    CLIARGS = fake_cliargs

    closure = cliargs_deferred_get('key')
    assert closure.__closure__[0].cell_contents is CLIARGS
    assert closure() is None

    fake_cliargs['key'] = 'value'
    assert closure() == 'value'

    # Restore global ``CLIARGS``
    CLIARGS = old_cliargs

# Generated at 2022-06-22 19:49:10.938572
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})

    inner = cliargs_deferred_get('a')
    assert inner() is None, 'Expect default to be returned'

    CLIARGS['a'] = 'b'
    CLIARGS['c'] = [1, 2, 3]
    CLIARGS['d'] = {'a': 1, 'b': 2}
    CLIARGS['e'] = {1, 2, 3}
    inner = cliargs_deferred_get('a')
    assert inner() == 'b', 'Expect to get back what was set'
    inner = cliargs_deferred_get('c')
    assert inner() == [1, 2, 3], 'Expect to get back what was set'
    inner = cliargs_deferred_get('d')
   

# Generated at 2022-06-22 19:49:17.926304
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    import sys
    from ansible.module_utils.common.collections import is_sequence

    _init_global_context(dict(foo=dict(bar=['baz', 'qux']), baz=set(['bar', 'baz'])))
    # test without shallow copy
    for val in CLIARGS.values():
        assert cliargs_deferred_get(val) is val
    # test with shallow copy
    for val in CLIARGS.values():
        if is_sequence(val):
            assert cliargs_deferred_get(val) is not val
            assert val == cliargs_deferred_get(val)
            assert val is not copy.copy(cliargs_deferred_get(val))
        elif isinstance(val, (Mapping, Set)):
            assert cli

# Generated at 2022-06-22 19:49:26.639345
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get behaves correctly"""
    global CLIARGS
    CLIARGS = CLIArgs({'__fake': u'fake_value'})

    def assert_value(expected, key, default=None, shallowcopy=False):
        """Assert that a value is returned

        Helper function to reduce duplication in the test
        """
        assert expected == cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)()

    assert_value(u'fake_value', '__fake')
    assert_value([u'fake_value'], '__fake', shallowcopy=True)
    assert_value(None, 'fake')
    assert_value('default_value', 'fake', default='default_value')

# Generated at 2022-06-22 19:49:34.791712
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # pylint: disable=too-few-public-methods
    class GlobalCLIArgs(CLIArgs):
        """Simplified CLIArgs for unit testing"""
        def __init__(self, value):
            super(GlobalCLIArgs, self).__init__()
            self._value = value

        def get(self, *args, **kwargs):
            return self._value

    cli_args = {'test': [1, 2, 3]}
    _init_global_context(cli_args)

    cliargs_get = cliargs_deferred_get('test')
    assert cliargs_get() == [1, 2, 3]

# Generated at 2022-06-22 19:49:44.895975
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    import types
    import collections

    # Testing basic functionality
    value = cliargs_deferred_get('foo', 'bar')
    assert isinstance(value, types.FunctionType)
    assert value() == 'bar'

    CLIARGS.polymorphic_ctype = 'foo'
    value = cliargs_deferred_get('polymorphic_ctype')
    assert isinstance(value, types.FunctionType)
    assert value() == 'foo'

    # Ensure we make a shallow copy
    CLIARGS.module_search_path = ['foo', 'bar']
    value = cliargs_deferred_get('module_search_path', shallowcopy=True)
    assert isinstance(value, types.FunctionType)
    assert isinstance(value(), collections.abc.Iterator)

# Generated at 2022-06-22 19:49:52.711766
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['complex'] = [1, 2, 3]
    CLIARGS['simple'] = 'simple'
    assert cliargs_deferred_get('complex', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('complex', shallowcopy=False)() == [1, 2, 3]
    assert cliargs_deferred_get('simple', shallowcopy=True)() == 'simple'
    assert cliargs_deferred_get('simple', shallowcopy=False)() == 'simple'

# Generated at 2022-06-22 19:49:56.299472
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Validate that cliargs_deferred_get returns the value set in the dictionary"""
    CLIARGS.__setattr__({'test': 'value'})
    assert cliargs_deferred_get('test')() == 'value'
    assert cliargs_deferred_get('bogus', 'fake')() == 'fake'

# Generated at 2022-06-22 19:50:06.399348
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    import copy
    import collections

    CLIARGS.my_key = 'myvalue'

    assert cliargs_deferred_get('my_key')() == 'myvalue'

    # args is a Mapping
    test_mapping = collections.ChainMap(CLIARGS, {'my_key': 'value2'})
    CLIARGS = CLIArgs(test_mapping)
    assert cliargs_deferred_get('my_key')() == 'myvalue'
    assert cliargs_deferred_get('my_key', default='value')() == 'myvalue'
    assert cliargs_deferred_get('my_key', default='value', shallowcopy=True)() == 'myvalue'
    assert cliargs_deferred_get('my_key2')() is None


# Generated at 2022-06-22 19:50:14.015419
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    args = {'t1': 't1', 't2': ['t2a', 't2b', {'t2c': 't2c'}]}
    CLIARGS = GlobalCLIArgs.from_options(args)
    get_t1 = cliargs_deferred_get('t1')
    assert get_t1() == args['t1']
    get_t2 = cliargs_deferred_get('t2', shallowcopy=True)
    assert get_t2() == args['t2']
    # Change cliargs
    args['t2'] = args['t2'][:]
    args['t2'][1] = 't2bb'

# Generated at 2022-06-22 19:50:22.629837
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=redefined-outer-name

    # Test that the function returns the value from CLIARGS
    _init_global_context({'test': 'value'})
    assert cliargs_deferred_get('test')() == 'value'

    # Test that the function returns the default value when nothing is there
    _init_global_context({})
    assert cliargs_deferred_get('test', 'default')() == 'default'

    # Test that the function returns a shallow copy
    seq = [1, 2]
    _init_global_context({'test': seq})
    newseq = cliargs_deferred_get('test', shallowcopy=True)()
    assert newseq == seq
    seq.append(3)
    assert newseq == [1, 2]

# Generated at 2022-06-22 19:50:33.729347
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 1, 'bar': [1, 2, 3], 'baz': {'one': 1, 'two': 2}, 'qux': {1, 2, 3}})

    assert cliargs_deferred_get('foo')() == 1
    assert cliargs_deferred_get('bar')() == [1, 2, 3]
    assert cliargs_deferred_get('baz')() == {'one': 1, 'two': 2}
    assert cliargs_deferred_get('qux')() == {1, 2, 3}

    assert cliargs_deferred_get('foo', shallowcopy=True)() == 1
    assert cliargs_deferred_get('bar', shallowcopy=True)() == [1, 2, 3]


# Generated at 2022-06-22 19:50:42.220814
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.set('test', 'global1')
    my_get = cliargs_deferred_get('test')
    assert my_get() == 'global1'

    CLIARGS.set('test', 'global2')
    assert my_get() == 'global2'

    CLIARGS.set('test', [1, 2, 3])
    assert my_get() == [1, 2, 3]
    assert my_get(shallowcopy=True) == [1, 2, 3]

    CLIARGS.set('test', {'a': 'b'})
    assert my_get() == {'a': 'b'}
    assert my_get(shallowcopy=True) == {'a': 'b'}

    CLIARGS.set('test', {1, 3})
    assert my_get()

# Generated at 2022-06-22 19:50:46.970458
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    expected = {'key': 'value'}
    def inner():
        global CLIARGS
        return CLIARGS
    inner.__doc__ = "Mock function to get CLIARGS global variable"
    orig_cliargs = CLIARGS
    CLIARGS = CLIArgs(expected)
    inner()
    assert inner.__doc__ == "Mock function to get CLIARGS global variable"
    get_fn = cliargs_deferred_get('key')
    assert get_fn() == expected['key']
    CLIARGS = orig_cliargs

# Generated at 2022-06-22 19:50:52.664486
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    data = [1, 2, 3]
    CLIARGS = CLIArgs({'data': data})
    assert data[-1] == cliargs_deferred_get('data', shallowcopy=True)[-1]

    data = {1: 2, 3: 4}
    CLIARGS = CLIArgs({'data': data})
    assert data[1] == cliargs_deferred_get('data', shallowcopy=True)[1]

# Generated at 2022-06-22 19:51:01.175096
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    temp_cliargs = CLIArgs({'foo': 'bar'})

    # Check that it can get a key when no default
    assert cliargs_deferred_get('foo')() == 'bar'
    # Check default can be set
    assert cliargs_deferred_get('bar', 'baz')() == 'baz'
    # Check that it can get a key that has a default
    assert cliargs_deferred_get('bar', 'baz')() == 'baz'

    # Check that it returns a shallow copy when requested
    b = {'a': 1}
    CLIARGS['b'] = b
    assert cliargs_deferred_get('b', shallowcopy=True)() is not b
    assert cliargs_deferred_get('b', shallowcopy=True)() == b

    # Check