

# Generated at 2022-06-22 19:41:07.921978
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Closure over getting a key from CLIARGS with shallow copy functionality

    Primarily used in ``FieldAttribute`` where we need to defer setting the default
    until after the CLI arguments have been parsed

    This function is not directly bound to ``CliArgs`` so that it works with
    ``CLIARGS`` being replaced
    """
    assert cliargs_deferred_get('test')() == CLIARGS.get('test')
    assert cliargs_deferred_get('test', shallowcopy=True)() == CLIARGS.get('test')
    assert cliargs_deferred_get('not_exist', 'default')() == 'default'
    assert cliargs_deferred_get('not_exist', 'default', shallowcopy=True)() == 'default'

# Generated at 2022-06-22 19:41:18.809556
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    initial_global_cliargs = CLIARGS

# Generated at 2022-06-22 19:41:29.836744
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict, is_sequence

    class CliArgs(Mapping):
        def __init__(self, items):
            self._items = items
            self._frozen = False

        def __len__(self):
            return len(self._items)

        def __iter__(self):
            return iter(self._items)

        def __getitem__(self, key):
            return self._items[key]

        def set(self, key, value):
            if self._frozen:
                raise RuntimeError("Cannot set on frozen instance")
            self._items[key] = value

        def freeze(self):
            self._frozen = True


# Generated at 2022-06-22 19:41:40.929204
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with no default
    global CLIARGS
    CLIARGS = CLIArgs({'r': None, 'f': 'new_format'})
    test_result = cliargs_deferred_get('r')()
    assert test_result is None

    # Test with default
    test_result = cliargs_deferred_get('f', default='default_format')()
    assert test_result == 'new_format'

    # Test with default that is a mutable value
    test_result = cliargs_deferred_get('f', default=['default_format'])()
    assert test_result == ['new_format']

    # Test with default that is an non-shallow copyable value
    test_result = cliargs_deferred_get('f', default=None)()
    assert test_result is None

# Generated at 2022-06-22 19:41:49.195576
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    from ansible.utils.context_objects import GlobalCLIArgs
    global CLIARGS
    CLIARGS = GlobalCLIArgs({'foo': 'bar', 'baz': [1, 2, '3']})

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('NOTHERE', 'NOTHERE')() == 'NOTHERE'
    CLIARGS['foo'] = 1
    assert cliargs_deferred_get('foo')() == 1
    CLIARGS['baz'] = (1, 2, '3')
    assert cliargs_deferred_get('baz')() == (1, 2, '3')
   

# Generated at 2022-06-22 19:41:57.648009
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CliArgs:
        @property
        def get(self):
            return lambda x, default=None: None

    args = CliArgs()
    global CLIARGS
    CLIARGS = args
    assert cliargs_deferred_get('test')() is None
    CLIARGS = CLIArgs({'test': 'test'})
    assert cliargs_deferred_get('test')() == 'test'
    assert cliargs_deferred_get('test', default='test')() == 'test'
    CLIARGS = CLIArgs({'test': ('test', )})
    assert cliargs_deferred_get('test', shallowcopy=True)() == ('test',)
    CLIARGS = CLIArgs({'test': set('test')})

# Generated at 2022-06-22 19:42:06.234688
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update(dict(foo='bar'))
    get_foo = cliargs_deferred_get('foo')

    assert get_foo() == 'bar'
    CLIARGS['foo'] = 'baz'
    assert get_foo() == 'baz'

    get_foo_list = cliargs_deferred_get('foo_list', [])
    assert get_foo_list() == []
    CLIARGS['foo_list'] = ['bar']
    assert get_foo_list() == ['bar']

    get_foo_dict = cliargs_deferred_get('foo_dict', {})
    assert get_foo_dict() == {}
    CLIARGS['foo_dict'] = dict(bar='baz')
    assert get_foo_dict() == dict(bar='baz')

# Generated at 2022-06-22 19:42:10.508061
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

    class TestObj(object):
        def __init__(self, val):
            self.val = val

        def __eq__(self, other):
            if not isinstance(other, TestObj):
                return False
            return self.val == other.val

    # Test default case
    cli_args = ImmutableDict()
    _init_global_context(cli_args)
    f = cliargs_deferred_get('key')
    assert f() is None
    f = cliargs_deferred_get('key', default='default')

# Generated at 2022-06-22 19:42:18.700032
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    class A:
        pass
    CLIARGS = A()
    CLIARGS.foo = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS.foo = 1
    assert cliargs_deferred_get('foo')() == 1
    CLIARGS.foo = ['a', 'b']
    assert cliargs_deferred_get('foo')() == ['a', 'b']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['a', 'b']
    CLIARGS.foo = set(['a', 'b'])
    assert cliargs_deferred_get('foo')() == set(['a', 'b'])

# Generated at 2022-06-22 19:42:24.903320
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    try:
        CLIARGS = CLIArgs({"a": 1, "b": ["a", "b", "c"]})
        assert 1 == cliargs_deferred_get('a')()
        assert ["a", "b", "c"] == cliargs_deferred_get('b')()
        assert 2 == cliargs_deferred_get('a', default=2)()
        assert ["a", "b", "c"] == cliargs_deferred_get('b', shallowcopy=True)()
    finally:
        CLIARGS = CLIArgs({})

# Generated at 2022-06-22 19:42:34.273152
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=redefined-outer-name
    """Unit test for function cliargs_deferred_get"""
    from . import run_command

    args = [
        '-vvvv',
        '-vvvvv',
        '-vvvvvv',
        '-vvvvvvv',
        '-vvvvvvvv',
        '-vvvvvvvvv',
    ]
    _, _, rc = run_command(['ansible-playbook', '-vvvv'] + args)
    assert rc == 0

    cliargs_get = cliargs_deferred_get('verbosity', default=0, shallowcopy=False)
    assert cliargs_get() == 9

# Generated at 2022-06-22 19:42:44.746569
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test deferred get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.errors import AnsibleError

    def inner_test(value, expected_value):
        """Test inner function of cliargs_deferred_get with value"""
        def reset_cliargs():
            global CLIARGS
            CLIARGS = CLIArgs({})

        reset_cliargs()
        del_value = cliargs_deferred_get('does_not_exist')
        assert del_value() is None

        reset_cliargs()
        del_value = cliargs_deferred_get('does_not_exist', default='foo')
        assert del_value() == 'foo'

        reset_cliargs()
        def bad_default():
            """Throw an exception"""

# Generated at 2022-06-22 19:42:56.411712
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test input types
    # When we get a single argument
    def test_sub_input(key):
        ret = cliargs_deferred_get(key)
        assert ret == key

    test_sub_input(None)
    test_sub_input(1)
    test_sub_input('str')

    # When we get two arguments
    def test_sub_input(key, default):
        ret = cliargs_deferred_get(key, default=default)
        assert ret == key

    test_sub_input(None, None)
    test_sub_input(1, None)
    test_sub_input('str', None)
    test_sub_input(None, 1)
    test_sub_input(1, 1)
    test_sub_input('str', 1)
    test_sub

# Generated at 2022-06-22 19:43:03.552158
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Check default value
    cliargs_old = CLIARGS
    _init_global_context(dict())
    assert cliargs_deferred_get('missing key', default=1)() == 1

    # Check that we get the same value from the global when present
    _init_global_context(dict(a=1))
    assert cliargs_deferred_get('a', default='a')() == 1

    # Check shallow copy of sequences
    assert cliargs_deferred_get('a', shallowcopy=True)() is None
    assert cliargs_deferred_get('a', default=[], shallowcopy=True)() == []
    assert cliargs_deferred_get('a', default=[1], shallowcopy=True)() == [1]

# Generated at 2022-06-22 19:43:14.345258
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.utils.context_objects as co
    class MockCliArgs(co.CLIArgs):
        def __init__(self, *args, **kwargs):
            self._items = kwargs
        def get(self, key, default=None):
            return self._items.get(key, default)

    old_cliargs = CLIARGS

# Generated at 2022-06-22 19:43:21.494808
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # When: I create a closure over CLIARGS
    # Then: I get a closure that returns the value of CLIARGS[key] that I used to create the closure
    assert cliargs_deferred_get('connection')(None) is None
    assert cliargs_deferred_get('connection')('smart') == 'smart'

    CLIARGS['connection'] = 'smart'
    assert cliargs_deferred_get('connection')(None) == 'smart'
    assert cliargs_deferred_get('connection')('smart') == 'smart'

    CLIARGS['connection'] = 'smart'
    assert cliargs_deferred_get('connection', 'smart')(None) == 'smart'
    assert cliargs_deferred_get('connection')('smart') == 'smart'


# Generated at 2022-06-22 19:43:31.356287
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from unittest import TestCase

    class TestCLIArgsDeferredGet(TestCase):
        def setUp(self):
            self.original = {'foo': 'bar'}
            global CLIARGS
            CLIARGS = CLIArgs(self.original)

        def test_no_default(self):
            self.assertEqual(cliargs_deferred_get('foo'), 'bar')

        def test_no_default_shallowcopy(self):
            self.assertEqual(cliargs_deferred_get('foo', shallowcopy=True), 'bar')

        def test_default(self):
            self.assertEqual(cliargs_deferred_get('bar', default='foobar'), 'foobar')


# Generated at 2022-06-22 19:43:36.246162
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs

    assert CLIARGS is CLIArgs({})
    CLIARGS = GlobalCLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    bar_default = object()
    assert cliargs_deferred_get('bar', default=bar_default)() is bar_default

    bar_value = ['a', 'b', 'c']
    CLIARGS = GlobalCLIArgs({'foo': 'bar', 'bar': bar_value})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is bar_value
    assert cliargs_deferred

# Generated at 2022-06-22 19:43:42.941512
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    new_cliargs = CLIArgs({'deprecation_warnings': False})
    # Ensure we're not modifying the global CLIARGS singleton
    old_cliargs = CLIARGS
    try:
        _init_global_context(new_cliargs)
        inner = cliargs_deferred_get('deprecation_warnings')
        assert not inner()
        assert inner() != new_cliargs.get('deprecation_warnings')
        inner = cliargs_deferred_get('deprecation_warnings', shallowcopy=True)
        assert not inner()
        assert inner() == new_cliargs.get('deprecation_warnings')
    finally:
        _init_global_context(old_cliargs)

# Generated at 2022-06-22 19:43:54.503955
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({"test_value": "value", "test_dict": {"key1": "value1"}, "test_list": ["value1", "value2"], "test_set": {"value1", "value2"}}, None)
    assert cliargs_deferred_get("test_value")() == "value"
    assert cliargs_deferred_get("not_a_value")() is None
    assert cliargs_deferred_get("not_a_value", default="default")() == "default"
    assert cliargs_deferred_get("test_dict", shallowcopy=True)() == {"key1": "value1"}

# Generated at 2022-06-22 19:43:58.556142
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.dict_transformations import dict_merge

    # default value
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('connection')(), 'local'

    # value set
    CLIARGS = CLIArgs({'connection': 'smart'})
    assert cliargs_deferred_get('connection')(), 'smart'

    # value set to a sequence
    CLIARGS = CLIArgs({'connection': 'ssh'})
    assert cliargs_deferred_get('connection', shallowcopy=True)(), 'ssh'
    assert cliargs_deferred_get('connection')(), 'ssh'
    assert cliargs_deferred_get('connection', shallowcopy=True)(), 'ssh'

    # value set to a mapping
   

# Generated at 2022-06-22 19:44:07.703212
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def make_dict(k: str, v: str):
        return dict(foo=dict(key=k, value=v))

    default = dict(foo='bar')
    cli_args = make_dict('foo', 'baz')

    get = cliargs_deferred_get(key='foo', default=default)
    assert get() is default
    _init_global_context(cli_args)
    assert get() == 'baz'

    get_no_copy = cliargs_deferred_get(key='foo', default=default, shallowcopy=False)
    assert get_no_copy() is default
    _init_global_context(cli_args)
    assert get_no_copy() == 'baz'


# Generated at 2022-06-22 19:44:16.872693
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({
        'a': 1,
        'b': 2,
    })
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('c')() is None
    assert cliargs_deferred_get('c', default=3)() == 3
    CLIARGS['c'] = 3
    assert cliargs_deferred_get('c')() == 3
    # Test shallow copy
    val = [1, 2]
    CLIARGS.update({'val': val})
    val[0] = 3
    assert cliargs_deferred_get('val', shallowcopy=True)() == [3, 2]

# Generated at 2022-06-22 19:44:27.286684
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz')() == None

    CLIARGS = CLIArgs({'foo': []})
    assert cliargs_deferred_get('foo')() == []
    assert cliargs_deferred_get('foo', default=[])() == []
    assert cliargs_deferred_get('foo', shallowcopy=True)() == []

    CLIARGS = CLIArgs({'foo': {}})
    assert cliargs_deferred_get('foo')() == {}

# Generated at 2022-06-22 19:44:38.767503
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""

    test_cliargs = CLIArgs({'test': True})
    # test that we can set the CLIArgs and that the closure returns the correct value
    # with no default
    global CLIARGS
    orig_cliargs = CLIARGS
    CLIARGS = test_cliargs
    assert cliargs_deferred_get('test') is True
    CLIARGS = orig_cliargs

    # test that we can set the CLIArgs and that the closure returns the correct value
    # with a default
    global CLIARGS
    orig_cliargs = CLIARGS
    CLIARGS = test_cliargs
    assert cliargs_deferred_get('test_default', default=False) is True
    CLIARGS = orig_cliargs

    # test that we can set the

# Generated at 2022-06-22 19:44:48.963115
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.module_utils.common._collections_compat as collections_compat

    def _test_value(value, expected):
        getter = cliargs_deferred_get("test", default=value, shallowcopy=False)
        assert getter() == expected
        getter = cliargs_deferred_get("test", default=value, shallowcopy=True)
        assert getter() == expected

    for value in (None, "string", 1, 1.0,
                  collections_compat.Mapping(),
                  collections_compat.Sequence(),
                  collections_compat.Set()):
        _test_value(value, value)


# Generated at 2022-06-22 19:44:59.259677
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs

    test_args = {'vault_password_file': '/some/file',
                 'extra_vars': ['foo=bar']}

    # Check that it returns a value when there is a store
    _init_global_context(test_args)
    result = cliargs_deferred_get('vault_password_file')()
    assert result == '/some/file'

    # Check that it returns the default when there is no store
    CLIARGS = GlobalCLIArgs({})
    result = cliargs_deferred_get('vault_password_file', default='some_default')()
    assert result == 'some_default'

    # Check that it shallowcopies list values

# Generated at 2022-06-22 19:45:08.497273
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Unit testing of cliargs_deferred_get
    """
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.context import CLIARGS, GlobalCLIArgs, _init_global_context

    arguments = {'filename': 'test_file', 'hosts': 'localhost', 'password': 'secret'}
    cli_args = GlobalCLIArgs({})
    _init_global_context(cli_args)
    func = cliargs_deferred_get('filename')
    value = func()
    assert value is None, \
        'Test that a key with no default returns none'

    cli_args['filename'] = arguments['filename']
    func = cliargs_deferred_get('filename')
    value = func()

# Generated at 2022-06-22 19:45:17.451284
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update(dict(dict=dict(a=1, b=2, c=3), list=[1, 2, 3, 4], set={'a', 'b', 'c'}))
    assert cliargs_deferred_get('dict') == {'a': 1, 'b': 2, 'c': 3}
    assert cliargs_deferred_get('list') == [1, 2, 3, 4]
    assert cliargs_deferred_get('set') == {'a', 'b', 'c'}
    # Test shallowcopy
    assert hasattr(cliargs_deferred_get('dict', shallowcopy=True), 'copy')
    assert hasattr(cliargs_deferred_get('list', shallowcopy=True), 'copy')

# Generated at 2022-06-22 19:45:26.263846
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCLIArgs(CLIArgs):
        def __init__(self, val):
            self.val = val

        def get(self, key):
            return self.val


# Generated at 2022-06-22 19:45:37.213150
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'a': 'b', 'c': ['d', 'e'], 'f': {'g': 'h'}, 'i': set(['j', 'k'])})
    assert cliargs_deferred_get('c', shallowcopy=True)() == ['d', 'e']
    assert cliargs_deferred_get('c', shallowcopy=False)() == ['d', 'e']
    assert cliargs_deferred_get('f', shallowcopy=True)() == {'g': 'h'}
    assert cliargs_deferred_get('f', shallowcopy=False)() == {'g': 'h'}
    assert cliargs_deferred_get('i', shallowcopy=True)() == set(['j', 'k'])
    assert cliargs_deferred_

# Generated at 2022-06-22 19:45:40.882438
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'key': 'value'})
    assert 'value' == cliargs_deferred_get('key')()
    assert 'not value' == cliargs_deferred_get('not key', default='not value')()

# Generated at 2022-06-22 19:45:51.196034
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test case 1: A normal use case
    # Tests that the value returned is the same value that was in the CLIARGS object
    # and that it is the same object
    value = {'one': 1}
    CLIARGS._CLIARGS_DATA["test1"] = value
    var = "test1"
    func = cliargs_deferred_get(var, default=None)
    assert func
    assert func() is value
    assert func() == value
    assert func()["one"] == 1

    # Test case 2: Getting the default value
    # Test that the default value is returned and the value is not the same object as was in
    # the CLIARGS object
    value = "foo"
    def_value = "bar"
    var = "test2"
    func = cliargs_deferred_get

# Generated at 2022-06-22 19:45:58.334080
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function for getting CLIARGS values"""
    # Test without shallowcopy
    global CLIARGS
    original = {'key': 'value'}
    CLIARGS = CLIArgs(original)
    value = cliargs_deferred_get('key')()
    assert original is CLIARGS.get('key') == value

    # Test with shallowcopy
    value = cliargs_deferred_get('key', shallowcopy=True)()
    assert original is not value

# Generated at 2022-06-22 19:46:09.240383
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(test_key=["item1"], test_key2={"item2": 1}))
    assert cliargs_deferred_get('test_key')() == ["item1"]
    assert cliargs_deferred_get('test_key', shallowcopy=True)() == ["item1"]
    assert cliargs_deferred_get('test_key2')() == {"item2": 1}
    assert cliargs_deferred_get('test_key2', shallowcopy=True)() == {"item2": 1}
    assert cliargs_deferred_get('test_key3', "default")() == "default"

# Example of deferring a value from CLIARGS in a FieldAttribute

# Generated at 2022-06-22 19:46:15.626603
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Note: this function is not tested in ansible-test because
    # ``CLIARGS`` is already initialized
    from ansible.utils.context_objects import (
        contexts,
        get_default_context,
        Context,
    )

    contexts.clear()
    args = {'one': 'foo', 'two': 'bar', 'list': ['1', '2'], 'set': set(['a', 'b', 'c']), 'dict': {'d': 'e'}}
    contexts.add(Context(args), name=get_default_context())

    # Just getting a value
    assert cliargs_deferred_get('one')() == 'foo'

    # Getting a value that doesn't exist
    assert cliargs_deferred_get('three')() is None

    # Getting a value that doesn't exist

# Generated at 2022-06-22 19:46:24.360722
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    import copy
    import mock

    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default=None)() == None, "Unset value should return default value"
    assert cliargs_deferred_get('foo', default=mock.sentinel.foo)() == mock.sentinel.foo, "Unset value should return default value"

    CLIARGS = CLIArgs({'foo': mock.sentinel.foo})
    assert cliargs_deferred_get('foo', default=None)() == mock.sentinel.foo, "Set value should return set value"

    # Ensure that copy is shallow
    CLIARGS = CLIArgs({'foo': {'bar': mock.sentinel.bar}})

# Generated at 2022-06-22 19:46:33.899672
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    foo = {'bar': 1, 'baz': 2}
    CLIARGS['foo'] = foo
    default = {'bar': 5, 'baz': 7}
    assert cliargs_deferred_get('foo')(), bar == foo
    assert cliargs_deferred_get('foo', default=default)(), bar == foo
    assert cliargs_deferred_get('foo', default=default, shallowcopy=True)(), bar == foo
    assert cliargs_deferred_get('foo', default=default, shallowcopy=False)(), bar == foo
    assert cliargs_deferred_get('garply', default=default, shallowcopy=False)(), garply == default
    assert cliargs_deferred_get('garply', default=default, shallowcopy=False)(), garply == default

# Unit tests

# Generated at 2022-06-22 19:46:41.240021
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'test': 'value', 'list': ['one', 'two', 'three']})
    test_cli_args_getter = cliargs_deferred_get('test')
    list_cli_args_getter = cliargs_deferred_get('list')
    assert test_cli_args_getter() == 'value'
    assert list_cli_args_getter() == ['one', 'two', 'three']
    # Make sure shallowcopy works correctly
    assert list_cli_args_getter(shallowcopy=True) == ['one', 'two', 'three']
    assert list_cli_args_getter(shallowcopy=True) is not CLIARGS['list']
    # Make sure that deepcopy is not used
    CLIARGS['list'].append('four')

# Generated at 2022-06-22 19:46:51.834142
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # We have to use some random "good" defaults here to avoid masking errors
    cliargs = {'inventory': 'nope', 'variable_manager': 'not happening'}
    _init_global_context(cliargs)
    # Test simple key
    default = 'foo'
    key = 'inventory'
    # Sanity check callable
    assert callable(cliargs_deferred_get(key, default=default))
    assert CLIARGS[key] == cliargs_deferred_get(key, default=default)()
    # Test simple key with deferred default
    key = 'connection'
    default = 'foo'
    assert cliargs_deferred_get(key, default=default)() == default
    cliargs.update(connection='bar')
    _init_global_context(cliargs)

# Generated at 2022-06-22 19:47:00.658710
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test getting a value that exists
    CLIARGS['test_key'] = 'test_value'
    assert 'test_value' == cliargs_deferred_get('test_key')()
    del CLIARGS['test_key']

    # Test getting a value that doesn't exist
    assert None is cliargs_deferred_get('test_key')()

    # Test getting a value while specifying a default
    assert 'test_default' == cliargs_deferred_get('test_key', default='test_default')()

    # Test that the default is returned even if a different key exists
    CLIARGS['test_key_exists'] = 'test_value_exists'

# Generated at 2022-06-22 19:47:12.254293
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test getting items from CLIARGS"""
    cliargs = CLIArgs({'item1': 1, 'item2': 2})

    deferred_get = cliargs_deferred_get(key='item1')
    assert deferred_get() == 1
    assert cliargs['item1'] == 1

    deferred_get = cliargs_deferred_get(key='item1', default=4)
    assert deferred_get() == 4
    assert cliargs['item1'] == 1

    deferred_get = cliargs_deferred_get(key='item3', default=4)
    assert deferred_get() == 4
    assert 'item3' not in cliargs

    cliargs['item4'] = set(range(10))

    deferred_get = cliargs_deferred_get(key='item4')


# Generated at 2022-06-22 19:47:20.727043
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    scope = {}
    scope['CLIARGS'] = CLIArgs({})
    scope['cliargs_deferred_get'] = cliargs_deferred_get

    test_default_value = 'hello world'
    test_non_default_value = 'the quick brown fox jumped over the lazy dog'

    assert scope['cliargs_deferred_get']('this_is_a_key', default=test_default_value, shallowcopy=True)() == test_default_value

    scope['CLIARGS']['this_is_a_key'] = test_non_default_value
    assert scope['cliargs_deferred_get']('this_is_a_key', default=test_default_value, shallowcopy=True)() == test_non_default_value

# Generated at 2022-06-22 19:47:30.978122
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo')() is None
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    seq = ['bar', 'baz']
    CLIARGS['seq'] = seq
    assert cliargs_deferred_get('seq', shallowcopy=True)() == seq
    assert cliargs_deferred_get('seq', shallowcopy=True)() is not seq
    CLIARGS['seq'] = set(seq)
    assert cliargs_deferred_get('seq', shallowcopy=True)() == set(seq)
    assert cliargs_deferred_get('seq', shallowcopy=True)() is not set(seq)
    CLIARGS['seq'] = dict(zip(seq, seq))
    assert cli

# Generated at 2022-06-22 19:47:40.289255
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar',
                'baz': [1, 2, 3],
                'quux': {'a': 'b', 'b': 'c', 'c': 'd'}}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('quux')() == {'a': 'b', 'b': 'c', 'c': 'd'}
    assert cliargs_deferred_get('quux', shallowcopy=True)() == {'a': 'b', 'b': 'c', 'c': 'd'}


# Generated at 2022-06-22 19:47:49.763295
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the closure over cliargs_deferred_get"""

    _init_global_context({'blah': 42})
    g = cliargs_deferred_get('blah')
    assert g() == 42

    _init_global_context({'blah': 42})
    g = cliargs_deferred_get('notblah')
    assert g() is None

    _init_global_context({'blah': 42})
    g = cliargs_deferred_get('notblah', default=42)
    assert g() == 42

    _init_global_context({'blah': [1, 2, 3]})
    g = cliargs_deferred_get('blah', shallowcopy=True)
    assert g() == [1, 2, 3]

# Generated at 2022-06-22 19:48:00.150099
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    class TestCliArgs(CLIArgs):
        def __init__(self, *args, **kwargs):
            self._args = {}
            super(TestCliArgs, self).__init__(*args, **kwargs)

    def assert_get_returns(cliargs, key, expected_value, shallowcopy=False):
        get_func = cliargs_deferred_get(key, shallowcopy=shallowcopy)
        cliargs._args = dict(key=expected_value)
        assert get_func() == expected_value
        # Confirm that we got a copy and not the object itself
        if shallowcopy and hasattr(expected_value, '__setitem__'):
            expected_value[0] = 'changed'
            assert get_func() != expected_

# Generated at 2022-06-22 19:48:07.749232
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs


# Generated at 2022-06-22 19:48:15.431316
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    defaults = {
        'hello': 'world',
        'pipeline': [1, 2, 3],
        'playbook': ['play.yml'],
        'roles_path': ['roles']
    }
    CLIARGS = CLIArgs(defaults)
    # Get defaults
    assert cliargs_deferred_get('hello')() == 'world'
    assert cliargs_deferred_get('pipeline')() == [1, 2, 3]
    assert cliargs_deferred_get('playbook')() == ['play.yml']
    assert cliargs_deferred_get('roles_path')() == ['roles']
    assert cliargs_deferred_get('nobody_home')() is None

    # Shallow copies
    assert cliargs

# Generated at 2022-06-22 19:48:23.472880
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''Test getting keys from CLIARGS'''
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    def assert_shallow_copy(key, value):
        """Assert that we can get a shallow copy of any value"""
        # Test that the returned type is the same type as the original
        assert type(value) is type(cliargs_deferred_get(key, shallowcopy=False)())
        # Test that the returned value is not the same object
        assert cliargs_deferred_get(key, shallowcopy=False)() is not cliargs_deferred_get(key, shallowcopy=True)()
        # Test that the returned value is a copy

# Generated at 2022-06-22 19:48:30.462680
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get function"""
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'

    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo', 'bar')() == 'baz'

    CLIARGS = GlobalCLIArgs.from_options({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo', default='bar')() == [1, 2, 3]

# Generated at 2022-06-22 19:48:41.006933
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    assert cliargs_deferred_get('bar', default='bar')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('bar', default='bar', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': [1, 2, 3, 4]})
    assert cliargs_deferred_get

# Generated at 2022-06-22 19:48:49.007512
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = {'foo': 'bar', 'baz': [1, 2, 3]}
    CLIARGS.update(cliargs)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('not-in-args')() is None
    assert cliargs_deferred_get('not-in-args', default='default')() == 'default'

# Generated at 2022-06-22 19:48:56.665618
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    global CLIARGS

    # Test the default value
    CLIARGS = GlobalCLIArgs.from_options({})
    assert cliargs_deferred_get('some key', default=3)() == 3

    def test_shallowcopy(value):
        """Test that the shallowcopy=True option does a shallow copy of the data"""
        CLIARGS = GlobalCLIArgs.from_options({'foo': value})
        # Test the default value
        copy = cliargs_deferred_get('foo', default=3)(shallowcopy=True)
        assert copy is not value
        assert copy == value

        # Test the value we actually got

# Generated at 2022-06-22 19:49:07.952256
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    orig_CLIARGS = CLIARGS

# Generated at 2022-06-22 19:49:16.500858
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    expected = 'blah'
    get = cliargs_deferred_get('a', default=expected)
    with patch.object(CLIARGS, 'get') as mock_get:
        assert get() == expected
        mock_get.assert_called_with('a', default=expected)

    with patch.object(CLIARGS, 'get') as mock_get:
        mock_get.return_value = ['foo']
        assert get(shallowcopy=True) == ['foo']

# Generated at 2022-06-22 19:49:27.058247
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'pi': 3.14, 'e': 2.71, 'version': '1.2.3', 'colors': ['red', 'green', 'blue'],
            'animals': {'dog': 'woof', 'cat': 'meow'}, 'num_set': set(range(10)),
            'complex_obj': {'thing': {'stuff': True, 'things': [4, 5]}}
            })
    shallow_default = cliargs_deferred_get('shallow_default', default='bacon')
    assert CLIARGS.get('shallow_default', default='bacon') == 'bacon'
    assert shallow_default() == 'bacon'
    assert shallow_default is not shallow_default()

# Generated at 2022-06-22 19:49:34.980249
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS

    # Set up a cli_args definition
    cli_args = {'foo': 'bar', 'baz': [1, 2, 3]}

    CLIARGS = CLIArgs(cli_args)

    # Check that the function works correctly
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

    # Check that the function works correctly with a key missing
    assert cliargs_deferred_get('missing')() is None
    assert cliargs_deferred_get('missing', default=0)

# Generated at 2022-06-22 19:49:42.192437
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']

    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'bar': 'baz'}


# Generated at 2022-06-22 19:49:53.713262
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    args = {'foo': {'bar': {'baz': 'theanswer'}}, 'list': [1, 2, 3], 'set': {1, 2, 3}}
    CLIARGS = CLIArgs(args)
    test_result = cliargs_deferred_get('foo')
    assert test_result is args['foo'], "Didn't get the value we wanted"
    test_result = cliargs_deferred_get('list')
    assert test_result is args['list'], "Didn't get the value we wanted"
    test_result = cliargs_deferred_get('set')
    assert test_result is args['set'], "Didn't get the value we wanted"

    test_result = cliargs_deferred_get('foo', shallowcopy=True)


# Generated at 2022-06-22 19:50:01.104767
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'ansible_foo': 'foo', 'ansible_bar': ['bar', ['baz']]})
    assert cliargs_deferred_get('ansible_foo')() == 'foo'
    assert cliargs_deferred_get('ansible_bar')() == ['bar', ['baz']]
    assert cliargs_deferred_get('ansible_bar', shallowcopy=True)() == ['bar', ['baz']]
    assert cliargs_deferred_get('ansible_bar')()[0] is cliargs_deferred_get('ansible_bar')()[0]

# Generated at 2022-06-22 19:50:12.300845
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    global CLIARGS
    CLIARGS = CLIArgs({})
    CLIARGS['foo'] = 'foo_value'
    CLIARGS['list'] = ['alpha', 'beta', 'gamma']
    CLIARGS['tuple'] = ('delta', 'epsilon', 'zeta')
    CLIARGS['dict'] = {'key1': 'value1', 'key2': 'value2'}
    CLIARGS['set'] = set(['element1', 'element2'])

    deferred = cliargs_deferred_get('foo')
    assert deferred() == 'foo_value'

    lcopy = cliargs_deferred_get('list', shallowcopy=True)

# Generated at 2022-06-22 19:50:22.074545
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': set([1, 2, 3]), 'c': {'d': 4, 'e': 5}, 'f': [1, 2, 3]})

    assert(cliargs_deferred_get('a')() == 1)
    assert(cliargs_deferred_get('z')() is None)
    assert(cliargs_deferred_get('a', default=7)() == 1)
    assert(cliargs_deferred_get('z', default=7)() == 7)
    assert(cliargs_deferred_get('b')() == set([1, 2, 3]))
    assert(cliargs_deferred_get('b', shallowcopy=True)() == set([1, 2, 3]))

# Generated at 2022-06-22 19:50:33.527223
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    context_options = dict(
        default_key='default_value',
        sequence_key=['first', 'second', 'third'],
        mapping_key={'dict': 'value'})

    _init_global_context(context_options)

    # test getting a value that exists
    assert cliargs_deferred_get('default_key')() == context_options['default_key']
    # test getting a value that exists as a sequence
    assert cliargs_deferred_get('sequence_key')() == context_options['sequence_key']
    assert cliargs_deferred_get('sequence_key', shallowcopy=True)() == context_options['sequence_key']
    # test getting a value that exists as a mapping

# Generated at 2022-06-22 19:50:42.082534
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from io import StringIO
    from ansible.module_utils.common._collections_compat import Mapping, Set

    class Options(Mapping):
        def __getitem__(self, key):
            if key == "one":
                return 1
            elif key == "two":
                return "two"
            elif key == "three":
                return [3, 4]
            elif key == "four":
                return {"four": "four"}

        def __iter__(self):
            return iter(["one", "two", "three", "four"])

        def __len__(self):
            return 4

    class Args(object):
        def __init__(self, kwargs):
            self.__dict__ = kwargs

    global CLIARGS


# Generated at 2022-06-22 19:50:48.512633
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    inner = cliargs_deferred_get('test_key', 'test_default')
    assert inner() == 'test_default'

    CLIARGS['test_key'] = 'test_value'
    assert inner() == 'test_value'

    CLIARGS['test_key'] = {'test_dict_key': 'test_dict_value'}
    assert inner() == {'test_dict_key': 'test_dict_value'}

    assert inner(shallowcopy=True) != {'test_dict_key': 'test_dict_value'}

    CLIARGS['test_key'] = (1, 2, 3)
    assert inner() == (1, 2, 3)

    assert inner(shallowcopy=True) != (1, 2, 3)

# Generated at 2022-06-22 19:50:56.032415
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_args = {'test_1': 'one',
                 'test_2': 'two',
                 'test_3': 3,
                 'test_4': (4, 4),
                 'test_5': [5, 5],
                 'test_6': {6: 6, 6: 6},
                 'test_7': {7, 7},
                 }

    _init_global_context(test_args)

    def test_by_key(key, expected, shallowcopy):
        value = cliargs_deferred_get(key, shallowcopy=shallowcopy)()
        assert value == expected
        if shallowcopy:
            assert value is not expected

    for key, value in test_args.items():
        test_by_key(key, value, shallowcopy=False)

# Generated at 2022-06-22 19:51:05.409595
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that function works with default value
    assert cliargs_deferred_get('does_not_exist', 'DEFAULT')() == 'DEFAULT'
    # Test that function works with getting a value from CLIARGS
    CLIARGS['some_value'] = 'SOME_VALUE'
    assert cliargs_deferred_get('some_value')() == 'SOME_VALUE'
    # Test that function works with shallow copy
    CLIARGS['some_value'] = ['a', 'b']
    some_value = cliargs_deferred_get('some_value', shallowcopy=True)()
    some_value.append('c')
    assert CLIARGS['some_value'] == ['a', 'b']