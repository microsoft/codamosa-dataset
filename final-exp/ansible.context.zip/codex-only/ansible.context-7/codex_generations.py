

# Generated at 2022-06-22 19:41:02.843852
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    init_default = {'foo': 'bar', 'baz': ['fizz', 'bang']}
    CLIARGS = CLIArgs(init_default)
    assert cliargs_deferred_get('foo', shallowcopy=False)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=False)() == ['fizz', 'bang']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['fizz', 'bang']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['fizz', 'bang']
    default_dict = {'key': 'val'}
    assert cliargs_

# Generated at 2022-06-22 19:41:12.777228
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Can get simple values
    assert cliargs_deferred_get('verbosity')() == 0
    # Can get default when not present in stack
    assert cliargs_deferred_get('not_present')('default') == 'default'
    assert cliargs_deferred_get('not_present')(default='default') == 'default'
    # Can get shallow copy
    import copy
    assert cliargs_deferred_get('verbosity', shallowcopy=True)() is not CLIARGS['verbosity']
    assert cliargs_deferred_get('verbosity', shallowcopy=True)() == CLIARGS['verbosity']
    assert cliargs_deferred_get('verbosity', shallowcopy=True)('default') == CLIARGS['verbosity']

# Generated at 2022-06-22 19:41:23.702678
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    class TestCliArgs(object):
        def get(self, key, default=None):
            return {'foo': 5, 'bar': [10, 11, 12, 13]}.get(key, default)

    global CLIARGS
    cliargs = TestCliArgs()
    CLIARGS = cliargs

    # foo is a primitive value
    assert cliargs_deferred_get('foo')() == 5
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 5

    # bar is a sequence
    assert cliargs_deferred_get('bar')() == [10, 11, 12, 13]
    assert cliargs_deferred_get('bar', shallowcopy=True)() == [10, 11, 12, 13]

    # bar is a sequence which is concatenated to


# Generated at 2022-06-22 19:41:34.050478
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.context_objects import CLIArgs
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 1, 'e': 2}})
    get_a = cliargs_deferred_get('a')
    assert get_a() == 1
    CLIARGS['a'] = 2
    assert get_a() == 2
    get_b = cliargs_deferred_get('b')
    assert get_b() == [1, 2, 3]
    CLIARGS['b'][0] = 5
    assert get_b() == [5, 2, 3]
    get_c = cliargs_deferred_get('c')
    assert get_c() == {'d': 1, 'e': 2}
    CLIAR

# Generated at 2022-06-22 19:41:39.617085
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.set_ansible_options(dict(var='val'))
    inner = cliargs_deferred_get('var')
    assert inner() == 'val'
    assert inner() == 'val'
    CLIARGS.set_ansible_options(dict(var='newval'))
    assert inner() == 'newval'


# Generated at 2022-06-22 19:41:48.551366
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import ContextObj
    from ansible.utils.context_objects.ansible_builtins import CliArgs
    from ansible.utils.context_objects.ansible_collections import AnsibleCollectionCliArgs
    from ansible.utils.context_objects.ansible_collections.base import AnsibleCollectionObj
    # cliargs_deferred_get() takes value of CLIARGS at runtime, tho
    # the individual function closures capture different CLIARGS objects
    # at definition time.
    cliargs_obj = CliArgs({})
    a_cliargs_obj = AnsibleCollectionCliArgs({})
    assert cliargs_obj is not a_cliargs_obj
    # In the real world, CLIARGS is replaced with a singleton after
    # initial setup
    global CLIARGS

# Generated at 2022-06-22 19:41:57.249139
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    d = {
        'foo': 'bar',
        'bar': {
            'foo': 'bar'
        },
        'bam': [1, 2, 3]
    }
    _init_global_context(d)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('bar')()['foo'] == 'bar'
    assert cliargs_deferred_get('bar', shallowcopy=True)()['foo'] == 'bar'
    assert cliargs_deferred_get('bam')() == [1, 2, 3]

# Generated at 2022-06-22 19:42:03.725864
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    get_test1 = cliargs_deferred_get('test1')
    get_test2 = cliargs_deferred_get('test2', default='test2 value')
    assert get_test1() == None
    assert get_test2() == 'test2 value'
    CLIARGS = CLIArgs({'test1': 'test1 value'})
    assert get_test1() == 'test1 value'
    assert get_test2() == 'test2 value'

# Generated at 2022-06-22 19:42:09.445799
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'ANSIBLE_STDOUT_CALLBACK': 'default', 'ANSIBLE_MODULE_ARGS': {'arg1': 'hello'}}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('ANSIBLE_STDOUT_CALLBACK')() == 'default'

    cli_args = {'ANSIBLE_STDOUT_CALLBACK': 'default', 'ANSIBLE_MODULE_ARGS': {'arg1': 'hello'}}
    retval = cliargs_deferred_get('ANSIBLE_STDOUT_CALLBACK', 'foo')()
    assert retval == 'default'
    assert retval is not 'default'


# Generated at 2022-06-22 19:42:18.245667
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

# Generated at 2022-06-22 19:42:25.807728
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    import sys
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    def _test_simple(key, value, **kwargs):
        """Helper function to test simple values"""
        # pylint: disable=missing-docstring
        _init_global_context(dict(key=value))

        closure = cliargs_deferred_get(key, **kwargs)

        if kwargs.get('shallowcopy'):
            if is_sequence(value):
                assert closure() == value[:]
            elif isinstance(value, (Mapping, Set)):
                assert closure() == value.copy()

# Generated at 2022-06-22 19:42:35.671973
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_value(src, result):
        CLIARGS.update(src)
        inner = cliargs_deferred_get("key")
        assert inner() == result
        CLIARGS.clear()

    test_value({}, None)
    test_value({"key": None}, None)
    test_value({"key": "value"}, "value")

    test_value({"key": [1, 2]}, [1, 2])
    test_value({"key": [1, 2]}, [1, 2], True)

    test_value({"key": {'a': 1}}, {'a': 1})
    test_value({"key": {'a': 1}}, {'a': 1}, True)

    test_value({"key": set([1, 2])}, set([1, 2]))


# Generated at 2022-06-22 19:42:45.666497
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence

    class Singleton(object):
        pass

    class Single(Singleton):
        pass

    class Other(Single):
        pass

    class Container(object):
        def copy(self):
            return Container()

    # A bunch of objects that we can't do things to
    singleton = Singleton()
    single = Single()
    other = Other()
    container = Container()

    # A bunch of objects that we can do things to
    copy_me = [1, 2, 3]
    copy_set = set([4, 5, 6])
    copy_map = dict(x=7, y=8)

    # The function
    f = cliargs_deferred_get('dne', default='def')

    # Routine object
    assert f

# Generated at 2022-06-22 19:42:55.950287
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CustomArgs(CLIArgs):
        def __getitem__(self, key):
            return 'bar'

    # Set up a mock CLIARGS
    cliargs = CustomArgs({'foo': 'bar'})
    global CLIARGS
    CLIARGS = cliargs

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='default')() == 'bar'
    assert cliargs_deferred_get('baz', default='default')() == 'default'
    assert cliargs_deferred_get('baz', default=object)() == object



# Generated at 2022-06-22 19:43:01.033103
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'key1': 'value1', 'key2': 'value2'})
    assert cliargs_deferred_get('not-a-key') is None
    assert cliargs_deferred_get('key1') == 'value1'

    # Shallow copy
    value1 = cliargs_deferred_get('key1', shallowcopy=True)
    value1 = 'value3'
    assert cliargs_deferred_get('key1') == 'value1'

# Generated at 2022-06-22 19:43:11.387443
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test without shallow copy
    CLIARGS = CLIArgs({'test': 'value'})
    assert cliargs_deferred_get('test')(), CLIARGS['test']
    assert cliargs_deferred_get('test2')(), None
    assert cliargs_deferred_get('test2', 'default')(), 'default'
    # Test with shallow copy
    CLIARGS = CLIArgs({'testlist': ['value1', 'value2'], 'testdict': {'key': 'value'}})
    assert cliargs_deferred_get('testlist', shallowcopy=True)(), ['value1', 'value2']
    assert cliargs_deferred_get('testdict', shallowcopy=True)(), {'key': 'value'}

# Generated at 2022-06-22 19:43:16.629721
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    cliargs_deferred_get('foo')()
    CLIARGS = CLIArgs({"foo": "bar"})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None

# Generated at 2022-06-22 19:43:22.574658
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test calling with something in the dict
    def cli_args_factory(config):
        def inner():
            return CLIARGS
        CLIARGS.data = config
        return inner

# Generated at 2022-06-22 19:43:31.956287
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert CLIARGS[-1] == 'test'
    assert cliargs_deferred_get(-1)() == 'test'
    assert cliargs_deferred_get(-1)(shallowcopy=True) == 'test'
    CLIARGS[-2] = [1, 2]
    assert cliargs_deferred_get(-2)() == [1, 2]
    assert cliargs_deferred_get(-2)(shallowcopy=True) == [1, 2]
    CLIARGS[-3] = {'a': 1, 'b': 2}
    assert cliargs_deferred_get(-3)() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get(-3)(shallowcopy=True) == {'a': 1, 'b': 2}


# Generated at 2022-06-22 19:43:36.090506
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_dict = {'a': 1}
    cli_args = CLIArgs({'a': test_dict})
    result = cliargs_deferred_get('a', shallowcopy=True)()
    assert result is not test_dict
    assert result == test_dict
    result2 = cliargs_deferred_get('a', shallowcopy=False)()
    assert result2 is test_dict

# Generated at 2022-06-22 19:43:43.353187
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    # pylint: disable=function-redefined

    cli_args = {'foo': 'bar', 'bam': 'boom', 'baz': {'zap': 'quux'}, 'bazz': ['one', 'two', 'three']}

    # Write over the global variable
    CLIARGS = CLIArgs(cli_args)

    def check_foo():
        return cliargs_deferred_get('foo', 'baz')

    def check_bam():
        return cliargs_deferred_get('bam', shallowcopy=True)

    def check_zap():
        return cliargs_deferred_get('baz', {}).get('zap')

    def check_bazz():
        return cliargs_deferred_get('bazz', shallowcopy=True)

# Generated at 2022-06-22 19:43:54.656407
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs
    from ansible.module_utils._text import to_text

    class GlobalCliArgs(CliArgs):
        @classmethod
        def from_options(cls, cliargs):
            """Set up the global context object

            :kwargs cliargs: Dictionary of options to set in the context
            :returns: A populated instance of this class
            """
            # FIXME: I don't think this is needed anymore.  We should probably just be
            # creating the object, initializing it and then modifying it
            context = cls({})
            context.update(dict(cliargs))
            return context

    cliargs_mock = {'foo': 'bar', 'baz': 'quux'}
    global CLIARGS
    CLIARGS = GlobalCli

# Generated at 2022-06-22 19:44:04.276648
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(foo=1, bar=dict(baz=2)))
    f = cliargs_deferred_get('foo', default=3)
    g = cliargs_deferred_get('baz', default=4)
    h = cliargs_deferred_get('baz', default=4, shallowcopy=True)
    # Default is set before args are parsed
    assert f() == 3
    assert g() == 4
    assert h() == 4
    # Non-deepcopy is the same as CLIARGS
    assert f() is CLIARGS.get('foo', default=3)
    assert g() is CLIARGS.get('baz', default=4)
    # Deepcopy is not the same
    assert h() is not CLIARGS.get('baz', default=4)

# Generated at 2022-06-22 19:44:08.746165
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Verify that cliargs_deferred_get works as expected"""
    global CLIARGS
    CLIARGS = CLIArgs({'test_key': 'test_value'})
    assert cliargs_deferred_get('test_key')() == 'test_value'
    assert cliargs_deferred_get('non_existent_key', default='default')() == 'default'
    assert cliargs_deferred_get('test_list', default=[])() == ['test_value']
    assert cliargs_deferred_get('test_list', default=[], shallowcopy=True)() == ['test_value']

# Generated at 2022-06-22 19:44:18.535423
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get
    """

    # test with no value and default
    assert cliargs_deferred_get('key')() is None

    # test with value and default
    CLIARGS['key'] = 'value'
    assert cliargs_deferred_get('key', 'default')() == 'value'

    # test with value but default used
    CLIARGS['another_key'] = 'value'
    assert cliargs_deferred_get('yet_another_key', 'default')() == 'default'

    # test with default not used
    assert cliargs_deferred_get('yet_another_key', 'default')('another_default') == 'default'

    # test with value and shallowcopy set

# Generated at 2022-06-22 19:44:28.725023
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test function returns a function closure
    inner = cliargs_deferred_get('test_key', 'test_value')
    assert callable(inner)
    assert inner() == 'test_value'

    # Test that if the key wasn't set yet we get the default value
    assert inner() == 'test_value'

    # The value is set on the CLIArgs instance so clear the cache and make sure we get the new value
    CLIARGS.pop('test_key', None)
    assert inner() == 'test_value'
    CLIARGS['test_key'] = 'new_value'
    assert inner() == 'new_value'

    # Test that we get a shallow copy of the value
    CLIARGS['test_key'] = ['test_item1', 'test_item2']

# Generated at 2022-06-22 19:44:38.989093
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_case(key, default, shallowcopy=False):
        def inner():
            return cliargs_deferred_get(key, default, shallowcopy)()
        return inner

    assert test_case('not_exist', 'default', True)() == 'default'
    assert test_case('not_exist', 'default', False)() == 'default'
    assert test_case('not_exist', dict(), True)() == dict()
    assert test_case('not_exist', dict(), False)() == dict()
    assert test_case('not_exist', {}, True)() == {}
    assert test_case('not_exist', {}, False)() == {}
    assert test_case('not_exist', [], True)() == []
    assert test_case('not_exist', [], False)() == []

# Generated at 2022-06-22 19:44:46.500870
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    import pytest
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch.object(CLIARGS, 'get', return_value='hello world'):
        assert cliargs_deferred_get('key', default='default')() == 'hello world'

    with patch.object(CLIARGS, 'get', return_value='hello world'):
        assert cliargs_deferred_get('key')(None) == 'hello world'

# Generated at 2022-06-22 19:44:52.576113
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that deferred get uses CLIARGS"""

    # CLIAGRGS is empty
    assert CLIARGS
    assert CLIARGS._raw_params == {}

    # Create a function to use
    my_get = cliargs_deferred_get('foo', 'bar')

    # Make sure it is using CLIARGS
    CLIARGS._raw_params['foo'] = 'bumblebee'
    assert my_get() == 'bumblebee'
    del CLIARGS._raw_params['foo']

    # Make sure it is using CLIARGS
    assert my_get() == 'bar'



# Generated at 2022-06-22 19:45:03.425334
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    CLIARGS['foo'] = 1
    CLIARGS['bar'] = 'test'
    CLIARGS['baz'] = [1, 2, 3]
    CLIARGS['quux'] = {1: 'foo', 2: 'bar', 3: 'baz'}

    class Object(object):
        foo = cliargs_deferred_get('foo')
        bar = cliargs_deferred_get('bar')
        baz = cliargs_deferred_get('baz')
        quux = cliargs_deferred_get('quux')

        # val should get the value, but shallowcopy() should return a copy of
        # the value
        foo_val = foo
        bar_val = bar
        baz_val = baz

# Generated at 2022-06-22 19:45:11.454446
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # The function is not bound to CliArgs so that it works if CliArgs is replaced
    assert cliargs_deferred_get.__qualname__ == 'cliargs_deferred_get'
    assert cliargs_deferred_get.__module__ == __name__

    # We've not initialized the args yet so we should get the default value
    assert cliargs_deferred_get('foo') == None

    # Now we have, so the actual CLIARGS value should be used
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo') == 'bar'

    # Also works with a default specified
    assert cliargs_deferred_get('bar', default=1) == 1

    # shallowcopy=True has

# Generated at 2022-06-22 19:45:17.501484
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the closure created by cliargs_deferred_get

    Note that we only test the closure here and don't test the interaction with
    the ``CLIARGS`` singleton.  That is tested in ``test_cliargs``
    """
    # Test the shallowcopy functionality
    value = [1, 2, 3]
    func = cliargs_deferred_get('key', value, True)
    assert func() == value
    assert func() is not value

    # Test the non-shallowcopy functionality
    value = [1, 2, 3]
    func = cliargs_deferred_get('key', value, False)
    assert func() == value
    assert func() is value

# Generated at 2022-06-22 19:45:26.300505
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function ``cliargs_deferred_get``"""
    import ansible.utils.context_objects
    global CLIARGS

    test_cliargs = dict(
        foo=dict(
            bar='bar',
        ),
        foos=list(range(10)),
        bar=0,
    )
    ansible.utils.context_objects._init_global_context(test_cliargs)

    # Check that we get the correct value back from cliargs
    assert cliargs_deferred_get('foo') == {'bar': 'bar'}
    assert cliargs_deferred_get('foos') == list(range(10))
    assert cliargs_deferred_get('bar') == 0

    # Check that non-scalar values are not shallow copied
    cliargs_deferred_

# Generated at 2022-06-22 19:45:37.304988
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import mock
    import copy
    with mock.patch('ansible.context.CLIARGS', CLIArgs({'foo': ['bar', 'baz'],
                                                       'bar': {'biz': 'baz'},
                                                       'baz': 'boo',
                                                       'boo': None})):
        assert cliargs_deferred_get('foo')() == ['bar', 'baz']
        assert cliargs_deferred_get('bar')() == {'biz': 'baz'}
        assert cliargs_deferred_get('baz')() == 'boo'
        assert cliargs_deferred_get('boo')() is None
        assert cliargs_deferred_get('quux')() is None

# Generated at 2022-06-22 19:45:43.935103
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-22 19:45:50.797739
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    # create a CLIARGS like object to test against
    class mock_cliargs(dict):
        def get(self, key, default=None):
            return super(mock_cliargs, self).get(key, default=default)

    # initial global CLIARGS
    init_args = CLIARGS

    # get cliargs_deferred_get bound to the initial value of CLIARGS
    deferred_get_init = cliargs_deferred_get
    # get cliargs_deferred_get bound to a new CLIARGS object

# Generated at 2022-06-22 19:46:01.499262
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set
    CLIARGS.update({'string': 'string', 'set': {1, 2}, 'dict': {'a': 1, 'b': 2}, 'list': [1, 2]})
    assert cliargs_deferred_get('string')() == 'string'
    assert cliargs_deferred_get('set')() == {1, 2}
    assert cliargs_deferred_get('dict')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('list')() == [1, 2]

    assert cliargs_deferred_get('string', shallowcopy=True)() == 'string'

# Generated at 2022-06-22 19:46:10.680775
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.options = {'a': 'a', 'b': ['b1', 'b2', 'b3'], 'c': {'c1': 'A', 'c2': 'B'}}
    assert cliargs_deferred_get('a')(), CLIARGS.options['a']
    assert cliargs_deferred_get('b')(), CLIARGS.options['b']
    assert cliargs_deferred_get('c')(), CLIARGS.options['c']
    assert cliargs_deferred_get('a', shallowcopy=True)(), CLIARGS.options['a']
    assert cliargs_deferred_get('b', shallowcopy=True)(), CLIARGS.options['b']
    assert cliargs_deferred_get('c', shallowcopy=True)(), CLIAR

# Generated at 2022-06-22 19:46:21.529371
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This prevents circular imports between ``CLIARGS`` and this file
    from ansible.utils.context_objects import CLIArgs

    cli_args = CLIArgs({'_ansible_debug': False})
    _init_global_context(cli_args)
    assert CLIARGS is cli_args

    # copyable
    get_shallow = cliargs_deferred_get('_ansible_debug', shallowcopy=True)
    copyable = get_shallow()
    copyable['foo'] = 'bar'
    val = cli_args['_ansible_debug']
    assert 'foo' not in val

    # callable
    get_callable = cliargs_deferred_get('_ansible_debug', shallowcopy=False)
    assert get_callable() is val

    # default
    get

# Generated at 2022-06-22 19:46:25.517521
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Function cliargs_deferred_get can be called prior to global context existing"""
    getter = cliargs_deferred_get('--version')
    assert getter() is None



# Generated at 2022-06-22 19:46:34.434887
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct values for different configurations.

    Note: this test should be run before an instance of ``GlobalCliArgs`` is created"""
    assert cliargs_deferred_get('foo')() == None
    assert cliargs_deferred_get('foo', default=1)() == 1
    assert cliargs_deferred_get('foo', default=1, shallowcopy=True)() == 1
    assert cliargs_deferred_get('foo', shallowcopy=True)() == None
    CLIARGS['foo'] = 1
    assert cliargs_deferred_get('foo')() == 1
    assert cliargs_deferred_get('foo', default=2)() == 1
    assert cliargs_deferred_get('foo', default=2, shallowcopy=True)

# Generated at 2022-06-22 19:46:41.574365
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def create_dict(copy_type):
        return {'a': {'a': 'b'}, 'b': [1, 2, 3], 'c': copy_type()}
    cliargs_inner = cliargs_deferred_get('test_value', default=create_dict(set), shallowcopy=True)
    cliargs_outer = cliargs_deferred_get('test_value', default=create_dict(set), shallowcopy=False)
    # CLIARGS is empty
    assert {} == CLIARGS.as_dict()
    # Defaults are set with `copy`
    assert {'a': {'a': 'b'}, 'b': [1, 2, 3], 'c': set()} == cliargs_inner()

# Generated at 2022-06-22 19:46:52.170107
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': {'a': 'b'}, 'frop': [{}, []]})
    def_value = []
    the_function = cliargs_deferred_get('foo')
    assert the_function() == 'bar'
    the_function = cliargs_deferred_get('foo', default=def_value)
    assert the_function() == 'bar'
    the_function = cliargs_deferred_get('fubar')
    assert the_function() is None
    the_function = cliargs_deferred_get('fubar', default=def_value)
    assert the_function() == def_value
    the_function = cli

# Generated at 2022-06-22 19:47:01.064525
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeOptions(object):
        """Fake the global options object

        Because the CLI options may not have been parsed yet, we can't directly
        use the options object
        """
        def __init__(self):
            self._options = {}

        def __getattr__(self, name):
            if name in self._options:
                return self._options[name]
            raise AttributeError('Missing attribute "%s"' % name)

        def __setattr__(self, name, value):
            if name.startswith('_'):
                super().__setattr__(name, value)
            else:
                self._options[name] = value

    options = FakeOptions()
    options.listkeys = True

    get_listkeys = cliargs_deferred_get('listkeys')
    get_minimal = cliargs

# Generated at 2022-06-22 19:47:09.439559
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    global CLIARGS
    CLIARGS = GlobalCLIArgs({})
    f = cliargs_deferred_get('foo')
    assert f() is None
    CLIARGS['foo'] = 'bar'
    assert f() == 'bar'
    CLIARGS['foo'] = {'a': 'b'}
    assert f() == {'a': 'b'}
    assert f(shallowcopy=True) == {'a': 'b'}

# Generated at 2022-06-22 19:47:18.555459
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.defaults = {'abc': 123}
    value = cliargs_deferred_get('abc')
    assert value() == 123
    assert value() != value()

    CLIARGS.defaults = {'xyz': [1, 2, 3]}
    value = cliargs_deferred_get('xyz', shallowcopy=True)
    assert value() == [1, 2, 3]
    assert value() is not value()

    CLIARGS.defaults = {'xyz': {1: 2, 3: 4}}
    value = cliargs_deferred_get('xyz', shallowcopy=True)
    assert value() == {1: 2, 3: 4}
    assert value() is not value()

    CLIARGS.defaults = {'xyz': {1, 2, 3}}
   

# Generated at 2022-06-22 19:47:29.672157
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for cliargs_deferred_get function

    This function is curried and returns callable, so it needs to be called twice
    """
    def_key = ('default_key', 'default_value')
    empty_key = ('empty_key', 'empty_value')
    dict_key = ('dict_key', {'thing': 'yellow'})
    list_key = ('list_key', ['one', 'two', 'three'])
    set_key = ('set_key', set(['one', 'two']))
    existing_key = ('existing_key', 'existing_value')

    # test with a cli_args dict and read from default
    CLIARGS.override({existing_key[0]: existing_key[1]})

# Generated at 2022-06-22 19:47:38.520320
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['verbosity'] = 10
    assert cliargs_deferred_get('verbosity')() == 10
    assert cliargs_deferred_get('verbosity', -1)() == 10
    assert cliargs_deferred_get('verbosity', shallowcopy=True)() == 10
    assert cliargs_deferred_get('tags', [])() == []
    assert cliargs_deferred_get('tags', [], shallowcopy=True)() == []

    assert cliargs_deferred_get('verbosity')() == 10
    assert cliargs_deferred_get('debug')() is None
    assert cliargs_deferred_get('debug', -1)() == -1

# Generated at 2022-06-22 19:47:49.145313
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': ['bar']})
    deferred = cliargs_deferred_get('foo', 'default', shallowcopy=True)
    assert deferred() == ['bar']

    CLIARGS = CLIArgs({'foo': ['bar']})
    deferred = cliargs_deferred_get('foo', 'default', shallowcopy=False)
    assert deferred() == ['bar']

    CLIARGS = CLIArgs({})
    deferred = cliargs_deferred_get('foo', 'default', shallowcopy=True)
    assert deferred() == 'default'

    CLIARGS = CLIArgs({})
    deferred = cliargs_deferred_get('foo', 'default', shallowcopy=False)
    assert deferred() == 'default'

# Generated at 2022-06-22 19:47:58.319393
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test when no default
    global CLIARGS
    CLIARGS = CLIArgs({'b': [2]})
    assert cliargs_deferred_get('a')() == None
    assert cliargs_deferred_get('b')() == [2]
    assert cliargs_deferred_get('c')() == None
    assert cliargs_deferred_get('a', shallowcopy=True)() == None
    assert cliargs_deferred_get('b', shallowcopy=True)() == [2]
    assert cliargs_deferred_get('c', shallowcopy=True)() == None

    CLIARGS = CLIArgs({'b': [2]})
    assert cliargs_deferred_get('a', default=1)() == 1

# Generated at 2022-06-22 19:48:05.849416
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.compat import mock
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock

    global CLIARGS
    CLIARGS = MagicMock(spec_set=GlobalCLIArgs)

    key = 'foo'
    default = {'bar': 'baz'}

    # Test with no default and no value
    CLIARGS.get.return_value = None
    assert cliargs_deferred_get(key)() == None
    CLIARGS.get.assert_called_once_with(key, default=None)
    CLIARGS.get.reset_mock

# Generated at 2022-06-22 19:48:15.884500
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    cli_args = {
        'abc': 'abc',
        'def': {'key1': 'value1'},
        'ghi': ['value2'],
        'jkl': ('value3',),
        'mno': set(('value4',)),
    }
    _init_global_context(cli_args)

    for d in normal_default, shallowcopy_default:
        for key in 'abc', 'def', 'ghi', 'jkl', 'mno':
            assert d(key)() == cli_args[key]

        assert d('not_exist')() == None

    assert normal_default('not_exist', default='default_value')() == 'default_value'

# Generated at 2022-06-22 19:48:23.583143
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Test with the internal default
    CLIARGS._options['v'] = 0
    val = cliargs_deferred_get('v')
    assert val() == 0
    CLIARGS._options['v'] = 1
    val2 = cliargs_deferred_get('v')
    assert val2() == 1

    # Test with a direct default
    val3 = cliargs_deferred_get('foo', default='bar')
    assert val3() == 'bar'
    CLIARGS.set('foo', 'foobar')
    assert val3() == 'foobar'

    # Ensure opts are getting fully copied
    opts = {'v': 0}
    CLIARGS.set('opts', opts)
    val = cliargs_deferred_get('opts', shallowcopy=True)
    opt

# Generated at 2022-06-22 19:48:33.898846
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Test for the happy path
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': set('abc')})
    assert(cliargs_deferred_get('foo')() == 'bar')
    assert(cliargs_deferred_get('baz')() == [1, 2, 3])
    assert(cliargs_deferred_get('qux')() == {'a': 1, 'b': 2})
    assert(cliargs_deferred_get('quux')() == set('abc'))

    # Test default value
    assert(cliargs_deferred_get('baz', default=42)() == [1, 2, 3])

# Generated at 2022-06-22 19:48:42.271104
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('key', default='default')() == 'default'

    global CLIARGS
    CLIARGS = CLIArgs({'key': 'value'})
    assert cliargs_deferred_get('key', default='default')() == 'value'

    CLIARGS = CLIArgs({'key': ['value']})
    value = cliargs_deferred_get('key', shallowcopy=True)()
    assert isinstance(value, list)
    assert value == ['value']

    CLIARGS = CLIArgs({'key': ('value',)})
    value = cliargs_deferred_get('key', shallowcopy=True)()
    assert isinstance(value, tuple)
    assert value == ('value',)

    CLIARGS = CLIArgs({'key': {'a': 1}})


# Generated at 2022-06-22 19:48:44.418223
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # TODO: Unit test for function cliargs_deferred_get
    return



# Generated at 2022-06-22 19:48:50.795787
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'a': 1, 'b': [1, 2, 3], 'c': {'a': 'b'}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('b', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'a': 'b'}
    assert cliargs_deferred_get('c', shallowcopy=True)() == {'a': 'b'}

# Generated at 2022-06-22 19:48:59.276660
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def set_default(key, value):
        CLIARGS[key] = value

    key = 'key'
    value = 'value'
    value2 = 'value2'
    default = 'default'
    default2 = 'default2'
    getter = cliargs_deferred_get(key, default)
    assert getter() == default
    set_default(key, value)
    assert getter() == value
    set_default(key, value2)
    assert getter() == value2
    set_default(key, default2)
    assert getter() == default2

# Generated at 2022-06-22 19:49:10.180022
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.errors import AnsibleError, AnsibleOptionsError
    from ansible.utils.display import Display
    from ansible.utils import context_objects
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible import constants as C
    from ansible.cli import CLI
    import ansible.config.manager


# Generated at 2022-06-22 19:49:17.547161
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MockCliArgs(object):
        def __getattr__(self, item):
            return cliargs_deferred_get(item, default=False)

    cli_args = CLIArgs(
        {'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 'b'}, 'quux': frozenset([4, 5, 6])}
    )
    cliargs_deferred_get.__globals__['CLIARGS'] = cli_args
    mock_cliarargs = MockCliArgs()
    assert mock_cliarargs.foo == 'bar'
    assert mock_cliarargs.baz == [1, 2, 3]
    assert mock_cliarargs.qux == {'a': 'b'}
    assert mock_cliar

# Generated at 2022-06-22 19:49:26.246786
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS_old = CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2], 'c': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2]
    assert cliargs_deferred_get('b', shallowcopy=True)() == [1, 2]
    assert cliargs_deferred_get('c')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('c', shallowcopy=True)() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('d')() is None
    assert cliargs

# Generated at 2022-06-22 19:49:34.575263
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    gc = GlobalCLIArgs({'x': 3, 'y': [1, 2, 3], 'z': {'a': 1}})
    CLIARGS._get.append(gc.get)

    # Does this return defaults
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    assert cliargs_deferred_get('foo', default=4)() == 4
    assert cliargs_deferred_get('foo')() is None

    # Does this retrieve from the command line
    assert cliargs_deferred_get('x', default='bar')() == 3
    assert cliargs_deferred_get('y', default='bar')() == [1, 2, 3]

# Generated at 2022-06-22 19:49:44.877553
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(foo=42, bar=dict(baz=43, qux=44), bam=45))

    my_closure = cliargs_deferred_get('foo')
    assert my_closure() == 42
    my_closure = cliargs_deferred_get('bar', default=dict(baz=50))
    assert my_closure() == dict(baz=43, qux=44)
    assert my_closure(shallowcopy=True) == dict(baz=43, qux=44)
    assert my_closure(shallowcopy=True)['baz'] == 43
    my_closure = cliargs_deferred_get('baz', default=dict(foo=42))
    assert my_closure() == dict(foo=42)

# Generated at 2022-06-22 19:49:54.498040
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the closure returned by cliargs_deferred_get"""
    input_value = {'a': 'b'}
    _init_global_context(CLIArgs({'key': input_value}))
    get = cliargs_deferred_get('key', default={'c': 'd'})
    assert input_value == get()
    get = cliargs_deferred_get('key2', default={'c': 'd'})
    assert {'c': 'd'} == get()
    get = cliargs_deferred_get('key', default={'c': 'd'}, shallowcopy=True)
    assert input_value == get()
    get = cliargs_deferred_get('key2', default={'c': 'd'}, shallowcopy=True)

# Generated at 2022-06-22 19:50:01.717781
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    cliargs = CLIArgs({})
    a = [1, 2, 3]
    cliargs._options = {'a': a}
    b = cliargs_deferred_get('a', shallowcopy=True)
    assert b() == a
    assert b() is not a
    a[0] = 10
    assert b() == [10, 2, 3]
    d = {'b': 1, 'c': 2}
    cliargs._options = {'d': d}
    e = cliargs_deferred_get('d', shallowcopy=True)
    assert e() == d
    assert e() is not d
    d['b'] = 10
    assert e() == {'b': 10, 'c': 2}

# Generated at 2022-06-22 19:50:11.559307
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({'global_foo': 'global_foo_value', 'global_bar': 'global_bar_value'})

    result = cliargs_deferred_get('global_foo')()
    assert result == 'global_foo_value'

    result = cliargs_deferred_get('global_bar')()
    assert result == 'global_bar_value'

    result = cliargs_deferred_get('global_baz', default='')()
    assert result == ''
    result = cliargs_deferred_get('global_baz', default='global_baz_value')()
    assert result == 'global_baz_value'

    result = cliargs_deferred_get('global_list', default=[])()
    assert result == []
    result = cliargs_def

# Generated at 2022-06-22 19:50:21.681287
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    import json
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert 'bar' == cliargs_deferred_get('foo')
    assert 'baz' == cliargs_deferred_get('qux', 'baz')
    assert 'bar' == cliargs_deferred_get('foo', shallowcopy=True)
    assert 'baz' == cliargs_deferred_get('qux', 'baz', shallowcopy=True)

    # shallowcopy functionality
    l = ['foo', 'bar', 'baz']
    s = set(l)
    d = {'foo': 'bar', 'baz': 'qux'}
    assert l == cliargs_deferred_get('foo', l)
    assert l == cliargs_def

# Generated at 2022-06-22 19:50:32.861511
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeCliArgs(dict):
        @classmethod
        def from_options(cls, options):
            for key in options:
                cls.__dict__[key] = options[key]
            return cls()

    myargs = FakeCliArgs.from_options({'foo': 'bar', 'a': 'b'})
    global CLIARGS
    CLIARGS = myargs
    func = cliargs_deferred_get('foo', default='defaultfoo')
    func2 = cliargs_deferred_get('foo', shallowcopy=True)
    func3 = cliargs_deferred_get('a', shallowcopy=True)

    assert func() == 'bar'
    assert func2() == 'bar'
    assert func3() == 'b'



# Generated at 2022-06-22 19:50:41.622540
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_default(default_arg, default_value):
        def set_cliargs(arg):
            pass  # Fill out later

        cla = cliargs_deferred_get('foo', default_arg)

        if default_value is None:
            # We're expecting the inner function to default to None
            assert cla() is None
            set_cliargs('bar')
            assert cla() == 'bar'
            set_cliargs('baz')
            assert cla() == 'baz'
            set_cliargs(None)
            assert cla() is None
        else:
            # We're expecting the inner function to default to default_value
            assert cla() == default_value
            set_cliargs('bar')
            assert cla() == 'bar'
            set_cliargs('baz')

# Generated at 2022-06-22 19:50:53.236509
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = ['bar1', 'bar2']
    assert cliargs_deferred_get('foo')() == ['bar1', 'bar2']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar1', 'bar2']

    CLIARGS['baz'] = {'foo1': 'bar1', 'foo2': 'bar2'}
    assert cliargs_deferred_get('baz')() == {'foo1': 'bar1', 'foo2': 'bar2'}
    assert cliargs_deferred_get('baz', shallowcopy=True)() == {'foo1': 'bar1', 'foo2': 'bar2'}

    CLIARGS['qux'] = ['bar1', 'bar2']
    assert cliargs_deferred

# Generated at 2022-06-22 19:51:01.473408
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    global CLIARGS
    CLIARGS = CLIArgs(dict(
        test_seq=['test1', 'test2'],
        test_mapping={'test1': 'test1', 'test2': 'test2'},
        test_set={'test1', 'test2'},
        test_unsafe_text=AnsibleUnsafeText('test'),
    ))

    assert cliargs_deferred_get('test_seq')() == ['test1', 'test2']
    assert cliargs_deferred_get('test_mapping')() == {'test1': 'test1', 'test2': 'test2'}