

# Generated at 2022-06-22 19:41:02.844386
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Bypass the singleton for testing
    class FakeArgs(dict):
        def get(self, key, default=None):
            return super(FakeArgs, self).get(key, default=default)

    fake_cliargs = FakeArgs({'some_list': [1, 2, 3],
                             'some_tuple': (1, 2, 3),
                             'some_dict': {'a': 'b'},
                             'some_set': set(['a', 'b', 'c'])
                             })
    global CLIARGS
    CLIARGS = fake_cliargs
    assert cliargs_deferred_get('some_list')() == [1, 2, 3]
    assert cliargs_deferred_get('some_tuple')() == (1, 2, 3)
    assert cliargs

# Generated at 2022-06-22 19:41:11.625477
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that a cliargs_deferred_get closure"""
    _init_global_context({'a': 1, 'b': 2, 'c': 'abc', 'd': {'d': 1}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == 2
    assert cliargs_deferred_get('e')('efg') == 'efg'
    assert cliargs_deferred_get('d', shallowcopy=True)() == {'d': 1}

# Generated at 2022-06-22 19:41:19.660193
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MockCliArgs(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def get(self, key, default=None):
            return self.__dict__.get(key, default)

    dict_1 = {'1':'1'}
    dict_2 = {'2':'2'}
    dict_3 = {}

    cli_args = MockCliArgs(
        value_1="value_1",
        list_1=[1, 2, 3],
        dict_1=dict_1,
        dict_2=dict_2,
        dict_3=dict_3,
    )
    cliargs = GlobalCLIArgs.from_options(cli_args)
    cliargs.get = cli_args.get



# Generated at 2022-06-22 19:41:30.977638
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-22 19:41:42.137542
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({
        'foo': ['bar', 'baz']
    })
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']

    # Test the handling of the default value
    assert cliargs_deferred_get('bar', default=['foo'])() == ['foo']
    assert cliargs_deferred_get('bar', default=['foo'], shallowcopy=True)() == ['foo']

    # Test the handling of the default value when there is a value in the cliargs
    CLIARGS = CLIArgs({
        'bar': ['bar', 'baz'],
    })
    assert cliargs_deferred

# Generated at 2022-06-22 19:41:52.962149
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def keyfunc(key):
        # Create the closure over getting a key from the CLI args
        return cliargs_deferred_get(key, shallowcopy=True)

    cliargs = {
            'foo': [1, 2, 3],
            'bar': {'a': 1},
            'baz': 'string',
            }
    _init_global_context(cliargs)

    # Verify we get the same thing back
    for key, value in cliargs.items():
        assert keyfunc(key)() is value

    # Verify a shallow copy was taken
    foo = keyfunc('foo')()
    assert foo is not cliargs['foo']
    assert foo == cliargs['foo']

    bar = keyfunc('bar')()
    assert bar is not cliargs['bar']
    assert bar == cli

# Generated at 2022-06-22 19:42:03.887873
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test_arg': 'bar'})
    assert cliargs_deferred_get('test_arg')() == 'bar'
    assert cliargs_deferred_get('no_such_arg')() is None
    assert cliargs_deferred_get('no_such_arg', default='baz')() == 'baz'

    CLIARGS = CLIArgs({'test_arg': ['foo', 'bar']})
    assert cliargs_deferred_get('test_arg')() == ['foo', 'bar']
    assert cliargs_deferred_get('test_arg', shallowcopy=True)() == ['foo', 'bar']

    CLIARGS = CLIArgs({'test_arg': {'key': 'val'}})
    assert cliargs_def

# Generated at 2022-06-22 19:42:07.667054
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test regular case
    _init_global_context({'a': 'b'})
    assert cliargs_deferred_get('a')() == 'b'

    # Test with a default that isn't set
    _init_global_context({'a': 'b'})
    assert cliargs_deferred_get('b', default='d')() == 'd'

    # Test with a default that is set
    _init_global_context({'a': 'b', 'b': 'd'})
    assert cliargs_deferred_get('b', default='e')() == 'd'

    # Test with shallow copy
    _init_global_context({'a': 'b', 'b': ['a', 'b']})

# Generated at 2022-06-22 19:42:17.593654
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    tmp = CLIARGS
    try:
        CLIARGS = {'foo': 3, 'bar': [1, 2]}
        assert cliargs_deferred_get('foo', 1)() == 3
        assert cliargs_deferred_get('foo', 1, True)() == 3
        assert cliargs_deferred_get('bar', 1, True)() == [1, 2]
        assert cliargs_deferred_get('bar', 1, False)() == [1, 2]
        assert cliargs_deferred_get('bar', 1)() == [1, 2]
        assert cliargs_deferred_get('baz', 1)() == 1
        assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    finally:
        CLI

# Generated at 2022-06-22 19:42:28.670258
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({"a": 1, "b": [1, 2, 3], "c": {"d": 1}})
    assert cliargs_deferred_get("a", 2)() == 1
    assert cliargs_deferred_get("b", [])() == [1, 2, 3]
    assert cliargs_deferred_get("c", {})() == {"d": 1}

    assert cliargs_deferred_get("d", [])() == []
    assert cliargs_deferred_get("d", {})() == {}
    assert cliargs_deferred_get("d", 2)() == 2

    assert cliargs_deferred_get("a", shallowcopy=True)() == 1

# Generated at 2022-06-22 19:42:39.148307
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the default behavior
    _init_global_context({})
    get = cliargs_deferred_get('test_key')
    assert get() is None

    # Test getting the default
    _init_global_context({})
    get = cliargs_deferred_get('test_key', default=42)
    assert get() == 42

    # Test getting a value
    _init_global_context({'test_key': 42})
    get = cliargs_deferred_get('test_key')
    assert get() == 42
    get = cliargs_deferred_get('test_key', default=0)
    assert get() == 42

    # Test getting a value from a different object
    # pylint: disable=protected-access
    _init_global_context({'test_key': 42})

# Generated at 2022-06-22 19:42:49.683940
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'some_key': 'some_value'}
    _init_global_context(cli_args)
    assert "some_value" == cliargs_deferred_get('some_key')()
    assert "default_value" == cliargs_deferred_get('some_other_key', default='default_value')()
    assert "default_value" == cliargs_deferred_get('still_another_key', default='default_value')()
    # Test shallow copy
    cli_args['another_key'] = [1, 2, 3]
    assert [1, 2, 3] == cliargs_deferred_get('another_key', shallowcopy=True)()
    assert not cliargs_deferred_get('another_key', shallowcopy=True)() is cli_args

# Generated at 2022-06-22 19:42:54.930971
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    CLIARGS.update(
        {
            'logging_plugin_filters': ['plugin_a', 'plugin_b'],
            'a_dict': {'foo': 'bar'},
            'a_set': set(['foo']),
            'a_list': [1, 2, 3],
            'a_string': 'foo',
        }
    )

    # Get a clone
    for key in CLIARGS:
        value = cliargs_deferred_get(key, shallowcopy=True)
        assert CLIARGS[key] is not value
        assert CLIARGS[key] == value

    # Don't clone
    for key in CLIARGS:
        value = cliargs_deferred_get(key, shallowcopy=False)
        assert CLIARGS[key] is value

# Generated at 2022-06-22 19:43:02.860956
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    def test_type(default, shallowcopy, expected):
        os.environ['ANSIBLE_PRIVATE_ROOT_PATHS'] = '/some/path'
        CLIARGS = GlobalCLIArgs.from_options(dict(private_data_dir=None, private_root_dirs='/some/path'))
        assert isinstance(cliargs_deferred_get('private_data_dir', default, shallowcopy), expected)
        CLIARGS = CLIArgs(dict(private_data_dir=None))

    test_type(None, False, type(None))
    test_type(None, True, type(None))
    test_type('a', False, str)
    test_type('a', True, str)
    test_type([], False, list)

# Generated at 2022-06-22 19:43:08.672418
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that the cliargs_deferred_get function wraps CLIARGS.get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})

    inner = cliargs_deferred_get('foo')
    assert callable(inner)
    assert inner() == 'bar'

    CLIARGS = CLIArgs({'foo': 'baz'})
    assert inner() == 'baz'

# Generated at 2022-06-22 19:43:18.515773
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Type of the object needs to be immutable.  Otherwise, the test would modify
    # the underlying object that the closure returns and we want to make sure that
    # the closure is always returning a new value.
    CLIARGS = GlobalCLIArgs.from_options({"loglevel": 51})
    assert cliargs_deferred_get("loglevel")() == 51
    assert cliargs_deferred_get("loglevel", default=52)() == 51
    assert cliargs_deferred_get("loglevel", default=52, shallowcopy=True)() == 51
    assert cliargs_deferred_get("loglevel", shallowcopy=True)() == 51
    assert cliargs_deferred_get("loglevel")() == 51

# Generated at 2022-06-22 19:43:29.604141
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 'b'})
    func = cliargs_deferred_get('a', default='c', shallowcopy=False)
    assert func() == 'b'
    func = cliargs_deferred_get('b', default='c', shallowcopy=False)
    assert func() == 'c'
    func = cliargs_deferred_get('a', default='c', shallowcopy=True)
    assert func() == 'b'
    func2 = cliargs_deferred_get('a', default='c', shallowcopy=True)
    assert func() == func2()
    # While we're here we might as well also test that we can use a closure to wrap
    # the global CLIARGS object

# Generated at 2022-06-22 19:43:37.890473
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import unittest

    class TestCliargsDeferredGet(unittest.TestCase):
        def setUp(self):
            class TestCliArgs(object):
                """Test wrapper around CLIARGS"""
                pass
            self.TestCliArgs = TestCliArgs
            self.global_cliargs = CLIARGS

            class TestCliArgsGlobal(object):
                """Test wrapper around global CLIARGS"""
                pass
            self.TestCliArgsGlobal = TestCliArgsGlobal
            self.global_cliargs_global = CLIARGS

            self.global_cliargs_global.__dict__.clear()

            global CLIARGS
            CLIARGS = self.TestCliArgs()
            CLIARGS.__dict__.clear()

        def tearDown(self):
            global CLIARGS
            CLIAR

# Generated at 2022-06-22 19:43:45.032119
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Set up a dummy context
    class TestContext(object):
        def update(self, other):
            for k, v in other.items():
                setattr(self, k, v)

    global CLIARGS
    orig_context = CLIARGS
    dummy_context = TestContext()
    dummy_context.update({
        'b_opt': True,
        'foo': 'bar',
        'list_opt': [1, 2, 3],
        'dict_opt': {'a': 1, 'b': 2},
        'set_opt': set([1, 2, 3]),
    })
    CLIARGS = dummy_context

    # Test no copy
    b_opt = cliargs_deferred_get('b_opt')
    assert b_opt() is dummy_context.b_opt

    # Test copy

# Generated at 2022-06-22 19:43:55.231167
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'a':1, 'b':None, 'c':'foo', 'd':[1,2,3], 'e':{1:2}, 'f':set([1,2,3])})

    assert cliargs_deferred_get("a")() == 1
    assert cliargs_deferred_get("b")() is None
    assert cliargs_deferred_get("c")() == 'foo'
    assert cliargs_deferred_get("d")() == [1,2,3]
    assert cliargs_deferred_get("e")() == {1:2}
    assert cliargs_deferred_get("f")() == set([1,2,3])


# Generated at 2022-06-22 19:44:05.032758
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get function"""
    global CLIARGS
    # Test with empty CLIARGS
    CLIARGS = CLIArgs({})
    assert 'foo' == cliargs_deferred_get('foo', default='foo')()
    assert 'a' == cliargs_deferred_get('a', default='a')()
    assert 'b' == cliargs_deferred_get('b', default='b')()
    # Test with CLIARGS with set key
    CLIARGS = CLIArgs({'a': 'A'})
    assert 'A' == cliargs_deferred_get('a', default='a')()
    assert 'b' == cliargs_deferred_get('b', default='b')()

# Generated at 2022-06-22 19:44:14.482404
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=import-outside-toplevel
    from ansible.utils.context_objects import CliArgs
    CLIARGS = CliArgs({'foo': 'bar'})

    def_get = cliargs_deferred_get('foo')
    assert def_get() == 'bar'

    def_get = cliargs_deferred_get('bar', default='baz')
    assert def_get() == 'baz'

    CLIARGS = CliArgs({'foo': 'bar'})
    def_get = cliargs_deferred_get('foo', shallowcopy=True)
    assert def_get() == 'bar'

# Generated at 2022-06-22 19:44:24.037191
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Override CLIARGS so that it is not modified.
    # Note that this function is not a bound method so it can use a global
    import __main__
    __main__.CLIARGS = CLIArgs({"a": {"b": {"c": 1}}})

    # Test the deferred get with shallow copy disabled
    assert cliargs_deferred_get("a")() == {"b": {"c": 1}}
    assert cliargs_deferred_get("a.b")() == {"c": 1}
    assert cliargs_deferred_get("a.b.c")() == 1

    # Test the deferred get with shallow copy enabled
    assert cliargs_deferred_get("a", shallowcopy=True)() == {"b": {"c": 1}}

# Generated at 2022-06-22 19:44:28.953082
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # make sure it works with a normal non-deferred context
    test_context = CLIArgs({'foo': 1})
    foo = cliargs_deferred_get('foo')()
    assert foo == 1


# PluginLoader is tested in test_utils_module_loader
__unittest_module__ = True

# Generated at 2022-06-22 19:44:39.127375
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Foo:
        bar = cliargs_deferred_get('foo')
    foo = Foo()
    _init_global_context(object())
    assert foo.bar == None
    CLIARGS['foo'] = 'hello'
    assert foo.bar == 'hello'
    CLIARGS['foo'] = [1,2,3]
    assert foo.bar == [1,2,3]
    # bar.baz should point to the same value that CLIARGS['foo'] points to
    # since we are shallow copying it
    foo.bar.append('world')
    assert foo.bar == [1,2,3,'world']
    assert CLIARGS['foo'] == [1,2,3,'world']
    # Assert that it works with a default
    del CLIARGS['foo']

# Generated at 2022-06-22 19:44:49.483448
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import AttributeDict
    import copy
    global CLIARGS
    CLIARGS = AttributeDict({
        'foo': 'bar',
        'baz': [1, 2, 3],
        'dict': {'k1': 'v1'},
        'something_else': None,
    })
    orig = CLIARGS.copy()
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('dict')() == {'k1': 'v1'}
    assert cliargs_deferred_get('something_else')() is None

# Generated at 2022-06-22 19:44:55.035590
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Verify that it works with the fake CLIARGS that is set in module_utils/common/__init__.py
    assert cliargs_deferred_get('ok_return')() == 'all'
    assert cliargs_deferred_get('changed_when')() == ['always']
    assert cliargs_deferred_get('retries')() == 2

    # When we replace CLIARGS, the closure's value should still work.  This is
    # important as ``CLIARGS`` gets replaced once the CLI arguments are parsed
    CLIARGS = CLIArgs({'ok_return': 'something_else',
                       'changed_when': ['never'],
                       'retries': 0})
    assert cliargs_deferred_get('ok_return')() == 'something_else'
    assert cli

# Generated at 2022-06-22 19:45:06.022580
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name,unused-variable
    # pylint: disable=unused-argument,missing-docstring
    import pytest

    # key isn't set.  returns default
    def test_key_not_set(capfd):
        CLIARGS.update({'foo': 'bar'})
        assert cliargs_deferred_get('baz')('bob') == 'bob'
        out, err = capfd.readouterr()
        assert not out
        assert not err

    # key set, shallowcopy is False, returns value
    def test_key_set_shallowcopy_false(capfd):
        CLIARGS.update({'foo': 'bar'})
        assert cliargs_

# Generated at 2022-06-22 19:45:16.346766
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeGlobalCLIArgs(object):
        def __init__(self, vals):
            self._internal = vals

        def __getitem__(self, key):
            return self._internal[key]

        def __contains__(self, key):
            return key in self._internal

        def get(self, key, default=None):
            return self._internal.get(key, default=default)

    data = {'foo': 1, 'bar': 2}
    func = cliargs_deferred_get('foo')
    func2 = cliargs_deferred_get('bar')
    func3 = cliargs_deferred_get('nonexist', default='val')
    real_cliargs = CLIARGS

# Generated at 2022-06-22 19:45:25.770953
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class test_class:
        # Deferred setting of cliarg attribute that is also shallow copied
        test_cliarg = cliargs_deferred_get('test_cliarg', shallowcopy=True)
        # Deferred setting of a cliarg attribute that is NOT shallow copied
        test_other_cliarg = cliargs_deferred_get('test_other_cliarg')

    # Test cliargs_deferred_get with CLIARGS unset
    t = test_class()
    # Check that we can get and set the attribute if it's not in CLIARGS
    t.test_cliarg = 'foo'
    assert t.test_cliarg == 'foo'
    # Check that we can get the attribute from CLIARGS if it's not set
    assert t.test_other_cliarg == 'bar'

    # Test

# Generated at 2022-06-22 19:45:36.787376
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    global CLIARGS
    # NOTE: We can't just use a mock object here as the closure will not be
    #       bound to the mock object.  Instead we create a simple object that
    #       behaves exactly as the CLIArgs object will behave.  We are not
    #       testing the underlying behavior of the CLI object, just that
    #       it is forwarding its options appropriately.
    class FakeCliArgs(dict):
        """Object that looks like a CLIArgs without the Mapping methods"""
        def get(self, key, default=None):
            return super(FakeCliArgs, self).get(key, default)

    CLIARGS = FakeCliArgs({'myopt': 'myvalue'})
    assert cliargs_deferred_get('myopt')() == 'myvalue'


# Generated at 2022-06-22 19:45:46.198425
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo')() is None
    def get_cliargs_foo():
        return CLIARGS.get('foo')
    CLIARGS.set('foo', 'bar')
    assert get_cliargs_foo() == 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS.set('foo', [1, 2, 3])
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=False)() == [1, 2, 3]

# Generated at 2022-06-22 19:45:51.769365
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs
    # Test with a context where the key is known
    CLIARGS = CliArgs({'acme': 'foo'})
    assert cliargs_deferred_get('acme')() == 'foo'
    assert cliargs_deferred_get('acme', default='bar')() == 'foo'

    # Test with a context where the key is not known
    assert cliargs_deferred_get('example')() is None
    assert cliargs_deferred_get('example', default='bar')() == 'bar'

    # Test with a context where the key is not known
    CLIARGS = CliArgs({'acme': ['foo', 'bar']})

# Generated at 2022-06-22 19:46:01.740168
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.text.converters import to_text
    from ansible import module_utils
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as td:
        the_ansible_path = os.path.join(td, 'ansible')
        module_utils.MODULEUTILS_PATH.insert(0, the_ansible_path)
        to_text('unittest').write_bytes(open(os.path.join(the_ansible_path, 'ansible_test.py'), 'wb'))

        assert 'unittest' == to_text(cliargs_deferred_get('module_utils')().get('ansible_test.py', default=None))


# Generated at 2022-06-22 19:46:10.762065
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the default is returned if the argument is not specified
    cli_args = {}
    _init_global_context(cli_args)
    assert (cliargs_deferred_get('foo')(), None) == (cliargs_deferred_get('foo', default=None)(), None)
    assert (cliargs_deferred_get('foo')(), 'bar') == (cliargs_deferred_get('foo', default='bar')(), 'bar')
    assert (cliargs_deferred_get('foo')(), []) == (cliargs_deferred_get('foo', default=[])(), [])
    assert (cliargs_deferred_get('foo')(), {}) == (cliargs_deferred_get('foo', default={})(), {})

    # Test that the default is not returned if the argument

# Generated at 2022-06-22 19:46:21.572180
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    old_args = CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [2, 3], 'c': {'d': 4}})
    assert cliargs_deferred_get('a', default='foo')() == 1
    assert cliargs_deferred_get('b', default='foo')() == [2, 3]
    assert cliargs_deferred_get('c', default='foo')() == {'d': 4}
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('b', shallowcopy=True)() == [2, 3]
    assert cliargs_deferred_get('c', shallowcopy=True)() == {'d': 4}

# Generated at 2022-06-22 19:46:32.811663
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for cliargs_deferred_get

    Verify that the function returned by the function actually gets the value
    from CLIARGS and performs the shallow copy.
    """
    from ansible.module_utils.common.text.converters import to_text

    _init_global_context({})
    assert CLIARGS.get('lcm_method') is None
    assert cliargs_deferred_get('lcm_method')().get('last') is None
    CLIARGS = CLIArgs({'lcm_method': {'first': 'a', 'second': 'b', 'last': 'c'}})
    assert CLIARGS.get('lcm_method').get('last') == to_text('c')
    assert CLIARGS.get('lcm_method') is not cliargs_deferred_get

# Generated at 2022-06-22 19:46:40.381176
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get for all valid key types"""
    def test_get(key, value):
        """Helper method to test cliargs_deferred_get"""
        value_a = cliargs_deferred_get(key, default=value)()
        value_b = cliargs_deferred_get(key, default=value, shallowcopy=True)()
        if isinstance(value, (Mapping, Set)):
            assert value is not value_a
            assert value is not value_b
            assert value == value_a
            assert value == value_b
        elif is_sequence(value):
            # sequences are allowed to be shallow copied
            assert value is not value_a
            assert value == value_a
            assert value is value_b
        else:
            assert value is value_a

# Generated at 2022-06-22 19:46:51.159020
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    context = CLIArgs({'a': 1, 'b': [1, 2]})

    # Bound function doesn't work in Python 2.6
    # get_a = cliargs_deferred_get('a')
    # get_b = cliargs_deferred_get('b')
    # get_c = cliargs_deferred_get('c', default=3)

    # Manual bound functions for Python 2.6 down to 2.4
    def get_a(): return cliargs_deferred_get('a')()
    def get_b(): return cliargs_deferred_get('b')()
    def get_c(): return cliargs_deferred_get('c', default=3)()

    assert 1 == get_a()
    assert [1, 2] == get_b()
    assert 3 == get

# Generated at 2022-06-22 19:47:00.053700
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function ``cliargs_deferred_get``"""
    # pylint: disable=function-redefined
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name

    intreg = 0
    intreg2 = 0
    listreg = []
    dictreg = {}
    dictreg2 = {}
    setreg = set()

    assert CLIARGS == {}

    # Regular get
    func = cliargs_deferred_get('mykey')
    value = func()
    assert value is None

    # Default value
    func = cliargs_deferred_get('mykey', 5)
    value = func()
    assert value == 5

    # Return proper value
    CLIARGS['mykey'] = 9
    func = cliargs_deferred_get

# Generated at 2022-06-22 19:47:08.122500
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('--verbosity')() == 0
    assert cliargs_deferred_get('--check')() is False
    assert cliargs_deferred_get('tags', default='foo')() == 'foo'

    assert cliargs_deferred_get('--verbosity', shallowcopy=True)() == 0
    assert cliargs_deferred_get('--check', shallowcopy=True)() is False
    assert cliargs_deferred_get('tags', default='foo', shallowcopy=True)() == 'foo'

# Generated at 2022-06-22 19:47:11.734527
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def inner():
        global CLIARGS
        CLIARGS = CLIArgs({'testkey': 'testvalue'})
        assert cliargs_deferred_get('testkey')() is CLIARGS['testkey']
    inner()

# Generated at 2022-06-22 19:47:20.239147
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Function: cliargs_deferred_get

    This test ensures that we return a copy of the default value if
    shallowcopy is set and check that the default value is properly
    returned if it is not set
    """
    import copy
    cliargs_unevaluated = CLIArgs({})
    default_list = [1, 2, 3]
    default_dict = {'a': 1, 'b': 2}
    assert cliargs_unevaluated.get(
        'key_which_is_not_set',
        default=default_list
    ) == default_list
    assert cliargs_unevaluated.get(
        'key_which_is_not_set',
        default=default_dict
    ) == default_dict

# Generated at 2022-06-22 19:47:30.637618
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    if CLIARGS is not None:  # pragma: no branch (if we're testing, CLIARGS should have already been created)
        # grab the real CLIARGS object and save it
        orig_cliargs = CLIARGS
    else:
        orig_cliargs = None

# Generated at 2022-06-22 19:47:40.055190
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    cli_args = {'one': 1, 'two': [1, 2, 3], 'three': {'one': 1, 'two': 2}, 'four': {1, 2, 3}}
    global CLIARGS
    CLIARGS = CLIArgs(cli_args)

    def _helper(key, default, shallow, expected):
        result = cliargs_deferred_get(key, default=default, shallowcopy=shallow)()
        assert result == expected

    # testing default
    _helper('not_in_cli_args', 'default', False, 'default')

    # testing primitive types
    _helper('one', 'default', False, 1)
    _helper('one', 'default', True, 1)

    # testing sequence types

# Generated at 2022-06-22 19:47:49.728731
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils import basic

    cli_args = {'vault_password_file': 'default_vault_password_file',
                'tags': ['tag_one', 'tag_two'],
                'verbosity': 3,
                'inventory': {'hosts': ['one', 'two'], 'vars': {'ansible_ssh_user': 'admin'}}}

    # test with CLIARGS set to the 'singleton' version
    _init_global_context(cli_args)

    # test getting a value without shallowcopy
    assert cliargs_deferred_get('vault_password_file') == 'default_vault_password_file'

    # test getting a value with shallowcopy

# Generated at 2022-06-22 19:48:00.150787
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence

    foo = dict(a=1,
               b=2,
               c=3)

    bar = cliargs_deferred_get('foo', default=foo)
    assert foo == bar()
    assert foo is not bar()

    foocopy = cliargs_deferred_get('foo', default=foo, shallowcopy=True)
    assert foo == foocopy()
    assert foo is not foocopy()

    baz = cliargs_deferred_get('baz', default=foo, shallowcopy=True)
    assert foo == baz()
    assert foo is not baz()

    # Call the closure multiple times and ensure it returns the same value
    for _ in range(100):
        assert foo == bar()

# Generated at 2022-06-22 19:48:07.717934
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Trivial test: nothing set
    assert '' == cliargs_deferred_get('test1')(), "test1 should be empty"
    assert '' == cliargs_deferred_get('test1', 'test')(), "test1 should be empty"
    assert 'test' == cliargs_deferred_get('test2', 'test')(), "test2 should be test"

    # Test copy vs shallow copy
    CLIARGS['test_list'] = ['one', 'two']
    assert ['one', 'two'] == cliargs_deferred_get('test_list', shallowcopy=True)(), "test_list should be shallow copied"
    assert ['one', 'two'] == cliargs_deferred_get('test_list', shallowcopy=False)(), "test_list should be shallow copied"

# Generated at 2022-06-22 19:48:17.817117
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from copy import copy

    cliargs = GlobalCLIArgs({'key0': 'value', 'key1': ['a', 'b', 'c'], 'key2': {'a': 0, 'b': 1, 'c': 2},
                             'key3': {'a', 'b', 'c'}})

    assert cliargs_deferred_get('key0')(cliargs) == 'value'
    assert cliargs_deferred_get('key1')(cliargs) == ['a', 'b', 'c']
    assert cliargs_deferred_get('key2')(cliargs) == {'a': 0, 'b': 1, 'c': 2}
    assert cliargs_deferred_get('key3')(cliargs)

# Generated at 2022-06-22 19:48:29.282476
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is a unit test for the function cliargs_deferred_get.  We aren't testing functionality
    # of the Context itself.

    def get_cliargs(self):
        return CLIARGS

    CLIARGS.__get__ = get_cliargs
    CLIARGS.__set__ = lambda x, y: None

    assert cliargs_deferred_get('foo')() is None
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default=True)() is True
    assert cliargs_deferred_get('foo', default='not bar')() == 'bar'

# Generated at 2022-06-22 19:48:39.937341
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check_value(key, expected, value=None):
        if value is None:
            value = default
        assert cliargs_deferred_get(key, default=default)() == expected

    default = {'a': [1,2,3], 'b': {'c': 1}, 'd': (True, False)}
    cli_args = {'a': [4,5,6], 'b': {'c': 2}, 'd': (True, True, False), 'e': True}

    # Test normal get
    _init_global_context(cli_args)
    check_value('a[0]', 4)
    check_value('b.c', 2)
    check_value('d.1', True)
    check_value('e', True)

    # Test missing key

# Generated at 2022-06-22 19:48:45.919384
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert cliargs_deferred_get('debug')() is False
    CLIARGS = CLIArgs({'debug': True})
    assert cliargs_deferred_get('debug')() is True
    assert cliargs_deferred_get('debug')() is True
    assert cliargs_deferred_get('verbosity')() == 4
    assert cliargs_deferred_get('verbosity')() == 4
    assert cliargs_deferred_get('verbosity', 0)() == 4
    assert cliargs_deferred_get('verbos')() is None

# Generated at 2022-06-22 19:48:53.658660
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make sure we get the defaults from the cliargs_deferred_get
    from ansible.module_utils.common._collections_compat import MutableMapping
    global CLIARGS
    CLIARGS = MutableMapping()
    f = cliargs_deferred_get('key', default='foo')
    assert f() == 'foo'

    # Make sure we can get the globals
    CLIARGS['key'] = 'bar'
    assert f() == 'bar'

    # Make sure that we get a shallow copy of mutable objects
    CLIARGS['key'] = ['baz']
    assert f(shallowcopy=True) == ['baz']

    # Make sure that we get a shallow copy of mutable objects
    CLIARGS['key'] = {'value': 'buz'}

# Generated at 2022-06-22 19:49:04.952642
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS._data = {}
    f = cliargs_deferred_get('foo')
    assert f() is None

    CLIARGS._data = {'foo': 42}
    f = cliargs_deferred_get('foo')
    assert f() == 42

    CLIARGS._data = {'foo': 42}
    f = cliargs_deferred_get('foo', default='bar')
    assert f() == 42

    CLIARGS._data = {}
    f = cliargs_deferred_get('foo', default='bar')
    assert f() == 'bar'

    CLIARGS._data = {'foo': 42}
    f = cliargs_deferred_get('foo', shallowcopy=True)
    assert f() == 42

    CLIARGS._data = {'foo': [42]}

# Generated at 2022-06-22 19:49:14.714407
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Note that we use a fake cliargs object here because_init_global_context() would have
    # replaced it otherwise.
    # Note further, that this function is a closure.  It returns an object which has a __call__
    # method.  Within __call__ it accesses the CLIARGS variable.  The closure will access the value
    # of CLIARGS at the time of its definition, not the time when it is called.  This means we
    # must set the CLIARGS variable before creating the closure, not after.
    CLIARGS = CLIArgs({'ANSIBLE_FOO': 'ANSIBLE_FOO VALUE', 'ANSIBLE_BAR': 'ANSIBLE_BAR VALUE'})

# Generated at 2022-06-22 19:49:23.136689
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def assert_cliargs_deferred_get(key, value, ref_value, shallowcopy=False):
        cli_args = {key: value}
        _init_global_context(cli_args)
        assert ref_value == cliargs_deferred_get(key, shallowcopy=shallowcopy)()

    # test a scalar value
    assert_cliargs_deferred_get('const', 'test_const', 'test_const')

    # test a list value
    list_val = ['foo', 'bar']
    assert_cliargs_deferred_get('list', list_val, list_val)

    # test a list value with shallow copy
    assert_cliargs_deferred_get('list', list_val, list_val[:], shallowcopy=True)

    # test a dict value
    dict_

# Generated at 2022-06-22 19:49:33.540814
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    a = cliargs_deferred_get('foo')
    assert 'foo' not in CLIARGS._internal_args
    assert a() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz'], 'bar': True, 'baz': {1: 2}})
    b = cliargs_deferred_get('foo', shallowcopy=True)
    c = cliargs_deferred_get('bar')
    d = cliargs_deferred_get('baz', shallowcopy=True)
    assert type(b()) is list
    assert b() == ['bar', 'baz']
    assert b() is not CLIARGS['foo']
    assert c() is True

# Generated at 2022-06-22 19:49:43.615582
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'abc': 123, 'def': [1, 2, 3]})
    shallow = cliargs_deferred_get('abc', shallowcopy=True)
    deep = cliargs_deferred_get('def', shallowcopy=True)
    assert shallow() == 123
    assert deep() == [1, 2, 3]
    assert cliargs_deferred_get('aoeu')() is None
    CLIARGS['abc'] = 111
    assert shallow() == 111
    CLIARGS['def'] = [4, 5, 6]
    assert deep() == [1, 2, 3]

# Generated at 2022-06-22 19:49:54.044675
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')().startswith('bar') is True
    assert cliargs_deferred_get('notfoo', 'foo')().startswith('foo') is True
    assert cliargs_deferred_get('notfoo')().startswith('foo') is False

    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')().pop().startswith('baz') is True
    assert cliargs_deferred_get('foo')().pop().startswith('bar') is True

# Generated at 2022-06-22 19:50:04.215910
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS.update({'foo': 'bar', 'a': [1, 2, 3], 'b': {'c': 5, 'd': 6}})

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('a')() == [1, 2, 3]
    assert cliargs_deferred_get('b')() == {'c': 5, 'd': 6}

    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('a', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('b', shallowcopy=True)() == {'c': 5, 'd': 6}

   

# Generated at 2022-06-22 19:50:14.275869
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    def test_inner(cliargs, key, default, shallowcopy, result):  # pylint: disable=redefined-outer-name
        old_cliargs = CLIARGS
        CLIARGS = cliargs
        inner = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)
        assert inner() == result
        CLIARGS = old_cliargs


# Generated at 2022-06-22 19:50:22.763419
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    args = {
        'foo': 'bar',
        'baz': ['1', '2', '3'],
        'qux': {
            'q': 'e',
            'a': 'b',
        }
    }

    # Test that the default value is used
    CLIARGS = CLIArgs(args)
    assert cliargs_deferred_get(key='abc', default='abc') == 'abc'

    # Test that the key is not in CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get(key='abc', default='abc') == 'abc'

    # Test that the key is in CLIARGS and no shallow copy
    CLIARGS = CLIArgs(args)

# Generated at 2022-06-22 19:50:33.855433
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'one': '1', 'two': 2})

    assert '1' == cliargs_deferred_get('one')()
    assert 2 == cliargs_deferred_get('two')()
    assert [] == cliargs_deferred_get('empty_list')()
    assert {} == cliargs_deferred_get('empty_dict')()
    assert set() == cliargs_deferred_get('empty_set')()

    assert [] == cliargs_deferred_get('empty_list', shallowcopy=True)()
    assert {} == cliargs_deferred_get('empty_dict', shallowcopy=True)()
    assert set() == cliargs_deferred_get('empty_set', shallowcopy=True)()


# Generated at 2022-06-22 19:50:42.302407
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': 2})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == 2
    assert cliargs_deferred_get('c')() is None
    assert cliargs_deferred_get('c', 3)() == 3
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('c', shallowcopy=True)() is None
    CLIARGS = CLIArgs({'a': [1, 2, 3], 'b': {'b1': 1, 'b2': 2}, 'c': set([1, 2, 3])})

# Generated at 2022-06-22 19:50:48.771433
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.collection_functions import is_sequence, is_set_like, is_mapping_like

    from ansible.errors import AnsibleError
    class TestOptions(object):
        def __init__(self, *args, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    # Test shallow copy behavior
    # Create a sequence of same value

# Generated at 2022-06-22 19:50:56.137214
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs  # pylint: disable=unused-import
    from ansible.utils.context_objects import CLIArgs  # pylint: disable=unused-import

    _init_global_context({'verbosity': 0, 'connection': 'local', 'module_path': '.', 'module_language': '.'})
    assert cliargs_deferred_get('verbosity') == 0

    assert cliargs_deferred_get('foo', default=5) == 5
    CLIARGS['foo'] = 3
    assert cliargs_deferred_get('foo', default=5) == 3
    assert cliargs_deferred_get('foo', default=[]) == 3
    CLIARGS['foo'] = [3]
    assert cliargs_deferred_get