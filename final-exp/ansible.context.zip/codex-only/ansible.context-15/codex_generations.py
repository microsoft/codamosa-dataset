

# Generated at 2022-06-22 19:41:08.104423
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def cli_args(*args):
        return dict([a.split('=', 1) for a in args])

    # None is the default
    assert CLIARGS.get('undefined', default=None) is None
    assert cliargs_deferred_get('undefined')() is None

    # default overrides None
    assert cliargs_deferred_get('undefined', default=42)() == 42

    # CLIARGS updates are reflected
    _init_global_context(cli_args('undefined=42'))
    assert cliargs_deferred_get('undefined', default=None)() == 42

    # default is not affected by CLIARGS
    assert cliargs_deferred_get('undefined', default=41)() == 41

# Generated at 2022-06-22 19:41:17.315375
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({'foo': 42})
    assert cliargs_deferred_get('foo')() == 42
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', default=42)() == 42
    # Sanity check that we return a shallow copy of lists
    cliargs = CLIArgs({'foo': [1, 2, 3]})
    list_copy = cliargs_deferred_get('foo', shallowcopy=True)()
    assert list_copy == [1, 2, 3]
    assert list_copy is not cliargs['foo']

# Generated at 2022-06-22 19:41:28.269235
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 5, 'b': {'c': [1, 2, 3]}, 'd': {1, 2, 3}})

    # Normal form: No shallow copy
    cfg = cliargs_deferred_get('a')()
    assert 5 == cfg
    cfg = cliargs_deferred_get('b')()
    assert {'c': [1, 2, 3]} == cfg
    cfg = cliargs_deferred_get('d')()
    assert {1, 2, 3} == cfg

    # Shallow copy of list
    cfg = cliargs_deferred_get('b', shallowcopy=True)()
    assert {'c': [1, 2, 3]} == cfg

# Generated at 2022-06-22 19:41:39.115720
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # These tests all run with global CLIARGS still being a regular CLIArgs so that the code
    # is covered even before the CLIARGS global is replaced with a GlobalCLIArgs
    assert cliargs_deferred_get('test')(), 'Default value should be None'
    assert cliargs_deferred_get('test', default=True)(), 'Easy test of default value'
    CLIARGS['test'] = 'foo'
    assert cliargs_deferred_get('test')(), 'Make sure we can get value'
    CLIARGS['test'] = ['test', 'foo']
    assert cliargs_deferred_get('test', shallowcopy=True)(), 'Make sure we can shallow copy sequence'
    CLIARGS['test'] = {'one': 1}

# Generated at 2022-06-22 19:41:48.161871
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set

    CLIARGS.clear()
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=False)() == 'bar'

    CLIARGS['foo'] = ['baz', 'bar']

# Generated at 2022-06-22 19:41:57.189445
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """sanity check for cliargs_deferred_get

    We're actually testing that the function works as expected.  We probably
    should have a test case in test_utils_context_objects instead that actually
    tests the wrapped functionality.
    """
    global CLIARGS
    assert cliargs_deferred_get('foo')(None) is None
    CLIARGS.update({'foo': 1})
    assert cliargs_deferred_get('foo')(None) == 1
    assert cliargs_deferred_get('foo', shallowcopy=True)(None) == 1
    v = {'foo': 1}
    CLIARGS.update({'bar': v})
    assert cliargs_deferred_get('bar')(None) is v

# Generated at 2022-06-22 19:42:06.100792
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': ['bar', 'baz'], 'boo': {'hoo': 1, 'zoo': 'cow'}, 'set': set([1, 2, 3])})
    deferred_get = cliargs_deferred_get
    assert deferred_get('foo') == ['bar', 'baz']
    assert deferred_get('bar', ['a', 'b']) == ['a', 'b']
    assert deferred_get('foo', default=['a', 'b']) == ['bar', 'baz']

    # Validate shallow copy
    result = deferred_get('foo', shallowcopy=True)
    assert result == ['bar', 'baz']
    result.append('qux')
    assert result == ['bar', 'baz', 'qux']
    assert CLI

# Generated at 2022-06-22 19:42:16.560762
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.context import GlobalCLIArgs

    # Test functions here
    def get_value(default=None):
        return default

    # set up a mock GlobalCLIArgs to be used in the test here
    class TestGlobalCLIArgs(GlobalCLIArgs):
        def get(self, key, default=None):  # pylint: disable=arguments-differ,redefined-builtin
            return get_value(default=default)

    # override the usage of GlobalCLIArgs in this test
    GlobalCLIArgs.from_options_with_defaults = lambda opts: TestGlobalCLIArgs(opts)

    # Simple test for cases where the default is not being used
    # pylint: disable=line-too-long
    assert cliargs_deferred_get('test')()

# Generated at 2022-06-22 19:42:24.996958
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access,too-few-public-methods

    class CliArgs(dict):
        """Mock class that implements just enough of the CliArgs interface to test that we get the
        expected shallow copy and shallow copy with default behavior
        """
        def get(self, key, default):
            if key in self:
                return self[key]
            return default

    class CliArgsDefault(CliArgs):
        """Mock class that implements just enough of the CliArgs interface to test that we get the
        expected shallow copy and shallow copy with default behavior
        """
        def get(self, key, default):
            return super(CliArgsDefault, self).get(key, default)

    # Single values are passed through
    for cls in (CliArgsDefault, CliArgs):
        cl_

# Generated at 2022-06-22 19:42:33.534758
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    test_cliargs = CLIArgs({})
    test_key = 'test_key'
    test_value = 'test_value'
    test_cliargs[test_key] = test_value
    assert cliargs_deferred_get(test_key)() == 'test_value'
    assert cliargs_deferred_get(test_key, default='hello')() == 'test_value'
    assert cliargs_deferred_get(test_key, default='hello', shallowcopy=True)() == 'test_value'

# Generated at 2022-06-22 19:42:43.963507
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({
        'one': 1,
        'two': [2, 4],
        'three': {3, 6},
        'four': {'four': 4},
        'five': 'five',
    })
    assert cliargs_deferred_get('one')() is 1
    assert cliargs_deferred_get('five')() == 'five'
    assert cliargs_deferred_get('five', shallowcopy=True)() == 'five'
    assert cliargs_deferred_get('six', shallowcopy=True)() is None

    assert cliargs_deferred_get('two', shallowcopy=True)() == [2, 4]
    assert cliargs_deferred_get('three', shallowcopy=True)() == {3, 6}
   

# Generated at 2022-06-22 19:42:55.697534
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.collections import is_sequence, is_mapping

    # Make a test 'Foo' object that is not a sequence
    class Foo(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value
        def copy(self):
            return Foo(self.name, self.value[:])

    # Create the closure
    defer_get_foo = cliargs_deferred_get('foo')

    # The closure can be called before CLIARGS is initialized
    assert defer_get_foo() == None

    _init_global_context(dict(foo='bar'))

    # The closure can be called after CLIARGS is initialized
    assert defer_get

# Generated at 2022-06-22 19:43:04.952710
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.__dict__['_deferred_defaults']['test_key'] = cliargs_deferred_get('test_key')
    CLIARGS.__dict__['test_key'] = 'test_value'
    assert CLIARGS.test_key == 'test_value'
    CLIARGS.__dict__['test_key'] = ['test_value']
    assert CLIARGS.test_key == ['test_value']
    CLIARGS.__dict__['test_key'] = {'test_value': 1}
    assert CLIARGS.test_key == {'test_value': 1}
    CLIARGS.__dict__['test_key'] = set(['test_value'])
    assert CLIARGS.test_key == set(['test_value'])
    CLIARGS.__

# Generated at 2022-06-22 19:43:10.824824
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)

    f = cliargs_deferred_get('foo')
    assert f() == 'bar'
    f = cliargs_deferred_get('frobnitz')
    assert f() is None
    f = cliargs_deferred_get('frobnitz', default='test')
    assert f() == 'test'

# Generated at 2022-06-22 19:43:20.225927
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Closure over getting a key from CLIARGS with shallow copy functionality
    """

    test_options = {'tag': 'tag_value',
                    'diff': True,
                    'some_list': [1, 2, 3],
                    'some_dict': {'some_key': 'value'},
                    'some_set': set([1, 2, 3, 4]),
                    }
    _init_global_context(test_options)
    assert [1, 2, 3] == cliargs_deferred_get('some_list')()
    cliargs_deferred_get('some_list')()[0] = 0
    assert [0, 2, 3] == cliargs_deferred_get('some_list')()

# Generated at 2022-06-22 19:43:30.084825
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    old_CLIARGS = CLIARGS

    def cleanup_cliargs():
        global CLIARGS
        CLIARGS = old_CLIARGS


# Generated at 2022-06-22 19:43:38.302656
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    test_list = [1, 2, 3]
    test_dict = {'a': 1, 'b': 2}
    test_set = set()

    def set_cli_args(cli_args):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    cli_args = dict(test_list=test_list, test_dict=test_dict, test_set=test_set)
    set_cli_args(cli_args)

    # Test with shallowcopy
    assert cliargs_deferred_get('test_list')() is test_list
    assert cliargs_deferred_get('test_list', shallowcopy=True)() is not test_list

# Generated at 2022-06-22 19:43:45.387966
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    @pytest.fixture
    def mock_cliargs(monkeypatch):
        """Fixture for mocking CLIARGS"""

        def inner() -> CLIArgs:
            return CLIArgs({})

        monkeypatch.setattr(sys.modules['ansible.context'], 'CLIARGS', CLIARGS(inner()))

    def test_basic_get(mock_cliargs):
        key = 'foo'
        value = cliargs_deferred_get(key)()
        assert value == mock_cliargs().get(key)

    def test_default_get(mock_cliargs):
        key = 'foo'
        default = 'bar'
        value = cliargs_deferred_get(key, default=default)()
        assert value == default


# Generated at 2022-06-22 19:43:55.440345
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_dict = {
        'ansible_playbook_python': '/usr/bin/python',
        'ansible_verbosity': 2,
        'force_color': True,
        'inventory': '/etc/ansible/hosts',
        'skip_tags': ['always'],
    }
    _init_global_context(cliargs_dict)
    assert cliargs_deferred_get('inventory')() == cliargs_dict['inventory']
    assert cliargs_deferred_get('ansible_verbosity')() == cliargs_dict['ansible_verbosity']
    skip_tags_copy = cliargs_deferred_get('skip_tags', shallowcopy=True)()
    assert skip_tags_copy == ['always']

# Generated at 2022-06-22 19:44:01.904750
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    testval = {'a' : ['b', 'c']}
    _init_global_context({'key' : testval})
    deferred = cliargs_deferred_get('key', shallowcopy=False)
    assert deferred() is testval
    assert deferred() is not testval
    deferred = cliargs_deferred_get('key', shallowcopy=True)
    assert deferred() is not testval
    assert deferred() != testval
    assert deferred() == testval

# Generated at 2022-06-22 19:44:08.537841
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import textwrap

    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch, Mock

    import ansible_collections.ansible.netcommon.plugins.module_utils.network.common.config.cliargs as cliargs

    # test: get(key, default=None)

    cliargs.CLIARGS = Mock(autospec=True)
    cliargs.CLIARGS.get.side_effect = ['test default']

    deferred = cliargs_deferred_get('test_key')
    assert isinstance(deferred, type(lambda: None))
    assert deferred() == 'test default'
    cliargs.CLIARGS.get.assert_called_once_with('test_key', default=None)

    cliargs.CLIARGS

# Generated at 2022-06-22 19:44:18.414567
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.compat import is_py3
    from ansible.module_utils.common.collections import is_sequence
    global CLIARGS

    def test_closure(value):
        def inner():
            return value

        return inner

    def list_closure():
        return [2]

    def dict_closure():
        return {'a': 1}

    def set_closure():
        return {1, 2, 3}

    # List closure
    value = list_closure()
    if is_py3:
        inner_closure = value
    else:
        inner_closure = value.func_closure[0]
    assert is_sequence(value)
    assert value == [2]
    assert value is not inner_closure.cell_contents
    inner_func = cliargs_deferred

# Generated at 2022-06-22 19:44:28.350427
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCliArgs(CLIArgs):
        class Options:
            # Using both non-existing and existing values
            non_existing = cliargs_deferred_get('non_existing', 42)
            existing = cliargs_deferred_get('existing', 43)

    # Test that non-existing is set
    cliargs = TestCliArgs({})
    assert cliargs['non_existing'] == 42

    # Test that existing is set
    cliargs = TestCliArgs({'existing': 'existing value'})
    assert cliargs['existing'] == 'existing value'

    # Test that existing is set
    cliargs = TestCliArgs({'non_existing': 'existing value'})
    assert cliargs['non_existing'] == 'existing value'

# Generated at 2022-06-22 19:44:38.880108
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test CliArgs.deferred_get"""
    # Test empty args
    _init_global_context({})
    assert cliargs_deferred_get("not_a_key") is None
    assert cliargs_deferred_get("not_a_key", default="default") == "default"

    # Test single value, no default
    _init_global_context({"one_key": "one_value"})
    assert cliargs_deferred_get("one_key") == "one_value"
    assert cliargs_deferred_get("not_one_key") is None
    assert cliargs_deferred_get("not_one_key", default="default") == "default"

    # Test single value, with default

# Generated at 2022-06-22 19:44:49.206995
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    import yaml

    # Simple test with a single option
    ansible_args = CLIArgs(dict(option=dict(action='store', type='str')))
    _init_global_context(ansible_args)
    cliargs_deferred_get('option')() == 'None'

    # Another simple test with two options
    ansible_args = CLIArgs(dict(
        option1=dict(action='store', type='str', default='default1'),
        option2=dict(action='store', type='int', default=10),
    ))
    _init_global_context(ansible_args)
    assert cliargs_deferred_get('option1')() == 'default1'
    assert cliargs_deferred_get('option2')

# Generated at 2022-06-22 19:44:59.769328
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Test for default when not set in CLIARGS
    my_default = object()
    assert cliargs_deferred_get('test_key', default=my_default)() is my_default

    # Test for default when not set and no default provided
    assert cliargs_deferred_get('test_key')() is None

    # Test for value returned when key is set in CLIARGS
    CLIARGS['test_key'] = my_default
    assert cliargs_deferred_get('test_key')() is my_default

    # Test for value returned when key is not set in CLIARGS but type
    # is list
    CLIARGS['test_list_key'] = []
    assert cliargs_deferred_get('test_list_key', shallowcopy=True)() == []

    # Test for value returned

# Generated at 2022-06-22 19:45:08.903528
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test a key that exists
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo') == 'bar'

    # Test a key that does not exist
    assert cliargs_deferred_get('zip') is None

    # Test a key that exists in the default
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', 'default') == 'bar'

    # Test a key that does not exist in the default
    assert cliargs_deferred_get('zip', 'default') == 'default'

    # Test a key that exists with shallow copy
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True) == 'bar'

    # Test a sequence that exists with shallow copy


# Generated at 2022-06-22 19:45:17.478306
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Test when cliargs are not yet available
    # Test default value is returned
    def_value = 'clia_def'
    assert def_value == cliargs_deferred_get('not_set', default=def_value, shallowcopy=False)
    # Test that shallow copy of default value is returned
    assert def_value == cliargs_deferred_get('not_set', default=def_value, shallowcopy=True)

    from ansible.cli import CLI  # pylint: disable=redefined-outer-name
    from ansible.errors import AnsibleOptionsError  # pylint: disable=redefined-outer-name


# Generated at 2022-06-22 19:45:26.300880
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs

    orig_cliargs = GlobalCLIArgs.from_options({})
    CLIARGS.try_replace(orig_cliargs)

# Generated at 2022-06-22 19:45:37.260813
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import (
        DeferredDict, DeferredList, DeferredSet,
    )
    from ansible.module_utils.common.text.converters import to_str
    from ansible.module_utils.common.validation import check_type, check_type_str
    from ansible.module_utils._text import to_text

    # Make sure that the closure returns the correct type when the value is a string
    assert_str_is_str = check_type_str('assert_str_is_str')
    inner = cliargs_deferred_get('assert_str_is_str')
    assert_str_is_str(inner())
    assert_str_is_str(inner())
    assert_str_is_str(inner())

    # Make sure that the

# Generated at 2022-06-22 19:45:47.190893
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.six import PY2 as _PY2

    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')(), ('bar', 'String get')
    assert cliargs_deferred_get('bar')(), ('', 'Default get')
    CLIARGS = CLIArgs({'foo': None})
    assert cliargs_deferred_get('foo')(), (None, 'None get')
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': []})
    # Note: This differs between py2 and py3.  Py2 returns a list but py3 returns a generator

# Generated at 2022-06-22 19:45:57.030035
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import map_type
    from ansible.utils.context_objects import GlobalCLIArgs

    # Note: Must test using an object other than CLIARGS to make sure the function is not
    # accidentally bound to it
    from unittest.mock import Mock
    class FakeCLIARGS(GlobalCLIArgs):
        def __getattr__(self, name):
            return self[name]

    args = {'foo': 'bar'}
    cliargs = FakeCLIARGS(args)

    func = cliargs_deferred_get('foo')
    assert func() == 'bar'
    assert func() is args['foo']


# Generated at 2022-06-22 19:46:03.516159
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    global CLIARGS
    CLIARGS = CLIArgs({'force_handlers': True})
    print(cliargs_deferred_get('force_handlers', shallowcopy=True))
    print(cliargs_deferred_get('force_handlers'))
    print(cliargs_deferred_get('force_handlers', shallowcopy=True) is BOOLEANS_TRUE)
    print(cliargs_deferred_get('force_handlers') is BOOLEANS_TRUE)

# Generated at 2022-06-22 19:46:11.615223
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get closure"""
    global CLIARGS
    assert CLIARGS == CLIArgs({})

    # Test before CLIARGS has been initialized
    default = set()
    default_closure = cliargs_deferred_get('foo', default=default)
    assert default_closure() is default
    default_closure = cliargs_deferred_get('foo', default=default, shallowcopy=True)
    assert default_closure() == default

    # initialize CLIARGS
    _init_global_context({})
    # test getting a key that is not in the context
    default_closure = cliargs_deferred_get('foo', default=default)
    assert default_closure() is default
    default_closure = cliargs_deferred_get('foo', default=default, shallowcopy=True)

# Generated at 2022-06-22 19:46:21.970435
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test defaults and gets
    cliargs = CLIArgs({})
    deferred_get = cliargs_deferred_get('test_default', 'default')
    assert deferred_get() == 'default'
    cliargs['test_default'] = 'hello'
    assert deferred_get() == 'hello'

    # Test shallow copy return values
    cliargs = CLIArgs({'test_list': [1, 2, 3], 'test_dict': {'foo': 'bar'}, 'test_set': set([1, 2, 3])})
    get_list = cliargs_deferred_get('test_list', 'default', True)
    get_list_nonexist = cliargs_deferred_get('test_list_nonexist', 'default', True)
    get_dict = cliargs_deferred_

# Generated at 2022-06-22 19:46:33.024359
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible import context
    context.CLIARGS = context.CLIArgs({'hello': 'world',
                                       'foo': [1, 2, 3, 4],
                                       'bar': {1: 'one', 2: 'two', 3: 'three'}})

    # No-copy cases
    assert context.cliargs_deferred_get('hello')() == 'world'
    assert context.cliargs_deferred_get('foo')() == [1, 2, 3, 4]
    assert context.cliargs_deferred_get('bar')() == {1: 'one', 2: 'two', 3: 'three'}

    # Copy cases
    assert context.cliargs_deferred_get('hello', shallowcopy=True)() == 'world'

# Generated at 2022-06-22 19:46:40.572695
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for ``cliargs_deferred_get`` function"""
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    class MockCliArgs(dict):
        def get(self, key, default=None):
            if key in self:
                return wrap_var(self[key])
            return default

    old_cliargs, CLIARGS = CLIARGS, MockCliArgs()
    assert cliargs_deferred_get('testkey', default='testdefault')() == 'testdefault'

    CLIARGS['testkey'] = 'test value'
    assert isinstance(cliargs_deferred_get('testkey', shallowcopy=True)(), AnsibleUnsafeText)

# Generated at 2022-06-22 19:46:51.200548
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MyCLIArgs(CLIArgs):
        def __init__(self):
            super(MyCLIArgs, self).__init__({'hello': 'world'})

    myargs = MyCLIArgs()

    closure = cliargs_deferred_get('hello', default='default', shallowcopy=True)
    assert closure() == 'world'

    closure = cliargs_deferred_get('hello', default='default', shallowcopy=False)
    assert closure() == 'world'

    closure = cliargs_deferred_get('goodbye', default='default', shallowcopy=False)
    assert closure() == 'default'

    closure = cliargs_deferred_get('goodbye', default='default', shallowcopy=True)
    assert closure() == 'default'


# Generated at 2022-06-22 19:46:59.702563
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert CLIARGS.get('foo', 13) == 13
    assert cliargs_deferred_get('foo', 13)() == 13

    CLIARGS = GlobalCLIArgs.from_options({'foo': 14})
    assert CLIARGS.get('foo', 13) == 14
    assert cliargs_deferred_get('foo', 13)() == 14

    CLIARGS = GlobalCLIArgs.from_options({'foo': [10, 11, 12]})
    assert CLIARGS.get('foo') == [10, 11, 12]
    assert cliargs_deferred_get('foo')() == [10, 11, 12]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [10, 11, 12]

# Generated at 2022-06-22 19:47:11.107681
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    _init_global_context({'zz': 'mycli'})
    assert CLIARGS.get('zz') == 'mycli'

    f = cliargs_deferred_get('zz')
    assert f() == 'mycli'

    CLIARGS['zz'] = [1, 2]
    assert is_sequence(CLIARGS['zz'])
    assert CLIARGS['zz'] == [1, 2]
    assert f() == [1, 2]

    f = cliargs_deferred_get('zz', shallowcopy=True)
    assert f() == [1, 2]


# Generated at 2022-06-22 19:47:19.792303
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test_key1': 'test_value1', 'test_key2': 'test_value2'})
    # Valid value
    assert cliargs_deferred_get('test_key1')(), 'test_value1'
    # Non-existant key
    assert cliargs_deferred_get('test_key3')(), None
    # Non-existant key that has a default
    assert cliargs_deferred_get('test_key3', default='test_value3')(), 'test_value3'
    # Shallow copy
    assert cliargs_deferred_get('test_key1', shallowcopy=True)(), 'test_value1'

# Generated at 2022-06-22 19:47:24.530325
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': True, 'bar': {'baz': 'quux'}})
    assert cliargs_deferred_get('foo')() is True
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='quux')() == 'quux'
    assert cliargs_deferred_get('bar')() is CLIARGS['bar']
    assert cliargs_deferred_get('bar', shallowcopy=True)() != CLIARGS['bar']
    assert cliargs_deferred_get('bar', shallowcopy=True)() == CLIARGS['bar'].copy()
    assert cliargs_deferred_get('foo', shallowcopy=True)() is True

# Generated at 2022-06-22 19:47:34.572673
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    results = {
        'key': lambda: cliargs_deferred_get('key', default='default'),
        'copy': lambda: cliargs_deferred_get('copy', shallowcopy=True),
    }
    values = {
        'key': 'value',
        'copy': [1, 2, 3],
    }
    # Single result
    global CLIARGS
    cliargs = CLIArgs(values)
    CLIARGS = cliargs
    assert results['key']() == 'value'
    # Multiple results
    CLIARGS = CLIArgs(values)
    assert results['key']() == 'value'
    assert results['key']() == 'value'
    assert results['copy']() == [1, 2, 3]
    assert results['copy']() == [1, 2, 3]
    # No

# Generated at 2022-06-22 19:47:43.598554
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the deferred version of get"""
    def _run(cliargs_args, key, default, shallowcopy, expected):
        global CLIARGS
        cliargs_args = dict(
            (key, value) for (key, value) in cliargs_args.items()
            if value is not None
        )
        CLIARGS = GlobalCLIArgs.from_options(cliargs_args)
        current = cliargs_deferred_get(key, default, shallowcopy)()
        assert current == expected


# Generated at 2022-06-22 19:47:50.952316
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    gc = GlobalCLIArgs.from_options(dict(FOO='bar'))
    get_foostr = cliargs_deferred_get('FOO')
    assert get_foostr() == 'bar'
    assert get_foostr() is get_foostr()  # Make sure we're returning the original

    get_foocopy = cliargs_deferred_get('FOO', shallowcopy=True)
    assert get_foocopy() == 'bar'
    assert get_foocopy() is not get_foocopy()  # Make sure we're returning a copy

    get_foocopyint = cliargs_deferred_get('FOO', default=42, shallowcopy=True)
    assert get_foocopyint() == 42
    assert get_foocopyint() is not get_

# Generated at 2022-06-22 19:47:51.511174
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-22 19:47:55.843568
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    key = 'foo'
    default = 'bar'
    inner = cliargs_deferred_get(key, default)
    assert inner() == default
    CLIARGS.set(key, 'foobar')
    assert inner() == 'foobar'
    CLIARGS.unset(key)
    assert inner() == default

# Generated at 2022-06-22 19:48:06.082380
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': {'key1': 'value1'}, 'qux': ('first_value', 'second_value')})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'bad')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', 'bad')() == 'bad'
    baz = cliargs_deferred_get('baz')()
    assert baz == {'key1': 'value1'}
    baz['key2'] = 'value2'

# Generated at 2022-06-22 19:48:07.673328
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import types
    assert isinstance(cliargs_deferred_get('foo'), types.FunctionType)

# Generated at 2022-06-22 19:48:17.776785
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    class TestObj:
        string = None
        def __init__(self, val):
            self.string = val

    to1 = TestObj('to1')
    to2 = TestObj('to2')
    CLIARGS = CLIArgs({'a': 'A', 'b': [1, 2, 3], 'c': to1})
    assert cliargs_deferred_get('a')() == CLIARGS.get('a')
    assert cliargs_deferred_get('b')() == CLIARGS.get('b')
    assert cliargs_deferred_get('c')() == CLIARGS.get('c')

    # shallow copy
    CLIARGS['b'].append(4)

# Generated at 2022-06-22 19:48:29.314369
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    original_cliargs = CLIARGS

# Generated at 2022-06-22 19:48:41.258727
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for ``cliargs_deferred_get`` function

    Note: this is a black box test.  Behavior of the function is tested by the unit
    tests for ``FieldAttribute`` and ``default_from_cliargs``
    """
    global CLIARGS
    _orig_CLIARGS = CLIARGS

    assert cliargs_deferred_get('nonexistent')(default=12) == 12
    CLIARGS = GlobalCLIArgs(dict(test=12))
    assert cliargs_deferred_get('test')(default=False) == 12

    CLIARGS = GlobalCLIArgs(dict(test=dict(b=2)))
    assert cliargs_deferred_get('test', shallowcopy=True)(default={}) == {'b': 2}

    CLIARGS = _orig_CLIARGS

# Generated at 2022-06-22 19:48:50.822885
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    class MockCliArgs(GlobalCLIArgs):
        """Mock out the ``CliArgs`` class in order to test the function cliargs_deferred_get"""
        def get(self, key, default=None):
            str_default = "test_default" if default == str else default
            dict_default = {"test_default": "test_default"} if default == dict else default
            lst_default = ["test_default"] if default == list else default
            tuple_default = ("test_default",) if default == tuple else default
            return [key, str_default, dict_default, lst_default, tuple_default]

    global CLIARGS
    test_args = MockCliArgs({})
    CLIARGS = test_args
    inner = cliargs_deferred_get("key", default=str)
   

# Generated at 2022-06-22 19:49:01.650451
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Verify that a call to the closure returns the correct value
    CLIARGS.set('test_key', 'test_value')
    test_closure = cliargs_deferred_get('test_key')
    assert test_closure() == 'test_value'
    # Verify that normalizing the closure with a value returns the normalizing value
    CLIARGS.set('test_key', 'test_value')
    test_closure = cliargs_deferred_get('test_key', lambda: "normalized_value")
    # While no value from the cli was provided there was a value from the user so we should
    # return the normalized value
    assert test_closure == 'normalized_value'
    # Verify that normalizing the closure with a value returns the normalizing value
    CLIARGS.set('test_key', 'test_value')

# Generated at 2022-06-22 19:49:12.388795
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    global CLIARGS

    # Test that it does not require a GlobalCLIArgs object
    CLIARGS = CLIArgs({})
    dget = cliargs_deferred_get('key', default='value')
    assert dget() == CLIARGS.get('key', default='value')
    CLIARGS = CLIArgs({'key': 'value'})
    assert dget() == CLIARGS.get('key', default='value')

    # Test that it works with a GlobalCLIArgs object
    CLIARGS = GlobalCLIArgs.from_options({})
    dget = cliargs_deferred_get('key', default='value')
    assert dget() == CLIARGS.get('key', default='value')
    CLIARGS = GlobalCLIArgs

# Generated at 2022-06-22 19:49:18.685022
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    CLIARGS['b'] = 2
    assert cliargs_deferred_get('b')() == CLIARGS['b']
    assert cliargs_deferred_get('a', 0)() == 0
    assert cliargs_deferred_get('a', [])() == []
    assert cliargs_deferred_get('a', {})() == {}
    CLIARGS['l'] = [1, 2, 3]
    assert cliargs_deferred_get('l')() == [1, 2, 3]
    assert cliargs_deferred_get('l', [])() == [1, 2, 3]
    assert cliargs_deferred_get('l', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-22 19:49:30.026817
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for cliargs_deferred_get"""
    # pyfunc must be an inner function to work
    def pyfunc():
        return 'hi'

    _init_global_context({'AN_OTHER_KEY': 'test'})
    assert CLIARGS['AN_OTHER_KEY'] == 'test'
    assert cliargs_deferred_get('AN_OTHER_KEY')() == 'test'
    assert cliargs_deferred_get('AN_OTHER_KEY', default='dont_get_this')() == 'test'
    assert cliargs_deferred_get('AN_OTHER_KEY', default='dont_get_this', shallowcopy=True)() == 'test'
    assert cliargs_deferred_get('AN_OTHER_KEY', default='dont_get_this', shallowcopy=False)

# Generated at 2022-06-22 19:49:41.070014
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that retrieval works in different contexts
    key = 'foo'
    global CLIARGS
    # Test retrieval of an existing key
    value = 'bar'
    exampledict = dict(foo=value)
    CLIARGS = CLIArgs(exampledict)
    assert cliargs_deferred_get(key) == value
    # Test retrieval of a key that does not exist
    value = 'notbar'
    exampledict = dict(foo=value)
    CLIARGS = CLIArgs(exampledict)
    assert cliargs_deferred_get('foobar') == None
    # Test retrieval of a key that does not exist with a default value
    value = 'default'
    exampledict = dict(foo=value)
    CLIARGS = CLIArgs(exampledict)
    assert cliargs_

# Generated at 2022-06-22 19:49:52.916964
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('spam')() is None
    assert cliargs_deferred_get('spam', default='ham')() == 'ham'

    CLIARGS = CLIArgs({'foo': [1, 2, 3], 'spam': {'ham': 'eggs'}})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('spam', shallowcopy=True)() == {'ham': 'eggs'}
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
   

# Generated at 2022-06-22 19:50:00.355370
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Make sure we can use cliargs_deferred_get"""
    # Mocking the CLIARGS should be sufficient
    test_args = dict(a=1, b='foo', c=[1, '2', 3])
    cliargs = CLIArgs(test_args)
    CLIARGS = cliargs

    # check that the function returns the value from the args object if it exists
    for key in test_args:
        val = cliargs_deferred_get(key)()
        assert val == test_args[key]

    # check that the function returns the default if set
    for key in ('d', 'e', 'f'):
        val = cliargs_deferred_get(key, default=None)()
        assert val is None

    # Testing shallowcopy only works for list, dict and set
    shallow_

# Generated at 2022-06-22 19:50:11.465654
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test(arg_dict, key, expected_value, shallowcopy):
        assert cliargs_deferred_get(key, shallowcopy=shallowcopy)() == expected_value

    test({}, 'foo', None, False)
    test({'foo': 'bar'}, 'foo', 'bar', False)
    test({}, 'foo', 'default', False)
    test({'foo': 'bar'}, 'foo', 'default', False)

    test({}, 'foo', None, True)
    test({'foo': 'bar'}, 'foo', 'bar', True)
    test({}, 'foo', 'default', True)
    test({'foo': 'bar'}, 'foo', 'default', True)

    test({'foo': ['a', 'b']}, 'foo', ['a', 'b'], True)

# Generated at 2022-06-22 19:50:21.651165
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': [1, 2, 3], 'bar': {'baz': True}, 'baz': 'abc'})
    assert cliargs_deferred_get('foo', shallowcopy=False)() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]

    assert cliargs_deferred_get('bar', shallowcopy=False)() == {'baz': True}
    assert cliargs_deferred_get('bar', shallowcopy=True)() == {'baz': True}

    assert cliargs_deferred_get('baz', shallowcopy=False)() == 'abc'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == 'abc'

# Generated at 2022-06-22 19:50:33.083522
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy

    class Dummy(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return "Dummy(%r)" % self.value

        def __copy__(self):
            return Dummy('copy ' + self.value)

        def __deepcopy__(self, memo):
            return Dummy('deepcopy ' + self.value)


# Generated at 2022-06-22 19:50:41.769215
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works in all the situations that the documentation promises"""
    class TestClass(object):
        def __init__(self):
            self.value = cliargs_deferred_get('test_value')

    # Set up the CLIARGS object
    import types
    global CLIARGS
    CLIARGS = CLIArgs({'test_value': 'bar'})
    assert CLIARGS.get('test_value') == 'bar'

    # Test that the value is returned when it has been set in CLIARGS
    testobj = TestClass()
    assert testobj.value == 'bar'

    # Test a function that returns a value
    testobj.value = cliargs_deferred_get('test_value', shallowcopy=True)
    assert testobj.value == 'bar'

    #

# Generated at 2022-06-22 19:50:53.348911
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIRUNNER

    cli_args = CLIRUNNER.get_opts()
    _init_global_context(cli_args)

    # 1. test that it works with the CLIARGS global
    assert cliargs_deferred_get('connection')() == 'smart'

    # 2. test that it works with a set CLIARGS
    temp_CLIARGS = CLIArgs({'connection': 'otherthing'})
    old_CLIARGS = CLIARGS
    CLIARGS = temp_CLIARGS
    assert cliargs_deferred_get('connection')() == 'otherthing'
    CLIARGS = old_CLIARGS

    # 3. test that it works with a set CLIARGS

# Generated at 2022-06-22 19:51:01.534159
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the expected value according to the context object's get() method

    This test is not run by default. To run the tests, run:
    ansible-test units --python 3 --python-version 3.5 --docker default --test none --test-name 'test_contexts.py::test_cliargs_deferred_get'
    """
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # test that we can get the value for a key
    value = 'key'
    cliargs_deferred_get_result = cliargs_deferred_get('key', value)
    assert cliargs_deferred_get_result() == value

    # test that we can get the default value when the key is not in the context