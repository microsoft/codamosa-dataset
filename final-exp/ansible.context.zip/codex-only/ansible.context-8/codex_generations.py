

# Generated at 2022-06-22 19:41:08.277614
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS._args = {'foo': True, 'bar': [1, 2, 3]}
    assert cliargs_deferred_get('foo')() is True
    assert cliargs_deferred_get('bar')() == [1, 2, 3]
    assert cliargs_deferred_get('bar', shallowcopy=True)() == [1, 2, 3]
    newval = cliargs_deferred_get('bar', shallowcopy=True)()
    assert newval == [1, 2, 3]
    newval.pop()
    assert newval == [1, 2]
    assert cliargs_deferred_get('bar')() == [1, 2, 3]
    # Test that we can use the cliargs even when it's not in the global
    CLIARGS._args = None
    CLI

# Generated at 2022-06-22 19:41:16.792690
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': {'bar': 5}})

    assert cliargs_deferred_get('foo')().get('bar') == 5
    assert cliargs_deferred_get('foo', {})().get('bar') == 5
    assert cliargs_deferred_get('bar', {})() == {}

    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'bar': 5}
    assert cliargs_deferred_get('foo', {})() == {'bar': 5}

    # try the GlobalCLIARGS
    def get_args(key, val):
        return (key, val if val else '')


# Generated at 2022-06-22 19:41:22.328845
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=too-many-statements
    # Loads of assertions to make sure it works
    assert cliargs_deferred_get('foo', default='bar').__closure__[0].cell_contents() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True).__closure__[0].cell_contents() is None
    _init_global_context({'foo': 'far'})
    assert cliargs_deferred_get('foo', default='bar').__closure__[0].cell_contents() == 'far'
    assert cliargs_deferred_get('foo', shallowcopy=True).__closure__[0].cell_contents() == 'far'
    assert cliargs_deferred_get('foo', default='bar').__closure__[0].cell_

# Generated at 2022-06-22 19:41:33.436972
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {
        'foo': 'bar',
        'baz': {
            'bam': 'boom',
        },
        'bar': ['a', 'b', 'c'],
        'int': 1,
        'float': 1.0,
    }

    def test_eq(closure, expected):
        assert closure() == expected

    def test_neq(closure, expected):
        assert closure() is not expected

    _init_global_context(cli_args)
    test_eq(cliargs_deferred_get('foo'), 'bar')
    test_neq(cliargs_deferred_get('baz'), {'bam': 'boom'})

# Generated at 2022-06-22 19:41:44.254357
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """ Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    cli_args = {'foo': [1, 2], 'bar': {'a': 1, 'b': 2}}
    _init_global_context(cli_args)

    # Test default value
    assert cliargs_deferred_get('baz')() == None

    # Test shallow copy
    assert cliargs_deferred_get('foo')() == [1, 2]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2]
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not cliargs_

# Generated at 2022-06-22 19:41:48.094119
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    expected = {
            'myitem': 'myvalue'
    }
    setattr(CLIARGS, '_attrs', expected)

    actual = cliargs_deferred_get('myitem')()
    assert actual == expected['myitem']

    actual = cliargs_deferred_get('myitem', shallowcopy=True)()
    assert actual == expected['myitem']

# Generated at 2022-06-22 19:41:54.621030
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for cliargs_deferred_get
    """
    global CLIARGS
    cliargs = CLIArgs({'a': 'a'})
    old_cliargs = CLIARGS
    try:
        CLIARGS = cliargs
        assert cliargs_deferred_get('a')() == cliargs['a']
        assert cliargs_deferred_get('b', 'b')() == cliargs.get('b', 'b')
    finally:
        CLIARGS = old_cliargs

# Generated at 2022-06-22 19:42:04.866224
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    cli_arg_default = []
    cli_arg = ['hi', 'world']
    cli_arg_shallowcopy = ['hi', 'world']
    get_func = cliargs_deferred_get('test_cli_arg', default=cli_arg_default,
                                    shallowcopy=False)
    get_func_shallowcopy = cliargs_deferred_get('test_cli_arg',
                                                default=cli_arg_default, shallowcopy=True)
    global CLIARGS
    CLIARGS.update({'test_cli_arg': cli_arg})

    # Execute
    results = get_func()
    results_shallowcopy = get_func_shallowcopy()

    # Verify
    assert results is cli_arg

# Generated at 2022-06-22 19:42:15.331089
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    from . import fake_from_options
    from ansible.utils.context_objects import GlobalCLIArgs


# Generated at 2022-06-22 19:42:23.976996
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'ANSIBLE_NOCOLOR': True, 'ANSIBLE_PYTHON_INTERPRETER': '/usr/bin/python3'})
    assert cliargs_deferred_get('ANSIBLE_NOCOLOR')()
    assert not cliargs_deferred_get('ANSIBLE_DEBUG')()
    assert cliargs_deferred_get('ANSIBLE_PYTHON_INTERPRETER')() == '/usr/bin/python3'
    assert cliargs_deferred_get('ANSIBLE_RETRY_FILES_ENABLED', shallowcopy=True)()


# FIXME: Remove cliargs_deferred_get_merged_do_not_use_directly when cliargs_deferred_get is used everywhere
# This should not be used as it is only here for backwards

# Generated at 2022-06-22 19:42:33.014060
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('bar') == None
    assert cliargs_deferred_get('bar', 'baz') == 'baz'

    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo', shallowcopy=True) == ['bar', 'baz']

    CLIARGS = CLIArgs({'foo': {'bar': 'baz'},
                       'fiz': {'buz': 'fux'}})
    assert cliargs_deferred_get('foo', shallowcopy=True) == {'bar': 'baz'}
    assert cliargs_

# Generated at 2022-06-22 19:42:43.541322
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=too-many-branches,too-many-statements
    """Unit test for function cliargs_deferred_get"""
    import ansible.config.manager

    # The first test is a basic check that the function returns the key that's there
    CLIARGS = {'foo': 'bar'}  # pylint: disable=invalid-name
    assert cliargs_deferred_get('foo')(), 'foo'

    # Verify that the default is returned when the key is not present
    CLIARGS = {}  # pylint: disable=invalid-name
    assert cliargs_deferred_get('foo', default='bar')(), 'bar'

    # If the default is None, then the value is not present
    CLIARGS = {}  # pylint: disable=invalid-

# Generated at 2022-06-22 19:42:55.236308
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.playbook.play_context import PlayContext
    from ansible.cli.arguments import Options
    from ansible.module_utils.common.text.converters import to_text
    import os

    # Unit test for cliargs_deferred_get

    options = Options()
    options.private_data_dir = '/tmp/path/to/a/known/good/place'

    # Create a new context so that we don't mess up the global context
    play_context = PlayContext()
    play_context.init_context(options)
    assert play_context.remote_tmp == '/tmp/path/to/a/known/good/place'

    # Make sure that a call using CLIARGS directly gets the right answer

# Generated at 2022-06-22 19:43:04.923274
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access

    from ansible.utils.context_objects import ContextObject
    from ansible.module_utils.common._collections_compat import Mapping, Sequence, Set
    from ansible.module_utils.common.collections import is_sequence

    # Test: just getting simple key
    class TestObject(Sequence):
        def __init__(self, data):
            self.data = data

        def __len__(self):
            return len(self.data)

        def __getitem__(self, index):
            return self.data[index]

    class TestArgs(ContextObject):
        _ATTRIBUTES = {'test': cliargs_deferred_get('test')}
        SHAKE = 'a'

    test = TestObject(['b'])
    cli

# Generated at 2022-06-22 19:43:15.232049
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MockCLIArgs(object):
        def __init__(self):
            self.d = {'foo': 1, 'bar': [1, 2]}
        def __getitem__(self, key):
            return self.d[key]
        def get(self, key, default=None):
            return self.d.get(key, default)

    global CLIARGS
    cliargs_bak = CLIARGS
    mock_cliargs = MockCLIArgs()

    CLIARGS = mock_cliargs
    f = cliargs_deferred_get('foo')
    assert f() == 1
    f = cliargs_deferred_get('bar', shallowcopy=True)
    assert f() == [1, 2]
    CLIARGS = cliargs_bak

# Generated at 2022-06-22 19:43:21.940994
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert CLIARGS._data['connection'] == 'smart'
    assert cliargs_deferred_get('connection')() == 'smart'
    assert cliargs_deferred_get('connection', shallowcopy=True)() == 'smart'
    CLIARGS['connection'] = 'network_cli'
    assert cliargs_deferred_get('connection')() == 'network_cli'
    assert cliargs_deferred_get('connection', shallowcopy=True)() == 'network_cli'
    CLIARGS['connection'] = ('network_cli', 'network_cli')
    assert cliargs_deferred_get('connection')() == ('network_cli', 'network_cli')
    assert cliargs_deferred_get('connection', shallowcopy=True)() == ('network_cli', 'network_cli')
    CLIARGS

# Generated at 2022-06-22 19:43:31.538817
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_value(key, shallowcopy, value):
        def inner():
            return key
        CLIARGS.update({key: value})
        assert cliargs_deferred_get(inner(), default='foo', shallowcopy=shallowcopy) == value
    # Test getting from the CLIARGS
    test_value('a', False, 'a')
    test_value('b', True, 'b')
    test_value('c', False, ['c'])
    test_value('d', True, ['d'])
    test_value('e', False, {'e': 'e'})
    test_value('f', True, {'f': 'f'})
    test_value('g', False, {'g'})
    test_value('h', True, {'h'})
    # Test getting from the default

# Generated at 2022-06-22 19:43:39.154330
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CliArgs(dict):
        def get(self, *args, **kwargs):
            return super(CliArgs, self).get(*args, **kwargs)

    CLIARGS = CliArgs(dict(a=1, b=2, c=[1, 2, 3], d={'foo': 1, 'bar': 2}))
    d_get_1 = cliargs_deferred_get('d')
    assert d_get_1() == CLIARGS['d']

    v1 = d_get_1()
    v2 = d_get_1()
    assert v1 is v2  # in the absence of shallowcopy we get the same object

    d_get_2 = cliargs_deferred_get('d', shallowcopy=True)
    v1 = d_get_2()
    v2

# Generated at 2022-06-22 19:43:43.250114
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo')('bar') == 'bar'
    class TestClass(object):
        cli_args = {'foo': 'bar'}
        def test_member(self):
            assert cliargs_deferred_get('foo')('baz') == 'bar'
    TestClass().test_member()
    cliargs_deferred_get('foo')('baz') == 'bar'

# Generated at 2022-06-22 19:43:54.580715
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Reset the global state
    globals().pop('CLIARGS', None)
    cliargs = CLIArgs({'foo': [1, 2, 3], 'bar': [{'foo': 1}], 'baz': 'hello'})
    _init_global_context(cliargs)
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('bar')() == [{'foo': 1}]
    assert cliargs_deferred_get('bar', shallowcopy=True)() == [{'foo': 1}]
    assert cliargs_deferred_get('baz')() == 'hello'
    assert cli

# Generated at 2022-06-22 19:44:04.808349
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MyCLIArgs(GlobalCLIArgs):
        def __init__(self, data):
            self._data = data

        def get(self, key, default=None):
            return self._data.get(key, default)


# Generated at 2022-06-22 19:44:15.736452
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Ensure that cliargs_deferred_get returns the correct default if the key is missing
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Ensure that cliargs_deferred_get returns the correct default if the value is None
    CLIARGS = CLIArgs({'foo': None})
    assert cliargs_deferred_get('foo', default='bar')() == None

    # Ensure that cliargs_deferred_get returns the correct value if the value is not None
    CLIARGS = CLIArgs({'foo': 'abc'})
    assert cliargs_deferred_get('foo', default='bar')() == 'abc'

    # Ensure that none of the above code is related to shallow copy.
    # That

# Generated at 2022-06-22 19:44:24.920255
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeArgs:
        def __init__(self, dict_):
            self._dict = dict_

        def __getitem__(self, key):
            return self._dict[key]

    a = FakeArgs({'foo': 'bar', 'nested': ['a', 'b']})
    get_foo = cliargs_deferred_get('foo')
    get_nested = cliargs_deferred_get('nested')

    assert get_foo() == 'bar'
    assert get_nested() == ['a', 'b']

    # Make sure shallowcopy works
    assert id(get_nested()) != id(get_nested())
    assert id(get_foo()) == id(get_foo())  # we return the same object, not a copy

# Generated at 2022-06-22 19:44:32.426841
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Empty CliArgs
    c = CLIArgs({})
    f = cliargs_deferred_get('foo')
    assert f() is None

    # CliArgs with foo value
    c = CLIArgs({'foo':'bar'})
    f = cliargs_deferred_get('foo')
    assert f() == 'bar'

    # Try with a shallowcopy
    c = CLIArgs({'foo':[1,2,3]})
    f = cliargs_deferred_get('foo', shallowcopy=True)
    retval = f()
    assert retval == [1,2,3]
    retval.append(4)
    assert f() == [1,2,3]
    assert c.get('foo') == [1,2,3]

# Generated at 2022-06-22 19:44:40.737778
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set

    class ARGS(object):
        def __init__(self, args):
            self.args = args

        def __getattr__(self, attr):
            return self.args.get(attr)

    args = {'arg1': 'value1', 'arg2': {'subarg1': 'subvalue1'}, 'arg3': [1, 2, 3],
            'arg4': (1, 2, 3), 'arg6': set([1, 2, 3]), 'arg7': ARGS({'subarg1': 'subvalue1'}),
            'arg8': 'value1'}
    _init_global_context(ARGS(args))


# Generated at 2022-06-22 19:44:50.921985
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test a simple deferred value that can be shallowcopied

    If this test fails, either the attribute is not being shallow_copy'd and
    we should fix it or there's other logic that needs to update the way
    ``FieldAttribute`` is using it

    :kwarg key: Key to use in the dict to retrieve
    :kwarg default: Default value to use when setting the attribute
    :kwarg shallowcopy: Whether to shallow copy the value returned
    """
    class _DummyCLIArgs(dict):
        def get(self, key, default=None):
            # Test that the default is used correctly
            return self[key]

    cliargs = CLIArgs(_DummyCLIArgs({'foo': 'bar'}))

    # Test a value that does not exist

# Generated at 2022-06-22 19:44:58.306189
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that cliargs_deferred_get() works with the global CLIARGS var
    CLIARGS.ansible_vars = {'foo': 'bar'}
    cli_vars = cliargs_deferred_get('ansible_vars')
    assert cli_vars() == {'foo': 'bar'}

    CLIARGS.ansible_vars = {'foo': 'baz'}
    assert cli_vars() == {'foo': 'baz'}

# Generated at 2022-06-22 19:45:05.247065
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Setup
    CLIARGS = CLIArgs({'x': 'y'})
    # Make sure we can get the value
    assert cliargs_deferred_get('x')() == 'y'
    # Make sure we can get a default
    assert cliargs_deferred_get('y', default='z')() == 'z'
    # Make sure we get the default, not None
    assert cliargs_deferred_get('y')() is None
    # Tear down
    CLIARGS = CLIArgs({})

# Generated at 2022-06-22 19:45:12.320172
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set

    class LocalCLIArgs(CLIArgs):
        def __init__(self):
            super(LocalCLIArgs, self).__init__({})
            self.num_called = 0

        def get(self, key, default=None):
            self.num_called += 1
            return super(LocalCLIArgs, self).get(key, default)

    def check_shallow_copy(value):
        if is_sequence(value):
            assert value is cliargs_deferred_get(value)(), "Copy of list not working"
        elif isinstance(value, (Mapping, Set)):
            assert value is cliargs_deferred_get(value)(), "Copy of set not working"

# Generated at 2022-06-22 19:45:23.295888
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is a function just because it is easy to mock and is easy to
    # interface with the function
    class CliArgs(object):
        def __init__(self, d):
            self._d = d

        def get(self, key, default):
            return self._d.get(key, default)

    cli_args = CliArgs({
        'collation_order': [1, 2, 3],
        'var_a': 'a',
        'var_b': 'b',
        'var_c': 'c',
        'var_d': 'd',
        'var_e': 'e',
    })

    # Should just return the value
    value = cliargs_deferred_get('var_a')
    assert value() == 'a'

    # Should return the default

# Generated at 2022-06-22 19:45:25.187026
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This unit test can only be run after we have parsed the cli arguments
    # so it is not run as part of the normal testsuite
    pass

# Generated at 2022-06-22 19:45:36.969662
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for cliargs_deferred_get()
    """
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    import pytest, sys

    # Test changing all the values
    options = {'host_key_checking': True,
               'private_key_file': '~/.ssh/id_rsa',
               'forks': 99,
               'verbosity': 3}
    _init_global_context(options)

    for key, value in options.items():
        assert cliargs_deferred_get(key)() == value
        if is_sequence(value):
            assert cliargs_deferred_get(key, shallowcopy=True)() is not value

# Generated at 2022-06-22 19:45:44.425611
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.override({'foo': 'bar'})
    default_key = cliargs_deferred_get('bar', 'yea')
    assert default_key() == 'yea'
    foo = cliargs_deferred_get('foo')
    assert foo() == 'bar'
    shallow_copy = cliargs_deferred_get('foo', shallowcopy=True)
    assert shallow_copy() == 'bar'
    assert foo() is not shallow_copy()
    assert foo() is not default_key()

# Generated at 2022-06-22 19:45:50.962495
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    args = {'foo': 'bar', 'baz': [1, 2, 3], 'zia': {'new': 'mexico', 'old': 'spain'}, 'my_set': {1, 2, 3}}
    CLIARGS = CLIArgs(args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('zia', shallowcopy=True)() == {'new': 'mexico', 'old': 'spain'}
    assert cliargs_deferred_get('my_set', shallowcopy=True)() == {1, 2, 3}
    assert cliargs_deferred_get

# Generated at 2022-06-22 19:46:01.499585
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo')() is None

    # Test that shallowcopy works as expected
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

    CLIARGS['bar'] = ['foo']
    assert cliargs_deferred_get('bar')() == ['foo']
    assert cliargs_deferred_get('bar', shallowcopy=True)() == ['foo']

    CLIARGS['baz'] = {'key': 'value'}
    assert cliargs_deferred_get('baz')() == {'key': 'value'}
    assert cliargs_deferred_get('baz', shallowcopy=True)

# Generated at 2022-06-22 19:46:08.771185
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test deferred getting of values from CLIARGS"""
    CLIARGS.setdefault('test_val', 'TEST')
    value = cliargs_deferred_get('test_val')()
    assert value == 'TEST'
    assert cliargs_deferred_get('dne_val')() is None
    assert cliargs_deferred_get('dne_val', default='TEST')() == 'TEST'
    assert cliargs_deferred_get('dne_val', default=['foo', 'bar'])() == ['foo', 'bar']

# Generated at 2022-06-22 19:46:15.433321
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get function"""
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('not_there', 'baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('not_there', 'baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('not_there', 'baz', default=None)() == 'baz'

    # Test that we don't mutate the global state
    _init

# Generated at 2022-06-22 19:46:24.149322
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from copy import copy as shallow_copy
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.cli import CLI

    cli = CLI(args=[])
    cli.parse()
    # So ansible.context._init_global_context is called by CLI.parse
    assert CLIARGS != CLIArgs({})
    assert CLIARGS['connection'] == 'smart'

    # Here we test that the closure over the key properly gets the value
    assert cliargs_deferred_get('connection')() == 'smart'
    assert cliargs_deferred_get('connection', default='local')() == 'smart'

    # Here we test that the closure over the default properly gets the default
    assert cliargs_deferred_get('ssh_executable')() is None
    assert cliargs_def

# Generated at 2022-06-22 19:46:33.128680
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_cli_args = {'default': [1, 2, 3]}
    _init_global_context(test_cli_args)
    assert cliargs_deferred_get('default')() == [1, 2, 3]
    assert cliargs_deferred_get('default', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('default', default=1)() == [1, 2, 3]

    _init_global_context({})
    assert cliargs_deferred_get('default', default=1)() == 1
    assert cliargs_deferred_get('default', default=1, shallowcopy=True)() == 1

# Generated at 2022-06-22 19:46:40.658023
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def assert_get_value(key, value, shallowcopy, expected):
        CLIARGS.data[key] = value
        gv = cliargs_deferred_get(key, shallowcopy=shallowcopy)
        assert gv() == expected

    # Normal value
    assert_get_value('key', 'value', False, 'value')
    assert_get_value('key', 'value', True, 'value')
    # Shallow copy unchanged
    assert_get_value('key', ['value'], False, ['value'])
    assert_get_value('key', ['value'], True, ['value'])
    assert_get_value('key', {'key': 'value'}, False, {'key': 'value'})

# Generated at 2022-06-22 19:46:51.280313
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update(dict(
        key1=True,
        key2='value',
        key3=[1, 2, 3],
        key4=dict(a=1, b=2),
    ))

    assert cliargs_deferred_get('key1')() is True
    assert cliargs_deferred_get('key2')() == 'value'
    assert cliargs_deferred_get('key2', default='default')() == 'value'
    assert cliargs_deferred_get('keyX')() is None
    assert cliargs_deferred_get('keyX', default='default')() == 'default'

    assert cliargs_deferred_get('key3', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-22 19:46:59.768829
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Ensure cliargs_deferred_get works as expected"""
    def double(x):
        return x * 2
    # First, test with a key that's not in cliargs
    deferred_get = cliargs_deferred_get('this_key_is_not_in_cli_args', default=double)
    assert deferred_get() is double
    # Now test with a key that is in cliargs and has a default
    _init_global_context({'this_key_is_not_in_cli_args': 'foo'})
    deferred_get = cliargs_deferred_get('this_key_is_not_in_cli_args', default=double)
    assert deferred_get() == 'foo'
    # Now test with a key that is in cliargs but with no default
    _init

# Generated at 2022-06-22 19:47:11.187752
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with a get that is known to work
    _init_global_context({'args': ['ansible', '--version']})
    assert CLIARGS.get('version', 'unknown') == 'unknown'
    get_callable = cliargs_deferred_get('version', 'unknown')
    assert get_callable() == 'unknown'
    # Test a get that is known to fail.
    # We don't have to replace CLIARGS since it will be reset to a simple
    # CLIArgs object in the next test case
    assert CLIARGS.get('cmdline', 'unknown') == 'unknown'
    get_callable = cliargs_deferred_get('cmdline', 'unknown')
    assert get_callable() == 'unknown'
    # Test with a simple callable.  We have to replace CLIARGS since the

# Generated at 2022-06-22 19:47:19.852263
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # non-copy
    CLIARGS.data['test_item'] = []
    assert cliargs_deferred_get('test_item')() is CLIARGS.data['test_item']
    assert cliargs_deferred_get('test_item', shallowcopy=True)() is CLIARGS.data['test_item']

    # non-copy
    CLIARGS.data['test_item'] = {}
    assert cliargs_deferred_get('test_item')() is CLIARGS.data['test_item']
    assert cliargs_deferred_get('test_item', shallowcopy=True)() is CLIARGS.data['test_item']

    CLIARGS.data['test_item'] = set()
    assert cliargs_deferred_get('test_item')() is CLIARGS.data

# Generated at 2022-06-22 19:47:24.564269
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 'b'})
    assert cliargs_deferred_get('a')() == 'b'
    assert cliargs_deferred_get('c')() is None
    assert cliargs_deferred_get('c', 'd')() == 'd'
    assert cliargs_deferred_get('c', default='d')() == 'd'
    assert cliargs_deferred_get('module_path')().endswith('/mymodule_path')
    assert cliargs_deferred_get('module_path', shallowcopy=True)() is not None
    assert cliargs_deferred_get('module_path', shallowcopy=True)() is not CLIARGS.module_path

# Generated at 2022-06-22 19:47:34.610389
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['x'] = None
    assert cliargs_deferred_get('x')(), None
    CLIARGS['y'] = ['x']
    assert cliargs_deferred_get('y')(), ['x']
    assert cliargs_deferred_get('y', shallowcopy=True)(), ['x']
    assert cliargs_deferred_get('y', shallowcopy=True)() is not CLIARGS['y']
    CLIARGS['z'] = {'x': 1}
    assert cliargs_deferred_get('z')(), {'x': 1}
    assert cliargs_deferred_get('z', shallowcopy=True)(), {'x': 1}
    assert cliargs_deferred_get('z', shallowcopy=True)() is not CLIARGS['z']

# Generated at 2022-06-22 19:47:43.689374
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    """Test for the closure over cli args"""
    def_value = {'a': 1, 'b': ['c', 'd']}
    CLIARGS['foo'] = 'bar'
    CLIARGS['baz'] = def_value
    # Check ordinary functionality
    assert cliargs_deferred_get('foo', 'baz')(), 'bar'
    # Check default functionality
    assert cliargs_deferred_get('missing', 'def_value')(), 'def_value'
    # check shallow copy functionality
    assert cliargs_deferred_get('baz', shallowcopy=True)() == def_value
    assert cliargs_deferred_get('baz')() is def_value
    # Check failure cases (these are needed to fully cover the function)

# Generated at 2022-06-22 19:47:54.634964
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _test(key, default, shallowcopy, expected):
        CLIARGS.update(dict(
            x=[1, 2, 3],
            y=dict(a=1, b=2),
        ))
        assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == expected

# Generated at 2022-06-22 19:48:04.637102
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(foo=dict(bar=1)))

    assert cliargs_deferred_get('foo') == dict(bar=1)
    assert cliargs_deferred_get('foo', shallowcopy=True) == dict(bar=1)
    assert cliargs_deferred_get('foo') is not cliargs_deferred_get('foo', shallowcopy=True)

    assert cliargs_deferred_get('bar') is None
    assert cliargs_deferred_get('bar', default=dict(baz=2)) == dict(baz=2)
    assert cliargs_deferred_get('bar') is None
    assert cliargs_deferred_get('bar', shallowcopy=True) is None

# Generated at 2022-06-22 19:48:14.567314
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """cliargs_deferred_get: Test that deferred get returns correct value"""
    value = 'value'
    CLIARGS['key'] = value
    assert cliargs_deferred_get('key')() is value
    # default value
    assert cliargs_deferred_get('not_key', default=value)() is value
    # should return a copy for mappings
    shallowcopy_value = {'foo': 'bar'}
    CLIARGS['key_shallowcopy'] = shallowcopy_value
    assert cliargs_deferred_get('key_shallowcopy', shallowcopy=True)() is not shallowcopy_value
    assert cliargs_deferred_get('key_shallowcopy', shallowcopy=True)() == shallowcopy_value
    # should return a copy for sequences

# Generated at 2022-06-22 19:48:18.175962
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    #deferred_get = cliargs_deferred_get('some_key', default=[])
    #CLIARGS = {'some_key': [1, 2, 3]}
    #assert deferred_get() == [1, 2, 3]
    pass

# Generated at 2022-06-22 19:48:29.633767
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.context_objects import CLIArgs

    context = CLIArgs({})
    get = cliargs_deferred_get('whatever')
    assert get() == None, \
            'Did not get default value for unset argument'
    context.whatever = 'hello'
    assert get() == 'hello', \
            'Did not get set value'
    context.whatever = ['a', 'b']
    assert get() == ['a', 'b'], \
            'Shallow copy failed'
    assert get(shallowcopy=True) == ['a', 'b'], \
            'Shallowcopy=True failed'
    context.whatever = ('a', 'b')
    assert get() == ('a', 'b'), \
            'Shallow copy failed'

# Generated at 2022-06-22 19:48:41.318763
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    import copy
    import random

    cli_args = {'foo': 'bar', 'baz': (1, 2, 3), 'bang': {'a': 1, 'b': 2}}
    _init_global_context(cli_args)
    assert callable(cliargs_deferred_get('foo'))
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', default=17)() == 17
    assert cliargs_deferred_get('baz')() == (1, 2, 3)

# Generated at 2022-06-22 19:48:51.491922
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def assert_shallow_copy(value, expected):
        assert value is not expected
        assert value == expected

    # Test with shallowcopy=False
    expectations = {
        'foo': 'foo',
        ('bar', 'baz'): ('bar', 'baz'),
        {'bop': 1}: {'bop': 1},
        ['bop']: ['bop'],
        set(): set(),
    }
    for value, expected in expectations.items():
        _init_global_context({'foo': value})
        assert cliargs_deferred_get('foo')() is expected

    # Test with shallowcopy=True

# Generated at 2022-06-22 19:49:02.422531
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    import copy
    import ansible.module_utils.context_objects
    from ansible.module_utils.connection_plugins.local import Connection as LocalConnection
    from ansible.plugins.loader import plugin_loader

    ansible.module_utils.context_objects.CLIARGS = ansible.module_utils.context_objects.CLIArgs({'connection': 'local'})
    assert cliargs_deferred_get('connection') == 'local'
    assert cliargs_deferred_get('connection', default='network') == 'local'
    assert cliargs_deferred_get('connection', shallowcopy=True) == 'local'
    assert cliargs_deferred_get('connections', default=[]) == []
    assert cliargs_deferred_get('connections', default=[]) == []
    assert cliargs_

# Generated at 2022-06-22 19:49:12.930034
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert CLIARGS == CLIArgs({})
    assert CLIARGS.get('options') == {}
    assert CLIARGS.defaults == {}

    cliargs_dict = {'options': {'foo': 'bar'}, 'defaults': {'bar': 'baz'}}
    CLIARGS = CLIArgs(cliargs_dict)
    assert CLIARGS == CLIArgs(cliargs_dict)
    assert CLIARGS.get('options') == {'foo': 'bar'}
    assert CLIARGS.defaults == {'bar': 'baz'}

    # Mutation of the default should affect calls after the mutation
    cliargs_defaults = CLIARGS.defaults
    cliargs_defaults['baz'] = 'borg'

# Generated at 2022-06-22 19:49:20.247024
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Ensure cliargs_deferred_get functions as expected"""
    global CLIARGS
    old_cliargs = CLIARGS

    # Make sure it gives back a default
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('default', default='default')(), 'default'

    # Make sure it gives back the value from the cli_args
    CLIARGS = CLIArgs({'key': 'value'})
    assert cliargs_deferred_get('key')(), 'value'

    # Make sure it will take a default as well
    assert cliargs_deferred_get('key2', default='default2')(), 'default2'

    # Make sure it can do shallow copies

# Generated at 2022-06-22 19:49:31.012469
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for cliargs_deferred_get"""
    import itertools

    cli_args = {}
    _init_global_context(cli_args)
    args_pairs = itertools.product((True, False), (True, False))
    for cli_args['shallowcopy'], shallowcopy in args_pairs:
        for key, value in {True: True, False: False, 'foo': 'bar', 'baz': [1, 2, 3],
                           'bar': {'a': 1, 'b': 2}, 'foobar': frozenset([1, 2, 3, 4])}.items():
            def_get = cliargs_deferred_get(key)
            assert def_get() == value

# Generated at 2022-06-22 19:49:41.253899
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # This is a test, so use the singleton version.  It's not used outside of unit tests.
    CLIARGS = CLIArgs({}, singleton=True)
    CLIARGS['a'] = 'A'
    CLIARGS['b'] = 'B'
    assert cliargs_deferred_get('a')(), 'A'
    assert cliargs_deferred_get('b')(), 'B'
    CLIARGS['a'] = 'a'
    CLIARGS['b'] = 'b'
    assert cliargs_deferred_get('a')(), 'a'
    assert cliargs_deferred_get('b')(), 'b'
    # key doesn't exist
    assert cliargs_deferred_get('c')(), None
    assert cliargs

# Generated at 2022-06-22 19:49:52.639571
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('nonexistent')() == None
    assert cliargs_deferred_get('nonexistent', default='other')() == 'other'

    for value in [
            42,
            '42',
            tuple(),
            frozenset(),
            set(),
            dict(),
            [42, '42'],
            ['42', '42'],
            (42, '42'),
            frozenset((42, '42')),
            set((42, '42')),
            {"42": 42},
    ]:
        CLIARGS = CLIArgs({'foo': value})
        assert cliargs_deferred

# Generated at 2022-06-22 19:50:00.104503
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.dict_utils import merge_dict
    from ansible.utils.context_objects import GlobalCLIArgs

    # Testing mutable default is not copied
    default = [{'a': 'a'}]
    default_copy = default[:]

    assert CLIARGS == GlobalCLIArgs.from_options({})
    assert cliargs_deferred_get('nonexistent_key', default=default)() == default_copy


    # Testing mutable default is copied
    default = [{'a': 'a'}]
    default_copy = default[:]

    assert CLIARGS == GlobalCLIArgs.from_options({})
    assert cliargs_deferred_get('nonexistent_key', default=default, shallowcopy=True)() != default_copy

    # Testing mutable

# Generated at 2022-06-22 19:50:11.328941
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.context import cliargs_deferred_get, _init_global_context

    _init_global_context({'key1': 'value1', 'key2': 'value2'})
    defg = cliargs_deferred_get
    assert defg('key1')() == 'value1'
    assert defg('key2')() == 'value2'
    assert defg('key3')('value3') == 'value3'
    assert defg('key1', shallowcopy=True)() == 'value1'
    assert defg('key2', shallowcopy=True)() == 'value2'
    assert defg('key3', shallowcopy=True)('value3') == 'value3'

# Generated at 2022-06-22 19:50:21.651674
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    ci_args = {'foo': 'bar',
               'fast': [1, 2, 3],
               'faster': {1: 2},
               'fastest': {1, 2, 3},
               'not_there': 'oh well'}

    from ansible.utils.context_objects import CLIArgs
    _init_global_context(ci_args)
    cli_args = CLIARGS

    # Test with no shallow copy needed
    foo = cliargs_deferred_get('foo')
    assert foo() == 'bar'
    # Test with no value present in the dictionary
    foo = cliargs_deferred_get('not_there')
    assert foo() == 'oh well'

    fast = cliargs_deferred_get('fast', shallowcopy=True)
    faster = cliargs_deferred

# Generated at 2022-06-22 19:50:33.078280
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from collections import OrderedDict, Counter
    from ansible.module_utils.common._collections_compat import Sequence

    context = CLIArgs({'foo': 'bar', 'baz': ['qux']})
    getter = cliargs_deferred_get('foo', 'not there')
    assert getter() == 'bar'
    assert context.get('foo') == 'bar'
    assert cliargs_deferred_get('baz')(shallowcopy=True) == ['qux']

    # Everything but mappings and sequences just return itself
    assert isinstance(cliargs_deferred_get('foo')(shallowcopy=True), str)
    assert isinstance(cliargs_deferred_get('foo')(), str)
    assert cliargs_deferred_get('baz')() == ['qux']

# Generated at 2022-06-22 19:50:41.768271
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set

    CLIARGS['key1'] = 'value1'
    assert cliargs_deferred_get('key1')() == 'value1'
    assert cliargs_deferred_get('key1', shallowcopy=True)() == 'value1'

    CLIARGS['key2'] = ['value2_0', 'value2_1']
    assert cliargs_deferred_get('key2')() == ['value2_0', 'value2_1']
    assert cliargs_deferred_get('key2', shallowcopy=True)() == ['value2_0', 'value2_1']


# Generated at 2022-06-22 19:50:53.413890
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import namedtuple

    MyCliArgs = namedtuple('CliArgs', ['get'])
    global CLIARGS
    CLIARGS = MyCliArgs(lambda key, default=None: {
        'foo': 'bar',
        'list': [1, 2, 3],
        'dict': {'bar': 'baz'},
        'aggregate': [(1, 2), (3, 4)],
    }.get(key, default))

    assert cliargs_deferred_get('foo')(), 'bar'
    assert cliargs_deferred_get('dict')(), {'bar': 'baz'}
    assert cliargs_deferred_get('list')(), [1, 2, 3]

    bar = cliargs_deferred

# Generated at 2022-06-22 19:51:01.563804
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Can get a value
    CLIARGS['__ansible_vault'] = None
    assert cliargs_deferred_get('__ansible_vault')() == None

    def non_shallow_copy():
        # return value is not a shallow copy
        CLIARGS['__ansible_module_name'] = 'dummy'
        value = cliargs_deferred_get('__ansible_module_name')()
        assert value == 'dummy'
        value[0] = 'f'
        assert CLIARGS['__ansible_module_name'] == 'fummy'

    non_shallow_copy()

    # Shallow copy returns shallow copy
    def shallow_copy():
        CLIARGS['__ansible_module_name'] = 'dummy'
        value = cliargs_deferred_get