

# Generated at 2022-06-22 19:41:03.690794
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    normal = {'foo': 'bar', 'nope': 'var'}
    nested = {'foo': ['bar']}

    # no shallowcopy, nested structure, normal value
    CLIARGS = CLIArgs(normal)
    assert cliargs_deferred_get('foo')() is CLIARGS.get('foo')

    # no shallowcopy, nested structure, default value
    CLIARGS = CLIArgs(normal)
    assert cliargs_deferred_get('baz')() == 'baz'

    # no shallowcopy, nested structure, default in kwargs
    CLIARGS = CLIArgs(normal)
    assert cliargs_deferred_get('baz', default='doh')() == 'doh'

    # shallowcopy, nested structure, normal value

# Generated at 2022-06-22 19:41:13.830692
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({'nested': {'other': 'foo'}, 'other': {'nested': 'bar'}})
    f = cliargs_deferred_get('nested')
    assert f() == {'other': 'foo'}
    f = cliargs_deferred_get('nested')
    assert f()['other'] == 'foo'
    f = cliargs_deferred_get('nested', default='bar')
    assert f() == 'bar'
    f = cliargs_deferred_get('nested', shallowcopy=True)
    assert f() == {'other': 'foo'}
    # Check shallow copies
    assert f() is not cliargs['nested']



# Generated at 2022-06-22 19:41:24.527712
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class C:
        foo = cliargs_deferred_get('foo')
    c = C()
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'something'})
    assert c.foo == 'something'
    CLIARGS['foo'] = 'something else'
    assert c.foo == 'something else'
    CLIARGS = CLIArgs({'foo': ['a', 'b']})
    assert c.foo == ['a', 'b']
    assert c.foo is not CLIARGS['foo']
    CLIARGS = CLIArgs({'foo': {'a': 'b'}})
    assert c.foo == {'a': 'b'}
    assert c.foo is not CLIARGS['foo']
    CLIARGS = CLIArgs({'foo': {'a', 'b'}})


# Generated at 2022-06-22 19:41:35.105266
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from unittest import TestCase
    from unittest.mock import patch

    class TestCLIARGS(GlobalCLIArgs):
        def __init__(self, args):
            super().__init__(args)
            self._deferred_get_tests = []

        def get(self, key, default=None):
            # Store all calls to get in the _deferred_get_tests list so we can run tests on them
            self._deferred_get_tests.append((key, default))
            return super().get(key, default)

    class CliArgsTestCase(TestCase):
        def setUp(self):
            global CLIARGS
            self.CLIARGS = CLIARGS
            CLIARGS = TestCLIARGS({})

        def tearDown(self):
            global CLIARGS
           

# Generated at 2022-06-22 19:41:45.514312
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This test verifies the closure function
    class TestArgs(object):
        def __init__(self, **kwargs):
            self._data = kwargs

        def get(self, key, default=None):
            return self._data.get(key, default)

        def __getitem__(self, key):
            return self._data[key]

    global CLIARGS
    cli_args = TestArgs(val1='abc')
    CLIARGS = cli_args
    assert cliargs_deferred_get('val1')() == 'abc'

    cli_args = TestArgs(list1=[1, 2, 3])
    CLIARGS = cli_args
    assert cliargs_deferred_get('list1')() == [1, 2, 3]
    assert cliargs_deferred

# Generated at 2022-06-22 19:41:55.453012
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    global CLIARGS
    testargs = {'a': 1, 'b': 'abc', 'c': {1: 1, 2: 2, 3: 3}, 'd': [1, 2, 3, 4]}
    CLIARGS = CLIArgs(testargs)

    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('a', shallowcopy=False)() == 1
    assert cliargs_deferred_get('a', default=3)() == 1
    assert cliargs_deferred_get('a', default=3, shallowcopy=True)() == 1

# Generated at 2022-06-22 19:42:05.499603
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    value = 'bar'
    cliargs = {'foo': value}
    _init_global_context(cliargs)

    assert CLIARGS == cliargs
    assert cliargs_deferred_get('foo')() == value
    assert cliargs_deferred_get('foo', shallowcopy=True)() == value
    assert cliargs_deferred_get('foo')() is value
    assert cliargs_deferred_get('foo', shallowcopy=True)() is value

    def inner():
        cliargs_deferred_get('foo')()

    assert cliargs_deferred_get('foo', default='spam')() == 'spam'

    with pytest.raises(KeyError):
        cliargs_deferred_get('bar')()

    assert cliargs

# Generated at 2022-06-22 19:42:15.996138
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

# Generated at 2022-06-22 19:42:24.804918
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    orig = CLIARGS

    # Test when no value set
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('nokey', default=3)() == 3
    assert cliargs_deferred_get('nokey', default=['a', 'b'])() == ['a', 'b']
    assert cliargs_deferred_get('nokey', default={'a': 'b'})() == {'a': 'b'}
    assert cliargs_deferred_get('nokey', default={'a': 'b'})() == {'a': 'b'}
    assert cliargs_deferred_get('nokey', default=set(('a', 'b')))() == set(('a', 'b'))
    assert cli

# Generated at 2022-06-22 19:42:35.021240
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_case(assertion, value=None, default=None, shallowcopy=False):
        foo = 'bar'
        bar = [foo, foo, foo]
        baz = {'quux': foo, foo: bar}
        if value is None:
            value = foo
        cliargs = GlobalCLIArgs({'key': value})
        inner = cliargs_deferred_get('key', default, shallowcopy)
        if assertion:
            assert inner() == assertion, 'Value is not equal'
        else:
            assert inner() is assertion
            return
        if shallowcopy:
            assert inner() is not assertion
            bar[1] = 'qux'
            assert inner() == assertion
            baz[foo][2] = 'qux'
            assert inner() == assertion

# Generated at 2022-06-22 19:42:45.043967
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'mykey': ['one', 'two', 'three']})
    getter = cliargs_deferred_get('mykey', shallowcopy=True)
    assert CLIARGS['mykey'] == getter()
    CLIARGS['mykey'].append('four')
    assert CLIARGS['mykey'] == getter()
    assert CLIARGS['mykey'] != ['one', 'two', 'three']

    CLIARGS = CLIArgs({'mykey': 'onetwothree'})
    getter = cliargs_deferred_get('mykey', shallowcopy=True)
    assert CLIARGS['mykey'] == getter()
    CLIARGS['mykey'] = 'fourfive'
    assert CLIARGS['mykey'] == getter()

# Generated at 2022-06-22 19:42:56.698198
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test getting a value
    cli_args = {'verbosity': 4, 'foo': 'bar'}
    _init_global_context(cli_args)
    val_function = cliargs_deferred_get('foo')
    assert val_function() == 'bar'
    # Test getting the default value
    val_function = cliargs_deferred_get('bar', default='baz')
    assert val_function() == 'baz'
    # Test getting a list
    cli_args = {'verbosity': 4, 'foo': ['bar']}
    _init_global_context(cli_args)
    val_function = cliargs_deferred_get('foo')
    assert val_function() == ['bar']
    # Test getting a copy of a list
    val_function = cliargs_

# Generated at 2022-06-22 19:43:03.766728
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_deferred_get(value, expected):
        expected = expected()
        # 1. Execute cliargs_deferred_get
        deferred_get = cliargs_deferred_get('key', value)
        v = deferred_get()
        # We don't want to just do an assertEqual because the default value from
        # cliargs_deferred_get might be a list and we want to check that it was
        # shallow copied.
        assert v == expected
        # 2. Validate that the default is not modified by the deferred get
        if is_sequence(value):
            value.append(2)
        elif isinstance(value, (Mapping, Set)):
            m = value
            m['key'] = 2
        else:
            assert False, 'Unknown type for value'
        assert v == expected

# Generated at 2022-06-22 19:43:14.392157
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import random
    from ansible.module_utils.common._collections_compat import OrderedDict

    # Initialize CLIARGS
    CLIARGS['a'] = random.random()
    CLIARGS['b'] = range(random.randint(0, 100))
    CLIARGS['c'] = OrderedDict([
        ('foo', random.random()),
    ])
    CLIARGS['d'] = set(range(random.randint(0, 100)))

    # Test that deferred access works with regular values
    assert cliargs_deferred_get('a') == CLIARGS.get('a')

    # Test that deferred access works with lists
    assert cliargs_deferred_get('b')[:] == CLIARGS.get('b')

# Generated at 2022-06-22 19:43:21.198238
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # First create the mock object that simulates CLIARGS
    _CLIARGS = CLIArgs({'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2, 'c': 3}})
    CLIARGS = _CLIARGS

    # Do the direct access
    assert CLIARGS['a'] == 1
    assert CLIARGS['b'] == 2
    assert CLIARGS['c'] == {'a': 1, 'b': 2, 'c': 3}

    # Now create the closures
    f1 = cliargs_deferred_get('a')
    f2 = cliargs_deferred_get('b')
    f3 = cliargs_deferred_get('c')
    f4 = cliargs_deferred_get('d', default=10)
    f5

# Generated at 2022-06-22 19:43:31.274906
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get"""
    class Container(object):
        pass
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': (1, 2, 3), 'c': [1, 2, 3], 'd': {'a': 1}, 'e': set([1, 2, 3]), 'f': Container()})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('a', default=0)() == 1
    assert cliargs_deferred_get('g', default=0)() == 0
    assert cliargs_deferred_get('b')() == (1, 2, 3)
    assert cliargs_deferred_get('c')() == [1, 2, 3]
    assert cl

# Generated at 2022-06-22 19:43:38.912188
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.json_utils import _JSONDecoder
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_text

    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo')() == None
    cli_args = {'foo': u'bar'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == u'bar'

    # Deferred access also checks the type of CLIARGS
    assert cliargs_deferred_get('foo', default='something')() == u'bar'

    cli_args = {'foo': None}
    _init_global_context(cli_args)
    assert cl

# Generated at 2022-06-22 19:43:45.901893
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({
        'foo': None,
        'bar': ['a', 'b', 'c'],
        'baz': {'a': 1, 'b': 2},
        'qux': set(('a', 'b', 'c'))})

    assert CLIARGS['foo'] is None
    assert cliargs_deferred_get('foo')() is None

    assert CLIARGS['bar'] == ['a', 'b', 'c']
    assert cliargs_deferred_get('bar')() == ['a', 'b', 'c']

    assert CLIARGS['baz'] == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('baz')() == {'a': 1, 'b': 2}

    assert CLIARGS['qux'] == set

# Generated at 2022-06-22 19:43:52.681204
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''This function contains the unit tests for cliargs_deferred_get'''
    global CLIARGS
    CLIARGS = CLIArgs({'test': 'value'})
    assert cliargs_deferred_get('test')() == 'value'
    assert cliargs_deferred_get('missing')() is None
    assert cliargs_deferred_get('missing', default='default')() == 'default'
    assert cliargs_deferred_get('test', shallowcopy=True)() == 'value'

# Generated at 2022-06-22 19:44:03.350946
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from copy import copy

    global CLIARGS

    # Make sure the function works with a global CLIARGS object
    CLIARGS = GlobalCLIArgs.from_options({'test_key': "test_value"})
    assert cliargs_deferred_get('test_key')() == 'test_value'

    # Make sure the function properly copys values when shallowcopy=True
    CLIARGS = GlobalCLIArgs.from_options({'test_key_1': [1,2,3], 'test_key_2': {1: 2}})
    assert cliargs_deferred_get('test_key_1', shallowcopy=True)() == [1,2,3]

# Generated at 2022-06-22 19:44:09.232976
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the deferred_get function

    Args:
        cliargs (CliArgs): Dictionary like object where the get is actually getting the value.
    """
    def test_inner_level(func, **kwargs):
        func()

    cliargs = CLIArgs(dict(
        foo=dict(
            bar=dict(
                baz='baz',
            ),
        ),
    ))

    # test_inner_level will call func
    test_inner_level(func=cliargs_deferred_get(key='foo.bar.baz', cliargs=cliargs))
    with pytest.raises(KeyError):
        test_inner_level(func=cliargs_deferred_get(key='foo.bar.noexist', cliargs=cliargs))

# Generated at 2022-06-22 19:44:18.986762
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup and verify initial state
    default = "bar"
    cli_args = {'foo': 'baz'}
    _init_global_context(cli_args)
    assert CLIARGS.get('foo', default=default) == cli_args['foo']
    assert CLIARGS.get('bar', default=default) == default

    # Make sure that a key that does not yet exist still returns the default
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default=default)() == default
    assert cliargs_deferred_get('bar', default=default)() == default

    # Make sure that once the global cli args are initialized that the closure
    # returns the same results as a direct call
    _init_global_context(cli_args)
    assert cliargs

# Generated at 2022-06-22 19:44:28.856102
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is very quick and dirty but needed for the test to pass
    global CLIARGS
    CLIARGS = CLIArgs({'x1': [1, 2, 3], 'x2': 'abc'})

    assert cliargs_deferred_get('x1')() == [1, 2, 3]
    assert cliargs_deferred_get('x2')() == 'abc'
    assert cliargs_deferred_get('x3')() is None

    assert cliargs_deferred_get('x1', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('x2', shallowcopy=True)() == 'abc'
    assert cliargs_deferred_get('x3', shallowcopy=True)() is None

# Generated at 2022-06-22 19:44:39.061026
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.context import cliargs_deferred_get

    # this isn't what CLIARGS is initialized to by the code, but we use it for these tests
    global CLIARGS
    CLIARGS = CLIArgs({})

    # nothing has been set in global context yet, so all of these should return None
    assert(cliargs_deferred_get('wait_for')() is None)
    assert(cliargs_deferred_get('wait_for', default='a')() == 'a')
    assert(cliargs_deferred_get('wait_for', default=['a'])() == ['a'])
    assert(cliargs_deferred_get('wait_for', shallowcopy=True)() is None)

# Generated at 2022-06-22 19:44:45.011204
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({'foo': [1, 2, 3, 4]})
    closure = cliargs_deferred_get('foo', default=[])
    closure2 = cliargs_deferred_get('foo', default=None, shallowcopy=True)
    assert closure() == [1, 2, 3, 4]
    assert closure2() == [1, 2, 3, 4]
    assert closure() is not closure2()

# Generated at 2022-06-22 19:44:53.097885
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Sequence
    # Verify Default
    _init_global_context({})
    assert CLIARGS.get('foo') is None
    assert CLIARGS.get('foo', default=42) == 42
    # Verify Fetching
    _init_global_context({'foo': 42})
    assert cliargs_deferred_get('foo')() == 42
    # Verify Shallow Copy
    _init_global_context({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    # Verify Reference
    value = cliargs_deferred_get('foo')()
    assert value is cliargs_deferred_get('foo')()

# Generated at 2022-06-22 19:45:03.954393
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    attr_settings = {'default': cliargs_deferred_get('option', default='foo')}
    attr_settings['shallowcopy'] = cliargs_deferred_get('option', default=['foo'], shallowcopy=True)
    attr_settings['tuple'] = cliargs_deferred_get('option', default=('foo',))
    attr_settings['tuple_shallow'] = cliargs_deferred_get('option', default=('foo',), shallowcopy=True)
    attr_settings['set'] = cliargs_deferred_get('option', default={'foo'})
    attr_settings['set_shallow'] = cliargs_deferred_get('option', default={'foo'}, shallowcopy=True)


# Generated at 2022-06-22 19:45:11.796145
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeGlobalArgs:
        def __init__(self, *args, **kwargs):
            self.opts = {}
            for arg, value in kwargs.items():
                self[arg] = value

        def __getitem__(self, key):
            return self.opts[key]

        def __setitem__(self, key, value):
            self.opts[key] = value

    class FakeContext:
        def __init__(self, *args, **kwargs):
            self.opts = {}
            for arg, value in kwargs.items():
                self[arg] = value

        def __getitem__(self, key):
            return self.opts[key]

        def __setitem__(self, key, value):
            self.opts[key] = value


# Generated at 2022-06-22 19:45:22.441783
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import collections
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS['baz'] = collections.defaultdict(int, foo='transmogrified')
    assert cliargs_deferred_get('baz')() == {'foo': 'transmogrified'}
    # Make sure copies are made
    CLIARGS['baz']['newkey'] = 42
    assert cliargs_deferred_get('baz')() == {'foo': 'transmogrified'}
    assert cliargs_deferred_get('baz', shallowcopy=True)() == {'foo': 'transmogrified', 'newkey': 42}

# Generated at 2022-06-22 19:45:31.721269
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'command': ['setup', '--tree', '/tmp/foo'], 'module_args': {'_ansible_verbose': 3}})
    assert cliargs_deferred_get('tree')('.') == '/tmp/foo'
    assert cliargs_deferred_get('_ansible_verbose')(1) == 3
    assert cliargs_deferred_get('_ansible_version')('2.5') == '.'
    assert cliargs_deferred_get('command')(['setup']) == ['setup', '--tree', '/tmp/foo']

# Generated at 2022-06-22 19:45:42.496121
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'a': 'A', 'b': 'B', 'c': 'C'}
    key = 'a'
    default = 'default'

    # Check that the closure returns the right value
    assert cliargs_deferred_get(key)(cli_args) == cli_args[key]
    assert cliargs_deferred_get(key, default)(cli_args) == cli_args[key]
    assert cliargs_deferred_get('nosuchkey', default)(cli_args) == default

    # Check that we get a shallow copy
    cliargs_deferred_get('a', shallowcopy=True)(cli_args) == cli_args[key]

# Generated at 2022-06-22 19:45:50.198785
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def return_num(value):
        return value
    def return_num_list(value):
        return value[:]
    def return_num_dict(value):
        return value.copy()

    # Do it once to ensure that the value of CLIARGS is not cached
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1})
    assert CLIARGS.get('a', default=10) == 1
    assert cliargs_deferred_get('a')(10) == 1
    assert cliargs_deferred_get('a', shallowcopy=True)(10) == 1
    assert cliargs_deferred_get('a', shallowcopy=False)(10) == 1
    assert cliargs_deferred_get('b')(10) == 10

# Generated at 2022-06-22 19:46:01.156728
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='quux')() == 'quux'

    _init_global_context({'foo': ['a', 'b', 'c']})
    assert cliargs_deferred_get('foo')() == ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', shallowcopy=True)() != CLIARGS['foo']


# Generated at 2022-06-22 19:46:10.569602
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    import os
    import pytest
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import PY2

    CLIARGS['string_param'] = 'value'
    CLIARGS['int_param'] = 1
    CLIARGS['list_param'] = [1]
    CLIARGS['mapping_param'] = {'a': 1}
    CLIARGS['set_param'] = {1}

    string_param_deferred = cliargs_deferred_get('string_param')
    int_param_deferred = cliargs_deferred_get('int_param')
    list_param_deferred = cliargs_deferred_get('list_param')

# Generated at 2022-06-22 19:46:21.445468
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Important to use the singleton as we are trying to test the replacement of the global variable
    global CLIARGS
    CLIARGS = CLIArgs({})

    # Test simple get with no defaults and no shallow copy
    assert cliargs_deferred_get('foo')() is None
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS['foo'] = 'bar2'
    assert cliargs_deferred_get('foo')() == 'bar2'

    # Test get with default and no shallow copy
    CLIARGS['foo'] = 'bar3'
    assert cliargs_deferred_get('foo', default='bak')() == 'bar3'
    assert cliargs_deferred_get('bar', default='bak')()

# Generated at 2022-06-22 19:46:32.699817
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils import context_objects

    class TestCliArgs(context_objects.CliArgs):
        """Just to make sure we have the correct behavior"""
        def __init__(self, args):
            context_objects.CliArgs.__init__(self, args)

        def __repr__(self):
            return 'TestCliArgs(%r)' % self.args

    class TestGlobalCliArgs(context_objects.GlobalCliArgs):
        """Just to make sure we have the correct behavior"""
        def __init__(self, args):
            context_objects.GlobalCliArgs.__init__(self, args)

        def __repr__(self):
            return 'TestGlobalCliArgs(%r)' % self.args


# Generated at 2022-06-22 19:46:39.742039
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 'bar', 'bar': [1,2,3], 'baz': {1:2, 3:4}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() == [1,2,3]
    assert cliargs_deferred_get('baz')() == {1:2, 3:4}
    assert cliargs_deferred_get('baz', shallowcopy=True)() == {1:2, 3:4}
    assert cliargs_deferred_get('bar', shallowcopy=True)() == [1,2,3]

    assert cliargs_deferred_get('qux')() is None

# Generated at 2022-06-22 19:46:50.689925
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    old_cliargs = CLIARGS

# Generated at 2022-06-22 19:46:59.674451
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test closure over getting a key from CLIARGS with shallow copy functionality

    This is a direct test of the closure method of ``cliargs_deferred_get`` so that
    it will get picked up even if the function is renamed or moved
    """
    def test_get_with_uninitialized_context():
        """Test cliargs_deferred_get with an uninitialized context

        This tests that ``cliargs_deferred_get`` can be used before ``CLIARGS`` has been
        initialized
        """
        assert cliargs_deferred_get('no-such-key', 'default_value')() is 'default_value'

    import sys

    # This must be run from within python2 since that is what creates the old functioning behavior

# Generated at 2022-06-22 19:47:11.057651
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        CLIARGS
    except NameError:
        CLIARGS = CLIArgs({})

    # "default" not set
    key = 'key'
    default = None
    get = cliargs_deferred_get(key, default)
    assert default == get(), 'default'
    CLIARGS[key] = 1
    assert 1 == get(), 'existing key'

    # "default" set
    default = 'default'
    get = cliargs_deferred_get(key, default)
    del CLIARGS[key]
    assert default == get(), 'default'
    CLIARGS[key] = 1
    assert 1 == get(), 'existing key'
    CLIARGS.clear()

    # Shallow copy
    get = cliargs_deferred_get(key, default, shallowcopy=True)

# Generated at 2022-06-22 19:47:19.755034
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _set_default_field(field):
        field.default = cliargs_deferred_get(field.name, False)
        return field
    # Test that CLIARGS is immutable
    from ansible.cli import CLI
    from ansible.utils.context_objects import CliArgs

    class ImmutableCliArgs(CliArgs):
        @property
        def cli_args(self):
            return self._cli_args

        @cli_args.setter
        def cli_args(self, value):
            raise RuntimeError(
                'Cannot set cli_args once context objects are initialized')

    cli_args = ImmutableCliArgs({})
    _set_default_field(CLI.args)(cli_args)

# Generated at 2022-06-22 19:47:30.419836
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make sure we get the correct value when it exists
    CLIARGS['a'] = 'a_value'
    assert cliargs_deferred_get('a')() == 'a_value'
    assert cliargs_deferred_get('a')(shallowcopy=True) == 'a_value'

    # Make sure we get the default value when it does not exist
    assert cliargs_deferred_get('b')() == None
    assert cliargs_deferred_get('b', default='default_value')() == 'default_value'

    # Make sure that if we have a shallow copy we get back a new object
    CLIARGS['c'] = [1, 2, 3]
    assert cliargs_deferred_get('c')() is CLIARGS['c']
    assert cliargs_deferred_

# Generated at 2022-06-22 19:47:37.834424
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    _init_global_context(dict(foo='foo', bar=dict(a=1, b=2, c=3)))

    assert 'foo' == cliargs_deferred_get('foo')()
    assert 42 == cliargs_deferred_get('bogus', 42)()
    assert [1, 2, 3] == cliargs_deferred_get('bar', shallowcopy=True)()
    assert dict(a=1, b=2, c=3) == cliargs_deferred_get('bar', shallowcopy=True)()

# Generated at 2022-06-22 19:47:48.772345
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_func():
        id_key = cliargs_deferred_get('id')
        return id_key()

    original_value = CLIARGS._options
    CLIARGS._options = {'id':'original'}
    assert test_func() == 'original'

    CLIARGS._options = {'id':'original', 'new_key':'new_value'}
    assert test_func() == 'original'

    CLIARGS._options = {'new_key':'new_value'}
    assert test_func() == None

    CLIARGS._options = {'id':['original']}
    assert test_func() == ['original']

    CLIARGS._options = {'id':{'original':'original'}}
    assert test_func() == {'original':'original'}

   

# Generated at 2022-06-22 19:47:58.098241
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs, CLIAction
    import datetime

    # CLIAction is immutable so we can use it for testing
    ca = CLIAction('foo')
    ga = GlobalCLIArgs({'_parse_called': True, 'cliopts': {'help': True, 'action': ca}})

    # Test when key is present in cliargs
    dg = cliargs_deferred_get('help')
    assert dg()

    # Test when key is present and we need to copy
    dg = cliargs_deferred_get('action', shallowcopy=True)
    assert dg() == ca
    assert dg() is not ca

    # Test when key is missing and we have a default

# Generated at 2022-06-22 19:48:08.670462
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check_shallowcopy(key, default=None, shallowcopy=False):
        val = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)()
        mod = val.pop()
        assert mod == 'mod'
        val.append('notmod')

    # test: key mapping to a list
    global CLIARGS
    CLIARGS = CLIArgs({'key': ['val1', 'val2']})
    val = cliargs_deferred_get('key')()
    assert val == ['val1', 'val2']
    check_shallowcopy('key')

    # test: key not in cliargs, default provided
    CLIARGS = CLIArgs({'key': ['val1', 'val2']})

# Generated at 2022-06-22 19:48:18.638645
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class DummyCliArgs:
        def get(self, key, default=None):
            return self.store[key] if key in self.store else default

    value = {'foo': 'bar'}
    cliargs = DummyCliArgs()
    cliargs.store = {'key': value}

    def get_closure():
        return cliargs_deferred_get('key')

    # Test closure with original bound
    tmp = cliargs_deferred_get
    cliargs_deferred_get = get_closure
    try:
        assert id(cliargs_deferred_get()) == id(value)
    finally:
        cliargs_deferred_get = tmp

    # Test closure with bound to new instance
    cliargs_deferred_get = get_closure()

# Generated at 2022-06-22 19:48:27.680056
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')(), "Should get foo back"

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', 'baz')(), "Should get foo back"

    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', 'baz')(), "Should get foo back"

# Generated at 2022-06-22 19:48:39.556454
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test_key1': 'test_value1'})
    assert cliargs_deferred_get('test_key1')() == 'test_value1'
    assert cliargs_deferred_get('test_key1', 'default_value1')() == 'test_value1'
    assert cliargs_deferred_get('test_key2', 'default_value2')() == 'default_value2'
    assert cliargs_deferred_get('test_key3', shallowcopy=True)() is None
    assert cliargs_deferred_get('test_key4', shallowcopy=True)() is None
    CLIARGS = CLIArgs({'test_key4': [1, 2, 3]})

# Generated at 2022-06-22 19:48:49.519906
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""

    # We are using a dict here because dicts are Mapping instances
    test_val = {}
    CLIARGS._extra_values['foo'] = test_val
    result = cliargs_deferred_get('foo')
    assert result == test_val

    result = cliargs_deferred_get('foo', shallowcopy=True)
    assert result is not test_val
    assert result == test_val

    test_val = []
    CLIARGS._extra_values['foo'] = test_val
    result = cliargs_deferred_get('foo')
    assert result == test_val

    result = cliargs_deferred_get('foo', shallowcopy=True)
    assert result is not test_val
    assert result == test_val

# Generated at 2022-06-22 19:48:56.799185
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'foo': 'bar'})
    import types
    assert isinstance(cliargs_deferred_get('foo'), types.FunctionType)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('other', 'not bar')() == 'not bar'

    CLIARGS = CLIArgs({'foo': ['bar']})
    assert isinstance(cliargs_deferred_get('foo'), types.FunctionType)
    assert cliargs_deferred_get('foo')() == ['bar']

    CLIARGS = CLIArgs({'foo': {'bar': 'bar'}})
    assert isinstance(cliargs_deferred_get('foo'), types.FunctionType)

# Generated at 2022-06-22 19:49:07.908460
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _assert_cliargs_deferred_get(key, default, shallowcopy, expected, cliargs):
        inner = cliargs_deferred_get(key, default, shallowcopy)
        _init_global_context(cliargs)
        assert inner() == expected, "%r != %r" % (inner(), expected)

    _assert_cliargs_deferred_get('somekey', 'somevalue', False, 'somevalue', {})
    _assert_cliargs_deferred_get('somekey', 'somevalue', False, 'somevalue', {'somekey': 'notsomevalue'})
    _assert_cliargs_deferred_get('somekey', 'somevalue', False, 'notsomevalue', {'somekey': 'notsomevalue'})

# Generated at 2022-06-22 19:49:16.441002
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the metadata field works with the default value of None
    get_field = cliargs_deferred_get('metadata', default=None, shallowcopy=False)
    assert get_field() is None

    # Test that the metadata field works with a different default value
    get_field = cliargs_deferred_get('metadata', default='notset', shallowcopy=False)
    assert get_field() == 'notset'

    # Test that the tags field works with the default value of None
    get_field = cliargs_deferred_get('tags', default=None, shallowcopy=False)
    assert get_field() is None

    # Test that the tags field works with a different default value
    get_field = cliargs_deferred_get('tags', default='notset', shallowcopy=False)
    assert get_field

# Generated at 2022-06-22 19:49:23.107959
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'testkey': 'testvalue'})
    assert 'testvalue' == cliargs_deferred_get('testkey')()
    assert 'newtestvalue' == cliargs_deferred_get('testkey', default='newtestvalue')()
    assert 'testvalue' == cliargs_deferred_get('nokey', default='newtestvalue')()
    assert 'newtestvalue' == cliargs_deferred_get('nokey', default='newtestvalue')()
    CLIARGS = CLIArgs({})

# Generated at 2022-06-22 19:49:33.497768
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # first we need to test the inner function
    assert cliargs_deferred_get('foo')() == None
    assert callable(cliargs_deferred_get('foo'))

    # now we can test the full closure
    assert cliargs_deferred_get('foo')(foo='bar') == 'bar'

    # now we can test the full closure
    assert cliargs_deferred_get('foo')() == 'bar'

    # now we can test the full closure
    assert cliargs_deferred_get('foo')(foo=[1]) == [1]

    # now we can test the full closure
    assert cliargs_deferred_get('foo')() == [1]

    # now we can test the full closure

# Generated at 2022-06-22 19:49:44.853765
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get()"""
    # Case 1: value is None and shallowcopy is false
    cliargs_value = None
    result = cliargs_deferred_get(cliargs_value)()
    assert result is None

    # Case 2: value is None and shallowcopy is true
    cliargs_value = None
    result = cliargs_deferred_get(cliargs_value, shallowcopy=True)()
    assert result is None

    # Case 3: value is a string and shallowcopy is false
    cliargs_value = "abc"
    result = cliargs_deferred_get(cliargs_value)()
    assert result == "abc"

    # Case 4: value is a string and shallowcopy is true
    cliargs_value = "abc"
    result = cl

# Generated at 2022-06-22 19:49:52.916384
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # Need to access protected attributes to test this function
    global CLIARGS
    args = dict(user='testuser', password='testpass')
    CLIARGS = CLIArgs(args)
    assert cliargs_deferred_get('user', 'testuser')() == cliargs_deferred_get('user')('testuser') == args['user']
    assert cliargs_deferred_get('foo', 'bar')('testuser') == 'testuser'
    assert cliargs_deferred_get('password')() == args['password']

# Generated at 2022-06-22 19:50:00.354289
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    def assert_value_unchanged(value):
        assert value == cliargs_deferred_get('test_var')(), \
            'Expected {} and {} to be the same'.format(value, cliargs_deferred_get('test_var')())

    # Make sure that we can pull a key that we set
    CLIARGS.set('test_var', 'testing')
    assert CLIARGS.get('test_var') == cliargs_deferred_get('test_var')()

    # Make sure we can pull a key that doesn't exist with a default
    assert cliargs_deferred_get('new_key', default='testing')() == 'testing'

    # Make sure that we can change the default returned by cliargs_deferred_get
   

# Generated at 2022-06-22 19:50:11.465309
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def mysetup():
        cli_args = {'foo': {'bar': {'baz': 'happy'}}}
        _init_global_context(cli_args)

    # Setup for running the test.  If running as a 'real' test, our global context has not been
    # setup.  So we run our setup inline for real tests
    if not CLIARGS:
        mysetup()

    def do_test(key, default=None, shallowcopy=False):
        return cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)()

    assert do_test('foo') == {'bar': {'baz': 'happy'}}
    assert do_test('bad_val') is None
    assert do_test('bad_val', 'mydefault') == 'mydefault'

    assert do

# Generated at 2022-06-22 19:50:21.657381
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest  # pylint: disable=import-error
    # check argument validation
    with pytest.raises(TypeError):
        list(cliargs_deferred_get())
    with pytest.raises(TypeError):
        list(cliargs_deferred_get(key='foo'))
    with pytest.raises(TypeError):
        list(cliargs_deferred_get(default='foo'))
    with pytest.raises(TypeError):
        list(cliargs_deferred_get(shallowcopy='foo'))

    # check defaults
    _init_global_context({})
    assert cliargs_deferred_get(key='verbosity', default=1)() == 1
    assert cliargs_deferred_get(key='verbosity', default=1, shallowcopy=True)

# Generated at 2022-06-22 19:50:33.079908
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function ``cliargs_deferred_get``"""
    global CLIARGS
    CLIARGS = CLIArgs({'mykey': ['value']})
    assert cliargs_deferred_get('mykey', default=False)()

    # cliargs_deferred_get with shallow copy
    assert isinstance(cliargs_deferred_get('mykey', default=['mydefault'], shallowcopy=True)(), list)
    assert cliargs_deferred_get('mykey', default=['mydefault'], shallowcopy=True)() == ['value']

    CLIARGS = CLIArgs({'mykey': {'mykey': 'myvalue'}})
    assert isinstance(cliargs_deferred_get('mykey', default={'mydefault': 'mydefault'}, shallowcopy=True)(), dict)
    assert cl

# Generated at 2022-06-22 19:50:35.214191
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_arg_dict = {'DEPRECATED_DEFAULT_VAULT_ID_MATCH': 'foo'}

    def test_cliargs_deferred_get_inner():
        _init_global_context(test_arg_dict)
        assert cliargs_deferred_get('DEPRECATED_DEFAULT_VAULT_ID_MATCH')() == 'foo'

    test_cliargs_deferred_get_inner()

# Generated at 2022-06-22 19:50:40.032866
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    key = 'foo'
    value = 'bar'
    _init_global_context(dict(foo=value))
    assert value == cliargs_deferred_get(key)()

    _init_global_context(dict())
    default = 42
    assert default == cliargs_deferred_get(key, default=default)()
    assert default == cliargs_deferred_get(key, None)()  # Should also work without keyword

# Generated at 2022-06-22 19:50:44.992431
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """test cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'a': 'aaaaa', 'b': [1, 2, 3]})
    assert cliargs_deferred_get('a')() == 'aaaaa'
    assert cliargs_deferred_get('a', shallowcopy=True)() == 'aaaaa'
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('b', shallowcopy=True)() == [1, 2, 3]
    cliargs_deferred_get('b')()[0] = 5
    assert cliargs_deferred_get('b')()[0] == 5



# Generated at 2022-06-22 19:50:54.744748
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.removed import removed

    global_args = {1: 1}
    _init_global_context(global_args)
    ref_func = cliargs_deferred_get(key=1)
    assert ref_func() == 1
    global_args[2] = 2
    ref_func = cliargs_deferred_get(key=2)
    assert ref_func() == 2
    ref_func = cliargs_deferred_get(key=2, shallowcopy=True)
    assert ref_func() == 2
    global_args[2] = removed
    assert ref_func() == 2

    global_args = {1: 1}
    _init_global_context(global_args)

# Generated at 2022-06-22 19:51:02.068398
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import UserDict

    cliargs = UserDict()
    def test_default(default):

        def _init(foo):
            global cliargs
            cliargs = UserDict()
            cliargs['foo'] = foo

        _init(None)
        assert cliargs_deferred_get('foo', default='bar')() == 'bar'

        _init('bar')
        assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    test_default('bar')

    # default can be a callable that returns a value
    def test_default_callable(callable_default):
        def _init(foo):
            global cliargs
            cliargs = UserDict()