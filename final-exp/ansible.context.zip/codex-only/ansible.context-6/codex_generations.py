

# Generated at 2022-06-22 19:41:03.534606
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # We do not test with a shallow copy of a non-collection because we can't get back
    # a copy of a non-collection-- We don't use copy.copy because it's a recursive copy and
    # we only want a shallow copy
    test_dict = {}
    test_list = []
    test_set = set()

    # Test that the inner closure works if the option is present
    CLIARGS = CLIArgs({'test_dict': test_dict, 'test_list': test_list, 'test_set': test_set})
    test_dict_copy = cliargs_deferred_get('test_dict', shallowcopy=True)()
    assert test_dict_copy == test_dict
    test_list_copy = cliargs_deferred_get('test_list', shallowcopy=True)()

# Generated at 2022-06-22 19:41:14.466812
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Sequence
    cli_args = {'foo': [1]}
    _init_global_context(cli_args)
    deferred = cliargs_deferred_get('foo')
    assert deferred() == [1]
    cli_args['foo'].append(2)
    assert deferred() == [1, 2]

    cli_args = {'foo': {'a': 1}, 'bar': 5}
    _init_global_context(cli_args)
    deferred = cliargs_deferred_get('foo', shallowcopy=True)
    assert isinstance(deferred(), dict)
    assert deferred() == {'a': 1}
    cli_args['foo']['b'] = 2

# Generated at 2022-06-22 19:41:24.983577
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar', 'bar': ['baz']}

    class Obj(object):
        foo = cliargs_deferred_get('foo')

    # mutable object
    o1 = Obj()
    _init_global_context(cli_args)
    assert o1.foo == 'bar'

    # shallow copy
    o2 = Obj()
    o2.foo = cliargs_deferred_get('bar', shallowcopy=True)
    assert o2.foo == ['baz']
    o2.foo.append('qux')
    assert o2.foo == ['baz', 'qux']
    assert cli_args['bar'] == ['baz']

    # not in CLIARGS
    o3 = Obj()

# Generated at 2022-06-22 19:41:35.567622
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = ['foo', 'bar', 'baz']
    c1 = cliargs_deferred_get('foo')
    c2 = cliargs_deferred_get('foo', shallowcopy=True)

    assert CLIARGS['foo'] == c1()
    assert CLIARGS['foo'] == c1()
    assert CLIARGS['foo'] == c1()
    assert c1 is c1()
    c1()[0] = 'asdf'
    assert CLIARGS['foo'][0] == 'asdf'

    assert CLIARGS['foo'] == c2()
    assert CLIARGS['foo'] == c2()
    assert CLIARGS['foo'] == c2()
    assert c2 is c2()
    c2()[0] = 'qwer'
    assert CLIAR

# Generated at 2022-06-22 19:41:45.944279
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestClass(object):
        def __init__(self, value):
            self.value = value

    t = TestClass(42)

    args = {}

    _init_global_context(args)
    assert CLIARGS == {}

    getter = cliargs_deferred_get('foo', default=t)
    assert getter() == t
    assert id(getter()) == id(t)
    assert getter.__name__ == 'inner'

    args['foo'] = t
    _init_global_context(args)
    assert CLIARGS['foo'] == t
    assert id(CLIARGS['foo']) == id(t)

    assert getter() == t
    assert id(getter()) == id(t)


# Generated at 2022-06-22 19:41:53.086509
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Since we cannot set module args after the module process has begun
    # lets fake it by changing CLIARGS
    global CLIARGS
    CLIARGS = CLIArgs({'ansible_verbosity': 4})
    value = cliargs_deferred_get('ansible_verbosity')()
    assert value == 4
    CLIARGS = CLIArgs({'ansible_verbosity': 5})
    value = cliargs_deferred_get('ansible_verbosity')()
    assert value == 5

# Generated at 2022-06-22 19:42:03.887393
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CliArgs(dict):
        @property
        def verbosity(self):
            return 1

    class CliArgs2(dict):
        pass

    class CliArgs3(dict):
        @property
        def verbosity(self):
            return 1

    global CLIARGS
    assert cliargs_deferred_get('verbosity')() is None
    CLIARGS = CliArgs3({'verbosity': 2})
    assert cliargs_deferred_get('verbosity')() == 2

    assert cliargs_deferred_get('verbosity', default=1)() == 1

    CLIARGS = CliArgs({'verbosity': 0})
    assert cliargs_deferred_get('verbosity').__closure__[0].cell_contents.verbosity == 1

    CLIARGS = CliArgs

# Generated at 2022-06-22 19:42:06.149963
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """ test the ``cliargs_deferred_get`` function """
    inner = cliargs_deferred_get('test_key', default='test_value')
    assert inner() == 'test_value'

# Generated at 2022-06-22 19:42:16.560672
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'one':1, 'two': [1,2,3], 'three': {'a':1, 'b':2}})
    assert cliargs_deferred_get('one')() == 1
    assert cliargs_deferred_get('one', default=2)() == 1
    assert cliargs_deferred_get('one', default=[])() == 1
    assert cliargs_deferred_get('does_not_exist', default=[])() == []
    assert cliargs_deferred_get('does_not_exist', default=[])() == []
    assert cliargs_deferred_get('does_not_exist', default=[], shallowcopy=True)() == []
    # Test that shallowcopy makes a copy of containers
    a = cliargs_

# Generated at 2022-06-22 19:42:24.996231
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test cliargs_deferred_get function

    This function is only unit tested to ensure it returns a closure that
    returns the value from ``CLIARGS``
    """
    cli_args = {'a': 'c', 'b': [1, 2, 3], 'c': {'foo': 'bar'}, 'd': {1, 2, 3}}
    # this is just a sanity check that the function is working
    assert cli_args['a'] == 'c'
    assert cli_args['b'] == [1, 2, 3]
    assert cli_args['c'] == {'foo': 'bar'}
    assert cli_args['d'] == {1, 2, 3}
    _init_global_context(cli_args)
    # not shallow copying
    assert cliargs_deferred

# Generated at 2022-06-22 19:42:33.892045
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.six import PY3

    # This should be able to run on Python 2.6-2.7 as well as 3.4+ as long as we use
    # the collection_compat module.  We might need to introduce a compat version if
    # it is needed anywhere else though

    # pylint: disable=redefined-outer-name
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # This is the function we're testing
    from ansible.context import cliargs_deferred_get

    # This import is just to get the right CLIArgs objects
    from ansible.context import CLIARGS


# Generated at 2022-06-22 19:42:44.346442
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import unittest

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import UserList
    from ansible.utils.context_objects import Context

    class TestCliargsDeferredGet(unittest.TestCase):

        def setUp(self):
            self.cliargs = Context()
            self.cliargs.set_options({'foo': 'bar'})

        def test_default(self):
            g = cliargs_deferred_get('bar', 'empty')
            self.assertEqual(g(), 'empty')

        def test_preset(self):
            g = cliargs_deferred_get('foo')
            self.assertEqual(g(), 'bar')


# Generated at 2022-06-22 19:42:52.155323
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = {'a': ['b', 'c']}
    CLIARGS._final_options = args
    result = cliargs_deferred_get('a')()
    assert result is args['a']
    result_copy = cliargs_deferred_get('a', shallowcopy=True)()
    assert result_copy is not args['a']
    assert result_copy == args['a']
    assert result_copy is not args['a'][:]
    assert result_copy == args['a'][:]

# Generated at 2022-06-22 19:43:01.133034
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    cli_args = {'foo': 'bar', 'empty': '', 'none': None}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('empty')() == ''
    assert cliargs_deferred_get('none')() is None
    assert cliargs_deferred_get('none', default='default')() == 'default'

    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('empty', shallowcopy=True)() == ''
    assert cliargs_deferred_get('none', shallowcopy=True)() is None

# Generated at 2022-06-22 19:43:04.438377
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    assert cliargs_deferred_get('connection')(), CLIARGS['connection']

# Generated at 2022-06-22 19:43:11.001521
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestClass(object):
        def __init__(self):
            self.set_default()
        def set_default(self):
            self.default = cliargs_deferred_get('default_key', default=10)

    def test_function():
        test_class = TestClass()
        return test_class.default

    assert test_function() == 10

    # Set the global context
    global CLIARGS
    CLIARGS = CLIArgs({'default_key': 5})

    assert test_function() == 5

# Generated at 2022-06-22 19:43:20.311051
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    from copy import deepcopy
    import collections

    # Test default value is returned
    assert cliargs_deferred_get('some_unset_key') is None
    assert cliargs_deferred_get('some_unset_key', default='bar') == 'bar'
    assert cliargs_deferred_get('some_unset_key', default=[]) == []

    def test_deepcopy(value, expected):
        copy = cliargs_deferred_get('key', default=value, shallowcopy=False)()
        if isinstance(copy, collections.Hashable):
            assert copy == expected
        else:
            assert copy is not value
            assert copy == value


# Generated at 2022-06-22 19:43:30.106783
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test without replacing the global CLIARGS
    CLIARGS.set(test_cliargs_deferred_get=1)
    assert cliargs_deferred_get('test_cliargs_deferred_get')() == 1
    assert cliargs_deferred_get('test_deferred_get_with_default', default=2)() == 2
    assert cliargs_deferred_get('test_deferred_get_with_default_None', default=None)() is None
    # Test with replacing the global CLIARGS
    global CLIARGS
    CLIARGS = CLIArgs({'test_cliargs_deferred_get': 2})
    assert cliargs_deferred_get('test_cliargs_deferred_get')() == 2

# Generated at 2022-06-22 19:43:31.472277
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """TODO: write tests"""
    pass

# Generated at 2022-06-22 19:43:38.800833
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get

    This is a sanity check because cliargs_deferred_get is a closure and has no
    unit tests"""
    inner = cliargs_deferred_get('a', default=3, shallowcopy=True)
    assert inner() == 3
    CLIARGS.set('a', 5)
    assert inner() == 5
    CLIARGS.set('a', [1,2,3])
    assert inner() == [1,2,3]
    CLIARGS.set('a', 1)
    assert inner() == 1
    CLIARGS.set('a', {'a': 1, 'b': 2})
    assert inner() == {'a': 1, 'b': 2}
    assert type(inner()) == dict

# Generated at 2022-06-22 19:43:45.781069
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    # We should be able to call it with a field that is not present in the
    # FieldAttribute AND a default value
    assert cliargs_deferred_get('not present', default='hello world')() == 'hello world'

    # We should be able to call it with a field that is present in the
    # FieldAttribute AND a default value
    CLIARGS = CLIArgs(dict(present='hello world'))
    assert cliargs_deferred_get('present', default='goodbye world')() == 'hello world'

    # We should be able to call it with a field that is present in the
    # FieldAttribute AND NO default value
    assert cliargs_deferred_get('present')() == 'hello world'

    # We should be able

# Generated at 2022-06-22 19:43:51.559320
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(foo='foo value'))
    # Test no shallow copy
    new_value = cliargs_deferred_get('foo', shallowcopy=False)
    assert new_value == 'foo value'

    # Test shallow copy
    new_value = cliargs_deferred_get('foo', shallowcopy=True)
    assert new_value == 'foo value'

# Generated at 2022-06-22 19:44:02.843509
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Init context
    _init_global_context({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1}})
    default_value = 'default_value'
    # Get key without shallow copy
    value = cliargs_deferred_get('foo')()
    assert value == 'bar'
    # Get key with shallow copy
    value = cliargs_deferred_get('foo', shallowcopy=True)()
    assert value == CLIARGS.get('foo')
    assert value is not CLIARGS.get('foo')
    # Get key with default value without shallow copy
    value = cliargs_deferred_get('undefined_key', default=default_value)()
    assert value == default_value
    # Get key with default value with shallow copy

# Generated at 2022-06-22 19:44:08.986283
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Fake GlobalCLIArgs
    class _MockCLIArgs(Mapping):
        def __getitem__(self, key):
            return self.get(key)

        def get(self, key, default=None):
            return key + default
        def __iter__(self):
            return iter(['foo'])
        def __len__(self):
            return 1
    global CLIARGS
    CLIARGS = _MockCLIArgs()
    # Test the cliargs_deferred_get function
    clargs_def_get = cliargs_deferred_get('bar')
    assert 'bar' == clargs_def_get()
    clargs_def_get = cliargs_deferred_get('bar', 'baz')
    assert 'barbaz' == clargs_def_get()


# Generated at 2022-06-22 19:44:15.694912
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})

    # Test default value
    f = cliargs_deferred_get('a')
    assert f() is None
    CLIARGS['a'] = 'b'
    assert f() == 'b'
    # Test default value when not present
    f = cliargs_deferred_get('c', 'd')
    assert f() == 'd'
    CLIARGS['c'] = 'e'
    assert f() == 'e'

# Generated at 2022-06-22 19:44:18.618210
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for cliargs_deferred_get"""
    # Can't really unit test this until we've got a way to mock out GlobalCLIArgs
    # (OR we directly use the public API instead of the global)
    pass

# Generated at 2022-06-22 19:44:28.791064
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-22 19:44:35.476797
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    key = 'key'
    default = 'default'
    val = 'val'

    # test default
    __args = {}
    _init_global_context(__args)
    assert cliargs_deferred_get(key, default) == default

    # test get
    __args = {key: val}
    _init_global_context(__args)
    assert cliargs_deferred_get(key, default) == val

# Generated at 2022-06-22 19:44:41.987542
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    global CLIARGS
    cliargs = CLIArgs({'foo': b'bar'})
    CLIARGS = cliargs
    assert cliargs_deferred_get('foo', 'other')() == b'bar'
    assert cliargs_deferred_get('does_not_exist', 'other')() == 'other'
    assert cliargs_deferred_get('foo', 'other', shallowcopy=True)() == b'bar'
    assert cliargs_deferred_get('does_not_exist', 'other', shallowcopy=True)() == 'other'
    test_v = {'a': b'1', 'b': b'2'}
    assert cliargs_deferred_get('foo', test_v, shallowcopy=True)()

# Generated at 2022-06-22 19:44:51.624999
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    FROM_OPTIONS = GlobalCLIArgs.from_options(
        {'hostfile': '/tmp/hosts', 'host_key_checking': True, 'hello': ['world', 'bob']})
    # Build the closure with different inputs and make sure it returns the proper value
    closure = cliargs_deferred_get('host_key_checking', shallowcopy=True)
    assert closure() == True
    closure = cliargs_deferred_get('host_key_checking', shallowcopy=False)
    assert closure() == True
    closure = cliargs_deferred_get('hostfile', shallowcopy=True)
    assert closure() == '/tmp/hosts'
    closure = cliargs_deferred_get('hello', shallowcopy=True)
    assert closure() == ['world', 'bob']
    closure = cl

# Generated at 2022-06-22 19:45:02.820594
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({"foo": "bar", "baz": ["a","b","c"]})
    assert cliargs_deferred_get('foo', default=None)() == 'bar'
    assert cliargs_deferred_get('foo', default='xyz')() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['a','b','c']
    assert cliargs_deferred_get('baz', default=None, shallowcopy=True)() == ['a','b','c']
    assert cliargs_deferred_get('baz', default=None)() == ['a','b','c']
    assert cliargs_deferred_get('xyz', default=None)() == None
    assert cliargs_def

# Generated at 2022-06-22 19:45:10.878521
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """ Unit tests for the cliargs_deferred_get function

    This is not a real unit test, but is instead a test of the function
    argument when doing coverage of the ``ansible/modules/utilities``
    directory.  This file is not imported in the normal execution of ansible.

    It would be better to put this function in a test_utils location
    but it cannot be in the same utils file that it is defined in
    so it is here
    """
    global CLIARGS
    cli_args = dict(hello=dict(world='howdy'), test=dict(foo='bar', baz=dict(hello='world')))
    _init_global_context(cli_args)
    assert cliargs_deferred_get('hello')() == {'world': 'howdy'}
    assert cliargs_deferred

# Generated at 2022-06-22 19:45:18.271513
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import types
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    def test_tuple(tuple_val):
        ansible_args = {'foobar': tuple_val}
        _init_global_context(ansible_args)
        cliargs_inner = cliargs_deferred_get('foobar')

        assert isinstance(cliargs_inner, types.FunctionType)
        assert cliargs_inner() == tuple_val
        assert not (cliargs_inner() is tuple_val)

    test_tuple(())
    test_tuple((1, 2, 3))
    test_tuple(('s', 'p', 'a', 'm'))


# Generated at 2022-06-22 19:45:26.906110
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import UserDict
    from ansible.module_utils.common.text.formatters import slugify

    # Basic dictionary values
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'

    # Default is applied if not present
    assert cliargs_deferred_get('empty', 'default')() == 'default'

    # Cloning
    cli_args = {'foo': [1, 2, 3],
                'bar': {'one': 1, 'two': 2},
                'baz': UserDict({'three': 3, 'four': 4}),
                'qux': {1, 2, 3}}
    _

# Generated at 2022-06-22 19:45:37.767525
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Sanity check for ``cliargs_deferred_get``"""
    args = CLIArgs({})
    args['key1'] = None
    args['key2'] = 'value2'
    args['key3'] = 'value3'
    args['key4'] = ['a', 'b', 'c']
    args['key5'] = ['a', 'b', 'c']
    args['key6'] = {'a': 1, 'b': 2}
    args['key7'] = {'a': 1, 'b': 2}

    getter = cliargs_deferred_get('key1')
    assert getter() is None

    getter = cliargs_deferred_get('key2')
    assert getter() == 'value2'

    getter = cliargs_deferred_get('key3')

# Generated at 2022-06-22 19:45:47.331209
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    import pytest
    from ansible.utils.context_objects import CLIArgs

    def do_test(original_dict, key, default, shallowcopy):
        """Helper for testing cliargs_deferred_get for simple values

        :arg original_dict: Dict that CLIARGS was initialized with.  This is used for
            reproducing the code in cliargs_deferred_get
        :kwarg key: Key to fetch from ``CLIARGS``
        :kwarg default: Default value to use if ``key`` is not in ``CLIARGS``.  This is used
        :kwarg shallowcopy: Whether or not to make a shallow copy of the fetched value.  This
            is used for reproducing the code in cliargs_deferred_get
        """
        global CLI

# Generated at 2022-06-22 19:45:52.257227
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get

    Includes testing a function that returns a closure
    """
    # If it's not a singleton then we can test it.  So create a new object
    global CLIARGS
    CLIARGS = CLIArgs({'a': 'b'})

    # Use cliargs_deferred_get
    get_a = cliargs_deferred_get('a')
    assert get_a() == 'b'

    # Use cliargs_deferred_get with a default
    get_b = cliargs_deferred_get('b', 'c')
    assert get_b() == 'c'

    # Test copy functionality
    get_a = cliargs_deferred_get('a', shallowcopy=True)
    assert get_a() == 'b'
    CLI

# Generated at 2022-06-22 19:46:02.073904
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test default value
    GLOBAL_ARGS = CLIArgs({'key1': 'value1', 'key2': 'value2'})
    global CLIARGS
    CLIARGS = GLOBAL_ARGS
    assert 'value1' == cliargs_deferred_get('key1')()
    assert 'value2' == cliargs_deferred_get('key2')()
    assert 'default' == cliargs_deferred_get('key3')()
    assert 'default' == cliargs_deferred_get('key3', 'default')()
    assert 100 == cliargs_deferred_get('key4', 100)()
    assert 100 == cliargs_deferred_get('key4', 100, False)()

    # Test no shallowcopy
    list_value = [1,2,3]

# Generated at 2022-06-22 19:46:10.946156
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({
        'inventory_manager': 'fake_im',
        'var_manager': 'fake_vm',
        'loader': 'fake_ld',
        'ssh_args': 'fake_sa',
        'colors': 'fake_cl',
    })

    cliargs = cliargs_deferred_get

    assert cliargs('') == 'fake_im'
    assert cliargs('', default='2') == 'fake_im'
    assert cliargs('', default='2', shallowcopy=True) == 'fake_im'

    assert cliargs('inventory_manager', default='2') == 'fake_im'
    assert cliargs('inventory_manager', default='2', shallowcopy=True) == 'fake_im'


# Generated at 2022-06-22 19:46:21.612547
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_func(arg):
        pass

    # Test calling a function with no args
    cliargs_deferred_get('no_arg_key')()

    # Test getting a key that exists
    CLIARGS['key_exists'] = 'value'
    assert cliargs_deferred_get('key_exists')() == 'value'

    # Test getting a key that exists with a default
    assert cliargs_deferred_get('key_exists', default='default')() == 'value'

    # Test getting a key that does not exist with a default
    assert cliargs_deferred_get('key_does_not_exist', default='default')() == 'default'

    # Test calling a function with an argument and a keyword argument

# Generated at 2022-06-22 19:46:32.848466
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Empty dict simulates CLIARGS not being populated
    # Set it to that
    args = {}
    _init_global_context(args)

    # No argument, no shallowcopy
    # no key, no cliargs
    assert cliargs_deferred_get('something')() is None

    # no key, but cliargs is set
    args['something'] = 'else'
    _init_global_context(args)
    assert cliargs_deferred_get('something')() == 'else'

    # key, no cliargs
    assert cliargs_deferred_get('something', default='default')() == 'default'

    # key, cliargs
    args['something'] = 'else'
    _init_global_context(args)

# Generated at 2022-06-22 19:46:36.092495
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo')('bar') == 'bar'
    _init_global_context(dict(foo='bar'))
    assert CLIARGS.get('foo') == 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

# Generated at 2022-06-22 19:46:40.919743
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # TODO: This test is too slow to run in unit test: sphinx-build -b doctest needs refactoring
    #       to be much faster
    import pytest
    pytest.importorskip('docutils')
    import doctest
    import ansible.context
    doctest.testmod(ansible.context, raise_on_error=True)

# Generated at 2022-06-22 19:46:51.521542
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # Set up a fake CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    # Test default is None and shallowcopy is False
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    # Test default is 'bar' and shallowcopy is False
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    assert cliargs_deferred_get('bar', 'bar')() == 'bar'
    # Test default is None and shallowcopy is True
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

# Generated at 2022-06-22 19:47:00.354661
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import unittest
    class CliArgsDeferredGetTestCase(unittest.TestCase):
        def test_no_shallow_copy(self):
            # To test no shallow copy we'll use the default value
            default_value = [1, 2, 3]
            deferred_get = cliargs_deferred_get('no such key', default=default_value)
            retrieved_value = deferred_get()
            assert retrieved_value is default_value

        def test_shallow_copy_list(self):
            value = [1, 2, 3]
            deferred_get = cliargs_deferred_get('no such key', default=value, shallowcopy=True)
            retrieved_value = deferred_get()
            assert retrieved_value is not value
            assert retrieved_value == value
            assert id(value) != id

# Generated at 2022-06-22 19:47:11.911769
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for cliargs_deferred_get
    """
    global CLIARGS
    CLIARGS = CLIArgs(dict(a=1, b=2, c=3))
    args = cliargs_deferred_get
    assert args('a')() == 1
    assert args('b')() == 2
    assert args('c')() == 3
    assert args('d')() is None
    assert args('e', 3)() == 3
    CLIARGS = CLIArgs(dict(a=4, b=5, c=6))
    assert args('a')() == 4
    assert args('b')() == 5
    assert args('c')() == 6
    assert args('d', 7)() == 7
    assert args('e', 3)() == 3

# Generated at 2022-06-22 19:47:20.359432
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    def get_value(key, default, shallowcopy):
        return CLIARGS.get(key, default=default)

    CLIARGS = {'foo': ['foo1', 'foo2']}
    assert cliargs_deferred_get('foo')().copy() == get_value('foo', None, True)
    assert cliargs_deferred_get('foo', shallowcopy=True)() == get_value('foo', None, True)

    CLIARGS = {'foo': ['foo1', 'foo2']}
    assert cliargs_deferred_get('bar')().copy() == get_value('bar', None, True)
    assert cliargs_deferred_get('bar', shallowcopy=True)() == get

# Generated at 2022-06-22 19:47:30.743199
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Unit test for function cliargs_deferred_get
    """
    from ansible.utils.context_objects import GlobalCLIArgs

# Generated at 2022-06-22 19:47:40.115403
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Using a closure instead of a global so that there's only one set of tests
    # instead of having to have separate ``test_global_cliargs`` and ``test_cliargs``
    # test cases.
    CLIARGS = CLIArgs({'foo': True, 'bar': ['baz', 'qux']})

    assert cliargs_deferred_get('foo')()
    assert cliargs_deferred_get('bar')() == ['baz', 'qux']
    assert cliargs_deferred_get('bar', shallowcopy=True)() == ['baz', 'qux']
    assert cliargs_deferred_get('baz', 'notfound')() == 'notfound'


# Generated at 2022-06-22 19:47:49.729152
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for cliargs_deferred_get"""
    cliargs = [
        'ansible', 'localhost',
        '-i', 'hosts',
        '-a', '"foo"',
        '-m', 'debug',
        '--foo-bar', '"arg1"',
    ]
    _init_global_context(cliargs)

    # we get a function that returns the value we wanted
    assert callable(cliargs_deferred_get('inventory'))
    assert cliargs_deferred_get('inventory')() == 'hosts'
    # it returns a copy
    val = cliargs_deferred_get('inventory', shallowcopy=True)()
    val.append('localhost')
    assert cliargs_deferred_get('inventory')() == ['hosts']

    # when the

# Generated at 2022-06-22 19:48:00.042633
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS.clear()

    # First run without setting CLIARGS
    assert cliargs_deferred_get("test_key")() == None
    assert cliargs_deferred_get("test_key", "test_default")() == "test_default"
    assert cliargs_deferred_get("test_key", default=None, shallowcopy=True)() == None
    assert cliargs_deferred_get("test_key", "test_default", shallowcopy=True)() == "test_default"

    # Now set CLIARGS
    CLIARGS.update({"test_key": "test_value"})
    assert cliargs_deferred_get("test_key")() == "test_value"

# Generated at 2022-06-22 19:48:07.741320
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})

    def test(default_value, key_value=None, shallowcopy=False):
        if key_value is None:
            key_value = default_value

        helper = cliargs_deferred_get('KEY', default_value, shallowcopy)
        CLIARGS['KEY'] = key_value
        return helper()

    # Test defaults
    assert test(1) == 1
    assert test(1, 2) == 2

    # Test shallow copy
    assert test([1], [1, 2], True) == [1]
    assert test([1], [1, 2], False) == [1, 2]
    assert test({1: 2}, {1: 2, 3: 4}, True) == {1: 2}

# Generated at 2022-06-22 19:48:15.422778
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Create empty global context to test with
    class Args(dict):
        """Pretend to be a namespace"""
        def __getattr__(self, key):
            return self[key]

    CLIARGS = CLIArgs(Args({}))

    assert cliargs_deferred_get('doesntexist') == None

    CLIARGS.args.a_key = 'a_value'
    assert cliargs_deferred_get('a_key') == 'a_value'

    class AClass:
        pass
    a_obj = AClass()
    CLIARGS.args.a_key = a_obj

    # Do not shallow copy
    assert cliargs_deferred_get('a_key', shallowcopy=False) is a_obj

    # Test shallow copy
    assert cli

# Generated at 2022-06-22 19:48:23.473352
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(foo=dict(key='value')))
    simple_value = cliargs_deferred_get('foo')()
    assert simple_value == CLIARGS['foo']

    simple_value = cliargs_deferred_get('foo', default=dict())()
    assert simple_value == dict()

    deep_value = cliargs_deferred_get('foo', shallowcopy=True)()
    assert deep_value == CLIARGS['foo']
    assert deep_value is not CLIARGS['foo']

    shallow_value = cliargs_deferred_get('foo', shallowcopy=True)()
    assert shallow_value == CLIARGS['foo']
    assert shallow_value['key'] is CLIARGS['foo']['key']


# Generated at 2022-06-22 19:48:33.838969
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': [0, 1, 2], 'b': {'c': 'd'}, 'c': set([1, 2])})
    assert cliargs_deferred_get('a')() == [0, 1, 2]
    assert cliargs_deferred_get('a', shallowcopy=True)() == [0, 1, 2]
    assert cliargs_deferred_get('b')() == {'c': 'd'}
    assert cliargs_deferred_get('b', shallowcopy=True)() == {'c': 'd'}
    assert cliargs_deferred_get('c')() == set([1, 2])
    assert cliargs_deferred_get('c', shallowcopy=True)() == set([1, 2])



# Generated at 2022-06-22 19:48:41.028254
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    assert cliargs_deferred_get("does_not_exist")() is None
    assert cliargs_deferred_get("does_not_exist", default=42)() == 42

    CLIARGS = CLIArgs({'does_not_exist': 42})

    assert cliargs_deferred_get("does_not_exist")() == 42
    assert cliargs_deferred_get("does_not_exist", default=1)() == 42
    assert cliargs_deferred_get("does_not_exist", shallowcopy=True)() == 42
    assert cliargs_deferred_get("does_not_exist", shallowcopy=True, default=1)() == 42

    # Make sure we can set a list and get a copy of it

# Generated at 2022-06-22 19:48:50.823968
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({
        'str': 'str',
        'list': ['list', 'list'],
        'tuple': tuple(('tuple', 'tuple')),
        'dict': dict((('dict', 'dict'), )),
        'set': set(('set', 'set')),
    })

    value = cliargs_deferred_get('str')
    assert value() is CLIARGS['str']
    value = cliargs_deferred_get('str', shallowcopy=True)
    assert value() is CLIARGS['str']

    value = cliargs_deferred_get('list')
    assert value() is CLIARGS['list']
    value = cliargs_deferred_get('list', shallowcopy=True)
    assert value() is not CLIARGS['list']
    assert value

# Generated at 2022-06-22 19:49:01.652134
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    foo = cliargs_deferred_get('foo', 42)
    assert callable(foo)
    result = foo()
    assert result == 42

    # Test shallow copy of strings
    bar = cliargs_deferred_get('bar', 'foo', shallowcopy=True)
    assert callable(bar)
    result = bar()
    assert result == 'foo'

    # Test shallow copy of lists
    baz = cliargs_deferred_get('baz', [1, 2, 3], shallowcopy=True)
    assert callable(baz)
    result = baz()
    assert result == [1, 2, 3]
    assert id(result) != id([1, 2, 3])

    # Test shallow copy of dicts
    biz = cli

# Generated at 2022-06-22 19:49:12.179596
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    cliargs = CLIArgs({'foo': 'bar'})
    _init_global_context(cliargs)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('bif', 'baz')() == 'baz'

    cliargs = CLIArgs({'foo': 'bar', 'blah': [1, 2, 3]})
    _init_global_context(cliargs)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('blah')() == [1, 2, 3]

# Generated at 2022-06-22 19:49:18.581568
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.clear()
    CLIARGS['a'] = 1
    CLIARGS['b'] = [1, 2, 3]
    CLIARGS['c'] = {'d':1, 'e':2}
    CLIARGS['f'] = {1, 2, 3}

    assert CLIARGS.get('a') == 1
    assert CLIARGS.get('a', shallowcopy=True) == 1

    assert CLIARGS.get('b') == [1, 2, 3]
    assert CLIARGS.get('b', shallowcopy=True) == [1, 2, 3]

    assert CLIARGS.get('c') == {'d':1, 'e':2}
    assert CLIARGS.get('c', shallowcopy=True) == {'d':1, 'e':2}

    assert CLIAR

# Generated at 2022-06-22 19:49:27.567899
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    #pylint: disable=g-long-lambda
    CLIARGS.vars = dict(foo='bar')

    # Test equality
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test default
    assert cliargs_deferred_get('not_foo')() == None
    assert cliargs_deferred_get('not_foo', default='baz')() == 'baz'

    # Test shallow copy
    CLS_SEQ = (1, 2, 3)
    CLS_SET = {1, 2, 3}
    CLS_MAPPING = {'a': 1, 'b': 2}


# Generated at 2022-06-22 19:49:35.176871
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def raise_KeyError(key):
        raise KeyError(key)

    global CLIARGS

# Generated at 2022-06-22 19:49:44.952488
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs

    real_cliargs = CLIARGS
    CLIARGS = GlobalCLIArgs.from_options(
        {'verbosity': 0, 'extra_vars': [], 'connection': 'smart', 'check': False, 'syntax': False, 'diff': False},
        connection_loader=None,
        connection_args=None,
    )

# Generated at 2022-06-22 19:49:56.089366
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def cliargs_set(**kwargs):
        global CLIARGS
        CLIARGS = CLIArgs(kwargs)
    cliargs_set(foo='bar')
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'

    cliargs_set(foo=['bar'])
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', default='baz')() == ['bar']

# Generated at 2022-06-22 19:50:06.332709
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Need to add this to the doctest module so it works in doctest
    import doctest

    def capture_stdout(func, *args, **kwargs):
        # Capture stdout
        # From http://stackoverflow.com/questions/16571150/how-to-capture-stdout-output-from-a-python-function-call
        from cStringIO import StringIO
        import sys
        old_stdout = sys.stdout
        sys.stdout = mystdout = StringIO()
        func(*args, **kwargs)
        sys.stdout = old_stdout
        return mystdout.getvalue()

    CLIARGS.update({'test': 'regular_value'})

    assert cliargs_deferred_get('test')() == 'regular_value'
    # By default it

# Generated at 2022-06-22 19:50:15.224626
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert CLIARGS.get('foo') is None
    assert cliargs_deferred_get('foo')(), None
    CLIARGS['foo'] = 1
    assert cliargs_deferred_get('foo')() == 1
    CLIARGS['foo'] = [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']
    CLIARGS['foo'] = {'foo': 'bar'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'foo': 'bar'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS

# Generated at 2022-06-22 19:50:22.967871
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    global CLIARGS
    args = {'foo': 'bar', 'baz': [1, 2, 3], 'quux': {'fum': 4, 'gork': 5}}
    args_copy = args.copy()
    CLIARGS = GlobalCLIArgs(args_copy)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert CLIARGS.get('foo') == 'bar'
    assert cliargs_deferred_get('not_there')() == None
    assert CLIARGS.get('not_there') == None
    assert cliargs_deferred_get('not_there', default=3)() == 3
    assert CLIARGS.get('not_there', default=3) == 3
    assert cl

# Generated at 2022-06-22 19:50:34.065078
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    def mock_global_cli_args(value):
        global CLIARGS
        CLIARGS = CLIArgs(value)

    def test_success(value, default, shallowcopy, expected_value):
        """Test successful case"""
        mock_global_cli_args(value)
        closure = cliargs_deferred_get('one', default, shallowcopy)
        assert closure() == expected_value

    def test_error(value, default, shallowcopy, ex_type, ex_msg):
        """Test an error case"""
        mock_global_cli_args(value)
        closure = cliargs_deferred_get('one', default, shallowcopy)
        with pytest.raises(ex_type) as exinfo:
            closure()
        assert ex_msg in str(exinfo.value)



# Generated at 2022-06-22 19:50:42.433927
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # ``CLIARGS`` must be set to a ``GlobalCLIArgs`` instance before
    # calling ``cliargs_deferred_get``
    def init_global_context(cli_args):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    # Now test the function return value
    def test_inner(inner):
        init_global_context({})
        assert inner() is None

        init_global_context({'foo': 5})
        assert inner() == 5

        init_global_context({'foo': [1, 2, 3]})
        assert inner() == [1, 2, 3]
        assert inner(shallowcopy=True) == [1, 2, 3]

        init_global_context({'foo': (1, 2, 3)})

# Generated at 2022-06-22 19:50:54.054660
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    import copy


    class FakeCLIArgs(Mapping):
        def __init__(self, values):
            self._values = values
        def __getitem__(self, key):
            return self._values[key]
        def __iter__(self):
            return iter(self._values)
        def __len__(self):
            return len(self._values)
        def get(self, key, default=None):
            return self._values.get(key, default=default)

    global CLIARGS
    orig_cliargs = CLIARGS

# Generated at 2022-06-22 19:51:01.788567
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the inner function directly
    inner = cliargs_deferred_get('foo', 'bar')
    assert inner() == 'bar'
    inner = cliargs_deferred_get('foo', 'bar', shallowcopy=True)
    assert inner() == 'bar'

    # Test the inner function with data
    CLIARGS['foo'] = 'foobar'
    inner = cliargs_deferred_get('foo', 'bar')
    assert inner() == 'foobar'
    inner = cliargs_deferred_get('foo', 'bar', shallowcopy=True)
    assert inner() == 'foobar'

    # Test the inner function with a list
    CLIARGS['foo'] = ['foo', 'bar', 'baz']
    inner = cliargs_deferred_get('foo', 'bar')