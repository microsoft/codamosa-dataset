

# Generated at 2022-06-22 19:41:09.800756
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS['list'] = ['a', 'b', 'c']
    assert cliargs_deferred_get('list')() == ['a', 'b', 'c']
    assert cliargs_deferred_get('list', shallowcopy=True)() == ['a', 'b', 'c']
    CLIARGS['dict'] = {'a': 'b'}
    assert cliargs_deferred_get('dict')() == {'a': 'b'}
    assert cliargs_deferred_get('dict', shallowcopy=True)() == {'a': 'b'}
    CLIARGS['set'] = {'a', 'b', 'c'}
    assert cliargs

# Generated at 2022-06-22 19:41:18.196432
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': [1,2,3], 'bar': {'one': 1, 'two': 2}, 'baz': set([1,2,3])})
    assert cliargs_deferred_get('foo')() == [1,2,3]
    assert cliargs_deferred_get('bar')() == {'one': 1, 'two': 2}
    assert cliargs_deferred_get('baz')() == set([1,2,3])
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('bar', shallowcopy=True)() == {'one': 1, 'two': 2}

# Generated at 2022-06-22 19:41:22.766229
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = dict(
        foo='foo_value',
        bar=dict(
            bar1='bar1_value',
            bar2='bar2_value',
        ),
        baz=['baz1_value', 'baz2_value'],
    )

    _init_global_context(cliargs)

    assert cliargs_deferred_get('foo')() == 'foo_value'
    assert cliargs_deferred_get('foo')() is not cliargs.get('foo')

    assert cliargs_deferred_get('bar')() == {'bar1': 'bar1_value', 'bar2': 'bar2_value'}
    assert cliargs_deferred_get('bar')() is not cliargs.get('bar')

    assert cliargs_deferred_get

# Generated at 2022-06-22 19:41:33.794011
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for ``cliargs_deferred_get``"""
    import ansible.context
    from ansible.context import CLIARGS
    from ansible.context import cliargs_deferred_get
    from collections import namedtuple
    from copy import copy

    Options = namedtuple('Options', ('multiple_values', 'one_value', 'multiple_values_as_dict') )

    CLIARGS.cmdline = Options(
        multiple_values=['foo', 'bar', 'baz'],
        one_value=lambda: 'one_value',
        multiple_values_as_dict=dict(a='b', c=1),
    )

    c = cliargs_deferred_get('multiple_values')
    assert c() == ['foo', 'bar', 'baz']

    del CLIARGS.cmdline

# Generated at 2022-06-22 19:41:44.591515
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with CLIARGS being a CLIArgs object
    CLIARGS.test = 42
    assert cliargs_deferred_get('test')() == 42

    # Test with CLIARGS being a GlobalCLIArgs
    def reset_cliargs():
        global CLIARGS
        CLIARGS = CLIArgs({})
    reset_cliargs()

    def replace_cliargs():
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options({'test': 42})

    assert cliargs_deferred_get('test')() == 42
    reset_cliargs()
    # Call the function without setting the global
    assert cliargs_deferred_get('test', default='NOT_HERE')() == 'NOT_HERE'

    replace_cliargs()

# Generated at 2022-06-22 19:41:54.696917
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence

    cli_args = dict(
        list=[1, 2, 3],
        dict=dict(a='A', b='B', c='C'),
        set=set(['A', 'B', 'C']),
        str='str',
        int=1,
        bool=True,
    )
    _init_global_context(cli_args)
    import copy

    # copied list
    raw = cliargs_deferred_get('list')()
    assert raw == cli_args['list']
    assert raw is not cli_args['list']
    assert is_sequence(raw)

    # copied dict
    raw = cliargs_deferred_get('dict')()
    assert raw == cli_args['dict']

# Generated at 2022-06-22 19:42:04.943066
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'existing_key': 'existing_value', 'empty_value': [], 'normal_value': [1, 2, 3]})

    def_get = cliargs_deferred_get('existing_key')
    assert CLIARGS['existing_key'] == 'existing_value'
    assert def_get() == 'existing_value'

    def_get = cliargs_deferred_get('nonexistent_key')
    assert def_get() is None

    def_get = cliargs_deferred_get('nonexistent_key', 'default_value')
    assert def_get() == 'default_value'

    def_get = cliargs_deferred_get('empty_value')
    assert def_get() == []

    def_get = cliargs

# Generated at 2022-06-22 19:42:15.410477
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Check that the function signature is correct
    def dummy():
        return cliargs_deferred_get('test_key')

    dummy()

    # test the non-shallow copy case
    @cliargs_deferred_get('test_key')
    def dummy():
        return

    CLIARGS.test_key = 'foo'
    dummy()
    assert CLIARGS.test_key == 'foo'

    # test the shallow copy case
    @cliargs_deferred_get('test_key', shallowcopy=True)
    def dummy():
        return

    CLIARGS.test_key = 'foo'
    dummy()
    assert CLIARGS.test_key == 'foo'

    # test the default value case

# Generated at 2022-06-22 19:42:21.634694
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import MutableSequence, MutableMapping, MutableSet
    from ansible.module_utils.common.json_params import _FieldAttribute

    from copy import copy, deepcopy
    import pytest

    val = list(range(10))
    mut_val = MutableSequence(val)
    attr = _FieldAttribute(None, cliargs_deferred_get('non_existant', val, shallowcopy=False))

    cliargs_copy = copy(CLIARGS)
    cliargs_deepcopy = deepcopy(CLIARGS)
    CLIARGS['non_existant'] = mut_val
    assert attr.default == val
    assert attr.default is not val

# Generated at 2022-06-22 19:42:30.233976
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_val = 'value'
    def test_func_callback(key, default=None, shallowcopy=False):
        return cliargs_deferred_get(key=key, default=default, shallowcopy=shallowcopy)

    cli_args = {'get_key': test_val}
    _init_global_context(cli_args)
    assert test_val == test_func_callback('get_key')
    assert test_func_callback('set_key', 'default_value') == 'default_value'
    assert test_func_callback('missing_key') is None
    assert test_func_callback('missing_key', default='default_value') == 'default_value'
    assert test_func_callback('get_key', shallowcopy=True) == test_val

# Generated at 2022-06-22 19:42:37.341076
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({'a': 'b'})
    assert cliargs_deferred_get('foo')() == None
    assert cliargs_deferred_get('foo', default='qux')() == 'qux'
    CLIARGS = CLIArgs({'a': 'b'})
    assert cliargs_deferred_get('foo', default=['1', '2'], shallowcopy=True)() == ['1', '2']
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default=['1', '2'], shallowcopy=False)() == ['1', '2']

# Generated at 2022-06-22 19:42:45.709248
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get() returns correct value"""
    global CLIARGS
    CLIARGS = CLIArgs({'key': 0, 'key_def': 5})
    assert cliargs_deferred_get('key')() == 0
    assert cliargs_deferred_get('key_def', default=-1)() == 5
    assert cliargs_deferred_get('key_none', default=-1)() == -1
    assert cliargs_deferred_get('key_shallow', default=[1, 2], shallowcopy=True)() == [1, 2]
    assert cliargs_deferred_get('key', shallowcopy=True)() == 0

# Generated at 2022-06-22 19:42:57.317685
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test simple cases
    def test_lazy_get(key, expected_value, expected_type=None, non_default_value=None, defaults=None):
        if defaults is None:
            defaults = {}
        class Defaults(object):
            pass
        defaults = Defaults()
        setattr(defaults, key, non_default_value)
        getter = cliargs_deferred_get(key, getattr(defaults, key))
        assert getter() == expected_value
        if expected_type:
            assert isinstance(getter(), expected_type)

    # Test lazy recursion
    def nested_key(keys, value):
        for k in reversed(keys):
            value = {k: value}
        return value

    # Test when value is None

# Generated at 2022-06-22 19:42:58.445450
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(None)

# Generated at 2022-06-22 19:43:04.687371
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_it(args, key, expected_value, shallowcopy=False):
        CLIARGS.update(args)
        assert cliargs_deferred_get(key, shallowcopy=shallowcopy)() == expected_value


    # Test non-existent key matches default
    test_it({}, 'key', 'default_value', 'default_value')
    # Test a simple key

# Generated at 2022-06-22 19:43:15.365426
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': [1,2,3], 'bar': {'bar': 'baz'}})

    # Calling without any arguments defaults to returning CLIARGS
    assert cliargs_deferred_get() == CLIARGS
    assert cliargs_deferred_get('foo') == [1,2,3]
    assert cliargs_deferred_get('bar') == {'bar': 'baz'}

    CLIARGS.foo.append(4)
    assert cliargs_deferred_get('foo') == [1,2,3,4]

    # Make sure shallowcopy does shallow copy
    cli_args_copy = cliargs_deferred_get('foo', shallowcopy=True)

# Generated at 2022-06-22 19:43:22.002746
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import __main__
    __main__.CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}
    assert cliargs

# Generated at 2022-06-22 19:43:31.574036
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Run a unit test on cliargs_deferred_get

    This is more of an integration test than a unit test.
    We're testing that the function actually returns the expected value.
    If this fails then there's a problem with the field attribute or the use of the
    function.
    """
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    CLIARGS.foo = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    CLIARGS.foo = ['baz']
    assert cliargs_deferred_get('foo', default='bar')() == ['baz']
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == ['baz']


# Generated at 2022-06-22 19:43:39.242470
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({'foo': 'bar'})

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', 'baz')() == 'baz'
    assert cliargs_deferred_get('bar', cliargs_deferred_get('foo'))() == 'bar'

    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('bar', shallowcopy=True)() is None
    assert cliargs_deferred_get('bar', 'baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-22 19:43:44.409845
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test():
        assert cliargs_deferred_get('key')() is None
        CLIARGS['key'] = 'value'
        assert cliargs_deferred_get('key')() == 'value'
        CLIARGS['key'] = ['value']
        assert cliargs_deferred_get('key', shallowcopy=True)() == ['value']
        CLIARGS['key'] = {'value'}
        assert cliargs_deferred_get('key', shallowcopy=True)() == {'value'}

    test()
    CLIARGS.clear()

# Generated at 2022-06-22 19:43:51.379570
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = CLIArgs({'ansible_foo': 'bar'})
    getter = cliargs_deferred_get('ansible_foo')

    # set the new singleton
    global CLIARGS
    old_args = CLIARGS
    CLIARGS = args

    try:
        assert getter() == 'bar'
    finally:
        CLIARGS = old_args
        assert CLIARGS.get('ansible_foo') is None

# Generated at 2022-06-22 19:43:57.947171
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = {'bar': 'baz'}
    assert cliargs_deferred_get('foo', default={})['bar'] == 'baz'
    assert cliargs_deferred_get('foo', default={}, shallowcopy=True) is CLIARGS['foo']
    assert cliargs_deferred_get('foo', shallowcopy=True) is CLIARGS['foo']

# Generated at 2022-06-22 19:44:07.703208
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Make sure deferred getter works"""
    val = {'a': [1, 2, 3],
           'b': {'a': 1},
           'c': 'a',
           }
    class t(object): pass
    o = t()
    for i in val:
        # Sanity check for value
        assert CLIARGS.get(i) is None
        setattr(o, i, cliargs_deferred_get(i))
        assert getattr(o, i)() is None

    _init_global_context(val)
    for i in val:
        assert CLIARGS.get(i) == val[i]
        assert getattr(o, i)() == val[i]

        setattr(o, i, cliargs_deferred_get(i, default=[]))
        assert get

# Generated at 2022-06-22 19:44:17.915689
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import unittest
    import mock

    class TestCliArgsDeferredGet(unittest.TestCase):
        def setUp(self):
            super(TestCliArgsDeferredGet, self).setUp()
            self.cli_args = {'ask_pass': False}
            CLIARGS = CLIArgs(self.cli_args)

        def tearDown(self):
            super(TestCliArgsDeferredGet, self).tearDown()
            del self.cli_args
            del CLIARGS

        def test_get(self):
            expected = False
            actual = CLIARGS.get('ask_pass')

            self.assertEquals(expected, actual)

            # Assert function found as expected
            expected = False
            actual = cliargs_deferred_get('ask_pass')()


# Generated at 2022-06-22 19:44:28.243074
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get()"""
    cli_args = {
        "defaults_dir": ["dir1"],
        "tree": "dir2",
    }
    _init_global_context(cli_args)
    # Test default
    func = cliargs_deferred_get("no_key")
    assert func() is None

    # Test default with a default value
    func = cliargs_deferred_get("no_key", default=True)
    assert func() is True

    # Test no shallow copy
    func = cliargs_deferred_get("defaults_dir")
    assert func() == ["dir1"]

    # Test shallow copy
    func = cliargs_deferred_get("defaults_dir", shallowcopy=True)
    assert func() == ["dir1"]

# Generated at 2022-06-22 19:44:38.881842
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeCLIArgs(object):
        def __init__(self, bridge_inventory=None, connection=None, private_data_dir=None, verbosity=None):
            self.bridge_inventory = bridge_inventory
            self._connection = connection
            self._private_data_dir = private_data_dir
            self.verbosity = verbosity
        def get(self, key, default=None):
            if key == 'bridge_inventory':
                return self.bridge_inventory
            elif key == 'connection':
                return self._connection
            elif key == 'private_data_dir':
                return self._private_data_dir
            elif key == 'verbosity':
                return self.verbosity


# Generated at 2022-06-22 19:44:49.207208
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # ensure that a default value is returned properly
    CLIARGS.clear()
    inner = cliargs_deferred_get('some_key', default="default_value")
    assert(inner() == "default_value")

    # ensure that a value is returned properly
    CLIARGS['some_key'] = 'some_value'
    assert(inner() == 'some_value')

    # ensure that a value is returned properly
    CLIARGS.clear()
    CLIARGS['some_key'] = ['v1', 'v2']
    assert(inner() == ['v1', 'v2'])

    # ensure that a shallow copy is returned properly
    CLIARGS.clear()
    CLIARGS['some_key'] = ['v1', 'v2']

# Generated at 2022-06-22 19:44:53.201497
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    new_cliargs = CLIArgs({'foo': {'bar': {'baz': 'quux'}}})
    global CLIARGS
    old_cliargs = CLIARGS
    CLIARGS = new_cliargs
    test1 = cliargs_deferred_get('foo')
    test2 = cliargs_deferred_get('foo', shallowcopy=True)
    assert test1() is not test2()
    CLIARGS = old_cliargs

# Generated at 2022-06-22 19:45:04.069612
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy

    class Class:
        a_string = 'hi'
        an_int = 1
        a_list = [1, 2, 3]
        a_dict = {'a': 6, 'b': 7}

        from ansible.module_utils.common.collections import ImmutableType, ImmutableDict, ImmutableSequence, ImmutableSet
        an_immutable_dict = ImmutableDict({'a': 8, 'b': 9})
        an_immutable_sequence = ImmutableSequence([4, 5, 6])
        an_immutable_set = ImmutableSet({7, 8, 9})

        an_immutable_type = ImmutableType(45)

    class SubClass(Class):
        an_int = 2


# Generated at 2022-06-22 19:45:10.822552
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(v2_playbook=True))
    assert cliargs_deferred_get('v2_playbook')() is True
    _init_global_context(dict(v2_playbook=False))
    assert cliargs_deferred_get('v2_playbook')() is False
    _init_global_context(dict(tags=['red']))
    assert cliargs_deferred_get('tags')() == ['red']
    _init_global_context(dict(tags=['red']))
    assert cliargs_deferred_get('tags', shallowcopy=True)() == ['red']



# Generated at 2022-06-22 19:45:13.055796
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('--help')() == False
    assert cliargs_deferred_get('--other_arg', default='hello')() == 'hello'

# Generated at 2022-06-22 19:45:24.145404
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''
    Tests that ``cliargs_deferred_get`` returns the correct values and that the
    CLIARGS are copied if the ``shallowcopy`` keyword argument is True
    '''

    def check_deferred_get(expected):
        assert expected == cliargs_deferred_get('check')(),\
            'unexpected value returned by cliargs_deferred_get, expected {}, got {}'.format(
                expected, cliargs_deferred_get('check')()
            )

    args = {
        'check': 'deferred',
        'list_check': ['deferred']
    }

    _init_global_context(args)
    check_deferred_get(args['check'])
    check_deferred_get(args['list_check'])

    args['list_check'].append

# Generated at 2022-06-22 19:45:30.476294
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import AttributeDict

    new_cliargs = CLIArgs({"foo": 1, "bar": {"baz": 100}})
    global CLIARGS
    old_cliargs = CLIARGS
    CLIARGS = new_cliargs


# Generated at 2022-06-22 19:45:41.091553
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    key = 'test_key'
    default = 'default_value'
    cli_args = {}
    _init_global_context(cli_args)
    assert cliargs_deferred_get(key) == default
    cli_args[key] = 'cli_value'
    _init_global_context(cli_args)
    assert cliargs_deferred_get(key) == 'cli_value'
    cliargs_deferred_get(key, shallowcopy=True) == 'cli_value'
    cli_args[key] = ['a', 'b']
    _init_global_context(cli_args)
    assert cliargs_deferred_get(key, shallowcopy=True) == ['a', 'b']

# Generated at 2022-06-22 19:45:51.183812
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the closure returned from cliargs_deferred_get

    This is a unit test of a function that is typically used in a context
    where we can't use the standard unit test fixtures and infrastructure so
    this test is in this file as well.
    """
    global CLIARGS
    CLIARGS = GlobalCLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    CLIARGS = GlobalCLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']

    CLIARGS = GlobalCLIArgs({'foo': {'bar': 1}})

# Generated at 2022-06-22 19:46:01.537758
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('a')() is None

    CLIARGS = CLIArgs({'a': 1, 'b': dict(c=2)})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')()['c'] == 2
    assert cliargs_deferred_get('b')() is not CLIARGS.get('b', default=None)
    assert cliargs_deferred_get('b', shallowcopy=True)() is not CLIARGS.get('b', default=None)
    assert cliargs_deferred_get('b', shallowcopy=True)()['c'] == 2

# Generated at 2022-06-22 19:46:06.562358
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'int': 0, 'list': [], 'deep_list': [[]]})

    assert cliargs_deferred_get('int')() == 0
    assert cliargs_deferred_get('list')() == []
    assert cliargs_deferred_get('deep_list')() == [[]]

    assert cliargs_deferred_get('int', shallowcopy=True)() == 0
    assert cliargs_deferred_get('list', shallowcopy=True)() == []
    assert cliargs_deferred_get('deep_list', shallowcopy=True)() == [[]]

# Generated at 2022-06-22 19:46:10.009936
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': ['bar']})
    val = cliargs_deferred_get('foo')
    assert val() == ['bar']
    val = cliargs_deferred_get('baz', default=42)
    assert val() == 42

# Generated at 2022-06-22 19:46:21.277822
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that a cliargs_deferred_get closure is the same as a direct cli_args.get"""
    # pylint: disable=redefined-outer-name, unused-argument
    def test_func(key, default=None, shallowcopy=False):
        return cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import binary_type, string_types
    def assert_test_fails(key, default=None, shallowcopy=False):
        """Assert that getting a key raises an exception for the test"""
        get_closure = test_func(key, default=default, shallowcopy=shallowcopy)

# Generated at 2022-06-22 19:46:23.025019
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('this doesnt exist')('should return the default value') == 'should return the default value'

# Generated at 2022-06-22 19:46:33.525881
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def assert_value_eq(key, expected, default=None, shallowcopy=False):
        value_func = cliargs_deferred_get(key, default, shallowcopy)
        assert value_func() == expected

    cli_args = {'the_test': "value-test"}
    # Note: if this is moved to the actual tests, it will fail the other
    # tests.  This is because moving it causes it to be run before
    # _init_global_context is run in the _context tests.  That makes
    # CLIARGS a CLIArgs object instead of a GlobalCLIArgs object and that
    # causes the tests to fail.
    _init_global_context(cli_args)
    assert_value_eq('the_test', "value-test")

# Generated at 2022-06-22 19:46:40.966411
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)
    assert CLIARGS.get('foo') == 'bar'
    assert cli_args_deferred_get('foo')() == 'bar'

    cli_args = {'foo': 'bar', 'lst': [], 'set': set(), 'dict': {}}
    _init_global_context(cli_args)
    assert CLIARGS.get('lst') == []
    assert cli_args_deferred_get('lst')() == []
    assert CLIARGS.get('set') == set()
    assert cli_args_deferred_get('set')() == set()
    assert CLIARGS.get('dict') == {}
    assert cli_args_deferred_get('dict')

# Generated at 2022-06-22 19:46:51.561224
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Normal case for a key that has been set
    global CLIARGS
    CLIARGS = {'foo': 'bar'}
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    # Normal case for a key that has not been set
    assert cliargs_deferred_get('notthere', default='default')() == 'default'
    assert cliargs_deferred_get('notthere', default='default', shallowcopy=True)() == 'default'
    # Normal case for a list that has been set so we get a copy
    CLIARGS = {'foo': ['bar', 'baz']}
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']


# Generated at 2022-06-22 19:47:00.220644
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for :py:func:`ansible.utils.context_objects.cliargs_deferred_get`"""
    import os
    from ansible.module_utils.common.text.converters import to_text


# Generated at 2022-06-22 19:47:11.739529
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from collections import OrderedDict
    from copy import copy
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping

    foo_default = 'foo_default'
    foo_original = 'foo_original'
    bar_default = 'bar_default'
    bar_original = 'bar_original'
    foo_nodefault = 'foo_nodefault'
    bar_nodefault = 'bar_nodefault'

    dict_copy_original = dict(one='one', two='two')
    dict_shallow_original = dict(one='one', two='two')
    list_copy_original = ['one', 'two']


# Generated at 2022-06-22 19:47:20.239330
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = {
        'myattr': [True],
    }

    global CLIARGS
    CLIARGS = CLIArgs(cliargs)

    # test get
    assert cliargs_deferred_get('myattr')() == [True]
    assert cliargs_deferred_get('noattr')() is None
    assert cliargs_deferred_get('noattr', default='yes')() == 'yes'
    assert cliargs_deferred_get('mydict', default={})() == {'mydict': [True]}
    assert cliargs_deferred_get('mydict', default={'hello': 'goodbye'})() == {'mydict': [True], 'hello': 'goodbye'}

    # should not be in cliargs because we are using a shallow copy
    assert cliargs_def

# Generated at 2022-06-22 19:47:24.753971
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestClass(object):
        def __init__(self, string=cliargs_deferred_get('test'), list=cliargs_deferred_get('test_list')):
            self.string = string
            self.list = list

    CLIARGS['test'] = 'Test'
    CLIARGS['test_list'] = ['a', 'b', 'c']
    test_class = TestClass()
    assert test_class.string == 'Test'
    assert test_class.list == ['a', 'b', 'c']

    CLIARGS['test'] = 'Test2'
    CLIARGS['test_list'] = ['a', 'b', 'c', 'd']
    assert test_class.string == 'Test'
    assert test_class.list == ['a', 'b', 'c']

# Generated at 2022-06-22 19:47:34.757472
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''Test cliargs_deferred_get with some basic types'''

    # Default
    assert cliargs_deferred_get('foo')('default') == 'default'

    # Simple
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')('default') == 'bar'

    # List
    CLIARGS['foo'] = ['bar']
    assert cliargs_deferred_get('foo')('default') == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)('default') == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=False)('default') == ['bar']
    CLIARGS['foo'].append('baz')

# Generated at 2022-06-22 19:47:44.041425
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.__setitem__('foo', 'bar')

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar', 'baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('bar', 'baz', shallowcopy=True)() == 'baz'

    CLIARGS.__setitem__('foo', ['bar', 'baz'])

    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']


# Generated at 2022-06-22 19:47:51.223328
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    _init_global_context({})
    assert CLIARGS.get('random') is None
    get_random = cliargs_deferred_get('random')
    assert get_random() is None
    CLIARGS.update({'random': 'foo'})
    assert get_random() == 'foo'
    get_random_copy = cliargs_deferred_get('random', default='bar', shallowcopy=True)
    assert get_random_copy == 'foo'
    CLIARGS.clear()
    assert get_random() is None
    assert get_random_copy == 'bar'
    _init_global_context({'random': 'bar'})
    assert CLIARGS.get('random') == 'bar'
    assert get_random() == 'bar'
    assert get_random_copy

# Generated at 2022-06-22 19:48:02.343495
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_deferred_get(key, default=None, shallowcopy=False, expected=None):
        result = cliargs_deferred_get(key, default, shallowcopy)()
        assert result == expected, "Should have gotten {} from {}. Deferred got {}".format(expected, key, result)

    test_deferred_get('foo', default='bar', expected='bar')
    test_deferred_get('foo', expected=None)
    test_deferred_get('foo', shallowcopy=True, expected=None)

    test_deferred_get('baz', default=['a', 'b'], expected=['a', 'b'])
    test_deferred_get('baz', default=['a', 'b'], shallowcopy=True, expected=['a', 'b'])

    test_deferred_

# Generated at 2022-06-22 19:48:07.087049
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Arrange
    key = "foo"
    default = [1, 2, 3]
    cliargs = {"foo": [4, 5]}
    # Act
    inner = cliargs_deferred_get(key, default)
    # Assert
    assert inner() == cliargs["foo"]

# Generated at 2022-06-22 19:48:17.228598
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSet
    from copy import copy
    from pprint import pformat
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    # Test for the non-shallow copy case
    cli_args = MutableMapping()
    cli_args['test_value'] = 'test_value'
    _init_global_context(cli_args)

    returned_value = cliargs_deferred_get('test_value')()
    assert returned_value == 'test_value'
    assert returned_value is not cli_args['test_value']
    assert returned_value == cli_args['test_value']


# Generated at 2022-06-22 19:48:24.163069
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the non-shallowcopy case
    CLIARGS.update({'test': 'value'})
    assert cliargs_deferred_get('test', shallowcopy=False) == 'value'
    assert cliargs_deferred_get('not_there', default='default', shallowcopy=False) == 'default'
    CLIARGS['test'] = [1, 2, 3]
    assert cliargs_deferred_get('test', shallowcopy=False) is CLIARGS['test']
    CLIARGS['test'] = {'a': 1, 'b': 2}
    assert cliargs_deferred_get('test', shallowcopy=False) is CLIARGS['test']

    # Test the shallowcopy case
    CLIARGS.update({'test': 'value'})
    assert cliargs_deferred_get

# Generated at 2022-06-22 19:48:34.103966
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the defaults
    f = cliargs_deferred_get('foo', default=2)
    assert f() == 2
    # Test a normal value
    CLIARGS = CLIArgs({'foo': 3})
    f = cliargs_deferred_get('foo', default=2)
    assert f() == 3
    # Test that a shallow copy is performed
    CLIARGS = CLIArgs({'foo': [4]})
    f = cliargs_deferred_get('foo', default=2)
    assert f() == [4]
    # Test that a shallow copy *is not* performed
    CLIARGS = CLIArgs({'foo': [4]})
    f = cliargs_deferred_get('foo', shallowcopy=False, default=2)
    assert f() is CLIARGS.get('foo')

# Generated at 2022-06-22 19:48:42.090957
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    if getattr(test_cliargs_deferred_get, '_ran', False):
        return
    setattr(test_cliargs_deferred_get, '_ran', True)

    cliargs = {'foo': 'bar'}
    def _init_global_context(cli_args):
        global CLIARGS
        CLIARGS.merge(cli_args)

    _init_global_context(cliargs)

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

# Generated at 2022-06-22 19:48:51.123749
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class DummyClass(object):
        pass
    my_dummy = DummyClass()
    my_dummy.variable = cliargs_deferred_get('my_key')
    CLIARGS['my_key'] = 'my_value'
    assert my_dummy.variable == 'my_value'
    CLIARGS['my_key'] = 'my_new_value'
    assert my_dummy.variable == 'my_new_value'
    assert my_dummy.variable == 'my_new_value'

    my_dummy.variable = cliargs_deferred_get('my_key_missing', default='my_default')
    assert my_dummy.variable == 'my_default'


# Generated at 2022-06-22 19:49:01.833352
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    _init_global_context(GlobalCLIArgs.from_options({'bar': 'baz'}))
    assert cliargs_deferred_get('bar') == 'baz'
    assert cliargs_deferred_get('foo', 'foo') == 'foo'
    assert cliargs_deferred_get('foo')() == 'foo'
    assert cliargs_deferred_get('bar', shallowcopy=True) == 'baz'
    assert cliargs_deferred_get('bar', shallowcopy=True)() == 'baz'
    try:
        # No
        cliargs_deferred_get('foo', shallowcopy=True)
    except KeyError:
        pass

# Generated at 2022-06-22 19:49:12.167452
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_dict_factory(dict_factory):
        name = 'name'
        value = 'default'
        expect = dict_factory({name: value})
        CLIARGS[name] = expect
        assert cliargs_deferred_get(name)() is expect

        del CLIARGS[name]
        expect = {name: value}
        assert cliargs_deferred_get(name, default={name: value})() == expect
        assert cliargs_deferred_get(name, default={name: value}, shallowcopy=True)() != expect

        CLIARGS[name] = expect
        shallow_expect = cliargs_deferred_get(name, default={name: value}, shallowcopy=True)()
        assert shallow_expect is not expect
        assert shallow_expect == expect

    test

# Generated at 2022-06-22 19:49:21.262274
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get(): # pylint: disable=too-many-branches
    """Unit tests for the cliargs_deferred_get function"""
    # pylint: disable=unused-variable, too-many-function-args, unused-argument
    # pylint: disable=unused-argument,too-many-nested-blocks,unused-local-variable
    # pylint: disable=bad-continuation
    import pytest
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common import remove_values
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    def test_default_func():
        """Get a default from a function"""
        from functools import partial, wraps


# Generated at 2022-06-22 19:49:32.014555
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Make sure the deferred get function works as expected"""

    # Empty cliargs
    _init_global_context(dict())

    # Test no values
    assert cliargs_deferred_get("does_not_exist")() is None
    assert cliargs_deferred_get("does_not_exist", default="default_value")() == "default_value"

    # Test some values.  We can't test all values, but we can test some.
    _init_global_context({"defer_facts": False, "diff": False, "verbosity": 1, "start_at_task": "task3"})
    assert not cliargs_deferred_get("defer_facts")()
    assert not cliargs_deferred_get("diff")()
    assert cliargs_deferred_get("verbosity")

# Generated at 2022-06-22 19:49:43.483465
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    args = dict(a=5, b=5, c=[], d=set(), e={}, f=[1,2,3])
    assert args == dict(CLIARGS)

    assert cliargs_deferred_get('a')() == args.get('a')

    args_copy = args.copy()
    assert cliargs_deferred_get('a', shallowcopy=True)() == args_copy.get('a')

    args_copy = args.copy()
    assert cliargs_deferred_get('a', default=1, shallowcopy=True)() == args_copy.get('a', default=1)

    args_copy = args.copy()
    assert cliargs_deferred_get('b', shallowcopy=True)() == args_copy.get('b')

    args

# Generated at 2022-06-22 19:49:53.881787
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get('foo'))

    assert cliargs_deferred_get('foo')() is None

    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    CLIARGS['foo'] = ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == CLIARGS['foo']

    CLIARGS['foo'] = {'bar': 'baz'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']

# Generated at 2022-06-22 19:50:04.045904
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.data = {'a': 10, 'b': [1, 2, 3], 'c': {}}
    v = cliargs_deferred_get('a')
    assert v() == 10
    assert v() == 10
    CLIARGS['a'] = 20
    assert v() == 20
    assert v() == 20
    w = cliargs_deferred_get('a', default=100)
    assert w() == 20
    assert w() == 20
    CLIARGS['a'] = None
    assert w() == 100
    assert w() == 100
    x = cliargs_deferred_get('d', default=100)
    assert x() == 100
    assert x() == 100
    CLIARGS['d'] = 200
    assert x() == 200
    assert x() == 200
    CLIAR

# Generated at 2022-06-22 19:50:14.265339
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.text.converters import to_native
    test_dict = {'ANSIBLE_MODULE_ARGS': {'key': 'value'}}
    _init_global_context(test_dict)

    assert cliargs_deferred_get('ANSIBLE_MODULE_ARGS')().get('key') == 'value'
    assert cliargs_deferred_get('ANSIBLE_MODULE_ARGS', default=None)().get('key') == 'value'
    assert cliargs_deferred_get('ANSIBLE_MODULE_ARGS', default=None, shallowcopy=True)().get('key') == 'value'

# Generated at 2022-06-22 19:50:22.767726
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-22 19:50:29.258235
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar', 'list': [1, 2, 3]}
    _init_global_context(cli_args)

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('list')() == [1, 2, 3]
    assert cliargs_deferred_get('list', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-22 19:50:39.047689
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'a': 1, 'b': 2})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('a', shallowcopy=False)() == 1
    assert cliargs_deferred_get('b')() == 2
    assert cliargs_deferred_get('b', shallowcopy=True)() == 2
    assert cliargs_deferred_get('b', shallowcopy=False)() == 2

    CLIARGS = CLIArgs({'a': [1, 2, 3], 'b': {1: 'a', 2: 'b'}})

# Generated at 2022-06-22 19:50:47.002118
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-22 19:50:55.324725
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'vars': {'foo': 'bar'}, 'module_name': 'hello', 'module_path': 'foo/bar'})

    def_func = cliargs_deferred_get('vars', default={'foo': 'baz'})
    assert(def_func()['foo'] == 'bar')

    def_func = cliargs_deferred_get('module_name', default='world')
    assert(def_func() == 'hello')

    def_func = cliargs_deferred_get('module_path', default='whizz/bang')
    assert(def_func() == 'foo/bar')

    def_func = cliargs_deferred_get('colors', default='1')
    assert(def_func() == '1')

   

# Generated at 2022-06-22 19:51:06.413712
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIContextObj
    from ansible.utils.context_objects import CLIArgs
    from ansible.module_utils._text import to_text
    import six

    class FakeCLIArgs(CLIArgs):

        def __init__(self, keys):
            super(FakeCLIArgs, self).__init__(keys)

        def __getattr__(self, name):
            if name in self.__dict__:
                return getattr(self, name)
            else:
                if name not in self:
                    raise AttributeError('{0} does not exist in CLIARGS'.format(name))
                return self[name]
