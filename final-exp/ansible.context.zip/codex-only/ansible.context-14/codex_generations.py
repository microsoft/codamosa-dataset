

# Generated at 2022-06-22 19:41:08.313342
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from copy import copy
    from types import SimpleNamespace

    def get_ns():
        return SimpleNamespace(dict_value=dict(a=1, b=2), list_value=[1, 2], set_value=set([1, 2]))

    cli_args = get_ns()
    _init_global_context(cli_args)
    assert CLIARGS.dict_value == cli_args.dict_value
    assert CLIARGS.list_value == cli_args.list_value
    assert CLIARGS.set_value == cli_args.set_value

    cli_args = get_ns()
    _init_global_context(cli_args)
    assert cliargs_deferred_get('dict_value')() == cli_args.dict_value
    assert cliargs_def

# Generated at 2022-06-22 19:41:16.825743
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='foo')() == 'foo'
    CLIARGS = CLIArgs({'foo': 'bar'})
    def foo():
        pass
    assert cliargs_deferred_get('foo', default=foo)() == 'bar'
    assert cliargs_deferred_get('baz', default='foo')() == 'foo'
    CLIARGS = CLIArgs({'foo': ['a', 1, 'b', 2]})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['a', 1, 'b', 2]
    assert cli

# Generated at 2022-06-22 19:41:27.330542
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSet
    import copy
    import uuid
    cli_args = {
        'list_key': ['value1', 'value2', 'value3'],
        'dict_key': {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'},
        'set_key': {'value1', 'value2', 'value3'}
    }
    _init_global_context(cli_args)
    CLIARGS['unique_key'] = unique_value = str(uuid.uuid4())
    assert str(unique_value) == cliargs_deferred_get('unique_key')()
    assert cliargs

# Generated at 2022-06-22 19:41:38.320926
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import types

    closure = cliargs_deferred_get('inventory', default=['host1', 'host2'], shallowcopy=True)
    assert isinstance(closure, types.FunctionType)
    # closure() is a direct reference to the default value so modifying
    # the original should not show up in the default.
    closure()[1] = 'host3'
    assert closure() == ['host1', 'host3'], 'Default value should be copied by value'

    # Just the value, not the list
    closure = cliargs_deferred_get('inventory', default='host1')
    assert isinstance(closure, types.FunctionType)
    closure()[1] = 'host3'
    assert closure() == 'host1', 'Default value should be copied by value'

# Generated at 2022-06-22 19:41:47.542405
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import defaultdict
    from copy import copy

    # Use a List instead of a Set because order is important for testing
    cli_args = {'ANSIBLE_FOO': ['a', 'b'], 'ANSIBLE_BAZ': 'hi', 'ANSIBLE_BAR': defaultdict(int)}
    _init_global_context(cli_args)

    for shallowcopy in (True, False):
        for key, expected_value in cli_args.items():
            # accessing the inner function should return the expected value
            actual_value = cliargs_deferred_get(key, shallowcopy=shallowcopy)()
            assert actual_value == expected_value

            # modifying the return value should not modify the original
            if is_sequence(expected_value):
                actual_

# Generated at 2022-06-22 19:41:50.670540
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    val = 'test_value'
    default = 'default_value'
    cliargs_deferred_get(val, default)() == default

# Generated at 2022-06-22 19:41:58.289203
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=missing-docstring
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    value = cliargs_deferred_get('foo')
    assert value == 'bar'
    # Test that the default value is returned if the option isn't found
    value = cliargs_deferred_get('nope', default='baz')
    assert value == 'baz'
    # Test that the object itself is being returned, not a copy
    lists = [['foo']]
    CLIARGS = CLIArgs({'foo': lists})
    value = cliargs_deferred_get('foo')
    assert value == lists
    assert value is lists
    value = cliargs_deferred_get('foo', shallowcopy=True)
    assert value == lists

# Generated at 2022-06-22 19:42:07.317192
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Test the default functionality
    CLIARGS = CLIArgs({'foo': 'bar'})
    value = cliargs_deferred_get('foo')()
    assert value == 'bar'
    value = cliargs_deferred_get('bar')()
    assert value is None

    # Test that the shallow copy returns the same type
    CLIARGS = CLIArgs({'foo': ('bar', 'baz')})
    value = cliargs_deferred_get('foo', shallowcopy=True)()
    assert value == ('bar', 'baz')
    assert type(value) is tuple
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    value = cliargs_deferred_get('foo', shallowcopy=True)()

# Generated at 2022-06-22 19:42:17.422256
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'this': 'that'})
    assert cliargs_deferred_get('this')() == 'that'
    assert cliargs_deferred_get('this', default='other')() == 'that'
    assert cliargs_deferred_get('notthis', default='other')() == 'other'
    assert 'notthis' not in CLIARGS
    assert cliargs_deferred_get('notthis')() is None


# Load i18n to ensure we have a translations function early
# This needs to be after the CLIARGS global is defined so we can use the _ flag

# Generated at 2022-06-22 19:42:23.202991
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def serialize(obj):
        """Serialize tuple/list/set/dict to string so we can use them elsewhere"""
        if isinstance(obj, tuple):
            return 't' + ''.join(map(serialize, obj))
        elif isinstance(obj, list):
            return '[' + ''.join(map(serialize, obj)) + ']'
        elif isinstance(obj, set):
            return 's{' + ''.join(map(serialize, obj)) + '}'
        elif isinstance(obj, dict):
            return 'd{' + ''.join((k + serialize(v) for k, v in obj.items())) + '}'
        return str(obj)


# Generated at 2022-06-22 19:42:32.389299
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Test that shallow copy works on an empty dict
    CLIARGS = GlobalCLIArgs({})
    assert cliargs_deferred_get('test_key', default={}, shallowcopy=True) == {}
    # Test that non-shallow copy works
    assert cliargs_deferred_get('test_key', default={}) is cliargs_deferred_get('test_key', default={})
    # Test that deepcopy works
    CLIARGS = GlobalCLIArgs({'test_key': {'foo': 'bar'}})
    assert cliargs_deferred_get('test_key', default={}, shallowcopy=False) == {'foo': 'bar'}
    # Test that it also works with lists

# Generated at 2022-06-22 19:42:42.903309
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    CLIARGS.update({'a': 1, 'b': 2, 'c': 3})
    assert cliargs_deferred_get('c')() == 3
    assert cliargs_deferred_get('c', 5)() == 3
    assert cliargs_deferred_get('d', 5)() == 5
    assert cliargs_deferred_get('d', None)() == None
    with pytest.raises(KeyError):
        cliargs_deferred_get('d')()
    # test shallow copy
    CLIARGS.update({'a': [1, 2, 3]})
    assert cliargs_deferred_get('a')() == [1, 2, 3]

# Generated at 2022-06-22 19:42:46.804059
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _test(default=None, shallowcopy=False):
        key = 'foo'
        value = 'bar'
        cli_args = {key: value}
        _init_global_context(cli_args)
        assert cliargs_deferred_get(key)() == value

        if isinstance(default, (Mapping, Set)):
            assert cliargs_deferred_get(key, default={}, shallowcopy=shallowcopy)() != default
            assert cliargs_deferred_get(key, default={}, shallowcopy=shallowcopy)()['bar'] == default['bar']
            assert cliargs_deferred_get(key, default={}, shallowcopy=False)() is default

# Generated at 2022-06-22 19:42:57.928123
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    This test is for the function cliargs_deferred_get. Since cliargs_deferred_get is a
    closure it is not possible to use fixtures
    """
    # pylint: disable=protected-access
    global CLIARGS
    CLIARGS._CLIArgs__args = {'a': 1, 'b': [1, 2]}
    assert cliargs_deferred_get('a')() == 1
    b_copy = cliargs_deferred_get('b', shallowcopy=True)()
    assert b_copy == [1, 2]
    b_copy.append(3)
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    # Ensure that shallow copying does not create a new list
    assert b_copy is cliargs_deferred_

# Generated at 2022-06-22 19:43:04.406632
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_dict = {'foo': 'bar', 'baz': {'spam': 'eggs'}, 'foobar': [1, 2, 3], 'foobarbaz': {1, 2, 3}}

    def test_inner(inner):
        # Verify value is not already set
        assert inner() is None, 'value should not be set until we set options'

        # Now set options
        cli_options = {'foo': 'bar', 'baz': {'spam': 'eggs'}, 'foobar': [1, 2, 3], 'foobarbaz': {1, 2, 3}}
        global CLIARGS
        CLIARGS = CLIArgs(cli_options)

        # Now verify value is set
        assert inner() == 'bar', 'value should be set to what we set options to'

    # Test non-

# Generated at 2022-06-22 19:43:15.051949
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with a default value
    default_value = object()
    f = cliargs_deferred_get('foo', default_value)

    # First check that we return the default value if CLIARGS is empty
    CLIARGS.clear()
    assert f() == default_value

    # Then check that we return the value if it is in the dict
    CLIARGS['foo'] = 'bar'
    assert f() == 'bar'

    # Test with no default value
    f = cliargs_deferred_get('foo', default=None)

    # First check that we return the default value if CLIARGS is empty
    CLIARGS.clear()
    assert f() is None

    # Then check that we return the value if it is in the dict
    CLIARGS['foo'] = 'bar'

# Generated at 2022-06-22 19:43:20.519375
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({"a": "aval", "b": "bval"})
    default_value = cliargs_deferred_get("c", default="cval")
    assert default_value() == "cval"
    assert cliargs_deferred_get("a", shallowcopy=True)() == "aval"
    assert cliargs_deferred_get("b")() == "bval"


# This is a temporary mechanism to allow some code to defer importing until after the cli_args
# have been initialized

# Generated at 2022-06-22 19:43:24.159469
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})

    def inner():
        return cliargs_deferred_get('foo')

    assert inner() == 'bar'

# Generated at 2022-06-22 19:43:33.420612
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'bool_opt': True,
                'int_opt': 3,
                'float_opt': 4.6,
                'list_opt': [1, '2', 3],
                'set_opt': {'a', 'b'},
                'dict_opt': {'a': 'vector', 'b': 'scalar'},
               }

    _init_global_context(cli_args)
    # Test with a value that is there
    assert cliargs_deferred_get('bool_opt')(), "Should get a value"
    assert cliargs_deferred_get('bool_opt', default=False)(), "Should get a value"
    assert cliargs_deferred_get('bool_opt', default='this should not be hit')(), \
        "Should get a value"

# Generated at 2022-06-22 19:43:43.814991
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # test for missing key
    assert cliargs_deferred_get('testkey', default='testdefault') == 'testdefault'
    assert cliargs_deferred_get('testkey', default='testdefault', shallowcopy=True) == 'testdefault'

    # test for key in CLIARGS
    CLIARGS = CLIArgs({'testkey': 'testvalue'})

    # default is ignored
    assert cliargs_deferred_get('testkey', default='testdefault') == 'testvalue'
    assert cliargs_deferred_get('testkey', default='testdefault', shallowcopy=True) == 'testvalue'

    # test for shallowcopy
    assert cliargs_deferred_get('testkey', shallowcopy=True) == 'testvalue'

# Generated at 2022-06-22 19:43:53.839302
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test1': 'test1', 'test2': 'test2', 'test3': 'test3', 'test4': 'test4'})
    closure = cliargs_deferred_get('test1')
    assert closure() == 'test1'

    closure = cliargs_deferred_get('test1', default='test')
    assert closure() == 'test1'
    closure = cliargs_deferred_get('not_there', default='test')
    assert closure() == 'test'
    closure = cliargs_deferred_get('not_there', default='test', shallowcopy=True)
    assert closure() == 'test'

# Generated at 2022-06-22 19:44:03.706633
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import OrderedDict, MutableSet

    cli_args = {'a': 'A', 'b': [1, 2, 3], 'c': 'C', 'd': MutableSet([4, 5, 6]), 'e': OrderedDict((('key1', 'val1'), ('key2', 'val2'), ('key3', 'val3'))), 'f': 'F'}
    _init_global_context(cli_args)

    key = 'a'
    default = None
    value = cliargs_deferred_get(key, default)()
    assert value == 'A'

    key = 'b'
    default = None
    value = cliargs_deferred_get(key, default)()

# Generated at 2022-06-22 19:44:15.044553
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = GlobalCLIArgs({'foo': ['foo'], 'bar': {'a': 1}, 'baz': {1, 2}, 'qux': None})

    key = 'foo'
    assert cliargs_deferred_get('foo')() == CLIARGS[key]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == CLIARGS[key]

    key = 'bar'
    assert cliargs_deferred_get('bar')() == CLIARGS[key]
    oldbar = CLIARGS[key]
    newbar = cliargs_deferred_get('bar', shallowcopy=True)()
    assert newbar == CLIARGS[key] and oldbar is not newbar

    key = 'baz'
    assert cliargs_

# Generated at 2022-06-22 19:44:24.578095
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # these tests rely on directly accessing the internals of CLIARGS rather than the public
    # interfaces

    # test with a non-copyable value
    CLIARGS._options['foo'] = [1, 2, 3]
    assert cliargs_deferred_get('foo')() is CLIARGS._options['foo']

    # test with a non-copyable value, shallow copy
    CLIARGS._options['bar'] = [1, 2, 3]
    assert cliargs_deferred_get('bar', shallowcopy=True)() != CLIARGS._options['bar']
    assert cliargs_deferred_get('bar', shallowcopy=True)() == CLIARGS._options['bar']

    # test with a copyable value

# Generated at 2022-06-22 19:44:29.347959
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Initialize the global context
    _init_global_context({})
    getter = cliargs_deferred_get('something_that_does_not_exist')
    assert getter() is None

    getter = cliargs_deferred_get('something_that_does_not_exist', default='abc')
    assert getter() == 'abc'

# Generated at 2022-06-22 19:44:39.359570
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that deferred get works as expected with various types"""
    def set_global_args(args):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(args)

    set_global_args({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default=[])() == []
    assert cliargs_deferred_get('foo', default=[], shallowcopy=True)() == []

    set_global_args(dict(foo='bar', baz=dict(quux='qux')))

# Generated at 2022-06-22 19:44:49.714708
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CliArgs(object):
        """Emulate CliArgs object"""
        def __getitem__(self, key):
            return self.store[key]

        def __init__(self, store):
            self.store = store

    def check_get(key, store, expected, shallowcopy=False):
        """Helper function to unit test cliargs_deferred_get()"""
        global CLIARGS
        CLIARGS = CliArgs(store)
        assert cliargs_deferred_get(key, shallowcopy=shallowcopy)() == expected
        if shallowcopy:
            import copy
            assert cliargs_deferred_get(key, shallowcopy=shallowcopy)() is not store[key]
            assert cliargs_deferred_get(key, shallowcopy=shallowcopy)() == copy.copy

# Generated at 2022-06-22 19:44:56.717378
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works with an empty CLIARGS
    assert cliargs_deferred_get('foo')() == None

    # Test that the closure works with an CLIARGS with actual values
    cliargs = GlobalCLIArgs({})
    cliargs.add_cli_option('bar')
    cliargs.update({'bar': 'baz'})
    global CLIARGS
    CLIARGS = cliargs
    assert cliargs_deferred_get('bar')() == 'baz'

# Generated at 2022-06-22 19:44:58.745136
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # TODO: Add a unit test for this function
    pass

# Generated at 2022-06-22 19:45:08.111422
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    class GlobalCLIArgsMock(object):
        class __metaclass__(type):
            """Shim for GlobalCLIArgs"""
            _instance = None

            def __call__(cls):
                if not cls._instance:
                    cls._instance = super(GlobalCLIArgs.__metaclass__, cls).__call__()
                return cls._instance

        def __init__(self):
            self.store = dict()

        def from_options(self, options):
            return GlobalCLIArgsMock()

        def get(self, key, default=None):
            return self.store.get(key, default=default)

    class GlobalCLIArgsMock2(object):
        class __metaclass__(type):
            """Shim for GlobalCLIArgs"""
            _instance = None

# Generated at 2022-06-22 19:45:17.422533
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    # pytest jumps through a lot of hoops to set the context of the tests so it's
    # not as easy as just setting a global variable in the test and then running
    # the code in this module.  Instead, we create a closure over the CLIARGS object
    # to allow us to make CLIARGS look like what we would expect it to look like during
    # normal program execution

    def cliargs():
        return CLIARGS

    # Test that we can get a default value for a variable that is not present
    _init_global_context({})
    assert cliargs_deferred_get('foo')(cliargs) == 'bar'

    # Test that we can get a default value for a variable that is present but None
    _init_global_context({'foo': None})
    assert cliargs_deferred_

# Generated at 2022-06-22 19:45:26.228620
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # The object used for testing cliargs_deferred_get
    class FakeCLIArgs(GlobalCLIArgs):
        def __init__(self, args):
            super(FakeCLIArgs, self).__init__({})
            self.args = args

        def get(self, key, default=None):
            return self.args.get(key, default)

    def assert_shallow_copies_match(value, expected_value):
        """Assert that a copy of the value matches the expected value"""
        for shallow_copy in (False, True):
            assert cliargs_deferred_get(value, shallowcopy=shallow_copy)() == expected_value

    assert cliargs_deferred_get('no_such_key')() == None

# Generated at 2022-06-22 19:45:31.379777
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_get(x):
        inner = cliargs_deferred_get('foo')
        return inner()

    ansible_args = lambda: {'foo': 'bar'}
    _init_global_context(ansible_args)
    ret = test_get('foo')
    assert ret == 'bar'

    ansible_args = lambda: {'foo': ['a', 'b']}
    _init_global_context(ansible_args)
    ret = test_get('foo')
    assert ret == ['a', 'b']

    ansible_args = lambda: {'foo': ('a', 'b')}
    _init_global_context(ansible_args)
    ret = test_get('foo')
    assert ret == ('a', 'b')


# Generated at 2022-06-22 19:45:42.268033
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This just makes sure the function definition is correct.
    # Actual tests are in test_context_objects.py
    test_args = {'string_value': 'foo',
                 'list_value': [1, 2, 3],
                 'dict_value': {'a': 1, 'b': 2},
                 'set_value': {'a', 'b'}}
    _init_global_context(test_args)
    assert cliargs_deferred_get('string_value')() == 'foo'
    assert cliargs_deferred_get('list_value')() == [1, 2, 3]
    assert cliargs_deferred_get('dict_value')() == {'a': 1, 'b': 2}

# Generated at 2022-06-22 19:45:50.055915
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    one = {'a': 'A', 'b': 'B'}
    two = {'c': 'C', 'd': 'D'}
    one_two = {'a': 'A', 'b': 'B', 'c': 'C', 'd': 'D', 'e': 'E'}

    def check(f, expected):
        check_value = f()
        assert check_value == expected
        check_type = type(check_value)
        assert check_type == type(expected)

    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options(one)
    check(cliargs_deferred_get('a'), 'A')
    check(cliargs_deferred_get('b'), 'B')
    check(cliargs_deferred_get('c'), None)

# Generated at 2022-06-22 19:45:57.731491
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import defaultdict
    # Set global var for testing
    global CLIARGS
    cli_args = {'foo': 'bar', 'baz': [1, 2, 3, 4], 'qux': defaultdict()}
    CLIARGS = CLIArgs(cli_args)
    # Deferred get test
    get_foo = cliargs_deferred_get('foo')
    assert get_foo() == 'bar'
    # Default test
    get_missing = cliargs_deferred_get('missing', default='qux')
    assert get_missing() == 'qux'
    # Shallow copy test
    get_baz = cliargs_deferred_get('baz', shallowcopy=True)
    get_baz_copy = get_baz

# Generated at 2022-06-22 19:46:09.350630
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('not_foo', 'baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    CLIARGS = CLIArgs({'foo': {1: 2, 3: 4}})

# Generated at 2022-06-22 19:46:20.584378
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # None default
    default = None
    get_none = cliargs_deferred_get('key', default)
    cli_args = {'key': default}
    _init_global_context(cli_args)
    if default is not None:
        assert get_none() is CLIARGS['key']
    else:
        assert get_none() == CLIARGS['key']

    # Not None default
    default = 123
    get_not_none = cliargs_deferred_get('key', default)
    cli_args = {'key': default}
    _init_global_context(cli_args)
    assert get_not_none() == default

    # Key missing, default None
    default = None
    get_key_missing = cliargs_deferred_get('key', default)
   

# Generated at 2022-06-22 19:46:32.513667
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCliArgs(object):
        def __init__(self, **kwargs):
            self._store = kwargs

        def __getitem__(self, key):
            return self._store[key]

        def get(self, key, default=None):
            return self._store.get(key, default)


# Generated at 2022-06-22 19:46:40.283922
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # get a key that doesn't exist yet
    assert cliargs_deferred_get('doesnt_exist')() is None
    # update the global with a value
    CLIARGS.update(doesnt_exist='hello')
    # get the value normally
    assert cliargs_deferred_get('doesnt_exist')() == 'hello'
    # get the value with a default
    assert cliargs_deferred_get('doesnt_exist', default='world')() == 'hello'
    # get the value with a default and shallowcopy
    assert cliargs_deferred_get('doesnt_exist', default=['goodbye'], shallowcopy=True)() == 'hello'
    # update the global with a list value
    CLIARGS.update(doesnt_exist=['hello'])
    # get the value normally


# Generated at 2022-06-22 19:46:51.158828
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Check that these closure works with a ``GlobalCLIArgs`` object."""
    import pytest
    from ansible.utils.context_objects import GlobalCLIArgs
    cliargs = {'diff': True, 'check': False}
    global_cli_args = GlobalCLIArgs.from_options(cliargs)
    get_cliargs_diff = cliargs_deferred_get('diff', default=False, shallowcopy=False)
    get_cliargs_diff_default = cliargs_deferred_get('diff_default', default=False, shallowcopy=False)
    get_cliargs_check = cliargs_deferred_get('check', default=True, shallowcopy=False)

    global CLIARGS
    CLIARGS = global_cli_args
    assert get_cliargs_diff() == True

# Generated at 2022-06-22 19:46:59.492413
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is a little awkward but it does exercise the code we need to exercise
    global CLIARGS
    CLIARGS = CLIArgs()

    def set_cliargs():
        CLIARGS['ansible_test_key'] = 1
        CLIARGS['ansible_test_list'] = [1,2,3]
        CLIARGS['ansible_test_dict'] = {'a': 'b'}
        CLIARGS['ansible_test_set'] = set((1, 2, 3))

    func = cliargs_deferred_get('ansible_test_key')
    assert func() is None

    set_cliargs()
    assert func() == 1

    func = cliargs_deferred_get('ansible_test_key', None, shallowcopy=True)
    assert func() == 1


# Generated at 2022-06-22 19:47:10.823553
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test deferred get"""
    prop = cliargs_deferred_get('foo', default=42)
    assert prop() == 42
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert prop() == 'bar'
    list_prop = cliargs_deferred_get('list', default=[])
    assert list_prop() == []
    CLIARGS['list'] = ['foo', 'bar']
    assert list_prop() == ['foo', 'bar']
    list_prop_shallow = cliargs_deferred_get('list', default=[], shallowcopy=True)
    assert list_prop_shallow() == ['foo', 'bar']
    assert list_prop_shallow() is not CLIARGS['list']

# Generated at 2022-06-22 19:47:13.778586
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # this is kinda a waste of time since we don't usually mutate cliargs
    # but checking that it runs without crashing is good enough
    cliargs_deferred_get('module_path')()

# Generated at 2022-06-22 19:47:21.571978
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    from ansible.module_utils._text import to_text

# Generated at 2022-06-22 19:47:31.584919
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from unittest import TestCase
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.context_objects import GlobalCLIArgs

    class TestClass(TestCase):
        def test_basics(self):
            cliargs_default_return = cliargs_deferred_get('not_a_real_key', default='default')
            self.assertIsInstance(cliargs_default_return, type(cliargs_default_return))
            self.assertEqual('default', cliargs_default_return())

            cliargs_nothing_return = cliargs_deferred_get('not_a_real_key')
            self.assertIsInstance(cliargs_nothing_return, type(cliargs_nothing_return))

# Generated at 2022-06-22 19:47:40.632571
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    class TestArgs(Mapping):
        def __init__(self, shallowcopy):
            self._shallowcopy = shallowcopy

        def __getitem__(self, key):
            return value

        def __iter__(self):
            return iter(keys)

        def __len__(self):
            return len(keys)

    keys = ['a', 'b', 'c']
    value = object()
    CLIARGS = TestArgs(shallowcopy=True)
    f = cliargs_deferred_get('a')
    assert f.__closure__[0].cell_contents() is CLIARGS
    assert value is f()

    CLIARGS = TestArgs(shallowcopy=False)
    f = cliargs_deferred_get('b')

# Generated at 2022-06-22 19:47:49.788192
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_value(value, shallowcopy):
        _init_global_context(dict(a_key=value))
        return cliargs_deferred_get('a_key', shallowcopy=shallowcopy)()

    # None, default, and shallow copy
    assert test_value(None, False) is None
    assert test_value(False, False) is False
    assert test_value(True, False) is True
    assert test_value('', False) == ''
    assert test_value('abc', False) == 'abc'
    assert test_value('a string', False) == 'a string'
    assert test_value([], False) == []
    assert test_value([1, 2, 3], False) == [1, 2, 3]
    assert test_value(set(), False) == set()
    assert test_

# Generated at 2022-06-22 19:47:56.494306
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'compile_cache': False, 'diff': False}
    _init_global_context(cli_args)
    assert CLIARGS.get('compile_cache') == cli_args.get('compile_cache')
    assert CLIARGS.get('diff') == cli_args.get('diff')
    assert CLIARGS.get('diff', True) == cli_args.get('diff', True)
    assert CLIARGS.get('diff') != cli_args.get('diff', True)

# Test dictionary shallow copy

# Generated at 2022-06-22 19:48:06.821137
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    global CLIARGS
    assert CLIARGS is not None
    assert CLIARGS.get('notakey') is None
    default_val = cliargs_deferred_get('notakey')()
    assert default_val is None
    # Test shallow copy
    assert cliargs_deferred_get('notakey', shallowcopy=True)() is None
    CLIARGS.update(dict(a_list=[1, 2, 3]))
    a_list_ref = cliargs_deferred_get('a_list')()
    assert a_list_ref == [1, 2, 3]
    assert a_list_ref is CLIARGS['a_list']
    # Test shallow copy

# Generated at 2022-06-22 19:48:16.963673
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'a': {'b': 1}, 'b': [1], 'c': (1,), 'd': 1, 'e': set('str'), 'f': 'str'})
    # Default value
    assert cliargs_deferred_get('x')(), None
    # Shallow copy of dict and list
    assert cliargs_deferred_get('a')(), {'b': 1}
    assert cliargs_deferred_get('a', shallowcopy=True)(), {'b': 1}
    assert cliargs_deferred_get('b')(), [1]
    assert cliargs_deferred_get('b', shallowcopy=True)(), [1]
    # Deep copy of tuple
    assert cliargs_deferred_get('c')(), (1,)

# Generated at 2022-06-22 19:48:24.030275
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get"""
    # pylint: disable=unused-variable
    # pylint: disable=undefined-variable
    from ansible.config.manager import ConfigManager
    from ansible.utils import context_objects

    config_manager = ConfigManager()
    # We need to use the same configmanager for all of the tests or we will get
    # strange interactions between them
    for args in [
            [],
            ['--extra-vars=test'],
            ['--extra-vars', 'test'],
    ]:
        config_manager.options = {}
        context_objects._init_global_context(config_manager.parse(args=args))

# Generated at 2022-06-22 19:48:34.103466
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import MutableMapping

    CLIARGS['a'] = {'s1': 's1', 's2': 's2'}
    CLIARGS['b'] = MutableMapping({'s1': 's1', 's2': 's2'})
    CLIARGS['c'] = Set()
    CLIARGS['c'].add('a')
    CLIARGS['d'] = Set(['a'])

    a = cliargs_deferred_get('a')
    assert a() == {'s1': 's1', 's2': 's2'}

    b = cliargs_deferred_get('b')
    assert b() == {'s1': 's1', 's2': 's2'}

    c

# Generated at 2022-06-22 19:48:41.093486
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=missing-docstring
    class TestClass:
        def __init__(self):
            self.val = 'test'
        def __eq__(self, other):
            return isinstance(other, TestClass) and self.val == other.val

    global CLIARGS
    CLIARGS = CLIArgs({'testkey': TestClass(), 'seqkey': [TestClass(), TestClass()],
                       'seqkey2': [1, 2, 3], 'dictkey': {'key1': TestClass()},
                       'dictkey2': {'key2': 2, 'key3': 3}})

    # Test a key that isn't there:
    assert cliargs_deferred_get('testkey1', default='test') == 'test'

    # Test a key that is there and isn't a sequence

# Generated at 2022-06-22 19:48:48.285572
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    og_cliargs = CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')(), 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo', shallowcopy=True)(), ['bar', 'baz']
    assert cliargs_deferred_get('foo', default=None, shallowcopy=True)() is None
    CLIARGS = og_cliargs

# Generated at 2022-06-22 19:48:56.355289
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Ensure the function returns None if there is no CLIARGS"""
    global CLIARGS

    CLIARGS = CLIArgs({
        'foo': 'bar',
    })
    assert cliargs_deferred_get('foo', None, shallowcopy=False)() == 'bar'
    assert cliargs_deferred_get('foo', None, shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', 'baz', shallowcopy=False)() == 'bar'
    assert cliargs_deferred_get('foo', 'baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('bar', 'baz', shallowcopy=False)() == 'baz'

# Generated at 2022-06-22 19:49:07.620028
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    import copy
    import types

    # test that basic types are shallow copied
    assert cliargs_deferred_get('somearg')() is None
    assert cliargs_deferred_get('somearg', default='somearg')() == 'somearg'
    assert cliargs_deferred_get('somearg', default=1)() == 1
    assert cliargs_deferred_get('somearg', default=1.1)() == 1.1
    assert cliargs_deferred_get('somearg', default=True)() is True

# Generated at 2022-06-22 19:49:16.253331
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    import collections

    global CLIARGS  # pylint: disable=global-statement
    _orig_CLIARGS = CLIARGS

    CLIARGS = CLIArgs({})
    closure = cliargs_deferred_get('foo', 'spam')
    assert closure() == 'spam'

    CLIARGS = GlobalCLIArgs.from_options(dict(foo='bar', bar='baz'))
    closure = cliargs_deferred_get('foo', {})
    assert closure() == 'bar'

    # Make sure that we return a shallow copy of the dict on a dict
    d = dict(ham=1, spam=2)
    closure = cliargs_deferred_get('foo', d)
    assert closure() is not d  # pylint

# Generated at 2022-06-22 19:49:23.532328
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert CLIARGS.get('verbosity') == cliargs_deferred_get('verbosity')()
    assert CLIARGS.get('verbose') == cliargs_deferred_get('verbose')()

    # The return value should be a copy of a mutable value so that it can be mutated
    # without affecting the cli_args values
    def test_mutable_copy(a, b=None):
        """Test that the closure returned by cliargs_deferred_get can be mutated without
        changing the original
        """
        copy = cliargs_deferred_get('become_methods')()

        # Check that mutating the copy doesn't change the original
        copy.append('updated value')
        a.append('original')

        # Check that this is a new unique object so that we can change it without affecting


# Generated at 2022-06-22 19:49:33.735389
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    as_closure = cliargs_deferred_get('foo', default=False)
    as_func = cliargs_deferred_get('bar', default=[2, 3])
    as_shallow = cliargs_deferred_get('baz', default={}, shallowcopy=True)

    _init_global_context({'foo': True, 'bar': [1, 2], 'baz': {'a': 1, 'b': 2}})
    assert as_closure()
    assert as_func() == [1, 2]
    assert as_shallow() == {'a': 1, 'b': 2}

    # Test that as_closure returns the default when the value is not defined
    _init_global_context({})
    assert not as_closure()
    # Test that as_func returns the default when the value is not

# Generated at 2022-06-22 19:49:44.854003
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test deferred execution of cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [2, 3], 'c': {'d': 4}, 'e': {1, 2, 3}})

    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [2, 3]
    assert cliargs_deferred_get('c')() == {'d': 4}

    assert cliargs_deferred_get('b', shallowcopy=True)() == [2, 3]
    assert cliargs_deferred_get('c', shallowcopy=True)() == {'d': 4}

# Generated at 2022-06-22 19:49:53.851042
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test(key, default, expected, shallowcopy):
        assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == expected

    # Mapping
    cliargs = dict(test_1=dict(test_2=1, test_3=2), test_4=dict(test_5=3))
    _init_global_context(cliargs)

    test('test_1', {}, dict(test_2=1, test_3=2), shallowcopy=False)
    test('test_1', {}, dict(test_2=1, test_3=2), shallowcopy=True)
    test('test_4', {}, dict(test_5=3), shallowcopy=False)

# Generated at 2022-06-22 19:50:00.995621
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    from ansible.module_utils.common.collections import ImmutableDict
    CLIARGS = CLIArgs(ImmutableDict(dict(x=1, y=[1], z=dict(a=1))))
    assert cliargs_deferred_get('x')() == 1
    assert cliargs_deferred_get('y')() == [1]
    assert cliargs_deferred_get('z')() == dict(a=1)
    assert cliargs_deferred_get('m')() is None
    assert cliargs_deferred_get('m', default=42)() == 42
    assert cliargs_deferred_get('x', shallowcopy=True)() == 1
    assert cliargs_deferred_get('y', shallowcopy=True)() == [1]


# Generated at 2022-06-22 19:50:12.129142
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(foo="bar", baz=[1, 2, 3], qux=dict(x=1, y=2, z=3)))
    assert cliargs_deferred_get('foo', shallowcopy=False)() == "bar"
    assert cliargs_deferred_get('baz', shallowcopy=False)() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('qux', shallowcopy=False)() == {'x': 1, 'y': 2, 'z': 3}

# Generated at 2022-06-22 19:50:21.969748
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    value = 'something'
    key = 'foo'

    try:
        del CLIARGS[key]
    except KeyError:
        pass

    test_get = cliargs_deferred_get(key)

    assert test_get() is None

    CLIARGS[key] = value

    assert test_get() == value

    shallow_copy = cliargs_deferred_get(key, shallowcopy=True)

    # Make sure shallow copy has the same value as CLIARGS[key]
    assert shallow_copy() == value

    # Make sure shallow copy is not the same object as CLIARGS[key]
    assert shallow_copy() is not value

    # Make sure shallow copy returns a copy of the list when CLIARGS[key] is a list
    CLIARGS[key] = [value]
    assert shallow_copy

# Generated at 2022-06-22 19:50:33.345797
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'inventory': ['test'],
                       'foo': [],
                       'bar': ['baz', 'boo'],
                       'mapping': {'test': 'value',
                                   'moo': 'cow'},
                       'set': {'test', 'value'}})
    assert cliargs_deferred_get('inventory')() == ['test']
    assert cliargs_deferred_get('inventory', shallowcopy=True)() == ['test']
    assert cliargs_deferred_get('foo')() == []
    assert cliargs_deferred_get('foo', shallowcopy=True)() == []
    assert cliargs_deferred_get('bar')() == ['baz', 'boo']

# Generated at 2022-06-22 19:50:41.962914
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    def _test_value(key, default, example_value, example_value_shallow_copy, expect_shallow_copy=False):
        func = cliargs_deferred_get(key, default, expect_shallow_copy)
        # pylint: disable=unused-variable
        # Unused variables are needed for the test
        ansible_vault_password_file, ansible_vault_password, ansible_vault_password_file_shallow_copy, ansible_vault_password_shallow_copy = (None,) * 4
        # pylint: enable=unused-variable
        global CLIARGS

# Generated at 2022-06-22 19:50:48.610867
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test functionality of global context object"""
    from ansible.module_utils._text import to_native

    from ansible.context import CLIARGS as ORIG_CLIARGS  # pylint: disable=undefined-variable
    global CLIARGS

# Generated at 2022-06-22 19:50:56.096953
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    def test_get():
        assert cliargs_deferred_get('foo')({'foo':'bar'}) == 'bar'
        assert cliargs_deferred_get('foo')({}) == None

    def test_get_default():
        assert cliargs_deferred_get('foo', default='def')({}) == 'def'

    def test_shallowcopy():
        def helper(container_type):
            cliargs = CLIARGS._cli_options.copy()
            value = container_type([1, 2, 3])
            cliargs['foo'] = value

            value2 = cliargs_deferred_get('foo', shallowcopy=True)(cliargs)
            assert id(value) != id(value2)


# Generated at 2022-06-22 19:51:06.443338
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert CLIARGS.get('cats') is None

    CLIARGS = CLIArgs({'cats': 'crackers'})
    assert cliargs_deferred_get('cats')() == 'crackers'
    assert cliargs_deferred_get('cats', default='dogs')() == 'crackers'
    assert cliargs_deferred_get('cats', default='dogs', shallowcopy=True)() == 'crackers'

    listval = [1, 2, 3]
    CLIARGS = CLIArgs({'cats': listval})
    assert cliargs_deferred_get('cats')() == listval
    assert cliargs_deferred_get('cats', default='dogs', shallowcopy=True)() == listval