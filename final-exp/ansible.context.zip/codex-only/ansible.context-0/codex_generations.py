

# Generated at 2022-06-22 19:41:08.033198
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Type: () -> None
    """Test that cliargs_deferred_get returns values properly"""
    global CLIARGS
    _cli_args = {
        'one': 1,
        'two': [2, 2],
        'three': {'three': 3},
    }
    CLIARGS = CLIArgs(_cli_args)
    assert cliargs_deferred_get('one')() == 1
    assert cliargs_deferred_get('two')() == [2, 2]
    assert cliargs_deferred_get('three')() == {'three': 3}

    # Test missing values
    assert cliargs_deferred_get('four')() is None
    assert cliargs_deferred_get('four', default='four')() == 'four'

    # Test shallowcopy=True

# Generated at 2022-06-22 19:41:10.377633
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import doctest
    doctest.testmod(doctest.LINKFLAGS, optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-22 19:41:21.339271
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCLIArgs(CLIArgs):
        def __init__(self, cli_args):
            super(TestCLIArgs, self).__init__(cli_args)
            self.test_var = True

    global CLIARGS
    cli_args = {'test_var': False, 'new_var': 'test'}
    CLIARGS = TestCLIArgs(cli_args)
    assert CLIARGS.get('test_var', default=True) is False
    assert CLIARGS.get('new_var', default='not test') == 'test'
    assert CLIARGS.get('not a key', default='not test') == 'not test'
    assert CLIARGS['not a key'] is CLIARGS.defaults()['not a key']

# Generated at 2022-06-22 19:41:31.257877
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    try:
        CLIARGS = CLIArgs({'foo': 'bar'})
        assert cliargs_deferred_get('foo')() == 'bar'
        assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
        assert cliargs_deferred_get('foo', default='biz')() == 'bar'
        assert cliargs_deferred_get('biz', default='biz')() == 'biz'

        CLIARGS = CLIArgs({'baz': 'bar'})
        assert cliargs_deferred_get('foo', default='biz')() == 'biz'
    finally:
        CLIARGS = CLIArgs({})

# Generated at 2022-06-22 19:41:42.414338
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({})

    func_dict = {'foo': 1}
    assert func_dict is cliargs_deferred_get('foo')(), 'Failed to find key in dictionary when no default is passed'
    assert 2 is cliargs_deferred_get('bar', 2)(), 'Failed to return default value when key is not in dictionary'

    # Test that a shallowcopy is returned by default
    list_dict = {'list': [1, 2, 3]}
    return_list = cliargs_deferred_get('list')().copy()
    assert list_dict['list'][0] is return_list[0], 'Shallow copy on a list did not copy the individual elements'

    dict_dict = {'dict': {'foo': 'bar'}}
    return_

# Generated at 2022-06-22 19:41:49.738336
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cli_args = dict(foo=2, bar='baz', baz='quz', bool_arg=False)
    _init_global_context(cli_args)
    base_value = cliargs_deferred_get('foo')()
    assert base_value == cli_args['foo']

    del cli_args['foo']
    base_value = cliargs_deferred_get('foo')()
    assert base_value == 2

    base_value = cliargs_deferred_get('foo', default=3)()
    assert base_value == 3

    bool(cliargs_deferred_get('bool_arg')()) is False
    assert bool(cliargs_deferred_get('bool_arg', default=True)()) is True

# Generated at 2022-06-22 19:41:54.320162
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get function works"""
    # Just verify the closure works
    value_to_retrieve = 1
    default_value = 2

    def inner():
        return value_to_retrieve

    def inner_default():
        return default_value

    # Not present.  Retrieve default
    del CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('key')() == default_value

    # Present and no shallow copy
    value_to_retrieve = 1
    CLIARGS = CLIArgs({'key': value_to_retrieve})
    assert cliargs_deferred_get('key')() == value_to_retrieve
    value_to_retrieve = 2
    assert cliargs_deferred_get('key')() == value_

# Generated at 2022-06-22 19:42:02.617617
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Set up global variables in module
    global CLIARGS

    # Simple key
    _init_global_context({'become': True})
    assert cliargs_deferred_get('become')

    # Key that does not exist
    _init_global_context({})
    assert cliargs_deferred_get('become', default='test') == 'test'

    # Shallow copy
    _init_global_context({'become_user': 'test_user'})
    assert cliargs_deferred_get('become_user', shallowcopy=True) == 'test_user'

# Generated at 2022-06-22 19:42:12.851903
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(key='foo', default=10)() == 10
    assert cliargs_deferred_get(key='foo', default=10, shallowcopy=True)() == 10

    CLIARGS['foo'] = [1,2,3]
    assert cliargs_deferred_get(key='foo', default=10)() == [1,2,3]
    assert cliargs_deferred_get(key='foo', default=10, shallowcopy=True)() == [1,2,3]

    CLIARGS['foo'] = {1:2, 3:4}
    assert cliargs_deferred_get(key='foo', default=10)() == {1:2, 3:4}

# Generated at 2022-06-22 19:42:20.173543
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeCliArgs(dict):
        def copy(self):
            return FakeCliArgs(self.items())

    # Test that the static value is returned
    static_value = object()
    test_args = FakeCliArgs()
    test_args['ansible_version'] = static_value
    deferred = cliargs_deferred_get('ansible_version')
    assert deferred() == static_value
    # Test that the default value is returned
    default_value = object()
    deferred = cliargs_deferred_get('ansible_check', default=default_value)
    assert deferred() == default_value

    # Test that cli_args are shallow copied
    test_args['ansible_version'] = static_value

# Generated at 2022-06-22 19:42:26.713220
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-22 19:42:30.946856
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    inner = cliargs_deferred_get('foo')
    assert inner() == 'bar'



# Generated at 2022-06-22 19:42:37.509375
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-22 19:42:43.375125
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.set('thing', 'stuff')
    f = cliargs_deferred_get('thing')
    assert f() == 'stuff'

    CLIARGS.set('thing', 'otherstuff')
    f = cliargs_deferred_get('thing')
    assert f() == 'otherstuff'

    f = cliargs_deferred_get('otherthing', default='default_value')
    assert f() == 'default_value'

# Generated at 2022-06-22 19:42:55.011757
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'known_hosts_file': '/etc/ansible/ssh/known_hosts'})

    assert cliargs_deferred_get('known_hosts_file')() == '/etc/ansible/ssh/known_hosts'

    # Test shallowcopy behavior
    _init_global_context({'roles_path': [u'/etc/ansible/custom_roles', u'/usr/share/ansible/roles']})
    assert cliargs_deferred_get('roles_path')() == [u'/etc/ansible/custom_roles', u'/usr/share/ansible/roles']

# Generated at 2022-06-22 19:43:02.687536
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs

    assert cliargs_deferred_get('foo', 'bar')() == 'bar'

    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert cliargs_deferred_get('foo', 'nope')() == 'bar'

    CLIARGS = GlobalCLIArgs.from_options({'foo': ('bar', 'baz')})
    assert cliargs_deferred_get('foo', 'nope')() == ('bar', 'baz')
    assert cliargs_deferred_get('foo', 'nope', shallowcopy=True)() == ('bar', 'baz')
    CLIARGS.default_vars = {"foo": "nope"}
    assert cliargs_def

# Generated at 2022-06-22 19:43:13.949959
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    test_args = {'foo': 'bar', 'baz': {'k1': 1, 'k2': 2}, 'list': [1, 2, 3], 'set': set([1, 2])}
    _init_global_context(test_args)

    # Only one test for non-shallow copy mode
    non_shallow_get = cliargs_deferred_get(key='baz')
    assert non_shallow_get() is test_args['baz']

    # Test for shallow copy mode
    # The returned dictionary should no longer be a reference to the CLIARGS dictionary
    shallow_get = cliargs_deferred_get(key='baz', shallowcopy=True)
    assert shallow_get() is not test_args['baz']

    # The returned dictionary should contain the same keys as

# Generated at 2022-06-22 19:43:21.311707
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping

    original_cliargs = CLIARGS
    _init_global_context({'ANSIBLE_LIBDIR': '/path/to/libdir'})
    assert CLIARGS.get('ANSIBLE_LIBDIR') == '/path/to/libdir'

    libdir_default = cliargs_deferred_get('ANSIBLE_LIBDIR')
    assert libdir_default() == '/path/to/libdir'

    # Make sure that the function returns a copy and not the original
    assert libdir_default() is not CLIARGS['ANSIBLE_LIBDIR']

    with pytest.raises(KeyError):
        cliargs_deferred_get('FOO')



# Generated at 2022-06-22 19:43:31.355916
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pragma: no cover
    from ansible.utils.context_objects import GlobalCLIArgs
    import copy
    import io

    # Mock the CLIARGS to be a GlobalCLIArgs and get the inner function
    CLIARGS = GlobalCLIArgs({"test": "value"})
    deferred_get = cliargs_deferred_get("test")

    # Verify that it gets the value from CLIARGS
    assert deferred_get() == "value"

    # Test that it gets the default and that it respects the shallow copy
    default = io.StringIO("test")
    assert deferred_get(default=default, shallowcopy=True) is not default
    assert deferred_get(default=default, shallowcopy=True) == default.getvalue()
    assert deferred_get(default=default, shallowcopy=False) is default

    # Test

# Generated at 2022-06-22 19:43:38.984532
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the function cliargs_deferred_get"""

    global CLIARGS
    # Set the value of CLIARGS to the default for testing purposes
    CLIARGS = CLIArgs({})

    # Test that a value that isn't in CLIARGS returns the default value
    assert cliargs_deferred_get('not_present', default=False)() is False, 'Default value not returned'

    # Test that passing an argument to CLIARGS returns the value
    cli_args = {'key1': 'value1', 'key2': 'value2'}
    CLIARGS = CLIArgs(cli_args)
    assert cliargs_deferred_get('key1', default=False)() == 'value1', 'Value passed in CLIARGS not returned'

    # Test that shallow copy works

# Generated at 2022-06-22 19:43:45.948140
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    import os

    old_environ = dict(os.environ)
    os.environ['ANSIBLE_JINJA2_NATIVE'] = 'true'
    args = {
        'check': True,
        'skip_tags': 'tag1',
        'vault_password_files': ['filepath']
    }
    cli_args = CLIArgs(args)
    _init_global_context(cli_args)

    # Deferred var
    assert CLIARGS.get('check'), 'Commandline argument check is not working'

    # Shallow copy
    assert cliargs_deferred_get('skip_tags') is cliargs_deferred_get('skip_tags')

# Generated at 2022-06-22 19:43:55.440416
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': ['bar'], 'baz': 1})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    assert cliargs_deferred_get('baz')() == 1
    assert cliargs_deferred_get('baz', shallowcopy=True)() == 1

    CLIARGS = CLIArgs({'foo': 'bar', 'baz': 1})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == 1

# Generated at 2022-06-22 19:44:05.325502
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import OrderedDict, Set
    from ansible.module_utils.common.text.converters import to_bytes
    global_args = CLIArgs({'ANSIBLE_HOST_KEY_CHECKING': False,
                           'ANSIBLE_INTERNAL_DATA': {to_bytes(b'ANSIBLE_METADATA', errors='surrogate_or_strict'): {}}})
    global_args['ANSIBLE_INTERNAL_DATA'][to_bytes(b'ANSIBLE_METADATA', errors='surrogate_or_strict')].update({'module_setup': True})

# Generated at 2022-06-22 19:44:13.844726
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""

    # Check that it returns the base value
    assert cliargs_deferred_get('foo')(), None
    assert cliargs_deferred_get('foo', default=1)(), 1

    # Check that it returns the shallow copy value
    test_value = [1, 2, 3]
    assert cliargs_deferred_get('foo', default=test_value, shallowcopy=True)(), test_value
    assert cliargs_deferred_get('foo', default=test_value, shallowcopy=False)(), test_value

# Generated at 2022-06-22 19:44:18.485543
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CliArgs(object):
        def get(self, key, default):
            return {'a':1, 'b':[1, 2, 3], 'c':{'c1':1, 'c2':2}}[key]

    # Replace global with our test object
    CLIARGS = CliArgs()

    GET = cliargs_deferred_get
    assert GET('a')() == 1
    assert id(GET('b')()) != id(GET('b')())
    assert GET('b', shallowcopy=True)() == [1, 2, 3]
    assert id(GET('c')()) != id(GET('c')())
    assert GET('c', shallowcopy=True)() == {'c1':1, 'c2':2}

# Generated at 2022-06-22 19:44:26.590835
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function ``cliargs_deferred_get``"""
    def inner():
        foo = cliargs_deferred_get('foo', default={}, shallowcopy=True)
        bar = cliargs_deferred_get('foo', default={}, shallowcopy=False)
        foo['bar'] = 1
        bar['bar'] = 2
        assert foo['bar'] == 1
        assert bar['bar'] == 2
        assert foo != bar

    old = CLIARGS
    CLIARGS = GlobalCLIArgs({'foo': {}})
    assert inner() is None
    CLIARGS = old

# Generated at 2022-06-22 19:44:38.649838
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_list = ['a', 'b', 'c']
    test_dict = {'a': 'A', 'b': 'B', 'c': 'C'}
    test_set = set([1, 2, 3])

    def test_worker(key, expected, default=None, shallcopy=False, expect_error=False):
        check_type = type(expected)
        # Test with default=None
        result_val = cliargs_deferred_get(key, default=default, shallowcopy=shallcopy)()
        result_type = type(result_val)
        assert not expect_error, "Test should not have thrown an error"
        assert result_type is check_type, "{} is not the same type as {}".format(result_type.__name__, check_type.__name__)

# Generated at 2022-06-22 19:44:48.803956
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import AttributeDict

    # We need to access the module's global for this hack to work
    global CLIARGS

    # Create a custom CLIARGS class so we can test how we interact with the frozen dict
    class CLIARGS(AttributeDict):
        pass
    CLIARGS.foo = 'foo'
    CLIARGS.bar = ['one', 'two']
    CLIARGS.baz = AttributeDict({'a': 'one'})

    assert CLIARGS.foo == 'foo'
    assert CLIARGS.bar == ['one', 'two']
    assert CLIARGS.baz.a == 'one'

    # Now test the deferred get
    cliargs_deferred_get_foo = cliargs_deferred_get('foo', 'foo')


# Generated at 2022-06-22 19:44:54.811544
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'a': 1, 'b': 2}
    global CLIARGS
    CLIARGS = CLIArgs(cli_args)
    assert cliargs_deferred_get('a')() == cliargs_deferred_get('a', default=None)()
    assert cliargs_deferred_get('b')() == cliargs_deferred_get('b', default=None)()
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == 2
    assert cliargs_deferred_get('c')() is None
    assert cliargs_deferred_get('c', default=4)() == 4

# Generated at 2022-06-22 19:44:59.908796
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({"foo": "bar"})
    fn = cliargs_deferred_get('foo')
    assert fn() == "bar"
    CLIARGS = CLIArgs({"foo": "baz"})
    assert fn() == "baz"


# Generated at 2022-06-22 19:45:08.999714
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    args = {'a': 1, 'b': {'b1': 1, 'b2': 2}, 'c': [1, 2, 3]}
    CLIARGS = CLIArgs(args)
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == {'b1': 1, 'b2': 2}
    assert cliargs_deferred_get('c')() == [1, 2, 3]
    assert cliargs_deferred_get('b', shallowcopy=True)() == {'b1': 1, 'b2': 2}
    assert cliargs_deferred_get('c', shallowcopy=True)() == [1, 2, 3]

    args.update({'a': 5})
    assert cli

# Generated at 2022-06-22 19:45:17.477649
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('arg1')() is None
    assert cliargs_deferred_get('arg1', default='x')() == 'x'
    CLIARGS.update(arg1='a', arg2=['b', 'c'])
    assert cliargs_deferred_get('arg1')() == 'a'
    assert cliargs_deferred_get('arg2')() == ['b', 'c']
    assert cliargs_deferred_get('arg2', shallowcopy=True)() == ['b', 'c']
    assert cliargs_deferred_get('arg1', shallowcopy=True)() == 'a'
    CLIARGS['arg2'].append('d')

# Generated at 2022-06-22 19:45:26.300468
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'v': 1, 'vv': 2, 'vvv': 3})
    assert cliargs_deferred_get('v', 0)() == 1
    assert cliargs_deferred_get('x', 5)() == 5
    assert cliargs_deferred_get('v', 6)() == 1
    assert cliargs_deferred_get('vv')().__class__ == int
    assert cliargs_deferred_get('vv', shallowcopy=True)() == 2
    assert cliargs_deferred_get('vv', shallowcopy=True)().__class__ == int
    assert cliargs_deferred_get('vvv', shallowcopy=True)() != list(range(4)[2:])

# Generated at 2022-06-22 19:45:37.304564
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    import random
    import string

    # Check that the "default" in the deferred_get closure is what we expect
    test_value = random.choice(string.ascii_letters)
    assert cliargs_deferred_get(test_value)() == test_value
    assert cliargs_deferred_get(test_value, test_value)() == test_value
    assert cliargs_deferred_get(test_value, test_value + 'zzz')() == test_value + 'zzz'
    assert cliargs_deferred_get(test_value, default=test_value + 'zzz')() == test_value + 'zzz'

    # Check that the value returned by the deferred_get closure is what we expect

# Generated at 2022-06-22 19:45:47.228674
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    assert callable(cliargs_deferred_get)
    assert cliargs_deferred_get is not CLIARGS.get

    cliargs_deferred_get_closure = cliargs_deferred_get('nonexistent', None)
    assert callable(cliargs_deferred_get_closure)
    assert cliargs_deferred_get_closure() is None

    CLIARGS['test'] = 'test value'
    cliargs_deferred_get_closure = cliargs_deferred_get('test')
    assert callable(cliargs_deferred_get_closure)
    assert cliargs_deferred_get_closure() == 'test value'


# Generated at 2022-06-22 19:45:57.053142
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Assign CLIARGS to a local variable so that it is still possible to turn on
    # warnings below without affecting the true global ``CLIARGS``
    def func():
        local_CLIARGS = CLIARGS
        def inner():
            cli_args = local_CLIARGS
            return cli_args
        return inner

    assert func()() == CLIARGS
    my_dict = {'foo': 'bar'}
    my_list = [1, 2]
    my_set = {1, 2, 3}
    CLIARGS.update({'foo': my_dict, 'bar': my_list, 'baz': my_set})

    assert cliargs_deferred_get('foo')() == my_dict
    assert cliargs_deferred_get('bar')() == my_list


# Generated at 2022-06-22 19:46:08.883106
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    cliargs = CLIARGS
    cliargs._options = dict(
        one=dict(default=2),
        two=dict(default=[1, 2, 3]),
        three=dict(default={1: 2}),
    )
    # No default
    assert cliargs.get('none') is None
    assert cliargs_deferred_get('none')() is None
    # Default
    assert cliargs.get('one') == 2
    assert cliargs_deferred_get('one')() == 2
    # Shallow copy
    assert cliargs.get('two', shallowcopy=True) == [1, 2, 3]
    assert cliargs_deferred_get('two', shallowcopy=True)() == [1, 2, 3]
   

# Generated at 2022-06-22 19:46:15.495061
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from collections import defaultdict, namedtuple

    class C(object):
        c = cliargs_deferred_get('c')
        d = cliargs_deferred_get('d', [1, 2])
        e = cliargs_deferred_get('e', "dummy")
        f = cliargs_deferred_get('f', defaultdict(int))
        g = cliargs_deferred_get('g', namedtuple('G', 'a b c')(1, 2, 3))
        h = cliargs_deferred_get('h', shallowcopy=False)
        i = cliargs_deferred_get('i', shallowcopy=True)
        j = cliargs_deferred_get('j', deepcopy=True)

    c = C()
    assert c.c() == {}

# Generated at 2022-06-22 19:46:23.332549
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with a string
    global CLIARGS
    CLIARGS = CLIArgs(dict(foo=['bar'], baz=dict(boo=dict())))
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == {'boo': {}}
    assert cliargs_deferred_get('doesnotexist', default='default')() == 'default'
    assert cliargs_deferred_get('doesnotexist', default='default', shallowcopy=True)() == 'default'

# Generated at 2022-06-22 19:46:33.763138
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs

    class FakeCliArgs(CLIArgs):
        def __init__(self, data):
            self._data = data

        def get(self, key, default=None):
            return self._data.get(key, default=default)

    global CLIARGS
    CLIARGS = FakeCliArgs({'key1': 'value1'})

    get_key1 = cliargs_deferred_get('key1')
    get_key2 = cliargs_deferred_get('key2')

    assert get_key1() == 'value1'
    assert get_key2() is None

    assert cliargs_deferred_get('key1', 'new default')() == 'value1'

# Generated at 2022-06-22 19:46:41.131604
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli = CLIArgs({'a': 42, 'verbosity': 1})
    inner = cliargs_deferred_get('verbosity', 0)
    assert inner() == 1
    inner = cliargs_deferred_get('nope', 42)
    assert inner() == 42
    inner = cliargs_deferred_get('a', default=99)
    assert inner() == 42
    inner = cliargs_deferred_get('a', shallowcopy=True)
    assert inner() == 42
    cli['a'] = {'b': 'c'}
    inner = cliargs_deferred_get('a', shallowcopy=True)
    assert inner() == {'b': 'c'}
    cli['a'] = ['a', 'b', 'c']
    inner = cliargs_deferred_

# Generated at 2022-06-22 19:46:47.694987
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Smoke test for cliargs_deferred_get"""
    # Just make sure this does not crash
    assert cliargs_deferred_get('whatever', shallowcopy=False)() is None
    assert cliargs_deferred_get('whatever', shallowcopy=True)() is None

# Note: These are not the singleton versions.  The Singletons are only created once the program has
# actually parsed the args
#CLIARGS = GlobalCLIArgs({})

# Generated at 2022-06-22 19:46:57.745623
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs, GlobalCLIArgsStub

    args = {'start_at_task': 'foo', 'myopt': 42, 'mylist': [1, 2, 3], 'mydict': {'foo': 'bar'}, 'myset': set(['a', 'b'])}

# Generated at 2022-06-22 19:47:03.879044
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy

    # Empty CLIARGS
    from ansible.utils.context_objects import CLIArgs
    global CLIARGS
    CLIARGS = CLIArgs({})

    # Default value with no args
    default = [1, 2, 3]
    for shallowcopy in (False, True):
        value = cliargs_deferred_get('not-in-args', default=default, shallowcopy=shallowcopy)()
        if shallowcopy:
            assert value == default
            assert value is not default
        else:
            assert value is default

    # Non-default value with args
    cli_args_value = [4, 5, 6]
    cli_args = {'not-in-args': cli_args_value[:]}
    global CLIARGS
    CLIARGS = CLIArgs(cli_args)


# Generated at 2022-06-22 19:47:13.190250
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import sys

    module_name = 'ansible.module_utils.context'
    module = sys.modules[module_name]

    init_module_contexts = module.__dict__.get('_init_module_contexts')
    if init_module_contexts is not None:
        init_module_contexts(CLIARGS)

    module_bool = cliargs_deferred_get('_ansible_module_dont_write_bytecode', default=False)
    assert module_bool()

    cli_bool = cliargs_deferred_get('DONT_WRITE_BYTECODE', default=False)
    assert cli_bool()

# Generated at 2022-06-22 19:47:21.141258
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    >>> test_cliargs_deferred_get()
    """
    global CLIARGS

    # the fact that CLIARGS is not a dict and that we want to be able to get
    # defaults is what this function is for, so test those conditions

    # given no command line args, it should return the default
    assert 42 == cliargs_deferred_get('my_key', default=42)()

    CLIARGS = CLIArgs({'my_key': 'my_val'})

    # test that we can get a value from cliargs
    assert 'my_val' == cliargs_deferred_get('my_key', default=None)()

    # test that shallow copies work
    l = ['my_val']

# Generated at 2022-06-22 19:47:31.334692
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    mydict = {'foo': 'bar'}

    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    _init_global_context({'foo': mydict})
    assert cliargs_deferred_get('foo')() == mydict
    assert cliargs_deferred_get('foo', shallowcopy=True)() == mydict
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not mydict

    mylist = ['foo', 'bar']
    _init_global_context({'foo': mylist})
    assert cliargs_deferred_get('foo')() == mylist
    assert cliargs_deferred_get('foo', shallowcopy=True)() == mylist
    assert cli

# Generated at 2022-06-22 19:47:37.094445
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # NOTE: This function is not actually tested by any unit tests as it is only called in the
    # constructor of FieldAttribute and FieldAttribute is only used by modules.  We do have
    # coverage of the calls but that is not the same thing as unit testing.  If we decide to
    # change the above to use a different method of creating the closure, we should add unit
    # tests for this method.
    pass

# Generated at 2022-06-22 19:47:48.089622
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Foo:
        pass
    _init_global_context({'foo': 'bar'})
    assert 'bar' == cliargs_deferred_get('foo')()
    assert 42 == cliargs_deferred_get('baz', default=42)()
    foo = Foo()
    assert foo == cliargs_deferred_get('baz', default=foo)()
    assert ['foo', 'bar'] == cliargs_deferred_get('baz', default=['foo', 'bar'])()
    assert ['foo', 'bar'] == cliargs_deferred_get('baz', default=['foo', 'bar'], shallowcopy=True)()
    assert 42 == cliargs_deferred_get('baz')()
    assert [] == cliargs_deferred_get('baz', default=[])

# Generated at 2022-06-22 19:47:57.360769
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test of cliargs_deferred_get"""
    global CLIARGS

    orig = CLIARGS.get('force_handlers')
    CLIARGS.__dict__['force_handlers'] = [1, 2, 3]

    closure = cliargs_deferred_get('force_handlers', shallowcopy=False)
    assert closure() == [1, 2, 3]

    closure = cliargs_deferred_get('force_handlers', shallowcopy=True)
    assert closure() == [1, 2, 3]

    closure = cliargs_deferred_get('force_handlers', default=[1, 2, 3, 4], shallowcopy=False)
    assert closure() == [1, 2, 3, 4]


# Generated at 2022-06-22 19:48:05.414012
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    cli_args = {'become': False, 'become_method': 'sudo', 'become_user': 'root', 'module_path': ['/home/shark/playbooks/library']}
    _init_global_context(cli_args)

    default_value = cli_args.get('become')
    assert cliargs_deferred_get('become')() == default_value

    value = cli_args.get('become_method')
    assert cliargs_deferred_get('become_method')() == value

    value = cli_args.get('become_user')
    assert cliargs_deferred_get('become_user')() == value

    default_value = cli_args.get('module_path')
    # Ensure default value is

# Generated at 2022-06-22 19:48:12.025918
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cli_args = dict(verbosity=0, module_compression='gzip', stdout_callback='json')
    _init_global_context(cli_args)
    assert CLIARGS.get('verbosity') == 0
    assert CLIARGS.get('module_compression') == 'gzip'
    assert cliargs_deferred_get('verbosity', shallowcopy=False) == 0
    assert cliargs_deferred_get('module_compression', shallowcopy=False) == 'gzip'

# Generated at 2022-06-22 19:48:21.270292
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Make sure that it works with the global CLIARGS
    assert cliargs_deferred_get('key', default='default_value') == 'default_value'
    CLIARGS = CLIArgs({'key': 'test_value'})
    assert cliargs_deferred_get('key', default='default_value') == 'test_value'

    # Make sure that it works with the non-singleton CLIARGS
    test_cliargs = CLIArgs({'key': 'test_value'})
    assert cliargs_deferred_get(key='key', default='default_value', cli_args=test_cliargs) == 'test_value'

    # Make sure that it works with shallow copy
    CLIARGS = CLIArgs({'key': ['one', 'two', 'three']})

# Generated at 2022-06-22 19:48:30.070320
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Mapping

    global CLIARGS
    cli_args = dict(
        connection='local',
        one_val=dict(foo='bar'),
        one_tuple=('tup0', 'tup1'),
    )

    orig_cli_args = cli_args.copy()

    _init_global_context(cli_args)

    assert CLIARGS['connection'] == 'local'
    assert cli_args['connection'] == 'local'

    assert CLIARGS['one_val'] == {'foo': 'bar'}
    assert cli_args['one_val'] == {'foo': 'bar'}

# Generated at 2022-06-22 19:48:40.042061
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get for the different cases"""
    import sys

    def reset_cliargs():
        global CLIARGS
        CLIARGS = CLIArgs(dict(
            test1='value1',
            test2=['value2']))

    reset_cliargs()

    assert cliargs_deferred_get('test1')() == 'value1'
    assert cliargs_deferred_get('test2')() == ['value2']

    set_cliargs(dict(test1=['value3']))
    assert cliargs_deferred_get('test1')() == ['value3']
    assert cliargs_deferred_get('test2')() == ['value2']

    del CLIARGS['test1']
    assert cliargs_deferred_get('test1')() is None

# Generated at 2022-06-22 19:48:50.099889
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    CLIARGS['var'] = 'value'

    # shallowcopy not set
    get = cliargs_deferred_get('var', default='default')
    assert(get() == 'value')
    get = cliargs_deferred_get('var2', default='default')
    assert(get() == 'default')

    # shallowcopy set
    get = cliargs_deferred_get('var', default={1,2,3}, shallowcopy=True)
    assert(get() == 'value')
    get = cliargs_deferred_get('var2', default={1,2,3}, shallowcopy=True)
    assert(get() == {1,2,3})
    assert(isinstance(get(), set))

# Generated at 2022-06-22 19:49:00.506158
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    orig = [1, 2, 3]
    result = cliargs_deferred_get('key', default=orig)()
    assert result is orig
    # Reassign CLIARGS to a different object.  If this was a closure over it directly, then we'd have
    # to rebind the function.
    CLIARGS = CLIARGS.copy()
    result = cliargs_deferred_get('key', default=orig)()
    assert result is orig
    result = cliargs_deferred_get('key', default=orig, shallowcopy=True)()
    assert result == orig
    #
    # Make sure that we really are getting a closure
    CLIARGS['key'] = 'value'
    result = cliargs_deferred_get('key', default=orig)()
    assert result

# Generated at 2022-06-22 19:49:11.493651
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is the input to the function
    CLIARGS_INPUT = CLIArgs({
        # list
        'list_key': [1, 2, 3],
        # dict
        'dict_key': {'a': 1, 'b': 2},
        # set
        'set_key': {'a', 'b', 'c'},
        # scalar
        'scalar_key': 'scalar value',
        # None
        'none_key': None,
    })

    def _compare_lists(list1, list2):
        assert len(list1) == len(list2)
        for item in list1:
            assert item in list2
        for item in list2:
            assert item in list1


# Generated at 2022-06-22 19:49:21.129057
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(test_default=dict(test_key='test_value')))

    assert cliargs_deferred_get('test_default') == dict(test_key='test_value')
    assert cliargs_deferred_get('test_default', default=dict(test_key='default_value')) == dict(test_key='test_value')
    assert cliargs_deferred_get('test_default', shallowcopy=True) == dict(test_key='test_value')
    assert cliargs_deferred_get('test_not_default') == cliargs_deferred_get('test_not_default', default=None)
    assert cliargs_deferred_get('test_not_default', default='default_value') == 'default_value'


# Generated at 2022-06-22 19:49:31.874728
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update(dict(foo='foo', bar='bar', baz='baz'))
    key = 'foo'
    value = 'foobar'
    default = 'foo'

    # test no default
    get = cliargs_deferred_get(key)
    assert get() == CLIARGS[key], '''value returned by inner should not be copied'''

    # test with default
    get = cliargs_deferred_get(key, default=default)
    assert get() == CLIARGS[key], '''value returned by inner should not be copied'''

    # test overriding default
    get = cliargs_deferred_get(key, default=default)
    assert get() != value
    CLIARGS[key] = value
    assert get() == value

    # test that copy happened
    CLI

# Generated at 2022-06-22 19:49:43.471791
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    # Setting up the test
    test_default = 2
    test_dict = {'test_dict': {'testkey': 'testvalue'}}
    test_list = {'test_list': [1, 2, 3]}
    test_set = {'test_set': {'a','b','c'}}
    # Testing non-copyable types
    _init_global_context(test_dict)
    assert cliargs_deferred_get('test_dict') == test_dict['test_dict']
    assert cliargs_deferred_get('test_dict', shallowcopy=True) == test_dict['test_dict']
    _init_global_

# Generated at 2022-06-22 19:49:53.812768
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.utils.context_objects
    import copy

    global CLIARGS
    orig_CLIARGS = CLIARGS

    global_value = [3, 4, 5]
    global_value2 = [6, 7, 8]
    global_default = [1, 2]

    def mock_cliargs_get(key, **kwargs):
        if key == 'value':
            return global_value
        elif key == 'value2':
            return global_value2
        return global_default

    class MockCliArgs(ansible.utils.context_objects.CliArgs):
        def get(self, key, **kwargs):
            return mock_cliargs_get(key, **kwargs)

    # First make sure that the function returns what cliargs would return
    CLIARGS = MockCliArgs

# Generated at 2022-06-22 19:50:00.972409
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Test ``cliargs_deferred_get``

    The use case the function was created to test was with ``FieldAttribute``.
    Here, we test the function in the use case it was originally written for

    TODO: These are not unit tests as they use the global context.  Move them to an integration
    test that initializes the CLIARGS with some arguments
    """
    global CLIARGS

    # Test default value
    CLIARGS = CLIArgs({})
    cliargs_deferred_get('--become')()
    # Test value that is present
    CLIARGS = CLIArgs({'become': True})
    cliargs_deferred_get('--become')()
    # Shallow copy mutable value
    CLIARGS = CLIArgs({'become_user': 'foo'})
    cliargs_

# Generated at 2022-06-22 19:50:11.495922
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def not_ok(args, key, default, shallowcopy):
        return not cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)().startswith(args)
    assert not cliargs_deferred_get('foo', default='bar', shallowcopy=False)() == 'bar'
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=False)() == 'bar'
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo', default='bad', shallowcopy=False)() == 'baz'

    # test that shallowcopy doesn't change the underlying value
    old_value = CLIARGS['foo']

# Generated at 2022-06-22 19:50:21.652733
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCLIArgs(CLIArgs):
        """Class for testing deferred get"""
        def __init__(self, opts=None):
            super(TestCLIArgs, self).__init__(opts)
            self['key'] = 'value'
    # Test with default
    test_args = TestCLIArgs()
    deferred_get_fn = cliargs_deferred_get('key', default='a value')
    assert deferred_get_fn() == 'value'
    del test_args['key']
    assert deferred_get_fn() == 'a value'

    # Test without default
    test_args = TestCLIArgs()
    deferred_get_fn = cliargs_deferred_get('key')
    assert deferred_get_fn() == 'value'
    del test_args['key']
   

# Generated at 2022-06-22 19:50:33.078894
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Verifies that default is returned when no key is found
    assert cliargs_deferred_get(key='foo', default='bar')(), 'bar'

    # Verifies that no default is required
    assert cliargs_deferred_get(key='foo')(), None

    # Verifies that it returns a shallow copy of a sequence
    assert cliargs_deferred_get(key='foo', shallowcopy=True)(), []

    # Verifies that it returns a shallow copy of a dictionary
    assert cliargs_deferred_get(key='foo', shallowcopy=True)(), {}

    # Verifies that it returns a shallow copy of a Set
    assert cliargs_deferred_get(key='foo', shallowcopy=True)(), set()

    # Verifies that it returns the value and not a copy when shallowcopy is False


# Generated at 2022-06-22 19:50:41.769040
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def helper(key, default, value, expected):
        _init_global_context(value)
        assert cliargs_deferred_get(key, default=default) == expected

    helper('foo', 'bar', {'foo': 'baz'}, 'baz')
    helper('foo', 'bar', {}, 'bar')
    helper('foo', [1, 2, 3], {'foo': [2, 3, 4]}, [2, 3, 4])
    helper('foo', 'bar', {'foo': 'baz'}, 'baz')

    _init_global_context({'foo': 'baz'})
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True) == 'baz'
    _init_global_context({'foo': [2, 3, 4]})


# Generated at 2022-06-22 19:50:48.511504
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def inner():
        # Test the function without a shallowcopy and without a default
        value = CLIARGS.get('key')
        assert value == inner
        # Test the function with a default
        value = CLIARGS.get('key_default', default='value_default')
        assert value == 'value_default'
        # Test the function with a shallowcopy and without a default
        value = CLIARGS.get('key_shallow', shallowcopy=True)
        assert value == inner
        # Test the function with a shallowcopy and with a default
        value = CLIARGS.get('key_shallow_default', default='value_default', shallowcopy=True)
        assert value == 'value_default'

    # Replace the global context with a dict with some basic values
    global CLIARGS

# Generated at 2022-06-22 19:50:59.094561
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'key': 1})
    assert cliargs_deferred_get('key')() == 1
    assert cliargs_deferred_get('key2')(default=2) == 2
    assert cliargs_deferred_get('key3')(default=[1, 2]) == [1, 2]
    assert cliargs_deferred_get('key4')(default=set([1, 2])) == set([1, 2])
    assert cliargs_deferred_get('key5')(default=dict(a=1, b=2)) == dict(a=1, b=2)

    # shallow copy
    assert cliargs_deferred_get('key', shallowcopy=True)() == 1