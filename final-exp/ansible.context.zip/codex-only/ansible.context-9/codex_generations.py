

# Generated at 2022-06-22 19:41:08.105155
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeCliArgs(Mapping):
        def __getitem__(self, key):
            return {'key1': ['foo', 'bar'], 'key2': {'value': 'qux'}}[key]

        def get(self, key, default=None):
            return {'key1': ['foo', 'bar'], 'key2': {'value': 'qux'}}[key]

        def __iter__(self):
            return iter(['key1', 'key2'])

        def __len__(self):
            return 2

    def foo(key, default=None, shallowcopy=False):
        return cliargs_deferred_get(key, default, shallowcopy)

    global CLIARGS
    CLIARGS = FakeCliArgs()


# Generated at 2022-06-22 19:41:16.657758
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for the cliargs_deferred_get function"""
    CLIARGS = CLIArgs({'ANSIBLE_STRATEGY': 'free',
                       'ANSIBLE_DIFF': True,
                       'ANSIBLE_LOOKUP_PLUGINS': ['plugins/lookup']})

    _cliargs_deferred_get = cliargs_deferred_get

    assert _cliargs_deferred_get('ANSIBLE_STRATEGY')() == 'free'
    assert _cliargs_deferred_get('ANSIBLE_DIFF')() is True
    assert _cliargs_deferred_get('ANSIBLE_LOOKUP_PLUGINS')() == ['plugins/lookup']
    assert _cliargs_deferred_get('ANSIBLE_LOOKUP_PLUGINS', shallowcopy=True)() == ['plugins/lookup']

# Generated at 2022-06-22 19:41:27.076684
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils._text import to_bytes
    import pytest

    # Test with no key present, with a default provided, and without a default provided
    for key, default in [('no_such_key', 'default'), ('no_such_key', None)]:
        assert cliargs_deferred_get(key, default=default)() == default

    # Test with a key present
    key, default, value = 'this_key', 'default', 'not_default'
    CLIARGS['this_key'] = value
    assert cliargs_deferred_get(key, default=default)() == value

    # Test that we support multiple data types
    key, value = 'key', 'value'
    CLIARGS[key] = value
    assert cliargs_deferred_get(key)() == value


# Generated at 2022-06-22 19:41:38.415743
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    data = {}
    def _init_global_context_proxy(data):
        global CLIARGS
        CLIARGS = CLIArgs(data)

    def verify(data, key, value):
        _init_global_context_proxy(data)
        assert cliargs_deferred_get(key)() == value
        # we need to test that shallow copies work
        if isinstance(value, (list, tuple)):
            cliargs_deferred_get(key, shallowcopy=True)()[0] = 'hello'
            assert CLIARGS.get(key) != cliargs_deferred_get(key)()

    def verify_default(data, key, default, value):
        _init_global_context_proxy(data)
        assert cliargs_deferred_get(key, default)() == value



# Generated at 2022-06-22 19:41:47.613651
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Foo(object):
        def __init__(self, cli_args):
            self.cli_args = cli_args
            self.bob = cliargs_deferred_get('bob')

    foo1 = Foo({'bob': 'the_bob'})
    assert foo1.bob() == 'the_bob'

    # The function still works after CLIARGS is replaced
    global CLIARGS
    CLIARGS = GlobalCLIArgs({'sam': 'the_sam'})
    foo2 = Foo({'bob': 'the_bob'})
    assert foo2.bob() == 'the_bob'
    CLIARGS = CLIArgs({'sue': 'the_sue'})
    foo3 = Foo({'bob': 'the_bob'})

# Generated at 2022-06-22 19:41:57.160074
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Note: the actual GlobalArgs object is created with _init_global_context
    # This object is just to test against
    class GlobalCliArgs(object):
        def __getitem__(self, key):
            if key == 'no_log':
                return True
            raise KeyError(key)

    cli_args = GlobalCliArgs()
    global CLIARGS
    old = CLIARGS

# Generated at 2022-06-22 19:42:06.065542
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This tests the closure over getting a key from CLIARGS.
    # No need to test the actual default retrieval because that is thoroughly covered by cliargs_deferred_get
    cli_args = CLIArgs({'a': {'b': 1}})
    get_a_b = cliargs_deferred_get('a', 'b', default=2)
    get_a_c = cliargs_deferred_get('a', 'c', default=3)

    assert get_a_b() == 1
    assert get_a_c() == 3

    # Now test the copy functionality
    cli_args.a = {'b': {'c': 1}}
    assert get_a_b() == {'c': 1}
    assert get_a_b(shallowcopy=True) == {'c': 1}

# Generated at 2022-06-22 19:42:16.524494
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get
    """
    global CLIARGS
    CLIARGS = CLIArgs({})
    # Test that we return the default if the value isn't set
    assert cliargs_deferred_get('foo')(), "Should return the default"
    # Test that we return the default if shallow copy is set but value isn't set
    assert cliargs_deferred_get('foo', shallowcopy=True)(), "Should return the default"
    # Test that we return the value if it's a non-sequence and non-mapping
    CLIARGS['foo'] = 1
    assert cliargs_deferred_get('foo')(), 1
    # Test that we return a shallow copy of the value if it's a non-sequence and non-mapping
    CLIARGS['foo'] = 1


# Generated at 2022-06-22 19:42:24.997454
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping
    from types import FunctionType
    from types import GeneratorType
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import zip

    cliargs = {
        'foo': 'bar',
        'baz': 1,
        'bak': 'bam',
        'xyz': {'a': 1},
        'qux': [1],
        'boz': [1, 2],
        'blah': {'a': 1, 'b': 2}
    }
    # init CLIARGS
    init_global_context(cliargs)

    class Foo(object):
        bar = cliargs_def

# Generated at 2022-06-22 19:42:32.679260
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        # This is just a function that returns something so we can invoke it more than
        # once and get the same result each time
        def do_get_size():
            return CLIARGS.get('list_size', default=1)

        CLIARGS.set('list_size', ['small'])
        assert do_get_size() == ['small']
        assert cliargs_deferred_get('list_size')() == ['small']
    finally:
        CLIARGS.reset()

# Generated at 2022-06-22 19:42:43.202755
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit Tests for cliargs_deferred_get"""
    _init_global_context({'one': 1})

    assert cliargs_deferred_get('one')() == 1
    assert cliargs_deferred_get('one', default=2)() == 1

    assert cliargs_deferred_get('two', default=2)() == 2
    assert cliargs_deferred_get('two', default=2, shallowcopy=True)() == 2

    assert cliargs_deferred_get('list', default=[])() == []
    assert cliargs_deferred_get('list', default=[], shallowcopy=True)() == []

    assert cliargs_deferred_get('dict', default={})() == {}

# Generated at 2022-06-22 19:42:54.822802
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.playbook.play

    class FakeCLIArgs(dict):
        """
        Rips off `CLIArgs`'s usage of attribute `option_list` to turn it into an attribute
        """
        option_list = ('one', 'two', 'three')

    global CLIARGS
    CLIARGS = FakeCLIArgs({'one': [1, 2, 3],
                          'two': {'a': 'b', 'c': 'd'},
                          'three': set((1, 2, 3))})

    # Make a fake field to test with
    class FakeField(ansible.playbook.play.FieldAttribute):
        def __init__(self, *args, **kwargs):
            super(FakeField, self).__init__(*args, **kwargs)

    field = FakeField()

   

# Generated at 2022-06-22 19:42:57.440216
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(key='test-key') == None
    assert cliargs_deferred_get(key='test-key', default='test-default') == 'test-default'



# Generated at 2022-06-22 19:43:01.689165
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    v = list(range(10))
    CLIARGS._options = {'moose': v}
    assert cliargs_deferred_get('moose')() == v
    assert cliargs_deferred_get('moose', shallowcopy=True)() == v
    assert cliargs_deferred_get('moose', shallowcopy=True)() is not v
    assert cliargs_deferred_get('moose')() is v

# Generated at 2022-06-22 19:43:06.193817
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Unit test for function cliargs_deferred_get
    """
    def test_data_sets(test_data):
        """
        Create test data sets for shallow copy, normal copy, and default values
        """
        data_sets = {
            'normal': {
                'copy': test_data,
                'reference': test_data,
                'default': [],
            },
            'shallow copy': {
                'copy': test_data,
                'reference': test_data[:],
                'default': [],
            },
            'default': {
                'copy': [],
                'reference': [],
                'default': test_data,
            }
        }
        return data_sets

    string_data = [1, 2, 3]

# Generated at 2022-06-22 19:43:16.471350
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSet
    from ansible.module_utils.common.collections import is_sequence
    # If CLIARGS is immutable, resulting function should return the same value
    args = {'foo': 'bar', 'baz': ['bip']}
    assert cliargs_deferred_get('foo')(args) == args['foo']
    assert cliargs_deferred_get('baz')(args) == args['baz']
    # If CLIARGS is changed, resulting function returns new value
    args['foo'] = 'updated'
    assert cliargs_deferred_get('foo')(args) == args['foo']
    # shallowcopy is False (default)
    args['baz'].append('bop')

# Generated at 2022-06-22 19:43:22.502618
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_helper(key, value):
        # Test that we get back a callable
        assert callable(cliargs_deferred_get(key))
        # Test that the callable gets the value we expect back
        assert value == cliargs_deferred_get(key)()

    class Options(object):
        def __init__(self, opts):
            for k, v in opts.items():
                setattr(self, k, v)

    # Test normal case
    opts = Options({'a': 1})
    CLIARGS.from_options(opts)
    test_helper('a', opts.a)

    # Test with a shallow copy
    opts = Options({'a': [1]})
    CLIARGS.from_options(opts)

# Generated at 2022-06-22 19:43:31.929908
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    d = {'list': [1, 2, 3], 'set': set(['1', '2']), 'dict': {'key': 'value'}, 'nothing': None, 'scalar': 1}
    CLIARGS = CLIArgs(dict((k, v) for k, v in d.iteritems()))

    assert(cliargs_deferred_get('scalar')(()) == 1)
    assert(cliargs_deferred_get('nothing')(()) is None)
    assert(cliargs_deferred_get('list')(()) == [1, 2, 3])
    assert(cliargs_deferred_get('set')(()) == set(['1', '2']))
    assert(cliargs_deferred_get('dict')(()) == {'key': 'value'})


# Generated at 2022-06-22 19:43:42.955862
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class StubCliArgs(object):
        def __init__(self, value):
            self.value = value

    # Test with a list
    c = StubCliArgs([1, 2, 3])
    f = cliargs_deferred_get('value', shallowcopy=True)
    assert f() == [1, 2, 3]
    c.value[0] = 10
    assert f() == [1, 2, 3]

    # Test with a dict
    c = StubCliArgs({1: 2, 3: 4})
    f = cliargs_deferred_get('value', shallowcopy=True)
    assert f() == {1: 2, 3: 4}
    c.value[1] = 10
    assert f() == {1: 2, 3: 4}

# Generated at 2022-06-22 19:43:54.504197
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that a function is returned
    assert callable(cliargs_deferred_get('key'))
    # Test that it gets the given key
    assert 'test' == cliargs_deferred_get('test', 'key')({'test': 'test'})
    # Test that it gets the given key
    assert 'test' == cliargs_deferred_get('test', default='key')({'test': 'test'})
    # Test that it gets the default
    assert 'key' == cliargs_deferred_get('test', 'key')({})
    # Test that it gets the default
    assert 'key' == cliargs_deferred_get('test', default='key')({})
    # Test that it gets the default

# Generated at 2022-06-22 19:44:04.189839
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    example_options = {'icecream': ['banana', 'peanut butter']}
    cli_args = CLIArgs(example_options)
    _init_global_context(cli_args)
    assert cliargs_deferred_get('icecream') == example_options['icecream']
    assert cliargs_deferred_get('icecream', shallowcopy=True) == example_options['icecream']
    example_options['icecream'].append('chocolate')
    assert cliargs_deferred_get('icecream') == example_options['icecream']
    assert cliargs_deferred_get('icecream', shallowcopy=True) != example_options['icecream']

    example_options = {'icecream': {'scoop': 'chocolate', 'topping': 'whipped cream'}}
    cli

# Generated at 2022-06-22 19:44:15.356655
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''Test that cliargs_deferred_get creates a closure that returns the expected value
    '''
    global CLIARGS
    CLIARGS = CLIArgs({
        'foo': 1,
        'bar': {
            'baz': 2,
        },
        'buzz': [3, 4],
    })
    foo_defer = cliargs_deferred_get('foo')
    bar_defer = cliargs_deferred_get('bar', shallowcopy=True)
    buzz_defer = cliargs_deferred_get('buzz')

    assert foo_defer() == 1
    assert bar_defer() == {'baz': 2}
    assert buzz_defer() == [3, 4]
    CLIARGS['foo'] = 5
    assert foo_defer() == 5


# Generated at 2022-06-22 19:44:24.876907
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for cliargs_deferred_get"""
    global CLIARGS
    cliargs_dict = dict(foo='bar',  # String
                        baz=[True, False, True],  # Mutable Sequence
                        deep=[dict(alpha=1, beta=2)], # Mutable Mapping
                        )
    cliargs_dict_copy = dict(cliargs_dict)
    cliargs = CLIArgs(cliargs_dict)
    CLIARGS = cliargs
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True) == [True, False, True, ]
    assert cliargs_deferred_get('baz', shallowcopy=True) is not cliargs_dict['baz']
    assert cli

# Generated at 2022-06-22 19:44:26.948674
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == cliargs_deferred_get('check')()

# Generated at 2022-06-22 19:44:38.728828
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def set_some_args():
        """Set defaults in CLIARGS"""
        CLIARGS['some_key'] = 'Hello, World!!'
        CLIARGS['some_sequence'] = [1, 2, 3]
        CLIARGS['some_set'] = {1, 2, 3}
        CLIARGS['some_dict'] = {'a': 1, 'b': 2}

    def assert_basic_behavior():
        """Make sure we can get the basic behavior

        For example, that we can get previously set values from CLIARGS and we can get
        default values from ``default``
        """
        deferred_get = cliargs_deferred_get('some_key', default='Default')
        assert deferred_get() == 'Hello, World!!'

# Generated at 2022-06-22 19:44:48.883956
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    CLIARGS['foo'] = 'bar'

    def_val = cliargs_deferred_get('foo')

    assert def_val() == 'bar'

    def_val_default = cliargs_deferred_get('bar', default='baz')

    assert def_val_default() == 'baz'

    CLIARGS['list'] = ['a', 'b', 'c']

    def_val_list_copy = cliargs_deferred_get('list', shallowcopy=True)

    assert def_val_list_copy() == ['a', 'b', 'c']

    CLIARGS['set'] = set(['a', 'b', 'c'])

    def_val_set_copy = cliargs_deferred_get('set', shallowcopy=True)

    assert def_val_set_copy

# Generated at 2022-06-22 19:44:54.827944
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for cliargs_deferred_get"""
    from ansible.utils.context_objects import GlobalCLIArgs
    import copy
    import types

    # Test 1: test the closure is properly setup and behaves as we expect
    # Setup the test
    test_key = 'test_closure'
    test_value = ['test_closure']
    test_default = [1]
    expected_value = test_value[:]
    expected_default = test_default[:]
    cliargs = GlobalCLIArgs({test_key: test_value})

    # Get the closure
    test_closure = cliargs_deferred_get(test_key, default=test_default, shallowcopy=True)
    assert isinstance(test_closure, types.FunctionType)

    # Replace the GlobalCLIArgs
    global CLIARGS

# Generated at 2022-06-22 19:45:05.636618
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = GlobalCLIArgs({'key': ['value-1', 'value-2']})
    assert cliargs_deferred_get('key')() == ['value-1', 'value-2']
    assert cliargs_deferred_get('key', shallowcopy=True)() == ['value-1', 'value-2']
    assert cliargs_deferred_get('key', shallowcopy=True)() == ['value-1', 'value-2']  # shallow copy should not change source
    assert cliargs_deferred_get('key', default=None)() is None
    assert cliargs_deferred_get('key', default=None, shallowcopy=True)() is None
    assert cliargs_deferred_get('non-existing-key')() is None
    assert cli

# Generated at 2022-06-22 19:45:12.449602
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    def do_test(cliargs):
        # Plain get
        assert cliargs_deferred_get('foo')(), 'test'
        assert cliargs_deferred_get('bar')(), None
        assert cliargs_deferred_get('bar', default='blip')(), 'blip'
        assert cliargs_deferred_get('bar', default='blip', shallowcopy=True)(), 'blip'

        # Shallow copy
        cliargs['baz'] = [1, 2, 3]
        assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
        assert cliargs_deferred_get('baz')() is cliargs['baz']

        # Deep copy

# Generated at 2022-06-22 19:45:23.433346
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common._collections_compat import MutableSequence, MutableMapping
    import copy

    # Basic functionality
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': 'qux'})
    assert cliargs_deferred_get('foo')(), 'bar'
    assert cliargs_deferred_get('baz')(), 'qux'
    assert cliargs_deferred_get('BAZ')(), 'qux'
    assert cliargs_deferred_get('missing'), None
    assert cliargs_deferred_get('missing', 'default'), 'default'

    # Closure functionality

# Generated at 2022-06-22 19:45:30.130953
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_vars = {'foo': 'bar', 'baz': 10}
    _init_global_context(cli_vars)

    f = cliargs_deferred_get('foo')
    assert f() == 'bar'
    g = cliargs_deferred_get('baz')
    assert g() == 10
    h = cliargs_deferred_get('fubar')
    assert h() is None
    i = cliargs_deferred_get('fubar', default='foobar')
    assert i() == 'foobar'
    j = cliargs_deferred_get('foo', shallowcopy=True)
    assert j() == 'bar'

    l = cliargs_deferred_get('foo', shallowcopy=True)
    l()
    l()
    l()

# Generated at 2022-06-22 19:45:41.008571
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for cliargs_deferred_get"""
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.utils import to_bytes
    from ansible import constants as C

    # Test the setting of the default
    assert callable(cliargs_deferred_get('foo'))
    foo = cliargs_deferred_get('foo')
    assert cliargs_deferred_get('foo')() == foo()
    # Test the changing of the default
    assert cliargs_deferred_get('foo', default=123)() == 123
    # Test the getting of a value
    cli_args = {'foo': 42}
    _init_global_context(cli_args)

# Generated at 2022-06-22 19:45:41.536824
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-22 19:45:51.427137
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    global CLIARGS
    assert cliargs_deferred_get('abc')(), None
    CLIARGS = CLIArgs({'abc': 123})
    assert cliargs_deferred_get('abc')(), 123
    CLIARGS = CLIArgs({'abc': {'xyz': 456}})
    assert cliargs_deferred_get('abc')(), {'xyz': 456}
    assert cliargs_deferred_get('abc', shallowcopy=True)(), {'xyz': 456}
    CLIARGS = CLIArgs({'abc': [123, 456, 789]})
    assert cliargs_deferred_get('abc')(), [123, 456, 789]

# Generated at 2022-06-22 19:46:01.641381
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    def new_CLIARGS():
        return CLIArgs({'foo': 5, 'bar': 'baz', 'verbose': [1, 2, 3], 'roles': [{'bob': 1, 'joe': 2}]})

    # The function tests the function that returns a function.  It's a closure so
    # we need to reset CLIARGS before each test
    def test_func(expected, fn, cliargs):
        assert expected == fn()
        CLIARGS.data = cliargs

    def test_reuse_cliargs():
        cliargs = new_CLIARGS()
        # Test that twice in a row gets the same value
        test_func(5, cliargs_deferred_get('foo'), cliargs)

# Generated at 2022-06-22 19:46:06.669512
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Basic sanity test for function cliargs_deferred_get
    """
    # For this test, we need to set a global, so reset the global state
    global CLIARGS
    CLIARGS = CLIArgs({})

    CLIARGS["test"] = "test"
    assert cliargs_deferred_get(key='test')() == 'test'

# Generated at 2022-06-22 19:46:12.654826
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function ``cliargs_deferred_get``"""
    import copy

    class _GlobalCLIArgs(GlobalCLIArgs):
        # no need to do validation
        def __init__(self, args):
            super(_GlobalCLIArgs, self).__init__(dict(args))

    def check(default, orig):
        global CLIARGS
        if orig is None:
            orig = default
        CLIARGS = _GlobalCLIArgs(dict(a=orig))
        closure = cliargs_deferred_get('a', default=default)
        value = closure()
        assert value == orig
        if isinstance(orig, (set, frozenset, Mapping)):
            assert value is not orig
            assert copy.copy(value) == orig

# Generated at 2022-06-22 19:46:22.085985
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # First test where cliargs is not set
    assert cliargs_deferred_get('foo') is None
    fake_cliargs = {'foo': 'bar'}
    GlobalCLIArgs.set(fake_cliargs)
    assert cliargs_deferred_get('foo') is fake_cliargs['foo']
    assert cliargs_deferred_get('bar') is None
    assert cliargs_deferred_get('bar', 'baz') == 'baz'
    assert cliargs_deferred_get('bar', default='baz') == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True) is fake_cliargs['foo']
    assert cliargs_deferred_get('bar', shallowcopy=True) is None
    assert cliargs_deferred_

# Generated at 2022-06-22 19:46:32.122692
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # CLIARGS has not been set so the default value is returned
    assert cliargs_deferred_get('does_not_exist', 'foo', False) == 'foo'
    assert cliargs_deferred_get('does_not_exist', 'foo', True) == 'foo'

    # CLIARGS has been set so it is accessed
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({'does_not_exist': 'foo'})

    assert cliargs_deferred_get('does_not_exist', 'bar', False) == 'foo'
    assert cliargs_deferred_get('does_not_exist', 'bar', True) == 'foo'

# Generated at 2022-06-22 19:46:39.882159
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Tests that cliargs_deferred_get() correctly returns values from CLIARGS and
    correctly shallow copies data

    Args:
        None

    Returns:
        None

    Raises:
        AssertionError if cliargs_deferred_get() does not correctly return values from CLIARGS
        or correctly shallow copy data
    """
    class Obj(object):
        pass
    expected_value_1 = Obj()
    expected_value_2 = 'value1'
    expected_value_3 = ['value2']
    expected_value_4 = {'value3': 'value4'}
    expected_value_5 = None
    expected_value_6 = {
        'key1': ['value1']
    }

# Generated at 2022-06-22 19:46:50.857146
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with a deferred copy
    CLIARGS.args = {'foo': 'bar'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

    CLIARGS.args = {'foo': ['bar']}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']

    CLIARGS.args = {'foo': {'bar': 'baz'}}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'bar': 'baz'}

    CLIARGS.args = {'foo': frozenset('bar')}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == frozenset('bar')

    # Test with a non-copy

# Generated at 2022-06-22 19:46:59.848546
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # Make sure the inner() function just returns the value
    assert CLIARGS._GlobalCLIArgs__shallow_copy is False
    assert cliargs_deferred_get('foo')() == 'default'

    # Make sure we can get the value from a real CLIArgs object
    CLIARGS._GlobalCLIArgs__cli_args = {'foo': 'bar'}
    assert cliargs_deferred_get('foo')() == 'bar'

    # Make sure we can get the default
    CLIARGS._GlobalCLIArgs__cli_args = {}
    assert cliargs_deferred_get('foo', default='baz')() == 'baz'

    # Make sure we can get a subset of the dict copy

# Generated at 2022-06-22 19:47:06.336518
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    assert cliargs_deferred_get('vault_password_file')() is None
    CLIARGS._values['vault_password_file'] = 'test'
    assert cliargs_deferred_get('vault_password_file')() == 'test'
    assert cliargs_deferred_get('vault_password_file', shallowcopy=True)() == 'test'

# Generated at 2022-06-22 19:47:16.446145
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with CLIARGS not being a singleton
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    m = CLIArgs({})
    cliargs_deferred_get('no_key')(), cliargs_deferred_get('no_key', default='default')(),
    cliargs_deferred_get('no_key', default='default', shallowcopy=True)() == 'default',

    m = GlobalCLIArgs.from_options({'key': 'value'})
    cliargs_deferred_get('key')(), cliargs_deferred_get('key', default='default')(),

# Generated at 2022-06-22 19:47:27.248285
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    d = {'a': 1}
    global CLIARGS

    # Test getting a value from cliargs
    CLIARGS = GlobalCLIArgs.from_options({'a': 1, 'c': 3})
    assert 3 == cliargs_deferred_get('c')()

    # Test using the default value
    assert 4 == cliargs_deferred_get('b', default=4)()

    # Test no shallow copy
    value = cliargs_deferred_get('d', default=d, shallowcopy=False)()
    assert value is d
    value['b'] = 2
    assert 'b' in d

    # Test shallow copy a sequence
    value = cliargs_deferred_get('e', default=d, shallowcopy=True)()
    assert value is not d

# Generated at 2022-06-22 19:47:36.995030
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({"foo": "bar", "bar": [1, 2], "baz": {"a": 1}, "x": "y"})

    assert cliargs_deferred_get("foo")() == "bar"
    assert cliargs_deferred_get("bar")() == [1, 2]
    assert cliargs_deferred_get("baz")() == {"a": 1}

    assert cliargs_deferred_get("foo", shallowcopy=True)() == "bar"
    assert cliargs_deferred_get("bar", shallowcopy=True)() != [1, 2]
    assert cliargs_deferred_get("baz", shallowcopy=True)() != {"a": 1}

# Generated at 2022-06-22 19:47:48.020982
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': 2, 'c': [4, 5, 6], 'd': {'e': None}})
    # Test default
    assert cliargs_deferred_get('f')() is None
    assert cliargs_deferred_get('f', [])(), []
    # Test shallow copy
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('b', shallowcopy=True)() == 2
    assert cliargs_deferred_get('c', shallowcopy=True)() == [4, 5, 6]
    assert cliargs_deferred_get('d', shallowcopy=True)() == {'e': None}
    # Test changing original  -- basic types

# Generated at 2022-06-22 19:47:57.101676
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def foo():
        return 'bar'
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({})
    assert cliargs_deferred_get('no_exist') is None
    assert cliargs_deferred_get('no_exist', 'a string') == 'a string'
    assert cliargs_deferred_get('no_exist', default=foo()) == 'bar'
    assert cliargs_deferred_get('no_exist', foo()) == 'bar'

    CLIARGS = GlobalCLIArgs.from_options({'a_string': 'baz'})
    assert cliargs_deferred_get('a_string') == 'baz'
    assert cliargs_deferred_get('a_string', 'a string') == 'baz'
    assert cliargs_

# Generated at 2022-06-22 19:48:03.677928
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.context_objects import CLIArgs

    cli_args = CLIArgs({'foo': 'bar'})
    def_get = cliargs_deferred_get('foo')

    assert def_get() == 'bar'

    cli_args.bar = {'ham': 'spam'}
    def_get = cliargs_deferred_get('bar', shallowcopy=True)
    assert def_get() == {'ham': 'spam'}

# Generated at 2022-06-22 19:48:14.142895
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with CLIARGS being the singleton
    cliargs = CLIArgs({'foo': 'bar'})
    a = cliargs_deferred_get('foo')
    assert a() == 'bar'
    # Test with CLIARGS being a fresh CLIArgs
    cliargs = CLIArgs({'foo': 'bar'})
    global CLIARGS
    old_cliargs = CLIARGS

# Generated at 2022-06-22 19:48:22.553840
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'a': 5,
                'b': [1, 2, 3],
                'c': {'d': 4, 'e': 5},
                }
    _init_global_context(cli_args)
    assert cliargs_deferred_get('a')() == 5
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 4, 'e': 5}
    assert cliargs_deferred_get('c', default='foo')() == {'d': 4, 'e': 5}
    assert cliargs_deferred_get('d', default='foo')() == 'foo'
    assert cliargs_deferred_get('a', shallowcopy=True)() == 5

# Generated at 2022-06-22 19:48:33.340446
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Make sure the generated function works the same way as using the GlobalCliArgs directly"""
    # TODO: Put this in tests/ and use a proper test framework once we have one
    cli_args = {'one': 1, 'two': [2, 2], 'three': {'four': 4}}
    _init_global_context(cli_args)

    # Test copy of list
    assert cliargs_deferred_get('two', shallowcopy=True)() == cli_args['two']
    assert cliargs_deferred_get('two', shallowcopy=True)() is not cli_args['two']

    # Test copy of mapping
    assert cliargs_deferred_get('three', shallowcopy=True)() == cli_args['three']

# Generated at 2022-06-22 19:48:41.965519
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.context_objects import CLIArgs
    my_dict = ImmutableDict()
    global CLIARGS
    CLIARGS = CLIArgs({'key1': 'value1', 'key2': [1, 2, 3]}, my_dict)
    get_value1 = cliargs_deferred_get('key1')
    get_value2 = cliargs_deferred_get('key2', shallowcopy=True)
    get_value3 = cliargs_deferred_get('key3')
    get_value4 = cliargs_deferred_get('key3', default='default_value')
    get_value5 = cliargs_deferred_get('key3', shallowcopy=True, default='default_value')

# Generated at 2022-06-22 19:48:50.872847
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('nope')() is None
    assert cliargs_deferred_get('nope', default=42)() == 42

    CLIARGS['list'] = [1, 2, 3]
    assert cliargs_deferred_get('list')() == [1, 2, 3]
    assert cliargs_deferred_get('list', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('list', shallowcopy=False)() == [1, 2, 3]

# Generated at 2022-06-22 19:49:01.650619
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test to test function ``cliargs_deferred_get``"""
    CLIARGS.clear()
    CLIARGS._options = {'answer': 42}
    assert cliargs_deferred_get('answer')() == 42
    assert cliargs_deferred_get('answer', shallowcopy=True)() == 42
    CLIARGS._options = {'answer': [42]}
    assert cliargs_deferred_get('answer')() == [42]
    assert cliargs_deferred_get('answer', shallowcopy=True)() == [42]
    assert cliargs_deferred_get('answer', shallowcopy=True)() != [[42]]
    CLIARGS._options = {'answer': [42]}
    assert cliargs_deferred_get('answer')() == [42]
    assert cli

# Generated at 2022-06-22 19:49:12.388731
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def func(cli_args):
        global CLIARGS
        def_get = cliargs_deferred_get
        if cli_args:
            from ansible.module_utils.common.collections import CLICollection
            CLIARGS = CLICollection(cli_args, ['extra_arg'])
            v = cliargs_deferred_get('extra_arg')
        else:
            v = cliargs_deferred_get('no_arg')
        return v

    arg_values = (True, False, None, 10, 'foo')
    assert func(dict()) == func(None)
    for arg_value in arg_values:
        defarg_value = func(dict(extra_arg=arg_value))
        v = func(dict(extra_arg=arg_value))

# Generated at 2022-06-22 19:49:21.296750
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # Test getting from a non-global context object that doesn't support shallow copies
    cli_args = CLIArgs({'foo': 'bar'})
    get_foo = cliargs_deferred_get('foo')
    assert get_foo() == cli_args['foo']
    assert get_foo() is cli_args['foo']
    get_foo_shallow = cliargs_deferred_get('foo', shallowcopy=True)
    assert get_foo_shallow() == cli_args['foo']
    assert get_foo_shallow() is cli_args['foo']

    # Test getting a global context object that supports shallow copies
    cli_args = CLIArgs({'foo': 'bar'}, is_global=True)
    get_foo

# Generated at 2022-06-22 19:49:32.060908
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Test with no existing CLIARGS object
    get_foo = cliargs_deferred_get('foo', 'bar')
    CLIARGS = CLIArgs({})
    assert get_foo() == 'bar'

    # Test with a CLIARGS object but no pre-existing 'foo'
    # Also test that that the mutable list is copied and not just referenced
    get_foo = cliargs_deferred_get('foo', 'bar')
    CLIARGS = CLIArgs({'a': 'b'})
    assert get_foo() == 'bar'
    # Ensure it's a new object and not just a reference
    assert id(get_foo()) != id('bar')
    assert get_foo() is not 'bar'


# Generated at 2022-06-22 19:49:42.050084
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Tests for cliargs_deferred_get"""
    cliargs_1 = CLIArgs({'key_1': 'value_1'})
    cliargs_2 = CLIArgs({'key_1': 'value_1', 'key_2': 'value_2'})
    args_1 = cliargs_deferred_get('key_1', 'value_0')
    assert args_1() == 'value_1'
    args_2 = cliargs_deferred_get('key_2', 'value_0')
    assert args_2() == 'value_0'

# Generated at 2022-06-22 19:49:53.686601
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Test replacement of the outer variable
    from_options = {'a': {'b': 'c', 'd': [1, 2, 3], 'e': (4, 5, 6), 'f': MutableMapping({'g': 'h'}), 'i': MutableMapping({'j': 'k'}), 'l': MutableMapping({'m': 'n'})}}
    CLIARGS = CLIArgs.from_options(from_options)

    a = cliargs_deferred_get('a')
    assert a() is from_options['a']

    b = cliargs_deferred_get('a', shallowcopy=True)
    assert b() is not from_options['a']

# Generated at 2022-06-22 19:50:00.920616
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update(
        ansible_inventory=['foo'],
        ansible_inventory_defaults=['foo'],
        ansible_inject_facts=['foo'],
        ansible_ssh_common_args=['foo'],
        ansible_connection_plugins=['foo'],
        ansible_lookup_plugins=['foo'],
        ansible_filter_plugins=[('foo', 'fake_path')],
        ansible_vars_plugins=['foo'],
        ansible_action_plugins=[('foo', 'fake_action_path')],
        ansible_shell_executable=['bar', 'baz'],
        ansible_python_interpreter=['bar', 'baz'])


# Generated at 2022-06-22 19:50:11.465593
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeArgs:
        class Connection:
            class _fake_args_value:
                pass

        connection = Connection()
        connection._fake_args_value = FakeArgs.connection._fake_args_value

    class FakeCLIARGS:
        def get(self, key, default=None):
            return getattr(FakeArgs, key, default)

    fake_args = FakeCLIARGS()

    def fake_init_args(args):
        def inner_fake_init_args():
            return args
        return inner_fake_init_args

    cli_args = fake_init_args({'foo': 'bar'})
    assert cliargs_deferred_get('foo')(**{'default': None})() == 'bar'

# Generated at 2022-06-22 19:50:21.653424
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({})
    cliargs['foo'] = 'bar'
    cliargs['baz'] = [1, 2, 3]
    cliargs['qux'] = dict(foo='bar')
    cliargs['spam'] = set(['foo', 'bar'])

    get_bar = cliargs_deferred_get('foo')
    get_baz = cliargs_deferred_get('baz')
    get_qux = cliargs_deferred_get('qux')
    get_spam = cliargs_deferred_get('spam')

    assert get_bar() == 'bar'
    assert get_baz() == [1, 2, 3]
    assert get_qux() == dict(foo='bar')
    assert get_spam() == set

# Generated at 2022-06-22 19:50:33.078735
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import unittest
    class TestCliargsDeferredGet(unittest.TestCase):
        def test_shallow_copy(self):
            a = {'int': 1,
                 'ordereddict': {'key': 'value'},
                 }

            initial_a = a.copy()
            get_a = cliargs_deferred_get('int')
            self.assertEqual(get_a(), 1)
            self.assertEqual(a, initial_a)

            initial_a = a.copy()
            get_a = cliargs_deferred_get('ordereddict', shallowcopy=True)
            self.assertEqual(get_a(), {'key': 'value'})
            self.assertEqual(a, initial_a)


# Generated at 2022-06-22 19:50:41.769371
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=missing-docstring,protected-access
    a_list = [1, 2, 3]
    a_dict = {'a': 1, 'b': 2, 'c': 3}
    a_set = {1, 2, 3}
    a_str = 'abc'
    a_int = 123

    def assert_value(expected, value):
        assert value == expected, 'Got {} expected {}'.format(value, expected)

    def assert_shallow(expected, shallow_expected, value):
        assert value == expected, 'Got {} expected {}'.format(value, expected)
        assert value is not expected, 'Got {} but expected shallow copy'.format(value)
        assert value == shallow_expected, 'Got {} expected {}'.format(value, expected)

# Generated at 2022-06-22 19:50:48.489309
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_inner(initial, final):
        global CLIARGS
        CLIARGS = CLIArgs(initial)
        assert (final == cliargs_deferred_get('b', default='def')())
    test_inner({'a': 1, 'b': 'bval'}, 'bval')
    test_inner({'a': 1}, 'def')
    test_inner({'a': 1, 'b': [1,2,3]}, [1,2,3])
    test_inner({'a': 1, 'b': [1,2,3]}, [1,2,3])
    test_inner({'a': 1, 'b': {'b1': 'bval'}}, {'b1': 'bval'})

# Generated at 2022-06-22 19:50:56.008132
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    # test closure as well as GlobalCLIArgs.from_options
    args = {'help': True, 'inventory': '/foo.inv'}
    cliargs = CLIArgs(args)
    globalcliargs = GlobalCLIArgs.from_options(cliargs)
    # Note that this is why we created the closure: we need to refer to the same object
    # before and after the GlobalCLIArgs.from_options call
    assert cliargs is cliargs_deferred_get.__closure__[1].cell_contents
    get_help = cliargs_deferred_get('help')
    get_inventory = cliargs_deferred_get('inventory')
    assert globalcliargs is get_help.__closure__[1].cell_cont

# Generated at 2022-06-22 19:51:02.724920
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Ensure values set on CLIArgs are returned as expected"""
    global CLIARGS
    CLIARGS = CLIArgs({})
    CLIARGS['somearg'] = 'somevalue'

    assert cliargs_deferred_get('somearg')() == 'somevalue'
    assert cliargs_deferred_get('someotherarg')() is None
    assert cliargs_deferred_get('someotherarg', 'default')() == 'default'

    CLIARGS['someotherarg'] = 5

    assert cliargs_deferred_get('someotherarg')() == 5
    assert cliargs_deferred_get('someotherarg', 'default')() == 5

    CLIARGS['someargs'] = [1, 2, 3]
