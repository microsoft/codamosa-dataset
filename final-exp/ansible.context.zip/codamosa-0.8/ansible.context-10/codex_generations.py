

# Generated at 2022-06-10 23:02:07.136185
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def cli_args():
        return {'foo': 'bar'}

    # NOTE: we are not testing that the correct value gets returned since
    # this would require ``_init_global_context`` being run first.  We just
    # care that this is bound correctly.
    #
    # Also, the closure is meant to be dynamically bound to the new
    # ``CLIARGS`` instance and not hard-bound to whatever ``CLIARGS``
    # happens to be right now.
    with CLIARGS.values.swap(cli_args()):
        assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'baz'

# Generated at 2022-06-10 23:02:17.097872
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    class _MockCliArgs(Mapping):
        def __init__(self):
            self._data = {}

        def __getitem__(self, key):
            return self._data[key]

        def __setitem__(self, key, value):
            self._data[key] = value

        def __iter__(self):
            return iter(self._data)

        def __len__(self):
            return len(self._data)

    class _MockSingletonCliArgs(_MockCliArgs):
        def __init__(self, args):
            self._data = {k: v for k, v in args.items()}


# Generated at 2022-06-10 23:02:23.558530
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    global CLIARGS # pylint: disable=global-statement
    CLIARGS = CLIArgs({})
    # pylint: disable=unused-variable
    fn = cliargs_deferred_get('foo')
    assert fn() is None

    CLIARGS['foo'] = 'bar'
    assert fn() == 'bar'

# Generated at 2022-06-10 23:02:27.066141
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Simple function that lets us test getting CLIARGS keys without having to
    # worry about creating a whole real world CLIARGS object
    def get_cliargs_key(key, default=None):
        return cliargs_deferred_get(key, default)()

    # Test basic functionality
    CLIARGS.update({'spam': 'eggs'})
    assert get_cliargs_key('spam') == 'eggs'
    assert get_cliargs_key('foo', 'bar') == 'bar'

    # Test shallow copy
    CLIARGS['list'] = [1, 2, 3]
    assert get_cliargs_key('list', shallowcopy=True) == [1, 2, 3]

    # Test shallow copy
    CLIARGS['dict'] = {'spam': 'eggs'}
    assert get

# Generated at 2022-06-10 23:02:34.975605
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['my_arg'] = 'my value'

    assert 'my_arg' in CLIARGS
    assert cliargs_deferred_get('my_arg', default='default') == 'my value'
    assert cliargs_deferred_get('my_arg', default='default', shallowcopy=True) == 'my value'
    # Simulate a copy of the argument list
    _init_global_context(dict(CLIARGS))
    assert 'my_arg' in CLIARGS
    assert cliargs_deferred_get('my_arg', default='default') == 'my value'
    assert cliargs_deferred_get('my_arg', default='default', shallowcopy=True) == 'my value'

    del CLIARGS['my_arg']

# Generated at 2022-06-10 23:02:45.696754
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

# Generated at 2022-06-10 23:02:52.356881
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = GlobalCLIArgs({'VALUE': 'value'})
    inner = cliargs_deferred_get('VALUE')
    assert inner() == 'value'
    inner = cliargs_deferred_get('MISSING')
    assert inner() is None
    inner = cliargs_deferred_get('MISSING', 'default')
    assert inner() == 'default'

# Generated at 2022-06-10 23:03:03.836461
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MockContext(object):
        def __init__(self):
            self.data = {'key1': 'value1', 'key2': {'key': 'value'}}

        def get(self, key, default=None):
            return self.data.get(key, default)

    c = MockContext()
    # No shallow copy
    get_key1 = cliargs_deferred_get('key1')
    assert get_key1() is 'value1'
    # Shallow copy
    get_key2 = cliargs_deferred_get('key2', shallowcopy=True)
    assert get_key2() is c.data['key2']
    assert get_key2() != c.data['key2']

# Generated at 2022-06-10 23:03:15.435915
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import mock

    class C(object):
        def __init__(self, arg):
            self.arg = arg

    def make_mock_args(mock_args):
        # return a patch that can be used to modify the CLIARGS
        patcher = mock.patch('ansible.context.CLIARGS', mock_args)
        patcher.start()
        return patcher

    args = mock.Mock()

    args.get = lambda key, default=None: mock_args[key]

    # test default behavior
    mock_args = {'a': 1, 'b': 2}
    with make_mock_args(args):
        dga = cliargs_deferred_get('a')
        assert dga() == mock_args['a'], 'default behavior is to pass through the value'
       

# Generated at 2022-06-10 23:03:25.891708
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Note: It is assumed that this unit test is run only in the context of a functional test suite
    # so there is no need to reset the global CLIARGS back to the empty version when we are done
    from ansible.utils.context_objects import BaseCLIArgs
    class MockCLIArgs(BaseCLIArgs):
        def __init__(self, parser):
            self.finalized = True
            super(MockCLIArgs, self).__init__(parser)

    class MockArgParse(object):
        def __init__(self, namespace):
            self.namespace = namespace

        def parse_known_args(self, args):
            return self.namespace, args

    # Test if we get the default value from the initial context
    args = MockArgParse({})

# Generated at 2022-06-10 23:03:37.631424
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    from ansible.module_utils.common._collections_compat import Mapping

    class Foo(Mapping):
        pass
    foo = Foo({})
    # pylint: enable=unused-variable

    # Make sure that it doesn't return a value in the case where no key is specified
    # and CLIARGS is not set yet.
    assert cliargs_deferred_get()() is None

    # Check that it returns default with no key specified
    _init_global_context({})
    assert cliargs_deferred_get()() is None
    assert cliargs_deferred_get()(default=42) == 42

    # Check that it returns the value with no key specified
    _init_global_context({'foo': 42})
    assert cliargs

# Generated at 2022-06-10 23:03:48.647174
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.constants as C
    import sys
    import io
    import tempfile
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.cache.plugin import FactCache
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleError
    from ansible.cli import CLI
    from ansible.executor.task_queue_manager import TaskQueueManager



# Generated at 2022-06-10 23:03:57.271952
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': {'a': 'b'}})
    assert cliargs_deferred_get('foo', default={})() == {'a': 'b'}
    assert cliargs_deferred_get('foo', default={}, shallowcopy=True)() == {'a': 'b'}
    CLI

# Generated at 2022-06-10 23:04:06.853638
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""

    # function in context objects module
    from ansible.utils.context_objects import (
        CliArgs,
        ContextObject,
        ContextObjectException,
        GlobalCLIArgs,
    )

    def test_options(options, key, default=None, shallcopy=False, expected=None):
        """Unit test for function cliargs_deferred_get

        :kw options: dict with command line options
        :kw key: key to look up
        :kw default: default value
        :kw shallowcopy: whether to copy result or not
        :kw expected: expected result from cliargs_deferred_get
        """

        # get context object based on cli options
        cliargs = GlobalCLIArgs.from_options(CliArgs(options))

# Generated at 2022-06-10 23:04:19.228111
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def set_value(value):
        global CLIARGS
        CLIARGS['var'] = value

    CLIARGS['var'] = 3
    assert cliargs_deferred_get('var')() == 3

    set_value(4)
    assert cliargs_deferred_get('var')() == 4

    set_value(['1', '2'])
    assert cliargs_deferred_get('var')() == ['1', '2']
    assert cliargs_deferred_get('var', shallowcopy=True)() == ['1', '2']

    set_value({'a': 'b'})
    assert cliargs_deferred_get('var')() == {'a': 'b'}

# Generated at 2022-06-10 23:04:27.577050
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''
    Test that cliargs_deferred_get generates a closure over getting
    keys from CLIARGS
    '''
    def check_value(name, out, default=None, shallowcopy=False):
        '''
        A helper function to check that the closure returned gives
        the expected values
        '''
        closure = cliargs_deferred_get(name, default, shallowcopy)

        assert closure() == out

    #
    # Initialize the CLIARGS
    #
    _init_global_context({'foo': 'bar', 'baz': 'qux', 'list': [1, 2, 3], 'dict': {'a': 1}})

    check_value('foo', 'bar')
    check_value('bar', 'non-existent-key', default='non-existent-key')
    check_

# Generated at 2022-06-10 23:04:37.994989
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get()"""
    def test_func(input_dict, key, default, shallowcopy, expected):
        """Function to be tested"""
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(input_dict)
        test_param = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)
        assert test_param() == expected

    test_func({'key': 'value'}, 'key', 'def', False, 'value')
    test_func({}, 'key', 'def', False, 'def')
    test_func({'key': {1, 2, 3}}, 'key', 'def', False, {1, 2, 3})

# Generated at 2022-06-10 23:04:49.516887
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    assert cliargs_deferred_get('foo') == None
    assert cliargs_deferred_get('foo', 'bar') == 'bar'
    assert cliargs_deferred_get('foo', default='bar') == 'bar'

    CLIARGS = GlobalCLIArgs.from_options({'foo': 'baz'})
    assert cliargs_deferred_get('foo') == 'baz'
    assert cliargs_deferred_get('foo', 'bar') == 'baz'
    assert cliargs_deferred_get('foo', default='bar') == 'baz'

    CLIARGS = GlobalCLIArgs.from_options({'foo': [1, 2, 3]})

# Generated at 2022-06-10 23:04:52.407379
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get

    This module is unittested by the test_cliargs because we don't want to
    duplicate the tests
    """
    pass

# Generated at 2022-06-10 23:04:59.276003
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = {
        'foo': 'bar',
        'baz': {
            'qux': 'quux'
        },
        'quux': [1, 2, 3]
    }
    _init_global_context(cliargs)

    # Normal
    assert 'bar' == cliargs_deferred_get('foo')()
    assert 'baz' == cliargs_deferred_get('baz')()
    assert {'qux': 'quux'} == cliargs_deferred_get('baz')()

    # Default
    assert 'quuz' == cliargs_deferred_get('corge', default='quuz')()

    # Shallow Copy
    baz = cliargs_deferred_get('baz', shallowcopy=True)()

# Generated at 2022-06-10 23:05:09.479990
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert CLIARGS.get('foo') is None
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo')(default='bar') == 'bar'
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    CLIARGS.foo = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    CLIARGS.foo = ['bar', 'baz']
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIAR

# Generated at 2022-06-10 23:05:17.667052
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    expected_list = [1, 2, 3]
    expected_dict = {'a': 1, 'b': 2, 'c': 3}
    expected_set = {1, 2, 3}
    expected_int = 1

    # Check initial state
    assert CLIARGS == {}

    # Test where key is not present
    assert cliargs_deferred_get("notpresent", default="default") == "default"

    # Test where key is present
    CLIARGS.update(dict(listitem=expected_list, dictitem=expected_dict, setitem=expected_set, intitem=expected_int))
    # Test that returned value is equal
    assert cliargs_deferred_get("listitem") == expected_list
    assert cliargs_deferred_get("dictitem") == expected_dict
    assert cliargs

# Generated at 2022-06-10 23:05:28.035227
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import unittest
    import inspect

    class CliArgsDeferredTestCase(unittest.TestCase):
        def setUp(self):
            # Note that this is normally created by Ansible's main()
            global CLIARGS
            CLIARGS = CLIArgs({'foo': 'bar', 'baz': ['1', '2']})

        def tearDown(self):
            del CLIARGS

        def test_get(self):
            deferred_get = cliargs_deferred_get('foo')
            self.assertEqual(deferred_get(), 'bar')
            self.assertEqual(deferred_get(), 'bar')
            self.assertIs(deferred_get(), 'bar')
            deferred_get = cliargs_deferred_get('baz')

# Generated at 2022-06-10 23:05:34.076085
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': ['1', '2']})
    field_attr = cliargs_deferred_get('a', shallowcopy=True)
    assert field_attr() == ['1', '2']
    CLIARGS['a'].append('3')
    assert field_attr() == ['1', '2']

# Generated at 2022-06-10 23:05:43.581414
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable

    cli_args = CLIArgs({'some_key': 1})

    assert cliargs_deferred_get('some_key')() == 1
    assert cliargs_deferred_get('other_key', default=1)() == 1
    assert cliargs_deferred_get('other_key')() is None

    assert cliargs_deferred_get('some_key', shallowcopy=True)() == 1
    assert cliargs_deferred_get('some_list', default=[], shallowcopy=True)() == []
    assert cliargs_deferred_get('some_key', shallowcopy=False)() == 1
    assert cliargs_deferred_get('some_key', shallowcopy=False)() == 1

    assert cliargs_deferred_

# Generated at 2022-06-10 23:05:53.799295
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = GlobalCLIArgs(dict(a=1, b=2, c=[1, 2, 3], d=dict(a=1, b=2)))
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == 2
    assert cliargs_deferred_get('b', default=None)() == 2
    assert cliargs_deferred_get('b', default=333)() == 2
    assert cliargs_deferred_get('missing')() is None
    assert cliargs_deferred_get('missing', default=333)() == 333
    assert cliargs_deferred_get('c')() == [1, 2, 3]

# Generated at 2022-06-10 23:05:59.274504
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'key': 'value', 'list': [1, 2, 3, 4], 'dict': {'key': 'value'}, 'set': {1, 2, 3, 4}})
    assert cliargs_deferred_get('key', 'default')() == 'value'
    assert cliargs_deferred_get('otherkey', 'default')() == 'default'
    assert cliargs_deferred_get('list')() == [1, 2, 3, 4]
    assert cliargs_deferred_get('dict')() == {'key': 'value'}
    assert cliargs_deferred_get('set')() == {1, 2, 3, 4}


# Generated at 2022-06-10 23:06:06.574694
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.tests.unit.compat.unittest import TestCase

    class TestInfo(TestCase):
        def setUp(self):
            self.expected_dict = {'first-key': 1, 'second_key': '2'}
            self.expected_list = [1, 'two', 'III']

            patcher = patch('ansible_collections.ansible.community.plugins.module_utils.context.GlobalCLIArgs.__new__', wraps=GlobalCLIArgs)
            self.addCleanup(patcher.stop)
            self.GlobalCLIArgs_new_mock = patcher.start()


# Generated at 2022-06-10 23:06:13.346547
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for the closure cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo')(shallowcopy=True) == 'bar'
    assert cliargs_deferred_get('foo')(default='baz') == 'bar'
    assert cliargs_deferred_get('baz')(default='baz') == 'baz'
    assert cliargs_deferred_get('foo')(default='baz') == 'bar'
    assert cliargs_deferred_get('baz')(default='baz') == 'baz'

# Generated at 2022-06-10 23:06:23.968634
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'foo': 'bar'})
    cliargs_deferred_get_foo = cliargs_deferred_get('foo', default='default')
    cliargs_deferred_get_bar = cliargs_deferred_get('bar', default='default')
    cliargs_deferred_get_shallow = cliargs_deferred_get('foo')
    cliargs_deferred_get_deep = cliargs_deferred_get('foo', shallowcopy=True)

    assert cliargs_deferred_get_foo() == 'bar'
    assert cliargs_deferred_get_bar() == 'default'
    assert cliargs_deferred_get_shallow() == 'bar'
    assert cliargs_deferred_get_deep

# Generated at 2022-06-10 23:06:41.009452
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    original_args = dict(one=1, two=2, three=3)
    global CLIARGS
    CLIARGS = CLIArgs(original_args)
    assert cliargs_deferred_get('one')() is 1
    assert cliargs_deferred_get('four')() is None
    assert cliargs_deferred_get('four', 4)() is 4
    # Ensure that immutable types are still immutable after getting them
    # with the cliargs getter
    assert cliargs_deferred_get('one', shallowcopy=True)() is 1
    # Ensure that mutable types are copied
    assert cliargs_deferred_get('two', shallowcopy=True)() == 2
    assert cliargs_deferred_get('three', shallowcopy=True)() == 3
    two = cliargs_def

# Generated at 2022-06-10 23:06:51.104972
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Verify that if we use a key that is not in the cliargs it returns the
    # default given
    # Use a non-default, non-shallow copy value as the default
    default_inner_value = [1,2,3]

    c = cliargs_deferred_get('foo', default=default_inner_value)
    assert callable(c)
    assert c() is default_inner_value
    # Verify that the default is cloned if a shallow copy is requested
    c = cliargs_deferred_get('foo', default=default_inner_value, shallowcopy=True)
    assert callable(c)
    assert c() is not default_inner_value
    assert c() == default_inner_value

    # Verify that we can get a non-default value from the cliargs
    cliargs_

# Generated at 2022-06-10 23:06:59.036933
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('FOO')(), None
    assert cliargs_deferred_get('FOO', 3)(), 3
    CLIARGS = CLIArgs({'FOO': 0})
    assert cliargs_deferred_get('FOO')(), 0
    assert cliargs_deferred_get('FOO', 3)(), 0
    assert cliargs_deferred_get('FOO', shallowcopy=True)(), 0

# Generated at 2022-06-10 23:07:07.265749
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test ``CLIARGS`` with a dict"""
    # pylint: disable=protected-access
    global CLIARGS
    cli_args = {'vars': {'foo': 'bar'}}
    CLIARGS = CLIArgs(cli_args)

    deferred_var = cliargs_deferred_get('vars', {})()
    assert deferred_var['foo'] == 'bar', deferred_var

    # Now test the shallow copy works
    deferred_var['foo'] = 'baz'
    assert cli_args['vars']['foo'] == 'baz', cli_args
    assert deferred_var['foo'] == 'baz', deferred_var

    # Now test that we can replace CLIARGS and this still works
    cli_args['vars']['foo'] = 'qux'

# Generated at 2022-06-10 23:07:17.683908
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    orig = CLIARGS

# Generated at 2022-06-10 23:07:29.020673
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test: Bound to a CLIArgs instance as a function
    cliargs = CLIArgs({'some_string': 'abcdef', 'some_list': [1, 2, 3]})
    assert cliargs_deferred_get('some_string')() == 'abcdef'
    assert cliargs_deferred_get('some_list')() == [1, 2, 3]
    assert cliargs_deferred_get('some_list', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('some_list', shallowcopy=True)() is not [1, 2, 3]
    assert cliargs_deferred_get('some_dict', {'blah': 'gah'})() == {'blah': 'gah'}
    assert cliargs_deferred

# Generated at 2022-06-10 23:07:30.046500
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-10 23:07:38.881623
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the default value
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test getting from CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test the shallow copy
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not [1, 2, 3]

# Generated at 2022-06-10 23:07:49.640224
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MockCliArgs(object):
        _defaults = {'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'quux': 'quuz'}}

        def __getitem__(self, key):
            return self._defaults[key]

        def __setitem__(self, key, value):
            self._defaults[key] = value

        def get(self, key, default=None):
            return self._defaults.get(key, default)

    def _t(key, default):
        mcliarsgs = MockCliArgs()
        global CLIARGS
        CLIARGS = mcliarsgs
        getter = cliargs_deferred_get(key, default)
        return getter()


    assert _t('foo', 'bar') == 'bar'

# Generated at 2022-06-10 23:07:58.764543
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Create a dummy CLIArgs
    class MyCLIArgs(CLIArgs):
        def __init__(self):
            self._options = {'ANSIBLE_DEBUG': True}

    global CLIARGS
    old_cliargs = CLIARGS
    CLIARGS = MyCLIArgs()

    assert cliargs_deferred_get('ANSIBLE_DEBUG')()
    assert cliargs_deferred_get('ANSIBLE_DEBUG', False)()
    assert cliargs_deferred_get('ANSIBLE_DEBUG', default=False)()
    assert not cliargs_deferred_get('ANSIBLE_NODEBUG')()
    assert cliargs_deferred_get('ANSIBLE_NODEBUG', True)()
    assert cliargs_deferred_get('ANSIBLE_NODEBUG', default=True)()

   

# Generated at 2022-06-10 23:08:23.243601
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    # Build and save the CLIARGS singleton
    with pytest.raises(AttributeError):
        global_cliargs_init('--no-logging')

    # Make sure we can get the value
    assert cliargs_deferred_get('no_logging')()

    # Make sure we can get the default
    assert not cliargs_deferred_get('no_logging', default=False)()

    # Make sure we can get the value of a different key
    assert not cliargs_deferred_get('diff_key', default=False)()

    # Make sure we can do shallow copy
    assert not cliargs_deferred_get('no_logging', default=False, shallowcopy=True)()



# Generated at 2022-06-10 23:08:34.146172
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    cli_args = {'1': [], '2': []}
    func = cliargs_deferred_get('3', [])
    func2 = cliargs_deferred_get('2')
    func3 = cliargs_deferred_get('2', shallowcopy=True)

    global CLIARGS
    with patch.dict('ansible.utils.context.CLIARGS', **cli_args):
        assert func() == []

    with unittest.mock.patch.object(CLIArgs, '__getitem__', new=lambda s, k: cli_args[k]):
        CLIARGS = CLIArgs(cli_args)
        assert func2() == []
       

# Generated at 2022-06-10 23:08:44.832987
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # For testing we need to use another object for the global vars
    class _TestCLIArgs(CLIArgs):
        def __init__(self, cli_args):
            self._options = cli_args

    def test(key, default, shallowcopy, expected):
        if default is not None:
            t = cliargs_deferred_get(key, default, shallowcopy)
        else:
            t = cliargs_deferred_get(key, shallowcopy=shallowcopy)
        assert t() == expected

    test('one', None, False, 'bar')
    test('two', None, False, ['bar', 'baz'])
    test('one', None, True, 'bar')
    test('two', None, True, ['bar', 'baz'])

# Generated at 2022-06-10 23:08:56.355991
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    _init_global_context({})
    assert cliargs_deferred_get('key-does-not-exist')() is None
    assert cliargs_deferred_get('key-does-not-exist', default='default')() == 'default'
    _init_global_context({'cliargs_array': [1, 2, 3]})
    assert cliargs_deferred_get('cliargs_array')() == [1, 2, 3]
    assert cliargs_deferred_get('cliargs_array', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('cliargs_array', shallowcopy=True)() is not [1, 2, 3]

# Generated at 2022-06-10 23:09:05.504282
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    cli_args = dict(
        foo='bar',
        baz=[1, 2, 3],
        qux={'a': 'hello', 'b': 'world'},
        top={'h': {'i': 'j'}},
    )

    # Needed to have a global_context to test
    _init_global_context(cli_args)

    for key in cli_args:
        inner_func = cliargs_deferred_get(key)
        assert cli_args.get(key) == inner_func()
        cli_args[key][:] = [4, 5, 6]
        assert cli_args.get(key) == inner_func()

    inner_func = cliargs_deferred_get('foo')
    assert inner_func() == 'bar'

    inner_

# Generated at 2022-06-10 23:09:15.323587
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 'bar'})
    assert 'bar' == cliargs_deferred_get('foo')()
    CLIARGS.update({'foo': 'baz'})
    assert 'baz' == cliargs_deferred_get('foo')()

    CLIARGS.update({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() is cliargs_deferred_get('foo')()
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not cliargs_deferred_get('foo', shallowcopy=True)()

    CLIARGS.update({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() is cliargs_deferred_get('foo')

# Generated at 2022-06-10 23:09:23.075290
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # reset the SHARED_CONTEXT
    global CLIARGS
    CLIARGS = CLIArgs({})
    cli_args = {'become': True, 'become_user': 'dude', 'connection': 'mock'}

    # test with a setting not in the args
    assert cliargs_deferred_get('check')() == None

    # test with a shallow copy of a list
    _init_global_context(cli_args)
    cli_args['check'] = True
    get_check = cliargs_deferred_get('check', shallowcopy=True)
    assert get_check() == True
    assert get_check() is not cli_args['check']



# Generated at 2022-06-10 23:09:33.809472
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the results from CLIARGS get method"""
    args = {
        'a': 1,
        'b': [2, 3],
        'c': {4, 5},
        'd': {'e': 6, 'f': 7}
    }

    keys = ('a', 'b', 'c', 'd', 'x', 'y', 'z')
    values = (1, [2, 3], {4, 5}, {'e': 6, 'f': 7}, None, [1, 2, 3], 6)

    _init_global_context(args)

    test_fns = []
    for key, value in zip(keys, values):
        test_fns.append(cliargs_deferred_get(key))


# Generated at 2022-06-10 23:09:41.496771
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import cli_args
    from ansible.playbook.play import Play
    from ansible.utils.context_objects import _init_global_context

    _init_global_context(cli_args(['--module-path', '/path/to/modules'], Play()))

    assert cliargs_deferred_get('module_path')() == '/path/to/modules'
    assert cliargs_deferred_get('ask_become_pass')() is False

# Generated at 2022-06-10 23:09:43.277566
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get('foo')()



# Generated at 2022-06-10 23:10:25.831713
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    assert cliargs_deferred_get('bar', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-10 23:10:35.727724
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'str_arg': 'foo', 'list_arg': [1, 2, 3], 'dict_arg': {'one': 1, 'two': 2}, 'set_arg': {1, 2, 3}, 'plain_arg': 123}
    _init_global_context(cli_args)
    str_func = cliargs_deferred_get('str_arg')
    assert str_func() == 'foo'

    list_func = cliargs_deferred_get('list_arg', shallowcopy=True)
    assert list_func() == [1, 2, 3]
    list_func()[0] = 4
    list_func2 = cliargs_deferred_get('list_arg', shallowcopy=True)
    assert list_func2() == [1, 2, 3]

    dict

# Generated at 2022-06-10 23:10:45.944283
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import GlobalCLIArgs
    # Set it back to a local one for testing
    global CLIARGS
    CLIARGS = CLIArgs({})

    # This is the function we're testing
    # pylint: disable=undefined-variable
    getter = cliargs_deferred_get('foo', 'bar')

    # Make sure that an explicit default returns that default if the key isn't present
    assert getter() == 'bar'

    # Make sure that we get the expected value with a key present
    CLIARGS = CLIArgs({'foo': 'foo'})
    assert getter() == 'foo'

# Generated at 2022-06-10 23:10:56.684213
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 'bar', 'baz': 'quux', 'quux': [True, False]})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == 'quux'
    assert cliargs_deferred_get('quux')() == [True, False]
    assert cliargs_deferred_get('unknown', default='spam')() == 'spam'

    # shallow copies
    def assert_shallow_copy(old_value, getter):
        new_value = getter()
        assert new_value is not old_value
        if isinstance(old_value, (Mapping, Set)):
            assert old_value == new_value

# Generated at 2022-06-10 23:11:05.262732
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import DeferredValue

    class Args(object):
        # Fake out the ImmutableDict so we can set values
        def __setitem__(self, key, value):
            setattr(self, key, value)

    global CLIARGS
    original_context = CLIARGS

# Generated at 2022-06-10 23:11:16.144721
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    import copy
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    cli_args['foo'] = ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    before = cliargs_deferred_get('foo')()
    before.append(['soop'])
    assert cliargs_deferred_get('foo')() == ['bar', 'baz', ['soop']]
    assert cliargs_deferred_get('foo', shallowcopy=True)

# Generated at 2022-06-10 23:11:25.910918
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # test with empty cliargs
    _init_global_context({})
    # check that it returns the default
    assert cliargs_deferred_get('a', default='FOO')() == 'FOO'
    # check that it returns the default for the right key
    assert cliargs_deferred_get('a', default='FOO')() == 'FOO'
    # set cliargs and check that we get it
    CLIARGS['a'] = 'ZAP'
    assert cliargs_deferred_get('a', default='FOO')() == 'ZAP'
    # check that it returns the default for the right key again
    assert cliargs_deferred_get('b', default='FOO')() == 'FOO'

    # test with cliargs already set

# Generated at 2022-06-10 23:11:35.471632
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check_copy(key, orig_value, orig_copy, orig_shallow):
        _init_global_context(dict(key=orig_value))
        assert cliargs_deferred_get(key, shallowcopy=False)() == orig_copy
        assert cliargs_deferred_get(key, shallowcopy=True)() == orig_shallow
    check_copy('key', False, False, False)
    check_copy('key', True, True, True)
    check_copy('key', 0, 0, 0)
    check_copy('key', 42, 42, 42)
    check_copy('key', 'f', 'f', 'f')
    check_copy('key', 'foo', 'foo', 'foo')
    check_copy('key', [], [], [])

# Generated at 2022-06-10 23:11:48.355729
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({
        'testkey': 'testvalue',
        'testkeysquence': ('testval1', 'testval2', 'testval3')
    })
    global CLIARGS
    CLIARGS = cliargs

    assert cliargs_deferred_get('testkey') == 'testvalue'
    assert cliargs_deferred_get('testkey', 'notdefault') == 'testvalue'
    assert cliargs_deferred_get('testkey', default='notdefault') == 'testvalue'
    assert cliargs_deferred_get('testkeynotpresent') is None

    assert cliargs_deferred_get('testkeysquence', shallowcopy=True) == ('testval1', 'testval2', 'testval3')

# Generated at 2022-06-10 23:11:57.974803
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function ``cliargs_deferred_get``

    Note that it is much harder to verify that the correct closure is being defined as
    we are testing something that is only a side-effect.  We can test that the closures
    being defined actually return the correct thing.
    """
    # With no args, should return ``None``
    assert cliargs_deferred_get('arg')() is None

    # Otherwise should return the default value
    assert cliargs_deferred_get('arg', default='foo')() == 'foo'

    # If the args have been set, then should return the value
    CLIARGS['arg'] = 'bar'
    assert cliargs_deferred_get('arg', default='foo')() == 'bar'
    CLIARGS['arg'] = 'bar'
    assert cliargs_deferred_get