

# Generated at 2022-06-10 23:02:12.266127
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar', 'baz': ['qux', 'quux'], 'will_be_overwritten': True, 'corpus': {'bleah': 'blah'}}
    _init_global_context(cli_args)
    assert 'bar' == cliargs_deferred_get('foo')()

    foo = cliargs_deferred_get('foo')
    _init_global_context(dict(cli_args, foo=42))
    assert 42 == foo()

    baz = cliargs_deferred_get('baz', shallowcopy=True)
    _init_global_context(dict(cli_args, baz=['fux', 'fuxx', 'fuxxx']))
    baz_default = baz()

# Generated at 2022-06-10 23:02:23.522722
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MyCliArgs(CLIArgs):
        def __init__(self, *args, **kwargs):
            super(MyCliArgs, self).__init__(*args, **kwargs)
            self.__dict__['my_list'] = ['list', 'with', 'three', 'elements']
            self.__dict__['my_dict'] = {'key1': 'value1', 'key2': 'value2'}
            self.__dict__['my_set'] = {'list', 'with', 'three', 'elements'}

    test_obj = MyCliArgs()
    global CLIARGS
    CLIARGS = test_obj
    # test with no default
    assert cliargs_deferred_get('my_list') == ['list', 'with', 'three', 'elements']

# Generated at 2022-06-10 23:02:33.176421
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Check that we get the default value if there is no CLIARGS
    CLIARGS = CLIArgs({})
    assert 'foo' == cliargs_deferred_get('foo', default='foo')()

    # Check that we get the value if there is a CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert 'bar' == cliargs_deferred_get('foo', default='foo')()

    # Check that shallow copies work as expected
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert ['bar'] == cliargs_deferred_get('foo', default='foo')()
    assert ['bar'] == cliargs_deferred_get('foo', default='foo', shallowcopy=True)()

# Generated at 2022-06-10 23:02:40.469722
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    try:
        CLIARGS = CLIArgs({'foo': [1, 2, 3]})
        fn = cliargs_deferred_get('foo')
        assert fn() == [1, 2, 3]
        # With shallow copy
        fn = cliargs_deferred_get('foo', shallowcopy=True)
        assert fn() == [1, 2, 3]
        assert fn() is not CLIARGS['foo']
    finally:
        CLIARGS = CLIArgs({})

# Generated at 2022-06-10 23:02:49.161334
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 'bar'})
    assert 'bar' == cliargs_deferred_get('foo')()
    assert 'bar' == cliargs_deferred_get('foo', default='baz')()
    assert 'baz' == cliargs_deferred_get('baz')()
    assert 'qux' == cliargs_deferred_get('baz', default='qux')()
    assert ['bar'] == cliargs_deferred_get('foo', shallowcopy=True)()
    assert {'foo': 'bar'} == cliargs_deferred_get('foo', shallowcopy=True, default={'foo': 'bar'})()

# Generated at 2022-06-10 23:03:02.363497
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.constants
    from ansible.utils.context_objects import cli_args
    global CLIARGS
    cli_args.parse(['-v', '-vvvvvvvvvvvv'])
    cli_args.validate()
    cli_args.normalize()
    _init_global_context(cli_args)
    assert cliargs_deferred_get('verbosity')() is 11
    cli_args.parse([])
    cli_args.validate()
    cli_args.normalize()
    _init_global_context(cli_args)
    assert cliargs_deferred_get('verbosity')() is ansible.constants.DEFAULT_VERBOSITY
    assert cliargs_deferred_get('extra_vars') is CLIARGS.get

# Generated at 2022-06-10 23:03:08.551937
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    # This should return the default value
    assert cliargs_deferred_get('bar', default=True)()

    # Check the copy functionality
    cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    cliargs_deferred_get('foo', shallowcopy=False)() == 'bar'

# Generated at 2022-06-10 23:03:18.036301
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    some_key = 'some_key'
    some_value = 'some_value'
    global CLIARGS
    # check normal get
    CLIARGS = CLIArgs({some_key: some_value})
    assert (cliargs_deferred_get(some_key, default=None)() is some_value)
    # check default get
    assert (cliargs_deferred_get('non-existent-key')() is None)
    # check copying
    CLIARGS = CLIArgs({some_key: ['1', '2']})
    assert (cliargs_deferred_get(some_key, shallowcopy=True)() == ['1', '2'])
    assert (cliargs_deferred_get(some_key, shallowcopy=True)() is not CLIARGS[some_key])

# Generated at 2022-06-10 23:03:27.128252
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs(dict(foo='foo'))
    assert cliargs_deferred_get('foo')(), "Function returns default when not set"
    assert cliargs_deferred_get('foo', 'bar')(), "Function returns default when not set"
    assert cliargs_deferred_get('foo', default='bar')() == 'bar', "Function returns default when not set"
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'foo', "Function returns value when set"
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'foo', "Function returns value when set"

# Generated at 2022-06-10 23:03:31.586158
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''Test that cliargs_deferred_get returns the default if CLIARGS is None'''
    global CLIARGS
    original_cliargs = CLIARGS
    CLIARGS = None
    assert cliargs_deferred_get('foo', 42)() == 42
    CLIARGS = original_cliargs

# Generated at 2022-06-10 23:03:41.586944
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import namedtuple
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.utils.context_objects import GlobalCLIArgs as ctx
    ctx.define('test_key_one', type=str, default='default_one')
    ctx.define('test_key_two', type=str, default='default_two')
    ctx.define('test_key_three', type=str, default='default_three')
    ctx.define('test_key_four', type=namedtuple('MyStruct', 'x y z'), default=namedtuple('MyStruct', 'x y z')('x', 'y', 'z'))

# Generated at 2022-06-10 23:03:45.953778
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cli_args = {"vault_password": "unittest_password"}
    CLIARGS = CLIArgs(cli_args)
    inner = cliargs_deferred_get("vault_password")
    assert inner() == "unittest_password"

# Generated at 2022-06-10 23:03:56.004599
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Prepare data for testing
    test_key = 'test_key'
    test_default = 'test_default'
    test_value = 'test_value'

    # Test raising exception when value is not supplied in CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('value', default=test_default)() == test_default

    # Test shallow copy is not performed if shallowcopy is False
    CLIARGS = CLIArgs({'value': [1, 2, 3]})
    assert cliargs_deferred_get('value', default=test_default)() == [1, 2, 3]

    # Test shallow copy is performed on a sequence
    CLIARGS = CLIArgs({'value': [1, 2, 3]})

# Generated at 2022-06-10 23:04:05.444125
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = {'foo': 'bar'}
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options(cliargs)
    cliargs_deferred = cliargs_deferred_get('foo')
    assert cliargs_deferred() == 'bar'
    cliargs_deferred = cliargs_deferred_get('bar')
    assert cliargs_deferred() == None
    cliargs_deferred = cliargs_deferred_get('bar', default='baz')
    assert cliargs_deferred() == 'baz'

# Generated at 2022-06-10 23:04:15.920181
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    test_value = {'high': 3, 'low': 1}
    _init_global_context({})
    value = cliargs_deferred_get('bar', test_value)
    assert value() == test_value
    _init_global_context({'bar': 'baz'})
    value = cliargs_deferred_get('bar', test_value)
    assert value() == 'baz'
    _init_global_context({'bar': 'baz', 'baz': test_value})
    value = cliargs_deferred_get('baz', 'foo')
    assert value() == test_value
    value = cli

# Generated at 2022-06-10 23:04:26.701923
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo', default=2)() == 2

    CLIARGS['foo'] = 5
    assert cliargs_deferred_get('foo', default=2)() == 5

    # shallowcopy defaults to False for a non-list value
    CLIARGS['foo'] = 5
    assert cliargs_deferred_get('foo', default=2)() == 5
    CLIARGS['foo'] = [5]
    assert cliargs_deferred_get('foo', default=2)() == [5]
    assert cliargs_deferred_get('foo', default=2, shallowcopy=True)() == [5]
    CLIARGS['foo'] = {'bar': 5}

# Generated at 2022-06-10 23:04:37.229646
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert not hasattr(CLIARGS, 'foo')

    # ``CLIARGS`` is a singleton so we want to make sure that the value
    # that ``CLIARGS.foo`` returns is the appropriate value even after
    # ``CLIARGS`` has been reset
    cliargs_foo_deferred_value = cliargs_deferred_get('foo', default='bar')
    assert cliargs_foo_deferred_value() == 'bar'
    CLIARGS.foo = 'baz'
    assert cliargs_foo_deferred_value() == 'baz'

    cliargs_foo_deferred_value = cliargs_deferred_get('foo', default='bar', shallowcopy=True)

# Generated at 2022-06-10 23:04:48.878052
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'something': 'here'})
    my_closure = cliargs_deferred_get('something')
    assert my_closure() == 'here'

    cliargs_shallowcopy = cliargs_deferred_get('something', shallowcopy=True)
    assert cliargs_shallowcopy() == 'here'

    # but only a shallow copy was made
    CLIARGS = CLIArgs({'something': 'there'})
    assert cliargs_shallowcopy() == 'here'

    tmp_closure = cliargs_deferred_get('something_else')
    assert tmp_closure() is None

    CLIARGS = CLIArgs({'something_else': 'here'})
    assert tmp_closure() == 'here'

    cliargs_nocopy = cl

# Generated at 2022-06-10 23:04:57.792238
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    from copy import copy
    from collections import namedtuple

    TEST_ARGS = namedtuple('TEST_ARGS', ('a', 'b', 'c', 'd', 'e', 'f',))
    CLIARGS = CLIArgs(TEST_ARGS(a=1, b=[2, 3], c={'a': 1, 'b': 2}, d=None, e=copy([4, 5]), f=copy({'c': 3, 'd': 4})))

    noncopy = cliargs_deferred_get('a')
    assert noncopy() == 1

    seqcopy = cliargs_deferred_get('b', shallowcopy=True)
    assert seqcopy() == [2, 3]
    assert seqcopy() is not CLIARGS['b']

    mappingcopy = cliargs_

# Generated at 2022-06-10 23:05:09.366150
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {
        'option1': ['value1'],
        'option2': ['value2'],
        'option3': ['value3'],
        'option4': ['value4'],
    }
    _init_global_context(cli_args)

    assert cliargs_deferred_get('option1')() == ['value1']
    assert cliargs_deferred_get('option2')('default2') == ['value2']

    # default is returned if key is not in cli_args
    assert cliargs_deferred_get('option5')('default5') == 'default5'

    # Shallow copy is done on sequences and sets
    seq = [1, 2, 3]
    cli_args['option6'] = ['value6']

# Generated at 2022-06-10 23:05:22.957405
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.collections import SequenceList

    test_global_context = CLIArgs({'test_foo': 'bar',
                                   'test_sequence': [1,2,3],
                                   'test_sequencelist': SequenceList(1,2,3)})

    global CLIARGS
    old_cliargs = CLIARGS
    CLIARGS = test_global_context

    assert cliargs_deferred_get('test_foo')() == 'bar'
    assert cliargs_deferred_get('test_sequence')() == [1,2,3]
    assert cliargs_deferred_get('test_sequence')(shallowcopy=True) == [1,2,3]
    assert cliargs_

# Generated at 2022-06-10 23:05:34.828230
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    old_cliargs = CLIARGS
    cliargs = {}
    CLIARGS = cliargs
    cliargs['default'] = 1
    cliargs['list'] = [1, 2, 3]
    cliargs['dict'] = {}
    cliargs['set'] = set([1, 2, 3])
    cliargs['notacopy'] = True
    assert cliargs_deferred_get('default')() == 1
    assert cliargs_deferred_get('list')() == [1, 2, 3]
    assert cliargs_deferred_get('dict')() == {}
    assert cliargs_deferred_get('set')() == set([1, 2, 3])
    assert cliargs_deferred_get('notacopy')() is True
    assert cliargs_deferred

# Generated at 2022-06-10 23:05:42.317122
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import FrozenDict
    _init_global_context(
        FrozenDict(dict(
            extra_vars=dict(a='b'),
            fact_path=['foo'],
            module_path=['bar'],
        ))
    )
    assert cliargs_deferred_get("extra_vars", default=dict())['a'] == 'b'
    assert cliargs_deferred_get("fact_path", shallowcopy=True) == ['foo']
    assert cliargs_deferred_get("missing_key", default=dict()) == dict()

# Generated at 2022-06-10 23:05:52.986419
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {"my_option": "myoption_value",
                "my_list": ['a', 'b', 'c'],
                "my_list_default": ['t', 'u', 'v'],
                "my_dict": {'a': 1, 'b': 2, 'c': 3},
                "my_dict_default": {'t': 4, 'u': 5, 'v': 6}
               }
    # Note: we have to do this in the functional test because of name resolution
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs
    _init_global_context(cli_args)
    assert CLIARGS.get("my_option") == "myoption_value"
    assert CLIARGS.get("my_list") == ['a', 'b', 'c']
   

# Generated at 2022-06-10 23:05:58.968111
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Ensure that cliargs_deferred_get works as intended"""
    _init_global_context({})
    func = cliargs_deferred_get('foo', default='bar')
    assert func() == 'bar'
    assert cliargs_deferred_get('foo', default=[])() == []
    assert cliargs_deferred_get('foo', default={})() == {}
    assert cliargs_deferred_get('foo', default=set())() == set()
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default=[], shallowcopy=True)() == []
    assert cliargs_deferred_get('foo', default={}, shallowcopy=True)() == {}
    assert cl

# Generated at 2022-06-10 23:06:04.980418
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': {'b': {'c': 'foo'}}})
    assert cliargs_deferred_get('a')()['b']['c'] == 'foo'
    assert cliargs_deferred_get('b', default='bar')() == 'bar'
    assert cliargs_deferred_get('c', default='bar')() == 'bar'
    assert cliargs_deferred_get('a', shallowcopy=True)().get('b', {}).get('c') == 'foo'



# Generated at 2022-06-10 23:06:12.966614
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    name = 'foo'
    default = 'default'
    CLIARGS = CLIArgs({name: 'value'})
    assert cliargs_deferred_get(name, default=default)() == 'value'
    assert cliargs_deferred_get(name + '1', default=default)() == default
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get(name, default=default)() == default
    CLIARGS = CLIArgs({name: []})
    assert cliargs_deferred_get(name, shallowcopy=True)() == []
    CLIARGS = CLIArgs({name: [1, 2, 3]})
    assert cliargs_deferred_get(name, shallowcopy=True)() == [1, 2, 3]
    CLIARGS

# Generated at 2022-06-10 23:06:23.695324
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is an internal function, no need to test, but these tests are here to keep
    # a pattern consistent.

    # Test with default
    _init_global_context(dict())

    deferred_get = cliargs_deferred_get('arg1', default=1)
    assert deferred_get() == 1

    # Test with answer in CLIARGS
    _init_global_context({'arg1': 2})

    deferred_get = cliargs_deferred_get('arg1', default=1)
    assert deferred_get() == 2

    # Test with no default, no answer in CLIARGS
    _init_global_context(dict())

    deferred_get = cliargs_deferred_get('arg1')
    assert deferred_get() is None

    # Test with no default, answer in CLIARGS
    _

# Generated at 2022-06-10 23:06:35.248027
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CliArgs(dict):
        @staticmethod
        def get(*args, **kwargs):
            return dict.get(*args, **kwargs)

    global CLIARGS
    CLIARGS = CliArgs({})
    CLIARGS.update({'value1': ['a', 'b'], 'value2': {'a': 'b'}, 'value3': 'a', 'value4': None})

    assert ['a', 'b'] == cliargs_deferred_get('value1')()
    assert ['a', 'b'] == cliargs_deferred_get('value1', shallowcopy=True)()

    assert {} == cliargs_deferred_get('value4')()
    assert {} == cliargs_deferred_get('value4', shallowcopy=True)()

    assert 'a' == cli

# Generated at 2022-06-10 23:06:46.953242
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    expected = dict(a=1, b=2, c=3)
    CLIARGS = CLIArgs(expected)
    result = cliargs_deferred_get('a')()
    assert result == expected['a']
    result = cliargs_deferred_get('b')()
    assert result == expected['b']
    result = cliargs_deferred_get('c')()
    assert result == expected['c']

    def test_with_default():
        expected = dict(a=1, b=2, c=3)
        CLIARGS = CLIArgs(expected)
        result = cliargs_deferred_get('a', default=None)()
        assert result == expected['a']
        assert cliargs_deferred_get('b', default=None)() is None
       

# Generated at 2022-06-10 23:07:07.267390
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class DummyCliArgs(object):
        def get(self, key, default=None):
            if key == 'foo':
                return [1]
            return default

    cliargs = DummyCliArgs()
    global CLIARGS

    assert CLIARGS.get('foo') is None
    pytest.raises(AttributeError, cliargs_deferred_get('bar'))

    # Now that we're using cliargs_deferred_get(), the call will defer until after
    # the CLI arguments are parsed
    CLIARGS = cliargs
    default = cliargs_deferred_get('bar')
    assert default == []
    assert CLIARGS.get('bar') is None

    default = cliargs_deferred_get('foo')
    assert default == [1]

# Generated at 2022-06-10 23:07:17.745122
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-10 23:07:29.061603
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=import-outside-toplevel
    import pytest
    from ansible.errors import AnsibleAssertionError
    from ansible.module_utils.common._collections_compat import Sequence, Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    def _assert_same(left, right):
        if is_sequence(left):
            assert is_sequence(right)
            assert left == right
        elif isinstance(left, Set):
            assert isinstance(right, Set)
            assert left == right
        elif isinstance(left, Mapping):
            assert isinstance(right, Mapping)
            assert left == right
        else:
            assert left == right


# Generated at 2022-06-10 23:07:35.223007
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 'b'})

    def check_value(key, expected):
        assert cliargs_deferred_get(key)() == expected

    # Test that we get values out of the context correctly
    check_value('a', 'b')

    # Test that we get the default value correctly
    check_value('c', None)

    # Test that we get the default value even if it is None
    check_value('c', 123)

    # Test that we get the default value even if it is 0
    check_value('c', 0)

    # Test that we return shallow copies of lists
    check_value('c', [])
    check_value('c', [1])
    check_value('c', [1, 2, 3])

    # Test that we return shallow

# Generated at 2022-06-10 23:07:45.828475
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Function cliargs_deferred_get unit test"""
    import copy

    cli_args = dict(
        test1=1,
        test2=2,
        test3=3,
        test4=[4, 5, 6],
        test5=dict(
            a=7,
            b=8,
            c=9,
        ),
        test6=set([10, 11, 12]),
    )

    CLIARGS.update(cli_args)

    # Test that the defaults work
    assert cliargs_deferred_get('test1')() == 1
    assert cliargs_deferred_get('test2')() == 2
    assert cliargs_deferred_get('test3')() == 3

# Generated at 2022-06-10 23:07:56.261555
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from tempfile import TemporaryDirectory
    from ansible import context
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.cli.arguments import context_objects as co_cli_args

    with TemporaryDirectory() as test_dir:
        # default values for context objects
        cli_args = vars(co_cli_args.create_parser(None).parse_args(args=['--inventory', test_dir]))
        context._init_global_context(cli_args)
        assert CLIARGS.get('inventory') == test_dir

        # sample values for context objects
        cli_args = vars(co_cli_args.create_parser(None).parse_args(args=['--inventory', test_dir, '--extra-vars', '{}']))
        context._init_global_

# Generated at 2022-06-10 23:08:08.450338
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test deferred getting of CliArgs"""
    import pytest
    global CLIARGS
    test_args = {'a': 'a', 'b': 'b', 'c': {'d': 'd'}}
    _init_global_context(test_args)
    assert CLIARGS.get('a') == cliargs_deferred_get('a')()
    assert CLIARGS.get('a') == cliargs_deferred_get('a', None)()
    assert '1' == cliargs_deferred_get('a', '1')()
    with pytest.raises(KeyError):
        CLIARGS.get('d')
    assert '2' == cliargs_deferred_get('d', '2')()
    assert CLIARGS.get('c') == cliargs_deferred_

# Generated at 2022-06-10 23:08:14.360310
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = {'test': 'value-set'}
    _init_global_context(args)
    assert cliargs_deferred_get('test') == 'value-set'
    assert cliargs_deferred_get('not-set') is None
    assert cliargs_deferred_get('not-set', 'default-value') == 'default-value'

# Generated at 2022-06-10 23:08:22.994623
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for cliargs_deferred_get"""
    assert cliargs_deferred_get('foo')() == None
    a = object()
    CLIARGS['foo'] = a
    assert cliargs_deferred_get('foo')() is a
    b = object()
    CLIARGS['foo'] = b
    assert cliargs_deferred_get('foo')() is b
    assert cliargs_deferred_get('foo', default=a)() is b
    assert cliargs_deferred_get('bar', default=a)() is a
    c = [1, 2, 3]
    assert cliargs_deferred_get('bar', default=c, shallowcopy=True)() is not c

# Generated at 2022-06-10 23:08:34.067452
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs

    # If no value is set in the CliArgs, then we get a callable that returns the default value
    assert callable(cliargs_deferred_get('foo'))
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', default=True)() is True

    cliargs = CliArgs({})
    cliargs.set('foo', 'bar')
    assert cliargs_deferred_get('foo')(_global_context=(cliargs,)) == 'bar'

    cliargs._update(dict(biz=dict(baz=True)))
    assert cliargs_deferred_get('biz')() == dict(baz=True)
    assert cliargs_deferred_get

# Generated at 2022-06-10 23:08:58.434782
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pragma: no cover
    import pytest
    cli_args = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the returned function is a closure over the current cli_args
    cli_args['foo'] = 'new_bar'
    assert cliargs_deferred_get('foo')() == 'new_bar'

    # Test that we can get a default value
    assert cliargs_deferred_get('noexist', default='baz')() == 'baz'

    # Test that we can shallow copy the value
    cli_args['should_copy'] = ['a', 'b', 'c']
    should_copy = cliargs_deferred_get('should_copy', shallowcopy=True)()
    should_

# Generated at 2022-06-10 23:09:03.819337
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

# Generated at 2022-06-10 23:09:11.708983
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cli_args = {'roles_path': ['/foo/bar']}
    CLIARGS = CLIArgs(cli_args)

    f = cliargs_deferred_get('roles_path', shallowcopy=True)
    assert f() == ['/foo/bar']
    cli_args['roles_path'].append('/bar/baz')
    assert f() == ['/foo/bar']
    assert cli_args['roles_path'] == ['/foo/bar', '/bar/baz']
    assert not f is cliargs_deferred_get('roles_path', shallowcopy=True)

# Generated at 2022-06-10 23:09:18.910293
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    normal_value = cliargs_deferred_get('something', default='Default')()
    assert normal_value == 'Default'
    assert normal_value is not cliargs_deferred_get('something', default='Default')()

    const_value = cliargs_deferred_get('something', default='Default', shallowcopy=True)()
    assert const_value == 'Default'
    assert const_value is const_value

    CLIARGS = GlobalCLIArgs.from_options({'something': 'my_value'})

    normal_value = cliargs_deferred_get('something', default='Default')()
    assert normal_value == 'my_value'
    assert normal_value is not cliargs_deferred_get('something', default='Default')()

    const_value = cliargs

# Generated at 2022-06-10 23:09:25.327366
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for cliargs_deferred_get
    """
    test_cliargs = GlobalCLIArgs.from_options({'foo': 'bar',
                                               'bam': ['baz', 'boz'],
                                               'zoo': {'zam': 'zim', 'zip': 'zap'}})
    global CLIARGS
    orig_cliargs = CLIARGS

# Generated at 2022-06-10 23:09:26.453531
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # TODO: write unit test
    pass

# Generated at 2022-06-10 23:09:37.962234
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This test code is not included in the code coverage because it wouldn't be reachable
    # unless CLIARGS were reset which would be non-standard behavior
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', default='jinja')() == 'jinja'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs(list(range(3)))
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

# Generated at 2022-06-10 23:09:47.962296
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.CONFIG_FILE = '/path/to/config'
    assert cliargs_deferred_get('CONFIG_FILE')() == '/path/to/config'
    assert cliargs_deferred_get('CONFIG_FILE', default=['empty'])() == '/path/to/config'
    assert cliargs_deferred_get('NONEXISTENT')() is None
    assert cliargs_deferred_get('NONEXISTENT', default=['empty'])() == ['empty']

    CLIARGS.VARIABLE_MANAGER = ['variables', 'here']
    assert cliargs_deferred_get('VARIABLE_MANAGER', shallowcopy=True)() == ['variables', 'here']

    CLIARGS.NOCOLOR = True
    assert cli

# Generated at 2022-06-10 23:10:00.223844
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    from ansible.utils.context_objects import CLIArgs
    from functools import partial

    cli_args = CLIArgs({'foo': 'bar', 'baz': [1, 2], 'liz': {'a': 1, 'b': 2}, 'set': {1, 2, 3}})
    CLIARGS = cli_args

    cliargs_deferred_get_default = partial(cliargs_deferred_get, shallowcopy=False)
    cliargs_deferred_get_shallow_copy = partial(cliargs_deferred_get, shallowcopy=True)

    assert cliargs_deferred_get('foo') is 'bar'
    assert cliargs_deferred_get('baz') is [1, 2]
    assert cliargs_deferred_get('liz')

# Generated at 2022-06-10 23:10:07.941495
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Singleton object for ``GlobalCLIArgs``
    class SingletonObject(object):
        pass

    def my_inner():
        return SingletonObject()

    class StubGlobalCLIArgs(object):
        @classmethod
        def from_options(cls, cli_args):
            # Keep the same closure as CliArgs only callable one time in this case
            return SingletonObject()

    stub = StubGlobalCLIArgs()
    old_global = CLIARGS
    old_from_options = GlobalCLIArgs.from_options
    GlobalCLIArgs.from_options = stub.from_options
    CLIARGS = 0
    # First time this is called it should return the Singleton and rebind CLIARGS
    value = cliargs_deferred_get('a', default='b', shallowcopy=False)()


# Generated at 2022-06-10 23:10:39.967459
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-10 23:10:50.980727
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'foo': {'bar': [1, 2, 3]}, 'baz': [1, 2, 3], 'spam': 'eggs'})

    def check_value(key, value, shallowcopy=False):
        expected = CLIARGS.get(key)
        if not shallowcopy:
            assert expected == value
            assert expected is value
        else:
            if is_sequence(expected):
                assert expected[:] == value
            elif isinstance(expected, (Mapping, Set)):
                assert expected.copy() == value
            else:
                # ints, strings, etc. can't be shallow-copied
                assert expected == value


# Generated at 2022-06-10 23:10:54.476723
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    a = {'a': [1, 2, 3], 'b': {'c':'d'}}
    b = {'a': [1, 2, 3], 'b': {'c':'d'}}
    c = {'a': [1, 2, 3], 'b': {'c':'d'}}
    cliarg = CLIArgs(a)
    get_a = cliargs_deferred_get('a')
    get_b = cliargs_deferred_get('b')
    get_c = cliargs_deferred_get('c', default=c)
    get_a_shallowcopy = cliargs_deferred_get('a', shallowcopy=True)
    get_b_shallowcopy = cliargs_deferred_get('b', shallowcopy=True)
    get_

# Generated at 2022-06-10 23:11:03.284371
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

    CLIARGS.update({'foo': ['a', 'b', 'c']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['a', 'b', 'c']

    CLIARGS.update({'foo': {'a': 'b'}})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'a': 'b'}

# Generated at 2022-06-10 23:11:13.458134
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeCLIArgs(object):
        def __init__(self, value):
            self._value = value

        def get(self, key, default=None):
            return self._value

    global CLIARGS

    CLIARGS = FakeCLIArgs(1)

    assert cliargs_deferred_get('foo')(), 1
    assert cliargs_deferred_get('foo', default=2)(), 1
    assert cliargs_deferred_get('foo', shallowcopy=True)(), 1
    assert cliargs_deferred_get('foo', shallowcopy=True, default=2)(), 1

    CLIARGS = FakeCLIArgs(2)

    assert cliargs_deferred_get('foo')(), 2
    CLIARGS = FakeCLIArgs(None)

    assert cliargs_def

# Generated at 2022-06-10 23:11:23.380905
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # dummy global context object
    class TestCLIARGS(dict):
        def get(self, key, default=None):
            if key == 'action':
                return self[key]
            return default

    # the test data

# Generated at 2022-06-10 23:11:34.061365
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    global CLIARGS

# Generated at 2022-06-10 23:11:44.296296
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    value = []
    def inner():
        return value
    try:
        cliargs_get = cliargs_deferred_get('no_such_key')
        assert cliargs_get() is None
        assert cliargs_deferred_get('no_such_key', default='foo')() == 'foo'
        value = {'a': 'b'}
        assert cliargs_get() == {'a': 'b'}
        assert cliargs_deferred_get('no_such_key', shallowcopy=True)() == {'a': 'b'}
    finally:
        del cliargs_get

# Generated at 2022-06-10 23:11:52.687502
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Equality tests
    _init_global_context({})
    assert cliargs_deferred_get('a')() is None
    _init_global_context({'a': 1})
    assert cliargs_deferred_get('a')() == 1

    # Shallow Copy
    _init_global_context({})
    assert cliargs_deferred_get('list', [], shallowcopy=True)() == []
    _init_global_context({'list': [1, 2, 3]})
    assert cliargs_deferred_get('list', [], shallowcopy=True)() == [1, 2, 3]

    # Ensure that when not copy, you get the underlying structure.  This is useful
    # when building playbooks
    _init_global_context({})

# Generated at 2022-06-10 23:12:01.241418
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    # No CLIArgs to use in this test
    assert cliargs_deferred_get('hello', default=3)() == 3
    # Now set up a CLIArgs to use
    global CLIARGS
    cli_args = {'hello': 'world'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('hello', default=None)() == 'world'
    for shallowcopy in True, False:
        assert cliargs_deferred_get('hello', default=None, shallowcopy=shallowcopy)() == 'world'
        assert cliargs_deferred_get('hello', default=4, shallowcopy=shallowcopy)() == 'world'