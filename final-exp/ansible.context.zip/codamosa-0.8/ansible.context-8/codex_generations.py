

# Generated at 2022-06-10 23:02:13.020789
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Mock CLIARGS with a dict
    global CLIARGS
    old_cliargs = CLIARGS
    class CliArgsMock(dict):
        def __getattr__(self, name):
            return self.get(name)

    CLIARGS = CliArgsMock()

    # Test that cliargs_deferred_get returns the same as dict.get
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    assert cliargs_deferred_get('no_value')() == None
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo')() == 'baz'
    CLIAR

# Generated at 2022-06-10 23:02:24.392257
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(foo=['bar', 'baz'], bam={'a':1,'b':2}, bar=1))

    # test the default value
    cli_arg_getter = cliargs_deferred_get('bar', default=2)
    assert 1 == cli_arg_getter()
    assert 1 == CLIARGS['bar']

    # test the shallow copy functionaliy
    cli_arg_getter = cliargs_deferred_get('foo', shallowcopy=True)
    cb = cli_arg_getter()
    assert 'bar' == cb[0]
    cb[0] = 'bat'
    assert ['bar', 'baz'] == CLIARGS['foo']

    cli_arg_getter = cli

# Generated at 2022-06-10 23:02:33.668155
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    sample_dict = dict(a=1, b=2, c=dict(d=3, e=4), f=[1,2,3], g=dict(h=set([1,2,3])))
    global CLIARGS
    CLIARGS = CLIArgs(sample_dict)

    # Test that the inner function works correctly
    inner = cliargs_deferred_get('a')
    assert inner() == 1
    inner = cliargs_deferred_get('c', shallowcopy=True)
    assert inner() == {'d': 3, 'e': 4}

    # Test that the inner function works correctly with recursion
    inner = cliargs_deferred_get('f')
    assert inner() == [1, 2, 3]
    inner = cliargs_deferred_get('g', shallowcopy=True)

# Generated at 2022-06-10 23:02:44.699687
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MyClass():
        """Mock CLIARGS"""
        def get(self, key, default=None):
            if key == 'my_list':
                return ['hello', 'world']
            elif key == 'my_dict':
                return {'first': 'hello'}
            elif key == 'my_set':
                return {'hello', 'world'}
            else:
                return default
    global CLIARGS
    x = CLIARGS
    CLIARGS = MyClass()
    get_func = cliargs_deferred_get('my_list', shallowcopy=True)
    assert get_func() == ['hello', 'world']
    get_func = cliargs_deferred_get('my_dict', shallowcopy=True)
    assert get_func() == {'first': 'hello'}


# Generated at 2022-06-10 23:02:56.162030
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo')() is None
    CLIARGS['foo'] = 42
    assert cliargs_deferred_get('foo')() == 42
    assert cliargs_deferred_get('foo', 42)() == 42
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 42
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS['foo'] = []
    assert cliargs_deferred_get('foo', shallowcopy=True)() == []
    CLIARGS['foo'] = {}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {}

# Generated at 2022-06-10 23:03:05.170333
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=redefined-outer-name
    """Test CliArgsDeferredGet"""
    def create_nu_cliargs(data):
        """Create a CLIArgs with some data"""
        return CLIArgs(data)

    def set_cliargs(nu_cliargs):
        """Replace CLIARGS with nu_cliargs"""
        global CLIARGS  # pylint: disable=global-statement
        CLIARGS = nu_cliargs

    def reset_cliargs():
        """Reset CLIARGS to default value"""
        set_cliargs(CLIArgs({}))

    from ansible.module_utils.common.collections import is_sequence


# Generated at 2022-06-10 23:03:16.074718
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""

    # 1) Test with a default
    cliargs = CLIArgs({})
    # 1.1) Test with a default and not shallow copy
    inner = cliargs_deferred_get('test_key', default='test_default')
    assert inner() == 'test_default'
    # 1.2) Test with a default and shallow copy
    inner = cliargs_deferred_get('test_key', default=[1, 2, 3], shallowcopy=True)
    assert inner() == [1, 2, 3]
    cliargs = CLIArgs({'test_key': [4, 5, 6]})
    # 1.3) Test with a default and not shallow copy
    inner = cliargs_deferred_get('test_key', default='test_default')


# Generated at 2022-06-10 23:03:26.485970
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.data_loader import DataLoader

    loader = DataLoader()

    _init_global_context(loader.load_from_file('test/ansible_cli_args.yaml'))
    print(CLIARGS.get('become_method'))
    assert cliargs_deferred_get('become_method')() == 'sudo'

    CLIARGS.data['become_user'] = 'william'
    assert cliargs_deferred_get('become_user')() == 'william'

    assert cliargs_deferred_get('become_method', default='su')() == 'sudo'
    CLIARGS.data.clear()
    assert cliargs_deferred_get('become_method', default='su')() == 'su'


# Generated at 2022-06-10 23:03:36.515983
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """This function is a test for ``cliargs_deferred_get``"""
    _init_global_context({'key': 'value'})
    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('notkey', 'default value')() == 'default value'

    # Should not copy a non-copyable type
    assert cliargs_deferred_get('key', shallowcopy=True)() == 'value'

    # Should copy a list
    assert cliargs_deferred_get('key', default=['a', 'b', 'c'], shallowcopy=True)() == ['a', 'b', 'c']

    # Should copy a dictionary
    assert cliargs_deferred_get('key', default={'a': 'b'}, shallowcopy=True)()

# Generated at 2022-06-10 23:03:40.532906
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test': 'default'})
    assert cliargs_deferred_get('test')() == cliargs_deferred_get('test')(), \
        'cliargs_deferred_get should return the same value as CLIArgs.get'

# Generated at 2022-06-10 23:03:52.830926
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_values = {
        'default_value': 'default value',
        'weird_value': {},
        'dict_value': {'a': 1, 'b': 2},
        'list_value': [1, 2, 3],
    }
    cli_args = {
        'weird_value': test_values['weird_value'],
        'dict_value': test_values['dict_value'],
        'list_value': test_values['list_value'],
    }
    _init_global_context(cli_args)

    # This is the function we're testing.  We don't care about how the closure works
    # so just test its output.
    _inner = cliargs_deferred_get
    default_value = 'default value'
    _inner_default = lambda: _

# Generated at 2022-06-10 23:04:05.383035
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test code relies on cliargs_deferred_get being a function and not bound directly
    # to CLIAGRGS
    assert cliargs_deferred_get.__name__ == 'cliargs_deferred_get'
    assert cliargs_deferred_get.__module__ == __name__

    assert cliargs_deferred_get('__missing_key__')() is None

    CLIARGS['test_key'] = 'test value'
    assert cliargs_deferred_get('test_key')() == 'test value'

    CLIARGS['test_list'] = ['item1', 'item2']
    assert cliargs_deferred_get('test_list', shallowcopy=True)() == ['item1', 'item2']

# Generated at 2022-06-10 23:04:15.878181
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=invalid-name
    folder = '/tmp/ansible/'
    def _set_cliargs(key, value):
        cli_args = CLIARGS.to_dict()
        cli_args[key] = value
        _init_global_context(cli_args)

    assert cliargs_deferred_get('test')(asdf=asdf) is None
    _set_cliargs('test', 'test_value')
    assert cliargs_deferred_get('test')(asdf=asdf) == 'test_value'

    assert cliargs_deferred_get('test', default='default_value')(asdf=asdf) == 'default_value'

    # shallowcopy - no side effects
    _set_cliargs('test', 'test_value')

# Generated at 2022-06-10 23:04:18.303148
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('ssh_common_args')(' -o A=B') == ' -o A=B'

# Generated at 2022-06-10 23:04:28.814803
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    orig = CLIARGS

    CLIARGS = CLIArgs({'a': [1, 2]})

    assert cliargs_deferred_get('a')() == [1, 2]
    assert cliargs_deferred_get('b', default='foo')() == 'foo'
    assert cliargs_deferred_get('a', shallowcopy=True)() == [1, 2]
    assert cliargs_deferred_get('a', shallowcopy=True)() is not cliargs_deferred_get('a')()

    CLIARGS = CLIArgs({'a': {'b': 1}})

    assert cliargs_deferred_get('a')() == {'b': 1}

# Generated at 2022-06-10 23:04:35.613046
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Check that the original CLIARGS value is not mutated
    CLIARGS._args['connection'] = 'foo'
    assert cliargs_deferred_get('connection', default='bar') == 'foo'
    assert cliargs_deferred_get('connection', default='bar') is CLIARGS._args['connection']

    # Check that copy is always done
    assert cliargs_deferred_get('connection', default='bar', shallowcopy=True) != 'foo'
    assert cliargs_deferred_get('connection', default='bar', shallowcopy=True) != CLIARGS._args['connection']

    # Check that dictionaries are recursively copied
    CLIARGS._args['vault_password_files'] = {'file1': 'file1'}

# Generated at 2022-06-10 23:04:41.758147
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class DummyArgs(object):
        '''This class is only to allow testing that the ``get`` method of CLIARGS is called'''
        def __getitem__(self, key):
            raise RuntimeError('Should not be calling __getitem__ on CLIARGS')
        def __contains__(self, key):
            raise RuntimeError('Should not be calling __contains__ on CLIARGS')
        def get(self, key, default=None):
            return key

    global CLIARGS
    dummy_args = DummyArgs()
    cliargs_deferred_get('test_key')



# Generated at 2022-06-10 23:04:54.038912
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = {'a': 1}
    _init_global_context(args)

    # Simple defaults
    assert cliargs_deferred_get('a', default=None)() == 1
    assert cliargs_deferred_get('a', default=2)() == 1
    assert cliargs_deferred_get('b', default=None)() is None
    assert cliargs_deferred_get('b', default=2)() == 2

    # shallow copy
    args['a'] = [1, 2, 3]
    assert cliargs_deferred_get('a', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('a', shallowcopy=True)() is not args['a']

    # no shallow copy
    assert cliargs_deferred_get

# Generated at 2022-06-10 23:05:04.205278
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-10 23:05:09.717631
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    cli_args = ImmutableDict(defaults_from='from', defaults_from_from='fromfrom')
    _init_global_context(cli_args)
    assert CLIARGS['defaults_from'] == 'from'
    assert CLIARGS.defaults_from == 'from'

    # default is not shallow copied on py3.5+
    getter = cliargs_deferred_get('defaults_from', default=None)
    assert getter() == 'from'
    getter = cliargs_deferred_get('defaults_from_from', default=None)
    assert getter() == 'fromfrom'


# Generated at 2022-06-10 23:05:25.706103
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['test_string'] = 'foo'
    assert cliargs_deferred_get('test_string', 'not set')() == 'foo'
    assert cliargs_deferred_get('test_string2', 'not set')() == 'not set'
    CLIARGS['test_list'] = ['foo', 'bar']
    assert cliargs_deferred_get('test_list', 'not set')() == ['foo', 'bar']
    assert cliargs_deferred_get('test_list', 'not set', shallowcopy=True)() == ['foo', 'bar']
    assert cliargs_deferred_get('test_list2', 'not set')() == 'not set'
    CLIARGS['test_dictionary'] = {'foo': 'bar'}
    assert cliargs_deferred

# Generated at 2022-06-10 23:05:37.426874
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get"""
    # The function is only for use in FieldAttribute and Field instances and is used
    # during the loading of plugin instances.  FieldAttribute is only used in
    # ansible/plugins/callback/ so we need to have a callback plugin to load to
    # verify that this is meant to work
    import ansible.plugins.callback
    assert ansible.plugins.callback.CallbackModule

    # pylint: disable=protected-access
    # This is needed because we are setting up test cases to verify _init_global_context()
    # and the test cases remove the _get method

    # Create some dummy values to test with
    cli_args = CLIArgs.from_options({'foo': 'bar', 'baz': 'boz'})
    # pylint: disable=line-too-

# Generated at 2022-06-10 23:05:45.408998
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    #
    # Test no default provided
    #
    # Verify if the key doesn't exist in the Ansible context that we don't get a KeyError
    assert cliargs_deferred_get('notakey')() is None

    #
    # Test default provided
    #
    # Verify if the key doesn't exist in the Ansible context that we don't get a KeyError
    assert cliargs_deferred_get('notakey', default='default value')() == 'default value'

    #
    # Test shallow copy functionality
    #
    # Verify the shallow copy functionality doesn't throw a TypeError for iterables
    assert cliargs_deferred_get('notakey', shallowcopy=True)() is None
    assert cliargs_deferred_get('notakey', deepcopy=True)() is None

    # Init the

# Generated at 2022-06-10 23:05:55.521714
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for function cliargs_deferred_get"""
    from ansible.module_utils.common._collections_compat import Mapping
    # Test getting a value that is present in the context
    _init_global_context({'key1': 'value1'})
    assert cliargs_deferred_get('key1')() == 'value1'

    # Test getting a value that is not present in the context
    # Defaults not set, returns None
    assert cliargs_deferred_get('key2')() is None
    # Defaults set, returns default
    assert cliargs_deferred_get('key2', default='value2')() == 'value2'

    # Test copying sequences
    _init_global_context({'key3': [1, 2, 3]})
    assert cliargs_def

# Generated at 2022-06-10 23:06:05.262217
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestC:
        value = cliargs_deferred_get('v')

    t1 = TestC()
    assert t1.value == None
    CLIARGS['v'] = 'foo'
    assert t1.value == 'foo'

    t2 = TestC()
    assert t2.value == None
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert t2.value == None

    # Test shallowcopy
    CLIARGS['v'] = ['a', 'b']
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options(CLIARGS)
    t3 = TestC()
    assert t3.value == ['a', 'b']
    t3.value.append('c')

# Generated at 2022-06-10 23:06:13.062474
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    args = {'foo': 1, 'bar': ['a', 'b', 'c'], 'baz': {'q': 1}}
    CLIARGS = CLIArgs(args)
    assert cliargs_deferred_get('foo')() == 1
    assert cliargs_deferred_get('bar')() == ['a', 'b', 'c']
    assert cliargs_deferred_get('baz')() == {'q': 1}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 1
    assert cliargs_deferred_get('bar', shallowcopy=True)() == ['a', 'b', 'c']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == {'q': 1}

# Generated at 2022-06-10 23:06:23.694855
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 'bar', 'baz': [1], 'bing': {'ram': 'bam'}, 'brem': {'snip', 'snap'}})
    cli_args_dict = {}
    for key in CLIARGS:
        cli_args_dict[key] = cliargs_deferred_get(key, shallowcopy=True)

    # check that the regular values are the same
    assert CLIARGS.get('foo') == cli_args_dict['foo']()
    assert CLIARGS.get('baz') == cli_args_dict['baz']()
    assert CLIARGS.get('bing') == cli_args_dict['bing']()
    assert CLIARGS.get('brem') == cli_args_dict['brem']()

    #

# Generated at 2022-06-10 23:06:35.247796
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    data = {'answer': 42, 'list': [1, 2, 3], 'dict': {'key': 'value'}}
    CLIARGS = CLIArgs(data)

    assert cliargs_deferred_get('answer')() == 42
    assert cliargs_deferred_get('answer')(shallowcopy=True) == 42

    assert cliargs_deferred_get('list')() == [1, 2, 3]
    assert cliargs_deferred_get('list')(shallowcopy=True) == [1, 2, 3]

    assert cliargs_deferred_get('dict')() == {'key': 'value'}
    assert cliargs_deferred_get('dict')(shallowcopy=True) == {'key': 'value'}

    assert cliargs

# Generated at 2022-06-10 23:06:42.845867
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.context_objects import GlobalCLIArgs
    from ansible.module_utils.common.collections import ImmutableDict, to_native
    from ansible.module_utils.common.validation import check_type_dict

    check_type_dict(ImmutableDict())
    expected_dict = to_native(ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4}))
    test_dict = to_native(ImmutableDict({'a': 1, 'b': 2, 'c': 3, 'd': 4}))

    expected_copy = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-10 23:06:53.601390
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from .shippable import HasAttribute
    from .shippable import assert_that
    import itertools
    import operator
    import tempfile
    import os
    from ansible.cli.arguments import optparser

    with tempfile.NamedTemporaryFile() as temp:
        temp.write('[defaults]\nfoo=bar\n')
        temp.flush()
        os.environ[b'ANSIBLE_CONFIG'] = temp.name

    (options, parser) = optparser()
    options.ansible_config = os.environ.get(b'ANSIBLE_CONFIG')
    options.connection = 'smart'
    _init_global_context(vars(options))

    assert_that(cliargs_deferred_get('connection')(), equal_to('smart'))

    # We need this

# Generated at 2022-06-10 23:07:06.460251
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({'_ansible_connection': 'local'})
    assert cliargs_deferred_get('_ansible_connection')([]) == 'local'
    assert cliargs_deferred_get('_ansible_connection', default='junk')([]) == 'local'
    assert cliargs_deferred_get('_ansible_connection', shallowcopy=True)([]) == 'local'

# Generated at 2022-06-10 23:07:16.648125
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    dc = CLIArgs._dict_class
    CLIARGS._options = dc({'a': 'value'})
    assert cliargs_deferred_get('a')() == 'value'
    assert cliargs_deferred_get('a', default='default')() == 'value'
    assert cliargs_deferred_get('b', default='default')() == 'default'
    assert cliargs_deferred_get('b')() is None
    assert cliargs_deferred_get('a', shallowcopy=True)() == 'value'
    CLIARGS._options = dc({'a': [1, 2, 3]})
    value = cliargs_deferred_get('a', shallowcopy=True)()
    assert value is not None

# Generated at 2022-06-10 23:07:18.481213
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

# Generated at 2022-06-10 23:07:29.700156
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This can only be tested once we have the CLIARGS
    global CLIARGS
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')('baz') == 'baz'

    CLIARGS['my_list'] = [1, 2, 3]
    assert cliargs_deferred_get('my_list', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('my_list', deepcopy=True)() == [1, 2, 3]

    CLIARGS['my_dict'] = {'a': 1, 'b': 2}

# Generated at 2022-06-10 23:07:35.468573
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    import copy
    def bar(x):
        CLIARGS['foo'] = x
    class Foo:
        baz = cliargs_deferred_get('foo', default=42)

    foo = Foo()
    assert foo.baz() == 42
    bar(56)
    assert foo.baz() == 56
    bar(['a'])
    x = foo.baz(shallowcopy=True)
    x.append('b')
    assert foo.baz() == ['a']

    bar(['a'])
    x = foo.baz()
    x.append('b')
    assert foo.baz() == ['a', 'b']

    bar({'a': 42, 'b': 56})
    x = foo.b

# Generated at 2022-06-10 23:07:46.110476
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['hello'] = 'world'
    assert cliargs_deferred_get('hello')() == 'world'

    CLIARGS['hello'] = ['world']
    assert cliargs_deferred_get('hello', shallowcopy=True)() == ['world']
    CLIARGS['hello'].append('moon')
    assert cliargs_deferred_get('hello', shallowcopy=True)() == ['world', 'moon']

    CLIARGS['hello'] = set(['world'])
    assert cliargs_deferred_get('hello', shallowcopy=True)() == set(['world'])
    CLIARGS['hello'].add('moon')
    assert cliargs_deferred_get('hello', shallowcopy=True)() == set(['world', 'moon'])

# Generated at 2022-06-10 23:07:56.419985
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIContext
    from ansible.utils.context_objects import CLIARGS
    from tempfile import NamedTemporaryFile
    from ansible.module_utils.six import PY3

    global CLIARGS

    def write_context(vars_file, context):
        # Write the environment vars to the vars_file
        cli_args = context.__dict__.copy()
        cli_args['vars_files'] = [vars_file.name]
        cli_args = CLIContext(cli_args)
        vars_file.write(b'---\n')

# Generated at 2022-06-10 23:08:08.542183
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Verify expected behavior of cliargs_deferred_get"""

    # Importing test requires pytest, so this is not done in a setUp()
    # method to avoid requiring pytest for the the unit tests in
    # ansible.module_utils
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY2, PY3
    from ansible.tests.unit.compat import mock
    from ansible.tests.unit.compat.mock import MagicMock, call

    # Since we want to verify that these are shallow copies, we need to use the
    # (somewhat) magic methods __eq__ and __hash__.  Instead, we use
    # to_bytes and to_text to get the repr() and a standard comparison
    string_default

# Generated at 2022-06-10 23:08:19.336977
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    def cliargs_append(obj, key, val):
        global CLIARGS
        copy = obj.copy()
        copy[key] = val
        CLIARGS = CLIArgs(copy)

    CLIARGS = CLIArgs({})
    value = cliargs_deferred_get('foo')()
    assert value is None

    cliargs_append(CLIARGS, 'foo', ['bar'])
    value = cliargs_deferred_get('foo')()
    assert value == ['bar']
    value2 = cliargs_deferred_get('foo', shallowcopy=True)()
    assert value2 is not value

    cliargs_append(CLIARGS, 'foo', 123)
    value = cliargs_deferred_get('foo')()
    assert value == 123

# Generated at 2022-06-10 23:08:24.397909
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def init():
        global CLIARGS
        CLIARGS = CLIArgs({'tuple': ('tuple',)})

    def cleanup():
        global CLIARGS
        CLIARGS = CLIArgs({})

    func = cliargs_deferred_get('tuple', default='tuple')
    try:
        assert func() == 'tuple'

        init()
        assert func() == ('tuple',)

        init()
        assert func(shallowcopy=True) == ('tuple',)

    finally:
        cleanup()

# Generated at 2022-06-10 23:08:42.953195
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test defaults
    key = 'test'
    default = 'value'
    assert cliargs_deferred_get(key, default)() == default
    assert cliargs_deferred_get(key, default, shallowcopy=True)() == default
    # Test keys in cliargs
    cliargs = {key: 'value'}
    _init_global_context(cliargs)
    assert cliargs_deferred_get(key, default)() == 'value'
    assert cliargs_deferred_get(key, default, shallowcopy=True)() == 'value'
    # Make sure deepcopy of lists works
    cliargs[key] = [1, 2, 3]
    assert cliargs_deferred_get(key, default)() == [1, 2, 3]
    assert cliargs

# Generated at 2022-06-10 23:08:55.573045
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.singleton import Singleton
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    CLIARGS = GlobalCLIArgs.from_options({'ANSIBLE_STRATEGY': 'async'})

    Singleton._instances = {}

    fake_option = cliargs_deferred_get('ANSIBLE_STRATEGY')
    assert(fake_option() == 'async')

    CLIARGS.update(dict(ANSIBLE_STRATEGY='free'))
    assert(fake_option() == 'free')

    fake_option2 = cliargs_deferred_get('ANSIBLE_STRATEGY', default='modified')
    assert(fake_option2() == 'free')

    CLIARGS.update(dict(ANSIBLE_STRATEGY='modified'))

# Generated at 2022-06-10 23:09:04.792954
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get

    We create a GlobalCLIArgs and then replace CLIARGS with it.  Since the previous
    CLIARGS wasn't really used (it was just created and immediately replaced) we
    don't need to restore it"""
    global CLIARGS
    CLIARGS = GlobalCLIArgs(dict(
        a_string='hello world',
        a_list=['one', 'two', 'three'],
        a_set=set(('one', 'two', 'three')),
        a_dict=dict(key='value', key2='value2'),
    ))
    assert CLIARGS['a_string'] == cliargs_deferred_get('a_string')()
    list_closure = cliargs_deferred_get('a_list', default=[])
    assert CLI

# Generated at 2022-06-10 23:09:14.754581
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Disabling docstring lint because the function under test is not directly bound to test_cliargs_deferred_get
    # pylint: disable=missing-docstring
    global CLIARGS
    # test calling with no key
    def default():
        return 'default is called'

    assert cliargs_deferred_get(None, default)() == 'default is called'
    CLIARGS = CLIArgs({'key': 'value'})

    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('notakey', default)() == 'default is called'
    assert cliargs_deferred_get('notakey', default='other')() == 'other'

    CLIARGS = CLIArgs({'dict': {'key': 'value'}})

# Generated at 2022-06-10 23:09:18.812545
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'bin_ansible_callbacks': True, 'lookup_plugins': 'lookupplugins'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('lookup_plugins') == 'lookupplugins'

# Generated at 2022-06-10 23:09:25.291109
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence

    def test_get_values(cliargs_value, shallowcopy, expected):
        # CLIARGS is used by cliargs_deferred_get so we need to reset it to a value
        # for each test
        global CLIARGS
        cliargs_obj = CLIArgs({})
        cliargs_obj[u'key'] = cliargs_value
        CLIARGS = cliargs_obj
        get_func = cliargs_deferred_get('key', shallowcopy=shallowcopy)
        assert get_func() == expected
    # Test with a list
    test_get_values([1, 2, 3], False, [1, 2, 3])

# Generated at 2022-06-10 23:09:36.338805
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import sys
    from collections import namedtuple
    from ansible.utils.context_objects import GlobalCLIArgs

    def fake_cli_args(**kwargs):
        return namedtuple('Options', kwargs.keys())(**kwargs)

    def fake_global_cli_args(options):
        return GlobalCLIArgs.from_options(options)

    ORIG_CLIARGS = CLIARGS
    CLIARGS = None
    orig_argv = sys.argv
    sys.argv = ['ansible-playbook']


# Generated at 2022-06-10 23:09:45.210760
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test global cliargs state
    orig_cliargs = CLIARGS

    # Test in a list
    cliargs_list = [('default', 'default'), ('value', 'value'), ('mapping', {'a': 'b'})]
    cliargs = CLIArgs(cliargs_list)
    CLIARGS = cliargs

    assert cliargs_deferred_get('missing', default='default')() == 'default', \
        'Incorrect default value'
    assert cliargs_deferred_get('default', default='extra')() == 'default', \
        'Incorrect final value'
    assert cliargs_deferred_get('value', default='extra')() == 'value', \
        'Incorrect final value'

    # Test in a dict

# Generated at 2022-06-10 23:09:57.329250
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'lol': ['first', 'second']})

    # Test getting a value.  This is the main reason to have this function
    default = cliargs_deferred_get('foo')
    assert default() == 'bar'

    # Test getting a single valued arg
    no_default = cliargs_deferred_get('foo', None, False)
    assert no_default() == 'bar'

    # Test getting a list
    no_default = cliargs_deferred_get('lol', None, False)
    assert no_default() == ['first', 'second']
    no_default = cliargs_deferred_get('lol', None, True)
    assert no_default() == ['first', 'second']
    no_default = cliargs

# Generated at 2022-06-10 23:10:05.032470
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test_key': 'test_value'})
    assert cliargs_deferred_get('test_key')() == 'test_value'
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('test_key', default='default_value')() == 'default_value'
    CLIARGS = CLIArgs({'test_key': 'test_value'})
    assert cliargs_deferred_get('test_key', shallowcopy=True)() == 'test_value'
    assert cliargs_deferred_get('test_key', shallowcopy=False)() == 'test_value'

# Generated at 2022-06-10 23:10:33.037898
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is the function to test
    from ansible.module_utils import context_objects
    # Create a dummy version of cli_args.  Note that it doesn't have to have
    # the same structure as the real cli args since we are only testing the
    # inner function
    global CLIARGS
    CLIARGS = context_objects.CLIArgs({'user': 'bob', 'password': 'wonderland'})

    # direct lookup
    test_value = cliargs_deferred_get('user')()
    assert test_value == CLIARGS['user']

    # default value
    test_value = cliargs_deferred_get('does', 'not', 'exist')()
    assert test_value == 'not'
    assert test_value is not None

    # shallowcopy
    test_value = cli

# Generated at 2022-06-10 23:10:40.294904
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    result = cliargs_deferred_get('does_not_exist', default=1)()
    assert result == 1
    result = cliargs_deferred_get('does_not_exist', default=1, shallowcopy=True)()
    assert result == 1
    result = cliargs_deferred_get('does_not_exist', default=[1])()
    assert result == [1]
    result = cliargs_deferred_get('does_not_exist', default=[1], shallowcopy=True)()
    assert result == [1]
    result = cliargs_deferred_get('does_not_exist', default={'foo': 1})()
    assert result == {'foo': 1}

# Generated at 2022-06-10 23:10:51.248013
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import is_sequence
    # pylint: disable=redefined-outer-name
    global CLIARGS  # pylint: disable=global-statement

    # Test getting a key which is not present.  The other tests are the same as the
    # setter tests in module_utils/ansible_test/test_common_collections.py
    assert cliargs_deferred_get('something', default='default')() == 'default'

    # Test getting a value which is present
    CLIARGS = CLIArgs({'something': 'value'})
    assert cliargs_deferred_get('something')() == 'value'

    # Test getting a value which is present with a shallow copy
    CLIARGS = CLI

# Generated at 2022-06-10 23:10:56.725850
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': 'bar'})

    # pylint: disable=unbalanced-tuple-unpacking
    # pylint: disable=keyword-arg-before-vararg
    assert ('bar', None) == (cliargs_deferred_get('foo')(), cliargs_deferred_get('bar')())
    # pylint: enable=keyword-arg-before-vararg
    # pylint: enable=unbalanced-tuple-unpacking

    # pylint: disable=unbalanced-tuple-unpacking
    # pylint: disable=keyword-arg-before-vararg
    assert ('baz', 'default') == (cliargs_deferred_get('foo', 'baz')(), cliargs_deferred_get('bar', 'default')())
   

# Generated at 2022-06-10 23:11:01.609434
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test_key': 1})
    assert cliargs_deferred_get('test_key')() == 1
    assert cliargs_deferred_get('test_key_2', 2)() == 2
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('test_key_3')(lambda:3) == 3

# Generated at 2022-06-10 23:11:07.636642
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Set up global context with some values
    _init_global_context(dict(a=1, b=dict(c=2), d=[1, 2, 3]))

    # Test that we can get the values from CLIARGS
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == dict(c=2)
    assert cliargs_deferred_get('d')() == [1, 2, 3]

    # Test that we get a default when it's not there
    assert cliargs_deferred_get('x', default='x')() == 'x'

    # Test that we get a shallow copy of mutable values when requested
    value = cliargs_deferred_get('b', shallowcopy=True)()

# Generated at 2022-06-10 23:11:18.492457
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible import context
    from unittest import TestCase
    test_cases = TestCase()
    # Test with default value
    test_key = 'test_key'
    test_value = 'test'
    def_value = 'default'
    context.CLIARGS['test_key'] = test_value
    test_cases._assertEqual(cliargs_deferred_get(test_key)(), test_value)
    test_cases._assertEqual(cliargs_deferred_get(test_key, default=def_value)(), test_value)
    test_cases.assertIs(cliargs_deferred_get(test_key, default=def_value, shallowcopy=True)(), test_value)

# Generated at 2022-06-10 23:11:30.275344
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'
    get_value = cliargs_deferred_get('foo', 42)
    assert get_value() == 'bar'
    CLIARGS['foo'] = 42
    assert get_value() == 42

    CLIARGS['foo_seq'] = [1, 2, 3]
    get_value = cliargs_deferred_get('foo_seq', [])
    assert get_value() == [1, 2, 3]
    CLIARGS['foo_seq'] = [4, 5, 6]
    assert get_value() == [1, 2, 3]
    get_value = cliargs_deferred_get('foo_seq', [], shallowcopy=True)
    assert get_value() == [4, 5, 6]


# Generated at 2022-06-10 23:11:39.041052
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function ``cliargs_deferred_get``"""
    test_dict = {'a': 'b'}

    # a basic get that doesn't exist
    result = cliargs_deferred_get('c')()
    assert result is None

    # an existing non-collection object
    result = cliargs_deferred_get('a')(default='c')
    assert result == 'c'
    CLIARGS['a'] = 'd'
    result = cliargs_deferred_get('a')(default='c')
    assert result == 'd'

    # an existing collection object
    result = cliargs_deferred_get('b')(default=test_dict)
    assert result == test_dict
    CLIARGS['b'] = test_dict

# Generated at 2022-06-10 23:11:50.354902
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Test that it works with CLIARGS being replaced
    CLIARGS = CLIArgs({'a': 1})
    assert cliargs_deferred_get('a')() == 1
    CLIARGS = CLIArgs({'b': 2})
    assert cliargs_deferred_get('b')() == 2

    CLIARGS = CLIArgs({'a': 1})
    fg = cliargs_deferred_get('a')
    assert fg() == 1
    CLIARGS = CLIArgs({'b': 2})
    assert fg() == 1

    # Test that it returns a different container when shallowcopy=True
    CLIARGS = CLIArgs({'a': [1]})