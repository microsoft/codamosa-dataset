

# Generated at 2022-06-10 23:02:07.087873
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # these tests are not very comprehensive because they can't be, the function is a closure
    # over ``CLIARGS``, which is a singleton, and we can't access it in tests.  This is just
    # here as a basic sanity check
    #
    # first, bound to a singleton
    global CLIARGS
    cli_args = {'some_key': 'some_value', 'other_key': {'inner_key': 'inner_value'}}
    CLIARGS = CLIArgs(cli_args)
    some_value = cliargs_deferred_get('some_key')()
    assert some_value == cli_args['some_key']
    other_value = cliargs_deferred_get('other_key')()
    assert other_value == cli_args['other_key']
   

# Generated at 2022-06-10 23:02:17.097652
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    b = {'a': 1, 'b': '2', 'c': [0, 1, 2]}
    CLIARGS['b'] = b
    get_b = cliargs_deferred_get('b')
    assert get_b() is b
    get_b_shallowcopy = cliargs_deferred_get('b', shallowcopy=True)
    assert get_b_shallowcopy() is not b
    assert get_b_shallowcopy() == b

    assert get_b_shallowcopy()['c'] is b['c']

    get_b_deepcopy = cliargs_deferred_get('b', shallowcopy=False)
    assert get_b_deepcopy() is not b
    assert get_b_deepcopy() == b

# Generated at 2022-06-10 23:02:28.498786
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('missing', default='foo') == 'foo'
    CLIARGS['existing'] = 'bar'
    assert cliargs_deferred_get('existing', default='foo') == 'bar'
    assert cliargs_deferred_get('missing') is None
    CLIARGS['existing'] = ['foo', 'bar']
    assert cliargs_deferred_get('existing', shallowcopy=False) == ['foo', 'bar']
    assert cliargs_deferred_get('existing', shallowcopy=True) == ['foo', 'bar']
    CLIARGS['existing'] = {'foo': 'bar'}
    assert cliargs_deferred_get('existing', shallowcopy=False) == {'foo': 'bar'}

# Generated at 2022-06-10 23:02:35.520716
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test_key':'test_value'})
    assert cliargs_deferred_get('test_key')() == 'test_value'
    assert cliargs_deferred_get('missing_key')() is None
    assert cliargs_deferred_get('missing_key', 1)() == 1
    assert cliargs_deferred_get('test_key', shallowcopy=True)() == 'test_value'

    l = [1, 2, 3]
    CLIARGS = CLIArgs({'shallow_list': l})
    shallow = cliargs_deferred_get('shallow_list', shallowcopy=True)()
    assert shallow is not l
    assert shallow == l

# Generated at 2022-06-10 23:02:40.847811
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""

    # Test with no CLIARGS set
    inner = cliargs_deferred_get('test')
    assert inner() is None

    # Test with CLIARGS set only
    _init_global_context({'test': object()})
    assert inner() is not None



# Generated at 2022-06-10 23:02:49.459819
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    import copy
    actual = copy.deepcopy(CLIARGS)
    def1 = cliargs_deferred_get('namespace_name', 'default')
    def2 = cliargs_deferred_get('namespace_name', 'default', shallowcopy=True)
    def3 = cliargs_deferred_get('namespace_name')
    assert actual == CLIARGS
    # Test basic functionality
    _init_global_context({'namespace_name': 'unittest_name'})
    assert CLIARGS.namespace_name() == 'unittest_name'
    assert def1() == 'unittest_name'
    # Test with a value that should do a shallow copy
    assert actual == CLIARGS

# Generated at 2022-06-10 23:03:02.538250
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # initialize a global variable cli_args
    cli_args = {'foo': 'bar'}

    # initialize global context
    _init_global_context(cli_args)

    # this is the test on cliargs_deferred_get function
    returned_func = cliargs_deferred_get('foo', 'baz')
    assert returned_func() == 'bar'

    returned_func = cliargs_deferred_get('nope', 'baz')
    assert returned_func() == 'baz'

    # Set a new variable
    cli_args['baz'] = 'asdf'

    # This should return the value in the new variable 'baz'
    assert cliargs_deferred_get('baz')(), 'asdf'
    # NOTE: This function should have "()" at

# Generated at 2022-06-10 23:03:14.211732
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from copy import copy
    from ansible.module_utils.six import PY3

    # We don't want to re-initialize the CLIARGS object because then we'll have a bunch of
    # other stuff set in it.  So we make a new one just for testing
    global CLIARGS
    oldcliargs = CLIARGS

# Generated at 2022-06-10 23:03:22.722029
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=too-few-public-methods
    class Inner():
        """Dummy class that doesn't have a get method"""
        pass

    CLIARGS.set('foo', 'bar')
    inner = cliargs_deferred_get('foo')
    assert(inner() == 'bar')
    assert(inner() is cliargs_deferred_get('foo')())

    # Test that cliargs_deferred_get is not bound to CLIARGS so it can be swapped in the unit tests
    cliargs = CLIA

# Generated at 2022-06-10 23:03:33.345359
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'key1': 'value1', 'key2': {'key': 'value'}, 'key3': [1, 2, 3]})
    assert cliargs_deferred_get('key1')() is CLIARGS['key1']
    assert cliargs_deferred_get('key2')() is CLIARGS['key2']
    assert cliargs_deferred_get('key3')() is CLIARGS['key3']
    assert cliargs_deferred_get('key1', shallowcopy=True)() is not CLIARGS['key1']
    assert cliargs_deferred_get('key2', shallowcopy=True)() is not CLIARGS['key2']

# Generated at 2022-06-10 23:03:52.115365
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 1}, 'd': set([1, 2, 3, 4])})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('a', default=10)() == 1
    assert cliargs_deferred_get('f', default=[])(), []
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('b', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 1}

# Generated at 2022-06-10 23:04:04.793189
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    test_dict = {'a': 1, 'b': '2'}
    test_list = [1, 2, 3]
    test_set = {1, 2, 3}
    test_str = 'test'
    test_tuple = (1, 2, 3)
    test_int = 1

    assert (copy.copy(test_dict) == cliargs_deferred_get('a')())
    assert (test_dict == cliargs_deferred_get('a', shallowcopy=False)())
    assert (copy.copy(test_list) == cliargs_deferred_get('b')())
    assert (test_list == cliargs_deferred_get('b', shallowcopy=False)())

# Generated at 2022-06-10 23:04:15.427048
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy

    class TestCliArgs(object):
        def __init__(self, options):
            self._options = options

        def get(self, key, default=None):
            return self._options.get(key, default)

    expected = {'key1': {'key2': 'key3'}}
    actual = TestCliArgs(expected)
    assert(expected == actual.get('key1'))
    actual_default = TestCliArgs({})
    assert({} == actual_default.get('key12', {}))

    result = cliargs_deferred_get('key1')()
    assert(expected == result)
    assert(expected == result)

    result2 = cliargs_deferred_get('key12', {})()
    assert({} == result2)

# Generated at 2022-06-10 23:04:25.930865
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works"""
    import unittest

    class TestCliargsDeferredGet(unittest.TestCase):
        def setUp(self):
            from ansible.module_utils.common._collections_compat import Mapping

            class CliArgsMock(Mapping):
                def __init__(self):
                    self.data = {'shallowcopy': [1, 2],
                                 'deepcopy': {'foo': 'bar'},
                                 'simple': 'simple'}
                def __getitem__(self, key):
                    return self.data.__getitem__(key)
                def __iter__(self):
                    return self.data.__iter__()
                def __len__(self):
                    return self.data.__len__()

            cli

# Generated at 2022-06-10 23:04:36.644738
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from copy import copy

    CLIARGS['foo'] = [1, 2]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2]
    assert cliargs_deferred_get('foo', shallowcopy=False)() is CLIARGS['foo']
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=False)() is CLIARGS['foo']
    CLIARGS['foo'] = {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'a': 1, 'b': 2}

# Generated at 2022-06-10 23:04:43.526902
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for cliargs_deferred_get
    """
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import _init_global_context
    from ansible.utils.context_objects import cliargs_deferred_get
    from copy import copy
    from copy import deepcopy

    cli_args = dict(foo='bar',
                    baz=[1, 2, 3],
                    quux={'quux1': 'quux2'},
                    barbaz=set([1, 2, 3, 4]),
                   )
    # Make the global object based on the args, this is what happens on program startup
    _init_global_context(cli_args)

    # When we initialize a new object this is the function which provides
    # CLIARGS.get functionality
   

# Generated at 2022-06-10 23:04:55.553352
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_dict = CLIARGS.asdict()
    cliargs_dict['foo'] = 'bar'
    cliargs_dict['bam'] = 'nope'
    cliargs_dict['fiddle'] = {'one': 'two', 'three': 'four'}
    cliargs_dict['fado'] = ['one']
    cliargs_dict['fado'].append('two')
    cliargs_dict['fado'].append('three')

    func = cliargs_deferred_get('foo')
    assert func() == 'bar'

    func = cliargs_deferred_get('fiddle', shallowcopy=True)
    assert func() == {'one': 'two', 'three': 'four'}

# Generated at 2022-06-10 23:05:07.033324
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS._options = {'a': 1}
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')(default=2) == 2
    assert cliargs_deferred_get('a')(shallowcopy=True) == 1
    assert cliargs_deferred_get('b')(default=[3], shallowcopy=True) == [3]
    assert cliargs_deferred_get('a')(shallowcopy=True) == 1
    assert cliargs_deferred_get('b')(default=set([4]), shallowcopy=True) == set([4])
    assert cliargs_deferred_get('a')(shallowcopy=True) == 1

# Generated at 2022-06-10 23:05:15.667159
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # only need a minimal CLIArgs object
    cli_args = CLIArgs(dict(a=5, b=[5, 6], c={5: 6}))
    assert cli_args.a == cliargs_deferred_get('a')()
    assert cli_args.b is not cliargs_deferred_get('b', shallowcopy=True)()
    assert cli_args.b == cliargs_deferred_get('b', shallowcopy=True)()
    assert cli_args.c is not cliargs_deferred_get('c', shallowcopy=True)()
    assert cli_args.c == cliargs_deferred_get('c', shallowcopy=True)()

# Generated at 2022-06-10 23:05:19.538146
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({'foo': 'bar'})
    closure = cliargs_deferred_get('foo')
    assert closure() == 'bar'

    closure = cliargs_deferred_get('bar')
    assert closure() == None

# Generated at 2022-06-10 23:05:37.416579
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence, equal_attributes_dict

    cliargs = GlobalCLIArgs({'a': 1, 'b': {'c': 2, 'd': 3}, 'e': [4, 5, 6], 'f': 7})

    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == {'c': 2, 'd': 3}
    assert cliargs_deferred_get('e')() == [4, 5, 6]
    assert cliargs_deferred_get('f')() == 7

    assert cliargs_deferred_get('a', shallowcopy=True)() == 1

# Generated at 2022-06-10 23:05:45.409194
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert (cliargs_deferred_get('not_present', default='default')()) == 'default'
    CLIARGS.update({'present': 'value'})
    assert (cliargs_deferred_get('present')()) == 'value'
    assert (cliargs_deferred_get('present', default='default')()) == 'value'
    CLIARGS.update({'mutables': {'key': 'value'}})
    assert (cliargs_deferred_get('mutables')()) == {'key': 'value'}
    new_dict = cliargs_deferred_get('mutables')()
    new_dict['key'] = 'new value'
    assert (cliargs_deferred_get('mutables')()) == {'key': 'value'}

# Generated at 2022-06-10 23:05:55.523324
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_dict = {'foo': 'bar'}
    CLIARGS.update(test_dict)

    # Tests from docstring

    # Basic usage
    assert cliargs_deferred_get('foo')() == 'bar'

    # Default usage
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

    # Shallow copy
    cliargs_deferred_get('foo')(shallowcopy=True) == 'bar'
    cliargs_deferred_get('foo')(shallowcopy=True) is not 'bar'

    # Test that shallowcopy doesn't return a shallowcopy if it's not a
    # sequence or mapping or set
    assert cliargs_deferred_get('foo', default=1)(shallowcopy=True) == 1

    # Test that

# Generated at 2022-06-10 23:06:05.261269
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test ``cliargs_deferred_get``"""
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo')(), 'foo was not returned'
    assert cliargs_deferred_get('foo', default=1)(), 1
    CLIARGS = CLIArgs({'foo': 1})
    assert cliargs_deferred_get('foo')(), 1
    assert cliargs_deferred_get('foo', default=2)(), 1
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo')(), [1, 2, 3]
    assert cliargs_deferred_get('foo', default=2)(), [1, 2, 3]
    assert cliargs_def

# Generated at 2022-06-10 23:06:13.063260
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''Verify that our deferred get function works'''
    assert cliargs_deferred_get('foo')() is None
    test_args = {'foo': 'foo_val', 'bar': ['bar_val1', 'bar_val2'], 'baz': {'baz_key': 'baz_val1'}}
    _init_global_context(test_args)
    assert cliargs_deferred_get('foo')() == 'foo_val'
    assert cliargs_deferred_get('bar')() == ['bar_val1', 'bar_val2']
    assert cliargs_deferred_get('baz')() == {'baz_key': 'baz_val1'}


# Generated at 2022-06-10 23:06:22.738616
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Verify function ``cliargs_deferred_get`` behaves as expected"""
    _init_global_context(dict(foo='bar'))
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('foo', default='biz') == 'bar'
    assert cliargs_deferred_get('biz', default='baz') == 'baz'
    _init_global_context(dict(foo=['bar', 'baz']))
    assert cliargs_deferred_get('foo', shallowcopy=True) == ['bar', 'baz']
    assert cliargs_deferred_get('foo') == ['bar', 'baz']

# Generated at 2022-06-10 23:06:33.399751
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    import copy

    class test_class(object):
        def __init__(self):
            self.t_int = 100
            self.t_list = [1, 2]
            self.t_set = set(self.t_list)
            self.t_dict = {'one': 1, 'two': 2}
            self.t_obj = test_class()
            self.test_dict = {
                't_int': 100,
                't_list': [1, 2],
                't_set': self.t_set,
                't_dict': self.t_dict,
                't_obj': self.t_obj
            }

    CLIARGS = CLIArgs({})
    test_obj = test_class()

# Generated at 2022-06-10 23:06:45.254233
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [2, 3], 'c': {'d': 4, 'e': [5, 6]}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [2, 3]
    assert cliargs_deferred_get('c')() == {'d': 4, 'e': [5, 6]}

    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('b', shallowcopy=True)() == [2, 3]
    assert cliargs_deferred_get('c', shallowcopy=True)() == {'d': 4, 'e': [5, 6]}

   

# Generated at 2022-06-10 23:06:56.656367
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    import pprint
    class CliArgs(object):
        def __init__(self, value):
            self.value = value

        def get(self, key, default=None):
            return self.value

    # These are all just straight up keys.  We should get them back verbatim
    cli_args = CliArgs(42)
    value = cliargs_deferred_get('a_key', default=None)()
    assert value == 42
    # Verify that we got a fresh copy
    assert value != cli_args.value

    cli_args = CliArgs(42.5)
    value = cliargs_deferred_get('a_key', default=None)()
    assert value == 42.5
    # Verify that we got a fresh copy
    assert value != cli_

# Generated at 2022-06-10 23:07:02.444869
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIA = CLIArgs({'a': 1, 'b': ['foo', 'bar'], 'c': {'k': 'v'}})
    assert 1 == cliargs_deferred_get('a')(CLIA)
    assert cliargs_deferred_get('b', default=[])() == ['foo', 'bar']
    assert cliargs_deferred_get('c', shallowcopy=True)() == {'k': 'v'}

# Generated at 2022-06-10 23:07:21.955941
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # testing of the inner function is not possible because it is a closure
    # and there is no good way to get access to it
    # pytest.raises(KeyError, CLIARGS.__getitem__, 'foo')
    cliargs_deferred_get('foo')().should.equal(None)
    CLIARGS['foo'] = 5
    cliargs_deferred_get('foo')().should.equal(5)
    cliargs_deferred_get('foo', shallowcopy=True)().should.equal(5)
    CLIARGS['foo'] = (1, 2)
    cliargs_deferred_get('foo')().should.equal((1, 2))

# Generated at 2022-06-10 23:07:31.050329
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_dict = {'key': 'value'}
    CLIARGS.setdefault('key', 'default')
    assert(cliargs_deferred_get('key')() == 'default')
    CLIARGS['key'] = 'realvalue'
    assert(cliargs_deferred_get('key')() == 'realvalue')
    CLIARGS['key'] = test_dict
    assert(cliargs_deferred_get('key')() == test_dict)
    assert(cliargs_deferred_get('missing', default='value')() == 'value')
    assert(cliargs_deferred_get('missing', default=test_dict)() == test_dict)

# Generated at 2022-06-10 23:07:40.961697
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Test that the closure returns the value set by the setter
    test_value = 'test_value'
    cli_args_update = dict(test_key=test_value)
    _init_global_context(cli_args_update)
    assert cliargs_deferred_get('test_key')() == test_value

    # Test that the closure returns the default value when not set
    assert cliargs_deferred_get('another_key', 'default')(), 'default'

    # Test that the closure returns a shallow copy when asked for
    test_value = ['list', 'of', 'values']
    cli_args_update = dict(test_key=test_value)
    _init_global_context(cli_args_update)

# Generated at 2022-06-10 23:07:51.713462
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test(val, default, shallowcopy):
        global CLIARGS
        CLIARGS = CLIArgs({'key': val})
        value = cliargs_deferred_get('key', default=default, shallowcopy=shallowcopy)()
        assert value == val
        if val is not None:
            if shallowcopy:
                assert value is not val
            else:
                assert value is val

    test(42, 43, False)
    test(42, 43, True)

    test([1, 2, 3, 4], [], False)
    test([1, 2, 3, 4], [], True)

    test({'a': 'one', 'b': 'two'}, {}, False)
    test({'a': 'one', 'b': 'two'}, {}, True)

    test(None, None, False)

# Generated at 2022-06-10 23:07:59.911522
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2], 'c': {'d': 3}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2]
    assert cliargs_deferred_get('c')() == {'d': 3}
    assert cliargs_deferred_get('d')() is None
    assert cliargs_deferred_get('a', default=2)() == 1
    assert cliargs_deferred_get('d', default=2)() == 2
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1

# Generated at 2022-06-10 23:08:11.640452
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # The class is directly tested in ansible.module_utils.common.context_objects.test_cli_args
    # This is just to test the function
    from ansible.module_utils.common.context_objects import CLIArgs
    args = {'list': [1, 2, 3]}
    CLIARGS.update(args)
    assert cliargs_deferred_get('list')() == CLIARGS.get('list')
    assert cliargs_deferred_get('list', shallowcopy=True)() == CLIARGS.get('list')
    assert cliargs_deferred_get('list')() is CLIARGS.get('list')
    assert cliargs_deferred_get('list', shallowcopy=True)() is not CLIARGS.get('list')

# Generated at 2022-06-10 23:08:21.446684
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # A bit of an integration test...
    from ansible.utils.context_objects import CliArgs
    from ansible.utils.context_objects import DeferredDefaultSpecification
    from ansible.utils.context_objects import cliargs_deferred_get
    from ansible.utils.context_objects import test_cliargs_deferred_get_inner
    from ansible.utils.context_objects import GlobalCLIArgs
    test_cliargs_deferred_get_inner()

    # create a new CLIArgs instance with some defaults
    cliargs = CliArgs({'foo': 'bar', 'a': 1, 'bar': False})
    # get an actual deferred version of the defaults
    deferred_defaults = cliargs.get_deferred_defaults()
    # create one of our own
    custom_deferred_defaults

# Generated at 2022-06-10 23:08:32.807119
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Test the default
    _init_global_context({})
    assert CLIARGS.keys() == set()
    assert cliargs_deferred_get('foo')() is None

    # Test that non-shallow copy returns the value
    _init_global_context({'foo': 'bar'})
    assert 'foo' in CLIARGS
    assert CLIARGS.keys() == {'foo'}
    assert cliargs_deferred_get('foo', shallowcopy=False)() == 'bar'

    # Test that shallow copy returns a copy
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    _init_global_context({'foo': [1, 2, 3]})
    assert cliargs_

# Generated at 2022-06-10 23:08:42.767961
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    # We need to call the return callback when we don't set the value (because the default is set later)
    assert cliargs_deferred_get('option_name')() == None
    assert cliargs_deferred_get('option_name', default='foo')() == 'foo'
    CLIARGS.update({'option_name': 123})
    assert cliargs_deferred_get('option_name')() == 123
    assert cliargs_deferred_get('option_name', default='foo')() == 123

    CLIARGS.update({'option_name': 'foo'})
    assert cliargs_deferred_get('option_name', shallowcopy=True)() == 'foo'

# Generated at 2022-06-10 23:08:55.391061
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == cliargs['foo']
    assert cliargs_deferred_get('bing', shallowcopy=True)() == cliargs.get('bing', default='bing')
    assert cliargs_deferred_get('bing', 'foo', shallowcopy=True)() == cliargs.get('bing', default='foo')
    assert cliargs_deferred_get('foo', shallowcopy=True)() == cliargs['foo']

    cliargs = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == cliargs['foo']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == cliargs

# Generated at 2022-06-10 23:09:31.771345
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('nonexistent', default='test')() == 'test'
    assert CLIARGS.get('nonexistent') is None
    CLIARGS.set_value('nonexistent', 'test')
    assert cliargs_deferred_get('nonexistent', default='test')() == 'test'
    CLIARGS.set_value('nonexistent', 'not_test')
    assert cliargs_deferred_get('nonexistent', default='test')() == 'not_test'

    CLIARGS.set_value('nodefault', 'test')
    assert cliargs_deferred_get('nodefault')() == 'test'
    CLIARGS.set_value('nodefault', 'not_test')

# Generated at 2022-06-10 23:09:36.888515
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def foo():
        return 'bar'

    # Nothing in cliargs
    assert cliargs_deferred_get('non_exist_key')() is None

    # Nothing in cliargs
    assert cliargs_deferred_get('non_exist_key', foo)() == 'bar'

    # Add a value
    CLIARGS['string_value'] = 'bar'
    assert cliargs_deferred_get('string_value', foo)() == 'bar'

    CLIARGS['list_value'] = ['bar', 'baz']
    assert cliargs_deferred_get('list_value')() == ['bar', 'baz']

    # Copy not made by default
    assert cliargs_deferred_get('list_value')().pop() == 'baz'
    assert cliargs_def

# Generated at 2022-06-10 23:09:43.008902
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Shallow copy
    def inner(): return CLIAGRS['foobar']
    inner_func = cliargs_deferred_get('foobar', shallowcopy=True)
    inner_func.__code__ == inner.__code__

    # Regular copy
    def inner(): return CLIAGRS['foobar']
    inner_func = cliargs_deferred_get('foobar', shallowcopy=False)
    inner_func.__code__ == inner.__code__

# Generated at 2022-06-10 23:09:49.766131
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # this should not call the inner function
    assert cliargs_deferred_get('foo')() is None

    # this should call the inner function
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # this should call the inner function
    CLIARGS['baz'] = [1,2,3,4]
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1,2,3,4]

    # this should call the inner function
    CLIARGS['qux'] = {'a': 1, 'b': 2}
    assert cliargs_deferred_get('qux', shallowcopy=True)() == {'a': 1, 'b': 2}

    # this should return the inner function
   

# Generated at 2022-06-10 23:10:01.639276
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pragma: no cover
    cli_vars = {'a': 'foo'}
    old_cliargs = CLIARGS
    _init_global_context(cli_vars)
    # Test None default
    default_none = cliargs_deferred_get('a')
    assert default_none() == 'foo'
    # Test default
    default_value = cliargs_deferred_get('b', default={'b': 'bar'})
    assert default_value() == {'b': 'bar'}
    # Test shallow copy
    default_value_copy = cliargs_deferred_get('b', default={'b': 'bar'}, shallowcopy=True)
    assert default_value_copy() == {'b': 'bar'}
    assert default_value() is not default_value_copy()

# Generated at 2022-06-10 23:10:08.895088
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Make sure the deferred get works"""
    cli_args = {'test_val': 'Value'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('test_val')() == 'Value'
    assert cliargs_deferred_get('other')() is None
    assert cliargs_deferred_get('other', 'Default')() == 'Default'
    assert cliargs_deferred_get('test_val', 'Default')() == 'Value'
    cli_args['list_val'] = ['l1', 'l2']
    assert cliargs_deferred_get('list_val')() == ['l1', 'l2']

# Generated at 2022-06-10 23:10:19.300792
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.dict import type_compat
    from ansible.module_utils.common.collections import is_sequence

    class CliArgs(dict):
        def get(self, k, default=None):
            return dict.get(self, k, default=default)

    CLIARGS['foo'] = [1, 2, 3]
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo')() == [1, 2, 3]

    CLIARGS['bar'] = {'k1': 1, 'k2': 2}
    assert cliargs_deferred_get('bar')()

# Generated at 2022-06-10 23:10:30.619283
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get()."""
    _init_global_context(dict(foo=1))
    assert cliargs_deferred_get('foo')() == 1

    _init_global_context(dict(foo=[1, 2, 3]))
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]

    _init_global_context(dict(foo=dict(bar=1)))
    assert cliargs_deferred_get('foo')() == dict(bar=1)
    assert cliargs_deferred_get('foo', shallowcopy=True)() == dict(bar=1)


# Generated at 2022-06-10 23:10:39.046164
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # normal case
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', 'not_bar')() == 'bar'

    # default case
    assert cliargs_deferred_get('not_foo', 'default')() == 'default'

    # Shallow copy of a list
    CLIARGS = CLIArgs({'foo': [1, 2, 3, 4]})
    value = cliargs_deferred_get('foo', shallowcopy=True)()
    value.append(5)
    assert cliargs_deferred_get('foo')() == [1, 2, 3, 4]

    # shallow copy of a set
    CLIARGS = CLIArgs({'foo': set([1, 2, 3, 4])})

# Generated at 2022-06-10 23:10:48.700436
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('test_key')() is None
    _init_global_context({'test_key': 'test_value'})
    assert cliargs_deferred_get('test_key')() == 'test_value'
    assert cliargs_deferred_get('test_key_copy')() is None
    assert cliargs_deferred_get('test_key_copy', default=['test_value'])() == ['test_value']
    assert cliargs_deferred_get('test_key_copy', default={'foo': 'bar'})() == {'foo': 'bar'}

# Generated at 2022-06-10 23:11:49.323964
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test calling cliargs_deferred_get() with a non-singleton CLIArgs object to ensure that the default behavior is correct"""
    global CLIARGS
    # pylint: disable=consider-using-ternary
    if CLIARGS is CLIArgs:
        old_cliargs = CLIARGS
    else:
        old_cliargs = CLIARGS.copy()
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

# Generated at 2022-06-10 23:11:53.805743
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Add some value to our test CLIARGS
    global CLIARGS
    CLIARGS = GlobalCLIArgs({'test_key': 123})

    f = cliargs_deferred_get('test_key', default=456)
    assert f() == 123

    f = cliargs_deferred_get('shallow_key', default=[])
    assert f() == []