

# Generated at 2022-06-10 23:02:07.846493
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MockCLIArgs(CLIArgs):
        @property
        def args(self):
            return {'foo': 'bar'}

        @property
        def connection_name(self):
            return 'ssh'

    my_cliargs = MockCLIArgs({})
    assert CLIARGS.get('foo') is None
    assert CLIARGS.connection_name is None
    # This normally happens when tasks are loaded in Ansible
    global CLIARGS
    CLIARGS = my_cliargs
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default=42)() == 'bar'
    assert cliargs_deferred_get('not_there', default=42)() == 42

# Generated at 2022-06-10 23:02:14.170011
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': 'bar'})
    # Shallow copy
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True) == 'bar'
    assert cliargs_deferred_get('bar', default='baz', shallowcopy=True) == 'baz'
    # Without shallow copy
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('bar', default='baz') == 'baz'


# Generated at 2022-06-10 23:02:25.841988
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'test': ['testing', 'one', dict(delta='two')], 't2': 'd2', 't3': set('abc')})
    assert cliargs_deferred_get('test')() == ['testing', 'one', {'delta': 'two'}]
    assert cliargs_deferred_get('t2')() == 'd2'
    assert cliargs_deferred_get('t3')() == set('abc')
    assert cliargs_deferred_get('t10', 'default')() == 'default'
    assert cliargs_deferred_get('test', default='default', shallowcopy=True)() == ['testing', 'one', {'delta': 'two'}]

# Generated at 2022-06-10 23:02:31.211554
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', 'bing', shallowcopy=True)() == 'bing'

# Generated at 2022-06-10 23:02:42.139883
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils import basic

    _init_global_context(['--module-path', 'foo:bar', '--fact-path', 'foo:bar', '--blah'])
    assert cliargs_deferred_get('module_path')() == ['foo', 'bar']
    assert cliargs_deferred_get('fact_path')() == ['foo', 'bar']
    # Test deep copy
    assert cliargs_deferred_get('module_path', shallowcopy=True)() == ['foo', 'bar']
    # Test default
    assert cliargs_deferred_get('verbosity')() == 0
    # Test default with deep copy
    assert cliargs_deferred_get('verbosity', shallowcopy=True)() == 0

    # Test replacing the global context (though this is not yet supported

# Generated at 2022-06-10 23:02:50.282167
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({'myarg': 'myvalue', 'mylist': [1, 2, 3], 'mydict': {'a': 1, 'b': 2},
                       'myset': set([1, 2, 3])})
    default = 'default'
    assert cliargs_deferred_get('myarg')() == 'myvalue'
    assert cliargs_deferred_get('notthere', default=default)() == default
    assert cliargs_deferred_get('mylist')() == [1, 2, 3]
    assert cliargs_deferred_get('mylist', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('mydict')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get

# Generated at 2022-06-10 23:02:57.522620
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test(key, expected):
        assert expected == cliargs_deferred_get(key)()

    _init_global_context({})
    test('url_username', None)
    _init_global_context({'url_username': 'bob'})
    test('url_username', 'bob')
    _init_global_context({'url_username': None})
    test('url_username', None)



# Generated at 2022-06-10 23:03:05.601128
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({
        'a': 'b',
        'c': ['d', 'e'],
        'f': {
            'g': 'h'
        }
    })
    result = cliargs_deferred_get('c', shallowcopy=True)()
    assert result == ['d', 'e'], 'expected result should be a shallow copy of the value'
    result[0] = 'foo'
    assert CLIARGS['c'][0] == 'foo', 'Expected result to be a shallow copy even though it was a mutable object like a list'
    result = cliargs_deferred_get('c')()
    assert result == ['foo', 'e'], 'Should not get a copy if shallow copy was not requested'

# Generated at 2022-06-10 23:03:16.331976
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from . import cli_args
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from copy import deepcopy
    cli_args = ["--something", "--else", "--something-else=bar"]
    args = cli_args.parse(args=cli_args)
    _init_global_context(args)
    assert cliargs_deferred_get(None, default=None) is None
    assert cliargs_deferred_get('something') == True
    assert cliargs_deferred_get('something-else') == 'bar'
    assert cliargs_deferred_get('missing', default='default') == 'default'
    # Test shallow copy of list
    cmdline_vars

# Generated at 2022-06-10 23:03:21.758998
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    CLIARGS = GlobalCLIArgs.from_options({'test': [1, 2, 3]})

    assert cliargs_deferred_get('test')() == [1, 2, 3]
    assert cliargs_deferred_get('does not exist')('default') == 'default'
    assert cliargs_deferred_get('test', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-10 23:03:36.820906
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _init(v):
        """Wrap the initialization of ``CLIARGS`` so that we don't affect other tests"""
        global CLIARGS
        CLIARGS = CLIArgs({'a': v})
        assert CLIARGS.get('a') == v
        assert cliargs_deferred_get('a')() == v

    # Test with a single value
    _init('a')
    assert cliargs_deferred_get('a')() == 'a'
    # Test with a list
    _init(['a'])
    assert cliargs_deferred_get('a')() == ['a']
    assert cliargs_deferred_get('a', shallowcopy=True)() == ['a']
    # Test with a dictionary
    _init({'a': 'a'})
    assert cliargs_

# Generated at 2022-06-10 23:03:48.448349
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar', 'baz': 2, 'now': '2018-02-26'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')(), 'bar'
    assert cliargs_deferred_get('baz')(), 2
    assert cliargs_deferred_get('now')(), '2018-02-26'
    assert cliargs_deferred_get('nope', 'nope')(), 'nope'
    assert cliargs_deferred_get('nope', default='nope')(), 'nope'

# Generated at 2022-06-10 23:03:57.147204
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from .mock import patch
    from ansible.module_utils.common._collections_compat import Mapping

    # cover the default case
    with patch.object(CLIARGS, 'get', return_value=None) as mock_get:
        assert cliargs_deferred_get('foo')(), None
        mock_get.assert_called_once_with('foo', None)

    # cover the set default case
    with patch.object(CLIARGS, 'get', return_value=None) as mock_get:
        assert cliargs_deferred_get('foo', default='bar')(), 'bar'
        mock_get.assert_called_once_with('foo', 'bar')


# Generated at 2022-06-10 23:04:06.754178
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_backup = CLIARGS
    CLIARGS = CLIArgs({'verbosity':3, 'roles_path': ['/fake/path/1', '/fake/path/2'],
                       'host_key_checking': True, 'gathering': 'smart'})

    assert cliargs_deferred_get('verbosity')() == 3
    assert cliargs_deferred_get('roles_path', shallowcopy=True)() == ['/fake/path/1', '/fake/path/2']
    assert cliargs_deferred_get('gathering', shallowcopy=True)() == 'smart'
    assert cliargs_deferred_get('host_key_checking', shallowcopy=True)() is True
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
   

# Generated at 2022-06-10 23:04:18.236433
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    try:
        CLIARGS = CLIArgs({'foo': 'bar', 'baz': ['quux']})
        dummy_default = object()
        assert cliargs_deferred_get('foo', dummy_default)() == 'bar'
        assert cliargs_deferred_get('baz', dummy_default)() == ['quux']
        assert cliargs_deferred_get('baz', shallowcopy=True)() == ['quux']
        assert cliargs_deferred_get('missing', default='found')() == 'found'
        assert cliargs_deferred_get('missing', default=dummy_default)() is dummy_default
    finally:
        CLIARGS = CLIArgs({})

# Generated at 2022-06-10 23:04:28.775012
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    stack = GlobalCLIArgs(dict(
        key1='value1',
        key2=['value2a', 'value2b'],
        key3=set(['value3a']),
        key4=dict(key4a=1, key4b=2),
    ))

    # test default behavior
    cliargs_deferred_get_1 = cliargs_deferred_get('key1', default='default value')
    assert cliargs_deferred_get_1() == 'value1'

    cliargs_deferred_get_2 = cliargs_deferred_get('key2', default='default value')
    assert cliargs_deferred_get_2() == ['value2a', 'value2b']

    cliargs_deferred_get_3 = cliargs_deferred_

# Generated at 2022-06-10 23:04:35.613243
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function ``cliargs_deferred_get``"""
    global CLIARGS

    # Test with a dict
    CLIARGS = CLIArgs({'key': {1,2}})
    assert cliargs_deferred_get('key', shallowcopy=True)() == {1, 2}
    assert cliargs_deferred_get('key', shallowcopy=True)() is not CLIARGS['key']

    # Test with a list
    CLIARGS = CLIArgs({'key': [1, 2]})
    assert cliargs_deferred_get('key', shallowcopy=True)() == [1, 2]
    assert cliargs_deferred_get('key', shallowcopy=True)() is not CLIARGS['key']

    # Test with a int

# Generated at 2022-06-10 23:04:43.106145
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_default(key, default, shallow, expected):
        global CLIARGS
        CLIARGS = CLIArgs({})
        assert expected == cliargs_deferred_get(key, default, shallow)()
    # Test with no default
    test_default(
        'missing', None, False,
        None,
    )
    test_default(
        'missing', None, True,
        None,
    )
    test_default(
        'missing', 5, False,
        5,
    )
    test_default(
        'missing', 5, True,
        5,
    )

    # Test with existing value that is a primitive
    cliargs = CLIArgs({'key': 5})
    CLIARGS = cliargs
    assert 5 == cliargs_deferred_get('key')()
   

# Generated at 2022-06-10 23:04:55.256124
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Set up a cli_args object with some sample data
    class CliArgs:
        def __init__(self):
            self.__data = {
                'foo': 'bar',
                'baz': ('one', 'two'),
                'id': {'name': 'user_name',
                       'id': 'user_id',
                       'type': 'user'},
            }

        def get(self, key, default=None):
            return self.__data.get(key, default)

    global CLIARGS
    old_cliargs = CLIARGS

# Generated at 2022-06-10 23:05:06.717035
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Normal functionality
    CLIARGS = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None

    # Shallow copy
    CLIARGS = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('bar', shallowcopy=True)() is None
    CLIARGS = GlobalCLIArgs.from_options({'foo': ['spam', 'eggs']})
    assert cliargs

# Generated at 2022-06-10 23:05:29.418175
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(foo=42))
    g = cliargs_deferred_get('foo')
    assert g() == 42
    g = cliargs_deferred_get('bar', default='blarg')
    assert g() == 'blarg'
    _init_global_context(dict(foo=['a', 'b', 'c']))
    g = cliargs_deferred_get('foo', shallowcopy=True)
    assert g() == ['a', 'b', 'c']
    g = cliargs_deferred_get('foo', shallowcopy=False)
    assert g() == ['a', 'b', 'c']
    assert g() is not CLIARGS.get('foo')
    _init_global_context(dict(foo=set(['a', 'b', 'c'])))

# Generated at 2022-06-10 23:05:40.894513
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from copy import deepcopy
    from ansible.module_utils.common.collections import LazyDict
    options = {'a': 'val_a', 'b': 'val_b',
               'c': ['list_item_one', 'list_item_two'],
               'd': {
                   'nested_key_one': 'val_nested_key_one',
                   'nested_key_two': 'val_nested_key_two',
                   'nested_key_three': ['list_item_one', 'list_item_two']
               }
               }
    _init_global_context(options)
    assert cliargs_deferred_get('a') == 'val_a'
    assert cliargs_deferred_get('b') == 'val_b'
    assert cliargs

# Generated at 2022-06-10 23:05:51.258851
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSet
    from ansible.module_utils.common.collections import is_sequence

    # Test not shallow copy
    CLIARGS = CLIArgs({'test_list': ['foo'], 'test_dict': {'bar': 'baz'}, 'test_set': {'qux'}})
    assert cliargs_deferred_get('test_list')() is CLIARGS['test_list']
    assert cliargs_deferred_get('test_dict')() is CLIARGS['test_dict']
    assert cliargs_deferred_get('test_set')() is CLIARGS['test_set']

    # Test shallow copy
    CLIARGS = CLIArgs()

# Generated at 2022-06-10 23:05:58.179669
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': {'bar': [1, 2, 3], 'baz': 'qux'}, 'zoo': ['abc', 'def']}
    _init_global_context(cli_args)

    def_get = cliargs_deferred_get('foo', default='moo')
    assert def_get()['bar'] == [1, 2, 3]
    assert def_get()['baz'] == 'qux'
    assert def_get(shallowcopy=True)['bar'] == [1, 2, 3]
    assert def_get(shallowcopy=True)['baz'] == 'qux'
    def_get = cliargs_deferred_get('zoo')
    assert def_get() == ['abc', 'def']
    # def_get() is a closure over

# Generated at 2022-06-10 23:06:06.379961
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.config.manager import ConfigManager
    from ansible.plugins.loader import cli_args
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    args = cli_args.AnsibleCLIArgs(["playbook.yml", "--some-option=some_value"])
    config_manager = ConfigManager()

    # setup CLIARGS with a bunch of options

# Generated at 2022-06-10 23:06:13.280105
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from collections import OrderedDict
    from copy import deepcopy
    cli_args = OrderedDict([
        ('remote-user', 'joe'),
        ('playbook', 'play.yml'),
        ('inventory', 'inventory.ini'),
        ('extra-vars', {'foo': 'bar'}),
        ('limit', 'all'),
    ])
    _init_global_context(cli_args)
    assert cliargs_deferred_get('remote-user')() == 'joe'
    assert cliargs_deferred_get('playbook')() == 'play.yml'
    assert cliargs_deferred_get('inventory')() == 'inventory.ini'

# Generated at 2022-06-10 23:06:23.894698
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils import context_objects
    from ansible.utils._context_objects import CliArgs

    cli_args = CliArgs({'foo': 'bar'})
    context_objects.CLIARGS = cli_args

    # Test getting a single value
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('foo', default='default') == 'bar'
    assert cliargs_deferred_get('bar', default='default') == 'default'

    # Test not doing a shallow copy
    my_list = ['foo', 'bar']
    cli_args.update(dict(foo=my_list))
    assert cliargs_deferred_get('foo', shallowcopy=False) is my_list

    # Test doing a shallow copy
   

# Generated at 2022-06-10 23:06:32.318673
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestClass(object):
        """Just a class to test that setting attributes on objects works"""
        pass
    test_args = {'yo': 'yo'}
    _init_global_context(test_args)
    assert cliargs_deferred_get('yo')() == 'yo'
    assert cliargs_deferred_get('yo2', 'yo3')() == 'yo3'
    test = TestClass()
    test.testval = cliargs_deferred_get('yo2', 'yo3')
    assert test.testval == 'yo3'

# Generated at 2022-06-10 23:06:40.752775
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_cliargs = CLIArgs({"test_key": [1, 2, 3]})
    global CLIARGS
    old_cliargs = CLIARGS
    CLIARGS = test_cliargs
    assert(test_cliargs["test_key"] == cliargs_deferred_get("test_key")())
    assert(test_cliargs["test_key"][:] == cliargs_deferred_get("test_key", shallowcopy=True)())
    CLIARGS = old_cliargs



# Generated at 2022-06-10 23:06:50.917364
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeCLIArgs(dict):
        def get(self, key, default=None):
            return self[key]

    def _check_default(key, expected, shallowcopy=False):
        # There's only one instance of this so we can't really test it
        # except as a state change
        original_object = CLIARGS
        CLIARGS = FakeCLIArgs()
        try:
            _test = cliargs_deferred_get(key, default='X', shallowcopy=shallowcopy)
            assert _test() == expected
        finally:
            CLIARGS = original_object

    _check_default('foo', 'X')
    _check_default('foo', 'bar', shallowcopy=False)
    _check_default('foo', 'bar', shallowcopy=True)

# Generated at 2022-06-10 23:07:22.051630
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # Test the different types supported
    # string
    assert cliargs_deferred_get('test1')() == ''
    assert cliargs_deferred_get('test1', default='default')() == 'default'

    # integer
    assert cliargs_deferred_get('test2')() == 0
    assert cliargs_deferred_get('test2', default=1)() == 1

    # boolean and None
    assert cliargs_deferred_get('test3')() is False
    assert cliargs_deferred_get('test3', default=None)() is None

    # dict
    assert cliargs_deferred_get('test4')() == {}

# Generated at 2022-06-10 23:07:32.136039
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test function"""
    assert cliargs_deferred_get('nope')(), 'Deferred get with no default should return None'
    assert cliargs_deferred_get('nope', default='default')(), 'Deferred get with default should return default'
    assert cliargs_deferred_get('nope', default='default', shallowcopy=True)(), 'Deferred get with default and shallowcopy should return default'
    assert cliargs_deferred_get('nope', default=['l', 'i', 's', 't'], shallowcopy=True)(), 'Deferred get with default and shallowcopy should return default'

# Generated at 2022-06-10 23:07:42.179823
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Test cases for cliargs_deferred_get
    """
    key = 'foo'
    default = 'bar'
    value = 'baz'

    # Test that if the global CLIARGS is empty, we return the default value
    get = cliargs_deferred_get(key, default)
    assert get() == 'bar'

    # Test that if the global CLIARGS has a value, we get that value
    global CLIARGS
    CLIARGS = {key: value}
    get = cliargs_deferred_get(key, default)
    assert get() == 'baz'

    # Test that if the global CLIARGS has a copy_value, we get the shallow copy
    global CLIARGS
    CLIARGS = {key: [1, 2, 3]}
    get = cliargs

# Generated at 2022-06-10 23:07:52.680985
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it works with a default value
    default = object()
    closure = cliargs_deferred_get('not-there', default=default)
    assert closure() is default

    # Test that it works with no default value
    closure = cliargs_deferred_get('not-there', default=None)
    assert closure() is None

    # Test that it works with a CLIARGS value
    _init_global_context({'not-there': default})
    closure = cliargs_deferred_get('not-there', default=object())
    assert closure() is default

    # Test that it works with a CLIARGS value
    _init_global_context({'not-there': {}})
    closure = cliargs_deferred_get('not-there', default=None, shallowcopy=True)
    #

# Generated at 2022-06-10 23:07:59.639816
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'is_default': 1, 'is_not_default':2})
    kwarg_default = cliargs_deferred_get('is_not_default', default=3)
    arg_default = cliargs_deferred_get('is_not_default')
    no_default = cliargs_deferred_get('is_default')
    assert kwarg_default() == 3
    assert arg_default() == 2
    assert no_default() == 1

    _init_global_context({})
    assert kwarg_default() == 3
    assert arg_default() == 2
    assert no_default() == 1

# Generated at 2022-06-10 23:08:11.510350
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_data = {'one': 1, 'two': [1, 2]}
    _init_global_context(test_data)

    # Default key
    func = cliargs_deferred_get('three', default=3)
    assert func() == 3

    # No default key
    func = cliargs_deferred_get('three')
    assert func() is None

    # Existing key with shallow copy off
    func = cliargs_deferred_get('one')
    assert func() == 1
    test_data['one'] = 2
    assert func() == 1

    # Existing key with shallow copy on
    func = cliargs_deferred_get('two', shallowcopy=True)
    assert func() == [1, 2]
    test_data['two'].append(3)
    assert func()

# Generated at 2022-06-10 23:08:21.335747
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo')() is None
    CLIARGS.set_overrides({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS.set_overrides({'foo': ['bar', 'frobnitz']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'frobnitz']
    assert cliargs_deferred_get('foo')() == ['bar', 'frobnitz']
    assert cliargs_deferred_get('foo', default='default')() == 'default'
    assert cliargs_deferred_get('foo', default=['default'], shallowcopy=True)()

# Generated at 2022-06-10 23:08:32.734663
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function ``cliargs_deferred_get``
    """
    global CLIARGS, _init_global_context
    CLIARGS = CLIArgs({})
    _init_global_context({'ANSIBLE_LOG_PATH':'/log/path.log'})
    assert cliargs_deferred_get('ANSIBLE_LOG_PATH') == '/log/path.log'
    assert CLIARGS.ANSIBLE_LOG_PATH == '/log/path.log'
    assert cliargs_deferred_get('ANSIBLE_LOG_PATH', 'log path') == '/log/path.log'
    assert CLIARGS.ANSIBLE_LOG_PATH == '/log/path.log'
    assert cliargs_deferred_get('ANSIBLE_LOG_PATH', default='log path') == '/log/path.log'

# Generated at 2022-06-10 23:08:42.675239
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs
    _init_global_context(CliArgs({}))
    global CLIARGS
    assert CLIARGS == CliArgs({})
    tdict = {1:2, 3:4}
    tlist = [1, 2]
    tset = {1, 2}
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', default={1:2})() == {1:2}
    CLIARGS['foo'] = tdict
    assert cliargs_deferred_get('foo')() == tdict
    assert cliargs_deferred_get('foo', shallowcopy=True)() == tdict
    CLIARGS['foo'] = tlist
    assert cliargs_deferred_get

# Generated at 2022-06-10 23:08:55.272457
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def assert_equal(expected, actual):
        assert expected() == actual(), \
            'Test failed: expected: {0}, actual: {1}'.format(expected(), actual())

    # Test defaults
    assert_equal(lambda: None, cliargs_deferred_get('key-does-not-exist', default=None))
    assert_equal(lambda: 1, cliargs_deferred_get('key-does-not-exist', default=1))
    assert_equal(lambda: {'a': 1}, cliargs_deferred_get('key-does-not-exist', default={'a': 1}))

    # Test shallow copy
    original_value = {'key': 'value'}
    original_value_copy = cliargs_deferred_get('key', default=original_value, shallowcopy=True)()

# Generated at 2022-06-10 23:09:48.996490
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)
    fn = cliargs_deferred_get('foo')
    assert fn() == 'bar'

    cli_args = {'foo': [1, 2, 3]}
    _init_global_context(cli_args)
    fn = cliargs_deferred_get('foo', shallowcopy=True)
    assert fn() == [1, 2, 3]
    assert fn() is not cli_args['foo']

    cli_args = {'foo': (1, 2, 3)}
    _init_global_context(cli_args)
    fn = cliargs_deferred_get('foo', shallowcopy=True)
    assert fn() == (1, 2, 3)

# Generated at 2022-06-10 23:10:01.050525
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test function
    _init_global_context({})
    assert CLIARGS.get('foo') is None
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', 42)() == 42
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'doh')() == 'bar'
    CLIARGS['foo'] = ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']

    # Test object
    _init_global_context({})
    assert CLIARGS.get('foo') is None
    assert CLIARGS.foo is None

# Generated at 2022-06-10 23:10:08.548015
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Sequence

    _cliargs_value = ['foo', 'bar', 'baz']
    _cliargs_result = _cliargs_value[:]


# Generated at 2022-06-10 23:10:19.073185
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Function cliargs_deferred_get"""
    from ansible.module_utils.six import PY2
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.collections import MutableSequence
    import datetime

# Generated at 2022-06-10 23:10:25.832346
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'one': [1,2,3]})
    # no copy
    assert cliargs_deferred_get('one', default=None)() == [1, 2, 3]
    # copy
    CLIARGS['one'].append(4)
    assert cliargs_deferred_get('one', default=None, shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-10 23:10:35.729350
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable

    class CustomClass(object):
        """Pretend custom object type"""
        def __init__(self, value):
            self.value = value

        def __deepcopy__(self, memo):
            return CustomClass(self.value)

        def __eq__(self, other):
            return self.value == other.value

    def check_no_shallow(func, orig, expected):
        value = func()
        assert value == expected
        value.append(True)
        assert orig == expected

    def check_shallow(func, orig, expected):
        value = func()
        assert value == expected
        value.append(True)
        assert orig != expected

    # pylint: disable=unused-variable

# Generated at 2022-06-10 23:10:47.126325
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def get_default():
        return 42

    ctx = {'foo': 'bar', 'foobar': [1, 2, 3], 'foobaz': {'one': 1, 'two': 2}}
    _init_global_context(ctx)

    assert cliargs_deferred_get('foobar')() == [1, 2, 3]
    assert cliargs_deferred_get('foobar', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foobaz')() == {'one': 1, 'two': 2}
    assert cliargs_deferred_get('foobaz', shallowcopy=True)() == {'one': 1, 'two': 2}
    assert cliargs_deferred_get('notpresent')() is None
    assert cli

# Generated at 2022-06-10 23:10:58.071099
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS['foo'] = 'bar'
    CLIARGS['baz'] = ['qux']
    CLIARGS['quux'] = {'corge': 'grault'}

    # plain
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == ['qux']
    assert cliargs_deferred_get('quux')() == {'corge': 'grault'}

    # shallow copy
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['qux']

# Generated at 2022-06-10 23:11:04.619669
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class DummyArgs(dict):
        pass
    args = DummyArgs()
    args['check'] = True
    args['diff'] = False
    global CLIARGS
    CLIARGS = CLIArgs(args)
    f = cliargs_deferred_get('check')
    assert f() is True
    f = cliargs_deferred_get('diff')
    assert f() is False
    f = cliargs_deferred_get('nonexistant')
    assert f() is None
    f = cliargs_deferred_get('nonexistant', default=True)
    assert f() is True

# Generated at 2022-06-10 23:11:15.380427
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.exceptions import AnsibleParserError

    cli_args = {'module_path': ''}

    # First initialization
    _init_global_context(cli_args)
    fetched_value = cliargs_deferred_get('module_path')()
    assert fetched_value == cli_args['module_path']

    # Second initialization with a different value
    cli_args['module_path'] = 'foo'
    _init_global_context(cli_args)
    fetched_value = cliargs_deferred_get('module_path')()
    assert fetched_value == cli_args['module_path']

    # First initialization of the shallow copy functionality
   