

# Generated at 2022-06-10 23:02:11.868410
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the behaviour of cliargs_deferred_get"""
    global CLIARGS

    # Test getting defaults
    CLIARGS = CLIArgs(dict(foo=42, bar='baz'))
    assert cliargs_deferred_get('not_there', default=42)() == 42
    assert cliargs_deferred_get('foo', default=42)() == 42
    assert cliargs_deferred_get('bar', default=42)() == 'baz'

    # Test shallow copy
    list_value = [1, 2, 3]
    CLIARGS = CLIArgs(dict(foo=list_value))
    assert cliargs_deferred_get('foo')() is list_value
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-10 23:02:20.414677
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=unused-variable
    ''' Test function cliargs_deferred_get '''
    ''' Test dictionary '''
    test_cliarg = {'key': 'value'}
    CLIARGS = CLIArgs(test_cliarg)
    test_key = 'key'

    ''' Test no shallow copy '''
    assert cliargs_deferred_get(test_key)() == 'value'

    ''' Test shallow copy '''
    assert cliargs_deferred_get(test_key, shallowcopy=True)() == {'key': 'value'}

# Generated at 2022-06-10 23:02:26.476857
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 'bar'})
    cliargs_deferred_get('foo')() == 'bar'
    cliargs_deferred_get('bar')() is None
    cliargs_deferred_get('bar', default='baz')() == 'baz'
    cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

# Generated at 2022-06-10 23:02:31.710790
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.plugins.loader import plugin_loaders

    _init_global_context(dict(foo='bar', plugins=plugin_loaders()))

    assert cliargs_deferred_get('foo')(), 'bar'
    assert cliargs_deferred_get('plugins')(), plugin_loaders()
    assert cliargs_deferred_get('plugins', shallowcopy=True)(), plugin_loaders()

# Generated at 2022-06-10 23:02:37.843411
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('host_key_checking', False)() is False
    assert cliargs_deferred_get('host_key_checking', False, shallowcopy=True)() is False
    assert cliargs_deferred_get('host_key_checking', 'default')() == 'default'
    assert cliargs_deferred_get('host_key_checking', 'default', shallowcopy=True)() == 'default'

# Generated at 2022-06-10 23:02:47.454578
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    class TestCliArgs(GlobalCLIArgs):

        def __init__(self, options,
                     # When an instance is created for the unit test,
                     # this attribute is filled with the values being
                     # tested by the unit test.  This is done by
                     # getting one of the default_values attribute of
                     # a field attribute
                     attr_defaults=None):
            super(TestCliArgs, self).__init__(options)
            self._attr_defaults = attr_defaults

        def get(self, key, default=None):
            if self._attr_defaults and key in self._attr_defaults:
                return self._attr_defaults[key]
            return super(TestCliArgs, self).get(key, default)

    # Use the ``default`` value as the unit test value.  This

# Generated at 2022-06-10 23:03:00.802160
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This test cannot be part of the PI field unit-test because we cannot rely on the
    # ``CLIARGS`` being set at import time.  It is initialized after the command line
    # arguments are parsed.  So instead, set up a minimal CLIARGS and make sure that
    # the function is working correctly
    global CLIARGS

    CLIARGS['foo'] = 'bar'
    CLIARGS['baz'] = [1, 2, 3]
    CLIARGS['quux'] = {'quuux': 'quuuux', 'quuuuux': 'quuuuuux'}
    CLIARGS['qum'] = set([1, 2, 3])

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('nonexistent')() is None


# Generated at 2022-06-10 23:03:12.408090
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint can't seem to parse the unittest module correctly here
    # pylint: disable=import-outside-toplevel
    from unittest import TestCase
    from copy import copy
    from ansible.utils.context_objects import CliArgs

    class MyTest(TestCase):
        def test_get_with_default(self):
            cli_args = CliArgs({'foo': '1', 'bar': '2'})
            self.assertFalse('bar' in cli_args)
            self.assertEqual(cli_args['bar'], '2')
            self.assertEqual(cli_args.get('bar', default='3'), '2')
            self.assertEqual(cli_args.get('baz', default='3'), '3')

# Generated at 2022-06-10 23:03:22.428833
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test_value': 'foo'})
    assert cliargs_deferred_get('test_value')() == 'foo'
    assert cliargs_deferred_get('bogus_value')() is None
    assert cliargs_deferred_get('bogus_value', default='bar')() == 'bar'
    CLIARGS = CLIArgs({'test_value': ['foo', 'bar']})
    assert cliargs_deferred_get('test_value', shallowcopy=True)() == ['foo', 'bar']
    assert cliargs_deferred_get('test_value')() == ['foo', 'bar']
    tmp = cliargs_deferred_get('test_value')()
    tmp.append('baz')
    assert cliargs

# Generated at 2022-06-10 23:03:33.051299
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This just needs to work for the ``FieldAttribute`` logic, so it's not a full test
    # of all the stuff that's available in CLIARGS nor even a test of all the different
    # kinds of things that could be in CLIARGS
    from ansible.module_utils.common.collections import Mapping as Dict
    my_dict = Dict({'foo': 'bar'})
    my_list = [1, 2, 3]
    my_set = set((1, 2, 3))
    my_int = 42
    my_str = 'ansible'

# Generated at 2022-06-10 23:03:44.978321
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    import copy
    # Make sure that setting the return value works
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo')() is None
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default=[1, 2, 3])() == 'bar'
    # make sure that the shallow copy works
    CLIARGS = CLIArgs({'bar': [1, 2, 3]})
    assert cliargs_deferred_get('bar', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-10 23:03:52.026335
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    cli_args = {'some_key': [1, 2]}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('some_key')() == [1, 2]
    assert cliargs_deferred_get('other_key', [])() == []
    assert cliargs_deferred_get('other_key', [], shallowcopy=True)() == []
    assert cliargs_deferred_get('some_key', shallowcopy=True)() == [1, 2]

# Generated at 2022-06-10 23:04:04.664547
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    assert CLIARGS == {}
    value = cliargs_deferred_get('ARGUMENT_NEVER_IN_CONTEXT')()
    assert value is None
    _init_global_context({'key': 'value'})
    assert 'key' in CLIARGS
    assert CLIARGS['key'] == 'value'
    value = cliargs_deferred_get('key')()
    assert value == 'value'
    value = cliargs_deferred_get('ARGUMENT_NEVER_IN_CONTEXT')()
    assert value is None
    _init_global_context({'key': 'value'})
    value = cliargs_deferred_get('key', default='value2')()
    assert value is not None
    assert value == 'value'


# Generated at 2022-06-10 23:04:10.308332
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test deferred get of CLIARGS"""
    # pylint: disable=unused-variable
    # Bind a value to CLIARGS to work with
    @cliargs_deferred_get('foo', 'bar')
    def ansible_foo():
        pass

    # Test after changing CLIARGS
    CLIARGS.foo = 'baz'
    assert ansible_foo() == 'baz'

# Generated at 2022-06-10 23:04:22.564753
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    def test_func(key, expected):
        """Helper function to test case"""
        test_default = set()
        test_object = object()
        test_dict = {'a': test_object}
        test_set = {test_object}
        test_list = ['a']

        CLIARGS.setdefault(key, expected)
        result = cliargs_deferred_get(key, default=test_default, shallowcopy=False)()
        assert result is expected, 'unexpected value for key %s in cliargs' % key

        CLIARGS.setdefault(key, expected)
        result = cliargs_deferred_get(key, default=test_default, shallowcopy=True)()

# Generated at 2022-06-10 23:04:33.198407
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'some_cli_arg': 'foo'})
    inner = cliargs_deferred_get('some_cli_arg', None)
    assert inner() == 'foo'

    inner = cliargs_deferred_get('some_other_cli_arg', 'bar')
    assert inner() == 'bar'

    inner = cliargs_deferred_get('some_cli_arg', None, shallowcopy=True)
    assert inner() == 'foo'

    inner = cliargs_deferred_get('some_other_cli_arg', 'bar', shallowcopy=True)
    assert inner() == 'bar'

    inner = cliargs_deferred_get('some_cli_arg', None, shallowcopy=True)
    assert inner() == 'foo'

    CLI

# Generated at 2022-06-10 23:04:42.208227
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    def setup_get_data(data):
        """Helper function to setup the mocking of cliargs.get"""
        class Stack:
            """Helper class to simulate a stack"""
            def __init__(self, data):
                self.data = data

            def __getattr__(self, key):
                return self.data[key]

        ret = Stack({})
        ret.get = lambda key, default=None: data[key]
        return ret
    # pylint: enable=redefined-outer-name

    global CLIARGS

    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    CLIARGS = setup_get_data({'foo': 'bar'})

# Generated at 2022-06-10 23:04:54.577710
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Sequence, MutableMapping, Set
    from ansible.module_utils.common.collections import is_sequence

    def test_copy(copy_type):
        class Test(copy_type):
            def __init__(self):
                if isinstance(copy_type, MutableMapping):
                    self.data = {'key': 'value'}
                elif isinstance(copy_type, Set):
                    self.data = set('abc')

            def copy(self):
                return Test()

        original = Test()
        shallow = cliargs_deferred_get('fake', default=original, shallowcopy=True)
        deep = cliargs_deferred_get('fake', default=original, shallowcopy=False)
        copy = shallow()

# Generated at 2022-06-10 23:05:07.094618
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _test(cliargs, key, default, expected_result):
        """Helper function to test a cliargs_deferred_get call"""
        _init_global_context(cliargs)

        shallow_getter = cliargs_deferred_get(key, default, shallowcopy=True)
        shallow_result = shallow_getter()
        if shallow_result is not None:
            assert shallow_result is not expected_result

        no_shallow_getter = cliargs_deferred_get(key, default, shallowcopy=False)
        no_shallow_result = no_shallow_getter()
        assert no_shallow_result is expected_result

    # Test with no value and no default
    _test({}, 'foo', None, None)

    # Test with a value and no default

# Generated at 2022-06-10 23:05:16.985775
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def my_test_func(key, default=None, shallowcopy=False):
        return cliargs_deferred_get(key, default, shallowcopy)()
    cliargs_dict = dict(foo='bar',
                        int_list=[1, 2, 3],
                        set_list=[set([1, 2, 3])],
                        dict_list=[dict(a=1, b=2)])
    CLIARGS.update(cliargs_dict)
    for key in cliargs_dict:
        assert my_test_func(key) == cliargs_dict[key]
        if isinstance(cliargs_dict[key], (Mapping, Set)):
            assert my_test_func(key, shallowcopy=True) is not cliargs_dict[key]

# Generated at 2022-06-10 23:05:32.791764
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is a pretty simple function, so just test that it works
    CLIARGS.clear()
    CLIARGS['foo'] = ['hello']
    f = cliargs_deferred_get('foo')
    assert f() == ['hello']
    assert f(default={}) == ['hello']
    assert f(default_if_none={}) == {}
    assert f(default_if_none=['world']) == ['hello']
    assert f(shallowcopy=True) == ['hello']
    assert f(default=[]) == ['hello']
    assert f(default_if_none=[]) == []
    assert f(default_if_none=['world']) == ['hello']


# This is also used by action plugin and needs to be bound to ``CLIARGS``
to_text_key = cliargs_deferred

# Generated at 2022-06-10 23:05:42.764553
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MockCLIArgs(object):
        # pylint: disable=unused-argument
        def get(self, key, default=None):
            return default
    default = []
    global CLIARGS
    CLIARGS = MockCLIArgs()
    value = cliargs_deferred_get('foo', default=default, shallowcopy=False)()
    assert value == default
    assert value is not default

    value = cliargs_deferred_get('foo', default=default, shallowcopy=True)()
    assert value == default
    assert value is not default

    default = {}
    value = cliargs_deferred_get('foo', default=default, shallowcopy=False)()
    assert value == default
    assert value is not default


# Generated at 2022-06-10 23:05:53.533602
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    import pytest

    def _call_inner(inner, cliargs_opts):
        cliargs = CLIArgs(cliargs_opts)
        old_cliargs = CLIARGS
        CLIARGS = cliargs
        try:
            return inner()
        finally:
            CLIARGS = old_cliargs

    # Test defaults (key not present)
    assert _call_inner(cliargs_deferred_get('test'),
                       {}) is None
    assert _call_inner(cliargs_deferred_get('test', default=42),
                       {}) == 42

    # Test specific option present
    assert _call_inner(cliargs_deferred_get('test', default=42),
                       {'test': 2}) == 2

    # Test shallow copy
   

# Generated at 2022-06-10 23:05:59.179895
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.parameters import FieldAttribute

    global CLIARGS

    test_input = {'spam': 'a', 'nested': {'eggs': ['b', 'c']}}
    CLIARGS = CLIArgs(test_input)

    field = FieldAttribute()

    field.set_default(cliargs_deferred_get('spam'))
    assert field.default == test_input['spam']

    field.set_default(cliargs_deferred_get('nested'))
    assert field.default == test_input['nested']
    assert field.default['eggs'][0] == 'b'

    field.set_default(cliargs_deferred_get('nested'))
    assert field.default['eggs'][0] == 'b'
    field.default

# Generated at 2022-06-10 23:06:08.912635
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check_context_object(value, expected):
        def inner():
            return value
        obj = cliargs_deferred_get("foo", inner, shallowcopy=False)
        assert obj() is expected

    check_context_object("hello", "hello")
    check_context_object(1, 1)
    check_context_object([2, 3], [2, 3])
    check_context_object({4, 5}, {4, 5})
    check_context_object({"key": "value"}, {"key": "value"})
    obj = cliargs_deferred_get("foo", inner, shallowcopy=False)
    assert obj() == "hello"

# Generated at 2022-06-10 23:06:20.737016
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    values = {'a': 'A', 'b': [1, 2, 3], 'c': {'d': 4}, 'e': set([1, 2, 3])}
    expected = {
        'a': 'A',
        'b': [1, 2, 3],
        'b_shallow': [1, 2, 3],
        'c': {'d': 4},
        'c_shallow': {'d': 4},
        'e': set([1, 2, 3]),
        'e_shallow': set([1, 2, 3])
    }
    global CLIARGS
    CLIARGS = CLIArgs(values)

    # Test
    for key, value in expected.items():
        assert cliargs_deferred_get(key)() == value

# Generated at 2022-06-10 23:06:28.026883
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    a = CLIArgs({'a': {'b': {'c': 'foo'}}})
    b = a.copy()
    b['a']['b']['c'] = 'bar'

    f = cliargs_deferred_get('a', default={})
    # CLIARGS has not been replaced yet so we get the default
    assert f() == {}

    global CLIARGS
    CLIARGS = a
    # Default is only used if there is no value
    f = cliargs_deferred_get('a', default={})
    assert f() == {'b': {'c': 'foo'}}

    # Now get a copy
    f = cliargs_deferred_get('a', default={}, shallowcopy=True)
    assert f() == {'b': {'c': 'foo'}}



# Generated at 2022-06-10 23:06:40.632934
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': ['b'], 'c': set(['d', 'e'])})
    assert cliargs_deferred_get('a')() == ['b']
    assert cliargs_deferred_get('a')() is not CLIARGS['a']
    assert cliargs_deferred_get('b')() is None
    assert cliargs_deferred_get('c')(shallowcopy=True) == set(['d', 'e'])
    assert cliargs_deferred_get('c')(shallowcopy=True) is not CLIARGS['c']
    assert cliargs_deferred_get('c')() == CLIARGS['c']

# Generated at 2022-06-10 23:06:50.832928
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({1: [1, 2], 2: {1: 2}, 3: {1, 2}})
    assert cliargs_deferred_get(1)() == [1, 2]
    assert cliargs_deferred_get(1)() == CLIARGS[1]
    CLIARGS[1].append(3)
    assert cliargs_deferred_get(1)() == [1, 2, 3]

    assert cliargs_deferred_get(3)() == {1, 2}
    assert cliargs_deferred_get(3)() == CLIARGS[3]
    CLIARGS[3].add(3)
    assert cliargs_deferred_get(3)() == {1, 2}


# Generated at 2022-06-10 23:07:02.249221
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # an empty value should just return the default with no other trouble
    assert cliargs_deferred_get("a key that is not there", "default") == "default"
    # if the default is None and the value is None, we should get back None
    assert cliargs_deferred_get("a key that is not there", None) is None
    # if the value is a copyable type it shouldn't have any trouble
    assert cliargs_deferred_get("some key")("some value") == "some value"
    # if we ask for a deepcopy into set
    assert cliargs_deferred_get("some key")({"this is an", "unordered", "set"}) == {"this is an", "unordered", "set"}
    # if we ask for a deepcopy into list
    assert cliargs_deferred_

# Generated at 2022-06-10 23:07:20.258693
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # CLIARGS not yet initialized
    assert CLIARGS.get('become_user') is None
    assert cliargs_deferred_get('become_user') is None

    _init_global_context({'become_user': 'testuser'})

    assert 'testuser' == CLIARGS.get('become_user')
    assert 'testuser' == cliargs_deferred_get('become_user')()

    assert CLIARGS.get('foobar', default='default') == 'default'
    assert cliargs_deferred_get('foobar', default='default')() == 'default'

    shallowcopy_f = cliargs_deferred_get('tags', shallowcopy=True)
    shallowcopy_t = cliargs_deferred_get('tags', shallowcopy=True)

    _init

# Generated at 2022-06-10 23:07:31.122684
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Container(object):
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return self.value == other.value

        def __ne__(self, other):
            return self.value != other.value

    assert cliargs_deferred_get('foo')(
    ) == cliargs_deferred_get('foo', default='bar')(
    ) == 'bar'
    assert cliargs_deferred_get('foo', default=Container('bar'))().value == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() is None
    assert cliargs_deferred_get('foo', default=1, shallowcopy=True)() == 1

# Generated at 2022-06-10 23:07:41.014945
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.text.converters import to_text

    cli_args = dict(
        inventory=[u"inventory"],
        test_args=[u"-vvvv", u"--debug"],
        test_boolean=False,
        test_default_mapping=None,
        test_mapping=dict(a=1, b=2)
    )

    _init_global_context(cli_args)
    assert CLIARGS['test_args'][0] == u"-vvvv"
    assert CLIARGS['test_args'][1] == u"--debug"
    assert to_text(CLIARGS['test_args']) == u"-vvvv --debug"

    cliargs_copy = cliargs_deferred_get('test_args')()
    cliargs_

# Generated at 2022-06-10 23:07:51.763551
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''test cliargs_deferred_get
    '''
    # pylint: disable=protected-access
    # Note: No tests for sets, mappings, or sequences because we don't use them and
    #       I am lazy.
    assert None is cliargs_deferred_get('foo')()
    assert 3 is cliargs_deferred_get('foo', 3)()

    foo = 'bar'
    CLIARGS._data['foo'] = foo
    assert foo is cliargs_deferred_get('foo')()
    assert foo is cliargs_deferred_get('foo', 3)()

    CLIAGRGS._data['foo'] = 'baz'
    assert 'baz' is cliargs_deferred_get('foo')()

    foo = 'bar'
    CLIARGS._data

# Generated at 2022-06-10 23:07:59.935700
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get"""
    # Unit test for function cliargs_deferred_get
    cli_args = CLIArgs({'foo': 'bar', 'baz': 'bam', 'bam': [1, 2, 3], 'bat': {'a': 'b'}}, prefix='_')

    # regular default
    assert cliargs_deferred_get('foo', default='nope')() == 'bar'

    # regular default but with shallow copy
    assert cliargs_deferred_get('foo', default='nope', shallowcopy=True)() == 'bar'

    # not found but given default
    assert cliargs_deferred_get('boz', default='nope')() == 'nope'

    # not found but given default but with shallow copy
    assert cliargs

# Generated at 2022-06-10 23:08:11.681300
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def callback():
        return 'foo'
    assert cliargs_deferred_get('test_key_not_present')(), None
    assert cliargs_deferred_get('test_key_not_present', default=None)(), None
    assert cliargs_deferred_get('test_key_not_present', default='foo')(), 'foo'
    assert cliargs_deferred_get('test_key_not_present', default=callback)(), 'foo'

    CLIARGS['test_key'] = 'bar'
    assert cliargs_deferred_get('test_key')(), 'bar'
    assert cliargs_deferred_get('test_key', shallowcopy=True)(), 'bar'

    CLIARGS['test_list_key'] = ['foo', 'bar']
    assert cl

# Generated at 2022-06-10 23:08:13.047560
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # noop
    return True

# Generated at 2022-06-10 23:08:22.199775
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCliArgs(GlobalCLIArgs):
        """Dummy class for test_cliargs_deferred_get"""

    cliargs = TestCliArgs({})
    # Test deferred get on non-existent value
    test_value = cliargs_deferred_get('blah')
    assert test_value() is None

    # Test deferred get on existent but empty value
    cliargs = TestCliArgs({'blah': None})
    test_value = cliargs_deferred_get('blah')
    assert test_value() is None

    # Test deferred get on existent non-empty value
    cliargs = TestCliArgs({'blah': 'blah'})
    test_value = cliargs_deferred_get('blah')
    assert test_value() == 'blah'



# Generated at 2022-06-10 23:08:33.465698
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'foo'})
    assert cliargs_deferred_get('foo', default='bar')() == 'foo'

    CLIARGS = CLIArgs({'foo': 'foo'})
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'foo'

    CLIARGS = CLIArgs({'foo': ['foo']})
    assert cliargs_deferred_get('foo', default=['bar'], shallowcopy=True)() == ['foo']

    CLIARGS = CLIArgs({'foo': ('foo')})

# Generated at 2022-06-10 23:08:43.422979
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test(key, default, shallowcopy, expected):
        value = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)
        assert callable(value)
        actual = value()
        if actual is not expected:
            assert actual == expected

    t = test
    t('key', 'default', False, 'default')
    t('key', ['default'], True, ['default'])
    t('key', ['default'], False, ['default'])
    t('key', {'dict': 'default'}, True, {'dict': 'default'})
    t('key', {'dict': 'default'}, False, {'dict': 'default'})
    t('key', {'dict'}, True, {'dict'})

# Generated at 2022-06-10 23:09:11.015756
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_opts = {
        'foo': ['bar'],
        'baz': 'bang',
        'zoom': {'zip': 1},
        'qux': {'one', 'two'},
    }

    _init_global_context(test_opts)

    one = cliargs_deferred_get('baz')
    assert one() == 'bang'

    two = cliargs_deferred_get('foo')
    assert two() == ['bar']
    assert two(shallowcopy=True) == ['bar']

    three = cliargs_deferred_get('zoom')
    assert three() == {'zip': 1}
    assert three(shallowcopy=True) == {'zip': 1}

    four = cliargs_deferred_get('qux')
    assert four()

# Generated at 2022-06-10 23:09:18.841026
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {
        'diff': True,
        'module_path': '/home/ansible/modules',
        'host_pattern': '*',
        'debug': True,
        'module_lang': 'en',
        'module_set_locale': True,
        'diff_pepper': 'pepper',
        'diff_timeout': 30.0,
        'verbosity': 4,
    }
    _init_global_context(cli_args)
    assert cliargs_deferred_get('diff')() is True
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

# Generated at 2022-06-10 23:09:25.290027
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns cached value after CliArgs is created"""
    # TODO: This is not a complete test.  It is here to remind us to write a complete test
    # once we figure out how to stub out the CLIArgs object
    global CLIARGS

    deferred_get = cliargs_deferred_get('debug', default=False, shallowcopy=True)

    assert deferred_get() is False

    options = {'debug': True}
    CLIARGS = CLIArgs(options)

    # Value should be cached
    assert deferred_get() is True
    assert CLIARGS.get('debug') is True

    # Should convert to boolean but keep cached
    options['debug'] = 'foo'
    assert deferred_get() is True
    assert CLIARGS.get('debug') is True


# Generated at 2022-06-10 23:09:36.337024
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class C(object):
        """Class used to keep track of data"""
        def __init__(self):
            self.data = None

        def set_data(self, data):
            self.data = data

    # test that a default is returned
    test_result = C()
    test_result.set_data(cliargs_deferred_get('foo'))
    assert test_result.data is None

    # test that a value is returned
    test_result.set_data(cliargs_deferred_get('verbosity'))
    assert test_result.data == 0

    # test that a default value is returned
    test_result.set_data(cliargs_deferred_get('foo', default=1))
    assert test_result.data == 1

    # test that a value is returned and shallow copied
    test

# Generated at 2022-06-10 23:09:45.182885
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    expected_dict_value = {'a': 'b'}
    expected_list_value = ['a', 'b']
    expected_set_value = {'a', 'b'}
    expected_dict_copy = expected_dict_value.copy()
    expected_list_copy = expected_list_value[:]
    expected_set_copy = expected_set_value.copy()

    # Test no key
    assert CLIARGS.get('notakey', None) is None
    assert cliargs_deferred_get('notakey', None)() is None

    # Test with key, no shallow copy
    result_dict = cliargs_deferred_get('test_dict_key')(); assert result_dict is expected_dict_value

# Generated at 2022-06-10 23:09:57.543614
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Container(object):
        pass

    container = Container()
    container.a = 1
    container.b = [1, 2, 3]
    container.c = {'1': 1, '2': 2}
    container.d = set([1, 2, 3])

    args = {'a': 1, 'b': [1, 2, 3], 'c': {'1': 1, '2': 2}, 'd': set([1, 2, 3])}

    CLIARGS.clear()
    CLIARGS.update(args)

    for key in ['a', 'b', 'c', 'd']:
        assert cliargs_deferred_get(key)() == getattr(container, key)

# Generated at 2022-06-10 23:10:02.455775
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    _init_global_context({'a': 'b'})
    assert cliargs_deferred_get('a')() == 'b'
    assert cliargs_deferred_get('b')('c') == 'c'
    _init_global_context({})
    assert cliargs_deferred_get('a')('c') == 'c'

# Generated at 2022-06-10 23:10:11.394125
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar', 'baz': ['qux', 'quux'], 'corge': {'grault': 'garply'}}
    _init_global_context(cli_args)
    def_foo = cliargs_deferred_get('foo')
    def_baz = cliargs_deferred_get('baz')
    def_corge = cliargs_deferred_get('corge')
    assert def_foo() == 'bar'
    assert def_baz() == ['qux', 'quux']
    assert def_corge() == {'grault': 'garply'}

    def_baz_copy = cliargs_deferred_get('baz', shallowcopy=True)

# Generated at 2022-06-10 23:10:20.582582
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCliArgs( dict ):
        def get(self, key, *args, **kwargs):
            try:
                return self[key]
            except KeyError:
                if 'default' in kwargs:
                    return kwargs['default']
                raise

    for i in range(-4, 4):
        cliargs = TestCliArgs()
        cliargs['i'] = i
        for shallowcopy in [False, True]:
            context = cliargs_deferred_get('i', shallowcopy=shallowcopy)
            assert context() == i
            if shallowcopy:
                if isinstance(i, (Mapping, Set)):
                    assert context() is not i
                elif is_sequence(i):
                    assert context() is not i
                else:
                    assert context() == i

# Generated at 2022-06-10 23:10:31.468504
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_dict = {'ansible_debug': True, 'list': ['foo', 'bar'], 'list_copy': ['foo', 'bar'],
                    'dict': {'foo': ['bar', 'baz']}, 'dict_copy': {'foo': ['bar', 'baz']},
                    'set': set(['foo', 'bar', 'baz']), 'set_copy': set(['foo', 'bar', 'baz']),
                    'int': 1, 'float': 1.1, 'str': 'foo'}
    _init_global_context(cliargs_dict)

    # Shallow copy
    assert cliargs_deferred_get('ansible_debug') is True
    assert cliargs_deferred_get('list') is cliargs_dict['list']
    assert cliargs_def

# Generated at 2022-06-10 23:11:07.796298
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get('foobar', default=None)() == None

# Generated at 2022-06-10 23:11:10.855721
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['test_key'] = ['test_value']
    deferred_get = cliargs_deferred_get('test_key')
    assert deferred_get() == ['test_value']


# Generated at 2022-06-10 23:11:21.421518
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    old = CLIARGS
    CLIARGS = CLIArgs(dict(key=42, other_key=dict(a=1, b=2)))
    result = cliargs_deferred_get('key')()
    assert result == 42
    assert result is not CLIARGS['key']

    result = cliargs_deferred_get('key', shallowcopy=True)()
    assert result == 42
    assert result is not CLIARGS['key']

    result = cliargs_deferred_get('other_key')()
    assert result == {'a': 1, 'b': 2}
    assert result is not CLIARGS['other_key']

    result = cliargs_deferred_get('other_key', shallowcopy=True)()

# Generated at 2022-06-10 23:11:29.506628
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def validate_simple_closure(value):
        assert value == 1

    def validate_shallow_copy(value):
        assert value == [1]
        value.append(2)
        assert CLIARGS[key] == [1]

    def validate_deep_copy(value):
        assert value == [1]
        value.append(2)
        assert CLIARGS[key] == [1]

    key = 'test_list'
    CLIARGS['test_list'] = [1]
    value = cliargs_deferred_get(key)()
    validate_simple_closure(value)

    value = cliargs_deferred_get(key, shallowcopy=True)()
    validate_shallow_copy(value)

    key = 'test_dict'

# Generated at 2022-06-10 23:11:38.619783
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function ``cliargs_deferred_get``

    We use an inner function as a closure to create a new instance of ``cliargs_deferred_get``
    every time a test is called.  This makes sure that each test gets a new instance of the
    closure instead of one that has been previously used
    """
    def test_cliargs_deferred_get_closure(key, value, default = None, shallowcopy=False):
        # We don't use the actual cliargs for this test since that would require us to pass all
        # the args correctly, including providing stdin, stdout, and stderr.  Which is a pain
        # even with mocks and just as easy to create a dummy class
        class DummyCliArgs(Mapping):
            def __getitem__(self, k):
                return value


# Generated at 2022-06-10 23:11:50.155333
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=False)() == [1, 2, 3]
    # shallow copy
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    CLIARGS['foo'].append(4)
    assert cliargs_deferred_get('foo', shallowcopy=False)() == [1, 2, 3, 4]
    # shallow copy
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('fooz', shallowcopy=True)() is None
    assert cliargs_deferred_get('fooz', default='bar', shallowcopy=True)

# Generated at 2022-06-10 23:11:59.477352
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    assert cliargs_deferred_get('this_key_does_not_exist', default='foo')() == 'foo'
    assert cliargs_deferred_get('this_key_does_not_exist', default='foo', shallowcopy=False)() == 'foo'
    assert cliargs_deferred_get('this_key_does_not_exist', default='foo', shallowcopy=True)() == 'foo'

    cliargs = CLIArgs({'a_foo_key': 'foo'})
    assert cliargs_deferred_get('a_foo_key')(cliargs=cliargs) == 'foo'