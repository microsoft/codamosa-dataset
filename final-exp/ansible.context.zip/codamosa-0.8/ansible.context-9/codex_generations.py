

# Generated at 2022-06-10 23:02:12.134717
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({})
    c = cliargs_deferred_get('test', default='test')
    assert c() == 'test'

    CLIARGS = CLIArgs({'test': 'test'})
    c = cliargs_deferred_get('test', default='test')
    assert c() == 'test'

    CLIARGS = CLIArgs({'test': 'test'})
    c = cliargs_deferred_get('test', default=['test'])
    assert c() == ['test']
    CLIARGS = CLIArgs({'test': ['test']})
    c = cliargs_deferred_get('test', default=['test'])
    assert c() == ['test']
    CLIARGS = CLIArgs({'test': ['test']})

# Generated at 2022-06-10 23:02:23.454336
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=protected-access
    global CLIARGS
    CLIARGS = CLIArgs({'string': 'test', 'list': [1, 2, 3, 4]})
    assert cliargs_deferred_get('string')() == 'test'
    assert cliargs_deferred_get('string', default='value')() == 'test'
    assert cliargs_deferred_get('list')() == [1, 2, 3, 4]
    assert cliargs_deferred_get('list', shallowcopy=True)() == [1, 2, 3, 4]
    assert cliargs_deferred_get('list', default='value')() == [1, 2, 3, 4]

# Generated at 2022-06-10 23:02:33.100330
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['verbosity'] = 1
    f1 = cliargs_deferred_get('verbosity')
    assert f1() == 1

    CLIARGS['verbosity'] = 2
    assert f1() == 2

    #
    # Verify shallow copy behavior
    #
    CLIARGS['roles_path'] = ['/path/to/roles1', '/path/to/roles2']
    f2 = cliargs_deferred_get('roles_path')
    roles_path1 = f2()
    CLIARGS['roles_path'] = ['/path/to/roles3', '/path/to/roles4']
    roles_path2 = f2()

    assert roles_path1 == roles_path2
    assert roles_path1 != CLIARGS['roles_path']

   

# Generated at 2022-06-10 23:02:44.093724
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=missing-docstring
    from ansible.utils.context_objects import FieldAttribute

    # Regular function
    inner = cliargs_deferred_get('foo', default=1)
    assert inner() == 1

    # FieldAttribute - uses Cache
    # pylint: disable=invalid-name
    foo_field = FieldAttribute('foo')
    assert foo_field.default == 1

    CLIARGS.update(foo='bar')
    # pylint: disable=invalid-name
    foo_field = FieldAttribute('foo')
    assert foo_field.default == 'bar'
    foo_field.default = 'baz'
    assert foo_field.default == 'baz'

    # FieldAttribute - uses Cache - shallowcopy
    # pylint: disable=invalid-name
    foo_

# Generated at 2022-06-10 23:02:51.224088
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert True is cliargs_deferred_get('force_handlers')(), 'Should return True by default'
    CLIARGS['force_handlers'] = False
    assert False is cliargs_deferred_get('force_handlers')(), 'Should return value of force_handlers'
    CLIARGS['force_handlers'] = [1, 2, 3]
    assert [1, 2, 3] == cliargs_deferred_get('force_handlers')(), 'Should return list'
    assert [1, 2, 3] == cliargs_deferred_get('force_handlers', shallowcopy=True)(), 'Should return shallow copy'
    CLIARGS['force_handlers'] = {'a': 1, 'b': 2}

# Generated at 2022-06-10 23:02:59.712565
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    class FakeCliArgs(object):
        def get(self, key, default=None):
            return key

    global CLIARGS
    orig_cliargs = CLIARGS
    for shallowcopy in (True, False):
        CLIARGS = FakeCliArgs()
        assert cliargs_deferred_get('foo', shallowcopy=shallowcopy)() == 'foo'
        assert cliargs_deferred_get('bar', default='baz', shallowcopy=shallowcopy)() == 'baz'
    CLIARGS = orig_cliargs

# Generated at 2022-06-10 23:03:06.187312
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Sequence
    from copy import copy

    global CLIARGS
    cli_args = {'python_interpreter': '/tmp/python', 'ansible_connection': 'docker', 'ansible_shell_type': 'fish'}
    CLIARGS = CLIArgs(cli_args)
    assert cliargs_deferred_get('python_interpreter')() == '/tmp/python'
    assert cliargs_deferred_get('python_interpreter', default=None)() is None
    assert cliargs_deferred_get('missing_interpreter', default='/tmp/python')() == '/tmp/python'
    # Make sure value is not cloned by default
    connection = cliargs_deferred_get('ansible_connection')()
   

# Generated at 2022-06-10 23:03:16.694819
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    expected = {}

    def func(default=None):
        return cliargs_deferred_get('no', default)()

    result = func()
    assert result == expected
    result = func(default=expected)
    assert result == expected
    result = func(default=expected)
    assert result == expected
    result = func(default=expected)
    assert result == expected
    result = func(shallowcopy=True)
    assert result == expected
    result = func(default=expected, shallowcopy=True)
    assert result == expected
    result = func(default=expected, shallowcopy=True)
    assert result == expected
    result = func(default=expected, shallowcopy=True)
    assert result == expected

    expected = []


# Generated at 2022-06-10 23:03:27.140796
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeCLI_ARGS(object):
        def __init__(self, args):
            self.args = args

        def __getattr__(self, name):
            return self.args[name]

        def __getitem__(self, name):
            return self.args[name]

        def get(self, name, default=None, *args, **kwargs):
            return self.args.get(name, default=default, *args, **kwargs)

    def check_shallow(args, key, expected):
        copied = cliargs_deferred_get(key, default=None, shallowcopy=True)()
        assert args[key] is not copied
        assert args[key] == copied

    def check_not_shallow(args, key, expected):
        same = cliargs_deferred_get

# Generated at 2022-06-10 23:03:33.641842
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # setting up
    import copy
    copy_cliargs = copy.copy(CLIARGS)
    # test
    cliargs_deferred_get('v', 'value1')()
    assert CLIARGS == copy_cliargs
    # test
    cliargs_deferred_get('v', 'value1', shallowcopy=True)()
    assert CLIARGS == copy_cliargs

# Generated at 2022-06-10 23:03:46.125745
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.module_utils.common.context as context

    def _test(variable):
        global CLIARGS
        context.CLIARGS = CLIArgs(variable)
        x = cliargs_deferred_get('foo')
        return x()

    # Test a simple value
    assert _test({'foo': 'bar'}) == 'bar'

    # Test a list
    assert _test({'foo': [1, 2, 3]}) == [1, 2, 3]

    # Test a dict
    assert _test({'foo': {'a': 1}}) == {'a': 1}

    # Test a set
    assert _test({'foo': set([1, 2, 3])}) == set([1, 2, 3])

    # Test with a default value

# Generated at 2022-06-10 23:03:55.073198
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """This function is used to test the function cliargs_deferred_get.
    """

    test_dict = {'1': 'one', '2': 'two', '3': 'three'}
    test_list = ['one', 'three', 'two']

    # 1. Test a key that is present in CLIARGS
    def inner_1():
        value = CLIARGS.get('version', default=None)
        return value

    inner_1_copy = cliargs_deferred_get('version')
    assert inner_1() == inner_1_copy()

    # 2. Test a key that is not present in CLIARGS with a default as None
    def inner_2():
        value = CLIARGS.get('version1', default=None)
        return value

    inner_2_copy = cliargs_

# Generated at 2022-06-10 23:04:01.073848
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'check': [False], 'verbosity': [0], 'inventory': ['/path/to/inventory']}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('check')() == [False]
    assert cliargs_deferred_get('inventory')() == ['/path/to/inventory']

# Generated at 2022-06-10 23:04:12.190600
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Setup the test
    CLIARGS = CLIArgs({})

    # Test that the default is returned when the key is not in the cliargs yet
    default_value = 'default'
    assert default_value == cliargs_deferred_get('does_not_exist', default=default_value)()

    # Test that the default is returned when the key is in the cliargs with a false value
    CLIARGS = CLIArgs({'does_not_exist': False})
    assert default_value == cliargs_deferred_get('does_not_exist', default=default_value)()

    # Test that the default is returned when the key is in the cliargs with a value of None
    CLIARGS = CLIArgs({'does_not_exist': None})
    assert default_value == cliargs

# Generated at 2022-06-10 23:04:22.371158
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test function without shallowcopy
    global CLIARGS
    CLIARGS = CLIArgs({'hello': 'world'})
    assert cliargs_deferred_get('hello')() == 'world'
    assert cliargs_deferred_get('goodbye')() is None

    # Test function with shallowcopy
    assert cliargs_deferred_get('hello', shallowcopy=True)() == 'world'
    assert cliargs_deferred_get('goodbye', shallowcopy=True)() is None
    CLIARGS = CLIArgs({'hello': [1, 2, 3]})
    # Verify that shallowcopy copies
    assert cliargs_deferred_get('hello', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-10 23:04:32.806018
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict

    # just a regular non-special type, no special treatment
    cli_args = ImmutableDict({'foo': 'bar'})
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

    # a known container, copy the underlying data
    cli_args = ImmutableDict({'foo': {'a': 1, 'b': 2}})
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == {'a': 1, 'b': 2}

# Generated at 2022-06-10 23:04:42.034465
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Ensure this is always AnsibleModuleArgs even if we
    # remove the global context
    CLIARGS = CLIArgs(dict(foo='bar', baz=[1, 2, 3]))
    # Test for shallow copy
    assert cliargs_deferred_get('foo')() is CLIARGS['foo']
    assert cliargs_deferred_get('baz')() is CLIARGS['baz']
    # Test the closure
    deferred_get_foo = cliargs_deferred_get('foo')
    assert deferred_get_foo() == 'bar'
    # Test shallow copy
    deferred_get_baz = cliargs_deferred_get('baz', shallowcopy=True)
    assert deferred_get_baz() == [1, 2, 3]
    assert deferred_get_

# Generated at 2022-06-10 23:04:50.448368
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert 1 == cliargs_deferred_get('test')({'test': 1})
    assert None is cliargs_deferred_get('test')({'foo': 1})
    assert 2 is cliargs_deferred_get('test', 2)({'foo': 1})
    assert [1, 2] == cliargs_deferred_get('test')({'test': [1, 2]}, shallowcopy=True)
    assert {'foo': 1} == cliargs_deferred_get('test')({'test': {'foo': 1}})

# Generated at 2022-06-10 23:04:58.562844
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    from ansible.module_utils.common._collections_compat import Mapping
    global CLIARGS
    CLIARGS = CLIArgs({'a': 'a'})
    assert cliargs_deferred_get('a')() == 'a'
    assert cliargs_deferred_get('b')() is None
    assert cliargs_deferred_get('b', default='b')() == 'b'
    CLIARGS = CLIArgs({'b': [1, 2, 3]})
    assert cliargs_deferred_get('b', default=[4, 5, 6])() == cliargs_deferred_get('b', default=[4, 5, 6])()
    assert cliargs_deferred_get('b', default=[4, 5, 6])

# Generated at 2022-06-10 23:05:08.229863
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    expected = object()
    cli_args = dict(key=expected)
    _init_global_context(cli_args)
    assert cliargs_deferred_get('key')() is expected
    assert cliargs_deferred_get('nonexistent')() is None
    assert cliargs_deferred_get('nonexistent', default='default')() == 'default'
    assert cliargs_deferred_get('key', shallowcopy=True)() is expected
    expected_copy = cliargs_deferred_get('key', shallowcopy=True)()
    assert expected_copy == expected
    assert isinstance(expected_copy, object)

# Generated at 2022-06-10 23:05:21.503938
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs

    cli_args = CliArgs({'some_arg': 'foo', 'some_list_arg': ['a', 'b', 'c']})

    assert cliargs_deferred_get('some_arg')() == 'foo'
    assert cliargs_deferred_get('some_list_arg', default=['d', 'e', 'f'])() == ['a', 'b', 'c']

    assert cliargs_deferred_get('some_list_arg', shallowcopy=True)() == ['a', 'b', 'c']



# Generated at 2022-06-10 23:05:32.747300
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.callees = [1, 2, 3]

    do_shallowcopy = cliargs_deferred_get('callees', default=[], shallowcopy=True)
    do_copy = cliargs_deferred_get('callees', default=[], shallowcopy=False)

    assert do_shallowcopy() == [1, 2, 3]
    assert do_copy() == [1, 2, 3]

    do_shallowcopy()[0] = 0
    do_copy()[0] = 0

    assert CLIARGS.callees == [1, 2, 3]

    CLIARGS.callees = set(CLIARGS.callees)
    do_shallowcopy = cliargs_deferred_get('callees', default=[], shallowcopy=True)
    do

# Generated at 2022-06-10 23:05:40.616993
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Normal case
    assert cliargs_deferred_get('foo')('bar') == 'bar'

    # Check that we get a shallow copy
    a = []
    def_get = cliargs_deferred_get('foo', shallowcopy=True)
    assert def_get(a) is not a
    assert def_get(a) == a

    # Check that we don't get a shallow copy
    a = []
    def_get = cliargs_deferred_get('foo', shallowcopy=False)
    assert def_get(a) is a

# Generated at 2022-06-10 23:05:47.043488
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    def assert_shallowcopy(obj):
        assert cliargs_deferred_get("foo", obj, shallowcopy=True) is not obj
    def assert_unchanged(obj):
        assert cliargs_deferred_get("foo", obj, shallowcopy=True) is obj
    def assert_default(obj):
        assert cliargs_deferred_get("foo", obj) is obj

    foo = object()
    assert_shallowcopy([1, 2, 3])
    assert_shallowcopy({'a': 1})
    assert_shallowcopy(set([1, 2, 3]))
    assert_unchanged(123)
    assert_unchanged(foo)
    assert_default(None)

    CLIARGS = CLIArgs({'foo': 123})
    assert_unchanged(123)
   

# Generated at 2022-06-10 23:05:57.747061
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'foo': 'bar', 'a': set([1, 2, 3])})

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('a')() == set([1, 2, 3])
    assert cliargs_deferred_get('a', shallowcopy=True)() == set([1, 2, 3])
    assert cliargs_deferred_get('b')() is None
    assert cl

# Generated at 2022-06-10 23:06:06.134725
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    ret_func = cliargs_deferred_get('key')
    assert ret_func() is None
    CLIARGS['key'] = 'value'
    ret_func = cliargs_deferred_get('key', default='default')
    assert ret_func() == 'value'
    CLIARGS['key'] = ['value']
    ret_func = cliargs_deferred_get('key', default=['default'])
    assert ret_func() == 'value'
    ret_func = cliargs_deferred_get('key', default=['default'], shallowcopy=True)
    assert ret_func() == ['value']
    ret_func = cliargs_deferred_get('key', default=['default'], shallowcopy=True)
    ret_func()[0] = 'new'
    assert ret

# Generated at 2022-06-10 23:06:13.262203
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def helper(input, shallowcopy):
        def inner():
            inner.called = True
            return input
        inner.called = False

        cb = cliargs_deferred_get('foo', default=inner, shallowcopy=shallowcopy)

        assert not inner.called
        value = cb()
        assert inner.called
        assert value is input

        del inner.called
        inner.called = False
        assert not inner.called
        another = cb()
        assert not inner.called
        assert another is input

    # Test that if the default is a callable, it is actually called
    helper('bar', shallowcopy=False)

    # Test that the function returns its output
    input = ['bar', 'baz']
    helper(input, shallowcopy=False)
    helper(input, shallowcopy=True)

    input

# Generated at 2022-06-10 23:06:23.892618
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_args = {
        'one': 1,
        'two': 2,
        'three': [1, 2, 3, 4],
        'four': {'a': 1, 'b': 2, 'c': 3},
    }
    cli_args = CLIArgs(test_args)
    assert 1 == cliargs_deferred_get('one')()
    assert 1 == cliargs_deferred_get('one', shallowcopy=True)()
    assert 2 == cliargs_deferred_get('two')()
    assert 2 == cliargs_deferred_get('two', shallowcopy=True)()
    assert [1, 2, 3, 4] == cliargs_deferred_get('three')()

# Generated at 2022-06-10 23:06:35.599076
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'key1_list': [1, 2, 3], 'key2_dict': {'a': 1, 'b': 2}, 'key3_set': {1, 2, 3}})
    # Test getting a key that is defined
    assert cliargs_deferred_get('key1_list')() == [1, 2, 3]
    assert cliargs_deferred_get('key2_dict')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('key3_set')() == {1, 2, 3}
    # Test getting a key that is not defined
    assert cliargs_deferred_get('foo')() is None
    # Test getting a key with default

# Generated at 2022-06-10 23:06:47.265780
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Unit test for function ``cliargs_deferred_get``
    """
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [2, 3], 'c': {'d': 5}})

    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [2, 3]
    assert cliargs_deferred_get('c')() == {'d': 5}

    assert cliargs_deferred_get('b', shallowcopy=True)() == [2, 3]
    assert cliargs_deferred_get('c', shallowcopy=True)() == {'d': 5}

    b_value = cliargs_deferred_get('b')()
    b_value.append(4)

# Generated at 2022-06-10 23:07:01.537474
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert not CLIARGS
    # If a key doesn't exist in the dict it should return a default value
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    # If a key exists in the dict it should return the key value
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo', 'not bar')() == 'bar'



# Generated at 2022-06-10 23:07:07.918417
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # The ordereddict used to maintain the ordering of the cli args prevents shallowcopying
    # here.  We use a list because we are just using it to test the functionality
    cli_args = [('foo', True), ('bar', False)]
    _init_global_context(cli_args)
    assert(cliargs_deferred_get('foo')() == True)
    assert(cliargs_deferred_get('bar')() == False)

    # Exercise get with a default value
    assert(cliargs_deferred_get('baz')() is None)
    assert(cliargs_deferred_get('baz', 'default')() == 'default')

    # Exercise the shallow copy functionality
    cli_args = cli_args + [('baz', 'baz')]

# Generated at 2022-06-10 23:07:18.276478
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS['foo'] = 'bar'

    # Testing full return
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('baz', default='spam')() == 'spam'
    assert cliargs_deferred_get('spam', default={'a': 'b'})() == {'a': 'b'}
    assert cliargs_deferred_get('egg', default=[1, 2])() == [1, 2]

    # Testing shallow copy
    CLIARGS['bar'] = ['a', 'b', 'c']

# Generated at 2022-06-10 23:07:29.539092
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Verify expected argument contract
    # Access key that doesn't exist in the dictionary
    assert cliargs_deferred_get('key_does_not_exist_1')() is None
    # Access key that doesn't exist in the dictionary with default specified
    assert cliargs_deferred_get('key_does_not_exist_2', default='foo')() == 'foo'

    # Access key that does exist in dictionary
    cli_args = {'key_exists': 'foo'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('key_exists')() == 'foo'
    assert cliargs_deferred_get('key_exists', shallowcopy=True)() == 'foo'

    # Access sequences, sets, and mappings

# Generated at 2022-06-10 23:07:35.429342
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    my_cliargs = CLIArgs({}, defaults={'VAL': 1, 'OTHERVAL': 'otherval'})
    my_get = cliargs_deferred_get('VAL', default='defaultval')
    my_copied_get = cliargs_deferred_get('VAL', default='defaultval', shallowcopy=True)
    my_otherget = cliargs_deferred_get('OTHERVAL', default='defaultval')
    my_othercopied_get = cliargs_deferred_get('OTHERVAL', default='defaultval', shallowcopy=True)
    my_notsetget = cliargs_deferred_get('NOTSET', default='defaultval')

# Generated at 2022-06-10 23:07:46.018901
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.errors import AnsibleError
    from ansible.plugins.filter.core import to_nice_yaml
    from ansible.module_utils._text import to_text
    from ansible.utils.context_objects import GlobalCLIArgs, CLIArgs
    import collections, types

    def closure_with_copy_func(copy_func):
        def closure():
            return copy_func()
        return closure

    class FakeCLIArgs(GlobalCLIArgs):
        def __init__(self):
            super(FakeCLIArgs, self).__init__({})
            self.vars = ["fake_var"]
            self.tags = ["fake_tag"]
            self.skip_tags = ["fake_skiptag"]
           

# Generated at 2022-06-10 23:07:56.420082
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class A:
        pass

    a = A()
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

    CLIARGS.update({'baz': 'qux'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == 'qux'
    assert cliargs_deferred_get('baz', default='foo')() == 'qux'

    CLIARGS.update({'baz': [1, 2, 3]})
    assert cliargs

# Generated at 2022-06-10 23:08:05.822161
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': {'bar': 1, 'baz': 2}})
    fn = cliargs_deferred_get('foo')
    assert fn() == {'bar': 1, 'baz': 2}

    assert fn() is not fn()

    fn2 = cliargs_deferred_get('foo', shallowcopy=True)
    assert fn2() == {'bar': 1, 'baz': 2}
    assert fn2() is not fn2()
    assert fn() is str(fn())
    assert fn2() is str(fn2())

# Generated at 2022-06-10 23:08:12.549488
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.context_objects import GlobalCLIArgs
    from ansible.module_utils.six import PY3
    import tempfile
    import copy

    def get_tempfile():
        # create a tempfile on disk and add to it
        _, tempfilename = tempfile.mkstemp()
        with open(tempfilename, 'w') as fileobj:
            fileobj.write('#!/bin/bash\n')
        return tempfilename

    # create a fake cli_args object

# Generated at 2022-06-10 23:08:20.152213
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = [u'--verbose', u'--foo=bar']

    _init_global_context(cliargs)
    assert CLIARGS.verbosity == 2
    assert CLIARGS.foo == u'bar'

    def_verbosity = cliargs_deferred_get('verbosity', 0)
    def_foo = cliargs_deferred_get('foo', u'buzz')

    assert def_verbosity() == 2
    assert def_foo() == u'bar'

    del CLIARGS
    assert def_verbosity() == 0
    assert def_foo() == u'buzz'

# Generated at 2022-06-10 23:08:46.373920
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function ``cliargs_deferred_get``"""
    from ansible.context_objects.cliargs import UserCLIArgs
    from ansible.module_utils.six import PY2

    class DummyObject(object):
        pass

    dummy_object = DummyObject()

    cli_args = UserCLIArgs({})
    cli_args.update({
        'foo': 'bar',
        'baz': [1, 2, 3, 4],
        'koo': {'q': 'r'},
        'boo': Set(['a', 'b', 'c']),
        'poo': dummy_object,
    })
    # This is normally done by ANSIBLE_CONFIG/ansible-config
    cli_args['config'] = 'foo'
    cli_args.update

# Generated at 2022-06-10 23:08:55.693583
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs

    cliargs = GlobalCLIArgs({})

    closure = cliargs_deferred_get('test')
    assert closure() == None, "'test' should not yet be in cliargs"

    value = {'a': 'b'}
    cliargs.update(test=value)
    assert closure() == value, "'test' should now be in cliargs"

    value2 = closure()
    assert value2 is not value, "'test' should be different when shallowcopy=True"
    assert value2 == value, "'test' should be equal when shallowcopy=True"

    closure = cliargs_deferred_get('test', shallowcopy=False)
    value2 = closure()

# Generated at 2022-06-10 23:09:04.883980
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # default
    CLIARGS = CLIArgs({})
    assert None is cliargs_deferred_get('foo')()

    # get
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert 'bar' is cliargs_deferred_get('foo')()

    # get with default
    CLIARGS = CLIArgs({})
    assert 'baz' is cliargs_deferred_get('foo', default='baz')()

    # get with default override
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert 'bar' is cliargs_deferred_get('foo', default='baz')()

    # copy shallowly
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert 'bar' is cliargs_deferred_

# Generated at 2022-06-10 23:09:14.835876
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foobar')() is None
    CLIARGS['foobar'] = 'BarFu'
    assert cliargs_deferred_get('foobar')() == 'BarFu'
    CLIARGS['foobar'] = [1, 2, 3]
    assert cliargs_deferred_get('foobar')() == [1, 2, 3]
    assert cliargs_deferred_get('foobar', shallowcopy=True)() == [1, 2, 3]
    # however types that can't be shallowcopied get a deepcopy
    CLIARGS['foobar'] = {1: 'a', 2: 'b'}
    assert cliargs_deferred_get('foobar')() == {1: 'a', 2: 'b'}
    assert cliargs_deferred_

# Generated at 2022-06-10 23:09:23.282513
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Populate CLIARGS with some dummy data
    CLIARGS.update({
        'list': [1, 2, 3, 4],
        'tuple': (1, 2, 3, 4),
        'set': {1, 2, 3, 4},
        'dict': {1: 1, 2: 2, 3: 3, 4: 4},
        'string': 'string',
        'int': 5,
        'non_shallow_munged': False,
        'default': False,
    })

    # test_default_value
    assert cliargs_deferred_get('default')() is False
    assert cliargs_deferred_get('doesnt_exist', default=True)() is True
    assert cliargs_deferred_get('doesnt_exist')() is None

    # test_non_sh

# Generated at 2022-06-10 23:09:33.944390
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the closure defered_get creates that can be used to initialize fields"""
    # Test default get
    cli_args = {}
    _init_global_context(cli_args)
    with_default = cliargs_deferred_get('foo', 'bar')
    assert with_default() == 'bar'
    # Test existing get
    cli_args = {'foo': 'baz'}
    _init_global_context(cli_args)
    with_default = cliargs_deferred_get('foo', 'bar')
    assert with_default() == 'baz'

    # Check shallow copy on collections.
    cli_args = {'foo': [1, 2, 3]}
    _init_global_context(cli_args)

# Generated at 2022-06-10 23:09:39.635106
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    del CLIARGS['foo']
    assert cliargs_deferred_get('foo', 'baz')() == 'baz'

# Generated at 2022-06-10 23:09:46.534107
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Basic unit test for cliargs_deferred_get

    This test's functionality should be expanded as cliargs_deferred_get adds more functionality
    """
    _init_global_context({'ANSIBLE_TEST': {'one': 1, 'two': 2}})

    # Test that a scalar returns as expected
    assert cliargs_deferred_get('ANSIBLE_TEST', default={'def':'scalar'}) == {'one': 1, 'two': 2}

    # Test that a copy works as expected
    value = cliargs_deferred_get('ANSIBLE_TEST', shallowcopy=True)
    value['one'] = 2
    assert CLIARGS['ANSIBLE_TEST']['one'] == 1
    assert value['one'] == 2

# Generated at 2022-06-10 23:09:59.037862
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_dict = {
        'b_bool': True,
        's_string': 'string',
        'l_list': ['list'],
        'd_dict': {'dict': 'dict'},
        'se_set': {'set'},
        'default': 'default',
    }
    cliargs = CLIArgs(cliargs_dict)
    assert cliargs_dict == cliargs

    for key, value in cliargs.items():
        assert cliargs_deferred_get(key)(), value

    for key, value in cliargs.items():
        assert cliargs_deferred_get(key, shallowcopy=True)(), value

    assert cliargs_deferred_get('default', default='newdefault')(), 'newdefault'
    assert cliargs_deferred

# Generated at 2022-06-10 23:10:07.033141
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert type(CLIARGS) == CLIArgs
    args = dict(foo={'a':'b'}, bar=['baz1', 'baz2'], biz=set(['baz3', 'baz4']))
    CLIARGS = CLIArgs(args)

    # Deferred get doesn't change state of cliargs
    assert cliargs_deferred_get('foo')() == args['foo']
    assert cliargs_deferred_get('foo')() is args['foo']
    assert cliargs_deferred_get('bar')() == args['bar']
    assert cliargs_deferred_get('bar')() is args['bar']
    assert cliargs_deferred_get('biz')() == args['biz']

# Generated at 2022-06-10 23:10:50.787058
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test():
        assert cliargs_deferred_get(None, default=10)() == 10
        assert cliargs_deferred_get(None)() is None

        assert cliargs_deferred_get('foo', default=10)() == 10
        assert cliargs_deferred_get('foo')() is None

        CLIARGS['foo'] = 10
        assert cliargs_deferred_get('foo', default=20)() == 10

        CLIARGS['bar'] = [1, 2, 3, 4]
        assert cliargs_deferred_get('bar', default=[1, 2])() == [1, 2, 3, 4]
        assert cliargs_deferred_get('bar', default=[1, 2], shallowcopy=True)() == [1, 2, 3, 4]


# Generated at 2022-06-10 23:10:56.379077
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test default value
    dg = cliargs_deferred_get('key', default='value')
    assert dg() == 'value'
    # Test shallow copy of list
    dg = cliargs_deferred_get('key', default=[1, 2, 3], shallowcopy=True)
    assert dg() == [1, 2, 3]
    # Test shallow copy of dict
    dg = cliargs_deferred_get('key', default={1: 2, 2: 3}, shallowcopy=True)
    assert dg() == {1: 2, 2: 3}
    # Test getting a value from cliargs
    CLIARGS = CLIArgs({'key': 'value'})
    dg = cliargs_deferred_get('key')
    assert dg() == 'value'
    # Test shallow

# Generated at 2022-06-10 23:11:05.147896
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIArgs
    cli_args = GlobalCLIArgs.from_options({'check': True})
    assert cli_args.get('check') is True

    # TODO: Make this work with the object instance?
    get_check = cliargs_deferred_get('check')
    assert get_check() is True

    # Need a different way to test that it works with CLIARGS being replaced
    # This one is caputuring the value of CLIARGS once and then running
    # the closure with a different CLIARGS
    cli_args = CLIArgs({'check': False})
    get_check = cliargs_deferred_get('check')
    assert get_check() is True

    global CLIARGS

# Generated at 2022-06-10 23:11:16.101540
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.display import Display
    from ansible.utils.color import stringc

    class FakeCliArgs:
        def __init__(self, cli_args):
            self._data = cli_args

        def __contains__(self, key):
            return key in self._data

        def get(self, key, default=None):
            return self._data.get(key, default)

        def __iter__(self):
            return iter(self._data.items())

    _init_global_context(FakeCliArgs({'ANSIBLE_FORCE_COLOR': True}))

    # Test basic function
    f = cliargs_deferred_get('ANSIBLE_FORCE_COLOR')
    assert f()

    # Test default

# Generated at 2022-06-10 23:11:25.872110
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    my_list = ['a', 'b', 'c']
    my_dict = {'a': 1, 'e': 5}
    my_set = {'a', 'b'}
    my_str = 'abc'
    class Options(object):
        def __init__(self, **kwargs):
            for key, val in kwargs.items():
                setattr(self, key, val)

    cli_args = Options(list=my_list, dict=my_dict, set=my_set, str=my_str)
    _init_global_context(cli_args)
    assert cliargs_deferred_get('list')() == my_list
    assert cliargs_deferred_get('dict')() == my_dict
    assert cliargs_deferred_get('set')() == my

# Generated at 2022-06-10 23:11:33.928419
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'debug': True})
    dget = cliargs_deferred_get('debug')
    assert dget() is True

    _init_global_context({})
    dget = cliargs_deferred_get('debug', default=False)
    assert dget() is False

    _init_global_context({})
    dget = cliargs_deferred_get('debug', default=[])
    assert dget() == []

    _init_global_context({})
    dget = cliargs_deferred_get('debug', default={})
    assert dget() == {}

# Generated at 2022-06-10 23:11:46.833185
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This function is created only once the CLIARGS object is created.
    assert hasattr(cliargs_deferred_get, '__code__'), (
        'test_cliargs_deferred_get is not a function. '
        'This is because the CLIARGS object does not yet exist')
    from ansible.utils.context_objects import GlobalCLIArgs
    CLIARGS = GlobalCLIArgs.from_options({'foo': 1, 'bar': [2, 3]})

    # Basic get
    assert cliargs_deferred_get('foo') == 1

    # Get with default
    assert cliargs_deferred_get('baz', default=4) == 4

    # Shallow copy of a list
    list_default = [5, 6]
    shallow_copy_default = cliargs_deferred_get

# Generated at 2022-06-10 23:11:56.449288
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping

    CLIARGS.set('foo', 'bar')
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='default')() == 'bar'
    assert cliargs_deferred_get('bar', default='default')() == 'default'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS.set('foo', ['a', 'b', 'c'])
    assert cliargs_deferred_get('foo')() == ['a', 'b', 'c']