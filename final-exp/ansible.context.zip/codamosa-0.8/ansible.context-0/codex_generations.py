

# Generated at 2022-06-10 23:02:06.942751
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS._data = {'foo': 'bar'}
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('baz', 'baz')() == 'baz'
    assert cliargs_deferred_get('baz', 'baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-10 23:02:12.899480
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=invalid-name
    """Test that deferred_get returns the key or the default"""
    CLIARGS.update({'key1': 'value1', 'key2': 'value2'})
    assert cliargs_deferred_get('key1')() == 'value1'
    assert cliargs_deferred_get('key2')() == 'value2'
    assert cliargs_deferred_get('key3', default='value3')() == 'value3'

# Generated at 2022-06-10 23:02:22.576714
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(foo='bar'))
    value = cliargs_deferred_get('foo')
    assert value() == 'bar'
    # Make sure we don't accidentally use the global directly
    value2 = cliargs_deferred_get('foo')
    CLIARGS = CLIArgs(dict(foo='foobar'))
    assert value2() == 'foobar'
    # Make sure we can handle deepcopy use cases
    CLIARGS = CLIArgs(dict(foo=['bar']))
    value3 = cliargs_deferred_get('foo', shallowcopy=True)
    assert value3() == ['bar']

# Generated at 2022-06-10 23:02:32.540984
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

# Generated at 2022-06-10 23:02:43.408110
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict1 = dict(a=dict(b='c'))
    dict2 = dict(z='y')
    cliargs = GlobalCLIArgs(dict1)
    a_dict_b = cliargs_deferred_get('a.b')(cliargs)
    assert a_dict_b == 'c'
    a_dict_b = cliargs_deferred_get('a.b', default=dict2)(cliargs)
    assert a_dict_b == 'c'
    cliargs = GlobalCLIArgs(dict())
    a_dict_b = cliargs_deferred_get('a.b', default=dict2)(cliargs)
    assert a_dict_b == dict2
    cliargs = GlobalCLIArgs(dict1)
    a_dict_b = cliargs_deferred

# Generated at 2022-06-10 23:02:50.907950
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.parsing.utils.env_var import get_default_value
    default = get_default_value
    cliargs_deferred_get('check_mode', default)().assert_equals(default)
    cliargs_deferred_get('check_mode', default, shallowcopy=True)().assert_equals(default)
    cliargs_deferred_get('check_mode', [], shallowcopy=True)().assert_equals([])
    cliargs_deferred_get('check_mode', [], shallowcopy=False)().assert_equals([])
    cliargs_deferred_get('check_mode', {}, shallowcopy=True)().assert_equals({})

# Generated at 2022-06-10 23:03:02.203566
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # check basic functionality
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': 3})
    # no shallow copy
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == 3
    assert cliargs_deferred_get('baz', default=False)() is True
    assert cliargs_deferred_get('spam')(default=False) is False
    # with shallow copy
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == 3
    assert cliargs_deferred_get('baz', default=False, shallowcopy=True)() is True

# Generated at 2022-06-10 23:03:13.974663
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    import copy

    class Thing(object):  # pylint: disable=too-few-public-methods
        """
        Class with side effects when it is copied
        """
        def __init__(self, thing_id):
            self.thing_id = thing_id
            self.copied = False

        def __copy__(self):
            self.copied = True
            return Thing(self.thing_id)

    THING_VALUE = Thing(0)
    CLIARGS_DICT = {'thing': THING_VALUE}

    class OptionCategory(object):
        """Class that defines the options in a parsed ``Parser``"""
        thing = CLIARGS.options.Str()

    _init_global_context(OptionCategory())
    CLIAGS

# Generated at 2022-06-10 23:03:15.533189
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-10 23:03:22.721962
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    some_key = 'some_key'
    some_value = 'some_value'
    cliargs = CLIArgs({some_key: some_value})
    global CLIARGS
    CLIARGS = cliargs
    # Caller gets the key from a deferred closure
    deferred = cliargs_deferred_get(some_key)
    assert deferred is not None, "deferred function was not created"
    # Call the deferred function to get the cliargs
    assert deferred() == some_value, "cliargs_deferred_get did not return expected value"

# Generated at 2022-06-10 23:03:35.247034
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    # Create a local CLIARGS object and make sure we can get a value out of it
    test_cliargs = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Set CLIARGS to a blank object and ensure that we can get a default value out of it
    global CLIARGS
    orig_cliargs = CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default='baz')() == 'baz'
    CLIARGS = orig_cliargs

    # Create a local CLIARGS with a list, dict, and set and ensure that shallow copying works

# Generated at 2022-06-10 23:03:44.610456
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'
    bar_getter = cliargs_deferred_get('foo')
    assert 'bar' == bar_getter()
    # Make sure the copy is deep
    CLIARGS['bar'] = {'key1': 'val1', 'key2': 'val2'}
    bar_getter = cliargs_deferred_get('bar', shallowcopy=True)
    bar = bar_getter()
    bar['key2'] = 'notval2'
    bar['key3'] = 'val3'
    assert 'notval2' == bar['key2']
    assert 'val3' == bar['key3']
    assert 'val2' == CLIARGS['bar']['key2']
    assert 'key3' not in CLIARGS['bar']
    # Make

# Generated at 2022-06-10 23:03:53.843031
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test deferred getting of CLIARGS"""
    global CLIARGS
    CLIARGS = CLIArgs(dict(foo=dict(bar=1, baz=2)))
    assert cliargs_deferred_get('foo')() == dict(bar=1, baz=2)
    assert cliargs_deferred_get('foo', shallowcopy=True)() == dict(bar=1, baz=2)
    assert cliargs_deferred_get('foo.bar')() == 1
    assert cliargs_deferred_get('foo.bar', shallowcopy=True)() == 1

    bar_1 = cliargs_deferred_get('foo.bar')()
    cliargs_deferred_get('foo.bar')()[0] = 1000

# Generated at 2022-06-10 23:04:06.525771
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    list_val = [1, 2, 3]
    set_val = {1, 2, 3}
    mapping_val = {'1': 1, '2': 2, '3': 3}
    complex_val = (1, 2, 3)

    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({})

    cliargs_deferred_get('list', list_val)().extend(list_val)
    assert cliargs_deferred_get('list')() == [1, 2, 3, 1, 2, 3]
    cliargs_deferred_get('set', set_val)().add(4)
    assert cliargs_deferred_get('set')() == {1, 2, 3, 4}

# Generated at 2022-06-10 23:04:19.062189
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from shutil import copy

    original_values = {'a': 1, 'b': 2, 'c': [3, 4, 5], 'd': {'e': 6, 'f': 7}, 'g': {8, 9, 10}}
    cli_args = CLIArgs(original_values)

    dest_values = {'a': 1, 'b': 2, 'c': [3, 4, 5], 'd': {'e': 6, 'f': 7}, 'g': {8, 9, 10}}
    assert cliargs_deferred_get('a')() == dest_values['a']
    assert cliargs_deferred_get('b')() == dest_values['b']
    assert cliargs_deferred_get('c')() == dest_values['c']
    assert cliargs_deferred_get

# Generated at 2022-06-10 23:04:27.498388
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # void context
    def check_return(key, expected_return, expected_type=None):
        actual_return = cliargs_deferred_get(key, default='foo')()
        assert actual_return == expected_return
        if expected_type is not None:
            assert isinstance(actual_return, expected_type)

    assert cliargs_deferred_get('nonexistent', default=False)() is False
    assert cliargs_deferred_get('nonexistent', default=None)() is None

    check_return('nonexistent', 'foo')
    check_return('nonexistent', 'foo')

    # void context with shallow copy
    assert cliargs_deferred_get('nonexistent', default=[])() == []

# Generated at 2022-06-10 23:04:37.917952
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    global CLIARGS
    CLIARGS = CLIArgs({'a':1})
    assert 1 == cliargs_deferred_get('a')()
    assert None == cliargs_deferred_get('b')()
    assert 2 == cliargs_deferred_get('b', 2)()
    CLIARGS = CLIArgs({'a':[1,2,3]})
    assert [1,2,3] == cliargs_deferred_get('a')()
    assert copy.copy([1,2,3]) == cliargs_deferred_get('a', shallowcopy=True)()
    CLIARGS = CLIArgs({'a':frozenset({1,2,3})})
    assert frozenset({1,2,3}) == cliargs_deferred_get('a')

# Generated at 2022-06-10 23:04:49.470290
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(foo="bar", bar="baz"))
    assert "bar" == CLIARGS.get('foo')

    # Test that the correct default is returned
    assert "default" == cliargs_deferred_get('does_not_exist', default="default")()

    # Test that shallow copies are returned
    CLIARGS['baz'] = list(range(10))
    assert list(range(10)) == cliargs_deferred_get('baz', shallowcopy=True)()
    # Test that it really is a copy
    cliargs_deferred_get('baz', shallowcopy=True)().append('10')
    assert list(range(10)) != cliargs_deferred_get('baz', shallowcopy=True)()


# Generated at 2022-06-10 23:04:58.096006
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy

    class _CliArgs(object):
        def __init__(self, cli_args):
            self._cli_args = cli_args

        def __getitem__(self, key):
            return self._cli_args[key]

        def __setitem__(self, key, value):
            self._cli_args[key] = value

    def check_deferred_value_equality(test_case, key, value, shallow_copy=False):
        """Check that cliargs_deferred_get returns the same object as cliargs"""
        test_case.assertEqual(cliargs_deferred_get(key), value)

        # Assert that they are actually the same object

# Generated at 2022-06-10 23:05:03.481588
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    inner = cliargs_deferred_get('value')
    assert inner() == None

    CLIARGS.update({'value': 'foo'})
    assert inner() == 'foo'

    CLIARGS.update({'value': 'bar'})
    assert inner() == 'bar'

# Generated at 2022-06-10 23:05:17.211069
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_default(value, default, expected):
        _init_global_context({})
        got = cliargs_deferred_get(value, default, shallowcopy=False)()
        assert got == expected, 'expected {} got {}'.format(expected, got)

    test_default('foo', 'bar', 'bar')

    # Make sure we keep the type of the default value
    test_default('foo', [1, 2, 3], [1, 2, 3])
    test_default('foo', set((1, 2, 3)), set((1, 2, 3)))
    test_default('foo', dict(a=1, b=2), dict(a=1, b=2))

    # Make sure we copy a value when requested
    _init_global_context({'foo': [1, 2, 3]})
    got

# Generated at 2022-06-10 23:05:27.347816
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': {'che': 'quix'}})
    assert cliargs_deferred_get('foo')(), 'bar'
    assert cliargs_deferred_get('baz')(), {'che': 'quix'}
    assert cliargs_deferred_get('foo', default='baz')(), 'bar'
    assert cliargs_deferred_get('xyzzy', default='baz')(), 'baz'
    assert cliargs_deferred_get('baz', shallowcopy=True)(), {'che': 'quix'}
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not CLIARGS['baz'], "Copy of dictionary"
    assert cl

# Generated at 2022-06-10 23:05:39.156103
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from tests.unit.callback_plugins.test_cliargs import test_global_context
    test_global_context.CliArgs.setUpClass()
    cli_args = CLIARGS = GlobalCLIArgs.from_options(test_global_context.cli_args)

    has_x = cliargs_deferred_get('x', default=False)
    assert has_x() is False
    cliargs_deferred_set('x', True)
    assert has_x() is True

    has_gathering_facts = cliargs_deferred_get('gathering_facts', default=False, shallowcopy=True)
    assert has_gathering_facts() == False
    cliargs_deferred_set('gathering_facts', True)
    assert has_gathering_facts() == True


# Generated at 2022-06-10 23:05:46.244869
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('test')() is None
    _init_global_context({'test': 'test'})
    assert cliargs_deferred_get('test')() == 'test'
    # Setting CLIARGS directly for testing
    CLIARGS['test'] = True
    assert cliargs_deferred_get('test')() is True
    assert cliargs_deferred_get('test', shallowcopy=True)() is True
    CLIARGS['test_list'] = [True, False]
    assert cliargs_deferred_get('test_list')() == [True, False]
    assert cliargs_deferred_get('test_list', shallowcopy=True)() == [True, False]
    CLIARGS['test_set'] = {'true', 'false'}

# Generated at 2022-06-10 23:05:57.098390
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3]})
    f = cliargs_deferred_get('baz', shallowcopy=True)

    def test_list_shallow():
        l = f()
        l[0] = 42
        assert f()[0] == 1, 'Function did not shallow copy the list'

    def test_list_no_shallow():
        l = f()
        l[0] = 42
        assert f()[0] == 42, 'Function shallow copied an object when it was not asked to'

    def test_str_shallow():
        value = f()
        value = 'not a list'
        assert f() == 'bar', 'Function did not shallow copy the list'

    def test_str_no_shallow():
        value

# Generated at 2022-06-10 23:06:05.836909
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCliArgs(GlobalCLIArgs):
        def __init__(self, args):
            self._data = args

    args = {'foo': 'bar'}
    cli_args = TestCliArgs(args)

    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'

    args['moo'] = 'cow'
    assert cliargs_deferred_get('moo', default='baz')() == 'cow'

    args['test_list'] = [1, 2, 3]
    assert cliargs_deferred_get('test_list', default='baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_

# Generated at 2022-06-10 23:06:13.247060
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    import pickle
    import unittest

    class CliArgsDeferredGetTest(unittest.TestCase):
        def setUp(self):
            # Make sure we are reset to a clean state
            global CLIARGS
            _init_global_context({})

        def test_get_default(self):
            expected = 'foo'
            actual = cliargs_deferred_get('baz', default=expected)()
            self.assertEqual(actual, expected)
            actual = cliargs_deferred_get('baz')()
            self.assertIsNone(actual)

        def test_get_true(self):
            expected = 'foo'
            CLIARGS['baz'] = expected
            actual = cliargs_deferred_get('baz')()
            self.assertEqual

# Generated at 2022-06-10 23:06:23.854071
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_default():
        """Case where the value is the same as the default"""
        # Default value is a primitive
        assert cliargs_deferred_get('test', default=1)() == 1
        # Default value is iterable
        assert cliargs_deferred_get('test', default=set([1]))() == set([1])
        # Default value is Mapping
        assert cliargs_deferred_get('test', default={1: 1})() == {1: 1}

        # Default value is a primitive but value is a sequence
        assert cliargs_deferred_get('test', default=1, shallowcopy=True)() == [1]
        # Default value is an iterable but value is a sequence
        assert cliargs_deferred_get('test', default=set([1]), shallowcopy=True)

# Generated at 2022-06-10 23:06:35.541009
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('baz', 'bar')() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo', 'baz')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', 'baz', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo', 'baz')() == {'bar': 'baz'}
   

# Generated at 2022-06-10 23:06:47.221859
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MockCliArgs(object):
        # pylint: disable=no-self-use
        def __getitem__(self, key):
            return key

    global CLIARGS
    CLIARGS = MockCliArgs()
    for arg in ('-v', '--verbose', 'frobnicate', 'complex', '--complex-arg'):
        # Default value should be None
        assert cliargs_deferred_get(arg)() is None
        # Key should not change
        assert cliargs_deferred_get(arg)() is arg
        # Key should not change
        assert cliargs_deferred_get(arg)() is arg

    # Set the CLIARGS back to the empty dict
    CLIARGS = CLIArgs({})

    # Test some simple values
    assert cliargs_deferred_

# Generated at 2022-06-10 23:07:05.113354
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS._options = {'foo': {'bar': 'baz'}}
    assert cliargs_deferred_get('foo.bar')() == 'baz'
    CLIARGS._options = {'ansible_run_tags': ['baz']}
    assert cliargs_deferred_get('ansible_run_tags')() == ['baz']
    assert cliargs_deferred_get('ansible_run_tags', shallowcopy=True)() == ['baz']
    CLIARGS._options = {}
    assert cliargs_deferred_get('foo.bar', 'default')() == 'default'
    assert cliargs_deferred_get('ansible_run_tags', 'default')() == 'default'
    CLIARGS._options = {'foo': 'bar'}
    assert cl

# Generated at 2022-06-10 23:07:14.065233
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    result = cliargs_deferred_get('a')()
    assert result is CLIARGS['a']
    assert result is CLIARGS['a']

    result = cliargs_deferred_get('a', shallowcopy=True)()
    assert result is CLIARGS['a']
    assert result is not CLIARGS['a']
    assert result is CLIARGS['a']

    result = cliargs_deferred_get('foo')()
    assert result is None
    assert result is None

    result = cliargs_deferred_get('foo', shallowcopy=True)()
    assert result is None
    assert result is None

    result = cliargs_deferred_get('a', default='b')()
    assert result is CLIARGS['a']
    assert result is CLIARGS['a']


# Generated at 2022-06-10 23:07:21.914612
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils._text import to_bytes

    def _convert_non_set_mapping(val):
        if isinstance(val, Mapping) and not isinstance(val, Set):
            return dict(val)
        return val

    class Foo:
        bar = cliargs_deferred_get('bar', default=None, shallowcopy=False)
        baz = cliargs_deferred_get('baz', default=None, shallowcopy=True)

    assert CLIARGS == {}
    assert Foo.bar() is None
    assert Foo.baz() is None

    CLIARGS.update(dict(bar=1, baz=2, qux=dict(quux=[1,2,3])))

# Generated at 2022-06-10 23:07:32.107154
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    CliArgs = CLIArgs  # Back up the global class
    CLIArgs.clear()  # Global singleton
    CLIARGS = CLIArgs({})  # Unit test instance
    CLIARGS.update({"list": [1, 2, 3], "set": {'a', 'b', 'c'}, "list_of_list": [[1, 2, 3], [4, 5, 6]]})
    assert cliargs_deferred_get("list")() == [1, 2, 3]
    assert cliargs_deferred_get("list")() == cliargs_deferred_get("list")()  # Same object
    assert cliargs_deferred_get("list", shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-10 23:07:42.180829
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import MutableSet

    CLIARGS['key'] = 'value'
    # Set up a deferred get with a default
    deferred_default_get = cliargs_deferred_get('key', 'default')
    assert CLIARGS['key'] == deferred_default_get()
    CLIARGS['key'] = 'new_value'
    assert CLIARGS['key'] == deferred_default_get()
    del CLIARGS['key']
    assert 'default' == deferred_default_get()

    # Set up a deferred get with no default
    deferred_get = cliargs_deferred_get('key2')
    assert 'default' == deferred_get()
    CLIARGS['key2'] = 'new_value'

# Generated at 2022-06-10 23:07:52.635359
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar',
                'baz': ['qux', 'quux'],
                'corge': {'grault': 'garply', 'waldo': 'fred'},
                'quux': {'garply', 'waldo', 'fred'},}

    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['qux', 'quux']
    assert cliargs_deferred_get('baz', shallowcopy=False)() == ['qux', 'quux']

# Generated at 2022-06-10 23:08:00.361446
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import namedtuple
    CliArgs = namedtuple('CLIARGS', ('test_key1',))
    class GlobalCliArgs(CliArgs):
        """Class that allows attributes to be set after definition"""
        def __init__(self, args):
            super(GlobalCliArgs, self).__init__(**args)
        def __setattr__(self, key, value):
            setattr(self, key, value)

    # Test that we get the default
    CLIARGS = GlobalCliArgs({})
    f = cliargs_deferred_get('key1', default='default')
    assert 'default' == f()

    # Test that we get the actual value of the CLIARGS

# Generated at 2022-06-10 23:08:12.020402
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for function cliargs_deferred_get"""
    # Note: set is not deep copied but is still a copy
    cli_args = CLIArgs({'a': {'b': 'c'}, 'd': [0, 1, 2], 'e': 'f', 'g': set([1, 2, 3])})
    get_a_b = cliargs_deferred_get('a:b')
    get_d = cliargs_deferred_get('d')
    get_g = cliargs_deferred_get('g')
    get_h = cliargs_deferred_get('h')
    get_h_copy = cliargs_deferred_get('h', shallowcopy=True)

    # Since we bound to CLIARGS, and not to cli_args, we need to initialize


# Generated at 2022-06-10 23:08:21.734941
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.display import Display
    import ansible.utils.context_objects as test_context
    # This is a bit hackish, but it's the easiest way to unit test this
    test_context._GLOBAL_CLI_ARGS = CLIARGS

# Generated at 2022-06-10 23:08:33.055625
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'foo': 'bar', 'bar': [1, 2, 3], 'spam': {'a': 1, 'b': 2}, 'eggs': {1, 2, 3, 1}, 'tags': 'spam'})

    # Basic check
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() == [1, 2, 3]
    assert cliargs_deferred_get('spam')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('eggs')() == {1, 2, 3}

    # Missing key
    assert cliargs_deferred_get('missing')() is None

# Generated at 2022-06-10 23:08:58.754873
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # create the actual class to make sure we can call the closure itself
    class TestClass(object):
        def __init__(self):
            self.closure = cliargs_deferred_get('key', default='default_value')
        def called(self):
            return self.closure()

    # when CLIARGS is not yet set, we still get the default
    obj = TestClass()
    assert obj.called() == 'default_value', \
        "Expected default of 'default_value' from closure when CLIARGS has not yet been set"
    _init_global_context({'key':'value'})
    assert obj.called() == 'value', \
        "Expected 'value' from closure after CLIARGS is properly initialized"
    # make sure we can get a new value when CLIARGS is replaced
    global CLIAR

# Generated at 2022-06-10 23:09:08.745065
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 'a', 'b': 'c', 'c': {}, 'd': set()})
    assert cliargs_deferred_get('a', default='b')() == 'a'
    assert cliargs_deferred_get('c', default='b')() == {}
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('a', default='b')() == 'b'
    assert cliargs_deferred_get('c', default='b')() == 'b'

    CLIARGS = CLIArgs({'a': 'a', 'b': 'c', 'c': {}, 'd': set()})
    assert cliargs_deferred_get('a', default='b', shallowcopy=True)() == 'a'
   

# Generated at 2022-06-10 23:09:18.400386
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Make sure cliargs_deferred_get works as expected"""
    # TODO: these should be moved to a general test_common.py
    inner = cliargs_deferred_get('foo', 'bar')
    assert inner() == 'bar'

    inner = cliargs_deferred_get('foo', 'bar', shallowcopy=True)
    assert inner() == 'bar'

    cli_args = {'foo': [1, 2, 3]}
    _init_global_context(cli_args)
    inner = cliargs_deferred_get('foo', 'bar', shallowcopy=True)
    assert inner() == [1, 2, 3]

    cli_args = {'foo': {'bar': 1}}
    _init_global_context(cli_args)
    inner = cliargs_def

# Generated at 2022-06-10 23:09:25.099025
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    cliargs = {'ansible_verbosity': 3}
    class FakeGlobalCliArgs(object):
        def __init__(self, args):
            self.args = args

        def get(self, key, default=None):
            return self.args[key]

    for args in (dict(a=1, b=2, c=3), [1, 2, 3], (1, 2, 3), {1, 2, 3}, {'a': 1, 'b': 2, 'c': 3}):
        CLIARGS = FakeGlobalCliArgs(dict(verbosity=args))
        f = cliargs_deferred_get('verbosity', default=2)
        assert f() == args

        # For this test, we modify the default to make sure we're getting
        # the copy back

# Generated at 2022-06-10 23:09:32.894810
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dictionary = {'a': 'test', 'b': 42}
    CLIARGS.replace(dictionary)
    f = cliargs_deferred_get('a', 'default')
    assert f() == 'test'
    g = cliargs_deferred_get('c', 'default')
    assert g() == 'default'
    h = cliargs_deferred_get('b', shallowcopy=True)
    assert h() == 42
    i = cliargs_deferred_get('a', shallowcopy=True)
    assert i() == 'test'

# Generated at 2022-06-10 23:09:43.458374
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # check the function works with GlobalCLIArgs
    CLIARGS.setdefault('foo', 'bar')
    v = cliargs_deferred_get('foo')
    assert v() == 'bar'
    # check the function works with CLIArgs
    _init_global_context(dict())
    assert cliargs_deferred_get('foo', default='baz')() == 'baz'
    # check the shallow copy with a list
    CLIARGS.setdefault('foo', [1, 2, 3])
    v = cliargs_deferred_get('foo', shallowcopy=True)
    assert v == [1, 2, 3]
    assert v() is not CLIARGS['foo']
    # check the shallow copy with a set
    CLIARGS.setdefault('foo', set((1, 2, 3)))
   

# Generated at 2022-06-10 23:09:49.928234
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def raise_error(*args, **kwargs):
        raise KeyError()

    def test_value():
        return {'a': {'b': {'c': 'd'}}}

    # test default
    _init_global_context({})
    assert cliargs_deferred_get('fake_key', True)() is True

    # test normal CLIARGS key is found
    _init_global_context({'fake_key': True, 'other_key': False})
    assert cliargs_deferred_get('fake_key')() is True
    # test normal CLIARGS key is not found
    CLIARGS.get = raise_error
    assert cliargs_deferred_get('fake_key')() is None

    # test deepcopy
    _init_global_context({})
    assert cliargs_def

# Generated at 2022-06-10 23:10:01.678554
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(a=1, b=2, c=dict(d=3), e=[0, 1], f={1, 2}, g=object()))
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == 2
    assert cliargs_deferred_get('c')() == {'d': 3}
    assert cliargs_deferred_get('e')() == [0, 1]
    assert cliargs_deferred_get('f')() == {1, 2}
    assert cliargs_deferred_get('g')() is CLIARGS['g']
    assert cliargs_deferred_get('h')() is None

# Generated at 2022-06-10 23:10:08.918886
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    ''' Unit test for function cliargs_deferred_get
    '''
    def _test_assertion(name, default, shallowcopy):
        ''' Internal function for testing assertion
        '''
        def_get_value = cliargs_deferred_get(name, default=default, shallowcopy=shallowcopy)
        value = def_get_value()
        assert value == default

        # set value, update value
        CLIARGS[name] = name
        assert CLIARGS[name] == name

        # ensure the value is not mutated by ``def_get_value``
        def_get_value()
        assert CLIARGS[name] == name

        # set value to a list, update value to a list
        CLIARGS[name] = [name]
        value = def_get_value()
        assert value

# Generated at 2022-06-10 23:10:19.334296
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from copy import copy
    my_args = {'debug': False,
               'vault_password_file': 'my_password_file',
               'vault_password': 'my_password',
               }
    cli_args = GlobalCLIArgs.from_options(my_args)
    deferred_getter = cliargs_deferred_get('debug', default=True, shallowcopy=False)
    assert not deferred_getter()
    my_args['debug'] = True
    assert deferred_getter()
    deferred_getter = cliargs_deferred_get('vault_password', default='no_vault_password', shallowcopy=False)
    assert deferred_getter() == 'my_password'
    deferred_getter = cliargs

# Generated at 2022-06-10 23:11:02.331675
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function itself works with parsing deferred to a later time
    _init_global_context({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': set([1, 2, 3])})
    cliargs_deferred_get('foo')() == 'bar'
    cliargs_deferred_get('baz')() == [1, 2, 3]
    cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    cliargs_deferred_get('quux')() == set([1, 2, 3])
    cliargs_deferred_get('does not exist', default='default')() == 'default'

# Generated at 2022-06-10 23:11:10.576307
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Retrieve a key that is not set
    assert CLIARGS.get('asdf') is None

    # Retrieve an empty key
    assert cliargs_deferred_get('asdf')() is None
    # Retrieve an empty key with a default
    assert cliargs_deferred_get('asdf', default=True)() is True

    # Retrieve a key with a value
    CLIARGS['asdf'] = 'fdsa'
    assert cliargs_deferred_get('asdf')() == 'fdsa'
    assert cliargs_deferred_get('asdf', default=True)() == 'fdsa'

    # Retrieve a key with a value with shallow copy enabled
    in_list = ['foo']
    in_dict = {'bar': 'baz'}
    CLIARGS

# Generated at 2022-06-10 23:11:21.177231
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'a': 10, 'b': [1, 2, 3], 'c': {'d': 4, 'e': 5}, 'f': 'g'}
    global CLIARGS
    CLIARGS = CLIArgs(cli_args)

    # Check with default value
    assert cliargs_deferred_get('a')(), 10
    assert cliargs_deferred_get('x', 10)(), 10

    # Check with shallowcopy
    assert cliargs_deferred_get('b', shallowcopy=True)(), [1,2,3]
    assert cliargs_deferred_get('c', shallowcopy=True)(), {'d': 4, 'e': 5}
    assert cliargs_deferred_get('f', shallowcopy=True)(), 'g'

# Generated at 2022-06-10 23:11:32.282351
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get closure"""
    import types

    tmp_cliargs = CLIARGS
    CLIARGS = CLIArgs({'key': 'value'})
    assert cliargs_deferred_get('key')() == 'value'

    # Test that it's still a function
    assert isinstance(cliargs_deferred_get('key'), types.FunctionType)
    assert isinstance(cliargs_deferred_get('key'), types.LambdaType)

    # Test that it returns the default
    assert cliargs_deferred_get('key2')() is None
    assert cliargs_deferred_get('key2', 'default_value')() == 'default_value'
    CLIARGS = tmp_cliargs



# Generated at 2022-06-10 23:11:44.974185
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Arrange
    global CLIARGS
    CLIARGS = CLIArgs({'test': 'default'})
    a = cliargs_deferred_get('test')
    b = cliargs_deferred_get('test', shallowcopy=True)

    # Act
    CLIARGS['test'] = 'value'

    # Assert
    assert a() == 'value'
    assert b() == 'value'

    # Act
    CLIARGS['test'] = [1, 2, 3]

    # Assert
    assert a() == [1, 2, 3]
    assert b() == [1, 2, 3]

    # Act
    CLIARGS['test'] = {1, 2, 3}

    # Assert
    assert a() == {1, 2, 3}

# Generated at 2022-06-10 23:11:54.287858
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=missing-docstring,invalid-name
    CLIARGS._args = {'key': 'value'}

    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('invalidkey')() is None
    assert cliargs_deferred_get('invalidkey', default='value')() == 'value'

    assert cliargs_deferred_get('invalidkey', shallowcopy=True)() is None
    assert cliargs_deferred_get('key', shallowcopy=True)() == 'value'
    assert cliargs_deferred_get('key', shallowcopy=True, default='value')() == 'value'

# Generated at 2022-06-10 23:12:02.224925
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    global CLIARGS
    old_CLIARGS = CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': 'bop'})