

# Generated at 2022-06-10 23:02:12.460785
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.value = dict(a=dict(b=2))
    # This should be able to run multiple times and get a different value each time
    value = cliargs_deferred_get('a.b')()
    assert value == 2
    value = cliargs_deferred_get('a.b')()
    assert value == 2
    # This should copy the value each time if we ask for shallow copy
    value = cliargs_deferred_get('a', shallowcopy=True)()
    value['b'] = 3
    value = cliargs_deferred_get('a', shallowcopy=True)()
    assert value['b'] == 3
    # This should get the same value each time from the same context
    value = cliargs_deferred_get('a', shallowcopy=True)()

# Generated at 2022-06-10 23:02:23.758869
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def assert_copy(original, expected):
        got = cliargs_deferred_get(key='test')(original)
        assert original == got  # Prove that the original object was not modified
        assert expected == got

    assert cliargs_deferred_get(key='test', default=None)() is None
    assert 'a' == cliargs_deferred_get(key='test', default='a')()
    # Mock of an incomplete dict/set
    incomplete = type('Incomplete', (object,), {'copy': lambda: 'copied'})
    assert 'copied' == cliargs_deferred_get(key='test', shallowcopy=True)(incomplete)

    assert_copy(None, None)
    assert_copy(True, True)
    assert_copy(False, False)
    assert_copy

# Generated at 2022-06-10 23:02:33.290944
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test 1: Test that cliargs_deferred_get does not shallow copy if shallowcopy
    # is not set.
    dict_obj = dict(test_dict={'1': 1, '2': 5})
    test_dict = dict_obj.get('test_dict')
    assert test_dict is not None
    inner = cliargs_deferred_get('test_dict', dict_obj)
    assert inner.__closure__ is not None
    assert inner() is test_dict
    test_dict['3'] = 8
    assert inner() == dict_obj['test_dict']

    # Test 2: Test that cliargs_deferred_get returns a copy of the dict if
    # shallowcopy is set
    dict_obj = dict(test_dict={'1': 1, '2': 5})

# Generated at 2022-06-10 23:02:44.281644
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert cliargs_deferred_get('test') == None
    CLIARGS = CLIArgs()
    CLIARGS.update({"test": 1})
    assert cliargs_deferred_get('test', shallowcopy=False) == 1
    assert cliargs_deferred_get('test', shallowcopy=True) == 1
    CLIARGS.update({'test': [1, 2, 3]})
    result = cliargs_deferred_get('test', shallowcopy=False)
    assert result is not [1,2, 3]
    assert result == [1,2, 3]
    result = cliargs_deferred_get('test', shallowcopy=True)
    assert result is not [1, 2, 3]
    assert result == [1, 2, 3]

# Generated at 2022-06-10 23:02:55.894675
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 'bar', 'a': [1, 2, 3], 'b': {'z': '19'}, 'c': set([42])})

    # Simple usage
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'notbar')() == 'bar'
    assert cliargs_deferred_get('notfoo', 'notbar')() == 'notbar'
    assert cliargs_deferred_get('notfoo', default='notbar')() == 'notbar'
    assert cliargs_deferred_get('notfoo', default='notbar', shallowcopy=True)() == 'notbar'

    # Sequence copy testing
    a_copy = cliargs_deferred_get('a', shallowcopy=True)

# Generated at 2022-06-10 23:03:01.748138
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', 1)() == 1
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']

# Generated at 2022-06-10 23:03:13.548195
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that we are able to retrieve a value and receive the default
    CLIARGS.set_from_options({})
    default = 'default-value'
    key = 'test-key'
    value = cliargs_deferred_get(key, default)()
    assert default == value, "Default value should be returned when no value is in CLIARGS. Current CLIARGS: {}".format(CLIARGS.get_all())
    CLIARGS.set_from_options({key: 'value-from-cliarg'})
    # Test that we can retrieve the value from CLIARGS
    value = cliargs_deferred_get(key, default)()

# Generated at 2022-06-10 23:03:20.099856
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class A(object):
        a = cliargs_deferred_get('test')

    test_obj = A()
    test_obj.a = 'foo'
    # Ensure that this value is not replaced
    assert test_obj.a == 'foo'

    global CLIARGS
    CLIARGS = CLIArgs({})
    # Ensure that the value was copied not referenced
    assert test_obj.a == 'foo'

    CLIARGS = CLIArgs({'test': 'bar'})
    # Ensure that the value was replaced
    assert test_obj.a == 'bar'

    def a(default=object()):
        return cliargs_deferred_get('test', default=default)

    test_obj = A()
    test_obj.a = 'foo'
    # Ensure that this value is not replaced
    assert test

# Generated at 2022-06-10 23:03:30.650923
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['test'] = 'bar'
    getter = cliargs_deferred_get('test')
    assert getter() == 'bar'

    getter = cliargs_deferred_get('test', default='baz')
    assert getter() == 'bar'

    getter = cliargs_deferred_get('no_key', default='baz')
    assert getter() == 'baz'

    CLIARGS['list'] = ['foo', 'bar', 'baz']
    getter = cliargs_deferred_get('list')
    assert getter() == ['foo', 'bar', 'baz']
    getter = cliargs_deferred_get('list', shallowcopy=True)
    assert getter() == ['foo', 'bar', 'baz']

# Generated at 2022-06-10 23:03:39.330823
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs, GlobalCLIArgsFake

# Generated at 2022-06-10 23:03:51.506918
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cliargs = dict(a=1, b=2, c=3, d=4)
    CLIARGS = CLIArgs(cliargs)
    assert 5 == cliargs_deferred_get('e', default=5)
    assert 3 == cliargs_deferred_get('c')
    assert 3 == cliargs_deferred_get('c', shallowcopy=True)
    cliargs['c'] = 10
    assert 10 == cliargs_deferred_get('c')
    dvalue = cliargs_deferred_get('d')
    assert 4 == dvalue()
    cliargs['d'] = 20
    assert 20 == dvalue()
    f = cliargs_deferred_get('f', default=[10])
    assert [10] == f()
    cliargs

# Generated at 2022-06-10 23:04:04.402418
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('nonesuch')() is None
    # This is the same value that GlobalCLIArgs.default uses
    assert cliargs_deferred_get('become_user')() == 'root'
    # Immutable values passed through
    assert cliargs_deferred_get('start_at_task', default={})() == {}
    # Shallow copy for mutable values
    assert cliargs_deferred_get('start_at_task', default={})() == CLIARGS.default('start_at_task')
    assert cliargs_deferred_get('start_at_task', default={}, shallowcopy=True)() is not CLIARGS.default('start_at_task')
    # Run tests again but with CLIARGS set to None
    CLIARGS = None
    assert cl

# Generated at 2022-06-10 23:04:15.176679
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeArgs(dict):
        def __getattr__(self, attr):
            try:
                return self[attr]
            except KeyError:
                raise AttributeError("'%s' object has no attribute '%s'" %(self.__class__, attr))

        def __setattr__(self, attr, val):
            self[attr] = val

    def test_func():
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(FakeArgs())
        CLIARGS.explicit_subset = 'test'
        def_test_value = cliargs_deferred_get('explicit_subset')
        # test function is returned
        assert callable(def_test_value)
        # test function returns the correct value

# Generated at 2022-06-10 23:04:25.652944
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.config.data import Var
    from ansible.module_utils.six import PY2

    CLIARGS['vars'] = Var([])
    assert cliargs_deferred_get('vars', default=[]) == []

    CLIARGS['vars'] = Var([])

    not_existing_key = 'not_existing_key'
    with_default = cliargs_deferred_get(not_existing_key, default=[])
    assert with_default == []

    without_default = cliargs_deferred_get(not_existing_key)
    assert without_default == not_existing_key

    existing_key = 'vars'
    with_default = cliargs_deferred_get(existing_key, default=[1, 2, 3])
    assert with_default == []

    #

# Generated at 2022-06-10 23:04:30.360875
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import Mapping
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # The Mapping API is not explicit about how it will be copied.
    # Therefore, we just assert that it is callable
    assert callable(cliargs_deferred_get('hello', default=Mapping()))

# Generated at 2022-06-10 23:04:40.395165
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({'foo': 'bar'})
    _init_global_context(cliargs)

    fun = cliargs_deferred_get('foo')
    assert fun() == 'bar'

    fun = cliargs_deferred_get('bar', default=42)
    assert fun() == 42

    fun = cliargs_deferred_get('foo', default=42)
    assert fun() == 'bar'

    cliargs = CLIArgs({'foo': [1,2,3]})
    _init_global_context(cliargs)

    fun = cliargs_deferred_get('foo')
    assert fun() == [1, 2, 3]

    fun = cliargs_deferred_get('foo', shallowcopy=True)
    assert fun() == [1, 2, 3]


# Generated at 2022-06-10 23:04:51.582707
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    getter = cliargs_deferred_get('foo', 'bar', shallowcopy=False)
    assert 'foo' not in CLIARGS
    assert getter() == 'bar'
    CLIARGS['foo'] = 'baz'
    assert getter() == 'baz'

    getter_copy = cliargs_deferred_get('foo', 'bar', shallowcopy=True)
    assert getter_copy() == 'baz'
    CLIARGS['foo'] = 'quux'
    assert getter_copy() == 'baz'

    CLIARGS['foo'] = foo = [1, 2, 3]
    getter_copy = cliargs_deferred_get('foo', 'bar', shallowcopy=True)
    assert getter_copy() == foo
   

# Generated at 2022-06-10 23:04:55.552564
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    closure = cliargs_deferred_get('foo', default='bar', shallowcopy=False)
    assert closure() == 'bar'
    CLIARGS['foo'] = 'baz'
    assert closure() == 'baz'

# Generated at 2022-06-10 23:05:08.147961
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Verify that the closure works
    assert cliargs_deferred_get('a', True)()

    # Verify that the value is not used until after assignment
    old_cliargs = CLIARGS
    CLIARGS = CLIArgs()
    assert cliargs_deferred_get('a', True)() is True
    CLIARGS = old_cliargs

    # Verify that the default is not used until after assignment
    old_cliargs = CLIARGS
    CLIARGS = CLIArgs()
    assert cliargs_deferred_get('a', True)() is True
    CLIARGS = old_cliargs

    # Verify that the closure uses initial value
    old_cliargs = CLIARGS
    CLIARGS = CLIArgs({'a': True})
    assert cliargs_deferred_get('a', False)() is True

# Generated at 2022-06-10 23:05:17.572093
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import unittest

    class TestCliArgsDeferredGet(unittest.TestCase):
        def test_return_value(self):
            """Test value when cliargs has been defined"""
            CLIARGS.update(a_value='asdf')
            self.assertEqual('asdf', cliargs_deferred_get('a_value')())
            self.assertEqual('asdf', cliargs_deferred_get('a_value')())

        def test_return_default(self):
            """Test value when cliargs has not been defined"""
            def_value = 'qwer'
            self.assertEqual(def_value, cliargs_deferred_get('a_value2', default=def_value)())


# Generated at 2022-06-10 23:05:28.294959
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': [1, 2], 'bar': 'baz'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')(), [1, 2]
    assert cliargs_deferred_get('foo', shallowcopy=True)(), [1, 2]
    assert cliargs_deferred_get('bar')(), 'baz'
    assert cliargs_deferred_get('bar', shallowcopy=True)(), 'baz'
    assert cliargs_deferred_get('old', default=dict, shallowcopy=True)(), {}
    assert cliargs_deferred_get('old', default=dict)(), {}
    assert cliargs_deferred_get('old', default=list, shallowcopy=True)(), []

# Generated at 2022-06-10 23:05:39.950848
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get

    This doesn't use mock.patch because that destroys the singletons in CLIARGS.
    """
    from ansible.utils.context_objects import GlobalCLIArgs
    global CLIARGS  # pylint: disable=global-statement
    orig_args = CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({'foo': 'bar', 'baz': [1, 2], 'set': {'foo', 'bar'}})

# Generated at 2022-06-10 23:05:46.702032
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = {'foo': 123, 'bar': [1, 2, 3], 'baz': {'a': 1, 'b': 2}}
    _init_global_context(cliargs)

    assert cliargs_deferred_get('foo')() == 123
    assert cliargs_deferred_get('bar')() == [1, 2, 3]
    assert cliargs_deferred_get('baz')() == {'a': 1, 'b': 2}

    assert id(CLIARGS.get('bar')) == id(cliargs_deferred_get('bar')())
    assert id(CLIARGS.get('baz')) == id(cliargs_deferred_get('baz')())

    cliargs['foo'] = 456

    # First test that shallow copies are not made


# Generated at 2022-06-10 23:05:57.450403
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function ``cliargs_deferred_get``"""
    def set_and_check(value, shallow_copy=False):
        """Function to set ``CLIARGS`` and test it"""
        global CLIARGS
        _init_global_context(value)
        assert CLIARGS.get('value') == cliargs_deferred_get('value', shallowcopy=shallow_copy)()

    set_and_check({'value': True})
    set_and_check({'value': 'string'})
    set_and_check({'value': False})
    set_and_check({'value': 1})
    set_and_check({'value': {'dict': '1'}})
    set_and_check({'value': ['list', 'of', 'strings']})

# Generated at 2022-06-10 23:06:06.003156
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = dict(ansible_vault_password_file='passfile.txt')
    _init_global_context(cli_args)

    ret = cliargs_deferred_get('ansible_vault_password_file', default='not_set')
    assert ret == 'passfile.txt'

    ret = cliargs_deferred_get('ansible_vault_password_file', default='not_set', shallowcopy=True)
    assert ret == 'passfile.txt'

    ret = cliargs_deferred_get('ansible_vault_password_file2', default='not_set')
    assert ret == 'not_set'

    ret = cliargs_deferred_get('ansible_vault_password_file2', default='not_set', shallowcopy=True)

# Generated at 2022-06-10 23:06:13.242445
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    import copy
    import types

    cli_args = {
        'foo': 'bar',
        'baz': True,
        'list': [1, 2, 3],
        'list_copy': lambda: [1, 2, 3],
        'set': {1, 2, 3},
        'set_copy': lambda: {1, 2, 3},
        'dict': {'a': 1, 'b': 2, 'c': 3},
        'dict_copy': lambda: {'a': 1, 'b': 2, 'c': 3},
    }

    _init_global_context(cli_args)


# Generated at 2022-06-10 23:06:23.855826
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    old_cliargs = CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'quux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('baz') == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True) == [1, 2, 3]
    assert cliargs_deferred_get('quux') == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('quux', shallowcopy=True) == {'a': 1, 'b': 2}

# Generated at 2022-06-10 23:06:35.540844
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cliargs = {'foo': 1, 'bar': [1, 2]}
    CLIARGS = CLIArgs(cliargs)
    for key, val in cliargs.items():
        assert cliargs_deferred_get(key)() == val
        assert cliargs_deferred_get(key, default='baz')() == val
        assert cliargs_deferred_get(key, shallowcopy=True)() == val[:]
        assert cliargs_deferred_get(key, default='baz', shallowcopy=True)() == val[:]

    assert cliargs_deferred_get('nonexistent')() is None
    assert cliargs_deferred_get('nonexistent', default='baz')() == 'baz'
    assert cliargs_deferred_get

# Generated at 2022-06-10 23:06:42.003732
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {
        '_ansible_check_mode': True,
        '_ansible_verbosity': 2,
    }
    _init_global_context(cli_args)
    assert cliargs_deferred_get('_ansible_check_mode')()
    assert cliargs_deferred_get('_ansible_verbosity')() == 2

# Generated at 2022-06-10 23:06:52.623720
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Sequence
    # Remove any existing CLIARGS first
    global CLIARGS
    CLIARGS = CLIArgs({})

    # Variable doesn't exist
    # Default provided
    # Default not provided
    # KeyError
    assert cliargs_deferred_get('foo')() == None
    assert cliargs_deferred_get('foo', default=True)() is True
    try:
        cliargs_deferred_get('foo', default=None)()
    except KeyError:
        pass
    else:
        raise AssertionError('KeyError not raised with no default')

    # Shallow copy sequence
    CLIARGS = GlobalCLIArgs.from_options({'foo': [1, 2, 3]})

# Generated at 2022-06-10 23:07:08.579277
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    d_copy = cliargs_deferred_get('test_val', shallowcopy=True)()
    d_nocopy = cliargs_deferred_get('test_val')()

    assert d_copy is d_nocopy
    assert d_copy is not d_nocopy
    assert d_nocopy is None
    assert d_copy is None

    CLIARGS['test_val'] = 'foo'

    d_copy = cliargs_deferred_get('test_val', shallowcopy=True)()
    d_nocopy = cliargs_deferred_get('test_val')()

    assert d_copy is d_nocopy
    assert d_copy is not d_nocopy
    assert d_nocopy == 'foo'

# Generated at 2022-06-10 23:07:18.942457
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    list_value = ['a', 'b', 'c']
    set_value = set(['a', 'b', 'c'])
    mapping_value = {'a': 1, 'b': 2, 'c': 3}
    int_value = 10
    # Test default value
    default_value = 'default'
    deferred_default = cliargs_deferred_get('key_does_not_exist', default=default_value)
    assert deferred_default() == default_value
    # Test getting from CLIARGS
    CLIARGS = CLIArgs({'list_value': list_value, 'set_value': set_value, 'mapping_value': mapping_value, 'int_value': int_value})
    deferred_list = cliargs_deferred_get('list_value')
    assert deferred_list() == list

# Generated at 2022-06-10 23:07:30.285940
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    import sys
    import collections
    import pytest

    class Foo(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return 'Foo({0!r})'.format(self.value)

    class CLIArgs(object):
        def __init__(self, args):
            self._args = args

        def get(self, key, default=None):
            return self._args.get(key, default)

    def mock_cliargs_deferred_get(key, default=None, shallowcopy=False):
        return cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)

    # Replace the global CLIARGS with our mock container
    old_cliargs = sys.modules[__name__].CL

# Generated at 2022-06-10 23:07:40.387509
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'var': True, 'constant': 'constant'}
    _init_global_context(cli_args)
    func = cliargs_deferred_get('var')
    assert func() is True
    assert func() is True
    func = cliargs_deferred_get('constant')
    assert func() == 'constant'
    assert func() == 'constant'
    func = cliargs_deferred_get('nonexistant')
    assert func() is None
    assert func() is None
    func = cliargs_deferred_get('nonexistant', 'default')
    assert func() is 'default'
    assert func() is 'default'
    func = cliargs_deferred_get('nonexistant', shallowcopy=True)
    # Shallow copy of None is

# Generated at 2022-06-10 23:07:50.959804
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def set_cliargs_with(value):
        global CLIARGS
        CLIARGS = CLIArgs({'ANSIBLE_TEST': value})

    set_cliargs_with('TEST')
    inner = cliargs_deferred_get('ANSIBLE_TEST')
    assert inner() == 'TEST'

    set_cliargs_with(['TEST1', 'TEST2'])
    inner = cliargs_deferred_get('ANSIBLE_TEST', shallowcopy=True)
    assert inner() == ['TEST1', 'TEST2']

    set_cliargs_with({'a': 'TEST1', 'b': 'TEST2'})
    inner = cliargs_deferred_get('ANSIBLE_TEST', shallowcopy=True)

# Generated at 2022-06-10 23:07:59.640318
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for cliargs_deferred_get"""
    _init_global_context(dict(a=1, b=[1,2,3], c={'a': 'b'}))
    a = cliargs_deferred_get('a')
    assert a() == 1
    assert a() == 1
    b = cliargs_deferred_get('b')
    assert b() == [1,2,3]
    assert b() == [1,2,3]
    c = cliargs_deferred_get('c')

    assert c() == {'a': 'b'}
    assert c() == {'a': 'b'}

    b1 = cliargs_deferred_get('b', shallowcopy=True)

# Generated at 2022-06-10 23:08:11.516381
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_defaults(function):
        function().should.equal(None)
        function(default=1).should.equal(1)

    def test_call(function, value):
        CLIARGS.clear()
        CLIARGS.update({'key1': value})
        function().should.equal(value)

    args1 = {'key1': 1, 'key2': 2, 'key3': 3}
    args2 = {}
    for args in (args1, args2):
        CLIARGS.clear()
        CLIARGS.update(args)
        function = cliargs_deferred_get('key1', default=None)
        function.__name__.should.equal('inner')
        test_defaults(function)
        test_call(function, 10)

# Generated at 2022-06-10 23:08:12.764996
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({'test': 'value'})
    get = cliargs_deferred_get('test')
    assert get() == 'value'



# Generated at 2022-06-10 23:08:21.972024
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    global CLIARGS
    CLIARGS._store = {'dict': {'key': 'value'},
                      'seq': [1, 2, 3],
                      'klass': object()}

    # Test shallow copy defaults to True
    assert cliargs_deferred_get('dict')() == CLIARGS['dict']
    assert cliargs_deferred_get('dict')() is not CLIARGS['dict']
    assert cliargs_deferred_get('seq')() == CLIARGS['seq']
    assert cliargs_deferred_get('seq')() is not CLIARGS['seq']
    assert cliargs_deferred_get('klass')() is CLIARGS['klass']

    # Test shallow copy when set to True
    assert cliargs_def

# Generated at 2022-06-10 23:08:33.258963
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    config = {'foo': {'bar': 'baz'}, 'a': 'b'}

    # Initially no args
    assert CLIARGS.get('foo') is None
    assert CLIARGS.get('foo', 'quux') is None
    assert CLIARGS.get('foo', 'quux') == 'quux'

    assert CLIARGS.get('foo', default={'bar': 'newbaz'}) == {'bar': 'newbaz'}
    assert CLIARGS['foo'] is None
    assert CLIARGS.get('foo', default={'bar': 'newbaz'}) == {'bar': 'newbaz'}

    # Try to get from the dict
    assert cliargs_deferred_get('foo', 'quux') == 'quux'
    assert cliargs_deferred_get

# Generated at 2022-06-10 23:08:57.867261
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['a'] = 'b'
    result = cliargs_deferred_get('a', 'c')
    assert result() == 'b'
    result = cliargs_deferred_get('a2', 'c')
    assert result() == 'c'
    CLIARGS['a2'] = 'd'
    assert result() == 'd'


# These are the default values that should be set after reading the CLIARGS
DEFAULT_IGNORE_OPTIONS = cliargs_deferred_get('ignore_options', [])
DEFAULT_IGNORE_FILES = cliargs_deferred_get('ignore_files', [])

# Generated at 2022-06-10 23:09:03.345600
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    >>> _init_global_context(dict(a=1, b=2))
    >>> cliargs_deferred_get('c')(), cliargs_deferred_get('c', default=42)(), cliargs_deferred_get('a')()
    (None, 42, 1)
    >>> cliargs_deferred_get('b', shallowcopy=True)(), cliargs_deferred_get('b', shallowcopy=False)()
    (2, 2)
    >>> a = dict(x=1)
    >>> b = cliargs_deferred_get('c', default=a, shallowcopy=True)()
    >>> a is b, b['x']
    (False, 1)
    """

# Generated at 2022-06-10 23:09:13.076971
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

# Generated at 2022-06-10 23:09:22.348300
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        import unittest.mock as mock
        from unittest.mock import call
    except ImportError:
        from mock import mock, call

    from ansible.utils.context_objects import CLIArgs

    # These tests are not as thorough as they could be, as we're testing for a particular
    # behavior, not every possible test.  The tests of the actual class cover the full gambit
    with mock.patch('ansible.module_utils.common.context._init_global_context') as mock_init:
        mock_init.return_value = None
        mock_args = mock.MagicMock(spec=CLIArgs)
        mock_args.get.return_value = 'somevalue'

        # The function will have been bound to a specific CLIArgs instance, so GlobalCLIArgs
        # should work, but not

# Generated at 2022-06-10 23:09:33.231186
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CliArgs(dict):
        def __init__(self, *args, **kwargs):
            super(CliArgs, self).__init__(*args, **kwargs)
            self.default = None
        def set_default(self, *args, **kwargs):
            self.default = args, kwargs
        def get(self, key, *args, **kwargs):
            self.set_default(*args, **kwargs)
            return super(CliArgs, self).get(key, *args, **kwargs)

    args = CliArgs()

    args['key'] = 3
    args['key2'] = 'value'
    args['key3'] = [1, 2, 3]
    args['key4'] = {'a': 'b', 'c': 'd'}

# Generated at 2022-06-10 23:09:43.690720
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    test_map = {'a': 1, 'b': ['c', 'd']}
    test_seq = ['e', 'f']
    _init_global_context(test_map)
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('a', default=3)() == 1
    assert cliargs_deferred_get('c')() is None
    assert cliargs_deferred_get('c', default=4)() == 4
    assert isinstance(cliargs_deferred_get('b')(), list)

# Generated at 2022-06-10 23:09:49.984928
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Tests to make sure the function correctly shallow copies and copies multidimensional data
    import copy
    import sys

    # Setup
    cli_args = {'a': 1, 'b': {'c': 3}, 'd': [1, 2, 3]}
    _init_global_context(cli_args)
    get_default = cliargs_deferred_get('not_there_at_all', 42)
    get_a = cliargs_deferred_get('a')
    get_b = cliargs_deferred_get('b', shallowcopy=True)
    get_c = cliargs_deferred_get('b.c')
    get_d = cliargs_deferred_get('d', shallowcopy=True)

    # Test normal get

# Generated at 2022-06-10 23:10:01.717896
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCliArgs(object):
        # Setting as a static member because we want to be able to check that the
        # value is returned in the dictionary we expect
        test_value = 'test_value'

        def __getitem__(self, key):
            return self.__dict__[key]

        def __setitem__(self, key, value):
            self.__dict__[key] = value

        def get(self, key, default=None):
            return self.__dict__.get(key, default)

    cli_args = TestCliArgs()

    # Basic get
    cli_args['test_key'] = cli_args.test_value
    test_closure = cliargs_deferred_get('test_key')
    assert test_closure() == cli_args.test_value



# Generated at 2022-06-10 23:10:09.510803
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for cliargs_deferred_get"""
    global CLIARGS
    # setup
    cli_args = {'a': 1, 'b': [1, 2, 3], 'c': {'a': 1}}
    CLIARGS = CLIArgs(cli_args)
    # Sanity
    assert cli_args == CLIARGS['a']

    # Get three different keys
    for key in cli_args:
        assert cli_args[key] == cliargs_deferred_get(key)()
    # Get non-existent key
    assert None == cliargs_deferred_get('d')()
    # Get non-existent key with default
    assert 'foo' == cliargs_deferred_get('d', 'foo')()
    # Get a with default
    assert 1 == cli

# Generated at 2022-06-10 23:10:19.765479
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-10 23:11:02.804654
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Needed to ensure that we set the CLIARGS to the global
    def init_global_context(cli_args):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('some_key')() is None
    init_global_context({'some_key': 'test'})
    assert cliargs_deferred_get('some_key')() == 'test'
    assert cliargs_deferred_get('some_key', 'default')() == 'test'
    assert cliargs_deferred_get('some_key', default='default')() == 'test'
    assert cliargs_deferred_get('some_other_key', 'default')() == 'default'

# Generated at 2022-06-10 23:11:12.296217
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global_default = {'a': 1, 'b': 2, 'c': 3}
    global_copy = CLIARGS.copy()
    cliargs_deferred = cliargs_deferred_get('a', default=global_default, shallowcopy=True)
    assert(cliargs_deferred == global_default['a']) # this should be 1

    # Test the copy functionality - mutate the copy and it should still be 1
    global_default['a'] = 4
    assert(cliargs_deferred == 1) # this should be 1

    # Test the no-copy option
    global_default['a'] = 5
    cliargs_deferred = cliargs_deferred_get('a', default=global_default)
    assert(cliargs_deferred == global_default['a']) # this should be 5



# Generated at 2022-06-10 23:11:22.297976
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name,unused-variable
    # Test with a sequence
    value = []
    func = cliargs_deferred_get("a key that doesnt exist", default=value)
    retval = func()
    assert retval is value

    # Test with a mutable type
    dict_value = {"foo": "bar"}
    func = cliargs_deferred_get("a key that doesnt exist", default=dict_value)
    retval = func()
    assert retval is dict_value
    retval["bar"] = "foo"
    assert dict_value["bar"] == "foo"

    # Test with a mutable type
    set_value = {"foo"}
    func = cliargs_deferred_get("a key that doesnt exist", default=set_value)
   

# Generated at 2022-06-10 23:11:28.082513
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update(dict(foo='bar', bar=dict(spam='eggs')))
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('bar')() == dict(spam='eggs')
    assert cliargs_deferred_get('bar', shallowcopy=True)() == dict(spam='eggs')

# Generated at 2022-06-10 23:11:37.217995
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _set_global_args(args):
        global CLIARGS
        CLIARGS = GlobalCLIArgs(args)

    _set_global_args(dict(a=1, b=2, c=3, d=4))
    # pylint: disable=unsubscriptable-object
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == 2
    assert cliargs_deferred_get('c')() == 3
    assert cliargs_deferred_get('d')() == 4
    assert cliargs_deferred_get('e')() is None
    assert cliargs_deferred_get('e', default='e')() == 'e'

    assert cliargs_deferred_get('a', shallowcopy=True)

# Generated at 2022-06-10 23:11:48.579422
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Sequence

    # Test default=
    value = cliargs_deferred_get('not_there', default=42)
    assert value() == 42

    # Test setting the value
    CLIARGS.module_defaults['not_there'] = 42
    value = cliargs_deferred_get('not_there', default=42)
    assert value() == 42

    assert not isinstance(value(), Sequence)


# FIXME: This should all be done by making these attributes on the context so that we don't need a special function
# for this.  However, that would mean reworking Fields, FieldAttribute, and Attribute to support this for the
# ``default`` attribute.


# Generated at 2022-06-10 23:11:58.209617
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = {'start_at_task': 'foo', 'tags': ['tag1', 'tag2'], 'skip_tags': ['tag3', 'tag4'], 'vars': {'var1': 'bar'}}
    _init_global_context(cliargs)
    assert CLIARGS.get('start_at_task') == 'foo'
    assert CLIARGS.get('tags') == ['tag1', 'tag2']
    assert CLIARGS.get('skip_tags') == ['tag3', 'tag4']
    assert CLIARGS.get('vars') == {'var1': 'bar'}
    cliargs['vars']['var2'] = 'baz'
    assert CLIARGS.get('vars') == {'var1': 'bar', 'var2': 'baz'}