

# Generated at 2022-06-10 23:02:11.734551
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.clear()
    assert cliargs_deferred_get('foo')() is None
    CLIARGS['foo'] = 1
    assert cliargs_deferred_get('foo')() == 1
    CLIARGS['bar'] = 'bar'
    assert cliargs_deferred_get('bar')() == 'bar'
    CLIARGS['bar'] = ['bar']
    assert cliargs_deferred_get('bar', shallowcopy=True)() == ['bar']
    CLIARGS['bar'] = ('bar', )
    assert cliargs_deferred_get('bar', shallowcopy=True)() == ('bar', )
    CLIARGS['bar'] = {'bar': 'bar'}

# Generated at 2022-06-10 23:02:22.931519
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from copy import copy
    from ansible.context import CLIARGS as CLIARGS_ORIG

    default = 'foo'
    key = 'test'
    value = 'bar'

    # test not being set, no default, no shallowcopy
    _init_global_context(CLIARGS_ORIG)
    assert cliargs_deferred_get(key, default=default, shallowcopy=False) == default

    # test not being set, no default, shallowcopy
    _init_global_context(CLIARGS_ORIG)
    assert cliargs_deferred_get(key, default=default, shallowcopy=True) == default

    # test being set, no default, no shallowcopy
    _init_global_context(CLIARGS_ORIG)
    CLIARGS[key] = value
    assert cl

# Generated at 2022-06-10 23:02:32.803734
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _make_default():
        return [{'foo': {'bar': 'baz'}}]

    # Deferred global context
    global CLIARGS
    CLIARGS = CLIArgs({})
    deferred_get = cliargs_deferred_get('foo', default=_make_default)
    assert isinstance(deferred_get, type(cliargs_deferred_get))
    assert isinstance(deferred_get(), list)
    assert deferred_get() == [{'foo': {'bar': 'baz'}}]

    # Global context set
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert deferred_get() == 'bar'

    # Shallow copy
    CLIARGS = CLIArgs({'foo': 'bar'})

# Generated at 2022-06-10 23:02:42.450205
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the function ``cliargs_deferred_get``"""
    cliargs = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'foobar': {'one': 1, 'two': 2}})
    global CLIARGS

    # Make sure function returns the right value with no change to the underlying object
    CLIARGS = cliargs
    for key, value in CLIARGS.items():
        assert cliargs_deferred_get(key)() is value

    # Make sure the copy functionality works
    CLIARGS = cliargs
    for key, value in CLIARGS.items():
        assert cliargs_deferred_get(key, shallowcopy=True)() == value

# Generated at 2022-06-10 23:02:50.480524
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    from unittest import TestCase

    class ContextTest(TestCase):
        def setUp(self):
            self.orig_cliargs = CLIARGS
            CLIARGS = CLIArgs({})

        def tearDown(self):
            CLIARGS = self.orig_cliargs

        def test_get_nonexistant(self):
            value = cliargs_deferred_get('foo', 'value_not_found')()
            self.assertEqual(value, 'value_not_found')

        def test_get_not_shallow(self):
            CLIARGS._cliargs['foo'] = 'bar'
            value = cliargs_deferred_get('foo')([])

# Generated at 2022-06-10 23:02:57.448902
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    value = 'foo'
    key = 'bar'
    CLIARGS = CLIArgs({key: value})
    assert value == cliargs_deferred_get(key)()
    assert value == cliargs_deferred_get(key, default='baz')()
    assert 'baz' == cliargs_deferred_get(key, default='baz', shallowcopy=True)()

# Generated at 2022-06-10 23:03:05.582558
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    cliargs = GlobalCLIArgs({'test': set(['foo'])})
    assert cliargs.get('test', default=None) == cliargs['test']

    get_default = cliargs_deferred_get('test', default='bar')
    assert get_default() == set(['foo'])

    get_default = cliargs_deferred_get('nonexistent', default='bar')
    assert get_default() == 'bar'
    assert get_default() is not cliargs['nonexistent']

    get_default = cliargs_deferred_get('test', shallowcopy=True)
    get_default_value = get_default()
    assert get_default_value is not get_default()
    assert get_default_

# Generated at 2022-06-10 23:03:08.035726
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''
    simple unit test for cliargs_deferred_get
    '''
    cliargs_deferred_get('foo')()

# Generated at 2022-06-10 23:03:17.828069
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get

    This function uses the same namespace as the function above so the function being tested
    must be imported globally.
    """
    global cliargs_deferred_get
    from ansible.utils.context_objects import GlobalCLIArgs

    class TestCLIArgs(GlobalCLIArgs):
        """A GlobalCLIArgs subclass with a __contains__ method"""
        def __contains__(self, key):
            return key in self._attrs

    test_args = {'test_arg': 'test',
                 'test_arg_default': 'default',
                 'test_arg_mapping': {'one': 1},
                 'test_arg_copy': ['one', 'two']}

    test_obj = TestCLIArgs(test_args)
    assert cliargs

# Generated at 2022-06-10 23:03:28.449386
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    class TestClass(object):
        # Simulate a class that's already been created and has a property set before
        # the CLI arguments are parsed
        def __init__(self, value):
            self._value = value

        @property
        def value(self):
            return cliargs_deferred_get('value')(self) or self._value

    val = {'a': 1, 'b': 2}
    val2 = {'a': 1, 'b': 2}
    tcp_listen = ['127.0.0.1', '::1']

    # Case 1
    global CLIARGS
    _init_global_context({})
    cli_args = CLIARGS.copy()
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options(cli_args)

   

# Generated at 2022-06-10 23:03:39.435250
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from copy import deepcopy

    data = {'abc': ['a', 'b'], 'def': {'a': 1}, 'ghi': {'a': 1}, 'jkl': ['a', 'b', {'1': '2'}]}

    # First we test that we get back the data as passed with no shallowcopy and no default
    for key, value in data.items():
        assert cliargs_deferred_get(key)() == value

    # Now we test that we get back the data as passed with no shallowcopy and the default
    for key, value in data.items():
        assert cliargs_deferred_get(key, default=None)() == value

    # Now we test that we get back the default with no shallowcopy and with no default
   

# Generated at 2022-06-10 23:03:49.665116
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy

    class A(dict):
        """Dummy dict class"""

    dict_a = A({'a': 1, 'b': 2})
    set_a = {3,4,5}
    list_a = [1,2,3]
    cli_args = {
        'list': dict_a,
        'set': set_a,
        'list': list_a,
        'valid': 'valid',
        'dict': {'a': 1, 'b': 2},
        }
    _init_global_context(cli_args)
    assert cliargs_deferred_get('valid') == 'valid'
    assert set(cliargs_deferred_get('dict')) == {'a', 'b'}
    assert not id(cliargs_deferred_get('dict')) == id

# Generated at 2022-06-10 23:03:58.425487
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pragma: no cover
    from ansible.utils.context_objects import CliArgs
    cliargs = CliArgs({'foo': 'bar'})
    cliargs.foo = cliargs_deferred_get('foo')
    assert cliargs.foo == cliargs_deferred_get('foo')()
    assert 'foo' in cliargs.keys()

    cliargs = CliArgs({'foo': 'bar'})
    cliargs.list_ = cliargs_deferred_get('list_', default=[], shallowcopy=True)
    assert cliargs.list_ == cliargs_deferred_get('list_', default=[], shallowcopy=True)()
    cliargs.list_.append('baz')
    assert cliargs.list_ == ['baz']
    assert cl

# Generated at 2022-06-10 23:04:10.033583
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    global CLIARGS
    CLIARGS._data = {'foo': [1, 2, 3], 'bar': 'baz', 'qux': {'quux': 'quuz'}}
    inner = cliargs_deferred_get('foo')
    assert inner() == [1, 2, 3]
    assert inner() is not CLIARGS._data['foo']
    inner = cliargs_deferred_get('bar')
    assert inner() == 'baz'
    assert inner() is not CLIARGS._data['bar']
    inner = cliargs_deferred_get('qux')
    assert inner() == {'quux': 'quuz'}
    assert inner() is not CLIARGS._data['qux']
    CLIARGS._data['foo'].pop()
    inner = cli

# Generated at 2022-06-10 23:04:22.277387
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from .context_objects.cli_args import CliArgs as TestCliArgs
    from .context_objects.field_attribute import FieldAttribute

    # Deferred get with get from CLIARGS
    cliargs = TestCliArgs({'abc': '123'})
    attr = FieldAttribute(cliargs=cliargs)
    attr.extend_default_value(cliargs_deferred_get('abc', default='not here'))
    assert attr.default_value == '123'

    cliargs = TestCliArgs()
    attr = FieldAttribute(cliargs=cliargs)
    attr.extend_default_value(cliargs_deferred_get('abc', default='not here'))
    assert attr.default_value == 'not here'


# Generated at 2022-06-10 23:04:28.712764
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS._options = {'a': '1', 'b': '2'}
    CLONE_TEST = cliargs_deferred_get('a', default='3')
    assert CLONE_TEST() == '1'
    CLONE_TEST = cliargs_deferred_get('b', shallowcopy=True)
    # The type of what's returned is not strictly specified so the assert
    # is for equality only
    assert CLONE_TEST() == '2'
    assert CLIARGS.b == '2'
    EXCLONE_TEST = cliargs_deferred_get('c', default='4', shallowcopy=True)
    assert EXCLONE_TEST() == '4'

    CLIARGS._options = {'a': [1], 'b': [2]}
    CLONE_T

# Generated at 2022-06-10 23:04:35.589960
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo')() is None
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    CLIARGS = CLIARGS.copy()
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS['foo'] = [1, 2, 3]
    assert cliargs_deferred_get('foo')() == [1, 2, 3]

# Generated at 2022-06-10 23:04:40.955256
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['testval'] = 'myval'
    value = cliargs_deferred_get('testval')()
    assert(value == 'myval')
    assert(isinstance(value, str))

    CLIARGS['testval'] = ['myval']
    value = cliargs_deferred_get('testval', shallowcopy=True)()
    assert(value == ['myval'])
    assert(isinstance(value, list))
    assert(value is not CLIARGS['testval'])

# Generated at 2022-06-10 23:04:52.165174
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def mock_init_global_context(cli_args):
        global CLIARGS
        CLIARGS = CLIArgs(cli_args)

    def check_value(key, expected_value, shallowcopy):
        actual = cliargs_deferred_get(key, shallowcopy=shallowcopy)()
        assert actual == expected_value
        if shallowcopy:
            # Make sure it's a copy
            assert actual is not expected_value

    orig_global_context_init = __builtins__['_init_global_context']
    __builtins__['_init_global_context'] = mock_init_global_context


# Generated at 2022-06-10 23:04:59.179436
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.context_objects import get_test_singleton
    cliargs = get_test_singleton()
    cliargs.update({'foo': {'bar': 'baz'}, 'listy': [1, 2, 3], 'setty': set([1, 2, 3])})

    # Test simple get
    assert cliargs_deferred_get('foo') == {'bar': 'baz'}
    assert cliargs_deferred_get('foo', shallowcopy=True) == {'bar': 'baz'}

    # Test getting a key that doesn't exist
    assert cliargs_deferred_get('no_existy') is None

    # Test getting a key that doesn't exist with a default

# Generated at 2022-06-10 23:05:13.509223
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import io
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', '--user')
    parser.add_argument('-k', '--keywords')
    parser.add_argument('-l', '--list')
    parser.add_argument('-s', '--set')
    parser.add_argument('-d', '--dictionary')
    parser.add_argument('-c', '--config')

# Generated at 2022-06-10 23:05:25.277752
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'key': 'value'})
    assert cliargs_deferred_get('key')() == 'value'
    # test the default
    assert cliargs_deferred_get('notakey', default="DEFAULT")() == 'DEFAULT'
    # test that we make a shallow copy
    _init_global_context({'key': [1, 2, 3]})
    list1 = cliargs_deferred_get('key', shallowcopy=True)()
    list2 = cliargs_deferred_get('key', shallowcopy=True)()
    assert list1 == [1, 2, 3]
    assert list2 == [1, 2, 3]
    list1.append(4)
    assert list1 == [1, 2, 3, 4]

# Generated at 2022-06-10 23:05:36.862252
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from unittest import TestCase
    from ansible.module_utils.common.context_objects import CLIArgs
    test_case = TestCase()
    # Value is not in CLIARGS
    deferred_get = cliargs_deferred_get("test")
    test_case.assertEqual(None, deferred_get())
    # Value is in CLIARGS but is not a list/dict/set/sequence
    cliargs = CLIArgs()
    cliargs.update({"test": 1})
    global CLIARGS
    old_cliargs = CLIARGS
    CLIARGS = cliargs
    test_case.assertEqual(1, deferred_get())
    # Value is in CLIARGS and is a list/dict/set/sequence
    cliargs = CLIArgs()

# Generated at 2022-06-10 23:05:45.161854
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def bar():
        if 'bar' not in CLIARGS:
            CLIARGS['bar'] = 1
        return CLIARGS['bar']
    cliargs_bar = cliargs_deferred_get('bar')
    cliargs_bar1 = cliargs_deferred_get('bar', default=1)
    cliargs_bar2 = cliargs_deferred_get('bar', default=2)
    cliargs_baz = cliargs_deferred_get('baz', default=[1])
    # Note: we are just testing that the closures work, there isn't any need to
    # reinstantiate the closure for each test
    assert id(cliargs_bar) == id(cliargs_bar1) == id(cliargs_bar2)

# Generated at 2022-06-10 23:05:55.264075
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the results of calling cliargs_deferred_get with different get
    # defaults
    global CLIARGS
    _init_global_context(dict())
    cliargs_value_get_default = cliargs_deferred_get('foo')
    assert callable(cliargs_value_get_default)
    cliargs_value_get_default_value = cliargs_value_get_default()
    assert cliargs_value_get_default_value is None

    cliargs_value_get_default_value = cliargs_deferred_get('foo', default='bar')()
    assert cliargs_value_get_default_value == 'bar'

# Generated at 2022-06-10 23:06:05.046831
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    _init_global_context({'_ansible_version': '1.0'})

    dummy_cls = type('dummy_cls', (object,), {})
    obj = dummy_cls()
    obj.ansible_version = cliargs_deferred_get('_ansible_version')
    assert obj.ansible_version == '1.0'

    CLIARGS = CLIArgs({})

    CLIARGS = CLIArgs({'_ansible_version': '1.1'})
    assert obj.ansible_version == '1.1'

    global_cli_args = GlobalCLIArgs.from_options({'_ansible_version': '1.2'})
    CLIARGS = global_cli_args
    assert obj.ansible_version == '1.2'

# Generated at 2022-06-10 23:06:12.991990
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    seqv1 = ["one", "two", "three"]
    setv1 = {"one", "two", "three"}
    dictv1 = {"one": 1, "two": 2, "three": 3}
    seqv2 = ["four", "five", "six"]
    setv2 = {"four", "five", "six"}
    dictv2 = {"four": 4, "five": 5, "six": 6}

    import types
    assert isinstance(cliargs_deferred_get("some_key"), types.FunctionType)
    assert isinstance(cliargs_deferred_get("some_key", default=seqv1), types.FunctionType)
    assert isinstance(cliargs_deferred_get("some_key", default=seqv1, shallowcopy=True), types.FunctionType)

    # check what happens if it

# Generated at 2022-06-10 23:06:23.018314
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': {'bar': 'bam'}}
    _init_global_context(cli_args)
    x = cliargs_deferred_get('foo', default='baz')
    y = x()
    assert y == {'bar': 'bam'}
    y['bar'] = 'bip'
    assert y['bar'] == 'bip'
    assert cli_args['foo']['bar'] == 'bam'
    y = x()
    assert y == {'bar': 'bip'}
    y['bar'] = 'bap'
    assert y['bar'] == 'bap'
    assert cli_args['foo']['bar'] == 'bam'

# Generated at 2022-06-10 23:06:29.270589
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test ``cliargs_deferred_get`` function"""
    _init_global_context(dict(a=1))
    assert CLIARGS.get('a', 1) == cliargs_deferred_get('a', 1)()
    assert CLIARGS.get('a', 5) == cliargs_deferred_get('a', 5)()
    assert 2 == cliargs_deferred_get('b', 2)()
    with CLIARGS.new_context('b', 3):
        assert 3 == cliargs_deferred_get('b', 2)()
    assert 2 == cliargs_deferred_get('b', 2)()

    CLIARGS['c'] = (1, 2, 3)
    assert (1, 2, 3) == cliargs_deferred_get('c')()

# Generated at 2022-06-10 23:06:38.785798
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # The CliArgs object is not a singleton.  GlobalCLIArgs is.  This isn't an issue
    # since changing this object to a singleton (as it currently is in ansible.utils)
    # would be a breaking change.
    # pylint: disable=protected-access
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == [1, 2, 3]

# Generated at 2022-06-10 23:06:52.257624
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get always returns the same first value after it is set"""
    global CLIARGS
    initial_args = {'foo': 'bar'}
    try:
        CLIARGS = CLIArgs(initial_args)
        my_deferred_get = cliargs_deferred_get('foo')
        assert my_deferred_get() == 'bar'
        CLIARGS.update(foo='notbar')
        assert my_deferred_get() == 'bar'
    finally:
        CLIARGS = CLIArgs({})

# Generated at 2022-06-10 23:07:03.026725
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    global CLIARGS
    CLIARGS = CLIArgs(dict(var1=True, var2=dict(subvar1=2), var3=set([2, 3, 4])))

    # Test simple value
    assert cliargs_deferred_get('var1') is True

    # Test default
    assert cliargs_deferred_get('var-does-not-exist', default='foobar') == 'foobar'

    # Test shallow copy
    shallow_test1 = [1, 2, 3]
    assert cliargs_deferred_get('var1', shallowcopy=True) is True
    assert cliargs_deferred_get('var2', shallowcopy=True)['subvar1'] == 2

# Generated at 2022-06-10 23:07:09.869221
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from copy import deepcopy

    # Test default functionality
    CLIARGS.data = {'a': 1, 'b': [1, 2, 3], 'c': {'d': 5, 'e': 6}, 'f': {1, 2, 3}}
    assert cliargs_deferred_get('a')() == CLIARGS['a']
    assert cliargs_deferred_get('a', default=10)() == CLIARGS['a']
    assert cliargs_deferred_get('g', default=10)() == 10
    assert cliargs_deferred_get('b')() == CLIARGS['b']
    assert cliargs_deferred_get('c')() == CLIARGS['c']
    assert cliargs_deferred_get('f')() == CLIARGS['f']

    # Test

# Generated at 2022-06-10 23:07:19.616850
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict

    @pytest.fixture
    def cliargs():
        # Global CLIARGS is created in the common.removed_module_utils
        # Properly restore it after we are done with the unit test
        global CLIARGS
        orig_CLIARGS = CLIARGS
        try:
            CLIARGS = CLIArgs({"a": 42})
            yield CLIARGS
        finally:
            CLIARGS = orig_CLIARGS

    def test_get(cliargs):
        get_key = cliargs_deferred_get("a")
        assert get_key() == 42

    def test_get_default(cliargs):
        get_key = cliargs_deferred_get("b")
        assert get

# Generated at 2022-06-10 23:07:30.644345
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Nothing set test
    assert cliargs_deferred_get('NOSUCHKEY')() is None
    assert cliargs_deferred_get('NOSUCHKEY', default=None)() is None
    assert cliargs_deferred_get('NOSUCHKEY', default=1)() == 1
    # Set the key to a sequence and a scalar
    CLIARGS.update(dict(
        SOMEKEY=range(5),
        SOMESCALAR='banana',
    ))
    # The key was set so we get the value
    assert cliargs_deferred_get('SOMEKEY')() == list(range(5))
    assert cliargs_deferred_get('SOMEKEY', default=None)() == list(range(5))

# Generated at 2022-06-10 23:07:40.584083
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def init_context(arg_dict):
        """Initialize the global context for testing"""
        # Initialize CLIARGS to a non-global version
        global CLIARGS
        CLIARGS = CLIArgs(arg_dict)

    init_context({'a': 'A', 'b': [1, 2, 3], 'c': {'a': 'b'}, 'd': True, 'e': set([1, 2, 3])})
    assert cliargs_deferred_get('a')() == 'A'
    assert cliargs_deferred_get('a', 'B')() == 'A'
    assert cliargs_deferred_get('b')() == [1, 2, 3]

# Generated at 2022-06-10 23:07:50.040340
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs

    cli = {'foo': 'bar', 'baz': ['qux']}
    CLIARGS = GlobalCLIArgs.from_options(cli)
    value = cliargs_deferred_get('foo')()
    assert value == 'bar'

    value = cliargs_deferred_get('baz')()
    assert value == ['qux']

    # shallow copy should be the same value
    assert CLIARGS['baz'] is value

    value = cliargs_deferred_get('baz', shallowcopy=True)()
    assert CLIARGS['baz'] == value
    assert CLIARGS['baz'] is not value

# Generated at 2022-06-10 23:07:59.064514
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Check no key
    cli_args = {
        'foo': 'bar',
        'baz': 'quux',
    }
    _init_global_context(cli_args)
    assert cliargs_deferred_get('fake') is None
    assert cliargs_deferred_get('fake', 'fake') == 'fake'

    # Check key with no shallowcopy
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('baz') == 'quux'

    # Check key with shallow copy and list
    cli_args['quux'] = ['quuux']
    assert cliargs_deferred_get('quux') == ['quuux']

# Generated at 2022-06-10 23:08:11.024661
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'become': True, 'tags': {'foo', 'bar'}, 'skip_tags': ('baz', 'boo')})
    assert cliargs_deferred_get('become') == True
    assert cliargs_deferred_get('tags') == {'bar', 'foo'}
    assert cliargs_deferred_get('tags', shallowcopy=True) == {'bar', 'foo'}
    assert cliargs_deferred_get('skip_tags') == ('baz', 'boo')
    assert cliargs_deferred_get('skip_tags', shallowcopy=True) == ('baz', 'boo')
    assert cliargs_deferred_get('start_at_task', 'all') == 'all'
    assert cliargs

# Generated at 2022-06-10 23:08:20.988686
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.dict_transformations import _union_dict
    from ansible.module_utils.common.text.common import TextCommon, THREAD_NAME_TEMPLATE

    # Create a new context and initialize with some dummy values

# Generated at 2022-06-10 23:08:35.261318
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    def inner():
        # pylint: disable=redefined-outer-name
        return CLIARGS.get('test_key', default=test_default)

    CLIARGS['test_key'] = 'test_value'
    test_default = 'not_test_value'
    assert inner() == 'test_value'

    CLIARGS['test_key'] = None
    del CLIARGS['test_key']
    assert inner() == 'not_test_value'

    global CLIARGS
    CLIARGS = CLIArgs({'test_key': 'test_value'})
    assert inner() == 'test_value'

    CLIARGS = CLIArgs({'test_key': None})
    del CLIARGS['test_key']

# Generated at 2022-06-10 23:08:45.727361
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Init a simple set of cli args
    _init_global_context({'foo': 'bar'})
    # Make sure that attempting to get a key that does not exist returns the default
    assert cliargs_deferred_get('baz')(), 'Baz'
    assert cliargs_deferred_get('baz', default='baz')(), 'baz'
    assert cliargs_deferred_get('baz', default={'foo': 'bar'})() == {'foo': 'bar'}
    # And that it returns the key's value when it does exist
    assert cliargs_deferred_get('foo')(), 'bar'
    # And that it properly copies the value

# Generated at 2022-06-10 23:08:53.358053
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    >>> arg = {'george': 'carlin'}

    >>> CLIARGS = CLIArgs(arg)

    >>> obj1 = cliargs_deferred_get('george')
    >>> assert obj1() == 'carlin'
    >>> assert arg is not obj1()

    >>> obj2 = cliargs_deferred_get('george', shallowcopy=True)
    >>> assert obj2() == 'carlin'
    >>> assert arg is not obj2()
    """

# Generated at 2022-06-10 23:09:01.378088
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    base_args = dict(arg1='1')
    global CLIARGS
    def _set_cli_args(args):
        global CLIARGS
        CLIARGS = CLIArgs(args)

    def_value = cliargs_deferred_get('arg2', default='2')
    assert callable(def_value)

    _set_cli_args(base_args)
    value = def_value()
    assert value == '2'

    base_args['arg2'] = '2'
    _set_cli_args(base_args)
    value = def_value()
    assert value == '2'

    base_args['arg2'] = 2
    _set_cli_args(base_args)
    value = def_value()
    assert value == 2


# Generated at 2022-06-10 23:09:09.054258
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert cliargs_deferred_get('--foo') is None
    CLIARGS = CLIArgs(dict(foo=42))
    assert 42 == cliargs_deferred_get('--foo')()
    CLIARGS = CLIArgs(dict(foo=None))
    assert None is cliargs_deferred_get('--foo')()
    CLIARGS = CLIArgs(dict(foo=42), dict(foo=43))
    assert 43 == cliargs_deferred_get('--foo')()

# Generated at 2022-06-10 23:09:17.979739
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test default
    global CLIARGS
    cli_args = CLIArgs({})
    cli_args.keys()
    assert cli_args.keys() == []
    _init_global_context(cli_args)
    f = cliargs_deferred_get('foo')
    assert f() is None
    assert cli_args.keys() == []

    # Test that key is added
    cli_args = CLIArgs({})
    cli_args['foo'] = 'bar'
    _init_global_context(cli_args)
    f = cliargs_deferred_get('foo')
    assert f() == 'bar'
    assert cli_args.keys() == []

    # Test that the key is not added if it is already present
    cli_args = CLIArgs({})
    cl

# Generated at 2022-06-10 23:09:28.447994
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(a='a', b='b'))
    assert cliargs_deferred_get('a')() == 'a'
    assert cliargs_deferred_get('a')(shallowcopy=True) == 'a'
    assert cliargs_deferred_get('b')() == 'b'
    assert cliargs_deferred_get('b')(shallowcopy=True) == 'b'

    # Test that it returns the default
    assert cliargs_deferred_get('c')(default='c') == 'c'
    assert cliargs_deferred_get('c')(default='c', shallowcopy=True) == 'c'

    # Test that it returns the default when copy is requested
    CLIARGS = CLIArgs()
    assert cl

# Generated at 2022-06-10 23:09:39.759974
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({'foo': [1, 2, 3], 'bar': {'foo': 'bar'}, 'fooset': set((1, 2, 3))})
    # non-shallow copy
    assert cliargs_deferred_get('nonexistent')() is None
    assert cliargs_deferred_get('nonexistent', default='bar')() == 'bar'
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    assert cliargs_deferred_get('bar')() == {'foo': 'bar'}
    assert cliargs_deferred_get('fooset')() == set((1, 2, 3))
    # shallow copy
    assert cliargs_deferred_get('nonexistent', shallowcopy=True)() is None
   

# Generated at 2022-06-10 23:09:48.540932
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    class FakeCLIArgs(object):
        def get(self, key, default=None):
            return getattr(self, key)

    # Create new, non-singleton, instance of GlobalCLIArgs
    cli_args = FakeCLIArgs()

    #Test no value with default
    cli_args.foo = None
    assert cliargs_deferred_get('foo')() == None

    #Test no value with explicit default
    cli_args.foo = None
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'

    #Test with value
    cli_args.foo = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    #Test with value and explicit default

# Generated at 2022-06-10 23:10:00.767304
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Simple unit test on cliargs_deferred_get function
    """
    cli_args = {
        'foo': 'bar',
        'baz': [2, 3],
        'qux': (1, 2, 3),
    }
    # create a closure that holds the key to extract
    cliargs_get_foo = cliargs_deferred_get('foo')
    # create a closure that holds the key to extract and does a shallow copy
    cliargs_get_baz = cliargs_deferred_get('baz', shallowcopy=True)
    _init_global_context(cli_args)
    # test the closure over the dictionary, this should be 'bar'
    assert cliargs_get_foo() == 'bar'
    # test the closure over the list, this should be [

# Generated at 2022-06-10 23:10:20.677264
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup CliArgs, our own which we can reset and CLIARGS which we can replace
    our_cliargs = CLIArgs({})
    global CLIARGS
    original_cliargs = CLIARGS
    CLIARGS = our_cliargs

    # Test deferring a key not in cli_args
    getter = cliargs_deferred_get('foo', default='five')
    assert getter() == 'five'
    our_cliargs['foo'] = 'bar'
    assert getter() == 'bar'

    # Test shallow copy
    our_cliargs['bar'] = [1, 2, 3]
    getter = cliargs_deferred_get('bar', shallowcopy=True)
    assert getter() == [1, 2, 3]
    getter()[1] = 9
    assert getter()

# Generated at 2022-06-10 23:10:31.559066
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Try with a primitive value
    CLIARGS._options['foo'] = False
    assert not cliargs_deferred_get('foo')()
    # Try with a list
    CLIARGS._options['foo'] = ['a', 'b', 'c']
    foo_copy = cliargs_deferred_get('foo', shallowcopy=True)
    assert isinstance(foo_copy, type(lambda: 0))
    assert foo_copy() == ['a', 'b', 'c']
    # Change the value and make sure we get a new copy
    CLIARGS._options['foo'] = ['x', 'y', 'z']
    assert foo_copy() == ['a', 'b', 'c']
    # Try with a mapping

# Generated at 2022-06-10 23:10:39.557980
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test simple getting
    _init_global_context({'key': 42})
    assert cliargs_deferred_get('key', default=None)() == 42
    assert cliargs_deferred_get('badkey', default=None)() is None
    assert cliargs_deferred_get('badkey', default=10)() == 10

    # Test with CLIARGS replaced
    new_cliargs = CLIArgs({'key': 42})
    global CLIARGS
    CLIARGS = new_cliargs
    assert cliargs_deferred_get('key', default=None)() == 42
    assert cliargs_deferred_get('badkey', default=None)() is None
    assert cliargs_deferred_get('badkey', default=10)() == 10

    # Test with shallow copy
    _

# Generated at 2022-06-10 23:10:50.826650
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Ensure we don't accidentally modify global config
    global CLIARGS
    orig_CLIARGS = CLIARGS

    # Test the inner function
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('buzz', default='baz')() == 'baz'
    assert not 'buzz' in CLIARGS
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'baz'

    # Test the rest
    del CLIARGS

# Generated at 2022-06-10 23:10:56.424746
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test closure with no default/shallow copy
    a = cliargs_deferred_get('a')
    assert a() == None

    # Test closure with shallowcopy
    b = cliargs_deferred_get('b', shallowcopy=True)
    assert b() == []

    # Test closure with both default and shallow copy
    c = cliargs_deferred_get('c', default=['c'], shallowcopy=True)
    assert c() == ['c']

    # Test closure with both default and shallow copy on a set
    d = cliargs_deferred_get('d', default=set(['D']), shallowcopy=True)
    assert d() == set(['D'])

    # Test closure with both default and shallow copy on a Mapping

# Generated at 2022-06-10 23:11:05.173180
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check_function(key, test_value, default, shallowcopy=False):
        """Check behavior of cliargs_deferred_get"""
        cliargs = CLIArgs({'test_key': test_value})
        global CLIARGS
        CLIARGS = cliargs

        getter = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)

        assert getter() is test_value

    # Test shallow copy for list
    test_list = [1, 2, 3]
    check_function('test_key', test_list, [], shallowcopy=True)
    test_list.append(4)
    assert getter() == [1, 2, 3]

    # Test shallow copy for set
    test_set = {1, 2, 3}

# Generated at 2022-06-10 23:11:16.098797
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(
        foo='bar',
        frob=['baz', 'glee', 'zoom'],
        frab={'a': 1, 'b': 2},
    ))
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('frob')() == ['baz', 'glee', 'zoom']
    assert cliargs_deferred_get('frab')() == {'a': 1, 'b': 2}

    frobshallow = cliargs_deferred_get('frob', shallowcopy=True)
    assert frobshallow() == ['baz', 'glee', 'zoom']
    assert frobshallow() is not CLIARGS['frob']

    # Check that we get the default

# Generated at 2022-06-10 23:11:21.963592
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''
    Test function for cliargs_deferred_get
    '''
    global CLIARGS
    CLIARGS = CLIArgs(None, {'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('bar', 'baz')() == 'baz'

# Generated at 2022-06-10 23:11:29.776746
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Unit test for function cliargs_deferred_get
    import pytest
    from ansible.utils.context_objects import CliArgs

    newcliargs = CliArgs({'foo': 'bar'})

    CLIARGS = newcliargs

    default = cliargs_deferred_get('bar', default='baz')
    assert default() == 'baz'
    assert default.__default__ == 'baz'

    default = cliargs_deferred_get('bar', default=lambda: 'baz')
    assert default() == 'baz'
    assert default.__default__() == 'baz'

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

    assert cliargs

# Generated at 2022-06-10 23:11:38.869797
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-argument
    def _argv(**kwargs):
        """Create a CliArgs instance to test with"""
        return GlobalCLIArgs.from_options(kwargs)

    # Check that the closure has access to the current CLIArgs
    inner = cliargs_deferred_get("foo", 10)
    assert inner() == 10

    # Check that shallow copy works
    cliargs = _argv(foo=['good'])
    inner = cliargs_deferred_get("foo", 10, shallowcopy=True)
    assert inner() == ['good']
    inner()[0] = 'bad'
    assert cliargs.get("foo")[0] == 'good'

    # Test with a regular mapping