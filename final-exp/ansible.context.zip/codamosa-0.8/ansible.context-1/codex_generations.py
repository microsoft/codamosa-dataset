

# Generated at 2022-06-10 23:02:03.863178
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    original_cliargs = CLIARGS
    args = GlobalCLIArgs({
        'foo': 'bar',
        'baz': 'quux',
    })
    CLIARGS = args
    assert 'bar' == cliargs_deferred_get('foo')()
    assert 'default' == cliargs_deferred_get('not_a_key', 'default')()
    assert args.get('foo') is cliargs_deferred_get('foo')()
    CLIARGS = original_cliargs

# Generated at 2022-06-10 23:02:12.241854
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    import copy
    import operator

    # Test with CLIARGS being a dict
    CLIARGS = {}
    assert operator.eq(cliargs_deferred_get('test1')(), None)
    assert operator.eq(cliargs_deferred_get('test2', 'blah')(), 'blah')
    assert operator.eq(cliargs_deferred_get('test3', default='bleh')(), 'bleh')
    assert cliargs_deferred_get('test4', default='bleh')() is not cliargs_deferred_get('test4', default='bleh')()
    assert operator.eq(cliargs_deferred_get('test4', default='bleh')(), 'bleh')
    assert 'test5' not in CLIARGS

# Generated at 2022-06-10 23:02:23.511975
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = {'bar': 'foo', 'baz': 'qux'}
    _init_global_context(cliargs)
    assert cliargs_deferred_get('bar')() == 'foo'
    assert cliargs_deferred_get('baz')() == 'qux'
    assert cliargs_deferred_get('key', default='value')() == 'value'
    assert cliargs_deferred_get('key', default='value')() == 'value'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == 'qux'
    # make sure shallowcopies are different
    shallow_baz = cliargs_deferred_get('baz', shallowcopy=True)()
    shallow_baz.append(True)
    assert cliargs_def

# Generated at 2022-06-10 23:02:28.257775
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(key='foo', default=1)() == 1
    CLIARGS = CLIArgs({'foo': 2})
    assert cliargs_deferred_get(key='foo', default=1)() == 2

# vim: set expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-10 23:02:35.505813
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test_key': 'test value',
                       'test_key2': 'test value2',
                       'test_key3': [1, 2, 3],
                       'test_key4': ({'key': 'value'}, {'key2': 'value2'})})
    cliargs_deferred_get('test_key', 'default value')() == 'test_value'
    cliargs_deferred_get('test_key', 'default value', True)() == 'test_value'
    cliargs_deferred_get('test_key2', 'default value')() == 'test_value2'
    cliargs_deferred_get('test_key2', 'default value', True)() == 'test_value2'
    cliargs_deferred_

# Generated at 2022-06-10 23:02:46.169977
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    _init_global_context()  # This should not exist in the rest of the code base.
                            # This is meant to test this function and the PlayContext only
    # Check that the function returns the default when the key isn't set
    assert cliargs_deferred_get('somekey', default='default value')() == 'default value'
    # Check that the function returns a shallow copy of the CLIARGS when the key is set
    CLIARGS['somekey'] = 'value from CLIARGS'
    assert cliargs_deferred_get('somekey', default='default value')() == 'value from CLIARGS'
    # Check that the

# Generated at 2022-06-10 23:02:59.468883
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test normal get operations"""
    CLIARGS._update({'a': {'b': {'c': 5}}})
    assert cliargs_deferred_get('a')() == {'b': {'c': 5}}
    assert cliargs_deferred_get('a') is not cliargs_deferred_get('a')()
    assert cliargs_deferred_get('a', shallowcopy=True) is cliargs_deferred_get('a', shallowcopy=True)()
    assert cliargs_deferred_get('a', shallowcopy=True) is not cliargs_deferred_get('a')()
    assert cliargs_deferred_get('a')() == cliargs_deferred_get('a', shallowcopy=True)()


# Generated at 2022-06-10 23:03:06.136294
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from itertools import chain
    from collections import Mapping, Set, Sequence, Sized

    # Test a default value for defaults
    default_value = 42
    default_get = cliargs_deferred_get('key', default=default_value)
    assert default_value == default_get()

    # Test arguments that do not copy
    for value in (42, 'string', u'unicode', lambda: 42, frozenset(), set(), (1, 2), [1, 2],
                  {'x': 42, 'y': 'z'}, {'x': {'y': 42}}):
        # Test defaults
        get = cliargs_deferred_get('key', value)
        result = get()
        assert value == result
        # Test non-defaults
        _init_global_context(dict(key=value))

# Generated at 2022-06-10 23:03:16.694793
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.ansible_playbook_python = '/usr/local/bin/python'
    assert cliargs_deferred_get('ansible_playbook_python')() == '/usr/local/bin/python'
    assert cliargs_deferred_get('ansible_playbook_python', default='foo')() == '/usr/local/bin/python'

    assert cliargs_deferred_get('invalid_key', default='foo')() == 'foo'
    CLIARGS.invalid_key = 'foo'
    assert cliargs_deferred_get('invalid_key', default='bar')() == 'foo'

    # Test that we haven't accidentally returned a reference to the value
    CLIARGS.ansible_playbook_python = '/bin/python'
    assert cliargs_deferred_get

# Generated at 2022-06-10 23:03:27.130632
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    _init_global_context(ImmutableDict(foo='bar', num=42, seq=[1, 2, 3]))
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('num')() == 42
    assert cliargs_deferred_get('seq')() == [1, 2, 3]
    seq_copy = cliargs_deferred_get('seq', shallowcopy=True)()
    assert seq_copy == [1, 2, 3]
    seq_copy[0] = 99
    assert seq_copy != [1, 2, 3]
    assert cl

# Generated at 2022-06-10 23:03:40.620625
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''Test that the closure works as expected'''
    CLIARGS = CLIArgs({'simple': 'foo'})
    assert cliargs_deferred_get('simple')() == 'foo'
    assert cliargs_deferred_get('nonexistent', default='bar')() == 'bar'

    CLIARGS = CLIArgs({'shallowcopy': [30]})
    assert cliargs_deferred_get('shallowcopy', shallowcopy=True)() == [30]
    assert cliargs_deferred_get('shallowcopy', shallowcopy=False)() == [30]

    CLIARGS = CLIArgs({'copy': {'foo': 'bar'}})
    assert cliargs_deferred_get('copy', shallowcopy=True)() == {'foo': 'bar'}
    assert cliargs_

# Generated at 2022-06-10 23:03:53.252948
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Basic functionality
    CLIARGS.register_cli_args({'foo': 'foo_value'})
    assert cliargs_deferred_get('foo')() == 'foo_value'
    assert cliargs_deferred_get('foo', default='default')() == 'foo_value'
    assert cliargs_deferred_get('bar', default='bar_value')() == 'bar_value'

    # No shallow copy if default is false
    CLIARGS.register_cli_args({'bar': ('bar_value',)})
    assert cliargs_deferred_get('bar')() == ('bar_value',)
    assert cliargs_deferred_get('bar', default=('default',))() == ('bar_value',)
    assert cliargs_deferred_get('bar', shallowcopy=True)

# Generated at 2022-06-10 23:04:05.801456
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cli_args = {
        'foo': 'bar',
        'baz': [1,2,3],
        'bat': {'some': 'thing'},
        'boo': set([1,2,3])
    }
    _init_global_context(cli_args)
    for key, value in cli_args.items():
        get_value = cliargs_deferred_get(key, shallowcopy=True)
        assert get_value() is value
        if is_sequence(value) or isinstance(type(value), Mapping):
            assert get_value() is not value

# Generated at 2022-06-10 23:04:16.190676
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def cliargs_get(key, default=None):
        return CLIARGS.get(key, default=default)

    # Normal usage
    cli_args = {'foo': 'bar', 'baz': 1}
    _init_global_context(cli_args)
    assert cliargs_get('foo') == 'bar'
    assert cliargs_get('foo') == cliargs_deferred_get('foo')()
    # Default value
    assert cliargs_get('boo', default='boo') == 'boo'
    assert cliargs_get('boo') is None
    assert cliargs_deferred_get('boo', default='boo')() == 'boo'
    assert cliargs_deferred_get('boo')() is None
    # shallowcopy=True


# Generated at 2022-06-10 23:04:26.064774
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    from ansible.utils.context_objects import LocalCLIArgs

    test_args = {'foo': 'bar', 'spam': ['eggs', 'eggs2']}
    cliargs_obj = LocalCLIArgs(test_args)

    def cliargs_deferred_get(key, default=None, shallowcopy=False):
        def inner():
            value = cliargs_obj.get(key, default=default)
            if not shallowcopy:
                return value
            elif is_sequence(value):
                return value[:]
            elif isinstance(value, (Mapping, Set)):
                return value.copy()
            return value
        return inner

    # Test that the closure doesn't evaluate immediately
    x = cliargs_deferred_get('foo')
    x()  #

# Generated at 2022-06-10 23:04:36.897442
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-argument
    def test_func(key, default, shallowcopy):
        return cliargs_deferred_get(key, default, shallowcopy)

    cargs = CLIArgs({'test': 'ansible', 'test2': 'python'})
    cargs.int_value = 5

    new_cls = type('NewCLI', (object,), {'_global_GLOBALCLIARGS': cargs})

    global CLIARGS
    old_cli = CLIARGS
    CLIARGS = None

# Generated at 2022-06-10 23:04:42.898744
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    cli_args = {'foo': [1]}
    _init_global_context(cli_args)
    func = cliargs_deferred_get('foo')
    assert func() == [1]
    cli_args['foo'].append(2)
    assert func() == [1, 2]
    assert cliargs_deferred_get('bar', shallowcopy=True)() is None
    assert cliargs_deferred_get('bar', default=['bar'], shallowcopy=True)() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1]

# Generated at 2022-06-10 23:04:55.114751
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Options():
        def __init__(self, **entries):
            self.__dict__.update(entries)
    o1 = Options(a=1, b=2)
    o2 = Options(b=3)
    o3 = Options(a=[1, 2, 3])
    o4 = Options(a={'k1': 'v1'})
    o5 = Options(a=set([1, 2, 3]))
    CLIARGS = GlobalCLIArgs.from_options(o1)
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('a', default=3)() == 1
    assert cliargs_deferred_get('b')() == 2
    assert cliargs_deferred_get('b', default=3)()

# Generated at 2022-06-10 23:05:06.673833
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make a custom CLIARGS with known values to verify that when CLIARGS is
    # changed, this function updates too
    global CLIARGS
    CLIARGS = CLIArgs({'n': [1, 2], 's': set({1, 2}), 'd': {'foo': 'bar'}})
    # Assert that defaults work
    assert cliargs_deferred_get('x')() is None
    assert cliargs_deferred_get('x', default='foo')() == 'foo'

    # Assert that shallowcopy works
    assert cliargs_deferred_get('n')() is CLIARGS['n']
    assert cliargs_deferred_get('d')() is CLIARGS['d']
    assert cliargs_deferred_get('s')() is CLIARGS['s']


# Generated at 2022-06-10 23:05:16.724384
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from copy import copy, deepcopy
    from six import string_types

    # Test shallow copies for sequences
    CLIARGS['test_key'] = []
    assert cliargs_deferred_get('test_key') is CLIARGS['test_key']
    assert cliargs_deferred_get('test_key', default=[]) is not CLIARGS['test_key']
    assert cliargs_deferred_get('test_key', shallowcopy=True) is not CLIARGS['test_key']
    assert cliargs_deferred_get('test_key', default=[], shallowcopy=True) is not CLIARGS['test_key']

# Generated at 2022-06-10 23:05:40.493748
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    # Run with the real CLIARGS object
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Run with a subset of the CLIARGS object
    local_cliargs = {'foo': 'bar'}
    CLIARGS = CLIArgs(local_cliargs)
    assert cliargs_deferred_get('foo')() == 'bar'

    # Run with an empty object
    local_cliargs = {}
    CLIARGS = CLIArgs(local_cliargs)
    assert cliargs_deferred_get('foo')() is None

    # Check shallowcopy
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLI

# Generated at 2022-06-10 23:05:45.008957
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': {'bar': {'baz': 'baz_value'}}})
    assert cliargs_deferred_get('foo')()['bar']['baz'] == 'baz_value'
    assert cliargs_deferred_get('foo', default='default')()['bar']['baz'] == 'baz_value'
    assert cliargs_deferred_get('bar', default='default')() == 'default'

# Generated at 2022-06-10 23:05:55.132433
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import Dict, List
    # set a value for CLIARGS
    CLIARGS['foo'] = 'bar'
    # set a value for CLIARGS with shallowcopy=True
    CLIARGS['baz'] = List(['foo'])

    # if CLIARGS has a value, then cliargs_deferred_get returns the value
    assert cliargs_deferred_get('foo', default=None)() == 'bar'
    # if CLIARGS has a value, then cliargs_deferred_get returns the value with shallowcopy
    assert cliargs_deferred_get('baz', default=None, shallowcopy=True)() is not CLIARGS['baz']

    # if CLIARGS doesn't have a value, then cliargs_deferred_get

# Generated at 2022-06-10 23:06:04.980243
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'a': 'A', 'b': [1, 2, 3], 'c': {'d': 'D', 'e': [4, 5, 6]}, 'f': (7, 8, 9)})
    cliargs_deferred_get_a = cliargs_deferred_get('a')
    assert cliargs_deferred_get_a() == 'A'

    cliargs_deferred_get_b = cliargs_deferred_get('b')
    assert cliargs_deferred_get_b() == [1, 2, 3]

    cliargs_deferred_get_c = cliargs_deferred_get('c')
    assert cliargs_deferred_get_c() == {'d': 'D', 'e': [4, 5, 6]}

# Generated at 2022-06-10 23:06:12.966301
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test CLIARGS deferred get"""

# Generated at 2022-06-10 23:06:23.695477
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIArgs

    # test with GlobalCLIArgs
    test_cliargs = GlobalCLIArgs({'b': ['-h'], 'args': ['--list-hosts']})
    cliargs_deferred_get(key='args', shallowcopy=True)()
    cliargs_deferred_get(key='args', shallowcopy=True)()
    cliargs_deferred_get(key='b', shallowcopy=True)()
    cliargs_deferred_get(key='b', shallowcopy=True)()

    # test with CLIArgs
    test_cliargs = CLIArgs({'b': ['-h'], 'args': ['--list-hosts']})

# Generated at 2022-06-10 23:06:35.249994
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs
    cliargs = CliArgs({'foo': 'BAR', 'print_ansible_config': False, 'module_path': ['a/b/c']})
    inner = cliargs_deferred_get('foo')

    # Check the inner function works
    assert inner() == 'BAR'

    # Check that the proper default is returned
    inner = cliargs_deferred_get('nonexistant')
    assert inner() is None
    inner = cliargs_deferred_get('nonexistant', 'fake_default')
    assert inner() == 'fake_default'

    # Verify shallow copy works
    inner = cliargs_deferred_get('module_path')
    assert inner() == ['a/b/c']

# Generated at 2022-06-10 23:06:42.846004
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    vals = {
        '1a': '1b',
        '2a': ['2b', '2c'],
        '3a': {'3b': '3c'},
        '4a': set(['4b', '4c']),
        '5a': ['5b', '5c'],
    }
    # no shallow copy
    inner = cliargs_deferred_get('1a')
    # Since we haven't set CLIARGS yet, the default will be returned
    assert inner() == None
    # Set CLIARGS to the passed in values and then run the function
    CLIARGS.update(vals)
    assert inner() == '1b'
    # shallow copy
    inner = cliargs_deferred_get('2a', shallowcopy=True)

# Generated at 2022-06-10 23:06:47.569828
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 'bar'})

    # simple test to make sure the function actually returns what is expected
    assert cliargs_deferred_get('foo')() == 'bar'

    # test with a default specified to make sure it works
    assert cliargs_deferred_get('xyz', 'default')() == 'default'

# Generated at 2022-06-10 23:06:58.997216
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.reset()
    # Test 1: Using default
    cli_arg = cliargs_deferred_get('foo', default='bar')
    assert cli_arg() == 'bar'

    # Test 2: Copy on set: no copy
    CLIARGS.update(dict(copy='copy'))
    cli_arg = cliargs_deferred_get('copy', shallowcopy=True)
    assert cli_arg() == 'copy'

    # Test 3: Copy on set: list
    CLIARGS.update(dict(copy=['copy', 'copy']))
    cli_arg = cliargs_deferred_get('copy', shallowcopy=True)
    assert cli_arg() == ['copy', 'copy']
    CLIARGS['copy'][0] = 'nocopy'

# Generated at 2022-06-10 23:07:20.595059
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class ObjectLikeDict:
        def __init__(self, base=None):
            self.base = base
            self.other_value = 'other_value'

        def get(self, key, default=None):
            if key == 'base':
                return self.base
            return default

    CLIARGS.__setitem__ = ObjectLikeDict().__setitem__
    CLIARGS.get = ObjectLikeDict().get

    assert cliargs_deferred_get('base')() is None
    assert cliargs_deferred_get('base', 'default_value')() == 'default_value'
    assert cliargs_deferred_get('other_key', 'default_value')() == 'default_value'

    CLIARGS.__setitem__('base', '')
    assert cliargs_def

# Generated at 2022-06-10 23:07:31.297578
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    global CLIARGS
    CLIARGS = CLIArgs({'A_KEY': 'A_VALUE', 'A_KEY2': 'A_VALUE2'})
    assert cliargs_deferred_get('A_KEY')() == 'A_VALUE'
    assert cliargs_deferred_get('A_KEY2')() == 'A_VALUE2'
    assert cliargs_deferred_get('A_KEY3')() is None
    assert cliargs_deferred_get('A_KEY3', default='A_DEFAULT')() == 'A_DEFAULT'
    # Note: copy() is shallow copy so we don't recurse down into a dictionary

# Generated at 2022-06-10 23:07:36.535670
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.set_value({'a': 1, 'b': 2})
    s = cliargs_deferred_get('b', shallowcopy=True)
    assert s() == 2
    CLIARGS.set_value({'a': 1, 'b': 3})
    assert s() == 2
    assert cliargs_deferred_get('c', default={'foo': 'bar'})() == {'foo': 'bar'}

# Generated at 2022-06-10 23:07:46.434014
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})

    deferred_get_foo = cliargs_deferred_get('foo')
    # Default value of foo is None
    assert deferred_get_foo() is None

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert deferred_get_foo() == 'bar'

    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})

    assert deferred_get_foo() == ['bar', 'baz']

    # Check that it's a shallow copy
    assert deferred_get_foo(shallowcopy=True) is not CLIARGS.get('foo')
    assert deferred_get_foo(shallowcopy=True) == CLIARGS.get('foo')

# Generated at 2022-06-10 23:07:56.572247
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get

    The function is intended to be used as a closure and so has no input arguments
    """

    global CLIARGS
    test_args = {
        "foo": "my_foo",
        "bar": ["bar_1", "bar_2"],
        "baz": {'a': 1, 'b': 2},
    }

    # Test shallow copy
    CLIARGS = CLIArgs(test_args)
    assert cliargs_deferred_get("foo", shallowcopy=True) == "my_foo"
    assert cliargs_deferred_get("bar", shallowcopy=True) == ["bar_1", "bar_2"]
    assert cliargs_deferred_get("baz", shallowcopy=True) == {'a': 1, 'b': 2}

    #

# Generated at 2022-06-10 23:08:08.632826
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""

    # Test expected function
    cli_args = CLIArgs({'key1': 'value1', 'key2': ['value2a', 'value2b']})
    g1 = cliargs_deferred_get('key1', None, False)
    g2 = cliargs_deferred_get('key2', None, False)
    g3 = cliargs_deferred_get('bad_key', 'default', False)
    assert g1() == 'value1'
    assert g2() == ['value2a', 'value2b']
    assert g3() == 'default'

    # Test copies
    g4 = cliargs_deferred_get('key2', None, True)
    list_copy = g4()

# Generated at 2022-06-10 23:08:19.429005
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from copy import copy
    cliargs = CLIArgs({'a': 'nada', 'b': [1, 2, 3], 'c': {'x': 1}, 'd': set([1, 2, 3])})
    func_a = cliargs_deferred_get('a', shallowcopy=False)
    func_b = cliargs_deferred_get('b', shallowcopy=False)
    func_c = cliargs_deferred_get('c', shallowcopy=False)
    func_d = cliargs_deferred_get('d', shallowcopy=False)

    func_e = cliargs_deferred_get('a', shallowcopy=True)
    func_f = cliargs_deferred_get('b', shallowcopy=True)

# Generated at 2022-06-10 23:08:31.307457
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from copy import copy, deepcopy
    # Test with CLIARGS being the GlobalCLIArgs singleton
    assert cliargs_deferred_get('foo', None, shallowcopy=False)() == None  # pylint: disable=protected-access
    assert cliargs_deferred_get('foo', None, shallowcopy=True)() == None  # pylint: disable=protected-access
    # Test with CLIARGS NOT being the GlobalCLIArgs singleton so it calls through to the proxy
    mycliargs = CLIArgs({})
    mycliargs.foo = 42
    assert cliargs_deferred_get('foo', None, shallowcopy=False)() == 42
    assert cliargs_deferred_get('foo', None, shallowcopy=True)() == 42

# Generated at 2022-06-10 23:08:38.784159
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        from unittest import mock
    except ImportError:
        import mock

    from ansible.utils.context_objects import CliArgs
    from ansible.utils.context import cliargs_deferred_get

    def test_fn():
        return cliargs_deferred_get('index_file')

    assert test_fn() is None

    with mock.patch.object(CliArgs, 'from_options', return_value=CliArgs({'index_file': 'foo.txt'})):
        result = test_fn()
        assert result == 'foo.txt'

# Generated at 2022-06-10 23:08:48.757742
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Use a global to be able to reference the value from `test_cliargs_deferred_get`
    # function
    global CLIARGS

    CLIARGS = CLIArgs({
        'gathering': 'smart',
        'verbosity': 'vvvv',
        'become': True,
        'no_log': False,
        'lookup_plugins': ['/foo'],
        'filter_plugins': ['/bar'],
    })

    def test_deferred_get(key, expected_types, expected_value, shallowcopy=False):
        # pylint: disable=unused-argument
        retvalue = cliargs_deferred_get(key, shallowcopy=shallowcopy)()
        assert isinstance(retvalue, expected_types)
        assert retvalue == expected_value

    test_deferred_get

# Generated at 2022-06-10 23:09:22.732140
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible_collections.testns.testcoll.plugins.module_utils import arg_defs, ModuleArgsParser

    class DummyModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            raise AssertionError(kwargs)

    mod = DummyModule()
    mod.params = {'source': '/path/to/source', 'dest': '/path/to/dest'}
    # Sets up the default connection args
    g_cli_args = GlobalCLIArgs.from_options({
        'connection': 'smart',
        'inventory': '/path/to/inventory'
    })

    # The defaults should

# Generated at 2022-06-10 23:09:33.555047
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.utils.context_objects import CliArgs
    old_cliargs = CLIARGS

# Generated at 2022-06-10 23:09:43.957564
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test getting values from CLIArgs object with deferred get"""
    cli_args = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    foo_dg = cliargs_deferred_get('foo')
    baz_dg = cliargs_deferred_get('baz', shallowcopy=True)
    qux_dg = cliargs_deferred_get('qux', shallowcopy=True)

    class Foo:
        foo = cliargs_deferred_get('foo')
        baz = cliargs_deferred_get('baz', shallowcopy=True)
        qux = cliargs_deferred_get('qux', shallowcopy=True)


# Generated at 2022-06-10 23:09:50.084157
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.module_utils.common._collections_compat as collections

    # Check that the closure works
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS['foo'] = [1, 2, 3]

# Generated at 2022-06-10 23:10:01.797902
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test CLIARGS.get closure works as expected

    This test can't run until the CLIARGS object has actually been parsed
    """
    import pytest

    @pytest.fixture
    def global_cliargs(mocker):
        global CLIARGS
        old_cliargs = CLIARGS
        CLIARGS = CLIArgs({'foo': 'bar', 'baz': []})
        yield
        CLIARGS = old_cliargs

    def test_can_access_value(global_cliargs, mocker):
        data = cliargs_deferred_get('foo')()
        assert data == 'bar'

    def test_non_existent_key(global_cliargs, mocker):
        data = cliargs_deferred_get('does_not_exist')()
        assert data is None


# Generated at 2022-06-10 23:10:08.986117
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Tests the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name

    # Test that the closure works properly
    def test_default(default, expected):
        def set_default():
            CLIARGS['foo'] = default
        def get_default():
            return cliargs_deferred_get('foo')()

        set_default()
        assert get_default() == expected

    test_default(None, None)
    test_default(True, True)
    test_default(False, False)
    test_default(42, 42)
    test_default([], [])
    test_default({}, {})
    test_default(set(), set())

    # Test that the shallowcopy works

# Generated at 2022-06-10 23:10:19.364885
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for cliargs_deferred_get

    Use cases:
        1) Retrieval of a value from CLIARGS when CLIARGS is not set
        2) Retrieval of a value from CLIARGS when CLIARGS is set
        3) Shallow copy of a value in CLIARGS.
    """
    global CLIARGS
    stack = []

    # Case 1: Retrieval of a value from ``CLIARGS`` when ``CLIARGS`` is not set
    stack.append(None)
    cliargs_get = cliargs_deferred_get('foo')
    assert cliargs_get() is None

    # Case 2: Retrieval of a value from ``CLIARGS`` when ``CLIARGS`` is set
    stack.append(42)

# Generated at 2022-06-10 23:10:29.839619
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-argument,redefined-outer-name
    def mock_get(key, default=None):
        if key == 'mykey':
            return 'myvalue'
        return default

    original_cliargs = CLIARGS
    try:
        CLIARGS = type('', (object,), {})()
        CLIARGS.get = mock_get
        assert cliargs_deferred_get('mykey')() == 'myvalue'
        assert cliargs_deferred_get('mykey', default='mydefault')() == 'myvalue'
        assert cliargs_deferred_get('otherkey', default='mydefault')() == 'mydefault'
    finally:
        CLIARGS = original_cliargs

# Generated at 2022-06-10 23:10:38.514806
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class T(object):
        a = cliargs_deferred_get('a')

    t = T()
    _init_global_context({'a': 'abc'})
    assert t.a == 'abc'

    t = T()
    _init_global_context({'a': ['abc', 'def']})
    assert t.a == ['abc', 'def']

    t = T()
    _init_global_context({'a': {'abc': 'def'}})
    assert t.a == {'abc': 'def'}

    t = T()
    _init_global_context({'a': set([1, 2, 3])})
    assert t.a == set([1, 2, 3])

    t = T()

# Generated at 2022-06-10 23:10:43.467500
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('a')(), None
    CLIARGS.update({'a': 1})
    assert cliargs_deferred_get('a')(), 1
    assert cliargs_deferred_get('b', default=2)(), 2

# Generated at 2022-06-10 23:11:45.793786
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pragma: no cover
    from ansible.module_utils.common.collections import AttributeDict
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CliArgs
    from ansible.compat.tests.mock import patch, Mock
    from ansible.cli import CLI
    import ansible.constants as C

    # Run the below assertions with a different version of CLIARGS
    C.ANSIBLE_ARGS = '-vvvv -vvvv'
    with patch('ansible.cli.CLI.run'):
        cli_args = AttributeDict(CLI().parse([]))

    # Initial version of CLIARGS
    cli_args_obj = CliArgs(cli_args)

# Generated at 2022-06-10 23:11:55.443254
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(test_var=True))
    assert cliargs_deferred_get('test_var')() is True
    assert cliargs_deferred_get('test_var', default=False)() is True
    assert cliargs_deferred_get('not_a_var', default=False)() is False
    assert cliargs_deferred_get('not_a_var', default=False, shallowcopy=True)() is False
    assert cliargs_deferred_get('not_a_var', default=None, shallowcopy=True)() is None
    assert cliargs_deferred_get('not_a_var', default=0, shallowcopy=True)() == 0