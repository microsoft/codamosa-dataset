

# Generated at 2022-06-10 23:02:10.103053
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # Set up CLIARGS to have some test arguments
    # Note: some of these are sequences which get shallow copied, some are dicts/sets which
    # get copied
    global CLIARGS
    cliargs = CLIARGS = CLIArgs({'test_arg': 123, 'test_arg_seq': [1, 2, 3]})

    # No arguments to deferred_get - gets the default global
    assert cliargs_deferred_get()() is cliargs

    # With arguments, should return the values
    assert cliargs_deferred_get('test_arg')() == 123
    assert cliargs_deferred_get('test_arg_seq')() == [1, 2, 3]

    # Make sure that shallow copy was used
    assert cliargs_

# Generated at 2022-06-10 23:02:20.688832
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test basic operation with no defaults and not shallowcopy
    cli_args = {'test': 5}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('test')() == 5

    # Test default value
    assert cliargs_deferred_get('test2', default=10)() == 10

    # Test shallow copy
    cli_args = {'seq': [], 'mapping': {}, 'set': set(), 'nostore': 5}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('seq', shallowcopy=True)() == []
    assert cliargs_deferred_get('mapping', shallowcopy=True)() == {}

# Generated at 2022-06-10 23:02:31.051252
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # No CLIARGS environment
    cargs = cliargs_deferred_get('foo')
    assert cargs() == None

    # CLIARGS environment with no foo key
    global CLIARGS
    class FakeCLIARGS:
        def __init__(self):
            self.foo = None

    CLIARGS = FakeCLIARGS()
    cargs = cliargs_deferred_get('foo')
    assert cargs() == None

    # CLIARGS environment with foo key and
    class FakeCLIARGS:
        def __init__(self):
            self.foo = 'foo'

    CLIARGS = FakeCLIARGS()
    cargs = cliargs_deferred_get('foo')
    assert cargs() == 'foo'

# Generated at 2022-06-10 23:02:42.047045
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class GlobalCliArgsStub(GlobalCLIArgs):
        def __init__(self, options):
            super(GlobalCliArgsStub, self).__init__({})
            self.options = options
        def __getitem__(self, key):
            return self.options.__getitem__(key)
    a_list = ['one', 'two', 'three']
    a_tuple = ('one', 'two', 'three')
    a_dict = {'key1': 'value1', 'key2': 'value2'}
    a_set = set(('one', 'two', 'three'))
    args = {'foo': a_list, 'bar': a_tuple, 'baz': a_dict, 'quux': a_set}

    global CLIARGS
    cli_args = Global

# Generated at 2022-06-10 23:02:50.223542
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=missing-docstring
    global CLIARGS
    cli_args = {'foo': 'bar', 'baz': [1, 2, 3]}
    CLIARGS = CLIArgs(cli_args)

    # A function to allow checking cliargs_deferred_get *and* put the results in a closure so
    # we can make sure that the function is only called once
    def check(key, default=None, shallowcopy=False):
        called = [False]

        def inner():
            if called[0]:
                raise RuntimeError('cliargs_deferred_get was called more than once')
            called[0] = True
            if default is not None:
                assert CLIARGS.get(key) is not default

# Generated at 2022-06-10 23:03:02.886897
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.shared_loader_obj.data = {'foo': 'bar'}
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS.shared_loader_obj.data = {'foo': ['a', 'b', 'c']}
    assert cliargs_deferred_get('foo')() == ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS.shared_loader_obj.data['foo']

# Generated at 2022-06-10 23:03:14.553999
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Make sure that cliargs_deferred_get returns the correct value"""
    import ansible.constants as C
    from ansible.utils.context_objects import ContextObject
    from ansible.utils import context_objects
    from ansible.plugins.loader import connection_loader

    class FakeCLIArgs(ContextObject):
        def __init__(self, args):
            self._data = args

        def get(self, key, default=None):
            return self._data.get(key, default)

    # Create a fake context with a specific set of cli args

# Generated at 2022-06-10 23:03:25.566479
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(foo='bar'))
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')(default='baz') == 'baz'

    _init_global_context(dict(foo=dict(bar='baz')))
    assert cliargs_deferred_get('foo')() == dict(bar='baz')
    assert cliargs_deferred_get('foo', shallowcopy=True)() == dict(bar='baz')

    _init_global_context(dict(foo=['bar', 'baz']))
    assert cliargs_deferred_get('foo')(default=[])() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)()

# Generated at 2022-06-10 23:03:35.857733
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict

    global_cliargs = GlobalCLIArgs({'test': 1})
    assert cliargs_deferred_get('test')() == 1
    assert cliargs_deferred_get('test', default=2)() == 1
    assert cliargs_deferred_get('test2', default=2)() == 2
    assert cliargs_deferred_get('test2')() is None
    # now test shallow copy of mutable types
    global_cliargs = global_cliargs._replace(mutable_copy_default=True)
    assert cliargs_deferred_get('test', default=2)() == 1
    assert cliargs_deferred_get('test2', default=2)() == 2
    assert cliargs_deferred

# Generated at 2022-06-10 23:03:46.192046
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # In python 2.6 this checks that the function can be defined
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    cliargs = GlobalCLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')(default='bler') == 'bler'

    cliargs['list'] = ['a', 'b', 'c']
    assert cliargs_deferred_get('list', shallowcopy=True)() == ['a', 'b', 'c']

# Generated at 2022-06-10 23:03:57.260172
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'test1': 'test1_value', 'test2': [1, 2], 'test3': {'a': 1}}
    _init_global_context(cli_args)

    assert CLIARGS.test1 == 'test1_value'
    assert CLIARGS.test1 is cliargs_deferred_get('test1')()
    assert CLIARGS.test1 is cliargs_deferred_get('test1', shallowcopy=True)()

    assert CLIARGS.test2 == [1, 2]
    assert CLIARGS.test2 is cliargs_deferred_get('test2')()
    assert CLIARGS.test2 == cliargs_deferred_get('test2', shallowcopy=True)()

    assert CLIARGS.test3 == {'a': 1}


# Generated at 2022-06-10 23:04:06.817233
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 5
    assert cliargs_deferred_get('foo')() == 5
    assert cliargs_deferred_get('foo', default=4)() == 5

    CLIARGS['bar'] = []
    assert cliargs_deferred_get('bar')() == []
    assert cliargs_deferred_get('bar', shallowcopy=True)() == []

    CLIARGS['baz'] = {}
    assert cliargs_deferred_get('baz')() == {}
    assert cliargs_deferred_get('baz', shallowcopy=True)() == {}

    CLIARGS['qux'] = {1, 2}
    assert cliargs_deferred_get('qux')() == {1, 2}

# Generated at 2022-06-10 23:04:15.466387
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = CLIArgs({'key': 'value', 'nestedkey': {'nestedvalue': 'nestedvalue'}})
    _init_global_context(args)
    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('nestedkey', shallowcopy=True)() == {'nestedvalue': 'nestedvalue'}
    assert cliargs_deferred_get('nestedkey', shallowcopy=True)() is not cliargs_deferred_get('nestedkey')()

# Generated at 2022-06-10 23:04:21.218851
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import doctest
    CLIARGS.SFTP_BATCH_MODE = False
    CLIARGS.options = {'ssh_args': '-o ControlMaster=no'}
    res = doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS)
    assert res.failed == 0, 'Failed %d tests: %s' % (res.failed, res)

# Generated at 2022-06-10 23:04:28.333892
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """allows a shallow copy of an attribute in CLIARGS to be used in FieldAttribute"""
    a = {'foo': [1, 2, 3]}
    CLIARGS.update(a)

    # No copy
    not_copied = cliargs_deferred_get('foo')
    assert id(a['foo']) == id(not_copied())

    # Shallow copy
    shallow_copied = cliargs_deferred_get('foo', shallowcopy=True)
    assert id(a['foo']) != id(shallow_copied())
    assert a['foo'] == shallow_copied()

    # Using a default
    default = cliargs_deferred_get('bar', default='bar')
    assert default() == 'bar'

    # Using a default with copy
    default_with_copy = cli

# Generated at 2022-06-10 23:04:35.444120
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = {'param1': 'value1',
               'param2': ['list_value1', 'list_value2']}

    _init_global_context(cliargs)

    assert cliargs_deferred_get('param1') == 'value1'
    assert cliargs_deferred_get('param1', shallowcopy=True) == 'value1'

    assert cliargs_deferred_get('param2') == ['list_value1', 'list_value2']
    assert cliargs_deferred_get('param2', shallowcopy=True) == ['list_value1', 'list_value2']
    assert cliargs_deferred_get('param2', shallowcopy=True) is not CLIARGS.get('param2')

    assert cliargs_deferred_get('unset_param')

# Generated at 2022-06-10 23:04:43.038504
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 'a', 'b': {'b': 'b'}, 'c': [1, 2, 3]})

    # simple get
    assert cliargs_deferred_get('a') == 'a'
    # get default
    assert cliargs_deferred_get('d', default='default') == 'default'
    # get shallow copy of sequence
    value = cliargs_deferred_get('c', shallowcopy=True)
    assert isinstance(value, list)
    assert value == [1, 2, 3]
    assert value is not CLIARGS.c
    # get shallow copy of mapping
    value = cliargs_deferred_get('b', shallowcopy=True)
    assert isinstance(value, dict)

# Generated at 2022-06-10 23:04:55.221196
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    class TestBase(object):
        attr = cliargs_deferred_get('missing_key', default=set())

    class TestSequence(TestBase):
        attr = cliargs_deferred_get('seq_key', default=[])

    class TestSet(TestBase):
        attr = cliargs_deferred_get('set_key', default=set())

    class TestMapping(TestBase):
        attr = cliargs_deferred_get('map_key', default={})

    class TestShallowCopy(TestBase):
        attr = cliargs_deferred_get('shallow_key', shallowcopy=True)

    class TestShallowCopySequence(TestBase):
        attr = cliargs_deferred_get('shallow_seq_key', shallowcopy=True)


# Generated at 2022-06-10 23:05:06.717133
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(one=1, two=2, three=3, kvlist=[dict(a=1, b=2)], list=['a', 'b']))
    assert cliargs_deferred_get('one')() == 1
    assert cliargs_deferred_get('two')() == 2
    assert cliargs_deferred_get('three')() == 3
    assert cliargs_deferred_get('four')() is None
    assert cliargs_deferred_get('four', default='four')() == 'four'

    assert cliargs_deferred_get('kvlist')() == [dict(a=1, b=2)]

# Generated at 2022-06-10 23:05:15.251466
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'abc': [1, 2, 3, 4]})
    func = cliargs_deferred_get('abc')
    assert func() == [1, 2, 3, 4]
    func = cliargs_deferred_get('abc', shallowcopy=True)
    assert func() == [1, 2, 3, 4]
    func = cliargs_deferred_get('abc', shallowcopy=False)
    assert func() == [1, 2, 3, 4]
    func = cliargs_deferred_get('abc', shallowcopy=True)
    assert func() != [1, 2, 3, 4]
    func = cliargs_deferred_get('xyz', default='foobar')
    assert func() == 'foobar'

# Generated at 2022-06-10 23:05:29.633532
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy

    # Setup
    cli_args = {'list': ['foo', 'bar'], 'dict': {'a': 'foo', 'b': 'bar'}, 'set': {'a', 'b'}}
    _init_global_context(cli_args)

    for key, value in cli_args.items():
        get_func = cliargs_deferred_get(key, shallowcopy=False)
        assert get_func() == value

        get_func = cliargs_deferred_get(key, shallowcopy=True)
        assert get_func() == copy.copy(value)

    # Teardown
    _init_global_context({'list': [], 'dict': {}, 'set': set()})

# Generated at 2022-06-10 23:05:41.051750
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    cliargs = {
        'a': None,
        'b': [1, 2, 3],
        'c': {'d': 4, 'e': 5},
    }
    _init_global_context(cliargs)
    assert cliargs_deferred_get('a')() == cliargs['a']
    assert cliargs_deferred_get('b')() == cliargs['b']
    assert cliargs_deferred_get('c')() == cliargs['c']
    assert cliargs_deferred_get('d')() is None
    assert cliargs_deferred_get('d', default='foo')() == 'foo'

    assert cliargs_deferred_get('a', shallowcopy=True)() == cliargs['a']
    assert cli

# Generated at 2022-06-10 23:05:51.456136
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import math
    import random

    # Validate noop
    range_ = range(1000)
    CLIARGS['range'] = range_
    result = cliargs_deferred_get('range')
    assert range_ is result
    assert range_ is cliargs_deferred_get('range')()
    assert range_ is cliargs_deferred_get('range', shallowcopy=True)
    assert range_ is cliargs_deferred_get('range', shallowcopy=True)()

    # Validate shallow copy
    assert range_[:] is not cliargs_deferred_get('range', shallowcopy=True)()

    # Validate default
    assert cliargs_deferred_get('not_a_range')() is None

# Generated at 2022-06-10 23:05:58.252201
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''Test function cliargs_deferred_get'''

# Generated at 2022-06-10 23:06:06.421493
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': {'bar': 1}}
    cli_args_copy = cli_args.copy()
    cli_args_copy['foo'] = cli_args_copy['foo'].copy()
    cli_args_copy['foo']['bar'] = 2
    cli_args_shallow_copy = cli_args.copy()
    cli_args_shallow_copy['foo']['bar'] = 3

    _init_global_context(cli_args)

    test_get_value = cliargs_deferred_get('foo')
    assert test_get_value() == {'bar': 1}

    test_get_default = cliargs_deferred_get('baz')
    assert test_get_default() == None

    test_get_shallow

# Generated at 2022-06-10 23:06:13.299988
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-argument
    def mock_get(key, default=None):
        if key == 'foo':
            return 'bar'
        # CLIArgs returns NOne by default
        return None
    saved = CLIARGS.get
    CLIARGS.get = mock_get
    assert cliargs_deferred_get('foo')(), 'bar'
    assert cliargs_deferred_get('not-a-key', default='foo')(), 'foo'
    assert cliargs_deferred_get('not-a-key', default='foo', shallowcopy=True)(), 'foo'
    assert cliargs_deferred_get('foo', default='foo')(), 'bar'

# Generated at 2022-06-10 23:06:23.941981
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _test_get_value(expected_value, shallowcopy):
        _init_global_context({'foo': expected_value})
        inner = cliargs_deferred_get('foo', default=None, shallowcopy=shallowcopy)
        return inner()

    test_sequence = [1, 2, 3]
    test_dict = {'a': 1}
    assert _test_get_value(123, shallowcopy=False) == 123
    assert _test_get_value([1, 2, 3], shallowcopy=False) == [1, 2, 3]
    assert _test_get_value({'a': 1}, shallowcopy=False) == {'a': 1}

    assert _test_get_value(123, shallowcopy=True) == 123

# Generated at 2022-06-10 23:06:35.655377
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeCliArgs:
        def __init__(self, values):
            self._values = values

        def __getitem__(self, key):
            return self._values[key]

    foo = FakeCliArgs({'foo': 'bar'})
    bar = FakeCliArgs({'bar': 'baz'})

    f = cliargs_deferred_get('foo')
    assert f() == 'bar'

    b = cliargs_deferred_get('bar')
    assert b() == 'baz'

    global CLIARGS
    CLIARGS = foo
    assert f() == 'bar'
    assert b() == 'baz'

    CLIARGS = bar
    CLIARGS = foo
    assert f() == 'bar'
    assert b() == 'baz'

# Generated at 2022-06-10 23:06:47.308241
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS._values = {'test_option': {'test_inner_option': 'test_value'}}
    assert cliargs_deferred_get('test_option', {})().get('test_inner_option') == 'test_value'
    CLIARGS._values = {'test_option': 'test_value'}
    assert cliargs_deferred_get('test_option')().get('test_inner_option') is None
    assert cliargs_deferred_get('test_option', default={'test_inner_option': 'test_value'})().get('test_inner_option') == 'test_value'
    assert cliargs_deferred_get('test_option', shallowcopy=True)() == 'test_value'

# Generated at 2022-06-10 23:06:58.724056
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-10 23:07:11.717405
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def reset():
        global CLIARGS
        CLIARGS = {}

    val = 'a_value'
    reset()
    assert None is cliargs_deferred_get('foo')()
    CLIARGS['foo'] = val
    assert val is cliargs_deferred_get('foo')()

    reset()
    assert None is cliargs_deferred_get('foo', default=None)()
    CLIARGS['foo'] = val
    assert val is cliargs_deferred_get('foo', default=None)()

    reset()
    assert None is cliargs_deferred_get('foo', default=None)()
    assert [] is cliargs_deferred_get('foo', default=[])()
    CLIARGS['foo'] = val

# Generated at 2022-06-10 23:07:20.751283
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(foo=[1, 2], bar={'answer': 42}, baz={1, 2}))

    assert cliargs_deferred_get('foo') == CLIARGS.get('foo')
    assert cliargs_deferred_get('bar') == CLIARGS.get('bar')
    assert cliargs_deferred_get('baz') == CLIARGS.get('baz')

    # Test shallowcopy
    assert cliargs_deferred_get('foo', shallowcopy=True) == CLIARGS.get('foo')
    assert cliargs_deferred_get('bar', shallowcopy=True) == CLIARGS.get('bar')

# Generated at 2022-06-10 23:07:31.365685
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pragma: no cover
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs

    # Test shallowcopy behavior
    test_list = [1, 2, 3]
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_set = {1, 2, 3}
    test_str = to_native(to_bytes('test'))
    test_bytes = to_bytes('test')
    test_int = 1
    test_bool = True
    test_func = lambda: None

    CLIARGS = CLIArgs({})


# Generated at 2022-06-10 23:07:41.290478
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.set_defaults(dict(
        a=dict(
            b=dict(
                c=[],
                d=1,
                e=set(),
            ),
        ),
    ))
    # Deferred get with a default
    dg = cliargs_deferred_get('a.b.f', default=2)
    assert dg() == 2

    # Deferred get with no default
    dg = cliargs_deferred_get('a.b.f')
    CLIARGS.set('a.b.f', 3)
    assert dg() == 3

    # Deferred get with a default and shallow copy True
    dg = cliargs_deferred_get('a.b.f', default=4, shallowcopy=True)
    assert dg() == 4
    CLIARGS

# Generated at 2022-06-10 23:07:51.954872
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works as expected
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foobar', default='baz')() == 'baz'

    # Test that the closure works with a deferred value
    def foo():
        return 'foo'
    CLIARGS['foobar'] = foo
    assert cliargs_deferred_get('foobar', default='bar')() == 'foo'
    assert cliargs_deferred_get('foo', default=foo)() == 'bar'

    # Test that the closure works with a deferred value that returns a mutable type

# Generated at 2022-06-10 23:07:58.198794
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=protected-access
    assert CLIARGS._data == {}
    assert cliargs_deferred_get('key', default=1)() == 1
    CLIARGS._data = {'key': 2}
    assert cliargs_deferred_get('key', default=1)() == 2
    assert not cliargs_deferred_get('key', default=1, shallowcopy=True)() is CLIARGS._data['key']

# Generated at 2022-06-10 23:08:10.068555
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS['foo'] = 'bar'

    # Get by attribute
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

    # Get by item
    assert cliargs_deferred_get(key='foo')() == 'bar'
    assert cliargs_deferred_get(key='foo', shallowcopy=True)() == 'bar'

    CLIARGS['baz'] = ['qux', 'qux2']

    # Get list
    assert cliargs_deferred_get(key='baz')() == ['qux', 'qux2']

# Generated at 2022-06-10 23:08:20.360270
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': ['x', 'y', 'z'], 'buz': {'k1': 'v1', 'k2': 'v2'}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == ['x', 'y', 'z']
    assert cliargs_deferred_get('buz')() == {'k1': 'v1', 'k2': 'v2'}
    assert cliargs_deferred_get('foz')() is None
    assert cliargs_deferred_get('foz', default='x')() == 'x'
    assert cliargs_deferred_get('foo', shallowcopy=True)()

# Generated at 2022-06-10 23:08:32.387475
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    cli_args = dict(val1=1, val2=2, val3=3)

    CLIARGS = CLIArgs(cli_args)

    assert cliargs_deferred_get('val2')() == 2
    assert cliargs_deferred_get('val1')() == 1
    assert cliargs_deferred_get('val3')() == 3
    assert cliargs_deferred_get('val4')() is None
    assert cliargs_deferred_get('val4', default='default')() == 'default'

    cli_args['val1'] = [1, 2, 3, 4]
    cli_args['val2'] = dict(key1=1, key2=2)

# Generated at 2022-06-10 23:08:35.862444
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('key', default='defval')() == 'defval'
    CLIARGS['key'] = 'val'
    assert cliargs_deferred_get('key', default='defval')() == 'val'



# Generated at 2022-06-10 23:08:57.628917
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    import collections

    base_cli_args = {
        'foo': 'bar',
        'spam': ['ham', 'eggs'],
        'nest': {'spam': 'ham'},
        'set': set(['spam', 'ham']),
    }

    global CLIARGS
    original_CLIARGS = CLIARGS

# Generated at 2022-06-10 23:09:07.025761
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that the deferred get behavior works"""
    # This one is easy.  Just call with a default= and make sure it doesn't
    # raise an exception.
    assert cliargs_deferred_get('foo1', default='bar')() == 'bar'

    # Now set a value and make sure it returns it
    CLIARGS = GlobalCLIArgs.from_options({'foo2': 'baz'})
    assert cliargs_deferred_get('foo2', default='bar')() == 'baz'

    # Same as the above test but with shallow copy enabled
    CLIARGS = GlobalCLIArgs.from_options({'foo3': 'baz'})
    assert cliargs_deferred_get('foo3', default='bar', shallowcopy=False)() == 'baz'

    # Check that shallow copy works

# Generated at 2022-06-10 23:09:16.546815
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo':'bar', 'baz': ['baz1', 'baz2']})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz', default='default')() == ['baz1', 'baz2']
    assert cliargs_deferred_get('quux', default='default')() == 'default'
    assert cliargs_deferred_get('quux', default=['default'])() == ['default']
    assert cliargs_deferred_get('baz')() == ['baz1', 'baz2']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

# Generated at 2022-06-10 23:09:23.252251
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    class FakeCLIArgs(dict):
        def get(self, key, default=None):
            return default
    global CLIARGS
    old_cliargs = CLIARGS
    new_cliargs = FakeCLIArgs()
    CLIARGS = new_cliargs

    # Test
    assert cliargs_deferred_get('missing_key', default='gotcha!')() == 'gotcha!'
    CLIARGS['missing_key'] = 'thiskey'
    assert cliargs_deferred_get('missing_key', default='gotcha!')() == 'thiskey'

    # Teardown
    CLIARGS = old_cliargs

# Generated at 2022-06-10 23:09:33.944215
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get

    Ensures that it copies and returns the correct value
    """
    global CLIARGS
    CLIARGS = CLIArgs({'key': 'value'})
    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('key', shallowcopy=True)() == 'value'
    CLIARGS = CLIArgs({'key': 'value', 'key2': Set(['a', 'b', 'c'])})
    assert cliargs_deferred_get('key', 'default')() == 'value'
    assert cliargs_deferred_get('key', 'default', shallowcopy=True)() == 'value'
    val2 = cliargs_deferred_get('key2')()
    val2.add

# Generated at 2022-06-10 23:09:44.259028
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping
    i = -1
    my_global = CLIARGS
    def increment_i():
        nonlocal i
        i += 1
        return i
    # Test with no default, always returns None
    foo = cliargs_deferred_get('foo')
    assert foo() is None, "Got %s instead of None" % foo
    assert i == 0, "increment_i did not get called"
    # Test with a non-shallow copy default
    foo_default = cliargs_deferred_get('foo', default=increment_i)
    assert foo_default() is 0, "got %s instead of 0" % foo_default()
    assert i == 1, "increment_i got called too many times"
    # Test with a

# Generated at 2022-06-10 23:09:48.948439
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)

    # Test
    returned_getter = cliargs_deferred_get('foo', 'default')
    assert returned_getter() == 'bar'
    returned_getter = cliargs_deferred_get('bar', 'default')
    assert returned_getter() == 'default'
    returned_getter = cliargs_deferred_get('bar', 'default', shallowcopy=True)
    assert returned_getter() == 'default'

# Generated at 2022-06-10 23:10:01.011353
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    from ansible.utils.context_objects import SeedCLIArgs
    from collections import OrderedDict, Counter

    def build_set(with_key='default'):
        ret = OrderedDict()
        ret['key'] = with_key
        ret['default'] = 'default_value'
        ret['list'] = ['list_value_1', 'list_value_2']
        ret['tuple'] = ('tuple_value_1', 'tuple_value_2')
        ret['dict'] = {'dict_value': 'dict_value'}
        ret['ordereddict'] = OrderedDict(dict_value='ordereddict_value')
        ret['counter'] = Counter(dict_value='counter_value')
        return ret

    # Test CLIARGS being unset

# Generated at 2022-06-10 23:10:08.507358
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    old_CLIARGS = CLIARGS
    CLIARGS = CLIArgs(dict(one=1, two=2))
    assert cliargs_deferred_get('two')() == 2
    assert cliargs_deferred_get('three')() is None
    assert cliargs_deferred_get('two', extract_hosts=True)() == 2
    assert cliargs_deferred_get('three', extract_hosts=True)() is None
    assert cliargs_deferred_get('three', default=3)() == 3
    assert cliargs_deferred_get('one', shallowcopy=True)() == [1]
    assert cliargs_deferred_get('two', shallowcopy=True)() == [2]
    CLIARGS = old_CLIARGS

# Generated at 2022-06-10 23:10:19.039977
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test if cliargs_deferred_get(key) works correctly"""
    cli_args = {'test_key_1': 'test_value_1', 'test_key_2': 'test_value_2'}

    def set_global_context():
        """Set up the global context so we can test this function"""
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    def unset_global_context():
        """Reset the global context after the test run"""
        global CLIARGS
        CLIARGS = CLIArgs({})


# Generated at 2022-06-10 23:10:37.833876
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.tests.unit.compat.mock import MagicMock
    # We patch this out so we don't have to import all the Ansible code.  This
    # is a just a test of a function and we don't need all the machinery to
    # test a function
    global CLIARGS
    CLIARGS = MagicMock(spec=CLIArgs)
    # Return a case-insensitive dictionary
    CLIARGS.get.return_value = ImmutableDict({'foo': 'bar', 'baz': 'blargh'})

    t = cliargs_deferred_get('FOO')

# Generated at 2022-06-10 23:10:45.585119
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS['inventory'] = 'a2'
    assert cliargs_deferred_get('inventory')() == 'a2'
    assert cliargs_deferred_get('inventory', default='shutup mypy')() == 'a2'
    assert cliargs_deferred_get('inventory', default='shutup mypy', shallowcopy=True)() == 'a2'
    assert cliargs_deferred_get('inventory', shallowcopy=True)() == 'a2'

# Generated at 2022-06-10 23:10:56.240506
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for cliargs_deferred_get"""
    CLIARGS['value'] = 1
    assert cliargs_deferred_get('value')() == 1
    assert cliargs_deferred_get('value')(shallowcopy=True) == 1

    CLIARGS['value'] = [1,2,3]
    assert cliargs_deferred_get('value')(shallowcopy=True) == [1,2,3]
    assert cliargs_deferred_get('value')(shallowcopy=False) == [1,2,3]
    CLIARGS['value'].append(4)
    assert cliargs_deferred_get('value')(shallowcopy=True) == [1,2,3,4]

# Generated at 2022-06-10 23:11:05.080687
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-10 23:11:16.962512
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('nonexistent', default=False)() is False

    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)

    assert cliargs_deferred_get('foo', default=False)() is 'bar'
    assert cliargs_deferred_get('nonexistent', default=False)() is False

    cli_args = {'foo': 'bar', 'deep': [1, 2, 3]}
    _init_global_context(cli_args)

    assert cliargs_deferred_get('foo', shallowcopy=True)() is 'bar'
    assert cliargs_deferred_get('deep', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('deep')

# Generated at 2022-06-10 23:11:29.701058
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Create a mock cliargs object
    CLIARGS = CLIArgs({'become': False, 'host_pattern': 'testhost', 'remaining_args': ('test-module', '/tmp/mytestfile')})
    # Test basic call
    assert cliargs_deferred_get('become')()
    # Test call with explicit default (should return default)
    assert not cliargs_deferred_get('vault_password', default=False)()
    # Test call with default as None (should return None)
    assert cliargs_deferred_get('vault_password')() is None
    # Test call with True for shallowcopy and immutable default
    assert not cliargs_deferred_get('vault_password', default=False, shallowcopy=True)()
    # Test call with True for shallowcopy and mutable default

# Generated at 2022-06-10 23:11:30.861365
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get('become')

# Generated at 2022-06-10 23:11:39.368788
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Class:
        pass
    global CLIARGS
    CLIARGS = {'a': 1, 'b': [2, 3], 'c': {'d': 4}, 'e': set([5]), 'f': Class()}

    # Make sure we get back the key
    assert cliargs_deferred_get('a')() == 1

    # Make sure the default is returned when the key isn't present
    assert cliargs_deferred_get('g')() is None
    assert cliargs_deferred_get('g', 'default')() == 'default'

    # Make sure we get a shallow copy of the value
    b_copy = cliargs_deferred_get('b', shallowcopy=True)()
    assert b_copy == [2, 3]
    b_copy.append(4)
    assert b_

# Generated at 2022-06-10 23:11:50.552336
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for cliargs_deferred_get"""
    import copy
    cliargs = {
        'a': 'a',
        'b': [],
        'c': {},
        'd': set(),
        'e': [1, 2],
        'f': {'foo': 'bar'},
        'g': set(['foo']),
    }
    _init_global_context(cliargs)
    for key in cliargs.keys():
        assert cliargs[key] == cliargs_deferred_get(key)()
    for key in cliargs.keys():
        assert cliargs[key] is not cliargs_deferred_get(key, shallowcopy=True)()
    for key in cliargs.keys():
        assert cliargs[key] == cliargs_

# Generated at 2022-06-10 23:11:59.740344
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    def test_assertion(value, assert_func):
        value1 = cliargs_deferred_get(key, default=value, shallowcopy=False)()
        value2 = cliargs_deferred_get(key, default=value, shallowcopy=True)()
        assert_func(value1, value2)

    key = 'foo'
    CLIARGS = GlobalCLIArgs.from_options({})
    test_assertion('bar', lambda v1, v2: v1 == v2)

    CLIARGS = GlobalCLIArgs.from_options({key: 'baz'})
    test_assertion(None, lambda v1, v2: v1 != v2)

    CLIARGS = GlobalCLIArgs.from_options({})