

# Generated at 2022-06-10 23:02:07.224872
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    assert cliargs_deferred_get('foo', default=['bar'])() == ['bar']
    CLIARGS['foo'] = (1, 2)
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2]
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']



# Generated at 2022-06-10 23:02:11.890921
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict1 = dict(key1="hello", key2=1, key3=dict(key="world"))
    CLIARGS.update(dict1)
    assert "hello" == cliargs_deferred_get('key1')()
    assert 1 == cliargs_deferred_get('key2')()
    assert dict(key="world") == cliargs_deferred_get('key3')()

# Generated at 2022-06-10 23:02:23.129648
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the closure over getting a key from CLIARGS with shallow copy functionality

    Primarily used in ``FieldAttribute`` where we need to defer setting the default
    until after the CLI arguments have been parsed
    """
    global CLIARGS

# Generated at 2022-06-10 23:02:32.930592
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    cliargs = CLIArgs({'foo': 'bar', 'baz': 123, 'biz': ['a', 'b', 'c']})
    global CLIARGS
    orig_CLIARGS = cliargs
    cliargs_get = cliargs_deferred_get
    CLIARGS = cliargs

    assert cliargs_get('foo') == 'bar'
    assert cliargs_get('baz') == 123
    assert cliargs_get('biz') == ['a', 'b', 'c']

    assert cliargs_get('bar', default='default1') == 'default1'

    assert cliargs_get('foo', default='default2') == 'bar'

# Generated at 2022-06-10 23:02:44.012969
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def init_cliargs(data):
        global CLIARGS
        CLIARGS = CLIArgs(data)

    def _test_deferred_get(key, default, expected_value, expected_shallow_copy_value):
        deferred_get = cliargs_deferred_get(key, default=default)
        assert deferred_get() == expected_value
        expected_value[0] = 'changed'
        assert deferred_get() != expected_shallow_copy_value
        assert deferred_get(shallowcopy=True) == expected_shallow_copy_value

    # Testing of the deferred_get closure.  This should always be in the form
    #   (key, default, expected_value, expected_shallow_copy_value)
    # Where:
    #   key: A string with the key to retrieve
    #  

# Generated at 2022-06-10 23:02:47.665620
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Dummy(object):
        attr = cliargs_deferred_get('test_key')

    assert Dummy().attr() is None
    CLIARGS['test_key'] = 'value'
    assert 'value' == Dummy().attr()



# Generated at 2022-06-10 23:02:55.381253
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def inner_func(a):
        return cliargs_deferred_get(a)

    _init_global_context(dict(ANSIBLE_FOO='foo', ANSIBLE_BAR='bar'))
    assert inner_func('ANSIBLE_FOO')() == 'foo'
    assert inner_func('ANSIBLE_BAR')() == 'bar'
    assert inner_func('ANSIBLE_BAZ')() is None

# Generated at 2022-06-10 23:03:00.258071
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Prepare the global context
    global CLIARGS
    def reset():
        CLIARGS = GlobalCLIArgs.from_options({})

    reset()
    CLIARGS.update({'foo': 'bar', 'baz': [1, 2, 3]})

    # Test the function
    assert (cliargs_deferred_get('foo')()) == 'bar'
    assert (cliargs_deferred_get('baz')()) == [1, 2, 3]
    assert (cliargs_deferred_get('baz', shallowcopy=True)()) == [1, 2, 3]
    assert (cliargs_deferred_get('non-existent', 'default-value')()) == 'default-value'

    # Test that the returned closure works across updates of the global context

# Generated at 2022-06-10 23:03:06.644372
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs
    cliargs = CliArgs({})
    cliargs['foo'] = 'bar'
    f = cliargs_deferred_get('foo')
    assert f() == 'bar'
    cliargs['foo'] = ['bar', 'baz']
    f = cliargs_deferred_get('foo', shallowcopy=True)
    assert f() == ['bar', 'baz']

# Generated at 2022-06-10 23:03:16.938722
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    expected = {'key_one': 'value_one', 'key_two': {'key_three': 'value_three'}, 'key_four': ['item_four', 'item_five']}

    # Test
    handler = cliargs_deferred_get('key_one', default='default_one')
    assert handler() == 'default_one'

    handler = cliargs_deferred_get('key_two', default='default_two')
    assert handler() == 'default_two'

    handler = cliargs_deferred_get('key_two', default='default_two', shallowcopy=True)
    assert handler() == 'default_two'

    handler = cliargs_deferred_get('key_four', default='default_four')
    assert handler() == 'default_four'

    handler

# Generated at 2022-06-10 23:03:30.189964
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from collections import MutableMapping
    from copy import copy, deepcopy
    from unittest import TestCase
    from ansible.cli.arguments import _make_parser
    from ansible.utils.context_objects import CliArgs

    class TestCliArgsDeferredGet(TestCase):
        def setUp(self):
            parser = _make_parser()
            argv = ['ansible-playbook', '-i', 'localhost,', '--forks=5', '--extra-vars', 'foo=bar', '--extra-vars', 'hosts=localhost']
            self.cli_args = CliArgs({})
            self.cli_args.parse_args(parser, argv)


# Generated at 2022-06-10 23:03:38.755668
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({"key": "value"})
    assert cliargs_deferred_get("key")() == "value"
    assert cliargs_deferred_get("key", default="default")() == "value"
    assert cliargs_deferred_get("other", default="default")() == "default"

    CLIARGS = CLIArgs({"key": ["v", "a", "l", "u", "e"]})
    assert cliargs_deferred_get("key", shallowcopy=True)() == ["v", "a", "l", "u", "e"]
    assert cliargs_deferred_get("key", shallowcopy=False)() == ["v", "a", "l", "u", "e"]

# Generated at 2022-06-10 23:03:42.662262
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': 'bar'})
    fetch1 = cliargs_deferred_get('foo')
    fetch2 = cliargs_deferred_get('foo')
    assert fetch1() == fetch2()



# Generated at 2022-06-10 23:03:47.136766
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def inner(key, default=None, shallowcopy=False):
        global CLIARGS
        CLIARGS = CLIArgs({'a': 2, 'b': [1, 2, 3], 'c': {'foo': 'bar'}, 'd': {1, 2, 3}})
        return cliargs_deferred_get(key, default, shallowcopy)()

    assert inner('a') == 2
    assert inner('b') == [1, 2, 3]
    assert inner('b', []) == [1, 2, 3]
    assert inner('b', shallowcopy=True) == [1, 2, 3]
    assert inner('b', default=[], shallowcopy=True) == [1, 2, 3]
    assert inner('c') == {'foo': 'bar'}

# Generated at 2022-06-10 23:03:56.527395
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'

    assert cliargs_deferred_get('foo')() is CLIARGS['foo']
    assert cliargs_deferred_get('foo', default='default')() is CLIARGS['foo']
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='default')() == 'default'
    assert cliargs_deferred_get('baz', default=[1, 2, 3])() == [1, 2, 3]

    CLIARGS['list'] = [1, 2, 3]
    assert cliargs_deferred_get('list', shallowcopy=True)() is not CLIARGS['list']
    assert cliargs_deferred_get('list', shallowcopy=True)() == CLI

# Generated at 2022-06-10 23:04:06.180039
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    import random
    import string
    import unittest

    class TestCliargsDeferredGet(unittest.TestCase):
        def test_variable_types(self):
            cli_args_dict = {}
            cli_args_dict['bool'] = [True, False]
            cli_args_dict['int'] = [random.randint(1, 100), random.randint(1, 100)]
            cli_args_dict['float'] = [random.random(), random.random()]
            cli_args_dict['string'] = [''.join(random.choice(string.ascii_letters) for _ in range(10)),
                                       ''.join(random.choice(string.ascii_letters) for _ in range(10))]
            cli_args_dict['dict']

# Generated at 2022-06-10 23:04:18.954460
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    from ansible.module_utils.common._collections_compat import Mapping, Set

    global CLIARGS
    test_dict = dict(
        test_default=dict(
            key='bar',
            default='default',
        ),
        test_undefined=dict(
            key='baz',
            default='undefined',
        ),
        test_mapping=dict(
            key='mapping',
            default=dict(),
        ),
        test_sequence=dict(
            key='sequence',
            default=list(),
        )
    )
    test_data = dict(
        bar='bar',
        mapping=dict(foo='bar'),
        sequence=['foo', 'bar']
    )

    CLIARGS = CLIArgs(copy.copy(test_data))

# Generated at 2022-06-10 23:04:27.452743
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Set up test
    import mock
    import sys

    with mock.patch.object(sys, 'argv', ['ansible-playbook', '-i', 'localhost', '-e', 'ansible_forks=42', 'playbook.yml']):
        from ansible.cli import CLI
        cli = CLI(['ansible-playbook', '-i', 'localhost', '-e', 'ansible_forks=42', 'playbook.yml'])
        cli.parse()
        _init_global_context(cli.options)

    assert cliargs_deferred_get('cheese') is None
    assert cliargs_deferred_get('cheese', default='cheddar') == 'cheddar'
    assert cliargs_deferred_get('forks') == 42
    assert cliargs

# Generated at 2022-06-10 23:04:37.876665
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.six import PY3

    # test a simple int value
    y = 5
    x = cliargs_deferred_get('key', y)
    assert x() == 5
    assert x() is y
    y = 6
    assert x() == 5

    # Make sure a copy is made when requested
    data = [1, 2, 3, 4]
    x = cliargs_deferred_get('key', data, shallowcopy=True)
    assert x() == data
    assert x() is not data
    data[1] = 20
    assert x() == [1, 2, 3, 4]
    if PY3:
        data.append(5)
        assert x() == [1, 2, 3, 4]

    # Make sure a deepcopy was not made when requested
   

# Generated at 2022-06-10 23:04:38.552711
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-10 23:04:55.255698
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Verify that cliargs_deferred_get works as expected"""
    from ansible.module_utils.common.collections import is_collection

    # new in python 3.3
    def is_sequence(obj):
        return isinstance(obj, (list, tuple))

    global CLIARGS
    CLIARGS = CLIArgs({})
    get_empty_iterator = cliargs_deferred_get('empty_iterator')
    get_empty_dict = cliargs_deferred_get('empty_dict')
    get_empty_list = cliargs_deferred_get('empty_list')
    get_empty_set = cliargs_deferred_get('empty_set')
    get_empty_user_string = cliargs_deferred_get('empty_user_string')
    get_empty_host_

# Generated at 2022-06-10 23:05:06.727664
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test ``cliargs_deferred_get()``"""

    # test the no-default case
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', shallowcopy=True)() is None

    # test the default case
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'


# Generated at 2022-06-10 23:05:15.251407
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Global():
        pass

    global CLIARGS
    global_ = Global()
    global_.COMMAND_NAME = 'a command'
    global_.CLIARGS = CLIARGS = CLIArgs({'global': 'global', 'command': 'command'})
    test_cliargs_deferred_get.__globals__['global'] = global_

    def check_default(key, default=None, shallowcopy=False):
        assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == default

    def check_value(key, value, shallowcopy=False):
        assert cliargs_deferred_get(key, default=None, shallowcopy=shallowcopy)() == value

    def check_shallow(key, expected, shallowcopy=True):
        assert cliargs

# Generated at 2022-06-10 23:05:22.662102
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.context_objects import CliArgs
    # Test that we succeed in getting a value
    cliargs = CliArgs({'ANSIBLE_FOO': 'FOO'})
    deferred_value = cliargs_deferred_get('ANSIBLE_FOO', default=None)()
    assert deferred_value == 'FOO'
    # Test that we get the default value when it's different from None
    deferred_value = cliargs_deferred_get('BAR', default='BAR')()
    assert deferred_value == 'BAR'
    # Test that we skip the default value when it's None
    deferred_value = cliargs_deferred_get('BAR')()
    assert deferred_value is None
    # Test that we get

# Generated at 2022-06-10 23:05:34.642059
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.context_objects import GlobalCLIArgs

    _init_global_context({'foo': 'foo-value', 'bar': 'bar-value'})
    actual = cliargs_deferred_get('foo')()
    assert actual == 'foo-value'

    actual = cliargs_deferred_get('baz')()
    assert actual == None

    actual = cliargs_deferred_get('baz', default='default-value')()
    assert actual == 'default-value'

    actual = cliargs_deferred_get('bar', shallowcopy=True)()
    assert actual == 'bar-value'
    assert actual is not CLIARGS['bar']

    CLIARGS = CLIARGS.copy()

# Generated at 2022-06-10 23:05:41.557020
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    value = 'bar'
    value_copy = 'baz'
    CLIARGS['foo'] = value
    G = cliargs_deferred_get('foo')
    assert G() is value

    G = cliargs_deferred_get('foo', shallowcopy=True)
    assert G() is value

    CLIARGS['foo'] = [value, value]
    value_copy = [value_copy, value_copy]
    G = cliargs_deferred_get('foo', shallowcopy=True)
    assert G() == value_copy

# Generated at 2022-06-10 23:05:47.502584
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function ``cliargs_deferred_get``"""
    from ansible.module_utils.common import FieldAttribute

    # Single Value Defaults
    assert cliargs_deferred_get('foo')(), FieldAttribute(cliargs_deferred_get('foo'))()

# Generated at 2022-06-10 23:05:58.125171
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Note: The test will implicitly test the check that the returned
    # ``CLIARGS`` object is a singleton.  Since we are setting ``CLIARGS``
    # before the test, that means that the global ``CLIARGS`` will be
    # overwritten, which won't happen in a non-test environment

    args_dict = {'foo': 'bar'}
    # Create a getter for the CLIARGS value for 'foo'
    getter = cliargs_deferred_get('foo')

    value = getter()
    assert value == 'bar'

    args_dict['foo'] = 'baz'
    # The getter should have cached the value originally at 'foo'
    assert getter() == 'bar'

    # Change the args_dict to have a value that is mutable

# Generated at 2022-06-10 23:06:06.357315
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    global CLIARGS

# Generated at 2022-06-10 23:06:12.695001
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update(dict(a=1, b=dict(c=2)))
    assert cliargs_deferred_get('a')(), 1
    assert cliargs_deferred_get('b')(), {'c': 2}
    assert cliargs_deferred_get('c')(), None

    # Test shallow copy
    assert cliargs_deferred_get('a', shallowcopy=True)(), 1
    assert cliargs_deferred_get('b', shallowcopy=True)(), {'c': 2}
    CLIARGS['b']['c'] = 3
    assert cliargs_deferred_get('b', shallowcopy=True)(), {'c': 3}

# Generated at 2022-06-10 23:06:31.221377
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    CLIARGS = CLIArgs({'foo': 'bar'})
    shallowcopy_value = cliargs_deferred_get('foo', shallowcopy=True)()
    assert shallowcopy_value == 'bar'
    assert not isinstance(shallowcopy_value, str)

    CLIARGS = CLIArgs({'foo': 'bar'})
    shallowcopy_value = cliargs_deferred_get('foo', default='baz', shallowcopy=True)()
    assert shallowcopy_value == 'bar'

# Generated at 2022-06-10 23:06:43.402684
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Initialize.  Make sure the default is not on the class
    class CliArgs(CLIArgs):
        foo = cliargs_deferred_get('foo', default='bar')
    CLIARGS = CliArgs({})
    assert CLIARGS.get('foo') == 'bar'

    # Change the value of foo
    CLIARGS = CLIArgs({'foo': 'bat'})
    assert CLIARGS.get('foo') == 'bat'

    # Make sure we can delete the default
    CLIARGS = CLIArgs({'foo': 'bleh'})
    del CLIARGS.foo
    assert CLIARGS.get('foo') is None
    CLIARGS = CliArgs({})
    assert CLIARGS.get('foo') == 'bar'

    # Make sure shallowcopy works

# Generated at 2022-06-10 23:06:54.546989
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foobar': 'default'})
    assert cliargs_deferred_get('foobar')() is CLIARGS.foobar
    assert cliargs_deferred_get('foobar', default=1)() == 1
    CLIARGS_FOO = cliargs_deferred_get('foobar', default=1)
    CLIARGS = CLIArgs({'foobar': 'alternate'})
    assert CLIARGS_FOO() is not CLIARGS.foobar
    assert CLIARGS_FOO() == 1
    CLIARGS = CLIArgs({'foobar': ('a', 'b')})
    CLIARGS_FOO = cliargs_deferred_get('foobar', shallowcopy=True)
    assert CLIARGS_FOO() is not CLI

# Generated at 2022-06-10 23:07:01.920969
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def my_test_function():
        value = cliargs_deferred_get('not_there', default=2.5)()
        assert value == 2.5

        CLIARGS['not_there'] = 3.5

        value = cliargs_deferred_get('not_there', default=2.5)()
        assert value == 3.5

        value = cliargs_deferred_get('not_there', default=2.5, shallowcopy=True)()
        assert value == 3.5


    my_test_function()

# Generated at 2022-06-10 23:07:08.703956
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=function-redefined, redefined-outer-name
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default='frobnicate')() == 'bar'
    assert cliargs_deferred_get('frobnicate', default='frobnicate')() == 'frobnicate'
    assert cliargs_deferred_get('frobnicate', default='frobnicate', shallowcopy=True)() == 'frobnicate'
    CLIARGS.update({'frobnicate': {'frob': 'nicate'}})
    assert cliargs_deferred_get('frobnicate', default='frobnicate', shallowcopy=True)

# Generated at 2022-06-10 23:07:19.076444
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import random
    from ansible.module_utils.common.collections import is_sequence

    cliargs_list = (
        (random.choice(list(range(10))),),
        (random.choice(list(range(10))), True),
    )
    for args, kwargs in cliargs_list:
        _init_global_context({})
        assert cliargs_deferred_get(*args, **kwargs)() is None
        CLIARGS['test_key'] = 'test_value'
        assert cliargs_deferred_get(*args, **kwargs)() == 'test_value'

        test_list = list(range(10))
        CLIARGS['test_list'] = test_list
        assert is_sequence(cliargs_deferred_get(*args, **kwargs)())

# Generated at 2022-06-10 23:07:28.083838
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''
    Test cliargs_deferred_get
    '''
    _init_global_context(dict(a=1))
    assert callable(cliargs_deferred_get('a', default=2))
    assert cliargs_deferred_get('a', default=2)() == 1
    assert cliargs_deferred_get('b', default=2)() == 2
    assert cliargs_deferred_get('a', default=2, shallowcopy=True)() == 1
    assert cliargs_deferred_get('b', default=2, shallowcopy=True)() == 2

# Generated at 2022-06-10 23:07:34.801580
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-10 23:07:45.375573
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def utils_module_args():
        """Return the module_args passed to a CLI command"""
        return cliargs_deferred_get('module_args')

    cliargs = {'verbosity': 4}

    # Test defaults
    _init_global_context(cliargs)
    assert utils_module_args() is None

    # Test value replacement
    cliargs['module_args'] = 'a=1'
    _init_global_context(cliargs)
    assert utils_module_args() == 'a=1'

    # Test shallow copies
    cliargs['module_args'] = {'a': 1}
    _init_global_context(cliargs)
    x = utils_module_args()
    assert x == {'a': 1}

# Generated at 2022-06-10 23:07:53.642132
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get context."""
    global CLIARGS

    # test with a key that doesn't exist
    def_get = cliargs_deferred_get('foo')
    assert def_get() is None
    CLIARGS.update(foo=13)
    assert def_get() == 13

    # test with a key that exists and has a default
    def_get = cliargs_deferred_get('baz', default=99)
    assert def_get() == 99
    CLIARGS.update(baz=13)
    assert def_get() == 13

# Generated at 2022-06-10 23:08:21.260172
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'host_key_checking': False})
    inner = cliargs_deferred_get('host_key_checking')

    assert not inner()
    assert isinstance(inner(), bool)

    CLIARGS = CLIArgs({'host_key_checking': True})
    assert inner()
    assert isinstance(inner(), bool)

    # Test that this works with None as well and doesn't convert to False
    CLIARGS = CLIArgs({'host_key_checking': None})
    assert inner() is None
    assert isinstance(inner(), type(None))

    CLIARGS = CLIArgs({})
    assert inner() is None
    assert isinstance(inner(), type(None))

    # Test that the default can be specified and works as expected
    inner = cliargs_deferred_

# Generated at 2022-06-10 23:08:32.658495
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test simple value
    _init_global_context({'debug': 1})
    assert cliargs_deferred_get('debug')() == 1
    assert cliargs_deferred_get('debug', default=2)() == 1

    # Test default value
    assert cliargs_deferred_get('verbose', default=2)() == 2

    # Test value type
    _init_global_context({'role_path': '/ansible/roles:/tmp/roles'})
    assert cliargs_deferred_get('role_path')() == '/ansible/roles:/tmp/roles'

    # Test shallowcopy
    _init_global_context({'roles_path': ['/ansible/roles', '/tmp/roles']})

# Generated at 2022-06-10 23:08:42.590215
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    assert cliargs_deferred_get('this_key_does_not_exist')() is None
    _init_global_context({'this_key_does_not_exist': 'somevalue'})
    assert cliargs_deferred_get('this_key_does_not_exist')() == 'somevalue'
    _init_global_context({'this_key_does_not_exist': ['somevalue']})
    assert cliargs_deferred_get('this_key_does_not_exist')() == ['somevalue']
    assert cliargs_deferred_get('this_key_does_not_exist', shallowcopy=True)() == ['somevalue']
    not_equal = cliargs_deferred_get('not_equal')()

# Generated at 2022-06-10 23:08:53.711696
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Test the usage of the closure like a decorator
    @cliargs_deferred_get('--foo')
    def foo_default():
        return 'default'

    # Test the usage of the closure via explicit call
    def bar_default():
        return 'default'

    CLIARGS = GlobalCLIArgs.from_options({'foo': 'value'})
    assert foo_default() == 'value'
    assert cliargs_deferred_get('foo', default=bar_default)() == 'value'
    CLIARGS = CLIArgs({})
    assert foo_default() == 'default'
    assert cliargs_deferred_get('foo', default=bar_default)() == 'default'

# Generated at 2022-06-10 23:09:03.340257
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    global CLIARGS
    orig_cliargs = CLIARGS

# Generated at 2022-06-10 23:09:12.975556
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import datetime

    global CLIARGS
    CLIARGS = CLIArgs({})

    def assertNoCliargs():
        assert cliargs_deferred_get('key') is None
        assert cliargs_deferred_get('key', default='foo') == 'foo'
        assert cliargs_deferred_get('key', shallowcopy=True) is None
        assert cliargs_deferred_get('key', default='foo', shallowcopy=True) == 'foo'
        assert cliargs_deferred_get('key', shallowcopy=True, default='foo') == 'foo'

    assertNoCliargs()

    CLIARGS = CLIArgs({'key': 'val'})

    def assertNormal():
        assert cliargs_deferred_get('key') == 'val'
        assert cliargs_deferred

# Generated at 2022-06-10 23:09:22.281395
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    global CLIARGS

# Generated at 2022-06-10 23:09:30.481992
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = ['one', 'two', 'three']
    assert cliargs_deferred_get('foo')() == ['one', 'two', 'three']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['one', 'two', 'three']
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', 'other')() == 'other'
    assert cliargs_deferred_get('bar', shallowcopy=True)() == 'other'


# Generated at 2022-06-10 23:09:36.093826
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MockCLIArgs(Mapping):
        def __init__(self, *args, **kwargs):
            self._dict = dict(*args, **kwargs)

        def __len__(self):
            return len(self._dict)

        def __getitem__(self, key):
            return self._dict.__getitem__(key)

        def __iter__(self):
            return iter(self._dict)

    global CLIARGS

# Generated at 2022-06-10 23:09:45.041399
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''Tests that the closure over getting a key from CLIARGS with shallow copy and deferred execution works'''
    context = {'key1': ['foo', 'bar'], 'key2': {'hello': 'world', 'number': 42}}
    value = cliargs_deferred_get('key1')
    assert value() is None
    context['key1'] = 'exit_code'
    value = cliargs_deferred_get('key1')
    assert value() == 'exit_code'
    value = cliargs_deferred_get('key3', 'default')
    assert value() == 'default'
    value = cliargs_deferred_get('key3', 'default', True)
    assert value() == 'default'
    value = cliargs_deferred_get('key2', 'default', True)

# Generated at 2022-06-10 23:10:31.516335
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options(dict(
        list_tasks=True,
        vvv=2,
        verbosity=True,
        extra_vars=[],
        extra_vars_dict={},
        check=True,
        limit='all',
        diff=False,
    ))

    test_list = cliargs_deferred_get('extra_vars', [1, 2, 3])
    test_dict = cliargs_deferred_get('extra_vars_dict', dict(a=1, b=2))
    test_bool = cliargs_deferred_get('check', False)
    test_list_copy = cliargs_deferred_get('extra_vars', [1, 2, 3], shallowcopy=True)
    test

# Generated at 2022-06-10 23:10:39.519738
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    assert cliargs_deferred_get('foo', {'foo': 1, 'bar': 2})() == {'foo': 1, 'bar': 2}
    assert cliargs_deferred_get('foo', Set((1, 2, 3)))() == Set((1, 2, 3))
    assert cliargs_deferred_get('foo', ['foo', 'bar', 'baz'])() == ['foo', 'bar', 'baz']
    CLIARGS = CLIArgs({'foo': 1})
    assert cliargs_deferred_get('foo', 'bar')() == 1
    CLIARGS = CLIArgs({'foo': ['foo', 'bar', 'baz']})
    assert cliargs_def

# Generated at 2022-06-10 23:10:49.834677
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    d = {'a': 42}
    CLIARGS = CLIArgs(d)
    assert cliargs_deferred_get('a')() == 42
    assert cliargs_deferred_get('b')() is None
    assert cliargs_deferred_get('b', default='foo')() == 'foo'
    assert cliargs_deferred_get('a', shallowcopy=True)() == 42
    a_list = ['bar']
    d['a'] = a_list
    assert cliargs_deferred_get('a', shallowcopy=True)() is not a_list
    assert cliargs_deferred_get('a', shallowcopy=True)() == a_list

# Generated at 2022-06-10 23:10:54.499558
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS_TEST = CLIArgs({'foo': 'bar'})
    val = cliargs_deferred_get('foo')(CLIARGS_TEST)
    assert val == 'bar'
    val = cliargs_deferred_get('foo')(CLIARGS_TEST)
    assert val == 'bar'

# Generated at 2022-06-10 23:11:03.283328
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIArgs

    # CLIARGS is a singleton and `GlobalCLIArgs` should be a descriptor that creates the
    # singleton automatically
    assert not isinstance(CLIARGS, GlobalCLIArgs)
    # test the basic case
    cliargs_deferred_get(key='connection', default='local')()
    # test the case where the value is a shallow copy
    cliargs_deferred_get(key='connection', default='local', shallowcopy=True)()
    # test the case where the value is a deep copy
    cliargs_deferred_get(key='connection', default='local', shallowcopy=False)()

# Generated at 2022-06-10 23:11:06.501237
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'
    deferred_get = cliargs_deferred_get('foo', 'bla')
    assert(deferred_get() == 'bar')
    del CLIARGS['foo']
    assert(deferred_get() == 'bla')

# Generated at 2022-06-10 23:11:17.162152
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.stdin_data = '{"0" : "zero"}'
    CLIARGS.args = 'one'
    assert cliargs_deferred_get('stdin_data')() == {'0': 'zero'}
    assert cliargs_deferred_get('args')() == 'one'

    CLIARGS.stdin_data = ['zero', 'one', 'two']
    CLIARGS.args = ['three', 'four']
    assert cliargs_deferred_get('stdin_data', shallowcopy=True)() == ['zero', 'one', 'two']
    assert cliargs_deferred_get('stdin_data', shallowcopy=False)() == ['zero', 'one', 'two']

# Generated at 2022-06-10 23:11:29.764384
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    class Options:
        test1 = None

    def init_context(options):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(options)

    # Test getting a default, this is what will be done all the time
    options = Options()
    cliargs_deferred_get('test1', default=True)()
    assert True

    # Test getting a value from CLIARGS
    options = Options()
    options.test1 = True
    init_context(options)
    assert cliargs_deferred_get('test1', default=False)()

    # Test getting None from CLIARGS.  Should return the default
    options = Options()
    options.test1 = None
    init_context(options)

# Generated at 2022-06-10 23:11:38.841941
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from copy import copy
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch.object(CLIARGS, '_cli_options', {'value': 'foobar'}):
        for value in ('foobar', b'foobar', u'foobar'):
            assert cliargs_deferred_get('value')() == value
            assert cliargs_deferred_get('value', shallowcopy=True)() == value


# Generated at 2022-06-10 23:11:47.390866
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function to ensure cliargs works after CLIARGS is replaced."""

    # Create a context and save it
    ctx = CLIArgs({'foo': 'bar'})
    test_cliargs_deferred_get.ctx = ctx

    # Create a new context and overwrite CLIARGS
    ctx2 = CLIArgs({'baz': 'qux'})
    globals()['CLIARGS'] = ctx2

    # Use the function to get back the original context
    assert cliargs_deferred_get('foo')() == 'bar'