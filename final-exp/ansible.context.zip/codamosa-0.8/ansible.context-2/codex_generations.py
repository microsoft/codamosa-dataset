

# Generated at 2022-06-10 23:02:13.225823
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function for cliargs_deferred_get"""
    from ansible.module_utils.common._collections_compat import MutableMapping
    import copy
    import pickle
    class MutableSet(MutableMapping):
        def __init__(self, items=None):
            self._items = set(items) if items else set()
            self._items_ref = set(self._items)

        @property
        def changed(self):
            return self._items != self._items_ref

        def __contains__(self, item):
            return item in self._items

        def __iter__(self):
            return iter(self._items)

        def __len__(self):
            return len(self._items)

        def __getitem__(self, item):
            return self._items[item]

# Generated at 2022-06-10 23:02:20.597458
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it handles empty cliargs
    old_context = CLIARGS
    try:
        CLIARGS = CLIArgs({})
        # Test multiple calls of the function to ensure the closure works
        f = cliargs_deferred_get("test", default="test_default")
        assert f() is CLIARGS.get("test", default="test_default")
        assert f() is CLIARGS.get("test", default="test_default")
    finally:
        CLIARGS = old_context



# Generated at 2022-06-10 23:02:31.331912
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the global variable is used
    CLIARGS['foo'] = 42
    assert cliargs_deferred_get('foo')() == 42

    # Test that the default is returned
    assert cliargs_deferred_get('bar', 42)() == 42

    # Test sequences and mappings are shallow copied
    CLIARGS['seq'] = [1, 2, 3]
    assert cliargs_deferred_get('seq', shallowcopy=True)() == [1, 2, 3]
    CLIARGS['map'] = {'one': 1, 'two': 2}
    assert cliargs_deferred_get('map', shallowcopy=True)() == {'one': 1, 'two': 2}

    # Test that you can override the default with shallowcopy

# Generated at 2022-06-10 23:02:42.138858
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable, unused-argument
    import pytest

    test_data = [
        ('key1', 'default1'),
        ('key2', 'default2'),
        ('key1', 'default1'),
        ('key3', 'default3'),
    ]

    # pylint: disable=invalid-name
    class TestContext:
        """Test context object to return the next value from test_data in get()"""

        def __init__(self):
            self.index = 0

        def get(self, key, default):
            retval = dict(test_data)[key]
            assert retval == test_data[self.index][1]
            assert default is None
            self.index += 1
            return retval

    global CLIARGS
    context = TestContext()
    CLI

# Generated at 2022-06-10 23:02:50.281673
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import MutableMapping, Mapping
    from ansible.module_utils.common.collections import is_sequence
    global CLIARGS
    CLIARGS = CLIArgs({'key1': 1, 'key2': [2, 3], 'key3': {4: 5}, 'key4': {6, 7}, 'key5': MutableMapping(), 'key6': Mapping()})
    assert cliargs_deferred_get('key1')() == 1
    assert cliargs_deferred_get('key2')() == [2, 3]
    assert cliargs_deferred_get('key3')() == {4: 5}
    assert cliargs_deferred_get('key4')() == {6, 7}
    # These types of collections are

# Generated at 2022-06-10 23:03:02.917866
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get closure"""
    import pytest
    from ansible.module_utils.common._collections_compat import OrderedDict # pylint: disable=import-error
    cliargs = CLIArgs({'a': 1, 'b': '2', 'c': [3, 3, 3], 'd': {'bar': True}})
    assert cliargs_deferred_get('a')(cliargs) == 1
    assert cliargs_deferred_get('b')(cliargs) == '2'
    assert cliargs_deferred_get('c')(cliargs) is cliargs['c']
    assert cliargs_deferred_get('c')(cliargs) == [3, 3, 3]

# Generated at 2022-06-10 23:03:07.326816
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'
    foo = cliargs_deferred_get('foo')
    assert foo == 'bar'

    CLIARGS['foo'] = None
    foo = cliargs_deferred_get('foo', default=42)
    assert foo == 42

# Generated at 2022-06-10 23:03:17.387066
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import copy
    import pytest
    from ansible.module_utils.common.context_objects import CliArgs

    @pytest.fixture(params=(True, False))
    def cliargs(request):
        """Fixture to create CLI args"""
        shallowcopy = request.param
        return Cliargs({'test': 'value', 'deepcopy': ['test', 'values']},
                       lambda: copy.deepcopy if not shallowcopy else copy.copy)


# Generated at 2022-06-10 23:03:27.982138
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _assert_equal(key, value, default=None, shallowcopy=False):
        assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == value

    _assert_equal('diff', True)
    _assert_equal('diff', True, shallowcopy=True)
    _assert_equal('diff', False)
    _assert_equal('diff', False, shallowcopy=True)

    _assert_equal('verbosity', 1)
    _assert_equal('verbosity', 1, shallowcopy=True)
    _assert_equal('verbosity', 99)
    _assert_equal('verbosity', 99, shallowcopy=True)

    _assert_equal('foo', 'foo', default='foo')
    _assert_equal('foo', 'foo', default='foo', shallowcopy=True)
   

# Generated at 2022-06-10 23:03:37.667512
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo')() is None
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo', default='blah')() == ['bar', 'baz']

# Generated at 2022-06-10 23:03:45.370052
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('nothing_there')() is None
    assert cliargs_deferred_get('nothing_there', default=1)() == 1
    assert cliargs_deferred_get('nothing_there', default=[])() == []
    assert cliargs_deferred_get('nothing_there', default=set())() == set()

    CLIARGS['foo'] = 42
    assert cliargs_deferred_get('foo')() == 42

    CLIARGS['bar'] = 'foo'
    assert cliargs_deferred_get('bar')() == 'foo'

    CLIARGS['baz'] = ['foo', 42]
    assert cliargs_deferred_get('baz')() == ['foo', 42]

    CLIARGS['qux'] = set(['foo', 42])

# Generated at 2022-06-10 23:03:55.753768
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # set CLIARGS to an empty dict
    CLIARGS = CLIArgs({})

    assert cliargs_deferred_get('no_such_key', default=42)() == 42
    assert cliargs_deferred_get('no_such_key', default=[1,2])() == [1,2]
    assert cliargs_deferred_get('no_such_key', default=[1,2], shallowcopy=True)() == [1,2]

    l = [1,2]
    CLIARGS = CLIArgs({'some_key': l})
    assert cliargs_deferred_get('some_key', default=42)() == l
    assert cliargs_deferred_get('some_key', default=[1,2])() == l
    assert cliargs_def

# Generated at 2022-06-10 23:04:02.330611
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Let us make sure that the closure doesn't just return the default
    cliargs_deferred_get('noexist', default='foo')()
    # Now let's make sure that it returns the CLIARGS value if it exists
    # Note: *not* a singleton!
    CLIARGS['thing'] = 'bar'
    assert cliargs_deferred_get('thing', 'foo')() == 'bar'

# Generated at 2022-06-10 23:04:13.095528
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def set_cliargs(cliargs):
        global CLIARGS
        CLIARGS = cliargs

    class FakeCliArgs(object):
        def __init__(self, **kwargs):
            self.options = kwargs

        def get(self, *args, **kwargs):
            return self.options.get(*args, **kwargs)

        def __getattr__(self, key):
            return self.get(key)

    assert cliargs_deferred_get('foo')('a', 'b') == 'a'
    assert cliargs_deferred_get('foo')('a', default='b') == 'b'
    set_cliargs(FakeCliArgs(foo='c'))

# Generated at 2022-06-10 23:04:24.537895
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Note: testing is done against CLIARGS because CLIARGS.get is bound to
    # "self" when it is called

    class Test(object):
        arg1 = cliargs_deferred_get('test', default=1)
        arg2 = cliargs_deferred_get('test', default=2, shallowcopy=True)

    _init_global_context({'test': 1})
    test = Test()
    assert test.arg1 == 1
    assert test.arg2 == 1

    class Test(object):
        arg1 = cliargs_deferred_get('test2', default=1)
        arg2 = cliargs_deferred_get('test2', default=2, shallowcopy=True)

    _init_global_context({})
    test = Test()
    assert test.arg1 == 1

# Generated at 2022-06-10 23:04:35.482557
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    def _test_get_default():
        return {}

    def test(args, expected_default, expected_non_default, expected_with_copy):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(args)
        assert cliargs_deferred_get('abc', default=_test_get_default) == expected_default
        assert cliargs_deferred_get('def', default=_test_get_default) == expected_non_default
        assert cliargs_deferred_get('def', default=_test_get_default, shallowcopy=True) == expected_with_copy

    test({'abc': ''}, {}, None, None)
    test({'def': 'foo'}, None, 'foo', 'foo')

# Generated at 2022-06-10 23:04:43.032603
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Simple tests for ``cliargs_deferred_get``"""
    import copy

    test_cli_args = {'one': 1, 'two': [2], 'three': {'a': 'a', 'b': 'b'}, 'four': set((1, 1))}
    test_cli_args_copy = copy.deepcopy(test_cli_args)
    for key in test_cli_args:
        assert cliargs_deferred_get(key)() is None
        assert test_cli_args_copy == test_cli_args

    _init_global_context(test_cli_args)
    for key in test_cli_args:
        assert cliargs_deferred_get(key)() == test_cli_args[key]

    # test shallowcopy functionality

# Generated at 2022-06-10 23:04:55.221216
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get(): # pylint: disable=unused-argument,missing-docstring
    import pytest
    from ansible.module_utils.cli_options import ConnectionOptions

    _init_global_context({'connection': 'local'})
    assert cliargs_deferred_get('connection') == 'local'
    assert cliargs_deferred_get('inventory') == ConnectionOptions.DEFAULT.inventory
    assert cliargs_deferred_get('inventory_hostname') == ConnectionOptions.DEFAULT.inventory_hostname
    assert cliargs_deferred_get('module_path') == ConnectionOptions.DEFAULT.module_path
    assert cliargs_deferred_get('forks') == ConnectionOptions.DEFAULT.forks
    assert cliargs_deferred_get('become') == ConnectionOptions.DEFAULT.become
    assert cli

# Generated at 2022-06-10 23:05:06.670890
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from collections import OrderedDict
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-10 23:05:09.921248
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'

    get = cliargs_deferred_get('foo')
    assert get() == 'bar'

    get = cliargs_deferred_get('missing', 'default')
    assert get() == 'default'

# Generated at 2022-06-10 23:05:24.144520
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # No nested function calls so we can test it

    # Test with CLIARGS.get returning  None
    orig_cliargs = CLIARGS
    try:
        CLIARGS = CLIArgs({'foo': None})
        none_default = cliargs_deferred_get('foo')()
        assert none_default is None
    finally:
        CLIARGS = orig_cliargs

    # Test with a default
    try:
        CLIARGS = CLIArgs({})
        default = cliargs_deferred_get('foo', default='bar')()
        assert default == 'bar'
    finally:
        CLIARGS = orig_cliargs

    # Test with a shallow copy of a regular value

# Generated at 2022-06-10 23:05:36.187372
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Check that the cliargs_deferred_get function works as expected"""
    # The first test is always to make sure we actually have the function
    try:
        cliargs_deferred_get
    except NameError:
        raise AssertionError('cliargs_deferred_get function not defined')

    from ansible.module_utils._text import to_bytes, to_text
    from tempfile import TemporaryDirectory

    # Unit tests for this function
    with TemporaryDirectory() as tmpdir:
        tmploc = to_bytes(tmpdir)


# Generated at 2022-06-10 23:05:43.127302
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('invalidkey') is None
    assert cliargs_deferred_get('invalidkey', default='somevalue') == 'somevalue'

    assert cliargs_deferred_get('ssh_extra_args', default='somevalue') == 'somevalue'
    assert cliargs_deferred_get('ssh_extra_args', shallowcopy=True) == []

    assert cliargs_deferred_get('no_log', default='somevalue') == 'somevalue'
    assert cliargs_deferred_get('no_log', shallowcopy=True) == []

# Generated at 2022-06-10 23:05:53.757779
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'syslog_facility': 'foo', 'extravar': 'bar'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('syslog_facility') is cliargs_deferred_get('syslog_facility')
    assert cliargs_deferred_get('syslog_facility')['foo'] == 'foo'
    assert cliargs_deferred_get('extravar') is cliargs_deferred_get('extravar')
    assert cliargs_deferred_get('extravar')['bar'] == 'bar'
    assert cliargs_deferred_get('syslog_facility') is not cliargs_deferred_get('extravar')

# Generated at 2022-06-10 23:05:59.125433
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class GlobalCLIArgs(dict):
        @classmethod
        def from_options(cls, options):
            return cls(options)

        def __getattr__(self, key):
            return self[key]

    global CLIARGS

    cli_args = dict(foo='bar', baz=['x', 'y', 'z'])
    CLIARGS = GlobalCLIArgs.from_options(cli_args)

    zero = cliargs_deferred_get('foo')
    assert zero() is CLIARGS.foo

    one = cliargs_deferred_get('baz', shallowcopy=True)
    assert one() is not CLIARGS.baz
    assert one() == CLIARGS.baz
    assert isinstance(one(), list)

# Generated at 2022-06-10 23:06:09.963120
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs
    _cliar = CliArgs({})

    # Test the cases where the default is returned
    assert cliargs_deferred_get('not-here')() is None
    assert cliargs_deferred_get('not-here', 'foo')() == 'foo'

    # Test shallow copy functionality

# Generated at 2022-06-10 23:06:22.081940
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(a=1, b=[1, 2, 3], c={'key': 'value'}))
    get_a = cliargs_deferred_get('a')
    assert get_a() == 1
    get_b = cliargs_deferred_get('b', shallowcopy=True)
    assert get_b() == [1, 2, 3]
    assert id(get_b()) != id(get_b())
    get_c = cliargs_deferred_get('c', shallowcopy=True)
    assert get_c() == dict(key='value')
    assert id(get_c()) != id(get_c())

    def get_d():
        try:
            return CLIARGS['d']
        except KeyError:
            return 4

# Generated at 2022-06-10 23:06:23.951933
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    >>> _init_global_context({'my_option': 'my_value'})
    >>> assert cliargs_deferred_get('my_option')() == 'my_value'
    """

# Generated at 2022-06-10 23:06:35.716286
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    _init_global_context(CLIArgs({}))

    get_test_key = cliargs_deferred_get('test_key')
    assert get_test_key() is None
    CLIARGS['test_key'] = 'test_val'
    assert get_test_key() == 'test_val'
    assert get_test_key(default='test_default') == 'test_val'

    get_test_seq = cliargs_deferred_get('test_seq', shallowcopy=True)
    assert get_test_seq() is None
    CLIARGS['test_seq'] = [1, 2, 3, 4]
    assert get_test_seq() == [1, 2, 3, 4]
    assert get_test

# Generated at 2022-06-10 23:06:47.348873
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'test1': 100})
    assert callable(cliargs_deferred_get('test1', None))
    assert cliargs_deferred_get('test1', None)() == 100
    assert cliargs_deferred_get('test1', 10)() == 100
    assert cliargs_deferred_get('test2', 10)() == 10

    from copy import copy
    from ansible.module_utils.common.collections import is_sequence

    data = [1, 2, 3]
    assert cliargs_deferred_get('test1', data, shallowcopy=True)() is not data
    assert data == cliargs_deferred_get('test1', data, shallowcopy=True)()

# Generated at 2022-06-10 23:07:02.755070
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    field = dict(default=cliargs_deferred_get('param', default=10))
    CLIARGS['param'] = 100
    assert field['default']() == 100
    CLIARGS['param'] = [1, 2, 3]
    assert field['default']() == [1, 2, 3]
    CLIARGS['param'] = {'k1': 1, 'k2': 2}
    assert field['default']() == {'k1': 1, 'k2': 2}

    field = dict(default=cliargs_deferred_get('param', default=10, shallowcopy=False))
    CLIARGS['param'] = 100
    assert field['default']() == 100
    CLIARGS['param'] = [1, 2, 3]
    assert field['default']() == [1, 2, 3]
    CLI

# Generated at 2022-06-10 23:07:09.685259
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    foo = [1, 2, 3]
    CLIARGS.options = {'foo': foo}
    foo_deepcopy = cliargs_deferred_get('foo')()
    assert foo == foo_deepcopy
    foo_shallowcopy = cliargs_deferred_get('foo', shallowcopy=True)()
    assert foo == foo_shallowcopy
    foo.append(4)
    assert foo == foo_deepcopy
    assert foo != foo_shallowcopy

    bar = {1: 2, 3: 4}
    CLIARGS.options = {'bar': bar}
    bar_deepcopy = cliargs_deferred_get('bar')()
    assert bar == bar_deepcopy
    bar_shallowcopy = cliargs_deferred_get('bar', shallowcopy=True)()


# Generated at 2022-06-10 23:07:19.488507
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.set('foo', 'bar')
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('does_not_exist', default='baz')() == 'baz'
    assert cliargs_deferred_get('does_not_exist')() is None
    # shallowcopy True
    CLIARGS.set('foo', ['bar', 'baz'])
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', default=['bar', 'baz'], shallowcopy=True)() == ['bar', 'baz']
    CLIAR

# Generated at 2022-06-10 23:07:30.563395
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get

    This is not a member of the class ``CLIArgs`` because it is called before the class is
    initialized and it uses the global CLIARGS constant, which is not set at class initialization
    """
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('spam', 'ham')() == 'ham'
    CLIARGS = GlobalCLIArgs.from_options({'spam': 1})
    assert cliargs_deferred_get('spam', 2)() == 1
    assert cliargs_deferred_get('spam', 'ham')() == 1
    assert cliargs_deferred_get('eggs', 'ham')() == 'ham'

# Generated at 2022-06-10 23:07:40.487664
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils._text import to_native

    # Test that the inner function is a closure over the key and default
    inner = cliargs_deferred_get('foo', 'bar')
    assert inner() == 'bar'

    CLIARGS['foo'] = 'baz'
    assert inner() == 'baz'

    # Test that we can get the inner function after replacing CLIARGS
    CLIARGS = CLIArgs({})
    inner2 = cliargs_deferred_get('foo', 'bar')
    assert inner2() == 'bar'

    CLIARGS['foo'] = 'qux'
    assert inner2() == 'qux'

    # Test that an exception during retrieval of the deferred value is handled
    # properly

# Generated at 2022-06-10 23:07:51.041687
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(foo='bar', baz='xxxxx'))
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == 'xxxxx'

    _init_global_context(dict(foo='bar', baz='xxxxx'))
    assert cliargs_deferred_get('foo')() is CLIARGS.get('foo')
    assert cliargs_deferred_get('baz')() is CLIARGS.get('baz')

    _init_global_context(dict(foo=['bar'], baz='xxxxx'))
    assert cliargs_deferred_get('foo')(shallowcopy=True) == ['bar']

# Generated at 2022-06-10 23:07:59.639614
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_dict = dict(a=1, b=2, c=dict(d=1, e=2), e=[1,2,3])
    # Replace global singleton with dummy object
    global CLIARGS
    CLIARGS = CLIArgs(test_dict)

    # Test basic usage, returns expected value
    value = cliargs_deferred_get('c')()
    assert value == test_dict['c']

    # Test alternative default value, returns expected value
    value = cliargs_deferred_get('x', default='hello')()
    assert value == 'hello'

    # Test shallowcopy of dictionary, returns copy
    value = cliargs_deferred_get('c', shallowcopy=True)()
    assert value == test_dict['c']
    assert value is not test_dict['c']

    # Test

# Generated at 2022-06-10 23:08:11.511866
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    tests = [
        ('examplelist', [1, 2, 3]),
        ('examplelist', [1, 2, 3, 4], True),
        ('exampledict', {'foo': 'bar'}),
        ('exampledict', {'foo': 'bar'}, True),
        ('exampleset', {1, 2, 3}),
        ('exampleset', {1, 2, 3}, True),
        ('non-existent-key', ['default']),
    ]
    for test in tests:
        key, default, shallowcopy = test
        print("Testing {} {} {}".format(key, default, shallowcopy))
        # test object
        class A:
            foo = cliargs_deferred_get(key, default, shallowcopy)
        # set up context

# Generated at 2022-06-10 23:08:21.336851
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make sure that the function is not bound to any specific CLIARGS object
    inital_cliargs = CLIARGS

# Generated at 2022-06-10 23:08:32.735832
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    orig_cliargs = CLIARGS
    # Test without shallowcopy
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    blueprint1 = cliargs_deferred_get('foo', shallowcopy=False)
    blueprint2 = cliargs_deferred_get('foo', shallowcopy=False)
    assert blueprint1() is blueprint2()

    # Test with shallowcopy
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    blueprint1 = cliargs_deferred_get('foo', shallowcopy=True)
    blueprint2 = cliargs_deferred_get('foo', shallowcopy=True)
    assert blueprint1() is not blueprint2()
    assert blueprint1() == blueprint2()


# Generated at 2022-06-10 23:08:51.380007
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the function with a valid key
    global CLIARGS
    CLIARGS = CLIArgs({'ansible_version': 'testing_version'})
    assert cliargs_deferred_get('ansible_version')() == 'testing_version'
    assert cliargs_deferred_get('ansible_version', shallowcopy=True)() == 'testing_version'

    # Test the function with a key missing from CLIARGS
    assert cliargs_deferred_get('missing')() is None
    assert cliargs_deferred_get('missing', shallowcopy=True)() is None

    # Test the function with a default value present
    assert cliargs_deferred_get('missing', default='default')() == 'default'
    assert cliargs_deferred_get('missing', shallowcopy=True, default='default')

# Generated at 2022-06-10 23:09:00.427407
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable, missing-docstring
    class TestCLIArgs(CLIArgs):
        def __init__(self):
            self._args = dict(
                a_sequence=['item 1', 'item 2'],
                a_mapping={'item 1': 1, 'item 2': 2},
                a_set={'item 1', 'item 2'},
            )
        def get(self, key, default=None, shallowcopy=False):
            return self._args.get(key, default=default)

    cliargs_deferred_get.__globals__['CLIARGS'] = TestCLIArgs()

    # plain get should work
    assert cliargs_deferred_get('a_sequence')[0] == 'item 1'
    # with a default

# Generated at 2022-06-10 23:09:08.569247
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class cliargs_mock:
        def get(self, key, default=None):
            return {'key': 'value'}.get(key, default)

    global CLIARGS
    cliargs_orig = CLIARGS
    CLIARGS = cliargs_mock()

    assert cliargs_deferred_get('doesnotexist')() is None
    assert cliargs_deferred_get('doesnotexist', 'foobar')() == 'foobar'
    assert cliargs_deferred_get('key')() == 'value'

    CLIARGS = cliargs_orig

# Generated at 2022-06-10 23:09:18.192092
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that the closure cliargs_deferred_get works as a closure

    For reference, PEP 8 states 'There are many other conventions that find their way into
    Python code. Some have been formalized in PEP 8, but many more have not. A style guide
    is about consistency. Consistency within a project is more important. Consistency within
    one module or function is the most important'
    """
    from ansible.module_utils.six import PY2
    from copy import copy

    # Some test data
    testdict = {'foo': 'bar', 'fuzz': 'buzz'}
    testlist = ['foo', 'bar', 'fuzz', 'buzz']
    teststr = 'foobarfuzzbuzz'

    # If a sequence, always return a shallow copy
    shallowcopy_list = cliargs_

# Generated at 2022-06-10 23:09:28.827406
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the closure over global CLIARGS"""
    global CLIARGS

    # Make sure we can get the default value
    assert cliargs_deferred_get('foobar')(), 'Did not get the default value'

    # Make sure we can get non-shallow copy of keys in CLIARGS
    CLIARGS['foobar'] = 'ansible'
    assert cliargs_deferred_get('foobar')() == 'ansible', 'Did not get the correct value'

    # Make sure we can get shallow copy of sequence values
    CLIARGS['foobar'] = ['ansible', 'rocks']
    assert cliargs_deferred_get('foobar', shallowcopy=True)() == ['ansible', 'rocks'], 'Did not get the correct value'

    # Make sure we can get shallow copy of mapping/set

# Generated at 2022-06-10 23:09:41.662095
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    value = cliargs_deferred_get('foo')()
    assert value is None

    # Reinit the GlobalCLIArgs to be an actual object
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({'foo': 'bar'})
    value = cliargs_deferred_get('foo')()
    assert value == 'bar'
    value = cliargs_deferred_get('foo', shallowcopy=True)()
    assert value == 'bar'

    CLIARGS = GlobalCLIArgs.from_options({'foo': ['bar']})
    value = cliargs_deferred_get('foo')()
    assert value == ['bar']
    value = cliargs_deferred_get('foo', shallowcopy=True)()
    assert value == ['bar']

    CLIARGS = Global

# Generated at 2022-06-10 23:09:49.330826
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence, Mapping, Set

    test_values = (
        'asdf',
        {'a': 1, 'b': 2, 'c': 3},
        [1, 2, 3],
        ('a', 2, {'a': 1})
    )
    for v in test_values:
        globals()['CLIARGS'] = CLIArgs({1: v})
        inner = cliargs_deferred_get(1)
        value = inner()
        assert value == v
        assert value is not v

        globals()['CLIARGS'] = CLIArgs({1: v})
        inner = cliargs_deferred_get(1, shallowcopy=True)
        value = inner()
        assert value == v

# Generated at 2022-06-10 23:09:55.234106
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs
    assert cliargs_deferred_get('--verbose')() is None
    CLIARGS._store = CliArgs()
    CLIARGS['--verbose'] = 3
    assert cliargs_deferred_get('--verbose')() == 3



# Generated at 2022-06-10 23:10:01.221228
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    CLIARGS._data['foo'] = 'bar'
    parsed_cli_args = {'foo': 'baz'}
    _init_global_context(parsed_cli_args)
    value = cliargs_deferred_get('foo')()
    assert value == 'baz', 'Deferred get did not prefer global over local context'

# Generated at 2022-06-10 23:10:08.645550
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    input_cli_args = {'a_list': [1, 2, 3], 'a_dict': {'key': 'value'}}
    _init_global_context(input_cli_args)

    # Assert that shallowcopy works
    assert cliargs_deferred_get('a_list', shallowcopy=True)() == input_cli_args['a_list']
    assert cliargs_deferred_get('a_list', shallowcopy=True)() is not input_cli_args['a_list']
    assert cliargs_deferred_get('a_dict', shallowcopy=True)() == input_cli_args['a_dict']
    assert cliargs_deferred_get('a_dict', shallowcopy=True)() is not input_cli_args['a_dict']

    # Ass

# Generated at 2022-06-10 23:10:35.767936
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.config.constants
    from ansible.playbook.play_context import PlayContext

    cli_args = dict(connection='local', module_path=None, forks=10, remote_user=None,
                    private_key_file=None, ssh_common_args=None, ssh_extra_args=None,
                    sftp_extra_args=None, scp_extra_args=None, become=None, become_method=None,
                    become_user=None, verbosity=None, check=False, listhosts=None,
                    listtasks=None, listtags=None, syntax=None, diff=False, force_handlers=False)
    cli_args['module_path'] = [ansible.config.constants.DEFAULT_MODULE_PATH]


# Generated at 2022-06-10 23:10:47.127377
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    # Test
    assert cliargs_deferred_get('foo', default=None)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    CLIARGS = CLIArgs({'foo': 'bar'})
    # Test shallow copy
    assert cliargs_deferred_get('foo', default=None, shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-10 23:10:58.072061
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def assert_return(key, val, shallowcopy=False):
        assert cliargs_deferred_get(key, shallowcopy=shallowcopy)() is val

    CLIARGS.set_options({'foo': 'foo', 'bar': ['bar'], 'baz': {'baz': 'baz'}})

    assert_return('foo', 'foo')
    assert_return('bar', ['bar'])
    assert_return('baz', {'baz': 'baz'})
    assert_return('no_key', None)
    assert_return('no_key', 'default', shallowcopy=True) == 'default'

    # Check shallowcopy
    assert_return('foo', 'foo', shallowcopy=True) == 'foo'

# Generated at 2022-06-10 23:11:06.011944
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CliArgs(Mapping):
        def __init__(self, init_dict):
            self.__dict = init_dict

        def __getitem__(self, key):
            return self.__dict[key]

        def __iter__(self):
            return iter(self.__dict)

        def __len__(self):
            return len(self.__dict)

    def check(value, shallowcopy):
        global CLIARGS
        CLIARGS = CliArgs(value)

        if value is None:
            retrieved = cliargs_deferred_get('doesntexist', default=42, shallowcopy=shallowcopy)()
            assert retrieved == 42
        else:
            retrieved = cliargs_deferred_get('key', default=42, shallowcopy=shallowcopy)()

# Generated at 2022-06-10 23:11:16.703606
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    import copy

    global CLIARGS
    existing = CLIARGS.copy()

# Generated at 2022-06-10 23:11:29.317559
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_args = {'foo': 'bar', 'baz': None, 'bat': [1, 2, 3]}

    def set_up():
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(test_args)

    def test_key():
        set_up()
        inner = cliargs_deferred_get('foo')
        assert inner() == 'bar'

    def test_default():
        set_up()
        inner = cliargs_deferred_get('non_existant_arg', 'bat')
        assert inner() == 'bat'

    def test_shallowcopy_sequence():
        set_up()
        inner = cliargs_deferred_get('bat')
        bat = inner(shallowcopy=True)
        bat.append(4)
        assert inner()

# Generated at 2022-06-10 23:11:37.603062
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that deferred get works"""
    class Foo():
        bar = cliargs_deferred_get('bar')

    # Test that the default is returned when there's not connection
    assert Foo().bar == None

    # Test that the value is returned when it's set
    CLIARGS['bar'] = 1
    assert Foo().bar == 1
    CLIARGS['bar'] = 'a'
    assert Foo().bar == 'a'

    # Test that shallow copies are made when required
    CLIARGS['bar'] = [1, 2, 3]
    assert Foo().bar == [1, 2, 3]
    CLIARGS['bar'].append(4)
    assert Foo().bar == [1, 2, 3]

# Generated at 2022-06-10 23:11:49.272036
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get('module_path'))

    # Won't work if we haven't initialized the global context yet
    CLIARGS = CLIArgs({'module_path': 'test'})
    assert callable(cliargs_deferred_get('module_path'))() == 'test'

    # Make sure that we return the default if no value is found in the global context
    CLIARGS = CLIArgs({})
    assert callable(cliargs_deferred_get('module_path', default='nottest'))() == 'nottest'

    # Make sure that we can get a shallow copy of the module_path
    CLIARGS = CLIArgs({'module_path': ['a', 'b']})

# Generated at 2022-06-10 23:11:58.725767
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.context_objects import EndCLIOption, CLIOverallArgs
    from ansible.utils.context_objects import GlobalCLIArgs, GlobalCLIArgsError

    # We need a mutable object that can be used to
    # simulate the CLIARGS object being changed.
    # An ordered dict is handy because if it is mutated in-place
    # it will not be equal to the original.
    class MutableCLIArgs(dict):
        pass

    orig_CLIARGS = CLIARGS
    mutable_CLIARGS = MutableCLIArgs()
    CLIARGS = mutable_CLIARGS

    # Sanity check that the closure returns the default value when the
    # key is not there
    assert cliargs_