

# Generated at 2022-06-10 23:02:10.755023
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check_for_shallow_copy(key):
        class FakeGlobalCLIArgs(object):
            def __init__(self):
                self.key = key
            def get(self, _, default):
                return self.key

        global CLIARGS
        cliargs = FakeGlobalCLIArgs()
        CLIARGS = cliargs

# Generated at 2022-06-10 23:02:21.730003
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    value = 42
    cli_args = dict(key=value)
    _init_global_context(cli_args)

    # No default
    assert cliargs_deferred_get('key')() == value

    # Default provided
    assert cliargs_deferred_get('notkey')() is None  # pylint: disable=used-before-assignment

    # No value for key and invalid default
    try:
        assert cliargs_deferred_get('notkey', default='foo')()
        assert False, 'Should have raised a KeyError'
    except KeyError:
        pass

    # No value for key and default provided
    assert cliargs_deferred_get('notkey', default='foo')() == 'foo'

    # No value for key and valid default provided
    more_value = 'bar'

# Generated at 2022-06-10 23:02:31.409892
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    d = {'a': 1}
    s = [2]

    global CLIARGS
    CLIARGS = CLIArgs({'a': d, 'b': s})

    # Test getting with no shallowcopy
    assert CLIARGS['b'] is s
    assert cliargs_deferred_get('b')() is s
    # Test getting with shallow copy
    assert cliargs_deferred_get('a', shallowcopy=True)() is not d
    assert cliargs_deferred_get('a', shallowcopy=True)() == d
    assert cliargs_deferred_get('b', shallowcopy=True)() is not s
    assert cliargs_deferred_get('b', shallowcopy=True)() == s



# Generated at 2022-06-10 23:02:42.144529
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['test'] = 'test'
    assert 'test' == cliargs_deferred_get('test')()
    assert None is cliargs_deferred_get('not_there')()
    assert 'not_there' == cliargs_deferred_get('not_there', 'not_there')()
    assert cliargs_deferred_get('test', shallowcopy=True)() == cliargs_deferred_get('test', shallowcopy=False)()
    assert cliargs_deferred_get('test', shallowcopy=True)() is not cliargs_deferred_get('test', shallowcopy=True)(), \
        'Shallow copy should return a new object'

# Generated at 2022-06-10 23:02:50.282416
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import os
    cli_args = dict(
        verbosity=4,
        inventory=['/foo/bar.ini'],
        become_ask_pass=True,
    )
    cli_args['extra_vars'] = dict(
        foo='bar',
    )
    _init_global_context(cli_args)
    assert CLIARGS == cli_args
    verbosity_func = cliargs_deferred_get('verbosity')
    assert verbosity_func() == 4
    assert cliargs_deferred_get('inventory')()[:] == ['/foo/bar.ini']
    extra_vars = cliargs_deferred_get('extra_vars')()
    assert extra_vars == dict(foo='bar')
    assert not isinstance(extra_vars, list)


# Generated at 2022-06-10 23:03:02.122208
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    CLIARGS['foo'] = 'bar'
    g = cliargs_deferred_get('foo')
    assert g() == 'bar'
    CLIARGS['foo'] = 'baz'
    assert g() == 'baz'

    # test that the shallow copy functionality works
    class Foo:
        def __init__(self, bar):
            self.bar = bar

    class Baz(Foo):
        pass

    CLIARGS['foo'] = ['bar']
    g = cliargs_deferred_get('foo')
    assert g() == ['bar']
    CLIARGS['foo'].append('baz')
    assert g() == ['bar', 'baz']
    CLIARGS['foo'] = ['foo', 'bar']
    assert g

# Generated at 2022-06-10 23:03:13.927044
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # test default behavior
    test_dict = {'key1': 'value1', 'key2': 'value2'}
    CLIARGS = CLIArgs(test_dict)

    assert cliargs_deferred_get('key1') == 'value1'
    assert cliargs_deferred_get('key3') is None
    assert cliargs_deferred_get('key4', 'some_value') == 'some_value'

    # test shallowcopy=True
    test_list = [1, 2, 3]
    CLIARGS['key5'] = test_list
    assert cliargs_deferred_get('key5', shallowcopy=True) == [1, 2, 3]
    assert cliargs_deferred_get('key5', shallowcopy=True) != test_list
   

# Generated at 2022-06-10 23:03:17.821613
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'a': 1}
    _init_global_context(cli_args)
    result = cliargs_deferred_get('a')()
    assert result == cli_args['a']

# Generated at 2022-06-10 23:03:20.711571
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(foo=42))
    closure = cliargs_deferred_get('foo', default=43)
    assert closure() == 42

# Generated at 2022-06-10 23:03:31.296850
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CLIArgsNotSingleton:
        option1 = 'val1'

        def get(self, key, default=None):
            return getattr(self, key, default)

        def __contains__(self, key):
            return hasattr(self, key)

    CLIARGS.set_override(CLIArgsNotSingleton())

    assert cliargs_deferred_get('option1')() == 'val1'
    assert cliargs_deferred_get('option2')() is None
    assert cliargs_deferred_get('option3', 'val3')() == 'val3'

    # Test shallowcopy
    opt4 = {'a': 1}
    CLIARGS.set_override(CLIArgsNotSingleton(option4=opt4))

# Generated at 2022-06-10 23:03:41.529241
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=global-statement
    global CLIARGS

    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo') == None

    CLIARGS = CLIArgs({'foo': 1})
    assert cliargs_deferred_get('foo')() == 1

    CLIARGS = CLIArgs({'foo': 1})
    assert cliargs_deferred_get('foo', default=2)() == 1

    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default=2)() == 2

    CLIARGS = CLIArgs({'foo': 1})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 1

    CLIARGS = CLIArgs({'foo': [1,2,3]})

# Generated at 2022-06-10 23:03:51.497604
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for function ``cliargs_deferred_get``"""
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    class CLITest(unittest.TestCase):
        def test_forwards_to_cliargs_get(self):
            key = 'key'
            default = 'default value'
            value = 'value'
            cli_args = {key: value}

            global CLIARGS
            CLIARGS = CLIArgs(cli_args)

            self.assertEqual(value, cliargs_deferred_get(key, default=default)())
            self.assertEqual(default, cliargs_deferred_get('bad key', default=default)())

        def test_shallow_copy_list(self):
            key = 'key'


# Generated at 2022-06-10 23:04:04.402638
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Initialize the global context
    CLIARGS = CLIArgs({})

    # No value set
    g = cliargs_deferred_get('foo')
    assert g() is None

    # Value set
    CLIARGS = CLIArgs({'foo': 'bar'})
    g = cliargs_deferred_get('foo')
    assert g() == 'bar'

    # Value set, shallow copy
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    g = cliargs_deferred_get('foo', shallowcopy=True)
    assert g() == [1, 2, 3]
    assert g() is not CLIARGS['foo']
    assert g()[0] is CLIARGS['foo'][0]

    # Value set, shallow copy
    CLI

# Generated at 2022-06-10 23:04:15.177097
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pragma: no cover
    cliargs_ = CLIArgs({'test':'value'})
    get_test_value = cliargs_deferred_get('test', default='default')
    assert get_test_value() == 'value'
    get_default_value = cliargs_deferred_get('foo', default='default')
    assert get_default_value() == 'default'
    assert get_test_value() == 'value'
    # Make sure we don't get references for mutable data
    cliargs_['test_list'] = ['foo', 'bar']
    get_test_list_value = cliargs_deferred_get('test_list', default='default')
    assert get_test_list_value() == ['foo', 'bar']
    del cliargs_['test_list']
   

# Generated at 2022-06-10 23:04:23.785300
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_list():
        value = ['a', 'b', 'c']
        # Test the non shallow copy
        result = cliargs_deferred_get('doesnotexist', value, shallowcopy=False)()
        assert result == value
        result[0] = 'z'  # Try to modify the result
        assert result == value  # Check that the result was actually modified

        # Now test the shallow copy
        result = cliargs_deferred_get('doesnotexist', value, shallowcopy=True)()
        assert result == value
        result[0] = 'z'  # Try to modify the result
        assert result != value  # Check that the result was not modified

    test_list()

# Generated at 2022-06-10 23:04:34.865257
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test to ensure that cliargs_deferred_get works as expected"""
    # Test that the function gets the expected value
    CLIARGS['verbosity'] = 3
    value = cliargs_deferred_get('verbosity')()
    assert value == 3

    # Test that the getter handles missing values correctly
    value = cliargs_deferred_get('missing', default=2)()
    assert value == 2

    # Test that the getter handles shallow copy correctly
    CLIARGS['shallow_copy'] = [1, 2, 3]
    value = cliargs_deferred_get('shallow_copy', shallowcopy=True)()
    assert value == [1, 2, 3]
    assert value is not CLIARGS['shallow_copy']

# Generated at 2022-06-10 23:04:42.819765
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    assert cliargs_deferred_get('does-not-exist')() == None
    assert cliargs_deferred_get('does-not-exist', 'default')() == 'default'
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('does-not-exist')() == None
    assert cliargs_deferred_get('does-not-exist', 'default')() == 'default'

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    CLIARGS = CLIArgs({'steal': 'thou art safe'})
    clippy = cliargs_deferred_get('steal')
    CLIARGS = CLIArgs({'steal': 'no more'})

# Generated at 2022-06-10 23:04:55.041506
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'test1': [1, 2, 3], 'test2': 2, 'test3': {1: 3}, 'test4': {'a', 'b'}})

    # Default values
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Lists
    assert cliargs_deferred_get('test1')() == [1, 2, 3]
    assert cliargs_deferred_get('test1', shallowcopy=True)() == [1, 2, 3]

    # int and str
    assert cliargs_deferred_get('test2')() == 2
    assert cliargs_deferred_get('test2', shallowcopy=True)() == 2

    #

# Generated at 2022-06-10 23:05:06.367807
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIARGS as MockCLIARGS
    cli_args = {'foo': {'bar': ['x', 'y', 'z']}}
    MockCLIARGS.from_options(cli_args)
    getter = cliargs_deferred_get('foo', default={})
    assert getter() == {'bar': ['x', 'y', 'z']}
    getter = cliargs_deferred_get('baz', default={})
    assert getter() == {}
    getter = cliargs_deferred_get('baz', default={}, shallowcopy=True)
    assert getter() == {}
    getter = cliargs_deferred_get('foo')
    assert getter() == {'bar': ['x', 'y', 'z']}

# Generated at 2022-06-10 23:05:16.530994
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test creation of a default value
    cli_args = CLIArgs({})
    cliargs_deferred_get_default = cliargs_deferred_get('test_key', default='test_default')
    assert cliargs_deferred_get_default() == 'test_default'

    # Test setting CLIARGS
    cli_args = CLIArgs({'test_key': 'test_value'})
    cliargs_deferred_get_default = cliargs_deferred_get('test_key', default='test_default')
    assert cliargs_deferred_get_default() == 'test_value'

    # Test shallowcopy() with various types
    cli_args = CLIArgs({'test_key': 'test_value'})
    cliargs_deferred_get_shallowcopy = cl

# Generated at 2022-06-10 23:05:33.198152
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict())
    # Test with no shallow copy
    assert cliargs_deferred_get('no_such_key')() is None
    assert cliargs_deferred_get('no_such_key', 'default')() == 'default'
    CLIARGS.set('test_key', 'value')
    assert cliargs_deferred_get('test_key')() == 'value'
    # Test with shallow copy
    v = [1, 2]
    CLIARGS.set('test_key2', v)
    v[0] = 2
    assert cliargs_deferred_get('test_key2', shallowcopy=True)() == [2, 2]
    # Test that we don't shallow copy when it is the default value

# Generated at 2022-06-10 23:05:42.430845
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MyCLIArgs(object):
        def __init__(self, mydict):
            self.mydict = mydict

        def get(self, key, default=None):
            return self.mydict.get(key, default)

    def_get = cliargs_deferred_get('test')
    assert def_get() is None
    mydict = {'test': 'it worked'}
    CLIARGS = MyCLIArgs(mydict)
    assert def_get() == 'it worked'
    mydict['test'] = ['test', 'again']
    assert def_get(shallowcopy=True) == ['test', 'again']
    assert def_get(shallowcopy=True) is not mydict['test']

# Generated at 2022-06-10 23:05:53.124623
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make a copy of CLIArgs so we can change it without affecting other tests
    from ansible.module_utils.common._collections_compat import MutableMapping
    import copy
    global CLIARGS
    old_cliargs = CLIARGS
    CLIARGS = copy.deepcopy(CLIARGS)
    if not isinstance(CLIARGS, MutableMapping):
        CLIARGS = CLIARGS.argv

    def set_true(key):
        CLIARGS[key] = True

    def set_false(key):
        CLIARGS[key] = False

    def set_none(key):
        CLIARGS[key] = None

    def set_123(key):
        CLIARGS[key] = 123


# Generated at 2022-06-10 23:05:59.038312
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is needed because '_init_global_context' relies on finding cliargs in the
    # namespace and other modules run this too early so CLIARGS is not a GlobalCLIArgs
    # subclass yet.
    global CLIARGS
    CLIARGS = GlobalCLIArgs(CLIARGS)
    _init_global_context({})

    default = 'default'
    value_to_set = 'value_to_set'

    def check_result(expected_value):
        assert cliargs_deferred_get('nonexistent', default) == default
        assert cliargs_deferred_get('nonexistent', default, shallowcopy=True) == default
        assert cliargs_deferred_get('foo', default) == expected_value

# Generated at 2022-06-10 23:06:09.896303
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.collection_functions import is_sequence, is_set
    from ansible.utils.context_objects import GlobalCLIArgs

    # Make sure that cliargs_deferred_get() works with the global context
    cli_args = {'debug': True}
    global CLIARGS
    _init_global_context(cli_args)

    # Populate CLIARGS
    CLIARGS['debug'] = False
    CLIARGS['verbosity'] = 2
    CLIARGS['inventory'] = 'some_inventory.yml'
    CLIARGS['help'] = 'some help text'

    # Defer getting a value from CLIARGS
    get_debug = cliargs_deferred_get('debug', default=True)

    # Verify that after polling the value is correct

# Generated at 2022-06-10 23:06:22.035032
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_cliargs = {'test': 42}
    _init_global_context(test_cliargs)
    # Test nested access
    assert cliargs_deferred_get('test')(default=1) == 42
    assert cliargs_deferred_get('idx')(default=1) == 1
    # Test shallowcopy
    test_list = [1, 2, 3]
    test_cliargs['list'] = test_list
    test_cliargs_copy = cliargs_deferred_get('list', shallowcopy=True)()
    assert test_cliargs_copy is not test_list
    assert test_cliargs_copy == test_list

    test_dict = {'a': 1, 'b': 2}
    test_cliargs['dict'] = test_dict

# Generated at 2022-06-10 23:06:32.086085
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # import pytest
    # import warnings

    # Loop over value types and test them
    for key in ('foo', 'bar', 'baz', 'frobnicate'):
        value = 'This is %s' % key
        CLIARGS[key] = value
    for key in ('foo', 'bar', 'baz', 'frobnicate'):
        assert CLIARGS.get(key) == 'This is %s' % key
        assert cliargs_deferred_get(key)() == 'This is %s' % key

    # Test getting a non-existant key
    with pytest.raises(KeyError):
        CLIARGS.get('blah')
    with pytest.raises(KeyError):
        cliargs_deferred_get('blah')()

    # Test getting with a default

# Generated at 2022-06-10 23:06:44.074575
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pragma: no cover
    _init_global_context({'foo': 'bar', 'baz': ['baz1', 'baz2'], 'bam': set([1,2,3])})

    # Test getting an existing key
    foo_get = cliargs_deferred_get('foo')
    assert foo_get() == 'bar'
    foo_get_shallow = cliargs_deferred_get('foo', shallowcopy=True)
    assert foo_get() == foo_get_shallow()

    # Test getting a key that doesn't exist
    def_foo_get = cliargs_deferred_get('fooz')
    assert def_foo_get() is None
    def_foo_get_shallow = cliargs_deferred_get('fooz', shallowcopy=True)

# Generated at 2022-06-10 23:06:55.243531
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_get(cliargs):
        cliargs['a'] = 5
        assert cliargs_deferred_get('a')(cliargs) == 5

        cliargs['b'] = [1, 2, 3]
        assert cliargs_deferred_get('b')(cliargs) == [1, 2, 3]

        cliargs['b'] = set([1, 2, 3])
        assert cliargs_deferred_get('b')(cliargs) == set([1, 2, 3])

        cliargs['b'] = (1, 2, 3)
        assert cliargs_deferred_get('b')(cliargs) == (1, 2, 3)

        cliargs['b'] = {'a': 1, 'b': 2}

# Generated at 2022-06-10 23:07:01.720414
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    _init_global_context({'foo': 'bar'})
    assert CLIARGS['foo'] == 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    _init_global_context({'foo': 'baz'})
    assert CLIARGS['foo'] == 'baz'
    assert cliargs_deferred_get('foo')() == 'baz'

# Generated at 2022-06-10 23:07:20.775061
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import os
    import tempfile
    import unittest

    class TestCliArgsDeferredGet(unittest.TestCase):
        def setUp(self):
            CLIARGS.new_context({'host_key_checking': False, 'become': True, 'listtags': False})

        def tearDown(self):
            CLIARGS.exit_context()

        def test_default(self):
            get_deepcopy = cliargs_deferred_get('deepcopy')
            self.assertIsNone(get_deepcopy())

        def test_get_direct(self):
            get_become = cliargs_deferred_get('become')
            self.assertTrue(get_become())

        def test_shallowcopy_true(self):
            get_host_key_checking = cliargs_

# Generated at 2022-06-10 23:07:30.525443
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS._options = {'foo': 'bar'}
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

    CLIARGS._options = {'bar': ['a', 'b', 'c']}
    assert cliargs_deferred_get('bar')() == 'a'
    assert cliargs_deferred_get('bar', shallowcopy=True)() == ['a', 'b', 'c']

# Generated at 2022-06-10 23:07:40.486854
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS[u'foo'] = u'bar'
    assert cliargs_deferred_get('foo')() == u'bar'
    assert cliargs_deferred_get('foo', default='baz')() == u'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == u'bar'
    li = [1, 2, 3]
    CLIARGS[u'foo'] = li
    assert cliargs_deferred_get('foo', shallowcopy=True)() == li
    assert cliargs_deferred_get('foo')() == li
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not li
    assert cliargs_deferred_get('foo')() is li

# Generated at 2022-06-10 23:07:51.041375
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Test with simple values
    CLIARGS = CLIArgs({'a': 'b'})
    assert cliargs_deferred_get('a')() == 'b'
    assert cliargs_deferred_get('a', default='')() == 'b'
    assert cliargs_deferred_get('c', default='d')() == 'd'
    assert cliargs_deferred_get('c', default='')() == ''

    # Test with list values
    CLIARGS = CLIArgs({'a': ['b']})
    assert cliargs_deferred_get('a')() == ['b']
    assert cliargs_deferred_get('a', shallowcopy=True)() == ['b']

# Generated at 2022-06-10 23:07:59.639873
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function ``cliargs_deferred_get``"""
    # pylint: disable=redefined-outer-name
    def test_inner_function(key, default, value):
        """Ensure that cliargs_deferred_get returns correct values"""
        cliargs = CLIArgs({key: value})
        result = cliargs_deferred_get(key, default=default)()
        assert result == value
        result = cliargs_deferred_get(key, default=default, shallowcopy=True)()
        assert result == value
    test_inner_function('int', 123, 456)
    test_inner_function('str', '123', '456')
    test_inner_function('tuple', (1, 2), (3, 4))

# Generated at 2022-06-10 23:08:11.505416
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from copy import copy, deepcopy

    class A:
        def __copy__(self):
            return 'copy'

        def __deepcopy__(self, memo):
            return 'deepcopy'

    global CLIARGS
    test_args_deepcopy = copy(CLIARGS)
    test_args_copy = A()

    assert cliargs_deferred_get('bogus_key')() is None
    assert cliargs_deferred_get('bogus_key', 'default')() == 'default'

    assert cliargs_deferred_get('list_copy')() is CLIARGS['list_copy']
    assert cliargs_deferred_get('list_copy', shallowcopy=True)() == ['x', 'y']

# Generated at 2022-06-10 23:08:21.337311
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # The test for the different types of value is pretty flimsy.
    # We are just testing that it returns the correct value.
    # Since this is a closure over a closure we don't test the actual
    # functionality of CLIARGS as that is tested in CliArgs
    _init_global_context({'foo': 'bar'})

    factory = cliargs_deferred_get('foo')
    assert factory() == 'bar'

    _init_global_context({'foo': ['bar', 'baz']})
    factory = cliargs_deferred_get('foo')
    assert factory() == ['bar', 'baz']

    _init_global_context({'foo': ['bar', 'baz']})
    factory = cliargs_deferred_get('foo', shallowcopy=False)

# Generated at 2022-06-10 23:08:32.733806
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class DummyCLIArgs(dict):
        """A Dict-like object that allows deferred retrieval of values"""
        def get(self, key, default=None):
            """Returns a function that when called will return the value"""
            def get_value():
                return self[key]
            return get_value

    class DummyCLIArgsSingleton(DummyCLIArgs):
        """A singleton version of DummyCLIArgs"""
        instance = None

        @classmethod
        def from_options(cls, options):
            if cls.instance is None:
                cls.instance = cls()
            cls.instance.update(options)
            return cls.instance

    global CLIARGS
    CLIARGS = DummyCLIArgsSingleton.from_options({'x':'y'})
    assert cl

# Generated at 2022-06-10 23:08:42.675177
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-10 23:08:55.272428
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)
    assert CLIARGS == cli_args
    # We can get the same value back that we put in
    get_foo = cliargs_deferred_get('foo')
    assert get_foo() == 'bar'
    # We get the default if the value doesn't exist (and it's not copied)
    get_baz = cliargs_deferred_get('baz', default='baz')
    assert get_baz() == 'baz'
    # We get a shallow copy of the data structure
    get_foo_shallow = cliargs_deferred_get('foo', shallowcopy=True)
    assert get_foo_shallow() == 'bar'
    # We get a copy of the data even

# Generated at 2022-06-10 23:09:24.588405
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Test the default
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('key', 'default')() == 'default'
    # Test key not in CLIARGS
    CLIARGS = CLIArgs({'not_key': 'value'})
    assert cliargs_deferred_get('key', 'default')() == 'default'
    # Test key in CLIARGS
    CLIARGS = CLIArgs({'key': 'value'})
    assert cliargs_deferred_get('key', 'default')() == 'value'
    # Test shallow copy of a list
    CLIARGS = CLIArgs({'key': ['item1', 'item2']})
    lst = cliargs_deferred_get('key', shallowcopy=True)()

# Generated at 2022-06-10 23:09:35.850601
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {
        'foo': ['bar'],
        'baz': 'yes',
    }
    _init_global_context(cli_args)

    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('baz')() == 'yes'
    assert cliargs_deferred_get('qux')() is None
    assert cliargs_deferred_get('qux', 'foobar')() == 'foobar'

    # shallow copies
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == 'yes'

# Generated at 2022-06-10 23:09:44.925777
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {
        'key1': 'value',
        'key2': [],
        'key3': {}
    }
    _init_global_context(cli_args)
    assert cliargs_deferred_get('key1', default='default')() == 'value'
    assert cliargs_deferred_get('key2', default='default')() == []
    assert cliargs_deferred_get('key3', default='default')() == {}
    assert cliargs_deferred_get('key4', default='default')() == 'default'
    assert cliargs_deferred_get('key1', shallowcopy=True)() == 'value'
    assert cliargs_deferred_get('key2', shallowcopy=True)() == []

# Generated at 2022-06-10 23:09:56.604047
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestArgs(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    import pytest
    cli_args = TestArgs(module_path=['one', 'two'], become_ask_pass=True, become_method='SU')
    _init_global_context(cli_args)
    assert cliargs_deferred_get('module_path')() == ['one', 'two']
    assert cliargs_deferred_get('module_path', shallowcopy=True)() == ['one', 'two']
    assert cliargs_deferred_get('become_ask_pass')() is True
    assert cliargs_deferred_get('become_method')() == 'SU'

# Generated at 2022-06-10 23:10:06.193358
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({'foo': 1, 'bar': [1, 2], 'baz': {'a': 'A', 'b': 'B'}, 'qux': {1, 2}})
    inner = cliargs_deferred_get('foo', default='not found')
    assert inner() == 1
    inner = cliargs_deferred_get('xyzzy', default='not found')
    assert inner() == 'not found'
    inner = cliargs_deferred_get('bar', default='not found', shallowcopy=True)
    bar = inner()
    bar.append(3)
    assert CLIARGS['bar'] == [1, 2, 3]
    inner = cliargs_deferred_get('baz', default='not found', shallowcopy=True)
    baz = inner()
    b

# Generated at 2022-06-10 23:10:15.724846
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar', 'baz': [1, 2]}
    _init_global_context(cli_args)
    get_foo = cliargs_deferred_get('foo', default='default_foo')
    get_baz = cliargs_deferred_get('baz', default=[3, 4])
    assert get_foo() == 'bar'
    assert get_baz() == [1, 2]
    get_foo = cliargs_deferred_get('foo2', default=[5, 6])
    get_baz = cliargs_deferred_get('baz2', default=None)
    assert get_foo() == [5, 6]
    assert get_baz() is None



# Generated at 2022-06-10 23:10:22.164713
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Use the singleton because we don't want to have to pass this around in fields
    CLIARGS.update({'a': 1, 'b': 2, 'c': {'d': 3}})

    assert 1 == cliargs_deferred_get('a')()
    assert 2 == cliargs_deferred_get('b')()

    # if the value isn't found, we return the default
    assert '3' == cliargs_deferred_get('thing', '3')()

    # if the value is copied and changed, the original isn't
    from copy import deepcopy
    deepcopy(CLIARGS)['c']['d'] = 4
    assert 3 == cliargs_deferred_get('c')()['d']

    # Unbound global object
    assert cliargs_deferred_get('a')

# Generated at 2022-06-10 23:10:32.714714
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for :py:func:`lib.context_objects.cliargs_deferred_get`"""
    # test copying
    results = []
    for shallowcopy in (False, True):
        for value in (['a', 'b', 'c'], {'a': 1, 'b': 2, 'c': 3}, (1, 2, 3), set('abcd'), 'abcd'):
            def inner(local_value):
                def get_value():
                    return value

# Generated at 2022-06-10 23:10:36.407300
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 42}
    _init_global_context(cli_args)

    get_foo = cliargs_deferred_get('foo')
    assert get_foo() == 42

    cli_args['foo'] = 'bar'
    assert get_foo() == 'bar'



# Generated at 2022-06-10 23:10:40.750264
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo')() is None
    CLIARGS.data['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'



# Generated at 2022-06-10 23:11:29.529753
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Constructing a FieldAttribute that has cliargs_deferred_get as its default
    # will work even if the CLIARGS object is not created yet

    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.module_utils.common.collections import FieldAttribute

    class TestClass(object):
        """Test object that can have their values set by FieldAttribute"""
        def __init__(self, test_value=None):
            self.test_value = test_value

        def get_test_value(self):
            return self.test_value

    myclass = TestClass(test_value=1)

    global CLIARGS

    class CLIArgs(dict):
        """dummy CLIArgs class"""

# Generated at 2022-06-10 23:11:38.653831
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class RealCLIArgs(object):
        def get(self, key):
            return value
    global CLIARGS
    value = dict()
    CLIARGS = RealCLIArgs()
    assert id(value) == id(cliargs_deferred_get('key', shallowcopy=False)())
    assert id(value) != id(cliargs_deferred_get('key', shallowcopy=True)())
    value = [1, 2]
    assert id(value) == id(cliargs_deferred_get('key', shallowcopy=False)())
    assert id(value) != id(cliargs_deferred_get('key', shallowcopy=True)())
    value = set()
    assert id(value) == id(cliargs_deferred_get('key', shallowcopy=False)())
    assert id(value) != id

# Generated at 2022-06-10 23:11:49.640273
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    original = {'foo': 'bar'}
    _init_global_context(original)

    def assert_get_value(key, default, shallowcopy, expected):
        value = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)()
        assert value is expected

    # Test getting an existing key with no shallowcopy
    assert_get_value('foo', default=None, shallowcopy=False, expected='bar')

    # Test getting an existing key with a shallowcopy
    assert_get_value('foo', default=None, shallowcopy=True, expected='bar')

    # Test getting a non-existent key with no shallowcopy
    assert_get_value('nope', default=None, shallowcopy=False, expected=None)

    # Test getting a non-existent key with a shallowcopy
    assert_

# Generated at 2022-06-10 23:11:50.512983
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get('foo')()

# Generated at 2022-06-10 23:11:56.028003
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the closure cliargs_deferred_get() works as expected"""
    global CLIARGS
    assert not hasattr(CLIARGS, 'foo')
    assert cliargs_deferred_get('foo')() is None
    CLIARGS = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'



# Generated at 2022-06-10 23:12:02.790039
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test None
    assert cliargs_deferred_get('test')() is None

    # Test different defaults
    global CLIARGS
    CLIARGS = CLIArgs({'test': 'test_value'})
    assert cliargs_deferred_get('test', 'test_default')() == 'test_default'
    assert cliargs_deferred_get('test', default='test_default')() == 'test_default'

    # Test values from CLIARGS
    CLIARGS = CLIArgs({'test': 'test_value'})
    assert cliargs_deferred_get('test')() == 'test_value'

    # Test with shallowcopy
    CLIARGS = CLIArgs({'test_list': ['test_value']})