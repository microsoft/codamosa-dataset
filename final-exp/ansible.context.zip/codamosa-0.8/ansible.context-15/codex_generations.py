

# Generated at 2022-06-10 23:02:11.868636
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for cliargs_deferred_get"""
    import collections
    import types
    import unittest


    class TestCase(unittest.TestCase):
        """Tests for cliargs_deferred_get"""
        def test_call(self):
            """Does cliargs_deferred_get call the inner function"""
            inner_called = False
            def inner():
                nonlocal inner_called
                inner_called = True
                return None

            inner_wrapper = cliargs_deferred_get(None, inner)
            self.assertTrue(inner_wrapper())
            self.assertTrue(inner_called)

        def test_return_value(self):
            """Does cliargs_deferred_get return the value of the inner function"""
            inner_return_value = 'foo'

# Generated at 2022-06-10 23:02:23.080211
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for functions that use cliargs_deferred_get"""
    global CLIARGS
    _init_global_context({'yes': True, 'list': [1, 2, 3], 'set': set([1, 2, 3, 1])})
    assert CLIARGS.get('set') == set([1, 2, 3])
    assert cliargs_deferred_get('set', default=[])() == set([1, 2, 3])
    assert cliargs_deferred_get('invalidkey')() is None
    assert cliargs_deferred_get('invalidkey', default=[])() == []
    assert cliargs_deferred_get('list', shallowcopy=True)() == [1, 2, 3]

if __name__ == "__main__":
    test_cliargs_deferred_

# Generated at 2022-06-10 23:02:32.931786
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def verify_closure(a, b, c, d, e):
        return a, b, c, d, e

    # Normal value
    key = 'k'
    data = {'foo': 'bar'}
    # This will make a shallow copy
    closure = cliargs_deferred_get(key=key, default=data)
    a, b, c, d, e = verify_closure(*[closure() for _ in range(5)])
    assert a == b == c == d == e
    assert a is b is c is d is e

    # Shallowcopy values
    key = 'k'
    data = ['foo', 'bar']
    # This will make a shallow copy
    closure = cliargs_deferred_get(key=key, default=data)

# Generated at 2022-06-10 23:02:43.957849
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for cliargs_deferred_get"""
    CLIARGS.update({'a_list': [1, 2, 3], 'a_tuple': (1, 2, 3), 'a_dict': {1: 'a', 2: 'b', 3: 'c'}, 'a_set': {1, 2, 3}})
    assert CLIARGS['a_list'] == cliargs_deferred_get('a_list')()
    assert CLIARGS['a_tuple'] == cliargs_deferred_get('a_tuple')()
    assert CLIARGS['a_dict'] == cliargs_deferred_get('a_dict')()
    assert CLIARGS['a_set'] == cliargs_deferred_get('a_set')()
    assert CLIARGS['a_list']

# Generated at 2022-06-10 23:02:51.164266
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Make sure cliargs_deferred_get works."""
    cli_args = {'test_str': 'foo',
                'test_int': 1,
                'test_list': ['bar', 'baz'],
                'test_dict': {'key': 'val'}}

    # Make sure that cliargs_deferred_get works as expected when called at init time
    _init_global_context(cli_args)
    result1 = cliargs_deferred_get('test_str')()
    result2 = cliargs_deferred_get('test_int')()
    result3 = cliargs_deferred_get('test_list')()
    result4 = cliargs_deferred_get('test_dict')()

# Generated at 2022-06-10 23:03:01.505956
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test': 6})
    assert cliargs_deferred_get('test', default=7)() == 6
    assert cliargs_deferred_get('test2', default=7)() == 7
    assert cliargs_deferred_get('test2', default=7, shallowcopy=True)() == 7
    lst = cliargs_deferred_get('test3', default=[], shallowcopy=True)()
    assert lst == []
    lst.append(7)
    lst2 = cliargs_deferred_get('test3', default=[], shallowcopy=True)()
    assert lst2 == []

# Generated at 2022-06-10 23:03:13.262920
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping
    global CLIARGS
    CLIARGS = CLIArgs()


# Generated at 2022-06-10 23:03:20.006137
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    # Set up some initial values:
    #   key that has a value, key that has default value, key that has no value
    #   and is not in the defaults.
    CLIARGS['has_value'] = 'value'
    CLIARGS['default_value'] = 'default'
    CLIARGS['no_value'] = None
    defaults = {'default_value': 'default'}
    # Test the value
    assert 'value' == cliargs_deferred_get('has_value')()
    assert 'default' == cliargs_deferred_get('default_value', default='default')()
    assert 'default' == cliargs_deferred_get('default_value', default='overridden')()
    assert 'default' == cliargs_deferred_

# Generated at 2022-06-10 23:03:30.558073
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Do not set up the context object in this test.
    # Otherwise we will get into a situation where the
    # singleton version of cliargs is created and then
    # the test code tries to create another one.
    #
    # We need to conditionally create a singleton so that
    # code can get the default value without triggering a
    # circular import.
    #
    # We use the same global object here to avoid having to
    # reset the singleton with the CLIArgs.from_options in
    # test_module_util
    global CLIARGS
    def_value = "default"
    non_def_value = "not default"
    get_value = cliargs_deferred_get("nothing", default=def_value)
    assert get_value() == def_value

# Generated at 2022-06-10 23:03:39.264133
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    foo = cliargs_deferred_get('foo')
    # test_ansible_module should set this before this is ever called
    assert foo() == 'test_ansible_module'

    bar = cliargs_deferred_get('bar')
    assert bar() is None
    bar = cliargs_deferred_get('bar', default="hello")
    assert bar() == "hello"

    baz = cliargs_deferred_get('baz', shallowcopy=True)
    assert baz() == [1, 2, 3, 4]
    assert baz() is not [1, 2, 3, 4]

    bat = cliargs_deferred_get('bat', shallowcopy=True)

# Generated at 2022-06-10 23:03:51.594301
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_cases = {
        "empty_dict": {},
        "populated_dict": {"foo": "bar"},
        "empty_list": [],
        "populated_list": ["foo", "bar"],
        "empty_set": set(),
        "populated_set": {1, 2, 3},
        "int": 42,
        "string": "foo",
    }

    for case, value in test_cases.items():

        # Test with shallowcopy=False
        raw_value = cliargs_deferred_get(case, default=value)()

        assert raw_value is value, "Got wrong value for case: {} should be value: {}".format(case, value)

        # Test with shallowcopy=True

# Generated at 2022-06-10 23:04:04.521422
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # check that it returns defaults
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # check that it returns a value from CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'
    # check that it makes a shallow copy of lists
    CLIARGS['foo'] = ['f', 'b', 'a', 'z']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['f', 'b', 'a', 'z']
    CLIARGS['foo'][3] = 'r'

# Generated at 2022-06-10 23:04:15.269866
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    key = 'test_cliargs_deferred_get'
    try:
        cliargs_deferred_get(key)()
        assert False
    except ValueError:
        pass

    CLIARGS.update({key: 'test_cliargs_deferred_get'})
    assert cliargs_deferred_get(key)() == 'test_cliargs_deferred_get'

    del CLIARGS[key]
    assert cliargs_deferred_get(key, 'test_cliargs_deferred_get_default')() == 'test_cliargs_deferred_get_default'

    CLIARGS[key] = ['a', 'b']
    assert cliargs_deferred_get(key, shallowcopy=True)() == ['a', 'b']

# Generated at 2022-06-10 23:04:25.744203
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import MutableSet
    import copy
    import ansible.module_utils.common.collections
    ansible.module_utils.common.collections.is_sequence = lambda x: isinstance(x, MutableSet)
    value = MutableSet([1, 2, 3])
    getter = cliargs_deferred_get('foo', default=value)
    CLIARGS = GlobalCLIArgs.from_options({})
    assert getter() == value
    assert getter() is value
    assert getter()[:] == [1, 2, 3]
    assert getter()[:] is not value
    CLIARGS = GlobalCLIArgs.from_options({'foo': value})
    assert getter() == value
    assert getter() is value
   

# Generated at 2022-06-10 23:04:36.463071
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works"""
    global CLIARGS
    CLIARGS = CLIArgs({'mykey': ['myvalue']})
    assert cliargs_deferred_get('mykey')() == ['myvalue']
    assert cliargs_deferred_get('mykey', shallowcopy=True)() == ['myvalue']
    CLIARGS['mykey'] = {'a': 1, 'b': 2}
    assert cliargs_deferred_get('mykey')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('mykey', shallowcopy=True)() == {'a': 1, 'b': 2}
    CLIARGS['mykey'] = 'myvalue'

# Generated at 2022-06-10 23:04:41.560013
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for cliargs_deferred_get"""
    # The inner function that we get back is not a bound method so it should work
    # in the same way that CLIARGS itself does when CLIARGS is replaced.
    assert cliargs_deferred_get('foo')(-1) == -1
    assert cliargs_deferred_get('foo', 'bar')(-1) == 'bar'
    # Since the outer function is hidden, we can't test the shallowcopy functionality
    # from here.
    pass

# Generated at 2022-06-10 23:04:53.524381
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    import copy

    def new_cliargs(val):
        global CLIARGS
        cli_args = CLIArgs({})
        cli_args._args = {'foo': val}
        CLIARGS = cli_args

    # Test simple get
    new_cliargs(42)
    func = cliargs_deferred_get('foo')
    assert func() == 42

    # Test get with default
    new_cliargs(None)
    func = cliargs_deferred_get('foo', default='Adam')
    assert func() == 'Adam'

    # Test deepcopy
    new_cliargs([1, 2, 3])
    func = cliargs_deferred_get('foo')
    assert func() == [1, 2, 3]
    assert func

# Generated at 2022-06-10 23:05:05.814318
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    import pytest

    # Create some data
    test_args = dict(v1='v1',
                     v2=['v2', 'v3'],
                     v3=('v4', 'v5'),
                     v4={'v6': 'v7', 'v8': 'v9'},
                     v5={'v10', 'v11'},
                     v6=copy.copy('v12'))

    # Ensure that it works off the bat
    global CLIARGS
    CLIARGS = CLIArgs(test_args)
    for key, value in test_args.items():
        assert cliargs_deferred_get(key)() == value

    # Call cliargs_deferred_get with an unknown key
    assert cliargs_deferred_get('not_there')() is None



# Generated at 2022-06-10 23:05:16.221594
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.utils.context_objects as context_objects
    global CLIARGS
    test_val = {'a': 'b'}
    CLIARGS = context_objects.CLIArgs({'a': test_val})
    assert CLIARGS['a'] is test_val
    assert cliargs_deferred_get('a')() is test_val
    assert cliargs_deferred_get('a', shallowcopy=True)() is not test_val
    assert cliargs_deferred_get('a', shallowcopy=True)() == test_val
    test_val = ['a']
    CLIARGS = context_objects.CLIArgs({'a': test_val})
    assert CLIARGS['a'] is test_val
    assert cliargs_deferred_get('a')() is test_val


# Generated at 2022-06-10 23:05:26.475502
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_test = {'test': 'abc', 'test_list': ['a', 'b', 'c'], 'test_set': {'a', 'b', 'c'}}
    _init_global_context(cliargs_test)
    assert cliargs_deferred_get('test') is cliargs_test['test']
    assert cliargs_deferred_get('test_list') is cliargs_test['test_list']
    assert cliargs_deferred_get('test_set') is cliargs_test['test_set']
    assert cliargs_deferred_get('test_list', shallowcopy=True) == cliargs_test['test_list']

# Generated at 2022-06-10 23:05:41.442328
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'one': 1, 'two': 2, 'three': [1, 2, 3], 'four': {'a': 1, 'b': 2, 'c': 3}, 'five': set([1, 2, 3])})
    assert cliargs_deferred_get('one')() == 1
    assert cliargs_deferred_get('two')() == 2
    assert cliargs_deferred_get('three')() == [1, 2, 3]
    assert cliargs_deferred_get('four')() == {"a": 1, "b": 2, "c": 3}
    assert cliargs_deferred_get('five')() == {1, 2, 3}
    assert cliargs_deferred_get('notthere', 3)() == 3

# Generated at 2022-06-10 23:05:49.386355
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.options = {'test_key': 'test_value'}
    # Bound function
    assert cliargs_deferred_get(key='test_key')() == 'test_value'
    assert cliargs_deferred_get(key='test_key', shallowcopy=True)() == 'test_value'
    # Unbound function
    assert cliargs_deferred_get('test_key')() == 'test_value'
    assert cliargs_deferred_get('test_key', shallowcopy=True)() == 'test_value'

# Generated at 2022-06-10 23:06:00.410331
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Unit tests for cliargs_deferred_get
    """
    global CLIARGS
    CLIARGS = CLIArgs({'key':'value', 'key1':[1,2,3], 'key2':{'a':'A'}, 'key3':True, 'key4':False})
    assert cliargs_deferred_get('key')(), 'value'
    assert cliargs_deferred_get('key1')(), [1,2,3]
    assert cliargs_deferred_get('key2')(), {'a':'A'}
    assert cliargs_deferred_get('key3')(), True
    assert cliargs_deferred_get('key4')(), False
    assert cliargs_deferred_get('key5')(), None

# Generated at 2022-06-10 23:06:10.862296
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # No need to do an extensive test of the cliargs_deferred_get because it simply
    # calls down to the same functions that we're already tested in the
    # ``CliArgs`` tests.  We verify that it's properly getting the CLIARGS global
    # and shallow copying the results if requested
    CLIARGS.FOO = 'foo'
    arg_foo = cliargs_deferred_get('FOO')
    assert arg_foo() == 'foo'
    # Assert that it works with an uninitalized CLIARGS
    global CLIARGS
    CLIARGS = None
    arg_foo = cliargs_deferred_get('FOO', 'bar')
    assert arg_foo() == 'bar'
    assert cliargs_deferred_get('BAR', 'baz')() == 'baz'


# Generated at 2022-06-10 23:06:22.507418
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

    CLIARGS = CLIArgs({'foo': 'bar', 'baz': {'blammo': 'blah'}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_

# Generated at 2022-06-10 23:06:27.973245
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 1, 'bar': 'hello'})
    value = cliargs_deferred_get('bar')
    assert value() == 'hello'
    value = cliargs_deferred_get('foo', default=1, shallowcopy=True)
    assert value() == 1
    value = cliargs_deferred_get('foo', default=2, shallowcopy=True)
    assert value() == 1
    CLIARGS.update({'default': [1, 2]})
    value = cliargs_deferred_get('default', shallowcopy=True)
    assert value() == [1, 2]

# Generated at 2022-06-10 23:06:40.568919
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.context_objects import GlobalCLIArgs
    from ansible.module_utils.common.validation import classonlymethod
    from ansible.module_utils.six import add_metaclass
    from ansible.parsing.plugin_docs import FIX_RELEASE_VERSION


# Generated at 2022-06-10 23:06:50.779081
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = {'test_val': [1, 2, 3]}
    _init_global_context(args)
    get_test_val = cliargs_deferred_get('test_val')
    assert get_test_val() == [1, 2, 3]
    args['test_val'].append(42)
    assert get_test_val() == [1, 2, 3, 42]
    args['test_val'].pop()
    assert get_test_val() == [1, 2, 3]

    get_test_val_copy = cliargs_deferred_get('test_val', shallowcopy=True)
    assert get_test_val_copy() == [1, 2, 3]
    args['test_val'].append(42)

# Generated at 2022-06-10 23:07:02.211358
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    import copy
    import pytest

    # make sure the context is clean
    CLIARGS = CLIArgs({})

    # make sure a KeyError exception is raised when the key is not present
    with pytest.raises(KeyError):
        cliargs_deferred_get('foo')()

    # make sure the default value is returned when the key is not present
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # make sure the key is returned when it is present
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # make sure the key is returned when deepcopy is requested
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs

# Generated at 2022-06-10 23:07:09.308524
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Sanity check that the deferred get works properly"""
    global CLIARGS
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default=None)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    _init_global_context({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    assert cliargs_deferred_get('foo', default=None)() == [1, 2, 3]

# Generated at 2022-06-10 23:07:21.862555
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set

    m = Mapping()
    s = Set(['one', 'two'])
    l = ['one']
    b = True
    i = 1
    o = object()

    def test_shallowcopy(mapping, value):
        inner = cliargs_deferred_get(mapping, default=value, shallowcopy=True)
        assert value is inner()
        assert inner() != value

    def test_deepcopy(mapping, value):
        inner = cliargs_deferred_get(mapping, default=value, shallowcopy=False)
        assert value is inner()

    for mapping in ('one', 'two', 'three'):
        for value in (m, s, l, b, i, o):
            test_

# Generated at 2022-06-10 23:07:32.051328
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function works with a non-singleton
    cli_args = CLIArgs({})
    cli_args['test'] = 'test'
    inner = cliargs_deferred_get('test')

    assert inner() == 'test'

    cli_args['test'] = 'foo'
    assert inner() == 'foo'

    # Test that it works with a singleton
    global CLIARGS
    CLIARGS = CLIArgs({'test': 'test'})

    assert inner() == 'test'

    CLIARGS['test'] = 'foo'
    assert inner() == 'foo'

    # Test that 'default' works
    CLIARGS = CLIArgs({'test': 'test'})

    inner = cliargs_deferred_get('test2', default='foo')

# Generated at 2022-06-10 23:07:42.076180
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _assert_val_eq(expected, key, default=None, shallowcopy=False):
        assert expected == cliargs_deferred_get(key, default, shallowcopy)()

    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    _assert_val_eq('bar', 'foo')
    _assert_val_eq('bar', 'foo', None, True)
    _assert_val_eq(['bar'], 'foo', None, False)
    _assert_val_eq({'foo': 'bar'}, 'foo', {'foo': 'bar'}, True)
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    _assert_val_eq(['bar', 'baz'], 'foo', None, False)
    _assert_val_eq

# Generated at 2022-06-10 23:07:52.634318
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.foo = 'bar'
    inner = cliargs_deferred_get('foo')
    assert inner() == 'bar'
    assert (inner() is CLIARGS.foo) is False
    CLIARGS.foo.append('baz')
    assert inner() == ['bar', 'baz']
    assert (inner() is CLIARGS.foo) is False

    CLIARGS.bar = set(('foo',))
    inner = cliargs_deferred_get('bar')
    assert inner() == set(('foo',))
    assert (inner() is CLIARGS.bar) is False
    CLIARGS.bar.add('bar')
    assert inner() == set(('foo', 'bar'))
    assert (inner() is CLIARGS.bar) is False

# Generated at 2022-06-10 23:07:59.392418
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert is_sequence(cliargs_deferred_get('foo', default=None, shallowcopy=True)()) == []
    assert cliargs_deferred_get('foo', default=None, shallowcopy=True)() is None
    assert cliargs_deferred_get('foo', default={'a': 'b', 'c': 'd'}, shallowcopy=True)() == {'a': 'b', 'c': 'd'}
    assert cliargs_deferred_get('foo', default={'a': 'b', 'c': 'd'}, shallowcopy=False)() == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-10 23:08:11.278528
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Unit test for function CLIARGS.get
    for cliargs_dict in ({'foo': 'bar'},):
        _init_global_context(cliargs_dict)
        assert cliargs_deferred_get('foo')() == 'bar'
        assert cliargs_deferred_get('baz')() is None

    for cliargs_dict in ({'foo': 'bar'},):
        _init_global_context(cliargs_dict)
        assert cliargs_deferred_get('foo')() == 'bar'
        assert cliargs_deferred_get('baz', default='default')() == 'default'
        assert cliargs_deferred_get('baz', default=cliargs_deferred_get('foo'))() == 'bar'
        assert cliargs_deferred_get

# Generated at 2022-06-10 23:08:20.194533
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3]})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('b', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('b', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('a', default=42)() == 1
    assert cliargs_deferred_get('c', default=42)() == 42

# Generated at 2022-06-10 23:08:32.184416
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-10 23:08:42.090200
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the function cliargs_deferred_get"""
    # pylint: disable=unused-argument
    class mock_CliArgs(object):
        """Mocked CLIArgs"""
        def get(self, key, default=None):
            """Get a key from a dict"""
            return {
                'a': 2,
                'b': [1, 2, 3],
                'c': {'d': 3},
                'd': {1, 2, 3},
                'e': 'value',
            }[key]

    global CLIARGS
    CLIARGS = mock_CliArgs()

    closure = cliargs_deferred_get('a')
    assert closure() == 2

    closure = cliargs_deferred_get('b', shallowcopy=True)

# Generated at 2022-06-10 23:08:54.728925
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS

    cli_args = {}
    _init_global_context(cli_args)
    assert CLIARGS == cli_args

    get_key = cliargs_deferred_get('foo', default='bar')
    assert get_key() == 'bar'

    cli_args = {'foo': 'baz'}
    _init_global_context(cli_args)
    assert CLIARGS == cli_args

    assert get_key() == cli_args['foo']
    get_key = cliargs_deferred_get('foo', default='bar', shallowcopy=True)
    assert get_key() == cli_args['foo']

    cli_args = {'foo': [1, 2, 3]}

# Generated at 2022-06-10 23:09:13.618852
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('this_key_does_not_exist_in_cliargs')() is None
    assert cliargs_deferred_get('this_key_does_not_exist_in_cliargs', 'this is a default')() == 'this is a default'

    _init_global_context({'test': True})

    assert cliargs_deferred_get('test')() is True
    # Test it doesn't do a shallow copy
    assert cliargs_deferred_get('test', shallowcopy=True)() is True

    _init_global_context({'test': [1, 2, 3]})
    assert cliargs_deferred_get('test')() == [1, 2, 3]
    # Test it does a shallow copy

# Generated at 2022-06-10 23:09:19.557592
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.set('foo', 'bar')
    assert cliargs_deferred_get('foo')() == 'bar'
    # test that shallow copy works
    L = [1, 2, 3]
    CLIARGS.set('foo', L)
    assert cliargs_deferred_get('foo', shallowcopy=True)() == L
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not L

# Generated at 2022-06-10 23:09:31.276840
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import unittest
    import ansible.utils.context_objects

    class Test(unittest.TestCase):
        def setUp(self):
            self.test_context = {
                'test': 'foo',
            }

            # Use the context_objects.CLIARGS as the global cliargs object
            self.cli_args = ansible.utils.context_objects.CLIArgs(self.test_context)
            ansible.utils.context_objects._init_global_context(self.cli_args)

        def tearDown(self):
            # Clear the global context singletons
            ansible.utils.context_objects.CLIARGS = {}

        def test_simple_get(self):
            key = 'test'
            default = 'bar'

# Generated at 2022-06-10 23:09:44.332752
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for ``cliargs_deferred_get``"""

    def inner_func(key, default=None, shallowcopy=False):
        """Inner function to test closure"""
        return cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)

    # Initialize the global context to something we can work against
    _init_global_context(dict(b=1, c=dict(x=1, y=2)))

    # Check that the nested value can be retrieved
    assert inner_func("c.x")() == 1
    assert inner_func("c.y")() == 2

    # Check that the server can retrieve a value that doesn't exist
    assert inner_func("c.z")() is None
    assert inner_func("c.z", default=2)() == 2

    # Test

# Generated at 2022-06-10 23:09:50.150475
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Validate that ``cliargs_deferred_get`` works as expected"""
    _init_global_context({})

    def_value = cliargs_deferred_get('foo', default='default')
    assert def_value == 'default'

    CLIARGS['foo'] = 'bar'
    assert def_value() == 'bar'

    CLIARGS['foo'] = ['bar']
    assert def_value() == 'default'
    assert def_value(shallowcopy=True) == ['bar']

    CLIARGS['foo'] = ['a', 'b', 'c']
    assert def_value() == 'default'
    assert def_value(shallowcopy=True) == ['a', 'b', 'c']

    CLIARGS['foo'] = {'a': 'b'}

# Generated at 2022-06-10 23:10:01.836824
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'debug': True, 'verbosity': 3, 'metadata': 'no'})

    assert isinstance(CLIARGS, CLIArgs)
    assert isinstance(CLIARGS, Mapping)
    assert CLIARGS['debug']
    assert CLIARGS['verbosity'] == 3
    assert CLIARGS.get('metadata', 'not_present') == 'no'
    assert CLIARGS.get('filters', 'not_present') == 'not_present'

    assert cliargs_deferred_get('debug')()
    assert cliargs_deferred_get('verbosity')() == 3
    assert cliargs_deferred_get('metadata', 'not_present')() == 'no'

# Generated at 2022-06-10 23:10:09.652707
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    originalCLIARGS = CLIARGS

# Generated at 2022-06-10 23:10:19.851415
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _test_get(key, default=None, shallowcopy=False):
        return cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)()
    class GlobalCLIArgsStub(object):
        def __init__(self, **kwargs):
            self._kwargs = kwargs
        def __setitem__(self, key, value):
            self._kwargs[key] = value
        def __getitem__(self, key):
            return self._kwargs[key]

# Generated at 2022-06-10 23:10:31.103144
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Need a global variable for this
    global CLIARGS
    CLIARGS = CLIArgs(dict(foo=dict(bar=[1, 2, 3])))
    assert cliargs_deferred_get('foo', default=dict(baz=1)) == dict(bar=[1, 2, 3], baz=1)
    assert cliargs_deferred_get('foo') == dict(bar=[1, 2, 3])
    assert cliargs_deferred_get('bar', default=4321) == 4321
    assert cliargs_deferred_get('bar') is None
    assert cliargs_deferred_get('foo', shallowcopy=True) == dict(bar=[1, 2, 3])
    assert cliargs_deferred_get('foo', shallowcopy=True)['bar'] is not CLIARGS.foo

# Generated at 2022-06-10 23:10:36.631173
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    orig = {'foo': 'bar'}
    CLIARGS = CLIArgs(orig)
    expected_result = orig.copy()
    result = cliargs_deferred_get('foo')()
    assert result == expected_result
    assert result is not expected_result
    expected_result = orig['foo']
    result = cliargs_deferred_get('foo')(shallowcopy=True)
    assert result == expected_result
    assert result is orig['foo']

# Generated at 2022-06-10 23:11:03.581395
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'foovals', 'bar': 'barvals'})

    closure = cliargs_deferred_get('foo')
    assert closure() == 'foovals'

    closure = cliargs_deferred_get('bar', 'baz')
    assert closure() == 'barvals'

    closure = cliargs_deferred_get('baz', 'baz')
    assert closure() == 'baz'

    closure = cliargs_deferred_get('foo', shallowcopy=True)
    assert closure() == 'foovals'

    CLIARGS['bar'] = [1, 2, 3]
    closure = cliargs_deferred_get('bar', shallowcopy=True)
    assert closure() == [1, 2, 3]

    CLIAR

# Generated at 2022-06-10 23:11:09.370537
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    assert callable(cliargs_deferred_get('foo'))
    assert callable(cliargs_deferred_get('foo', 'bar'))
    assert callable(cliargs_deferred_get('foo', default='bar'))
    assert callable(cliargs_deferred_get('foo', default='bar', shallowcopy=True))
    assert callable(cliargs_deferred_get('foo', shallowcopy=True))

# Generated at 2022-06-10 23:11:19.914070
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for function cliargs_deferred_get"""
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import PY3

    global CLIARGS
    CLIARGS = CLIArgs({'test_list': [1, 2, 3],
                       'test_list_default': [4, 5, 6],
                       'test_set': set([1, 2, 3]),
                       'test_dict': {'a': 1, 'b': 2, 'c': 3},
                       'test_dict_default': {'d': 4, 'e': 5, 'f': 6}})

    # No shallow copy

# Generated at 2022-06-10 23:11:31.630073
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct data"""

    # pylint: disable=missing-docstring
    import pytest

    class Args:
        cli_options = {
            'a_list': [],
            'a_set': set(),
            'a_dict': {},
        }

    # Empty args
    args = Args()
    CLIARGS.clear()
    CLIARGS.update(args.cli_options)
    cliargs_deferred_get('a_list')() == []
    cliargs_deferred_get('a_set')() == set()
    cliargs_deferred_get('a_dict')() == {}

    # Non empty args
    args = Args()

# Generated at 2022-06-10 23:11:39.502922
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test CliArgs deferred get"""

# Generated at 2022-06-10 23:11:47.508658
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # tests where we don't use the closure
    CLIARGS = GlobalCLIArgs.from_options({'HOST_KEY_CHECKING': True})
    assert CLIARGS.get('HOST_KEY_CHECKING') is True
    # test where we would be calling the closure
    try:
        foo = cliargs_deferred_get('HOST_KEY_CHECKING')
        assert foo is not None
        assert foo() is True
    finally:
        CLIARGS = CLIArgs({})

# Generated at 2022-06-10 23:11:57.149895
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with a shallowcopy and without a shallowcopy
    # Make sure we don't end up with a stale COPYED reference
    # Test with a deepcopy
    # Test with a scalar
    import copy
    import random
    value = {'foo': random.random(), 'bar': random.random()}
    _init_global_context(dict(foo=value))
    copy_func = copy.copy if random.choice((True, False)) else copy.deepcopy
    deferred_value = cliargs_deferred_get('foo', shallowcopy=copy_func)
    assert deferred_value() is value
    for _ in range(10):
        random.shuffle(list(value.keys()))
        assert deferred_value() == value
    _init_global_context(dict(foo='value'))
    assert cliargs_