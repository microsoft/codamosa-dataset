

# Generated at 2022-06-20 13:54:44.995996
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    >>> from ansible.utils.context_objects import GlobalCLIArgs
    >>> from ansible.utils.context_manager import _init_global_context
    >>> from ansible.utils.context_objects import cliargs_deferred_get

    >>> args = {'foo': 1}
    >>> _init_global_context(args)

    >>> callback = cliargs_deferred_get('foo')
    >>> assert callback() == 1

    >>> callback = cliargs_deferred_get('bar')
    >>> assert callback() is None

    >>> callback = cliargs_deferred_get('bar', default='dog')
    >>> assert callback() == 'dog'

    >>> _init_global_context(GlobalCLIArgs())
    """
    pass

# Generated at 2022-06-20 13:54:54.286283
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': []})
    f = cliargs_deferred_get('foo', [])
    assert f() == []
    CLIARGS = CLIArgs({'foo': 1})
    f = cliargs_deferred_get('foo', 2)
    assert f() == 1
    CLIARGS = CLIArgs({'foo': None})
    f = cliargs_deferred_get('foo', 2)
    assert f() is None
    f = cliargs_deferred_get('bar', 2)
    assert f() == 2
    # Test shallow copy
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    f = cliargs_deferred_get('foo', shallowcopy=True)

# Generated at 2022-06-20 13:55:04.226613
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check_equal_and_shallowcopy(func, key, default, shallowcopy, expected):
        assert func() == expected, "value was not equal"
        if shallowcopy and isinstance(expected, (dict, list)):
            assert func() is not expected, "value was not shallow copied"
        elif shallowcopy and isinstance(expected, set):
            assert func() is not expected, "value was not shallow copied"

    cli_args = {'a': 'a'}
    _init_global_context(cli_args)
    check_equal_and_shallowcopy(cliargs_deferred_get('a'), 'a', None, False, 'a')

    cli_args = {'a': ['a', 'b', 'c']}
    _init_global_context(cli_args)
    check_equal

# Generated at 2022-06-20 13:55:14.970145
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class _GlobalCLIArgs(GlobalCLIArgs):
        def __init__(self, val):
            self.val = val
        def get(self, key, default=None):
            return self.val
    global CLIARGS
    CLIARGS = _GlobalCLIArgs(None)
    assert cliargs_deferred_get('key')() is None
    CLIARGS = _GlobalCLIArgs('value')
    assert cliargs_deferred_get('key')() == 'value'
    CLIARGS = _GlobalCLIArgs(default='value')
    assert cliargs_deferred_get('key', default='value')() == 'value'
    CLIARGS = _GlobalCLIArgs([0, 1, 2])

# Generated at 2022-06-20 13:55:19.059970
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCliArg(CLIArgs):
        def __init__(self, options):
            super(TestCliArg, self).__init__(options)
            self._options = options

        def _get_option(self, key):
            return self._options[key]

    # Ensure the inner function works when the outer function works
    inner = cliargs_deferred_get('foo', 'bar')
    assert inner() == 'bar'
    CLIARGS = TestCliArg({'foo': 'fooval'})
    assert inner() == 'fooval'

    # Ensure that the closure over the getter works
    assert cliargs_deferred_get('foo', 'bar')() == 'fooval'

# Generated at 2022-06-20 13:55:30.571459
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    old_cliargs = CLIARGS
    CLIARGS = CLIArgs({'my_option': {'one': 1, 'two': 2}})


# Generated at 2022-06-20 13:55:42.160256
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo', 42)() == 42
    assert cliargs_deferred_get('foo', [])() == []
    assert cliargs_deferred_get('foo', set())() == set()
    assert cliargs_deferred_get('foo', {})() == {}
    assert cliargs_deferred_get('foo', 42, shallowcopy=True)() == 42
    assert cliargs_deferred_get('foo', [], shallowcopy=True)() == []
    assert cliargs_deferred_get('foo', set(), shallowcopy=True)() == set()
    assert cliargs_deferred_get('foo', {}, shallowcopy=True)() == {}
    # Now test some collections

# Generated at 2022-06-20 13:55:54.383355
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get()"""
    global CLIARGS

# Generated at 2022-06-20 13:56:05.900378
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['a'] = 1
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('a', default=2)() == 1
    assert cliargs_deferred_get('b', default=2)() == 2
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('b', shallowcopy=True)() == None

    CLIARGS['a'] = [1]
    assert cliargs_deferred_get('a', shallowcopy=True)() == [1]
    assert cliargs_deferred_get('a', shallowcopy=False)() == [1]
    CLIARGS['a'].append(2)

# Generated at 2022-06-20 13:56:16.599082
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Unit test for function cliargs_deferred_get
    global CLIARGS
    class CliArgs(Mapping):
        def __getitem__(self, key):
            return CLIARGS[key]

        def __iter__(self):
            return iter(CLIARGS)

        def __len__(self):
            return len(CLIARGS)

    # Test deferred get with default value
    default = 'default'
    CLIARGS = CliArgs()
    assert cliargs_deferred_get('foo', default=default)() == default
    # Test deferred get with existing value
    cmdline = '--foo bar'
    value = 'bar'
    CLIARGS = GlobalCLIArgs.from_commandline(cmdline.split())

# Generated at 2022-06-20 13:56:30.285729
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Unit test for cliargs_deferred_get
    """
    cliargs_init(dict(key1=True,
                      key2="value",
                      key3=['a', 'b', 'c'],
                      key4={'a': 'b', 'c': 'd', 'e': 'f'}))
    def test_get(key, default=None):
        return cliargs_deferred_get(key, default, shallowcopy=True)()
    assert test_get('key1') is True
    assert test_get('key2') == 'value'
    assert test_get('key3', default=[]) == ['a', 'b', 'c']
    assert test_get('key4', default={}) == {'a': 'b', 'c': 'd', 'e': 'f'}


# Generated at 2022-06-20 13:56:39.940774
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS

    # args is a dict-like object that works like a dict but isn't a dict
    class Args(Mapping):
        def __init__(self, data):
            self.data = data

        def __getitem__(self, key):
            return self.data[key]

        def __iter__(self):
            return iter(self.data)

        def __len__(self):
            return len(self.data)

    # Check for backing store
    CLIARGS = CLIArgs({})
    key = 'key'
    value = object()
    assert cliargs_deferred_get(key)() is None
    CLIARGS.data[key] = value
    assert cliargs_deferred_get(key)()

# Generated at 2022-06-20 13:56:49.453011
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = dict(foo=dict(a='a'), bar=['x', 'y'], baz=16)
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo', shallowcopy=True)() == dict(a='a')
    assert cliargs_deferred_get('bar', shallowcopy=True)() == ['x', 'y']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == 16
    assert cliargs_deferred_get('nonexistent', shallowcopy=True)() is None
    assert cliargs_deferred_get('nonexistent', 'default', shallowcopy=True)() == 'default'

# Generated at 2022-06-20 13:56:59.318373
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Basic test to ensure cliargs_deferred_get works."""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default='moo')() == 'moo'
    assert cliargs_deferred_get('foo', shallowcopy=True, default=['a', 'b', 'c'])() == ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', shallowcopy=True, default=set(['a', 'b', 'c']))() == set(['a', 'b', 'c'])


# Generated at 2022-06-20 13:57:09.850186
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common import remove_values
    import copy

    assert cliargs_deferred_get('foo')(lambda: 'bar') == 'bar'

    # Test immutable types
    assert cliargs_deferred_get('foo')(lambda: 'bar') == 'bar'
    assert cliargs_deferred_get('foo')(lambda: 'baz') == 'baz'

    # Test mutable types
    sequence = [1,2,3]
    assert cliargs_deferred_get('foo')(lambda: sequence) == sequence
    sequence.append(4)
    assert cliargs_deferred_get('foo')(lambda: sequence) == [1,2,3,4]

    copy_sequence = copy.copy(sequence)

# Generated at 2022-06-20 13:57:20.429248
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Default functionality
    def clo1():
        return cliargs_deferred_get('foo')()
    CLIARGS = CLIArgs({})
    assert None is clo1()

    # Default value
    def clo2():
        return cliargs_deferred_get('foo', default='bar')()
    CLIARGS = CLIArgs({})
    assert 'bar' == clo2()

    # Basic getting value
    def clo3():
        return cliargs_deferred_get('foo')()
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert 'bar' == clo3()

    # Shallow copy of an immutable value
    def clo4():
        return cliargs_deferred_get('foo', shallowcopy=True)()

# Generated at 2022-06-20 13:57:25.839462
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('undefined', default=None)() is None
    assert cliargs_deferred_get('undefined', default=None, shallowcopy=True)() is None
    assert cliargs_deferred_get('undefined', default='default', shallowcopy=True)() == 'default'
    CLIARGS['undefined'] = 'value'
    assert cliargs_deferred_get('undefined', default=None, shallowcopy=True)() == 'value'
    # shallowcopy=True
    assert cliargs_deferred_get('undefined', default=None, shallowcopy=True)() == 'value'
    CLIARGS['undefined'] = ['value']
    assert cliargs_deferred_get('undefined', default=None, shallowcopy=True)() == ['value']
   

# Generated at 2022-06-20 13:57:34.766644
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = {'key': 'value', 'key1': ['ansible', 'rocks']}
    _init_global_context(args)

    def_get = cliargs_deferred_get('key', default='default')
    assert def_get() == 'value'

    def_get = cliargs_deferred_get('key1', default='default')
    assert def_get() == ['ansible', 'rocks']

    def_get = cliargs_deferred_get('key2', default='default')
    assert def_get() == 'default'


# These are deprecated apis that we should not be using anymore
# they will be removed in 2.14
from ansible.utils.context_objects import get_context as commandline_get_context
from ansible.utils.context_objects import get_play_context

# Generated at 2022-06-20 13:57:45.459994
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    CLIARGS = CLIArgs({'foo': 'oof', 'baz': [1, 2, 3]})
    assert cliargs_deferred_get('foo')(),cliargs_deferred_get('foo')() == ('oof', 'oof')
    assert cliargs_deferred_get('foo', shallowcopy=True), cliargs_deferred_get('foo', shallowcopy=True) == ('oof', 'oof')
    assert cliargs_deferred_get('baz'), cliargs_deferred_get('baz') == ([1, 2, 3], [1, 2, 3])
    baz_returned = cliargs_deferred_get('baz', shallowcopy=True)
   

# Generated at 2022-06-20 13:57:55.679071
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get with different values of shallowcopy
    """

    # Test the default value
    default_value = 1
    init_value = cliargs_deferred_get('key', default=default_value)()
    assert default_value == init_value
    assert id(default_value) != id(init_value)

    # Test shallowcopy=False on cliargs_deferred_get
    inner = cliargs_deferred_get('key', shallowcopy=False)
    _init_global_context(CLIArgs({'key': default_value}))
    value = inner()
    assert value is default_value
    assert id(default_value) == id(value)

    # Test shallow copy on a set
    init_value = set(range(20))
    inner = cliargs_

# Generated at 2022-06-20 13:58:10.289583
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get function"""
    # pylint: disable=protected-access
    # This is a test function

    # The function under test is not bound to a global object
    # It directly refers to the global object so we need to provide it
    # for testing:
    global CLIARGS
    test_args = {'foo': 'bar', 'baz': [1, 2, 3], 'boing': {'a': 1, 'b': 2}}
    CLIARGS = CLIArgs(test_args)

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('boing')() == {'a': 1, 'b': 2}



# Generated at 2022-06-20 13:58:21.978394
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'test_key': 'test_value'})
    assert 'test_value' == cliargs_deferred_get('test_key')()
    assert 'default_value' == cliargs_deferred_get('invalid_key', 'default_value')()
    assert None is cliargs_deferred_get('invalid_key')()

    test_list = ['list', 'values']
    CLIARGS.update({'test_list': test_list})

    # Test both shallow and non-shallow copies
    shallow_copy = cliargs_deferred_get('test_list', shallowcopy=True)()
    non_shallow_copy = cliargs_deferred_get('test_list', shallowcopy=False)()

# Generated at 2022-06-20 13:58:31.362172
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test to make sure the deferred get closures work"""
    # This works with the inner function only touching the outer closure
    # pylint: disable=cell-var-from-loop
    for key, value in (
            # pylint: disable=invalid-name
            ('list', [1, 2, 3]),
            ('set', set([1, 2, 3])),
            ('dict', {'a': 1, 'b': 2, 'c': 3}),
            ('string', 'abc'),
            ('bool', True),
            ('none', None),
            ('unknown', 'foo'),
    ):
        assert cliargs_deferred_get(key, 'foo')() == value

# Generated at 2022-06-20 13:58:42.408491
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    init_args = dict(a=1, b='1', c=1.1, d=dict(e=1, f='1', g=1.1), s=set([1, '1', 1.1]))
    CLIARGS = CLIArgs(init_args)
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == '1'
    assert cliargs_deferred_get('c')() == 1.1
    assert cliargs_deferred_get('d')() == dict(e=1, f='1', g=1.1)
    assert set(cliargs_deferred_get('d').items()) == set(dict(e=1, f='1', g=1.1).items())
   

# Generated at 2022-06-20 13:58:53.306164
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs
    cli_args = CliArgs({'foo': 'bar', 'baz': ['a', 'b', 'c']})
    _init_global_context(cli_args)

    # Test simple get
    assert cliargs_deferred_get('baz')() == ['a', 'b', 'c']
    # Test default
    assert cliargs_deferred_get('doe', default='def')() == 'def'
    # Test shallow copy
    baz = cliargs_deferred_get('baz', shallowcopy=True)()
    baz[0] = 'x'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['x', 'b', 'c']

# Generated at 2022-06-20 13:59:05.345824
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeCLIArgs(Mapping):
        def __getitem__(self, key):
            if key == 'a':
                # Testing this works with a non-shallow copyable
                return lambda: None
            elif key == 'b':
                # Shallow copyable
                return lambda: None
            elif key == 'c':
                return lambda: None
            elif key == 'd':
                return lambda: None
            return None
        def __len__(self):
            return 4
        def __iter__(self):
            return iter(['a', 'b', 'c', 'd'])
    CLIARGS = FakeCLIArgs()

    assert cliargs_deferred_get('a') == cliargs_deferred_get('a')

# Generated at 2022-06-20 13:59:13.448754
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make a new instance for testing, we really should refactor this to use
    # the singleton
    cliargs = CLIArgs({'foo': 'bar'})
    deferred_key = cliargs_deferred_get('foo', 'default')
    assert deferred_key() == 'bar'
    deferred_key2 = cliargs_deferred_get('answer', 42)
    assert deferred_key2() == 42
    # Shallow copy
    foo_value = cliargs['foo']
    assert id(foo_value) == id(deferred_key())
    foo_copy = deferred_key(shallowcopy=True)
    assert id(foo_value) != id(foo_copy)
    # Using whatever the current CLIARGS is

# Generated at 2022-06-20 13:59:22.255079
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_fn():
        cliargs_deferred_get('foo')
    class TestException(Exception):
        pass

    # Test get with default
    _init_global_context({})
    assert cliargs_deferred_get('foo', default='bar') == 'bar'
    _init_global_context({'foo': 'baz'})
    assert cliargs_deferred_get('foo', default='bar') == 'baz'

    # Test get without default
    _init_global_context({})
    try:
        cliargs_deferred_get('foo')
    except TestException as e:
        assert "foo" in str(e)
    else:
        assert False, "Expected an exception"

    # Test get with non-copyable object

# Generated at 2022-06-20 13:59:30.957496
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    mydict = dict(a=1, b=2, c=dict(d=3, e=4))
    CLIARGS['mydict'] = mydict
    assert cliargs_deferred_get('mydict', shallowcopy=False) is mydict
    assert cliargs_deferred_get('mydict', shallowcopy=True) == mydict

    CLIARGS['mylist'] = [1, 2, 3, 4]
    assert cliargs_deferred_get('mylist', shallowcopy=False) is CLIARGS['mylist']
    assert cliargs_deferred_get('mylist', shallowcopy=True) == CLIARGS['mylist']

# Generated at 2022-06-20 13:59:41.158426
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.cli.arguments import get_base_parser

    # the results of this should be a parser with the defaults set
    parser = get_base_parser(suppress_extras=True)

    # Create non-singleton CLIArgs
    CLIARGS = CLIArgs({})
    # add default ARGUMENT_ATTRIBUTE_CLASS namespace to parser
    parser.set_defaults(**CLIARGS.get_defaults())
    # Parse cliargs
    # XXX: The namespace is not readonly so if someone modifies the cliargs between the parse
    # and the _init_global_context we are in trouble when we replace the cliargs below
    cliargs = parser.parse_args()
    _init_global_context(cliargs)

    shallow_default = object()
    assert cliargs

# Generated at 2022-06-20 14:00:00.810119
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'a': [1, 2, 3]}
    _init_global_context(cli_args)
    assert CLIARGS.a == [1, 2, 3]
    fget = cliargs_deferred_get('a', shallowcopy=False)
    # assert shallowcopy=False
    assert fget() == [1, 2, 3]
    fget = cliargs_deferred_get('b', shallowcopy=False)
    assert fget() is None
    fget = cliargs_deferred_get('a', shallowcopy=True)
    # assert shallowcopy=True
    assert fget() == [1, 2, 3]
    fget = cliargs_deferred_get('b', shallowcopy=True)
    assert fget() is None

# Generated at 2022-06-20 14:00:09.838550
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    from ansible.module_utils.common.collections import SimpleAttr

    cliargs = CLIARGS
    cliargs['abc'] = 123
    cliargs['xyz'] = SimpleAttr()

    # normal processing
    assert cliargs_deferred_get('abc')() == 123
    assert cliargs_deferred_get('xyz')() == SimpleAttr()

    # missing key
    assert cliargs_deferred_get('klm')() == None

    # shallow copy
    a = [1, 2, 3, 'abc']
    b = cliargs_deferred_get('abc', shallowcopy=True)()
    assert b == a
    a[0] = 'xyz'
    assert b[0] == 1

    c = cliargs_deferred_get

# Generated at 2022-06-20 14:00:17.772472
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'test': 'value', 'testlist': [1, 2, 3]})
    assert cliargs_deferred_get('test')() == 'value'
    assert cliargs_deferred_get('testlist')() == [1, 2, 3]
    assert cliargs_deferred_get('test', default='newvalue')() == 'value'
    assert cliargs_deferred_get('test2', default='newvalue')() == 'newvalue'
    assert cliargs_deferred_get('testlist')() is not CLIARGS['testlist']
    assert cliargs_deferred_get('testlist', shallowcopy=True)() is not CLIARGS['testlist']
    assert cliargs_deferred_get('testlist', shallowcopy=True)() == CLIARGS

# Generated at 2022-06-20 14:00:19.923978
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import types
    assert isinstance(cliargs_deferred_get('dummy'), types.FunctionType), 'Returned not a function'

# Generated at 2022-06-20 14:00:28.966065
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'x': {'y': [1, 2]}})
    f = cliargs_deferred_get
    assert 1 == f('x.y.0', default=None)
    assert 2 == f('x.y.1', default=None)
    assert CLIARGS.x.y is f('x.y', shallowcopy=False)
    assert [1, 2] == f('x.y', shallowcopy=True)
    assert 1 == f('y.x.0', default=1)

# Generated at 2022-06-20 14:00:35.556438
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Set up a temp global cli variable for the closure to use.
    # _init_global_context doesn't do anything to cliargs so we don't need to call it
    global CLIARGS
    CLIARGS = GlobalCLIArgs(test_data={'one':1, 'two':[1,2,3], 'three':{'a':'A', 'b':'B'}})

    # Test the non-copy version
    assert cliargs_deferred_get('one', default=None)() == 1
    assert cliargs_deferred_get('two', default=None)() == [1,2,3]
    assert cliargs_deferred_get('three', default=None)() == {'a':'A', 'b':'B'}

# Generated at 2022-06-20 14:00:46.752346
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get function

    Make sure it shallowcopies the right type of things and returns the original for
    immutable types
    """
    class Config(object):
        class cliargs(object):
            extra_vars = None
            extra_var_strings = None
            vault_password_files = None
            vault_ids = None
            vault_identity = None

    config = Config()

    # Test with default
    default = {'test' : 'test_value'}
    fn = cliargs_deferred_get('test_key', default=default)
    config.cliargs.test_key = fn
    assert config.cliargs.test_key == default

    # Test without default
    fn = cliargs_deferred_get('test_key2')
    config.cliargs.test

# Generated at 2022-06-20 14:00:57.762150
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=too-many-locals
    # The number of locals is kind of the point
    import sys

    def test_function(values, expected_cliargs, expected_values):
        global CLIARGS
        instance = CLIArgs({})
        for val in values:
            instance[val[0]] = val[1]

        CLIARGS = instance

        for key in expected_cliargs:
            print(cliargs_deferred_get(key)())

        print()
        global_instance = GlobalCLIArgs.from_options(instance)
        CLIARGS = global_instance
        for key, func in expected_values:
            print("key={}, value={}".format(key, func()))


# Generated at 2022-06-20 14:01:09.351242
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    import sys

    class CLIArgs(object):
        def get(self, key, default=None):
            return key

    global CLIARGS
    CLIARGS = CLIArgs()

    x = 1
    # Check that the function returns the correct value
    assert cliargs_deferred_get('dummy-value')(x == 'dummy-value')

    # Check the default value
    assert cliargs_deferred_get('default-value', default='default-value')(x == 'default-value')

    x = [1, 2, 3, 4]
    y = cliargs_deferred_get('a-list', shallowcopy=False)(x == 'a-list')
    # Check that the same instance is returned
    assert x is y

    x = [1, 2, 3, 4]
   

# Generated at 2022-06-20 14:01:14.248746
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Temporary replacement for CLIARGS
    #
    # Note: this is in test_context because this function is only called in some
    #       templated tests, and so won't be pulled in.  It's easier to just
    #       load the test file for this function and use this module's cliargs
    #       class
    cliargs = CLIArgs({
        'key1': 'abc',
        'key2': ['abc'],
        'key3': {'abc': 'def'},
        'key4': set('abc'),
    })
    global CLIARGS
    cliargs_orig = CLIARGS
    CLIARGS = cliargs

# Generated at 2022-06-20 14:01:43.046924
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class NotAContext(object):
        def __init__(self, seq=None):
            self._seq = seq

        def get(self, key, default=None):
            return self._seq[key]

    seq = {
        'a': [1, 2, 3],
        'b': {'a': 1},
        'c': (1, 2, 3),
        'd': {1, 2, 3},
    }
    context = NotAContext(seq=seq)

    for key in seq:
        get_value = cliargs_deferred_get(key)
        assert get_value() == seq[key], 'value returned from context should match original value'

    # Test shallow copy

# Generated at 2022-06-20 14:01:54.435472
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar', default='blech')() == 'blech'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('bar', default='blech', shallowcopy=True)() == 'blech'

    CLIARGS = CLIArgs({'foo': ['bar', 'blech']})
    assert cliargs_deferred_get('foo')() == ['bar', 'blech']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'blech']


# Generated at 2022-06-20 14:02:04.576410
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_clis = (
        {},
        {'ANSIBLE_TEST_CLI': 1},
        {'ANSIBLE_TEST_CLI': [1,2,3]},
        {'ANSIBLE_TEST_CLI': {'a': 1, 'b': 2}},
        {'ANSIBLE_TEST_CLI': (1,2,3)},
        {'ANSIBLE_TEST_CLI': {1,2,3}},
    )
    for test_cli in test_clis:
        # Ensure that we are not shallow copying
        test_value = cliargs_deferred_get('ANSIBLE_TEST_CLI')().get('ANSIBLE_TEST_CLI')
        cliargs_deferred_get('ANSIBLE_TEST_CLI')().update

# Generated at 2022-06-20 14:02:14.106876
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable,too-many-branches,too-many-statements
    tmp_cliargs = CLIARGS
    CLIARGS = GlobalCLIArgs({})
    _init_global_context(dict(test_key='foo'))

    # Did not specify a key to get so we get default
    assert (cliargs_deferred_get('fake_key', default='foo')() == 'foo')

    # Specified a key that has a value so we get the value back
    assert (cliargs_deferred_get('test_key', default='foo')() == 'foo')

    # Specified a key that has no value so we get the default
    assert (cliargs_deferred_get('fake_key', default='foo')() == 'foo')

    # Specified a key that has no value

# Generated at 2022-06-20 14:02:22.658126
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': {'bar': 'test'}})
    assert cliargs_deferred_get('foo')() == cliargs_deferred_get('foo')()
    assert cliargs_deferred_get('foo')() is cliargs_deferred_get('foo')()
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not cliargs_deferred_get('foo', shallowcopy=True)()
    assert cliargs_deferred_get('foo', shallowcopy=True)() == cliargs_deferred_get('foo', shallowcopy=True)()

# Generated at 2022-06-20 14:02:32.083634
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence

    class Stub:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __call__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            return 'dummy'

    def check_default(key):
        dg = cliargs_deferred_get(key=key, default='default')
        assert dg() == 'default'
        assert dg.__name__ == key

    def check_shallow_copy_default(key):
        dg = cliargs_deferred_get(key=key, default='default', shallowcopy=True)
        assert dg() == 'default'


# Generated at 2022-06-20 14:02:40.366059
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # set global object to our test object
    CLIARGS = CLIArgs({})
    # test running with empty dictionary inside `cliargs_deferred_get`
    _dummy_func = cliargs_deferred_get('some_key', 'default_value')
    assert _dummy_func() == 'default_value'

    # test running with empty dictionary inside `cliargs_deferred_get`
    CLIARGS = CLIArgs({'some_key': 'some_value'})
    _dummy_func = cliargs_deferred_get('some_key', 'default_value')
    assert _dummy_func() == 'some_value'

# Generated at 2022-06-20 14:02:47.961010
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': [1, 2, 3], 'bar': {'a': 'b', 'c': 'd'}, 'baz': set(['x', 'y', 'z'])})
    # Test getting a list
    assert cliargs_deferred_get('foo', default=[])() == [1, 2, 3]
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    # Test getting a mapping
    assert cliargs_deferred_get('bar', default={})() == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-20 14:02:55.887267
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = {'foo': 'bar', 'bar': [1, 2, 3]}

    assert cliargs_deferred_get('foo')(), 'bar'
    assert cliargs_deferred_get('foo', default='baz')(), 'bar'
    assert cliargs_deferred_get('baz')(), None
    assert cliargs_deferred_get('baz', default='qux')(), 'qux'

    assert cliargs_deferred_get('bar')(), [1, 2, 3]
    assert cliargs_deferred_get('bar', default='baz')(), [1, 2, 3]

    assert cliargs_deferred_get('foo', shallowcopy=True)(), 'bar'

# Generated at 2022-06-20 14:03:06.189742
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', 'xyz')() == 'bar'
    CLIARGS['foo'] = []
    assert cliargs_deferred_get('foo', [0, 1, 2])() == []
    assert cliargs_deferred_get('foo', [0, 1, 2], shallowcopy=True)() == []
    CLIARGS['foo'].append(1)
    assert cliargs_deferred_get('foo', [0, 1, 2], shallowcopy=True)() == [1]

# Generated at 2022-06-20 14:03:33.018138
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-20 14:03:36.162039
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Tests that this function works immediately without initializing the context object
    # to return the default value (None)
    assert cliargs_deferred_get('fail_on_lookup', default='foo')() == 'foo'

# Generated at 2022-06-20 14:03:45.153683
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible import context
    CLIARGS['command_name'] = 'test_cmd'
    CLIARGS['module_name'] = 'test_module'
    CLIARGS['actions'] = ['a','b','c']
    CLIARGS['extra'] = {'a': 1}
    CLIARGS['options'] = {'v': True}
    CLIARGS['output_path'] = '/tmp/test_output.txt'
    CLIARGS['playbook_path'] = '/tmp/test_playbook.yml'
    context.CLIARGS.update({'test1_bool': None, 'test2_str': 'str', 'test3_set': set(['a', 'b']), 'test4_dict': {'a': 1}})

    # Make sure we get a shallow copy
    assert cliargs

# Generated at 2022-06-20 14:03:56.931451
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""

    # Create a global cliargs for a singleton which returns a default value
    global CLIARGS
    CLIARGS = GlobalCLIArgs({})

    # Test default value
    cliargs_deferred_get('non_existent_key', default='foo')(), 'foo'

    # Test default value not used when key is defined
    CLIARGS = GlobalCLIArgs({'non_existent_key': 'bar'})
    cliargs_deferred_get('non_existent_key', default='foo')(), 'bar'

    # Check other types
    CLIARGS = GlobalCLIArgs({'some_key': 'bar'})
    cliargs_deferred_get('some_key', default=['foo'])() is ['foo'], False
    cli

# Generated at 2022-06-20 14:04:03.748082
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # sanity
    CLIARGS = CLIArgs({})

    assert cliargs_deferred_get('nonexistant_key')() == None
    assert cliargs_deferred_get('nonexistant_key', default='something')() == 'something'

    CLIARGS = CLIArgs({'hello': 'world'})

    assert cliargs_deferred_get('hello')() == 'world'
    assert cliargs_deferred_get('hello')() == 'world'

    CLIARGS = CLIArgs({'hello': [1, 2, 3]})
    assert cliargs_deferred_get('hello', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('hello', shallowcopy=False)() == [1, 2, 3]

   

# Generated at 2022-06-20 14:04:14.947986
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # reset CLIARGS because this unit test runs after the global context has been initialized
    global CLIARGS
    CLIARGS = CLIArgs({})

    # get should work without an exception without cli_args being parsed
    assert cliargs_deferred_get('foo') is None
    assert cliargs_deferred_get('foo', default='bar') == 'bar'

    # but once they are it should get the value
    cli_args = {'foo': 'hello'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo') == 'hello'
    assert cliargs_deferred_get('foo', default='bar') == 'hello'

    # shallowcopy also works
    cli_args = {'foo': [1,2,3]}
    _init_global

# Generated at 2022-06-20 14:04:19.901501
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    >>> _init_global_context(dict(a=1, b=2, c=[1, 2, 3]))
    >>> assert cliargs_deferred_get('b')() == 2
    >>> c = 3
    >>> assert cliargs_deferred_get('c')() == [1, 2, 3]
    >>> assert c == 3
    """
    pass

# Generated at 2022-06-20 14:04:28.334893
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    from ansible.module_utils.common.text.converters import to_bytes
    def test_func(key, default, expected_value, cliargs=CLIARGS):
        assert cliargs_deferred_get(key, default=default)() == expected_value
        assert cliargs_deferred_get(key, default=default, shallowcopy=True)() == expected_value

    # Test case: key is not present in cliargs
    test_func('foo.bar', 'baz', 'baz')
    # Test case: key is present in cliargs
    cliargs = {'foo': {'bar': 'baz'}}
    test_func('foo.bar', 'qux', 'baz', cliargs=CLIArgs(cliargs))

    # Test case:

# Generated at 2022-06-20 14:04:35.948338
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_data = {
        'hostfile': '/tmp/hosts',
        'private_key_file': '/tmp/key',
        'inventory': ['/tmp/hosts'],
        'remaining_args': [
            '-m', 'command',
            '-a', 'uname -a',
            '-u', 'root',
            'localhost'
        ]
    }
    _init_global_context(cliargs_data)
    assert cliargs_deferred_get('hostfile')() == cliargs_data['hostfile']
    assert cliargs_deferred_get('hostfile', default='missing')() == cliargs_data['hostfile']
    assert cliargs_deferred_get('missing_key')() is None