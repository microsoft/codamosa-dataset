

# Generated at 2022-06-20 13:54:38.550741
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.reset()

    # simple value
    assert cliargs_deferred_get('log_path')() is None
    CLIARGS.update(dict(log_path='/tmp/log'))
    assert cliargs_deferred_get('log_path')() == '/tmp/log'

    # default value
    assert cliargs_deferred_get('verbosity', default=2)() == 2
    assert cliargs_deferred_get('verbosity', default=2)() == 2
    CLIARGS.update(dict(verbosity=3))
    assert cliargs_deferred_get('verbosity', default=2)() == 3

    # list
    assert cliargs_deferred_get('skip_tags', shallowcopy=True)() is None

# Generated at 2022-06-20 13:54:46.923913
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test closure over getting a key from CLIARGS with shallow copy functionality
    """
    def _test_value(value):
        """Test function for asserting the provided value"""
        if is_sequence(value):
            assert value == [1, 2, 3]
        elif isinstance(value, (Mapping, Set)):
            assert value == {'key': 'value'}
        else:
            assert value == 'value'

    cliargs_mock = CLIArgs(dict(key=[1, 2, 3], target='value'))
    # This function is not directly bound to ``CliArgs`` or ``CLIARGS`` so that it
    # works with ``CLIARGS`` being replaced
    cliargs_mock_get = cliargs_deferred_get('key')
    # Not sure why this doesn't work

# Generated at 2022-06-20 13:54:55.977460
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_args = {
        'foo': 'bar',
        'baz': {'a': 1, 'b': 2},
    }
    test_default = 'test'
    _init_global_context(test_args)

    assert cliargs_deferred_get('foo')(), test_args['foo']
    assert cliargs_deferred_get('foo', shallowcopy=True)(), test_args['foo']
    assert cliargs_deferred_get('baz', shallowcopy=True)(), test_args['baz']
    assert cliargs_deferred_get('default_key', default=test_default)(), test_default
    assert cliargs_deferred_get('default_key', default=test_default, shallowcopy=True)(), test_default



# Generated at 2022-06-20 13:55:01.544961
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import mock
    with mock.patch('ansible.cli.cli.CLIARGS', {'foo': 'bar'}):
        assert cliargs_deferred_get('foo')() == 'bar'
    with mock.patch('ansible.cli.cli.CLIARGS', {'foo': 'bar'}):
        assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    with mock.patch('ansible.cli.cli.CLIARGS', {'foo': ['baz']}):
        assert cliargs_deferred_get('foo', shallowcopy=True)() == ['baz']
    with mock.patch('ansible.cli.cli.CLIARGS', {'foo': {'baz': 'quux'}}):
        assert cliargs_deferred

# Generated at 2022-06-20 13:55:03.276373
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert (lambda: CLIARGS.get('a')) == cliargs_deferred_get('a')



# Generated at 2022-06-20 13:55:13.723799
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'verbosity': 2, 'foo': {1: 2, 3: 4}}
    _init_global_context(cli_args)
    # Test shallow copy
    assert cliargs_deferred_get('verbosity', shallowcopy=True) == 2
    assert cliargs_deferred_get('foo', shallowcopy=True) == {1: 2, 3: 4}
    # Test shallow copy doesn't copy sequences
    cli_args['foo'][3] = 5
    assert cliargs_deferred_get('foo', shallowcopy=True) == {1: 2, 3: 5}
    # Test shallow copy doesn't copy sets
    cli_args['foo'] = {1, 2, 3, 4}

# Generated at 2022-06-20 13:55:25.671782
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get function"""

    def test_func():
        value = {}
        dict_default = {}
        list_default = []
        value['dict_default'] = cliargs_deferred_get('dict', default=dict_default, shallowcopy=True)
        value['list_default'] = cliargs_deferred_get('list', default=list_default, shallowcopy=True)
        value['dict_nodefault'] = cliargs_deferred_get('dict', default=dict_default, shallowcopy=True)
        value['list_nodefault'] = cliargs_deferred_get('list', default=list_default, shallowcopy=True)
        return value

    # Verify that the value is not returned until we call it
    value = test_func()

# Generated at 2022-06-20 13:55:30.328780
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo')() is None
    CLIAGRS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIAGRS['foo'] = ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']

# Generated at 2022-06-20 13:55:42.117671
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({
        'foo': 'bar',
        'baz': {'bleep': 'bloop'},
        'spam': [1, 2],
        'spam2': [1, 2],
    })
    for arg in cliargs:
        cliargs_deferred_get(arg, shallowcopy=False)()
        cliargs_deferred_get(arg, shallowcopy=True)()
    assert cliargs.get('bleep', 'bloop', shallowcopy=False) == 'bloop'
    assert cliargs.get('bleep', 'bloop', shallowcopy=True) == 'bloop'
    assert cliargs.get('bleep', None, shallowcopy=False) is None
    assert cliargs.get('bleep', None, shallowcopy=True) is None

# Generated at 2022-06-20 13:55:52.969455
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCliArgs:  # pylint: disable=too-few-public-methods
        """A dummy context object that just holds values"""
        def __init__(self, test_values):
            self._values = test_values
        def get(self, key, default=None):
            return self._values.get(key, default=default)
    class TestGlobalCliArgs(TestCliArgs, GlobalCLIArgs):  # pylint: disable=too-few-public-methods
        """A dummy context object that implements the Singleton
        functionality of ``GlobalCLIArgs``"""
        INSTANCE = None
        @classmethod
        def from_options(cls, test_options):
            if cls.INSTANCE is None:
                cls.INSTANCE = cls(test_options)
            return cls

# Generated at 2022-06-20 13:56:00.720913
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-20 13:56:10.582008
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def func():
        pass

    # We need to set a field value so that it knows that it is not uninitialized
    CLIARGS.setdefault("no_log", False)

    global_cli_args = GlobalCLIArgs({})
    assert global_cli_args.get("no_log", True) == True

    global_cli_args = GlobalCLIArgs({"no_log": True})
    assert global_cli_args.get("no_log", False) == True

    # Check for default value
    global_cli_args = GlobalCLIArgs({"no_log": True})
    assert global_cli_args.get("connection", func) is func

    # Check that the closure is working
    global_cli_args = GlobalCLIArgs({"connection": "local"})
    get_connection = cliargs_deferred

# Generated at 2022-06-20 13:56:18.484827
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs

    class FakeArgs(object):
        def get(self, k, default=None):
            return default

    fake_args = FakeArgs()
    # Need to use temporary binding so we don't hit the real ``CLIARGS``
    CLIArgs.CLIARGS = fake_args
    get_foo = cliargs_deferred_get('foo')
    assert get_foo() is None
    assert get_foo(default="test") == "test"
    del CLIArgs.CLIARGS

# Generated at 2022-06-20 13:56:29.752459
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This isn't a perfect unit test; we really want to be testing the value returned
    # from the inner function but that's hard to do.  The best we can do is make sure
    # we are calling inner.
    #
    # We expect this to fail on a lot of the types; should go add them when we find them
    global CLIARGS
    CLIARGS = {'foo': ["a", "b", "c"], 'bar': {'d': 0}, 'baz': set(['a', 'b', 'c'])}
    eq_(cliargs_deferred_get('foo')()[:], ["a", "b", "c"])
    eq_(cliargs_deferred_get('bar')()['d'], 0)
    eq_(cliargs_deferred_get('baz')()['a'], 'a')

# Generated at 2022-06-20 13:56:37.043408
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.clear()
    CLIARGS['base'] = 'base'
    CLIARGS['nest'] = {'level1': 'level1'}
    CLIARGS['nest']['level2'] = 'level2'

    assert cliargs_deferred_get('base')() == 'base'
    assert cliargs_deferred_get('nest')() == {'level2': 'level2', 'level1': 'level1'}
    assert cliargs_deferred_get('nest', shallowcopy=True)() == {'level2': 'level2', 'level1': 'level1'}

    CLIARGS['non-mutating_list'] = [1, 2, 3]
    CLIARGS['non-mutating_tuple'] = (1, 2, 3)
    CLIAR

# Generated at 2022-06-20 13:56:48.220994
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.playbook.play_context import PlayContext, DEFAULT_SUDO_PASS, DEFAULT_SUDO, DEFAULT_SU, DEFAULT_REMOTE_USER, DEFAULT_BECOME_METHOD
    from tempfile import mkdtemp

    class ContextObject(object):
        attr_foo = PlayContext.CLIARGS_ATTRIBUTE('foo')
        attr_bar = PlayContext.CLIARGS_ATTRIBUTE('bar', default='baz')
        attr_shallow = PlayContext.CLIARGS_ATTRIBUTE('shallow', shallowcopy=True, default=[1,2,3])

    # at module import time, CLIARGS is empty
    context = ContextObject()
    assert context.attr_foo is None
    assert context.attr_bar == 'baz'


# Generated at 2022-06-20 13:56:58.346505
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils._text import to_text
    from six import StringIO

    args = StringIO('--connection=local --verbosity')
    opts = {}
    cliargs = Parser(args, opts).parse_args()
    # If this is the first time we've parsed the args, initialize the context
    if CLIARGS is not GlobalCLIArgs():
        _init_global_context(cliargs)

    class TestClass(object):
        def __init__(self, attr):
            self.attr = attr

    # Run tests
    test1 = TestClass(cliargs_deferred_get('connection'))
    assert test1.attr == 'local'
    test2 = TestClass(cliargs_deferred_get('verbosity'))
    assert test2.attr == 'v'
   

# Generated at 2022-06-20 13:57:09.237245
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for ``cliargs_deferred_get``"""
    global CLIARGS

    CLIARGS.update(
        {
            'foo': 'bar',
            'list': [1, 2, 3],
            'dict': {'a': 1, 'b': 2},
        }
    )

    get_bar = cliargs_deferred_get('foo')
    get_list = cliargs_deferred_get('list', shallowcopy=True)
    get_dict = cliargs_deferred_get('dict', shallowcopy=True)
    get_default = cliargs_deferred_get('boo', 'baz', shallowcopy=True)

    assert 'bar' == get_bar()
    assert [1, 2, 3] == get_list()

# Generated at 2022-06-20 13:57:19.942702
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': ['apple', 'banana', 'cherry']})

    # Using default
    assert cliargs_deferred_get('not_there')() is None

    # Getting a key
    assert cliargs_deferred_get('foo')() == 'bar'

    # Getting a key with shallow = False
    assert cliargs_deferred_get('baz', shallowcopy=False)() is CLIARGS['baz']
    assert cliargs_deferred_get('baz')() is CLIARGS['baz']
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not CLIARGS['baz']
    assert cliargs_deferred_get('baz', shallowcopy=True)()

# Generated at 2022-06-20 13:57:30.959135
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def inner(key):
        return cliargs_deferred_get(key)
    # Test local variable
    CLIARGS = CLIArgs({})
    assert inner('fake') is None
    # Test local variable with a default
    CLIARGS = CLIArgs({})
    assert inner('fake')() == 'default'
    # Test with a global variable
    CLIARGS.add_option('fake_global')
    assert inner('fake_global') is None
    assert inner('fake_global')() is None
    CLIARGS.fake_global = 'empire'
    assert inner('fake_global')() == 'empire'
    # Test with a global variable with a default
    CLIARGS.add_option('fake_global_default', default='default')
    assert inner('fake_global_default')() == 'default'
   

# Generated at 2022-06-20 13:57:45.462644
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': 'bar', 'baz': [1, 2, 3]})

    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('baz') == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True) == [1, 2, 3]
    assert cliargs_deferred_get('notthere', 42) == 42
    assert cliargs_deferred_get('notthere', 42, shallowcopy=True) == 42
    assert cliargs_deferred_get('notthere', default=42) == 42
    assert cliargs_deferred_get('notthere', default=42, shallowcopy=True) == 42

# Generated at 2022-06-20 13:57:55.677425
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test_key': 'value'})
    assert cliargs_deferred_get('test_key')() == 'value'
    assert cliargs_deferred_get('missing_key')() is None
    assert cliargs_deferred_get('missing_key', default='value')() == 'value'
    CLIARGS = CLIArgs({'test_dict': {'sub_key': 'sub_value'}})
    outer = cliargs_deferred_get('test_dict')
    inner = cliargs_deferred_get('sub_key')
    assert inner() == outer()['sub_key']
    assert inner() is outer()['sub_key']
    assert inner() == 'sub_value'
    inner_copy = cliargs_deferred_

# Generated at 2022-06-20 13:58:01.072594
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from mock import patch

    # Tests that it handles a scalar and gives a copy
    with patch.object(CLIARGS, 'get', return_value=True):
        assert cliargs_deferred_get('key')() is True
        assert cliargs_deferred_get('key', shallowcopy=True)() is True

    # Tests that it handles a sequence and gives a copy
    with patch.object(CLIARGS, 'get', return_value=list()):
        assert cliargs_deferred_get('key', default=['a'])() == ['a']
        assert cliargs_deferred_get('key', shallowcopy=True, default=['a'])() == ['a']

    # Tests that it handles a mapping and gives a copy

# Generated at 2022-06-20 13:58:10.573986
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foobar')() is None

    # Empty dict
    CLIARGS.update({})
    assert cliargs_deferred_get('foobar')() is None
    # Default defined
    assert cliargs_deferred_get('foobar', default={'a': 'b'})() == {'a': 'b'}

    # Dict with list
    CLIARGS.update({'bar': {'foo': [1, 2, 3]}, 'baz': [4, 5, 6]})
    assert cliargs_deferred_get('bar')() == {'foo': [1, 2, 3]}
    assert cliargs_deferred_get('baz')() == [4, 5, 6]

# Generated at 2022-06-20 13:58:16.898454
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_dict = {'a': 1, 'b': '2', 'c': [3, 3, 3], 'd': {'d': 4}, 'e': {5, 6}, 'f': None, 'g': True}
    _init_global_context(test_dict)
    for key in test_dict:
        assert cliargs_deferred_get(key)() == test_dict[key]

# Generated at 2022-06-20 13:58:27.852692
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # We are testing a closure so have to have a prefilled CLIARGS
    global CLIARGS

    CLIARGS = CLIArgs(dict(a=dict(x=1), b=set([1, 2, 3]), c=10, d=[1, 2, 3]))

    for key in ('a', 'b', 'c', 'd'):
        assert cliargs_deferred_get(key)() == CLIARGS[key]
        assert cliargs_deferred_get(key, default=[])() == CLIARGS.get(key, default=[])
        assert cliargs_deferred_get(key, shallowcopy=True)() == CLIARGS[key]
        assert cliargs_deferred_get(key, shallowcopy=True, default=[])() == CLIARGS.get(key, default=[])

   

# Generated at 2022-06-20 13:58:34.143294
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the functionality of cliargs_deferred_get"""
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    cli_args = CLIArgs(dict(foo='bar', baz=42))
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == 42
    assert cliargs_deferred_get('baz', shallowcopy=True)() == 42
    assert cliargs_deferred_get('baz', shallowcopy=False)() == 42
    assert cliargs_deferred_get('baz', shallowcopy=True)() == 42

# Generated at 2022-06-20 13:58:44.829875
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_gets(value, expected):
        global CLIARGS
        CLIARGS = CLIArgs({'foo': value})
        assert cliargs_deferred_get('foo', shallowcopy=True)() is expected

    # Test primitive types
    test_gets(123, 123)
    test_gets('a', 'a')

    # Test sequences
    a_list = ['a',]
    test_gets(a_list, a_list)
    a_tuple = ('a',)
    test_gets(a_tuple, a_tuple)
    a_set = set()
    a_set.add('a')
    test_gets(a_set, a_set)

    # Test complex types with shallow copy
    a_list_copy = a_list[:]

# Generated at 2022-06-20 13:58:55.634374
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-20 13:59:06.922890
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Make sure deferred get returns the value we expect"""

    # force CLIARGS to be an empty object
    global CLIARGS
    CLIARGS = CLIArgs({})

    # Make sure we can get the default
    # Note: this is a function because we want to make sure the return value is read fresh every time
    deferred_get_default = cliargs_deferred_get('testkey', default='default value')
    actual = deferred_get_default()
    assert actual == 'default value'
    # And make sure the caller can't change the state of the returned value
    actual.append('thing')
    assert actual == 'default value'

    # Now put something into the argument
    CLIARGS['testkey'] = 'real value'
    assert CLIARGS['testkey'] == 'real value'

    # Now the deferred get should return the

# Generated at 2022-06-20 13:59:23.013562
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-20 13:59:34.421238
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get

    Note: This is a unit test because it can only be run with the CLIArgs
    object from the command line.  It is checked into the library so that
    it can be run as a unit test to ensure that it works.
    """
    import tempfile
    import os
    import shutil
    import json


# Generated at 2022-06-20 13:59:43.088619
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_data = {'cows': 'moo'}
    _init_global_context(test_data)
    assert cliargs_deferred_get('cows')() == 'moo'
    assert cliargs_deferred_get('cows', default='quack')() == 'moo'
    assert cliargs_deferred_get('cows', default='quack')() == 'moo'
    # testing that we are getting a copy of the value and not a reference
    assert cliargs_deferred_get('cows', shallowcopy=True)() != 'moo'
    assert cliargs_deferred_get('cows', shallowcopy=True)() == 'moo'
    # testing that we are getting a copy of the value and not a reference
    # we have to do this because Python caches immutable

# Generated at 2022-06-20 13:59:54.048597
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import tempfile
    import sys
    import os
    import shutil
    import random

    class Test_cliargs_deferred_get(unittest.TestCase):
        ''' Unit tests for ``ansible.context.cliargs_deferred_get``'''

        default_str = u'a string'
        default_list = [u'a', u'list']
        default_tuple = (u'a', u'tuple')
        default_set = {u'a', u'set'}
        default_dict = {u'a': u'dict'}
        non_default_str = u'a different string'

# Generated at 2022-06-20 14:00:05.678368
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.clear()
    CLIARGS.update(dict(
        foo='bar',
        baz=[1, 2],
        bob=dict(joe='jim'),
        moo=set([3, 4])
    ))

    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('bar') == None
    assert cliargs_deferred_get('baz') == [1, 2]
    assert cliargs_deferred_get('bob') == dict(joe='jim')
    assert cliargs_deferred_get('moo') == set([3, 4])

    assert cliargs_deferred_get('bar', default=2) == 2

# Generated at 2022-06-20 14:00:14.447185
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # set a bunch of values in GLOBAL_CLIARGS
    GLOBAL_CLIARGS._CLIARGS = {
        'strings': ['foo', 'bar'],
        'nested_strings': ['foo', ['bar', 'baz']],
    }
    # set up attributes on a mock class
    MyClass = type('MyClass', (object,), {})()
    MyClass._my_strings = cliargs_deferred_get(key='strings', default=None)
    MyClass._my_nested_strings = cliargs_deferred_get(key='nested_strings', default=None)
    assert CLIARGS.get('strings') == MyClass._my_strings() == ['foo', 'bar']
    assert CLIARGS.get('nested_strings') == MyClass._my_n

# Generated at 2022-06-20 14:00:20.359912
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # TODO: This needs to be updated when we have some way of doing functional
    # testing of the fields
    # Test normal case
    CLIARGS.update({'some_key': 'value'})
    assert callable(cliargs_deferred_get('some_key'))
    assert cliargs_deferred_get('some_key')() == 'value'
    # Test with a default
    CLIARGS.update({'some_key': 'value'})
    assert callable(cliargs_deferred_get('key_does_not_exist', default='some_default'))
    assert cliargs_deferred_get('key_does_not_exist', default='some_default')() == 'some_default'

    # Test shallow copy

# Generated at 2022-06-20 14:00:32.225149
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'test': [1,2]}
    _init_global_context(cli_args)
    # test retrieving a value
    assert cliargs_deferred_get('test') == [1,2]
    # test retrieving a value with shallow copy
    assert cliargs_deferred_get('test', shallowcopy=True) == [1,2]
    # test retrieving a value that doesn't exist
    assert cliargs_deferred_get('no_exist') == None
    # test retrieving a value that doesn't exist with a default
    assert cliargs_deferred_get('no_exist', default=1) == 1
    # test retrieving a value that doesn't exist with a default and shallow copy
    assert cliargs_deferred_get('no_exist', default=1, shallowcopy=True) == 1

# Generated at 2022-06-20 14:00:43.716924
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    cli_args = {'become': True, 'become_user': 'user', 'become_method': 'sudo'}
    CLIARGS = CLIArgs({})
    _init_global_context(cli_args)
    # Not a shallow copy
    assert cliargs_deferred_get('become_method')() is cli_args['become_method']
    # Changing the global cli_args
    cli_args['become_method'] = 'su'
    assert cliargs_deferred_get('become_method')() is cli_args['become_method']
    # Shallow copy

# Generated at 2022-06-20 14:00:55.238708
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def init_cliargs(cli_args):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    init_cliargs({})

    get_deferred = cliargs_deferred_get('foo')
    assert get_deferred() == None

    init_cliargs({'foo': 'bar'})
    assert get_deferred() == 'bar'

    init_cliargs({'foo': 'bar'})
    get_shallowcopy = cliargs_deferred_get('foo', shallowcopy=True)
    assert get_shallowcopy() == 'bar'
    assert get_shallowcopy() is not 'bar'

    init_cliargs({'foo': 'bar'})
    get_deferred = cliargs_deferred_get('foo', 'baz')

# Generated at 2022-06-20 14:01:14.120578
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'list': [1, 2, 3], 'dict': {'a': 1, 'b': 2}, 'int': 1, 'str': 'str'})
    assert cliargs_deferred_get('list')() == [1, 2, 3]
    assert cliargs_deferred_get('list', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('dict')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('dict', shallowcopy=True)() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('int')() == 1
    assert cliargs_deferred_get('int', shallowcopy=True)() == 1
    assert cliargs

# Generated at 2022-06-20 14:01:22.024568
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    args = {
        'top': 'layer',
        'seq': [1, 2, 3, 5, 8],
        'map': {'a': 'b', 'c': 'd'},
    }

    _init_global_context(args.copy())
    assert CLIARGS.get('top') == 'layer'
    assert CLIARGS.get('seq') == [1, 2, 3, 5, 8]
    assert CLIARGS.get('map') == {'a': 'b', 'c': 'd'}

    assert cliargs_deferred_get('top')() == 'layer'
    assert cliargs_deferred_get('seq')() == [1, 2, 3, 5, 8]

# Generated at 2022-06-20 14:01:28.972314
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for function cliargs_deferred_get"""
    inner = cliargs_deferred_get('test_key')
    assert inner.__name__ == 'inner'
    assert inner.__closure__[0].cell_contents is CLIARGS
    assert inner.__closure__[1].cell_contents == 'test_key'

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-20 14:01:36.732559
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # noqa: A003
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('baz', default='bak') == 'bak'
    CLIARGS['buz'] = [1, 2, 3]
    assert cliargs_deferred_get('buz', shallowcopy=True) == [1, 2, 3]
    assert cliargs_deferred_get('fuz', shallowcopy=True, default=[4, 5, 6]) == [4, 5, 6]

# Generated at 2022-06-20 14:01:45.322649
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'one': 1, 'two': [1, 2, 3], 'three': {'a': 'a', 'b': ['b1', 'b2']}, 'four': set(['a', 'b', 'c'])})

    value1 = cliargs_deferred_get('one')
    assert value1() == 1

    value2 = cliargs_deferred_get('two')
    assert value2() == [1, 2, 3]
    assert value2() is not CLIARGS['two']

    value3 = cliargs_deferred_get('three')
    assert value3() == {'a': 'a', 'b': ['b1', 'b2']}
    assert value3() is not CLIARGS['three']


# Generated at 2022-06-20 14:01:56.261589
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_closure(value, shallowcopy=False):
        def inner():
            if not shallowcopy:
                return value
            elif is_sequence(value):
                return value[:]
            elif isinstance(value, (Mapping, Set)):
                return value.copy()
            return value
        return inner
    # No default specified
    assert cliargs_deferred_get('foo')() == test_closure(default=None)()
    # Default specified
    assert cliargs_deferred_get('foo', default='default')() == test_closure(default='default')()
    # Default is empty
    assert cliargs_deferred_get('foo', default=None)() == test_closure(default=None)()
    # Default is copyable type

# Generated at 2022-06-20 14:02:06.172008
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pragma: no cover
    from ansible.utils.context_objects import CLIArgs
    from copy import copy, deepcopy

    assert cliargs_deferred_get('skip_tags')() == cliargs_deferred_get('skip_tags')().get('skip_tags') is None

    cli_args = CLIArgs(dict(skip_tags={'skip_tags': 'some_tag'}))
    assert cliargs_deferred_get('skip_tags')() == cli_args['skip_tags']

    cli_args['skip_tags'] = []
    assert cliargs_deferred_get('skip_tags', shallowcopy=True)() == cli_args['skip_tags']

# Generated at 2022-06-20 14:02:17.657750
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'a': 1})
    assert cliargs_deferred_get('a')(), cliargs_deferred_get('a', shallowcopy=True)() == (1, 1)
    assert cliargs_deferred_get('b')(), cliargs_deferred_get('b', shallowcopy=True)() == (None, None)
    assert cliargs_deferred_get('b', default=2)(), cliargs_deferred_get('b', default=2, shallowcopy=True)() == (2, 2)

    CLIARGS = CLIArgs({'a': [1,2]})

# Generated at 2022-06-20 14:02:24.631788
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class GlobalCliargs:
        def get(self, key, default=None):
            return {'a': 1, 'b': 'foo', 'c': [1,2,3], 'd': {'a':1,'b':2}}.get(key, default)

    def inner():
        return CLIARGS.get('d', 'e', True)

    try:
        # Make sure this actually does work before we commit it to tests
        assert(not hasattr(CLIARGS, 'get'))
        CLIARGS = GlobalCliargs()
        assert(inner() == {'a':1,'b':2})
        assert(inner() is not CLIARGS.get('d'))
    finally:
        del CLIARGS

# Generated at 2022-06-20 14:02:33.999247
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['var'] = [1, 2, 3]
    CLIARGS['dict'] = {'a': 'b'}
    CLIARGS['set'] = set(['x'])
    assert cliargs_deferred_get('var') == [1, 2, 3]
    assert cliargs_deferred_get('dict') == {'a': 'b'}
    assert cliargs_deferred_get('set') == set(['x'])

    assert cliargs_deferred_get('var', shallowcopy=True) == [1, 2, 3]
    assert cliargs_deferred_get('dict', shallowcopy=True) == {'a': 'b'}
    assert cliargs_deferred_get('set', shallowcopy=True) == set(['x'])

    CLIARGS

# Generated at 2022-06-20 14:02:57.215093
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('no_such_key')() is None
    assert cliargs_deferred_get('no_such_key', default='baz')() == 'baz'
    assert cliargs_deferred_get('no_such_key', shallowcopy=True)() is None
    CLIARGS['seq'] = ['foo', 'bar']
    assert cliargs_deferred_get('seq')() == ['foo', 'bar']
    assert cliargs_deferred_get('seq', shallowcopy=True)() == ['foo', 'bar']
    CLIARGS['set'] = {'foo', 'bar'}
    assert cliargs

# Generated at 2022-06-20 14:03:08.677538
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {}
    test_args = {
        'test_value_key': 'a',
        'test_default_key': 5,
        'test_seq_key': [1,2,3,4],
        'test_mapping_key': {'a': 1, 'b': 2},
        'test_set_key': {1, 2, 3, 4},
    }
    _init_global_context(cli_args)

    # test with cli_args that exist
    for key, value in test_args.items():
        assert cliargs_deferred_get(key, shallowcopy=False)() == value
        assert cliargs_deferred_get(key, shallowcopy=True)() == value

    # test with cli_args that don't exist
    assert cliargs_def

# Generated at 2022-06-20 14:03:18.668117
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.set_value({"a": 1, "b": [1, 2, 3], "c": {'d': 4, 'e': 5}})

    # Test normal operation
    cliarg_a = cliargs_deferred_get('a')
    assert cliarg_a() == 1

    cliarg_b = cliargs_deferred_get('b')
    assert cliarg_b() == [1, 2, 3]

    cliarg_c = cliargs_deferred_get('c')
    assert cliarg_c() == {'d': 4, 'e': 5}

    # Test normal operation with missing key
    cliarg_d = cliargs_deferred_get('d')
    assert cliarg_d() is None

    cliarg_d = cl

# Generated at 2022-06-20 14:03:30.842868
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # First, test that the function calls the underlying get call
    CLIARGS['dict'] = {'a':1}
    CLIARGS['set'] = {'b'}

    class D(dict):
        pass

    class S(set):
        pass

    CLIARGS['named_set'] = S({'c'})
    CLIARGS['named_dict'] = D({'d': 1})

    CLIARGS['list'] = [1,2,3]
    CLIARGS['tuple'] = (1,2,3)

    assert cliargs_deferred_get('dict') == {'a':1}
    assert cliargs_deferred_get('dict', shallowcopy=True) == {'a':1}
    assert cliargs_deferred_get('set') == {'b'}
   

# Generated at 2022-06-20 14:03:42.558873
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_inner(value, expected, shallowcopy=False):
        def inner():
            return value
        assert cliargs_deferred_get('test', inner, shallowcopy)() == expected

    test_inner(['a', 'b', 'c'], ['a', 'b', 'c'])
    test_inner(('a', 'b', 'c'), ('a', 'b', 'c'))
    test_inner(set(['a', 'b', 'c']), set(['a', 'b', 'c']))
    test_inner({'a': 1, 'b': 2, 'c': 3}, {'a': 1, 'b': 2, 'c': 3})
    test_inner(['a', 'b', 'c'], ['a', 'b', 'c'], shallowcopy=True)
    test_

# Generated at 2022-06-20 14:03:54.215414
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_values = {'foo': 42, 'bar': (1, 2, 3), 'baz': {'a': 1, 'b': 2},
                   'bat': {1, 2, 3}}
    global CLIARGS
    CLIARGS = CLIArgs(test_values)
    for (key, value) in test_values.items():
        assert value == cliargs_deferred_get(key)()
        assert value == cliargs_deferred_get(key, default='bar')()
        assert 'bar' == cliargs_deferred_get(key + 'foo', default='bar')()
        assert value == cliargs_deferred_get(key, shallowcopy=True)()
        assert isinstance(cliargs_deferred_get(key, shallowcopy=True)(), type(value))

# Generated at 2022-06-20 14:04:02.421568
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=not-an-iterable,expression-not-assigned,unused-variable
    original_CLIARGS = ('one_item', 'two_item')
    global CLIARGS
    CLIARGS = CLIArgs(original_CLIARGS)

    expected = original_CLIARGS[:]
    item = cliargs_deferred_get('mykey', 'mydefault', True)
    assert item() == expected

    expected = original_CLIARGS.copy()
    item = cliargs_deferred_get('mykey', 'mydefault', True)
    assert item() == expected

    expected = 'mydefault'
    item = cliargs_deferred_get('mykey', 'mydefault', False)
    assert item() == expected

    expected = 'mydefault'

# Generated at 2022-06-20 14:04:14.061081
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=unused-variable, undefined-variable, redefined-outer-name

    # This is a truly terrible unit test but it's good enough for now.
    # The reason it's a bad unit test is that it doesn't test the closure part of the code.
    # The function inside of the closure is used as the inner function here but that's not the
    # function that will exist when this function is used by Ansible code.  Instead, the
    # closure created by this function will be used when ansible code is run.  The closure does
    # *not* have a direct reference to any of the variables in this function but it does have
    # a reference to the objects in this function's outer scope.  So it captures a reference
    # to CLIARGS which is a valid

# Generated at 2022-06-20 14:04:23.945881
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=invalid-name
    """Test function cliargs_deferred_get"""
    # pylint: disable=unused-variable

    from ansible.module_utils.common.collections import is_sequence

    # Note: cliargs_deferred_get is not bound to CLIARGS
    #       cliargs_deferred_get is bound to CLIARGS after cliargs are initialized
    assert cliargs_deferred_get('connection')() is None

    # Test initialization of global context
    _init_global_context({'connection': 'local'})

    assert cliargs_deferred_get('connection')() == 'local'

    # Test resetting global context
    _init_global_context({'connection': 'smart'})

    assert cliargs_deferred_get('connection')()

# Generated at 2022-06-20 14:04:28.998900
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    CLIARGS.data = {'foo': 'bar'}
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foobar')() is None
    assert cliargs_deferred_get('foobar', default='ansible')() == 'ansible'
    CLIARGS.data = {'foo': ['bar', 'baz']}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']