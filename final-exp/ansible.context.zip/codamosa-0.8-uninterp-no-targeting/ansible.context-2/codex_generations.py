

# Generated at 2022-06-20 13:54:39.169886
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(
        some_key1='some_value1',
        some_key2='some_value2',
        some_key_seq=['val1', 'val2'],
        some_key_set=set(['s1', 's2']),
        some_key_dict={'d1': 'blah1', 'd2': 'blah2'},
    ))
    # Test normal operation
    assert cliargs_deferred_get('some_key1', default='default1') == 'some_value1'
    assert cliargs_deferred_get('some_key2', default='default2') == 'some_value2'
    assert cliargs_deferred_get('some_key3', default='default3') == 'default3'
   

# Generated at 2022-06-20 13:54:47.344738
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # get with default, no default, and default=None
    CLIARGS = CLIArgs({'abc': 123, 'xyz': None})
    assert cliargs_deferred_get('abc')() == 123
    assert cliargs_deferred_get('xyz')() == None
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    assert cliargs_deferred_get('foo', default=None)() == None
    assert cliargs_deferred_get('foo')() == None

    # get with shallow copy for sequence, mapping, set, other

# Generated at 2022-06-20 13:54:51.763966
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make sure the function is callable before CLIARGS is filled in
    cliargs_deferred_get('foo', default='bar')()
    # Make sure the function returns the right thing after CLIARGS is filled in
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo')(), 'baz'

# Generated at 2022-06-20 13:55:02.988635
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get(): # pylint: disable=missing-docstring
    import inspect
    assert inspect.getargspec(cliargs_deferred_get).args == ['key', 'default', 'shallowcopy']

    assert cliargs_deferred_get(key='key', default='default', shallowcopy=True)() == 'default'
    assert cliargs_deferred_get(key='key', default='default', shallowcopy=False)() == 'default'

    assert cliargs_deferred_get(key='key', default=[], shallowcopy=True)() == []
    assert cliargs_deferred_get(key='key', default=[], shallowcopy=False)() == []

    assert cliargs_deferred_get(key='key', default=set(), shallowcopy=True)() == set()

# Generated at 2022-06-20 13:55:13.416708
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from collections import namedtuple
    test_options = namedtuple('Options', ['foo'])

    _init_global_context(test_options(foo=['a','b']))

    # test deffered, shallow copy, existence
    assert CLIARGS.get('foo') == cliargs_deferred_get('foo')()
    assert CLIARGS.get('foo') is not cliargs_deferred_get('foo', shallowcopy=True)()
    assert CLIARGS.get('foo') == cliargs_deferred_get('foo', shallowcopy=True)()

    # test not deffered, shallow copy, existence
    assert CLIARGS['foo'] == cliargs_deferred_get('foo', shallowcopy=True)()
    assert CLI

# Generated at 2022-06-20 13:55:25.340750
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import json

    fake_args = {
      'foo': 'bar',
      'bar': ['one', 'two', 'three'],
      'baz': {
          'one': 'two',
          'three': ['four'],
          'five': set(['six', 'seven']),
      }
    }
    _init_global_context(fake_args)
    assert 'bar' == cliargs_deferred_get('foo')()
    foo_list = cliargs_deferred_get('bar')()
    assert isinstance(foo_list, list)
    assert 't' == foo_list[1]

    foo_list[1] = 'e'
    assert 'bar' == CLIARGS['foo']
    assert 'e' == fake_args['bar'][1]

    baz_dict

# Generated at 2022-06-20 13:55:34.875941
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils._text import to_text
    from ansible.utils.context_objects import CLIArgs
    # These tests must be run before the context objects have been initialized.
    # The module loader does not have a clean way to unload the modules so we
    # have to do this at the beginning of the tests.
    import ansible.module_utils.basic
    import ansible.module_utils.common._collections_compat
    import ansible.module_utils.connection
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.parsing.convert_bool


# Generated at 2022-06-20 13:55:39.883278
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from copy import copy

    # Test to make sure it doesn't crash if cliargs are not initialized
    assert cliargs_deferred_get('foo') is None

    # Test to make sure a regular argument works
    cli_args = GlobalCLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('foo') is not cli_args.get('foo')

    # Test to make sure a shallow copy argument works
    cli_args_copy = cli_args.copy()
    assert cliargs_deferred_get('foo', shallowcopy=True) == 'bar'

# Generated at 2022-06-20 13:55:47.707779
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import ContextObjBase
    class TestContext(ContextObjBase):
        foo = cliargs_deferred_get('foo')

    TestContext._init_global_context = _init_global_context
    test_context = TestContext()

    assert test_context.foo is None
    test_context._configure_global_context({'foo': 42})
    assert test_context.foo == 42
    test_context._configure_global_context({'foo': 23})
    assert test_context.foo == 23

    class TestShallow(ContextObjBase):
        foo = cliargs_deferred_get('foo', shallowcopy=True)

    TestShallow._init_global_context = _init_global_context
    test_shallow = TestShallow()


# Generated at 2022-06-20 13:55:56.704418
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def assert_copy(copy, orig):
        copy.append('test')
        if copy is orig:
            raise AssertionError('Failed shallow copy, {}, {}'.format(copy, orig))

    # Test with a sequence
    _init_global_context({'ANSIBLE_STRICT': 'warnings'})
    orig = CLIARGS.get('ANSIBLE_STRICT')
    copy = cliargs_deferred_get('ANSIBLE_STRICT', shallowcopy=True)()
    assert_copy(copy, orig)

    # Test with a Mapping
    _init_global_context({'ANSIBLE_NOCOLOR': True})
    copy = cliargs_deferred_get('ANSIBLE_NOCOLOR', shallowcopy=True)()
    assert_copy(copy, orig)

    # Test with a Set

# Generated at 2022-06-20 13:56:09.916504
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common import jsonarg_true

    _init_global_context({'check_mode': True, 'diff': 'yes', 'extra_vars': ['foo', 'bar']})
    assert cliargs_deferred_get('check_mode')(), True
    assert cliargs_deferred_get('check_mode', default=False)(), True
    assert cliargs_deferred_get('bogus', default=False)(), False

    assert cliargs_deferred_get('diff')(), 'yes'
    assert cliargs_deferred_get('diff', default='no')(), 'yes'

    assert cliargs_deferred_get('diff', default=jsonarg_true)(), True

# Generated at 2022-06-20 13:56:21.296015
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({
        'connection': 'smart',
        'module_path': '/usr/share/ansible',
        'forks': 5,
        'become': True,
        'become_method': 'sudo',
        'become_user': 'root',
        'check': False,
        'diff': False,
        'extra_vars': [],
        'tags': [],
    })
    assert CLIARGS == CLIARGS_default
    assert cliargs_deferred_get('connection')() == 'smart'
    assert cliargs_deferred_get('module_path')() == '/usr/share/ansible'
    assert cliargs_deferred_get('forks')() == 5
    assert cliargs_deferred_get('become')() == True

# Generated at 2022-06-20 13:56:32.275950
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = CLIArgs({'a':1, 'b':2, 'c':[1,2,3]})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == 2
    assert cliargs_deferred_get('c')() == [1,2,3]
    assert cliargs_deferred_get('c', shallowcopy=True)() == [1,2,3]
    cliargs_deferred_get('c', shallowcopy=True)()[0] = 4
    assert cliargs_deferred_get('c')() == [4,2,3]
    assert cliargs_deferred_get('d', default='default')() == 'default'
    assert cliargs_deferred_get('d')

# Generated at 2022-06-20 13:56:43.737925
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'a': 1}
    global CLIARGS
    CLIARGS = CLIArgs(cli_args)

    def test_factory(key, default=None, shallowcopy=False):
        return cliargs_deferred_get(key, default, shallowcopy)

    assert test_factory('a')(), 1
    assert test_factory('b')(), None
    assert test_factory('b', default=1)(), 1
    assert test_factory('a', default=1)(), 1

    l = [1, 2, 3]
    cli_args['list'] = l
    assert test_factory('list')(), l
    assert test_factory('list', shallowcopy=True)(), l
    assert test_factory('list', shallowcopy=True)() is not l



# Generated at 2022-06-20 13:56:54.866957
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # pylint: disable=protected-access
    import copy
    import os
    import sys
    # pylint: enable=protected-access
    from ansible.utils.context_objects import CliArgs


# Generated at 2022-06-20 13:57:02.461110
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    # Make sure that it works with a setting set, not set, and set to None
    c1 = CLIArgs({'foo': 'bar'})
    g1 = cliargs_deferred_get
    assert g1('foo')() == 'bar'
    assert g1('bar')() is None
    assert g1('bar', default='baz')() == 'baz'
    assert g1('baz', default=['cheese'])() == ['cheese']

    # Make sure that it works after CLIARGS has been replaced
    c2 = CLIArgs({'foo': 'baz', 'bar': None, 'baz': ['cheese']})
    CLIARGS.replace(c2)
    assert g1('foo')() == 'baz'
    assert g

# Generated at 2022-06-20 13:57:11.115382
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    import copy
    new_cliargs = CLIArgs({'foo': ['bar', 'baz'], 'bar': {'key': 'value'}})
    CLIARGS = new_cliargs

    # Test shallow copy
    unmodified_default_value = [1, 2, 3]
    unmodified_dict_value = {'foo': 'bar', 'baz': 'qux'}
    unmodified_set_value = set(unmodified_dict_value)

    default_value = cliargs_deferred_get('not-set', default=unmodified_default_value, shallowcopy=True)()
    assert default_value == unmodified_default_value
    assert default_value is unmodified_default_value


# Generated at 2022-06-20 13:57:20.746443
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make sure we always get an arugment in a closure
    key = 'something'
    default = 'something else'

    def test_arugment_passing():
        inner = cliargs_deferred_get(key, default, shallowcopy=False)
        inner_shallowcopy = cliargs_deferred_get(key, default, shallowcopy=True)
        # Let's be sure that we're getting a closure here
        assert inner() == inner()
        assert inner_shallowcopy() == inner_shallowcopy()
        assert isinstance(inner(), str)
        assert isinstance(inner_shallowcopy(), str)
        assert inner() == inner_shallowcopy()
        assert inner() == default
        assert inner_shallowcopy() == default

    test_arugment_passing()

    # Set a known value

# Generated at 2022-06-20 13:57:22.925739
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert cliargs_deferred_get('not in cli args')(), None
    CLIARGS = CLIArgs({'key1': 'val1'})
    assert cliargs_deferred_get('key1')(), 'val1'

# Generated at 2022-06-20 13:57:32.872417
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # argh uses lists for storing args so we need to make sure we are not causing
    # problems by shallowcopying lists
    cli_args = {'_ansible_opts': ['first_arg'], 'help': False, 'complex_arg': [{'a': 'b'}, {'c': 'd'}]}
    _init_global_context(cli_args)
    assert [{'a': 'b'}, {'c': 'd'}] == cliargs_deferred_get('complex_arg')()
    # but we have copied it
    cli_args['complex_arg'].append({'e': 'f'})
    assert [{'a': 'b'}, {'c': 'd'}] == cliargs_deferred_get('complex_arg')()

# Generated at 2022-06-20 13:57:48.796883
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''Test the function cliargs_deferred_get'''
    import tap.tests
    import tap.runner
    import tap.loader
    import tempfile


# Generated at 2022-06-20 13:57:53.250290
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    retval = cliargs_deferred_get('DEFAULT', default='default')
    assert retval == 'default'

    def retval():
        return CLIARGS.get('DEFAULT', default='default')
    assert not retval()

    CLIARGS.DEFAULT = 'value'
    assert retval() == 'value'

# Generated at 2022-06-20 13:57:56.577239
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    def init_args():
        # Note: it is a global singleton
        global CLIARGS
        # Use a new singleton
        CLIARGS = CLIArgs(dict(a=[1, 2, 3], b=[], c=set([1, 2, 3]), d=set([]),
            e={'a': 1, 'b': 2, 'c': 3}, f={}, g=True, h=False, i=None))

    def assert_eq(a, b):
        assert a == b
        # Verify that we do shallow copies
        assert id(a) != id(b)
        if is_sequence(a):
            assert id(a[0]) == id(b[0])

# Generated at 2022-06-20 13:58:06.891299
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test closure over CLIARGS to get values

    This tests that we can get values from CLIARGS and that even if the global
    var is overwritten we still get values from the original CLIARGS
    """
    # The tests below will set different values in this global so we could end up
    # with a different CLIARGS
    old_cliargs = CLIARGS
    # Basic tests
    old_cliargs['someval'] = [1, 2, 3]
    old_cliargs['someval2'] = 2
    old_cliargs['someval3'] = {'foo': 'bar'}
    # We have to use the inner closure to reproduce the behavior
    assert cliargs_deferred_get('someval')() == [1, 2, 3]
    assert cliargs_deferred_get('someval2')() == 2

# Generated at 2022-06-20 13:58:10.608622
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # call cliargs_deferred_get with a key that is always in CLIARGS
    # Make it shallow copy
    expected = CLIARGS.get('verbosity', shallowcopy=True)
    returned = cliargs_deferred_get('verbosity')(shallowcopy=True)
    assert returned is not expected
    assert returned == expected

# Generated at 2022-06-20 13:58:14.750561
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function ``cliargs_deferred_get``
    """
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {}

# Generated at 2022-06-20 13:58:25.581924
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    This function is not directly bound to ``CliArgs`` so that it works with
    ``CLIARGS`` being replaced
    """
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs
    global CLIARGS
    CLIARGS = CLIArgs({})
    do_shallowcopy = cliargs_deferred_get('SHALLOWCOPY', shallowcopy=True)
    assert do_shallowcopy() is not None
    do_not_shallowcopy = cliargs_deferred_get('SHALLOWCOPY')
    assert do_not_shallowcopy() is not None


# Generated at 2022-06-20 13:58:33.646574
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(KEY=True, OTHER_KEY='foo'))

    get_key = cliargs_deferred_get('KEY')
    assert get_key() is True
    get_key_shallow = cliargs_deferred_get('KEY', shallowcopy=True)
    assert get_key_shallow() is True

    get_other_key = cliargs_deferred_get('OTHER_KEY')
    assert get_other_key() == 'foo'
    get_other_key_shallow = cliargs_deferred_get('OTHER_KEY', shallowcopy=True)
    assert get_other_key_shallow() == 'foo'

    get_no_key = cliargs_deferred_get('NO_KEY')
    assert get_no_key() is None
    get_

# Generated at 2022-06-20 13:58:44.628424
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Primarily a unit test for cliargs_deferred_get, but also a sanity check for
    cliargs_deferred_set
    """
    def _test(key, expected, data, **kwargs):
        # Verify the default values
        default_getter = cliargs_deferred_get(key, **kwargs)
        assert expected == default_getter()

        # Verify that cliargs_deferred_set works and that the value is stored in CLIARGS
        cliargs_deferred_set(key, data, **kwargs)
        assert data == default_getter()

    _test('foo', False, True)
    _test('foo_sequence', [], [1,2,3])
    _test('foo_sequence', [], (1,2,3))

# Generated at 2022-06-20 13:58:52.866747
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(arg1='value1'))

    deferred = cliargs_deferred_get('arg1')
    assert deferred() == 'value1'

    deferred_default = cliargs_deferred_get('not_here', 'default_value')
    assert deferred_default() == 'default_value'

    CLIARGS = CLIArgs(dict(arg2='value2'))

    assert deferred() == 'value1'
    assert deferred_default() == 'default_value'

# Generated at 2022-06-20 13:59:12.140177
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    import sys
    import unittest

    class CliArgsDeferredGetTestCase(unittest.TestCase):
        def test_inner(self):
            # Without a bind
            #  Nothing in CLIARGS
            with self.assertRaises(KeyError):
                cliargs_deferred_get('test')().get('test')

            #  Have something in CLIARGS
            CLIARGS['test'] = {}
            with self.assertRaises(KeyError):
                cliargs_deferred_get('test')().get('test')


# Generated at 2022-06-20 13:59:21.548224
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'var': 1, 'var_list': [1,2,3], 'var_dict': {1:2}})
    assert cliargs_deferred_get('var')() == 1
    assert cliargs_deferred_get('var_list')() == [1,2,3]
    assert cliargs_deferred_get('var_dict')() == {1:2}
    assert cliargs_deferred_get('var_list', shallowcopy=True)() == [1,2,3]
    assert cliargs_deferred_get('var_dict', shallowcopy=True)() == {1:2}
    assert cliargs_deferred_get('var', default=['a', 'b'])() == ['a', 'b']

# Generated at 2022-06-20 13:59:32.903686
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    deferred = cliargs_deferred_get('check', default=True)
    assert not deferred()

    _init_global_context({'check': False})
    deferred = cliargs_deferred_get('check', default=True)
    assert not deferred()

    _init_global_context({'check': False})
    deferred = cliargs_deferred_get('check', default=True, shallowcopy=True)
    assert not deferred()

    _init_global_context({'check': True})
    deferred = cliargs_deferred_get('check', default=True)
    assert deferred()

    _init_global_context({'check': True})
    deferred = cliargs_deferred_get('check', default=True, shallowcopy=True)
    assert deferred()



# Generated at 2022-06-20 13:59:41.962637
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)

    # Directly bound function
    foo = cliargs_deferred_get('foo')
    assert foo() == 'bar'

    # Indirectly bound function
    foo = cliargs_deferred_get('foo')
    assert foo() == 'bar'

    # Test what happens when we don't have the key
    foo = cliargs_deferred_get('bar', default='bar')
    assert foo() == 'bar'

    # Test what happens when we don't have the key and no default
    foo = cliargs_deferred_get('bar')
    assert foo() is None

    # Test sequence copy
    cli_args['foo'] = ['bar']
    foo = cliargs_deferred_

# Generated at 2022-06-20 13:59:53.037492
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _do_test(key, value, shallowcopy):
        # We have to use the function rather than just calling the function to
        # put the GET in a closure over the local variables
        def _get_value():
            return CLIARGS.get(key, default=None)

        # Set the global object
        global CLIARGS
        CLIARGS = GlobalCLIArgs({key: value})
        assert _get_value() == value

        # Use the deferred get and make sure we get the same value
        get_value = cliargs_deferred_get(key, shallowcopy=shallowcopy)
        assert get_value() == value

        # Delete the global object and ensure that the deferred get works
        del CLIARGS
        assert get_value() == value


# Generated at 2022-06-20 14:00:04.951678
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIARGS as _ORIG_CLIARGS
    cli_args = {'config': 'foo',
                'inventory': ['bar']}
    _ORIG_CLIARGS = GlobalCLIArgs.from_options(cli_args)
    assert cliargs_deferred_get('config')() == 'foo'
    assert cliargs_deferred_get('inventory')() == ['bar']
    assert cli_args['inventory'] is cliargs_deferred_get('inventory')()
    assert cliargs_deferred_get('inventory', shallowcopy=True)() is not cliargs_deferred_get('inventory')()
    _ORIG_CLIARGS = GlobalCLIArgs.from_

# Generated at 2022-06-20 14:00:13.148563
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    assert cliargs_deferred_get('bar', default=['baz'], shallowcopy=True)() == ['baz']
    assert cliargs_deferred_get('bar', default={'baz': 'gronk'}, shallowcopy=True)() == {'baz': 'gronk'}
    assert cliargs_deferred_get('bar', default=set('baz'), shallowcopy=True)() == set('baz')

# Generated at 2022-06-20 14:00:20.678502
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the deferred_get function

    The ``FieldAttribute`` class that uses this does not have any tests yet.  This
    is a basic test for the deferred_get function to ensure that it actually works
    """
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    import pytest
    # Create fake cliargs
    cliargs = dict((k, v) for k, v in CLIArgs.fields.items() if k in ('verbosity', 'become_method'))
    # Init the context
    _init_global_context(cliargs)
    # Check if it behaves as expected
    for key, default in (('become_method', None), ('verbosity', None)):
        value = cliargs_def

# Generated at 2022-06-20 14:00:22.253899
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get('ANSIBLE_STRATEGY')()

# Generated at 2022-06-20 14:00:33.357334
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(a=1, b=2, c=dict(d=4, e=5)))

    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('a')() == 1

    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1

    assert cliargs_deferred_get('b')() == 2
    assert cliargs_deferred_get('b')() == 2

    assert cliargs_deferred_get('b', shallowcopy=True)() == 2
    assert cliargs_deferred_get('b', shallowcopy=True)() == 2


# Generated at 2022-06-20 14:01:05.192178
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_inner(key, default, shallowcopy, expected):
        # test we can get the default back
        assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == expected

        # test we can override
        CLIARGS[key] = expected
        assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == expected

    # Test a scaler value
    test_inner('foo', 3, False, 3)
    test_inner('foo', 3, True, 3)

    # Test a list
    test_inner('bar', [1, 2, 3], False, [1, 2, 3])
    test_inner('bar', [1, 2, 3], True, [1, 2, 3])

    # Test a dict
    test_inner

# Generated at 2022-06-20 14:01:15.581373
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    cliargs = GlobalCLIArgs.from_options({'test': {'foo': 'bar'}})
    # Test getting a value
    assert cliargs_deferred_get('test')(), {'foo': 'bar'}
    assert cliargs_deferred_get('test', shallowcopy=True)(), {'foo': 'bar'}
    # Test for a default
    assert cliargs_deferred_get('baz')(), None
    assert cliargs_deferred_get('baz', default=42)(), 42
    assert cliargs_deferred_get('baz', default={'foo': 'bar'})(), {'foo': 'bar'}
    assert cliargs_deferred_

# Generated at 2022-06-20 14:01:20.053157
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable

    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})

    # Test with no copy specified
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo')(shallowcopy=False) == 'bar'

    # Test with shallow copy specified
    assert cliargs_deferred_get('foo')(shallowcopy=True) == 'bar'

    # Test default
    assert cliargs_deferred_get('foo', default='baz')(shallowcopy=True) == 'bar'
    assert cliargs_deferred_get('bar', default='baz')(shallowcopy=True) == 'baz'

    # The function should also work if the global doesn't exist

# Generated at 2022-06-20 14:01:23.945477
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    >>> CLIARGS.DEFAULTS = {'key': 1, 'other_key': [2, 3]}
    >>> cliargs_deferred_get('key')(); 2
    """


# Generated at 2022-06-20 14:01:35.680434
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    def test_list(value, expect, shallowcopy):
        def inner():
            if shallowcopy:
                return value[:]
            return value

        function = cliargs_deferred_get('a_key', inner, shallowcopy=shallowcopy)
        result = function()
        assert result == expect
        if shallowcopy:
            result[0] = 'boom'
        else:
            result[0] = 'new'
        assert result != expect

    test_list(['a', 'b'], ['a', 'b'], False)
    test_list(['a', 'b'], ['a', 'b'], True)

    def test_dict(value, expect, shallowcopy):
        def inner():
            if shallowcopy:
                return value.copy()
            return value

        function = cliargs_deferred

# Generated at 2022-06-20 14:01:44.536148
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCLIARGS(CLIArgs):
        def __init__(self, *args, **kwargs):
            super(TestCLIARGS, self).__init__(*args, **kwargs)
            self.__dict__['global_args'] = {'foo': 'bar'}

    # Test that we can get a key
    global CLIARGS
    old = CLIARGS
    CLIARGS = TestCLIARGS()
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = old
    # Test that we get the default
    assert cliargs_deferred_get('non_existent', default='apple')() == 'apple'

    # Test that we shallow copy
    def throws():
        raise RuntimeError
    CLIARGS = old

# Generated at 2022-06-20 14:01:55.428739
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=too-many-branches
    """Test cliargs_deferred_get"""
    CLIARGS['test'] = 'bar'
    assert cliargs_deferred_get('test')() == 'bar'
    assert cliargs_deferred_get('test', default='default')() == 'bar'
    assert cliargs_deferred_get('test', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('test', default='default', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo')() is None
    CLIARGS['foo'] = {'a': 'b'}
    assert cliargs_deferred_get('foo')() == {'a': 'b'}
    assert cliargs_deferred

# Generated at 2022-06-20 14:02:05.436129
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # set normal value
    cliargs = CLIARGS({'foo': 'bar'})

    # get from direct context value
    assert cliargs.get('foo') == 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # get from cliargs_deferred_get with default value
    assert CLIARGS.get('bar', default='REPLACEMENT') == 'REPLACEMENT'
    assert cliargs_deferred_get('bar', default='REPLACEMENT')() == 'REPLACEMENT'

    # test that shallow copy works
    cliargs = CLIARGS({'foo': [1, 2, 3]})
    foo_copy = cliargs_deferred_get('foo', shallowcopy=True)()

# Generated at 2022-06-20 14:02:16.794170
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with default value when key is outside CLIARGS
    assert cliargs_deferred_get('wrongo', default=True)() is True
    assert cliargs_deferred_get('wrongo', default=True, shallowcopy=True)() is True

    # Test with replacement cliargs
    CLIARGS = {
        'foo': False,
        'bar': True,
        'baz': ['a', 'list'],
        'quux': {'a': 'dict'},
    }
    assert cliargs_deferred_get('foo')(CLIARGS) is False
    assert cliargs_deferred_get('bar')(CLIARGS) is True
    assert cliargs_deferred_get('baz')(CLIARGS) == ['a', 'list']
    assert cli

# Generated at 2022-06-20 14:02:28.904581
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # create a test CLIARGS
    # args is a dictionary that mimics what a argparse.Namespace object
    # would look like with values set
    args = {
        # A key that is present in the CLIARGS
        'become': True,
        # A key that is not present in the CLIARGS
        'does_not_exist': 'Test',
        # A key that normally has a list but doesn't in this case
        'roles_path': None,
        # A key that is normally not a list but does in this case
        'tags': ['test'],
    }
    # We can't use a GlobalCLIArgs here since this would get caught in a
    # singleton and use the real CLIARGS.  So we just use an object with a
    # .get() method
    global CLIARGS
    CLI

# Generated at 2022-06-20 14:03:19.877915
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    data = {'a': 1, 'b': 3}

    cli_args = CLIArgs(data)

    assert CLIARGS.get('a') == data['a']
    assert cliargs_deferred_get('a')() == data['a']
    assert cliargs_deferred_get('a', default=0)() == data['a']
    assert cliargs_deferred_get('b', default=0)() == data['b']
    assert cliargs_deferred_get('b', default=[])() == data['b']
    assert cliargs_deferred_get('b', shallowcopy=True)().copy() == data['b']
    assert cliargs_deferred_get('b', shallowcopy=True)() is not data['b']

# Generated at 2022-06-20 14:03:31.305939
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    old_cliargs = CLIARGS

# Generated at 2022-06-20 14:03:42.607352
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def assert_shallow_copy(key, val):
        cli_args = {key: val}
        _init_global_context(cli_args)

        value = cliargs_deferred_get(key, shallowcopy=False)()
        shallow_value = cliargs_deferred_get(key, shallowcopy=True)()

        assert value == shallow_value
        assert value is not shallow_value

    def assert_no_shallow_copy(key, val):
        cli_args = {key: val}
        _init_global_context(cli_args)

        value = cliargs_deferred_get(key, shallowcopy=False)()
        shallow_value = cliargs_deferred_get(key, shallowcopy=True)()

        assert value == shallow_value
        assert value is shallow_

# Generated at 2022-06-20 14:03:54.253662
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def init_mock_cliargs():
        args = dict(test='test',
                    test2='test2',
                    test3=dict(inner='inner'),
                    test4=set(['inner2']),
                    test5=['inner3'])
        _init_global_context(args)
    init_mock_cliargs()
    # Nonexistant key
    assert cliargs_deferred_get('test6')() == None
    # Nonexistant key with a default
    assert cliargs_deferred_get('test6', default='test6')() == 'test6'
    # Existing key
    assert cliargs_deferred_get('test')() == 'test'
    # Shallow copy
    value = cliargs_deferred_get('test')()
    assert id(value) != id

# Generated at 2022-06-20 14:04:02.451749
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get() function and the behavior it provides to FieldAttribute"""
    from ansible.module_utils.common.collections import is_sequence

    class Dummy(object):
        a = cliargs_deferred_get('a')
        b = cliargs_deferred_get('b')

        def __init__(self, cliargs):
            global CLIARGS
            assert CLIARGS is not cliargs
            CLIARGS = cliargs

    cliargs = CLIArgs({'a': 1, 'b': [2, 3]})
    t = Dummy(cliargs)

    assert t.a == 1
    assert t.b == [2, 3]
    cliargs['a'] = 42
    assert t.a == 42
    assert t.b is t.b



# Generated at 2022-06-20 14:04:14.099829
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({
        'ansible_defer_foo': [1, 2, 3],
        'ansible_defer_bar': {'a': 1, 'b': 2},
    })
    class Foo:
        foo = cliargs_deferred_get('ansible_defer_foo')
        bar = cliargs_deferred_get('ansible_defer_bar', default={})
    foo = Foo()

    assert foo.foo == [1, 2, 3]
    assert foo.bar == {'a': 1, 'b': 2}

    CLIARGS['ansible_defer_foo'][2] = 4
    assert foo.foo == [1, 2, 4]

    CLIARGS['ansible_defer_bar']['a'] = 3


# Generated at 2022-06-20 14:04:23.985187
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for cliargs_deferred_get

    This is a little clumsy as a unit test but doing it this way keeps the
    understanding of how this works isolated to this one file.

    global_context is not a Singleton.  Therefore, we can instantiate it more
    than once.  We just have to be careful to not call methods such as
    ``from_options`` more than once.
    """
    # Test normal usage
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    func = cliargs_deferred_get('foo')
    assert func() == 'bar'

    # Test default usage
    CLIARGS = CLIArgs({})
    func = cliargs_deferred_get('foo', 'bar')
    assert func() == 'bar'

    # Test shallowcopy
   

# Generated at 2022-06-20 14:04:34.118655
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs

    # Test getting values before cliargs is defined
    # noinspection PyUnusedLocal
    def test_func(key, default=None, shallowcopy=False):
        value = CLIARGS.get(key, default=default)
        if not shallowcopy:
            return value
        elif is_sequence(value):
            return value[:]
        elif isinstance(value, (Mapping, Set)):
            return value.copy()
        return value

    # nested dicts shallowcopy
    CLIARGS = CliArgs({})
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', {})() == {}