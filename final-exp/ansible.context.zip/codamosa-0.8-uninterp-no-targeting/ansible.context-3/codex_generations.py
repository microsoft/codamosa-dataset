

# Generated at 2022-06-20 13:54:41.537486
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({})
    assert cliargs_deferred_get('foo')() == None, 'Should have returned None because CLIARGS is empty'
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar', 'Should have returned bar'

# Generated at 2022-06-20 13:54:52.453170
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for cliargs_deferred_get"""
    CLIARGS.update({'foo': 'bar', 'baz': [1, 2, 3]})
    get_foo = cliargs_deferred_get('foo')
    get_foo_shallowcopy = cliargs_deferred_get('foo', shallowcopy=True)
    get_baz = cliargs_deferred_get('baz')
    get_baz_shallowcopy = cliargs_deferred_get('baz', shallowcopy=True)
    get_qux = cliargs_deferred_get('qux', default=1)
    get_qux_shallowcopy = cliargs_deferred_get('qux', default=1, shallowcopy=True)

    assert get_foo() == 'bar'
    CLIAR

# Generated at 2022-06-20 13:55:03.363675
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-20 13:55:13.808362
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_default_value():
        """Default value"""
        key = 'abc'
        default = 'default'
        get = cliargs_deferred_get(key, default)
        assert get() == default

    def test_cliargs_value():
        """Value from cliargs"""
        key = 'abc'
        default = 'default'
        value = 'value'
        # This can't be a global because it could be called before the
        # GlobalCLIArgs object is created and then a reference to it will be
        # cached for the lifetime of the object.
        class C(GlobalCLIArgs):
            pass
        global CLIARGS
        CLIARGS = C({key: value})
        get = cliargs_deferred_get(key, default)
        assert get() == value


# Generated at 2022-06-20 13:55:25.767870
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    from ansible.module_utils.common.collections import is_sequence

    # Validate that the function works when called with no arguments
    assert cliargs_deferred_get()() is None

    # Validate that the function works when there is no matching env var
    assert cliargs_deferred_get('PATH')(), os.environ['PATH']

    k = 'ANSIBLE_FOO'
    v = 'bar'
    os.environ[k] = v
    assert cliargs_deferred_get(k)(), v

    # Verify the function works when there is a matching env var
    del os.environ[k]
    v = 'bar'
    CLIARGS[k] = v
    assert cliargs_deferred_get(k)(), v

    # Verify that the function works

# Generated at 2022-06-20 13:55:34.130696
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-20 13:55:44.460801
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check_retval(retval, expected):
        assert retval == expected

    retval = cliargs_deferred_get('foo')(CLIARGS)
    check_retval(retval, None)
    retval = cliargs_deferred_get('foo', shallowcopy=True)(CLIARGS)
    check_retval(retval, None)

    retval = cliargs_deferred_get('foo', 'bar')(CLIARGS)
    check_retval(retval, 'bar')
    retval = cliargs_deferred_get('foo', 'bar', shallowcopy=True)(CLIARGS)
    check_retval(retval, 'bar')

    CLIARGS['foo'] = 'bar'

# Generated at 2022-06-20 13:55:50.882017
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'hello': 'world', 'foo': ['baz', 'biz']})
    assert cliargs_deferred_get('hello')() == 'world'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['baz', 'biz']
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', 'other')() == 'other'

# Generated at 2022-06-20 13:55:58.641131
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    from ansible.module_utils.common._collections_compat import Set
    import copy
    args = {'some_arg': 'foo', 'some_list': [1, 2, 3], 'some_set': Set(['a', 'b', 'c'])}
    CLIARGS = CLIArgs(copy.deepcopy(args))
    some_arg = cliargs_deferred_get('some_arg', default='bar')
    assert some_arg() == 'foo'

    some_other_arg = cliargs_deferred_get('some_other_arg', default='bar')
    assert some_other_arg() == 'bar'

    some_list = cliargs_deferred_get('some_list', default='bar')
    assert some_list()

# Generated at 2022-06-20 13:56:08.566155
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = {'one': 1, 'two': 2, 'three': 3}
    _init_global_context(cliargs)
    # value is the default, get function is not called
    assert cliargs_deferred_get('alpha')('beta') == 'beta'
    # value is found in the context, get function is called
    assert cliargs_deferred_get('one')('beta') == 1
    # value is found in the context and shallow copy is set
    assert cliargs_deferred_get('two', shallowcopy=True)() == 2
    assert cliargs_deferred_get('three', shallowcopy=True)() == 3

# Generated at 2022-06-20 13:56:24.951022
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    key = 'key'
    default = 'default'
    value = 'value'
    shallow_copy = 'shallow_copy'
    global CLIARGS
    CLIARGS = CLIArgs({key: value})
    assert cliargs_deferred_get(key)() == value
    assert cliargs_deferred_get(key, default=default)() == value
    assert cliargs_deferred_get(key, default=default, shallowcopy=True)() == value
    assert cliargs_deferred_get(shallow_copy, default=default, shallowcopy=True)() == default
    assert cliargs_deferred_get(shallow_copy, default=default)() == default
    CLIARGS = CLIArgs({})
    assert cliargs_

# Generated at 2022-06-20 13:56:34.693066
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get"""
    # pylint: disable=too-many-statements
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.errors import AnsibleError
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import iteritems
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.tests.unit.plugins.modules.utils import AnsibleExitJson

# Generated at 2022-06-20 13:56:47.019624
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=no-self-use
    from ansible.utils.context_objects import CLIArgs

    # Make sure that the function works with a regular CLIArgs object
    cli_args = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')(), cli_args['foo']
    assert cliargs_deferred_get('foo', shallowcopy=True)(), cli_args['foo'][:]

    # Make sure that the function works when CLIARGS is initialized
    cli_args = CLIArgs({'foo': ['bar']})
    CLIARGS = GlobalCLIArgs.from_options(cli_args)
    assert cliargs_deferred_get('foo')(), cli_args['foo']

# Generated at 2022-06-20 13:56:57.347932
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs

    def TrueFunc():
        return True

    def FalseFunc():
        return False

    foo = TrueFunc()

    assert foo is True
    assert cliargs_deferred_get('foo')() is None
    # Test that it doesn't copy things if we don't ask for it
    assert cliargs_deferred_get('foo', default=TrueFunc)() is foo
    assert not cliargs_deferred_get('foo', default=FalseFunc)()

    bar = [True] * 2
    baz = {'foo': True}
    qux = set([True])

    CLIARGS = GlobalCLIArgs({'foo': True, 'bar': bar, 'baz': baz, 'qux': qux})
    assert cli

# Generated at 2022-06-20 13:57:08.347442
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.clear()
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    CLIARGS.setdefault('bar', 'baz')
    assert cliargs_deferred_get('bar')() == 'baz'
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    CLIARGS.setdefault('baz', 'boo')
    assert cliargs_deferred_get('baz', shallowcopy=True)() == 'boo'

# Generated at 2022-06-20 13:57:19.195450
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_inner(value):
        def inner2():
            return value
        return inner2

    test_dict = {}
    bound_test_dict = cliargs_deferred_get('dict', test_dict)
    should_be_test_dict = bound_test_dict()
    assert should_be_test_dict is test_dict

    # Test with a non-default value
    c = CLIArgs({'dict': {'foo': 'bar'}})
    bound_test_dict = cliargs_deferred_get('dict', test_dict)
    should_be_test_dict = bound_test_dict()
    assert should_be_test_dict is not test_dict
    assert should_be_test_dict == {'foo': 'bar'}

    # Get a copy of the value
    bound_test

# Generated at 2022-06-20 13:57:30.473145
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def setUpFunction():
        global CLIARGS
        CLIARGS = CLIArgs({'key_str': 'value_str'})

    def test_get():
        assert(cliargs_deferred_get('key_str')() == 'value_str')
        assert(cliargs_deferred_get('key_str_not_exist')() == None)
        assert(cliargs_deferred_get('key_str_not_exist', default='default') == 'default')

    def test_copy():
        assert(cliargs_deferred_get('key_str', shallowcopy=True)() == 'value_str')
        assert(cliargs_deferred_get('key_str_not_exist', shallowcopy=True)() == None)

# Generated at 2022-06-20 13:57:40.069475
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # create an object of the class to provide a closure for the function
    obj = cliargs_deferred_get('test_key')
    # no error should be raised when in non-global state
    assert obj() == None
    # set cliargs to something
    cliargs = {'test_key': {'test': 'value'}}
    _init_global_context(cliargs)
    assert obj() == cliargs['test_key']
    assert cliargs['test_key'] is obj()
    cliargs['test_key']['test'] = 'value2'
    assert obj() == cliargs['test_key']
    assert cliargs['test_key'] is obj()



# Generated at 2022-06-20 13:57:44.972988
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    CLIARGS = CLIArgs({'foo': 'result'})
    # Ensure that we're not just calling CLIArgs.get
    assert cliargs_deferred_get('foo', 'bar')() == 'result'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'result'
    assert cliargs_deferred_get('foo', shallowcopy=False)() == 'result'
    CLIARGS = CLIArgs({'foo': ['result', 'other']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['result', 'other']

# Generated at 2022-06-20 13:57:55.246051
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the function cliargs_deferred_get"""
    class MockCLIArgs:
        def __init__(self, data):
            self.data = data

        def __getitem__(self, k):
            return self.data[k]

        def copy(self):
            return self.data.copy()

    class MockCLIArgs2:
        def __init__(self, data):
            self.data = data

        def __getitem__(self, k):
            return self.data[k]

        def copy(self):
            return self

    global CLIARGS

    # Test normal key retrieval
    CLIARGS = MockCLIArgs({'foo': 'bar'})
    test_ = cliargs_deferred_get('foo')
    assert test_() == 'bar'

    # Test default retrieval

# Generated at 2022-06-20 13:58:10.678118
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_cli_args = {
        'foo': 'bar',
        'baz': [1, 2, 3],
        'qux': {'a': 1},
    }

    global CLIARGS
    old_cliargs = CLIARGS
    CLIARGS = CLIArgs(test_cli_args)

    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('baz') is test_cli_args['baz']
    assert cliargs_deferred_get('qux') is test_cli_args['qux']

    assert cliargs_deferred_get('foo', shallowcopy=True) == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True) == [1, 2, 3]
    assert cli

# Generated at 2022-06-20 13:58:22.455097
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    # Test simple usage with normal values
    CLIARGS.setdefault('key', 'value')
    result = cliargs_deferred_get('key')()
    assert result == 'value'
    result = cliargs_deferred_get('key', shallowcopy=True)()
    assert result == 'value'

    result = cliargs_deferred_get('notakey')()
    assert result is None
    result = cliargs_deferred_get('notakey', shallowcopy=True)()
    assert result is None

    result = cliargs_deferred_get('notakey', 'defaultvalue')()
    assert result == 'defaultvalue'

# Generated at 2022-06-20 13:58:31.695279
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # temporary mock
    class _MockCliArgs(object):
        def __init__(self, inner=None, get_return=None):
            self._inner = inner
            self._get_return = get_return

        def get(self, key, default=None):
            self._get_return if self._get_return is not None else default

        def __getitem__(self, key):
            return self._inner[key]

    # test cliargs_deferred_get with a CLIARGS that is not the Singleton
    def nested_copy(value):
        if is_sequence(value):
            return value[:]
        elif isinstance(value, (Mapping, Set)):
            return value.copy()
        return value

    # test shallow copy
    # test with list

# Generated at 2022-06-20 13:58:42.858100
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert cliargs_deferred_get('connection', default='local')() == 'local'
    def _assert_cliargs_deferred_get(key, default, expected):
        "Helper function to ensure we get the expected output"
        assert cliargs_deferred_get(key, default, shallowcopy=True)() == expected
        assert cliargs_deferred_get(key, default, shallowcopy=False)() == expected

    # Immutable objects
    CLIARGS = CLIArgs({'necromancy': 'reanimation'})
    _assert_cliargs_deferred_get('necromancy', 'nope', 'reanimation')
    _assert_cliargs_deferred_get('necromancy', default='nope', expected='reanimation')
    _assert_cliargs_deferred

# Generated at 2022-06-20 13:58:54.166752
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value

    This test is an integration test across two modules
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.context_objects import AnsibleContext

    # the sequence, dictionary and set defaults should be the empty ones from PlayContext
    # the other defaults should be whatever the global context has
    play = PlayContext()
    ansible = AnsibleContext()

    assert CLIARGS['ask_vault_pass'] == ansible.ask_vault_pass
    assert CLIARGS['force_handlers'] == ansible.force_handlers
    assert CLIARGS['force_pipelining'] == ansible.force_pipelining
    assert CLIARGS['forks'] == ansible.forks

# Generated at 2022-06-20 13:59:05.684094
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    from six import PY2

    if not PY2:
        # we're not testing PY2 here so bail
        return

    cli_args = CLIArgs({'foo': 'bar', 'baz': ['1', 2, 3], 'quux': {'1': 2, '3': 4}, 'quuux': {1, 2, 3}})
    closure = cliargs_deferred_get('foo', shallowcopy=False)
    assert closure() == 'bar'
    closure = cliargs_deferred_get('foo', default='i_dont_exist', shallowcopy=False)
    assert closure() == 'i_dont_exist'
    closure = cliargs_deferred_get('foo', shallowcopy=True)

# Generated at 2022-06-20 13:59:13.662083
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeArgs(dict):
        def __getitem__(self, key):
            if key in self:
                value = self[key]
                if is_sequence(value) and key != 'ANSIBLE_CONFIG':
                    raise TypeError('Tried to return a reference to the cliargs instead of a copy')
                return value
            else:
                return None

    import copy
    value = {'foo': 'bar'}
    cliargs = FakeArgs(foo=value)
    # First check that we get the correct value
    assert cliargs_deferred_get('foo', default=cliargs)() == cliargs['foo']
    # Now check that we made a copy of the dict
    assert cliargs['foo'] is not cliargs_deferred_get('foo', default=cliargs)()
    # Now

# Generated at 2022-06-20 13:59:22.395135
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _inner_get_something():
        return cliargs_deferred_get('something')

    # This test is run twice to be sure both shallow and deep copies work.
    for inc in range(2):
        global CLIARGS
        CLIARGS = CLIArgs(dict(something=['foo', 'bar']))

        assert _inner_get_something() == ['foo', 'bar']

        CLIARGS['something'].pop()
        assert _inner_get_something() == ['foo']

        CLIARGS['something'].append('new')
        assert _inner_get_something() == ['foo', 'new']

        # switch to shallowcopy
        if inc:
            _inner_get_something = _inner_get_something()

        CLIARGS['something'].pop()

# Generated at 2022-06-20 13:59:33.683290
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    CLIARGS = CLIArgs({'foo': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo')() == {'a': 1, 'b': 2}

# Generated at 2022-06-20 13:59:40.425235
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = {'foo': 'bar'}
    _init_global_context(args)
    assert cliargs_deferred_get('foo')() == 'bar'
    _init_global_context({})
    assert cliargs_deferred_get('foo', default='def')() == 'def'
    _init_global_context(args)
    assert cliargs_deferred_get('foo')(), 'bar'
    _init_global_context({})
    assert cliargs_deferred_get('foo', default='def')(), 'def'

# Generated at 2022-06-20 13:59:56.146425
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    arg_dict = {
        'v': 3,
        'random_dict': {'1': 2, '2': 3}
    }
    CLIARGS = CLIArgs(arg_dict)
    assert cliargs_deferred_get('v')() == 3
    assert cliargs_deferred_get('v', shallowcopy=True)() == 3
    assert cliargs_deferred_get('random_dict')() == arg_dict['random_dict']
    assert cliargs_deferred_get('random_dict', shallowcopy=True)() == arg_dict['random_dict']

# Generated at 2022-06-20 14:00:02.092633
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert 1 == cliargs_deferred_get('foo')()
    CLIARGS['foo'] = 2
    assert 2 == cliargs_deferred_get('foo')()
    CLIARGS['foo'] = ['a']
    assert ['a'] == cliargs_deferred_get('foo')()
    assert ['a'] == cliargs_deferred_get('foo', shallowcopy=True)()

# Generated at 2022-06-20 14:00:11.827161
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # Test that we can use the cliargs_deferred_get function in the function it
    # was created in
    def inner():
        value = cliargs_deferred_get('deferred1')
        assert value == 'default'
    # Test that we can use the cliargs_deferred_get function in a method
    # it was created in
    class Inner(object):
        def method(self):
            value = cliargs_deferred_get('deferred1')
            assert value == 'default'
    # Test that we can use the cliargs_deferred_get function in a class it
    # was created in

# Generated at 2022-06-20 14:00:18.593561
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test None
    assert cliargs_deferred_get('foo')() is None

    # Test shallow copy
    li = [1, 2, 3]
    assert cliargs_deferred_get('foo', default=li, shallowcopy=True)() == li
    assert cliargs_deferred_get('foo', default=li, shallowcopy=False)() is li

    d = {'x': 1, 'y': 2}
    assert cliargs_deferred_get('foo', default=d, shallowcopy=True)() == d
    assert cliargs_deferred_get('foo', default=d, shallowcopy=False)() is d

    st = {1, 2, 3}
    assert cliargs_deferred_get('foo', default=st, shallowcopy=True)() == st
    assert cli

# Generated at 2022-06-20 14:00:30.620000
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit Tests for cliargs_deferred_get()"""
    global CLIARGS
    args_map = {'arg1': 'value1', 'arg2': 'value2', 'arg3': 'value3'}
    CLIARGS = CLIArgs(args_map)

    assert cliargs_deferred_get('arg1')() == 'value1'
    assert cliargs_deferred_get('arg2')() == 'value2'
    assert cliargs_deferred_get('arg3')() == 'value3'
    assert cliargs_deferred_get('arg4', 'default')() == 'default'
    assert cliargs_deferred_get('arg5', default='default')() == 'default'

    del CLIARGS
    global CLIARGS
    CLIARGS = CLIArgs({})


# Generated at 2022-06-20 14:00:42.170740
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('inventory')().__class__.__name__ == 'InventoryManager'
    assert cliargs_deferred_get('become_pass')().__class__.__name__ == 'str'
    assert cliargs_deferred_get('connection_user')().__class__.__name__ == 'str'
    assert cliargs_deferred_get('verbosity')().__class__.__name__ == 'int'
    assert cliargs_deferred_get('private_key_file')().__class__.__name__ == 'str'
    assert cliargs_deferred_get('remote_user')().__class__.__name__ == 'str'
    assert cliargs_deferred_get('forks', default=1)() == 1
   

# Generated at 2022-06-20 14:00:48.182372
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class GlobalCLIArgsSubclass(GlobalCLIArgs):
        pass

    class CLIArgsSubclass(CLIArgs):
        pass

    foo = 'bar'
    baz = [1, 2, 3]

    # Test behavior with GlobalCLIArgsSubclass
    cliargs_subclass = GlobalCLIArgsSubclass.from_options(dict(foo=foo, baz=baz, thing=CLIArgsSubclass.from_options(dict(foo=foo, baz=baz))))

    # test getting a key that is present
    assert cliargs_subclass.get('foo') == 'bar'
    assert cliargs_subclass.get('baz') == [1, 2, 3]

# Generated at 2022-06-20 14:00:58.615296
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['test'] = 'test_value'
    assert cliargs_deferred_get('test')() == 'test_value'
    assert cliargs_deferred_get('test', default='default')() == 'test_value'
    assert cliargs_deferred_get('test2', default='default')() == 'default'
    CLIARGS['test_list'] = ['test', 1]
    assert cliargs_deferred_get('test_list', shallowcopy=True)() == ['test', 1]
    CLIARGS['test_dict'] = dict(a=1)
    assert cliargs_deferred_get('test_dict', shallowcopy=True)() == dict(a=1)
    CLIARGS['test_set'] = set(['a', 1])
    assert cliargs_def

# Generated at 2022-06-20 14:01:10.195168
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.parsing.vault import VaultLib
    assert cliargs_deferred_get('vault_password_file')().endswith('password.txt')
    assert cliargs_deferred_get('vault_password_files')().endswith('password.txt')
    assert cliargs_deferred_get('vault_ids')().endswith('password.txt')
    assert cliargs_deferred_get('vault_identity_list')().endswith('ansible.pub')
    assert cliargs_deferred_get('vault_identity_list')().endswith('ansible.pub')
    assert cliargs_deferred_get('vault_identity_list')().endswith('ansible.pub')
    assert cliargs_

# Generated at 2022-06-20 14:01:19.531639
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({})
    CLIARGS._config.update(dict(a="b", c=["d"], e=[{'f': 'g'}], h={"i": "j"}))

    a = cliargs_deferred_get('a')
    b = cliargs_deferred_get('b')
    c = cliargs_deferred_get('c')
    d = cliargs_deferred_get('d')
    e = cliargs_deferred_get('e')
    f = cliargs_deferred_get('f')
    g = cliargs_deferred_get('g')
    h = cliargs_deferred_get('h')
    i = cliargs_deferred_get('i')
    j = cliargs_

# Generated at 2022-06-20 14:01:38.444605
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['test'] = [1,2,3]
    get1 = cliargs_deferred_get('test')
    get2 = cliargs_deferred_get('test', shallowcopy=True)
    CLIARGS['test'].append(4)
    assert get1() == [1,2,3,4]
    assert get2() == [1,2,3]

# Generated at 2022-06-20 14:01:42.834698
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(vars=dict()))
    assert cliargs_deferred_get('something', None, False)() == None
    _init_global_context(dict(vars=dict(something=dict(var='var'))))
    assert cliargs_deferred_get('something', None, False)() == dict(var='var')

# Generated at 2022-06-20 14:01:54.118834
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the``cliargs_deferred_get`` method"""
    global CLIARGS
    assert cliargs_deferred_get('foo')() is None

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', 'quux')() == 'quux'

    assert cliargs_deferred_get('bar', default=['foo'])() == ['foo']

    CLIARGS = CLIArgs({'bar': ['foo']})

# Generated at 2022-06-20 14:02:04.302403
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import MutableSequence
    global CLIARGS
    # Test without args
    CLIARGS = GlobalCLIArgs.from_options({})
    deferred = cliargs_deferred_get('foo')
    assert deferred() is None

    # Test with default
    deferred = cliargs_deferred_get('foo', default='bar')
    assert deferred() == 'bar'

    # Test with args
    CLIARGS = GlobalCLIArgs.from_options({'foo': 1})
    deferred = cliargs_deferred_get('foo')
    assert deferred() == 1

    # Test shallow copy
    CLIARGS = GlobalCLIArgs.from_options({'foo': MutableSequence([1, 2, 3])})
    deferred = cliargs_deferred

# Generated at 2022-06-20 14:02:08.356529
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the callback closure
    global CLIARGS
    try:
        CLIARGS = CLIArgs({})

        get_callback = cliargs_deferred_get('callback')
        assert get_callback() is None

        CLIARGS['callback'] = 'yaboo'
        assert get_callback() == 'yaboo'

    finally:
        # cleanup of global
        CLIARGS = CLIArgs({})

# Generated at 2022-06-20 14:02:19.546011
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_inner(key, default, expected):
        """Test_inner - inner helper to reduce duplication in unit tests

        :key: Key to use for the test
        :default: Default value to set for the test
        :expected: Expected value to get from cliargs_deferred_get
        """
        # We're testing a closure over CLIARGS but CLIARGS may not have
        # been initialized yet
        if not isinstance(CLIARGS, GlobalCLIArgs):  # pragma: no cover
            assert cliargs_deferred_get(key, default=default)() == expected
        # We've already initialized CLIARGS so we need to monkey patch it in order
        # to test in the unit test
        else:  # pragma: no cover
            assert cliargs_deferred_get(key, default=default)

# Generated at 2022-06-20 14:02:30.710830
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test ``cliargs_deferred_get()`` function"""
    test_dict = {'key1': 1, 'key2': [1, 2, 3], 'key3': {'a': 1, 'b': 2}, 'key4': {1, 2, 3}}
    global CLIARGS
    CLIARGS = GlobalCLIArgs(test_dict)
    for key, value in test_dict.items():
        assert cliargs_deferred_get(key)() == value
        if is_sequence(value):
            assert cliargs_deferred_get(key, shallowcopy=True)() == value[:]
        elif isinstance(value, (Mapping, Set)):
            assert cliargs_deferred_get(key, shallowcopy=True)() == value.copy()
        else:
            assert cli

# Generated at 2022-06-20 14:02:40.617406
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import _init_global_context
    from ansible.utils.context_objects import cliargs_deferred_get
    from ansible.utils.context_objects import CLIARGS
    from collections import Mapping
    cli_args = dict(foo='bar', bar=dict(baz='qix'), bin=[1, 2, 3])
    _init_global_context(cli_args)
    # First, test that the function works in the normal case
    assert cli_args == CLIARGS
    assert cli_args['foo'] is cliargs_deferred_get('foo')()
    assert cli_args['bar'] is cliargs_deferred_

# Generated at 2022-06-20 14:02:51.796731
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence, Set

    class Mutable(object):  # pylint: disable=too-few-public-methods
        """Just to have a mutable object"""
    obj = Mutable()

    # Some common types
    expected_result = 1
    assert expected_result == cliargs_deferred_get('nokey', expected_result)()
    expected_result = 'string'
    assert expected_result == cliargs_deferred_get('nokey', expected_result)()
    expected_result = obj
    assert expected_result == cliargs_deferred_get('nokey', expected_result)()

    # Shallow copy of mutable sequence
    expected_result = [obj, obj]
    assert expected_result == cli

# Generated at 2022-06-20 14:03:03.329729
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.context_objects import CLIArgs
    global CLIARGS
    cli_args = CLIArgs({'foo': 'bar', 'baz': ['qux', 'quux'], 'corge': {'grault': 1, 'garply': 2}, 'waldo': True, 'fred': set('abc')})
    expected = 'bar'
    CLIARGS = cli_args
    assert cliargs_deferred_get('foo')() == expected
    assert cliargs_deferred_get('foo')() is not expected
    assert cliargs_deferred_get('foo', shallowcopy=True)() is expected
    assert cliargs_deferred_get('waldo')() is expected
    assert cliargs_deferred_get('waldo', shallowcopy=True)() is expected


# Generated at 2022-06-20 14:03:36.533710
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MyCLIArgs(object):
        def __init__(self, values):
            self.values = values

        def get(self, name, default=None):
            value = self.values.get(name, default)
            return cliargs_deferred_get(name, default=value, shallowcopy=True)

    # Calling the closure with an arg of "values" returns the value from the arg
    my_args = MyCLIArgs({"values": "value"})
    assert cliargs_deferred_get("values")() == "value"
    assert my_args.get("values")() == "value"

    # Calling the closure with an arg that doesn't have a value
    assert cliargs_deferred_get("fake")() is None
    assert my_args.get("fake")() is None

    # Calling

# Generated at 2022-06-20 14:03:45.419961
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=R0201
    class FakeCliArgs(dict):
        """Mock of the CLIARGS class"""
        def get(self, key, default=None):
            return super(FakeCliArgs, self).get(key, default)
    test_args = FakeCliArgs()
    test_args.update({'list_arg': ['a', 'b', 'c'],
                      'dict_arg': {'a': 1, 'b': 2, 'c': 3},
                      'set_arg': {'a', 'b', 'c'},
                      'string_arg': 'value'})
    _init_global_context(test_args)

    assert cliargs_deferred_get('list_arg')() == ['a', 'b', 'c']
    assert cliargs_deferred_

# Generated at 2022-06-20 14:03:45.956149
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    return True

# Generated at 2022-06-20 14:03:57.755252
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for the closure cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    import pytest

    # First test shallow copy
    global CLIARGS
    test_args = {'a': 1, 'b': [1, 2], 'c': {'d': 4}}
    CLIARGS = GlobalCLIArgs.from_options(test_args)

    a = cliargs_deferred_get('a')
    b = cliargs_deferred_get('b')
    c = cliargs_deferred_get('c')

    # Calling the closures should return the right values
    assert a() == 1
    assert b() == [1, 2]
    assert c() == {'d': 4}

    # Now make sure that they're full copies so mutating them doesn

# Generated at 2022-06-20 14:04:05.633095
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    _init_global_context({'foo': ['a', 'b', 'c']})
    func = cliargs_deferred_get('foo')
    assert func() == ['a', 'b', 'c']

    _init_global_context({'foo': {'k': 'v'}})
    func = cliargs_deferred_get('foo')
    assert func() == {'k': 'v'}

    _init_global_context({'foo': {'k': 'v'}})
    func = cliargs_deferred_get('foo', shallowcopy=True)
    assert func() == {'k': 'v'}

    _init_global_context({'foo': ['a', 'b', 'c']})

# Generated at 2022-06-20 14:04:16.507177
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    test_val = ['first_val']
    CLIARGS = CLIArgs({'test_key': test_val})

    def_val = ['default_val']
    def_val2 = def_val + ['another_val']
    no_val = ['no_val']
    no_val2 = no_val + ['another_val']

    test_val.append('second_val')

    deffered_get = cliargs_deferred_get('test_key', default=def_val)
    deffered_get2 = cliargs_deferred_get('test_key2', default=def_val2)
    deffered_get_no_val = cliargs_deferred_get('no_val_key', default=no_val)
    deffered_get_no

# Generated at 2022-06-20 14:04:23.041129
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get function
    """
    # pylint: disable=unused-variable
    cli_args = {'BAR': 'bar', 'FOO': ['foo']}
    cli_args_singleton_initializer(cli_args)
    assert cliargs_deferred_get('BAR') == 'bar'
    assert cliargs_deferred_get('FOO') == ['foo']
    unset_cli_args_singleton()



# Generated at 2022-06-20 14:04:25.322529
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test, tmpdir = _test_cliargs_deferred_get()
    yield test
    _test_cliargs_deferred_get_cleanup(tmpdir)


# Generated at 2022-06-20 14:04:33.869404
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Note: not necessarily a good unit test as it should be ensured that
    # _init_global_context is called with args and any change to this function
    # should also ensure that the code calling _init_global_context is updated
    # appropriately.
    test_args = {'foo': 42}
    _init_global_context(test_args)
    assert cliargs_deferred_get('foo')(), 42 == cliargs_deferred_get('foo')()
    assert cliargs_deferred_get('bar')(), None == cliargs_deferred_get('bar')()
    assert cliargs_deferred_get('bar', default=2)(), 2 == cliargs_deferred_get('bar', default=2)()