

# Generated at 2022-06-20 13:54:45.502082
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestArgs:
        def __init__(self, args):
            self.args = args

        def __getitem__(self, key):
            return self.args[key]

    class TestCLIGlobalArgs(GlobalCLIArgs):
        def __init__(self, args):
            super(TestCLIGlobalArgs, self).__init__(args)

        def copy(self):
            return TestCLIGlobalArgs(self.args.copy())

    test_args = {'test_list': ['foo', 'bar'], 'test_int': 99, 'test_str': "test", 'test_dict': {'foo': 'bar'}}
    global CLIARGS
    test_args_obj = TestCLIGlobalArgs(test_args)
    CLIARGS = test_args_obj
    assert cl

# Generated at 2022-06-20 13:54:54.736517
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # fake the cli_args not having been processed, so the singleton version
    # hasn't been created
    global CLIARGS
    CLIARGS = CLIArgs({})
    cli_args = {
        'foo': 'bar',
        'a_list': [1, 2, 3],
        'a_dict': {'a': 1, 'b': 2},
        'a_set': set(['a', 'b', 'c']),
        'a_mapping': {'a': 'one', 'b': 'two'},
    }

    _init_global_context(cli_args)

    get_foo = cliargs_deferred_get('foo')
    assert get_foo() == 'bar'


# Generated at 2022-06-20 13:55:04.617562
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    import pytest
    from ansible.utils.context_objects import CLIRunnable
    from ansible.utils.context_objects import CLIArgs

    class TestRunnable(CLIRunnable):
        def execute(self):
            pass

    class TestCLIArgs(CLIArgs):
        pass

    class TestCLIRunnable(TestRunnable):
        def parse_cli(self):
            return {'testkey': {'type': 'str', 'default': 'test_value'}}

    def check_dynamic(cli_args, test_runnable):
        """Check that cli_args object is correctly bound"""
        assert cli_args is CLIARGS
        t = cliargs_deferred_get('testkey')
        assert t() == 'test_value'
        assert not isinstance

# Generated at 2022-06-20 13:55:15.492924
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check_deferred_list(func, value):
        func.__defaults__ = (value,)
        assert func() == value, 'Should return the supplied value: {}'.format(func)
        assert func() is not value, 'Should be a new copy of the value: {}'.format(func)

    def check_deferred_nocopy(func, value):
        func.__defaults__ = (value,)
        assert func() is value, 'Should return the supplied value: {}'.format(func)

    check_deferred_list(cliargs_deferred_get(''), [])
    check_deferred_list(cliargs_deferred_get('', shallowcopy=True), [])
    check_deferred_nocopy(cliargs_deferred_get('', shallowcopy=False), [])

    check_deferred

# Generated at 2022-06-20 13:55:27.283739
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'_ansible_verbosity': 0, '_ansible_syslog_facility': None})
    CLIARGS.__setitem__ = CLIARGS.set
    # Test using an unset value.  We should only get the default back
    get_verbosity = cliargs_deferred_get('verbosity', 5)
    assert get_verbosity() == 5
    CLIARGS['verbosity'] = 3
    assert get_verbosity() == 3
    # Test using a value that is an immutable object.  We should get the same object back
    assert get_verbosity() is CLIARGS['verbosity']
    get_syslog_facility = cliargs_deferred_get('_ansible_syslog_facility', 'LOG_USER')
    # Test that

# Generated at 2022-06-20 13:55:34.840026
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check_value(expected, input_value, shallowcopy=False):
        CLIARGS.set('sample_key', input_value)
        assert expected == cliargs_deferred_get('sample_key', shallowcopy=shallowcopy)()
        CLIARGS.pop()

    # value is not copied if shallowcopy is False
    check_value(['A', 'B'], ['A', 'B'])
    # Sequence types are shallow copied if shallowcopy is True
    check_value(['A', 'B'], ['A', 'B'], shallowcopy=True)
    check_value({'A': 'A', 'B': 'B'}, {'A': 'A', 'B': 'B'})

# Generated at 2022-06-20 13:55:45.038479
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('dummy')() is None
    assert cliargs_deferred_get('dummy', default='foo')() == 'foo'
    cli_args = dict(dummy='bar', shallow='baz')
    _init_global_context(cli_args)
    assert cliargs_deferred_get('dummy')() == 'bar'
    assert cliargs_deferred_get('shallow')() == 'baz'
    assert cliargs_deferred_get('shallow', shallowcopy=True)() == 'baz'
    cli_args = dict(dummy='bar', shallow=[1, 2, 3])
    _init_global_context(cli_args)
    assert cliargs_deferred_get('shallow')() == [1, 2, 3]

# Generated at 2022-06-20 13:55:55.359460
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {
        'collect_facts': 'explicit',
        'output_path': '/some/file',
        'become': True,
        'become_user': 'asdf',
        'become_method': 'other',
        'check': True,
        'listtasks': False,
        'listtags': False,
        'metadata_dependency_tree': True,
        'syntax': False,
        'task_filters': ['filter1', 'filter2'],
        'tags': ['t1', 't2'],
        'skip_tags': ['st1', 'st2'],
    }

    global CLIARGS
    _init_global_context(cli_args)

    # check that we get the same value that is in the context

# Generated at 2022-06-20 13:56:00.319274
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo')() == 'baz'
    assert cliargs_deferred_get('foo')() == 'baz'
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

# Generated at 2022-06-20 13:56:10.413625
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_dict = {'bar': [1, 2, 3]}
    set_value = {1, 2, 3}

    def build_cliargs(data):
        return CLIArgs(data)

    def build_inner(key):
        return cliargs_deferred_get(key, shallowcopy=True)

    # Test getting a value from the dictionary
    assert build_inner('foo')().get() == None
    # Test that the default is set back to default
    CLIARGS = CLIArgs({})
    assert build_inner('foo')().get() == None

    # Test getting a value from the dictionary
    assert build_inner('foo')().get(default='testing') == 'testing'
    # Test that the default is set back to default
    CLIARGS = CLIArgs({})

# Generated at 2022-06-20 13:56:23.881195
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS._options = {'foo': 'bar'}
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foobar', default='baz')() == 'baz'

    CLIARGS._options = {'foo': 'bar', 'list': [1, 2, 3]}
    assert cliargs_deferred_get('list')() == [1, 2, 3]
    assert cliargs_deferred_get('list', shallowcopy=True)() == [1, 2, 3]

    CLIARGS._options = {'foo': 'bar', 'dict': {'one': 1, 'two': 2}}
    assert cl

# Generated at 2022-06-20 13:56:25.408870
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('doesnt_exist')() is None



# Generated at 2022-06-20 13:56:34.997984
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    global CLIARGS
    myargs = CLIARGS.copy()
    myargs.update(dict(
        abc=123,
        def_value=None,
        def_value_non_none=123,
        def_value_shallow=dict(foo='bar'),
        def_value_shallow_copy=dict(foo='bar'),
    ))
    CLIARGS = myargs
    default = object()

    assert cliargs_deferred_get('abc')() == 123
    assert cliargs_deferred_get('def_value', default=default)() is default
    assert cliargs_deferred_get('def_value_non_none', default=default)() == 123

# Generated at 2022-06-20 13:56:40.862063
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    val = list(range(10))
    _init_global_context(dict(test=val))
    assert cliargs_deferred_get('test')() == val

    val = set(range(10))
    _init_global_context(dict(test=val))
    assert cliargs_deferred_get('test')() == val

# Generated at 2022-06-20 13:56:51.900758
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cli_args = {'bin_ansible_callbacks': 'default', 'force_handlers': False,
                'force_pipeline': True, 'force_poll': True,
                'force_remote_user': True, 'force_verbosity': False,
                'force_debug': False, 'module_path': None,
                'one_line': False, 'output_path': None, 'playbook_dir': None,
                'playbook_paths': None, 'show_custom_stats': None,
                'stats': False, 'syntax': None,
                'top_file_location': '/path/to/ansible/playbook',
                'verbosity': 1}
    _init_global_context(cli_args)

# Generated at 2022-06-20 13:57:00.862722
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS_DATA = {'ansible_verbosity': 1}
    _init_global_context(CLIARGS_DATA.copy())
    assert cliargs_deferred_get('ansible_verbosity') == 1
    assert cliargs_deferred_get('ansible_verbosity', default=2) == 1
    assert cliargs_deferred_get('ansible_verbosity_default', default=2) == 2
    string_value = 'A test string'
    list_value = ['A', 'test', 'string']
    CLIARGS_DATA['string_value'] = string_value
    CLIARGS_DATA['list_value'] = list_value
    assert cliargs_deferred_get('string_value') == string_value

# Generated at 2022-06-20 13:57:07.655754
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = {'foo': 'bar', 'baz': [1,2,3], 'quux': {'a': 1, 'b': 2}, 'blap': {'a', 'b'}}
    _init_global_context(cliargs)
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('foo', default='zab') == 'bar'
    assert cliargs_deferred_get('fuzz', default='zab') == 'zab'
    assert cliargs_deferred_get('baz') == [1,2,3]
    assert cliargs_deferred_get('baz', shallowcopy=True) == [1,2,3]
    assert cliargs_deferred_get('zab') is None

# Generated at 2022-06-20 13:57:18.496943
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 42}
    _init_global_context(cli_args)
    assert CLIARGS.get('foo') == 42
    assert cliargs_deferred_get('foo')() == 42
    assert cliargs_deferred_get('foo', default=6)() == 42
    assert cliargs_deferred_get('bar', default=6)() == 6
    assert cliargs_deferred_get('bar')() is None

    cli_args = {'foo': [1, 2, 3]}
    _init_global_context(cli_args)
    assert CLIARGS.get('foo') == [1, 2, 3]
    assert cliargs_deferred_get('foo')() == [1, 2, 3]

# Generated at 2022-06-20 13:57:30.349875
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    test_arg = dict(key='value',
                    key2=dict(subkey1=1, subkey2='2'),
                    key3=[1, 2, 3],
                    key4=set([3, 2, 1]))
    _init_global_context(test_arg)
    key1 = cliargs_deferred_get('key')
    key2 = cliargs_deferred_get('key2')
    key3 = cliargs_deferred_get('key3')
    key4 = cliargs_deferred_get('key4')
    key1_shallow = cliargs_deferred_get('key', shallowcopy=True)
    key2_shallow = cliargs_deferred_get('key2', shallowcopy=True)
    key3_shallow = cl

# Generated at 2022-06-20 13:57:41.561991
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check_value(key, value, shallowcopy=False):
        """Check the value returned by ``cliargs_deferred_get`` is set up properly"""
        answers = {}
        assert cliargs_deferred_get(key, default=value, shallowcopy=shallowcopy)() is value
        assert cliargs_deferred_get(key, default=value, shallowcopy=shallowcopy)().__closure__[0].cell_contents is default
        answers[key] = value
        _init_global_context(answers)
        assert cliargs_deferred_get(key, default=value, shallowcopy=shallowcopy)() is value
        assert cliargs_deferred_get(key, default=value, shallowcopy=shallowcopy)().__closure__[0].cell_contents is value


    #

# Generated at 2022-06-20 13:57:55.837566
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Test default value
    get_default = cliargs_deferred_get('doesnotexist', default='test')
    assert get_default() == 'test'

    # Test cache works across multiple calls
    _init_global_context({'test': 'result'})
    get_test = cliargs_deferred_get('test', default='cache-broken')
    assert get_test() == 'result'
    assert get_test() == 'result'

    # Test shallow copy on list and tuple
    _init_global_context({'test_shallow_list': [1, 2, 3]})
    get_test_shallow_list = cliargs_deferred_get('test_shallow_list')
    assert get_test_shallow_list() == [1, 2, 3]
    _init_global_context

# Generated at 2022-06-20 13:58:04.300721
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils import basic
    args = basic.parse_cli_args(['--test-opt'])
    _init_global_context(args)
    assert CLIARGS['test_opt'] is True
    assert cliargs_deferred_get('test_opt')() is True
    assert cliargs_deferred_get('test_opt', shallowcopy=True)() is True
    assert cliargs_deferred_get('other_opt', default='foobar')() is 'foobar'
    assert cliargs_deferred_get('other_opt', default='foobar', shallowcopy=True)() is 'foobar'

# Generated at 2022-06-20 13:58:10.950679
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': ['qux']})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == ['qux']
    assert cliargs_deferred_get('nonexistent', default=42)() == 42
    assert cliargs_deferred_get('baz', shallowcopy=True)() != cliargs_deferred_get('baz')()
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['qux']

# Generated at 2022-06-20 13:58:18.042537
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Make a non-singleton version of :py:class:`GlobalCLIArgs` for unit testing"""
    def inner(key, default=None, shallowcopy=False):
        value = CLIARGS.get(key, default=default)
        if not shallowcopy:
            return value
        elif is_sequence(value):
            return value[:]
        elif isinstance(value, (Mapping, Set)):
            return value.copy()
        return value
    return inner

# Generated at 2022-06-20 13:58:28.808471
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cliargs = CLIArgs({'test_key': 'test'})
    CLIARGS = cliargs
    testing = cliargs_deferred_get('test_key')
    assert testing() == cliargs['test_key']
    cliargs['test_key'] = 'test2'
    assert testing() == cliargs['test_key']
    cliargs = CLIArgs({'test_key': 'test'})
    CLIARGS = cliargs
    testing_copy = cliargs_deferred_get('test_key', shallowcopy=True)
    assert testing_copy() == cliargs['test_key']
    cliargs['test_key'] = 'test2'
    assert testing_copy() != cliargs['test_key']


# Generated at 2022-06-20 13:58:34.964106
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs

    # Check mapping key
    CLIARGS = CliArgs({'foo': 'bar'})
    deferred_get = cliargs_deferred_get('foo')
    assert deferred_get() == 'bar'
    assert deferred_get(default='new') == 'bar'

    # Check missing key
    CLIARGS = CliArgs({'other': 'something'})
    deferred_get = cliargs_deferred_get('foo')
    assert deferred_get() is None
    assert deferred_get(default='new') == 'new'

    # Check sequence get
    CLIARGS = CliArgs({'seq': [1, 2, 3]})
    deferred_get = cliargs_deferred_get('seq')

# Generated at 2022-06-20 13:58:45.201731
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that this works when CLIARGS is the singleton
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': 2})
    get_a = cliargs_deferred_get('a')
    get_b = cliargs_deferred_get('b')
    get_c = cliargs_deferred_get('c')
    assert get_a() == 1
    assert get_b() == 2
    assert get_c() is None

    # Test that this works when CLIARGS is a function
    CLIARGS = {'a': 1, 'b': 2}
    get_a = cliargs_deferred_get('a')
    get_b = cliargs_deferred_get('b')
    get_c = cliargs_deferred_get('c')

# Generated at 2022-06-20 13:58:55.732062
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from copy import copy
    from ansible.utils.context_objects import GlobalCLIArgs

    global CLIARGS
    cliargs_backup = CLIARGS

# Generated at 2022-06-20 13:59:07.489062
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""

    def test_get_cliargs(key, default, expected):
        """Unit test helper function to test different combination of argument values and default/no default

        ``expected`` is returned values from cliargs_deferred_get
        """
        cli_args = CLIArgs({key: 'value'})
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

        expected_func = cliargs_deferred_get(key, default=default)
        assert expected_func() == expected

    # Test different combination of argument values and default/no default
    # test_cliargs_deferred_get(key, default=None, expected)
    yield test_cliargs_deferred_get, 'key', None, 'value'
   

# Generated at 2022-06-20 13:59:13.983463
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    argument = [1, 2, 3]
    key = 'key'
    CLIARGS = CLIArgs({key: argument})
    assert argument is cliargs_deferred_get(key)()

# Avoid missing docstring errors for functions that aren't part of the public API
test_cliargs_deferred_get.__doc__ = None

# Generated at 2022-06-20 13:59:34.021761
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.text.converters import to_text
    import copy
    global CLIARGS
    CLIARGS = CLIArgs({'ANSIBLE_STDOUT_CALLBACK': 'default',
                       'ANSIBLE_MODULE_ARGS': {'foo': 'bar',
                                               'this': 'is a test',
                                               'of': 'cliargs_deferred_get'},
                       'ANSIBLE_MODULE_ARGS_SAFE': {'baz': 'buzz'},
                       'ANSIBLE_MODULE_ARGS_TEST_SET': {'two': '3'}})
    assert cliargs_deferred_get('ANSIBLE_STDOUT_CALLBACK') == 'default'

# Generated at 2022-06-20 13:59:42.746555
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Options(object):
        option1 = None
        option2 = None

    class CliArgs(object):
        def __init__(self, options):
            self.options = options

        def get(self, key, default=None):
            return getattr(self.options, key, default)

    options = Options()
    options.option1 = 'Yay!'
    options.option2 = ['a', 'b', 'c']

    global CLIARGS
    CLIARGS = CliArgs(options)

    # Call the function
    inner_option1 = cliargs_deferred_get('option1')
    assert inner_option1() == 'Yay!'

    # Call the function a 2nd time will get the same result
    inner_option1_2nd = cliargs_deferred_get('option1')


# Generated at 2022-06-20 13:59:53.955638
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test(default=None, shallowcopy=False, cliargs_override=None):
        if cliargs_override is None:
            cliargs_override = {}
        _init_global_context(cliargs_override)
        inner = cliargs_deferred_get('key', default=default, shallowcopy=shallowcopy)
        return inner()

    assert test() is None
    assert test('a value') == 'a value'
    assert test(cliargs_override={'key': 'test value'}) == 'test value'
    assert test('a value', cliargs_override={'key': 'test value'}) == 'test value'
    assert test(shallowcopy=True, cliargs_override={'key': 'test value'}) == 'test value'

# Generated at 2022-06-20 14:00:05.639027
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Need to set CLIARGS:
    #   ensure it is not callable (trying to call it will trigger an error)
    #   add test values
    #   ensure the test values are returned
    def check_closure(key, value):
        assert callable(value)
        assert CLIARGS[key] == value()

    CLIARGS['list_key'] = ['foo', 'bar']
    CLIARGS['mapping_key'] = {'a': 'b'}
    CLIARGS['string_key'] = 'foo'
    CLIARGS['set_key'] = {'foo', 'bar'}

    tuple_key = 'tuple_key'
    CLIARGS[tuple_key] = 'foo', 'bar'

# Generated at 2022-06-20 14:00:13.808363
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert None is cliargs_deferred_get("foo")()
    CLIARGS = CLIArgs({"foo": "bar"})
    assert "bar" is cliargs_deferred_get("foo")()
    CLIARGS = CLIArgs({"foo": "bar"})
    assert "bar" is cliargs_deferred_get("foo", 'baz')()
    CLIARGS = CLIArgs({"foo": ["bar"]})
    assert ["bar"] is cliargs_deferred_get("foo", shallowcopy=True)()
    CLIARGS = CLIArgs({"foo": ["bar"], "baz": "quux"})
    assert ["bar"] is cliargs_deferred_get("foo", shallowcopy=True)()

# Generated at 2022-06-20 14:00:18.027945
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # setup
    class CliArgs(dict):
        def get(self, key, default=None):
            pass
    cliargs = CliArgs()
    cliargs['verbosity'] = 'vvv'
    CLIARGS = cliargs

    # write
    cliargs['verbosity'] = 'vvv'

    # read
    assert cliargs['verbosity'] is 'vvv'

# Generated at 2022-06-20 14:00:28.442210
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = {'bar': 'baz', 'bam': 'bam bam'}
    assert cliargs_deferred_get('foo')() == {'bar': 'baz', 'bam': 'bam bam'}
    assert cliargs_deferred_get('bam', 'bip', True)() == 'bip'
    assert cliargs_deferred_get('foo', True)() == {'bar': 'baz', 'bam': 'bam bam'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'bar': 'baz', 'bam': 'bam bam'}

# Generated at 2022-06-20 14:00:35.346851
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'v': 1, 'u': 2})
    assert cliargs_deferred_get('u')() == 2
    # The function should by default not shallow copy
    assert cliargs_deferred_get('v') == cliargs_deferred_get('v')()
    assert cliargs_deferred_get('v', shallowcopy=True)() == 1
    assert cliargs_deferred_get('v', shallowcopy=True)() is not cliargs_deferred_get('v')()
    # The default should not be copied
    assert cliargs_deferred_get('x')() is None
    assert cliargs_deferred_get('x', default=3)() is 3

# Generated at 2022-06-20 14:00:46.506221
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is a dummy function as ``CLIARGS`` needs to be replaced
    cli_args = {'test_key': 'test_value'}

    def do_test(key, default, shallowcopy, expected_value):
        _init_global_context(cli_args)
        assert cliargs_deferred_get(key, default, shallowcopy)() == expected_value

    # Test basic get
    do_test('test_key', None, False, 'test_value')

    # Test that the value returned is a shallow copy
    test_set = set(['a', 'b'])
    cli_args = {'test_set': test_set}
    do_test('test_key', None, True, 'test_value')
    test_set.add('c')

# Generated at 2022-06-20 14:00:57.617270
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert CLIARGS.get('1') is None
    CLIARGS = GlobalCLIArgs({'1': [1, 2, 3]})
    f = cliargs_deferred_get('1')
    assert f() == [1, 2, 3]
    CLIARGS = GlobalCLIArgs({'1': {1, 2, 3}})
    f2 = cliargs_deferred_get('1')
    assert f2() == {1, 2, 3}
    CLIARGS = GlobalCLIArgs({'1': {'foo': 'bar'}})
    f3 = cliargs_deferred_get('1')
    assert f3() == {'foo': 'bar'}
    f4 = cliargs_deferred_get('1', shallowcopy=True)
    assert f

# Generated at 2022-06-20 14:01:19.282247
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for the function cliargs_deferred_get
    """
    from ansible_collections.vmware.vmware_rest.tests.unit.compat import unittest
    from ansible.module_utils.common._collections_compat import Mapping

    class TestCliArgs(Mapping):
        __getitem__ = lambda self, key: 'value'

    class CliArgsDeferredGetTestCase(unittest.TestCase):
        def setUp(self):
            self.cliargs = TestCliArgs()
            self.key = 'key'
            self.default = 'default'
            self.expected = self.cliargs[self.key]
            self.inner = cliargs_deferred_get(self.key)
            self.shallowcopy_inner = cliargs_deferred_get

# Generated at 2022-06-20 14:01:20.300727
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get('this_does_not_exist', default='yes')()

# Generated at 2022-06-20 14:01:32.171457
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import ContextObjectsCollection
    from copy import deepcopy

    # Define the cli_args which will be used to initialize ``CLIARGS``

# Generated at 2022-06-20 14:01:42.506526
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ac_listify
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode

# Generated at 2022-06-20 14:01:53.602177
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Normal use
    expected_value = 'bar'
    CLIARGS['foo'] = expected_value
    retrieved_value = cliargs_deferred_get('foo')()
    assert retrieved_value == expected_value

    # Default value
    expected_value = 'baz_default'
    retrieved_value = cliargs_deferred_get('baz', default=expected_value)()
    assert retrieved_value == expected_value

    # Clone sequence
    expected_value = ['foo', 'bar']
    CLIARGS['sequence'] = expected_value
    retrieved_value = cliargs_deferred_get('sequence', shallowcopy=True)()
    assert retrieved_value is not expected_value
    assert retrieved_value == expected_value

    # Clone mapping

# Generated at 2022-06-20 14:02:03.828211
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test': 'old', 'test2': ['old', 'old'], 'test3': {'old': 'old'}})
    assert cliargs_deferred_get('test')() == 'old'
    assert cliargs_deferred_get('test2')() == ['old', 'old']
    assert cliargs_deferred_get('test3')() == {'old': 'old'}
    assert cliargs_deferred_get('missing')() is None
    assert cliargs_deferred_get('test')() is cliargs_deferred_get('test')()
    assert cliargs_deferred_get('test2')() is cliargs_deferred_get('test2')()

# Generated at 2022-06-20 14:02:09.342744
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS.update({'foo': {'bar': 'baz'}, 'baz': [1, 2, 3]})
    assert cliargs_deferred_get('foo') == CLIARGS.get('foo')
    assert cliargs_deferred_get('foo', shallowcopy=True) == {'bar': 'baz'}
    assert cliargs_deferred_get('baz') == CLIARGS.get('baz')
    assert cliargs_deferred_get('baz', shallowcopy=True) == [1, 2, 3]

# FIXME: This function is not implemented yet but is not a temporary function

# Generated at 2022-06-20 14:02:20.331121
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    if CLIARGS.get('ANSIBLE_CLI_TEST_CLIARGS_DEFERRED_GET'):
        def _verify_value(value):
            assert value == [1, 2, 3], 'CliArgs_deferred_get did not shallowcopy list values'
        CLIARGS.ANSIBLE_CLI_TEST_CLIARGS_DEFERRED_GET = False
        _init_global_context(CLIARGS)  # Note _init_global_context is not bound to any class so it works here
        CLIARGS['ANSIBLE_CLI_TEST_CLIARGS_DEFERRED_GET'] = [1, 2, 3]
        assert cliargs_deferred_get('ANSIBLE_CLI_TEST_CLIARGS_DEFERRED_GET', shallowcopy=True)

# Generated at 2022-06-20 14:02:29.039532
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': 42})
    assert cliargs_deferred_get('foo')() == 42
    assert cliargs_deferred_get('foo', default=1)() == 42
    assert cliargs_deferred_get('bar', default=1)() == 1
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 42
    assert cliargs_deferred_get('foo', default=1, shallowcopy=True)() == 42
    assert cliargs_deferred_get('bar', default=1, shallowcopy=True)() == 1

# Generated at 2022-06-20 14:02:38.681851
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    global CLIARGS
    old_cliargs = CLIARGS
    CLIARGS = CLIArgs({'test': True})
    assert cliargs_deferred_get('test')()
    CLIARGS = CLIArgs({'test': True, 'test2': 'foo'})
    assert cliargs_deferred_get('test', default=False)()
    assert cliargs_deferred_get('test2', default='bar')() == 'foo'
    assert cliargs_deferred_get('test3', default='bar')() == 'bar'
    CLIARGS = CLIArgs({'test': {'foo': 'bar'}, 'test2': ['foo', 'bar']})

# Generated at 2022-06-20 14:03:22.534254
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Initialize the global context for unit testing
    _init_global_context(None)

    def foo():
        return 'foo'

    # Validate passing in a function is called
    assert cliargs_deferred_get('nope', foo)() == 'foo'

    # Validate that a literal is returned
    assert cliargs_deferred_get('nope', 'foo')() == 'foo'

    # Validate that a literal is returned
    assert cliargs_deferred_get('nope', ['foo'])() == ['foo']

    # Validate that a literal is returned
    assert cliargs_deferred_get('nope', {'foo'})() == {'foo'}

    # Validate that a literal is returned

# Generated at 2022-06-20 14:03:32.323435
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Basic unit test for cliargs_deferred_get"""
    # pylint: disable=unused-variable
    from unittest import TestCase

    from ansible.utils.context_objects import GlobalCLIArgs

    class Test(TestCase):
        def test_get_default(self):
            _init_global_context(GlobalCLIArgs.from_options({}))
            res = cliargs_deferred_get('foo', default='default')()
            self.assertEqual(res, 'default')

        def test_get_default_shallowcopy(self):
            _init_global_context(GlobalCLIArgs.from_options({}))
            res = cliargs_deferred_get('foo', default=['default'], shallowcopy=True)()

# Generated at 2022-06-20 14:03:37.482398
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(foo='bar'))
    assert cliargs_deferred_get('foo', default='not_bar')() == 'bar'
    _init_global_context(dict(foo='bar'))
    assert cliargs_deferred_get('not_foo', default='bar')() == 'bar'

# Generated at 2022-06-20 14:03:46.040343
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-20 14:03:55.749677
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    class Foo(object):
        def __init__(self):
            self.bar = cliargs_deferred_get('bar')

        def get_bar(self):
            return self.bar

    global CLIARGS
    CLIARGS = CLIArgs(dict(bar=123))
    f = Foo()
    assert f.get_bar() == 123
    CLIARGS = CLIArgs(dict(bar=321))
    assert f.get_bar() == 321
    CLIARGS = CLIArgs(dict())
    assert f.get_bar() is None
    CLIARGS = CLIArgs({})

# Generated at 2022-06-20 14:04:00.799478
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'verbosity': 2, 'extra_vars': {'foo': 'bar'}}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('verbosity') == 2
    assert cliargs_deferred_get('extra_vars') == {'foo': 'bar'}
    assert cliargs_deferred_get('extra_vars', shallowcopy=True) == {'foo': 'bar'}

# Generated at 2022-06-20 14:04:12.508834
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # "introduce" the function by shadowing it with a global variable
    global CLIARGS

    # first test that it returns the default when the variable has not been set
    result = cliargs_deferred_get('key', 'value')()
    assert result == 'value'

    # test that it returns the default if the key is not in the CLIARGS
    CLIARGS = {}
    result = cliargs_deferred_get('key', 'value')()
    assert result == 'value'

    # test that it returns the default if the key is None
    CLIARGS = {'key': None }
    result = cliargs_deferred_get('key', 'value')()
    assert result == 'value'

    # test that it returns the key's value if present
    CLIARGS = {'key': 'server' }

# Generated at 2022-06-20 14:04:22.998937
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils._text import to_text
    from ansible.utils.context_objects import GlobalCLIArgs

    def cli_arg_list(list_):
        args = list_[:]
        # NOTE: the code below assumes that this function is called with the
        # following arguments:
        # ['--list-foo-bar']
        return args

    cli_args = cli_arg_list(['--list-foo-bar'])
    _init_global_context(cli_args)

    assert to_text(cliargs_deferred_get('list_foo_bar')) == u"on"
    orig_list_foo_bar = CLIARGS.get('list_foo_bar')
    # Make sure that calling the deferred get does not change the original value

# Generated at 2022-06-20 14:04:29.736779
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Note: we have to do this here as it won't work in a class's static method
    # (which is where this is needed)
    # TODO: If we ever convert to pytest's conftest, then we can get rid of this
    CLIARGS._args = {
        'foo': 'bar',
        'frobnicate': [1, 2, 'three'],
        'dict': {'a': 'b'},
        'set': set([1, 2, 3, 4]),
    }

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('frobnicate')() == [1, 2, 'three']
    assert cliargs_deferred_get('dict')() == {'a': 'b'}


# Generated at 2022-06-20 14:04:36.681005
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Test no key in CLIARGS
    assert cliargs_deferred_get('foo')() is None

    # Test key in CLIARGS
    CLIARGS = GlobalCLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

    # Test key in CLIARGS that is a list
    CLIARGS = GlobalCLIArgs({'foo': ['bar', 'baz', 'qux']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz', 'qux']