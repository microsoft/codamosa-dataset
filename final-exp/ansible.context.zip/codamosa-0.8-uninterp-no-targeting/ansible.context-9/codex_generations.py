

# Generated at 2022-06-20 13:54:39.505713
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.context_objects import CLIArgs
    from ansible.module_utils.parsing.convert_bool import boolean


# Generated at 2022-06-20 13:54:53.191326
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.DEFAULT = True
    assert cliargs_deferred_get('DEFAULT')() is True
    assert cliargs_deferred_get('DEFAULT', default='foo')() == 'foo'
    assert cliargs_deferred_get('NO_DEFAULT')() is None
    assert cliargs_deferred_get('NO_DEFAULT', default='foo')() == 'foo'
    CLIARGS.NO_DEFAULT = 'bar'
    assert cliargs_deferred_get('NO_DEFAULT')() == 'bar'

    CLIARGS.SEQUENCE = ()
    assert cliargs_deferred_get('SEQUENCE', shallowcopy=True)() == ()
    assert cliargs_deferred_get('SEQUENCE')() == ()

# Generated at 2022-06-20 13:55:03.903986
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Check that deferred gets work with CLIARGS as a singleton"""
    global CLIARGS
    # Test with GlobalCLIArgs
    opt = {u'host_key_checking': True, u'inventory': [u'foo'], u'subset': u'all'}
    CLIARGS = GlobalCLIArgs.from_options(opt)
    assert cliargs_deferred_get(u'host_key_checking')()
    assert cliargs_deferred_get(u'inventory')() == [u'foo']
    assert cliargs_deferred_get(u'subset')() == u'all'
    assert cliargs_deferred_get(u'wtf')() is None

# Generated at 2022-06-20 13:55:14.582634
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=missing-class-docstring,missing-function-docstring
    # pylint: disable=no-member
    from ansible.context import _init_global_context
    from copy import copy, deepcopy
    from ansible.errors import AnsibleError
    from ansible.utils.context_objects import GlobalCLIArgs
    from collections import OrderedDict

    # We need to create a context object
    _init_global_context(GlobalCLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 5, 'b': 7}, 'corge': OrderedDict((('a', 1), ('b', 2))), 'grault': 5, 'garply': None}))

# Generated at 2022-06-20 13:55:21.657128
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})

    # verify default return value
    got_default = cliargs_deferred_get('not_set')()
    assert got_default is None

    # verify return with non-default value
    CLIARGS.update(dict(not_set='value'))
    got_value = cliargs_deferred_get('not_set')()
    assert got_value == 'value'

# Generated at 2022-06-20 13:55:31.855033
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy

    cliargs_dict = {'foo': [1, 2, 3]}
    orig_foo = cliargs_dict['foo']

    _init_global_context(cliargs_dict)
    # Check that we can get a value
    assert cliargs_deferred_get('foo')() == cliargs_dict['foo']
    # Check that we can get a value not in cliargs
    assert cliargs_deferred_get('bar', default='qux')() == 'qux'

    # Check that we get a shallow copy when shallowcopy is True
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not orig_foo

    # Check that the shallow copy is really shallow
    new_copy = cliargs_deferred_get('foo', shallowcopy=True)()


# Generated at 2022-06-20 13:55:42.721652
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for the ``cliargs_deferred_get`` function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_bytes

    CLIARGS = CLIArgs({})

    # Default values
    assert not CLIARGS
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'

    # Shallow copies

# Generated at 2022-06-20 13:55:54.383218
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get() works as expected

    This test should be run with pylint and pycodestyle

    ``pylint test_cliargs_deferred_get``
    ``pycodestyle test_cliargs_deferred_get``

    """
    test_dict = {'key': 'value'}
    test_list = ['value1', 'value2']
    test_int = 1
    test_default = 'test_default'
    test_default_list = ['test_default', 'test_default']
    test_default_dict = {'test_default': 'test_default'}
    assert hasattr(test_default_dict, 'copy')
    assert not hasattr(test_int, 'copy')
    assert not hasattr(test_default, 'copy')

    # Test against the

# Generated at 2022-06-20 13:56:05.904356
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class A(CliHosts):
        pass

    def deferred_get_closure(key):
        """Closure over cliargs_deferred_get"""
        return cliargs_deferred_get(key)

    cli_args = CliArgs({'hosts': 'example.com', 'host_key_checking': False})

    cli_hosts = A('hosts')
    assert cli_hosts.default_callback == deferred_get_closure('hosts')
    assert cli_hosts.key == 'hosts'

    cli_host_key_checking = A('host_key_checking')
    assert cli_host_key_checking.default_callback == deferred_get_closure('host_key_checking')
    assert cli_host_key_checking.key == 'host_key_checking'



# Generated at 2022-06-20 13:56:16.598663
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test simple value case
    cliargs = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test mutable value case
    my_var = [1, 2, 3]
    cliargs = CLIArgs({'foo': my_var})
    assert cliargs_deferred_get('foo')(shallowcopy=True) == my_var
    assert cliargs_deferred_get('foo')(shallowcopy=True) is not my_var
    assert cliargs_deferred_get('foo')() == my_var
    assert cliargs_deferred_get('foo')() is my_var
    assert cliargs_deferred_get('bar')(default=[5]) == [5]

    # Test mutable value with no

# Generated at 2022-06-20 13:56:26.883841
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test without CLIARGS being replaced
    global CLIARGS
    import sys
    _argv_pre_test = sys.argv[:]
    _init_global_context({'test': 'hello world'})
    result = cliargs_deferred_get('test')()
    assert result == 'hello world'
    sys.argv[:] = _argv_pre_test
    # Test with the CLIARGS being replaced
    result = cliargs_deferred_get('test')()
    assert result == 'hello world'



# Generated at 2022-06-20 13:56:35.733251
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=missing-docstring
    import copy

    # Regular usage
    class Args(object):
        def __init__(self, data):
            self.data = data

        def __contains__(self, name):
            return name in self.data

        def __getattr__(self, name):
            return self.data[name]

        def __getitem__(self, name):
            return self.data[name]

    args = Args({'foo': 'bar'})
    get_foo = cliargs_deferred_get('foo')
    assert get_foo() == 'bar'
    assert get_foo() == args.foo
    assert get_foo() == args['foo']

    # Default functionality
    args = Args({})
    get_foo = cliargs_deferred_

# Generated at 2022-06-20 13:56:47.424799
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from collections import namedtuple
    from ansible.module_utils.common.collections import is_sequence

    def test_closure(name, key, default=None, shallowcopy=False, expected_default=None, expected_type=None, expected_value=None):
        _default = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)
        try:
            actual_value = _default()
        except TypeError:
            # No cliargs were provided so we were passed a default value
            assert default is not None
            actual_value = default

        assert isinstance(actual_value, expected_type)
        if expected_default:
            assert actual_value is expected_default

# Generated at 2022-06-20 13:56:52.879978
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.validation import FieldAttribute
    from ansible.module_utils.common.validation import FieldModuleArgsValidator
    from ansible.module_utils.common.validation import FieldClassValidator

    # test dict as input
    dict_input = {'to_str': 'xyz', 'to_list': 'abc'}
    dict_expected = {'to_str': 'xyz', 'to_list': [u'abc']}
    field_class_validator = FieldClassValidator(dict_input)
    str_field_attribute = FieldAttribute(name='to_str', default=cliargs_deferred_get('to_str'), always_run=True,
                                         required=True, validator=field_class_validator)

# Generated at 2022-06-20 13:57:01.618389
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update(dict(foo='bar'))
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS.update(dict(foo=['bar', 'baz']))
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', default='qux')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']

# Generated at 2022-06-20 13:57:10.196820
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Doesn't require any code to use the function...
    def test(val):
        def inner():
            return val
        return inner

    assert cliargs_deferred_get('foo', default=None)() == None
    assert cliargs_deferred_get('foo', default=test(None))() == None
    assert cliargs_deferred_get('foo', default=test(1))() == 1
    assert cliargs_deferred_get('foo', default=test(1))() == 1

    assert cliargs_deferred_get('foo', default=test(True))() is True
    assert cliargs_deferred_get('foo', default=test(True))() is True

# Generated at 2022-06-20 13:57:20.505532
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = ['--foo=bar']
    from ansible.cli.CLI import CLI

    cli = CLI(args)
    cli.parse()
    _init_global_context(cli.options)
    # Funcs that return values
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    # Funcs that return shallow copies
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', 'baz', shallowcopy=True)() == 'bar'

# Generated at 2022-06-20 13:57:31.257128
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(test='test'))
    assert cliargs_deferred_get('test')() == 'test'
    CLIARGS = CLIArgs(dict(test='test2'))
    assert cliargs_deferred_get('test')() == 'test2'
    assert cliargs_deferred_get('test', 'test_default')() == 'test2'
    CLIARGS = CLIArgs(dict(test2=dict(test3='test3')))
    assert cliargs_deferred_get('test2')() == dict(test3='test3')
    assert cliargs_deferred_get('test2', shallowcopy=True)() == dict(test3='test3')
    assert cliargs_deferred_get('test2')() is cli

# Generated at 2022-06-20 13:57:42.627562
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Typical usage
    CLIARGS['verbosity'] = 3
    assert cliargs_deferred_get('verbosity')() == 3

    # Defaults
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    assert cliargs_deferred_get('foo')() is None

    # Copy
    CLIARGS['some_list'] = [1, 2, 3]
    assert id(CLIARGS['some_list']) != id(cliargs_deferred_get('some_list', shallowcopy=True)())
    CLIARGS['some_dict'] = {'foo': 'bar'}
    assert id(CLIARGS['some_dict']) != id(cliargs_deferred_get('some_dict', shallowcopy=True)())

# Generated at 2022-06-20 13:57:53.293168
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the right value"""
    assert isinstance(cliargs_deferred_get('foo'), type(cliargs_deferred_get))

    def test_closure():
        """Closure that has a local var is defined in a scope so that we can test that
        the closure is working correctly"""
        key = 'foo'
        value = 'bar'
        def inner():
            return value
        return inner

    _init_global_context({})
    assert cliargs_deferred_get(test_closure())() == 'bar'

    _init_global_context({'foo': 'baz'})
    assert cliargs_deferred_get('foo')() == 'baz'
    assert cliargs_deferred_get(test_closure())() == 'baz'

# Generated at 2022-06-20 13:58:08.512611
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'key': 'value'})

    value = cliargs_deferred_get('key')().copy()
    assert value == 'value'
    value = cliargs_deferred_get('key', default='default')().copy()
    assert value == 'value'
    value = cliargs_deferred_get('non_existent_key', default='default')().copy()
    assert value == 'default'
    value = cliargs_deferred_get('key', shallowcopy=True)()
    assert value == 'value'

    CLIARGS = CLIArgs({'key': ['value', 'value2']})
    value = cliargs_deferred_get('key', shallowcopy=True)()
    assert value == ['value', 'value2']

    CLIARGS

# Generated at 2022-06-20 13:58:14.346554
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that when no arguments are passed, it just gets the raw value from the CLIARGS object
    # Test that when we pass a value we get that, no matter what's in CLIARGS
    # Test that when we pass a default, we get that if the cliarg isn't set
    # Test that when we pass shallow copy, we get a shallow copy of the value
    # Test that when we pass shallow copy with a list, we get a shallow copy
    # Test that when we pass shallow copy with a dict, we get a shallow copy
    # Test that when we pass shallow copy with a set, we get a shallow copy
    # Test that the closure can run even if we change the value of CLIARGS
    raise NotImplementedError

# Generated at 2022-06-20 13:58:25.198381
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # test default value
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('test')() is None
    assert cliargs_deferred_get('test', default='default')() == 'default'
    assert cliargs_deferred_get('test', default=list)() == list
    # test shallowcopy of immutable types
    CLIARGS = CLIArgs({'test': 'value'})
    assert cliargs_deferred_get('test')() == 'value'
    assert cliargs_deferred_get('test', default='default')() == 'value'
    # test shallowcopy of sequences
    CLIARGS = CLIArgs({'test': [1, 2, 3]})

# Generated at 2022-06-20 13:58:33.408313
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''
    Tests for cliargs_deferred_get function
    '''
    import copy
    import collections

    CLIARGS._options = {'test_value': {'test_default': True}}
    assert cliargs_deferred_get('test_value', 'test_default')()

    CLIARGS._options = {'test_value': {'test_default': 'something'}}
    assert cliargs_deferred_get('test_value', 'test_default')() == 'something'

    CLIARGS._options = {'test_value': {'test_default': 'something'}}
    assert cliargs_deferred_get('test_default', 'test_default')() == 'test_default'

    CLIARGS._options = {'test_value': {'test_default': ['something']}}


# Generated at 2022-06-20 13:58:44.626564
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    from contextlib import ExitStack as does_not_raise

    # Trivial case without key set
    # Key is not set, we fall back to the default
    assert cliargs_deferred_get('key')() == None
    # Key is not set, we fall back to the specified default
    assert cliargs_deferred_get('key', default='default')() == 'default'

    # Key is set
    # The value is set, it is returned
    CLIARGS['key'] = 'value'
    assert cliargs_deferred_get('key')() == 'value'
    # The value is set, we return the specified default
    assert cliargs_deferred_get('key', default='default')() == 'value'

    # The key is unset, we

# Generated at 2022-06-20 13:58:55.454356
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar', 'baz': ['a', 'b'], 'zip': {'a': 'b'}, 'zap': frozenset([1, 2, 3])}
    _init_global_context(cli_args)

    foo = cliargs_deferred_get('foo')
    assert foo() == 'bar'
    baz = cliargs_deferred_get('baz')
    assert baz() == ['a', 'b']
    zip = cliargs_deferred_get('zip')
    assert zip() == {'a': 'b'}
    zap = cliargs_deferred_get('zap')
    assert zap() == frozenset([1, 2, 3])


# Generated at 2022-06-20 13:59:07.490265
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder

    def test_results(key, default, shallowcopy, results):
        assert results == cliargs_deferred_get(key, default, shallowcopy)()

    cli_args = {'tags': ['role', 'restart'], 'skip_tags': ['role1'], 'ANSIBLE_FORCE_COLOR': 'True'}
    _init_global_context(cli_args)
    test_results('tags', None, False, ['role', 'restart'])
    test_results('tags', None, True, ['role', 'restart'])
    test_results('skip_tags', ['default-skip-tag'], False, ['role1'])

# Generated at 2022-06-20 13:59:15.451393
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cli_args = {'foo': {'bar': True}}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo') is cli_args['foo']
    assert cliargs_deferred_get('foo')['bar'] is True
    assert cliargs_deferred_get('foo', default=dict(spam='ham'))['spam'] == 'ham'
    assert cliargs_deferred_get('foo', shallowcopy=True) is not cli_args['foo']
    assert cliargs_deferred_get('foo', shallowcopy=True) == cli_args['foo']
    assert cliargs_deferred_get('bar', default=dict(spam='ham'), shallowcopy=True)['spam'] == 'ham'

# Generated at 2022-06-20 13:59:23.252820
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get

    These are just coarse tests:  the type checking of the various value types
    are tested in test_context_objects and the shallowcopy functionality is
    tested in the test_fieldattribute.

    If the inner function is somehow broken, the tests here will catch that.
    """
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.parsing.convert_bool import boolean
    saved_stdout = CLIARGS.stdout
    saved_args = CLIARGS.args
    dummy_args = ['ansible-playbook', '--one-line']
    outer_args = ['--connection', 'openstack']
    CLIARGS.args = dummy_args
    CLIARGS.stdout = StringIO()
    # Test with a set, sequence,

# Generated at 2022-06-20 13:59:28.799690
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    def inner():
        assert cliargs_deferred_get('test', None)() == 'default'
        assert cliargs_deferred_get('test', 'default')() == 'default'
        # Ensure we have no reference to default
        default = ['not_in']
        assert cliargs_deferred_get('default', default)() == 'default'
        default[0] = 'found_me'
        assert cliargs_deferred_get('test', None)() == 'default'
        _init_global_context({'test': 'test_value'})
        # Ensure we still have no reference to default
        assert cliargs_deferred_get('default', default)() == 'default'

# Generated at 2022-06-20 13:59:36.901731
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pragma: no cover
    # test no value
    no_value_func = cliargs_deferred_get('foo')
    assert callable(no_value_func)

    # test no value with default
    no_value_default_func = cliargs_deferred_get('foo', default='default')
    assert callable(no_value_default_func)

    # test shallow copy
    shallow_copy_func = cliargs_deferred_get('foo', default=[], shallowcopy=True)
    assert callable(shallow_copy_func)

    # test shallow copy with dict
    dict_shallow_copy_func = cliargs_deferred_get('foo', default={}, shallowcopy=True)
    assert callable(dict_shallow_copy_func)

    # test shallow copy with set
   

# Generated at 2022-06-20 13:59:44.748880
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeGlobalCLIArgs(Mapping):
        def __init__(self, data):
            self._data = data

        def __getitem__(self, key):
            return self._data[key]

        def __len__(self):
            return len(self._data)

        def __iter__(self):
            return iter(self._data)

    # Make sure that it doesn't try to use the context as a function (meaning it's not bound to
    # CLIARGS)
    assert callable(cliargs_deferred_get)

    # we don't use actual options here because they have a different __eq__
    # from the objects that we have been requested to provide as defaults
    options = dict(spam='spam', eggs=['a', 'b', 'c'], foo={'a': 'A'})
   

# Generated at 2022-06-20 13:59:56.103632
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    test_cli_args = {'a': 1, 'b': 'asdf', 'c': ['q', 'w', 'e', 'r'], 'd': {'x': 1, 'y': 2}, 'e': set([1, 2, 3])}
    CLIARGS = CLIArgs(test_cli_args)
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('a', default='default')() == 1
    assert cliargs_deferred_get('A', default='default')() == 'default'
    assert cliargs_deferred_get('b')() == 'asdf'
    assert cliargs_deferred_get('b', shallowcopy=True)() is not 'asdf'
    assert cliargs_deferred

# Generated at 2022-06-20 14:00:04.342770
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MockCLIARGS(object):
        def get(self, key, default=None):
            return 'foo'
    cliargs_deferred_get(key='mytest', shallowcopy=False)()
    cliargs_deferred_get(key='mytest', shallowcopy=True)()
    cliargs_deferred_get(key='mytest', default='bar', shallowcopy=False)()
    cliargs_deferred_get(key='mytest', default='bar', shallowcopy=True)()

# Generated at 2022-06-20 14:00:13.034604
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # test that it works with CLIARGS being a global
    try:
        del CLIARGS
    except NameError:
        pass
    global CLIARGS
    CLIARGS = CLIArgs({'a': 3})
    assert CLIARGS == {'a': 3}
    assert cliargs_deferred_get('a')(), 3
    assert cliargs_deferred_get('a', shallowcopy=True)(), 3
    assert cliargs_deferred_get('b')(), None
    assert cliargs_deferred_get('b', default=5)(), 5
    assert cliargs_deferred_get('b', shallowcopy=True)(), 5

    # test that it works with CLIARGS being set
    CLIARGS = CLIArgs({'a': ('a', 'b', 'c', 'd')})

# Generated at 2022-06-20 14:00:19.454228
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from copy import deepcopy
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    def get_cliargs_dict():
        return {
            'foo': 'bar',
            'blug': 'bleg',
            'bloo': [1, 2, 3, 4],
            'blah': {'boo': 'moo', 'bla': 1, 'boo': 'derp'},
            'weak': set([1, 2, 3]),
        }


    # Test cliargs_deferred_get to make sure it returns the same value we
    # expect
    cliargs = CLIArgs(get_cliargs_dict())
    assert cliargs

# Generated at 2022-06-20 14:00:31.351828
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.data['a'] = 'b'
    assert cliargs_deferred_get('a')() == 'b'
    assert cliargs_deferred_get('b')() is None
    assert cliargs_deferred_get('b', default='c')() == 'c'
    assert cliargs_deferred_get('b', default='c', shallowcopy=True)() == 'c'
    CLIARGS.data['c'] = ['d']
    assert cliargs_deferred_get('c')() == ['d']
    c = cliargs_deferred_get('c', shallowcopy=True)()
    assert c == ['d']  # shallow copy
    c.append('e')
    # Original data unchanged
    assert CLIARGS.data['c'] == ['d']
    CLIAR

# Generated at 2022-06-20 14:00:43.385217
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    # Make sure default values work
    CLIARGS.clear()
    value = cliargs_deferred_get(key='test_value', default='default value')()
    assert value == 'default value'

    # Make sure we can get the value
    CLIARGS['test_value'] = 'value we set'
    value = cliargs_deferred_get(key='test_value')()
    assert value == 'value we set'

    # Make sure we can shallow copy the value
    CLIARGS['test_value'] = [1, 2, 3]
    value = cliargs_deferred_get(key='test_value', shallowcopy=True)()
    assert value == [1, 2, 3]
    assert value is not CLIARGS['test_value']

    # Make sure for non-sequence

# Generated at 2022-06-20 14:00:54.866764
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # unittest based off of the FieldAttribute tests
    key = "FAKE_KEY"
    fake_default = True
    fake_default2 = False

    _init_global_context({"FAKE_KEY": 1})
    assert 1 == cliargs_deferred_get(key, default=fake_default)()
    assert 1 == cliargs_deferred_get(key, default=fake_default2)()

    _init_global_context({})
    assert fake_default == cliargs_deferred_get(key, default=fake_default)()
    assert fake_default2 == cliargs_deferred_get(key, default=fake_default2)()

    _init_global_context({"FAKE_KEY": 1})

# Generated at 2022-06-20 14:01:01.569158
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Tests for cliargs_deferred_get"""
    global CLIARGS

    CLIARGS.update(dict(a=1, b=[1,2,3], c=dict(d=4)))
    # simple, no copy
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == dict(d=4)
    # with copy
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('b', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-20 14:01:20.174940
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = {'a': 'a', 'b': [1, 2], 'c': {'k': 'c'}, 'd': set([1, 2, 3])}
    _init_global_context(args)

    # Does not shallow copy
    f = cliargs_deferred_get('b')
    assert f() == [1, 2]
    f()[0] = 1234
    assert CLIARGS['b'][0] == 1234

    # Does shallow copy
    f = cliargs_deferred_get('b', shallowcopy=True)
    assert f() == [1, 2]
    f()[0] = 1234
    assert CLIARGS['b'][0] != 1234

    # Does not copy non-mutable types

# Generated at 2022-06-20 14:01:31.913533
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    def deferred_get(key, default=None):
        return cliargs_deferred_get(key, default=default)
    CLIARGS._store = {'some_key': 'some_value',
                      'another_key': ['a', 'b', 'c'],
                      'a_dictionary': {'a': 'b', 'c': 'd'},
                      'a_set': {'a', 'b'}}
    # no default
    assert deferred_get('some_key') == 'some_value'
    # default
    assert deferred_get('some_other_key', default='some_other_value') == 'some_other_value'
    # shallow copy of list

# Generated at 2022-06-20 14:01:40.174120
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Check that cliargs_deferred_get binds properly to CLIARGS"""
    import types
    _init_global_context({'foo': 'bar'})
    test_f = cliargs_deferred_get('foo')
    assert isinstance(test_f, types.FunctionType)
    hostvars = cliargs_deferred_get('hostvars', shallowcopy=True)
    assert isinstance(hostvars, types.FunctionType)
    # The function should reference CLIARGS which we've replaced
    assert test_f() == 'bar'
    assert hostvars() == {}

# Generated at 2022-06-20 14:01:50.135532
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.associate(dict(my_list=[1,2,3], my_dict={'a': 1, 'b': 2, 'c': 3}))
    # Retrieving shallowcopies of the values work
    assert cliargs_deferred_get('my_list', default=[1,2,3], shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('my_dict', default={'a': 1, 'b': 2, 'c': 3}, shallowcopy=True)() == {'a': 1, 'b': 2, 'c': 3}

    # Retrieving a deepcopy of the value works
    assert cliargs_deferred_get('my_list', default=[1,2,3])() == [1, 2, 3]
    assert cliargs_def

# Generated at 2022-06-20 14:02:00.515489
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    argv = ['ansible', '-i', 'hosts', 'playbook.yml']

# Generated at 2022-06-20 14:02:08.576863
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('bar', shallowcopy=True)() is None
    assert cliargs_deferred_get('bar', shallowcopy=True, default='baz')() == 'baz'

    CLIARGS = CLIArgs({'foo': [1,2,3]})

# Generated at 2022-06-20 14:02:18.535441
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pragma: no cover
    class Foo():  # pylint: disable=too-few-public-methods
        """
        Dummy class for test_cliargs_deferred_get

        noinspection PyUnusedLocal
        """
        cli = cliargs_deferred_get('verbosity', default=0)

    # Before the context is available
    assert Foo.cli() == 0

    # After the context is available
    from ansible.cli import CLI
    CLI.setup(['ansible-playbook', '--verbosity', '1'])
    _init_global_context(CLI.base_parser.parse_args())
    assert Foo.cli() == 1

# Generated at 2022-06-20 14:02:25.467477
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo')() is None

    cliargs_dict = dict(
        foo=dict(bar='baz', bam=dict(baz='bop')),
        bam=(1, 2, 3),
        baz={'bop': 'bam'},
    )
    _init_global_context(cliargs_dict)
    assert cliargs_deferred_get('foo')() == dict(bar='baz', bam=dict(baz='bop'))
    assert cliargs_deferred_get('bam')() == (1, 2, 3)
    assert cliargs_deferred_get('baz')() == {'bop': 'bam'}

# Generated at 2022-06-20 14:02:34.312987
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS  # pylint: disable=global-statement
    CLIARGS._data = {'arg1': 'value1'}  # pylint: disable=protected-access
    assert cliargs_deferred_get('arg1')() == 'value1'
    assert cliargs_deferred_get('arg2')() is None
    assert cliargs_deferred_get('arg2', 'value2')() == 'value2'

    # Test deepcopy
    CLIARGS._data = {'arg1': [1, 2, 3]}  # pylint: disable=protected-access
    assert cliargs_deferred_get('arg1')() == [1, 2, 3]

# Generated at 2022-06-20 14:02:41.775499
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    assert cliargs_deferred_get('default_module_name')([]) == 'command'
    assert cliargs_deferred_get('default_module_name', default='fizz')([]) == 'command'
    assert cliargs_deferred_get('default_module_name', default='fizz')({
        'default_module_name': 'buzz'
    }) == 'buzz'
    assert cliargs_deferred_get('default_module_name', shallowcopy=True)({
        'default_module_name': 'buzz'
    }) == 'buzz'

# Generated at 2022-06-20 14:03:07.010352
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'become_user': 'bob'})
    value_func = cliargs_deferred_get('become_user')
    assert value_func() == 'bob'

    _init_global_context({})
    value_func = cliargs_deferred_get('become_user', default='alice')
    assert value_func() == 'alice'

# Generated at 2022-06-20 14:03:17.500414
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function ``cliargs_deferred_get``"""
    from ansible.test.unit.test_context_objects import TestCliArgs

    obj = TestCliArgs({})

    assert cliargs_deferred_get('testget')(obj) is None
    assert cliargs_deferred_get('testget')(obj) is None
    assert cliargs_deferred_get('testget')(obj) is None
    obj.testget = 'testget'
    assert cliargs_deferred_get('testget')(obj) == 'testget'
    assert cliargs_deferred_get('testget')(obj) == 'testget'
    assert cliargs_deferred_get('testget')(obj) == 'testget'
    obj.testget = 'testget2'


# Generated at 2022-06-20 14:03:23.389847
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get"""
    global CLIARGS
    orig_cliargs = CLIARGS

    class TestCliArgs(object):
        """Test class for CLIARGS"""
        def __init__(self, data):
            self.data = data
        def get(self, key, default=None):
            return self.data[key]

    data = {'foo': 'bar'}
    testcliargs = TestCliArgs(data)
    CLIARGS = testcliargs
    cliargs_getter = cliargs_deferred_get('foo')
    assert cliargs_getter() == 'bar'
    CLIARGS = orig_cliargs

# Generated at 2022-06-20 14:03:29.924555
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cli_args = {'connection': 'local', 'host_pattern': 'all'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('connection') == 'local'
    assert cliargs_deferred_get('host_pattern') == 'all'
    assert cliargs_deferred_get('not-in-cliargs', default='default') == 'default'


# Generated at 2022-06-20 14:03:42.515279
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    # Try an empty context
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    _init_global_context({'foo': 'baz'})
    # Try a non-empty context
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'
    # Try shallowcopy
    _init_global_context({'foo': 'baz'})
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'baz'
    _init_global_context({'foo': ['baz', 'qux']})
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == ['baz', 'qux']
    # Try

# Generated at 2022-06-20 14:03:54.175072
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-20 14:04:02.392684
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': True})
    assert cliargs_deferred_get('foo')()
    # Make certain it returns the default
    assert not cliargs_deferred_get('bar')()

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    CLIARGS = CLIArgs({'foo': [1,2,3]})
    assert cliargs_deferred_get('foo')() == [1,2,3]
    # Test shallow copy
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1,2,3]

    CLIARGS = CLIArgs({'foo': {'bar': 1, 'baz': 2}})

# Generated at 2022-06-20 14:04:14.059773
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    original_cliargs = CLIARGS
    cliargs = CLIArgs(dict(DEFAULT_TEST=dict(string="", string_list=[], bool=False, bool_list=[],
                                             int=0, int_list=[], float=0.0, float_list=[]),
                           OTHER_TEST=dict(string="", string_list=[], bool=False, bool_list=[],
                                           int=0, int_list=[], float=0.0, float_list=[])))
    global CLIARGS
    CLIARGS = cliargs

    assert cliargs_deferred_get('DEFAULT_TEST')().get('bool') == False
    assert cliargs_deferred_get('DEFAULT_TEST')().get('string_list') == []


# Generated at 2022-06-20 14:04:23.619017
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Initialize the global context
    _init_global_context({})
    assert cliargs_deferred_get('ansible_check_mode')() is False
    assert cliargs_deferred_get('ansible_check_mode', default=True)() is True
    assert cliargs_deferred_get('ansible_check_mode', default=None)() is None

    # Replace context
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('ansible_check_mode')() is False
    assert cliargs_deferred_get('ansible_check_mode', default=True)() is True
    assert cliargs_deferred_get('ansible_check_mode', default=None)() is None

# Generated at 2022-06-20 14:04:34.118650
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    import copy
    import datetime

    #: TODO: Move this to a setup_class method