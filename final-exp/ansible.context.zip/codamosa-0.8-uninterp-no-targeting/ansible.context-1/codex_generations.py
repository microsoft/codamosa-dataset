

# Generated at 2022-06-20 13:54:39.506038
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test getting a value that doesn't exist
    missing_value_closures = [cliargs_deferred_get(k) for k in (1, 'one', {})]
    assert missing_value_closures[0]() is None
    assert missing_value_closures[1]() is None
    assert missing_value_closures[2]() is None

    # Test getting a value that does exist
    CLIARGS['one'] = 'uno'
    assert cliargs_deferred_get('one')() == 'uno'

    # Test getting a shallow copy
    CLIARGS['lone'] = [1, 2, 3]
    assert cliargs_deferred_get('lone', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-20 13:54:51.722763
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    start_value = dict(a={'b': 5})
    opts = dict(a=start_value)
    # test default with shallow copy
    g = cliargs_deferred_get('unknown', default=start_value, shallowcopy=True)
    assert start_value == g(), 'Default should match'
    assert start_value == opts, 'Default should not have changed'
    # test default with no shallow copy
    g = cliargs_deferred_get('unknown', default=start_value, shallowcopy=False)
    assert start_value is g(), 'Default should match'
    assert start_value == opts, 'Default should not have changed'
    # test known value with shallow copy
    g = cliargs_deferred_get('a', shallowcopy=True)

# Generated at 2022-06-20 13:55:02.944310
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    results = []
    def make_deferred_getter(value):
        def inner():
            results.append(value)
            return value
        return inner
    cli_args = {'foo': make_deferred_getter(object()),
                'bar': make_deferred_getter(42),
                'baz': make_deferred_getter(True),
                }
    global CLIARGS
    CLIARGS = CLIArgs(cli_args)

    assert cliargs_deferred_get('foo') is cliargs_deferred_get('foo')
    assert cliargs_deferred_get('bar', default=None) is cliargs_deferred_get('bar', default=None)
    assert cliargs_deferred_get('baz', default=None, shallowcopy=True) is cl

# Generated at 2022-06-20 13:55:13.038277
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=missing-docstring,invalid-name
    class TestCLIArgs(CLIArgs):
        def __init__(self, attrs):
            super(TestCLIArgs, self).__init__(attrs)

    global CLIARGS
    test_options = TestCLIArgs({'cliargs_deferred_get_test': 'test_value'})
    CLIARGS = test_options
    assert cliargs_deferred_get('cliargs_deferred_get_test') == 'test_value'
    assert cliargs_deferred_get('x', 'y') == 'y'
    assert cliargs_deferred_get('cliargs_deferred_get_test', shallowcopy=True) == 'test_value'

# Generated at 2022-06-20 13:55:24.880660
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    global CLIARGS
    # This is the dummy object that comes in at the beginning of the program
    cliargs = CLIARGS

    # Make sure the fake cliargs are returned when the real cliargs aren't set
    deferred = cliargs_deferred_get('foobar', 'baz')
    assert deferred() == 'baz'

    # Now set the real cliargs
    from ansible.cli import CLI
    import sys
    options, args = CLI.parser.parse_args(args=['--version'])
    CLI.setup_logging(options)
    cli_args = CLI.parse(args)
    _init_global_context(cli_args)

    # Check that the real cliargs are returned
    deferred = cliargs_deferred_get('foo')
    deferred = cl

# Generated at 2022-06-20 13:55:33.628454
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test without default and without shallow copy
    _init_global_context({'connection': 'mock', 'host_key_checking': False,
                          'private_key_file': '~/.ssh/id_rsa', 'become': True})
    cliargs_deferred_get_not_set = cliargs_deferred_get('test_value')
    assert list(CLIARGS['become_methods']) == list(cliargs_deferred_get_not_set())

    # Test with default and with shallow copy
    cliargs_deferred_get_not_set = cliargs_deferred_get('test_value', default='test_default',
                                                        shallowcopy=True)
    assert cliargs_deferred_get_not_set() == 'test_default'

    # Test

# Generated at 2022-06-20 13:55:44.120788
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = dict()

    # Simple get test with no default
    cli_args['test_key'] = 'test_value'
    _init_global_context(cli_args)
    assert cliargs_deferred_get('test_key')() == 'test_value'

    # Default value test
    cli_args['test_key'] = 'test_value'
    _init_global_context(cli_args)
    assert cliargs_deferred_get('test_key2', default='default')() == 'default'

    # Shallow copy test
    cli_args['test_key'] = 'test_value'
    _init_global_context(cli_args)
    test_mapping = {}
    assert cliargs_deferred_get('test_key', shallowcopy=True)()

# Generated at 2022-06-20 13:55:48.574298
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    base = {
        'foo': 'foo_val',
        'bar': [1, 2, 3],
    }
    _init_global_context(base)
    assert cliargs_deferred_get('foo')(), base['foo']



# Generated at 2022-06-20 13:55:57.308732
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # First test that it works with the CLIARGS being replaced
    global CLIARGS

    orig_cliargs = CLIARGS
    test_cliargs = CLIArgs({'a': 1})

    fn = cliargs_deferred_get('a', default=2)
    assert fn() == 2

    CLIARGS = test_cliargs
    assert fn() == 1

    CLIARGS = orig_cliargs
    assert fn() == 1

    # Now test the shallowcopy functionality
    fn_dict = cliargs_deferred_get('shallow', default={'a': 1}, shallowcopy=True)
    fn_list = cliargs_deferred_get('shallow', default=[1], shallowcopy=True)
    fn_str = cliargs_deferred_get('shallow', default='1', shallowcopy=True)


# Generated at 2022-06-20 13:56:08.746966
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from unittest import TestCase

    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Note: setcliargs is so that we can test that this function is bound to
    # ``CLIARGS``
    def setcliargs(value):
        global CLIARGS
        CLIARGS = value

    class CliArgsUnitTest(TestCase):
        def setUp(self):
            setcliargs({})

        def test_default(self):
            get = cliargs_deferred_get('missing-key')
            self.assertIsNone(get(), msg='default value should be None')

        def test_default_not_none(self):
            get = cliargs_deferred_get('missing-key', default=1)

# Generated at 2022-06-20 13:56:25.106230
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    new_args = {"test": True, "foo": "test", "bar": "test2", "baz": ['test1', 'test2', 'test3'], "wibble": {"wobble": True}}
    CLIARGS = CLIArgs(new_args)
    assert cliargs_deferred_get("test")() is True
    assert cliargs_deferred_get("foo")() == "test"
    assert cliargs_deferred_get("bar")() == "test2"
    assert cliargs_deferred_get("baz")() == ['test1', 'test2', 'test3']
    assert cliargs_deferred_get("wibble")() == {"wobble": True}
    assert cliargs_deferred_get("baz", shallowcopy=True)

# Generated at 2022-06-20 13:56:34.793156
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

# Generated at 2022-06-20 13:56:47.020135
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS  # pylint: disable=global-statement

    example_cliargs = {'a': [1, 2], 'b': {'c': set([1, 2])}, 'd': 'foo'}
    cliargs_deferred = cliargs_deferred_get('a')
    CLIARGS = CLIArgs(example_cliargs)  # pylint: disable=global-statement
    assert cliargs_deferred() == example_cliargs['a']

    cliargs_deferred_shallow = cliargs_deferred_get('a', shallowcopy=True)
    assert cliargs_deferred_shallow() is not example_cliargs['a']
    assert cliargs_deferred_shallow() == example_cliargs['a']

    cliargs_deferred_same = cl

# Generated at 2022-06-20 13:56:52.880071
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that the closure returned by cliargs_deferred_get works properly"""
    # pylint: disable=protected-access
    gca = GlobalCLIArgs({'foo': 'bar', 'baz': ['blah']})
    gca._values['foo'] = 'bar'
    gca._values['baz'] = ['blah']
    # pylint: enable=protected-access
    cli_args = CLIArgs({})
    # Just checking that the function works
    return cliargs_deferred_get('foo')(), cliargs_deferred_get('baz', shallowcopy=True)()


try:
    from __main__ import display
except ImportError:
    from ansible.utils.display import Display

    display = Display()



# Generated at 2022-06-20 13:57:01.618504
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Test that we get the default value
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo')() == None

    # Test that we get the actual value
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that we get the shallow copy of a value
    CLIARGS = CLIArgs({'foo': {'bar': 'bash'}})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'bar': 'bash'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() != CLIARGS["foo"]

    # Test that we get the shallow copy of a value

# Generated at 2022-06-20 13:57:10.829887
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get"""
    import pytest
    from ansible.module_utils.six import PY2, PY3

    global CLIARGS
    CLIARGS = CLIArgs({})

    assert CLIARGS.get('unset') is None
    assert cliargs_deferred_get('unset')() is None
    assert cliargs_deferred_get('unset', shallowcopy=True)() is None

    if PY2:  # pragma: no cover
        CLIARGS = CLIArgs({'unset': unicode('unset')})
        assert CLIARGS.get('unset') == 'unset'
        assert isinstance(CLIARGS.get('unset'), unicode)

# Generated at 2022-06-20 13:57:20.746370
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(Foo='bar'))
    f = cliargs_deferred_get('Foo')
    assert f() == 'bar'
    f = cliargs_deferred_get('Foo', default='other')
    assert f() == 'bar'
    f = cliargs_deferred_get('Foo', default='other', shallowcopy=True)
    assert f() == 'bar'
    f = cliargs_deferred_get('Bar', default='other', shallowcopy=True)
    assert f() == 'other'
    # Test shallowcopying a list
    _init_global_context(dict(Foo=['bar', 'baz']))
    f = cliargs_deferred_get('Foo', default=[])

# Generated at 2022-06-20 13:57:26.034617
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import is_sequence

    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('foo', default='blah') == 'bar'

    CLIARGS['foo'] = ['bar1', 'bar2']
    assert cliargs_deferred_get('foo') == ['bar1', 'bar2']
    assert cliargs_deferred_get('foo', default=[]) == ['bar1', 'bar2']
    assert cliargs_deferred_get('foo', default=None) == ['bar1', 'bar2']

# Generated at 2022-06-20 13:57:32.337259
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_map = {'key': 'value'}

    # Test default value
    assert(cliargs_deferred_get('foo', default='bar')() == 'bar')

    # Test shallow copy of existing
    global CLIARGS
    CLIARGS = CLIArgs(test_map)
    assert(cliargs_deferred_get('key', shallowcopy=True)() == test_map)
    assert(cliargs_deferred_get('key', shallowcopy=True)() is not test_map)

# Generated at 2022-06-20 13:57:43.273055
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that deferred_get returns the right value"""
    # pylint: disable=protected-access
    CLIARGS._options = dict(foo='bar')
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='morebar')() == 'bar'
    assert cliargs_deferred_get('baz', default='morebar')() == 'morebar'

    foo_default = cliargs_deferred_get('foo', default='bar', shallowcopy=True)
    # Initial value gets shallow copied
    assert foo_default() is not CLIARGS._options['foo']
    assert foo_default() == 'bar'

    foo_list_default = cliargs_deferred_get('foo', default=['bar'], shallowcopy=True)

# Generated at 2022-06-20 13:57:58.487300
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'become_user': 'root'})
    assert cliargs_deferred_get('become_user')() == 'root'
    assert cliargs_deferred_get('become_user', default='toshio')() == 'root'
    assert cliargs_deferred_get('become_user', shallowcopy=True)() == 'root'
    _init_global_context({'become_user': 'toshio'})
    assert cliargs_deferred_get('become_user')() == 'toshio'
    assert cliargs_deferred_get('become_user', default='toshio')() == 'toshio'
    _init_global_context({'inventory': ['localhost', '127.0.0.1']})
    assert cl

# Generated at 2022-06-20 13:58:08.973581
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Test cliargs_deferred_get with GlobalCLIArgs.from_options and with CLIArgs
    """

    cli_args = {'key1': 'value1', 'key2': ['value2,1', 'value2,2'], 'key3': {'dict': 'value'}}
    _init_global_context(cli_args)

    assert cliargs_deferred_get('key1')() == 'value1'
    assert cliargs_deferred_get('key2')() == ['value2,1', 'value2,2']
    assert cliargs_deferred_get('key3')() == {'dict': 'value'}
    assert cliargs_deferred_get('key_undefined')() is None

# Generated at 2022-06-20 13:58:20.529552
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable,protected-access
    def _simple_init(value, shallowcopy):
        def inner():
            return value
        CLIARGS._get = inner
        inner._shallowcopy = shallowcopy

    def _sequence_init(seq, shallowcopy):
        def inner():
            return seq
        CLIARGS._get = inner
        inner._shallowcopy = shallowcopy

    def _mapping_init(mapping, shallowcopy):
        def inner():
            return mapping
        CLIARGS._get = inner
        inner._shallowcopy = shallowcopy

    def _set_init(set_, shallowcopy):
        def inner():
            return set_
        CLIARGS._get = inner
        inner._shallowcopy = shallowcopy


# Generated at 2022-06-20 13:58:30.650059
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # use a dict so we can mutate it
    test_default = {'test_key': 'test'}
    CLIARGS = CLIArgs({})
    inner = cliargs_deferred_get('test_key', test_default)
    assert inner() == test_default
    CLIARGS = CLIArgs({'test_key': 'override'})
    assert inner() == 'override'
    CLIARGS = CLIArgs({'test_key': ['override']})
    override_shallow = inner(shallowcopy=True)
    assert override_shallow == ['override']
    override_shallow.append('overriden!')
    assert CLIARGS['test_key'] == override_shallow
    override = inner()
    assert override == ['override', 'overriden!']

# Generated at 2022-06-20 13:58:41.645691
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Standard use case
    cli_args = {'vault_password_file': 'pwfile'}
    _init_global_context(cli_args)
    assert CLIARGS['vault_password_file'] == cliargs_deferred_get('vault_password_file')()

    # Test default use case
    cli_args = {}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('vault_password_file')() is None

    # Test shallow copy is disabled by default
    cli_args = {}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('vault_password_file')() is None

    # Test default use case

# Generated at 2022-06-20 13:58:51.446240
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.compat.tests import mock
    from ansible.utils.context_objects import GlobalCLIArgs
    cli_args = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert 'bar' == cliargs_deferred_get('foo')()
    cliargs_deferred_get.__globals__['CLIARGS'] = cli_args
    assert 'bar' == cliargs_deferred_get('foo')()
    with mock.patch.object(GlobalCLIArgs, 'from_options', return_value=cli_args, autospec=True):
        assert 'bar' == cliargs_deferred_get('foo')()

# Generated at 2022-06-20 13:58:55.633099
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = CLIArgs({'connection': 'local'})
    assert 'connection' in cli_args

    deferfunc = cliargs_deferred_get('connection')
    assert deferfunc() == 'local'

    cli_args.update({'connection': 'ssh'})
    assert deferfunc() == 'ssh'

# Generated at 2022-06-20 13:59:05.847763
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """shallowcopy=False doesn't do anything"""
    global CLIARGS
    CLIARGS = CLIArgs({'key': 'value'})
    assert cliargs_deferred_get('key')() is 'value'

    #NOTE: it was not clear from the documentation if this was going to be a copy or not
    CLIARGS = CLIArgs({'key': ['value1', 'value2']})
    assert cliargs_deferred_get('key')() is ['value1', 'value2']

    CLIARGS = CLIArgs({'key': {'key': 'value'}})
    assert cliargs_deferred_get('key')() is {'key': 'value'}



# Generated at 2022-06-20 13:59:13.781311
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.text.converters import to_unicode
    _init_global_context(dict(TEST_OUTER=dict(TEST_INNER='TEST_VALUE')))

    # Test string
    cliargs_get = cliargs_deferred_get('TEST_OUTER.TEST_INNER')
    assert cliargs_get() == 'TEST_VALUE'

    # Test unicode (Python 2)
    cliargs_get = cliargs_deferred_get('TEST_OUTER.TEST_INNER')
    assert cliargs_get() == to_unicode('TEST_VALUE')

    # Test list
    cliargs_get = cliargs_deferred_get('TEST_OUTER.TEST_INNER')
    assert cl

# Generated at 2022-06-20 13:59:22.449178
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.collections import is_sequence

    # fill cli_args with some dummy data

# Generated at 2022-06-20 13:59:41.804074
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'verbosity': 5})
    assert cliargs_deferred_get('foo', 'default')() == 'bar'
    assert cliargs_deferred_get('verbosity', 0)() == 5
    assert cliargs_deferred_get('baz', 'default')() == 'default'
    assert cliargs_deferred_get('verbosity', shallowcopy=True)() == 5
    v = cliargs_deferred_get('verbosity', shallowcopy=False)()
    assert isinstance(v, int)
    assert v == 5


# Generated at 2022-06-20 13:59:52.924163
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    def test_function():
        from copy import copy
        from ansible.module_utils.common.collections import is_sequence

        inner = cliargs_deferred_get('test')
        assert inner() is None

        inner = cliargs_deferred_get('test', default=1)
        assert inner() == 1

        CLIARGS['test'] = 2
        inner = cliargs_deferred_get('test')
        assert inner() == 2

        CLIARGS['test'] = [1,2,3]
        inner = cliargs_deferred_get('test', shallowcopy=True)
        original = CLIARGS['test']

# Generated at 2022-06-20 14:00:04.201753
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Need to import this here to prevent circular import
    from ansible.plugins.loader import get_all_plugin_loaders

    val = cliargs_deferred_get('plugins')
    # We know that this will create an instance of GlobalCLIArgs
    _init_global_context(get_all_plugin_loaders())
    assert val() == CLIARGS.get('plugins')

    class A:
        pass
    data = A()
    data.c = 'value'
    _init_global_context({'test': data})
    val = cliargs_deferred_get('test')
    assert data == val()

    val = cliargs_deferred_get('test', shallowcopy=True)
    assert val() is not data

# Generated at 2022-06-20 14:00:12.450340
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.clear()
    CLIARGS.update(dict(one=1, two=2, three=3, list=[1, 2, 3]))

    # Test no copy needed
    assert cliargs_deferred_get('one')() == 1
    assert cliargs_deferred_get('one', shallowcopy=True)() == 1
    assert cliargs_deferred_get('one', default=100)() == 1
    assert cliargs_deferred_get('one', default=100, shallowcopy=True)() == 1

    # Test no key returns default
    assert cliargs_deferred_get('blah', default=100)() == 100
    assert cliargs_deferred_get('blah', default=100, shallowcopy=True)() == 100

    # Test copy needed
    assert cli

# Generated at 2022-06-20 14:00:20.172349
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test to make sure that cliargs_deferred_get returns the correct data in all cases"""
    # Initialize the global context
    _init_global_context({'foo': 'bar'})
    # Make sure the function works for simple values
    assert cliargs_deferred_get('foo')() == 'bar'
    # Make sure the function works for getting a default
    assert cliargs_deferred_get('non_existent', default=123)() == 123
    # Make sure that the copy works for lists
    CLIARGS['list'] = [1, 2, 3]
    assert cliargs_deferred_get('list', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('list', shallowcopy=True)() is not CLIARGS['list']
    #

# Generated at 2022-06-20 14:00:32.061796
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.context_objects import CLIArgs
    from copy import copy, deepcopy

    assert cliargs_deferred_get('foo')() is None
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    list_ = [1, 2, 3]
    dict_ = {'foo': 'bar'}
    set_ = set(['foo'])
    global CLIARGS
    CLIARGS = CLIArgs({'foo': list_, 'bar': dict_, 'baz': set_})
    assert cliargs_deferred_get('foo')() is list_


# Generated at 2022-06-20 14:00:43.717051
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update(dict(foo='bar', bar=['baz', 'qux'], baz={'quux': 'quuz'}, option_with_list_as_default=[]))
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=False)() == 'bar'
    assert cliargs_deferred_get('bar', shallowcopy=True)() == ['baz', 'qux']
    assert cliargs_deferred_get('bar', shallowcopy=False)() == ['baz', 'qux']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == {'quux': 'quuz'}

# Generated at 2022-06-20 14:00:55.237041
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that deferred get works with setting the value locally"""
    from ansible.module_utils.common.collections import MutableSequence

    # Clear the global context
    import ansible.context
    ansible.context.CLIARGS = ansible.context.CLIArgs({})

    assert not cliargs_deferred_get('fake', default=None)()
    assert cliargs_deferred_get('fake', default=1)() == 1

    class FakeList(MutableSequence):
        def __len__(self):
            return 0
        def __getitem__(self, i):
            raise IndexError()
        def __setitem__(self, i, v):
            pass
        def __delitem__(self, i):
            pass
        def insert(self, i, v):
            pass

   

# Generated at 2022-06-20 14:01:06.329566
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(foo='bar'))
    assert cliargs_deferred_get('foo')(), 'bar'
    assert cliargs_deferred_get('foo', 'baz')(), 'bar'
    assert cliargs_deferred_get('foo', 'baz', shallowcopy=True)(), 'bar'
    assert cliargs_deferred_get('biz', 'baz')(), 'baz'
    assert cliargs_deferred_get('biz', 'baz', shallowcopy=True)(), 'baz'
    assert cliargs_deferred_get('biz')(), None
    assert cliargs_deferred_get('biz', shallowcopy=True)(), None

# Generated at 2022-06-20 14:01:16.576943
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Tests that get the default work
    cli_args = {"a": "b", "c": "d", "verbosity": 8}
    _init_global_context(cli_args)
    assert cliargs_deferred_get("a") == "b"
    assert cliargs_deferred_get("c") == "d"
    assert cliargs_deferred_get("verbosity") == 8
    assert cliargs_deferred_get("something", default="nothing") == "nothing"
    # Tests that get the default with shallow copy work
    x = [1,2,3]
    assert cliargs_deferred_get("something", default=x, shallowcopy=True) == x
    assert cliargs_deferred_get("something", default=x, shallowcopy=True) is not x
    assert cl

# Generated at 2022-06-20 14:01:52.769526
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({'foo_key': 'foo value'})
    cliargs_get = cliargs_deferred_get('foo_key', 'default value')
    assert cliargs_get() == 'foo value'
    cliargs_get = cliargs_deferred_get('bar_key', 'default value')
    assert cliargs_get() == 'default value'

    CLIARGS = GlobalCLIArgs.from_options({'foo_key': 'foo value', 'loglevel': 6})
    cliargs_get = cliargs_deferred_get('foo_key', 'default value')
    assert cliargs_get() == 'foo value'

# Generated at 2022-06-20 14:02:03.296992
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # these tests need to be run in a different process to avoid updating
    # the global CLIARGS
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils import context_objects
    import pytest
    import subprocess
    import random
    import string
    from ansible.utils.context_objects import GlobalCLIArgs
    # global CLIARGS is not always available
    try:
        context_objects.CLIARGS
    except AttributeError:
        # but it's not needed here
        pass
    else:
        context_objects.CLIARGS = CLIArgs({})

    def generate_random_string(length=16):
        return ''.join(random.choice(string.ascii_letters) for _ in range(length))


# Generated at 2022-06-20 14:02:09.824816
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    from types import ModuleType
    args = {'blah': 'foo', 'thing': ['a', 'b', 'c'], 'mapping': {'a': 1, 'b': 2, 'c': 3}, 'set': {1, 2, 3}}
    cliargs = CLIArgs(args)
    module = ModuleType("test_module")
    module.test_cliargs = cliargs
    module.test_get = cliargs_deferred_get
    assert module.test_get('blah') == 'foo'
    assert module.test_get('thing') == ['a', 'b', 'c']
    assert module.test_get('mapping') == {'a': 1, 'b': 2, 'c': 3}
    assert module.test_get

# Generated at 2022-06-20 14:02:20.550532
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get

    :returns: ``bool`` -- True if unit test passes
    """
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common._collections_compat import Set

    class TestCliArgs(object):
        """Mock of ``CLIARGS``"""
        def __init__(self, data):
            self.__data = data

        def get(self, key, default=None):
            return self.__data.get(key, default)

    global CLIARGS

    # Test default value
    context = CLIARGS

    CLIARGS = TestCliArgs({})
    assert cliargs_deferred_get('data')() is None

# Generated at 2022-06-20 14:02:26.581613
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible_collections.ansible.misc.tests.unit.test_context.test_mock_cli_args import mock_cli_args

    args = mock_cli_args()
    _init_global_context(args)
    assert cliargs_deferred_get('become')() is True
    assert cliargs_deferred_get('become')() is True
    assert cliargs_deferred_get('become')() is True
    assert cliargs_deferred_get('become', default=False)() is True

    assert cliargs_deferred_get('roles_path', default=[])() == ['path/one', 'path/two']
    assert cliargs_deferred_get('roles_path', default=[])() == ['path/one', 'path/two']

# Generated at 2022-06-20 14:02:35.906861
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # Test that we get the default back if the key is not found
    test_default = 42
    assert test_default == cliargs_deferred_get('does-not-exist', default=test_default)()

    # Test that we get the default back if the key is None
    test_default = 'hello'
    assert test_default == cliargs_deferred_get('does-not-exist', default=test_default)()

    # Test we get the value back if we have it
    key = 'has-a-value'
    test_val = 42
    CLIARGS[key] = test_val
    assert test_val == cliargs_deferred_get(key)()

    # Test we get the value back if we have it and the default is None

# Generated at 2022-06-20 14:02:45.035246
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    # Due to the decorator, the function is undefined when this test
    # starts.
    global CLIARGS
    # This is a slightly modified version of GlobalCLIArgs that has
    # a get() method that returns a new value each time it is called
    class DeferredCliArgs:
        def __init__(self, cliargs):
            self.cliargs = cliargs

        def get(self, key, default=None):
            return self.cliargs.get(key, default=default)

        def __getattr__(self, key):
            return cliargs_deferred_get(key, default=None, shallowcopy=False)

    dummy_cliargs = DeferredCliArgs({"foo": "bar"})
    CLIARGS = dummy_cli

# Generated at 2022-06-20 14:02:54.942750
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Need to ensure that CLIARGS is a GlobalCLIArgs object
    CLIARGS = GlobalCLIArgs.from_options({})

    def __init_context__(context_dict):
        _init_global_context(context_dict)

    # No arguments given
    CLIARGS.clear()
    assert cliargs_deferred_get('key')(), None
    assert cliargs_deferred_get('key', default='default')(), 'default'

    # Arguments
    __init_context__({'key': 'value'})
    assert cliargs_deferred_get('key')(), 'value'

    # Shallowcopy

# Generated at 2022-06-20 14:03:06.738139
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Need to have a safe value here to test the function.
    # CLIARGS is a singleton so we can't set it once the
    #  Context is initialized
    _init_global_context({})
    assert CLIARGS.get('no_such_key') is None
    assert cliargs_deferred_get('no_such_key')() is None
    assert cliargs_deferred_get('no_such_key', default=True)() is True
    assert cliargs_deferred_get('no_such_key', default=True)() is True
    CLIARGS.update({'key': 1})
    assert cliargs_deferred_get('key')(), 1
    assert cliargs_deferred_get('key', shallowcopy=True)() != 1

# Generated at 2022-06-20 14:03:17.212712
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    import os
    import tempfile
    import sys


# Generated at 2022-06-20 14:04:15.994971
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo')() is None

    _init_global_context(dict(foo=42))
    assert cliargs_deferred_get('foo')() == 42

    _init_global_context(dict())
    assert cliargs_deferred_get('foo', 42)() == 42

    assert cliargs_deferred_get('foo', 42, shallowcopy=True)() == 42
    assert cliargs_deferred_get('foo', [1, 2, 3], shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo', {'bla': 42}, shallowcopy=True)() == {'bla': 42}

# Generated at 2022-06-20 14:04:25.776575
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    result = cliargs_deferred_get('testkey')
    assert result() is None
    CLIARGS['testkey'] = 'value'
    result = cliargs_deferred_get('testkey')
    assert result() == 'value'
    result = cliargs_deferred_get('testkey', default='defaultvalue')
    assert result() == 'value'
    assert cliargs_deferred_get('differentkey', default='defaultvalue')() == 'defaultvalue'
    CLIARGS['testseq'] = [1, 2, 3]
    result = cliargs_deferred_get('testseq')
    assert result() == [1, 2, 3]
    result = cliargs_deferred_get('testseq', shallowcopy=True)
    assert result() == [1, 2, 3]

# Generated at 2022-06-20 14:04:34.835233
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    args = {'list': [1, 2, 3],
            'dict': {'a': 'Alpha', 'b': 'Bravo'},
            'set': {'one', 'two', 'three'},
            'int': 0,
            'string': 'foo'}
    CLIARGS = CLIArgs(args)
    assert cliargs_deferred_get('list') is args['list']
    assert cliargs_deferred_get('list', shallowcopy=True) == args['list']
    assert cliargs_deferred_get('dict') is args['dict']
    assert cliargs_deferred_get('dict', shallowcopy=True) == args['dict']
    assert cliargs_deferred_get('set') == args['set']
    assert cliargs_deferred_