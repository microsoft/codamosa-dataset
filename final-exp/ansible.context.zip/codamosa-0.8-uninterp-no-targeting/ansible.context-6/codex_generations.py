

# Generated at 2022-06-20 13:54:30.379800
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is a placeholder to make sure that the function above works properly
    # in a future where we have tests implemented
    assert True

# Generated at 2022-06-20 13:54:39.008424
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.clear()
    CLIARGS['key'] = 'value'
    CLIARGS['list'] = [1, 2, 3]
    CLIARGS['dict'] = {'a': 1, 'b': 2}
    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('key', default='default')() == 'value'
    assert cliargs_deferred_get('key2', default='default')() == 'default'
    assert cliargs_deferred_get('list')() == [1, 2, 3]
    assert cliargs_deferred_get('list', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('list')() is not CLIARGS['list']
    assert cl

# Generated at 2022-06-20 13:54:47.234567
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=too-few-public-methods,no-init
    class Init:
        init_called = False
        def __init__(self):
            Init.init_called = True

    class Dummy:
        arg = None
        def __init__(self):
            self.arg = cliargs_deferred_get('arg', default=Init())

    empty_init = Dummy()
    assert not empty_init.arg.init_called
    _init_global_context(dict(arg='testing'))
    assert empty_init.arg() == 'testing'

    empty_init = Dummy()
    assert not empty_init.arg.init_called
    _init_global_context(dict())
    assert empty_init.arg.init_called
    assert empty_init.arg() is None

# Generated at 2022-06-20 13:54:56.531190
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for function cliargs_deferred_get"""
    import pytest

    class TestCliArgs(Mapping):
        """Special class for testing"""
        TEST_VALUE = 'Test Value'

        def __init__(self):
            self._keys = ['test_key']

        def __getitem__(self, key):
            return self.TEST_VALUE

        def __iter__(self):
            yield from self._keys

        def __len__(self):
            return len(self._keys)

    with pytest.raises(NameError):
        cliargs_deferred_get('test_key')()

    with pytest.raises(NameError):
        cliargs_deferred_get('test_key', default='test_value')()

# Generated at 2022-06-20 13:55:02.442669
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import mock
    get_mock = mock.Mock()
    CLIARGS = mock.Mock()
    CLIARGS.get = get_mock
    cliargs_deferred_get_bound = cliargs_deferred_get('foo')
    cliargs_deferred_get_bound.__closure__
    cliargs_deferred_get_bound()
    get_mock.assert_called_with('foo', default=None)

# Generated at 2022-06-20 13:55:09.629310
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Test lambda/defaults/lambda when there's no cli_args
    assert cliargs_deferred_get('random_key')(0) == 0
    assert cliargs_deferred_get('random_key', default=1)(0) == 1
    assert cliargs_deferred_get('random_key', default=lambda: 0)(0) == 0
    assert cliargs_deferred_get('random_key', default=lambda: 1)(0) == 1
    assert cliargs_deferred_get('random_key', default=1, shallowcopy=True)(0) == 1

    # Test lambda/defaults/lambda when there are cli_args

# Generated at 2022-06-20 13:55:21.244659
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for cliargs_deferred_get"""
    def cliargs_get(key, default=None):
        """Get a key from CLIARGS.  This is a wrapper that mostly works
        because tests can use it to set the value of CLIARGS"""
        return CLIARGS.get(key, default=default)

    # Note: we aren't testing the actual shallowcopy mechanism.  That's tested in
    # the get() method of the CLIArgs classes in test_context_objects.py

    # non-existing key
    assert cliargs_deferred_get('no_such_key')() == None
    # existing key
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # non-existing key
    assert cliargs_deferred

# Generated at 2022-06-20 13:55:31.561327
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_eval(function, result):
        assert function() == result

    _init_global_context({'module_path': '/tmp/foo', 'foo_bar': {'nested': True}})
    test_eval(cliargs_deferred_get('module_path', default='not used'), '/tmp/foo')
    test_eval(cliargs_deferred_get('module_path', default='used', shallowcopy=True), '/tmp/foo')
    test_eval(cliargs_deferred_get('module_path', default='used', shallowcopy=False), '/tmp/foo')
    test_eval(cliargs_deferred_get('module_path', shallowcopy=True), '/tmp/foo')
    test_eval(cliargs_deferred_get('module_path', shallowcopy=False), '/tmp/foo')
   

# Generated at 2022-06-20 13:55:42.443945
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for ``cliargs_deferred_get``"""
    from .test_common import mock
    from ansible.utils.context_objects import CLIArgs

    cliargs = CLIArgs({})

    # Test with no key
    cliargs.set('test1', ['one', 'two'])
    test_not_present = cliargs_deferred_get('not_present')
    assert test_not_present() == None


    # Test with key
    test_present = cliargs_deferred_get('test1')
    assert test_present() == cliargs.get('test1')


    # Test with key and default
    test_present_with_default = cliargs_deferred_get('test1', default='default')

# Generated at 2022-06-20 13:55:54.383550
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSet
    from copy import copy

    test_dict = {'key': 'value'}
    test_set = {'I', 'am', 'a', 'set'}
    test_list = ['I', 'am', 'a', 'list']
    test_copy_dict = copy(test_dict)
    test_copy_dict['key'] = 'new'
    test_copy_set = test_set.copy()
    test_copy_set.add('new')
    test_copy_list = test_list[:]
    test_copy_list[0] = 'new'

    global CLIARGS

# Generated at 2022-06-20 13:56:02.514777
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''
    CLIARGS.get() should return the same thing that cliargs_deferred_get() does
    '''
    _init_global_context({'foo': 'bar'})
    actual = cliargs_deferred_get('foo')()
    expected = CLIARGS.get('foo')
    assert actual == expected


# Generated at 2022-06-20 13:56:11.187447
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert cliargs_deferred_get('random_thing')() == None
    assert cliargs_deferred_get('random_thing', 'foo')() == 'foo'
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS._options.update({'foo': 'baz'})
    assert cliargs_deferred_get('foo')() == 'baz'
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS.pop('foo')
    assert cliargs_deferred_get('foo')() == None

# Generated at 2022-06-20 13:56:22.328784
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_opts = CLIArgs({})
    getter = cliargs_deferred_get('test')
    assert getter() is None
    cli_opts['test'] = 'test'
    assert getter() == 'test'
    cli_opts['test'] = 'test2'
    assert getter() == 'test2'
    cli_opts['test'] = ['test3']
    assert getter() == ['test3']
    cli_opts['test'] = {'foo': 'bar'}
    assert getter() == {'foo': 'bar'}
    cli_opts['test'] = set('abcd')
    assert getter() == set('abcd')
    cli_opts['test'] = ['test3']

# Generated at 2022-06-20 13:56:33.265509
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs(dict(foo=1, bar=[1, 2, 3], baz={'x': 'y'}))
    assert cliargs_deferred_get('foo')() == 1
    assert cliargs_deferred_get('bar')() == [1, 2, 3]
    assert cliargs_deferred_get('baz')() == {'x': 'y'}

    assert cliargs_deferred_get('foo', shallowcopy=True)() == 1
    assert cliargs_deferred_get('bar', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-20 13:56:44.623924
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    import inspect
    from ansible.utils.context_objects import CLIArgs
    cli_args = CLIArgs({})
    assert inspect.isgeneratorfunction(cliargs_deferred_get('foo', default='bar'))
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    cli_args['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    cli_args['foo'] = ['foo', 'bar', 'baz']
    cli_args['foo2'] = 'baz'
    cli_args['foo3'] = {'foo': 'baz'}

# Generated at 2022-06-20 13:56:55.703606
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.errors import AnsibleError
    from ansible.utils.context_objects import CLIContextWrapper

    def _get_value(key, default=None, shallowcopy=False):
        return cliargs_deferred_get(key, default, shallowcopy)()

    # test default
    assert _get_value('not in global_args') is None
    assert _get_value('not in global_args', 1) is 1
    with CLIContextWrapper({'not in global_args': 1}):
        assert _get_value('not in global_args', shallowcopy=True) is 1

    # test shallow copy
    assert _get_value('not in global_args', shallowcopy=True) is None

# Generated at 2022-06-20 13:57:03.091607
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Base function
    assert 'test' == cliargs_deferred_get('test', default='test')()

    # No default, default default
    assert None == cliargs_deferred_get('not_here')()

    # Overriding default
    assert 'override' == cliargs_deferred_get('not_here', default='override')()

    # With a value
    CLIARGS = CLIArgs({'test': 'value'})
    assert 'value' == cliargs_deferred_get('test')()

    # With a list
    CLIARGS = CLIArgs({'test': ['one', 'two']})
    assert ['one', 'two'] == cliargs_deferred_get('test')()
    assert ['one', 'two'] == cliargs_deferred_

# Generated at 2022-06-20 13:57:11.343528
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Unit tests for the ``cliargs_deferred_get`` function.

    The function itself is a closure, so we need to create a new one
    for each test.
    """
    global CLIARGS
    VERSION = ['1','2','3','unicorn','rainbow']
    test_case = cliargs_deferred_get('version')
    CLIARGS = CLIArgs({'version': VERSION})
    cliargs_version = test_case()
    assert cliargs_version == VERSION

    CLIARGS = CLIArgs({'version': VERSION})
    cliargs_version = test_case()
    assert cliargs_version == VERSION
    cliargs_version_shallow = test_case(shallowcopy=True)
    assert cliargs_version_shallow == VERSION

   

# Generated at 2022-06-20 13:57:14.376762
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _test(**kwargs):
        cliargs_deferred_get('frobnitz')(**kwargs)
    _test()

# Generated at 2022-06-20 13:57:22.950724
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    original_value = [1, 2, 3]
    assert cliargs_deferred_get('foo')() is None

    CLIARGS = CLIArgs({'foo': original_value, 'bar': 5})
    assert cliargs_deferred_get('foo')() is original_value
    assert cliargs_deferred_get('foo', shallowcopy=True)() == original_value

    CLIARGS = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'baz'

    CLIARGS = CLIArgs({'foo': [], 'bar': 5})
    assert cliargs_deferred_get('foo')() == []
   

# Generated at 2022-06-20 13:57:35.494202
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    cliargs_value = ['value']
    cliargs_value_shallow = ['value']
    cliargs_value_deep = ['value']
    cliargs_value_deep_shallow = ['value']

    # cliargs_value is a list and lists are mutable, so value_shallow_copy should be a
    # different object but with the same contents
    cliargs_value_shallow_copy = cliargs_deferred_get('cliargs_value', shallowcopy=True)()
    # pylint: disable=unsubscriptable-object
    cliargs_value_shallow[0] = 'modified'
    assert cliargs_value_shallow_copy == ['value']

# Generated at 2022-06-20 13:57:45.459982
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'qox': {1, 2, 3}})
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('qux', shallowcopy=True)() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('qox', shallowcopy=True)() == {1, 2, 3}

# Generated at 2022-06-20 13:57:55.673506
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    import tempfile
    from ansible.module_utils.common.collections import is_sequence

    old_cliargs = CLIARGS
    test_args = ["--foo", "bar", "--baz", "boo"]

# Generated at 2022-06-20 13:58:05.877443
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    class A(object):
        pass

    a = A()
    a.x = 1
    CLIARGS = CLIArgs({'a': 1, 'b': '2'})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == '2'
    assert cliargs_deferred_get('c')() is None
    assert cliargs_deferred_get('c', default='3')() == '3'
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('b', shallowcopy=True)() == '2'
    assert cliargs_deferred_get('c', shallowcopy=True)() is None
    assert cliargs

# Generated at 2022-06-20 13:58:16.198948
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    assert callable(cliargs_deferred_get('foo'))

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    CLIARGS = CLIArgs({'foo': [1, 2, 3], 'baz': {'a': 'b'}})
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() == {'a': 'b'}

    CLIARGS = CLIArgs({'foo': [1, 2, 3], 'baz': {'a': 'b'}})

# Generated at 2022-06-20 13:58:27.345828
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for cliargs_deferred_get"""
    def fake_global_cliargs(obj):
        global CLIARGS
        CLIARGS = GlobalCLIArgs(obj)

    # Test that we can get the value of CLIARGS
    fake_global_cliargs({'a': 1})
    assert cliargs_deferred_get('a') == 1

    # Test that we get the default if the value is missing
    fake_global_cliargs({'b': 1})
    assert cliargs_deferred_get('a', default=2) == 2

    # Test that we get a shallow copy of the value
    fake_global_cliargs({'a': [1, 2, 3]})
    a = cliargs_deferred_get('a', shallowcopy=False)
    b = cliargs_def

# Generated at 2022-06-20 13:58:33.405408
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    def check_if_shallow_copy(value, shallow_copy):
        result = cliargs_deferred_get('somekey', value, shallow_copy)()
        if shallow_copy and id(value) == id(result):
            return True
        elif not shallow_copy and id(value) != id(result):
            return True
        else:
            return False

    assert check_if_shallow_copy(['foo', 'bar'], True)
    assert check_if_shallow_copy(['foo', 'bar'], False)
    assert check_if_shallow_copy(set(['foo', 'bar']), True)
    assert check_if_shallow_copy(set(['foo', 'bar']), False)
    assert check_if_shallow_copy({'foo':'bar'}, True)

# Generated at 2022-06-20 13:58:44.627435
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    cli_args = {}
    CLIARGS = CLIArgs(cli_args)

    assert cliargs_deferred_get('testkey') == None
    assert cliargs_deferred_get('testkey', default=1) == 1
    assert cliargs_deferred_get('testkey', default=1, shallowcopy=True) == 1

    cli_args['testkey'] = 2
    assert cliargs_deferred_get('testkey', default=1) == 2
    assert cliargs_deferred_get('testkey', default=1, shallowcopy=True) == 2

    cli_args['testkey'] = ['foo']
    assert cliargs_deferred_get('testkey') == ['foo']
   

# Generated at 2022-06-20 13:58:55.453783
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # normal behavior
    assert cliargs_deferred_get("foo", "bar")() == "bar"

    # normal behavior when cliargs are set
    global CLIARGS
    temp_cliargs = CLIArgs({"foo": "bar"})
    CLIARGS = temp_cliargs
    assert cliargs_deferred_get("foo", "baz")() == "bar"
    assert cliargs_deferred_get("bar", "baz")() == "baz"
    CLIARGS = CLIArgs({})

    # normal behavior when we request a shallow copy and it's a list
    temp_cliargs = CLIArgs({"foo": ["bar"]})
    CLIARGS = temp_cliargs
    assert cliargs_deferred_get("foo", ["baz"], shallowcopy=True)() == ["bar"]


# Generated at 2022-06-20 13:59:07.489240
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Unit test for function cliargs_deferred_get

    confirmation that the closure works with an instance of CLIArgs and that
    the shallow copy functionality works
    """
    global CLIARGS
    import copy
    import types
    import unittest

    class CliArgsDefaultUnitTest(unittest.TestCase):
        """Unit tests for function cliargs_deferred_get"""
        def test_deferred_get_closure(self):
            """Confirm that the closure captures the key, default, and shallowcopy
            inputs """
            key = 'key'
            default = 'default'
            shallowcopy = True
            f = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)
            self.assertTrue(isinstance(f, types.FunctionType))
            self.assertEqual

# Generated at 2022-06-20 13:59:23.554787
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test accessing cliargs with shallow copy"""
    cli_args = {
        'foo': 'bar',
        'food': ['a', 'b', 'c'],
        'fool': {'a': 'A', 'b': 'B'},
        'foos': set([1, 2, 3]),
    }
    _init_global_context(cli_args)

    # Accessing existing value
    foo = cliargs_deferred_get('foo')
    assert foo() == 'bar'

    # Accessing existing value with deep copy
    food = cliargs_deferred_get('food', shallowcopy=True)
    assert food() == ['a', 'b', 'c']
    food_return = food()
    food_return[0] = 'd'

# Generated at 2022-06-20 13:59:34.931292
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # First test that it works as expected without shallowcopy
    test_dict = dict(a=1, b=2)
    test_list = ['one', 'two', 'three']
    test_tuple = ('one', 'two', 'three')
    test_str = 'onetwothree'
    _init_global_context(dict(dictarg=test_dict, listarg=test_list, tuplearg=test_tuple,
                              strarg=test_str, missingarg='default'))

    assert cliargs_deferred_get('dictarg') == test_dict
    assert cliargs_deferred_get('listarg') == test_list
    assert cliargs_deferred_get('tuplearg') == test_tuple
    assert cliargs_deferred_get('strarg') == test_str


# Generated at 2022-06-20 13:59:43.453037
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Deferred access works
    CLIARGS.set('foo', 'bar')
    closure = cliargs_deferred_get('foo')
    assert closure() == 'bar'
    # Shallow copy
    CLIARGS.set('foo', 'baz')
    assert closure() == 'baz'
    lst = list(range(10))
    CLIARGS.set('foo', lst)
    assert closure(shallowcopy=True) == lst
    lst.append('baz')
    assert closure(shallowcopy=True) == list(range(10))
    # Non-shallow copy
    CLIARGS.set('foo', 'baz')
    assert closure() == 'baz'
    lst = list(range(10))
    CLIARGS.set('foo', lst)
    assert closure

# Generated at 2022-06-20 13:59:53.245483
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({"foo": "bar"})
    assert cliargs_deferred_get("foo")() == "bar"
    assert cliargs_deferred_get("foo", "baz")() == "bar"
    assert cliargs_deferred_get("baz", "baz")() == "baz"
    assert cliargs_deferred_get("foo", shallowcopy=True)() == "bar"
    assert cliargs_deferred_get("foo", "baz", shallowcopy=True)() == "bar"
    assert cliargs_deferred_get("baz", "baz", shallowcopy=True)() == "baz"



# Generated at 2022-06-20 14:00:05.154959
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import MutableMapping
    class FakeCLIArgs(MutableMapping):
        def __init__(self, dict_, attr_dict):
            self._dict = dict_
            self._attr_dict = attr_dict
        def __getitem__(self, key):
            return self._dict[key]
        def __setitem__(self, key, value):
            self._dict[key] = value
        def __delitem__(self, key):
            del self._dict[key]
        def __len__(self):
            return len(self._dict)
        def __iter__(self):
            return iter(self._dict)


# Generated at 2022-06-20 14:00:13.341057
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})

    # Test getting
    assert 'bar' == cliargs_deferred_get('foo')()

    # Test getting with a default
    assert 'baz' == cliargs_deferred_get('bar', default='baz')()

    # Test shallow copy
    assert 'baz' == cliargs_deferred_get('bar', default='baz', shallowcopy=True)()
    assert type(cliargs_deferred_get('foo', shallowcopy=True)()) == type(cliargs_deferred_get('foo')())

    # Test setting
    def set():
        """Setting the global CLIARGS"""
        global CLIARGS

# Generated at 2022-06-20 14:00:20.816951
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class DummyCliArgs:
        def get(self, key, default=None):
            return {'foo': 1, 'bar': [1, 2, 3]}

    def assert_equal(func1, func2):
        assert func1() == func2()

    get = cliargs_deferred_get
    cli_args_dict = DummyCliArgs()
    get_normal = get('foo', default=2)
    get_default = get('baz', default=2)
    get_seq = get('bar', shallowcopy=True)
    get_no_shallow = get('bar', shallowcopy=False)
    assert_equal(get_normal, lambda: 1)
    assert_equal(get_default, lambda: 2)
    assert_equal(get_seq, lambda: [1, 2, 3])

# Generated at 2022-06-20 14:00:30.828158
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    context = CLIArgs({
        'default': 'bar'
    })
    global CLIARGS
    try:
        CLIARGS = context
        assert cliargs_deferred_get('default') == 'bar'
        assert cliargs_deferred_get('baz', 'Baz') == 'Baz'
        assert cliargs_deferred_get('qux', shallowcopy=True) is None
        context['qux'] = ['a', 'b']
        assert cliargs_deferred_get('qux', shallowcopy=True) == ['a', 'b']
    finally:
        CLIARGS = {}

# Generated at 2022-06-20 14:00:42.780381
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    CLIARGS['empty_list'] = []
    CLIARGS['filled_list'] = [1, 2, 3, 4]
    CLIARGS['empty_dict'] = {}
    CLIARGS['filled_dict'] = {'1': 'apple', '2': 'banana'}
    CLIARGS['empty_set'] = set()
    CLIARGS['filled_set'] = {'1', '2', '3'}
    CLIARGS['string'] = 'adam'
    CLIARGS['int'] = 12
    CLIARGS['default_not_in_cliargs'] = 'grapes'

    assert cliargs_deferred_get('empty_list')() is None
    assert cliargs_deferred_get('empty_list', default=[])

# Generated at 2022-06-20 14:00:48.345652
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert cliargs_deferred_get('test')() == None
    assert cliargs_deferred_get('test', 'foo')() == 'foo'
    CLIARGS = CLIArgs({'test': 'bar'})
    assert cliargs_deferred_get('test')() == 'bar'
    assert cliargs_deferred_get('test', 'foo')() == 'bar'


# Generated at 2022-06-20 14:01:16.033740
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Unicode strings are not sequences
    CLIARGS.update({'foo2': u'bar'})
    assert cliargs_deferred_get('foo2')() == u'bar'
    assert cliargs_deferred_get('foo2', shallowcopy=True)() == u'bar'

    # Lists are sequences
    CLIARGS.update({'foo3': ['bar']})
    assert cliargs_deferred_get('foo3')() == ['bar']
    assert cliargs_deferred_get('foo3', shallowcopy=True)() == ['bar']

    # Tuples are sequences
    CLIARGS.update({'foo4': ('bar', )})

# Generated at 2022-06-20 14:01:23.104792
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCliArgs:
        def __init__(self, val):
            self.val = val

        def __getitem__(self, key):
            return self.val[key]

    value = {'foo': 'bar'}
    test_value = value.copy()
    test_cliar = TestCliArgs(test_value)
    global CLIARGS
    CLIARGS = test_cliar

    callback = cliargs_deferred_get('foo')
    assert callback() == 'bar'
    assert test_value is callback()

    test_value['foo'] = 'baz'
    assert callback() == 'baz'
    callback2 = cliargs_deferred_get('foo', shallowcopy=True)
    assert callback2() == 'bar'

# Generated at 2022-06-20 14:01:33.988509
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert callable(cliargs_deferred_get)
    test_hash = {'test_key': 'test_value'}
    CLIARGS = GlobalCLIArgs(test_hash)
    assert callable(cliargs_deferred_get('test_key'))
    assert cliargs_deferred_get('test_key')(), 'test_value'
    assert cliargs_deferred_get('test_key', shallowcopy=True)(), 'test_value'
    assert cliargs_deferred_get('test_key2')(), None
    assert cliargs_deferred_get('test_key2', 'default')(), 'default'
    CLIARGS = GlobalCLIArgs({'test_key': ['a', 'b']})
    assert cliargs_deferred_

# Generated at 2022-06-20 14:01:43.774521
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    class GlobalCLIArgsMock(object):
        """Mock the GlobalCLIargs"""
        def __init__(self, **kwargs):
            self.kwargs = kwargs
        def __getitem__(self, key):
            return self.kwargs[key]
        def get(self, key):
            return self.kwargs.get(key, None)

    global CLIARGS
    orig_args = CLIARGS

# Generated at 2022-06-20 14:01:54.825667
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check(value, shallowcopy, expected):
        inner = cliargs_deferred_get('test', default=value, shallowcopy=shallowcopy)
        assert inner() == expected

    # Check with value None
    check(None, False, None)
    check(None, True, None)

    # Check with value string
    check('test', False, 'test')
    check('test', True, 'test')

    # Check with value list
    check(['test', 'test'], False, ['test', 'test'])
    check(['test', 'test'], True, ['test', 'test'])

    # Check with value dict
    check({'test': 'test'}, False, {'test': 'test'})
    check({'test': 'test'}, True, {'test': 'test'})

    #

# Generated at 2022-06-20 14:02:04.917723
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    cli_args = {'foo': 'bar'}
    global CLIARGS
    CLIARGS = CLIArgs(cli_args)
    assert cliargs_deferred_get('foo')() == cli_args['foo']
    assert cliargs_deferred_get('bar')() == None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'
    assert cliargs_deferred_get('foo', shallowcopy=True)() is cli_args['foo']

    # Test with a GlobalCLIArgs object
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == cli_args['foo']
    assert cliargs_deferred_

# Generated at 2022-06-20 14:02:10.672940
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get function
    """

    # in this test we create a new global CLIARGS object
    CLIARGS = GlobalCLIArgs.from_options({'foo': 1})

    # test key exists in new CLIARGS
    func = cliargs_deferred_get('foo', shallowcopy=False)
    assert func() == 1
    func = cliargs_deferred_get('foo', shallowcopy=True)
    assert func() == 1

    # test key exists in new CLIARGS when default is provided
    func = cliargs_deferred_get('foo', default=2, shallowcopy=False)
    assert func() == 1
    func = cliargs_deferred_get('foo', default=2, shallowcopy=True)
    assert func() == 1

    # test key does not

# Generated at 2022-06-20 14:02:20.841183
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for :py:func:`cliargs_deferred_get`
    """
    _init_global_context({'ansible_python_interpreter': '/usr/bin/python'})
    assert cliargs_deferred_get('ansible_python_interpreter')() == '/usr/bin/python'
    assert cliargs_deferred_get('ansible_python_interpreter')(default='/usr/bin/python3')() == '/usr/bin/python'
    assert cliargs_deferred_get('ansible_python_interpreter')(default='/usr/bin/python3')() == '/usr/bin/python'
    assert cliargs_deferred_get('foo')(default='bar')() == 'bar'

# Generated at 2022-06-20 14:02:31.058931
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import defaultdict

    CLIARGS_test = CLIArgs()
    CLIARGS_test['val1'] = 'test1'
    CLIARGS_test['val2'] = 'test2'
    CLIARGS_test['val3'] = 'test3'
    CLIARGS_test['val4'] = 'test4'
    CLIARGS_test['val5'] = 'test5'

    assert 'test1' == cliargs_deferred_get('val1')()
    assert 'test2' == cliargs_deferred_get('val2')()
    # test default of None
    assert None == cliargs_deferred_get('val6')()

# Generated at 2022-06-20 14:02:40.673804
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'

    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({'foo': 'bar'})

# Generated at 2022-06-20 14:03:22.638652
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class GlobalCliArgsMock(object):
        def __init__(self, cli_args):
            self.cli_args = cli_args

        def get(self, key, default=None):
            return self.cli_args.get(key, default=default)

    # Testing that cliargs_deferred_get returns a bound closure
    global CLIARGS
    CLIARGS = GlobalCliArgsMock({'bar': 'baz'})
    test_closure = cliargs_deferred_get('bar')
    assert test_closure() == 'baz'
    assert cliargs_deferred_get('bar')() == 'baz'

    CLIARGS = GlobalCliArgsMock({})
    assert cliargs_deferred_get('bar')('qux') == 'qux'



# Generated at 2022-06-20 14:03:27.942117
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cli_args = {'a': [1, 2, 3], 'b': {1: 2, 3: 4}, 'c': set([1, 2, 3])}
    cli_args2 = {'a': [{1: 2, 3: 4}]}
    # First make sure it works if it's already instantiated
    CLIARGS = GlobalCLIArgs.from_options(cli_args)
    assert CLIARGS.get('a') == [1, 2, 3]
    assert cliargs_deferred_get('a', default=[])() == [1, 2, 3]
    assert cliargs_deferred_get('b', default={})() == {1: 2, 3: 4}
    assert cliargs_deferred_get('c', default=set([]))() == set

# Generated at 2022-06-20 14:03:36.218554
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function ``cliargs_deferred_get``"""
    global CLIARGS

# Generated at 2022-06-20 14:03:42.662998
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from copy import deepcopy

    # Make this a global instead of a module based fixture so we can mock it.  The mocker fixture
    # is module scoped
    global CLIARGS

    # Nested fixture so it will run after the real cliargs fixture
    def init_cliargs(cliargs):
        """Ensure the global is initialized so that deferred get works"""
        CLIARGS.clear()
        CLIARGS.update(cliargs)

    # Shallow copy of a sequence
    def test_sequence(mocker, cliargs):
        CLIARGS = GlobalCLIArgs.from_options({})
        init_cliargs(cliargs)
        key = 'shallowsequence'
        assert cliargs[key] == cliargs_deferred_get(key, shallowcopy=False)()
        assert cliargs[key]

# Generated at 2022-06-20 14:03:54.254019
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    t1 = dict(a=dict(b=dict(c=dict(d=42))))
    CLIARGS = CLIArgs(t1)
    assert cliargs_deferred_get('a.b.c.d')() == 42
    t1['a']['b']['c']['d'] = 43
    assert cliargs_deferred_get('a.b.c.d')() == 43
    t1['a']['b']['c']['d'] = [1, 2, 3]
    assert cliargs_deferred_get('a.b.c.d', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('a.b.c.d', shallowcopy=False)() == [1, 2, 3]
    t

# Generated at 2022-06-20 14:04:02.450322
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    class CliArgs:
        def __init__(self, cliargs):
            self._cliargs = cliargs

        def get(self, key, default=None):
            return self._cliargs.get(key, default=default)

        def __getitem__(self, key):
            return self._cliargs[key]

    data = {'a': [1, 2, 3], 'b': {1: 'a', 2: 'b'}, 'c': set((1, 2, 3))}
    cliargs = CliArgs(data)
    global CLIARGS
    CLIARGS = cliargs

    for key, value in data.items():
        # test that we always get the same object
        assert cliargs_deferred_get(key) is value
        assert cliargs_def

# Generated at 2022-06-20 14:04:14.101068
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': ['bar']}
    global CLIARGS
    CLIARGS = CLIArgs(cli_args)
    check = cliargs_deferred_get('foo')
    assert check() == ['bar']
    check = cliargs_deferred_get('foo', shallowcopy=True)
    assert check() == ['bar']
    CLIARGS.set('foo', ['baz'])
    assert check() == ['bar']

    cli_args = {'foo': {'bar': 'baz'}}
    CLIARGS = CLIArgs(cli_args)
    check = cliargs_deferred_get('foo')
    assert check() == {'bar': 'baz'}
    check = cliargs_deferred_get('foo', shallowcopy=True)

# Generated at 2022-06-20 14:04:23.989088
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    from ansible.utils.context_objects import DeferredValue

    # Set up a test CLIARGS object
    CLIARGS._test_only_set_values({'the_value_to_get': 'the value'})

    # Test that the function returns the value it should
    assert 'the value' == cliargs_deferred_get('the_value_to_get')()

    # Test that the value is a deferred value
    value = cliargs_deferred_get('the_value_to_get', default='not used')()
    assert isinstance(value, DeferredValue)

    # Test that if the key is not found then the default value is used
    assert 'default' == cliargs_deferred_get('no_such_value', default='default')()

    # Test that if we use the

# Generated at 2022-06-20 14:04:34.118479
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    from ansible.context.cliargs_deferred_get import cliargs_deferred_get

    get_cliargs_deferred_get = cliargs_deferred_get('test_key')
    assert get_cliargs_deferred_get() is None

    cli_args = {'test_key': 'a test string'}
    _init_global_context(cli_args)

    assert get_cliargs_deferred_get() == 'a test string'

    cli_args['test_key'] = ['a test list']
    _init_global_context(cli_args)

    assert get_cliargs_deferred_get() == ['a test list']
    assert get_cliargs_deferred_get(shallowcopy=True) == ['a test list']

    cli_args