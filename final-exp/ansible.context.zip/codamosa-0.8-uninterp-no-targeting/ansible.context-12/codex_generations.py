

# Generated at 2022-06-20 13:54:39.667628
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    from ansible.module_utils.common.collections import is_sequence

    cli_args = CLIArgs({'local_tmp': '/tmp/ansible-tmp', 'forks': 10, 'valgrind': True, 'vars': ['foo', 'bar'], 'autotest_files': {'/foo': {'cliargs1': 'cliargs1', 'something': 'else', 'and': 'more'}}})
    assert cli_args == CLIARGS
    assert cli_args['local_tmp'] == '/tmp/ansible-tmp'
    assert cli_args['forks'] == 10
    assert cli_args['valgrind'] is True
    assert cli_args['vars'] == ['foo', 'bar']

# Generated at 2022-06-20 13:54:51.806765
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Verify that cliargs_deferred_get works as expected

    Should support:

     * returning a value from CLIARGS
     * returning a default value
     * returning a shallow-copied value for sequences, Mappings and Sets
     * returning other values by value
    """
    # pylint: disable=protected-access
    _init_global_context({'one': 'first', 'two': 'second', 'five': 5, 'six': 6})

    closure = cliargs_deferred_get('one')
    assert closure() == 'first'

    closure = cliargs_deferred_get('two')
    assert closure() == 'second'

    closure = cliargs_deferred_get('three')
    assert closure() is None

    closure = cliargs_deferred_get('three', default='third')


# Generated at 2022-06-20 13:55:03.033726
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def inner_test(key, value, default=None, shallowcopy=False):
        assert cliargs_deferred_get(key, default, shallowcopy)() == value

    # Test that a non-default value gets returned
    inner_test('test', 'b', 'a')

    # Test that a default value gets returned
    inner_test('test2', 'a', 'a')

    # Test that a default value can be set while also allowing a non-default value
    CLIARGS['test3'] = 'b'
    inner_test('test3', 'b', 'a')
    del CLIARGS['test3']

    # Test that a non-default value can be returned after the value was removed
    CLIARGS['test4'] = 'b'
    del CLIARGS['test4']

# Generated at 2022-06-20 13:55:13.418674
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # pylint: disable=unnecessary-lambda
    CLIARGS = CLIArgs({'test_global': 'global'})
    assert cliargs_deferred_get('test_global')() == 'global'
    assert cliargs_deferred_get('test_global', shallowcopy=True)() == 'global'
    assert cliargs_deferred_get('test_global', default='default')() == 'global'
    assert cliargs_deferred_get('test_global', default='default', shallowcopy=True)() == 'global'
    assert cliargs_deferred_get('test_global', default=lambda: 'default')() == 'global'

# Generated at 2022-06-20 13:55:25.339852
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'test': 'value'}
    _init_global_context(cli_args)
    assert 'value' == cliargs_deferred_get('test')()
    assert 'value' == cliargs_deferred_get('test', default='test_default')()
    assert 'test_default' == cliargs_deferred_get('not_a_key', default='test_default')()
    assert 'test_default' == cliargs_deferred_get('not_a_key', 'test_default')()  # Without the keyword

    # Test when the key is missing
    cli_args.clear()
    _init_global_context(cli_args)
    assert cliargs_deferred_get('test')(default='test_default') == 'test_default'
    assert cl

# Generated at 2022-06-20 13:55:34.874840
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.inventory.dir import InventoryDirectory
    from ansible.plugins.loader import become_loader
    from ansible.plugins.connection.network_cli import Connection as NetworkCliConnection

    class DummyCli(object):
        def __init__(self, defaults=None):
            self.parser = None
            self.args = {}
            self.options = {}
            if defaults is not None:
                self.options.update(defaults)

    # Test code to make sure that we do not shallowcopy by default
    cli = DummyCli()
    assert cliargs_deferred_get('dummy_key')() == None
    cli.options['dummy_key'] = object()
    assert cliargs_deferred_get('dummy_key')() is cli.options['dummy_key']

   

# Generated at 2022-06-20 13:55:45.038259
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    # pylint: disable=unused-variable
    # TODO: figure out why pylint has false positives
    global CLIARGS
    # No cliargs are parsed yet, so get the default value
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', default=False)() is False
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('blah', default=False)() is False
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})

# Generated at 2022-06-20 13:55:55.398667
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS  # pylint: disable=global-statement
    # Don't need to mock out the whole CLI

    # Test default value and default is a copy
    CLIARGS = CLIArgs({})
    default = ['foo', 'bar']
    assert cliargs_deferred_get('no_such_key', default=default, shallowcopy=True)() == default
    assert cliargs_deferred_get('no_such_key', default=default, shallowcopy=False)() == default
    assert cliargs_deferred_get('no_such_key', default=default, shallowcopy=False)() is not default
    assert cliargs_deferred_get('no_such_key', default=default, shallowcopy=True)() is not default

    # Test returning a value and no copy specified
    CLIARGS = CLI

# Generated at 2022-06-20 13:56:06.878116
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'debug': True})
    assert cliargs_deferred_get('debug')()
    CLIARGS = CLIArgs({'debug': False})
    assert not cliargs_deferred_get('debug')()
    assert cliargs_deferred_get('foo', default=42)() == 42
    CLIARGS = CLIArgs({})
    # We're returning a list not a copy so the list will change when the context changes
    assert cliargs_deferred_get('foo', default=[1, 2, 3], shallowcopy=True)() == [1, 2, 3]
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo', default=[1, 2, 3], shallowcopy=True)()

# Generated at 2022-06-20 13:56:12.917943
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert CLIARGS == CLIARGS, "This is a singleton pattern.  There should be only one CLIARGS"
    # Note that this is not a singleton pattern, we're only testing the function.  Each time
    # we instantiate it, we should have a new function that has a closure over the value of
    # CLIARGS at the moment we created it
    get_module_utils_path = cliargs_deferred_get('module_utils_path')

    # Verify that it works even if the cli args have not yet been initialized
    # just in case we're running this unit test before the cli args are initialized
    assert get_module_utils_path() == CLIARGS.get('module_utils_path', default=None)

    # Now set the singleton with a realistic set of cli args and ensure that the closure works
   

# Generated at 2022-06-20 13:56:28.724247
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import defaultdict

    # Use a simple object that raises an exception if mutated
    class NonMutatingDict(dict):
        def __setitem__(self, name, value):
            raise RuntimeError("Attempt to mutate NonMutatingDict")

    cliargs_from_options = GlobalCLIArgs.from_options

    def run_test(expected_vals, val_types, cli_args):
        expected_vals = expected_vals.copy()
        expected_vals.update({
            type: defaultdict(str)
            for type in val_types
        })
        global CLIARGS
        CLIARGS = cliargs_from_options(cli_args)
        for key, expected_val in expected_vals.items():
            assert cliargs_deferred

# Generated at 2022-06-20 13:56:36.620468
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the deferred getter"""
    class MyCliArgs(dict):
        def __getattr__(self, attr):
            return cliargs_deferred_get(attr)

    cliargs = MyCliArgs({'foo': 'bar'})
    _init_global_context(cliargs)

    assert cliargs.foo() == 'bar'

    cliargs['foo'] = [1, 2, 3]
    assert cliargs.foo() == [1, 2, 3]

    cliargs['foo'] = {'one': 1}
    assert cliargs.foo() == {'one': 1}

    cliargs['foo'] = {1, 2, 3}
    assert cliargs.foo() == {1, 2, 3}

    cliargs['foo'] = 'one'
   

# Generated at 2022-06-20 13:56:47.977928
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_args = dict(
        test_arg='test',
        test_clone=dict(
            test=1,
            test2='test',
        ),
        test_tuple=(1, 2, 3,),
        test_list=['test', 'test2', 'test3'],
        test_set={'test', 'test2', 'test3'},
    )

    _init_global_context(test_args)

    for key, value in test_args.items():
        inner = cliargs_deferred_get(key)
        assert inner() == value


# Generated at 2022-06-20 13:56:58.111335
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cliargs = {
        'string': 'foo',
        'seq': [1, 2, 3],
        'mapping': {'a': 1},
        'set': (1, 2),
    }
    CLIARGS = CLIArgs(cliargs)

    # Function bound directly to cliargs_deferred_get
    for key, value in cliargs.items():
        func = cliargs_deferred_get(key)
        assert value is func()
        assert value is not func()

    # Function bound to cliargs_deferred_get with shallow copy
    for key, value in cliargs.items():
        func = cliargs_deferred_get(key, shallowcopy=True)
        assert value == func()
        assert value is not func()

# Generated at 2022-06-20 13:57:09.031101
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CLIArgs(dict):
        def get(self, key, default=None):
            return super(CLIArgs, self).get(key, default=default)

    global CLIARGS
    cliargs = CLIArgs({})
    cliargs['moo'] = 'moo'
    cliargs['moo2'] = ['moo', 'boo']
    cliargs['moo3'] = {'moo': 'boo'}
    cliargs['moo4'] = ('moo', 'boo')
    cliargs['moo5'] = {'moo', 'boo'}
    CLIARGS = cliargs

    f = cliargs_deferred_get('moo', 'aoeu')

    assert f() == 'moo'

# Generated at 2022-06-20 13:57:19.776613
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import types
    from ansible.utils.context_objects import GlobalCLIArgs
    global CLIARGS
    args = types.SimpleNamespace(
        connection='ssh',
        inventory='inventory',
        module_path='module_path',
    )

    def test_set_context():
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(args)

    closure = cliargs_deferred_get('module_path')
    assert not hasattr(closure, '_closured_connection')
    assert not hasattr(closure, '_closured_inventory')
    assert not hasattr(closure, '_closured_module_path')
    assert closure() is None

    test_set_context()
    assert not hasattr(closure, '_closured_connection')
    assert not has

# Generated at 2022-06-20 13:57:28.101994
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test1': 'test1', 'test2': 'test2'})
    lazy_test1 = cliargs_deferred_get('test1')
    lazy_test2 = cliargs_deferred_get('test2')
    assert lazy_test1() == 'test1'
    assert lazy_test2() == 'test2'
    assert cliargs_deferred_get('test3')() is None
    assert cliargs_deferred_get('test3', default='test3')() == 'test3'

# Generated at 2022-06-20 13:57:36.016351
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # Initial test of a known key
    assert cliargs_deferred_get('verbosity')() == 0

    # Test a default
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test a default with a shallow copy
    value = {'a': 1}
    default = {'a': 1}
    assert cliargs_deferred_get('foo', shallowcopy=True, default=default)() is not default
    assert cliargs_deferred_get('foo', shallowcopy=True, default=default)() == default

    # Test a known key with a shallow copy
    key = 'check'
    CLIARGS.setdefault(key, value)

# Generated at 2022-06-20 13:57:47.434885
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_cli_args = CLIArgs({'connection': 'ssh', 'no_log': True, 'vault_password_file': 'secret/ansible-vault', 'verbosity': 3})

    global CLIARGS
    CLIARGS = test_cli_args

    assert cliargs_deferred_get('connection')(), 'ssh'
    assert cliargs_deferred_get('no_log')(), True
    assert cliargs_deferred_get('verbosity')(), 3



# Note: the global context should be initialized as the very first thing that happens in the program
# this allows later code to simply import the CLIARGS object and use it.
# TODO: we should switch to a singleton pattern for the CLIARGS.  In the future, we may want to allow
# multiple ansible runs in parallel (e.

# Generated at 2022-06-20 13:57:56.626505
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Set up the cliargs for this test
    _init_global_context(dict(one = [1, 2, 3], two = 'two', three = dict(a = 1, b = 2, c = 3)))

    # Test sanity
    assert cliargs_deferred_get(key='one') == [1,2,3]
    assert cliargs_deferred_get(key='two') == 'two'
    assert cliargs_deferred_get(key='three') == dict(a = 1, b = 2, c = 3)

    # Test getting non-existent keys
    assert cliargs_deferred_get(key='one', default=True) == [1,2,3]
    assert cliargs_deferred_get(key='two', default=True) == 'two'
    assert cliargs

# Generated at 2022-06-20 13:58:20.536704
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_case(arg, default, expected_value, expected_type=None, shallowcopy=False):
        cliargs = GlobalCLIArgs.from_options({'foo_bar': arg})
        assert cliargs.get('foobar') == expected_value, 'foobar == {}'.format(expected_value)
        assert cliargs.get('foobar', default=default) == expected_value, 'foobar with default == {}'.format(expected_value)
        if isinstance(expected_value, (Mapping, Set)):
            assert type(cliargs.get('foobar')) == type(expected_value), 'type(foobar) == {}'.format(type(expected_value))

# Generated at 2022-06-20 13:58:23.537608
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'



# Generated at 2022-06-20 13:58:32.381605
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Tests the functionality provided by cliargs_deferred_get

    The primary functionality is that the function returned can be called
    even when ``CLIARGS`` is replaced with a new object.
    """
    key = 'test_key'
    default = 'test_default'
    def_get = cliargs_deferred_get(key, default)
    assert def_get is not None
    # check that it works with a non-replaced CLIARGS
    assert CLIARGS.get(key, default) == default
    assert def_get() == default

    # check that it works with old CLIARGS replaced with a new one
    class TestArgs(object):
        def __init__(self, overrides=None):
            self.opts = {}

# Generated at 2022-06-20 13:58:43.678595
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import DeferredCLIArgs

    cliargs = DeferredCLIArgs({'foo': 'bar'})
    CLIARGS = cliargs
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz', False)() == False

    CLIARGS = None

    assert cliargs_deferred_get('foo')() == None
    assert cliargs_deferred_get('baz', False)() == False

    cliargs = DeferredCLIArgs({'foo': 'bar', 'baz': False})
    CLIARGS = cliargs
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz', False)() == False

# Generated at 2022-06-20 13:58:55.014601
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = dict(cmd_line=dict(become_method='su'), connection_plugins=dict(ssh=dict(connect_timeout=1)))
    _init_global_context(cli_args)
    # Regular get
    assert cliargs_deferred_get('become_method')() == 'su'
    assert cliargs_deferred_get('connection_plugins')() == {'ssh': {'connect_timeout': 1}}

    # Get with default
    assert cliargs_deferred_get('nope', 42)() == 42

    # Get with shallow copy
    result = cliargs_deferred_get('connection_plugins', shallowcopy=True)()
    assert id(result) != id(cli_args['connection_plugins'])
    assert result == {'ssh': {'connect_timeout': 1}}

# Generated at 2022-06-20 13:59:06.351695
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class M:
        x = cliargs_deferred_get('x')

    _init_global_context(dict(x='y'))
    m = M()
    assert m.x == 'y'

    _init_global_context(dict(x=[1, 2, 3]))
    m = M()
    assert m.x == [1, 2, 3]
    assert m.x is not CLIARGS['x']
    assert m.x == CLIARGS['x']

    _init_global_context(dict(x=dict(a=1, b=2, c=3)))
    m = M()
    assert m.x == dict(a=1, b=2, c=3)
    assert m.x is not CLIARGS['x']
    assert m.x == CLIARGS['x']

# Generated at 2022-06-20 13:59:16.085770
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    key = 'test'
    cliargs = {key: {'a': 'b'}}
    _init_global_context(cliargs)

    value = cliargs_deferred_get(key, default=None, shallowcopy=False)()
    assert value == cliargs[key]

    value = cliargs_deferred_get(key, default=None, shallowcopy=True)()
    assert value == cliargs[key]
    assert value is not cliargs[key]

    del cliargs[key]
    value = cliargs_deferred_get(key, default='c', shallowcopy=True)()
    assert value == 'c'

    value = cliargs_deferred_get(key, default='d', shallowcopy=False)()
    assert value == 'd'

# Generated at 2022-06-20 13:59:25.077193
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MockCLIArgs(object):
        def __init__(self, d):
            self._d = d

        def get(self, *args):
            return self._d.get(*args)

    assert cliargs_deferred_get('nope', 'default')(MockCLIArgs({})) == 'default'

    assert cliargs_deferred_get('thing', 'default')(MockCLIArgs({'thing': 'mything'})) == 'mything'

    # shallow copy
    assert cliargs_deferred_get('mapping', 'default', shallowcopy=True)(MockCLIArgs({'mapping': {'why': 'yes'}})) == {'why': 'yes'}

# Generated at 2022-06-20 13:59:36.699389
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'foo': 'bar'})
    assert 'bar' == cliargs_deferred_get('foo')()

    assert 'default' == cliargs_deferred_get('missing', default='default')()

    CLIARGS = CLIArgs({'foo': {'foo': {'foo': 'bar'}}})
    assert {'foo': {'foo': 'bar'}} == cliargs_deferred_get('foo', shallowcopy=True)()
    assert {'foo': 'bar'} == cliargs_deferred_get('foo', shallowcopy=True)()['foo']
    assert 'bar' == cliargs_deferred_get('foo', shallowcopy=True)()['foo']['foo']
    assert id(CLIARGS['foo']) == id

# Generated at 2022-06-20 13:59:43.929040
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    from ansible.tests.unit.utils.fakes import FakeOptions

    args = FakeOptions()
    args.become_user = 'some_user'

    CLIARGS = CLIArgs(args)

    def_cls = cliargs_deferred_get('become_user')
    def_shallow = cliargs_deferred_get('become_user', shallowcopy=True)
    def_default = cliargs_deferred_get('not_a_key', default=True)

    assert def_cls() == 'some_user'
    assert def_shallow() == 'some_user'
    assert def_default() is True

# Generated at 2022-06-20 14:00:16.371175
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('default')(), None
    from parameterized import parameterized
    from functools import partial


# Generated at 2022-06-20 14:00:22.397789
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Verify that ``cliargs_deferred_get`` works correctly"""
    import collections
    import copy

    testdict = {'a': ['a', 'list', 'not', 'a', 'shallow', 'copy'],
                'b': collections.OrderedDict([('a', 1), ('b', 2), ('c', 3)]),
                'c': 'Not a sequence',
                }
    CLIARGS.set_options(testdict)

    result = cliargs_deferred_get('c')()
    assert result == testdict['c']
    # Verify that changes to the result do not change CLIARGS
    try:
        result[0] = 'a'
    except (TypeError, KeyError):
        pass
    assert result == testdict['c']

# Generated at 2022-06-20 14:00:33.363573
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Tests normal use case
    default = {'a': 1, 'b': 2}
    value = cliargs_deferred_get('foo', default=default)()
    assert value == default

    class MockGlobalCLIArgs:
        def __init__(self, foo):
            self.foo = foo
        def get(self, key, default=None):
            if key == 'foo':
                return self.foo
            else:
                return default

    foo = {'a': 3, 'b': 4}
    # Test that the new object gets copied
    global CLIARGS
    CLIARGS = MockGlobalCLIArgs(foo)
    value = cliargs_deferred_get('foo', default=default)()
    assert value == foo
    assert value is not foo

    foo = [1, 2, 3]


# Generated at 2022-06-20 14:00:39.142788
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the inner function runs when bound
    def mock_get(key, **kwargs):
        assert key == 'foo'
        assert kwargs == {'default': None}
        return 'bar'
    CLIARGS.get = mock_get
    inner = cliargs_deferred_get('foo')
    assert inner() == 'bar'

# Generated at 2022-06-20 14:00:43.836967
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'foo'
    assert cliargs_deferred_get('foo')() == 'foo'
    assert cliargs_deferred_get('foo', default='bar')() == 'foo'
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', default='bar')() == 'bar'

# Generated at 2022-06-20 14:00:51.759572
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['somekey'] = u'foo'
    assert cliargs_deferred_get('somekey')() == u'foo'
    assert cliargs_deferred_get('somekey', shallowcopy=True)() == u'foo'

    CLIARGS['someotherkey'] = [1, 2, 3]
    assert cliargs_deferred_get('someotherkey')() == [1, 2, 3]
    assert cliargs_deferred_get('someotherkey', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-20 14:01:00.347826
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test a simple value
    def test_simple_value():
        global CLIARGS
        CLIARGS = CLIArgs({'a': 'hello'})
        assert cliargs_deferred_get('a')() == 'hello'

        # Test the default value
        assert cliargs_deferred_get('b', default='default')() == 'default'
        CLIARGS = GlobalCLIArgs.from_options({'b': 'notdefault'})
        assert cliargs_deferred_get('b', default='default')() == 'notdefault'

    # Test a mutable value
    def test_mutable_value():
        global CLIARGS
        CLIARGS = CLIArgs({'a': ['hello']})
        assert cliargs_deferred_get('a')() == ['hello']

        # Make sure the value

# Generated at 2022-06-20 14:01:11.384863
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Simple unit test for cliargs_deferred_get

    Uses our subclass ``CLIArgs`` since it is a ``dict`` and not just a proxy
    """
    cli_args = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 2}, 'e': 'test'})
    get_a = cliargs_deferred_get('a')
    assert get_a() == 1
    get_a_shallow = cliargs_deferred_get('a', shallowcopy=True)
    assert get_a_shallow() == 1
    get_b = cliargs_deferred_get('b')
    assert get_b() == [1, 2, 3]

# Generated at 2022-06-20 14:01:20.245763
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test closure to get value from CLIARGS with shallow copy functionality"""
    from ansible.utils.collections import is_sequence

    # Prepare fixture
    global CLIARGS
    CLIARGS = CLIArgs({'a': ['b', 'c']})

    assert cliargs_deferred_get('a')(), CLIARGS['a']
    assert cliargs_deferred_get('a', shallowcopy=True)(), ['b', 'c']
    assert not cliargs_deferred_get('b')(), 'empty default'
    assert cliargs_deferred_get('b', ['d', 'e'])(), ['d', 'e']
    assert cliargs_deferred_get('b', shallowcopy=True)(), ['d', 'e']

# Generated at 2022-06-20 14:01:32.045737
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    class MyKeys(dict):
        VALUE = 'value'
        OTHER = 'other'
        ANOTHER = 'another'

    my_keys = MyKeys()

    testargs = {
        my_keys.VALUE: 'foo',
        my_keys.OTHER: [1, 2, 3],
        my_keys.ANOTHER: {'one': 1, 'two': 2},
    }

    _init_global_context(testargs)

    def_get = cliargs_deferred_get
    value = def_get(my_keys.VALUE)()
    assert isinstance(value, str)
    assert value == 'foo'

    other = def_get(my_keys.OTHER)()
    assert isinstance(other, list)
    assert other == [1, 2, 3]


# Generated at 2022-06-20 14:02:06.790007
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set, Sequence
    from ansible.module_utils.common.collections import is_sequence

    # Test normal case
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'x': 'm', 'y': 'n'}, 'd': {1, 2, 3}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'x': 'm', 'y': 'n'}
    assert cliargs_deferred_get('d')() == {1, 2, 3}



# Generated at 2022-06-20 14:02:10.666225
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.set('foo', 123, None)
    closure = cliargs_deferred_get('foo', 1)
    assert closure() == 123

    closure = cliargs_deferred_get('nofoo', 1)
    assert closure() == 1

# Generated at 2022-06-20 14:02:21.451446
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    d = {
        'a': 1,
        'b': [1, 2, 3],
        'c': {
            '1': 1,
            '2': 2,
            '3': 3,
        },
        'd': {1, 2, 3},
        'e': 'this is a string',
        'f': None,
        'g': '',
        'h': False,
        'i': True,
        }
    global CLIARGS

# Generated at 2022-06-20 14:02:26.932492
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    key = 'table'
    default = ['foo', 'bar']
    shallowcopy = True

    def mock_context_object(value):
        return GlobalCLIArgs({key: value})

    # test default value
    CLIARGS = mock_context_object(None)
    assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == default

    # test shallow copy
    val = [1, 2]
    CLIARGS = mock_context_object(val)
    assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == val
    assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() is not val

    # test shallow copy with non-copyable
    val = [1, 2]

# Generated at 2022-06-20 14:02:38.130036
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def is_shallow_copy(left, right):
        if not is_sequence(left):
            if isinstance(left, Set):
                # This can be simplified to just `return left != right` once we move to python3.7
                return not all(elem in right for elem in left) and not all(elem in left for elem in right)
            return left is right
        if not is_sequence(right):
            return False
        if len(left) != len(right):
            return False
        return all(is_shallow_copy(l, r) for l, r in zip(left, right))


# Generated at 2022-06-20 14:02:46.454917
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'listy': ['one', 'two']})

    # test 1: Not deferred, not shallow
    d = cliargs_deferred_get('foo')
    assert d() == 'bar'

    # test 2: deferred, not shallow
    d = cliargs_deferred_get('foo', default='baz', shallowcopy=False)
    assert d() == 'bar'

    # test 3: Not deferred, shallow
    d = cliargs_deferred_get('foo', shallowcopy=True)
    assert d() == 'bar'

    # test 4: deferred, shallow
    d = cliargs_deferred_get('foo', default='baz', shallowcopy=True)
    assert d() == 'bar'

    # test 5: Not

# Generated at 2022-06-20 14:02:55.344772
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from unittest import TestCase, main

    class TestCLIARGSDeferredGet(TestCase):
        def testNoArgs(self):
            expected = 'foo'
            def set_cliargs():
                global CLIARGS
                CLIARGS = GlobalCLIArgs({'foo': expected})

            actual = cliargs_deferred_get('foo')(set_cliargs)
            self.assertEqual(expected, actual)

        def testDefault(self):
            expected = 'foo'
            def set_cliargs():
                global CLIARGS
                CLIARGS = GlobalCLIArgs({})

            actual = cliargs_deferred_get('foo', expected)(set_cliargs)
            self.assertEqual(expected, actual)


# Generated at 2022-06-20 14:03:02.826881
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    initial_cliargs = CLIARGS
    try:
        CLIARGS = CLIArgs({'key': 'value'})
        closure = cliargs_deferred_get('key')
        assert closure() == 'value'
        assert closure() is closure()
    except:
        raise
    finally:
        CLIARGS = initial_cliargs

# TODO: Add unit tests for all the functions in the Context module

# Generated at 2022-06-20 14:03:13.144358
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    class FakeOptions(dict):
        def __init__(self, options):
            super(FakeOptions, self).__init__(options)
            self._changed = False

        def __setitem__(self, key, value):
            self._changed = True
            super(FakeOptions, self).__setitem__(key, value)

        def set_changed(self, value):
            self._changed = value


# Generated at 2022-06-20 14:03:21.655038
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    # Test with empty CLIARGS
    assert cliargs_deferred_get('foo', default='default')(), 'default'
    assert cliargs_deferred_get('foo')(), None
    assert cliargs_deferred_get('foo', shallowcopy=True)(), None

    # Test with CLIARGS that contains a list, str, and other objects
    cli_args = {'answer': 42, 'base_opts': ['one', 'two'], 'dest': '/tmp', 'foo': 'bar'}
    _init_global_context(cli_args)
    # Test basic default and retreival
    assert cliargs_deferred_get('foo', default='default')(), 'bar'
    assert cliargs_deferred_get('foo')(), 'bar'
    assert cl

# Generated at 2022-06-20 14:03:57.871720
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for ``cliargs_deferred_get``"""

    # Test with CLIARGS as a CLIArgs
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIARGS['foo'] = {'foobar': True}
    assert cliargs_deferred_get('foo')() == {'foobar': True}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'foobar': True}

    # Test with CLIARGS as a GlobalCliArgs
    CLIARGS = GlobalCLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')

# Generated at 2022-06-20 14:04:05.993902
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import MutableMapping, Sequence
    from collections import OrderedDict, namedtuple
    from types import ModuleType

    # test cliargs_deferred_get
    cliargs_deferred_get('foo')()
    cliargs_deferred_get('foo')(shallowcopy=True)

    # test functions with args and kwargs
    cliargs_deferred_get('foo')('arg1', arg2='kwarg1', shallowcopy=True)
    cliargs_deferred_get('foo')('arg1', arg2='kwarg1')

    # test

# Generated at 2022-06-20 14:04:16.898033
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['a'] = 'A'
    assert cliargs_deferred_get('a')() == 'A'
    assert cliargs_deferred_get('b')() is None
    assert cliargs_deferred_get('b', default='B')() == 'B'
    assert cliargs_deferred_get('a', shallowcopy=True)() == 'A'

    CLIARGS['b'] = [1, 2, 3]
    assert cliargs_deferred_get('b')() == CLIARGS.get('b')
    assert cliargs_deferred_get('b', shallowcopy=True)() == CLIARGS.get('b')[:]

    CLIARGS['c'] = {'1': 1}
    assert cliargs_deferred_get('c')() == CLIARGS

# Generated at 2022-06-20 14:04:26.253635
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    mock_cliargs = CLIArgs({'bar': [1, 2, 3], 'baz': {'foo': 1}})
    global CLIARGS
    CLIARGS = mock_cliargs

    def test_cli_args(key, default, shallowcopy, expected):
        get_default = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)
        assert get_default() == expected

    test_cli_args('foo', 'default', False, 'default')
    test_cli_args('bar', 'default', False, [1, 2, 3])
    test_cli_args('bar', 'default', True, [1, 2, 3])
    test_cli_args('baz', 'default', False, {'foo': 1})

# Generated at 2022-06-20 14:04:35.073298
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def parse_args(**kwargs):
        """parses command line arguments.

        :arg value: The value to set the argument to.
        :arg default: The default value to set the argument to.
        :arg type: The type to cast the argument to.
        :arg choices: The choices that the argument is valid under.
        :arg positional: Whether this is a positional argument or a named argument.
        :arg env: The environment variable to read from.
        :arg action: The action that the argument should perform
        """
        class ParseResult:  # in place of argparse.Namespace
            def __init__(self, **kwargs):
                for k, v in kwargs.items():
                    setattr(self, k, v)
        args = ParseResult(**kwargs)