

# Generated at 2022-06-20 13:54:45.595224
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _assert_shallow_copy(key, default=None):
        cu = CLIARGS.user_vars.copy()
        cu[key] = 2
        assert 2 == cliargs_deferred_get(key)()
        assert 2 == cliargs_deferred_get(key, default=default)()
        assert default != cliargs_deferred_get(key, default=default)()
        assert {'a': 1} == cliargs_deferred_get(key, default={'a': 1})()
        assert 1 == cliargs_deferred_get(key, default={'a': 1})()['a']
        assert [1, 2, 3] == cliargs_deferred_get(key, default=[1, 2, 3])()

# Generated at 2022-06-20 13:54:51.833119
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # noqa: D103
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.utils.context_objects import GlobalCLIArgs, CLIArgs

    cli_args = CLIArgs({'ANSIBLE_DEBUG': True, 'ANSIBLE_NOCOLOR': False})
    class MyObj(object):
        def bar(self):
            return 'baz'

        foo = cliargs_deferred_get('ANSIBLE_NOCOLOR')
        quux = cliargs_deferred_get('ANSIBLE_DEBUG')
        quuz = cliargs_deferred_get('ANSIBLE_CALLBACK_WHITELIST')

# Generated at 2022-06-20 13:55:03.034327
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    cli_args = {
        'verbosity': 0,
    }
    global CLIARGS
    _init_global_context(cli_args)

    # Test the default value
    assert cliargs_deferred_get('verbosity')() == 0
    assert cliargs_deferred_get('some_key', default=5)() == 5

    # Test whether shallow copies are returned
    value = []
    assert cliargs_deferred_get('some_key', default=value, shallowcopy=False)() is value
    assert cliargs_deferred_get('some_key', default=value, shallowcopy=True)() is not value

# Generated at 2022-06-20 13:55:13.416898
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MyMapping(Mapping):
        def __init__(self, values):
            self._values = values

        def __getitem__(self, key):
            return self._values[key]

        def __len__(self):
            return len(self._values)

        def __iter__(self):
            return iter(self._values)

    my_dict = {'foo': 'bar'}
    my_list = ['one', 'two', 'three']

    def test_orig_type(func):
        assert func() == 'bar'
        my_dict['foo'] = 'not bar'
        assert func() == 'bar'

    def test_list_type(func):
        assert func() == ['one', 'two', 'three']
        my_list[1] = 'not two'
        assert func()

# Generated at 2022-06-20 13:55:25.339500
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy

    CLIARGS.update(dict(a=1, b=dict(c=3), d=set([4]), e=5))
    f = cliargs_deferred_get('a')
    assert callable(f)
    assert f() == CLIARGS['a']
    assert f() == CLIARGS.get('a')
    b = cliargs_deferred_get('b')
    c = cliargs_deferred_get('c')
    d = cliargs_deferred_get('d')
    e = cliargs_deferred_get('e')
    assert callable(c)
    assert c() is None
    assert callable(b)
    assert b() is CLIARGS.get('b')
    assert b() == dict(c=3)

# Generated at 2022-06-20 13:55:34.832177
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def get_cliargs_deferred_get_w_copy():
        return cliargs_deferred_get('foo', default='bar', shallowcopy=True)

    def get_cliargs_deferred_get_wo_copy():
        return cliargs_deferred_get('foo', default='bar', shallowcopy=False)

    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'foo'})

    assert get_cliargs_deferred_get_w_copy() == 'foo'
    assert get_cliargs_deferred_get_w_copy() == 'foo'
    assert get_cliargs_deferred_get_wo_copy() == 'foo'
    assert get_cliargs_deferred_get_wo_copy() == 'foo'

    CLIARGS = CLIArgs({})

    assert get

# Generated at 2022-06-20 13:55:45.038745
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import ContextObject, GlobalCLIArgs
    cli_args = {
        'first': 1,
        'second': [1, 2],
        'third': {'a': 1, 'b': 2},
        'fourth': {1, 2, 3},
    }
    # Test defaults
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options(cli_args)
    assert cliargs_deferred_get('no_such_key') is None
    assert cliargs_deferred_get('no_such_key', 'default_value') == 'default_value'

    class MyContext(ContextObject):
        my_first = cliargs_deferred_get('first')
        my_second = cliargs_deferred_get('second')
        my

# Generated at 2022-06-20 13:55:52.703147
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Test default value
    cliargs = CLIArgs({})
    CLIARGS = cliargs
    f = cliargs_deferred_get('newkey', 'defaultvalue')
    assert f() == 'defaultvalue'

    # Test explicit value
    cliargs.newkey = 'newvalue'
    assert f() == 'newvalue'

    # Test shallow copy
    cliargs.newkey2 = [1, 2]
    assert cliargs.newkey2 is f() is not f(shallowcopy=True)

# Generated at 2022-06-20 13:55:59.550263
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import sys
    import unittest
    import unittest.mock

    class cliargs_deferred_get_TestCase(unittest.TestCase):
        def test_cliarg_lookup(self):
            self.assertEqual(cliargs_deferred_get('no_default')(), None)
            self.assertEqual(cliargs_deferred_get('bad_default')(), 'default')
            self.assertEqual(cliargs_deferred_get('bad_default', default=42)(), 42)
            with unittest.mock.patch.object(CLIARGS, '__getitem__') as cli_args_getitem:
                cli_args_getitem.return_value = 'value'

# Generated at 2022-06-20 13:56:08.950529
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(DEFAULT_PASSWORD=None, DEFAULT_MODULE_PATH='/foo'))
    assert cliargs_deferred_get('DEFAULT_PASSWORD')().get('DEFAULT_MODULE_PATH') == '/foo'
    assert cliargs_deferred_get('DEFAULT_PASSWORD', shallowcopy=True)() == dict(DEFAULT_MODULE_PATH='/foo')
    assert cliargs_deferred_get('DEFAULT_PASSWORD', default='bar')() == 'bar'
    assert cliargs_deferred_get('DEFAULT_PASSWORD', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-20 13:56:23.218939
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Verify the ``CLIARGS`` are properly retrieved and shallow copies are performed when the
    ``shallowcopy`` parameter is set
    """
    global CLIARGS
    cli_args = [{'name': 'ansible'}, {'version': 1, 'messaging_type': 'jms'}]
    _init_global_context(cli_args)
    copy_value = ['foo']
    assert 'version' in CLIARGS and 'messaging_type' in CLIARGS and 'name' in CLIARGS and 'copy_value' in CLIARGS

    # Verify the normal get functionality is performed
    assert 'name' in CLIARGS and CLIARGS['name'] == 'ansible'

    # Verify the default is returned when the key doesn't exist
    assert 'unknown_key' in CLIARGS and CLIARGS

# Generated at 2022-06-20 13:56:33.466200
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set

    class Dummy:
        @staticmethod
        def _get_my_key():
            return CLIARGS

        my_key = property(fget=cliargs_deferred_get('my_key'))

    _init_global_context({'my_key': 'value'})

    # When the global CLIARGS is already set, we should get the value from CLIARGS
    d = Dummy()
    assert d.my_key == 'value'

    # If the global CLIARGS is changed and isn't set, we should get the default
    CLIARGS = CLIArgs({})
    assert d.my_key is None

    # If the global CLIARGS is changed and is set, we should get the value from CLIARGS
    CLI

# Generated at 2022-06-20 13:56:44.959239
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import ContextObject, CliArgs

    # Using a secondary context to test the actual function
    context = CliArgs({'a': 1, 'b': 2})

    # Test a key with a value
    getter_a = cliargs_deferred_get('a')
    assert getter_a() == 1

    # Test a key without value
    getter_c = cliargs_deferred_get('c', default=3)
    assert getter_c() == 3

    # Test a key without value and without default
    getter_d = cliargs_deferred_get('d')
    assert getter_d() is None

    # Test a

# Generated at 2022-06-20 13:56:55.958803
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence

    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('bar', 'baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('bar', shallowcopy=True)() == None

    CLIARGS['abc'] = ['abc', 'def', 'ghi']
    assert is_sequence(cliargs_deferred_get('abc')())

# Generated at 2022-06-20 13:57:03.291607
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        cl_args = CLIARGS
    except NameError:
        pass
    else:
        raise AssertionError("cliargs should not be defined")

    # You can define it temporarily
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo')() == None
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo')() == 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # But if you redefine it, it should continue to work with the new one
    CLIARGS = CLIArgs({'foo': 'moo', 'bar': 'moo'})


# Generated at 2022-06-20 13:57:10.851134
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def get_cliargs(shallow):
        class CLIARGS:
            def __init__(self, value):
                self.value = value

            def get(self, key, default=None):
                return self.value

        return cliargs_deferred_get('key', default=None, shallowcopy=shallow)(None)

    def check(shallow):
        cliargs = CLIARGS(['a', 'b', 'c'])
        assert get_cliargs(shallow)() is cliargs

    check(False)
    check(True)

    cliargs = CLIARGS({'a': 1, 'b': 2})
    assert get_cliargs(False)() is cliargs
    assert get_cliargs(True)() is not cliargs

# Generated at 2022-06-20 13:57:20.745734
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.config.manager import ConfigManager
    from ansible.config.data import ConfigData

    # This will be the value that is returned when the inner function is called
    value = ConfigData()
    value_copy = ConfigData()
    value_shallowcopy = ConfigData()
    value_shallowcopy.data = value.data

    # This is the data that we'll load into the CliArgs object.
    cli_args = ConfigManager()
    cli_args.data = {'key': value}
    _init_global_context(cli_args)

    # Test that we get the value
    assert cliargs_deferred_get('key')() is value

    # Test that we get the default
    assert cliargs_deferred_get('key_default', default=value_copy)() is value_copy



# Generated at 2022-06-20 13:57:26.015014
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.context_objects import CliArgs

    cfg = CliArgs({'foo': 'bar', 'baz': [1, 2], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2}})
    assert cliargs_deferred_get('foo')(cfg) == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)(cfg) == 'bar'
    assert cliargs_deferred_get('baz')(cfg) == [1, 2]
    assert cliargs_deferred_get('baz', shallowcopy=True)(cfg) == [1, 2]
    assert cliargs_deferred_get('qux')(cfg) == {'a': 1, 'b': 2}
    assert cl

# Generated at 2022-06-20 13:57:34.892926
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_test = CLIArgs({'test': 'value'})
    # This is a bit of a hack but since cliargs_deferred_get isn't a closure
    # over a singleton, we can swap the singleton out for a test version
    global CLIARGS
    CLIARGS = cliargs_test

    value = cliargs_deferred_get('test', default=None, shallowcopy=False)()
    assert value == 'value'

    value = cliargs_deferred_get('foo', default='bar', shallowcopy=False)()
    assert value == 'bar'

    value = cliargs_deferred_get('test', default=None, shallowcopy=True)()
    assert value == 'value'


# Generated at 2022-06-20 13:57:45.627313
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Test for default
    CLIARGS = CLIArgs({'some_key': 'some_value'})
    assert cliargs_deferred_get('other_key', default='default_value') == 'default_value'
    # Test for cliargs_deferred_get with no shallow copy
    assert cliargs_deferred_get('some_key') == 'some_value'
    # Test for cliargs_deferred_get with shallow copy
    assert cliargs_deferred_get('some_key', shallowcopy=True) == 'some_value'
    # Test for cliargs_deferred_get with no shallow copy that is a list
    CLIARGS = CLIArgs({'some_key': ['some_value']})

# Generated at 2022-06-20 13:57:59.035317
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Global variable should be empty
    assert CLIARGS._option_defaults == {}
    assert CLIARGS._options == {}
    assert CLIARGS._runtime_defaults == {}

    # Test default value
    default_callable = cliargs_deferred_get('foo', 'bar')
    assert default_callable() == 'bar'

    # Test dunder value
    dunder_callable = cliargs_deferred_get('__foo__')
    assert dunder_callable() == CLIARGS.__option_defaults__['__foo__']

    # Test regular value
    cliargs_deferred_get.options = {'foo': 'bar'}
    foo_callable = cliargs_deferred_get('foo')
    assert foo_callable() == 'bar'

    # Test list shallowcopy

# Generated at 2022-06-20 13:58:09.457158
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CliArgs(dict):
        def __getattr__(self, key):
            return self.get(key)
        def __setattr__(self, key, value):
            self[key] = value

    cliargs = CliArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 'e'}})
    cliargs_deferred = cliargs_deferred_get
    assert cliargs_deferred('a')() == cliargs.a
    assert cliargs_deferred('a', shallowcopy=True)() == cliargs.a
    assert type(cliargs_deferred('a', shallowcopy=True)()) == type(cliargs.a)
    assert cliargs_deferred('b')() == cliargs.b
    assert cli

# Generated at 2022-06-20 13:58:17.533749
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Initialize the global context objects
    _init_global_context({'foo': 'bar'})

    # First test that initializing CLIARGS to something that isn't a CliArgs object
    # doesn't break the closure
    assert cliargs_deferred_get('foo') == 'bar'

    # Test that we get the default
    assert cliargs_deferred_get('nonexistent', default='default') == 'default'

    # Test that we get the value
    assert cliargs_deferred_get('foo') == 'bar'

# Generated at 2022-06-20 13:58:23.056940
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCLIArgs:
        def get(self, key, default=None, shallowcopy=False):
            return "value"

    global CLIARGS

    CLIARGS = TestCLIArgs()
    assert "value" == cliargs_deferred_get("foo")()
    assert "value" == cliargs_deferred_get("foo", default="def")()

# Generated at 2022-06-20 13:58:32.089940
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=too-many-locals
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSet
    from ansible.module_utils.common.text.converters import to_text

    class MyGlobalCLIArgs(GlobalCLIArgs):
        def __init__(self, data=None, aliases=None, default=None):
            super(MyGlobalCLIArgs, self).__init__(data, aliases, default)
            self.default = default

        def get(self, key, default=None):
            default = default if default is not None else self.default
            return super(MyGlobalCLIArgs, self).get(key, default)

    # Test when cliargs is

# Generated at 2022-06-20 13:58:43.369739
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # type: () -> None
    def _get(key):
        # type: (str) -> (str, str)
        """Helper function to return the value of the closure and the default value"""
        closure = cliargs_deferred_get(key)
        value = closure()
        return value, default
    default = 'default'
    # Closure that doesn't actually exist
    assert _get('foo') == (default, default)
    assert _get('foo') == (default, default)
    # Closure with a single value
    CLIARGS['foo'] = 'bar'
    assert _get('foo') == ('bar', 'bar')
    # Closure with a list value
    assert _get('foo') == ('bar', 'bar')
    CLIARGS['foo'] = ['bar']

# Generated at 2022-06-20 13:58:54.709794
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    # Note: This will return an empty dictionary when no args are given
    cliargs = {'foo': 'bar', 'baz': ['list', 'of', 'things']}

    CLIARGS.replace(cliargs)
    # Check that we won't get a copy of a non-mutable
    assert cliargs_deferred_get('foo')() is cliargs['foo']
    # Check that we won't get a copy of a non-mutable
    assert cliargs_deferred_get('foo', 'default')() is cliargs['foo']
    # Check that we will get a copy of a non-mutable
    assert cliargs_deferred_get('foo', shallowcopy=True)() == cliargs['foo']
    # Check that we get the default value if the key isn't in cli

# Generated at 2022-06-20 13:59:06.071090
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # noqa: D103
    """Performs a basic unit test for ``cliargs_deferred_get``"""
    from ansible.parsing import vault
    from ansible.utils.context_objects import GlobalCLIArgs

    # test inner function
    from ansible.utils.context import cliargs_deferred_get
    cliargs_deferred_get(None)

    # test whole chain
    cli_args = {'ask_vault_pass': False, 'vault_password_file': None,
                'new_vault_password_file': None}
    vault.VaultLib = object()
    Vault = object()
    vault._get_vault_manager = lambda *args, **kwargs: Vault
    _init_global_context(cli_args)
    get_vault_manager = cliargs

# Generated at 2022-06-20 13:59:13.968027
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class GlobalCLIArgsTests(unittest.TestCase):

        def setUp(self):
            import ansible.utils.context_objects
            self.old_cliargs = ansible.utils.context_objects.CLIARGS
            ansible.utils.context_objects.CLIARGS = GlobalCLIArgs({'a': 1, 'b': 'foo'})

        def tearDown(self):
            import ansible.utils.context_objects
            ansible.utils.context_objects.CLIARGS = self.old_cliargs

        def test_cliargs_deferred_get_default(self):
            self.assertEqual(cliargs_deferred_get('a', 'foo')(), 1)

        def test_cliargs_deferred_get_shallow_copy(self):
            import sys
           

# Generated at 2022-06-20 13:59:22.861906
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=missing-docstring
    global CLIARGS  # pylint: disable=global-statement
    CLIARGS = CLIArgs({'key': 'baz'})
    assert cliargs_deferred_get('key')() == 'baz'
    assert cliargs_deferred_get('key', default='asdf')() == 'baz'
    assert cliargs_deferred_get('key2', default='asdf')() == 'asdf'
    CLIARGS = CLIArgs({'key2': 'baz'})
    assert cliargs_deferred_get('key2')() == 'baz'
    assert cliargs_deferred_get('key2', default='asdf')() == 'baz'

# Generated at 2022-06-20 13:59:41.389954
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('__not_a_key__')() is None, "Should default to None when key not present"
    assert cliargs_deferred_get('__not_a_key__', 'default')() == 'default', \
        "Should allow specifying a custom default when key not present"
    global CLIARGS
    orig_cliargs = CLIARGS

# Generated at 2022-06-20 13:59:52.134323
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs

    # Functionality of accessing and getting from value stored in context
    _init_global_context(dict(a=1, b=dict(c=1)))
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == dict(c=1)
    assert cliargs_deferred_get('c', default=2)() == 2
    assert cliargs_deferred_get('c')() is None
    assert cliargs_deferred_get('a')() == 1

    # Functionality of accessing and getting from value as a default
    _init_global_context(dict(a=1, b=dict(c=1)))

# Generated at 2022-06-20 14:00:04.250072
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    def inner():
        return set([1, 2, 3])
    assert cliargs_deferred_get('test')(dict(test=inner))() is inner()
    assert cliargs_deferred_get('test')(dict(test={'a': 'b'})) == {'a': 'b'}
    assert cliargs_deferred_get('test')(dict(test='abc')) == 'abc'
    assert cliargs_deferred_get('test', shallowcopy=True)(dict(test=[1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-20 14:00:12.521065
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    _init_global_context({'one': 1})
    assert cliargs_deferred_get('one')() == 1
    assert cliargs_deferred_get('one', shallowcopy=True)() == 1
    assert cliargs_deferred_get('two')() is None
    assert cliargs_deferred_get('two', default=2)() == 2
    assert cliargs_deferred_get('two', default=2, shallowcopy=True)() == 2
    assert cliargs_deferred_get('two', shallowcopy=True)() is None
    CLIARGS['one'] = 'one string'
    assert cliargs_deferred_get('one')() == 'one string'

# Generated at 2022-06-20 14:00:20.262819
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = CLIArgs({'foo': 'bar'})

    # Simple get, no shalowcopy
    assert cliargs_deferred_get('foo')() == 'bar'

    # Get with default value
    assert cliargs_deferred_get('does_not_exist', 'default')() == 'default'

    # List, shallowcopy
    cli_args['foo'] = ['a', 'b', 'c']
    foo = cliargs_deferred_get('foo', shallowcopy=True)()
    assert foo == ['a', 'b', 'c']
    foo[0] = 'd'
    assert foo == ['d', 'b', 'c']
    assert cli_args['foo'] == ['a', 'b', 'c']

    # Set, shallowcopy

# Generated at 2022-06-20 14:00:32.121727
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'one': 1,
                'two': 2,
                'seq': [1, 2, 3],
                'map': {'a': 1, 'b': 2, 'c': 3}}

    # Ensure the function works with the empty args
    _init_global_context({})
    assert cliargs_deferred_get('one')() is None

    # Make sure that we can use the function in the context of an instantiated ``CLIARGS``
    _init_global_context(cli_args)
    assert cliargs_deferred_get('one')() is 1
    assert cliargs_deferred_get('two')() is 2
    assert cliargs_deferred_get('three')() is None
    assert cliargs_deferred_get('three', default=3)() is 3

# Generated at 2022-06-20 14:00:43.676309
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Deferred gets should fail without an actual cli_args
    assert cliargs_deferred_get('test_key') == None

    # Create the GlobalCLIArgs but don't initialize the singleton
    cli_args = GlobalCLIArgs.from_options({'test_key': 'test_value'})
    assert cliargs_deferred_get('test_key') == 'test_value'

    # Initialize from the dict
    _init_global_context({'test_key': 'test_value2'})
    assert cliargs_deferred_get('test_key') == 'test_value2'
    del CLIARGS

    # Initialize from the object properly
    CLIARGS = cli_args

# Generated at 2022-06-20 14:00:55.194267
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CliArgs(Mapping):
        def __getitem__(self, key):
            return self.get(key, None)

        def __iter__(self):
            return iter({'bar': 'baz', 'foo': 'bar', 'default': 'value'})

        def __len__(self):
            return len(self.keys())

        def get(self, key, default=None):
            return {'bar': 'baz', 'foo': 'bar', 'default': 'value'}[key]

    global CLIARGS
    ca = CliArgs()
    CLIARGS = ca
    assert cliargs_deferred_get('default')('value') == 'value'
    assert cliargs_deferred_get('default')() == 'value'

# Generated at 2022-06-20 14:01:05.440267
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_id = id(CLIARGS)
    cliargs_no_copy_id = id(cliargs_deferred_get('connection', 'ssh')())
    cliargs_copy_id = id(cliargs_deferred_get('become', 'false', shallowcopy=True)())
    assert cliargs_id == cliargs_no_copy_id
    assert cliargs_id != cliargs_copy_id
    # Verify that the values are still the same even if they have a different id()
    assert CLIARGS.connection == cliargs_deferred_get('connection', 'ssh')()
    assert CLIARGS.become == cliargs_deferred_get('become', 'false', shallowcopy=True)()

# Generated at 2022-06-20 14:01:15.831607
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    initial_cliargs = CLIARGS
    CLIARGS = CLIArgs({'a': 'a_val', 'b': 'b_val', 'c': ['a', 'b', 'c']})

# Generated at 2022-06-20 14:01:43.963449
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # We test against a real `CLIARGS` object
    # Set up
    cliargs_keys = ['module_path', 'roles_path', 'private_key_file']
    cliargs_values = [
        ['./modules', '/etc/ansible/modules', '/usr/share/ansible/modules'],
        ['./roles', '/etc/ansible/roles', '/usr/share/ansible/roles'],
        '/home/user/.ssh/id_rsa',
    ]
    cliargs_dict = dict(zip(cliargs_keys, cliargs_values))
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options(cliargs_dict)

    # Test normal get
    for key in cliargs_keys:
        assert _cliargs_

# Generated at 2022-06-20 14:01:52.817132
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'first': 'one', 'second': 'two'})

    assert cliargs_deferred_get('first')() == 'one'
    assert cliargs_deferred_get('third')() is None
    assert cliargs_deferred_get('third', default='three')() == 'three'

    CLIARGS = CLIArgs({'first': 'one', 'second': 'two', 'third': 'three'})

    assert cliargs_deferred_get('first')() == 'one'
    assert cliargs_deferred_get('third')() == 'three'

# Generated at 2022-06-20 14:02:03.299657
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for ``cliargs_deferred_get``

    This test confirms that the closure over the ``CLIARGS`` works properly with the
    ``CLIARGS`` global being replaced.
    """
    # Test getting the default value
    assert cliargs_deferred_get('foobar', default='baz')() == 'baz'
    # Test getting an existing value
    assert cliargs_deferred_get('verbosity', default=0)() == 0
    # Test changing ``CLIARGS`` so that we get a different value
    global CLIARGS
    old_cliargs = CLIARGS
    try:
        CLIARGS = CLIArgs({'verbosity': 5})
        assert cliargs_deferred_get('verbosity', default=0)() == 5
    finally:
        CLIARGS = old

# Generated at 2022-06-20 14:02:11.373180
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=wildcard-import
    # pylint: disable=unused-wildcard-import
    # pylint: disable=redefined-outer-name

    # This test requires the following imports but they are not used directly
    # in this test to avoid circular imports
    from ansible.cli.doc import AnsibleCLI
    from ansible.utils.context_objects import GlobalCLIArgs

    class FakeCLIArgs(GlobalCLIArgs):
        def __init__(self, *args, **kwargs):
            super(FakeCLIArgs, self).__init__(*args, **kwargs)
            # This is a hack to get the args to work in the test context
            self.args = self._options


# Generated at 2022-06-20 14:02:21.905641
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update(dict(
        foo_seq=['a', 'b', 'c'],
        foo_set=set(['a', 'b', 'c']),
        foo_dict=dict(a=1, b=2, c=3),
        foo_noncopyable=123,
    ))
    assert cliargs_deferred_get('foo_seq')() == ['a', 'b', 'c']
    assert cliargs_deferred_get('foo_seq', shallowcopy=True)() == ['a', 'b', 'c']
    assert cliargs_deferred_get('foo_set')() == set(['a', 'b', 'c'])

# Generated at 2022-06-20 14:02:24.333878
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar', 'baz': [1, 2, 3]}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')(shallowcopy=True) == [1, 2, 3]

# Generated at 2022-06-20 14:02:33.892459
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {
        'roles_path': [
            'role1',
            'role2',
        ],
        'inventory': '/fake/path/to/inventory',
    }
    _init_global_context(cli_args)

    # Sequence
    assert cliargs_deferred_get('roles_path', shallowcopy=True)() == cli_args['roles_path']
    assert cliargs_deferred_get('roles_path', shallowcopy=True)() is not cli_args['roles_path']

    # Not a collection
    assert cliargs_deferred_get('inventory')() is cli_args['inventory']
    assert cliargs_deferred_get('inventory', shallowcopy=True)() is cli_args['inventory']

    # Add a new key


# Generated at 2022-06-20 14:02:41.640810
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # In Python 3, the default value of a kwarg is evaluated at definition time.
    # This means that if the default is a mutable value, or a function call,
    # it will be evaluated once and stored forever. This is different from what
    # happens in Python 2, where the default value is evaluated each time the
    # function is called.
    # For more information, see PEP-0448, specifically the Python 2 behavior section:
    # https://www.python.org/dev/peps/pep-0448/#python-2-behavior
    #
    # As a result, if we want to create a function that has a mutable default value
    # in Python 3, we have to wrap default in a function, as shown in the class
    # below.
    class Mutable(object):
        def __init__(self):
            self

# Generated at 2022-06-20 14:02:52.940836
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    class FakeArgs(Mapping):
        """Simple test mapping class that throws NotImplementedError if you try to access something"""
        def __getitem__(self, key):
            raise NotImplementedError(key)
        def __iter__(self):
            raise NotImplementedError()
        def __len__(self):
            raise NotImplementedError()
        def copy(self):
            raise NotImplementedError()
    fake_args = FakeArgs()
    default = 'the default value'
    result = cliargs_deferred_get('fake key', default=default)
    assert result == default
    result = cliargs_deferred_get('fake key', default=default, shallowcopy=True)
    assert result == default
    result = cliargs

# Generated at 2022-06-20 14:03:04.185539
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test deferred getting of CLIARGS' key"""
    from ansible.module_utils.common.collections import is_sequence, Mapping, Set

    # test using a class that can be shallow-copied so that we can check if
    # the closure is returning a shallow copy
    class A(object):
        def __init__(self):
            self.value = 5
        def __getitem__(self, key):
            if isinstance(key, (slice, int)):
                return self.value
            raise KeyError()
        def __setitem__(self, key, value):
            self.value = value

    # Test the closure with a sequence type
    sequence = [1,2,3]
    cliargs_deferred_get_sequence = cliargs_deferred_get('test')
    assert cliargs_

# Generated at 2022-06-20 14:03:46.597551
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = CLIArgs({'one': ['a', 'b', 'c'], 'two': {'a': 1}, 'three': 1})
    global CLIARGS
    CLIARGS = args

    assert cliargs_deferred_get('one', shallowcopy=False)() == ['a', 'b', 'c']
    assert cliargs_deferred_get('one', shallowcopy=True)() == ['a', 'b', 'c']
    assert cliargs_deferred_get('two', shallowcopy=False)() == {'a': 1}
    assert cliargs_deferred_get('two', shallowcopy=True)() == {'a': 1}
    assert cliargs_deferred_get('three', shallowcopy=False)() == 1

# Generated at 2022-06-20 14:03:57.871849
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test Deferred get with no shallow copy
    inner = cliargs_deferred_get('a', True)
    assert inner() is True

    # Test Deferred get with shallow copy
    my_list = ['a']
    CLIARGS['a'] = my_list
    inner = cliargs_deferred_get('a',True, True)
    assert inner() == my_list
    assert inner() is not my_list

    # Test Deferred get with shallow copy and non-default value
    my_list = ['a']
    CLIARGS['a'] = my_list
    inner = cliargs_deferred_get('a', False, True)
    assert inner() == my_list
    assert inner() is not my_list

    # Test Deferred get with no shallow copy and non-default value

# Generated at 2022-06-20 14:04:03.899540
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the deferred cliargs_deferred_get function"""
    global CLIARGS

    cli_args = {
        'foo': 'foo',
        'bar': [1, 2, 3],
        'baz': {'a': 'a', 'b': 'b', 'c': 'c'},
        'bat': {'a', 'b', 'c'},
        'bag': 1,
        'bap': 2,
    }
    _init_global_context(cli_args)
    cli_args['foo'] = 'foo2'
    cli_args['bar'].append(4)
    cli_args['baz']['c'] = 'd'
    cli_args['bat'].add('d')


# Generated at 2022-06-20 14:04:15.062544
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    CLIARGS.update({'foo': 1, 'bar': None, 'baz': 'original string'})
    assert cliargs_deferred_get('foo')() == 1
    assert cliargs_deferred_get('foo', default=2)() == 1
    assert cliargs_deferred_get('nonexistent', default=2)() == 2
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', default=2)() is None
    assert cliargs_deferred_get('baz')() == 'original string'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == 'original string'

    # Check that our copies are different from the original
    CLIARGS['foo'] = 2
    assert cli

# Generated at 2022-06-20 14:04:25.007743
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    with pytest.raises(RuntimeError):
        cliargs_deferred_get('bogus key')()

    CLIARGS.clear()
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')(), 'bar'
    assert cliargs_deferred_get('foo', default='baz')(), 'bar'
    assert cliargs_deferred_get('bogus key', default='baz')(), 'baz'
    assert cliargs_deferred_get('bogus key', default='baz', shallowcopy=True)(), 'baz'

    CLIARGS['baz'] = ['a', 'b', 'c']

# Generated at 2022-06-20 14:04:34.252972
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # From FieldAttribute->__init__
    global CLIARGS