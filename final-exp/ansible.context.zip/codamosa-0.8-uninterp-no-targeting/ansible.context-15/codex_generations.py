

# Generated at 2022-06-20 13:54:44.783372
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs

    def validate(key, expected):
        args_map = {"argument_spec": {"key": {"type": "str", "default": "default"}}}
        args = GlobalCLIArgs._init_module_context(args_map, {"key": key})
        assert cliargs_deferred_get(key)(args) == expected
        assert cliargs_deferred_get(key, shallowcopy=True)(args) == expected

    def validate_sequence(key, expected):
        args_map = {"argument_spec": {"key": {"type": "list", "default": ["list_default"]}}}
        args = GlobalCLIArgs._init_module_context(args_map, {"key": key})
        assert cliargs_deferred_get(key)(args) == expected


# Generated at 2022-06-20 13:54:54.118472
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test deferred args"""
    _init_global_context({})
    assert CLIARGS == {}

    assert cliargs_deferred_get('default')(None) == cliargs_deferred_get('default')(None)
    assert cliargs_deferred_get('default')(None) == cliargs_deferred_get('default')(None)
    assert cliargs_deferred_get('default')(None) == cliargs_deferred_get('default')(None)

    assert cliargs_deferred_get('default', default=True)(None) == cliargs_deferred_get('default', default=True)(None)
    assert cliargs_deferred_get('default', default=True)(None) == cliargs_deferred_get('default', default=True)(None)

# Generated at 2022-06-20 13:55:00.721502
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Normally global module variable are not tested.  The CLIARGS variable should
    # be unit tested to ensure our approximation of the global variable is functioning
    # as we expect.
    global CLIARGS

    # We cannot test that it fails if the variable is None because
    # the function is just a wrapper around the CLIARGS variable
    # The function should normally throw AttributeError if called when
    # CLIARGS is None.  So we test that it succeeds when the variable exists
    # and contains the value we are expecting
    cliargs = {
        'foo': ['bar'],
        'deepcopy': [1, 2, 3],
        'shallowcopy': {'a': 1, 'b': 2, 'c': 3},
    }
    CLIARGS = CLIArgs(cliargs)

    foo = cliargs_deferred_get

# Generated at 2022-06-20 13:55:08.344473
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_inner():
        assert CLIARGS.get('foo', default='hi') == 'hi'
        assert cliargs_deferred_get('foo', default='hi')() == 'hi'
        assert cliargs_deferred_get('foo', default='hi', shallowcopy=True)() == 'hi'
        CLIARGS['foo'] = 'bar'
        assert cliargs_deferred_get('foo', default='hi')() == 'bar'
        assert cliargs_deferred_get('foo', default='hi', shallowcopy=True)() == 'bar'

    CLIARGS = CLIArgs({})
    test_inner()

    CLIARGS = GlobalCLIArgs.from_options(dict(foo='bar'))
    test_inner()

# Generated at 2022-06-20 13:55:19.233052
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test normal get
    CLIARGS['foo'] = 'bar'
    assert 'bar' == cliargs_deferred_get('foo')()
    # Test default get
    assert 'baz' == cliargs_deferred_get('foo', default='baz')()
    del CLIARGS['foo']
    # Test default get no default
    assert None is cliargs_deferred_get('foo')()
    # Test shallow copy behavior
    CLIARGS['foo'] = [1, 2, 3]
    # Make sure to retain the reference as we don't clone mutable types
    orig_value = CLIARGS['foo']
    assert orig_value is cliargs_deferred_get('foo')()
    assert orig_value is cliargs_deferred_get('foo', shallowcopy=True)()
    #

# Generated at 2022-06-20 13:55:30.728799
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Single stack case
    CLIARGS['verbosity'] = 10
    assert cliargs_deferred_get('verbosity')() == 10

    # Default supplied
    CLIARGS['verbosity'] = 10
    assert cliargs_deferred_get('nonsense', 'foo')() == 'foo'

    # Nested stack
    CLIARGS['verbosity'] = 10
    assert cliargs_deferred_get('verbosity')() == 10

    # Default supplied
    CLIARGS['verbosity'] = 10
    assert cliargs_deferred_get('nonsense', 'foo')() == 'foo'

    # List shallow copy
    l = [1, 2, 3]
    CLIARGS['vars'] = l
    result = cliargs_deferred_get('vars', shallowcopy=True)()
   

# Generated at 2022-06-20 13:55:41.819714
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.utils.context_objects import CliArgs
    cliargs = Cliargs({'foo': {'bar': {'baz': 'test_value'}}})
    assert cliargs_deferred_get('foo.bar.baz', default=None)() == 'test_value'
    assert cliargs_deferred_get('foo.bar.baz', default='default_value')() == 'test_value'
    assert cliargs_deferred_get('foo.qux', default='default_value')() == 'default_value'
    assert cliargs_deferred_get('foo.qux.qax', default='default_value')() == 'default_value'

# Generated at 2022-06-20 13:55:52.793866
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Foo(object):
        pass
    data = {'dict': {'a': 1},
            'list': [1, 2, 3],
            'obj': Foo(),
            }
    CLIARGS['dict'] = {'a': 1}
    CLIARGS['list'] = [1, 2, 3]
    CLIARGS['obj'] = Foo()
    for key, expected in data.items():
        assert cliargs_deferred_get(key)() == expected
        if isinstance(expected, Mapping):
            assert cliargs_deferred_get(key)(shallowcopy=True) != expected
        else:
            assert cliargs_deferred_get(key)(shallowcopy=True) == expected
    assert cliargs_deferred_get('missing', 5)() == 5
    assert cliargs

# Generated at 2022-06-20 13:55:56.811827
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-20 13:56:08.492445
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.six import StringIO
    from ansible.cli.arguments import options as cli_args
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.module_utils.common.text.converters import to_bytes

    # The object we'll be using for cliargs_deferred_get
    CLIARGS = GlobalCLIArgs.from_options({})

    # Check that it works when called with an uninitialized CLIArgs
    assert cliargs_deferred_get('ANSIBLE_ASK_PASS', default=True)() is True

    # Check that getting a list and a dict shallow copies
    cli_args.command = 'ansible'
    cli_args.connection = 'ssh'
    cli_args.module_path = ['/foo']
    cl

# Generated at 2022-06-20 13:56:21.960356
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get

    Ensure that cliargs_deferred_get works with:
    * plain value
    * mutable value
    * nested mutable value
    * with shallowcopy
    * with shallowcopy and nested mutable value
    """
    from copy import copy
    mutable_value = {'key': 'value'}
    nested_mutable_value = {'key': {'key': 'value', 'key2': {'key': 'value'}}, 'key2': {'key': 'value'}}
    result = cliargs_deferred_get('key', default=mutable_value)()
    assert result == mutable_value
    result = cliargs_deferred_get('key', default=[mutable_value])()
    assert result == [mutable_value]


# Generated at 2022-06-20 13:56:30.087367
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cli_args = CLIArgs({'verbosity': 4})
    _init_global_context(cli_args)
    assert cliargs_deferred_get('verbosity') == 4
    verbosity = cliargs_deferred_get('verbosity', default=0)
    assert verbosity() == 4
    assert verbosity() == 4

    cli_args = CLIArgs({'verbosity': 5})
    _init_global_context(cli_args)
    assert verbosity() == 5
    assert verbosity() == 5

# Generated at 2022-06-20 13:56:37.848290
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    testargs = {'host_pattern': 'test1',
                'test_dict': {'test2': 'test3'},
                'test_set': {'test4'},
                'test_list': ['test5']}
    initial_cliargs = CLIARGS

# Generated at 2022-06-20 13:56:48.783004
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({'hello': 'world'})

    # Test basic access
    assert 'world' == cliargs_deferred_get('hello')()
    # Test default access
    assert 'foo' == cliargs_deferred_get('goodbye', default='foo')()
    # Test with a shallow copy
    assert ['foo'] == cliargs_deferred_get('bar', shallowcopy=True, default=['foo'])()

    CLIARGS = CLIArgs({'bar': ['foo'], 'baz': {'foo': 'bar'}, 'boing': set(['foo'])})

    # Test self-referential shallow copy
    foo = {'bar': {'baz': 'foo'}}
    CLIARGS['foo'] = foo
    assert foo is not cliargs

# Generated at 2022-06-20 13:56:58.800775
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'a': [1, 2, 3]}
    _init_global_context(cli_args)
    assert CLIARGS['a'] == [1, 2, 3]

    f = cliargs_deferred_get('a')
    assert f() == [1, 2, 3]

    b = cliargs_deferred_get('b', default=[])
    assert b() == []

    c = cliargs_deferred_get('c', default=None)
    assert c() is None

    d = cliargs_deferred_get('a', shallowcopy=True)
    assert d() == [1, 2, 3]

    # Remove the singleton so that we can replace it
    del CLIARGS


# Generated at 2022-06-20 13:57:03.109157
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs  # Avoid circular import
    cliargs = CliArgs({'hello': 'world'})
    inner = cliargs_deferred_get('hello')
    assert inner() == 'world'

# Generated at 2022-06-20 13:57:08.922594
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    def _test(container_type, container, expected):
        _init_global_context(cli_args=container)

        getter = cliargs_deferred_get(key='my_key', shallowcopy=True)
        assert expected == getter()

        getter = cliargs_deferred_get(key='my_key', shallowcopy=False)
        assert container == getter()

    _test(Mapping, {'my_key': {'foo': 'bar'}}, {'foo': 'bar'})
    _test(Sequence, ['my_key', {'foo': 'bar'}], {'foo': 'bar'})

# Generated at 2022-06-20 13:57:19.709957
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_funct(function, expected):
        """Inner function to test getter"""
        cli_args = {'foo': 'bar', 'empty_dict': {}, 'empty_list': [], 'empty_set': set()}
        _init_global_context(cli_args)
        assert expected == function()

    # Test with no key
    test_funct(lambda: cliargs_deferred_get('foobar', 'default')(), 'default')

    # Test with key and no shallow copy
    test_funct(lambda: cliargs_deferred_get('foo', 'default')(), 'bar')

    # Test with key and shallow copy for string
    test_funct(lambda: cliargs_deferred_get('foo', 'default', shallowcopy=True)(), 'bar')

    # Test

# Generated at 2022-06-20 13:57:30.740492
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # test with empty cliargs
    CLIARGS = CLIArgs({})

    get_now = cliargs_deferred_get('foo', default=42)
    assert get_now() == 42
    CLIARGS = CLIArgs({'foo': 100})
    get_later = cliargs_deferred_get('foo')
    assert get_now() == 100
    assert get_later() == 100

    # test immutable type
    CLIARGS['bar'] = 'bar'
    get_bar = cliargs_deferred_get('bar')
    assert get_bar() == 'bar'
    assert get_bar() is CLIARGS['bar']

    # test mutable shallow copy
    CLIARGS['copy_list'] = [1, 2, 3]
    get_copy_list = cli

# Generated at 2022-06-20 13:57:42.035595
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('not_yet_set')() is None
    assert cliargs_deferred_get('not_yet_set', default='default')() == 'default'
    CLIARGS = CLIArgs({'not_yet_set': 'set'})
    assert cliargs_deferred_get('not_yet_set')() == 'set'
    assert cliargs_deferred_get('not_yet_set', default='default')() == 'set'

    CLIARGS = CLIArgs({'shallowcopy': [1, 2, 3]})
    assert cliargs_deferred_get('shallowcopy', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-20 13:57:55.878155
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # A couple of minimal unit tests
    cliargs = CLIArgs([])
    closure = cliargs_deferred_get('test-key')
    assert closure() == None

    cliargs = CLIArgs({'test-key': 'test-value'})
    closure = cliargs_deferred_get('test-key')
    assert closure() == 'test-value'

    closure = cliargs_deferred_get('test-key-2', default='test-value-2')
    assert closure() == 'test-value-2'

    closure = cliargs_deferred_get('test-key', shallowcopy=True)
    assert closure() == 'test-value'

    test_list = CLIArgs({'test-key': ['a', 'b', 'c']})
    closure = cliargs_deferred_get

# Generated at 2022-06-20 13:58:01.302009
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': 'bar'})
    closure = cliargs_deferred_get('foo')
    assert callable(closure)
    assert closure() == 'bar'

    _init_global_context({'foo': 'bar'})
    closure = cliargs_deferred_get('baz', default='spam')
    assert closure() == 'spam'

    _init_global_context({'foo': ['bar', 'baz']})
    closure = cliargs_deferred_get('foo')
    assert closure() == ['bar', 'baz']

    _init_global_context({'foo': ['bar', 'baz']})
    closure = cliargs_deferred_get('foo', shallowcopy=True)
    assert closure() == ['bar', 'baz']

    _init

# Generated at 2022-06-20 13:58:10.643440
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    cli_args = CLIArgs({'foo': 'bar'})

    result = cliargs_deferred_get('foo')(cli_args)
    assert result == 'bar'

    result = cliargs_deferred_get('baz')(cli_args)
    assert result is None

    result = cliargs_deferred_get('baz', default='whatevs')(cli_args)
    assert result == 'whatevs'



# TODO: Deferred Context Attributes
#
# def deferred_get(self, key, default=None, shallowcopy=False):
#     """Closure over getting a key from this ``Context`` with shallow copy functionality
#
#     Primarily used in ``FieldAttribute`` where we need to defer setting the default
#     until after

# Generated at 2022-06-20 13:58:22.408219
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import deepcopy

    _init_global_context({'test': True})
    assert cliargs_deferred_get('test')() is True

    # test that a deferred get returns the new value if CLIARGS has been updated
    CLIARGS['test'] = False
    assert cliargs_deferred_get('test')() is False

    # test that the shallow copy uses the original value
    # (note that this test will break if the value of the test arg changes)
    CLIARGS['test'] = 'original'
    copy = cliargs_deferred_get('test', shallowcopy=True)()
    copy += ' changed'
    assert copy != CLIARGS['test']

    # test that the shallow copy does use the original value
    CLIARGS['test']

# Generated at 2022-06-20 13:58:30.237403
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeCLIArgs:
        def get(self, key, default=None):
            return self.data[key]

    class Test:
        def __init__(self, cliargs_data):
            self.data = cliargs_data
            self.test_attr1 = cliargs_deferred_get('test_attr1')(self)

    fake_cliargs = FakeCLIArgs()
    fake_cliargs.data = {'test_attr1': 'This is a test'}
    test_data = Test(fake_cliargs)
    assert test_data.test_attr1 == 'This is a test'

# Generated at 2022-06-20 13:58:35.911945
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    global CLIARGS
    # Test that it works with no cliargs set
    assert cliargs_deferred_get('foo') is None
    assert cliargs_deferred_get('foo', 'bar') == 'bar'

    # Test that it works with non-sequences, non-collections
    CLIARGS = CLIArgs({'foo': 1})
    assert cliargs_deferred_get('foo', shallowcopy=True) == 1
    assert cliargs_deferred_get('foo') == 1

    # Test that it works with sequences
    CLIARGS = CLIArgs({'foo': [1, 2]})
    assert cliargs_deferred_get('foo', shallowcopy=True) == [1, 2]

# Generated at 2022-06-20 13:58:45.764647
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # This is the same content that PluginLoader passes to _init_global_context

# Generated at 2022-06-20 13:58:56.052693
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import json
    import pytest

    def test_args_values():
        args_values = {
            'tags': ['a', 'b', 'c'],
            'skip_tags': ['d', 'e'],
            'module_defaults': {'foo': 'bar'},
            'module_defaults_path': 'foo',
        }
        _init_global_context(args_values)

    test_args_values()
    test_shallowcopy = cliargs_deferred_get('module_defaults', shallowcopy=True)
    test_no_shallowcopy = cliargs_deferred_get('module_defaults')

    assert test_shallowcopy() == json.loads('{"foo": "bar"}')
    assert test_no_shallowcopy() == {'foo': 'bar'}


# Generated at 2022-06-20 13:59:07.234021
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for ``cliargs_deferred_get`` function
    """

    cli_args = dict(
        svalue='svalue',
        lvalue=['lvalue'],
        dvalue=dict(
            d1='dvalue1',
            d2='dvalue2',
        ),
        svalue2='svalue2',
        lvalue2=['lvalue2'],
        dvalue2=dict(
            d1='dvalue2.1',
            d2='dvalue2.2',
        ),
    )
    _init_global_context(cli_args)

    # The functions below are pointers to the original data and will change when the CLI
    # arguments change
    dvalue2_fn = cliargs_deferred_get('dvalue2')
    lvalue_fn = cliargs_

# Generated at 2022-06-20 13:59:15.056528
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # First test that the object being returned is a closure
    assert callable(cliargs_deferred_get('some_key'))
    # Test that the closure returns the same value as CLIARGS
    assert cliargs_deferred_get('some_key')(default='some_value') == 'some_value'
    # Test that the closure can be used to get values out of CLIARGS
    CLIARGS.clear()
    CLIARGS['some_key'] = 'some_value'
    assert cliargs_deferred_get('some_key')() == 'some_value'

# Generated at 2022-06-20 13:59:29.248898
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # test that a dict is copied
    cliargs_dict = {'a_key': 'a_val'}
    _init_global_context(cliargs_dict)
    get_a_key = cliargs_deferred_get('a_key')
    assert get_a_key() is cliargs_dict['a_key']
    cliargs_dict['a_key'] = 'new_val'
    assert get_a_key() is not cliargs_dict['a_key']

    # test that a string is not copied
    get_a_key = cliargs_deferred_get('a_key', 'default')
    assert get_a_key() is not 'default'

    # test that a list is copied
    _init_global_context

# Generated at 2022-06-20 13:59:40.144981
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def do_test(value, shallowcopy):
        func = cliargs_deferred_get('example_key', default=value, shallowcopy=shallowcopy)
        global CLIARGS
        CLIARGS = CLIArgs({'example_key': value})
        result = func()
        assert result == value
        # If we are shallow copying sequences, then they should be unique
        if shallowcopy and is_sequence(value):
            assert result is not value
        else:
            # if we are not shallow copying sequences; if value is a Sequence then it should
            # refer to the same sequence as the default does
            if is_sequence(value):
                assert result is value
        # If we are shallow copying mappings or sets, then the same should be true

# Generated at 2022-06-20 13:59:46.502859
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

# Generated at 2022-06-20 13:59:58.319660
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Dummy(object):
        opt = cliargs_deferred_get('test', shallowcopy=True)

    x = Dummy()
    assert x.opt is None
    CLIARGS._data['test'] = 'test'
    assert x.opt == 'test'
    CLIARGS._data['test'] = ['test']
    assert x.opt == ['test']
    assert x.opt is not CLIARGS._data['test']
    CLIARGS._data['test'] = {'test': 'test'}
    assert x.opt == {'test': 'test'}
    assert x.opt is not CLIARGS._data['test']
    CLIARGS._data['test'] = {'test': ['test']}
    assert x.opt == {'test': ['test']}
    assert x.opt is not CLI

# Generated at 2022-06-20 14:00:09.296180
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import mock

    with mock.patch('ansible.utils.context_objects.CLIARGS',
            return_value=CLIArgs({'foo': 'bar'})):
        assert cliargs_deferred_get('foo')() == 'bar'

    with mock.patch('ansible.utils.context_objects.CLIARGS',
            return_value=CLIArgs({})):
        # Regular default value
        assert cliargs_deferred_get('foo', default='baz')() == 'baz'

        # Delay evaluation of the default value
        default_value = cliargs_deferred_get('foo')
        assert default_value() == default_value
        assert callable(default_value)

        # Delay evaluation of the default value which comes from a method
        default_value = cliargs_deferred_

# Generated at 2022-06-20 14:00:17.590844
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import inspect
    import pytest

    def test():
        # build a fake CLIARGS object
        mock_cliargs = CLIArgs(dict(
            one='1',
            two='2',
            three='3'
        ))
        # run tests on fake CLIARGS object
        assert cliargs_deferred_get('one')(mock_cliargs) == '1'
        assert cliargs_deferred_get('four', default='4')(mock_cliargs) == '4'

    def test_default():
        # build a fake CLIARGS object
        mock_cliargs = CLIArgs(dict(
            one='1',
            two='2',
            three='3'
        ))
        # run tests on fake CLIARGS object

# Generated at 2022-06-20 14:00:29.918517
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get function"""
    # pylint: disable=unused-argument,redefined-outer-name
    import pytest

    @pytest.fixture
    def cli_args():
        return {
            'a': 'foo',
            'b': [1],
            'c': {'d': 1},
            'e': set(),
        }

    def test_gets_existing_args(cli_args):
        """Test with key in cli_args"""
        _init_global_context(cli_args)
        assert cliargs_deferred_get('a') == 'foo'

    def test_gets_default_value(cli_args):
        """Test with key not in cli_args"""
        _init_global_context(cli_args)
        assert cli

# Generated at 2022-06-20 14:00:35.936827
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Check that the deferred get function works
    """
    global CLIARGS

    def check_cliargs_deferred_get(value, expected_return, shallowcopy_return):
        """
        Solve the closure for the deferred get function
        """
        CLIARGS['key'] = value
        deferred_value = cliargs_deferred_get('key', default=None, shallowcopy=False)
        assert deferred_value() is expected_return

        # shallow copy should make a copy and return
        deferred_value = cliargs_deferred_get('key', default=None, shallowcopy=True)
        assert deferred_value() == shallowcopy_return

    # Test each data type
    check_cliargs_deferred_get('value', 'value', 'value')

# Generated at 2022-06-20 14:00:47.098011
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import AttributeDict
    from ansible.utils.context_objects import GlobalCLIArgs
    testargs = AttributeDict(dict(
        connection='local',
        module_path=['/home/user/mymodules'],
        forks=3,
        become=False,
        become_method=None,
        become_user=None
    ))
    _init_global_context(testargs)
    assert cliargs_deferred_get('connection')() == 'local'
    assert cliargs_deferred_get('module_path')() == ['/home/user/mymodules']
    assert cliargs_deferred_get('module_path', shallowcopy=True)() == ['/home/user/mymodules']
    assert cliargs_deferred_get

# Generated at 2022-06-20 14:00:57.996708
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test of cliargs_deferred_get"""
    global CLIARGS
    assert CLIARGS.get('verbosity') is None
    # these next two functions should be equivalent
    assert cliargs_deferred_get('verbosity')() is None
    assert cliargs_deferred_get('verbosity', default=None)() is None

    CLIARGS.verbosity = '-vvvv'
    # These next two functions should be equivalent
    assert cliargs_deferred_get('verbosity')() == '-vvvv'
    assert cliargs_deferred_get('verbosity', default=None)() == '-vvvv'

    CLIARGS.verbosity = None
    # These next three functions should be equivalent
    assert cliargs_deferred_get('verbosity')() is None
    assert cli

# Generated at 2022-06-20 14:01:22.565755
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs

    expected_dict = {'key': 'value', 'key2': 'value2'}
    expected_list = ['one', 'two', 'three']

    # Expected to return None if the global cliargs object has not been populated
    # and no default was passed to the function
    assert cliargs_deferred_get('key1')() is None

    # Expected to return the default value if the global cliargs object has not
    # been populated
    assert cliargs_deferred_get('key1', default='default')() == 'default'

    # Should find the key in the cliargs object
    CLIARGS.__setstate__(expected_dict)
    assert cliargs_deferred_get('key', default={})() == 'value'



# Generated at 2022-06-20 14:01:33.619250
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_handler():
        pass

# Generated at 2022-06-20 14:01:43.427129
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import functools

    # Change the global to a testable instance
    global CLIARGS
    CLIARGS = CLIArgs({'key': 'value'})

    # Check that the inner function gets the value from ``CLIARGS``
    inner = cliargs_deferred_get('key')
    assert 'value' == inner()

    # Check that the default value can be returned
    inner = cliargs_deferred_get('key_not_present', default='default_value')
    assert 'default_value' == inner()

    # Check that the shallow copy works on sequences
    inner = cliargs_deferred_get('key', shallowcopy=True)
    assert 'value' == inner()
    assert 'value' == CLIARGS['key']
    CLIARGS['key'] = 'new_value'

# Generated at 2022-06-20 14:01:54.569511
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    global CLIARGS
    CLIARGS = CLIArgs(dict(
        hello=['foo'],
        mapping=dict(
            foo='bar'
        ),
        set=set(['baz'])
    ))

    assert cliargs_deferred_get('hello')() == ['foo']
    assert cliargs_deferred_get('hello', shallowcopy=True)() == ['foo']
    assert cliargs_deferred_get('nosuchkey')() is None
    assert cliargs_deferred_get('nosuchkey', default='mydefault')() == 'mydefault'
    assert cliargs_deferred_get('nosuchkey', default=None)() is None

    # Test that the variadic arguments don't get treated like keyword arguments

# Generated at 2022-06-20 14:02:04.692306
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS

    # Test: no value, no default
    CLIARGS = CLIArgs({'some_key': None})
    assert cliargs_deferred_get('some_key')() is None

    # Test: value present, no default
    CLIARGS = CLIArgs({'some_key': 'some_value'})
    assert cliargs_deferred_get('some_key')() == 'some_value'

    # Test: value present, default same as value
    CLIARGS = CLIArgs({'some_key': 'some_value'})
    assert cliargs_deferred_get('some_key', default='some_value')() == 'some_value'

    # Test: value

# Generated at 2022-06-20 14:02:11.096396
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(foo=dict(bar=[1,2,3])))
    with_copy = cliargs_deferred_get('foo', shallowcopy=True)
    without_copy = cliargs_deferred_get('foo', shallowcopy=False)
    assert with_copy() == without_copy()
    with_copy()['bar'].append(4)
    assert with_copy() != without_copy()
    assert with_copy()['bar'] == [1,2,3,4]

# Generated at 2022-06-20 14:02:22.867905
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common import removed_module

    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    test_cliargs = CLIArgs({})

    def inner(key, default=None, shallowcopy=False):
        value = test_cliargs.get(key, default=default)
        if not shallowcopy:
            return value
        elif is_sequence(value):
            return value[:]
        elif isinstance(value, (Mapping, Set)):
            return value.copy()
        return value

    inner('does-not-exist') == None
    inner('does-not-exist', default='foo') == 'foo'

# Generated at 2022-06-20 14:02:28.773399
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """This is a unit test for cliargs_deferred_get"""
    from ansible.utils.context_objects import GlobalCLIArgs

    cliargs = GlobalCLIArgs({'key': 'value'})

    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('missing')() is None
    assert cliargs_deferred_get('missing', 'default')() == 'default'

# Generated at 2022-06-20 14:02:35.961851
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Note that this will fail if the internal structure of CLIARGS changes
    global CLIARGS
    CLIARGS = CLIArgs({'a': {'b': {1, 2, 3}}})
    val = cliargs_deferred_get('a', {})
    assert val is not CLIARGS.a
    assert val is CLIARGS.a
    assert val == CLIARGS.a

    val = cliargs_deferred_get('a', shallowcopy=True)
    assert val is not CLIARGS.a
    assert val is not CLIARGS.a.b
    assert val == CLIARGS.a

# Generated at 2022-06-20 14:02:45.105997
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import to_text

# Generated at 2022-06-20 14:03:32.164865
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs(dict(
        a="a",
        b=['b'],
        c=set(['c']),
        d=dict(d='d'),
        e=[dict(e='e')],
        f=set([dict(f='f')]),
    ))
    global CLIARGS
    CLIARGS = cliargs
    assert cliargs_deferred_get('a')() == 'a'
    assert cliargs_deferred_get('b')() == ['b']
    assert cliargs_deferred_get('c')() == set(['c'])
    assert cliargs_deferred_get('d')() == dict(d='d')

    # Test that the list and set are shallow copied
    b = cliargs_deferred_get('b')()
    c

# Generated at 2022-06-20 14:03:34.166534
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is for a test scenario that is not yet implemented
    pass

# Generated at 2022-06-20 14:03:43.837142
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global_cli_args = {'one': 1, 'two': 2}
    _init_global_context(global_cli_args)

    assert cliargs_deferred_get('one')() == 1
    assert cliargs_deferred_get('one', default=5)() == 1
    assert cliargs_deferred_get('three', default=5)() == 5

    assert cliargs_deferred_get('one', shallowcopy=True)() == 1
    assert cliargs_deferred_get('three', default=5, shallowcopy=True)() == 5

    assert cliargs_deferred_get('three')(None, [1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-20 14:03:55.706635
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    # Make sure we get the defaults
    assert cliargs_deferred_get('foo', default='bar') == 'bar'

    # Make sure that we can get the value when CLIARGS is set
    CLIARGS.foo = 'baz'
    assert cliargs_deferred_get('foo') == 'baz'

    # Make sure that the closure works
    # Ref: https://docs.pytest.org/en/stable/fixture.html#fixture-scope-module
    CLIARGS.foo = 'baz'
    assert cliargs_deferred_get('foo') == 'baz'

    # Make sure that we don't need to call the closure to get the defaults
    assert cliargs_deferred_get('foo', 'bar') == 'baz'

    # Make sure that the

# Generated at 2022-06-20 14:04:03.094766
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs
    from copy import deepcopy

    CLIARGS = CliArgs({
        'action': 'some_action',
        'args': {
            'arg1': 'val1',
            'arg2': 'val2',
        },
        'verbosity': 1
    })

    # function is created without any value, just like when ansible run
    cliargs_deferred_get_instance = cliargs_deferred_get('action')
    assert cliargs_deferred_get_instance() is None

    # function is associated with CliArgs, but it's still not work
    CLIARGS = CliArgs({'action': 'some_action'})
    cliargs_deferred_get_instance = cliargs_deferred_get('action')

# Generated at 2022-06-20 14:04:14.444962
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    import copy

    list_before = [1, 2, 3]
    cliargs_dict = {'list': list_before}
    global CLIARGS
    CLIARGS = CLIArgs(cliargs_dict)

    # Test deferred get with no shallowcopy
    list_retrieved = cliargs_deferred_get('list')()
    assert list_retrieved == list_before
    assert list_retrieved is list_before

    # Test deferred get with shallowcopy
    list_retrieved_2 = cliargs_deferred_get('list', shallowcopy=True)()
    assert list_retrieved_2 == list_before
    assert list_retrieved_2 is not list_before

    # Test deferred get with non string type
    int_before = 1


# Generated at 2022-06-20 14:04:24.351828
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('no_key')() is None, "Should return default of None with no args"
    _ = CLIARGS
    CLIARGS = CLIArgs({'key': 123})
    assert cliargs_deferred_get('key')() == 123, "Should be able to return CLIARGS['key'] value"
    assert cliargs_deferred_get('key', default='new_default')() == 123, "Should be able to return CLIARGS['key'] value"
    assert cliargs_deferred_get('no_key')() is None, "Should return default of None with no args"
    assert cliargs_deferred_get('no_key', shallowcopy=True)() is None, "Should return default of None with no args"

# Generated at 2022-06-20 14:04:30.210325
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Test default value
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('test')() == None

    # Test non-existent value
    CLIARGS = CLIArgs({'test1': 'value1'})
    assert cliargs_deferred_get('test2')() == None

    # Test non-copyable value
    CLIARGS = CLIArgs({'test3': 42})
    assert cliargs_deferred_get('test3')() == 42
    assert cliargs_deferred_get('test3', shallowcopy=True)() == 42

    # Test copyable value without copy
    CLIARGS = CLIArgs({'test4': [1, 2]})
    assert cliargs_deferred_get('test4')() == [1, 2]
   

# Generated at 2022-06-20 14:04:33.534120
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test _init_global_context and cliargs_deferred_get"""
    _init_global_context({'key': 'value'})
    assert cliargs_deferred_get('key')() == 'value'

    global CLIARGS
    CLIARGS = CLIArgs({'new_key': 'new_value'})
    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('new_key')() == 'new_value'