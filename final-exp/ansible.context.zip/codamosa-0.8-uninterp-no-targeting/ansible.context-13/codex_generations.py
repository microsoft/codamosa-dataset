

# Generated at 2022-06-20 13:54:42.246196
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Now override CLIARGS in the global namespace with our own mock CLIARGS

    class MockCliArgs(dict):
        def get(self, key, default=None):
            return {'key': 'value'}.get(key, default)

    global CLIARGS
    CLIARGS = MockCliArgs()

    value = cliargs_deferred_get('key', 'default')()
    assert value == 'value'
    value = cliargs_deferred_get('missing', 'default')()
    assert value == 'default'

# Generated at 2022-06-20 13:54:52.769381
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_key = 'test_key'
    new_value = 'new_value'

    def check_for_new_value():
        assert CLIARGS.get(test_key) == new_value

    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({})
    assert CLIARGS.get(test_key) is None
    cliargs_deferred_get(test_key)()
    assert CLIARGS.get(test_key) is None
    assert cliargs_deferred_get(test_key)() is None
    assert cliargs_deferred_get(test_key, default=new_value)() == new_value
    CLIARGS = GlobalCLIArgs.from_options({test_key: new_value})

# Generated at 2022-06-20 13:55:03.739699
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Custom(Mapping, Set):
        def __getitem__(self, item):
            pass

        def __iter__(self):
            pass

        def __len__(self):
            pass

        def __contains__(self, item):
            pass

        def __deepcopy__(self, memo):
            pass

    from operator import methodcaller
    from copy import copy

    custom = Custom()
    defaulter = cliargs_deferred_get('foo', default=custom)
    result = defaulter()
    assert result is custom
    assert id(result) == id(defaulter())

    custom1 = Custom()
    custom2 = Custom()
    defaulter = cliargs_deferred_get('foo', default=custom2, shallowcopy=True)
    result = defaulter()

# Generated at 2022-06-20 13:55:14.311017
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_opts = {}
    _init_global_context(cli_opts)

    def check_func(key, value):
        """Create the function"""
        func = cliargs_deferred_get(key)
        assert func() == value

    cli_opts = {}
    check_func('foo', None)

    cli_opts['foo'] = 'bar'
    check_func('foo', 'bar')

    cli_opts['foo'] = [1, 2, 3]
    check_func('foo', [1, 2, 3])
    check_func('foo', [1, 2, 3], shallowcopy=True)
    check_func('foo', [1, 2, 3, 4], default=[1, 2, 3, 4])


# Generated at 2022-06-20 13:55:26.272065
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=too-few-public-methods
    """Unit test for cliargs_deferred_get"""
    class MyCLIArgs(CLIArgs):
        def __init__(self, args):
            super(MyCLIArgs, self).__init__(args)

    class TestObject(object):
        """An object that uses the cliargs"""
        my_value = cliargs_deferred_get('somekey', 'somevalue')

    class TestObjectNoShallow(object):
        """An object that uses the cliargs"""
        my_value = cliargs_deferred_get('somekey', 'somevalue', shallowcopy=True)

    class TestObjectList(object):
        """An object that uses the cliargs"""

# Generated at 2022-06-20 13:55:34.373629
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from __main__ import cli, display

    cli_args = cli.argument_parser.parse_args(['--connection=smart', '--forks=2', '--become=true', '--become_method=sudo', '--become_user=root', '--become_ask_pass', '--check', '--diff', '-i', 'ansible', '/etc/ansible'])
    _init_global_context(cli_args)

    # GlobalCLIArgs.from_options expects a dict, so convert
    cli_args = dict((key, getattr(cli_args, key)) for key in dir(cli_args) if not key.startswith('_'))

    # test with direct reference to CLIARGS
    assert cl

# Generated at 2022-06-20 13:55:44.673123
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    import types
    import unittest

    # This is to avoid ``CLIARGS`` from being replaced to a ``GlobalCLIArgs``
    # object and having the wrong type for ``inner`` function
    test_cliargs = CLIARGS
    test_cliargs.options = {
        'bool_param1': True,
        'bool_param2': False,
        'list_param': ['foo', 'bar', 'baz'],
        'integer_param': 3,
        'dict_param': {'foo': 'bar'},
    }

    inner = cliargs_deferred_get('bool_param1')
    assert type(inner) == types.FunctionType
    assert inner() == test_cliargs._field_values['bool_param1']
    assert inner.__name__ == 'inner'


# Generated at 2022-06-20 13:55:51.120281
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'somekey': 'somevalue'})
    func = cliargs_deferred_get('somekey', default='somedefault')
    assert func() == 'somevalue'
    func = cliargs_deferred_get('otherkey', default='somedefault')
    assert func() == 'somedefault'

# Generated at 2022-06-20 13:55:58.743384
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Check the get operations for cliargs_deferred_get"""
    global CLIARGS
    # Setting CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    # Getting a key
    test = cliargs_deferred_get('foo')
    assert test() == 'bar'
    # Using the default
    test = cliargs_deferred_get('baz', default=False)
    assert test() is False
    # using the shallowcopy
    list_object = [1, 2, 3]
    test = cliargs_deferred_get('foo', shallowcopy=True)
    assert test() == 'bar'
    list_object.append(4)
    test = cliargs_deferred_get('list_object', default=list_object, shallowcopy=True)
    assert test

# Generated at 2022-06-20 13:56:09.700892
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import DEFAULTS

    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options(DEFAULTS)
    assert cliargs_deferred_get('diff') == DEFAULTS['diff']
    CLIARGS['diff'] = True
    assert cliargs_deferred_get('diff') is True
    assert cliargs_deferred_get('diff', shallowcopy=True) is True

    CLIARGS = GlobalCLIArgs.from_options(DEFAULTS)
    CLIARGS['tags'] = ['one', 'two']
    assert cliargs_deferred_get('tags', default=['three']) == ['one', 'two']

# Generated at 2022-06-20 13:56:23.319435
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    old_deferred_get = cliargs_deferred_get

# Generated at 2022-06-20 13:56:33.544834
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is currently a module test.  Should probably be moved.
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping
    # cliargs_deferred_get should return the default parameter when there is no
    # value for the key in CLIARGS
    test_default = 'test_default'
    assert cliargs_deferred_get('test_nonexistent_key', test_default)() == test_default
    # cliargs_deferred_get should return the value when there is a value for the
    # key in CLIARGS
    assert cliargs_deferred_get('username')() == 'nested'
    # When we call cliargs_deferred_get twice it should be a new value
    first_value = cliargs_deferred_get('username')

# Generated at 2022-06-20 13:56:45.062177
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Function make_context_deferred_get"""
    # pylint: disable=redefined-outer-name
    # FIXME: these should be tested on CliArgs as well.  These should not be
    # converted to fixtures as that defeats the purpose of the function
    from ansible.module_utils.common.collections import is_sequence
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'


# Generated at 2022-06-20 13:56:56.036767
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.set_values({'foo': ['bar', 'baz'], 'buzz': {'bar': 'buzz'}})
    assert cliargs_deferred_get('foo', default=None)() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', default=None, shallowcopy=True)() == ['bar', 'baz']
    baz = cliargs_deferred_get('foo', default=None)()
    baz.pop()
    assert CLIARGS['foo'] == ['bar', 'baz']
    baz = cliargs_deferred_get('foo', default=None, shallowcopy=True)()
    baz.pop()
    assert CLIARGS['foo'] == ['bar', 'baz']
    baz = cliargs_deferred

# Generated at 2022-06-20 13:57:03.419916
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {
        'var1': 'ansible',
        'var2': ['rides', 'again'],
        'var3': {'mapping': 'test'},
        'var4': set(['a', 'b']),
        'var5': [],
        'var6': {},
        'var7': set()
    }
    _init_global_context(cli_args)

    def get_value(key, shallowcopy):
        return cliargs_deferred_get(key, shallowcopy=shallowcopy)()

    def assert_value_is_original(key, shallowcopy):
        value = get_value(key, shallowcopy=shallowcopy)
        assert value is cli_args[key]
        assert value == cli_args[key]

    # Scenario check:

# Generated at 2022-06-20 13:57:07.399456
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_cli_args = {'one': 1, 'two': 2}
    cli_args = CLIArgs(test_cli_args)
    test_value = cli_args_deferred_get('one')
    assert test_value() == test_cli_args['one']
    test_value = cli_args_deferred_get('two', shallowcopy=True)
    assert test_value() == test_cli_args['two']

# Generated at 2022-06-20 13:57:13.316028
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    test_val = [1, 2, 3]
    cliargs = CLIArgs.from_options({'test_val': test_val})
    getter = cliargs_deferred_get('test_val')
    assert test_val == getter()
    pytest.raises(KeyError, cliargs_deferred_get, 'non_existent_key')
    assert cliargs_deferred_get('non_existent_key', default='default') == 'default'

    test_val.append(4)
    assert test_val == getter()

    getter = cliargs_deferred_get('test_val', shallowcopy=True)
    assert test_val == getter()
    assert test_val == getter()

    test_val.append(5)
    assert test_val

# Generated at 2022-06-20 13:57:18.961464
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Put in a value for the first key
    CLIARGS['first_key'] = 'first_val'
    # Make sure it is returned
    assert 'first_val' == cliargs_deferred_get('first_key')()
    # Make sure we can still get the default value
    assert 'default_val' == cliargs_deferred_get('key_does_not_exist', default='default_val')()



# Generated at 2022-06-20 13:57:30.384978
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    default_value = object()
    test_value = object()
    test_value2 = object()
    copy_value = object()

    # Test default value
    assert cliargs_deferred_get('key', default_value)() is default_value

    # Test setting the key and value
    CLIARGS['key'] = test_value
    assert cliargs_deferred_get('key')() is test_value

    # Test copying it
    CLIARGS['shallowcopy'] = copy_value
    assert cliargs_deferred_get('shallowcopy', shallowcopy=True)() is copy_value

    # Test changing the value
    CLIARGS['key'] = test_value2
    assert cliargs_deferred_get('key')() is test_value2

    # Test copying a non-shallow copyable

# Generated at 2022-06-20 13:57:41.561623
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CliargsDeferredExpression

    def test_get_default(key, key2, value, value2):
        """Test getting a value from a default"""
        deferred_get = cliargs_deferred_get(key, default=value)
        deferred_get2 = cliargs_deferred_get(key2, default=value2)
        assert isinstance(deferred_get, CliargsDeferredExpression)
        assert isinstance(deferred_get2, CliargsDeferredExpression)
        assert deferred_get() is value
        assert deferred_get2() is value2

    def test_get_cliargs(key, value, value2, value3):
        """Test getting a value from a default"""

# Generated at 2022-06-20 13:57:54.443456
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-20 13:58:04.670474
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name,unused-argument
    import pytest
    from unittest import mock

    def test_get_from_cliargs(cliargs, key, expected):
        """Get a value from the cliargs and return the expected value"""
        _init_global_context(cliargs)
        return cliargs_deferred_get(key)()


# Generated at 2022-06-20 13:58:14.548034
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_key(key, value, default):
        if default is None:
            assert cliargs_deferred_get(key) == value
            assert cliargs_deferred_get(key, shallowcopy=True) == value
        else:
            assert cliargs_deferred_get(key) == value
            assert cliargs_deferred_get(key, default) == value
            # Default value should get copied
            assert cliargs_deferred_get(key, default, shallowcopy=True) == default

    args = {'foo': 'bar',
            'baz': ['baz', 'baz2'],
            'qux': {'qux': 'qux'},
            'quux': {'quux'},
            }
    _init_global_context(args)
    test_key

# Generated at 2022-06-20 13:58:22.023126
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=missing-docstring
    def check_value(value):
        assert value == cliargs_deferred_get('key', value, shallowcopy=True)()

    check_value(None)
    check_value(False)
    check_value('asdf')
    check_value([1, 2, 3])
    check_value({'a': 1, 'b': 2, 'c': 3})
    check_value(set([1, 2, 3]))


# Generated at 2022-06-20 13:58:28.605001
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['test'] = 'hi'
    assert 'hi' == cliargs_deferred_get('test')()
    assert [] == cliargs_deferred_get('list', shallowcopy=True)()
    assert {} == cliargs_deferred_get('dict', shallowcopy=True)()
    assert set() == cliargs_deferred_get('set', shallowcopy=True)()
    assert 'default' == cliargs_deferred_get('nonexistent', default='default')()

# Generated at 2022-06-20 13:58:34.777652
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test of the cliargs_deferred_get function

    This function will be removed when the unit tests are moved to a different
    testing framework
    """
    assert cliargs_deferred_get('__cli_args_no_such_key__')() is None
    assert cliargs_deferred_get('__cli_args_no_such_key__', 123)() == 123
    assert cliargs_deferred_get('__cli_args_no_such_key__', 123, shallowcopy=True)() == 123

    CLIARGS.update(x=1, y=2, z=[3, 4, 5], a={'b': 'c'})

    assert cliargs_deferred_get('x')() == 1

# Generated at 2022-06-20 13:58:45.052012
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    value = {'a': 1}
    CLIARGS = {"a": value}

    # Test normal operation
    assert cliargs_deferred_get('a')() == value
    assert cliargs_deferred_get('b')() is None
    assert cliargs_deferred_get('b', default={})() == {}

    # Test shallowcopy operation
    assert cliargs_deferred_get('a', shallowcopy=True)() is value
    assert cliargs_deferred_get('b', shallowcopy=True)() is None
    assert cliargs_deferred_get('b', default={}, shallowcopy=True)() == {}
    assert cliargs_deferred_get('a', shallowcopy=True)() is value

    CLIARGS["a"] = [1, 2, 3]
    assert cli

# Generated at 2022-06-20 13:58:55.052251
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'vault_password_file': ['foo']}
    _init_global_context(cli_args)
    f = cliargs_deferred_get('vault_password_file', shallowcopy=True)
    # shallow should make a copy for sequence, set, and mapping types
    assert f() == ['foo']
    assert f() is not CLIARGS['vault_password_file']
    assert f() == CLIARGS['vault_password_file']

    f = cliargs_deferred_get('vault_password_file')
    # No shallow copy so we can assume that f() is the same as CLIARGS['vault_password_file']
    assert f() is CLIARGS['vault_password_file']

# Generated at 2022-06-20 13:59:06.397832
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    from tempfile import NamedTemporaryFile
    from ansible.module_utils.common import load_module_spec
    from ansible.module_utils._text import to_text

    # Create a dummy module to use
    with NamedTemporaryFile('w', encoding='utf-8') as test_module:
        test_module.write(to_text("#!/usr/bin/python\ndef main(): pass"))
        test_module.flush()
        module_name = test_module.name
        global_spec = load_module_spec(module_name, True)

    global CLIARGS


# Generated at 2022-06-20 13:59:16.167631
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # type: ignore

    import sys
    import types

    def _assert_bound(bound_method, value):
        assert isinstance(bound_method, types.MethodType)
        assert bound_method() == value

    with patch.object(sys, 'argv', ['ansible-playbook', 'setup.yml', '-e', 'foo=bar']):
        _init_global_context(dict(e=['foo=bar']))
        get_bar = cliargs_deferred_get('e')

        _assert_bound(get_bar, ['foo=bar'])

        get_bar = cliargs_deferred_get('e', shallowcopy=True)

# Generated at 2022-06-20 13:59:25.115239
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for ``cliargs_deferred_get``

    These tests only test that the get returns the default value and the value if
    CLIARGS is set to something different
    """
    def _inner_default_value(fn, value):
        """Inner function to test that cliargs_deferred_get returns the value"""
        assert fn() == value

    def _inner_cliargs_set(fn, value, cliargs_value):
        """Inner function to test that cliargs_deferred_get returns the cli_args value"""
        global CLIARGS
        CLIARGS = CLIArgs({'key': cliargs_value})
        assert fn() == value
        CLIARGS = CLIArgs({})

    # Test that it returns the value when the key is not in the cli_args (CLIARGS)

# Generated at 2022-06-20 13:59:36.745484
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    orig_value = 'original'
    cli_args = {'foo': orig_value}
    CLIARGS = CLIArgs(cli_args)

    value = cliargs_deferred_get('foo')
    assert value() == orig_value

    cli_args['foo'] = 'new'
    cli_args['bar'] = 'not present'
    assert value() == orig_value
    orig_value = 'original'

    default = []
    value = cliargs_deferred_get('bar', default=default)
    assert value() is default
    assert value() is not cli_args['bar']
    orig_default = default

    default = {1: 1}
    value = cliargs_deferred_get('bar', default=default)
    assert value() is default


# Generated at 2022-06-20 13:59:44.664272
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # If a value is not set, return a default value
    assert cliargs_deferred_get('test') == None

    # If a key is set, return its value
    CLIARGS['test'] = 'value'
    assert cliargs_deferred_get('test') == 'value'
    del CLIARGS['test']

    # If a key is set and a default value is specified, return its value
    CLIARGS['test'] = 'value'
    assert cliargs_deferred_get('test', 'default') == 'value'
    del CLIARGS['test']

    # If a key is not set and a default value is specified, return the default value
    assert cliargs_deferred_get('test', 'default') == 'default'

    # If a key is set, return a shallow copy of its value
   

# Generated at 2022-06-20 13:59:52.875076
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({"test": True, "blah": [1,2,3]})
    assert cliargs_deferred_get("test")()
    assert cliargs_deferred_get("blah")() == [1,2,3]
    CLIARGS["blah"].append(4)
    assert cliargs_deferred_get("blah", shallowcopy=True)() == [1,2,3,4]
    assert cliargs_deferred_get("blah", shallowcopy=False)() == [1,2,3,4]

# Generated at 2022-06-20 14:00:04.863824
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get(): # pylint: disable=too-many-locals,too-many-branches,too-many-statements
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=import-outside-toplevel
    import copy
    import os
    import sys
    import tempfile
    import unittest
    import textwrap

    class ArgsToNamespace(object):
        """Helper to convert dicts of args to an argparse.Namespace"""
        def __init__(self, args):
            for key, value in args.items():
                setattr(self, key, value)

    class TestCase(unittest.TestCase):
        """Unit test for function cliargs_deferred_get"""

# Generated at 2022-06-20 14:00:13.071193
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': 2})

    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == 2

    assert cliargs_deferred_get('c', default=3)() == 3

    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('b', shallowcopy=True)() == 2
    assert cliargs_deferred_get('c', default=3, shallowcopy=True)() == 3

    CLIARGS = CLIArgs({'a': [1], 'b': (1,)})

    assert cliargs_deferred_get('a', shallowcopy=True)() == [1]
    assert cl

# Generated at 2022-06-20 14:00:20.620871
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('test_string')() is None

    # This is a proper closure over the non-global version of the cliargs
    # created by the unittest
    options = {'test_string': 'string',
               'test_list': ['item1'],
               'test_dict': {'key': 'value'}}
    _init_global_context(options)

    get_string = cliargs_deferred_get('test_string')
    get_list = cliargs_deferred_get('test_list')
    get_dict = cliargs_deferred_get('test_dict')

    assert get_string() == 'string'
    assert get_list() == ['item1']
    assert get_dict() == {'key': 'value'}

# Generated at 2022-06-20 14:00:32.468076
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Create a mock CLIARGS to work with
    CLIARGS.update({'v': 10, 'name': 'Bob', 'boolean': True, 'list': ['a', 'b', 'c'], 'dict': {'a': 1}})
    cliargs_deferred_get_test = cliargs_deferred_get('v')
    assert cliargs_deferred_get_test() == 10
    cliargs_deferred_get_test = cliargs_deferred_get('boolean', shallowcopy=True)
    assert cliargs_deferred_get_test() == True
    cliargs_deferred_get_test = cliargs_deferred_get('boolean', shallowcopy=False)
    assert cliargs_deferred_get_test() == True
    cliargs_deferred

# Generated at 2022-06-20 14:00:43.795937
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Check that cliargs_deferred_get works as expected"""
    from ansible.module_utils.context import Context
    from .context_objects import FieldAttribute, Field

    class Obj(Context):
        """Example object"""
        _name = FieldAttribute()
        _cli_default = FieldAttribute(default=cliargs_deferred_get('default'))
        _cli_shallowcopy = FieldAttribute(default=cliargs_deferred_get('shallowcopy', shallowcopy=True))

        def __init__(self, name=None):
            """Initialize the object with a name
            :kwarg name: Name of the object being created
            """
            self._name = name
            super(Obj, self).__init__()

        @property
        def name(self):
            """Return the object's name"""
            return self._

# Generated at 2022-06-20 14:00:55.325175
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    tmp_cliargs = CLIARGS

# Generated at 2022-06-20 14:01:00.471399
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('inventory')().list_hosts() == []
    assert cliargs_deferred_get('string_list_key', default=[])(), []

# Generated at 2022-06-20 14:01:11.512561
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.validation import Validator

    _cli_args = CLIArgs({'foo': 'foo_value', 'bar': 'bar_value', 'baz': 'baz_value'})
    global CLIARGS
    # Set the cliargs to a temporary value so we can test
    cliargs_save = CLIARGS
    CLIARGS = _cli_args

    def test_default(key, expected_value, expected_type):
        test_value = cliargs_deferred_get(key)()
        assert test_value == expected_value, \
            "Deferred cliargs get did not return the correct default value for key: %s;" \
            " expected: %s; actual: %s" % (key, expected_value, test_value)

# Generated at 2022-06-20 14:01:18.576624
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')(), "'bar'"
    assert cliargs_deferred_get('foo', default='bad')(), "'bar'"
    assert cliargs_deferred_get('nope', default='bad')(), "'bad'"
    assert cliargs_deferred_get('foo', shallowcopy=True)(), "'bar'"
    assert cliargs_deferred_get('nope', shallowcopy=True, default=['bad'])() == ['bad']

# Generated at 2022-06-20 14:01:24.433154
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=attribute-defined-outside-init,unused-argument,blacklisted-name
    global CLIARGS

    # Test setup
    CLIARGS = CLIArgs({'CONTEXT_KEY_1': 1, 'CONTEXT_KEY_2': {'key': 'value'}})
    expected = {'CONTEXT_KEY_1': 1, 'CONTEXT_KEY_2': {'key': 'value'}}

    # Test deep copy
    result = cliargs_deferred_get('CONTEXT_KEY_1')()
    assert result == expected['CONTEXT_KEY_1']
    result = cliargs_deferred_get('CONTEXT_KEY_2')()
    assert result == expected['CONTEXT_KEY_2']
    assert result is not expected['CONTEXT_KEY_2']

    # Test shallow

# Generated at 2022-06-20 14:01:36.215278
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS  # pylint: disable=global-statement
    cli_args_dict = {'foo': 'bar'}
    cli_args = CLIArgs(cli_args_dict)
    CLIARGS = cli_args
    assert cliargs_deferred_get('foo')(), 'bar'
    assert cliargs_deferred_get('missing')(), None
    assert cliargs_deferred_get('missing', default='not found')(), 'not found'
    cli_args_dict['foo'] = None
    assert cliargs_deferred_get('foo')(), None
    cli_args_dict['foo'] = [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)(), cli_args_dict['foo']


# Generated at 2022-06-20 14:01:44.940708
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert 'bar' == cliargs_deferred_get('foo')()
    assert 'baz' == cliargs_deferred_get('does_not_exist', 'baz')()
    CLIARGS.foo = ['bar']
    assert ['bar'] == cliargs_deferred_get('foo')()
    assert ['bar'] == cliargs_deferred_get('foo', shallowcopy=True)()
    assert ['bar'] is not cliargs_deferred_get('foo', shallowcopy=False)()
    CLIARGS.foo = {'foo': 'bar'}
    assert {'foo': 'bar'} == cliargs_deferred_get('foo')()

# Generated at 2022-06-20 14:01:55.865456
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    # we have a local test_cliargs_deferred_get
    cliargs_deferred_get('')

    # If the cli args haven't been parsed, this should return None unless
    # a default is specified
    get_test1 = cliargs_deferred_get('test1')
    assert get_test1() is None, 'Should be none'

    get_test2 = cliargs_deferred_get('test2', default='default')
    assert get_test2() == 'default', 'Should default to default'

    # Now set the global cli args to something
    cliargs_dict = {'test1': 'set1', 'test2': 'set2'}
    _init_global_context(cliargs_dict)


# Generated at 2022-06-20 14:02:05.837446
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get.
    """
    assert CLIARGS._data == {}
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', default=0)(default=1) == 0
    assert cliargs_deferred_get('foo', default=0)() == 0

    assert CLIARGS._data == {}
    CLIARGS._data = {'foo': 1, 'bar': [2, 3]}
    assert cliargs_deferred_get('foo')(default=0) == 1
    assert cliargs_deferred_get('bar')(default=[]) == [2, 3]
    assert cliargs_deferred_get('bar', shallowcopy=True)() == [2, 3]

    assert cliargs

# Generated at 2022-06-20 14:02:10.408267
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    assert cliargs_deferred_get.__name__ == 'inner'
    assert cliargs_deferred_get() == {}
    CLIARGS._data['foo'] = 'bar'
    assert cliargs_deferred_get('foo') == 'bar'

# Generated at 2022-06-20 14:02:20.988696
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import argparse
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument("--foo")
    arg_parser.add_argument("--bar", action='append')
    args = arg_parser.parse_args([])
    _init_global_context(args)
    assert cliargs_deferred_get("foo")() is None
    assert cliargs_deferred_get("bar")() == []

    # Make sure that the closure keeps the key available
    args = arg_parser.parse_args(["--foo", "Foo"])
    _init_global_context(args)
    assert cliargs_deferred_get("foo")() == "Foo"

    # Make sure other values get set
    args = arg_parser.parse_args(["--bar", "b"])


# Generated at 2022-06-20 14:02:32.975613
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    test_args = dict(
        foo='bar',
        bat=dict(
            buzz=42,
        ),
    )
    CLIARGS = CLIArgs(test_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bat')() == dict(buzz=42)
    assert cliargs_deferred_get('bat', default={})() == dict(buzz=42)
    assert cliargs_deferred_get('baz', default={})() == {}
    assert cliargs_deferred_get('baz', default={}, shallowcopy=True)() == {}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_

# Generated at 2022-06-20 14:02:41.230873
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test to ensure cliargs_deferred_get works properly"""
    expected_values = {'bool': False,
                       'str': 'abc',
                       'list': [1, 2, 3],
                       'dict_': {'a': 1, 'b': 2, 'c': 3},
                       'set': {1, 2, 3},
                       'default': 'default',
                       }
    dummy_cli_args = {key: value for key, value in expected_values.items() if key != 'default'}
    global CLIARGS
    assert CLIARGS == CLIArgs({})
    _init_global_context(dummy_cli_args)
    assert CLIARGS == GlobalCLIArgs.from_options(dummy_cli_args)
    for key, value in expected_values.items():
        assert cliargs_

# Generated at 2022-06-20 14:02:52.941455
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.six import PY2
    from copy import deepcopy
    from time import sleep
    from tempfile import mktemp

    cliargs = {'vault_password_file': mktemp(), 'become_ask_pass': False, 'verbosity': 5}
    _init_global_context(cliargs)

    # Test default
    default = 42
    f = cliargs_deferred_get('__does_not_exist__', default=default)
    assert f() == 42

    # Test regular value
    key = 'verbosity'
    f = cliargs_deferred_get(key)
    assert f() == 5
    # Note: The following doesn't work until the global singleton is created in ``ansible-playbook``
    # CLIARGS[key] = 6
    # assert

# Generated at 2022-06-20 14:03:02.529212
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def value_raise(a):
        return 1/0

    assert cliargs_deferred_get('a')(default=value_raise) == value_raise()
    assert cliargs_deferred_get('a')(default=value_raise, shallowcopy=True) == value_raise()
    assert cliargs_deferred_get('a')(default=[]) == []
    assert cliargs_deferred_get('a')(default=[], shallowcopy=True) == []
    assert cliargs_deferred_get('a')(default={}) == {}
    assert cliargs_deferred_get('a')(default={}, shallowcopy=True) == {}

# Generated at 2022-06-20 14:03:12.729467
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'test_key': 'test_value'})
    assert cliargs_deferred_get('test_key')() == 'test_value'
    assert cliargs_deferred_get('test_key', 'test_fallback')() == 'test_value'
    assert cliargs_deferred_get('test_fallback', 'test_fallback')() == 'test_fallback'
    assert cliargs_deferred_get('test_key', shallowcopy=True)() == 'test_value'

    CLIARGS = CLIArgs({'test_list_key': ['test_value1', 'test_value2']})
    assert cliargs_deferred_get('test_list_key', list)() == ['test_value1', 'test_value2']

# Generated at 2022-06-20 14:03:19.876583
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.six import PY2
    global CLIARGS
    assert CLIARGS.get('verbosity') == 0
    CLIARGS = CLIArgs({u'verbosity': 10})
    assert cliargs_deferred_get('verbosity')() == 10
    if PY2:
        # This is a regression test to make sure that we don't actually retrieve the value
        # until the call which allows the CLIARGS to be replaced
        CLIARGS = CLIArgs({u'verbosity': 11})
        assert cliargs_deferred_get('verbosity')() == 10

# Generated at 2022-06-20 14:03:31.304290
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make sure that we can return a value
    CLIARGS.set('foo', 'bar')
    value = cliargs_deferred_get('foo', 'default')()
    assert value == 'bar'

    # Make sure we can return a default
    CLIARGS.pop('foo', None)
    assert 'foo' not in CLIARGS
    value = cliargs_deferred_get('foo', 'default')()
    assert value == 'default'

    # Make sure that we can return a value with a shallowcopy
    CLIARGS.set('foo', 'bar', shallow_copy=False)
    value = cliargs_deferred_get('foo', 'default', True)()
    assert value == 'bar'

    # Make sure we can return a default with a shallowcopy
    CLIARGS.pop('foo', None)

# Generated at 2022-06-20 14:03:42.604756
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.clear()
    CLIARGS.update(dict(
        ansible_field=1,
        ansible_field_a=2,
        ansible_field_b=3,
        ansible_field_c=[1, 2, 3],
    ))

    # Test with default (and no shallow copy)
    field_default = cliargs_deferred_get('ansible_field_nonexistant', 'value')
    assert field_default() == 'value'

    # Test without default (and no shallow copy)
    field_nodefault = cliargs_deferred_get('ansible_field')
    assert field_nodefault() == 1

    # Test with default (and shallow copy)

# Generated at 2022-06-20 14:03:54.253350
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'v': 2})

    fn = cliargs_deferred_get('v', default=1)
    assert fn() == 2

    fn = cliargs_deferred_get('b', default=1)
    assert fn() == 1

    CLIARGS = CLIArgs({'v': ['a', 'b']})
    print(CLIARGS)
    fn = cliargs_deferred_get('v', default=1)
    assert fn() == ['a', 'b']
    fn = cliargs_deferred_get('v', default=1, shallowcopy=True)
    assert fn() == ['a', 'b']
    assert fn() is not CLIARGS['v']


# Generated at 2022-06-20 14:04:02.452855
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=missing-docstring
    import copy
    import collections

    test_args = {'someint': 42, 'somestr': '42', 'somelist': [1, 2, 3],
                 'somedict': {'one': 1, 'two': 2, 'three': 3}, 'someset': set([1, 2, 3])}

    _init_global_context(test_args)
    assert CLIARGS == test_args

    tmp = cliargs_deferred_get('someint')
    assert tmp() == 42
    assert tmp.__closure__[0].cell_contents == test_args

    tmp = cliargs_deferred_get('fakekey')
    assert tmp() is None
    assert tmp.__closure__[0].cell_contents == test_args



# Generated at 2022-06-20 14:04:12.221556
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({'one': [1]})
    getter = cliargs_deferred_get('one')
    assert getter() == cliargs.get('one')  # calls multiple times
    assert getter() == cliargs.get('one')  # calls multiple times
    assert getter() is cliargs.get('one')  # calls multiple times



# Generated at 2022-06-20 14:04:22.688945
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import MutableSet, MutableSequence
    cliargs = {'a': 1, 'b': 2, 'c': 'foo', 'd': [1, 2, 3], 'e': {1: 'a', 2: 'b'}, 'f': MutableSequence([1, 2, 3]), 'g': MutableSet([1, 2, 3])}
    _init_global_context(cliargs)
    get_a = cliargs_deferred_get('a')
    get_b = cliargs_deferred_get('b')
    get_c = cliargs_deferred_get('c')
    get_d = cliargs_deferred_get('d')
    get_e = cliargs_deferred_get('e')


# Generated at 2022-06-20 14:04:29.602523
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    from ansible.module_utils.six import text_type
    global CLIARGS
    args = {'some': {'arbitrary': 'value'},
            'list': [1, 2, 3],
            'integer': 9,
            'unicode': u'string',
            'long_string': text_type('0' * 100),
            }
    CLIARGS = CLIArgs(args)

    # Default
    assert cliargs_deferred_get('beep') is None

    # Normal
    assert cliargs_deferred_get('integer') == 9
    assert cliargs_deferred_get('unicode') == u'string'

# Generated at 2022-06-20 14:04:36.657259
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    assert cliargs_deferred_get('key', default='something')() == 'something'
    assert cliargs_deferred_get('key', default={'a': 'b'})() == {'a': 'b'}
    assert cliargs_deferred_get('key', default={'a': 'b'}, shallowcopy=True)() == {'a': 'b'}
    assert cliargs_deferred_get('key', default=['a', 'b'])() == ['a', 'b']
    assert cliargs_deferred_get('key', default=['a', 'b'], shallowcopy=True)() == ['a', 'b']
    assert cliargs_deferred_get('key', default=('a', 'b'))()