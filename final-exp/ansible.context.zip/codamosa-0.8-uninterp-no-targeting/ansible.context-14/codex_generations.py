

# Generated at 2022-06-20 13:54:44.745167
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo')() is None
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'bar': 'baz'}
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']

# Generated at 2022-06-20 13:54:54.113118
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=unused-argument
    global CLIARGS

    # Test with a different backend than the real one
    class Backend(object):
        """Backend class that just holds the args"""
        def __init__(self, cli_args):
            self.cli_args = cli_args

        def get(self, key, default=None):
            """Get a value from the backend"""
            # pylint: disable=missing-docstring
            return self.cli_args[key]

        def __contains__(self, key):
            """Check if a key is in the backend"""
            return key in self.cli_args

        def __getitem__(self, key):
            """Get an item from the backend"""
            return self.cli_args[key]


# Generated at 2022-06-20 13:55:04.146903
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {
        'somekey': 'somevalue',
        'someotherkey': ['somevalue', 'someothervalue'],
        'onemorekey': {'somekey': 'somevalue'},
        'yetsomeotherkey': set(['somevalue', 'someothervalue']),
        }
    _init_global_context(cli_args)

    assert cliargs_deferred_get('dummy')() is None
    assert cliargs_deferred_get('dummy', default='other')() == 'other'
    assert cliargs_deferred_get('dummy', default='other', shallowcopy=True)() == 'other'

    assert cliargs_deferred_get('somekey')() == 'somevalue'

# Generated at 2022-06-20 13:55:14.877777
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Foo(dict):
        x = cliargs_deferred_get('x')
        y = cliargs_deferred_get('y')
        z = cliargs_deferred_get('z')
        a = cliargs_deferred_get('a')
        b = cliargs_deferred_get('b')
        c = cliargs_deferred_get('c')
        d = cliargs_deferred_get('d', shallowcopy=True)

    from ansible.utils.context_objects import GlobalCLIArgs
    CLIARGS = GlobalCLIArgs({})
    global_foo = Foo()
    assert global_foo.x is None and global_foo.y is None and global_foo.z is None

# Generated at 2022-06-20 13:55:25.576764
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({'a': 'b'})
    assert cliargs_deferred_get('a')(cliargs) == 'b'
    assert cliargs_deferred_get('a', default='c')(cliargs) == 'b'
    assert cliargs_deferred_get('a', default='c')(cliargs) == 'b'
    assert cliargs_deferred_get('b', default='c')(cliargs) == 'c'
    assert cliargs_deferred_get('b', default=['c'])(cliargs) == ['c']
    assert cliargs_deferred_get('b', default=['c'], shallowcopy=True)(cliargs) == ['c']

# Generated at 2022-06-20 13:55:34.029487
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import __main__
    import pytest
    from contextlib import contextmanager
    from ansible.utils.context_objects import CLIArgs

    @contextmanager
    def cliargs(**kwargs):
        global CLIARGS
        old_cliargs = CLIARGS
        __main__.CLIARGS = CLIARGS = CLIArgs(kwargs)
        yield
        CLIARGS = __main__.CLIARGS = old_cliargs

    def check_deferred_get(key, expected_value, *args, **kwargs):
        cliargs(**kwargs)
        assert cliargs_deferred_get(key, *args)() == expected_value
        cliargs()

    check_deferred_get('foo', 'default', 'default')


# Generated at 2022-06-20 13:55:41.906609
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    cli_args = {'test': 'foo'}

    global CLIARGS
    CLIARGS = CLIArgs(cli_args)

    foo = cliargs_deferred_get('test')
    assert foo() == 'foo'

    # Now get a deferred getter with a default
    foo = cliargs_deferred_get('other', default='bar')
    assert foo() == 'bar'



# Generated at 2022-06-20 13:55:52.878429
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'list': ['foo'], 'set': {'foo'}, 'tuple': ('foo',), 'dict': {'foo': 'bar'}}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('no_such_key')() is None
    assert cliargs_deferred_get('list')() is cli_args['list']
    assert cliargs_deferred_get('tuple')() is cli_args['tuple']
    assert cliargs_deferred_get('set')() is cli_args['set']
    assert cliargs_deferred_get('dict')() is cli_args['dict']
    assert cliargs_deferred_get('list', shallowcopy=True)() == cli_args['list']
   

# Generated at 2022-06-20 13:55:59.640914
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check(key, default, value, shallowcopy):
        inner = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)
        assert inner() == value

    def check_shallowcopy(key, value):
        inner = cliargs_deferred_get(key, shallowcopy=True)
        assert inner() == value

    # key isn't in CLIARGS so the default is returned
    check('foo', 'bar', 'bar', False)
    check('foo', 'bar', 'bar', True)

    # key is in CLIARGS so the value is returned.
    #
    # Note that it is not copied in this case because default=None and
    # the value found in CLIARGS is not a compatible type with a non-None default
    #
    # The expectation is that if a non-

# Generated at 2022-06-20 13:56:10.070712
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with CLIARGS being a local variable
    cliargs = CLIArgs({'foo': True, 'bar': 1, 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})

    # Test each type of value is returned by the inner function returned by cliargs_deferred_get
    foo = cliargs_deferred_get('foo')
    bar = cliargs_deferred_get('bar')
    baz = cliargs_deferred_get('baz')
    qux = cliargs_deferred_get('qux')

    assert foo() == True
    assert bar() == 1
    assert baz() == [1, 2, 3]
    assert qux() == {'a': 1, 'b': 2}

    # Test each type of value

# Generated at 2022-06-20 13:56:23.648210
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    class CliArgsStub(object):
        def __init__(self, data):
            self.data = data
        def get(self, key, default=None):
            return self.data.get(key, default)

    def do_test(expected, *args, **kwargs):
        assert expected == cliargs_deferred_get(*args, **kwargs)()

    # Directly testing methods of the closure instead of indirect calls via the
    # ``ContextObj`` class which makes testing more difficult
    do_test('foo', 'a', default='foo', shallowcopy=False)
    do_test('foo', 'b', default='foo', shallowcopy=False)
    do_test([1, 2, 3], 'a', default=[1, 2, 3], shallowcopy=False)

# Generated at 2022-06-20 13:56:33.858619
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    original_val = ['a', 'b', 'c']
    cli_args = {'test1': original_val}
    CLIARGS = CLIArgs(cli_args)

    def1 = cliargs_deferred_get('test1')

    # If we don't do the shallow copy, we should get the original value
    # back
    assert def1() == original_val

    # If we *do* do the shallow copy, we should get a new list
    assert id(def1()) != id(original_val)

    # If we ask for something that doesn't exist, we should get
    # the default back
    def2 = cliargs_deferred_get('test2', default=2)
    assert def2() == 2

    # If we ask for the default for something that does exist, we

# Generated at 2022-06-20 13:56:45.570249
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    foo = {'a': 1, 'b': 2, 'c': 3}
    bar = ['a', 'b', 'c']
    baz = [1, 2, 3]
    for cls in (CLIArgs, GlobalCLIArgs):
        args = cls({'foo': foo, 'bar': bar, 'baz': baz, 'qux': 'qux'})
        assert foo is cliargs_deferred_get('foo')(), "cls={}".format(type(args))
        assert bar is cliargs_deferred_get('bar')(), "cls={}".format(type(args))
        assert baz is cliargs_deferred_get('baz', shallowcopy=True)(), "cls={}".format(type(args))
        assert bar is not cliargs_

# Generated at 2022-06-20 13:56:56.321225
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    original_value = cliargs_deferred_get('--private-key-file')()
    CLIARGS = CLIArgs({'--private-key-file': '/path/to/key'})
    assert cliargs_deferred_get('--private-key-file')() == '/path/to/key'
    CLIARGS = CLIArgs({'--private-key-file': '/another/key'})
    assert cliargs_deferred_get('--private-key-file')() == '/another/key'

    # Test that it works with the default value
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('--private-key-file', default='foo')() == 'foo'

    # Test shallow copy

# Generated at 2022-06-20 13:57:03.673845
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pragma: no cover
    global CLIARGS

    # Test to see if the deferred works when run before the global is updated
    def dummy():
        return cliargs_deferred_get('test_cliargs_deferred_get', default='foo')

    CLIARGS = CLIArgs({})
    assert dummy() == 'foo'

    # Test to see if the deferred works when run after the global is updated
    CLIARGS = CLIArgs({'test_cliargs_deferred_get': 'bar'})
    assert dummy() == 'bar'

    # Test to ensure the inner closure is not affected by changing the global
    CLIARGS.update({'test_cliargs_deferred_get': 'baz'})
    assert dummy() == 'bar'

    # Test that we shallow copy

# Generated at 2022-06-20 13:57:12.395032
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''Unit test to check that cliargs_deferred_get returns expected results
    '''
    def set_cliargs_to_dict(item):
        CLIARGS.update(item)
    def set_cliargs_to_list(item):
        CLIARGS.update(item)
    def set_cliargs_to_set(item):
        CLIARGS.update(item)
    def set_cliargs_to_int(item):
        CLIARGS.update(item)
    def set_cliargs_to_none():
        CLIARGS.update({})

    # check that cliargs_deferred_get returns expected results

# Generated at 2022-06-20 13:57:21.298167
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for contextmanager cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.validation import FieldAttribute, FieldMetaclass
    #
    # Test to make sure that we get the default value when we haven't set it yet
    #
    class MyClass(object):
        """This type is used to make sure that the context manager is only called once"""
        @staticmethod
        def init_once(*args, **kwargs):
            """Inits the first time it's called.  In all other cases it raises an exception"""
            if not hasattr(MyClass, 'called'):
                MyClass.called = True
                return "Called with {} {}".format(args, kwargs)
            raise Exception("Should not be called twice")

   

# Generated at 2022-06-20 13:57:31.901213
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get(): # pylint: disable=invalid-name
    global CLIARGS

# Generated at 2022-06-20 13:57:43.231205
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = dict(
        max_plugins_per_host=10,
        plugins_dir=['/dir1', '/dir2'],
    )
    _init_global_context(cli_args)

    # test default when key not present
    getter = cliargs_deferred_get("not_an_arg")
    assert getter() == None

    # test default with key present
    getter = cliargs_deferred_get("max_plugins_per_host", default=100)
    assert getter() == 10

    # test value when key present
    getter = cliargs_deferred_get("max_plugins_per_host")
    assert getter() == 10

    # test copy a list
    getter = cliargs_deferred_get("plugins_dir", shallowcopy=True)

# Generated at 2022-06-20 13:57:53.921658
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    CLIARGS = CLIArgs({"test": [1, 2, 3]})
    assert True == cliargs_deferred_get('test')(), "get method"
    del CLIARGS
    CLIARGS = CLIArgs({"test": [1, 2, 3]})
    assert [1, 2, 3] == cliargs_deferred_get('test', shallowcopy=True)(), "get method with shallowcopy"
    del CLIARGS
    CLIARGS = CLIArgs({"test": [1, 2, 3]})
    assert [1, 2, 3] == cliargs_deferred_get('test', default=None, shallowcopy=True)(), "get method with shallowcopy and default"
    del CLIARGS

# Generated at 2022-06-20 13:58:08.720742
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.collections import ImmutableDict, ImmutableSet, MutableSet

    try:
        tempdir = TemporaryDirectory()
        ansible_config_dir = tempdir.name
        tempdir.cleanup()
    except Exception:
        pass

    global CLIARGS

# Generated at 2022-06-20 13:58:20.419079
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    from ansible.cli import CLI
    from ansible.utils.context_objects import CLIArgs

    my_args = CLI.base_parser(constants=CLIArgs.constants).parse_args([])
    assert isinstance(my_args, dict)
    _init_global_context(my_args)
    cli_args = CLIARGS
    assert isinstance(cli_args, GlobalCLIArgs)
    cli_args['bin_ansible_callbacks'] = 'foobar'
    cli_args['check'] = True

    get_check = cliargs_deferred_get('check')
    assert get_check()

    # reset CLIARGS to a new object
    temp_cliargs = CLIArgs({})
    temp_cliargs.constants = cl

# Generated at 2022-06-20 13:58:30.649360
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'key': 'value', 'key2': 'value2'})

    # Non-mutating tests
    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('key', 'default')() == 'value'
    assert cliargs_deferred_get('key_not_there')() is None
    assert cliargs_deferred_get('key_not_there', 'default')() == 'default'
    assert cliargs_deferred_get('key', default='default', shallowcopy=True)() == 'value'
    assert cliargs_deferred_get('key', default='default', shallowcopy=False)() == 'value'

# Generated at 2022-06-20 13:58:41.644853
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    CLIARGS['a'] = {'b': 'c'}
    assert cliargs_deferred_get('a')(), {'b': 'c'}
    assert cliargs_deferred_get('a', shallowcopy=True)(), {'b': 'c'}
    assert cliargs_deferred_get('a', shallowcopy=True)() is not cliargs_deferred_get('a')(), {'b': 'c'}
    CLIARGS['a'] = [1, 2, 3]
    assert cliargs_deferred_get('a')(), [1, 2, 3]
    assert cliargs_deferred_get('a', shallowcopy=True)(), [1, 2, 3]
    assert cliargs

# Generated at 2022-06-20 13:58:53.361573
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    # pylint: disable=expression-not-assigned

    # Set up some objects in the global context
    import ansible
    ansible.context._init_global_context(
        {'connection': {'timeout': 42}, 'forks': 10, 'extra-vars': [True, False, True]})
    connection_timeout = cliargs_deferred_get('connection/timeout')
    forks = cliargs_deferred_get('forks')
    extra_vars = cliargs_deferred_get('extra-vars')
    extra_vars_shallowcopy = cliargs_deferred_get('extra-vars', shallowcopy=True)

    # Test that the function correctly got the

# Generated at 2022-06-20 13:59:02.075154
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    x = cliargs_deferred_get('foo', default='bar')
    assert x() == 'bar'
    CLIARGS['foo'] = 'baz'
    assert x() == 'baz'
    CLIARGS['foo'] = ['a', 'b', 'c']
    y = cliargs_deferred_get('foo', default=None, shallowcopy=True)
    assert y() == ['a', 'b', 'c']
    assert y() is not CLIARGS['foo']

# Generated at 2022-06-20 13:59:08.024801
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for cliargs_deferred_get"""

    assert cliargs_deferred_get('not_present')() is None

    assert cliargs_deferred_get('not_present', default=1)() == 1

    CLIARGS['not_present'] = 1

    assert cliargs_deferred_get('not_present')() == 1

    assert cliargs_deferred_get('not_present', default=2)() == 1

# Generated at 2022-06-20 13:59:15.729710
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Simulate GlobalCLIArgs.from_options()
    cli_args = dict(foo='foo')
    _init_global_context(cli_args)
    cli_args['foo'] = 'bar'

    # Test no shallowcopy
    value = cliargs_deferred_get('foo')
    assert value == 'bar'

    # Test shallowcopy
    value = cliargs_deferred_get('foo', shallowcopy=True)
    assert value == 'bar'
    cli_args['foo'] = 'baz'
    assert value == 'bar'

    # Test nominal default
    value = cliargs_deferred_get('bar', 'bar')
    assert value == 'bar'

    # Test non-string default
    value = cliargs_deferred_get('bar', ['bar'])
   

# Generated at 2022-06-20 13:59:23.382899
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class CliArgs(Mapping):
        def __init__(self, value):
            self.value = value

        def __getitem__(self, key):
            return self.value[key]

        def __iter__(self):
            return iter(self.value)

        def __len__(self):
            return len(self.value)

    cliargs = CliArgs({'key': 'value'})
    result = cliargs_deferred_get('key')(cliargs)
    assert result == 'value'
    result = cliargs_deferred_get('default_key', default='default_value')(cliargs)
    assert result == 'default_value'
    result = cliargs_deferred_get('key', shallowcopy=True)(cliargs)
    assert result == 'value'
    result

# Generated at 2022-06-20 13:59:34.752149
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cli_args
    _init_global_context(cli_args)
    assert cliargs_deferred_get is CLIArgs.deferred_get

    cliargs = CLIArgs({'v': 1, 'extra-vars': [1, 2, 3], 'check': True})
    actual = cliargs_deferred_get('v', 'foo')()
    assert actual == 1
    actual = cliargs_deferred_get('bogus', 'foo')()
    assert actual == 'foo'
    actual = cliargs_deferred_get('extra-vars', shallowcopy=True)()
    assert actual == [1, 2, 3]
    cliargs['extra-vars'].append(4)

# Generated at 2022-06-20 13:59:54.818696
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    if CLIARGS:
        raise AssertionError("Expected CLIARGS to not have been initialized")

    # Test to make sure the function is callable
    cliargs_deferred_get('--something-not-in-cliargs', default=2)()

    cliargs = CLIArgs({'something-in-cliargs': ['something']})
    global CLIARGS
    CLIARGS = cliargs

    cliargs_deferred_get('something-in-cliargs', default=3)()
    cliargs_deferred_get('something-in-cliargs', default=3, shallowcopy=True)()

    if cliargs_deferred_get('something-not-in-cliargs', default=3)() != 3:
        raise AssertionError("Expected default value to propagate")

    CLIARGS

# Generated at 2022-06-20 14:00:05.395539
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update(dict(a=[1, 2, 3], b='foo'))
    assert cliargs_deferred_get('a') == [1, 2, 3]
    assert cliargs_deferred_get('a', shallowcopy=True) == [1, 2, 3]
    assert cliargs_deferred_get('b') == 'foo'
    assert cliargs_deferred_get('b', shallowcopy=True) == 'foo'
    assert cliargs_deferred_get('c') is None
    assert cliargs_deferred_get('c', 'foo') == 'foo'
    assert cliargs_deferred_get('c', 'foo', True) == 'foo'

# Generated at 2022-06-20 14:00:14.307961
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'val': 'now'})
    assert cliargs_deferred_get('val')() == 'now'
    assert cliargs_deferred_get('notaval')() == None
    assert cliargs_deferred_get('notaval', 'default')() == 'default'
    CLIARGS = CLIArgs({'val': [1, 2, 3]})
    assert cliargs_deferred_get('val')() == [1, 2, 3]
    assert cliargs_deferred_get('val', shallowcopy=True)() == [1, 2, 3]
    CLIARGS = CLIArgs({'val': {'a': 'b'}})
    assert cliargs_deferred_get('val')() == {'a': 'b'}
   

# Generated at 2022-06-20 14:00:21.423494
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import mock

    # Create a test class
    class TestCLIArgs(object):
        def __getitem__(self, key):
            return self.__dict__[key]
        def get(self, key, default=None):
            return self.__dict__.get(key, default)
        def __setitem__(self, key, value):
            self.__dict__[key] = value
        def __iter__(self):
            return iter(self.__dict__)
        def __len__(self):
            return len(self.__dict__)

    # Test that the default value is used if the key is not found in the CLIARGS context
    with mock.patch.object(CLIARGS, 'get', side_effect=KeyError):
        test_args = TestCLIArgs()
        test_args

# Generated at 2022-06-20 14:00:27.997228
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    f = cliargs_deferred_get('foo')
    assert f() == 'bar'
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert f() == 'baz'

# Generated at 2022-06-20 14:00:35.148532
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Inner function to create the closure
    mock_cliargs = {
        'b': 'b_value',
        'c': 'c_value',
        'd': ['d_list'],
        'e': {'e_dict': 'e_value'},
        'f': {'f_dict': 'f_value'},
    }

    def test_inner(key, default, shallowcopy):
        """Mock the inner function"""
        inner = cliargs_deferred_get(key, default, shallowcopy)

        # Verify that the closure does not run until after CLIARGS is set up

# Generated at 2022-06-20 14:00:46.306113
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = {
        'foo': ['bar'],
        'baz': {'baz': 'baz'}
    }
    cliargs['deferred'] = cliargs_deferred_get('foo', shallowcopy=True)
    global CLIARGS
    CLIARGS = CLIArgs(cliargs)
    assert CLIARGS['deferred'] == cliargs['foo']
    new_foo = ['new', 'foo']
    cliargs['foo'] = new_foo
    assert CLIARGS.get('foo') == new_foo
    assert CLIARGS['deferred'] == cliargs['foo']

    cliargs['deferred'] = cliargs_deferred_get('baz', shallowcopy=True)
    assert CLIARGS.get('baz') == cliargs['baz']


# Generated at 2022-06-20 14:00:57.430577
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from types import FunctionType

    f = cliargs_deferred_get('hosts')
    assert isinstance(f, FunctionType)

    host_list = ['1.2.3.4', '5.6.7.8']
    CLIARGS['hosts'] = host_list

    out = f()
    assert isinstance(out, list)
    assert out is not host_list
    assert out == host_list

    out = f(shallowcopy=False)
    assert isinstance(out, list)
    assert out is not host_list
    assert out == host_list

    out = f(shallowcopy=True)
    assert isinstance(out, list)
    assert out is not host_list
    assert out == host_list

    host_str = 'ansible@example.com:2222'


# Generated at 2022-06-20 14:01:08.963101
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils._text import to_text

    class _GlobalCLIArgs(GlobalCLIArgs):
        def __init__(self, keys=None, vars=None):
            super(_GlobalCLIArgs, self).__init__()
            self.keys = keys if keys is not None else {}
            self.vars = vars if vars is not None else {}

        def __getitem__(self, item):
            return self.keys[item]

        def get(self, item, default=None):
            try:
                return self.keys[item]
            except KeyError:
                return default

        @property
        def extra_vars(self):
            return self.vars

    assert cliargs_deferred_get('DEFAULT')().get('foo') is None
    assert cliargs

# Generated at 2022-06-20 14:01:18.538714
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    list_val = ['first', 'second', 'third']

    # global CLIARGS not set
    inner = cliargs_deferred_get('list', list_val, shallowcopy=False)
    assert inner() == ['first', 'second', 'third']
    assert id(inner()) != id(list_val)
    inner = cliargs_deferred_get('list', list_val, shallowcopy=True)
    assert inner() == ['first', 'second', 'third']
    assert id(inner()) != id(list_val)

    # giobal CLIARGS set
    CLIARGS = CLIArgs({'list': ['fourth', 'fifth']})
    inner = cliargs_deferred_get('list', list_val, shallowcopy=False)


# Generated at 2022-06-20 14:01:43.583402
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(None)() is None
    assert cliargs_deferred_get('hello', default='world')(), 'world'
    CLIARGS['hello'] = 'bar'
    assert cliargs_deferred_get('hello', default='world')() == 'bar'
    assert cliargs_deferred_get('hello', default='world', shallowcopy=True)() == 'bar'
    CLIARGS['hello'] = ['foo', 'bar']
    assert cliargs_deferred_get('hello', shallowcopy=True)() == ['foo', 'bar']

# Generated at 2022-06-20 14:01:54.742180
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.collections import Mapping, Set

    # Mock out CLIARGS
    global CLIARGS
    orig_cliargs = CLIARGS
    def _inner_test():
        # Get value of CLIARGS
        orig_cliargs_value = orig_cliargs.get('foo', None)

        # simple value
        CLIARGS = CLIArgs({'foo': 'bar'})
        assert cliargs_deferred_get('foo')() == 'bar'
        assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

        # list copy
        CLIARGS = CLIArgs({'foo': ['bar1', 'bar2']})
        assert cliargs_deferred_get

# Generated at 2022-06-20 14:02:02.088023
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test default
    assert cliargs_deferred_get('key1')(value=None) is None
    assert cliargs_deferred_get('key2', default=42)(value=None) == 42

    # Test direct retrieval
    CLIARGS['key3'] = 42
    assert cliargs_deferred_get('key3')(value=None) == 42

    # Test direct retrieval with .get syntax (with default)
    assert cliargs_deferred_get('key4', default=42)(value=None) == 42



# Generated at 2022-06-20 14:02:05.005745
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Deferred getter always uses the global cliargs object
    defaults = {
        'foo': 'bar',
    }
    global CLIARGS
    CLIARGS = CLIArgs(defaults)
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    CLIARGS = CLIArgs({})

# Generated at 2022-06-20 14:02:10.719973
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence

    value = []
    value2 = {}
    value3 = set()
    value4 = 'string'
    value5 = 1
    cli_args = {'test': value, 'test2': value2, 'test3': value3, 'test4': value4, 'test5': value5}
    _init_global_context(cli_args)

    deferred_value = cliargs_deferred_get('test', shallowcopy=True)
    assert value == deferred_value()
    assert value is not deferred_value()

    deferred_value2 = cliargs_deferred_get('test2', shallowcopy=True)
    assert value2 == deferred_value2()
    assert value2 is not deferred_value2()

    deferred_value3 = cl

# Generated at 2022-06-20 14:02:21.451509
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # NOTE: Most of the functionality of this function is covered in the test for
    # ``FieldAttribute``
    cliargs = {'test_key': 456}
    _init_global_context(cliargs)

    # Test the default case
    default_func = cliargs_deferred_get('non_key')
    assert default_func() is None

    # Test getting a normal key
    default_func = cliargs_deferred_get('test_key')
    assert default_func() == 456

    # Test passing a shallow value in
    shallow_func_1 = cliargs_deferred_get('test_key', shallowcopy=True)
    assert shallow_func_1() == 456

    # Test passing a value that is already shallow copied

# Generated at 2022-06-20 14:02:26.932053
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make the function not be a closure function
    # pylint: disable=cell-var-from-loop
    def _init_global_context(cli_args):
        global CLIARGS
        CLIARGS.reinitialize(cli_args)

    from ansible.module_utils._text import to_text
    _init_global_context({})
    for key, value in dict(one=1, two=2, three=(1, 2, 3), four={'a': 1, 'b': 2}).items():
        get_default = cliargs_deferred_get(key, default=value)
        assert get_default() is value
        _init_global_context({key: value})
        assert get_default() is value
        # shallow copy
        shallow_value = get_default(shallowcopy=True)


# Generated at 2022-06-20 14:02:38.129742
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCLIArgs(CLIArgs):
        def __init__(self, attrs):
            self.attrs = attrs
        def __getitem__(self, key):
            return self.attrs[key]
        def get(self, key, default=None):
            return self.attrs.get(key, default)

    # Test normal case
    global CLIARGS
    CLIARGS = TestCLIArgs({'a': 42})
    assert cliargs_deferred_get('a')() == 42

    # Test when it doesn't exist
    assert cliargs_deferred_get('b')() is None

    # Test when it doesn't exist but a default was provided
    assert cliargs_deferred_get('b', default=43)() == 43

    # Test when a copy is needed
    CLI

# Generated at 2022-06-20 14:02:46.456823
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2], 'c': {'d': 1}})
    assert cliargs_deferred_get(key='a')() == 1
    assert cliargs_deferred_get(key='b')() == [1, 2]
    assert cliargs_deferred_get(key='c')() == {'d': 1}
    assert cliargs_deferred_get(key='a', default=2)() == 1
    assert cliargs_deferred_get(key='d', default=2)() == 2
    assert cliargs_deferred_get(key='a', shallowcopy=True)() is CLIARGS.get('a')

# Generated at 2022-06-20 14:02:55.345207
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.text.converters import to_bytes
    import sys
    import subprocess

# Generated at 2022-06-20 14:03:42.515590
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _test_case(key, value):
        assert value == cliargs_deferred_get(key)()

    def _test_case_with_default(key, value):
        assert value == cliargs_deferred_get(key, default=value)()

    _test_case('inventory', [])
    _test_case('inventory_file', None)
    _test_case('action_plugins', [])
    _test_case('delegate_to', None)
    _test_case('host_pattern', '*')
    _test_case('host_pattern_raw', 'all')
    _test_case('vault_identity', 'default')
    _test_case('vault_identity_file', '~/.ansible/vault')

# Generated at 2022-06-20 14:03:54.174661
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # An actual function reference is used so we can mock it
    from ansible.utils.context_objects import cliargs_deferred_get

    # pylint: disable=protected-access,unidiomatic-typecheck,anomalous-backslash-in-string
    class MockCLIArgs(dict):
        """Mock ``CLIArgs`` for testing"""
        def _get_from_dict(self, key, default=None):
            return super(MockCLIArgs, self).get(key, default=default)

        def _get_from_attr(self, key, default=None):
            return getattr(self, key, default=default)


# Generated at 2022-06-20 14:04:02.393044
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get"""
    # Test for default return
    obj = cliargs_deferred_get('key_not_in_dict', default=1)
    assert 1 == obj()

    # Test for existence
    cliargs = CLIArgs({'key_in_dict': 3})
    obj = cliargs_deferred_get('key_in_dict', cliargs=cliargs)
    assert obj() == 3

    # Test to make sure we are actually using the bound variable
    cliargs = CLIArgs({'key_in_dict': 4})
    obj = cliargs_deferred_get('key_in_dict', cliargs=cliargs)
    assert obj() == 4

    # Test shallow copy
    in_list = [1, 2]
    cliargs = CLI

# Generated at 2022-06-20 14:04:14.060404
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    cli_args = {'foo': 'foo', 'bar': [1,2,3], 'baz': {'a': 1}, 'quux': {1,2,3}}
    _init_global_context(cli_args)
    foo = cliargs_deferred_get('foo')
    assert foo() == 'foo'
    bar = cliargs_deferred_get('bar', shallowcopy=True)
    assert bar() == [1,2,3]
    baz = cliargs_deferred_get('baz', shallowcopy=True)
    assert baz() == {'a': 1}
    quux = cliargs_def

# Generated at 2022-06-20 14:04:23.955625
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import OrderedDict, Mapping
    from ansible.module_utils.six import PY2

    global CLIARGS
    cliargs_val = OrderedDict((('test', 'test'), ('test2', 'test2'), ('test3', 'test3')))
    CLIARGS = GlobalCLIArgs.from_options(cliargs_val)

    # test use of inner closure
    get_test = cliargs_deferred_get('test')
    assert get_test() == 'test'
    get_test2 = cliargs_deferred_get('test2')
    assert get_test2() == 'test2'
    get_test3 = cliargs_deferred_get('test3')

# Generated at 2022-06-20 14:04:33.842453
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    # Run for before the context has been set to ensure that the returned function
    # will work even when the context hasn't been set yet
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('verbosity', 2, shallowcopy=False)() == 2
    assert cliargs_deferred_get('verbosity', 2, shallowcopy=True)() == 2

    # Run for after the context has been set
    CLIARGS = GlobalCLIArgs({'verbosity': 1})
    assert cliargs_deferred_get('verbosity', 2, shallowcopy=False)() == 1
    assert cliargs_deferred_get('verbosity', 2, shallowcopy=True)() == 1