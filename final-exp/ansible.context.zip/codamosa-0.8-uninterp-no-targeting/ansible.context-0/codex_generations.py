

# Generated at 2022-06-20 13:54:44.591810
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Test that the default gets returned when there is no value in the cliargs
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default=1) == 1
    assert cliargs_deferred_get('foo', default='1') == '1'
    assert cliargs_deferred_get('foo', default=True) == True
    assert cliargs_deferred_get('foo', default=False) == False
    assert cliargs_deferred_get('foo', default=None) == None

    # Test that the value in the class is gotten if it is set
    CLIARGS.update(foo=1)
    assert cliargs_deferred_get('foo') == 1

# Generated at 2022-06-20 13:54:50.742401
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    global CLIARGS
    dummy_default = object()
    assert cliargs_deferred_get('key', default=dummy_default)() is dummy_default
    assert cliargs_deferred_get('key')() is None
    CLIARGS = CLIArgs({'key': 'value'})
    assert cliargs_deferred_get('key')() == 'value'
    # pylint: enable=unused-variable

# Generated at 2022-06-20 13:54:58.718845
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Function cliargs_deferred_get testing"""
    local_cliargs = CLIArgs({'mykey': [1, 2, 3]})
    global CLIARGS
    CLIARGS = local_cliargs  # pylint: disable=global-statement
    value = cliargs_deferred_get('mykey')()
    assert value == [1, 2, 3]
    value = cliargs_deferred_get('mykey', shallowcopy=True)()
    assert value == [1, 2, 3]
    assert value is not CLIARGS['mykey']  # pylint: disable=unsupported-membership-test

    value = cliargs_deferred_get('mykey', default={'k': 'v'})()
    assert value == {'k': 'v'}  # pylint: disable

# Generated at 2022-06-20 13:55:07.513351
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    import mock

    _init_global_context(dict())
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    _init_global_context(dict(foo='baz'))
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'
    assert cliargs_deferred_get('not_foo', default='bar')() == 'bar'

    l = [1, 2, 3]
    with mock.patch.object(l, '__getitem__', mock.Mock(side_effect=lambda x: l[x])):
        _init_global_context(dict(foo=l))

# Generated at 2022-06-20 13:55:18.504385
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access

    # sanity check the function works on a direct access
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)

    assert CLIARGS._cli_args is cli_args
    assert CLIARGS.get('foo') == 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('missing')() is None
    assert cliargs_deferred_get('missing', 1)() == 1

    assert CLIARGS._cli_args == cli_args
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'  # for non-mutable objects shallow copy returns original

# Generated at 2022-06-20 13:55:30.080443
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({'bar': 'baz'})
    # Test inner function
    assert cliargs_deferred_get('bar')() == 'baz'
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    assert cliargs_deferred_get('bar', default='foo')() == 'baz'
    # Test with peeped closure
    foo = cliargs_deferred_get('foo')
    assert foo() == None
    assert foo() == None
    foo = cliargs_deferred_get('foo', default='bar')
    assert foo() == 'bar'
    assert foo() == 'bar'
    foo = cliargs_deferred_get('foo')
    assert foo() == None
    assert foo() == None

# Generated at 2022-06-20 13:55:42.034213
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # can just return the default
    result = cliargs_deferred_get('does not exist')(None)
    assert result is None

    result = cliargs_deferred_get('does not exist', default='foo')(None)
    assert result == 'foo'

    # get the value
    CLIARGS['this exists'] = 'bar'
    result = cliargs_deferred_get('this exists')(None)
    assert result == 'bar'
    result = cliargs_deferred_get('this exists', default='foo')(None)
    assert result == 'bar'

    # copyable
    result = cliargs_deferred_get('this exists', shallowcopy=True)(None)
    assert result == 'bar'

# Generated at 2022-06-20 13:55:47.904793
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Test that inner() has access to the scope of cliargs_deferred_get
    inner = cliargs_deferred_get('key')
    CLIARGS = CLIArgs({'key': True})
    assert inner()

    # Test that inner() uses the current value of CLIARGS
    CLIARGS = CLIArgs({})
    assert not inner()

# Generated at 2022-06-20 13:55:55.704351
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    >>> CLIARGS._store['foo'] = 'bar'
    >>> bar = cliargs_deferred_get('foo')
    >>> assert bar() == 'bar'
    >>> assert bar() is bar()
    >>> foo_shallowcopy = cliargs_deferred_get('foo', default=[], shallowcopy=True)
    >>> bar_shallowcopy = cliargs_deferred_get('bar', default=[], shallowcopy=True)
    >>> assert foo_shallowcopy() is foo_shallowcopy()
    >>> assert foo_shallowcopy()[:] == ['b', 'a', 'r']
    >>> assert bar_shallowcopy() == []
    """

# Generated at 2022-06-20 13:56:07.533411
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test function works with getting values
    import os
    os.environ['ANSIBLE_FOO'] = 'bar'
    os.environ['ANSIBLE_LIST'] = 'a,b,c'
    os.environ['ANSIBLE_DICT'] = '{"a":1,"b":2,"c":3}'
    from ansible.modules.system import ping

    # This is a list
    original_list = ['a', 'b', 'c', 'd']
    default_list = cliargs_deferred_get('ANSIBLE_LIST')()
    # The default value is returned if environment variable is not set
    assert default_list == original_list
    # And then works, even after replacement of the global CLIARGS
    CLIARGS['ANSIBLE_LIST'] = 'foo,bar'
    assert cliargs_

# Generated at 2022-06-20 13:56:20.607773
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'foo', 'bar': [1, 2, 3], 'baz': {'one': 1, 'two': 2}})
    get_foo = cliargs_deferred_get('foo')
    get_bar = cliargs_deferred_get('bar')
    get_baz = cliargs_deferred_get('baz')
    get_default = cliargs_deferred_get('foobar')

    assert get_foo() == 'foo'
    assert get_bar() == [1, 2, 3]
    assert get_baz() == {'one': 1, 'two': 2}
    assert get_default() is None

    # Now test the shallow copy
    CLIARGS['bar'].append(4)

# Generated at 2022-06-20 13:56:32.016041
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    global CLIARGS
    testargs = {'key': ['val1', 'val2'], 'other': {'nestkey': 'nestval'}}
    CLIARGS = CLIArgs(testargs)

    val = cliargs_deferred_get('key')
    assert val() is testargs['key']

    val = cliargs_deferred_get('key', shallowcopy=True)
    assert val() is testargs['key']
    assert val() is not testargs['key']
    assert val() == testargs['key']

    val = cliargs_deferred_get('other', shallowcopy=True)
    assert val() is testargs['other']
    assert val() is not testargs['other']
    assert val() == testargs['other']

   

# Generated at 2022-06-20 13:56:38.022840
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-argument, redefined-outer-name
    # This function requires pytest-mock to work.
    import pytest
    import copy
    import pdb
    from ansible.utils.context_objects import CliArgs
    from ansible.utils.context_objects import CLIARGS as _CLIARGS
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    testargs = {'a': 'b', 'c': [1, 2, 3], 'd': {'a': 'b'}, 'e': set([1, 2, 3])}
    testdefault = 'testdefault'


# Generated at 2022-06-20 13:56:48.926208
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is a one off test to make sure that cliargs_deferred_get is working as expected.
    # As such it doesn't need to be as robust as the test framework normally uses. Eg: it
    # doesn't explicitly load and unload minimum imports
    import pytest
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2]})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2]
    assert cliargs_deferred_get('c')() is None
    assert cliargs_deferred_get('c', default=3)() == 3
    with pytest.raises(KeyError):
        cliargs_deferred_get('d')()

    #

# Generated at 2022-06-20 13:56:55.319468
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the value when called"""
    test_dict = {'foo': 1}
    value = cliargs_deferred_get('bar', default=test_dict)
    assert value() == test_dict

    test_value = 'test value'
    cliargs = {'bar': test_value}
    _init_global_context(cliargs)
    assert value() == test_value

# Generated at 2022-06-20 13:57:02.781926
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-20 13:57:11.280303
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('nope')(), None
    assert cliargs_deferred_get('nope', default='foo')(), 'foo'
    assert cliargs_deferred_get('nope', default=['foo'])(), ['foo']

    # Test shallow copy
    shallow_copy_list = cliargs_deferred_get('nope', default=['foo'], shallowcopy=True)()
    shallow_copy_list.append('bar')
    shallow_copy_list.append('qux')

    assert cliargs_deferred_get('nope', default=['foo'])(), ['foo']
    assert cliargs_deferred_get('nope', default=['foo'], shallowcopy=True)(), ['foo']

    # Test shallow copy with dicts
    shallow_copy_

# Generated at 2022-06-20 13:57:20.802011
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test for invalid nested calls
    assert 'allow_deferred_invalid_nested' in globals()
    allow_deferred_invalid_nested = allow_deferred_invalid_nested
    assert 'allow_deferred_invalid_nested' in globals()
    del allow_deferred_invalid_nested

    # Test valid nested calls
    assert 'allow_deferred_valid_nested' in globals()
    allow_deferred_valid_nested = cliargs_deferred_get('allow_deferred_valid_nested', 'allow_deferred_valid_nested')
    assert 'allow_deferred_valid_nested' in globals()
    allow_deferred_valid_nested = allow_deferred_valid_nested

# Generated at 2022-06-20 13:57:31.505066
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    cliargs_dict = {'foo': 42}
    global CLIARGS
    CLIARGS = CLIArgs(cliargs_dict)

    answer = [42]
    assert cliargs_deferred_get('foo', default=answer, shallowcopy=True)() is answer, 'deferred_get does not return default when key not found'
    assert cliargs_deferred_get('foo', default=answer, shallowcopy=False)() is answer, 'deferred_get does not return default when key not found'

    assert cliargs_deferred_get('foo', shallowcopy=True)() == 42, 'deferred_get returns wrong value'

# Generated at 2022-06-20 13:57:37.841105
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.json_utils import _dump_result_json

    def test_json_output(data_):
        ret = _dump_result_json(data_, **CLIARGS)
        return ret

    # Test DeferredGet on a non-default value
    def get_verbosity():
        return cliargs_deferred_get('verbosity')
    CLIARGS['verbosity'] = 4
    assert get_verbosity() == 4

    # Test deferred get on a default value.
    # Test default value from a dict
    def get_json():
        return cliargs_deferred_get('json', {'foo': 'bar'})
    assert get_json() == {'foo': 'bar'}
    # Test default value from a callable

# Generated at 2022-06-20 13:57:53.208245
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    nested_dict = {'foo': 'bar'}
    nested_list = ['apple', 'banana']
    nested_set = set(['one', 'two'])
    cli_args = {'nested_dict': nested_dict,
                'nested_list': nested_list,
                'nested_set': nested_set}

    # Set up
    _init_global_context(cli_args)
    nested_dict['hello'] = 'world'
    nested_list.append('pear')
    nested_set.add('three')

    # Access the same set of keys but with and without shallow copies
    get_nested_dict = cliargs_deferred_get('nested_dict')

# Generated at 2022-06-20 13:58:03.133929
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence

    # Verify that it can return a value when CLIARGS is global
    CLIARGS['a'] = 'b'
    assert cliargs_deferred_get('a')() == 'b'
    # and that it can return a sequence with shallow copy
    CLIARGS['c'] = [1, 2, 3]
    assert cliargs_deferred_get('c', shallowcopy=True)() == [1, 2, 3]
    assert is_sequence(cliargs_deferred_get('c', shallowcopy=True)())
    # and that it can return a mapping with shallow copy
    CLIARGS['d'] = {'e': 'f'}

# Generated at 2022-06-20 13:58:11.749780
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    def test_value():
        return 7

    # Test that the value is returned directly
    assert cliargs_deferred_get('foo', default=test_value)() is test_value

    # Test that the default is returned when the value isn't there
    assert cliargs_deferred_get('foo', default=test_value)() is test_value

    # Test that the value is returned
    CLIARGS.update(foo=test_value)
    assert cliargs_deferred_get('foo', default=test_value)() is test_value

    # Test that the value is returned when the value isn't there
    assert cliargs_deferred_get('foo', default=test_value)() is test_value

    # Test that a copy is returned when shallow copy is set to True
    assert cliargs_deferred_

# Generated at 2022-06-20 13:58:23.104070
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from types import ModuleType
    from unittest.mock import Mock, patch

    mod = ModuleType(__name__)
    mod.CLIARGS = Mock(wraps=dict, spec=dict)
    with patch.dict(__builtins__, {'__import__': lambda *x: mod}):
        from ansible.utils.context_objects import cliargs_deferred_get

    arg_dict = {'key1': [], 'key2': {}, 'key3': set()}
    mod.CLIARGS.get.return_value = arg_dict['key1']
    cli_get = cliargs_deferred_get('key1')
    cli_get_default = cliargs_deferred_get('key1', default='default')
    cli_get_shallowcopy = cl

# Generated at 2022-06-20 13:58:28.887915
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test we can get a key from CLIARGS"""
    assert not CLIARGS
    CLIARGS['testing'] = True

    assert cliargs_deferred_get('testing')()
    del CLIARGS['testing']

    assert not CLIARGS

    CLIARGS['testing'] = True
    assert cliargs_deferred_get('testing')()
    global CLIARGS
    CLIARGS = CLIArgs({})

    assert not CLIARGS

# Generated at 2022-06-20 13:58:35.008171
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    import pytest

    def check(nested, output):
        for key in output:
            assert key in nested
            if key in output:
                assert output[key] == nested[key]

    from ansible.utils.context_objects import CLIArgs
    CLIARGS = CLIArgs({
        'something_iterable': [1, 5, 2, 3],
        'something_map': {'a': 'b', 'c': 'd'},
        'something_set': {1, 2, 3},
    })

    # get(<key>) should return an unmodified value
    obj1 = CLIARGS.get('something_iterable')
    obj2 = CLIARGS.get('something_set')
    obj3 = CLIARGS.get('something_map')

# Generated at 2022-06-20 13:58:42.216808
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    old_cliargs = CLIARGS
    try:
        CLIARGS.update({'test': {'test2': 'test'}})
        assert('test' == cliargs_deferred_get('test')())
        CLIARGS = CLIArgs({'test': 'test'})
        assert('test' == cliargs_deferred_get('test')())
    finally:
        CLIARGS = old_cliargs

# Generated at 2022-06-20 13:58:53.605059
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import sys
    import unittest
    from ansible.module_utils.common.collections import is_sequence

    class TestCliargsDeferredGet(unittest.TestCase):
        def setUp(self):
            global CLIARGS
            CLIARGS = CLIArgs(cli_args={'list': [1, 2, 3], 'dict': {'a': 1, 'b': 2, 'c': 3}})

        def test_no_default_value(self):
            cliargs_deferred_get_inner = cliargs_deferred_get('list')
            self.assertEqual(cliargs_deferred_get_inner(), [1, 2, 3])


# Generated at 2022-06-20 13:59:05.393112
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'one': 1,
                'two': 'two',
                'three': [3, 3.3],
                'four': {'four': 4,
                         'fourfour': 44},
                'five': frozenset(['five', 'fiver', 'fives'])}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('one')() == 1
    # Test the default
    assert cliargs_deferred_get('nothere')() is None
    assert cliargs_deferred_get('nothere', default='nothere')() == 'nothere'

    # Shallow copy checks
    shallow_copy = cliargs_deferred_get('one', shallowcopy=True)()
    assert shallow_copy == 1
    # Change the copy
   

# Generated at 2022-06-20 13:59:14.543394
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = {'foo': [1, 2, 3], 'bar': {'baz': 'bak'}, 'flaz': set(['a', 'b', 'c'])}

    _init_global_context(cliargs)

    for l in (cliargs_deferred_get('foo'), cliargs_deferred_get('bar'), cliargs_deferred_get('flaz')):
        assert l() != cliargs['foo']
        assert l() == cliargs['foo']
        assert l() is not cliargs['foo']

    for l in (cliargs_deferred_get('foo', shallowcopy=True), cliargs_deferred_get('bar', shallowcopy=True), cliargs_deferred_get('flaz', shallowcopy=True)):
        assert l() != cliargs

# Generated at 2022-06-20 13:59:34.114093
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'

    # Test a list
    _init_global_context({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo')() is not cliargs_deferred_get('foo')()

# Generated at 2022-06-20 13:59:42.851157
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Enable deepcopy in this test so that it is tested
    class FakeCliArgs(dict):
        def deepcopy(self, value):
            return value

    global CLIARGS
    test_dict = {'a': 'a_value',
                 'b': ['b0', 'b1'],
                 'c': {'c0': 'c0_value', 'c1': 'c1_value'}}

    CLIARGS = FakeCliArgs(test_dict)
    for key, value in test_dict.items():
        # Check that the default value works
        assert cliargs_deferred_get('z')(), None
        # Check that we get the value back
        assert cliargs_deferred_get(key)(), value
        # Check that we don't get a reference to the original value back
        assert cl

# Generated at 2022-06-20 13:59:54.697267
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    l = ['foo', 'bar']
    m = {'foo': 1, 'bar': 2}
    s = set(['foo', 'bar'])
    for v in (None, 'foo', l, m, s):
        assert cliargs_deferred_get('nokey', v)() == v
    assert cliargs_deferred_get('nokey', l, shallowcopy=True)() is not l
    assert cliargs_deferred_get('nokey', m, shallowcopy=True)() == m
    assert cliargs_deferred_get('nokey', s, shallowcopy=True)() == s

    CLIARGS = CLIArgs({'foo': 1})
    assert cliargs_deferred_get('foo')(), 1

# Generated at 2022-06-20 13:59:56.574127
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import doctest
    doctest.run_docstring_examples(cliargs_deferred_get, globals())

# Generated at 2022-06-20 14:00:07.565564
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # First test case: missing key
    old_cliargs = CLIARGS

# Generated at 2022-06-20 14:00:16.096561
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that the deferred get functions properly"""
    global CLIARGS
    CLIARGS = CLIArgs({'test': 'foo'})

    assert cliargs_deferred_get('test')() is 'foo'
    assert cliargs_deferred_get('test', shallowcopy=True)() is 'foo'

    CLIARGS['test'] = {'value': 'bar'}
    assert cliargs_deferred_get('test')() is CLIARGS['test']
    assert cliargs_deferred_get('test', shallowcopy=True)() == {'value': 'bar'}

    CLIARGS['test'] = ['value']
    assert cliargs_deferred_get('test')() is CLIARGS['test']

# Generated at 2022-06-20 14:00:19.508979
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')(), 'bar'
    assert cliargs_deferred_get('foo', default='baz')(), 'bar'
    assert cliargs_deferred_get('baz', default='baz')(), 'baz'

# Generated at 2022-06-20 14:00:31.389722
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['test_key'] = 123
    value = cliargs_deferred_get('test_key')
    value() == 123

    value = cliargs_deferred_get('test_key', shallowcopy=True)
    value() == 123

    CLIARGS['test_list'] = [1,2,3]
    value = cliargs_deferred_get('test_list', shallowcopy=True)
    value() == [1,2,3]
    value() is not CLIARGS['test_list']

    CLIARGS['test_dict'] = {'a': 1, 'b': 2}
    value = cliargs_deferred_get('test_dict', shallowcopy=True)
    value() == {'a': 1, 'b': 2}

# Generated at 2022-06-20 14:00:35.748221
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    check_cliarg_get('k', 'k', 'v1', 'v1')
    check_cliarg_get('k', 'k', 'v2', 'v2')
    check_cliarg_get('k', 'k', 'v3', 'v3')


# Generated at 2022-06-20 14:00:45.413813
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    default = 'default'
    key = 'key'
    value = 'value'
    cliargs = CLIArgs()
    cliargs[key] = value
    cliargs2 = CLIArgs()
    cliargs2[key] = None

    global CLIARGS
    CLIARGS = cliargs
    assert value == cliargs_deferred_get(key)()
    assert default == cliargs_deferred_get(key, default)()

    global CLIARGS
    CLIARGS = cliargs2
    assert None == cliargs_deferred_get(key)()
    assert default == cliargs_deferred_get(key, default)()



# Generated at 2022-06-20 14:01:01.259727
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'fie': 'baz'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('fie')() == 'baz'
    assert cliargs_deferred_get('fum', 'foo')(
    ) == 'foo', 'return default value when key is not set'

    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('fie', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('fum', 'foo', shallowcopy=True)(
    ) == 'foo', 'return default value when key is not set'

    CLIAR

# Generated at 2022-06-20 14:01:12.101542
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from .test.units.module_utils.test_ansible_context import TestCliArgsGlobal
    from .test.units.module_utils.test_ansible_context import TestCliArgs1

    assert cliargs_deferred_get('test_cliargs_globals')() is TestCliArgsGlobal

    # Test for shallow copy
    shallow_list = cliargs_deferred_get('shallow_list', shallowcopy=True)()
    shallow_list.pop()
    assert TestCliArgsGlobal['shallow_list'] == [0]

    assert TestCliArgs1 == cliargs_deferred_get('test_cliargs_1')()

    # Test for shallow copy
    shallow_dict = cliargs_deferred_get('shallow_dict', shallowcopy=True)()

# Generated at 2022-06-20 14:01:21.064462
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from nose2.tools import such
    from nose2.tools import params

# Generated at 2022-06-20 14:01:32.457508
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Note: don't try to use mock from ansible.module_utils.common._collections_compat here
    # because we need this to work in python2 and python3 and mock with
    # ``_collections_compat`` is not always available in python2
    from unittest import TestCase, main
    from unittest.mock import patch

    class MockClass(object):
        def __init__(self):
            pass
        def __call__(self):
            return 'MockClass'

    class TestCliArgsDeferredGet(TestCase):

        def test_deferred(self):
            # Test the case where the key is not in ``CLIARGS``
            with self.assertRaises(AttributeError):
                def_get = cliargs_deferred_get('MOCK_KEY')
                def_

# Generated at 2022-06-20 14:01:42.794540
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    test_cli_args = {
        'foo': ['global_foo'],
        'bar': {'global_bar': 'global_bar'},
    }
    _init_global_context(test_cli_args)

    def cliargs_get_test(key, shallowcopy=False):
        value = cliargs_deferred_get(key, shallowcopy=shallowcopy)()
        return value

    # Test actual value and shallow copy
    assert cliargs_get_test('foo', shallowcopy=False) == ['global_foo']
    assert cliargs_get_test('foo', shallowcopy=True) == ['global_foo']

    # Test setting the default

# Generated at 2022-06-20 14:01:54.073605
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    default = 'default'
    data = {'a': 'b', 'c': [1, 2]}
    CLIARGS = CLIArgs(data)
    assert cliargs_deferred_get('a')() == 'b'
    assert cliargs_deferred_get('a', shallowcopy=True)() is 'b'
    assert cliargs_deferred_get('a', shallowcopy=False)() is 'b'
    assert cliargs_deferred_get('d', default)() is default

    assert cliargs_deferred_get('d')() is None
    assert cliargs_deferred_get('d', default)() is default

    assert cliargs_deferred_get('c', shallowcopy=True)() == [1, 2]

# Generated at 2022-06-20 14:02:04.264898
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''Test function cliargs_deferred_get

    This has to be called with the CLIARGS object removed or else it will fail.
    '''
    global CLIARGS
    old_cliargs = CLIARGS
    CLIARGS = None

# Generated at 2022-06-20 14:02:10.365943
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default=False)() is False
    assert cliargs_deferred_get('doesnotexist', default=False)() is False
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    # Test shallowcopy
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})

# Generated at 2022-06-20 14:02:20.989749
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # pylint: disable=invalid-name
    class MyDict(dict):
        '''A dict that will raise an exception if copied'''
        def copy(self):
            raise Exception('Not allowed to copy me')

    class TestCliArgs(object):
        def get(self, key, default=None):
            if key == 'key1':
                return 'first'
            if key == 'key2':
                return 'second'
            if key == 'key3':
                return [1, 2, 3, 4]
            if key == 'key4':
                return ['a', 'b', 'c', 'd']
            if key == 'key5':
                return MyDict(key1='first')

    CLIARGS = TestCliArgs()
    assert cliargs_deferred_get('key1')()

# Generated at 2022-06-20 14:02:23.797415
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'
    x = cliargs_deferred_get('foo')
    y = cliargs_deferred_get('foo')
    assert x == 'bar'
    assert y == 'bar'
    assert x is y



# Generated at 2022-06-20 14:02:42.072718
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    global CLIARGS
    CLIARGS = CLIArgs({'key': 'value'})
    assert cliargs_deferred_get('key')() == 'value'
    assert cliargs_deferred_get('notakey', 'foo')() == 'foo'

    cli_args = CLIArgs({'key': [1, 2, 3]})
    assert cliargs_deferred_get('key')() == [1, 2, 3]
    assert cliargs_deferred_get('key', shallowcopy=True)() == [1, 2, 3]
    CLIARGS.args['key'].append(4)
    assert cliargs_deferred_get('key')() == [1, 2, 3, 4]

# Generated at 2022-06-20 14:02:49.079722
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(Foo='bar'))
    orig_value = CLIARGS

# Generated at 2022-06-20 14:02:56.409130
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Test(object):
        foo = cliargs_deferred_get('foo')
    options = {'foo': 'bar'}
    _init_global_context(options)
    t = Test()
    assert t.foo == 'bar'

    # Deferred options should work with changing the global context
    options2 = {'foo': 'baz'}
    _init_global_context(options2)
    assert t.foo == 'baz'

    # Deferred options with default values should also work
    class Test2(object):
        foo = cliargs_deferred_get('foo', default='default')
    options3 = {}
    _init_global_context(options3)
    t2 = Test2()
    assert t2.foo == 'default'

    # Deferred options with shallowcopy=True should create

# Generated at 2022-06-20 14:03:08.440691
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    __tracebackhide__ = True
    old_cliargs = CLIARGS
    CLIARGS = CLIArgs({'key1': 'value1', 'key2': 'value2'})

# Generated at 2022-06-20 14:03:18.426711
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # not shallow copied
    assert cliargs_deferred_get('test')('test') == 'test'
    assert cliargs_deferred_get('test', 'default')('test') == 'test'
    assert cliargs_deferred_get('test', default='default')('test') == 'test'

    assert cliargs_deferred_get('test', shallowcopy=True)(['test'])[0] == 'test'
    assert cliargs_deferred_get('test', 'default', shallowcopy=True)(['test'])[0] == 'test'
    assert cliargs_deferred_get('test', default=['default'], shallowcopy=True)(['test'])[0] == 'test'


# Generated at 2022-06-20 14:03:24.666489
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Make sure that the cliargs_deferred_get works as expected"""
    CLIARGS.data = {'name': 123}
    dgfunc = cliargs_deferred_get('name')
    assert dgfunc() == 123

# Generated at 2022-06-20 14:03:33.397088
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for function cliargs_deferred_get

    This unit test is returning value from CLIARGS instead of using __getitem__ to
    also test returning default values
    """
    _init_global_context(dict(a=1))
    # testing returning default values
    assert cliargs_deferred_get('b', default=2)() == 2
    assert cliargs_deferred_get('b', default=None)() is None

    # Ensure we just return the value without shallow copying
    assert cliargs_deferred_get('a', shallowcopy=False)() == 1
    assert cliargs_deferred_get('a', default=None, shallowcopy=False)() == 1
    # ensure we shallow copy correctly
    t = (3, 4)
    CLIARGS['t'] = t
    assert cl

# Generated at 2022-06-20 14:03:43.302879
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    class TestClass(object):
        def __init__(self):
            self.value = cliargs_deferred_get('test_value', default='default')
            self.value_shallow = cliargs_deferred_get('test_value_shallow', default=[], shallowcopy=True)
            self.value_shallow_mapping = cliargs_deferred_get('test_value_shallow_mapping', default={}, shallowcopy=True)

    _init_global_context({'test_value': 'something',
                          'test_value_shallow': [1, 2, 3],
                          'test_value_shallow_mapping': {'a': 'b'}})
    expected_value = CLIARGS['test_value']
    expected_value_shallow = CLIAR

# Generated at 2022-06-20 14:03:54.986929
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common import remove_values

    test_args = {'x': 'foo', 'y': ['a', 'b', 'c'], 'z': {'a': '1', 'b': '2'}}
    _init_global_context(test_args)

    assert cliargs_deferred_get('x') == test_args['x']
    assert cliargs_deferred_get('x', default='bar') == test_args['x']
    assert cliargs_deferred_get('x', default='bar', shallowcopy=True) == test_args['x']
    assert cliargs_deferred_get('q', default='bar', shallowcopy=True) == 'bar'

# Generated at 2022-06-20 14:04:02.779741
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    global CLIARGS
    CLIARGS = CLIArgs({'b': [1]})

    # non-shallow copy
    get_a = cliargs_deferred_get('a')
    get_b = cliargs_deferred_get('b')
    assert get_a is not None
    assert get_b() == [1]
    get_b().append(2)
    assert get_b() == [1, 2]

    # shallow copy
    get_a = cliargs_deferred_get('a', shallowcopy=True)
    get_b = cliargs_deferred_get('b', shallowcopy=True)
    assert get_a is not None
    assert get_b() == [1, 2]

# Generated at 2022-06-20 14:04:27.975463
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-import
    from ansible import context
    # pylint: enable=unused-import

    # CLIARGS is not present
    assert cliargs_deferred_get('foo') is None

    # CLIARGS is present but the requested key is not
    context._init_global_context({})
    assert cliargs_deferred_get('foo') is None

    # CLIARGS is present and has the requested key
    context._init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('foo', 'asdf') == 'bar'

    # CLIARGS is present but the requested key is not set
    context._init_global_context({'foo': None})


# Generated at 2022-06-20 14:04:35.717918
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    class_cliargs = CLIArgs({'var': 1})
    CLIARGS = class_cliargs
    assert cliargs_deferred_get('var')(), 1
    class_cliargs = CLIArgs({'var': [1, 2]})
    CLIARGS = class_cliargs
    assert cliargs_deferred_get('var')(), [1, 2]
    assert cliargs_deferred_get('var', shallowcopy=True)(), [1, 2]
    assert cliargs_deferred_get('var', shallowcopy=True)() is not cliargs_deferred_get('var')()
    class_cliargs = CLIArgs({'var': ({'a': 1}, {'b': 2})})
    CLI