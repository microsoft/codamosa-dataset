

# Generated at 2022-06-20 13:54:44.855668
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    # Simple test for regular usage
    CLIARGS = GlobalCLIArgs.from_options({'roles_path': ['./roles', './test/roles']})
    assert cliargs_deferred_get('roles_path') == CLIARGS['roles_path']
    # Test that we can get shallowcopy from it
    assert cliargs_deferred_get('roles_path', shallowcopy=True) == CLIARGS['roles_path'][:]
    # Test that we can override CLIARGS and still get the same functionality
    original = CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({'roles_path': ['./other_roles', './test/other_roles']})

# Generated at 2022-06-20 13:54:54.180954
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import Mapping
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': 'foo', 'c': [1, 2, 3]})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == 'foo'
    # This is a reference to the CLIARGS object.  Changing it via the returned
    # reference should modify the original object
    assert cliargs_deferred_get('c')() is CLIARGS['c']
    #
    # But when we request shallow copy we get our own copy
    assert cliargs_deferred_get('c', shallowcopy=True)() is not CLIARGS['c']
    #
    # By default we get a reference to the

# Generated at 2022-06-20 13:55:00.765996
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common import to_safe_path
    from ansible.module_utils._text import to_text, to_bytes

    CLIARGS.update({"foo": "bar",
                    "baz": ["quux", "xyzzy"],
                    "cli_common_args": {"forks": 4, "ansible_python_interpreter": "/bin/python"}})

    # Original value is returned
    assert "bar" == cliargs_deferred_get("foo")()

    # Modifying the return value does not change CLIARGS value (unless it's a Mapping or Set)
    assert "bar" == cliargs_deferred_get("foo")()
    cliargs_deferred_get("foo")().clear()
    assert "bar" == cliargs_deferred_get("foo")

# Generated at 2022-06-20 13:55:04.225511
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = CLIArgs({})
    deferred = cliargs_deferred_get('key', default=42)
    assert deferred() == 42
    CLIARGS = GlobalCLIArgs.from_options({'key':'value'})
    assert deferred() == 'value'

# Generated at 2022-06-20 13:55:14.968649
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.clear()
    CLIARGS['default'] = 'some value'
    CLIARGS['default_copy'] = ['a', 'b']
    CLIARGS['default_shallowcopy'] = ['a', 'b']
    def_value = cliargs_deferred_get('default')
    def_value_copy = cliargs_deferred_get('default_copy')
    def_value_shallowcopy = cliargs_deferred_get('default_shallowcopy', shallowcopy=True)
    assert CLIARGS['default'] == def_value()
    assert CLIARGS['default_copy'] == def_value_copy()
    assert CLIARGS['default_copy'] is not def_value_copy()
    assert CLIARGS['default_shallowcopy'] == def_value_shallowcopy()
   

# Generated at 2022-06-20 13:55:19.524857
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    def run_test(mock_cliargs_from_options, mock_cliargs_setdefault, default_val, shallowcopy, expected_default_val):
        mock_cliargs = mock_cliargs_from_options()
        mock_cliargs_setdefault.return_value = default_val
        default_val_func = cliargs_deferred_get('mykey', default=default_val, shallowcopy=shallowcopy)
        mock_cliargs.__getitem__.side_effect = [mock_cliargs, expected_default_val]
        assert default_val == default_val_func()

    from unittest.mock import Mock, patch
    from copy import copy
    from ansible.module_utils.common.collections import is_sequence

   

# Generated at 2022-06-20 13:55:30.922826
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import (Mapping, Set)

    # Test a basic argument
    CLIARGS['verbosity'] = 4
    assert cliargs_deferred_get('verbosity')() == 4

    # Test a basic argument with a default that isn't used
    assert cliargs_deferred_get('verbosity', default=1)() == 4

    # Test a basic argument with a default that is used
    assert cliargs_deferred_get('debug', default=1)() == 1

    # Test a sequence that is shallow copied
    CLIARGS['extra_vars'] = [1, 2, 3]

# Generated at 2022-06-20 13:55:37.870682
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the function cliargs_deferred_get"""
    # Test getting a value from an empty context
    assert cliargs_deferred_get('foo')() is None

    # Test getting a value from a context
    global CLIARGS
    orig_cliargs = CLIARGS
    CLIARGS = CLIArgs(dict(foo='bar'))
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = orig_cliargs

# Generated at 2022-06-20 13:55:44.806237
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.import_from_dict({'a': 'A', 'b': ['B'], 'c': {'C': 'C'}})
    assert cliargs_deferred_get('a')() == 'A'
    # Default
    assert cliargs_deferred_get('d', default='D')() == 'D'
    # Shallow Copy
    assert cliargs_deferred_get('b', shallowcopy=True)() == ['B']
    assert cliargs_deferred_get('c', shallowcopy=True)() == {'C': 'C'}

# Generated at 2022-06-20 13:55:55.164535
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.context_objects import CLIArgs, GlobalCLIArgs
    arr = [1, 2, 3, 4]
    d = dict(a='b', c='d')
    v1 = 'abc'
    v2 = 1
    cli_args = CLIArgs({
        'arr': arr,
        'd': d,
        'v1': v1,
        'v2': v2,
    })
    # We only replace CLIARGS after the actual parse_args() runs
    #
    # If we didn't have the 'deepcopy' builtin then this would just be a reference to some
    # dict which is not what we want.
    #
    # If we used the dict copy() method then we wouldn't have copies of the values stored
    # in the dict which is not what we want

# Generated at 2022-06-20 13:56:08.748362
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': 'bar'})

    def assert_not_equal_with_copy(func):
        """Assert that inner and value are different objects with an equality that implies their values are the same"""
        inner1 = func()
        inner2 = func()
        assert inner1 is not inner2, 'inner1 and inner2 are the same object'
        assert inner1 == inner2, 'inner1 and inner2 are not equal'

    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', 'buzz')() == 'buzz'
    assert_not_equal_with_copy(cliargs_deferred_get('foo', shallowcopy=True))

# Generated at 2022-06-20 13:56:11.030065
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import ContextObje

# Generated at 2022-06-20 13:56:22.121030
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def outer(value):
        def inner():
            return value
        return inner

    assert cliargs_deferred_get(1)() is None

    args = {'a': 1,
            'b': [],
            'c': {}}
    CLIARGS.set_options(args)
    assert cliargs_deferred_get('a')() == args['a']
    assert cliargs_deferred_get('b')() is args['b']
    assert cliargs_deferred_get('c')() is args['c']
    assert cliargs_deferred_get('b', default=[])() is args['b']
    assert cliargs_deferred_get('c', default={})() is args['c']


# Generated at 2022-06-20 13:56:33.104194
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict(x=2, y=dict(m=5), z=[5, 6, 7]))

    # no shallowcopy
    cliarg_x = cliargs_deferred_get('x')
    assert cliarg_x == 2

    cliarg_y = cliargs_deferred_get('y')
    assert cliarg_y == dict(m=5)
    cliarg_y['p'] = 6
    assert cliarg_y == dict(m=5, p=6)

    cliarg_z = cliargs_deferred_get('z')
    assert cliarg_z == [5, 6, 7]
    cliarg_z.append(8)

# Generated at 2022-06-20 13:56:40.427931
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestClass(object):
        def __init__(self):
            self.value = cliargs_deferred_get('key', 'default')
        def get_value(self):
            return self.value()

    CLIARGS['key'] = 'override'
    c = TestClass()
    assert c.get_value() == 'override'
    del CLIARGS['key']
    assert c.get_value() == 'default'

# Generated at 2022-06-20 13:56:44.916505
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=too-few-public-methods
    class CliArgsTest:
        """Class that fakes CLIARGS

        It has the same interface as CLIARGS so that the main difference is in the
        mutability of the value stored in its attributes
        """
        def __init__(self):
            self.args = {}

        def get(self, key, default=None):
            return self.args.get(key, default)

    global CLIARGS
    cliargs_value = {}
    cliargs_value['some_key'] = 'some_value'
    cliargs_value['some_int'] = 2
    cliargs_value['some_list'] = ['one', 'two', 'three']
    cliargs

# Generated at 2022-06-20 13:56:55.918533
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the ``cliargs_deferred_get`` function"""
    # Set up
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'list': ['a', 'b'], 'set': {'x', 'y'}})

    # Test with no shallow copy
    no_shallowcopy = cliargs_deferred_get('foo')
    assert no_shallowcopy() == 'bar'

    # Test with shallow copy
    shallowcopy = cliargs_deferred_get('foo', shallowcopy=True)
    assert shallowcopy() == 'bar'

    # Test sequence with no shallow copy
    no_shallowcopy = cliargs_deferred_get('list')
    assert no_shallowcopy() == ['a', 'b']

    # Test sequence with shallow copy
    shallowcopy = cl

# Generated at 2022-06-20 13:57:07.525151
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('test_key_2', default='test_default')() == 'test_default'
    assert cliargs_deferred_get('test_key_3')(default='test_default') == 'test_default'

    assert cliargs_deferred_get('test_key_2', default='test_default', shallowcopy=True)() == 'test_default'
    assert cliargs_deferred_get('test_key_3')(default='test_default', shallowcopy=True) == 'test_default'

    assert cliargs_deferred_get('test_key_3')() == 'c'
    assert cliargs_deferred_get('test_key_3', shallowcopy=True)() == 'c'

    # We should return the item by reference not value

# Generated at 2022-06-20 13:57:10.781455
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    result = cliargs_deferred_get('tags', 'foo')
    assert result() == 'foo'

    global CLIARGS
    CLIARGS = CLIArgs({'tags': 'bar'})
    result = cliargs_deferred_get('tags', 'foo')
    assert result() == 'bar'

# Generated at 2022-06-20 13:57:14.088306
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    obj = cliargs_deferred_get('foo', 'bar')
    assert obj is not None
    assert obj() == 'bar'

# Generated at 2022-06-20 13:57:30.289714
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from mock import patch

    @patch.object(CLIARGS, 'get', autospec=True)
    def testme(mock_get):
        mock_get.return_value = ['foo', 'bar']
        assert cliargs_deferred_get('foo')(), 'should return copy of list'
        assert cliargs_deferred_get('foo', shallowcopy=True)() is ['foo', 'bar'], 'should return original list'
        mock_get.return_value = {'foo': 'bar'}
        assert cliargs_deferred_get('foo')() != {'foo': 'bar'}, 'should return copy of dict'
        assert cliargs_deferred_get('foo', shallowcopy=True)() is {'foo': 'bar'}, 'should return original dict'

# Generated at 2022-06-20 13:57:41.477745
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for `CLIARGS.get()`"""
    global CLIARGS
    tmp_cliargs = CLIARGS
    CLIARGS = CLIArgs({})

# Generated at 2022-06-20 13:57:52.201795
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get

    This function update ``CLIARGS``.  Additionally several of the callers for
    this function use other functions in this module so we'll test those as well.
    """
    global CLIARGS
    from ansible.module_utils.common.compat.six import PY2, StringIO
    import sys
    import pytest
    # pylint: disable=import-error
    from ansible.module_utils._text import to_text

    # force it to python2
    old_py2 = PY2
    PY2 = True
    old_stdout = sys.stdout
    buf = StringIO()
    sys.stdout = buf
    old_cliargs = CLIARGS

# Generated at 2022-06-20 13:58:02.037638
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the deferred_get function
    import collections

    test_cli_args = {'a': 'foo', 'b': [1, 2, 3], 'c': collections.Counter('foo')}
    _init_global_context(test_cli_args)

    assert cliargs_deferred_get('a')() == 'foo'
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == collections.Counter('foo')

    assert cliargs_deferred_get('bad_arg')() == None
    assert cliargs_deferred_get('bad_arg', default='asdf')() == 'asdf'

    # Test when cli_args hasn't been initialized yet
    CLIARGS.__init__({})
   

# Generated at 2022-06-20 13:58:10.860732
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''Test function cliargs_deferred_get'''
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo') == 'bar'
    assert cliargs_deferred_get('bar', 'zoof') == 'zoof'
    assert cliargs_deferred_get('bar', default=set([1, 2])) == set([1, 2])
    list_default = ['one', 'two']
    result = cliargs_deferred_get('bar', default=list_default)
    # We should have got a shallow copy of the list
    assert result == list_default
    result.append('three')
    assert result != list_default

# Generated at 2022-06-20 13:58:22.591613
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def my_default():
        return {'foo': 'bar'}
    cli_args = CLIArgs({'foo': ['bar']})
    assert cli_args.get('this.that', default=my_default) == my_default()
    assert cli_args.get('this.that', default=my_default) == my_default()
    assert cli_args.get('foo') == 'bar'
    assert cli_args.get('foo') == 'bar'
    assert cli_args.get('foo', shallowcopy=True) == 'bar'
    assert cli_args.get('foo', shallowcopy=True) == 'bar'
    assert cli_args.get('foo', default=['bar'], shallowcopy=True) == ['bar']

# Generated at 2022-06-20 13:58:31.797094
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update_options(dict(
        foo='foo',
        bar=['bar1', 'bar2'],
        baz={'baz1': 'baz2'},
    ))
    assert cliargs_deferred_get('foo')() == 'foo'
    assert cliargs_deferred_get('foo', default='default')() == 'foo'
    assert cliargs_deferred_get('foobar')() == None
    assert cliargs_deferred_get('foobar', default='default')() == 'default'
    assert cliargs_deferred_get('bar')() == ['bar1', 'bar2']
    assert cliargs_deferred_get('bar', shallowcopy=True)() == ['bar1', 'bar2']

# Generated at 2022-06-20 13:58:43.021898
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # empty -> default
    assert cliargs_deferred_get.__defaults__ == (None, False,)
    assert cliargs_deferred_get('key', 'defvalue')() == 'defvalue'

    # valid key, no shallowcopy
    CLIARGS.set('key', 'value')
    assert cliargs_deferred_get('key')() == 'value'

    # valid key, with shallowcopy
    CLIARGS.set('key', 'value')
    assert cliargs_deferred_get('key', shallowcopy=True)() == 'value'

    # valid key, value is a list
    CLIARGS.set('key', ['value'])
    assert cliargs_deferred_get('key')() == ['value']

# Generated at 2022-06-20 13:58:52.573931
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-argument
    # This is only used by unit test code
    global CLIARGS
    def set_value(dummy, value):
        global CLIARGS
        new_cli_args = CLIArgs({'key': value})
        CLIARGS = GlobalCLIArgs.from_options(new_cli_args)

    context_value = cliargs_deferred_get('key', [])
    assert context_value() == []
    assert context_value() == []
    set_value(None, 'new value')
    assert context_value() == 'new value'
    assert context_value() == 'new value'

# Generated at 2022-06-20 13:58:58.977635
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    _init_global_context(dict(vault_password_file='/dev/null',
                              vault_password='dummy_password',
                              private_key_file='/dev/null',
                              ask_sudo_pass=True))
    assert cliargs_deferred_get('vault_password_file')() == '/dev/null'
    assert cliargs_deferred_get('vault_password')() == 'dummy_password'
    assert cliargs_deferred_get('private_key_file')() == '/dev/null'
    assert cliargs_deferred_get('ask_sudo_pass')() == True
    CLIARGS = CLIArgs(dict())
    assert cliargs_deferred_get('vault_password_file')() is None
    assert cl

# Generated at 2022-06-20 13:59:17.683705
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test defaults

    assert cliargs_deferred_get('_does_not_exist')() is None

    assert cliargs_deferred_get('_does_not_exist', default=1)() == 1

    # Test with cli args

    cli_args = dict(foo=['foo'], bar=1, baz=dict(qux=2))

    _init_global_context(cli_args)

    assert cliargs_deferred_get('foo')() == ['foo']
    assert cliargs_deferred_get('bar')() == 1
    assert cliargs_deferred_get('baz')() == dict(qux=2)

    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['foo']

# Generated at 2022-06-20 13:59:23.245858
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'verbosity': 3, 'inventory_hostname': 'foo'})
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    assert cliargs_deferred_get('verbosity', 'bar')() == 3
    assert cliargs_deferred_get('inventory_hostname')() == 'foo'
    assert cliargs_deferred_get('verbosity', shallowcopy=True)() == 3



# Generated at 2022-06-20 13:59:29.103048
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('qux', default='baz')() == 'baz'
    assert cliargs_deferred_get('qux', 'baz')() == 'baz'

# Generated at 2022-06-20 13:59:39.956512
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    class MockCliArgs(object):
        """Mock class for CLIARGS"""

        def __init__(self, contents=None):
            self.contents = contents if contents is not None else {}

        def __getitem__(self, key):
            return self.contents[key]

        def __contains__(self, key):
            return key in self.contents

    def mock_cliargs(contents):
        """Make a version of cliargs_deferred_get for our mock CLIARGS"""
        mock_cliargs = MockCliArgs(contents)
        def mock_inner():
            return mock_cliargs
        return mock_inner


# Generated at 2022-06-20 13:59:43.491186
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from copy import copy
    from types import FunctionType

    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert isinstance(cliargs_deferred_get('foo'), FunctionType)

    assert cliargs_deferred_get('baz', default='quux')() == 'quux'

    CLIARGS['bar'] = [1, 2, 3, 4]
    CLIARGS['baz'] = {'a': 1, 'b': 2, 'c': 3}
    CLIARGS['quux'] = {1, 2, 3, 4}

    CLIAGS_COPY = copy(CLIARGS)

    assert cliargs_deferred_get('bar', shallowcopy=True)() == [1, 2, 3, 4]


# Generated at 2022-06-20 13:59:54.576436
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Verify that the returned inner function gets the correct value from CLIARGS.

    Make sure that it picks up the correct value when CLIARGS changes,
    and that it takes a copy of mutable values.
    """
    # Sanity check: make sure that these are the correct defaults.
    assert cliargs_deferred_get('host_key_checking') == False
    assert cliargs_deferred_get('skip_tags') == []
    assert cliargs_deferred_get('vault_identity') is None

    # Test that it gets the existing value from CLIARGS when it is still the default
    cliargs_closure = cliargs_deferred_get('vault_identity')
    assert cliargs_closure() is None

    # Override CLIARGS to change the default value of vault_identity


# Generated at 2022-06-20 14:00:06.109140
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    for args in (
            {},
            {'foo': 'bar'},
            {'foo': ['bar', 'baz']},
            ):
        CLIARGS = CLIArgs(args)
        for (key, expected_value) in args.items():
            assert cliargs_deferred_get(key)() == expected_value
            expected_value = expected_value[:]
            assert cliargs_deferred_get(key, shallowcopy=True)() == expected_value
            assert cliargs_deferred_get(key)() == cliargs_deferred_get(key)()
            assert cliargs_deferred_get(key)() == cliargs_deferred_get(key)()

# Generated at 2022-06-20 14:00:14.840397
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test closure cliargs_deferred_get"""
    from ansible.errors import AnsibleError

    # TODO: This is a shallow test.  We should add more tests when we have
    #       more types for defaults

    # TODO: We need to either change this function to use CDG_SINGLETON (which always exists)
    #       or change the singleton to use the cloargs_deferred_get
    global CLIARGS
    CLIARGS = CLIArgs({})

    # set a default
    default = cliargs_deferred_get('key', default=None)
    assert default() == None

    # set no default
    no_default = cliargs_deferred_get('key')

# Generated at 2022-06-20 14:00:18.950822
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the function ``cliargs_deferred_get``"""
    global CLIARGS
    CLIARGS = CLIArgs({'one': 'two'})
    deferred_get = cliargs_deferred_get('one')
    assert deferred_get() == 'two'
    CLIARGS = CLIArgs({'one': 'three'})
    assert deferred_get() == 'three'



# Generated at 2022-06-20 14:00:30.828106
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the closure returned by cliargs_deferred_get"""
    class testclass:
        foo = cliargs_deferred_get('test')
    obj = testclass()
    CLIARGS['test'] = 'got it'
    assert obj.foo == 'got it'
    assert obj.foo == 'got it'
    CLIARGS['test'] = 'got it again'
    assert obj.foo == 'got it'
    shallow = cliargs_deferred_get('test', shallowcopy=True)
    obj.foo = shallow
    assert obj.foo == 'got it again'
    assert obj.foo == 'got it again'
    CLIARGS['test'] = 'got it again and again'
    assert obj.foo == 'got it again'
    CLIARGS['test'] = ['foo', 'bar']


# Generated at 2022-06-20 14:00:58.405746
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'seq': [1, 2, 3], 'map': {1: 2, 3: 4}, 'set': {1, 2, 3}})

    # Get the closure and verify that it returns the expected value when called
    def_value = cliargs_deferred_get('foo', 'default')
    assert def_value() == 'bar'

    def_value = cliargs_deferred_get('seq', 'default')
    assert def_value() == [1, 2, 3]

    def_value = cliargs_deferred_get('seq', 'default', shallowcopy=True)
    assert def_value() == [1, 2, 3]

    def_value = cliargs_deferred_get('map', 'default')

# Generated at 2022-06-20 14:01:09.954300
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # static initialization to avoid the global singleton
    global CLIARGS
    ref = set()
    CLIARGS = GlobalCLIArgs.from_options({'foo': ref})

    value = cliargs_deferred_get('foo')()

    # ensure ref is still in CLIARGS
    assert CLIARGS['foo'] == ref

    # ensure value is a copy that is not the same object
    value.add('baz')
    assert CLIARGS['foo'] != value

    # ensure a deepcopy of ref is returned
    value.add('baz')
    assert CLIARGS['foo'] != value

    value = cliargs_deferred_get('bar')()
    assert value is None

    value = cliargs_deferred_get('baz')(default=set())()
    assert value == set()

    value

# Generated at 2022-06-20 14:01:19.353094
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['a'] = 1
    src_dict = {'key': 'value'}
    src_list = [1, 2, 3]
    src_set = {1, 2, 3}
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('b')() is None
    assert cliargs_deferred_get('b', 'default')() == 'default'
    CLIARGS['b'] = 'value'
    assert cliargs_deferred_get('b')() == 'value'
    assert cliargs_deferred_get('b', shallowcopy=True)() == 'value'
    CLIARGS['b'] = src_dict
    assert cli

# Generated at 2022-06-20 14:01:28.001410
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class FakeCliArgs():
        def __init__(self):
            self.args = {'a': 'b'}
        def get(self, key, default=None):
            return self.args.get(key, default)

    global CLIARGS
    orig_args = CLIARGS
    cli_args = FakeCliArgs()
    CLIARGS = cli_args
    cliargs_deferred_get('a')() == 'b'
    cliargs_deferred_get('b')() == None
    CLIARGS = orig_args

# Generated at 2022-06-20 14:01:38.398769
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test _init_global_context
    _init_global_context(
        {'ansible_connection': 'defaultconnection',
         'ansible_ssh_common_args': '--ssh-extra-foo',
         'ansible_ssh_extra_args': '--ssh-common-foo',
         'connection': 'defaultconnection',
         'timeout': 42,
         'username': 'defaultuser',
         'vault_password_file': 'defaultpasswordfile',
         'verbosity': 1}
    )

    # Test shallowcopy=False
    assert cliargs_deferred_get('verbosity', shallowcopy=False) == 1

    # Test shallowcopy=True
    _new = cliargs_deferred_get('ansible_ssh_common_args', shallowcopy=True)

# Generated at 2022-06-20 14:01:46.318042
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for cliargs_deferred_get"""

    class MockArgs(object):
        def get(self, key, default=None):
            if key == 'test_key':
                return 'test_value'
            elif key == 'test_key2':
                return set(['test_value2'])
            elif key == 'test_key3':
                return ['test_value3']
            elif key == 'test_key4':
                return {'test_key4': 'test_value4'}
            else:
                return default

    global CLIARGS
    CLIARGS = MockArgs()

    assert cliargs_deferred_get('test_key', default='default_value')() == 'test_value'
    assert cliargs_deferred_get('test_key2', default=set())

# Generated at 2022-06-20 14:01:57.442010
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=unused-argument
    def mock_cliargs_get(key, default=None):
        return {
            'key': 'value'
        }.get(key, default)

    _init_global_context(mock_cliargs_get)

    cliargs_deferred_get('key')(); cliargs_deferred_get('key')(); cliargs_deferred_get('key')();
    cliargs_deferred_get('not_found')(); cliargs_deferred_get('not_found')(); cliargs_deferred_get('not_found')();

    assert CLIARGS.get('key') == 'value'
    assert CLIARGS.get('not_found')

# Generated at 2022-06-20 14:02:06.971992
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _g():
        return CLIARGS

    setattr(CLIARGS, '_g', _g)
    CLIARGS.update(dict(a='a', b=[1, 2, 3], c=dict(d='d', e='e'), f=set(['g', 'h'])))

    dg = cliargs_deferred_get('a')
    assert dg.__closure__[0].cell_contents() == 'a'

    dg = cliargs_deferred_get('b')
    assert dg.__closure__[0].cell_contents() == [1, 2, 3]

    dg = cliargs_deferred_get('b', shallowcopy=True)
    assert dg.__closure__[0].cell_contents() == [1, 2, 3]

   

# Generated at 2022-06-20 14:02:15.511356
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('a', default=None)() is None
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('a', default=None)() is None
    assert cliargs_deferred_get('a', default=[1])() == [1]
    assert cliargs_deferred_get('a', default=[1], shallowcopy=True)() == [1]

# Generated at 2022-06-20 14:02:23.944869
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import os
    import sys

    # First thing to do is convert our mock to a global object
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({'foo': 1})
    assert cliargs_deferred_get('foo')() == 1

    # Set up a closure for a different object
    args = {'bar': 2}
    get_bar = cliargs_deferred_get('bar', default=3)

    # Assign a new CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({'bar': 2})
    assert get_bar() == 2

    # Use the default
    CLIARGS = GlobalCLIArgs.from_options({'baz': 3})
    assert get_bar() == 3

    # Use the passed in default
    get_qux = cli

# Generated at 2022-06-20 14:03:09.879112
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping
    def check_copy(value):
        if is_sequence(value):
            return list(value)
        if isinstance(value, Mapping):
            return dict(value)
        return value

    mock_args = {
        "abc": 1,
        "def": ['a', 'b', 'c'],
        'ghi': {'aa': 11, 'bb': 22},
    }
    global CLIARGS
    CLIARGS = CLIArgs(mock_args)
    for key, value in mock_args.items():
        assert cliargs_deferred_get(key, shallowcopy=True)() == check_copy(value)
        assert cliargs_deferred_get(key, shallowcopy=False)() == value
       

# Generated at 2022-06-20 14:03:19.699403
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import _init_global_context
    _init_global_context({'foo': True})

    # Test a single level key
    assert cliargs_deferred_get('foo') is True
    # Test the default value
    assert cliargs_deferred_get('bar', default=False) is False

    # Test the copy functionality for mutable structures
    for x in (
            ['bar'],
            {'bar': 2},
            {1, 2},
    ):
        default = cliargs_deferred_get('bar', default=x, shallowcopy=True)
        assert default == x
        assert default is not x
    # Test that scalars are still passed through
    assert cliargs_deferred_get('bar', default=1, shallowcopy=True) is 1

# Generated at 2022-06-20 14:03:31.129678
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    default = object()
    cli_args = {'foo': 'bar', 'baz': {'b_key1': 'b_val1', 'b_key2': 'b_val2'}, 'qux': ['q_val1', 'q_val2']}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='fallback')() == 'bar'
    assert cliargs_deferred_get('bar', default='fallback')() == 'fallback'
    assert cliargs_deferred_get('baz')() == cli_args['baz']

# Generated at 2022-06-20 14:03:42.601567
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    import types
    global CLIARGS
    cliargs_copy = CLIARGS
    CLIARGS = CLIArgs(dict(a=dict(b='c')))

    res = cliargs_deferred_get('a', shallowcopy=True)
    assert isinstance(res, types.FunctionType)
    assert res() == dict(b='c')
    assert res() is not CLIARGS['a']

    res = cliargs_deferred_get('a', shallowcopy=False)
    assert isinstance(res, types.FunctionType)
    assert res() == dict(b='c')
    assert res() is CLIARGS['a']

    # It's very important that we set CLIARGS back to what it was before the
    # test so the next test doesn

# Generated at 2022-06-20 14:03:48.753148
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Foo:
        bar = cliargs_deferred_get('invalid', 'foo')

    _init_global_context({'verbosity': 0})
    foo = Foo()
    assert foo.bar == 'foo'

    _init_global_context({'verbosity': 0, 'invalid': 'baz'})
    foo = Foo()
    assert foo.bar == 'baz'

# Generated at 2022-06-20 14:03:59.130307
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    assert cliargs_deferred_get('foo')('bar') == 'bar'
    CLIARGS = CLIArgs({'foo': 'bax'})
    assert cliargs_deferred_get('foo')('bar') == 'bax'
    CLIARGS = CLIArgs({'foo': ['bax']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bax']
    assert cliargs_deferred_get('foo')() == ['bax']
    CLIARGS = CLIArgs({'foo': {'bax': 'baz'}})


# Generated at 2022-06-20 14:04:04.579779
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    global CLIARGS
    assert CLIARGS is not None
    assert 'list_key' not in CLIARGS

    my_get = cliargs_deferred_get('list_key', default=[])
    assert my_get() == []

    CLIARGS['list_key'] = list('my_list')
    assert my_get() == list('my_list')
    # We have to override the global CLIARGS so that we can unit test the function
    cli_args = {'list_key': list('my_list')}
    CLIARGS = GlobalCLIArgs.from_options(cli_args)
    assert my_get() == list('my_list')



# Generated at 2022-06-20 14:04:15.336828
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MockCliArgs():
        def __init__(self, vals):
            self.vals = vals

        def get(self, key, default=None):
            return self.vals.get(key, default)

    vals = {'key': 'val'}
    mock_cliargs = MockCliArgs(vals)
    assert cliargs_deferred_get('key', default='default')(mock_cliargs) == 'val'
    assert cliargs_deferred_get('no_key', default='default')(mock_cliargs) == 'default'

    vals['key_seq'] = ['val']
    vals['key_dict'] = {'key': 'val'}
    vals['key_set'] = {'val'}


# Generated at 2022-06-20 14:04:25.286495
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works even when CLIARGS is replaced"""
    cliargs_orig = CLIARGS
    assert cliargs_orig is CLIARGS
    global CLIARGS
    CLIARGS = CLIArgs({'a': [1, 2, 3], 'b': {'d': 4}, 'c': (5,)})
    assert cliargs_orig is not CLIARGS
    assert 'a' not in cliargs_orig
    assert 'a' in CLIARGS
    # test lazy loading
    a_lazy = cliargs_deferred_get('a')
    assert a_lazy() == [1, 2, 3]
    a_lazy_mutated = cliargs_deferred_get('a', default=None)
    a_lazy_mutated()[0]

# Generated at 2022-06-20 14:04:34.414471
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-argument
    global CLIARGS
    CLIARGS = CLIArgs({'this': 'that'})
    assert cliargs_deferred_get('this')() == 'that'
    assert cliargs_deferred_get('this')() is CLIARGS['this']
    assert cliargs_deferred_get('this', 'other')() == 'that'
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    assert cliargs_deferred_get('foo', 'bar', shallowcopy=True)() == 'bar'
    CLIARGS['this'] = ['it', 'was', 'a', 'list']
    assert cliargs_deferred_get('this')() == ['it', 'was', 'a', 'list']
    assert cl