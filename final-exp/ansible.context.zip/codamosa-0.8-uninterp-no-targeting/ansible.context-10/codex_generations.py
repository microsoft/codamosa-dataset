

# Generated at 2022-06-20 13:54:43.791161
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    try:
        CLIARGS = CLIArgs({'key': 'value'})
        assert cliargs_deferred_get('key')(), 'value'
        assert cliargs_deferred_get('key', shallowcopy=True)(), 'value'

        CLIARGS = CLIArgs({'key': ['value', 'value2']})
        assert cliargs_deferred_get('key')(), ['value', 'value2']
        assert cliargs_deferred_get('key', shallowcopy=True)(), ['value', 'value2']
    finally:
        CLIARGS = CLIArgs({})

# Generated at 2022-06-20 13:54:53.746950
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    ''' Test to make sure cliargs_deferred_get correctly gets the value '''

    test_dict = {'a': 1, 'b': 2}
    _init_global_context(test_dict)

    # Test getting an existing key
    def1 = cliargs_deferred_get('a')
    assert def1() == 1

    # Test getting a default value for a key that does not exist
    def2 = cliargs_deferred_get('c', default=4)
    assert def2() == 4

    # Test getting a default value for a key that does not exist, but does not copy
    def3 = cliargs_deferred_get('c', default=4, shallowcopy=True)
    assert def3() == 4

    # Test getting a value for a key that does exist, but does not copy
   

# Generated at 2022-06-20 13:55:04.065639
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def check_default_for_key(key, callback):
        """Assert that the closure returned by cliargs_deferred_get returns a default value"""
        value = callback()
        assert value == default[key]
        if not shallowcopy:
            assert value is default[key]

    # Initially CLIARGS is an empty dict
    assert CLIARGS == {}

    # Closure works with CLIARGS as an empty dict
    default = {'foo': 'bar', 'baz': (1, 2, 3), 'set': set([1, 2, 3]), 'dict': {1: 2}}
    for key in default:
        for shallowcopy in (False, True):
            callback = cliargs_deferred_get(key, default[key], shallowcopy)
            check_default_for_key(key, callback)
            #

# Generated at 2022-06-20 13:55:14.831252
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make sure we work with a normal CliArgs object
    ca = CLIArgs(dict(a_string='A String', a_list=['first', 'second'], a_mapping={'foo': 'bar', 'baz': 'qux'}))
    assert ca.a_string == cliargs_deferred_get('a_string')()
    assert ca.a_list[:] == cliargs_deferred_get('a_list', shallowcopy=True)()
    assert ca.a_mapping.copy() == cliargs_deferred_get('a_mapping', shallowcopy=True)()

    # Make sure we work with the version that was a singleton
    global CLIARGS
    CLIARGS = ca
    assert ca.a_string == cliargs_deferred_get('a_string')()


# Generated at 2022-06-20 13:55:19.398693
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = GlobalCLIArgs.from_options({'connection': 'network_cli'})
    assert cliargs_deferred_get('connection')() == 'network_cli'
    assert cliargs_deferred_get('connection', shallowcopy=True)() == 'network_cli'

    CLIARGS = GlobalCLIArgs.from_options({'connection': 'network_cli', 'inventory': ['localhost']})
    assert cliargs_deferred_get('inventory')() == ['localhost']
    assert cliargs_deferred_get('inventory', shallowcopy=True)() == ['localhost']

    # Test that we don't shallowcopy a value that doesn't need it
    assert cliargs_deferred_get('connection', shallowcopy=True)() == 'network_cli'

# Generated at 2022-06-20 13:55:30.846659
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # test basic usage (no copy)
    CLIARGS = CLIARgs(dict(
        foo=dict(bar='baz'),
    ))
    assert cliargs_deferred_get('foo') == dict(bar='baz')

    # test missing key
    assert cliargs_deferred_get('does_not_exist') is None

    # test default value
    assert cliargs_deferred_get('does_not_exist', default='default_value') == 'default_value'

    # test shallow copy
    CLIARGS = CLIARgs(dict(
        nested=dict(
            foo=dict(bar='baz'),
        ),
        string='foo',
    ))

# Generated at 2022-06-20 13:55:42.160811
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert CLIARGS.get('test_key') is None
    CLIARGS = CLIArgs({'test_key': 'test_value'})
    assert cliargs_deferred_get('test_key') == 'test_value'
    CLIARGS = CLIArgs({'test_key': ['test_value']})
    assert cliargs_deferred_get('test_key') == ['test_value']
    assert cliargs_deferred_get('test_key', shallowcopy=True) == ['test_value']
    CLIARGS = CLIArgs({'test_key': {'test': 'value'}})
    assert cliargs_deferred_get('test_key') == {'test': 'value'}

# Generated at 2022-06-20 13:55:52.960526
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_callback(cli_args, value, shallowcopy=False):
        global CLIARGS
        _init_global_context(cli_args)
        return cliargs_deferred_get('test_key', default=value, shallowcopy=shallowcopy)()
    assert test_callback({}, 'def') == 'def'
    assert test_callback({'test_key': 'val'}, 'def') == 'val'
    assert test_callback({}, None) is None
    assert test_callback({'test_key': None}, None) is None
    assert test_callback({'test_key': None}, 'def') is None
    assert test_callback({}, []) == []
    assert test_callback({'test_key': []}, []) == []

# Generated at 2022-06-20 13:56:02.004320
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit tests for function cliargs_deferred_get"""
    assert cliargs_deferred_get is not None
    _init_global_context({'DEBUG': True,
                          'ANSIBLE_DEBUG': False,
                          'ANSIBLE_INVENTORY': 'foo'})
    assert cliargs_deferred_get('list', default=[])() == []
    assert cliargs_deferred_get('set', default=set())() == set()
    assert cliargs_deferred_get('dict', default={})() == {}
    assert cliargs_deferred_get('ANSIBLE_INVENTORY')() == 'foo'
    assert not cliargs_deferred_get('ANSIBLE_DEBUG')()
    assert cliargs_deferred_get('DEBUG')()
    assert cliargs_def

# Generated at 2022-06-20 13:56:11.162001
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCliArgs(CLIArgs):
        def __init__(self, args):
            super(TestCliArgs, self).__init__(args)
            self.args = args
        def __getitem__(self, key):
            return self.args[key]
        def __len__(self):
            return len(self.args)
        def __iter__(self):
            return self.args.__iter__()

    # Test default
    global CLIARGS
    CLIARGS = TestCliArgs({})
    assert 5 == cliargs_deferred_get('somekey', 5)

    # Test basic value
    CLIARGS = TestCliArgs({'somekey': 'someval'})
    assert 'someval' == cliargs_deferred_get('somekey', 5)

    # Test

# Generated at 2022-06-20 13:56:26.236055
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': ['bar'], 'blarg': {'baz': 'zar'}}
    _init_global_context(cli_args)

    fut1 = cliargs_deferred_get('foo')
    fut2 = cliargs_deferred_get('blarg')

    assert callable(fut1)
    assert callable(fut2)

    assert fut1() == ['bar']
    assert fut2() == {'baz': 'zar'}

    assert callable(cliargs_deferred_get('buz'))
    assert cliargs_deferred_get('buz')() is None

    assert callable(cliargs_deferred_get('quux', default='quuz'))
    assert cliargs_deferred_get('quux', default='quuz')()

# Generated at 2022-06-20 13:56:35.488279
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('a')() is None
    CLIARGS['a'] = 'b'
    assert cliargs_deferred_get('a')() == 'b'
    CLIARGS['a'] = ['b']
    assert cliargs_deferred_get('a')() == ['b']
    CLIARGS['a'] = ['b']
    assert cliargs_deferred_get('a', shallowcopy=True)() == ['b']
    CLIARGS['a'] = {'b': 'c'}
    assert cliargs_deferred_get('a')() == {'b': 'c'}
    CLIARGS['a'] = {'b': 'c'}

# Generated at 2022-06-20 13:56:47.385447
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy

    # create a closure (tmp1) over a key (first) that doesn't exist in the CliArgs
    # object.  It should return the default value of "foo"
    tmp1 = cliargs_deferred_get("first", "foo")
    assert tmp1() == "foo"

    # create a closure (tmp2) over a key (second) that does exist in the CliArgs
    # object with value "bar".  This should return that value.
    tmp2 = cliargs_deferred_get("second", "foo")
    _init_global_context({"second": "bar"})
    assert tmp2() == "bar"

    # create a closure (tmp3) over a key that does exist in the CliArgs object
    # with value ["bar", "baz", "bim"]
    #

# Generated at 2022-06-20 13:56:57.674290
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({
        'tree': 'mytree',
        'diff': False,
        'verbosity': 4,
        'debug': True,
        'module_path': '/path/to/modules',
        'extra_module_path': ['/path/to/my/modules', '/path/to/other/modules']
    })
    # Test simple value
    assert cliargs_deferred_get('tree')() == 'mytree'
    # Test default value
    assert cliargs_deferred_get('no_such_key', 'default_value')() == 'default_value'
    # Test shallow copy of Sequence

# Generated at 2022-06-20 13:57:08.693145
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():  # noqa
    dict_data = dict(a=True, b=False)
    list_data = [1, 2 , 3]
    set_data = {'a', 'b', 'c'}
    data_types = (dict_data, list_data, set_data)
    for value in data_types:
        cliargs_deferred_get_value = cliargs_deferred_get('fake_key', value, shallowcopy=True)()
        assert cliargs_deferred_get_value is not value
        assert cliargs_deferred_get_value == value
        cliargs_deferred_get_value = cliargs_deferred_get('fake_key', value, shallowcopy=False)()
        assert cliargs_deferred_get_value is value

# Generated at 2022-06-20 13:57:19.495871
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs = CLIArgs({'module_defaults': {'one': 1, 'twentythree': [23], 'fourtysix': {'fourtysix': 46}}})
    global CLIARGS
    CLIARGS = cliargs
    assert cliargs_deferred_get('module_defaults')('one') == 1
    assert cliargs_deferred_get('module_defaults')('twentythree') == [23]
    assert cliargs_deferred_get('module_defaults')('fourtysix') == {'fourtysix': 46}
    assert cliargs_deferred_get('module_defaults', shallowcopy=True)('one') == 1
    assert cliargs_deferred_get('module_defaults', shallowcopy=True)('twentythree') == [23]
   

# Generated at 2022-06-20 13:57:24.987382
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['key'] = 'value'
    # This is not going to work in pytest as it is not run from the command line
    # To test this you must run from the command line
    #   python -m ansible.utils.context_objects --collect-only
    assert cliargs_deferred_get('key')() == 'value'

# Generated at 2022-06-20 13:57:34.190059
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class MyArgs(object):
        _source_internal_val = 'original'

    global CLIARGS
    myargs = MyArgs()
    myargs.get = lambda x, y=None: y
    CLIARGS = myargs
    assert cliargs_deferred_get('does_not_exist')(), 'Expected to get default value'
    myargs._source_internal_val = 'foo'
    assert cliargs_deferred_get('_source_internal_val')(), 'Expected to get value'
    CLIARGS.setdefault('_source_internal_val', 'foo')
    assert cliargs_deferred_get('_source_internal_val', default='bar')(), 'Expected to get value even with default'

# Generated at 2022-06-20 13:57:45.139850
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIARGS
    from ansible.module_utils.common.collections import is_sequence

    # with shallowcopy
    test_dict = {'key': 'value'}
    test_list = ['item1', 'item2']
    test_set = set(['item1', 'item2'])
    test_int = 5

    assert cliargs_deferred_get('key', test_dict)() is test_dict
    assert cliargs_deferred_get('key', test_dict, shallowcopy=True)() is not test_dict

    assert cliargs_deferred_get('key', test_list)() is test_list
    assert cliargs_deferred_get('key', test_list, shallowcopy=True)() is not test_list
    assert is_

# Generated at 2022-06-20 13:57:55.370462
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def assert_equal_pairs(pairs):
        for lh, rh in pairs:
            assert lh == rh

    global CLIARGS
    args = {'a': 'b', 'c': 'd', 'e': {'f': 'g'}, 'h': ['i', 'j', 'k'], 'l': ['m']}
    CLIARGS = CLIArgs(args)

# Generated at 2022-06-20 13:58:10.643535
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    result = cliargs_deferred_get('something_that_does_not_exist')
    assert result == None

    CLIARGS.other_options = {'something_that_does_not_exist': 'some value'}
    result = cliargs_deferred_get('something_that_does_not_exist')
    assert result == 'some value'

    CLIARGS.other_options = {'some_list': [1, 2, 3, 4]}
    result = cliargs_deferred_get('some_list', shallowcopy=True)
    assert result == [1, 2, 3, 4]
    result[0] = 10
    assert CLIARGS.other_options['some_list'][0] == 1


# Generated at 2022-06-20 13:58:22.407776
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from unittest import TestCase
    from ansible.module_utils.common._collections_compat import Mapping, Set

    class MockCliArgs(Mapping):
        def __getitem__(self, key):
            return self._dict[key]

        def __len__(self):
            return len(self._dict)

        def __iter__(self):
            return iter(self._dict)

        def __init__(self, initial):
            self._dict = initial

    class TestCliArgsDeferredGet(TestCase):
        """Unit test for the ``cliargs_deferred_get`` function"""

        def setUp(self):
            self.mock = MockCliArgs({'foo': 'angelica'})
            self.global_cliargs = CLIArgs(self.mock)


# Generated at 2022-06-20 13:58:27.298693
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert cliargs_deferred_get('foo')(), None
    CLIARGS = CLIArgs({'foo': 'baz', 'bar': 'qux'})
    assert cliargs_deferred_get('foo')() == 'baz'
    assert cliargs_deferred_get('bar')() == 'qux'

# Generated at 2022-06-20 13:58:34.234923
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class GlobalCLIArgs(dict):
        def __init__(self, *args, **kwargs):
            super(GlobalCLIArgs, self).__init__(*args, **kwargs)
            self._updated = True

        @property
        def updated(self):
            return self._updated

        def set_updated(self, updated=True):
            self._updated = updated

        def __getitem__(self, key):
            if not self._updated:
                raise ValueError("CLIARGS has not been updated")
            return super(GlobalCLIArgs, self).__getitem__(key)

    global CLIARGS
    old_CLIARGS = CLIARGS
    CLIARGS = GlobalCLIArgs(foo=42)
    assert CLIARGS.updated is True
    get_foo = cliargs_deferred

# Generated at 2022-06-20 13:58:44.880041
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    # Covered by test_commandline.py

    # Test that we get the value normally when global context is there
    _init_global_context({'a': 'A', 'b': 'B'})
    assert 'A' == cliargs_deferred_get('a')

    # Test that we get the default when global context is missing
    CLIARGS = CLIArgs({})
    assert 'A' == cliargs_deferred_get('a', default='A')

    # Test that we get the default when global context is there and key is missing
    _init_global_context({'b': 'B'})
    assert 'A' == cliargs_deferred_get('a', default='A')

    # Test that shallow copy works when global context is there and key is missing
    _init_global_context

# Generated at 2022-06-20 13:58:55.633582
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'foo': 'bar'})
    assert CLIARGS.get('foo') == 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    _init_global_context({'foo': 'baz'})
    assert CLIARGS.get('foo') == 'baz'
    assert cliargs_deferred_get('foo')() == 'baz'

    _init_global_context({'foo': True})
    assert CLIARGS.get('foo') is True
    assert cliargs_deferred_get('foo')() is True

    _init_global_context({'foo': False})
    assert CLIARGS.get('foo') is False
    assert cliargs_deferred_get('foo')() is False


# Generated at 2022-06-20 13:59:07.490230
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=missing-docstring

    def assert_equal(a, b):  # noqa
        if a != b:
            raise AssertionError("\nExpected:\n%r\nActual:\n%r\n" % (a, b))

    cli_args = {'v': [0], 's': 'some_string', 't': ['some_string'], 'l': 'some_string'}
    _init_global_context(cli_args)
    assert_equal(CLIARGS['v'], 0)

    get_v = cliargs_deferred_get('v')
    get_v.__module__ = 'ansible.context_objects'
    get_v.__name__ = 'cliargs_deferred_get'

# Generated at 2022-06-20 13:59:15.452859
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo')(shallowcopy=True) == [1, 2, 3]
    assert cliargs_deferred_get('foo')() == [1, 2, 3]

    CLIARGS = CLIArgs({'foo': set()})
    value = cliargs_deferred_get('foo')(shallowcopy=True)
    assert isinstance(value, set)
    assert value == set()
    value = cliargs_deferred_get('foo')()
    assert isinstance(value, set)
    assert value == set()

# Generated at 2022-06-20 13:59:23.983806
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with no default
    assert cliargs_deferred_get('foo')() is None
    global CLIARGS
    CLIARGS = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test with a default
    assert cliargs_deferred_get('bar', default='default')() == 'default'
    assert cliargs_deferred_get('foo', default='default')() == 'bar'

    # Test with a default that we can't deepcopy, so it's shallowcopied
    CLIARGS = GlobalCLIArgs.from_options({'baz': ['list']})
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['list']
    assert cliargs_def

# Generated at 2022-06-20 13:59:29.423382
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy

    class FakeOptions(object):
        def __init__(self, options):
            self.options = options

        def get(self, key, default=None):
            return self.options.get(key, default)

    test_values = {'a': 'b', 'c': [1, 2, 3], 'd': {'k': 'v'}}


# Generated at 2022-06-20 13:59:43.121997
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def has_default_list(key):
        """Return a closure that checks if a list of a given key has a default value in the
        global context
        """
        return cliargs_deferred_get(key, [])

    CLIARGS.update(dict(foo='bar', baz=[1, 2, 3]))
    # Ensure that we are returning copies of the mutable objects
    assert 'foo' not in CLIARGS
    assert has_default_list('foo')() == 'bar'
    assert CLIARGS == dict(baz=[1, 2, 3])
    assert has_default_list('baz')() == [1, 2, 3]

    assert has_default_list('non_existent')() == []

# Generated at 2022-06-20 13:59:54.698554
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils._text import to_native

    class DummyCLIARGS(object):
        def __getitem__(self, key, default=None):
            if key == 'list':
                return [1,2,3]
            elif key == 'dict':
                return {'a': 1}
            elif key in ('set', 'default'):
                return set()          # Don't let code path worry about if we have a set or not
            raise KeyError(key)

        def get(self, key, default=None):
            if key == 'default':
                return default
            return self.__getitem__(key)

    global CLIARGS
    _real = CLIARGS
    CLIARGS = DummyCLIARGS()

# Generated at 2022-06-20 14:00:06.223201
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping
    cliargs = {}
    old_cliargs = CLIARGS
    new_cliargs = CLIArgs.from_options(cliargs)
    CLIARGS = new_cliargs
    get_key = cliargs_deferred_get('test_key', default='test_value')
    assert get_key() == 'test_value'
    value = {'key': 'value'}
    cliargs['test_key'] = value
    assert get_key() == value
    cliargs['test_key'] = [1, 2]
    assert get_key() == [1, 2]
    cliargs['test_key'] = (1, 2)
    assert get_key() == (1, 2)

# Generated at 2022-06-20 14:00:14.944336
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Intentionally not using the singleton in this test

    dict_value = dict(foo='bar')
    list_value = ["a", "b", "c"]
    set_value = set(["a", "b", "c"])
    cliargs_dict = CLIArgs(dict(dict_value=dict_value,
                                list_value=list_value,
                                set_value=set_value))
    _init_global_context(cliargs_dict)

    assert CLIARGS.get('dict_value', default=None) is dict_value
    assert cliargs_deferred_get('dict_value', default=None)() is dict_value
    assert cliargs_deferred_get('dict_value', default=None, shallowcopy=True)() == dict_value
    assert cliargs_def

# Generated at 2022-06-20 14:00:22.900947
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': [1,2]})
    # Reference
    assert CLIARGS.get('foo') == [1,2]
    # Default
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', default=1)() == 1
    # Shallow copy is off by default
    assert cliargs_deferred_get('foo') is CLIARGS.get('foo')
    # Shallow copy is on when requested
    assert cliargs_deferred_get('foo', shallowcopy=True)() == CLIARGS.get('foo')
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS.get('foo')

# Generated at 2022-06-20 14:00:33.552440
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': ['a1', 'a2']})
    func = cliargs_deferred_get('a', default=[], shallowcopy=True)
    copied_list = func()
    assert id(copied_list) != id(func())
    assert copied_list == ['a1', 'a2']
    assert id(copied_list[0]) == id(func()[0])
    assert id(copied_list[1]) == id(func()[1])

    func = cliargs_deferred_get('a', default=[], shallowcopy=False)
    copied_list = func()
    assert id(copied_list) == id(func())
    # Even though we've only shallow copied the list elements is_sequence()
    # returns true.

# Generated at 2022-06-20 14:00:44.506872
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    my_dict = {
        'key': 'value'
    }
    my_list = [1,2,3,4]
    my_set = {'a', 'b', 'c'}
    my_func = cliargs_deferred_get('key')

    # Test non-default
    CLIARGS.update({'key': 'value'})
    assert my_func() == 'value'

    # Test default
    CLIARGS = CLIArgs({})
    assert my_func() == 'value'

    # Test shallow copy
    my_func = cliargs_deferred_get('key', shallowcopy=True)
    # Test dict
    CLIARGS.update({'key': my_dict})
    value_dict = my_func()
   

# Generated at 2022-06-20 14:00:56.003741
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Tests that cliargs_deferred_get functions as expected"""
    class CliArgsMock(dict):
        """A mock CLIARGS that we can use to test various attribute functionality"""
        def __init__(self, d):
            super(CliArgsMock, self).__init__(d)

        def __getattr__(self, key):
            return cliargs_deferred_get(key, shallowcopy=True)

        def get(self, key, default=None, shallowcopy=False):
            """Mock get"""
            if key in self:
                return cliargs_deferred_get(key, shallowcopy=shallowcopy)()
            return default

    # Simple shallow copy

# Generated at 2022-06-20 14:01:02.189197
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test for the case where the value is a mutable
    expected = [1, 2, 3]
    CLIARGS._store['foo'] = expected
    inner_func = cliargs_deferred_get('foo', shallowcopy=True)
    assert inner_func() is not expected
    assert inner_func() == expected

    # Test for the case where the value is an immutable
    expected = 'bar'
    CLIARGS._store['foo'] = expected
    inner_func = cliargs_deferred_get('foo', shallowcopy=True)
    assert inner_func() is expected

    # Test for the case where the value is not present
    default = 'default'
    inner_func = cliargs_deferred_get('bar', default=default)
    assert inner_func() == default

    # Test for the case where the

# Generated at 2022-06-20 14:01:11.687234
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({"foo": "bar", "baz": [1,2,3]})
    assert cliargs_deferred_get("foo")() == "bar"
    assert cliargs_deferred_get("foo", "xyzzy")() == "bar"
    assert cliargs_deferred_get("baz", shallowcopy=True)() == [1, 2, 3]
    # value returned should not be mutable
    v = cliargs_deferred_get("baz", shallowcopy=True)()
    v.append(4)
    assert cliargs_deferred_get("baz")() != v

# Generated at 2022-06-20 14:01:34.701841
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(v1=1, v2=2, v3=[1, 2, 3], v4={'x': 'y'}))
    assert 1 == cliargs_deferred_get('v1')()
    assert 2 == cliargs_deferred_get('v2')()
    assert [1, 2, 3] == cliargs_deferred_get('v3')()
    assert {'x': 'y'} == cliargs_deferred_get('v4')()
    assert (1, 2, 3) == cliargs_deferred_get('v3', shallowcopy=True)()
    assert {'x': 'y'} == cliargs_deferred_get('v4', shallowcopy=True)()

# Generated at 2022-06-20 14:01:44.188567
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.six import PY3
    from collections import deque
    from copy import deepcopy
    import pytest
    if PY3:
        from collections.abc import MutableMapping, MutableSet
    else:
        from collections import MutableMapping, MutableSet

    # Tests are in code order
    def test_returns_default_if_not_present():
        assert cliargs_deferred_get('foo', 123)() == 123

    def test_calls_default_if_supplied():
        def fake_default():
            return 456
        assert cliargs_deferred_get('foo', fake_default)() == 456

    def test_returns_value_if_present():
        CLIARGS['foo'] = 789
        assert cliargs_deferred_

# Generated at 2022-06-20 14:01:55.133647
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make a closure for CLIArgs
    get_foo = cliargs_deferred_get('foo')
    get_foo2 = cliargs_deferred_get('foo')

    # Initially not set
    assert get_foo() is None
    assert get_foo2() is None

    # Now set to a value and test that the closure binds to it
    CLIARGS['foo'] = 'bar'
    assert get_foo() == 'bar'
    assert get_foo2() == 'bar'

    # Now set to another value and test that the closure binds to the new value
    CLIARGS['foo'] = 'baz'
    assert get_foo() == 'baz'
    assert get_foo2() == 'baz'

    # Ensure that when copied, we don't get the same object
    assert get_foo() == get

# Generated at 2022-06-20 14:01:56.653858
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['val'] = 5
    assert cliargs_deferred_get('val')() == 5



# Generated at 2022-06-20 14:02:01.243922
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    assert cliargs_deferred_get('verbosity')(2) == 2
    assert cliargs_deferred_get('verbosity')('debug') == 'debug'
    assert cliargs_deferred_get('verbosity')('default') == 'default'

# Generated at 2022-06-20 14:02:08.915743
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    cliargs = CLIArgs({'foo': [1, 2, 3], 'bar': {'baz': 'quux'}})
    deferred_get = cliargs_deferred_get('foo', default='default', shallowcopy=True)
    assert deferred_get() == [1, 2, 3]
    assert deferred_get() == [1, 2, 3]
    assert isinstance(deferred_get(), list)
    deferred_get = cliargs_deferred_get('bar', default='default', shallowcopy=True)
    assert deferred_get() == {'baz': 'quux'}
    assert deferred_get() == {'baz': 'quux'}
   

# Generated at 2022-06-20 14:02:19.945556
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    gbl = CLIArgs({'foo': 'bar'})
    true_sc = 'abc'
    fb = cliargs_deferred_get('foo', True, True)
    assert fb() is True
    assert cliargs_deferred_get('baz', 'qux', True)() == 'qux'
    assert cliargs_deferred_get('baz', 'qux', shallowcopy=True)() == 'qux'
    assert cliargs_deferred_get('baz', 'qux')() == 'qux'
    assert cliargs_deferred_get('baz', 'qux')() == 'qux'
    gbl['baz'] = 'qwix'
    assert cliargs_deferred_get('baz', 'qux')() == 'qwix'


# Generated at 2022-06-20 14:02:30.791894
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class Test:
        pass

    test = Test()
    setattr(test, 'field', cliargs_deferred_get('no_such_key', 'default'))
    assert test.field == 'default'
    setattr(test, 'field', cliargs_deferred_get('no_such_key', 'default', shallowcopy=True))
    assert test.field == 'default'
    setattr(test, 'field', cliargs_deferred_get('no_such_key', default=['something'], shallowcopy=True))
    assert test.field == ['something']
    setattr(test, 'field', cliargs_deferred_get('no_such_key', default=['something'], shallowcopy=False))
    assert test.field is ['something']

# Generated at 2022-06-20 14:02:40.617274
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class C(object):
        """A simple object for use in testing"""
        def __init__(self, field='val'):
            self.field = field
    c = C()
    new_c = C()
    d = {'a': 1, 'b': 2, 'c': c}
    CLIARGS['normal_default'] = 'val'
    CLIARGS['new_default'] = new_c
    CLIARGS['two_level_default'] = {'a': {'b': {'c': c}}}
    CLIARGS['list_default'] = [1, 2, 3]
    CLIARGS['dict_default'] = d
    CLIARGS['set_default'] = {1, 3, 5}

    cliargs_default = cliargs_deferred_get('nonexistent', 'default')

# Generated at 2022-06-20 14:02:44.859859
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    test_value = set([1, 2, 3])
    CLIARGS = CLIArgs({'foo': test_value})
    inner = cliargs_deferred_get('foo', shallowcopy=False)
    assert id(inner()) == id(test_value)
    assert inner() == test_value
    inner = cliargs_deferred_get('foo', shallowcopy=True)
    assert id(inner()) != id(test_value)
    assert inner() == test_value
    test_value = [1, 2, 3]
    CLIARGS = CLIArgs({'foo': test_value})
    inner = cliargs_deferred_get('foo', shallowcopy=False)
    assert id(inner()) == id(test_value)
    assert inner() == test_value
    inner = cli

# Generated at 2022-06-20 14:03:15.817933
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test function without setting CLIARGS
    key = 'test'
    default = 'TEST'
    getter = cliargs_deferred_get(key, default=default)
    assert getter() == default

    # Test function with setting CLIARGS
    value = 'VALUE'
    CLIARGS['test'] = value
    assert getter() == value
    return True

# Generated at 2022-06-20 14:03:22.144366
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('doesnotexist')() is None
    assert cliargs_deferred_get('doesnotexist', 'defaultvalue')() == 'defaultvalue'
    assert cliargs_deferred_get('doesnotexist', default='anotherdefault')() == 'anotherdefault'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS['foo'] = ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']

# Generated at 2022-06-20 14:03:32.291950
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-20 14:03:42.887895
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    CLIARGS = CLIArgs({})
    cliargs_deferred_get('test_key')()
    assert CLIARGS == CLIArgs({'test_key': None})

    CLIARGS = CLIArgs({'test_key': 'test_value'})
    assert cliargs_deferred_get('test_key')() == 'test_value'

    CLIARGS = CLIArgs({'test_key': 'test_value'})
    assert cliargs_deferred_get('test_key', default='default')() == 'test_value'

    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('test_key', default='default')() == 'default'

    CLIARGS = CLIArgs({'test_key': 'test_value'})
    assert cliargs

# Generated at 2022-06-20 14:03:54.317910
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set

    default = CLIARGS.get('not-a-key', default='default value')
    assert 'default value' == default

    list_value = [1, 2, 3]
    dict_value = {1: 1, 2: 2}
    set_value = set((1, 2, 3))
    str_value = 'value'
    cliargs = CLIArgs({'list_value': list_value, 'dict_value': dict_value, 'set_value': set_value, 'str_value': str_value})

    get_default = cliargs_deferred_get('not-a-key', 'default')
    assert 'default' == get_default()


# Generated at 2022-06-20 14:04:02.478572
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update(dict(abc=123, xyz=dict(yzx=456)))
    deferred_get = cliargs_deferred_get('abc')
    # Deferred_get returns a function because this is called from inside the FieldAttribute
    # initialization so we have to called deferred_get() to get the final value.
    assert 123 == deferred_get()
    deferred_get_default = cliargs_deferred_get('default', 'test')
    assert 'test' == deferred_get_default()
    deferred_get_shallow_copy = cliargs_deferred_get('abc', shallowcopy=True)
    assert 123 == deferred_get_shallow_copy()
    deferred_get_dict_shallow_copy = cliargs_deferred_get('xyz', shallowcopy=True)

# Generated at 2022-06-20 14:04:08.917915
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS._store = {'a': 3}
    assert cliargs_deferred_get('a')(), 3
    CLIARGS = CLIArgs({'b': [1, 2, 3]})
    assert cliargs_deferred_get('b', shallowcopy=True)(), [1, 2, 3]
    assert cliargs_deferred_get('c')(), None

# Generated at 2022-06-20 14:04:19.373619
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({'foo': 'bar', 'undefined': {1: 2, 3: 4}, 'undefined_sequence': [3, 4, 5], 'undefined_set': set([1, 2, 3, 4, 5])})
    assert cliargs_deferred_get('undefined', default='100', shallowcopy=True)() == {1: 2, 3: 4}
    assert cliargs_deferred_get('undefined', default='100', shallowcopy=False)() == {1: 2, 3: 4}

# Generated at 2022-06-20 14:04:28.042075
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils import six
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence

    class Dummy(Mapping):
        def __init__(self):
            self.data = {}

        def __getitem__(self, key):
            return self.data[key]

        def __iter__(self):
            return iter(six.iterkeys(self.data))

        def __len__(self):
            return len(self.data)

        def __repr__(self):
            return '{0}({1!r})'.format(self.__class__.__name__, self.data)

    # Test that we get a default back

# Generated at 2022-06-20 14:04:35.744607
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLI_ARGS_INITIAL = {
        'default': 'bar',
        'list': [1, 2, 3],
        'dict': {'a': 1, 'b': 2},
        'set': set([1, 3, 5]),
    }
    CLIARGS = GlobalCLIArgs.from_options(CLI_ARGS_INITIAL)
    assert cliargs_deferred_get('default')() == 'bar'
    assert cliargs_deferred_get('__default__', 'default')() == 'default'
    assert cliargs_deferred_get('list')() == [1, 2, 3]
    assert cliargs_deferred_get('list', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get