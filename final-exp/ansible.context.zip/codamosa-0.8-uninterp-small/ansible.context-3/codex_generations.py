

# Generated at 2022-06-24 18:36:08.847027
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:36:15.005509
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping

    bool_0 = True
    # We need to import the test_var to setup the closure
    from ansible.module_utils.ansible_galaxy.test_utils.test_cliargs import test_var
    var_0 = cliargs_deferred_get(bool_0, test_var)
    assert callable(var_0)
    # assert var_0() == test_var


# Generated at 2022-06-24 18:36:23.714362
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import re
    import tempfile
    import shutil
    import os.path
    import sys

    o_cwd = os.getcwd()
    o_argv = sys.argv
    o_path = sys.path

    tmpdir = tempfile.mkdtemp()
    script_dir, script_name = os.path.split(__file__)
    shutil.copy(os.path.join(script_dir, "test_context.py"), os.path.join(tmpdir, "test_context.py"))

# Generated at 2022-06-24 18:36:28.605313
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = dict()
    cli_args['key_0'] = 'str_0'
    cli_args['key_1'] = 'str_1'
    tmp_0 = cliargs_deferred_get(cli_args, cli_args)
    assert tmp_0() == cli_args



# Generated at 2022-06-24 18:36:31.370737
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get = Mock(return_value=None)
    y = cliargs_deferred_get

    assert y == cliargs_deferred_get



# Generated at 2022-06-24 18:36:36.833245
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Create the 'cli_args' variable
    cli_args = {}
    cli_args['foo'] = 'bar'

    # Call the '_init_global_context' function
    _init_global_context(cli_args)

    # Call the 'test_case_0' function
    test_case_0()


# Generated at 2022-06-24 18:36:40.390952
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)
    assert var_0 == False


# Generated at 2022-06-24 18:36:43.298124
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

if __name__ == '__main__':
    # Unit test for function cliargs_deferred_get
    test_case_0()

# Generated at 2022-06-24 18:36:47.713222
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_1 = False
    str_0 = 'ansible.cfg'
    var_1 = cliargs_deferred_get(str_0, bool_1)

    _init_global_context({})
    assert CLIARGS is not None
    assert CLIARGS.get(str_0, bool_1) == var_1()



# Generated at 2022-06-24 18:36:48.288425
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get()

# Generated at 2022-06-24 18:36:59.101549
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs

    # these are the actual cli arguments

# Generated at 2022-06-24 18:37:00.593550
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    test_case_0()

# Generated at 2022-06-24 18:37:02.412412
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)



# Generated at 2022-06-24 18:37:05.231163
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # test_case_0
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)



# Generated at 2022-06-24 18:37:07.339232
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)

# Generated at 2022-06-24 18:37:16.725579
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)
    assert var_0() == False
    bool_1 = True
    var_1 = cliargs_deferred_get(bool_1, bool_1)
    assert var_1() == True
    str_0 = 'This is a string'
    var_2 = cliargs_deferred_get(str_0, str_0)
    assert var_2() == 'This is a string'
    str_1 = '''This is a string.'''
    var_3 = cliargs_deferred_get(str_1, str_1)
    assert var_3() == '''This is a string.'''
    str_2 = '''It's also a string'''
    var_4

# Generated at 2022-06-24 18:37:19.936495
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # read from a file

    # feed some input to the function
    cliargs_deferred_get(True, True)
    return # nothing to assert that does not change the behavior of the function


# Generated at 2022-06-24 18:37:20.537854
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:37:23.515906
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {}
    var = cliargs_deferred_get(cli_args, cli_args)
    assert var == cli_args

# Generated at 2022-06-24 18:37:32.985155
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.context
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import sys

    (OK, FAILED) = (True, False)

    # reqs: No such file or directory
    testcase_0 = [
        'No such file or directory',
        None,  # key_0
        cliargs_deferred_get(key_0, None),
        {
            'ansible_verbosity': None,  # global_config_0 -> verbosity_options
        },
        (OK, FAILED),
    ]

    # reqs: No such file or directory

# Generated at 2022-06-24 18:37:38.329356
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == True # TODO: implement your test here



# Generated at 2022-06-24 18:37:46.909542
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-24 18:37:49.317286
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # make sure that both values evaluate to be equal
    assert cliargs_deferred_get(bool_0) == bool_0


# Generated at 2022-06-24 18:37:50.861388
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    not_implemented


# Generated at 2022-06-24 18:37:53.419203
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        cliargs_deferred_get(0)
    except Exception:
        pass
    else:
        assert False, "Unreachable"

# Generated at 2022-06-24 18:37:54.932903
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        cliargs_deferred_get(5, 7)
    except SystemExit:
        pass

# Generated at 2022-06-24 18:37:58.905109
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get('var_0', 'var_0')



# Generated at 2022-06-24 18:38:09.564068
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils._text import to_native

    # from ansible-test
    try:
        from ansible_test._internal.common.collections import MOCK_CALL
    except ImportError:
        MOCK_CALL = None

    # Save the previous values for CLIARGS
    _backup = dict()
    _backup['CLIARGS'] = {k: v for k, v in CLIARGS.__dict__.items() if k != 'instance'}

    # Define arguments used by the AnsibleModule
    bool_0 = True
    bool_1 = False
    dict_0 = dict()
    dict_0['mutable-1'] = set()
    dict_0['mutable-2'] = dict()
    dict_0['mutable-3'] = frozenset()
    dict

# Generated at 2022-06-24 18:38:10.734529
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert not callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:38:12.919073
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    x = None


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 18:38:24.229087
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)


if __name__ == "__main__":
    import sys
    import nose2

    if len(sys.argv) > 1:
        nose2.main()

# Generated at 2022-06-24 18:38:24.968924
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass


# vim: ansible-autoformat

# Generated at 2022-06-24 18:38:30.390840
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)



# Generated at 2022-06-24 18:38:31.645528
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # From Ansible tests
    assert True


# Generated at 2022-06-24 18:38:32.160561
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:38:33.746470
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_1 = cliargs_deferred_get(0, 1)
    assert var_1 == 0


# Generated at 2022-06-24 18:38:35.959508
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)
    assert var_0 == False

# Generated at 2022-06-24 18:38:38.486354
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)

    # Test nested function calls
    if var_0:
        pass


# Generated at 2022-06-24 18:38:41.747618
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)
    # Get default value for 'cliargs_deferred_get'
    assert var_0 == bool_0

# Generated at 2022-06-24 18:38:42.831038
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(None, None)


# Generated at 2022-06-24 18:39:06.080325
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    num_0 = int(0)
    bool_0 = True
    str_0 = str('')
    num_1 = int(1)
    inner_seq = [num_0]
    test_seq = [num_1]
    inner_mapping = {num_0: num_0}
    test_mapping = {num_1: num_1}
    inner_set = {num_0}
    test_set = {num_1}

    # Test the default values for each sequence type
    assert not inner_seq
    assert var_0 is inner_seq
    assert var_1 is inner_mapping
    assert var_2 is inner_set

    # Test that the sequences are copied
    inner_seq.append(num_1)
    inner_mapping['1'] = num_1
    inner_

# Generated at 2022-06-24 18:39:06.841857
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:39:07.867600
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(False)

# Generated at 2022-06-24 18:39:08.721664
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:39:11.450175
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)
    assert var_0 == cliargs_deferred_get(bool_0, bool_0)

# TESTING CODE

# Generated at 2022-06-24 18:39:13.063347
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(None, None)


if __name__ == '__main__':
    cliargs_deferred_get(None, None)

# Generated at 2022-06-24 18:39:16.665657
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    bool_1 = False
    str_0 = 'Hello, World!'
    str_1 = 'Hello, World!'
    str_2 = 'Hello, World!'
    str_3 = 'Hello, World!'

    # Call cliargs_deferred_get(bool_0, bool_0)
    test_case_0()



# Generated at 2022-06-24 18:39:24.037370
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = False
    bool_0 = False
    try:
        assert var_0 == cliargs_deferred_get(bool_0, bool_0)
    except AssertionError:
        print("AssertionError raised from test_cliargs_deferred_get()")



# Generated at 2022-06-24 18:39:26.988413
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Get the value of the CLIARGS variable
    value_0 = cliargs_deferred_get(bool_0)
    # Check the value of the variable against the expected value
    assert value_0 == bool_0

# Generated at 2022-06-24 18:39:34.481617
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible_collections.ansible.community.plugins.module_utils.ansible_release.utils.testing import (
        AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    )
    set_module_args({})
    with ModuleTestCase.from_params(
        args={}
    ) as testcase:
        result = testcase.run_module()
    assert result.exit_json == {}
    assert result.fail_json == {}


# Generated at 2022-06-24 18:40:10.465442
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    assert cliargs_deferred_get(1, 2) == cliargs_deferred_get(1, 2)


# Check the test was called
if __name__ == '__main__':
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:40:11.145687
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True

# Generated at 2022-06-24 18:40:20.373327
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    # Create a dummy function that returns a value
    def foo_0(): return 'string'

    # Create a dummy function that returns a value
    def foo_1(): return 'string'

    # Create a dummy function that returns a value
    def foo_2(): return 'string'

    # Create a dummy function that returns a value
    def foo_3(): return 'string'

    f = foo_0
    f = foo_1
    f = foo_2
    f = foo_3


if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:40:21.515545
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)



# Generated at 2022-06-24 18:40:26.072683
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True

# Test for the presence of the keyword cli_args in the CLIARGS dictionary

# Generated at 2022-06-24 18:40:27.393409
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test to make sure the code executes
    test_case_0()



# Generated at 2022-06-24 18:40:28.418456
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    #assert False # we need to figure out how to test this
    pass

# Generated at 2022-06-24 18:40:29.452519
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == False # TODO: implement your test here


# Generated at 2022-06-24 18:40:32.683614
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)



# Generated at 2022-06-24 18:40:36.621085
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)
    assert CLIARGS.get(var_0) == (var_0)

# Generated at 2022-06-24 18:41:47.051734
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0, bool_0)
    assert var_0

# Generated at 2022-06-24 18:41:48.285212
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(False, False)



# Generated at 2022-06-24 18:41:51.688650
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)
    print('var_0', var_0)



# Generated at 2022-06-24 18:41:58.438390
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    try:
        from unittest import mock
    except:
        import mock

    # patching the the return value for function 'get'
    with mock.patch('ansible.cli.CLIARGS.get', return_value=True):
        assert cliargs_deferred_get(True) == True

    # patching the the return value for function 'get'
    with mock.patch('ansible.cli.CLIARGS.get', return_value=False):
        assert cliargs_deferred_get(False) == False

# Generated at 2022-06-24 18:42:00.333970
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)
    assert var_0 == bool_0

# Generated at 2022-06-24 18:42:01.173425
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get('arg')

# Generated at 2022-06-24 18:42:01.957578
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()


# Generated at 2022-06-24 18:42:06.732644
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)



# Generated at 2022-06-24 18:42:10.284189
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context([])
    test_case_0()
    # AssertionError: <module>()
    # AssertionError: 'var_0' is not callable
    # Line 9

# Generated at 2022-06-24 18:42:12.033316
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get("bool_0") == False


# Generated at 2022-06-24 18:44:43.758746
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('INVOCATION', bool, True)()



# Generated at 2022-06-24 18:44:46.506375
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert TEST_CASE_0
    assert TEST_CASE_1
    assert TEST_CASE_2
    assert TEST_CASE_3
    assert TEST_CASE_4

# Generated at 2022-06-24 18:44:49.063753
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = None
    var_0 = cliargs_deferred_get(bool_0, bool_0)
    assert var_0 == bool_0

# Generated at 2022-06-24 18:44:52.067689
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.clear()
    test_case_0()
    CLIARGS.clear()
    test_case_0()
    CLIARGS.clear()
    test_case_0()
    CLIARGS.clear()
    test_case_0()
    CLIARGS.clear()
    test_case_0()
    CLIARGS.clear()


# Generated at 2022-06-24 18:44:53.029094
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # TODO: test
    pass

# Generated at 2022-06-24 18:44:55.106117
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    init(_init_global_context)

    # Call tests
    test_case_0()



# Generated at 2022-06-24 18:44:57.388501
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0, bool_0)
    assert var_0 is False

# Generated at 2022-06-24 18:44:58.824486
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(None)


# Generated at 2022-06-24 18:45:00.058946
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    assert True == (var_0())

# Generated at 2022-06-24 18:45:01.102171
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('bool_0', bool_0) == False