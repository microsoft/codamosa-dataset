

# Generated at 2022-06-24 18:36:11.443411
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    arg_0 = 'sst89Tp'
    str_0 = 'a;I}er:8<A[|KwIo'
    arg_1 = 'kw-fKF'
    str_1 = 'N)^'
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-24 18:36:15.198064
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get('test', 3, True)

# Generated at 2022-06-24 18:36:19.987181
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({})
    test_case_0()
    CLIARGS = CLIArgs({'8Sae<X\\P?}KS%y{+n7': '"test"'})
    test_case_0()
    CLIARGS = CLIArgs({'8Sae<X\\P?}KS%y{+n7': 'test'})
    test_case_0()

# Generated at 2022-06-24 18:36:22.321151
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    #print(test_case_0.__annotations__)
    print(test_case_0.__closure__[0].cell_contents)

# Generated at 2022-06-24 18:36:31.718058
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '8Sae<X\\P?}KS%y{+n7'
    fn_0 = cliargs_deferred_get(str_0)
    fn_1 = cliargs_deferred_get(str_0, default=1)
    assert fn_0() == fn_1()

    # Test this func doesn't get called before cliargs is initialized
    def function_0(var_0):
        return var_0[0]
    cliargs_deferred_get.__globals__[str_0] = function_0
    test_case_0()
    cliargs_deferred_get.__globals__[str_0] = None

# Generated at 2022-06-24 18:36:34.587544
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '7&sy>eS<j7@|]L'
    var_0 = cliargs_deferred_get(str_0)


# Generated at 2022-06-24 18:36:38.229279
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('0')() == None
    assert cliargs_deferred_get("")() == None

# Generated at 2022-06-24 18:36:39.497756
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:36:46.434039
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import random
    import string

    def _gen_text(length):
        return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))


    str_0 = _gen_text(random.randint(5, 15))
    str_1 = _gen_text(random.randint(5, 15))
    str_2 = _gen_text(random.randint(5, 15))
    str_3 = _gen_text(random.randint(5, 15))
    str_4 = _gen_text(random.randint(5, 15))
    str_5 = _gen_text(random.randint(5, 15))
    str_6 = _gen_text(random.randint(5, 15))
    str_7 = _gen_text

# Generated at 2022-06-24 18:36:48.083865
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print("Running cliargs_deferred_get tests")
    test_case_0()



# Generated at 2022-06-24 18:36:59.254050
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_cli_args = {
            'list1': [1,2,3],
            'list2': [4,5,6],
            'list3': [6,7,8],
            'dict1': {'key1': 'dict1 value 1', 'key2': 'dict1 value 2'},
            'dict2': {'key3': 'dict2 value 3', 'key4': 'dict2 value 4'}
            }
    test_case_0()
    cliargs_deferred_get('list1')()
    cliargs_deferred_get('list2', default=[3])()
    cliargs_deferred_get('list2', shallowcopy=True)()
    cliargs_deferred_get('list3', shallowcopy=True)()

# Generated at 2022-06-24 18:37:00.242409
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()


# Generated at 2022-06-24 18:37:03.576444
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_CLIARGS = CLIArgs()

    print(cliargs_deferred_get('a'))
    test_CLIARGS.a = 2
    print(cliargs_deferred_get('a'))

# Generated at 2022-06-24 18:37:13.992424
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert(cliargs_deferred_get('test')() is None)

    # Note that cliargs is a function not a dict, so we can't update it directly
    cliargs_get = cliargs_deferred_get('test')
    cliargs_get()
    assert(cliargs_get() is None)
    cliargs_get()

    cliargs_get = cliargs_deferred_get('test', default=0)
    cliargs_get()
    assert(cliargs_get() == 0)
    cliargs_get()

    cliargs_get = cliargs_deferred_get('test', default='')
    cliargs_get()
    assert(cliargs_get() == '')
    cliargs_get()

    cliargs_get = cliargs

# Generated at 2022-06-24 18:37:20.252369
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils import basic
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.utils.context_objects import ContextObject
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get
    from ansible.utils.context_objects import _init_global_context
    from ansible.utils.context_objects import TEST_VALUE_0
    from ansible.utils.context_objects import TEST_VALUE_1

    # test get default
    result = cliargs_deferred_get(TEST_VALUE_1, TEST_VALUE_0)
    assert result() == TEST_VALUE_0

    # test not get value
    _init_global_context({})
    result = cliargs_deferred_

# Generated at 2022-06-24 18:37:21.468610
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert test_case_0() == 0

# Generated at 2022-06-24 18:37:31.727740
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    expected = 'expected'
    key = 'test'
    _init_global_context({})
    assert CLIARGS.get(key) is None

    # Test with no default
    assert cliargs_deferred_get(key)() is None

    # Test with default
    assert cliargs_deferred_get(key, expected)() == expected

    # Test with value
    CLIARGS = GlobalCLIArgs.from_options({key: expected})
    assert cliargs_deferred_get(key)() == expected

    # Test shallowcopy
    assert cliargs_deferred_get(key, shallowcopy=True)() == expected
    CLIARGS = GlobalCLIArgs.from_options({})

    # Test shallowcopy default

# Generated at 2022-06-24 18:37:41.303285
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    assert cliargs_deferred_get('test', default=0)() == 0
    assert cliargs_deferred_get('test', default=(0, 1))() == (0, 1)
    assert cliargs_deferred_get('test', default={'a': 1})() == {'a': 1}
    assert cliargs_deferred_get('test', default=set('a'))() == set('a')
    f = cliargs_deferred_get('test', default=0)
    _init_global_context({'test': 1})
    assert f() == 1
    assert f() == 1  # Make sure it only calls it the first time
    next_init = {'test': (1, 2)}
    _init_global_context(next_init)

# Generated at 2022-06-24 18:37:46.361257
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    int_0 = cliargs_deferred_get('force', default=0)
    print(int_0()) # We know it's a function so we can call it, but we don't want to call it until later
    test_case_0()

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:55.301958
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import doctest
    from ansible.utils.context_objects import CLIARGS
    doctest.testmod()

    assert(cliargs_deferred_get('--check')() == False)
    assert(cliargs_deferred_get('--start-at-task')() == None)

    CLIARGS['--check'] = True
    CLIARGS['--start-at-task'] = "test_case_0"
    assert(cliargs_deferred_get('--check')() == True)
    assert(cliargs_deferred_get('--start-at-task')() == "test_case_0")

    CLIARGS['--check'] = False
    assert(cliargs_deferred_get('--check')() == False)

# Generated at 2022-06-24 18:38:07.554643
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    '''
    def inner():
        value = CLIARGS.get('int_0', default=0)
        if not shallowcopy:
            return value
        elif is_sequence(value):
            return value[:]
        elif isinstance(value, (Mapping, Set)):
            return value.copy()
        return value
    return inner
    '''
    assert cliargs_deferred_get('int_0')() == 0
    assert cliargs_deferred_get('int_0', default=3)() == 3
    CLIARGS.update(dict(int_0=5))
    assert cliargs_deferred_get('int_0', default=3)() == 5

# Generated at 2022-06-24 18:38:15.827573
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get), 'cliargs_deferred_get is not callable'
    assert cliargs_deferred_get(key='int_0', default=1) == 1, \
            'actual: %s' % cliargs_deferred_get(key='int_0', default=1)
    test_case_0()
    assert cliargs_deferred_get(key='int_0', default=1) == 0, \
            'actual: %s' % cliargs_deferred_get(key='int_0', default=1)

# Generated at 2022-06-24 18:38:18.971816
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:38:23.659863
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    _init_global_context(dict(foo=0))
    assert cliargs_deferred_get('foo')() == 0
    _init_global_context(dict(foo=1))
    assert cliargs_deferred_get('foo')() == 1

# Generated at 2022-06-24 18:38:29.961325
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.module_utils.common.collections as collections
    d = {'1': 1, '2': 2, '3': 3, '4': 4}
    d_seq = [1, 2, 3]
    s = {'1', '2', '3', '4'}
    # test returns None and not default
    val = cliargs_deferred_get('5')()
    assert val is None
    # test returns default and not None
    val = cliargs_deferred_get('5', default = 'a')()
    assert val == 'a'
    # test returns same value with same keys
    val = cliargs_deferred_get('5', default = 'a')()
    assert val == 'a'
    # test returns different values with different keys
    val_1 = cliargs_

# Generated at 2022-06-24 18:38:37.341160
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.cli import CLI
    ansible_args = CLI(
        None,
        ['ansible']
    ).parse()
    _init_global_context(ansible_args)
    assert cliargs_deferred_get('diff')
    assert cliargs_deferred_get('module_path')
    assert cliargs_deferred_get('module_path') == CLIARGS['module_path']
    assert not cliargs_deferred_get('force_color')
    assert cliargs_deferred_get('force_color', default=True)
    assert cliargs_deferred_get('module_path', shallowcopy=True)

# Generated at 2022-06-24 18:38:38.523948
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get(0, 1, True)) == True

# Generated at 2022-06-24 18:38:40.311968
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Tests for function cliargs_deferred_get
    test_case_0()

if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:40.752691
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True

# Generated at 2022-06-24 18:38:46.856264
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({"welcome":"ansible"})
    b = cliargs_deferred_get("welcome")
    assert b() == "ansible"
    CLIARGS = CLIArgs({"welcome":u"ansible"})
    b = cliargs_deferred_get("welcome")
    assert b() == u"ansible"
    CLIARGS = CLIArgs({"welcome":1})
    b = cliargs_deferred_get("welcome")
    assert b() == 1
    CLIARGS = CLIArgs({"welcome":False})
    b = cliargs_deferred_get("welcome")
    assert b() == False
    CLIARGS = CLIArgs({"welcome":None})

# Generated at 2022-06-24 18:38:51.275740
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(None, None, False) is None



# Generated at 2022-06-24 18:38:54.212394
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get('key', 'defau8lt')
    assert issubclass(var_0.__class__, FunctionType)


# Generated at 2022-06-24 18:38:56.058044
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '8Sae<X\\P?}KS%y{+n7'
    assert callable(cliargs_deferred_get)
    assert cliargs_deferred_get(str_0) is not None


# Generated at 2022-06-24 18:39:03.684258
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'from': '123'}
    cli_args = {str.encode(k): v.encode() for k, v in cli_args.items()}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('from') == '123'
    assert cliargs_deferred_get('from', default='456') == '123'

    # Check that the shallowcopy isn't too shallow
    # as in it doesn't just return the same object.
    list_0 = [1, 2, 3, 4, 5]
    dict_0 = {'from': list_0}
    cli_args = {str.encode(k): v.encode() for k, v in dict_0.items()}

# Generated at 2022-06-24 18:39:05.898261
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print(test_case_0())

if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:39:11.291045
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_1 = '8Sae<X\\P?}KS%y{+n7'
    str_2 = 'BJ5^5+\\$:y6[KjJHpG6x'
    str_3 = 'v5]5%5O5o5'
    cliargs_deferred_get(str_1, cliargs_deferred_get(str_2), cliargs_deferred_get(str_3))


# Generated at 2022-06-24 18:39:13.503568
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()


# Test variables
str_0 = '8Sae<X\\P?}KS%y{+n7'


# Unit test functions

# Generated at 2022-06-24 18:39:14.975126
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:39:18.642538
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'A'
    str_0 += 'B'
    str_1 = 'D'
    str_0 += str_1
    var_0 = cliargs_deferred_get(str_0)

# Generated at 2022-06-24 18:39:24.531770
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '8Sae<X\\P?}KS%y{+n7'
    var_0 = cliargs_deferred_get(str_0)
    print(var_0)


if __name__ == "__main__":
    # Load json file (json.json)
    test_case_0()
    # Run tests
    test_cliargs_deferred_get()
    test_case_0()

# Generated at 2022-06-24 18:39:30.643031
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '8Sae<X\\P?}KS%y{+n7'
    var_0 = cliargs_deferred_get(str_0)

# Generated at 2022-06-24 18:39:32.494284
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    function_name = 'cliargs_deferred_get'
    assert callable(eval(function_name))


# Generated at 2022-06-24 18:39:42.554311
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    str_0 = '8Sae<X\\P?}KS%y{+n7'
    var_0 = cliargs_deferred_get(str_0)

    str_1 = 'fW>}q.pf9G'
    var_1 = cliargs_deferred_get(str_1)

    str_2 = '{|9X-^F&@a"OL'
    var_2 = cliargs_deferred_get(str_2)

    str_3 = 'Q%cT$Bw8pi)s'
    var_3 = cliargs_deferred_get(str_3)

    str_4 = 'ZlC:\\@z>h*2jJ'
    var_4 = cliargs_deferred_get(str_4)

    str

# Generated at 2022-06-24 18:39:44.021475
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()
    assert True


# Generated at 2022-06-24 18:39:46.369965
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print(var_0())
    print(var_0())
    print(var_0())
    print(var_0())
    print(var_0())


# Generated at 2022-06-24 18:39:48.711997
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '8Sae<X\\P?}KS%y{+n7'
    var_0 = CLIARGS.get(str_0, default=None)
    assert True

# Generated at 2022-06-24 18:39:50.876363
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get('8Sae<X\\P?}KS%y{+n7')


# Generated at 2022-06-24 18:40:00.489682
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Get the defaults -- we don't actually use these values but we do
    # have to have some default for the Keys to exist in the CLIARGS dict
    for key in CLIARGS.__dict__:
        if key.startswith('_') or key.startswith('__') or callable(getattr(CLIARGS, key)):
            continue
        getattr(CLIARGS, key)

    for key in CLIARGS.__dict__:
        if key.startswith('_') or key.startswith('__') or callable(getattr(CLIARGS, key)):
            continue
        cliargs_deferred_get(key)


# Generated at 2022-06-24 18:40:00.984226
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True

# Generated at 2022-06-24 18:40:07.266715
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Boundary parameter conditions.  Expect:

        - `_get` returns the given default if there is no value for key
        - `_get` returns the given value for key if there is a value
        - `_get` returns a shallow copy of the value if shallowcopy=True
        - `_get` returns a reference to the value if shallowcopy=False
    """

# Generated at 2022-06-24 18:40:18.132736
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

# Generated at 2022-06-24 18:40:19.859057
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print('Test: test_cliargs_deferred_get')
    test_case_0()


# Generated at 2022-06-24 18:40:26.326217
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '+o9Jh=.=]3q^1m~0+['
    str_1 = 'r_/U6#PDzB^9Hb/hP6.'
    str_2 = 'pU?\\dU\\2"r'
    str_3 = 'pU?\\dU\\2"r'
    str_4 = '!#AI_C"{yW?~]h'
    str_5 = '8Sae<X\\P?}KS%y{+n7'
    str_6 = '<oYMfin\'a(XIa(}L'
    str_7 = 'i'
    str_8 = 'H7/c%bE/~XV-s_s'
    str_9 = '\'(SxS'
    str

# Generated at 2022-06-24 18:40:28.857330
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_1 = '8Sae<X\\P?}KS%y{+n7'
    var_0 = cliargs_deferred_get(str_1)
    assert var_0() is None



# Generated at 2022-06-24 18:40:30.564648
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    a = False
    try:
        test_case_0()
    except:
        a = True
    assert not a


# Generated at 2022-06-24 18:40:35.957564
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'JDZ:P$-YH8BvF%O`'
    var_0 = cliargs_deferred_get(str_0, 'KDd1X?')
    assert var_0() == 'KDd1X?'

# Generated at 2022-06-24 18:40:39.649081
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    str_0 = '8Sae<X\\P?}KS%y{+n7'

    # Exercise
    var_0 = cliargs_deferred_get(str_0)

    # Verify
    assert True



# Generated at 2022-06-24 18:40:47.941254
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_1 = '8Sae<X\\P?}KS%y{+n7'
    str_2 = 'KWVa#8F*1BZ{q3Oj'
    str_3 = '*5MFp{yRk+jx'
    str_4 = 'E{qj+Q%fz'
    str_5 = 'g}>r[({Hn8aJwQG'
    str_6 = 'Cp8&~'
    str_7 = '*5MFp{yRk+jx'
    str_8 = '0;H&$G'
    str_9 = '~<<WNx<'
    str_10 = 'U6{uU;|X@6\\>'
    str_11 = '0;H&$G'
   

# Generated at 2022-06-24 18:40:49.515490
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

# end of file


# Generated at 2022-06-24 18:40:54.179561
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    str_0 = '8Sae<X\\P?}KS%y{+n7'
    # Procedure
    var_0 = cliargs_deferred_get(str_0)
    # Verification
    var_0 = var_0()
    assert var_0 is None, 'Expression var_0 is None is False'


# Generated at 2022-06-24 18:41:15.889996
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '8Sae<X\\P?}KS%y{+n7'
    var_0 = cliargs_deferred_get(str_0)

# Generated at 2022-06-24 18:41:23.926849
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    input_0 = 'w-%c=^+Z'
    str_0 = ')6nxr+U9mQ_'
    output_0 = cliargs_deferred_get(input_0, default=str_0)
    str_1 = '1'
    output_1 = cliargs_deferred_get(input_0, default=str_1)
    assert output_0 == str_0
    assert output_1 == str_1


# Generated at 2022-06-24 18:41:31.039255
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    str_0 = 'I{m52Cm'
    str_1 = 'U<7V}'
    str_2 = 'Z3q'
    str_3 = '%c$+R'
    num_0 = 9
    num_1 = 89
    num_2 = 79
    num_3 = 54
    num_4 = 57
    num_5 = 14
    num_6 = 10
    num_7 = 9
    # Test function
    test_case_0()



# Generated at 2022-06-24 18:41:32.889965
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == (True)
    print('')


# Generated at 2022-06-24 18:41:37.856907
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Test function cliargs_deferred_get
    """
    CLIARGS['test_key'] = 'test_value'
    assert cliargs_deferred_get('test_key')() == 'test_value'
    assert cliargs_deferred_get('non_existent_key')() is None

# Generated at 2022-06-24 18:41:41.214140
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        str_0 = '4zwBVu!>1z|7Vu~%cF'
        var_0 = cliargs_deferred_get(str_0)
    except NameError:
        print("NameError exception")


# Generated at 2022-06-24 18:41:44.170537
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '8Sae<X\\P?}KS%y{+n7'
    var_0 = cliargs_deferred_get(str_0)
    assert var_0 is not None


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 18:41:46.139016
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:41:47.673006
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:41:50.503996
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'Ue*-U0Im'
    var_0 = cliargs_deferred_get(str_0)


# Generated at 2022-06-24 18:42:34.221898
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '8Sae<X\\P?}KS%y{+n7'
    var_0 = cliargs_deferred_get(str_0)

# Generated at 2022-06-24 18:42:39.056605
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'Qr/rZL[BDKpb{d5c\\1}'
    CLIARGS[str_0] = str_0
    var_0 = cliargs_deferred_get(str_0)
    assert var_0() == str_0

test_case_0()
test_cliargs_deferred_get()

# Generated at 2022-06-24 18:42:41.427579
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '8Sae<X\\P?}KS%y{+n7'
    var_0 = cliargs_deferred_get(str_0)

# Generated at 2022-06-24 18:42:42.293226
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()



# Generated at 2022-06-24 18:42:43.160389
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

# Generated at 2022-06-24 18:42:46.598636
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        assert False == (CLIARGS.get('ANSIBLE_CONFIG') is not None)
    except NameError:
        pass
    try:
        assert False == (CLIARGS.get('DEFAULT_ROLES_PATH') is not None)
    except NameError:
        pass


# Generated at 2022-06-24 18:42:52.722032
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import unittest
    class unit_test(unittest.TestCase):
        def test_case_0(self):
            str_0 = '8Sae<X\\P?}KS%y{+n7'
            var_0 = cliargs_deferred_get(str_0)
    def suite():
        unit_test_suite = unittest.TestSuite()
        unit_test_suite.addTest(unit_test('test_case_0'))
        return unit_test_suite
    runner = unittest.TextTestRunner()
    runner.run(suite())

if __name__ == '__main__':
    import sys
    (fn, imported_as) = sys.argv[0:2]

# Generated at 2022-06-24 18:43:04.603291
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        assert test_case_0()
    except AssertionError as e:
        import traceback
        traceback.print_exc()
        print('AssertionError raised in test_cliargs_deferred_get')
        # If you see AssertionError raised in test_cliargs_deferred_get, then you need to check
        # the logic of test_case_0
        # (current implementaion of test_case_0 is just a example, you need to replace it)

if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:43:09.713445
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {}
    _init_global_context(cli_args)
    str_0 = '8Sae<X\\P?}KS%y{+n7'
    var_0 = cliargs_deferred_get(str_0)
    assert var_0 == None

# Generated at 2022-06-24 18:43:17.952229
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        str_1 = '5Md,5p%?{[n/1lJ"n/'
        var_1 = cliargs_deferred_get(str_1)
    except Exception:
        var_2 = False
        var_3 = False
        var_3 = var_3 == var_2
        var_3 = var_3 == var_2
        var_3 = var_3 == var_2
        var_3 = var_3 == var_2
    else:
        var_3 = True
    assert var_3

# Generated at 2022-06-24 18:44:50.277019
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print("begin test_cliargs_deferred_get")
    test_case_0()
    print("test_cliargs_deferred_get")
    pass

# Generated at 2022-06-24 18:44:56.115776
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '8Sae<X\\P?}KS%y{+n7'
    var_0 = cliargs_deferred_get(str_0)
    assert var_0 == default


# Generated at 2022-06-24 18:45:01.209174
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '8Sae<X\\P?}KS%y{+n7'
    str_1 = 'TqT9uQ?4'
    var_0 = cliargs_deferred_get(str_0)
    var_1 = cliargs_deferred_get(str_1)
    assert var_0 == var_1

test_case_0()
test_cliargs_deferred_get()

# Generated at 2022-06-24 18:45:02.036909
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True

# Test global context is created correctly

# Generated at 2022-06-24 18:45:11.599207
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'U6Q1:@[(d+gWf5AnaJ'
    str_1 = 'X8)yM'
    str_2 = 'O\\$=\\}B-\\'
    str_3 = 'YYvX{W\\mI]t_'
    str_4 = 'ZT'
    str_5 = 'Ci}'
    str_6 = 'p'
    str_7 = 'nM%$'
    str_8 = '>SJ'
    str_9 = 'H'
    str_10 = 'Y%c'
    str_11 = 'GzS'
    str_12 = '~t'
    str_13 = '7F='
    str_14 = '\\'
    str_15 = '|'
    str_

# Generated at 2022-06-24 18:45:20.368912
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = {
        'action': {
            'default': 'my_default_action',
            'choices': [
                'my_action',
                'my_other_action',
            ],
        },
    }
    _init_global_context(args)

    # test that the default gets set if the CLIARGS doesn't have it set
    assert CLIARGS['action'] == 'my_default_action'
    action = cliargs_deferred_get('action')
    assert action() == 'my_default_action'

    # test that the default does not get set if the CLIARGS does have it set
    CLIARGS['action'] = 'my_set_action'
    action = cliargs_deferred_get('action', 'my_default_action')

# Generated at 2022-06-24 18:45:23.308748
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print('unitTest - test_cliargs_deferred_get')
    str_0 = '<e{g'
    var_0 = cliargs_deferred_get(str_0)

# Generated at 2022-06-24 18:45:34.073934
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '8Sae<X\\P?}KS%y{+n7'
    result = cliargs_deferred_get(str_0)
    assert(isinstance(result, dict))
    str_1 = 'X\'lNS)kZ'
    result = cliargs_deferred_get(str_1)
    assert(result == None)
    str_2 = 'v\x0e\x1d\x0f\x1b\r\x16\x10\x05\x1a\x1a\x13\x1b\x12\x0f\x1e'

# Generated at 2022-06-24 18:45:36.863768
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # result = cliargs_deferred_get(str_0)
    # assert result == None
    assert True # TODO: implement your test here

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:45:38.941949
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '+gdkBCY;\tS]O+eZ^z'
    int_0 = 7
    bool_0 = False
    assert callable(cliargs_deferred_get(str_0))
