

# Generated at 2022-06-24 18:36:07.005977
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'byc~u~0X': '0X'})
    test_case_0()

# Generated at 2022-06-24 18:36:16.791100
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.text.converters import to_unicode
    import ansible.module_utils.common.string as string
    import sys
    test_case = [
        # Testcase entries are tuples of (expected_result, args, kwargs)
        (None, (), dict(key=to_unicode('Hn^z'))),
        (None, (to_unicode('yq3I'),), dict(key=to_unicode('Z`r'))),
        (None, (to_unicode('>-L_'),), dict(key=to_unicode('N1O'), shallowcopy=True)),
    ]


# Generated at 2022-06-24 18:36:18.683906
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert False, "Cannot test cliargs_deferred_get()"


# Generated at 2022-06-24 18:36:21.314759
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
    except Exception as err:
        print(str(err))
        assert False


# Generated at 2022-06-24 18:36:24.176314
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "lA(5"

    str_1 = "Uv~[U"
    var_0 = cliargs_deferred_get(str_1)
    assert var_0 == None

# Generated at 2022-06-24 18:36:35.269791
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    with pytest.raises(AssertionError):
        cliargs_deferred_get('alternate_tilde_enable', default=False, shallowcopy=False)
    with pytest.raises(AssertionError):
        cliargs_deferred_get('w', default=False, shallowcopy=False)
    with pytest.raises(AssertionError):
        cliargs_deferred_get('string_0', default=False, shallowcopy=False)
    with pytest.raises(AssertionError):
        cliargs_deferred_get('str_0', default=False, shallowcopy=False)

# Generated at 2022-06-24 18:36:44.596601
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    before = GlobalCLIArgs.get_instance()
    GlobalCLIArgs._instance = None

    test_case_0()
    after = GlobalCLIArgs.get_instance()

    GlobalCLIArgs._instance = before

    assert id(after) == id(before)

if __name__ == "__main__":
    # Unit test code
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:36:48.165390
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    str_1 = "\\*$\\"
    var_0 = cliargs_deferred_get(str_0)
    var_1 = cliargs_deferred_get(str_1)


# Generated at 2022-06-24 18:36:54.354946
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        raise Exception()
    except:
        test_case_0()

# Global Variable CLIARGS
# Type: <class 'ansible.module_utils.common.context.CLIArgs'>
# Value: CLIArgs({'check': False, 'file': None, 'listhosts': None, 'syntax': None, 'start_at_task': None, 'step': None, 'limit': None, 'diff': False, 'tags': None, 'skip_tags': None, 'ask_sudo_pass': False, 'ask_su_pass': False, 'ask_pass': False, 'su': False, 'sudo': False, 'sudo_user': None, 'verbosity': 0, 'flush_cache': None, 'force_handlers': False, 'force': True, 'inventory': 'localhost,', 'listtasks': None, '

# Generated at 2022-06-24 18:36:59.894407
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "f_w_b"
    var_0 = cliargs_deferred_get(str_0)
    assert callable(var_0), "cliargs_deferred_get should return function"
    assert var_0(), "f_w_b should return True"
    var_0 = cliargs_deferred_get(str_0, shallowcopy=True)
    assert var_0() is True, "f_w_b should return True"


# Not called by the unit tests, but called whenever the unit tests don't
# explicitly call it
_init_global_context({})

# Generated at 2022-06-24 18:37:06.132422
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "kCjt"
    bool_0 = False
    var_0 = cliargs_deferred_get(str_0, bool_0)
    assert var_0() == bool_0


# Generated at 2022-06-24 18:37:07.977777
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    with pytest.raises(NameError):
        cliargs_deferred_get()


# Generated at 2022-06-24 18:37:11.724473
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    cliargs_deferred_get(str_0)

# Main body of code
if __name__ == '__main__':
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:17.365274
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        # Setup mock
        expected_result = "X' byc~u~0"
        str_0 = "byc~u~'0X"
        var_0 = cliargs_deferred_get(str_0)
        assert var_0() == expected_result
    except AssertionError:
        raise AssertionError('Unexpected result: cliargs_deferred_get returned "{0}", expected "{1}"'.format(str(var_0()), str(expected_result)))

# Generated at 2022-06-24 18:37:21.584550
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = test_case_0()
    print(var_0)

# Generated at 2022-06-24 18:37:24.343115
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "QG]Zb0X"
    var_0 = cliargs_deferred_get(str_0)



# Generated at 2022-06-24 18:37:26.997454
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    var_0 = cliargs_deferred_get(str_0)
    assert 1 == var_0

# Test_case_1

# Generated at 2022-06-24 18:37:30.475321
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    func_0 = cliargs_deferred_get('abc')
    assert isinstance(func_0(), str)
    func_1 = cliargs_deferred_get('def', shallowcopy=True)
    assert isinstance(func_1(), str)

# Generated at 2022-06-24 18:37:32.089238
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_1 = get('foo', default=None, shallowcopy=False)


# Generated at 2022-06-24 18:37:35.142779
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()
    test_case_0()


if __name__ == "__main__":
    # execute only if run as a script
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:47.742947
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    var_1 = cliargs_deferred_get(str_0)
    try:
        assert var_1() == {}
        var_2 = True
    except:
        var_2 = False
    assert var_2
    str_1 = "bnr~a|"
    var_3 = cliargs_deferred_get(str_1)
    try:
        assert var_3() == {}
        var_4 = True
    except:
        var_4 = False
    assert var_4
    str_2 = "eLu?-d"
    var_5 = cliargs_deferred_get(str_2)
    try:
        assert var_5() == {}
        var_6 = True
    except:
        var

# Generated at 2022-06-24 18:37:49.615746
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert test_case_0() == None

# Entry point for the ansible-test utility

# Generated at 2022-06-24 18:37:52.520885
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest

    with pytest.raises(AssertionError):
        cliargs_deferred_get('')


# Generated at 2022-06-24 18:38:00.125617
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    var_0 = cliargs_deferred_get(str_0)
    str_1 = "vn~'7Y"
    var_1 = cliargs_deferred_get(str_1)
    str_2 = "vn~'7Y"
    var_2 = cliargs_deferred_get(str_2)
    str_3 = "byc~u~'0X"
    var_3 = cliargs_deferred_get(str_3, default=var_1)
    str_4 = "byc~u~'0X"
    var_4 = cliargs_deferred_get(str_4, default=var_2)
    str_5 = "byc~u~'0X"


# Generated at 2022-06-24 18:38:01.900654
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

# Run the tests
if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:05.659043
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = "byc~u~'0X"
    str_0 = cliargs_deferred_get(var_0)
    assert str_0 == '0X', 'function cliargs_deferred_get failed'


# Generated at 2022-06-24 18:38:15.702884
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    var_0 = cliargs_deferred_get(str_0)
    str_1 = 'p"6y'
    var_1 = cliargs_deferred_get(str_1)
    str_2 = '_o?y'
    var_2 = cliargs_deferred_get(str_2)
    str_3 = ']e'
    var_3 = cliargs_deferred_get(str_3)

# Entry point for running unit tests
if __name__ == '__main__':
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:20.513030
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Assertions
    str_0 = "byc~u~'0X"
    var_0 = cliargs_deferred_get(str_0)



# Generated at 2022-06-24 18:38:22.191275
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    test_case_0()
    test_case_1()


# Generated at 2022-06-24 18:38:24.249237
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    var_0 = cliargs_deferred_get(str_0)

# Generated at 2022-06-24 18:38:34.788731
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Unit test for cliargs_deferred_get
    assert False
#
#
# Functional test for function cliargs_deferred_get

# Generated at 2022-06-24 18:38:40.484546
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Get the value of the "byc~u~'0X" key from CLIARGS
    var_0 = cliargs_deferred_get("byc~u~'0X")
    # Now use the value to create a context object showing how many multiples of 9 do we need
    # to get to at least that number of Ansible Galaxy roles (should be at least 9 for any
    # real value)
    var_0 = Context(var_0, 'roles', 'Ansible Galaxy Roles', '9', 'multiple of 9')
    print(var_0.value_str())


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 18:38:43.270643
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_1 = "g58U6"
    str_2 = "zXl6Q"
    value_1 = cliargs_deferred_get(str_1, str_2)
    assert value_1 is str_2


test_case_0()
test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:44.263351
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()



# Generated at 2022-06-24 18:38:46.603352
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    with pytest.raises(Exception):
        str_0 = None
        var_1 = cliargs_deferred_get(str_0)


# Generated at 2022-06-24 18:38:56.026072
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with
    # - non-default argument value
    # - default argument value
    # - non-default argument and default argument value
    str_0 = ")'Li,?|"
    str_1 = "7^N0"
    str_2 = "N.u/2)5*t"
    str_3 = "B>a?_&O)2"
    str_4 = "L:pjK@<g>"
    var_0 = cliargs_deferred_get(str_0, str_1)
    var_1 = cliargs_deferred_get(str_2, str_3)
    var_2 = cliargs_deferred_get(str_4, str_3, str_1)


# Generated at 2022-06-24 18:38:58.811856
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''
    Unit test for function cliargs_deferred_get
    '''
    try:
        test_case_0()
    except TypeError as error:
        print(error)

test_cliargs_deferred_get()

# Generated at 2022-06-24 18:39:00.834659
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    var_0 = cliargs_deferred_get(str_0)



# Generated at 2022-06-24 18:39:03.202757
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = None
    try:
        var_0 = test_case_0()
    except Exception as exp:
        print(exp)
    finally:
        print('line', var_0)

test_cliargs_deferred_get()

# Generated at 2022-06-24 18:39:07.014689
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        cliargs_deferred_get()

    except SystemExit:
        assert False



# Generated at 2022-06-24 18:39:26.407934
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    for i in range(100):
        test_case_0()

# Generated at 2022-06-24 18:39:31.791515
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()


include_vars = cliargs_deferred_get('include_vars', default=dict(), shallowcopy=True)



# Generated at 2022-06-24 18:39:34.290909
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(str_0)

if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:39:35.260954
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True



# Generated at 2022-06-24 18:39:39.095026
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # str_0 = "byc~u~'0X"
    # var_0 = cliargs_deferred_get(str_0)
    pass


if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:39:42.460786
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        str_0 = "byc~u~'0X"
        var_0 = cliargs_deferred_get(str_0)
    except:
        assert (False)

# test_cliargs_deferred_get()

# Generated at 2022-06-24 18:39:45.404996
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
    except:
        print('Exception: test_case_0()')

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:39:47.940346
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    var_1 = cliargs_deferred_get("z"'J')
    assert callable(var_1)



# Generated at 2022-06-24 18:39:50.506545
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_1 = "y'0X"
    try:
        assert isinstance(var_1, str)
    except AssertionError as e:
        raise e


# Generated at 2022-06-24 18:39:53.632176
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    var_0 = cliargs_deferred_get(str_0)
    assert var_0 == cliargs_deferred_get(str_0)

# Generated at 2022-06-24 18:40:31.629903
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(str_0)(), "CLIARGS should have been created with the get call"
    CLIARGS.clear()
    str_1 = "byc~u~'0X"
    assert cliargs_deferred_get(str_1)(), "CLIARGS should have been created with the get call"

# Generated at 2022-06-24 18:40:32.406782
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

# Generated at 2022-06-24 18:40:33.169698
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print(test_case_0)

# Generated at 2022-06-24 18:40:35.069987
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
    except:
        print('Failed to run test case 0')

if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:40:37.930761
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    key = cliargs_deferred_get

    # Exercise
    # Exercise

    # Verify
    pass


# Generated at 2022-06-24 18:40:40.177582
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    var_0 = cliargs_deferred_get(str_0)
    print(var_0)



# Generated at 2022-06-24 18:40:45.068398
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    var_0 = cliargs_deferred_get(str_0)
    assert var_0() == u'0X', "Expected 0X, got %s" % repr(var_0())

if __name__ == "__main__":
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:40:48.692091
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print("Test 0")
    test_case_0()
    print("Test 1")
    test_case_1()
    print("Test 2")
    test_case_2()



# Generated at 2022-06-24 18:40:52.585164
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    var_0 = cliargs_deferred_get(str_0)
    var_1 = cliargs_deferred_get(str_0, True)


#
# The end.

# Generated at 2022-06-24 18:40:54.694628
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    var_0 = cliargs_deferred_get(str_0)
    assert var_0 == "tilde_ttt"



# Generated at 2022-06-24 18:42:11.372850
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'zs0j'
    str_1 = 'b'
    var_0 = cliargs_deferred_get(str_0, str_1)
    var_1 = CLIARGS.get(str_0, str_1)
    assert var_0 != var_1
    test_case_0()

test_cliargs_deferred_get()

# End of this file.

# Generated at 2022-06-24 18:42:16.549671
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        str_0 = "b4t1s4s@"
        var_0 = cliargs_deferred_get(str_0)
        return var_0
    except Exception as e:
        print(e)

# Generated at 2022-06-24 18:42:19.605095
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "'^y"
    var_0 = cliargs_deferred_get(str_0)
    str_1 = '1h'
    var_1 = cliargs_deferred_get(str_1)
    if ((var_0 != 'q') and (var_1 != 'v')):
        raise Exception('Failed to create the global context')

# Generated at 2022-06-24 18:42:25.835757
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = ""
    str_1 = ""
    str_2 = ""
    str_3 = ""
    str_4 = ""
    str_5 = ""
    str_6 = ""
    str_7 = ""
    str_8 = ""
    str_9 = ""
    str_10 = ""
    str_11 = ""
    str_12 = ""
    str_13 = ""
    str_14 = ""
    str_15 = ""
    str_16 = ""
    str_17 = ""
    str_18 = ""
    str_19 = ""
    str_20 = ""
    str_21 = ""
    str_22 = ""
    str_23 = ""
    str_24 = ""
    str_25 = ""
    str_26 = ""
    str_27 = ""
    str_

# Generated at 2022-06-24 18:42:28.374171
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_1 = "apv+d+'0x"
    var_1 = cliargs_deferred_get(str_1)
    assert var_1() == "", "The function 'cliargs_deferred_get' did not return the expected value"

# Generated at 2022-06-24 18:42:31.435096
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    var_1 = cliargs_deferred_get(str_0)
    assert var_1() == None

# Generated at 2022-06-24 18:42:34.678997
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the function cliargs_deferred_get"""

    try:
        test_case_0()
    except Exception as e:
        print("Exception raised in test case: {}".format(e))

# Generated at 2022-06-24 18:42:43.924846
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    with patch('ansible.utils.context_objects.CLIARGS', new_callable=PropertyMock) as mock_CLIARGS:
        instance = mock_CLIARGS.return_value

        # set the attachment_mime_type attribute
        type(instance).attachment_mime_type = PropertyMock(return_value='text/plain')

        # set the attachment_filename attribute
        type(instance).attachment_filename = PropertyMock(return_value='stdout')

        str_0 = "byc~u~'0X"
        var_1 = cliargs_deferred_get(str_0)
        assert var_1 == instance.attachment_mime_type
        str_1 = "wjT0&\|[p"
        var_2 = cliargs_deferred_

# Generated at 2022-06-24 18:42:44.701724
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()


# Generated at 2022-06-24 18:42:49.989072
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Build a mock for the expected results
    expected_mock = cliargs_deferred_get('byc~u~0X')
    # Call the function under test
    actual = test_case_0()
    # Make sure the results are as expected
    assert expected_mock == actual


# Generated at 2022-06-24 18:45:34.770891
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    try:
        assert test_case_0()
    except SystemExit:
        assert False


# Generated at 2022-06-24 18:45:37.535396
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "byc~u~'0X"
    var_0 = cliargs_deferred_get(str_0)
    assert var_0() is None

test_case_0()
test_cliargs_deferred_get()

# Generated at 2022-06-24 18:45:39.267021
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
    except Exception as err:
        print('Exception caught: ' + str(err))
        return 1



# Generated at 2022-06-24 18:45:42.813313
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass


if __name__ == "__main__":
    import sys
    import doctest

    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-24 18:45:46.611415
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = None
    var_0 = cliargs_deferred_get(str_0,default=None,shallowcopy=False)
    var_1 = test_case_0()
    # Check for equality
    if var_0 == var_1:
        print('Test case passed.')
    else:
        print('Test case failed.')

# Unit tests for cliargs_deferred_get

# Generated at 2022-06-24 18:45:48.331364
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
    except:
        assert 0



# Generated at 2022-06-24 18:45:54.407636
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    if False:
        # Fixme: test
        str.decode()
    # Fixme: when we know the cliargs_deferred_get function has been called this
    # function can be tested
    str_0 = "byc~u~'0X"
    cliargs_deferred_get(str_0)
    # Fixme: Implement me
    assert False == True

# Generated at 2022-06-24 18:46:00.541858
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Rebind the global CLIARGS to a new value for a test
    global CLIARGS
    old_value = CLIARGS
    try:
        CLIARGS = CLIArgs({'somekey': 'somevalue'})
        assert cliargs_deferred_get('somekey')() == 'somevalue'

        # Should return default when key is not present
        assert cliargs_deferred_get('someotherkey', default='someothervalue')() == 'someothervalue'

    finally:
        CLIARGS = old_value
        del old_value