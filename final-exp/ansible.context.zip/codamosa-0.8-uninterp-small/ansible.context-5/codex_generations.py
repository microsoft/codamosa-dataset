

# Generated at 2022-06-24 18:36:06.687686
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils import basic
    results = basic.run_command('sh test_ansible_context.sh', check_rc=True)
    assert results[0] == 0

# Generated at 2022-06-24 18:36:09.286890
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(5.5, default=5.5)
    cliargs_deferred_get(1152.77, default=1152.77)

# Generated at 2022-06-24 18:36:10.336416
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert False  # remove this line and complete the test!


# Generated at 2022-06-24 18:36:16.678870
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    with mock.patch('ansible.utils.context_objects.CLIARGS', new={}):
       var_0 = cliargs_deferred_get(2682.71)
       assert isinstance(var_0, (types.LambdaType, ))

# Generated at 2022-06-24 18:36:17.845462
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:36:21.315107
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        rv = cliargs_deferred_get(float_0)
    except Exception as e:
        rv = e

    assert True


# Generated at 2022-06-24 18:36:22.275623
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass



# Generated at 2022-06-24 18:36:25.585682
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set

    cliargs_deferred_get_0_0 = cliargs_deferred_get(2682.71)



# Generated at 2022-06-24 18:36:31.521127
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = 2682.71
    var_0 = cliargs_deferred_get(float_0)
# testing for equality float_0 == float_0
    if float_0 == float_0:
        assert True
    else:
        assert False
# testing for equality var_0 == var_0
    if var_0 == var_0:
        assert True
    else:
        assert False


# Generated at 2022-06-24 18:36:40.806546
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    assert CLIARGS is not None
    assert cliargs_deferred_get(CLIARGS) is CLIARGS
    assert cliargs_deferred_get(CLIARGS, default=cliargs_deferred_get) is CLIARGS
    assert cliargs_deferred_get(CLIARGS, default=cliargs_deferred_get) is CLIARGS
    assert cliargs_deferred_get(CLIARGS, default=CLIARGS) is CLIARGS
    assert cliargs_deferred_get(CLIARGS, default=CLIARGS) is CLIARGS
    test_case_0()

# Generated at 2022-06-24 18:36:45.396508
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Test function cliargs_deferred_get
    """
    # No error has been raised if all the tests pass
    assert True

# Generated at 2022-06-24 18:36:46.390068
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert test_case_0() == None

# Generated at 2022-06-24 18:36:48.652768
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    val = cliargs_deferred_get('test')
    assert callable(val)

# Generated at 2022-06-24 18:36:52.934009
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible_collections.testns.testcoll.plugins.module_utils.facts import default_facts

    # Set global argument defaults
    _init_global_context({})

    # Defer getting an unspported argument to the CLIARGS
    var_0 = cliargs_deferred_get('foo', default_facts)
    assert var_0() == default_facts

    # Defer getting a supported argument to the CLIARGS
    var_1 = cliargs_deferred_get('connection')
    assert var_1() == 'smart'

    test_case_0()

# Generated at 2022-06-24 18:36:53.556646
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:36:56.189112
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = 2682.71
    var_0 = cliargs_deferred_get(float_0)
    assert type(var_0) == type(lambda:0)


# Generated at 2022-06-24 18:36:56.752220
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:36:57.537082
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert False

# Generated at 2022-06-24 18:37:01.657101
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    var_0 = cliargs_deferred_get()
    assert var_0 == None



# Generated at 2022-06-24 18:37:12.359769
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-24 18:37:26.953785
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'good': '', 'bad': 0})

    assert cliargs_deferred_get('good')(), 'should be good'
    #assert cliargs_deferred_get('bad')(), 'should be bad'
    assert cliargs_deferred_get('bad', default=5)(), 'should be bad'
    assert cliargs_deferred_get('awful', default=5)(), 'should be awful'

    test_case_0()

# Generated at 2022-06-24 18:37:28.979838
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(float_0) == 2682.71



# Generated at 2022-06-24 18:37:30.285069
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:37:39.870221
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get('string_0')
    cliargs_deferred_get('s', 'string_1')
    cliargs_deferred_get('bool_0')
    cliargs_deferred_get('b', 'bool_1')
    cliargs_deferred_get('float_0')
    cliargs_deferred_get('f', 'float_1')
    cliargs_deferred_get('int_0')
    cliargs_deferred_get('i', 'int_1')
    cliargs_deferred_get('list_0')
    cliargs_deferred_get('l', 'list_1')
    cliargs_deferred_get('list_2', 'list_2')

# Generated at 2022-06-24 18:37:42.666174
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    values = {'float_0': 2682.71, 'var_0': cliargs_deferred_get(2682.71)}
    assert values == {'float_0': 2682.71, 'var_0': None}

# Generated at 2022-06-24 18:37:44.760745
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = 2682.71
    assert cliargs_deferred_get(var_0)() == 2682.71

# Generated at 2022-06-24 18:37:48.855796
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = 2682.71
    var_0 = cliargs_deferred_get(float_0)

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 18:37:51.438162
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get"""
    pass # test_case_0(self)



# Generated at 2022-06-24 18:38:00.129244
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.text.converters import BOOLEAN_TRUE_STRINGS, to_text
    from ansible.module_utils.common.text.converters import BOOLEAN_FALSE_STRINGS, to_text
    assert cliargs_deferred_get(2682.71) == to_text(2682.71)
    assert cliargs_deferred_get(BOOLEAN_TRUE_STRINGS) == to_text(BOOLEAN_TRUE_STRINGS)
    assert cliargs_deferred_get(BOOLEAN_FALSE_STRINGS) == to_text(BOOLEAN_FALSE_STRINGS)



# Generated at 2022-06-24 18:38:01.634779
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(float_0 = 2682.71)



# Generated at 2022-06-24 18:38:19.748179
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Load the CLI arguments file
    import sys
    import json

    # Load the games file and parse the first argument to be the JSON representation of the CLI arguments
    with open(sys.argv[1], 'r') as games_file:
        args = json.loads(games_file.readline())

    # Call _init_global_context
    _init_global_context(args)

    # Load the test data file
    with open(sys.argv[2], 'r') as test_file:
        # Extract the function name
        func_name = test_file.readline().strip()

        # Extract the function arguments
        func_args = json.loads(test_file.readline())

        # Call the function and check its output

# Generated at 2022-06-24 18:38:27.045773
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs(dict())

    assert cliargs_deferred_get(0, 2) == 2
    assert cliargs_deferred_get(0, 2, shallowcopy=True) == 2
    CLIARGS = CLIArgs({0: 3})
    assert cliargs_deferred_get(0, 2) == 3
    assert cliargs_deferred_get(0, 2, shallowcopy=True) == 3

    CLIARGS = CLIArgs({0: [1,2,3]})
    assert cliargs_deferred_get(0, []) == [1, 2, 3]
    assert cliargs_deferred_get(0, [], shallowcopy=True) == [1, 2, 3]


# Generated at 2022-06-24 18:38:34.733351
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os

    # Ensure we get a function back
    result = cliargs_deferred_get(to_bytes('a'), to_bytes('b'))
    assert callable(result)

    # Ensure we get the proper values back
    test_case_0()

    # Ensure all supported versions return the fixed value
    for major, minor in basic.SUPPORTED_PYTHON_VERSIONS:
        result = cliargs_deferred_get(to_bytes(str(major)), default=to_bytes(str(minor)))()
        assert result == str(minor)

    # Ensure we get the default value back

# Generated at 2022-06-24 18:38:43.431691
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'ansible_verbosity': 1, 'private_key_file': None, 'connection': 'smart', 'timeout': 10,
        'forks': 5, 'remote_user': None, 'ask_pass': False, 'module_path': None, 'ssh_common_args': '',
        'ssh_extra_args': '', 'sftp_extra_args': '', 'scp_extra_args': '', 'become': False, 'become_method': None,
        'become_user': None, 'become_ask_pass': False, 'verbosity': 0, 'check': False, 'listhosts': None,
        'listtasks': None, 'listtags': None, 'syntax': None, 'diff': False}
    test_case_0()
    assert var_0()

# Generated at 2022-06-24 18:38:44.778085
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert CLIARGS == {}

    test_case_0()

# Generated at 2022-06-24 18:38:50.364715
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # It should return float
    ret_0 = cliargs_deferred_get('maybe', default=3.141592653589793, shallowcopy=False)
    assert 3.141592653589793 == ret_0

    # It should return float
    ret_1 = cliargs_deferred_get('hello', default=3.141592653589793, shallowcopy=False)
    assert 3.141592653589793 == ret_1

    # It should return float
    ret_2 = cliargs_deferred_get('a', default=3.141592653589793, shallowcopy=False)
    assert 3.141592653589793 == ret_2

    # It should return float

# Generated at 2022-06-24 18:38:53.095986
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Not valid because the context object is still empty
    test_case_0()

    # TODO: Add tests that use a context object that is real
    return

# Generated at 2022-06-24 18:38:56.148167
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {}
    _init_global_context(cli_args)
    float_0 = 2682.71
    var_0 = cliargs_deferred_get(float_0)
    assert var_0 == 2682.71

# Generated at 2022-06-24 18:39:03.745651
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = {'a': 'b'}
    _init_global_context(args)

    assert cliargs_deferred_get('a') == 'b'
    assert cliargs_deferred_get('a', 'c') == 'b'
    assert cliargs_deferred_get('a', 'b') == 'b'
    assert cliargs_deferred_get('a', 'c', True) == 'b'
    assert cliargs_deferred_get('a', 'b', True) == 'b'
    assert cliargs_deferred_get('a', shallowcopy=True) == 'b'
    assert cliargs_deferred_get('a', 'c', shallowcopy=True) == 'b'
    assert cliargs_deferred_get('a', 'b', shallowcopy=True)

# Generated at 2022-06-24 18:39:07.090027
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    orig_cliargs = CLIARGS
    CLIARGS = CLIArgs({0: 'some_value'})

    try:
        var_0 = cliargs_deferred_get(0)
        assert var_0 == 'some_value'
    finally:
        CLIARGS = orig_cliargs

# Generated at 2022-06-24 18:39:36.485017
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get.__name__ == 'cliargs_deferred_get'
    assert cliargs_deferred_get.__doc__ == 'Closure over getting a key from CLIARGS with shallow copy functionality\n\n    Primarily used in ``FieldAttribute`` where we need to defer setting the default\n    until after the CLI arguments have been parsed\n\n    This function is not directly bound to ``CliArgs`` so that it works with\n    ``CLIARGS`` being replaced\n    '

# Generated at 2022-06-24 18:39:43.194743
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.constants
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    ansible_constants_mock = patch.dict(ansible.constants.__dict__, {'__file__': '/ansible_constants.py'})
    with ansible_constants_mock:
        from ansible.utils.context_objects import cliargs_deferred_get
        cliargs_deferred_get(1.68)



# Generated at 2022-06-24 18:39:51.309893
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # The following argument specifications are only used with
    # om_proto_compile_full.
    import tempfile
    import json
    args = [
        '--json', '--quiet',
        '--',
        '{"1": [1, 2, 3]}',
        '{"2": [1, 2, 3]}'
    ]

    temp = tempfile.NamedTemporaryFile(delete=False)
    temp.write('\n'.join(args).encode('utf-8'))
    temp.close()

    import pytest
    with pytest.raises(SystemExit):
        from ansible.playbook.play_context import PlayContext
        from ansible.parsing.dataloader import DataLoader

        context = PlayContext()
        loader = DataLoader()

# Generated at 2022-06-24 18:39:53.853993
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = 2682.71
    var_0 = cliargs_deferred_get(float_0)


# Generated at 2022-06-24 18:39:58.630703
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(float_0)
    assert var_0 == float_0
    var_1 = cliargs_deferred_get(float_0)
    assert var_1 == float_0
    var_2 = cliargs_deferred_get(float_0)
    assert var_2 == float_0



# Generated at 2022-06-24 18:40:00.411549
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(float_0)
    assert var_0 == 2682.71


# Generated at 2022-06-24 18:40:03.161362
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ctypes
    import inspect
    import logging
    import os
    import subprocess
    import sys
    import tempfile
    import time
    import unittest

    logging.basicConfig(level=logging.DEBUG, stream=sys.stderr)


# Generated at 2022-06-24 18:40:03.992775
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass # stub


# Generated at 2022-06-24 18:40:07.640984
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = 2682.71
    var_0 = cliargs_deferred_get(float_0)



# Generated at 2022-06-24 18:40:15.941898
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.pytest.utils import assert_type
    from ansible.utils.pytest.mock import MockCLIArgs
    context = MockCLIArgs()
    context['foo'] = 'bar'
    context['bar'] = 'baz'
    context['baz'] = ['bar', 'baz', 'foo']
    get = cliargs_deferred_get
    assert get('foo')() == 'bar'
    assert get('foo', default=0)() == 'bar'
    assert get('bar')() == 'baz'
    assert get('bar', default=0)() == 'baz'
    assert get('baz')() == ['bar', 'baz', 'foo']
    assert get('baz', default=0)() == ['bar', 'baz', 'foo']
    assert get

# Generated at 2022-06-24 18:40:57.558387
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # var_0 = cliargs_deferred_get(key='python')
    # print(var_0)
    test_case_0()


# Generated at 2022-06-24 18:41:00.850152
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = 2682.71
    var_0 = cliargs_deferred_get(float_0)
    # assert var_0 == var_0

# Generated at 2022-06-24 18:41:03.238354
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    ### Unit test for cliargs_deferred_get
    assert test_case_0()


if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:41:05.383093
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()

    except Exception:
        import sys
        print("Unexpected error:", sys.exc_info()[0])
        raise

# Generated at 2022-06-24 18:41:08.141297
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = 53641.246
    assert cliargs_deferred_get(float_0) == 53641.246
    assert cliargs_deferred_get(float_0, None) == 53641.246

# Generated at 2022-06-24 18:41:14.445379
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Set up test values
    float_0 = 1.0
    var_0 = cliargs_deferred_get(float_0)
    assert var_0 == 1.0

    float_1 = 1.3
    var_1 = cliargs_deferred_get(float_1)
    assert var_1 == 1.3

    float_2 = 1.6
    var_2 = cliargs_deferred_get(float_2)
    assert var_2 == 1.6

    float_3 = 1.9
    var_3 = cliargs_deferred_get(float_3)
    assert var_3 == 1.9

    float_4 = 2.2
    var_4 = cliargs_deferred_get(float_4)
    assert var_4 == 2.2

    float

# Generated at 2022-06-24 18:41:24.454305
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    argv = ["./ansible-test", "/home/toshio/src/ansible/test/units/module_utils/common/test_context.py"]
    assert cliargs_deferred_get(argv)() == argv

if __name__ == "__main__":
    from ansible.module_utils.common.collections import BytesEncodedDict
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '--arg', type=BytesEncodedDict)
    args = parser.parse_args()
    _init_global_context(args)
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:41:30.920893
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    fixture_0 = test_case_0
    fixture_1 = cliargs_deferred_get
    fixture_2 = cliargs_deferred_get
    fixture_3 = cliargs_deferred_get
    fixture_4 = cliargs_deferred_get
    fixture_5 = cliargs_deferred_get
    fixture_6 = cliargs_deferred_get

# Test the cliargs_deferred_get function
# This is the second test case

# Generated at 2022-06-24 18:41:33.724752
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = 2682.71
    var_0 = cliargs_deferred_get(float_0)
    with pytest.raises(TypeError):
        cliargs_deferred_get()

# Generated at 2022-06-24 18:41:34.476260
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:43:00.674186
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = 2682.71
    var_0 = cliargs_deferred_get(float_0)
    assert True


# Generated at 2022-06-24 18:43:08.433515
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {
        'timeout': 30,
        'forks': 5,
        'become': True,
        'become_method': 'sudo',
        'listhosts': None,
        'listtasks': None,
        'listtags': None,
        'syntax': None,
        'module_path': '/home/vagrant/.ansible/plugins/modules',
        'become_user': 'root',
        'remote_user': 'vagrant',
        'private_key_file': '/home/vagrant/.ssh/id_rsa',
        'connection': 'smart',
        'verbosity': 0,
        'check': False}

    _init_global_context(cli_args)
    cliarg_deferred_value = cliargs_deferred_get('verbosity')


# Generated at 2022-06-24 18:43:16.381976
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Run the test with the original value of cliargs_deferred_get_global_var_0
    # The test also confirms that it's safe to call the function without any
    # args
    assert test_case_0() == cliargs_deferred_get_global_var_0
    # Set cliargs_deferred_get_global_var_0 to a new value and re-run the test
    old_value = cliargs_deferred_get_global_var_0
    try:
        cliargs_deferred_get_global_var_0 = 1
        assert test_case_0() == cliargs_deferred_get_global_var_0
    finally:
        cliargs_deferred_get_global_var_0 = old_value

# Generated at 2022-06-24 18:43:17.785654
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = 2682.71
    var_0 = cliargs_deferred_get(float_0)

# Generated at 2022-06-24 18:43:25.089227
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = test_case_0()
    from ansible.module_utils.common_functions import ensure_type
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.module_utils._text import to_native
    from ansible.errors import AnsibleError
    from ansible.utils.display import Display
    import imp
    import os.path
    import sys
    import warnings
    import types
    if not os.path.isfile("/usr/bin/ansible-doc"):
        warnings.warn("The unit test module requires /usr/bin/ansible-doc")
        return

# Generated at 2022-06-24 18:43:26.402330
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:43:27.649293
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True
    # test_case_0()



# Generated at 2022-06-24 18:43:32.269845
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = 2682.71
    assert cliargs_deferred_get(float_0) is not None
    assert isinstance(cliargs_deferred_get(float_0), float)
    assert cliargs_deferred_get(float_0, shallowcopy=False) == 2682.71
    assert cliargs_deferred_get(float_0, shallowcopy=True) == 2682.71

# Generated at 2022-06-24 18:43:34.918064
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {}
    _init_global_context(cli_args)
    test_case_0()


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(args=sys.argv))

# Generated at 2022-06-24 18:43:44.383470
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({1: 2})
    CLIARGS.setdefault(0, 42)
    assert cliargs_deferred_get(0)() == 42
    assert cliargs_deferred_get(0, 43)() == 42
    assert cliargs_deferred_get(1)() == 2
    assert cliargs_deferred_get(2)() == None
    assert cliargs_deferred_get(2, 43)() == 43
    assert cliargs_deferred_get(0, shallowcopy=True)() == 42
    assert isinstance(cliargs_deferred_get(1,shallowcopy=True)(), int)
    assert cliargs_deferred_get(2, 43, shallowcopy=True)() == 43
    float_0 = 2682