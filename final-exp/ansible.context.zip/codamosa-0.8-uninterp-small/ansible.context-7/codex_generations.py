

# Generated at 2022-06-24 18:36:08.498230
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = -175
    var_1 = cliargs_deferred_get(int_1)

# Generated at 2022-06-24 18:36:11.135169
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = -175
    var_1 = cliargs_deferred_get(int_1)
    assert var_1() == -175



# Generated at 2022-06-24 18:36:16.845089
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CliArgs
    test_obj = CliArgs({})
    default = 264
    result = cliargs_deferred_get(test_obj, default)
    assert result == 264



# Generated at 2022-06-24 18:36:20.614888
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    assert(callable(cliargs_deferred_get))
    try:
        cliargs_deferred_get(1)
    except NameError:
        pass
    else:
        assert False, "Expected an exception"

# Generated at 2022-06-24 18:36:23.384499
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test if TypeError raised when required arg is missing
    with pytest.raises(TypeError):
        cliargs_deferred_get()


# Generated at 2022-06-24 18:36:23.981325
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == False

# Generated at 2022-06-24 18:36:26.762508
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    funcs_list = _init_global_context.__code__.co_names
    assert "cliargs_deferred_get" in funcs_list
# EOF

# Generated at 2022-06-24 18:36:38.075715
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    int_1 = -113
    int_2 = -102
    int_3 = -24
    int_4 = -5
    int_5 = 29
    int_6 = 123
    list_0 = [int_6, int_6, int_6, int_6, int_6, int_6, int_6, int_6, int_6, int_6]
    dict_0 = dict()
    dict_0[int_6] = int_6
    dict_0[int_1] = int_0
    dict_0[int_6] = int_0
    dict_0[int_3] = int_0
    dict_0[int_2] = int_0
    dict_0[int_5] = int_0

# Generated at 2022-06-24 18:36:42.021971
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    passed = True
    placeholder = 0  # TODO: replace with real value
    original_placeholder = placeholder
    try:
        test_case_0()
        if placeholder != original_placeholder:
            passed = False
    except:
        passed = False
    print(('%s: %s' % (('test_cliargs_deferred_get', passed))))

# Generated at 2022-06-24 18:36:50.782916
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make sure we set up some arguments
    _init_global_context(dict(foo=5, bar='5', bam=dict(a=1, b=2)))

    # Check that we can get a value by key
    assert cliargs_deferred_get('foo')() == 5
    assert cliargs_deferred_get('bar')() == '5'
    assert cliargs_deferred_get('bam')() == dict(a=1, b=2)

    # Check that the default works
    assert cliargs_deferred_get('unknown')(default='default') == 'default'
    assert cliargs_deferred_get('unknown')(default=dict(t=3)) == dict(t=3)

    # Check that we can get a value by an key of an int
    assert cliargs

# Generated at 2022-06-24 18:37:00.375493
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import unittest
    import tempfile
    import inspect

    class TestCliargs_deferred_get(unittest.TestCase):
        def setUp(self):
            pass
        def test_cliargs_deferred_get_0(self):
            int_0 = -175
            var_0 = cliargs_deferred_get(int_0)
            self.assertEquals(var_0(), None)
        def tearDown(self):
            pass
    # Replace the built-in open() call with one that uses a tempfile
    unittest.TestLoader.open = tempfile.NamedTemporaryFile
    # Replace the built-in inspect.getsource() call with one that gets the source from a tempfile
    inspect.getsource = lambda x: tempfile.NamedTemporaryFile().read()
    un

# Generated at 2022-06-24 18:37:02.569380
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)

# Generated at 2022-06-24 18:37:03.149615
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:37:05.885263
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)



# Generated at 2022-06-24 18:37:07.389103
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)
    assert var_0 == None, "var_0 == None"


# Generated at 2022-06-24 18:37:12.098871
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-24 18:37:17.723208
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)
    assert var_0 == -175


if __name__ == '__main__':
    import pytest
    # The following command line arguments are used:
    #   --tb=line | --tb=native
    #   -s | --capture=no
    #   --verbose
    options = ['-s', '--tb=line', '--verbose']
    pytest.main(options)

# Generated at 2022-06-24 18:37:20.350627
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)


if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:21.432380
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)



# Generated at 2022-06-24 18:37:24.910326
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print(test_case_0())

if __name__ == "__main__":
    import ansible_test
    ansible_test.run_test(test_cliargs_deferred_get)

# Generated at 2022-06-24 18:37:31.003886
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)
    assert var_0() is int_0

# Generated at 2022-06-24 18:37:37.450446
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Create test input/output variable(s)
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)
    var_1 = CLIARGS.defaults[int_0]
    # Create expected output variable(s)
    expected_return_value = var_1

    # Call the targeted C function
    actual_return_value = test_case_0()

    # Check the results of the function call
    assert expected_return_value == actual_return_value

# Generated at 2022-06-24 18:37:40.120423
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup

    # Test
    test_case_0()

## Unit tests ##

if __name__ == "__main__":
    import nose
    nose.main(defaultTest=__name__)

# Generated at 2022-06-24 18:37:41.658942
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)

# Generated at 2022-06-24 18:37:49.874934
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from six import PY3
    from ansible.utils.context_objects import AnsibleFileAttribute
    from ansible.utils.context_objects import AnsibleFileAttributeCompatibility
    from ansible.utils.context_objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.context_objects import AnsibleVaultEncryptedUnicodeAttribute
    from ansible.utils.context_objects import AnsibleVaultEncryptedUnicodeAttributeCompatibility
    from ansible.utils.context_objects import AnsibleVaultVersionedUnicodeAttribute
    from ansible.utils.context_objects import AnsibleVaultVersionedUnicodeAttributeCompatibility
    from ansible.utils.context_objects import CliArgs
    from ansible.utils.context_objects import CliArgsAttribute
    from ansible.utils.context_objects import Cli

# Generated at 2022-06-24 18:37:55.883249
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        assert isinstance(test_case_0(), int)
    except (AssertionError, AttributeError) as e:
        print(e)
        print("AssertionError: in test_case_0")
        raise
    else:
        return True

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:59.625750
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Place your code here
    pass

if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-24 18:38:02.332870
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    result = cliargs_deferred_get('test_data')
    assert result == 'test_value', 'incorrect result for test_data'


################################################################
#
#   Begin test cases for docstrings
#
################################################################



# Generated at 2022-06-24 18:38:04.549212
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(0)

    assert callable(var_0)
    assert var_0() is None

# Generated at 2022-06-24 18:38:08.019480
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1, str_1 = 42, 'Forty-two'
    var_1 = cliargs_deferred_get(int_1, str_1)
    assert var_1 == 42


# Generated at 2022-06-24 18:38:23.846344
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = -289
    int_0 = -298
    int_2 = -448
    int_3 = -482
    int_4 = -424
    int_5 = -143
    int_6 = -6
    var_1 = cliargs_deferred_get(int_1)
    var_0 = cliargs_deferred_get(int_0)
    var_1 = cliargs_deferred_get(int_1)
    var_1 = cliargs_deferred_get(int_1)
    var_0 = cliargs_deferred_get(int_0)
    var_1 = cliargs_deferred_get(int_1)
    var_1 = cliargs_deferred_get(int_1)
    var_1 = cliargs_def

# Generated at 2022-06-24 18:38:27.078751
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

# Generated from the above test case.  This is used to determine the name of the generated function
# The original test case function is named test_case_[index] where [index] is the first or second arg
# to the call to ``test_cliargs_deferred_get``

# Generated at 2022-06-24 18:38:28.792690
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -39
    f_0 = cliargs_deferred_get(int_0, shallowcopy=True)
    assert f_0 is f_0


# Generated at 2022-06-24 18:38:32.048317
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)
    if not var_0:
        raise TypeError('var_0 did not get value from CLIARGS')


# Generated at 2022-06-24 18:38:33.326981
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(int_0)
    assert var_0 == 5
    


# Generated at 2022-06-24 18:38:35.197777
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    # call function
    try:
        test_case_0()
    except SystemExit:
        assert False, "Expected no SystemExit"


# Test for Class GlobalCLIArgs

# Generated at 2022-06-24 18:38:41.086441
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    default = None
    shallowcopy = False

    cliargs_deferred_get(int_0, default, shallowcopy)


if __name__ == '__main__':
    import pytest
    # --cov-report html to open html report
    # --cov-report html:/tmp/coverage-report to specify the directory
    # --cov ansible.module_utils.common
    pytest.main(['-s', 'ansible/module_utils/common/context.py', '--cov-report', 'html'])

    # Test case(s)
    test_case_0()

    # Unit test(s)
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:42.335597
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)



# Generated at 2022-06-24 18:38:46.597770
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    f_0 = cliargs_deferred_get
    int_0 = -2
    var_0 = f_0(int_0)
    int_1 = -4
    var_1 = f_0(int_1)
    str_0 = 'SUBSYS'
    var_2 = f_0(str_0)
    str_1 = 'SUBSYS'
    var_3 = f_0(str_1)
    str_2 = 'SUBSYS'
    var_4 = f_0(str_2)
    str_3 = 'SUBSYS'
    var_5 = f_0(str_3)
    str_4 = 'SUBSYS'
    var_6 = f_0(str_4)
    str_5 = 'SUBSYS'

# Generated at 2022-06-24 18:38:49.257303
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = -5
    str_0 = 'abc-par'
    cliargs_deferred_get(int_1)
    cliargs_deferred_get(str_0)



# Generated at 2022-06-24 18:39:12.748091
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import logging
    import tempfile
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display
    from ansible.errors import AnsibleParserError
    import ansible.constants as C
    import ansible.cli.playbook

    display = Display()
    options = ansible.cli.Sorted

# Generated at 2022-06-24 18:39:19.649017
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-24 18:39:23.893186
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert len(CLIARGS) == 0
    assert cliargs_deferred_get('test_0')() is None
    CLIARGS.update({'test_0': 0})
    assert cliargs_deferred_get('test_0')() == 0


# Test default value

# Generated at 2022-06-24 18:39:27.284151
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = -175
    var_1 = cliargs_deferred_get(int_1)
    assert var_1 == 1



# Generated at 2022-06-24 18:39:29.812318
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Setup test values
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)

    # Execute function
    result = test_case_0()

    # Verify expected result
    assert(result == var_0.__closure__[0].cell_contents)

# Generated at 2022-06-24 18:39:35.836693
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.cli_common.cliargs import AnsibleCLIArgs # pylint: disable=import-error

    mock_cli_args = AnsibleCLIArgs()    # pylint: disable=no-value-for-parameter

    with patch.object(mock_cli_args, 'get', return_value=1):
        var_1 = cliargs_deferred_get(
            'global-v0',
            default=1,
            shallowcopy=False)
        assert var_1 == 1



# Generated at 2022-06-24 18:39:44.437512
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_1 = cliargs_deferred_get(1)
    var_2 = cliargs_deferred_get(2)
    assert var_1() == CLIARGS.get(1)
    assert var_2() == CLIARGS.get(2)
    assert id(var_1()) != id(var_2())
    from ansible.utils.context_objects import GlobalCLIArgs
    CLIARGS = GlobalCLIArgs.from_options(dict(a=2))
    assert var_1() != CLIARGS.get(1)
    assert var_2() != CLIARGS.get(2)
    assert id(var_1()) != id(var_2())

# Generated at 2022-06-24 18:39:46.792414
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        assert (isinstance(var_0, types.LambdaType))
    except AssertionError as e:
        raise (e)


# Generated at 2022-06-24 18:39:52.957167
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import random
    int_0 = random.uniform(1, 1000)
    var_0 = cliargs_deferred_get(int_0)

    with _pytest.raises(AttributeError) as context:
        var_0()
    assert (var_0() is None)
    _init_global_context(int_0)
    #assert (var_0() == int_0.get(int_0))

# Generated at 2022-06-24 18:39:57.822600
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = ['-175',-175,]
    if len(args) == 2:
        int_0 = args[0]
        var_0 = args[1]
    else :
        int_0 = args[0]
    var_1 = cliargs_deferred_get(int_0)
    assert (var_0 == var_1)


# Generated at 2022-06-24 18:40:36.427616
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 58
    int_1 = -66
    str_0 = 'Z3q'
    float_0 = -74.51
    # call function 'cliargs_deferred_get'
    int_0 = cliargs_deferred_get(int_0, default=int_1, shallowcopy=str_0)


# Generated at 2022-06-24 18:40:45.871609
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    test_case_0()

#    @property
#    def become(self):
#        """Become plugin object"""
#        if not hasattr(self.__class__, '_become'):
#            setattr(self.__class__, '_become', Become(**self.become_options))
#        return self._become
#
#    @property
#    def connection(self):
#        """Connection plugin object"""
#        if not hasattr(self.__class__, '_connection'):
#            setattr(self.__class__, '_connection', Connection(**self.connection_options))
#        return self._connection
#
#    @property
#    def vars_plugins(self):
#        """List of vars

# Generated at 2022-06-24 18:40:49.989898
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass
    # Disable this test for now, it's not currently being used
    # test_case_0()

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()

# Generated at 2022-06-24 18:40:56.101057
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansiblelint.runner import Runner

    runner = Runner(None, None, [], None)


# Generated at 2022-06-24 18:41:06.256382
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common import CLIARGS
    from ansible.module_utils.common.context import cliargs_deferred_get
    from ansible.module_utils.six import PY2, PY3

    # Compare default to None
    assert cliargs_deferred_get(0)() is None

    # Set the global value
    setattr(CLIARGS, 0, 0)

    # Compare value to expected value
    assert cliargs_deferred_get(0)() == 0

    # Reset the global value
    setattr(CLIARGS, 0, None)

    # Compare default to expected value
    assert cliargs_deferred_get(0, default=0)() == 0

    # Set the global value again


# Generated at 2022-06-24 18:41:08.609107
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)
    var_0()
    pass



# Generated at 2022-06-24 18:41:10.032228
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # If we can call the function, then it probably works
    cliargs_deferred_get(42)


# Generated at 2022-06-24 18:41:13.531730
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:41:14.921109
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:41:17.784942
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert func_name_0 == "cliargs_deferred_get"
    test_case_0()

# Generated at 2022-06-24 18:42:28.308911
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)
    assert var_0() == 5, "Return value should be 5"



# Generated at 2022-06-24 18:42:30.985011
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = {
        'int_0': -175
    }
    _init_global_context(args)
    test_case_0()

# Generated at 2022-06-24 18:42:32.198552
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:42:33.655720
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

# Generated at 2022-06-24 18:42:36.201275
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Create the arguments
    int_0 = -175

    # Call the function
    cliargs_deferred_get(int_0)


# Generated at 2022-06-24 18:42:39.094368
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)


if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:42:42.130953
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)
    assert isinstance(var_0, type(lambda: None))
    assert var_0() == CLIARGS.get(-175)



# Generated at 2022-06-24 18:42:49.414248
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = -129
    var_1 = cliargs_deferred_get(int_1)
    assert var_1() == object
    int_2 = -40
    var_2 = cliargs_deferred_get(int_2)
    assert var_2() == object
    int_3 = -229
    var_3 = cliargs_deferred_get(int_3)
    assert var_3() == object
    int_4 = -14
    var_4 = cliargs_deferred_get(int_4)
    assert var_4() == object
    int_5 = -4
    var_5 = cliargs_deferred_get(int_5)
    assert var_5() == object
    int_6 = -6
    var_6 = cliargs_deferred

# Generated at 2022-06-24 18:42:50.920084
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert "Get the value of a key in CLIARGS with shallow copy functionality"



# Generated at 2022-06-24 18:42:53.985405
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(int(), default=int())
    assert var_0 is None



# Generated at 2022-06-24 18:45:36.975773
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Not much to test as we are just calling through to another object
    # but let's at least get test coverage up :)
    assert cliargs_deferred_get('is_tty')() is False

    # These cover the ``shallowcopy`` parameter
    assert cliargs_deferred_get('list_one')() == ['a']
    assert cliargs_deferred_get('list_one', shallowcopy=True)() == ['a']
    assert cliargs_deferred_get('dict_one')() == {'a': 1}
    assert cliargs_deferred_get('dict_one', shallowcopy=True)() == {'a': 1}
    assert cliargs_deferred_get('set_one')() == {1}

# Generated at 2022-06-24 18:45:39.013164
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    var_0 = cliargs_deferred_get(int_0)
    assert var_0 is None


# Generated at 2022-06-24 18:45:40.903996
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = -175
    var_1 = cliargs_deferred_get(int_1)

    assert(isinstance(var_1, function))



# Generated at 2022-06-24 18:45:42.379246
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(0)() == 0

# Generated at 2022-06-24 18:45:48.688335
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import sys
    import os
    import pytest
    import yaml
    from ansible.module_utils.common.context import cliargs_deferred_get
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    # Load JSON data into a dict
    with open("tests/test_context.json") as f:
        test_context = json.load(f)

    # Iterate over test cases
    for test_case in test_context['test_cases']:
        # Get test case values
        int_0 = test_case['int_0']
        value_0 = test_case['value_0']
        expect_0

# Generated at 2022-06-24 18:45:53.054228
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():


    print('[+] test_cliargs_deferred_get')
    test_case_0()


if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:45:58.611320
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = 15
    var_1 = { 'key_1' : int_1 }
    var_2 = CLIARGS
    var_2['key_1'] = { 'key_2' : var_1 }
    var_3 = cliargs_deferred_get(var_1)
    assert var_3 == { 'key_2' : var_1 }

# Generated at 2022-06-24 18:46:04.795620
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -175
    expected_0 = None
    with pytest.raises(TypeError) as wrapped_e:
        cliargs_deferred_get(int_0)
    assert 'too many positional arguments' in str(wrapped_e.value)
    expected_1 = None
    actual_1 = cliargs_deferred_get(key=int_0)
    assert expected_1 == actual_1
    actual_2 = cliargs_deferred_get(key=int_0, default=None)
    assert expected_1 == actual_2
    expected_3 = False
    actual_3 = cliargs_deferred_get(key=int_0, default=False)
    assert expected_3 == actual_3
    expected_4 = False
    actual_4 = cliargs_deferred