

# Generated at 2022-06-24 18:36:17.082906
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print("INSIDE TEST")
    test_case_0()


if __name__ == "__main__":
    import sys
    import os
    import pytest
    the_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, os.path.join(the_path, "..", ".."))
    print(sys.path)
    pytest.main([__file__, '-vvs', '-x', '--pdb'])

# Generated at 2022-06-24 18:36:28.188615
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(int_0)


#
# Code here is to help find where the context objects are used.  They can be deleted once
# the context objects are stabilized
#
from ansible.utils.context_objects import CliArgsContext
from ansible.utils.display import Display
from ansible.defaults import *
from ansible.inventory.host import Host
from ansible.module_utils.common.process import get_bin_path
from ansible.vars.include import IncludeVars
from ansible.inventory.group import Group
from ansible.plugins import *
from ansible.inventory.manager import InventoryManager
from ansible.playbook.role import Role
from ansible.playbook.task import Task
from ansible.vars.manager import VariableManager

# Generated at 2022-06-24 18:36:30.578735
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -2211
    input_0 = cliargs_deferred_get(int_0)
    assert input_0() is None, "Input 1: Function cliargs_deferred_get returned JSON: %s" % input_0()


test_case_0()

# Generated at 2022-06-24 18:36:31.802741
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = -2211
    var_1 = cliargs_deferred_get(int_1)
    assert var_1() == 0

# Generated at 2022-06-24 18:36:38.580119
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    # Call cliargs_deferred_get with incorrect types of arguments
    # Call cliargs_deferred_get with correct types of arguments
    try:
        test_case_0()
    except Exception:
        assert False, "unexpected error"
    # No exception should be thrown


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 18:36:42.487126
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Do not yet have the values for cliargs parsed so we can't do a full unit test.  This will have to do for
    # now.  We'll do some basic checking of the types and that the function returns a function
    # TODO: Move this to the unit tests once we have cliargs.get() mocked in the unit tests
    assert callable(cliargs_deferred_get(1))



# Generated at 2022-06-24 18:36:44.858604
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Note: We don't test anything here.  The function is a closure so it's not
    #       something you can test in isolation
    pass

# Generated at 2022-06-24 18:36:45.446182
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:36:47.924477
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('var_0', 0, True)() == 0
    assert cliargs_deferred_get('var_0', 0, False)() == 0

# Generated at 2022-06-24 18:36:54.024305
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = 5513
    int_0 = cliargs_deferred_get(int_1)
    assert isinstance(int_0, function)

    str_0 = '_1'
    str_1 = str_0
    str_2 = str_0
    str_3 = 'a1'
    str_4 = 'a1'
    str_5 = 'a1'
    str_6 = str_4
    str_4 = str_5
    str_5 = str_6
    str_6 = str_4
    value = CLIARGS.get(str_2, default=str_0)
    if not (is_sequence(value)):
        assert str_0 is None
    elif isinstance(value, (Mapping, Set)):
        assert str_3 is None

# Generated at 2022-06-24 18:36:59.013061
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -2211
    var_0 = cliargs_deferred_get(int_0)
    var_0()

if __name__ == '__main__':
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:01.214071
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    # Not sure how to test this any better since this is a closure

# Generated at 2022-06-24 18:37:02.766897
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print("IN TEST")
    assert cliargs_deferred_get("abc") is None

# Generated at 2022-06-24 18:37:05.886855
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert hasattr(cliargs_deferred_get, '__call__') and callable(cliargs_deferred_get), "must be a function"


# Generated at 2022-06-24 18:37:09.805273
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = CLIARGS
    var_1 = cliargs_deferred_get(int_1)
    vars_0 = [int_1, var_1]
    assert vars_0 == [CLIARGS, cliargs]



# Generated at 2022-06-24 18:37:12.271899
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = [
        (-2211, ) # int_0
    ]

    # Test the first argument
    assert cliargs_deferred_get(*args[0]) == 0

# Generated at 2022-06-24 18:37:22.992105
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import sys
    import types
    import pytest
    from ansible.module_utils.common.context import cliargs_deferred_get

    args = {}

    # Now you can use cliargs_deferred_get to get cliargs_deferred_get
    func = cliargs_deferred_get(args)

    # Test if cliargs_deferred_get is callable
    if not isinstance(func, types.FunctionType):
        print(("\033[1;31mtest_cliargs_deferred_get\033[0m "
              "Failure: func is not callable"))
        return 1

    # Test if func returns the correct value

# Generated at 2022-06-24 18:37:25.807368
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    info = cliargs_deferred_get(__name__, __file__)
    assert info() == __file__
    assert isinstance(info, function)
    assert info.__name__ == 'inner'



# Generated at 2022-06-24 18:37:35.793385
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo', 'bar') == 'bar'
    CLIARGS['foo'] = 'not bar'
    assert cliargs_deferred_get('foo', 'bar') == 'not bar'
    CLIARGS['foo'] = 1
    assert cliargs_deferred_get('foo', 'bar') == 1
    CLIARGS['foo'] = []
    assert cliargs_deferred_get('foo', 'bar') == []
    assert cliargs_deferred_get('foo', 'bar', shallowcopy=True) == []
    CLIARGS['foo'] = {}
    assert cliargs_deferred_get('foo', 'bar') == {}
    assert cliargs_deferred_get('foo', 'bar', shallowcopy=True) == {}

# Generated at 2022-06-24 18:37:37.919679
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(0)() == -2211
    assert cliargs_deferred_get(1)() == None

# Generated at 2022-06-24 18:37:44.683418
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(int_0)
    assert var_0 == -2211



# Generated at 2022-06-24 18:37:55.339598
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cmdline_arg_0 = ''
    cmdline_arg_1 = '.'
    cmdline_arg_2 = '..'
    cmdline_arg_3 = '../'
    cmdline_arg_4 = './'
    cmdline_arg_5 = './..'
    cmdline_arg_6 = '...'
    cmdline_arg_7 = '....'
    cmdline_arg_8 = '../..'
    cmdline_arg_9 = '../../'
    cliargs_deferred_get(cmdline_arg_0, )
    cliargs_deferred_get(cmdline_arg_1, )
    cliargs_deferred_get(cmdline_arg_2, )
    cliargs_deferred_get(cmdline_arg_3, )
    cli

# Generated at 2022-06-24 18:38:03.952555
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.utils.context_objects
    ansible_module_0 = ansible.utils.context_objects
    # call function 'cliargs_deferred_get'
    test_case_0()
    # create class 'CLIARGS'
    ansible_module_0.CLIARGS = CLIARGS

# entry point for 'python -m ansible.utils.context_objects'
if __name__ == '__main__':
    ansible.utils.context_objects.test_cliargs_deferred_get()
    print('main: end')

# Generated at 2022-06-24 18:38:09.408311
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def _anon_0():
        int_0 = 0
        var_0 = cliargs_deferred_get(int_0)
        return var_0
    str_0 = _anon_0()
    int_0 = 0
    cliargs_deferred_get(int_0)
    return var_0


# Generated at 2022-06-24 18:38:12.540070
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = -2211
    var_1 = cliargs_deferred_get(int_1)
    assert var_1() == -2211



# Generated at 2022-06-24 18:38:16.551087
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS.clear()
    # Setup
    int_0 = -2211
    var_0 = cliargs_deferred_get(int_0)
    # Procedure call
    result_0 = var_0()
    assert result_0 is None
    pass

# Generated at 2022-06-24 18:38:21.266230
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        globals()['test_' + sys.argv[1]]()
    else:
        for k, v in globals().items():
            if k.startswith('test_'):
                print(k)
                v()

# Generated at 2022-06-24 18:38:24.125652
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        int_0 = -2211
        var_0 = cliargs_deferred_get(int_0)
        assert False, "Expected NameError"
    except TypeError:
        pass


# Generated at 2022-06-24 18:38:25.490887
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import types
    assert isinstance(cliargs_deferred_get, types.FunctionType)


# Generated at 2022-06-24 18:38:33.153502
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    class TestCliargsDeferredGet(unittest.TestCase):

        def test__inner(self):
            import os
            os.getcwd()

            # DO NOT USE cliargs_deferred_get DIRECTLY
            # THIS IS ONLY FOR UNIT TESTING
            def _inner():
                value = CLIARGS.get(key, default=default)
                if not shallowcopy:
                    return value
                elif is_sequence(value):
                    return value[:]
                elif isinstance(value, (Mapping, Set)):
                    return value.copy()
                return value
            return _inner

        def test_cliargs_deferred_get(self):
            pass

    return TestCliargsDeferredGet

# Generated at 2022-06-24 18:38:47.769837
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -2211
    var_0 = cliargs_deferred_get(int_0)
    str_0 = 'cz>`~u+1&|)p-M/%hC}+'
    bytearray_0 = bytearray(str.encode(str_0))
    set_0 = set([bytearray_0])
    dict_0 = {'^': str_0, '1nW]7': 2211, 'u!7V.yY-W': set_0}
    str_1 = 'Z()``'
    dict_1 = {str_1: dict_0, '{;B': 2211, '-TS:0%P': int_0}
    list_0 = [dict_1, dict_1]
    bool_0 = False

# Generated at 2022-06-24 18:38:50.318033
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get), 'Function "cliargs_deferred_get" is not callable'
    test_case_0()

test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:51.759932
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)



# Generated at 2022-06-24 18:38:55.775853
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    try:
        cliargs_deferred_get(1)
    except TypeError:
        pass
    else:
        assert False, "unexpected exception"
    # TODO: implement your test here



# Generated at 2022-06-24 18:39:07.581627
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get_instance = cliargs_deferred_get(int_0, True)
    assert cliargs_deferred_get_instance.get('default') == True
    assert not cliargs_deferred_get_instance.get('default')
    assert cliargs_deferred_get_instance.get('shallowcopy') == False
    assert cliargs_deferred_get_instance.get('key', default=False)
    assert cliargs_deferred_get_instance.get('key')
    assert not cliargs_deferred_get_instance.get('var_0', default=True)
    assert cliargs_deferred_get_instance.get('var_0') == -2211

# Generated at 2022-06-24 18:39:14.414001
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import GlobalCLIArgs

    # Replace the LegacyCLIargs with a real one
    argv = ['ansible-playbook', '-i', 'hosts', 'play.yml']
    cli_args = GlobalCLIArgs(argv).parse()
    _init_global_context(cli_args)

    def _check_non_usercall(key, value):
        test_val = cliargs_deferred_get(key)()
        assert test_val == value
        if isinstance(test_val, (Mapping, Set)):
            assert test_val is not value

# Generated at 2022-06-24 18:39:25.149828
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 1514
    var_0 = cliargs_deferred_get(int_0)
    str_0 = 'smarty'
    str_1 = 'foo'
    var_1 = cliargs_deferred_get(str_0, str_1)
    var_2 = var_1()
    int_1 = -1053
    var_3 = cliargs_deferred_get(int_1)
    var_4 = var_3()
    var_5 = var_0()
    int_2 = -3894
    var_6 = cliargs_deferred_get(int_2)
    var_7 = var_6()
    var_8 = cliargs_deferred_get(int_1)
    var_9 = var_8()

# Generated at 2022-06-24 18:39:26.819479
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Run the above function
    test_case_0()



# Generated at 2022-06-24 18:39:30.141487
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == True



# Generated at 2022-06-24 18:39:31.941217
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        b0 = True
    except:
        b0 = False
    assert b0


# Generated at 2022-06-24 18:39:53.346870
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass # nothing to assert

if __name__ == '__main__':
    import nose2
    nose2.main()
    #test_case_0()
    #test_cliargs_deferred_get()

# Generated at 2022-06-24 18:40:02.135085
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    # From pytest_ansible.module_utils.common.context import cliargs_deferred_get
    class CliArgs:
        def __getitem__(self, key):
            return self.get(key)

        def get(self, key, default=None):
            return default

    global CLIARGS
    CLIARGS = CliArgs()

    # Ensure we're returning the default value
    assert cliargs_deferred_get('default_key')() == None

    # Set the value to a string and ensure we're returning the string value
    CLIARGS.get = lambda _, key, default=None: key
    assert cl

# Generated at 2022-06-24 18:40:08.404052
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -2211
    var_0 = cliargs_deferred_get(int_0)
    s = '{} {} {} {} {}'.format(var_0, var_0, var_0, var_0, var_0)
    assert s == '{} {} {} {} {}', "Expected '{} {} {} {} {}', but got: %s".format(s)


# Generated at 2022-06-24 18:40:10.998487
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo', 'bar') == 'bar'


# Generated at 2022-06-24 18:40:12.740321
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -2211
    var_0 = cliargs_deferred_get(int_0)


# Generated at 2022-06-24 18:40:16.558535
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_0=None
    int_0 = -2211
    value_0=cliargs_deferred_get(int_0)
    # This should be a function
    assert callable(value_0)


# Generated at 2022-06-24 18:40:23.936847
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    from ansible.module_utils.common.collections import is_sequence

    int_0 = -2211
    var_0 = cliargs_deferred_get(int_0)
    assert var_0 == None

    int_1 = -4506
    var_1 = cliargs_deferred_get(int_1, True)
    assert var_1 == True

    int_2 = -2211
    var_2 = cliargs_deferred_get(int_2)
    assert var_2 == None

    int_3 = -4506
    var_3 = cliargs_deferred_get(int_3, True)
    assert var_3 == True

# Generated at 2022-06-24 18:40:29.009640
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import cProfile
    cProfile.runctx('test_case_0()', globals(), locals(), filename='cliargs_deferred_get.profile')
    import pstats
    p = pstats.Stats('cliargs_deferred_get.profile')
    p.print_stats()


if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:40:33.364895
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import StringIO
    stream = StringIO.StringIO()
    import sys
    old_stdout = sys.stdout
    sys.stdout = stream
    import textwrap
    try:
        test_case_0()
        expected_stdout = textwrap.dedent("""
        """)[1:]
        assert expected_stdout == stream.getvalue()
    finally:
        sys.stdout = old_stdout
        stream.close()

# Generated at 2022-06-24 18:40:38.680424
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -2211
    var_0 = cliargs_deferred_get(int_0)
    try:
        assert (var_0() == None)
    except AssertionError as e:
        raise(AssertionError("Failed with {}".format(e)))



# Generated at 2022-06-24 18:41:23.547619
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -2211
    var_0 = cliargs_deferred_get(int_0)
    assert type(var_0) == type(int_0)
    assert var_0 == int_0
    print('Success: test_cliargs_deferred_get')

test_types = [int]
if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:41:32.161292
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansiblelint.rules.RuleMatch import RuleMatch
    from ansiblelint.rules import RulesCollection
    from ansiblelint.RuleLoader import RuleLoader

    # Initialize a RulesCollection and RuleLoader
    rules_collection = RulesCollection()
    rule_loader = RuleLoader(rules_collection, {}, [], [])

    # Create a list of RuleMatched objects
    matches = test_case_0()

    # Add the matches to the rules collection
    # Populate the broken_rules dictionary
    for match in matches:
        rules_collection.add(match)

    # Run the __main__ code
    result = rule_loader._run()

    # Verify the result
    assert result == 0

# Generated at 2022-06-24 18:41:34.807566
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var = cliargs_deferred_get(None)
    assert var == {}, "%s != {}" % var


# Generated at 2022-06-24 18:41:37.940337
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_1 = -2211
    # Function call: cliargs_deferred_get
    var_2 = var_1
    test_case_0()

# Generated at 2022-06-24 18:41:45.629594
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -2211
    var_0 = cliargs_deferred_get(int_0)
    assert var_0() == int_0
    CLIARGS.set(int_0, "elephant")
    assert var_0() == "elephant"
    CLIARGS.set(int_0, "tiger")
    assert var_0() == "tiger"
    int_0 = -8409
    CLIARGS.set(int_0, "giraffe")
    assert var_0() == "tiger"
    int_0 = -6917
    var_1 = cliargs_deferred_get(int_0)
    assert var_1() == CLIARGS.get(int_0)
    CLIARGS.set(int_0, "dog")
    assert var_1

# Generated at 2022-06-24 18:41:47.961314
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -2211
    var_0 = cliargs_deferred_get(int_0)


# Generated at 2022-06-24 18:41:50.129994
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    x = cliargs_deferred_get(None)
    assert x == None

# Generated at 2022-06-24 18:41:51.547405
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)



# Generated at 2022-06-24 18:41:55.882154
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(1)() == 1
    assert cliargs_deferred_get('1', 2)() == 2
    assert cliargs_deferred_get('1', 2, shallowcopy=True)() == 2


if __name__ == '__main__':
    test_case_0()
    exit()

# Generated at 2022-06-24 18:41:57.369381
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test function
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:43:19.676500
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get(int, int))



# Generated at 2022-06-24 18:43:21.851818
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''
    Unit test for function cliargs_deferred_get
    '''
    pass



# Generated at 2022-06-24 18:43:24.491779
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -2211
    var_0 = cliargs_deferred_get(int_0)
    assert var_0() is None

    int_1 = -1921
    var_1 = cliargs_deferred_get(int_1, default=1)
    assert var_1() == 1

# Generated at 2022-06-24 18:43:33.854444
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import tempfile

    fd, fpath = tempfile.mkstemp(prefix='ansible_test_context_')
    fobj = os.fdopen(fd, 'w')

    old_stdout = sys.stdout
    sys.stdout = fobj

    print(">>> cliargs_deferred_get(int_0)")
    print(cliargs_deferred_get(int_0))
    print(">>> var_0()")
    print(var_0())

    fobj.close()
    sys.stdout = old_stdout

    with open(fpath, 'r') as f:
        output = f.readlines()

    assert output[0] == ">>> cliargs_deferred_get(int_0)\n"

# Generated at 2022-06-24 18:43:36.590006
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = -2211
    var_0 = cliargs_deferred_get(int_0,shallowcopy=True)


if __name__ == "__main__":
    import sys
    import doctest
    failed, attempted = doctest.testmod()
    sys.exit(failed)

# Generated at 2022-06-24 18:43:38.417091
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert(callable(cliargs_deferred_get))


# Generated at 2022-06-24 18:43:42.252448
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

# Generated at 2022-06-24 18:43:48.905149
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import OrderedDict

    fake_cli_args = OrderedDict([('a', ['1', '1', '1', '1']), ('b', ['2', '2', '2', '2']), ('c', 3)])

    CLIARGS = CLIArgs(fake_cli_args)

    test_dict = {'int': -2211, 'str': 'string', 'list': [1, 2, 3, 4], 'mapping': {'a': 1, 'b': 2, 'c': 3, 'list': [1, 2, 3, 4]}}

    assert var_0() == ['1', '1', '1', '1']
    assert var_1() == ['2', '2', '2', '2']
    assert var_2()

# Generated at 2022-06-24 18:43:50.187511
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS = {-2211: None}
    assert not cliargs_deferred_get(-2211)()

# Generated at 2022-06-24 18:43:51.712620
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = -2211
    result = cliargs_deferred_get(var_0)
    assert result == ''

