

# Generated at 2022-06-24 18:36:09.627791
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_6 = cliargs_deferred_get('a', default='b')
    var_7 = cliargs_deferred_get('c', default=None, shallowcopy=True)
    var_8 = cliargs_deferred_get('d', shallowcopy=True)

# Generated at 2022-06-24 18:36:12.751275
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cmd_0 = "When loading an external command file"
    nova_0 = None
    cliargs_deferred_get(cmd_0, default=nova_0)

test_case_0()
test_cliargs_deferred_get()

# Generated at 2022-06-24 18:36:16.103999
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)
    assert var_0 is not None
    assert var_0 == None


# Generated at 2022-06-24 18:36:18.347539
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)
    assert var_0() == "hey"

# Generated at 2022-06-24 18:36:22.945112
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    # TODO: Implement your test here
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)
    raise Exception("Cannot test an abstract function")



# Generated at 2022-06-24 18:36:29.091113
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "zRZ1w_7VuF"
    var_0 = cliargs_deferred_get(str_0)


if __name__ == '__main__':
    import sys
    import pytest

    if len(sys.argv) > 1:
        pytest.main(sys.argv)
    else:
        test_case_0()
        test_cliargs_deferred_get()

# Generated at 2022-06-24 18:36:30.685952
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert CLIARGS.get(str_0) is var_0()

# Generated at 2022-06-24 18:36:34.005170
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)
    assert var_0(), False

test_cliargs_deferred_get()

# Generated at 2022-06-24 18:36:37.498983
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_1 = "dKzo]K_(j'"
    # Uncomment the following line to initialize values for test_case_0
    # test_case_0()
    var_1 = None


# Generated at 2022-06-24 18:36:40.226731
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)
    assert var_0 is not None


# Generated at 2022-06-24 18:36:44.224642
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(test_case_0)

test_case_0()

# Generated at 2022-06-24 18:36:50.013488
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    input_0 = "z"
    print(cliargs_deferred_get(input_0))


# Generated at 2022-06-24 18:36:59.035525
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with three different values for CLIARGS:
    # 1.  CLIARGS is empty
    # 2.  CLIARGS has a single key in it
    # 3.  CLIARGS is not empty and does not contain the key
    # Test with three different values for key:
    # 1.  Key is not present
    # 2.  Key is present
    # 3.  Key is present with default=None
    # Test with three different values for default:
    # 1.  default is not present
    # 2.  default is present
    # 3.  default is present with None as the value
    # Test with three different values for shallowcopy:
    # 1.  shallowcopy is False
    # 2.  shallowcopy is True
    # 3.  shallowcopy is True and key is present with a list as the value
    global CLI

# Generated at 2022-06-24 18:36:59.905690
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass



# Generated at 2022-06-24 18:37:02.411512
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert func(str_0) == "dKzo]K_(j'"

# vim: set expandtab:ts=4:sw=4

# Generated at 2022-06-24 18:37:12.272666
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Run function cliargs_deferred_get with arguments ('v1',) and kwargs

    test_case_0()


if __name__ == '__main__':
    # Use setuptools so that the tests will be run automatically
    import setuptools
    setuptools.setup(
        name='global_context_module_utils',
        description='Functional unit test for global_context_module_utils.py',
        version='0.0.1',
        author='tkuratomi',
        url='http://github.com/ansible/ansible',
        packages=setuptools.find_packages(),
        setup_requires=['pytest-runner'],
        tests_require=['pytest'],
    )

# Generated at 2022-06-24 18:37:21.817676
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    func_name = 'CLIARGS'
    func_loc = 'ansible.module_utils.common.context'

    test_cases = [
        {
            "test_case_name": "TestCase #0",
            "func_name": func_name,
            "func_loc": func_loc,
            "cliargs_deferred_get": test_case_0
        }
    ]
    for test_case in test_cases:
        test_case["cliargs_deferred_get"]()

test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:32.038939
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_1 = ":0et0YG"
    str_2 = "vV8fTCG6U"
    str_3 = "vV8fTCG6U"
    str_4 = "dKzo]K_(j'"
    str_5 = "[|H`>W`"
    str_6 = "[|H`>W`"
    var_1 = {str_1: str_2, str_3: str_4, str_5: str_6}
    str_7 = "dKzo]K_(j'"
    str_8 = "[|H`>W`"
    str_9 = "[|H`>W`"
    str_10 = ":0et0YG"
    str_11 = "vV8fTCG6U"

# Generated at 2022-06-24 18:37:34.328745
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {}
    _init_global_context(cli_args)
    test_case_0()
    print(CLIARGS)

# Generated at 2022-06-24 18:37:36.866294
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "gEZ0^A_}HNr"
    var_0 = cliargs_deferred_get(str_0)


# Generated at 2022-06-24 18:37:40.574701
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

# Generated at 2022-06-24 18:37:40.997188
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True


# Generated at 2022-06-24 18:37:42.732602
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)


# Generated at 2022-06-24 18:37:44.145749
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    output = cliargs_deferred_get("test")
    assert output == None

# Generated at 2022-06-24 18:37:49.317409
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        str_0 = "dKzo]K_(j'"
        var_0 = cliargs_deferred_get(str_0)
    except Exception as exception_0:
        print(exception_0)

# Generated at 2022-06-24 18:37:58.329009
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    value = cliargs_deferred_get('foo', default=2)
    assert value() == 2

    # now let's set the global context
    CLIARGS = CLIArgs({'foo': 1})

    value = cliargs_deferred_get('foo', default=2)
    assert value() == 1

    # now test the shallow copy option
    value = cliargs_deferred_get('foo', default=[])
    assert value() == [1]  # still a shallow copy

    value = cliargs_deferred_get('foo', default=[], shallowcopy=True)
    assert value() == [1]



# Generated at 2022-06-24 18:38:01.567982
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    str_0 = "S*O'kG=zOQ"
    var_0 = cliargs_deferred_get(str_0)
    # Verify
    assert callable(var_0)
    assert var_0() == None

# Generated at 2022-06-24 18:38:07.456358
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "o;7^:8=vw"
    function_1 = cliargs_deferred_get(str_0)
    str_1 = "FOn6)M%Z?"
    var_1 = function_1()
    assert var_1 == str_1, 'AssertionError: assert {} == {}'.format(repr(var_1), repr(str_1))


# Generated at 2022-06-24 18:38:09.625641
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0();
    except (Exception) as ex:
        print(str(ex));

# Generated at 2022-06-24 18:38:10.209843
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert False

# Generated at 2022-06-24 18:38:20.513125
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_1 = "dKzo]K_(j'"
    var_1 = cliargs_deferred_get(str_1)
    assert not var_1


# Generated at 2022-06-24 18:38:22.106009
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "apg^y*B{i"
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:38:25.330064
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        # Test the enumerable version too
        for x in [0,1]:
            # Test positive case
            test_pass = True
            # Test negative case
            test_fail = False
    except TypeError as exception:
        print(exception)
        pass


# Generated at 2022-06-24 18:38:27.180857
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "Qo]9X]{1]"
    var_0 = cliargs_deferred_get(str_0)
    assert var_0() is None


# Generated at 2022-06-24 18:38:34.866291
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Get an example value from a key
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)
    # Get an example value from a key using the default value
    str_1 = "~m-0dgZ=U"
    var_1 = cliargs_deferred_get(str_1, str_1)
    # Get an example value from a key using a shallow copy
    str_2 = "w?y^3qI'M"
    var_2 = cliargs_deferred_get(str_2, True)
    # Get an example value from a key using the default value with a shallow copy
    str_3 = "A;[tNkl~V"

# Generated at 2022-06-24 18:38:35.862805
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()



# Generated at 2022-06-24 18:38:39.341224
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = {
        'ansible': {
            'ansible_play_hosts': 'val_0',
        },
        'ansible_play_hosts': 'unused',
    }
    _init_global_context(var_0)
    test_case_0()

# Generated at 2022-06-24 18:38:39.873973
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:38:41.953754
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)

    assert var_0 is None, "Unexpected result when calling function"

# Generated at 2022-06-24 18:38:45.187751
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)
    var_1 = cliargs_deferred_get(str_0, shallowcopy=True)
    assert var_0() == var_1()

    int_0 = -9820
    cliargs_deferred_get(int_0)



# Generated at 2022-06-24 18:39:00.382514
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '("I[Y\'Y_'
    str_1 = ']yFb4yqX'
    res = cliargs_deferred_get(str_0, str_1)
    assert res == None

    str_0 = 'x8M,+L=f'
    str_1 = 'dD5P&\'ON'
    str_2 = 'dKzo]K_(j\''
    res = cliargs_deferred_get(str_0, str_1, str_2)
    assert res == None


if __name__ == "__main__":
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:39:04.615625
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    result = cliargs_deferred_get("dKzo]K_(j'")
    assert result == []


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 18:39:07.253359
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup test
    str_0 = "dKzo]K_(j'"

    # Exercise SUT
    var_0 = cliargs_deferred_get(str_0)

    # Verify results
    assert var_0 == CLIARGS.get(str_0, default=None)

# Generated at 2022-06-24 18:39:13.259845
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test variables
    func_ret_0 = None
    CLIARGS_0 = None
    def func_0(arg_1, arg_2=None):
        return arg_2 if arg_2 else None
    arg_1 = func_0
    str_0 = "dKzo]K_(j'"

    CLIARGS_0 = GlobalCLIArgs()
    func_ret_0 = cliargs_deferred_get(str_0)

    # Assertions
    assert(func_ret_0() == CLIARGS_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 18:39:18.064733
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "dKzo]K_(j'"
    assert not cliargs_deferred_get(str_0)
    str_1 = "uv^"
    object_0 = cliargs_deferred_get(str_1, default=str_0)
    assert object_0 is not None


# Generated at 2022-06-24 18:39:19.089229
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # call function
    test_case_0()

# Generated at 2022-06-24 18:39:29.459169
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "dKzo]K_(j'"
    # TypeError check
    with pytest.raises(TypeError):
        cliargs_deferred_get(str_0, 'z0ZTlT^Xs', shallowcopy='4o{IuhyF1a')
    # TypeError check
    with pytest.raises(TypeError):
        cliargs_deferred_get(str_0, shallowcopy=True, default='l}\pFg\~l5')
    with pytest.raises(TypeError):
        cliargs_deferred_get(str_0, True, 'X|fD/n>RU')
    with pytest.raises(TypeError):
        cliargs_deferred_get(str_0, True, True)
    # TypeError check


# Generated at 2022-06-24 18:39:30.245170
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

test_cliargs_deferred_get()

# Generated at 2022-06-24 18:39:36.928140
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-24 18:39:42.642517
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = '5\x0c\x01\x0b\x11\n\x19\x03'
    # Function cliargs_deferred_get sends its first argument (key) to the
    # function get, which returns a value.
    var_0 = cliargs_deferred_get(str_0)
    assert var_0 is not None, "Argument: var_0 is missing."



# Generated at 2022-06-24 18:40:11.960956
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "set_fact"
    var_0 = cliargs_deferred_get(str_0)

    str_1 = "listen"
    var_1 = cliargs_deferred_get(str_1)

    str_2 = "set_fact"
    var_2 = cliargs_deferred_get(str_2)

    str_3 = "listen"
    var_3 = cliargs_deferred_get(str_3)

if __name__ == "__main__":
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:40:14.430214
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
    except Exception as e:
        print('Exception: {}'.format(e))
        assert False

    print('passed')

# Unit test fot class CLIArgs

# Generated at 2022-06-24 18:40:18.082741
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(lambda: None, default=None, shallowcopy=False)
    assert var_0 is None, "var_0 is not None"



# Generated at 2022-06-24 18:40:21.452627
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)
    print(var_0)

# main function
if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:40:32.721873
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    input_vars = {}
    expected_result = None
    pass_through = input_vars.copy()
    result = cliargs_deferred_get(pass_through)
    assert result == expected_result

    input_vars = {}
    expected_result = None
    pass_through = input_vars.copy()
    result = cliargs_deferred_get(pass_through)
    assert result == expected_result

    input_vars = {}
    expected_result = None
    pass_through = input_vars.copy()
    result = cliargs_deferred_get(pass_through)
    assert result == expected_result

    input_vars = {}
    expected_result = None
    pass_through = input_vars.copy()

# Generated at 2022-06-24 18:40:34.233606
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == True


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(["-s", __file__]))

# Generated at 2022-06-24 18:40:37.142889
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "['ZfJTeC'Vu"
    var_0 = cliargs_deferred_get(str_0)

# Generated at 2022-06-24 18:40:38.282259
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass



# Generated at 2022-06-24 18:40:41.658652
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Set up mock objects
    class MockCLIArgs(object):
        def get(self, key, default=None):
            return None
    cliargs_mock = MockCLIArgs()

    # Set up mock objects
    var_0 = cliargs_deferred_get(cliargs_mock)
    var_1 = cliargs_deferred_get(cliargs_mock, False)
    
    assert var_0() == None
    assert var_1() == None


test_case_0()

# Generated at 2022-06-24 18:40:47.146849
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "2M6C1(a0W"
    var_0 = cliargs_deferred_get(str_0)


# Generated at 2022-06-24 18:41:36.331586
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)


if __name__ == "__main__":
    pass

# Generated at 2022-06-24 18:41:45.055206
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    ansible_connection = CLIARGS.get("ansible_connection", "")
    assert ansible_connection == "local"

    # useless test
    var_0 = cliargs_deferred_get("lalala", False)
    assert var_0 is False

    # an "ansible" argument is expected to be a string
    ansible_python_interpreter = CLIARGS.get("ansible_python_interpreter")
    assert isinstance(ansible_python_interpreter, str)

    # this is a really strange "ansible" argument
    ansible_module_json = CLIARGS.get("ansible_module_json")
    assert isinstance(ansible_module_json, str)

    # this is a really strange "ansible" argument
    ansible_python_interpreter = CLIARGS

# Generated at 2022-06-24 18:41:47.581034
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)



# Generated at 2022-06-24 18:41:48.128104
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:41:52.925275
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # call function
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)

if __name__ == "__main__":
    # Unit tests for cliargs_deferred_get
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:41:56.385713
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_1 = "lopHDrA@0+g[3]"
    str_1 = "Zanjz7\}g1_u*7"
    print("{}{}".format(var_1, str_1))

test_case_0()
test_cliargs_deferred_get()

# Generated at 2022-06-24 18:41:58.215613
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get("The quick brown fox jumps over the lazy dog") is not None


# Generated at 2022-06-24 18:42:03.116300
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_1 = "B'(#"
    str_2 = "$J+'z"
    str_3 = 'M1'
    var_1 = CLIARGS.get(str_1, default=None)
    var_2 = CLIARGS.get(str_2, default=var_1)
    assert var_2 == var_1
    var_3 = cliargs_deferred_get(str_3, default=var_1)
    assert var_3 == var_1


# Generated at 2022-06-24 18:42:12.737911
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "dKzo]K_(j'"
    # if True, then we test normalization of the global context.
    # else, then we test lazy initialization of the global context
    var_0 = True
    if var_0:
        cli_args = {'default_module_name': '', 'role_names': [], 'free_form': ['TEST', 'TEST2']}
        # This should be called immediately after cli_args are processed (parsed, validated, and any
        # normalization performed on them).  No other code should call it
        _init_global_context(cli_args)
        var_1 = cliargs_deferred_get(str_0, True)
        # assert that the value returned is a list
        assert is_sequence(var_1)
        # assert that the

# Generated at 2022-06-24 18:42:16.044788
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test for using string arguments
    arg_0 = "U@F6UZ'0Ia"
    arg_1 = "?_o0X[%M:K"
    arg_2 = "J'O?\\`-f`"
    result_0 = cliargs_deferred_get(arg_0, arg_1, arg_2)
    assert result_0 == ''


# Generated at 2022-06-24 18:43:56.861930
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    test_case_0()

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:43:58.744195
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    with pytest.raises(Exception):
        cliargs_deferred_get()



# Generated at 2022-06-24 18:43:59.279369
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get()

# Generated at 2022-06-24 18:44:06.496816
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Set up mock
    _init_global_context(mock.MagicMock())

    mock_key = mock.Mock()
    mock_default = mock.Mock()
    mock_shallowcopy = mock.Mock()

    # Invoke method
    result = cliargs_deferred_get(mock_key, mock_default, mock_shallowcopy)

    # Check return type
    assert isinstance(result, types.FunctionType)

    # Check return value
    assert result() == CLIARGS.get(mock_key, mock_default)

    # Check side_effect
    assert CLIARGS.get.call_count == 1

# Generated at 2022-06-24 18:44:11.015617
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup test case
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)

    assert var_0 == 1



# Generated at 2022-06-24 18:44:19.833150
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        assert callable(cliargs_deferred_get)
        # Call function cliargs_deferred_get
        test_case_0()
    except (AssertionError, TypeError) as e:
        print('Unit test failed:', e)
        raise


if __name__ == '__main__':  # pragma: no cover
    cliargs_deferred_get()

# Generated at 2022-06-24 18:44:22.168212
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = "dKzo]K_(j'"
    var_0 = cliargs_deferred_get(str_0)
    print(var_0())


# Generated at 2022-06-24 18:44:25.818767
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert False

# Generated at 2022-06-24 18:44:28.479011
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_1 = "tddQ!*1@w4"
    var_1 = cliargs_deferred_get(str_1)
    var_1()

# Generated at 2022-06-24 18:44:32.854255
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    value_0 = 'q'
    value_1 = cliargs_deferred_get(value_0)
    assert value_1 is True

cliargs_deferred_get('a', True)
cliargs_deferred_get('b', True)
