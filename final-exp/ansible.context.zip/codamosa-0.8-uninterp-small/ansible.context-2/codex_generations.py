

# Generated at 2022-06-24 18:36:15.098522
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert False
# -*- -*- -*- End included fragment: lib/ansible/utils/context_objects.py -*- -*- -*-

# -*- -*- -*- Begin included fragment: lib/ansible/inventory/host.py -*- -*- -*-

# Copyright: (c) 2018, Toshio Kuratomi <tkuratomi@ansible.com>
# Copyright: (c) 2018, Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

import os

from ansible.module_utils._text import to_native

# Generated at 2022-06-24 18:36:17.263346
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.errors
    with pytest.raises(ansible.errors.AnsibleError):
        test_case_0()

# Generated at 2022-06-24 18:36:25.419508
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import UserDict

    int_0 = "foo"
    var_0 = cliargs_deferred_get(int_0)
    assert var_0() is None

    # Since we've misconfigured the global var_0 we're going to be expecting a copy
    int_0 = "vars"
    var_0 = cliargs_deferred_get(int_0, shallowcopy=True)
    # vars should return a dictionary
    assert isinstance(var_0(), UserDict)
    # and has no entries
    assert len(var_0()) is 0


if __name__ == '__main__':
    # Test code
    # Run test on all functions/classes in this file
    import doctest

    doctest.run_docstring_

# Generated at 2022-06-24 18:36:30.921366
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()


# Note: this is not the singleton version.  The Singleton is only created once the program has
# actually parsed the args
CLIARGS = CLIArgs({})


# This should be called immediately after cli_args are processed (parsed, validated, and any
# normalization performed on them).  No other code should call it

# Generated at 2022-06-24 18:36:41.287733
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.cli.arguments import option_helpers

    from ansible.utils.context_objects import CLIArgs

    class TestCase0(unittest.TestCase):
        """Tests for AnsibleCliArgs"""

        def setUp(self):
            self.mock_cli_args = option_helpers.create_parser()
            self.mock_cli_args.config = "/path/to/config"
            self.mock_cli_args.connection = "local"

# Generated at 2022-06-24 18:36:43.041729
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(int_0) == None

# Generated at 2022-06-24 18:36:47.160264
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = [
        '_init_global_context',
        'test_case_0'
    ]
    if args[0] in globals():
        globals()[args[0]](1,2)
        for test in args[1:]:
            globals()[test]()
        return 0
    return 1


if __name__ == '__main__':
    import sys
    sys.exit(test_cliargs_deferred_get())

# Generated at 2022-06-24 18:36:52.838983
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import sys
    import test.context
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    args = dict(ANSIBLE_MODULE_ARGS=dict(one=1, two=2), ANSIBLE_MODULE_CONSTANTS=dict(UNDEFINED=1))
    args[b'ANSIBLE_MODULE_ARGS'] = dict((to_bytes(k, errors='surrogate_or_strict'), to_bytes(v, errors='surrogate_or_strict')) for k, v in args[b'ANSIBLE_MODULE_ARGS'].items())

# Generated at 2022-06-24 18:37:00.266029
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-24 18:37:02.814841
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:09.077035
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Need to implement:
    # This is part of the Ansible test infrastructure
    # assert cliargs_deferred_get() == ? # TODO: implement your test here
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)

# Generated at 2022-06-24 18:37:11.317915
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:11.916692
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:37:14.213716
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        int_0 = None
        var_0 = cliargs_deferred_get(int_0)
    except Exception:
        assert False, 'Uncaught exception'

# Generated at 2022-06-24 18:37:19.619783
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # test_cases = [
    #     {
    #         "key": None,
    #         "default": None,
    #         "shallowcopy": None,
    #         "expected_result": None
    #     }
    # ]
    # for test_case in test_cases:
    #     var_0 = cliargs_deferred_get(**test_case)
    #     assert test_case["expected_result"] == var_0
    return True



# Generated at 2022-06-24 18:37:26.746628
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch
    from ansible.utils.context_objects import CLIArgs

    with patch.object(CLIArgs, 'get', return_value=dict()) as mock_get:
        var_0 = cliargs_deferred_get(int_0)
        mock_get.assert_called_with(int_0, None)
    assert var_0 == dict()

# Generated at 2022-06-24 18:37:28.741462
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    pass

# Generated at 2022-06-24 18:37:30.475053
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)


# Generated at 2022-06-24 18:37:31.049222
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert 1 == 1

# Generated at 2022-06-24 18:37:38.494795
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock
    from ansible_collections.ansible.community.plugins.module_utils.common.context_objects import GlobalCLIArgs
    m_cliargs = MagicMock(spec=GlobalCLIArgs)
    m_cliargs.get.return_value = 'test_var'

    with patch('ansible_collections.ansible.community.plugins.module_utils.common.context_objects.CLIARGS', m_cliargs):
        test_case_0()

# Generated at 2022-06-24 18:37:50.387747
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    my_cli_args = {}
    _init_global_context(my_cli_args)
    int_0 = 0
    assert (cliargs_deferred_get(int_0)() == None)
    int_1 = 1
    my_cli_args[int_1] = 1
    assert (cliargs_deferred_get(int_1)() == 1)
    str_0 = 'str_0'
    my_cli_args[str_0] = "str_0_val"
    assert (cliargs_deferred_get(str_0)() == "str_0_val")
    str_1 = 'str_1'
    my_cli_args[str_1] = "str_1_val"

# Generated at 2022-06-24 18:37:51.097181
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:38:01.035019
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(1,2) == 2


# Generated by 'ansible-doc' on Mon, 26 Aug 2019 16:07:04 -0500

# Generated at 2022-06-24 18:38:06.249205
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.dict_transformations import to_bytes
    from ansible.module_utils.common.text.converters import to_text, to_native
    import sys


    def equal(first, second):
        equal = False
        if isinstance(first, dict) and isinstance(second, dict):
            equal = len(first) == len(second) and all(first.get(x, None) == second.get(x, None) for x in first.keys())
        elif isinstance(first, (list, set)) and isinstance(second, (list, set)):
            equal = len(first) == len(second) and all(x in second for x in first)
        else:
            equal = first == second

# Generated at 2022-06-24 18:38:06.960305
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:38:12.867375
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {'ansible_connection': 'local', 'connection': 'local', 'builtin_facts': None, 'roles_path': ['roles']}
    _init_global_context(dict_0)
    assert (not (callable(cliargs_deferred_get('vault_identity_list', default='', shallowcopy=False))))
    assert (cliargs_deferred_get('vault_identity_list', default='', shallowcopy=False) == '')
    assert (not (callable(cliargs_deferred_get('vault_identity_list', default='', shallowcopy=True))))
    assert (cliargs_deferred_get('vault_identity_list', default='', shallowcopy=True) == '')

# Generated at 2022-06-24 18:38:18.045626
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.utils.context_objects as context_objects
    from ansible.utils.context_objects import CLIARGS
    from ansible.utils.context_objects import cliargs_deferred_get
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    var_0()
    import pdb; pdb.set_trace()
    if True:
        pass


# Generated at 2022-06-24 18:38:30.305735
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'deprecated2': 3, 'deprecated': '7', 'skip_tags': [],
                'sudo': None, 'module_path': None, 'forks': 5, 'become': None,
                'list_hosts': None, 'list_tasks': None,
                'vault_password_files': [], 'module_set': set(),
                'diff': False, 'skip_check': False}
    _init_global_context(cli_args)

    for i in cli_args.keys():
        if i == 'module_set':
            continue
        x = cliargs_deferred_get(i, 0)()
        y = cli_args[i]
        print(x)
        print(y)
        assert x == y
    z = cliargs_def

# Generated at 2022-06-24 18:38:38.682954
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def get_default():
        return None
    int_0 = cliargs_deferred_get(0, default=get_default)
    int_m0 = cliargs_deferred_get(-1, default=get_default)
    int_m10 = cliargs_deferred_get(-10, default=get_default)
    str_abc = cliargs_deferred_get('abc', default=get_default)
    str_hello = cliargs_deferred_get('hello', default=get_default)
    var_0 = cliargs_deferred_get(int_0)
    var_m0 = cliargs_deferred_get(int_m0)
    var_m10 = cliargs_deferred_get(int_m10)
    var_abc = cliargs_def

# Generated at 2022-06-24 18:38:41.631666
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get("a", "b")("a") == "b"
    assert cliargs_deferred_get("a", "b", shallowcopy=True)("a") == "b"

# Generated at 2022-06-24 18:38:59.477728
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make sure that the closure over CLIARGS is setting the default now
    # even if CLIARGS was initialized to an empty dictionary
    cli_args = {'_ansibullbot': {'version': '0.0.0', 'mode': 'dev'}}
    _init_global_context(cli_args)

    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    assert var_0() is None
    int_1 = '_ansibullbot.version'
    var_1 = cliargs_deferred_get(int_1)
    assert var_1() == '0.0.0'
    int_2 = '_ansibullbot.mode'
    var_2 = cliargs_deferred_get(int_2)
    assert var_

# Generated at 2022-06-24 18:39:02.329325
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'test_key': 'test_value'}
    global CLIARGS
    CLIARGS = CLIArgs(cli_args)
    assert cliargs_deferred_get('test_key')() == 'test_value'



# Generated at 2022-06-24 18:39:09.422200
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import sys
    import ansible.module_utils.common.base_objects

    # This function uses the following globals:
    # - CLIARGS
    # - AnsibleModule
    # Setup initial state
    ansible.module_utils.common.base_objects.CLIARGS.data = {}
    ansible.module_utils.common.base_objects.AnsibleModule = None
    # Run the function with different inputs
    test_case_0()

# Generated at 2022-06-24 18:39:10.801046
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)



# Generated at 2022-06-24 18:39:11.827404
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()



# Generated at 2022-06-24 18:39:15.719271
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function `cliargs_deferred_get`"""

    # Get function parameters to test
    key = 'key'
    default = 'default'

    # Invoke the actual call we are testing
    returned_1 = cliargs_deferred_get(key, default)

    # Check if the returned value is as expected
    assert returned_1 == 'default'


# Generated at 2022-06-24 18:39:18.362325
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)


# Generated at 2022-06-24 18:39:28.647002
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    mock_cli_args = {
        'some_key': 'some_value',
        'some_other_key': [],
    }
    CLIARGS = GlobalCLIArgs.from_options(mock_cli_args)
    assert cliargs_deferred_get('some_key')() == 'some_value'
    assert cliargs_deferred_get('some_key', shallowcopy=True)() == 'some_value'
    assert cliargs_deferred_get('some_other_key')() == []
    assert cliargs_deferred_get('some_other_key', shallowcopy=True)() == []
    assert cliargs_deferred_get('some_key', default='other')() == 'some_value'
   

# Generated at 2022-06-24 18:39:36.557085
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'connection': 'local', 'module_path': ['/home/ansible/mymodules/'], 'forks': 10, 'remote_user': 'ansible', 'remote_port': '22', 'private_key_file': '/home/ansible/.ssh/id_rsa', 'module_name': 'ping', 'module_args': {'data': 'hello world', '_ansible_selinux_special_fs': ['fuse', 'nfs', 'vboxsf', 'ramfs', '9p', 'vfat']}, 'timeout': 10, 'become': None, 'become_method': None, 'become_user': None, 'become_ask_pass': None, 'check': False, 'diff': False}
    _init_global_context(cli_args)


# Generated at 2022-06-24 18:39:38.522807
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    test_case_0()



# Generated at 2022-06-24 18:39:57.619776
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert(cliargs_deferred_get(1) == CLIARGS)
    assert(cliargs_deferred_get(0, default="test") == "test")

# Generated at 2022-06-24 18:39:59.165756
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    # TODO: add tests

# Generated at 2022-06-24 18:40:06.303349
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    # Nothing I've found so far removes this deprecation warning and it's a bit of a pain
    # so just suppress it.
    import warnings
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', message='Unbuilt token for "\{\{[\s\S]+?\}\}"')
        warnings.filterwarnings('ignore', message='Forcing collection reload due to a file change')

# Generated at 2022-06-24 18:40:10.720870
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get("key_0")
    assert cliargs_deferred_get("key_1", default="default_value_0")
    assert cliargs_deferred_get("key_2", shallowcopy=True) == "default_value_0"

# Generated at 2022-06-24 18:40:14.109970
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    assert CLIARGS._options == {}
    CLIARGS._options = {'hello': 'world'}
    result = cliargs_deferred_get('hello')
    assert result() == 'world'
    assert cliargs_deferred_get('null')() is None
    CLIARGS._options = {}

# Generated at 2022-06-24 18:40:23.796719
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    # FIXME: https://github.com/ansible/ansible/issues/65338  get rid of this patch when we figure out how to make
    # ``_init_global_context()`` work in our tests
    patch_init_context = patch('ansible_collections.ansible.community.plugins.module_utils.ansible_free_form.CLIARGS.__init_global_context')

    # FIXME: https://github.com/ansible/ansible/issues/65339  Get rid of this patch when we figure out how to get
    # the ``CLIArgs`` object to use in our tests

# Generated at 2022-06-24 18:40:29.283451
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    v1 = {'a': 'b', 'c': 'd'}
    v2 = {'a': 'e', 'c': 'f'}

    CLIARGS.update(v1)
    assert cliargs_deferred_get('a')() == 'b'

    CLIARGS = Manager(v2)
    assert cliargs_deferred_get('a')() == 'e'
    assert cliargs_deferred_get('c')() == 'f'

# Generated at 2022-06-24 18:40:39.613565
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import unittest.mock

    # Setup mock for function get
    with unittest.mock.patch('ansible.context._cliargs_deferred_get.CLIARGS.get', side_effect=lambda: None) as mock_get:

        # Call tested function
        cliargs_deferred_get(int_0=None)
        # noinspection PyUnresolvedReferences
        assert mock_get.call_args_list == [unittest.mock.call(None, default=None)]

if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-24 18:40:47.919566
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    source = 'https://github.com/ansible/ansible/blob/devel/lib/ansible/utils/context_objects.py'
    testcase0 = {
        'expected_result': None,
        'call_args': dict(
            key='a_key',
            default=None,
            shallowcopy=False,
        ),
    }
    testcases = [testcase0]
    for idx, testcase in enumerate(testcases):
        expected_result = testcase.get('expected_result')
        call_args = testcase.get('call_args', {})
        result = cliargs_deferred_get(**call_args)
        print('# TestCase #{idx}'.format(idx=idx))
        print('result: {}'.format(result))

# Generated at 2022-06-24 18:40:54.726089
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    try:
        var_1 = var_0()
    except Exception:
        var_1 = None
    assert var_1 == None
# -- END -- #
# -- END -- #


# -- END -- #
# -- END -- #
# -- END -- #


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(['-vv', '--capture=sys', 'test_context.py']))

# Generated at 2022-06-24 18:41:31.409588
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = dict(
        int_0 = None,
        var_0 = cliargs_deferred_get(int_0),
    )
    assert args['var_0']() == args['var_0']()

# Generated at 2022-06-24 18:41:38.403859
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _ansible_global_context = _init_global_context
    _ansible_global_context(None)
    assert cliargs_deferred_get(int_0) is None
    _ansible_global_context(int_0)
    assert cliargs_deferred_get(int_0) is None


if __name__ == '__main__':
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:41:43.577560
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    var_1 = cliargs_deferred_get(int_0, default=0)
    var_2 = cliargs_deferred_get(int_0, default=0, shallowcopy=True)


if __name__ == '__main__':
    import sys
    sys.exit(test_case_0())

# Generated at 2022-06-24 18:41:45.058202
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    int_0 = CLIARGS.get(int_0, default=None)
    var_0 = cliargs_deferred_get(int_0)

# Generated at 2022-06-24 18:41:46.238407
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    var_0()

# Generated at 2022-06-24 18:41:47.760346
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    test_case_0()



# Generated at 2022-06-24 18:41:56.896739
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    key = None
    default = 'True'
    shallowcopy = 'True'
    p = cliargs_deferred_get(key, default, shallowcopy)
    assert p() == 'True'

    key = None
    default = 'True'
    shallowcopy = 'False'
    p = cliargs_deferred_get(key, default, shallowcopy)
    assert p() == 'True'

    key = 'debug'
    default = 'True'
    shallowcopy = 'True'
    p = cliargs_deferred_get(key, default, shallowcopy)
    assert p() == 'True'

    key = 'debug'
    default = 'True'
    shallowcopy = 'False'
    p = cliargs_deferred_get(key, default, shallowcopy)
    assert p() == 'True'

# Generated at 2022-06-24 18:42:01.058233
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None

    var_0 = cliargs_deferred_get(int_0)
    assert var_0() is None

    int_0 = 'ansible_log_callback'

    var_0 = cliargs_deferred_get(int_0)
    assert var_0() is None

# Generated at 2022-06-24 18:42:07.470147
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    assert cliargs_deferred_get
    # We have enough here to assert that there are no errors

# Generated at 2022-06-24 18:42:13.433903
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Create mock values to use throughout the test.
    # Mock type: <class 'function'>
    cliargs_deferred_get_mock_0 = mock.Mock(side_effect=lambda: default)

    # Save the original implementations.
    cliargs_deferred_get_old = ansible_base.context.cliargs_deferred_get

    # Replace the attribute, so that we can validate it got called.
    ansible_base.context.cliargs_deferred_get = cliargs_deferred_get_mock_0

    # Set up mock objects.
    # Mock type: <type 'str'>
    var_0 = 'test string'

    # Try to call the function.
    # No exceptions should be raised.
    var_1 = cliargs_deferred_get(var_0)



# Generated at 2022-06-24 18:43:25.031696
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass # TODO

# Generated at 2022-06-24 18:43:27.029467
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(None, default=None, shallowcopy=False)


# Generated at 2022-06-24 18:43:29.004817
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    global CLIARGS
    cli_args = ImmutableDict(dict(int_0=1, int_1=2, int_2=3))
    CLIARGS = CLIArgs(cli_args)
    test_case_0()

# Generated at 2022-06-24 18:43:30.307192
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    assert var_0 is not None

# Generated at 2022-06-24 18:43:33.407963
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo')() == None
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')(default='bar') == 'bar'

# Generated at 2022-06-24 18:43:37.203897
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        int_0 = None
        var_0 = cliargs_deferred_get(int_0)
        if var_0:
            print('Failed at Test Case 0')
    except Exception as e:
        print('Test Case 0: Exception Caught as Expected')
        print('Exception is: %s' % (e))

test_cliargs_deferred_get()

# Generated at 2022-06-24 18:43:42.378310
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['CLIARGS_key1'] = 'CLIARGS_value1'
    _init_global_context(CLIARGS)
    var_1 = None
    var_2 = cliargs_deferred_get(var_1)
    var_3 = "CLIARGS_key1"
    var_4 = cliargs_deferred_get(var_3)
    var_5 = {'CLIARGS_key2': 'CLIARGS_value2'}
    var_6 = cliargs_deferred_get(var_3, var_5)
    assert var_2() == {}
    assert var_4() == 'CLIARGS_value1'
    assert var_6() == 'CLIARGS_value1'

# Generated at 2022-06-24 18:43:44.982072
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # No set up needed
    # Call the function
    cliargs_deferred_get(int_0=0)
    # No tear down needed
    # No assertions needed

# Generated at 2022-06-24 18:43:47.018593
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    s = "This is cliargs_deferred_get function"
    print(s)
    # assert(False)


# Generated at 2022-06-24 18:43:47.986600
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get()

