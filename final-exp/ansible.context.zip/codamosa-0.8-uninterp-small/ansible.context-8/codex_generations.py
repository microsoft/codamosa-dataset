

# Generated at 2022-06-24 18:36:06.541510
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()


# Generated at 2022-06-24 18:36:09.140075
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(4, default=5) == 4
    assert cliargs_deferred_get(5, default=5) == 5

# Generated at 2022-06-24 18:36:16.837236
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # TODO
    # - [ ] Fix function to match function signature
    # - [ ] Add assertions
    # - [x] Add tests
    # - [ ] Fix this test

    # Covered by:
    #     ansible.cli.doc_fragments.connection_plugins.connection_options
    #     ansible.cli.doc_fragments.connection_plugins.connection_option_help
    #     ansible.cli.doc_fragments.connection_plugins.connection_option_help_array
    #     ansible.cli.doc_fragments.connection_plugins.connection_option_version
    pass



# Generated at 2022-06-24 18:36:27.734519
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIRunner
    from types import FunctionType
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    (lambda x: x)
    __builtins__ = builtins
    if PY3:
        assert(isinstance(var_0, FunctionType))  # noqa: F821
    else:
        assert(type(var_0) is types.FunctionType)  # noqa: F821
    result = var_0()
    if PY3:
        assert(isinstance(result, FunctionType))  # noqa: F821
    else:
        assert(type(result) is types.FunctionType)  # noqa: F821
    assert(result() is None)



# Generated at 2022-06-24 18:36:31.420737
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    assert 'CLIARGS' in locals()
    assert 'key' in locals()
    assert 'value' in locals()

# Generated at 2022-06-24 18:36:33.906321
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(None)() == None
    assert cliargs_deferred_get('foo')() == None


# Generated at 2022-06-24 18:36:37.073009
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    var_1 = cliargs_deferred_get('var_1')
    pass


# Generated at 2022-06-24 18:36:41.952151
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {
        'some_param': {'default': 'a default value', 'description': 'A param with a default'},
    }
    _init_global_context(cli_args)
    test_ok = False
    try:
        test_case_0()
    except KeyError:
        test_ok = True

    assert test_ok, 'Expected:  KeyError   Actual:  KeyError not thrown'

# Generated at 2022-06-24 18:36:50.734340
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    class TestCase(unittest.TestCase):
        """Test cases for cliargs_deferred_get"""

        @patch("ansible.module_utils.common.context.CLIARGS")
        def test__cliargs_deferred_get__default(self, mock_cliargs):
            """Test default behavior of cliargs_deferred_get"""
            int_0 = "var_0"
            var_0 = cliargs_deferred_get(int_0, default="default_0")
            self.assertEqual("default_0", var_0())
            mock_cliargs.assert_called_with

# Generated at 2022-06-24 18:36:59.312453
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""

    from ansible.module_utils.common.collections import ImmutableDict
    # Setup some test cases
    def test_case(cliargs, key, default):
        _init_global_context(cliargs)
        return cliargs_deferred_get(key, default)()

    cliargs = ImmutableDict(a=1, b=2)
    assert test_case(cliargs, 'a', default=None) == 1
    assert test_case(cliargs, 'b', default=None) == 2
    assert test_case(cliargs, 'c', default=None) is None
    assert test_case(cliargs, 'd', default=3) == 3
    assert test_case(cliargs, 'e', default=None) is None

# Generated at 2022-06-24 18:37:05.831802
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    actual = cliargs_deferred_get(None, default=0)
    assert actual == 0

    CLIARGS['None']: int = 1
    actual = cliargs_deferred_get(None, default=0)
    assert actual == 1

    del CLIARGS['None']

# Generated at 2022-06-24 18:37:10.883882
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    who_2 = 'me'
    int_2 = None
    assert cliargs_deferred_get(int_2) == None
    assert cliargs_deferred_get(int_2, who_2) == 'me'
    assert cliargs_deferred_get(int_2, who_2, True) == 'me'


# Generated at 2022-06-24 18:37:16.683366
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    var_1 = cliargs_deferred_get('foo', default=1)
    var_2 = cliargs_deferred_get('bar')
    var_3 = cliargs_deferred_get('baz')
    var_4 = cliargs_deferred_get('bar', shallowcopy=True)
    var_5 = cliargs_deferred_get('baz', shallowcopy=True)

# Generated at 2022-06-24 18:37:19.343212
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    assert var_0 == None

# Generated at 2022-06-24 18:37:21.330013
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({'some_key': 'some_value'})
    assert 'some_value' == cliargs_deferred_get('some_key')()

# Generated at 2022-06-24 18:37:31.649606
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-24 18:37:32.938007
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get


# Generated at 2022-06-24 18:37:36.053029
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'
    assert callable(cliargs_deferred_get('foo'))
    assert cliargs_deferred_get('foo')() == 'bar'

# Generated at 2022-06-24 18:37:44.272124
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.argparse import ArgumentParser
    parser = ArgumentParser(allow_abbrev=False)
    parser.add_argument('-a')
    parser.add_argument('-b')
    parser.add_argument('-c')
    args = parser.parse_args(['-b', 'foo', '-a', 'bar'])

    _init_global_context(vars(args))

    var_a = cliargs_deferred_get('a')
    assert var_a() == 'bar'
    var_b = cliargs_deferred_get('b')
    assert var_b() == 'foo'
    var_c = cliargs_deferred_get('c')
    assert var_c() is None

# Generated at 2022-06-24 18:37:47.655316
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)

# Generated at 2022-06-24 18:38:01.532736
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with just the default value
    options = {'elements': [1, 2, 3]}
    _init_global_context(options)
    val = cliargs_deferred_get('elements')
    assert val == options['elements']

    # Test with a value that isn't in options
    val = cliargs_deferred_get('elements', default='foo')
    assert val == options['elements']

    # Test with a value that isn't in options and has a different default
    val = cliargs_deferred_get('elements', default=['foo'])
    assert val == options['elements']

    # Test with a value that isn't in options and has no default
    val = cliargs_deferred_get('nonexistent')
    assert val is None

# Generated at 2022-06-24 18:38:04.548590
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # TODO: Note about this function being tested.
    #
    # TODO: Note about this function being tested.
    #
    # TODO: Note about this function being tested.
    assert True

# Generated at 2022-06-24 18:38:10.425003
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # set up the test:
    int_0 = None
    var_1 = cliargs_deferred_get(int_0)
    str_0 = None
    var_2 = cliargs_deferred_get(str_0)
    # perform the test:
    var_0 = var_1
    var_1 = var_2


# Generated at 2022-06-24 18:38:14.854194
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Save the current CLIARGS and restore it after the test
    cliargs_old = CLIARGS

    try:
        test_case_0()
    finally:
        # Restore the global variable so as to not impact other tests
        CLIARGS = cliargs_old


# Generated at 2022-06-24 18:38:21.476164
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print(cliargs_deferred_get('foo'))
    CLIARGS['foo'] = 'bar'
    print(cliargs_deferred_get('foo'))
    print(cliargs_deferred_get('bar'))
    print(cliargs_deferred_get(None))
    print(cliargs_deferred_get(None, default=5))

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:28.559927
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'file': 'file1', 'path': ['path1']}
    _init_global_context(cli_args)

    test_case_0()  # WARNING:  WARNING: The following lines were not reviewed:  int_0 = None, var_0 = cliargs_deferred_get(int_0)


if __name__ == "__main__":
    import sys
    import doctest

    failed, _ = doctest.testmod()
    sys.exit(failed)

# Generated at 2022-06-24 18:38:33.788429
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    int_1 = None
    var_1 = cliargs_deferred_get(int_1)
    int_2 = None
    var_2 = cliargs_deferred_get(int_2)
    int_3 = None
    var_3 = cliargs_deferred_get(int_3)
    pass



# Generated at 2022-06-24 18:38:35.325787
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context({})
    test_case_0()

# Generated at 2022-06-24 18:38:43.637556
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Replace the global CLIARGS with a mocked version
    global CLIARGS
    from unittest.mock import Mock
    CLIARGS = Mock()

    # This is the value that we expect to be passed to the mock
    expected = 'asdf'

    # This is the value we expect to be returned
    mocked_return = 'qwerty'

    # Make the value we expect to be returned the return value of the mock
    CLIARGS.get.return_value = mocked_return

    # Call cliargs_deferred_get and make sure that it returns the same value as the mock
    assert(next(cliargs_deferred_get(expected)) == mocked_return)

    # Make sure the mock was called with the expected value
    CLIARGS.get.assert_called_with(expected)

# Generated at 2022-06-24 18:38:44.514493
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:39:01.166174
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import sys
    import inspect
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    # Hack to load the argspec for cliargs_deferred_get.  We don't want to
    # import it because that would remove our ability to test different
    # versions of the ansible-base library.
    module = inspect.getmodule(cliargs_deferred_get)
    argspec = inspect.getargspec(cliargs_deferred_get)
    assert argspec.args == ['key', 'default', 'shallowcopy'], "Should only have the args specified.  If you've changed the args, you need to update this test"
    assert argspec.varargs is None, "cliargs_deferred_get should not take a variadic argument"
    assert argspec

# Generated at 2022-06-24 18:39:02.414655
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get()
    # no return value, test fixture instead

# Generated at 2022-06-24 18:39:06.080365
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get), 'Function "cliargs_deferred_get" is not callable'

# Generated at 2022-06-24 18:39:07.382830
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)


# Generated at 2022-06-24 18:39:11.450263
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('int_0') == None
    assert cliargs_deferred_get('int_0', 1) == 1
    assert cliargs_deferred_get('int_0', [1, 2]) == [1, 2]
    assert cliargs_deferred_get('int_0', {'a': 1}) == {'a': 1}

# Generated at 2022-06-24 18:39:12.366758
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Unit tests for this module

# Generated at 2022-06-24 18:39:19.421188
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.compat.tests import unittest
    from ansible.utils.context_objects import GlobalCLIArgs

    class TestCliargs_deferred_get(unittest.TestCase):

        def setUp(self):
            self.valid_args = {
                'display_args': True,
                'forks': 10,            # int
                'check': False,         # bool
                'foobar': 'baz',        # str
                'defaults': True,       # bool
                'inventory': 'localhost',
                'listtags': False,      # bool
                'listtasks': False,     # bool
                'pattern': '*',
                'subset': 'all',
                'module_path': '/foo/bar',
                'start_at_task': 'foo',
            }


# Generated at 2022-06-24 18:39:20.286819
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:39:25.149548
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('test_case_0')() == None, 'Value returned by function cliargs_deferred_get does not match value expected'


if __name__ == "__main__":
    import sys
    import doctest

    failedTestCount, _ = doctest.testmod()
    sys.exit(failedTestCount)

# Generated at 2022-06-24 18:39:27.307625
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # No default
    assert callable(test_case_0)
    # Default
    pass # TODO
    # shallowcopy
    pass # TODO

# Generated at 2022-06-24 18:39:50.625617
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import sys, os, tempfile
    from ansible.module_utils.common.text.converters import to_text

    h, t = tempfile.mkstemp()
    try:
        os.write(h, to_text("0").encode('utf-8'))
        os.close(h)
        sys.path.insert(0, t)

        # Clear 'CLIARGS' so that the code will be reloaded
        try:
            del sys.modules['CLIARGS']
        except KeyError:
            pass

        global CLIARGS
        CLIARGS = CLIArgs({})

        test_case_0()
    finally:
        os.remove(t)

# Generated at 2022-06-24 18:40:00.256052
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs

# Generated at 2022-06-24 18:40:06.490720
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(dict(foo={'bar': 'baz'}))
    assert cliargs_deferred_get('foo', 'baz')() == {'bar': 'baz'}
    assert cliargs_deferred_get('bar', 'baz')() == 'baz'

    assert cliargs_deferred_get('foo', None, shallowcopy=True)() == {'bar': 'baz'}
    assert cliargs_deferred_get('bar', None, shallowcopy=True)() == None

    assert isinstance(cliargs_deferred_get('foo'), collections.abc.Callable)
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}

# Generated at 2022-06-24 18:40:11.958452
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var = cliargs_deferred_get("checking", default=None, shallowcopy=False)
    assert var() == None
    CLIARGS.set("checking", "test")
    assert var() == "test"

# Generated at 2022-06-24 18:40:12.851543
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get() is None

# Generated at 2022-06-24 18:40:22.038521
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        setattr(CLIARGS, 'get', lambda *args, **kwargs: 42)
        assert cliargs_deferred_get(None)() == 42
    except Exception:
        assert False, 'An exception occurred while testing cliargs_deferred_get'

    setattr(CLIARGS, 'get', lambda *args, **kwargs: None)
    try:
        assert cliargs_deferred_get(None)() is None
    except Exception:
        assert False, 'An exception occurred while testing cliargs_deferred_get'

    # If no exception is raised, the test was successful.
    assert True


if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:40:28.814096
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'int_0': 2})
    int_0 = 2
    var_0 = cliargs_deferred_get('int_0', 2)
    assert var_0 == 2
    int_1 = 2
    var_1 = cliargs_deferred_get('int_0', 2)
    assert var_1 == 2

# Generated at 2022-06-24 18:40:31.167145
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0: int = None
    var_0 = cliargs_deferred_get(int_0)
    assert type(var_0) == type(cliargs_deferred_get)



# Generated at 2022-06-24 18:40:31.934379
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get()

# Generated at 2022-06-24 18:40:34.780879
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    key = None
    default = None
    shallowcopy = None

# assert test_case_0(key, default, shallowcopy) == "expected"
# assert test_cliargs_deferred_get() == "expected"

# assert test_case_0(key, default, shallowcopy) == "expected"
# assert test_cliargs_deferred_get() == "expected"

# Generated at 2022-06-24 18:41:09.764726
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()



# Generated at 2022-06-24 18:41:15.032933
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()


if __name__ == '__main__':
    import sys
    import doctest
    failed, _ = doctest.testmod()
    sys.exit(failed)

# Generated at 2022-06-24 18:41:16.989642
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # TODO: Figure out how to write unit tests
    assert True



# Generated at 2022-06-24 18:41:18.106994
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:41:28.837516
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {
        'str_0': 'test'
    }
    _init_global_context(cli_args)
    assert CLIARGS.get('str_0') == 'test'

    str_0 = cliargs_deferred_get('str_0', 'empty')
    assert str_0() == 'test'
    str_1 = cliargs_deferred_get('str_1', 'empty')
    assert str_1() == 'empty'
    str_2 = cliargs_deferred_get('str_2')
    assert str_2() is None

    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    assert var_0() is None

    int_0 = 'str_0'
    var_0 = cliargs

# Generated at 2022-06-24 18:41:31.808253
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    assert len(var_0) == 13
    #assert var_0 == 'device_connection'

# Common main for all tests

# Generated at 2022-06-24 18:41:33.061841
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    ci_0 = CLIA

# Generated at 2022-06-24 18:41:36.120216
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(None, default=None)() == None
    # No assertions.  Just make sure we don't see any errors



# Generated at 2022-06-24 18:41:37.484471
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass # FIXME

# Generated at 2022-06-24 18:41:41.585823
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        from ansible.utils.context_objects import CLIArgs
        from ansible.module_utils.common.collections import is_sequence
    except ImportError:
        # Mock for unit tests
        class CLIArgs(object):
            def __init__(self, options):
                pass

            def __getitem__(self, key):
                if key == 'allow_world_readable_tmpfiles':
                    return True
                return CLIArgs({})

        def is_sequence(x):
            return True
    cli_args = CLIArgs({})
    int_0 = None
    var_29 = cliargs_deferred_get(int_0)
    int_1 = 0
    var_30 = cliargs_deferred_get(int_1)
    int_2 = 2
    var_31 = cli

# Generated at 2022-06-24 18:42:57.832136
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(int_0) == None



# Generated at 2022-06-24 18:43:04.587956
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with an invalid key
    try:
        result = cliargs_deferred_get(1)
        assert False, 'Expected KeyError'
    except KeyError:
        pass

    # Test with no default value
    try:
        result = cliargs_deferred_get('foo')
        assert False, 'Expected KeyError'
    except KeyError:
        pass

    global CLIARGS
    CLIARGS = CLIARGS._replace(one=1, two=2)

    # Test with a valid key and no default
    result = cliargs_deferred_get('one')
    assert result == 1

    # Test with a valid key and a default
    result = cliargs_deferred_get('three', default=3)
    assert result == 3

    # Test with a valid key, a default and

# Generated at 2022-06-24 18:43:09.710701
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    with pytest.raises(TypeError):
        void_0 = var_0()


#############################################################################
# Unit Tests for cliargs_deferred_get #
#############################################################################

# Generated at 2022-06-24 18:43:13.614148
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context(var_0)
    assert CLIARGS.get(key, default=default) is var_0



# Generated at 2022-06-24 18:43:14.758150
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

# Generated at 2022-06-24 18:43:17.140653
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get is not None, "Failed to find function cliargs_deferred_get"


if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:43:22.905550
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get("key", "default"))
    assert callable(cliargs_deferred_get("key"))
    assert callable(cliargs_deferred_get("key", "default", True))
    assert callable(cliargs_deferred_get("key", shallowcopy=True))
    with __raises__(TypeError):
        cliargs_deferred_get("key", True, True)

    v = cliargs_deferred_get("key", "default")()
    assert v == "default"


# Generated at 2022-06-24 18:43:24.753157
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    ret_0 = cliargs_deferred_get(()).__closure__[0].cell_contents
    assert ret_0 == CLIARGS
    assert ret_0 is CLIARGS



# Generated at 2022-06-24 18:43:26.831245
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get_0()
    cliargs_deferred_get_1()



# Generated at 2022-06-24 18:43:31.329815
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Test case for the ``cliargs_deferred_get`` function.

    The specific test:
        >>> test_case_0()
        >>> assert(int_0 == None)
    """

    int_0 = None
    var_0 = cliargs_deferred_get(int_0)
    test_case_0()
    assert int_0 == None