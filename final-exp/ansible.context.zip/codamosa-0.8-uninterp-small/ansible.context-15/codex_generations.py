

# Generated at 2022-06-24 18:36:11.700145
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)
    var_1 = cliargs_deferred_get(dict_0)


# Generated at 2022-06-24 18:36:15.675949
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(**dict_0)

# Generated at 2022-06-24 18:36:16.567603
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get()

# Generated at 2022-06-24 18:36:17.275113
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    #TODO: review implementation
    pass



# Generated at 2022-06-24 18:36:19.679122
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_1 = {}
    var_1 = cliargs_deferred_get(dict_1)



# Generated at 2022-06-24 18:36:22.044459
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    ret = cliargs_deferred_get(dict_0)
    assert ret is None



# Generated at 2022-06-24 18:36:32.818936
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    t = cliargs_deferred_get
    assert t({'a': 1}) == 1
    assert t({'a': 1, 'b': 2}) == 2
    assert t({'a': 1, 'b': 2, 'c': 3}, default=7) == 3
    assert t({'a': 1, 'b': 2, 'c': 3}, default=7, shallowcopy=True) == 3
    assert t({'a': 1, 'b': 2, 'c': [4, 5, 6]}, shallowcopy=True) == [4, 5, 6]
    assert t({'a': 1, 'b': 2, 'c': {4, 5, 6}}, shallowcopy=True) == {4, 5, 6}

# Generated at 2022-06-24 18:36:33.805573
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get()

# Generated at 2022-06-24 18:36:48.242155
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print("id: " + hex(id(test_case_0)))
    print("id: " + hex(id(dict_0)))
    print("id: " + hex(id(var_0)))
    if None != dict_0:
        var_0 = dict_0
    else:
        dict_0 = var_0
        print("id: " + hex(id(dict_0)))
        print("id: " + hex(id(var_0)))
        assert dict_0 is var_0
    assert dict_0 is cliargs_deferred_get.func_defaults[0]
    assert dict_0 is var_0
    print("id: " + hex(id(dict_0)))
    print("id: " + hex(id(var_0)))
    assert dict_0 is var_0
   

# Generated at 2022-06-24 18:36:49.176736
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    with raises(NameError):
        test_case_0()

# Generated at 2022-06-24 18:36:52.241776
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True




# Generated at 2022-06-24 18:36:54.093974
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)


# Generated at 2022-06-24 18:36:59.066933
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)
    dict_1 = {"a": 2}
    var_1 = cliargs_deferred_get(dict_1, default=3)
    dict_2 = {"a": 2}
    var_2 = cliargs_deferred_get(dict_2)
    dict_3 = {"a": 2}
    var_3 = cliargs_deferred_get(dict_3, shallowcopy=True)

# Generated at 2022-06-24 18:37:07.091614
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''
	# Functionality testing
	>>> cliargs_deferred_get(0, default=None, shallowcopy=False)

	# Functionality testing
	>>> cliargs_deferred_get(0, default=None, shallowcopy=True)

	# Boundary testing
	>>> cliargs_deferred_get(dict(), default=None, shallowcopy=True)

	# Boundary testing
	>>> cliargs_deferred_get(dict(), default=0, shallowcopy=True)
	'''



# Generated at 2022-06-24 18:37:08.126735
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get()

# Generated at 2022-06-24 18:37:11.115268
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    input_0 = "{}"
    expected_0 = None
    actual_0 = cliargs_deferred_get(input_0)
    assert expected_0 == actual_0



# Generated at 2022-06-24 18:37:15.429701
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pytest.skip("TODO: Implement")
    # var_0 = cliargs_deferred_get()
    # assert var_0 == expected
    # assert cliargs_deferred_get() == expected


if __name__ == '__main__':
    # Unit test for function cliargs_deferred_get
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:16.271031
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass



# Generated at 2022-06-24 18:37:21.499938
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Initialise the 'dict_0' variable, and pass it to the function
    dict_0 = {}
    # Call function 'cliargs_deferred_get'
    var_0 = cliargs_deferred_get(dict_0)
    # Assert is boolean type
    # Assert that var_0 is False
    pass



if __name__ == "__main__":
    import ansible_test._context_main as context_main
    context_main.main(globals())

# Generated at 2022-06-24 18:37:22.371984
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True



# Generated at 2022-06-24 18:37:28.790809
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)
    assert var_0 == dict_0

# Generated at 2022-06-24 18:37:38.457405
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.playbook.play_context
    ansible_playbook_play_context = ansible.playbook.play_context
    import ansible.plugins.connection.network_cli
    ansible_plugins_connection_network_cli = ansible.plugins.connection.network_cli
    import ansible.plugins.loader
    ansible_plugins_loader = ansible.plugins.loader
    import ansible.vars.manager
    ansible_vars_manager = ansible.vars.manager

    import copy
    import types
    import sys

    # Save the original modules so we can reinstate them at the end of the test
    original_modules = sys.modules.copy()

    # This is just a generic object for testing purposes
    class MockModule(object):
        pass


# Generated at 2022-06-24 18:37:39.782846
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get() == ""



# Generated at 2022-06-24 18:37:40.656193
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get is not None

# Generated at 2022-06-24 18:37:41.338759
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:37:43.541067
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
    except NameError as e:
        print(str(e))
        assert False

# Generated at 2022-06-24 18:37:44.481215
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True


# Generated at 2022-06-24 18:37:51.349131
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Dummy CLIRGS
    global CLIARGS
    CLIARGS = CLIArgs({'debug': True})
    deferred_get = cliargs_deferred_get('debug')
    assert(deferred_get() == True)
    CLIARGS = CLIArgs({'debug': False})
    assert(deferred_get() == False)
    assert(cliargs_deferred_get('undefined', default=False)() == False)

# Generated at 2022-06-24 18:37:57.486337
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    check_clirargs_deferred_get = "A test string"
    dict_0 = {"test_key": check_clirargs_deferred_get}
    var_0 = cliargs_deferred_get(dict_0, "test_key")
    assert var_0 == check_clirargs_deferred_get, "Expected {}, but got {}".format(check_clirargs_deferred_get, var_0)

# Generated at 2022-06-24 18:37:59.400445
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test function with default argument
    # Test function with positional argument only
    # Test function without argument
    assert False, "Test not implemented"

# Generated at 2022-06-24 18:38:08.533301
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get() == None

# Generated at 2022-06-24 18:38:11.692823
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():


    #from ansible.module_utils.common.generic_objects import field_attribute

    #var_0 = field_attribute.FieldAttribute()
    assert True

# Generated at 2022-06-24 18:38:12.301117
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:38:15.029260
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        assert callable(cliargs_deferred_get)
    except AssertionError:
        raise AssertionError('function cliargs_deferred_get not callable')

# Generated at 2022-06-24 18:38:18.912807
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert func_0() == 0

# Generated at 2022-06-24 18:38:28.847751
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Verify that the function returns the same value that is assigned
    dict_0 = {'key_1': 'value_1'}
    dict_0['key_2'] = 'value_2'
    dict_0['key_3'] = 'value_3'
    var_0 = cliargs_deferred_get('key_1')
    assert var_0 == 'value_1'
    var_0 = cliargs_deferred_get('key_2')
    assert var_0 == 'value_2'
    var_0 = cliargs_deferred_get('key_3')
    assert var_0 == 'value_3'

# Generated at 2022-06-24 18:38:31.853870
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Call the function
    # assert cliargs_deferred_get(key, default=None, shallowcopy=False) == expected
    raise NotImplementedError('This function needs a unit test.')



# Generated at 2022-06-24 18:38:36.639475
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)
    assert var_0 is cliargs_deferred_get(dict_0, shallowcopy=True)
    list_0 = [1, 2, 3]
    var_0 = cliargs_deferred_get(list_0)
    assert var_0 is cliargs_deferred_get(list_0, shallowcopy=True)

# Generated at 2022-06-24 18:38:42.161806
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    res = cliargs_deferred_get(0, 1, False)
    assert res is None
    res = cliargs_deferred_get(0, 1, False)
    assert res is None

if __name__ == '__main__':
    res = cliargs_deferred_get(0, 1, False)
    print(res)
    res = cliargs_deferred_get(0, 1, False)
    print(res)

# Generated at 2022-06-24 18:38:43.501913
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)


# Generated at 2022-06-24 18:39:06.913763
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}  # initialization
    # Checking if the dictionary is empty
    if not dict_0:
        pass

    # Checking if the dictionary is NOT empty
    if dict_0:
        pass

    # Checking if a key is NOT in the dictionary
    if dict_0.get(dict_0) is None:
        pass

    # Iterating over the dictionary
    for var_0 in dict_0.keys():
        pass

    # Iterating over the dictionary while returning both keys and values
    for var_0, var_1 in dict_0.items():
        pass

# Generated at 2022-06-24 18:39:10.255163
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('test_case_0', default=None) == None
    # placeholder to force the call to cliargs_deferred_get to execute
    result = cliargs_deferred_get('test_case_0', default=None)
    assert result == None

# Generated at 2022-06-24 18:39:12.425485
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This test requires the implementation of cliargs_deferred_get with the
    # option to not shallow copy the result
    pass

# Generated at 2022-06-24 18:39:15.082178
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Create the needed objects
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)

    # Call the function
    cliargs_deferred_get()

    # Validate the results



# Generated at 2022-06-24 18:39:16.699751
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_1 = {}
    var_1 = cliargs_deferred_get(dict_1)

# Generated at 2022-06-24 18:39:22.346933
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = {}
    var_1 = cliargs_deferred_get(var_0)

# Generated at 2022-06-24 18:39:26.677781
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)

# Generated at 2022-06-24 18:39:33.183152
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_2 = {}
    dict_2['foo'] = 'bar'
    dict_2['ansible_verbosity'] = '4'
    dict_2['bar'] = 'foo'
#
#
# Test call(s)
#
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:39:43.247125
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_1 = {}
    expected_0 = None
    actual_0 = cliargs_deferred_get(dict_1)
    assert actual_0 == expected_0

    dict_2 = {"a": "b", "c": "d", "e": "f"}
    expected_1 = "f"
    actual_1 = cliargs_deferred_get(dict_2)
    assert actual_1 == expected_1

    dictionary_0 = {"c": "f", "d": "e"}
    expected_2 = "f"
    actual_2 = cliargs_deferred_get(dictionary_0)
    assert actual_2 == expected_2

    dictionary_1 = {"c": "f", "d": "e", "a": "b"}
    expected_3 = "f"
    actual_3

# Generated at 2022-06-24 18:39:45.361246
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get('var_0')()
    assert var_0 is None


# Generated at 2022-06-24 18:40:17.876964
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True

# Generated at 2022-06-24 18:40:25.250299
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    param_0 = [{}, {'key': 'value', 'default': 'value'}]
    param_0 = [{'key': 'value', 'default': 'value'}]
    var_0 = cliargs_deferred_get(param_0)
    var_0 = cliargs_deferred_get(param_0)
    var_0 = cliargs_deferred_get(param_0)
    var_0 = cliargs_deferred_get(param_0)
    var_0 = cliargs_deferred_get(param_0)
    var_0 = cliargs_deferred_get(param_0)
    var_0 = cliargs_deferred_get(param_0)
    var_0 = cliargs_deferred_get(param_0)
   

# Generated at 2022-06-24 18:40:27.604595
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_arg = {}
    # Remove this line when cliargs_deferred_get is tested
    raise ValueError


# Generated at 2022-06-24 18:40:29.206634
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {'message': 'test message'}
    var_0 = cliargs_deferred_get(dict_0)

# Generated at 2022-06-24 18:40:31.887208
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)

# Generated at 2022-06-24 18:40:34.723187
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get
    test_case_0()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-24 18:40:37.076437
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)

# Generated at 2022-06-24 18:40:46.233865
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Create context object
    context = Context()


if __name__ == '__main__':
    import sys
    import inspect
    # Get the name of the test_case_0 function
    test_case_0_name = sys.argv[1]
    # Get the function object named test_case_0_name
    test_case_0_object = globals()[test_case_0_name]
    # Get the arguments passed to test_case_0
    # arg_spec[0] is a list of the argument names (it's a tuple)
    # arg_spec[1] is the varargs name (or None)
    # arg_spec[2] is the keyword args name (or None)
    # arg_spec[3] is the default values for all arguments (None if no default)
    arg_spec = inspect

# Generated at 2022-06-24 18:40:47.580207
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)


# Generated at 2022-06-24 18:40:51.694298
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)


if __name__ == "__main__":
    import sys
    ret = min([0, 1])
    ret += test_case_0()
    sys.exit(ret)

# Generated at 2022-06-24 18:41:58.488711
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True

# Generated at 2022-06-24 18:41:58.962434
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:42:00.612194
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)
    assert var_0 is not None

# Generated at 2022-06-24 18:42:01.653121
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get('foo', 'bar')

# Generated at 2022-06-24 18:42:02.389105
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True



# Generated at 2022-06-24 18:42:12.719468
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Store the initial value of the cliargs
    initial_cliargs = CLIARGS

    # Test the basic functionality of this function
    assert cliargs_deferred_get(key='foo', default='bar')('run') == 'bar'
    cliargs = {'foo': 'abc', 'bar': 'def'}
    assert cliargs_deferred_get(key='foo', default='bar')('run') == 'abc'
    assert cliargs_deferred_get(key='bar')('run') == 'def'
    assert cliargs_deferred_get(key='foobar')('run') is None

    # Test the behavior for shallowcopy
    dict_0 = {'a': 1, 'b': 2}
    dict_1 = {'c': 3, 'd': 4}
    cl

# Generated at 2022-06-24 18:42:14.524904
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        cli_args = {}
        _init_global_context(cli_args)

        assert False
    except AssertionError:
        pass

# Generated at 2022-06-24 18:42:16.196330
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass  # TODO: Implement test or remove if not needed

# Generated at 2022-06-24 18:42:21.841588
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert isinstance(cliargs_deferred_get('key_0', 'default_0', 'shallowcopy_0'), object)

    assert cliargs_deferred_get('dict_0').get('key_1') is None
    assert cliargs_deferred_get('dict_0', 'default_1').get('key_2') == 'default_1'
    assert cliargs_deferred_get('dict_0', 'default_2') is None
    assert cliargs_deferred_get('list_0') == []
    assert cliargs_deferred_get('list_0', 'default_3') == 'default_3'
    assert cliargs_deferred_get('set_0') == set([])

# Generated at 2022-06-24 18:42:23.012503
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert False, "Test for function cliargs_deferred_get not implemented"

# Generated at 2022-06-24 18:44:55.574170
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    '''
    Unit test for function cliargs_deferred_get
    '''
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)
    assert not var_0

# Generated at 2022-06-24 18:45:03.286767
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {0:0}
    dict_1 = {0:0}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {0:0}
    dict_5 = {0:0}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    stat_0 = {}

    assert cliargs_deferred_get(dict_0) == dict_0
    assert cliargs_deferred_get(dict_1) == dict_1
    assert cliargs_deferred_get(dict_2) == dict_2
    assert cliargs_deferred_get(dict_3) == dict_3
    assert cliargs_deferred_get(dict_4) == dict_4

# Generated at 2022-06-24 18:45:07.787505
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)

# Generated at 2022-06-24 18:45:15.909034
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get('foo')()
    assert isinstance(var_0, cliargs_deferred_get)
    assert var_0 is not False
    assert var_0 is not True

    CLIARGS.foo = 'bar'
    var_1 = cliargs_deferred_get('foo')()
    assert var_1 == 'bar'

    var_2 = cliargs_deferred_get('foo', 'default')()
    assert var_2 == CLIARGS.foo

# Generated at 2022-06-24 18:45:17.515470
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = None
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)


# Generated at 2022-06-24 18:45:20.640667
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)
    if var_0 != dict_0:
        raise AssertionError("Expected: " + str(dict_0) + "\nReceived: " + str(var_0))


# Generated at 2022-06-24 18:45:22.305373
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get() == ''


# Generated at 2022-06-24 18:45:24.862173
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_1 = {}
    var_1 = cliargs_deferred_get(dict_1)
    assert (var_1 == dict_1)



# Generated at 2022-06-24 18:45:27.569442
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    dict_0 = {}
    var_0 = cliargs_deferred_get(dict_0)
    assert True

# Generated at 2022-06-24 18:45:29.070012
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    with pytest.raises(TypeError):
        test_case_0()