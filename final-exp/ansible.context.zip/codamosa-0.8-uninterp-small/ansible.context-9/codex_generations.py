

# Generated at 2022-06-24 18:36:12.240036
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    tuple_0 = None
    dict_0 = {tuple_0: tuple_0}
    var_0 = cliargs_deferred_get(tuple_0, dict_0)


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        globals()['test_' + sys.argv[1]]()
    else:
        for k, v in globals().items():
            if k.startswith('test_'):
                print(k)
                v()

# Generated at 2022-06-24 18:36:20.589945
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('agk')('agk') == 'agk'
    #assert cliargs_deferred_get('agk')('agk') == 'agk'
    assert cliargs_deferred_get('agk')('agk') == 'agk'
    #assert cliargs_deferred_get('agk')('agk') == 'agk'
    #assert cliargs_deferred_get('agk')(tuple_0) == tuple_0
    #assert cliargs_deferred_get('agk')(tuple_0) == tuple_0
    #assert cliargs_deferred_get('agk')(dict_0) == dict_0

# Generated at 2022-06-24 18:36:31.371548
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # simple test
    dict_0 = {'key_1': 'value_1', 'key_2': 'value_2', 'key_3': 'value_3'}
    key_4 = 'key_4'
    var_0 = cliargs_deferred_get('key_1', dict_0)
    assert var_0() == dict_0['key_1']
    var_0 = cliargs_deferred_get(key_4, dict_0)
    assert var_0() == dict_0
    var_0 = cliargs_deferred_get('key_1', dict_0, True)
    assert var_0() == dict_0['key_1']
    var_0 = cliargs_deferred_get(key_4, dict_0, True)
    assert var_0()

# Generated at 2022-06-24 18:36:36.055102
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Try to catch dictionary getter
    try:
        test_case_0()
    except TypeError as exc0:
        print('TypeError:', exc0)
    else:
        assert False

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:36:40.567277
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    tuple_0 = None
    dict_0 = {tuple_0: tuple_0}
    var_0 = cliargs_deferred_get(tuple_0, dict_0)
    str_0 = 'No module found for: '
    str_1 = str_0 + var_0
    assert str_1 == 'No module found for: '

# Generated at 2022-06-24 18:36:45.398361
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible import constants as C
    test_case_0()
    set_0 = set()
    dict_0 = {None: set_0}
    str_0 = cliargs_deferred_get(set_0, dict_0)
    return str_0
#

# Generated at 2022-06-24 18:36:46.533221
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Source function: cliargs_deferred_get
    # Test case 0
    test_case_0()

# Generated at 2022-06-24 18:36:48.163283
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Assign var_0 the result of an inline function call
    var_0 = test_case_0()



# Generated at 2022-06-24 18:36:54.356166
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    tuple_0 = None
    dict_0 = {tuple_0: tuple_0}
    tuple_1 = (tuple_0, dict_0, dict_0, dict_0)
    tuple_2 = (tuple_0, dict_0, dict_0, dict_0)
    dict_1 = {tuple_1: tuple_2}
    var_0 = cliargs_deferred_get(tuple_0, dict_0, dict_1)
    assert var_0 == dict_0
    var_0 = cliargs_deferred_get(tuple_0, dict_0, dict_0, dict_1)
    assert var_0 == dict_0
    var_0 = cliargs_deferred_get(tuple_0, dict_0, dict_1, dict_0)


# Generated at 2022-06-24 18:36:56.496839
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    tuple_0 = None
    dict_0 = {tuple_0: tuple_0}
    var_0 = cliargs_deferred_get(tuple_0, dict_0)

# Generated at 2022-06-24 18:37:10.067477
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    obj_0 = CLIARGS
    import ansible.module_utils.common.context_objects
    temp_0 = set()
    temp_0.add(ansible.module_utils.common.context_objects.CLIARGS)
    temp_0.add(ansible.module_utils.common.context_objects.GlobalCLIArgs)
    temp_0.add(ansible.module_utils.common.context_objects.CLIArgs)
    temp_0.add(ansible.module_utils.common.collections)
    temp_0.add(ansible.module_utils.common.json_sanitize)
    temp_0.add(ansible.module_utils.common.json_sanitize._dict_sanitize)

# Generated at 2022-06-24 18:37:12.488735
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)
    print(var_0)

test_case_0()

# Generated at 2022-06-24 18:37:13.105571
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Call function
    test_case_0()

# Generated at 2022-06-24 18:37:14.591701
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    value = cliargs_deferred_get(str_0)
    assert value is None


# Generated at 2022-06-24 18:37:15.976389
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:23.360252
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-24 18:37:24.995315
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)

# Generated at 2022-06-24 18:37:34.425849
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)
    # This is only used for type hinting so we expect it to be a function.
    # It may be that this is a bug in the MyPy codebase.
    assert isinstance(var_0, type(test_case_0))


if __name__ == "__main__":
    import sys
    import pytest

    print("Testing %s" % __file__)
    print("Python %s" % sys.version)
    print("Pytest %s" % pytest.__version__)
    print("Pytest-Mypy %s" % pytest_mypy.__version__)

    pytest.main(args=[__file__])

# Generated at 2022-06-24 18:37:35.490726
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is a stub.
    pass


# Generated at 2022-06-24 18:37:44.093306
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Call cliargs_deferred_get with argument 0 cliargs_deferred_get(key, default=None, shallowcopy=False)
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)

    # Assert result is not equal to "agk"
    assert var_0 != str_0

    # Assert result is not equal to None
    assert var_0 != None

    # Assert result is not equal to 2
    assert var_0 != 2

    # Assert result is not equal to "agk"
    assert var_0 != str_0

    # Assert result is not equal to None
    assert var_0 != None

    # Assert result is not equal to False
    assert var_0 != False

    # Assert result is not equal to "ag

# Generated at 2022-06-24 18:37:49.305364
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert test_case_0()



# Generated at 2022-06-24 18:37:52.315951
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'

    var_0 = cliargs_deferred_get(str_0)
    assert var_0() == None

# Generated at 2022-06-24 18:37:56.576280
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestAnsibleModule(object):
        def __init__(self):
            self.params = {}

    test_ansible_module = TestAnsibleModule()

    try:
        test_case_0()
    except Exception:
        assert False, "Unable to execute function test_case_0"


# Generated at 2022-06-24 18:38:00.320116
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup
    str_0 = 'agk'
    expected = None

    # Exercise
    actual = cliargs_deferred_get(str_0)

    # Verify
    assert expected is actual

    # Cleanup - N/A

# Generated at 2022-06-24 18:38:02.025203
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)



# Generated at 2022-06-24 18:38:10.337667
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get('debug')

    # Call function 'cliargs_deferred_get'
    return_value = cliargs_deferred_get('foo')

    # Return assertions
    assert return_value is None


# Note: this is not the singleton version.  The Singleton is only created once the program has
# actually parsed the args
CLIARGS = CLIArgs({})


# This should be called immediately after cli_args are processed (parsed, validated, and any
# normalization performed on them).  No other code should call it

# Generated at 2022-06-24 18:38:11.843136
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Call function
    test_case_0()

# Generated at 2022-06-24 18:38:14.325240
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)
    assert var_0 is None

# Generated at 2022-06-24 18:38:17.072091
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)

# Generated at 2022-06-24 18:38:19.737177
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)
    try:
        assert var_0() == 'ieplat'
    except AssertionError:
        raise AssertionError('var_0 is: {}'.format(var_0))


# Generated at 2022-06-24 18:38:26.902038
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        assert 1 == 1
    except Exception as err:
        print("Test of function 'cliargs_deferred_get' FAILED: %s" % err)
    else:
        print("Test of function 'cliargs_deferred_get' PASSED")


# Generated at 2022-06-24 18:38:34.602205
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    arglist = []
    arglist.append(['agk', 'adg'])
    arglist.append(['agk', 'adg'])
    arglist.append(['agk', 'adg'])
    arglist.append(['agk', 'adg'])
    arglist.append(['agk', 'adg'])
    arglist.append(['agk', 'adg'])
    arglist.append(['agk', 'adg'])
    arglist.append(['agk', 'adg'])
    arglist.append(['agk', 'adg'])
    arglist.append(['agk', 'adg'])

    def test_case_inner():
        str_0 = arglist[0][0]
        var_0 = cliargs_deferred

# Generated at 2022-06-24 18:38:36.225904
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    arg = None
    assert cliargs_deferred_get(arg) == 0



# Generated at 2022-06-24 18:38:44.541796
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()


if __name__ == '__main__':
    import traceback
    import logging
    logging.basicConfig(level=logging.INFO)

    # If a test fails it will raise an exception.  The rest of the tests should
    # still be run
    failed_tests = []
    passed_tests = []
    failed_test_exceptions = []
    tests_run = 0
    passed_tests_run = 0
    failed_tests_run = 0

    for name, test_func in sorted(locals().items()):
        if not name.startswith('test_'):
            continue
        tests_run += 1

# Generated at 2022-06-24 18:38:47.781028
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_1 = 'r'
    var_1 = cliargs_deferred_get(str_1)
    pass

if __name__ == '__main__':
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:50.317878
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS._options = {}
    str_0 = 'jdbf'
    var_0 = cliargs_deferred_get(str_0)()
    assert var_0 is None


# Generated at 2022-06-24 18:38:51.759705
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    inner = cliargs_deferred_get('agk')
    assert inner() == None

# Generated at 2022-06-24 18:38:55.085024
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible_collections.yunxu.deep.plugins.module_utils.common.context_objects import cliargs_deferred_get
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:38:55.685055
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert False

# Generated at 2022-06-24 18:38:57.528749
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # make sure the errors are caught when calling the function
    try:
        test_case_0()
    except Exception:
        assert False



# Generated at 2022-06-24 18:39:13.917101
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)

    str_1 = 'agk'
    dict_0 = dict()
    dict_0[str_1] = var_0
    dict_1 = dict_0

    # try to run code with different hash seed
    for i in range(10):
        dict_1 = dict_0.copy()
        dict_1 = dict_0.copy()
        dict_1 = dict_0.copy()
        dict_1 = dict_0.copy()
        dict_1 = dict_0.copy()
        dict_1 = dict_0.copy()
        dict_1 = dict_0.copy()
        dict_1 = dict_0.copy()
        dict_1 = dict_0.copy()
       

# Generated at 2022-06-24 18:39:14.882879
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True


# Generated at 2022-06-24 18:39:17.827781
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
        str_0 = 'agk'
        var_0 = cliargs_deferred_get(str_0)


# Generated at 2022-06-24 18:39:28.189363
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'ex'
    var_0 = cliargs_deferred_get(str_0)


if __name__ == "__main__":
    import sys
    import inspect
    import argparse
    argparser = argparse.ArgumentParser(description='Check for python code in ansible for argument validation')
    argparser.add_argument('--blacklist', dest='blacklist',
            type=lambda x:set([y.strip() for y in x.split(',')]),
            help='Comma separated list of modules to not check')
    argparser.add_argument('--whitelist', dest='whitelist',
            type=lambda x:set([y.strip() for y in x.split(',')]),
            help='Comma separated list of modules to check')
    argparser.parse_args()
   

# Generated at 2022-06-24 18:39:33.137052
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    arg_0 = 'agk'
    arg_1 = None
    arg_2 = False
    assert not cliargs_deferred_get(arg_0, arg_1, arg_2)
    assert not cliargs_deferred_get(arg_0, arg_1, arg_2)
    assert not cliargs_deferred_get(arg_0, arg_1, arg_2)
    assert isinstance(cliargs_deferred_get(arg_0, arg_1, arg_2), type(lambda:0))
    assert not cliargs_deferred_get(arg_0, arg_1, arg_2)

# Generated at 2022-06-24 18:39:34.832213
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get('agk')
    assert var_0() is None

# Generated at 2022-06-24 18:39:38.320534
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(str_0)
    var_2 = cliargs_deferred_get('the_key', str_0)
    var_3 = cliargs_deferred_get(str_0)



# Generated at 2022-06-24 18:39:39.582899
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
    except:
        assert False



# Generated at 2022-06-24 18:39:48.816396
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # String test for cliargs_deferred_get, with arguments:
    #   key: 'agk'
    #   default: None,
    #   shallowcopy: False
    str_0 = 'agk'
    str_1 = cliargs_deferred_get(str_0)
    assert (str_1 == None), 'Failed to get cliargs_deferred_get where key = ' + str(str_0) + ', expecting: None'
    # String test for cliargs_deferred_get, with arguments:
    #   key: 'agk'
    #   default: 'uvj',
    #   shallowcopy: True
    str_2 = 'agk'
    str_3 = cliargs_deferred_get(str_2, 'uvj', True)

# Generated at 2022-06-24 18:39:49.991119
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:40:09.542478
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:40:12.154495
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)
    print(var_0)


# Generated at 2022-06-24 18:40:16.218703
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)
    assert (var_0() == None)

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:40:19.576330
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)


if __name__ == '__main__':
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:40:21.990679
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cvar_0 = 'agk'
    var_0 = cliargs_deferred_get(cvar_0)
    assert True


# Unit tests for function _init_global_context

# Generated at 2022-06-24 18:40:28.814768
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        str_0 = 'agk'
        var_0 = cliargs_deferred_get(str_0)
        str_1 = 'nj'
        var_1 = cliargs_deferred_get(str_1)
    except Exception as e_1:
        print('test_cliargs_deferred_get:', e_1)

# Generated at 2022-06-24 18:40:30.238271
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get("str_0") == 'agk'

test_case_0()

# Generated at 2022-06-24 18:40:33.081380
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)

# Generated at 2022-06-24 18:40:34.110856
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-24 18:40:35.441151
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True  # TODO

# Generated at 2022-06-24 18:41:14.784138
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(test_case_0)
    #TODO - Fix test_case_0
    #test_case_0()

# Generated at 2022-06-24 18:41:19.824180
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_2 = cliargs_deferred_get(str_0)
    print(var_2)


if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:41:21.650204
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)

# Generated at 2022-06-24 18:41:23.546939
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)
    assert var_0() is None

# Generated at 2022-06-24 18:41:31.120604
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    arg_0 = 'agk'
    arg_1 = 'agk'
    arg_2 = 'agk'
    try:
        assert arg_0 == arg_1 and arg_1 == arg_2
    except AssertionError:
        print('arg_0 =', arg_0)
        print('arg_1 =', arg_1)
        print('arg_2 =', arg_2)
        raise
    # TODO: Test that 'inner' returns the same results as calling cliargs.get() with the same
    # arguments
    return



# Generated at 2022-06-24 18:41:37.136431
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = 'ttg'
    frontend_0 = {'module_name': 'ansible.module_utils.common.context_objects.cliargs_deferred_get', 'name': 'cliargs_deferred_get'}
    result_0 = cliargs_deferred_get
    assert result_0 == frontend_0

# Generated at 2022-06-24 18:41:40.453560
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=duplicate-code
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    test_case_0()
    # tests 0-1
    return

# Generated at 2022-06-24 18:41:41.284592
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = None
    assert var_0 == 'agk'

# Generated at 2022-06-24 18:41:42.870855
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)
    var_0()

# Generated at 2022-06-24 18:41:48.406339
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print('Test function cliargs_deferred_get:')
    test_case_0()
    print('Done with test function cliargs_deferred_get!')


if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:43:08.314414
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)
    assert var_0() == {}

# Generated at 2022-06-24 18:43:14.925543
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_1 = 'agk'
    str_2 = 'agk'
    str_3 = 'agk'
    var_2 = cliargs_deferred_get(str_1, str_2, str_3)
    assert isinstance(var_2, cliargs_deferred_get)

    str_4 = 'agk'
    var_3 = cliargs_deferred_get(str_4)
    assert isinstance(var_3, cliargs_deferred_get)

# Generated at 2022-06-24 18:43:19.342824
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert test_cliargs_deferred_get.__name__ == 'test_cliargs_deferred_get'
    # Run test case 0
    test_case_0()


if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:43:23.028870
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert 'str_0' in globals()
    assert 'var_0' in globals()
    for temp_0 in var_0():
        pass

# Local Variables:
# slow-sort-imports: t
# coding: utf-8
# python-isort: t
# isort-line-length: 120
# eval: (newline-and-indent)
# End:

# Generated at 2022-06-24 18:43:24.381724
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get() == 'abc'
#

# Generated at 2022-06-24 18:43:27.920296
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)
    str_1 = 'e7h'
    str_2 = 'abc'
    var_0 = cliargs_deferred_get(str_1, default=str_2)
    str_1 = 'e7h'
    str_2 = 'abc'
    var_0 = cliargs_deferred_get(str_1, shallowcopy=True, default=str_2)


# Generated at 2022-06-24 18:43:30.206518
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'flu'
    var_0 = cliargs_deferred_get(str_0)
    assert var_0() is None



# Generated at 2022-06-24 18:43:30.632678
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass



# Generated at 2022-06-24 18:43:32.634306
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)



# Generated at 2022-06-24 18:43:34.546663
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'agk'
    var_0 = cliargs_deferred_get(str_0)
    assert var_0() == None
