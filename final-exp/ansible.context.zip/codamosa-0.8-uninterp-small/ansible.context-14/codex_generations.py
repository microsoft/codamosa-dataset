

# Generated at 2022-06-24 18:36:10.789236
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)
    var_1 = cliargs_deferred_get(int_0, 'default-1139')
    var_2 = cliargs_deferred_get(int_0, shallowcopy=True)
    var_3 = cliargs_deferred_get(int_0, 'default-1139', True)

# Generated at 2022-06-24 18:36:15.968847
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == isinstance(cliargs_deferred_get(int(0), default='test'), (int, str))



# Generated at 2022-06-24 18:36:26.456686
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.config.manager import ConfigManager
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Note: CLIARGS is global and can be changed between unit tests so we need to ensure that
    # the global remains what it started as at the beginning of this test
    global CLIARGS
    original_cliargs = CLIARGS


# Generated at 2022-06-24 18:36:27.826707
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:36:29.559758
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)
    assert var_0() == {}



# Generated at 2022-06-24 18:36:31.964896
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)
    print(var_0)

# Generated at 2022-06-24 18:36:38.332976
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)
    int_1 = 2992
    var_1 = cliargs_deferred_get(int_1)
    var_2 = cliargs_deferred_get(int_0)
    var_3 = cliargs_deferred_get(int_0)


# Generated at 2022-06-24 18:36:44.454710
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    "Test cliargs_deferred_get()"
    assert callable(cliargs_deferred_get)
    # TODO: Lazy format needed
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-24 18:36:45.741067
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(2992) == None

# vim: pola

# Generated at 2022-06-24 18:36:47.494743
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)

# Generated at 2022-06-24 18:36:53.702898
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    print("Test cliargs_deferred_get()")
    test_case_0()
    print("*" * 40)
    return True

if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:36:58.004796
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Capture exceptions
    # Call the decorated function
    try:
        test_case_0()
    except Exception:
        # If an exception occurred, print the exception
        import sys
        print("Exception in test case 0:", file=sys.stderr)
        raise


test_cliargs_deferred_get.__test__ = False # so pytest doesn't collect this as a testcase

# Generated at 2022-06-24 18:36:59.699134
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('test') == None


# Generated at 2022-06-24 18:37:05.881675
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = CLIArgs({'bar': 'foo'})
    assert cli_args.get == cli_args.__getitem__
    assert cli_args.get('bar') == 'foo'
    #assert cliargs_deferred_get('bar')('foo') == 'foo'

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:07.291375
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-24 18:37:16.231071
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    d = {'key-int': 1, 'key-str': 'str-value'}
    cli_args = CLIArgs(d)
    f_inner = cliargs_deferred_get('key-int')
    assert f_inner() == 1
    f_inner = cliargs_deferred_get('key-str')
    assert f_inner() == 'str-value'
    f_inner = cliargs_deferred_get('key-none')
    assert f_inner() == None

# Execute unit tests.  When this is run standalone, __name__ will be __main__
if __name__ == '__main__':
    # Only run this test in unit test mode
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:21.728830
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    #
    # str_0 is a unicode string
    #
    str_0 = 'Test cliargs_deferred_get()'
    print('str_0:', str_0)
    bool_0 = CLIARGS.get('vault_password_file')
    print('bool_0:', bool_0)

#
# Call function test_case_0
#
test_case_0()

#
# Call function test_cliargs_deferred_get
#
test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:25.489332
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == True
    str_0 = 'Test cliargs_deferred_get(): This is not yet implemented'
    assert False == False

# Test this file with `python -m ansible.module_utils.common.context_objects`

# Generated at 2022-06-24 18:37:27.169607
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(test_case_0)

test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:35.969419
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'test_key': 'test_value'}
    _init_global_context(cli_args)

    result = cliargs_deferred_get('test_key')()
    assert result == 'test_value', 'Failed to get cli_args key test_key'

    result = cliargs_deferred_get('test_key', 'default_value')()
    assert result == 'test_value', 'Failed to get cli_args key test_key'

    result = cliargs_deferred_get('test_key2', 'default_value')()
    assert result == 'default_value', 'Failed to get cli_args key test_key'

# Generated at 2022-06-24 18:37:43.097880
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'Test cliargs_deferred_get()'

    # Test depth = 0
    result = cliargs_deferred_get(key=str_0, default=None, shallowcopy=False)
    assert result is not None

# Run tests
if __name__ == '__main__':
    test_cliargs_deferred_get()
    print('Test cliargs_deferred_get completed successfully!')

# Generated at 2022-06-24 18:37:48.893887
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Unit: default argument
    value_0 = cliargs_deferred_get('foo', default='bar')
    assert value_0() == 'bar'

    CLIARGS['foo'] = 1
    value_1 = cliargs_deferred_get('foo', default='bar')
    assert value_1() == 1

    # Unit: shallowcopy argument
    CLIARGS['foo'] = ['test']
    value_2 = cliargs_deferred_get('foo', shallowcopy=True)
    assert value_2() == ['test']

# Generated at 2022-06-24 18:37:58.364185
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    str_0 = 'Test cliargs_deferred_get()'

    # Setup
    cli_args = {}

    # Set up context
    _init_global_context(cli_args)

    # Test
    assert True is cliargs_deferred_get('check')()
    assert False is cliargs_deferred_get('check', False)()
    assert () is cliargs_deferred_get('diff')()
    assert () is cliargs_deferred_get('diff', ())()

    # Exit
    return str_0

if __name__ == "__main__":
    print(test_cliargs_deferred_get())

# Generated at 2022-06-24 18:38:03.467270
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'Test cliargs_deferred_get()'
    # print(str_0)
    try:
        assert str(cliargs_deferred_get)
        # print('pass')
        return
    except AssertionError:
        print(str_0 + ' AssertionError')
        return

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:05.657289
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print(test_cliargs_deferred_get.__doc__)

    test_case_0()



# Generated at 2022-06-24 18:38:16.678933
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    ###############################################################################
    # Unit test for function cliargs_deferred_get
    ###############################################################################
    print('TestCase: ' + str_0)
    print("Test function cliargs_deferred_get()")
    print("Pass" if True else "Fail")
    test_case_0()


if __name__ == '__main__':

    param = 1
    option = 1
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--cliargs", action = "store_true", dest = "cliargs", help = "show CLI args")
    args = parser.parse_args()

    if args.cliargs:
        test_cliargs_deferred_get()

# pylint: disable=redefined-builtin, unused-wildcard-import

# Generated at 2022-06-24 18:38:20.548959
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
    except:
        print("Failed to Test")

# Execute Test
#test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:21.848822
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(0)

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 18:38:29.466555
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Input parameters
    key0 = 'assemble'
    default0 = True
    shallowcopy0 = True

    # Call function
    # result = cliargs_deferred_get(key0, default0, shallowcopy0)

    # Output processing
    # assert result == None
    print(key0, default0, shallowcopy0)

if __name__ == '__main__':
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == 'test_cliargs_deferred_get':
        test_case_0()

    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:30.971288
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

# Unit tests for this module

# Generated at 2022-06-24 18:38:39.998213
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'Test cliargs_deferred_get()'
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get
    from ansible.utils.context_objects import _init_global_context
    from ansible.utils.context_objects import GlobalCLIArgs
    # Test default values
    result_0 = cliargs_deferred_get(key_0=None, default_0=None, shallowcopy_0=False)()
    # Test shallow copy

# Generated at 2022-06-24 18:38:42.311167
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get == 'Test cliargs_deferred_get'

# codetest: ignore

# Generated at 2022-06-24 18:38:43.763780
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the function and all its branch
    try:
        test_case_0()
    except:
        pass

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:47.907385
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        str_0 = 'Test cliargs_deferred_get()'
        assert 'Test cliargs_deferred_get()' == str_0
    except AssertionError:
        raise

if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-24 18:38:49.460131
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # function call at line number 31
    assert_equals('Test cliargs_deferred_get()', str_0)

# Generated at 2022-06-24 18:38:59.009737
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
    except Exception as e:
        print('Fail: test_case_0\n' + str(e))
    else:
        print('Pass: test_case_0')


import doctest
import traceback

# Plain text tests
test_text = r'''

TESTING
=======

>>> show_test = False
>>> test_text = 'short test_text'
>>> if show_test:
...    print(test_text)

>>> test_text = '''

# Generated at 2022-06-24 18:39:01.122301
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get('')

    # Test all types of return values (dict, [], () )


# Generated at 2022-06-24 18:39:06.364040
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    str_0 = 'Test cliargs_deferred_get()'
    ansible_module = mock.Mock()
    ansible_module.fail_json.return_value = {}
    cli_args = {'test_config': {}, 'smoke': False}
    _init_global_context(cli_args)
    ansible_module.fail_json.assert_not_called()

# Generated at 2022-06-24 18:39:07.119492
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()


# Generated at 2022-06-24 18:39:10.378872
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        from inspect import signature
        assert signature(cliargs_deferred_get).parameters.__len__() == 3
    except ValueError:
        pass
    else:
        test_case_0()
        str_0 = 'Test cliargs_deferred_get()'


# Generated at 2022-06-24 18:39:19.853559
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansiblelint import Runner, RulesCollection
    rulesdir = 'lib/ansiblelint/rules'
    runner = Runner(RulesCollection.create_from_directory(rulesdir), [], [], [])
    test_case_0()
    real_result = runner.run()
    expected_result = []
    assert real_result == expected_result

# Generated at 2022-06-24 18:39:20.994325
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:39:26.744294
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)
    assert type(var_0) is type(lambda: None)
    # Function execution
    var_1 = var_0()
    assert type(var_1) is type(b'')
    assert var_1 == b'y'

    # Function execution
    var_1 = var_0()
    assert type(var_1) is type(b'')
    assert var_1 == b'y'

# Generated at 2022-06-24 18:39:32.664799
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)
    try:
        assert var_0 is None
    except AssertionError:
        raise AssertionError(var_0)


# Generated at 2022-06-24 18:39:34.035216
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(int_0)
    return

# Generated at 2022-06-24 18:39:44.120520
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-24 18:39:45.448555
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert isinstance(cliargs_deferred_get, object)



# Generated at 2022-06-24 18:39:47.977171
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import inspect
    import types

    assert inspect.isclass(cliargs_deferred_get)
    assert inspect.isclass(cliargs_deferred_get())

    test_case_0()


# Generated at 2022-06-24 18:39:53.442871
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)
    try:
        assert var_0() == 0
    except AssertionError:
        raise AssertionError(var_0())


# Test module functionality if called directly
if __name__ == '__main__':
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:39:54.573089
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    t = test_case_0()
    assert t == 2992

# Generated at 2022-06-24 18:40:08.323247
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = 2992
    var_1 = cliargs_deferred_get(int_1)
    assert var_1 is not None
    assert var_1 is not False
    with pytest.raises(KeyError):
        assert var_1('not a key')

# Generated at 2022-06-24 18:40:10.998897
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get("key", default=None, shallowcopy=False)



# Generated at 2022-06-24 18:40:13.092405
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    key = None
    default = None
    shallowcopy = None
    result = cliargs_deferred_get(key, default, shallowcopy)
    assert result is None



# Generated at 2022-06-24 18:40:14.647921
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    assert cliargs_deferred_get(int_0) == None



# Generated at 2022-06-24 18:40:24.136527
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from unittest import TestCase
    from copy import copy
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    cli_args = CLIArgs({})
    cli_args['list_0'] = [1, 2, 3]
    cli_args['set_0'] = set([4, 5, 6])
    cli_args['dict_0'] = {'a': 7, 'b': 8}
    cli_args['int_0'] = 2992
    cli_args['obj_0'] = object()

    # List should return a shallow copy
    var_0 = cliargs_deferred_get('list_0')
    var

# Generated at 2022-06-24 18:40:33.027834
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {
        "module_path": "/usr/local/Cellar/ansible/devel/libexec/lib/python3.7/site-packages/ansible/modules",
        "module_name": "__future__",
        "module_args": "",
        "_ansible_version": "devel",
        "_ansible_sys_version": "3.7.2 (default, Jan 31 2019, 22:38:44) \n[Clang 10.0.0 (clang-1000.10.44.4)]",
        "_ansible_changelog_url": "https://github.com/ansible/ansible/blob/devel/changelogs/CHANGELOG-v2.8.rst",
        "_run_args": {"devel": "devel"}
    }


# Generated at 2022-06-24 18:40:38.698342
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = 2992

    # Call function
    int_1 = cliargs_deferred_get(int_1)
    # Verify the result
    assert int_1 == _init_global_context


if __name__ == '__main__':
    import pytest
    # The following line may be used to vary the set of executed tests;
    # for example pytest.main(['-k', 'test_read']) would just run the tests whose name contains 'read'
    # More about '-k': https://docs.pytest.org/en/latest/usage.html#cmdoption-k
    # More about command line options: https://docs.pytest.org/en/latest/usage.html
    pytest.main(['-s', __file__])

# Generated at 2022-06-24 18:40:46.398736
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert not cliargs_deferred_get('x')()
    cliargs = {
        'x': 1,
        'y': 1,
    }
    _init_global_context(cliargs)
    assert cliargs_deferred_get('x')() == 1
    assert cliargs_deferred_get('y')() == 1
    assert cliargs_deferred_get('z')() is None
    assert cliargs_deferred_get('z', default=0)() == 0
    assert cliargs_deferred_get('x', shallowcopy=True)() == 1
    assert cliargs_deferred_get('y', shallowcopy=True)() == 1


# Generated at 2022-06-24 18:40:53.646771
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Pull in tests to ensure the CLIARGS and cliargs_deferred_get are behaving sanely and
    # aren't doing anything out of the ordinary.  We do this because we're using this closure
    # in the FieldAttribute and we want to make sure it works before it gets used for something
    # that really needs to work
    from test.unit.module_utils.common.collections_tests import TestCLIArgsDeferredGet
    test_case_0()
    TestCLIArgsDeferredGet.test_cliargs_deferred_get()

# Generated at 2022-06-24 18:40:56.328919
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_1 = cliargs_deferred_get()
    str_1 = "test"
    int_1 = 2992
    assert int_1 == 2992
    assert str_1 == "test"

# Generated at 2022-06-24 18:41:18.103474
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)
    assert var_0() is None

# Generated at 2022-06-24 18:41:28.838194
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with defaults
    expected = cliargs_deferred_get(int, default=2992)
    actual = cliargs_deferred_get(int, default=2992)
    assert actual == expected
    assert type(actual) == type(expected)
    # Test with a direct key
    expected = cliargs_deferred_get('int', default=2992)
    actual = cliargs_deferred_get('int', default=2992)
    assert actual == expected
    assert type(actual) == type(expected)
    # Test with a direct key and explicit default
    expected = cliargs_deferred_get('int', 2992)
    actual = cliargs_deferred_get('int', 2992)
    assert actual == expected
    assert type(actual) == type(expected)
    expected = cl

# Generated at 2022-06-24 18:41:32.874240
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)

# Generated at 2022-06-24 18:41:34.573617
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get


# Generated at 2022-06-24 18:41:37.664438
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)
    assert var_0 is not None

test_case_0()

# Generated at 2022-06-24 18:41:41.015798
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = 2992
    var_1 = cliargs_deferred_get(int_1)


if __name__ == "__main__":
    pass
    # unit test
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:41:43.078942
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = {'ansible_verbosity': 1, 'vault_password': 'password'}
    _init_global_context(args)
    # FIXME: This test is not complete
    test_case_0()

# Generated at 2022-06-24 18:41:50.816860
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import collections

    int_0 = 8248
    var_0 = cliargs_deferred_get(int_0, None)
    # Call function 'cliargs_deferred_get'
    var_1 = var_0()
    var_2 = collections.OrderedDict()
    var_2[var_1] = var_1
    # Keep this assertion
    assert var_2


# Generated at 2022-06-24 18:41:58.622861
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import sys
    import datetime
    import types
    import random
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    # Setup test values
    argspec = dict()
    argspec['key'] = random.randint(0, sys.maxsize)
    if random.choice([True, False]):
        argspec['default'] = None
    else:
        argspec['default'] = random.randint(0, sys.maxsize)
    argspec['shallowcopy'] = random.choice([True, False])

    # Run the function
    try:
        retval = cliargs_deferred_get(**argspec)
    except BaseException:
        # If it throws an error
        assert False



# Generated at 2022-06-24 18:42:00.257594
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {0: 0}
    _init_global_context(cli_args)
    test_case_0()

# Generated at 2022-06-24 18:42:40.721442
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)



# Generated at 2022-06-24 18:42:41.482358
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True


# Generated at 2022-06-24 18:42:42.801054
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    assert callable(cliargs_deferred_get(int_0))



# Generated at 2022-06-24 18:42:46.303668
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    r'''Test for function cliargs_deferred_get
    Primarily for coverage'''
    # This function is for coverage testing only.  There's not really
    # a way to test the actual closure itself so we'll just call it
    # and make sure that it doesn't raise an exception
    test_case_0()



# Generated at 2022-06-24 18:42:50.239758
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    assert cliargs_deferred_get(0)() is None


# ansible-test compatibility layer
test_case_0()



# Generated at 2022-06-24 18:42:51.285090
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:42:59.399678
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)
    assert var_0 == 29


# Generated at 2022-06-24 18:43:03.606794
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)
    assert '_get' in repr(var_0)
    assert '_default' in repr(var_0)
    assert '_shallowcopy' in repr(var_0)

# Generated at 2022-06-24 18:43:09.672399
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    key = 'foo'
    default = 'bar'
    shallowcopy = True
    value = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)

if __name__ == '__main__':
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:43:15.443975
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    UUT = CLIARGS
    int_0 = 2992
    UUT.set(int_0, "msgs")
    var_0 = cliargs_deferred_get(int_0)
    assert(var_0 == "msgs")



# Test cases for function _init_global_context

# Generated at 2022-06-24 18:44:38.822217
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = 2992
    var_1 = cliargs_deferred_get(int_1)


# Generated at 2022-06-24 18:44:45.721202
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import sys, os
    import json

    fname = os.path.expanduser("~/.ansible/tmp/ansible-tmp-1570558855.27-96947019356719/AnsiballZ_test_case_0.py")
    with open(fname, 'r') as f:
        module_body = f.read()

    # create a dummy ansible module
    module = type(sys)('ansible_module')
    module.exit_json = exit_json
    module.fail_json = fail_json
    sys.modules["ansible_module"] = module

    # This hackery is needed because we are calling into an inner function
    # and don't want to add an actual ansible argument
    CLIARGS._options = {'extra_variable': 'ansible_ansible_variable'}

# Generated at 2022-06-24 18:44:50.125739
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = 2992
    var_0 = cliargs_deferred_get(int_1)
    var_1 = test_case_0()

    # AssertionError: assert 'var_0' == 'var_1'
    # - var_0: None
    # - var_1: None



# Generated at 2022-06-24 18:44:54.911119
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)



# Generated at 2022-06-24 18:44:57.137764
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)
    assert var_0() is None, \
        'var_0: expected %(expected)s, got %(actual)s' % {'expected': None, 'actual': var_0()}


# Generated at 2022-06-24 18:44:59.627566
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_0 = cliargs_deferred_get(int_0)
    assert var_0() == 2992


# Generated at 2022-06-24 18:45:00.724877
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_1 = 2992
    var_1 = cliargs_deferred_get(int_1)
    assert var_1() is None


# Generated at 2022-06-24 18:45:03.515737
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    int_0 = 2992
    var_1 = cliargs_deferred_get(int_0)
    # Check type of var_1
    assert isinstance(var_1, type(lambda:0))
    var_1()
    var_2 = cliargs_deferred_get(int_0)
    # Check type of var_2
    assert isinstance(var_2, type(lambda:0))
    var_2()

# Generated at 2022-06-24 18:45:12.884121
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(int_0) == var_0




from ansible.module_utils.common.collections import is_sequence, is_set, is_scalar
from ansible.module_utils.six import string_types, PY3
from ansible.module_utils.parsing.convert_bool import boolean
from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE


# from ansible.module_utils.common.text.asserts import assert_type_or_none, assert_type

# These are used to indicate what type of yaml tag is being used and how it should be
# expanded.  The tags fall into two categories:
#
# 1. They expand to scalars or scalar tuples
#

# Generated at 2022-06-24 18:45:13.376687
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass