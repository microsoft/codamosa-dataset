

# Generated at 2022-06-24 18:36:11.657735
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_0 = cliargs_deferred_get(bytes_0)



# Generated at 2022-06-24 18:36:20.692960
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_0 = cliargs_deferred_get(bytes_0)
    if ( var_0( ) is None ):
        print('test_cliargs_deferred_get ok')
    else:
        print('test_cliargs_deferred_get failed')



if __name__ == "__main__":
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:36:24.571564
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    val = cliargs_deferred_get('a', True)
    assert val() is True

    val = cliargs_deferred_get(b'\x1fXdX\x90\xf1\xf5\x95\xba', False)
    assert val() is False

# Generated at 2022-06-24 18:36:25.145528
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == True

# Generated at 2022-06-24 18:36:28.863287
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\xb9a\xacQ\xab\xbf\x7f\xec\x84'
    var_0 = cliargs_deferred_get(bytes_0)
    var_0()


# Generated at 2022-06-24 18:36:39.903779
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_0 = cliargs_deferred_get(bytes_0)
    bytes_1 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_1 = cliargs_deferred_get(bytes_1)
    _init_global_context(var_1)
    var_2 = var_0()
    assert type(var_2) == dict
    var_3 = var_1()
    assert var_3 == var_2
    bytes_2 = b'\x1fXdX\x90\xf1\xf5\x95\xba'

# Generated at 2022-06-24 18:36:41.791604
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    return cliargs_deferred_get(None, default=None, shallowcopy=False)

# Generated at 2022-06-24 18:36:44.640655
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = test_case_0()
    assert var_0 == '\x1fXdX\x90\xf1\xf5\x95\xba'

# Generated at 2022-06-24 18:36:45.995896
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # No setup or teardown needed
    pass




# Generated at 2022-06-24 18:36:47.353117
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:36:55.920129
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_0 = cliargs_deferred_get(bytes_0,b'\x1fXdX\x90\xf1\xf5\x95\xba' in bytes_0,b'\x1fXdX\x90\xf1\xf5\x95\xba' not in bytes_0)
    return globals()

# Generated at 2022-06-24 18:37:01.892420
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Set up test data
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    bytes_1 = b'Xp\xd0\x1d\xe5\xe2\x93\xcb\xceN\xac\xba\x93\x00\xc5\x0b\x86\xcf\x97tR'
    bytes_2 = b'\x06>\x9f\n\xf5\x95\xba'
    bytes_3 = b'^\xc7\xbb\xf9\xe9\xe6:.'

# Generated at 2022-06-24 18:37:09.421753
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test type of return value
    assert isinstance(cliargs_deferred_get(b'\x1fXdX\x90\xf1\xf5\x95\xba'), Callable)

    # Test repr
    assert repr(cliargs_deferred_get(b'\x1fXdX\x90\xf1\xf5\x95\xba')) == '<function cliargs_deferred_get.<locals>.inner at 0x7f41a6759bf8>'



# Generated at 2022-06-24 18:37:12.611502
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('--new-vault-password-file')() == '--new-vault-password-file'
    assert cliargs_deferred_get('--vault-password-file', default='--vault-password-file')() == '--vault-password-file'
    assert cliargs_deferred_get('--vault-password-file', shallowcopy=True)() == '--vault-password-file'

# Generated at 2022-06-24 18:37:16.148569
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_1 = b'\xc5\x98\xfd\x8c\xb1\x9d\xdd\xdb\r\xa7\xa5\x14\x0e'
    var_1 = cliargs_deferred_get(bytes_1)


# Generated at 2022-06-24 18:37:18.420600
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test case for cliargs_deferred_get
    cliargs_deferred_get(1, 2, 3)


if __name__ == "__main__":
    main()

# Generated at 2022-06-24 18:37:24.952865
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(b'\x1fXdX\x90\xf1\xf5\x95\xba') == b'\x1fXdX\x90\xf1\xf5\x95\xba', 'cliargs_deferred_get returned incorrect value'



# Generated at 2022-06-24 18:37:29.445813
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        CLIARGS = {}
        bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
        var_0 = cliargs_deferred_get(bytes_0)
        var_0()
    except NameError:
        assert False



# Generated at 2022-06-24 18:37:34.569304
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with valid arguments (the default for the default value of the
    # ``default`` param
    print("Testing cliargs_deferred_get() with valid arguments")
    test_case_0()
    # Test the normalization of the first argument (``key``)
    print("Testing normalization of the first argument (``key``)")

# Test function: cliargs_deferred_get

# Generated at 2022-06-24 18:37:38.167595
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_0 = cliargs_deferred_get(bytes_0)
    assert var_0 is not None


# Generated at 2022-06-24 18:37:48.092460
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    func_name = 'cliargs_deferred_get'
    print('\n')
    print('##### Begin Test of {}'.format(func_name))
    print('##### This test will raise an exception if there is a regression')

    test_case_0()
    print('##### End Test of {}'.format(func_name))

if __name__ == '__main__':
    test_cliargs_deferred_get()
    print('All tests completed')

# Generated at 2022-06-24 18:37:50.382370
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This will fail after once everything is cleaned up and we no longer defer
    # to cliargs_deferred_get.
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:37:54.011803
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_0 = cliargs_deferred_get(bytes_0)

# Generated at 2022-06-24 18:38:00.469359
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_0 = cliargs_deferred_get(bytes_0)
    # assert var_0() == reference_value_0()



# Generated at 2022-06-24 18:38:02.980409
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # 1
    expected_1 = cliargs_deferred_get(b'\x18\xac>\xea\x8f\x1f$<')
    actual_1 = 1
    assert actual_1 == expected_1


# Generated at 2022-06-24 18:38:04.859835
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setup fixture
    # Exercise function
    test_case_0()
    # Verify operation
    # Verify final state

# Generated at 2022-06-24 18:38:16.232263
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(0)
    assert callable(var_0)
    var_1 = cliargs_deferred_get(0, True)
    assert callable(var_1)
    var_2 = cliargs_deferred_get(0, True, True)
    assert callable(var_2)
    # This will not build from the command line as the initial CLIARGS is empty,
    # but it will run the tests in a Python repl
    var_3, var_4 = var_0(), var_1()
    assert var_3 is not None
    assert var_4 is not None
    assert var_1() == var_0()
    # This will not build from the command line as the initial CLIARGS is empty,
    # but it will run the tests in a Python

# Generated at 2022-06-24 18:38:19.174251
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get()
    assert cliargs_deferred_get()
    assert cliargs_deferred_get()


# Generated at 2022-06-24 18:38:22.192998
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = test_case_0()
    print(locals())
    assert var_0() is None

# Generated at 2022-06-24 18:38:29.061573
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    from ansible.module_utils.common.collections import cliargs_deferred_get
    assert cliargs_deferred_get(bytes_0) == {}
    assert cliargs_deferred_get(bytes_0) == {}
    assert cliargs_deferred_get(bytes_0) == {}
    assert cliargs_deferred_get(bytes_0) == {}
    assert cliargs_deferred_get(bytes_0) == {}
    assert cliargs_deferred_get(bytes_0) == {}
    assert cliargs_deferred_get(bytes_0) == {}
    assert cliargs_deferred_get(bytes_0) == {}
   

# Generated at 2022-06-24 18:38:39.642809
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass
    #assert cliargs_deferred_get(u'\U00039b57', False, False) == u'\U00039b57'



# Generated at 2022-06-24 18:38:45.948921
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS

    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_0 = CLIARGS.get(bytes_0, default=None)
    var_1 = cliargs_deferred_get(bytes_0)
    assert var_0 == var_1()

    bytes_1 = b'\xb6\x90\x94\xbd\x8b\x84\xb1`'
    int_0 = -1955118072
    var_2 = CLIARGS.get(bytes_1, default=None)
    var_3 = cliargs_deferred_get(bytes_1)
    assert var_2 == var_3() == int_0


# Generated at 2022-06-24 18:38:47.700094
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:38:48.232908
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True

# Generated at 2022-06-24 18:38:49.130315
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:38:52.921423
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(b'\x1fXdX\x90\xf1\xf5\x95\xba')(), 'test_cliargs_deferred_get:Assertion Failed'



# Generated at 2022-06-24 18:38:54.213413
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:38:56.192204
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(b'\x1fXdX\x90\xf1\xf5\x95\xba')

# Generated at 2022-06-24 18:39:03.775279
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert CLIARGS.get(b'\x1fXdX\x90\xf1\xf5\x95\xba', default=None) is None
    assert cliargs_deferred_get(b'\x1fXdX\x90\xf1\xf5\x95\xba')() is None

    cli_args_dict = {
        b'\x1fXdX\x90\xf1\xf5\x95\xba': 'test_string'
    }
    _init_global_context(cli_args_dict)

    assert CLIARGS.get(b'\x1fXdX\x90\xf1\xf5\x95\xba', default=None) == 'test_string'

# Generated at 2022-06-24 18:39:06.735545
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_0 = cliargs_deferred_get(bytes_0)
    assert var_0() == None


# Generated at 2022-06-24 18:39:30.105190
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with a key and no default
    cliargs_deferred_get(b'\x1fXdX\x90\xf1\xf5\x95\xba')
    # Test with a key and a default that is a sequence
    cliargs_deferred_get(b'\x1fXdX\x90\xf1\xf5\x95\xba', default=['\x1fXdX\x90\xf1\xf5\x95\xba', '\x1fXdX\x90\xf1\xf5\x95\xba', '\x1fXdX\x90\xf1\xf5\x95\xba'])
    # Test with a key, a default that is a sequence, and a shallowcopy
    cliargs_deferred_get

# Generated at 2022-06-24 18:39:36.910311
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # mock for cliargs_deferred_get
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    dict_0 = {bytes_0: "("}
    bytes_1 = b"\xa8\xfa\xcd\xa9\xca\xca\xea\x1a"
    dict_1 = {bytes_1: "\x7f"}
    dict_2 = {bytes_0: ")", bytes_1: "C"}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {bytes_1: 6, bytes_0: "\x7f"}
    dict_6 = {bytes_1: "\x7f"}

# Generated at 2022-06-24 18:39:40.191079
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Testing with defaults
    assert cliargs_deferred_get('foo', default='bar') == 'bar'
    assert cliargs_deferred_get('foo')('ham') == 'ham'

# unit tests go here

# Generated at 2022-06-24 18:39:49.279156
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\xb5\x97\xd1\x8f\x0e\x0f\x94\x8a'
    bytes_1 = b'\x91\xfd\xc1\x1b\xb2\xbf\x9a\xdd'
    bytes_2 = b'\x1a\xc7\x9d\x1c\xee\x10\xfb\xfc'
    bytes_3 = b'\x09\xd0\x01\xe7\xea\x03\x1a\xce'
    bytes_4 = b'\xc6\x86\x12U\xf0\x1a\xf1\xfb'

# Generated at 2022-06-24 18:39:51.907317
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# This is incomplete, so don't import it as part of the public API
__all__ = ()

# Generated at 2022-06-24 18:39:54.090760
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-24 18:39:57.902945
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_0 = cliargs_deferred_get(value = bytes_0, shallowcopy = True)
    assert var_0 == var_0

# Generated at 2022-06-24 18:39:58.749840
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get()


# Generated at 2022-06-24 18:40:06.047220
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import GlobalCLIArgs


# Generated at 2022-06-24 18:40:08.557525
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1f\x1f\x1f'
    print(cliargs_deferred_get(bytes_0)(), arg_0)

# Generated at 2022-06-24 18:40:48.326541
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    setattr(CLIARGS, '__call__', lambda: None)
    test_case_0()


# This should be called immediately after cli_args are processed (parsed, validated, and any
# normalization performed on them).  No other code should call it

# Generated at 2022-06-24 18:40:53.143532
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_0 = cliargs_deferred_get(bytes_0)
    # Uncomment the next line to view the value of var_0
    # print('var_0 is', repr(var_0))



# Generated at 2022-06-24 18:40:54.260253
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:40:55.721619
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get()

# Generate stubs for assert functions

# Generated at 2022-06-24 18:41:05.859182
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_0 = cliargs_deferred_get(bytes_0)
    # Test the inner function is returned
    assert callable(var_0)

    # Test it works at all
    CLIARGS[bytes_0] = b'pass!'
    var_1 = var_0()
    assert var_1 == b'pass!'
    CLIARGS[bytes_0] = b'fail!'
    var_1 = var_0()
    assert var_1 == b'pass!'

    # Test the default value
    bytes_1 = b'\xb4\xcbJ\x14\x1c\xef\xa0\xdd'
    var_2 = cliargs_deferred

# Generated at 2022-06-24 18:41:11.434282
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_0 = cliargs_deferred_get(bytes_0)()
    assert var_0 == CLIARGS.get(bytes_0, default=None), "Failed to call function cliargs_deferred_get with arguments: ({} , )"
    #assert var_0 == var_0, "Failed to call function cliargs_deferred_get with arguments: ({} , )"

# Generated at 2022-06-24 18:41:16.090690
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(u'\x1f\x18\xdc\x7f\xcf\xb9\x1f\x81')() is None
    func_b = cliargs_deferred_get('b')
    assert func_b() is None
    func_z = cliargs_deferred_get(u'z', default=u'\x03\xe8\x04\x19')
    assert func_z() == u'\x03\xe8\x04\x19'
    func_c = cliargs_deferred_get(u'c')
    assert func_c() is None
    func_z = cliargs_deferred_get(u'z', default=u'\x03\xe8\x04\x19')
    assert func_z

# Generated at 2022-06-24 18:41:20.796603
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(b'\x1fXdX\x90\xf1\xf5\x95\xba')


# Generated at 2022-06-24 18:41:30.721127
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-24 18:41:36.097862
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import shutil
    import os
    import tempfile
    def call_function_0():
        assert cliargs_deferred_get('XcXZ', 'FO0', False) == 'FO0'

    def call_function_1():
        assert cliargs_deferred_get('FO1', 'FO1', False) == 'FO1'

    def call_function_2():
        assert cliargs_deferred_get('FO2', 'FO2', False) == 'FO2'

    def call_function_3():
        assert cliargs_deferred_get('FO3', 'FO3', False) == 'FO3'

    def cleanup_function():
        # Do your cleanup here.  This gets called even if there is an exception
        assert True

# Generated at 2022-06-24 18:42:52.416310
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This will probably fail with KeyError, though...
    var_0 = cliargs_deferred_get(0)
    assert var_0 == None


# Generated at 2022-06-24 18:42:59.401711
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(bytes([31, 88, 100, 88, 144, 241, 245, 149, 186]), default=None, shallowcopy=False)


# Generated at 2022-06-24 18:43:07.864148
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_1 = cliargs_deferred_get(var_0, None, False)
    var_2 = cliargs_deferred_get(var_0, None, False)
    var_3 = cliargs_deferred_get(var_0, None, False)
    var_4 = cliargs_deferred_get(var_0, None, False)
    var_5 = cliargs_deferred_get(var_0, None, False)
    var_6 = cliargs_deferred_get(var_0, None, False)
    var_7 = cliargs_deferred_get(var_0, None, False)
    var_8 = cli

# Generated at 2022-06-24 18:43:16.303531
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_1 = cliargs_deferred_get('p_string')
    assert var_1()
    CLIARGS.p_string = var_0
    assert var_1() == var_0
    CLIARGS.p_string = var_0
    assert var_1() == var_0
    CLIARGS.p_string = var_0
    assert var_1() == var_0
    CLIARGS.p_string = var_0
    assert var_1() == var_0
    CLIARGS.p_string = var_0
    assert var_1() == var_0
    CLIARGS.p_string = var_0
    assert var_1() == var_0
    CLIARGS.p_string = var_0
    assert var_1() == var_0

# Generated at 2022-06-24 18:43:20.065999
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    with patch.object(CLIARGS, 'get') as mock_get:
        mock_get.return_value = 'foo'
        assert cliargs_deferred_get('bar')() == 'foo'
        mock_get.assert_called_once_with('bar')


# Generated at 2022-06-24 18:43:23.184994
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = CLIArgs({b'\x1fXdX\x90\xf1\xf5\x95\xba': 'var_0'})
    _init_global_context(cli_args)
    test_case_0()


if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:43:24.320159
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
        return True
    except Exception:
        return False

# Generated at 2022-06-24 18:43:26.427189
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    var_0 = cliargs_deferred_get(bytes_0)

# vim: set ft=python et ts=4 sw=4 :

# Generated at 2022-06-24 18:43:28.445480
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert test_case_0() == True



# Utilities for creating custom components for the global context that can be used in tasks
# or filters

# Generated at 2022-06-24 18:43:31.003810
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x1fXdX\x90\xf1\xf5\x95\xba'
    assert callable(cliargs_deferred_get(bytes_0))
