

# Generated at 2022-06-24 18:36:06.835471
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get()



# Generated at 2022-06-24 18:36:07.781839
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == True


# Generated at 2022-06-24 18:36:10.838410
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    try:
        test_case_0()
    except NameError:
        pass

if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:36:16.615717
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)


# Generated at 2022-06-24 18:36:20.292971
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)
    assert var_0() == None


# Generated at 2022-06-24 18:36:31.023098
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with the default arguments
    assert cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2') == None

    # Test with shallow copy of list
    assert cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2', shallowcopy=True) == []

    # Test with shallow copy of mapping
    assert cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2', shallowcopy=True) == {}

    # Test with shallow copy of set
    assert cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2', shallowcopy=True) == set()

# Generated at 2022-06-24 18:36:41.359146
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'

# Generated at 2022-06-24 18:36:45.396840
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

if __name__ == '__main__':
    import pytest
    # --durations=10  -s -v
    pytest.main(['-x', "test_context_manager.py", '-s', '-v'])

# Generated at 2022-06-24 18:36:52.180819
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Verify behavior when a key is not found
    assert cliargs_deferred_get(b'\x33\x7f\x95\x90\x18\x86 j\xaa')() is None
    # Test that defaults work
    assert cliargs_deferred_get(b'\xcc\xdc\xf4\xfe\x14\x91\xc1\x11', b'\x1a\x88\xd6\xdb\x971\xda\xee\xad')() == b'\x1a\x88\xd6\xdb\x971\xda\xee\xad'

    # Test that shallow copies work

# Generated at 2022-06-24 18:36:57.440347
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)
    print("Type of the object: {0}.".format(type(var_0)))
    print("Value of the object: {0}.".format(var_0))
    print("Id of the object: {0}.".format(id(var_0)))




# Generated at 2022-06-24 18:37:02.768502
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    test_case_0()

# Using a different name to minimize conflicts with the decorator

# Generated at 2022-06-24 18:37:05.231178
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Call function
    result = cliargs_deferred_get(var_0)

    # Assertions
    assert result == None



# Generated at 2022-06-24 18:37:07.365391
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This test case definition is a work-in-progress
    try:
        test_case_0()
    except Exception:
        # This is an expected exception
        pass
    else:
        # More code than expected was executed before an exception was raised.
        # This is an unexpected exception.
        raise Exception



# Generated at 2022-06-24 18:37:08.767778
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    with pytest.raises(ValueError):
        cliargs_deferred_get()

# vim: set noet ts=4 sw=4 ft=python :

# Generated at 2022-06-24 18:37:12.491672
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2')
    assert cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2')


# Generated at 2022-06-24 18:37:15.389586
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = bytes([156])
    var_0 = cliargs_deferred_get(bytes_0)


if __name__ == '__main__':
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:22.978940
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)
    assert type(var_0) is type(cliargs_deferred_get)

    bytes_1 = b'\x99\x1e\x8a \xfal\t\xc2\x8f\x99\xbd\x97\xf4\x16\x06\xfd\x9c\x9b\xc3\xfd\xac\xda\x14\xd2\x99\xdb\x9b\xf5'
    var_1 = cliargs_deferred_get(bytes_1)
    assert type(var_1) is type(cliargs_deferred_get)

   

# Generated at 2022-06-24 18:37:25.765685
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """
    Test case for the ``cliargs_deferred_get`` function defined in :mod:`ansible.utils.context_objects`.

    This is a Mocking Test.
    """

    test_case_0()

# Generated at 2022-06-24 18:37:26.746535
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()


# Generated at 2022-06-24 18:37:36.761618
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils._text import to_text
    cli_args = dict(
        collection_playbooks=['test1.yaml', 'test2.yaml'],
        collection_roles=['test1.yaml', 'test2.yaml'],
    )
    _init_global_context(cli_args)
    assert CLIARGS.collection_playbooks == ['test1.yaml', 'test2.yaml']
    assert CLIARGS.get('collection_playbooks') == ['test1.yaml', 'test2.yaml']
    assert CLIARGS.collection_roles == ['test1.yaml', 'test2.yaml']
    assert CLIARGS.get('collection_roles') == ['test1.yaml', 'test2.yaml']

    func = cli

# Generated at 2022-06-24 18:37:45.316539
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {b'\x99\x1e\x8a \xfal\t\xc2': b'\x99\x1e\x8a \xfal\t\xc2'}
    _init_global_context(cli_args)
    assert not cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2')

# Generated at 2022-06-24 18:37:55.798679
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_1 = b'\xbd\xf0\x1f\x08\x04Pv\xd9\x8a\xd3\xc3\xb5\x11\x8b\xef\x1f'
    str_1 = '\xbd\xf0\x1f\x08\x04Pv\xd9\x8a\xd3\xc3\xb5\x11\x8b\xef\x1f\xfd\x18\x98\x15\x0f\xa3\xc3\xaa\x17'

# Generated at 2022-06-24 18:38:00.579368
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Start of Python3 test
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)
    # End of Python3 test


# Generated at 2022-06-24 18:38:02.823085
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)


# Generated at 2022-06-24 18:38:05.757908
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        assert cliargs_deferred_get()
    except AssertionError:
        assert False, "Raise AssertionError"



# Generated at 2022-06-24 18:38:08.487260
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)

# Generated at 2022-06-24 18:38:10.026109
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()



# Generated at 2022-06-24 18:38:19.361482
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    bytes_1 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_1 = cliargs_deferred_get(bytes_1, default=None, shallowcopy=False)
    assert var_1() is None
    CLIARGS[bytes_1] = u'\u2e2f\u5ba5\u8d77\u15de\u9a9e\u0cc2'
    assert var_1() == u'\u2e2f\u5ba5\u8d77\u15de\u9a9e\u0cc2'


# Generated at 2022-06-24 18:38:28.879677
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'

    var_0 = cliargs_deferred_get(bytes_0)

    assert var_0 == cliargs_deferred_get(bytes_0)

    var_1 = cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2')

    assert var_1 == cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2')

    assert var_0 == var_1



# Generated at 2022-06-24 18:38:37.705004
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cmd = 'ansible-playbook test_playbook.yml -i inventory some_host --list-tasks --extra-vars my_var=some_val --private-key=test_private_key_file -vvvv'

    argv = cmd.split()[1:]
    assert argv[0] == 'test_playbook.yml'
    assert argv[1] == '-i'
    assert argv[2] == 'inventory'
    assert argv[3] == 'some_host'
    assert argv[4] == '--list-tasks'
    assert argv[5] == '--extra-vars'
    assert argv[6] == 'my_var=some_val'
    assert argv[7] == '--private-key'

# Generated at 2022-06-24 18:38:47.169151
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert var_0() in [None, 'you', 'there', 'you.']

# Generated at 2022-06-24 18:38:52.964541
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    res_0 = cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2', 4189779146)
    ans_0 = u"^\x9a\xee\x87h\xd4\x1f\x88\xa7S\xe4"
    assert res_0 == ans_0, error(test_case_0)

test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:54.951766
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# -- END # Unit tests for function cliargs_deferred_get

# Generated at 2022-06-24 18:38:56.427913
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)

# Generated at 2022-06-24 18:39:01.302742
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x0b\x19\xa0\x14\x91\x9f\xe0\xf1\x9e\x1d\x8f'
    var_0 = cliargs_deferred_get(bytes_0)

# Generated at 2022-06-24 18:39:01.858503
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass # Stub

# Generated at 2022-06-24 18:39:05.317427
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert isinstance(cliargs_deferred_get(b'%\xad\xda\xeb\x00RB\xa4\x16\xf7'),
                       lambda: None)


# Generated at 2022-06-24 18:39:12.707626
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-24 18:39:14.186864
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-24 18:39:16.440770
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
    except (TypeError, ValueError, AttributeError, ImportError, NameError):
        raise AssertionError()

# Generated at 2022-06-24 18:39:34.289147
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)
    assert cliargs_deferred_get(bytes_0) is not var_0


# Generated at 2022-06-24 18:39:40.319673
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'_\xac\xe0\x86\xdd\x19'
    var_0 = cliargs_deferred_get(bytes_0)
    if not var_0():
        return False
    var_1 = cliargs_deferred_get(bytes_0, default=b'\x1d\x8c\x83\x98\xeb\xc5', shallowcopy=True)
    return not var_1()



# Generated at 2022-06-24 18:39:41.031936
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:39:49.937754
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.validation import check_type_str

    # TODO: look for a way to define an unmocked Template to test this
    # check_type_str(u'after', u'bef\xe0re')
    # check_type_str(u'after', b'bef\xe0re')
    # check_type_str(u'after', cliargs_deferred_get(bytes_1))
    try:
        # This is NOT a valid test since the order of the bytes may be different
        # in Python 2 vs Python 3.  Trailing \x00's are dropped.
        check_type_str(u'after', b'bef\xe0re\x00\x00\x00\x00')
    except:
        pass

# Generated at 2022-06-24 18:39:51.105819
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == True  # TODO: Implement your test here



# Generated at 2022-06-24 18:40:00.719008
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_1 = cliargs_deferred_get(b'\xdb\xdc(N\xab\x8d\x93')
    var_1.rstrip(b'\x0c\xdd\xcf\x98\x7f\xe9\xc0\x99')
    var_1.rstrip(b'\x0c\xdd\xcf\x98\x7f\xe9\xc0\x99')
    var_1.rstrip(b'\x0c\xdd\xcf\x98\x7f\xe9\xc0\x99')
    var_1.rstrip(b'\x0c\xdd\xcf\x98\x7f\xe9\xc0\x99')

# Generated at 2022-06-24 18:40:05.016733
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2')() is None
    # Called with final kwarg
    assert cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2', default='e')() == 'e'


if __name__ == '__main__':
    pass

# Generated at 2022-06-24 18:40:12.755402
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\t\x13\x84\x18\x00\x98\xf5\x18'
    bool_0 = bool(b'\x00\x1eK\xab\xfc')
    str_0 = str(bytearray([ord(c) for c in 'b']))
    str_1 = str(chr(ord('\x1f')))
    print("%s %s %s %s" % (bytes_0, bool_0, str_0,str_1))
    var_0 = cliargs_deferred_get(bytes_0)
    print("%s" % var_0)

# Generated at 2022-06-24 18:40:19.746149
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This is testing a deferred get, which is just a python
    # closure.  Instead, we'll just force an immediate get and then
    # reset the global to not break tests that depend on the
    # operation of cliargs deferred get
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)
    var_0 = var_0()
    test_case_0()

# Generated at 2022-06-24 18:40:26.238854
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils._text import to_text
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    # Set up mock objects
    cli_args = MagicMock()
    expected_result = 'expected_result'

    # Set up the mock objects
    cli_args.__getitem__.return_value = expected_result

    # Call the function under test
    result = cliargs_deferred_get('my_key', cli_args=cli_args, shallowcopy=True)

    # Ensure that the function under test made all of the expected calls
    assert result() == expected_result
    assert cli_args.__getitem__.call_count == 1


if __name__ == '__main__':
    pass

# Generated at 2022-06-24 18:41:01.216800
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)
    assert var_0() is None

# Generated at 2022-06-24 18:41:03.650884
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
    except AssertionError:
        raise AssertionError()

# vim: ts=4 sw=4 expandtab

# Generated at 2022-06-24 18:41:11.844549
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)

    # Test with bytes
    _init_global_context({bytes_0: b'\x87\xf3c\xb4\x9b\x14F\x12'})
    assert var_0() == b'\x87\xf3c\xb4\x9b\x14F\x12'

    # Test with int
    _init_global_context({bytes_0: -9})
    assert var_0() == -9

    # Test with text

# Generated at 2022-06-24 18:41:13.802249
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)



# Generated at 2022-06-24 18:41:21.271517
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'e\xbc\xc3\xbe\xe2h\x8c\x05\x1f\xa4\x9b\x80\x15\x0f'
    bytes_1 = b'\xd6\x9a\xd1\x84\xdc\x8e\xdb\xc77\x83'
    assert callable(cliargs_deferred_get)
    assert callable(cliargs_deferred_get(bytes_0))
    assert isinstance(cliargs_deferred_get(bytes_1), (type(None), type(0)))

# Generated at 2022-06-24 18:41:24.585054
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)
    var_1 = cliargs_deferred_get(bytes_0)



# Generated at 2022-06-24 18:41:29.213258
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        cliargs_deferred_get(0)
    except TypeError as e:
        assert False, "Exception: {}".format(e)
    else:
        pass
# <<< W0223(unused-variable)


# >>> W0223(unused-variable)

# Generated at 2022-06-24 18:41:34.672430
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)

# Generated at 2022-06-24 18:41:36.289112
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # This test script is just to get 100% test coverage
    raise Exception

# Generated at 2022-06-24 18:41:39.500788
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        # Test the function.
        # Not using assert
        test_case_0()
    except:
        print("\n*** test_cliargs_deferred_get failed ***")
        raise

# Generated at 2022-06-24 18:42:48.719817
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:42:59.520280
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2')
    assert callable(var_0)

    var_1 = cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2', b'\x99\x1e\x8a \xfal\t\xc2')
    assert callable(var_1)

    var_2 = cliargs_deferred_get(b'\x99\x1e\x8a \xfal\t\xc2', b'\x99\x1e\x8a \xfal\t\xc2', True)
    assert callable(var_2)



# Generated at 2022-06-24 18:43:03.717395
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)
    assert CLIARGS.get(var_0) is None


# Generated at 2022-06-24 18:43:13.189433
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_2 = bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    def test_case_0():
        bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
        var_0 = cliargs_deferred_get(bytes_0)
    # Testing: Closure over getting a key from CLIARGS with shallow copy functionality
    test_case_0()



# Generated at 2022-06-24 18:43:16.854347
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)
    print(var_0)

if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:43:20.535412
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)
    assert var_0 == bytes_0

test_case_0()
test_cliargs_deferred_get()

# Generated at 2022-06-24 18:43:26.270243
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Replace the value of CLIARGS for the testing func
    global CLIARGS
    CLIARGS = CLIArgs({b'foo': 'bar', b'bar': [1, 2, 3]})
    assert cliargs_deferred_get(b'foo')() == 'bar'
    assert cliargs_deferred_get(b'bar', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get(b'bar', shallowcopy=False)() == [1, 2, 3]
    assert cliargs_deferred_get(b'baz')() is None


test_case_0()
test_cliargs_deferred_get()

# Generated at 2022-06-24 18:43:27.143111
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()



# Generated at 2022-06-24 18:43:28.487318
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True # TODO: implement your test here


# Generated at 2022-06-24 18:43:29.133543
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:45:58.942804
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bytes_0 = b'\x99\x1e\x8a \xfal\t\xc2'
    var_0 = cliargs_deferred_get(bytes_0)
    assert var_0() == None


# Generated at 2022-06-24 18:46:00.966195
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        assert _init_global_context(None) == True
        test_case_0()
    except Exception as exception:
        print('Exception: ', exception)


# Generated at 2022-06-24 18:46:02.154956
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True # TODO: implement your test here
