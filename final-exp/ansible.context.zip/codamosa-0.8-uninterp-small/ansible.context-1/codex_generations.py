

# Generated at 2022-06-24 18:36:17.644740
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    bool_1 = bool_0
    bool_2 = bool_1
    bool_3 = bool_2
    bool_4 = bool_3
    bool_5 = bool_4
    bool_6 = bool_5
    bool_7 = bool_6
    bool_8 = bool_7
    bool_9 = bool_8
    bool_10 = bool_9
    bool_11 = bool_10
    bool_12 = bool_11
    bool_13 = bool_12
    bool_14 = bool_13
    bool_15 = bool_14
    bool_16 = bool_15
    bool_17 = bool_16
    bool_18 = bool_17
    bool_19 = bool_18
    bool_20 = bool_19
    bool_21 = bool_20
    bool_

# Generated at 2022-06-24 18:36:21.057070
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)
    assert var_0 is not bool_0



# Generated at 2022-06-24 18:36:22.362368
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    actual = True
    expected = True
    assert actual == expected


# Generated at 2022-06-24 18:36:24.136998
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)
    assert var_0() == True

# Generated at 2022-06-24 18:36:28.188835
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get("ansible_hosts") == None
    assert cliargs_deferred_get("ansible_hosts", "DEFAULT") == "DEFAULT"
    assert cliargs_deferred_get("ansible_hosts") == "DEFAULT"

# Generated at 2022-06-24 18:36:34.423507
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Init global context
    global CLIARGS

    CLIARGS = CLIArgs({})

    ansible_args = {'verbosity': 2,
                    'no_log': True,
                    'connection': 'local'}

    _init_global_context(ansible_args)
    assert CLIARGS.get('verbosity') == 2
    assert CLIARGS.get('no_log')
    assert CLIARGS.get('connection') == 'local'

# Generated at 2022-06-24 18:36:35.271084
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True

# Generated at 2022-06-24 18:36:39.812539
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)
    assert not var_0()

# Generated at 2022-06-24 18:36:41.016819
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert False, "Test not implemented"


# Generated at 2022-06-24 18:36:42.338378
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == True


# Generated at 2022-06-24 18:36:52.525058
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(None)
    assert cliargs_deferred_get(False)
    assert cliargs_deferred_get([])
    assert cliargs_deferred_get({})
    assert cliargs_deferred_get(set())

# Generated at 2022-06-24 18:36:54.629468
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get()
    with pytest.raises(TypeError):
        cliargs_deferred_get(None)

# Generated at 2022-06-24 18:36:57.515426
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    import __builtin__ as builtins

    # Save off original builtins
    builtins_save = builtins._

# Generated at 2022-06-24 18:37:00.242060
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var = CLIARGS

    var_0 = var.get('test_case_0', cliargs_deferred_get(bool_0))

    assert (var_0 == True)

# Generated at 2022-06-24 18:37:02.816172
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    # Test function is callable
    assert callable(cliargs_deferred_get)


# Generated at 2022-06-24 18:37:13.299631
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""

    fixture_value = [
        (
            (
                True,
            ),
            None,
        ),
    ]

    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import MagicMock, patch
    from ansible_collections.ansible.netcommon.tests.unit.modules.utils import set_module_args
    from ansible.module_utils.common._collections_compat import Mapping

    results = []

# Generated at 2022-06-24 18:37:16.159065
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        assert cliargs_deferred_get(True, default=1) == 1
    except TypeError:
        print("Function cliargs_deferred_get raised a TypeError exception. The exception is:")
        print(sys.exc_info()[1])
        return



# Generated at 2022-06-24 18:37:16.710577
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == True

# Generated at 2022-06-24 18:37:23.136013
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True
# -*- -*- -*- End included fragment: lib/ansible/utils/context_objects.py -*- -*- -*-


# -*- -*- -*- Begin included fragment: lib/ansible/module_utils/basic.py -*- -*- -*-
#
# (c) 2012-2018 Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
#

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DEFAULT_STDOUT_JSON_FORMAT = 'friendly'



# Generated at 2022-06-24 18:37:25.806656
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Replace the system under test and assert that the answer
    # to life, the universe, and everything is correct.
    from ansible.utils.context_objects import cliargs_deferred_get as Sut
    assert Sut == 42

# Generated at 2022-06-24 18:37:30.478775
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:37:32.430675
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)
    assert var_0 == True

# Generated at 2022-06-24 18:37:33.980365
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert False, "Test case not implemented"


# Generated at 2022-06-24 18:37:38.653343
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_1 = False
    var_1 = cliargs_deferred_get(bool_1)
    var_2 = str(var_1)
    assert var_2 == "<bound method cliargs_deferred_get.inner of <function cliargs_deferred_get.<locals>.inner at 0x7f85c3b73bf8>>"




# Generated at 2022-06-24 18:37:40.330013
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get()
    var_0()
    print(var_0)

# Generated at 2022-06-24 18:37:42.155907
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)
    assert not var_0

# Generated at 2022-06-24 18:37:44.885412
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        # First test case
        test_case_0()
        pass
    except:
        import traceback

        print(traceback.format_exc())


if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:48.149243
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)



# Generated at 2022-06-24 18:37:50.420684
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)
    assert var_0 is not None


# Generated at 2022-06-24 18:37:53.839368
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = {}
    args['bool_0'] = True
    bool_0 = args['bool_0']
    var_0 = cliargs_deferred_get(bool_0)
    print(var_0)

# Generated at 2022-06-24 18:38:04.912556
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)
    assert var_0 == bool_0



# Generated at 2022-06-24 18:38:08.623662
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)
    bool_1 = True
    var_1 = cliargs_deferred_get(bool_1, bool_1)

# Generated at 2022-06-24 18:38:18.045791
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cnt = 0
    while 1:
        n = random.randint(0, len(test_list) - 1)
        if test_list[n] != 'stdout':
            break
    print("Iteration: "+str(n))
    print("Executing function cliargs_deferred_get")

    try:
        my_closure = cliargs_deferred_get(test_list[n])
        if my_closure is None:
            print("Error -- Function cliargs_deferred_get returned None")
            return

    except SystemExit:
        print("Exception caught")
        return

if __name__ == '__main__':
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:22.149556
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_1 = True
    var_1 = cliargs_deferred_get(bool_1)

# Generated at 2022-06-24 18:38:23.717096
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)

# Generated at 2022-06-24 18:38:25.264072
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get('key')
    var_0()



# Generated at 2022-06-24 18:38:27.672306
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Setting up test values
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)
    # Testing function
    assert var_0 == None


if __name__ == '__main__':
    pass

# Generated at 2022-06-24 18:38:31.527132
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'bool_0': True}
    _init_global_context(cli_args)
    bool_0 = True
    var_0_1 = cliargs_deferred_get(bool_0)
    var_0_2 = cliargs_deferred_get(bool_0)
    var_0_3 = cliargs_deferred_get(bool_0, default='x')
    assert var_0_1() == True
    assert var_0_2() == True
    assert var_0_3() == 'x'


# Generated at 2022-06-24 18:38:32.677846
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # assert callable(cliargs_deferred_get)
    cliargs_deferred_get()



# Generated at 2022-06-24 18:38:33.735417
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == True
    # Replace following line with your actual test.
    assert False



# Generated at 2022-06-24 18:38:53.007620
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    assert cliargs_deferred_get(bool_0)()
    assert cliargs_deferred_get(bool_0, shallowcopy=True)()


# Generated at 2022-06-24 18:38:54.643456
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)

# Generated at 2022-06-24 18:39:01.352659
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert set() == set(locals().keys())
    assert set() == set(globals().keys())


# Generated at 2022-06-24 18:39:02.568878
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(bool_0) == var_0

# Generated at 2022-06-24 18:39:03.012946
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:39:07.014646
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)


# Generated at 2022-06-24 18:39:10.060725
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    str_0 = 'n'
    cliargs_deferred_get(bool_0)
    cliargs_deferred_get(str_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 18:39:13.800332
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'bool_0': True}
    _init_global_context(cli_args)
    bool_0 = True
    var_0 = bool_0
    assert var_0
    var_0 = cliargs_deferred_get(bool_0)
    assert var_0

# Generated at 2022-06-24 18:39:16.124368
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cmd = ansible.module_utils.common.context_objects.CliArgs()
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)

# Generated at 2022-06-24 18:39:19.531619
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    var_0 = cliargs_deferred_get(bool_0)
    assert var_0 == None




# Generated at 2022-06-24 18:40:01.308133
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    #
    # Ensure that the closure preserves the default value
    #
    def test_case_1():
        var_0 = cliargs_deferred_get('test')
        assert var_0() == None
        var_1 = cliargs_deferred_get('test', default='test')
        assert var_1() == 'test'

    test_case_1()
    #
    # Ensure that the closure preserves shallowcopy
    #
    def test_case_2():
        var_0 = cliargs_deferred_get('test', shallowcopy=True)
        assert var_0() == None
        var_1 = cliargs_deferred_get('test', default='test', shallowcopy=True)
        assert var_1() == 'test'

# Generated at 2022-06-24 18:40:02.331239
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get()



# Generated at 2022-06-24 18:40:03.497260
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    from ansible.playbook.play_context import PlayContext

    test_case_0()

# Generated at 2022-06-24 18:40:06.614458
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(bool_0) == inner()


# Generated at 2022-06-24 18:40:10.464867
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args_0 = {'foo': 'xyzzy', 'n': 5}
    args_1 = {'foo': 'xyzzy', 'n': 5}
    _init_global_context(args_0)
    assert cliargs_deferred_get('n') == 5
    cliargs_deferred_get('n', shallowcopy=True) == 5

# Generated at 2022-06-24 18:40:12.154366
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
    except NameError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 18:40:13.878448
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)
    assert var_0() == True

# Generated at 2022-06-24 18:40:17.275497
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    if True:
        print('BEGIN TEST: cliargs_deferred_get')
        test_case_0()
        print('END TEST: cliargs_deferred_get')

# Generated at 2022-06-24 18:40:18.665799
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(bool_0)

# Generated at 2022-06-24 18:40:20.209017
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert type(test_case_0()) == bool

# Generated at 2022-06-24 18:41:30.461439
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = None

    # Call function 'cliargs_deferred_get'
    var_0 = cliargs_deferred_get(bool_0)
    assert var_0 is not None
    assert type(var_0) is bool


# Generated at 2022-06-24 18:41:42.617613
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.config.manager import ConfigManager
    from ansible.config.ansible_config import AnsibleConfig

    config_manager = ConfigManager()
    config_manager.load()
    config = config_manager.get_config()
    args = AnsibleConfig(config)
    args = {'nocolor': False, 'force_color': False, 'debug': True}
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        args['inventory'] = '{}/hosts'.format(temp_dir)
        args['listhosts'] = True
        with open(args['inventory'], 'w') as f:
            f.write('''
[fake_group]
localhost
''')
        _init_global_context(args)

# Generated at 2022-06-24 18:41:46.464856
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)

# Generated at 2022-06-24 18:41:47.152667
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True == True

# Generated at 2022-06-24 18:41:51.909888
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        test_case_0()
    except NameError as e:
        assert False, "Unable to call cliargs_deferred_get"
    except Exception as e:
        assert False, "Unexpected exception raised when calling cliargs_deferred_get: {}".format(str(e))

# Generated at 2022-06-24 18:42:01.541952
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['var_0'] = "abcd"
    assert cliargs_deferred_get('var_0')() == "abcd"
    assert cliargs_deferred_get('var_1')() is None
    assert cliargs_deferred_get('var_1', 'default')() == 'default'
    assert cliargs_deferred_get('var_2', False)() is False
    assert cliargs_deferred_get('var_2', 'default')() == 'default'
    CLIARGS['var_3'] = ['a', 'b', 'c', 'd']
    assert cliargs_deferred_get('var_3')() == ['a', 'b', 'c', 'd']
    assert cliargs_deferred_get('var_3', shallowcopy=True)()

# Generated at 2022-06-24 18:42:02.065306
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:42:03.152538
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get(bool_0) == None



# Generated at 2022-06-24 18:42:09.434788
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = ['--connection=local']
    _init_global_context(args)
    assert(CLIARGS['connection'] == 'local')
    assert(CLIARGS.get('connection') == 'local')

    func = cliargs_deferred_get('connection', default=None, shallowcopy=False)
    assert(func() == 'local')
    func = cliargs_deferred_get('connection', default='blah', shallowcopy=False)
    assert(func() == 'local')
    func = cliargs_deferred_get('foo', default='blah', shallowcopy=False)
    assert(func() == 'blah')

# Generated at 2022-06-24 18:42:12.282334
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = False
    var_0 = cliargs_deferred_get(var_0)

# Generated at 2022-06-24 18:44:44.420117
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)

# Generated at 2022-06-24 18:44:46.101685
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    _init_global_context()
    assert True # TODO: implement your test here



# Generated at 2022-06-24 18:44:48.979340
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)
    assert isinstance(var_0, types.FunctionType), "'var_0' is not 'types.FunctionType'"

# Generated at 2022-06-24 18:44:51.985188
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = True
    var_0 = cliargs_deferred_get(bool_0)
    # assert type(var_0) == <class 'function'>
    # print(type(var_0))
    # assert var_0() == bool_0

if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:44:56.324170
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    expected_value_0 = None
    expected_value_1 = None
    expected_value_2 = None

    # Call cliargs_deferred_get and check the result
    result = cliargs_deferred_get(bool_0)
    assert expected_value_0 == result

    # Call cliargs_deferred_get and check the result
    result = cliargs_deferred_get(var_0)
    assert expected_value_1 == result

    # Call cliargs_deferred_get and check the result
    result = cliargs_deferred_get(var_1)
    assert expected_value_2 == result



# Generated at 2022-06-24 18:44:57.345036
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()

# Generated at 2022-06-24 18:45:04.108530
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    bool_0 = False
    bool_1 = True
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    var_0 = cliargs_deferred_get(bool_0)
    print(type(var_0))
    var_1 = cliargs_deferred_get(str_0)
    print(type(var_1))
    str_1 = 'my_secret_key'
    var_2 = cliargs_deferred_get(str_1)
    print(type(var_2))
    str_2 = 'client_cert'
    var_3 = cliargs_deferred_get(str_2)
    print(type(var_3))
    str_3 = 'ca_cert'
    var_4 = cliargs_deferred_

# Generated at 2022-06-24 18:45:07.030465
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True


# Generated at 2022-06-24 18:45:11.086923
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('bool_0') == True
    assert cliargs_deferred_get('var_0') == None
    assert cliargs_deferred_get('str_0') == 'str_0'
    assert cliargs_deferred_get('dict_0') == {'a': 'b'}

# Generated at 2022-06-24 18:45:20.042916
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.six import PY3

    if PY3:
        from imp import reload
    else:
        from imp import reload

    # save for later restoration
    saved_cliargs_deferred_get = cliargs_deferred_get

    cli_args = {
        'bool_0': True,
        'var_0': '',
        'var_1': '',
        'var_2': '',
        'var_3': '',
        'var_4': '',
    }

    cliargs_deferred_get = saved_cliargs_deferred_get

    # setup test defaults
    bool_0 = True
    var_0 = 'default'
    var_1 = 'default'
    var_2 = 'default'
    var_3 = 'default'
